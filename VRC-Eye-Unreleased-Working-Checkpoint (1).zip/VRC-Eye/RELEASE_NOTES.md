# VRC Eye release notes

## 1.21.0 Development 21

Adds material/texture isolation and inspection, vertex colors and UV0 transforms,
read-only mesh health, reviewed exact-byte association rules with revocation and
batch undo, broader observed profile history, and ten-section settings coverage.
See [changes and entry points](DEVELOPMENT_21_RELEASE_NOTES.md),
[validation](DEVELOPMENT_21_VALIDATION.md) and [remaining work](ARC_VRCX_REMAINING_DEV21.md).
Native/live acceptance remains open.

## 1.21.0 Development 20

Extends the complete Development 19 source with typed sidebar/photo settings and
undo, Home source ages and optional sensor cadence, bounded GLB material/texture
preview, checkpointed VPM operations in recovery copies, session-day photos,
private composer blocks and read-only OSC connection diagnostics.
See [changes and entry points](DEVELOPMENT_20_RELEASE_NOTES.md),
[validation](DEVELOPMENT_20_VALIDATION.md) and [remaining work](ARC_VRCX_REMAINING_DEV20.md).
This is a runnable source checkpoint; native and live-provider acceptance remains open.

## 1.21.0 Development 15

Continues the completed Development 14 build: resumable avatar transfers, bounded
opt-in retries, publication recovery, structured Home tables and shared private notes.
Player-session details now use those same notes, reject stale/account-mismatched
drafts, preserve deliberate clears and offer the shared review editor. Roster tags
retain their existing player-list purpose. See [the continuation guide](CONTINUATION_DEV15.md)
and [validation](VALIDATION_1_21.md). All earlier files and launchers are retained.

## 1.21.0 Development 5

Adds per-field VRCX import comparisons with guarded commit/rollback; ordinary
group-role deletion; gallery creation, editing and deletion; inventory type,
slot, tag and seen filters; slot-based unequip and three profile cosmetic slots;
and animated emoji playback, stepping, atlas comparison and frame-rate presets.
Reward redemption now handles and correlates the documented result list.

The VRCX ledger now records 32 source-implemented packages and 50 partial.
See [the batch guide](VRCX_BATCH1_1_21.md),
[current development notes](DEVELOPMENT_1_21.md) and [validation](VALIDATION_1_21.md).
This remains a runnable source package with native/live acceptance outstanding.

## 1.21.0 Development 4

Enhances existing Favorites, Search, Accounts/Social, Photos, Home and
Customization with native VRCX replacement workflows. Adds reviewed migration
and backup, shared remote actions, richer media/inventory tools, notification
delivery and desktop controls. Includes the requested privacy, sidebar, photo,
search-tile and SDK/VCC download fixes, with foreground mobile QR pairing.

This is a runnable Windows/Linux source package. Full VRCX parity remains in
progress: 30 of 82 prepared packages are source-implemented and 52 are partial.
See [current development notes](DEVELOPMENT_1_21.md),
[validation](VALIDATION_1_21.md) and [remaining scope](IMPLEMENTATION_STATUS_1_21.md).

## 1.20.0 Development 5

Separate SDK/VCC public download-only tools, paged Unity patch archive browsing,
reviewed no-overwrite saves and receipts/rechecks; ten navigation-key assignments
with reviewed profiles and dialog isolation. No silent updater or installer.
See [development notes](DEVELOPMENT_1_20.md) for actual scope and validation limits.

The following sections are preserved historical release notes.

## Version 1.19.9: Remembered sign-in and keyboard login

A small update on 1.19.8. Close the old copy, extract **VRC-Eye-v1.19.9.zip**,
open **VRC-Eye**, and run **Start.cmd**. No launcher or dependency changes.

The existing VRChat connection window now has separate **Remember username** and
**Remember password** checkboxes. Either, both, or neither can be selected.
New values save only after successful sign-in, including verification. Unchecking
an option immediately forgets that stored value without deleting the other one.
**Forget saved sign-in** removes both; Disconnect only discards the current session.

**Enter and keypad Enter** submit sign-in or the requested verification code,
with duplicate-request protection and automatic focus on the code field. Mouse
buttons remain available. There is no automatic sign-in or verification bypass.

Passwords use **Windows Credential Manager**, never plaintext settings. The
username has its own per-user JSON file. Password-only mode leaves the username
blank and checks that untouched autofill belongs to the typed username. A failed
storage operation is reported without breaking an otherwise successful sign-in.
Demo/Safe mode do not read or change saved values. Non-Windows systems support
username remembering and Enter, but password remembering stays disabled.

Read **[LOGIN_GUIDE.md](LOGIN_GUIDE.md)** for the four combinations, storage,
forgetting and validation details. Native Windows storage and live VRChat sign-in
remain untested here; the release uses offline tests and real Tk keyboard checks.

---

# VRC Eye 1.19.8 — Client Bridge Lab

Builds on 1.19.7 with eight native lab views, 13 strictly scoped optional bridge
capabilities, provider SDK pre-dispatch validation, context-bound temporary
experiments, recovery evidence and cooperative playtest comparison. The real
existing services are reused. Sandbox has a separate in-memory provider; Replay
in this lab is a read-only sanitized report view. Live requires a separately
supplied approved provider. No VRChat-specific runtime plugin is shipped.

The tool palette contains 77 destinations. Networking has a Client Bridge entry
that opens the existing connection/permission manager. The original API catalog,
launchers and dependency list are retained. The release packager now explicitly
includes required runtime/reference JSON catalogs without collecting arbitrary
private JSON exports.

The shared peer transport also atomically publishes last-peer removal and its
disconnected state, with deterministic regression coverage for the cleanup race.

See CLIENT_BRIDGE_LAB_GUIDE.md, CLIENT_BRIDGE_LAB_CAPABILITIES.md and VALIDATION.md
for exact functionality, measured checks, the intermittent test observation and
unverified Windows/live behavior.

---

# VRC Eye release notes

## Version 1.19.7: Developer / Black Lab

This release extends the existing 1.19.6.1 application. Close the old copy,
extract **VRC-Eye-v1.19.7.zip**, open **VRC-Eye**, and run **Start.cmd**. Keep the
files together. The launchers and dependency list are unchanged.

Choose **Developer** in the top View selector, then open **Advanced → Developer /
Black Lab**. **Ctrl+K** also finds its sections. The workspace starts in
**Sandbox**, with live writes disarmed and no developer key required.

The new catalog has **58 entries: 37 read adapters, 18 write adapters, and 3
reference-only entries**. Live adapters use VRC Eye's existing API connection,
lock, request interval, cookies and transport. They are executable implementations,
not simulated buttons in the Live environment; **no live VRChat account or service
has been used to validate them in this build environment**. Each entry says so.

The eight sections are **Overview, API Workbench, Traffic, Events & State,
Testing Lab, Data & Recovery, Integrations, and Reports**. They include guided
fields and data-only JSON requests; exact one-use action reviews; selected
post-write verification reads; sanitized shared API and pipeline observation;
response/schema comparisons; page-by-page list inspection; shared player-state
provenance; isolated fixture failures and replay; read-only SQLite inspection;
consistent private database backups; and previewed sanitized report exports.

Networking configuration remains in **VRC Eye → Networking**, with a new
**Developer API** tab for application contact identification. Existing creator,
OSC, peer, companion and runtime services are not replaced. Opening Developer
never grants OSC permissions, starts a bridge listener, or arms live writes.
Tool search now indexes **67 destinations**.

Read **[DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)** for operation and privacy details,
**[DEVELOPER_CAPABILITIES.md](DEVELOPER_CAPABILITIES.md)** for the exact implemented
catalog and roadmap gaps, and **[VALIDATION.md](VALIDATION.md)** for verification
scope. The supplied full design is retained as **DEVELOPER_DESIGN_INPUT.md**;
it is a roadmap, not a claim that every proposal is implemented.

### Engineering changes

The API transport now records bounded sanitized diagnostics for its own requests,
including calls initiated outside the Developer workspace. A server-requested
429 delay is respected by the shared request budget. The workbench does not
retry writes. A lost response is distinguished from a rejection or a request
that never dispatched, and account/environment changes invalidate reviews and
pending operations. API caches are invalidated before write dispatch so a lost
response cannot leave the pre-write snapshot marked fresh.

New implementation modules: `developer_core.py`, `developer_catalog.py`,
`developer_service.py`, `developer_lab.py`, `developer_data.py`, and
`developer_ui.py`. New regression modules: `tests/test_developer_workbench.py`
and `tests/test_developer_native.py`.

See the historical sections in README.md and VALIDATION.md for earlier releases.
