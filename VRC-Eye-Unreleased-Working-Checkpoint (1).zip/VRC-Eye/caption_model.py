"""Bounded, memory-only live caption state and strict display preferences."""
from array import array
from collections import deque
from dataclasses import asdict, dataclass
import json
import math
import sys
import unicodedata

KEY='accessibility.live-captions.v1'
PALETTES={'Theme':None,'White on black':('#ffffff','#000000'),'Black on white':('#000000','#ffffff'),'Yellow on black':('#ffff00','#000000')}


@dataclass(frozen=True)
class Preferences:
    schema:int=1
    model:str=''
    points:int=20
    lines:int=3
    retain:int=100
    palette:str='White on black'
    topmost:bool=True
    partials:bool=True
    timestamps:bool=False

    @classmethod
    def parse(cls,raw):
        if not isinstance(raw,dict) or set(raw)-set(cls.__dataclass_fields__):raise ValueError('Use supported live-caption settings only.')
        p=cls(**raw)
        for name,low,high in (('schema',1,1),('points',12,48),('lines',1,8),('retain',10,200)):
            value=getattr(p,name)
            if type(value) is not int or not low<=value<=high:raise ValueError(f'{name} must be a whole number from {low} to {high}.')
        if not isinstance(p.model,str) or len(p.model)>4096 or any(ord(c)<32 for c in p.model):raise ValueError('Choose an extracted local speech model folder.')
        if not isinstance(p.palette,str) or p.palette not in PALETTES:raise ValueError('Choose a supported caption palette.')
        if any(type(getattr(p,k)) is not bool for k in ('topmost','partials','timestamps')):raise ValueError('Caption switches must be true or false.')
        return p

    def to_dict(self):return asdict(self)


def clean(text):
    if not isinstance(text,str):raise ValueError('The speech provider returned invalid text.')
    return ' '.join(''.join(c for c in text[:4000] if not unicodedata.category(c).startswith('C') or c in '\n\r\t').split())[:1000]


def result_text(raw,final):
    if not isinstance(raw,str) or len(raw)>32768:raise ValueError('The speech provider returned an oversized result.')
    value=json.loads(raw)
    if not isinstance(value,dict):raise ValueError('The speech provider returned invalid data.')
    return clean(value.get('text' if final else 'partial',''))


def pcm16(data,channels):
    if not isinstance(data,bytes) or not data or type(channels) is not int or not 1<=channels<=64 or len(data)>48000*64*4 or len(data)%(channels*4):raise ValueError('Invalid caption audio block.')
    samples=array('f');samples.frombytes(data);pcm=array('h')
    for start in range(0,len(samples),channels):
        values=samples[start:start+channels]
        if any(not math.isfinite(v) for v in values):raise ValueError('Invalid caption audio samples.')
        value=sum(values)/channels;pcm.append(round(max(-1,min(1,value))*32767))
    if sys.byteorder!='little':pcm.byteswap()
    return pcm.tobytes()


@dataclass(frozen=True)
class Caption:
    start:float
    end:float
    text:str


class Transcript:
    def __init__(self,limit=100):self.rows=deque(maxlen=limit);self.partial='';self.generation=0;self.revision=0;self.dropped=0
    def clear(self):self.rows.clear();self.partial='';self.generation+=1;self.revision+=1;self.dropped=0
    def resize(self,limit):
        self.dropped+=max(0,len(self.rows)-limit);self.rows=deque(list(self.rows)[-limit:],maxlen=limit);self.revision+=1
    def accept(self,event):
        kind,text,start,end=event
        if kind not in ('partial','final') or not all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=86400*365 for v in (start,end)) or end<start:raise ValueError('Invalid timed caption.')
        text=clean(text)
        if kind=='partial':
            if text!=self.partial:self.partial=text;self.revision+=1
        else:
            self.partial=''
            if text:
                if len(self.rows)==self.rows.maxlen:self.dropped+=1
                self.rows.append(Caption(start,end,text))
            self.revision+=1
    def display(self,prefs):
        rows=[(stamp(c.start)+'  ' if prefs.timestamps else '')+c.text for c in list(self.rows)[-prefs.lines:]]
        if prefs.partials and self.partial:rows.append('… '+self.partial)
        return '\n'.join(rows[-prefs.lines:])
    def export(self,kind='txt'):
        if kind=='txt':return '\n'.join(stamp(c.start)+'  '+c.text for c in self.rows)+'\n'
        if kind!='srt':raise ValueError('Choose TXT or SRT.')
        return '\n\n'.join(f'{i}\n{stamp(c.start,srt=True)} --> {stamp(max(c.end,c.start+.1),srt=True)}\n{c.text}' for i,c in enumerate(self.rows,1))+'\n'


def stamp(seconds,srt=False):
    millis=max(0,round(seconds*1000));s,ms=divmod(millis,1000);m,s=divmod(s,60);h,m=divmod(m,60)
    return f'{h:02}:{m:02}:{s:02}'+(f',{ms:03}' if srt else '')
