"""Bounded GLB linear skinning and position morph previews; no source writes.

Follows glTF 2.0: position deltas precede skinning; skinned node transforms
are ignored; joint world transforms multiply inverse bind matrices.
"""
from dataclasses import dataclass,replace
import math
import time
from avatar_scene import IDENTITY,integer,vector,name,multiply,transform,bounds
from avatar_library_files import check_cancel

MAX_SKINS=32
MAX_JOINTS=256
MAX_TARGETS=32
MAX_MORPH_VERTICES=200000


def affine(value):
    value=vector(value,16)
    if any(abs(value[i]-v)>1e-7 for i,v in ((3,0),(7,0),(11,0),(15,1))):
        raise ValueError('Skin and joint matrices must be affine.')
    return value


def morph_weights(value,count):
    value=vector(value,count)
    if any(abs(v)>4 for v in value):raise ValueError('This preview supports morph weights from -4 to 4.')
    return value


@dataclass(frozen=True)
class Skin:
    name:str
    joints:tuple
    inverse_bind:tuple


@dataclass(frozen=True)
class RigPart:
    base:tuple
    matrix:tuple
    skin:int=-1
    joints:tuple=()
    weights:tuple=()
    morph_names:tuple=()
    morph_deltas:tuple=()
    morph_weights:tuple=()


def validate_skin(skin,parents):
    if not 1<=len(skin.joints)<=MAX_JOINTS or len(set(skin.joints))!=len(skin.joints) or len(skin.inverse_bind)!=len(skin.joints):
        raise ValueError('Skin joints and inverse bind matrices must have matching bounded counts.')
    roots=[]
    for joint in skin.joints:
        if joint not in parents:raise ValueError('Every skin joint must belong to the selected scene.')
        chain=set();n=joint
        while n!=-1:
            if n in chain or len(chain)>64:raise ValueError('Invalid joint ancestry.')
            chain.add(n);n=parents[n]
        roots.append(chain)
    common=set.intersection(*roots)
    if not common:raise ValueError('Skin joints require a common scene ancestor.')
    return common


def parse_skins(doc,ordered,accessor):
    from avatar_scene import array
    source=array(doc,'skins',MAX_SKINS);nodes=doc['nodes']
    if not source and any('skin' in nodes[n.index] for n in ordered):raise ValueError('Referenced GLB skin is unavailable in this file.')
    used=sorted({integer(nodes[n.index]['skin'],0,len(source)-1) for n in ordered if 'skin' in nodes[n.index]})
    output=[];mapping={};parents={n.index:n.parent for n in ordered};total=0
    for index in used:
        row=source[index];joints=row.get('joints')
        if not isinstance(joints,list) or not 1<=len(joints)<=MAX_JOINTS or row.get('extensions'):
            raise ValueError('Choose a skin with 1–256 joints and no skin extensions.')
        joints=tuple(integer(v,0,len(nodes)-1) for v in joints)
        matrices=tuple(affine(v) for v in accessor(row['inverseBindMatrices'],'matrix')) if 'inverseBindMatrices' in row else (IDENTITY,)*len(joints)
        skin=Skin(name(row.get('name'),f'Skin {index+1}'),joints,matrices)
        common=validate_skin(skin,parents)
        if 'skeleton' in row and integer(row['skeleton'],0,len(nodes)-1) not in common:
            raise ValueError('Declared skin skeleton must be a common joint ancestor.')
        total+=len(joints)
        if total>2048:raise ValueError('Skin catalog exceeds 2,048 joint references.')
        mapping[index]=len(output);output.append(skin)
    return tuple(output),mapping


def influences(joints,weights,count,skin):
    if len(joints)!=count or len(weights)!=count:raise ValueError('Skin attributes must match the POSITION vertex count.')
    output=[];joint_rows=[]
    for js,ws in zip(joints,weights):
        if not isinstance(js,(tuple,list)) or len(js)!=4:raise ValueError('Skin joints require four indices per vertex.')
        js=tuple(integer(v,0,len(skin.joints)-1) for v in js);ws=vector(ws,4)
        if any(v<0 or v>1 for v in ws) or abs(sum(ws)-1)>1e-3:
            raise ValueError('Each vertex needs nonnegative skin weights summing to one.')
        if len({j for j,w in zip(js,ws) if w>0})!=sum(w>0 for w in ws):
            raise ValueError('A vertex cannot repeat a nonzero joint influence.')
        total=sum(ws);output.append(tuple(w/total for w in ws) if abs(total-1)>1e-12 else ws);joint_rows.append(js)
    return tuple(joint_rows),tuple(output)


def positions(rig,skins,world,weights=None,*,stop=None,deadline=None):
    weights=rig.morph_weights if weights is None else morph_weights(weights,len(rig.morph_names))
    active=[(w,d) for w,d in zip(weights,rig.morph_deltas) if w]
    matrices=tuple(multiply(world[j],ib) for j,ib in zip(skins[rig.skin].joints,skins[rig.skin].inverse_bind)) if rig.skin>=0 else ()
    output=[]
    for i,base in enumerate(rig.base):
        if i%256==0:
            check_cancel(stop)
            if deadline and time.monotonic()>deadline:raise ValueError('Deformation preview exceeded ten seconds; use a smaller source.')
        p=tuple(base[k]+sum(w*d[i][k] for w,d in active) for k in range(3))
        if matrices:
            mixed=[(w,transform(matrices[j],p)) for j,w in zip(rig.joints[i],rig.weights[i]) if w]
            output.append(vector([sum(w*v[k] for w,v in mixed) for k in range(3)],3))
        else:output.append(transform(rig.matrix,p))
    return tuple(output)


def pose(scene,overrides=None,*,joints=None,stop=None):
    from avatar_scene_pose import offsets,world_matrices,inverse
    overrides={} if overrides is None else dict(overrides)
    counts={p.node:len(p.rig.morph_names) for p in scene.parts if p.rig and p.rig.morph_names}
    if any(type(n) is not int or n not in counts for n in overrides):raise ValueError('Select a morph-bearing node from this scene.')
    overrides={n:morph_weights(v,counts[n]) for n,v in overrides.items()}
    joints=offsets(scene,{} if joints is None else joints)
    deadline=time.monotonic()+10;world,changed=world_matrices(scene,joints,stop=stop);parts=[]
    original={n.index:n.matrix for n in scene.nodes}
    for p in scene.parts:
        check_cancel(stop)
        if p.rig:
            vertices=positions(replace(p.rig,matrix=world[p.node]),scene.skins,world,overrides.get(p.node),stop=stop,deadline=deadline)
        elif p.node in changed:
            matrix=multiply(world[p.node],inverse(original[p.node]));vertices=[]
            for i,v in enumerate(p.vertices):
                if i%256==0:
                    check_cancel(stop)
                    if time.monotonic()>deadline:raise ValueError('Deformation preview exceeded ten seconds; use a smaller source.')
                vertices.append(transform(matrix,v))
            vertices=tuple(vertices)
        else:vertices=p.vertices
        parts.append(replace(p,vertices=vertices))
    box=bounds(tuple(v for p in parts for v in p.vertices))
    if max(box[1][k]-box[0][k] for k in range(3))<=1e-12:raise ValueError('These pose controls collapse the preview bounds.')
    return replace(scene,nodes=tuple(replace(n,matrix=world[n.index]) for n in scene.nodes),parts=tuple(parts),bounds=box)


def decode_skin(raw,parents):
    if not isinstance(raw,dict) or set(raw)!={'name','joints','inverse_bind'}:raise ValueError('Invalid skin provider data.')
    if not isinstance(raw['joints'],list) or not isinstance(raw['inverse_bind'],list):raise ValueError('Invalid skin provider lists.')
    label=raw['name']
    if label!=name(label,'') or not label:raise ValueError('Invalid skin label.')
    skin=Skin(label,tuple(integer(v,0,511) for v in raw['joints']),tuple(affine(v) for v in raw['inverse_bind']))
    validate_skin(skin,parents);return skin


def decode_part(raw,count,skins,budget):
    if raw is None:return None
    fields={'base','matrix','skin','joints','weights','morph_names','morph_deltas','morph_weights'}
    if not isinstance(raw,dict) or set(raw)!=fields:raise ValueError('Invalid deformation provider fields.')
    for field in fields-{'matrix','skin'}:
        if not isinstance(raw[field],list):raise ValueError('Invalid deformation provider list.')
    if len(raw['base'])!=count:raise ValueError('Deformation vertex count mismatch.')
    base=tuple(vector(v,3) for v in raw['base']);matrix=affine(raw['matrix']);skin=integer(raw['skin'],-1,len(skins)-1)
    joints=weights=()
    if skin>=0:joints,weights=influences(raw['joints'],raw['weights'],count,skins[skin])
    elif raw['joints'] or raw['weights']:raise ValueError('Orphan skin attributes in provider result.')
    names=raw['morph_names'];deltas=raw['morph_deltas']
    if len(names)>MAX_TARGETS or len(names)!=len(deltas) or any(not isinstance(v,str) or v!=name(v,'') or not v for v in names):
        raise ValueError('Invalid morph names/counts.')
    budget[0]+=count*len(names)
    if budget[0]>MAX_MORPH_VERTICES:raise ValueError('Morph output exceeds 200,000 target vertices.')
    if any(not isinstance(v,list) or len(v)!=count for v in deltas):raise ValueError('Morph vertex count mismatch.')
    return RigPart(base,matrix,skin,joints,weights,tuple(names),tuple(tuple(vector(v,3) for v in rows) for rows in deltas),morph_weights(raw['morph_weights'],len(names)))


def joint_rows(scene):
    nodes={n.index:n for n in scene.nodes};rows=[]
    for i,skin in enumerate(scene.skins):
        counts=[0]*len(skin.joints);maximum=[0.]*len(skin.joints)
        for p in scene.parts:
            if p.rig is None or p.rig.skin!=i:continue
            for js,ws in zip(p.rig.joints,p.rig.weights):
                for j,w in zip(js,ws):
                    if w:counts[j]+=1;maximum[j]=max(maximum[j],w)
        for j,node in enumerate(skin.joints):
            n=nodes[node]
            rows.append(dict(skin=i,joint=j,node=node,name=n.name,skin_name=skin.name,parent=n.parent,
                             vertices=counts[j],maximum_weight=maximum[j],world_position=n.matrix[12:15],inverse_bind=skin.inverse_bind[j]))
    return rows


def skeleton_lines(scene,visible,center,radius,camera,width,height):
    """Joint transforms from the supplied display pose; no animation or IK."""
    active={p.rig.skin for p in scene.parts if p.node in visible and p.rig and p.rig.skin>=0}
    nodes={n.index:n for n in scene.nodes};pairs=set()
    for i in active:
        joints=set(scene.skins[i].joints)
        for child in joints:
            parent=nodes[child].parent
            while parent>=0 and parent not in joints:parent=nodes[parent].parent
            if parent>=0:pairs.add((parent,child))
    cy,sy=math.cos(math.radians(camera.yaw)),math.sin(math.radians(camera.yaw))
    cp,sp=math.cos(math.radians(camera.pitch)),math.sin(math.radians(camera.pitch));scale=min(width,height)*.42*camera.zoom
    def project(node):
        x,y,z=((nodes[node].matrix[12+k]-center[k])/radius for k in range(3))
        rx,rz=cy*x+sy*z,-sy*x+cy*z
        return width*(.5+camera.pan_x)+rx*scale,height*(.5+camera.pan_y)-(cp*y-sp*rz)*scale
    return tuple((child,project(parent)+project(child)) for parent,child in sorted(pairs))
