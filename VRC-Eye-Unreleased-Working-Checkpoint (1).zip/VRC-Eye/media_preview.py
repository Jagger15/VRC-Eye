"""Cookie-free, public-HTTPS image previews for URLs explicitly selected from logs."""
from http.client import HTTPSConnection, HTTPException
import ipaddress
import socket
import ssl
from urllib.parse import urlsplit, urljoin

from player_profile import safe_link
from profile_images import preview_png, LIMIT
from vrchat_api import APIError


def public_addresses(host,port):
    try: addresses=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM)
    except OSError: raise APIError("Could not resolve the image host.") from None
    for family,kind,proto,canon,address in addresses:
        ip=ipaddress.ip_address(address[0].split('%')[0])
        if not ip.is_global: raise APIError("Image previews cannot contact local/private/reserved network addresses.")
    if not addresses: raise APIError("Image host has no supported public address.")
    return addresses


class PublicHTTPS(HTTPSConnection):
    def connect(self):
        # Resolve once, vet every answer, connect to that numeric address, verify original TLS host.
        addresses=public_addresses(self.host,self.port)
        last=None
        for family,kind,proto,canon,address in addresses:
            sock=socket.socket(family,kind,proto); sock.settimeout(self.timeout)
            try:
                sock.connect(address)
                self.sock=self._context.wrap_socket(sock,server_hostname=self.host)
                return
            except OSError as error:
                last=error; sock.close()
        raise APIError("Could not connect to the public image host.") from last


def fetch_public_image(url,*,stop=None,connection=PublicHTTPS):
    for redirect in range(6):
        if stop and stop.is_set(): raise APIError("Preview canceled.")
        if not safe_link(url): raise APIError("Choose a valid image URL.")
        parts=urlsplit(url)
        if parts.scheme!="https" or parts.port not in (None,443) or parts.fragment:
            raise APIError("Automatic previews support public HTTPS on port 443. Other links can be opened manually.")
        conn=connection(parts.hostname,443,timeout=10,context=ssl.create_default_context())
        try:
            conn.request("GET",(parts.path or "/")+("?"+parts.query if parts.query else ""),headers={"User-Agent":"VRC-Eye/1.18.6 image-preview","Accept":"image/png,image/jpeg,image/gif,image/webp","Accept-Encoding":"identity"})
            response=conn.getresponse()
            if response.status in (301,302,303,307,308):
                destination=response.getheader("Location")
                if not destination: raise APIError("Image redirect has no destination.")
                url=urljoin(url,destination); continue
            if response.status!=200: raise APIError(f"Image host returned HTTP {response.status}.")
            if response.getheader("Content-Type","").split(';')[0].strip().lower() not in ("image/png","image/jpeg","image/gif","image/webp"):
                raise APIError("The URL did not return a supported image.")
            if response.getheader("Content-Encoding","identity").lower() not in ("","identity"):
                raise APIError("Compressed HTTP responses are unsupported.")
            data=bytearray()
            while len(data)<=LIMIT:
                if stop and stop.is_set(): raise APIError("Preview canceled.")
                block=response.read(min(65536,LIMIT+1-len(data)))
                if not block: break
                data.extend(block)
            if len(data)>LIMIT: raise APIError("Image exceeds 8 MiB.")
            return preview_png(bytes(data))
        except (OSError,HTTPException,UnicodeError):
            raise APIError("Could not retrieve this image. No cookies or credentials were sent.") from None
        finally: conn.close()
    raise APIError("Image redirected too many times.")
