"""Shared presentation/accessibility controls. No permissions or account writes."""
from __future__ import annotations
import json
from pathlib import Path

from companion_ui import Page
from creator_projects import read_bytes
from friendly_ui import ScrollPane
from ui_preferences import (Presentation, CONTRASTS, COLOR_VISIONS, SCALES, DENSITIES, TEXT_SIZES,
                            ACCESSIBILITY_FIELDS, accessibility_profile, validate_accessibility_profile)

PRESETS = {
    'Large text': dict(font_scale=150, density='Comfortable'),
    'High contrast dark': dict(contrast='High contrast dark', strong_focus=True),
    'High contrast light': dict(contrast='High contrast light', strong_focus=True),
    'Large controls': dict(large_controls=True, density='Comfortable', strong_focus=True),
    'Reduced motion': dict(reduced_motion=True),
}


class AccessibilityPage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, 'Accessibility', task_controls=False)
        self.experience = self.app.experience
        self.undo_value = None
        self.scroll = ScrollPane(self.app, parent, min_width=430)
        self.tabs = self.ttk.Notebook(self.scroll.body)
        self.tabs.pack(fill='both', expand=True)
        self.frames = {}
        for name in ('Display', 'Keyboard', 'Screen reader', 'Alternate input', 'Live captions'):
            frame = self.ttk.Frame(self.tabs, padding=8)
            self.tabs.add(frame, text=name); self.frames[name] = frame
        body = self.frames['Display']
        self.variables = {}
        self.ttk.Label(body, text='Available before sign-in, offline, and in every view. These controls edit the same appearance settings used by Settings.',
                       wraplength=750).pack(anchor='w', pady=(5, 12))
        from text_scaling import FontScaleControl
        self.font_control = FontScaleControl(self.app, body, self.experience.preferences.font_percent)
        self.ttk.Button(body, text='Apply text size', command=lambda:self.guard(self.apply_text)).pack(fill='x', pady=5)
        for key, label, choices in (
            ('contrast', 'Contrast', CONTRASTS), ('color_vision', 'Color vision support', COLOR_VISIONS),
            ('scale', 'Control spacing scale (%)', SCALES),
            ('density', 'Spacing', DENSITIES)):
            self.ttk.Label(body, text=label).pack(anchor='w', pady=(8, 2))
            variable = self.tk.StringVar(value=str(getattr(self.experience.preferences, key)))
            self.variables[key] = variable
            picker = self.ttk.Combobox(body, textvariable=variable, values=choices, state='readonly', width=28)
            picker.pack(anchor='w', fill='x')
            if key in ('contrast', 'color_vision'):
                picker.bind('<<ComboboxSelected>>', lambda _:self.preview_colors())
        from color_vision import STATUS_SAMPLES
        self.color_description = self.tk.StringVar()
        self.ttk.Label(body, textvariable=self.color_description, wraplength=750).pack(anchor='w', pady=(10, 4))
        self.color_samples = []
        for role, text in STATUS_SAMPLES:
            sample = self.ttk.Label(body, text=text, anchor='w', font='TkDefaultFont', wraplength=750, padding=(8, 4))
            sample.pack(fill='x')
            self.color_samples.append((role, sample))
        self.ttk.Label(body, text='Preview only until Apply display settings. Choose whichever palette helps you. Status labels and chart shapes remain available with every palette. Custom accent values stay saved; photos, avatar materials and map images keep their original colors.',
                       wraplength=750, style='Muted.TLabel').pack(anchor='w', pady=8)
        self.preview_colors()
        for key, label in (('large_controls', 'Larger buttons and shared list rows'),
                           ('strong_focus', 'Stronger keyboard focus outlines'),
                           ('reduced_motion', 'Reduce motion in supported shared consumers')):
            var = self.tk.BooleanVar(value=getattr(self.experience.preferences, key))
            self.variables[key] = var
            self.ttk.Checkbutton(body, text=label, variable=var).pack(anchor='w', pady=(10, 0))
        for text, command in (('Apply display settings', self.apply_values), ('Undo last accessibility change', self.undo),
                              ('Reset accessibility display settings', self.reset)):
            self.ttk.Button(body, text=text, command=lambda fn=command:self.guard(fn)).pack(fill='x', pady=(8, 0))
        self.ttk.Separator(body).pack(fill='x', pady=15)
        self.ttk.Label(body, text='Profiles', style='Heading.TLabel').pack(anchor='w')
        self.preset = self.tk.StringVar(value='Large text')
        self.ttk.Combobox(body, textvariable=self.preset, values=tuple(PRESETS), state='readonly').pack(fill='x', pady=5)
        for text, command in (('Review and apply preset', self.apply_preset), ('Import profile…', self.import_profile), ('Export profile…', self.export_profile)):
            self.ttk.Button(body, text=text, command=lambda fn=command:self.guard(fn)).pack(fill='x', pady=4)
        self.ttk.Label(body, text='Keyboard: F1 opens the control guide. Tab / Shift+Tab move between controls; F6 / Shift+F6 move between regions; Ctrl+Page Up / Down change workspace tabs. Enter activates buttons and Shift+F10 opens table actions. Open Keyboard for the full guide and remapping, or Screen reader for local narration and Reading view.',
                       wraplength=750, style='Muted.TLabel').pack(anchor='w', pady=16)
        from shortcut_ui import ShortcutPanel
        self.shortcuts_panel = ShortcutPanel(self, self.frames['Keyboard'])
        from screen_reader_ui import ScreenReaderPanel
        self.reader_panel = ScreenReaderPanel(self,self.frames['Screen reader'])
        from alternate_input_ui import InputPanel
        self.input_panel = InputPanel(self,self.frames['Alternate input'])
        from caption_ui import CaptionPanel
        self.caption_panel = CaptionPanel(self,self.frames['Live captions'])
        self.status.set('Display and navigation-key settings are available before sign-in. No account or network connection is required.')

    def sync(self):
        for key, variable in self.variables.items():
            variable.set(getattr(self.experience.preferences, key))
        self.font_control.set(self.experience.preferences.font_percent)
        self.preview_colors()

    def preview_colors(self):
        from color_vision import DESCRIPTIONS, semantic_colors
        preferences = self.experience.preferences.changed(**{key:self.variables[key].get() for key in ('contrast', 'color_vision')})
        from appearance_colors import palette
        base = getattr(self.app, '_base_theme_colors', None)
        colors = semantic_colors(preferences, palette(preferences, base) if base else None)
        self.color_description.set(DESCRIPTIONS[preferences.color_vision])
        for role, sample in self.color_samples:
            sample.configure(background=colors['panel'], foreground=colors[role])

    def apply_text(self):
        self.change(dict(font_scale=self.font_control.get()))

    def change(self, values):
        self.undo_value = {key:getattr(self.experience.preferences,key) for key in ACCESSIBILITY_FIELDS}
        self.experience.change(**values)
        self.sync()
        self.status.set(self.experience.notice.get())

    def apply_values(self):
        values={key:variable.get() for key,variable in self.variables.items()}
        values['scale']=int(values['scale'])
        values['font_scale']=self.font_control.get()
        self.change(validate_accessibility_profile(dict(schema=1,**values)))

    def review(self, values):
        lines=[f'{key.replace("_"," ").title()}: {getattr(self.experience.preferences,key)} → {value}' for key,value in values.items()]
        if self.confirm('Review accessibility changes', '\n'.join(lines)+'\n\nNo accounts, shortcuts, integrations or permissions are imported.'):
            self.change(values)

    def apply_preset(self):
        self.review(PRESETS[self.preset.get()])

    def reset(self):
        defaults=Presentation()
        self.review({key:getattr(defaults,key) for key in ACCESSIBILITY_FIELDS})

    def undo(self):
        if self.undo_value is None:
            raise ValueError('There is no accessibility change to undo in this session.')
        previous=self.undo_value
        self.change(previous)

    def import_profile(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title='Import accessibility profile',filetypes=[('JSON profile','*.json')])
        if not path:return
        try:
            raw=json.loads(read_bytes(Path(path),65536).decode('utf-8-sig'))
        except (UnicodeError,json.JSONDecodeError,RecursionError) as error:
            raise ValueError('The selected file is not a supported JSON profile.') from error
        self.review(validate_accessibility_profile(raw))

    def export_profile(self):
        from tkinter import filedialog
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Export accessibility profile',initialfile='VRC-Eye-Accessibility.json',defaultextension='.json')
        if not path:return
        with Path(path).open('x',encoding='utf-8') as stream:
            json.dump(accessibility_profile(self.experience.preferences),stream,indent=2)
        self.status.set('Accessibility profile exported. No account, project, photo or credential data was included.')
