"""One delivery policy for normalized events and existing player banners."""
from collections import OrderedDict
from datetime import datetime
import time


def quiet(policy,now=None):
    if policy.get('dnd'):return True
    if not policy.get('quiet_hours'):return False
    now=now or datetime.now().astimezone();minute=now.hour*60+now.minute
    start,end=policy['quiet_start'],policy['quiet_end']
    return start<=minute<end if start<end else minute>=start or minute<end


class Delivery:
    def __init__(self,shell,*,clock=time.monotonic):
        self.shell,self.clock=shell,clock;self.seen=OrderedDict();self.pending=[];self.visible_until=0;self.context=None;self.last_sound=-1e30;self.was_quiet=False
        self.batch_started=None;self.cooldowns=OrderedDict()

    def clear(self):
        reader=getattr(getattr(self.shell,'app',None),'screen_reader',None)
        if reader and reader.notification_pending:reader.stop()
        self.pending.clear();self.seen.clear();self.shell.native_banner.set('');self.visible_until=0
        self.batch_started=None;self.cooldowns.clear()
        service=getattr(self.shell,'desktop_service',None)
        if service:
            service.speech.cancel()
            runtime=service.vr_runtime()
            if runtime:runtime.display_social({})

    def enqueue(self,row,category='ACCOUNT'):
        key=row.get('delivery_id')
        if not key or key in self.seen:return
        self.seen[key]=self.clock()
        while len(self.seen)>2000:self.seen.popitem(last=False)
        self.pending=(self.pending+[(dict(row),category)])[-200:]
        if self.batch_started is None:self.batch_started=self.clock()

    def tick(self,hub,policy,*,blocked=False):
        projection=hub.project()
        if self.context!=hub.generation:
            self.context=hub.generation;self.clear()
        if blocked or not projection['account']:self.clear();hub.delivery.clear();hub.social_delivery.clear();return
        is_quiet=quiet(policy)
        if is_quiet and not self.was_quiet:
            reader=getattr(getattr(self.shell,'app',None),'screen_reader',None)
            if reader and reader.notification_pending:reader.stop()
            service=getattr(self.shell,'desktop_service',None)
            if service:
                service.speech.cancel()
                runtime=service.vr_runtime()
                if runtime:runtime.display_social({})
        self.was_quiet=is_quiet
        if is_quiet or not policy.get('banners'):
            self.shell.native_banner.set('');self.visible_until=0
        for row in hub.delivery:self.enqueue(row)
        hub.delivery.clear()
        for row in hub.social_delivery:self.enqueue(row,'SOCIAL')
        hub.social_delivery.clear()
        # Suppress queued alerts that were read or hidden before the batch fired.
        self.pending=[(row,category) for row,category in self.pending
            if not hub.notifications.get(row.get('delivery_id'),{}).get('deleted')
            and hub.notifications.get(row.get('delivery_id'),{}).get('seen') is not True]
        if is_quiet:self.pending.clear();self.batch_started=None
        if self.clock()>=self.visible_until:self.shell.native_banner.set('')
        if not self.pending:self.batch_started=None;return
        if self.clock()-self.batch_started<policy.get('notification_batch_seconds',0):return
        rows=self.pending;self.pending=[];self.batch_started=None
        permitted=[]
        for row,category in rows:
            key=(row.get('cooldown_key') or row.get('senderUserId') or row.get('type','unknown'),row.get('type','unknown'))
            if self.clock()-self.cooldowns.get(key,-1e30)<policy.get('notification_cooldown_seconds',0):continue
            if self.shell.companion.notify(category)['allow'] and row.get('type','unknown') not in policy.get('muted_types',[]):permitted.append(row)
        if not permitted or quiet(policy):return
        for row in permitted:
            key=(row.get('cooldown_key') or row.get('senderUserId') or row.get('type','unknown'),row.get('type','unknown'))
            self.cooldowns[key]=self.clock();self.cooldowns.move_to_end(key)
        while len(self.cooldowns)>2000:self.cooldowns.popitem(last=False)
        priorities=policy.get('priority_types',[])
        permitted.sort(key=lambda r:r.get('type') not in priorities)
        if len(permitted)>1:
            r=permitted[0]
            priority=(str(r.get('type'))+': '+str(r.get('senderUsername') or '')+' · '+str(r.get('message') or ''))[:200] if r.get('type') in priorities else ''
            watched=any(str(r.get('type','')).startswith('watch-') for r in permitted)
            destination='Feed → Watchlists and Social → Inbox' if watched else 'Social → Inbox'
            noun='updates' if watched else 'notifications'
            message=(priority+'\n' if priority else '')+f'{len(permitted)} new VRChat {noun}. Open {destination} to review.'
        else:
            r=permitted[0];message=(r.get('senderUsername','')+' · '+str(r.get('message') or r.get('type','Notification')))[:450]
        if policy.get('banners'):
            self.shell.native_banner.set(message);self.visible_until=self.clock()+policy.get('banner_seconds',15)
        service=getattr(self.shell,'desktop_service',None)
        reader=getattr(self.shell.app,'screen_reader',None)
        if service and policy.get('speech'):
            spoken=message if policy.get('speech_details') else f'{len(permitted)} new VRChat notification'+('s' if len(permitted)!=1 else '')
            if reader and reader.preferences.mode!='Off':reader.announce(spoken,key='notification')
            else:service.speech.say(spoken)
        if service and service.vr_active and policy.get('vr_notifications'):
            runtime=service.vr_runtime()
            if runtime:runtime.display_social(dict(enabled=True,text=message,seconds=policy.get('banner_seconds',15)))
        if policy.get('sound') and self.clock()-self.last_sound>=3:
            tools=getattr(self.shell,'session_tools',None)
            if not tools or not tools.event_sound(permitted):self.shell.app.root.bell()
            self.last_sound=self.clock()

    def player(self,message,policy):
        from account_header import private
        if private(self.shell.app) or quiet(policy) or not policy.get('banners'):return ''
        return message
