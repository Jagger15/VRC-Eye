# Alternate input and editable Home tiles

## Start alternate input

Open the **Alternate input** header button or **Accessibility → Alternate input**.
Choose a mode and timing, apply the settings, then select **Start alternate input**.
Settings persist for the local profile; scanning and dwell always start explicitly
for each session. Demo and Safe mode keep settings in the current session.

| Mode/control | Behavior |
| --- | --- |
| Two switches | One key advances focus; another selects the focused control. |
| One switch auto scan | Focus advances at the selected interval; the select key chooses the highlighted control. |
| Pointer dwell | A stationary pointer activates an enabled button, checkbox or radio control after the selected delay. |
| Default keys | F8: next; F9: select; F7: pause/resume. Choose different listed function keys if needed. |
| Escape | Stop alternate input and cancel an active layout drag. |
| Header button while active | Stop alternate input immediately. |

Scan and dwell timing accept 500–10000 milliseconds. Pointer tolerance accepts
0–40 pixels. The footer shows input state and dwell progress. Move away before
the countdown completes to cancel it. After activation, leaving the control is
required before it can activate again, including when the button's label changes.
Starting input and changing focus/workspace require fresh pointer movement before
dwell resumes. F7 pauses scanning and dwell; F9 resumes a paused scan.

Switch keys act on release. Held keys and X11 repeat pairs do not repeatedly
activate controls. Pending selection is cancelled when the target, its command,
account/privacy context, workspace or modal owner changes. Scanning considers
visible, enabled controls in the active app window and excludes hold controls.
Ordinary typing pauses scanning and leaves native typing, shortcuts and text
editing available. Shortcut conflicts are rejected when starting or applying
input settings; active switch keys cannot be reassigned as navigation shortcuts.

Selecting a field, list or slider opens **Control actions**. These offer changes
to values/selections, scrolling and table row details where supported. Editable
text fields also get a small on-screen keyboard with letters, numbers, symbols,
case, space and backspace. Multiline editors have a New line button. Password
entry uses the original protected widget; the action window does not copy or
display its contents. OS keyboards and dictation can enter additional characters.
Closing the action window returns to the original control when it is still valid.

Import/export on the same page uses a data-only input profile. Import shows a
review and leaves input stopped. Apply, Undo and Reset also stop active input so
new key assignments or timings take effect deliberately.

This supports switches/controllers that emit ordinary keyboard input and
head/eye/voice tools that supply ordinary pointer input. It does not include a
raw gamepad driver, gaze tracker or speech-recognition engine. Native OS file
dialogs, menus, external applications and VRChat use their own input mechanisms.
No global hooks, scripts or game input are generated.

## Edit Home tiles

The visible header lock has both a bitmap icon and a text state. Every app
session begins **locked**. Unlock it to expose Home tile editing controls.

- Drag the **Move tile** handle onto another tile to reorder it, or use
  **Earlier / Later**. Pinned and unpinned tiles retain their separate ordering.
- Drag **Resize tile**, or use **Narrower / Wider / Shorter / Taller**. Width
  snaps to one, two or three columns. Minimum height is stored in 50-unit steps,
  up to 1200, and scales with desktop text. Content remains readable; it is not
  cropped to force a smaller height. Tiles in a grid row share the row's height.
- **Hide** removes a tile from view while retaining its identity, settings and
  account-scoped notes. **Restore hidden tiles** restores manually hidden tiles
  in the current layout. Visibility conditions still apply after locking.
- **Undo layout edit** reverses up to 20 direct edits in this session. It refuses
  to overwrite later changes to the same layout from another editor.
- **Customization → Home layout** also offers Hide/Show selected. Structural
  edits there use the same lock and saved layout document. Its existing reset,
  import/export and settings-history tools remain available.

Dragging makes no saved change until release. Escape, release outside the layout,
changed focus/modal ownership, a changed layout, or an account/privacy change
cancels it. Account/privacy changes also relock the layout. The active Home
layout is held while editing so automatic rules cannot switch it mid-edit.
Locking resumes normal conditional layout selection and hides the editing handles.

Editing is scoped to Home tiles. Essential navigation, input recovery, the lock,
dialogs and workflow controls retain their existing layouts. This is a responsive
tile editor, not arbitrary repositioning of every widget in the application.

## Verification and platform acceptance

`ALTERNATE_INPUT_QUALIFICATION.json` and the `alternate_input_update` entry in
`PENDING_WORKING_VALIDATION.json` record the source hashes and exact test results.
Portable tests cover strict profile validation, persistence/Undo, session-only
behavior, key release/repeat, modal/focus/privacy cancellation, dwell re-entry and
restarting commands, timer cleanup, protected typing, tile hide/restore, sizing,
drag release/cancel, concurrent edits and conditional-layout behavior.

Seven real-Tk cases are supplied in `tests/test_alternate_layout_native.py`.
They require a graphical Windows/Linux desktop and were not executable here.
Actual assistive-device use, keyboard/pointer delivery, native rendering, DPI,
500% text workflows and screen-reader interoperability remain platform acceptance
tasks. This checkpoint contains source and evidence, not a compiled release.

Design references: [W3C dragging alternatives](https://www.w3.org/WAI/WCAG22/Understanding/dragging-movements.html)
and [pointer cancellation](https://www.w3.org/WAI/WCAG22/Understanding/pointer-cancellation.html).
