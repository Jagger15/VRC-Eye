# VRC Eye 1.20.0 — Development checkpoint 8

This checkpoint attempts the pending ARC-inspired work with concrete desktop
features and an optional Unity editor-source subset. It extends Development 7;
the complete 1.20 roadmap remains unfinished.

## Start this build

Close the running copy and back up settings/databases. Extract all of
**VRC-Eye-v1.20.0-Development-8.zip** into a fresh folder and run **VRC-Eye/Start.cmd**.
Keep the previous build. Do not run two versions against the same databases.
On Linux, use Python 3.10 or newer with Tkinter and the existing `requirements.txt`
dependencies, then run `python3 vrc_eye.py` from the extracted `VRC-Eye` folder.
All four launchers and `requirements.txt` are unchanged. This is a source package;
new Windows executables and Flatpak packaging are not included.

Baseline Development 7 SHA-256:
`42139a9544a53c80850b7c9fac5f5981844ee735547d4e86ee02a5f336e48e48`.
The previous archive is preserved.

## What is new

| Addition | Location / behavior |
|---|---|
| Real mesh preview | Avatar Library → 3D preview. Explicit local OBJ geometry with orbit, pan, zoom, fit, flat shading and wireframe. |
| Folder discovery | Avatar Library → Folder discovery. Bounded selected-folder/cache candidate scan and session-only opt-in rescans. Each file/avatar association is separately reviewed. |
| Bulk metadata import | Avatar Library → Import & export. Up to 500 avatar objects, frozen review and one database transaction; preserve notes/favorites/thumbnails/files. |
| HTML galleries | The same section. Export selected avatar or current filtered page into a standalone static HTML file, with optional saved thumbnails. |
| Recovery preparation | Avatar Library → Recovery. Verified source-copy handoff plus read-only inspection of manually recovered Unity output. |
| Unity repair copies | Optional Avatar Toolkit menu: VRC Eye → Avatar Repair Copies. Explicit shader replacement on material copies, missing-normal mesh copies, animation path remapping and missing-script prefab copies. Source files and assignments remain. |
| Unity mesh export | The same editor window exports a bounded source-local OBJ compatible with the desktop viewer. |
| Integrity fixes | File associations validate before transaction commit; exports/copies pin/check publication identities. Clearing prepared work invalidates pending callbacks. |

The existing Avatar Library worker, catalog and account/privacy lifecycle are
reused. The new desktop panels do not scan, download, execute a recovery tool,
change the worn avatar or grant permissions merely by opening.

See **[ARC_FEATURES_1_20_DEV8.md](ARC_FEATURES_1_20_DEV8.md)** for supported formats,
limits and workflows; **[IMPLEMENTATION_STATUS_1_20.md](IMPLEMENTATION_STATUS_1_20.md)**
for the complete carried-forward roadmap.

## What remains partial

The desktop viewer loads OBJ geometry; it does not decode VRCA/FBX, run Unity
shaders, skin a rig or play animations. Unity repair operations are bounded source
copy tools, not universal repairs. Their editor code and EditMode tests are
included, but native Unity compile/execution must still be verified.

The reviewed official AssetRipper GUI arguments did not establish a supported
automatic export command for this integration. VRC Eye prepares a handoff and
inspects manually exported output. Actual extraction happens in AssetRipper separately. No ARC, AssetRipper,
AssetViewer or FACS executable/source package is copied into this build.

## Validation

The clean-extracted desktop package passed 4,044 tests and 1,141 subtests,
with no failures, errors or skips. Details are recorded in BUILD_VALIDATION.json. Desktop validation uses synthetic files/accounts, temporary stores and real Linux/Tk
widgets with external sockets blocked. C# syntax parsing and static contracts are
separate from native Unity compilation. No real avatar was recovered or repaired,
no live VRChat write was sent, and no uploaded third-party executable was run.

Native Windows, installed Unity/AssetRipper/VPM, live VRChat/VRCX, Flatpak and
screen-reader interoperability remain unverified. Launchers and runtime dependency
requirements are carried forward unchanged.

## Final Development 8 validation

The clean-extracted package passed **4,044 tests and 1,141 subtests**,
with no failures, errors or skips. This includes **268 new test cases**,
63 using real Tk workflows. All **368 Python files** passed Python 3.10 grammar
checks. The **414-file** source manifest matches the clean-tested code.

The external-socket guard reported 8 blocked attempts in the final run;
no external socket traffic was allowed. Two pre-existing test/dependency warnings
remain; details are in BUILD_VALIDATION.json. Validation used synthetic inputs and
accounts, temporary stores and Linux/Tk. No live VRChat write or third-party
recovery executable was run.

Both new C# files passed syntax parsing and Python contract checks. These checks
do not establish Unity compilation or runtime behavior. The 37 supplied native
Unity test cases remain unexecuted. Native Windows and installed Unity/VPM
verification remain pending.

The **497-file archive** retains all 473 Development 7 paths. Launchers and
requirements.txt are byte-identical. Final documentation and validation metadata
were added after the clean-code suite; runtime/test/Unity bytes were rechecked
against that tested source before packaging.
