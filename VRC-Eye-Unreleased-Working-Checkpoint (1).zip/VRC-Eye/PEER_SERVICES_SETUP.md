# VRC Eye Peer Services — 1.19.1

Open **VRC Eye → VRC Eye Primary** for local tools and shared activities, and
**VRC Eye → Networking** for connections. All connections start off. The
application opens in Private Mode on every launch; reconnecting is an explicit
choice. See **NETWORKING_SETUP.md** for the expanded provider options.

## Private Mode

No VRC Eye account, relay, Hamachi installation or networking package is needed
to edit the local profile/bio, maintain personal notes/bookmarks, plan a party or
photo session, run timers, maintain creator checklists/playtests, capture supported
local diagnostic/performance cards, compare saved runs, or import/export safe
presets. The local workspace uses its own SQLite database beside the existing
companion database.

Private Mode disables VRC Eye peer networking. It does not disable independent
VRChat API features, VRCX Companion, the client bridge or ordinary application
functions. No local profile field or record is published simply by connecting.
Select the fields you permit, review the recipient and choose Share explicitly.
An incoming card never silently becomes a local favorite, applied preset or command.

Local saved records and local optional conversation history are different:
explicitly saved notes/plans remain local files even when conversation history is
off. History is off by default. Player List's Session only history and Incognito
settings restrict peer retention; presentation/streamer settings suppress private
notices. Local storage is not a claim of encrypted-at-rest storage.

## Connections

**Start.cmd** automatically prepares `cryptography`, `psutil` and the other app
dependencies in its local environment. This does not install Hamachi or connect
a service. Private tools remain available after an offline setup failure; reopen
**Start.cmd** when online to retry missing packages.

Connections authenticate VRC Eye installations using a persistent device signing
key and pinned TLS. A displayed alias is not an identity credential. The protocol
negotiates supported capabilities, while each action still requires local policy,
recipient policy, compatible context and a current connection.

1. On the hosting computer, open **VRC Eye → Networking** and choose the connection mode.
2. Choose the local adapter/address and port for LAN/Hamachi, or supply the relay
   address, port and trusted relay certificate fingerprint for Relay mode.
3. Start hosting and wait for the listening/ready state.
4. Create an expiring invitation and share it privately with the intended person.
5. The other person pastes the invitation, reviews its destination and joins.
6. Select the authenticated device in the peer picker. Share a profile field,
   whisper, card or plan explicitly. The receiver can allow once, grant an
   appropriate longer scope, or deny.

Connections form a host-to-guest group: each guest connects to the host, and the
host can share a party board with selected guests and request their readiness.
Guests do not gain a route to message other guests. Pair separately for a private
conversation between those installations. The UI shows each member's individual
consent and readiness; an unanswered request is never counted as ready.

Invitations contain connection credentials. They are expiring and one-use, are
not stored in ordinary preferences/history and are excluded from diagnostic
exports. Create a separate invitation for each participant. Sharing an invitation
authorizes pairing with whoever possesses it; it does not prove their real-world
or VRChat identity. Invitations must not be posted publicly.

Private Mode closes the host/listeners and peer connections, revokes temporary
approvals and ends active shared context. Local plans stay editable. Reconnection
does not replay countdowns, media cues or celebrations, or upload private drafts.

### Hamachi by LogMeIn

Install and configure Hamachi separately. Participants need a common reachable
Hamachi network; a mesh network is the straightforward arrangement for a small
group. Refresh local adapters in VRC Eye and select the detected Hamachi adapter.
Host in Hamachi mode and distribute separate VRC Eye invitations to participants.
Windows may require an application-specific firewall allowance on that adapter.
VRC Eye does not change firewall policy, Hamachi networks or account settings.
This release supports Hamachi's IPv4 mesh addresses (25.x.x.x) with a detected
Hamachi adapter on both ends. Gateway-mode and IPv6-only networks are not supported.

Hamachi provides the VPN route; VRC Eye still performs its own device handshake,
TLS pin verification, schema validation and consent checks. A Hamachi network
member is not automatically allowed to view diagnostics or receive a bio.
Hamachi depends on its provider's infrastructure. Direct VPN connections can
expose peers' underlying network endpoints; this mode does not promise public-IP
anonymity. Binding uses the selected local interface, not all interfaces.

### LAN

Use a specific local adapter address. Loopback is useful for testing on one
computer. A LAN or direct connection reveals the chosen endpoint to the peer.
There is no automatic LAN scan, router configuration or UPnP port forwarding.

### Self-hosted relay

The source includes `peer_relay.py`. There is no public VRC Eye relay provisioned
by this release. An operator can run it on a machine reachable by the participants:

```text
python peer_relay.py --bind YOUR_RELAY_ADAPTER_IP --port 8769
```

The relay prints its certificate SHA-256 fingerprint. Distribute that fingerprint
through a trusted channel; do not obtain it from an unverified connection. In the
VRC Eye Networking category choose Relay, enter its hostname/address, port and pin,
then host and create invitations as above. The default relay CLI bind is loopback
only. The operator controls exposure, firewall rules and service availability.

Relay transport uses outer pinned TLS plus a separate pinned TLS connection
between the applications. The relay forwards opaque bytes and cannot decrypt the
inner application payloads. It sees connection endpoints, timing and traffic
sizes. Connected applications see the relay endpoint rather than each other's
direct address. This is a live tunnel, not an account service, global directory
or offline message mailbox. Stop it with Ctrl+C.

## Workspace features

| Feature | Local use | Optional peer behavior |
|---|---|---|
| Profile / bio | Edit fields and visibility | Explicitly share permitted fields |
| Availability | Set availability and local DND behavior | Share current availability; stale state remains unknown |
| Session card | Capture available runtime/session summary | Share a reviewed card |
| Whispers | Private note/draft and optional retained history | Send/receive with delivery and consent states |
| Bookmarks / recommendations | Personal world/avatar reference lists and notes | Send references; accepting does not change VRChat favorites |
| Party board / roles | Private destination plan and notes | Share revisioned session plans and VRC Eye-only roles |
| Ready checks | Save preparation templates | Request explicit Ready / Not Ready responses; silence is no response |
| Countdowns / photo plans | Solo timer, shot list and pose notes | Share a target time and photo plan with uncertainty shown |
| Media cues | Cue sheet and playback markers | Exchange approved cue markers; no remote audio playback |
| Safety check-ins / alerts | Own peer safety setting and personal notices | Explicit check-in/reply or minimal state alert |
| Diagnostic cards | Capture, sanitize, preview and save | Share selected structured information |
| Troubleshooting | Local diagnostic tools and support preparation | Request narrow information; no remote desktop, shell or filesystem access |
| Presets | Export/import allowlisted preferences, diff and rollback | Transfer the same package for a separate local import review |
| Creator sessions / checklists | Solo test phases, pass/fail results and notes | Share revisioned snapshots; private originals remain separate |
| Performance comparison | Compare own or imported measurements | Share sanitized measurement cards with source and sample context |
| Diagnostic confirmations | Record a local observation | Match independent device reports; agreement does not prove cause |
| Encounter confirmation | Local observations remain separately labeled | Count only matching reciprocal peer reports |
| Notices / celebrations | Personal static notices and timers | Recipient owns display, duration, suppression and accessibility |
| Permissions | Configure local policy and blocks | Directional, scoped approvals and immediate revocation |

Profile icons are small text/symbol fields, not arbitrary image uploads. Avatar
recommendations are references only and do not grant access to private avatars.
Capability/version displays describe authenticated installations and advertised
support; they do not prove the identity of a VRChat player.

Safety Mode in this workspace controls peer presentation/sharing preferences. It
does not claim to activate VRChat's in-game safety controls. Startup Safe Mode is
a separate recovery setting and blocks optional peer networking entirely.

## Diagnostics, presets and measurements

Capture reads existing VRC Eye providers. Missing or stale measurements are
unavailable; captures do not start a hidden process monitor or invent FPS. A point
sample is labeled as such. Comparing two snapshots does not establish that an
avatar caused a performance problem; hardware and measurement windows may differ.

Diagnostic cards use closed schemas and omit raw logs, account credentials,
tokens, filesystem paths, Windows usernames, unrelated player history and
Whisper text. Review a card before sharing. A voluntarily entered note is still
your text; review it before including it in any explicitly shared plan/card.

Preset transfer supports a deliberate allowlist of Wellness reminder/display
preferences and Resource Guard display mode. It cannot transfer peer permissions,
API credentials, executable paths, network settings, automatic process actions,
local history, user notes or entire settings files. Import presents a diff and
applies a verified SQLite transaction with an in-memory rollback checkpoint.
Open Wellness and Resource Guard views refresh immediately without starting
providers or restarting a session. Rollback refuses to overwrite settings changed
after import. Close the page or app and the in-memory undo checkpoint is gone.

## Player List and notices

Player details → VRC Eye link associates an exact player ID with a known device
only after local review. The row's Eye linked label means a local association,
not verified VRChat identity or proof of current presence. The existing profile
Whisper tab opens the same workspace and owns no second connection.

Accepted notices appear in the app. Optional SteamVR notices use the existing
Wellness SteamVR input connection and optional OpenVR/Pillow components; enable
them in the peer presentation preferences. Notices are static and bounded, with
no remote control over opacity, position, audio or full-screen behavior. Receiver
privacy and accessibility preferences take priority. The input worker expires the
notice independently of UI updates.

## Developer tools and limits

Developer view provides bounded metadata, capability explanations and isolated
protocol/permission simulations. Simulations do not open sockets or modify the
real peer workspace. Black Box integration records event categories and counts,
never peer names, addresses, invitations or message bodies.

Explicitly sent queueable Whispers, references and presets can wait locally for
an offline known device. After reconnecting, choose **Review queued messages…**
and review their contents before sending. Ready checks, countdowns, media cues
and celebrations cannot wait for reconnection. Queue lifetime and size limits
still apply; the relay never stores messages and restarting the app discards
outgoing jobs.

This release has no cloud account synchronization, multi-device account routing,
public directory, automatic reconnection, remote OS control or background cloud
message retention. Devices can pair without a VRC Eye account. A connection drop
leaves local tools usable; a saved local object is never an implicit outbound job.
Native Windows/Tk, real Hamachi networks and physical SteamVR overlays still need
testing on the target installation. See VALIDATION.md for automated checks.

## Primary protocol/dependency references

- Python SSL: https://docs.python.org/3.10/library/ssl.html
- Cryptography X.509: https://cryptography.io/en/stable/x509/tutorial/
- Hamachi networking: https://vpn.net/
- Hamachi architecture: https://vpn.net/security
- Hamachi address modes: https://lmi-documentation-origin.azurewebsites.net/webhelp/EN/CentralUserGuide/LogMeIn/c_hamachi_Virtual_IP.html
