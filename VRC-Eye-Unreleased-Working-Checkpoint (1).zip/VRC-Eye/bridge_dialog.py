"""Advanced, optional bridge supervisor and reviewed capability-specific controls."""

from text_viewport import window_body
import json

from bridge_protocol import BridgeError,CAPABILITIES,fresh_id,parameters
from companion_ui import Table,line,button,entry,choice


def show_bridge(app):
    if getattr(app,"safe_mode",False):
        from tkinter import messagebox
        messagebox.showinfo("Safe Mode", "Client bridge is disabled in Safe Mode. Restart normally to enable it.", parent=app.root)
        return
    existing=getattr(app,"bridge_dialog",None)
    if existing and not existing.closed:existing.window.lift();return existing
    window=BridgeDialog(app);app.bridge_dialog=window;return window


class BridgeDialog:
    def __init__(self,app):
        self.app=app;self.tk=app.tk;self.ttk=app.ttk;self.bridge=app.bridge;self.closed=False;self.pending=[];self.copied="";self.rendered=None
        self.window=self.tk.Toplevel(app.root);self.window.title("VRC Eye · Advanced client bridge");self.window.geometry("1120x890");self.window.minsize(960,760)
        self.window.configure(bg=app.BG);self.window.protocol("WM_DELETE_WINDOW",self.close)
        self.parent=self.ttk.Frame(window_body(self.window),padding=18);self.parent.pack(fill="both",expand=True)
        self.status=self.tk.StringVar(value="Disabled.");self.identity=self.tk.StringVar(value="No client connected.")
        self.consent=self.tk.StringVar(value="This connection");self.details=self.tk.StringVar(value="Select a capability for its status and client-defined preset details.")
        self.controls=self.tk.BooleanVar(value=False);self.paused=self.tk.BooleanVar(value=False)
        self.action=self.tk.StringVar(value="");self.target=self.tk.StringVar(value="");self.value=self.tk.StringVar(value="")
        self.ttk.Label(self.parent,text="Advanced · Client bridge",style="Title.TLabel").pack(anchor="w")
        self.ttk.Label(self.parent,textvariable=self.identity,wraplength=1050).pack(anchor="w",pady=5)
        self.ttk.Label(self.parent,textvariable=self.status,wraplength=1050,style="Muted.TLabel").pack(anchor="w",pady=5)
        row=line(self);button(self,row,"Enable bridge",self.enable);button(self,row,"Disable bridge",self.disable)
        button(self,row,"Copy connection code",self.copy_code);button(self,row,"Disconnect client",self.disconnect)
        self.ping_button=button(self,row,"Test connection",self.ping)
        self.ttk.Label(self.parent,text="Optional local IPC. VRC Eye stays external. Each new connection starts in quarantine; approve only the capabilities you want. Client identity and measurements are reported by the adapter, not independently verified.",wraplength=1040,style="Muted.TLabel").pack(anchor="w",pady=4)
        self.table=Table(self,self.parent,(("cap","Capability",260),("kind","Type",80),("state","Approval / availability",245),("title","Purpose",290)),height=8,select=self.selection)
        self.table.tree.configure(selectmode="extended")
        row=line(self);choice(self,row,self.consent,("This connection","10 minutes","1 hour"),width=19)
        button(self,row,"Approve selected…",self.approve);button(self,row,"Revoke selected",self.revoke_selected);button(self,row,"Revoke all",lambda:self.bridge.state.revoke())
        row=line(self)
        self.ttk.Checkbutton(row,text="Enable approved local game controls for this connection",variable=self.controls,command=lambda:self.guard(self.toggle_controls)).pack(side="left")
        self.ttk.Checkbutton(row,text="Pause bridge requests (keep telemetry)",variable=self.paused,command=lambda:self.guard(lambda:self.bridge.state.pause_requests(self.paused.get()))).pack(side="left",padx=8)
        self.ttk.Label(self.parent,textvariable=self.details,wraplength=1040,style="Muted.TLabel").pack(anchor="w",pady=5)
        self.actions_frame=self.ttk.Frame(self.parent)
        self.ttk.Label(self.actions_frame,text="Connected-client local controls",style="Accent.TLabel").pack(anchor="w")
        row=line(self,self.actions_frame);self.action_box=choice(self,row,self.action,(),self.action_changed,37)
        self.ttk.Label(row,text="User ID(s):").pack(side="left");entry(self,row,self.target,42)
        row=line(self,self.actions_frame);self.value_box=choice(self,row,self.value,(),width=20);button(self,row,"Review and request local change…",self.apply)
        self.telemetry=self.tk.Text(self.parent,height=7,wrap="word",state="disabled");self.telemetry.pack(fill="both",expand=True,pady=5)
        self.ttk.Label(self.parent,text="Telemetry expires after three seconds; the connection lease expires after five seconds without a heartbeat. Disconnect, runtime/account changes, consent expiry and revocation disable affected actions. Sent actions cannot be undone by disconnecting. Closing this panel leaves an enabled bridge running.",wraplength=1040,style="Muted.TLabel").pack(anchor="w",pady=5)
        row=line(self);button(self,row,"Show recent bridge requests",self.show_ledger);button(self,row,"Close panel",self.close)
        self.tick()

    def guard(self,action):
        try:return action()
        except (BridgeError,OSError,ValueError) as error:self.status.set(str(error))
    def confirm(self,title,text):
        from tkinter import messagebox
        return messagebox.askyesno(title,text,parent=self.window)
    def sync_environment(self):
        self.bridge.environment(self.app.api.user_id if self.app.api and self.app.api.authenticated else "",bool(self.app.demo))
    def enable(self):
        self.bridge.environment(self.app.api.user_id if self.app.api and self.app.api.authenticated else "",self.app.demo)
        self.bridge.start();self.status.set("Local bridge enabled. Give the connection code only to the adapter you choose.")
    def clear_clipboard(self):
        if self.copied:
            try:
                if self.app.root.clipboard_get()==self.copied:self.app.root.clipboard_clear()
            except Exception:pass
            self.copied=""
    def disable(self):self.bridge.stop();self.clear_clipboard();self.status.set("Bridge disabled and connection code invalidated.")
    def disconnect(self):self.bridge.disconnect_client();self.status.set("Client disconnected. Any new connection requires fresh approval.")
    def copy_code(self):
        code=self.bridge.pairing_code();self.app.root.clipboard_clear();self.app.root.clipboard_append(code);self.copied=code
        self.status.set("Connection code copied. It contains a temporary bridge secret; paste it into your chosen local adapter. It is invalidated when you disable the bridge.")
    def selected_names(self):return [name for name in self.table.tree.selection() if name in self.table.records]
    def approve(self):
        names=self.selected_names();snap=self.bridge.state.snapshot()
        if not names:raise BridgeError("Select one or more supported capabilities.")
        if any(name not in snap["capabilities"] for name in names):raise BridgeError("Unsupported capability versions cannot be approved.")
        session=snap["session"];seconds={"This connection":None,"10 minutes":600,"1 hour":3600}[self.consent.get()]
        client=snap["client"]
        if not self.confirm("Review bridge capabilities",f"Approve these capabilities for {client.get('name')} {client.get('version')}?\n\n"+"\n".join(names)+f"\n\nDuration: {self.consent.get()}. All approvals end on disconnect. Local controls also require their separate enable switch."):return
        self.sync_environment();self.bridge.state.grant(names,session,seconds);self.status.set("Approved selected capabilities; waiting for the client's permission acknowledgement.")
    def revoke_selected(self):
        names=self.selected_names()
        if not names:raise BridgeError("Select capabilities to revoke.")
        self.bridge.state.revoke(names);self.status.set("Permissions revoked; affected queued actions and telemetry cleared.")
    def toggle_controls(self):
        enabled=self.controls.get();snap=self.bridge.state.snapshot()
        if enabled and not self.confirm("Enable local client controls",f"Allow approved local-control capabilities for {snap['client'].get('name','the connected client')} in this connection?\n\nEvery action in this panel still requires its own review. Legacy safety controls change local presentation. Lab experiments have separate reviews and may synchronize or persist; provider claims are not guarantees."):
            self.controls.set(False);return
        self.sync_environment();self.bridge.state.controls(enabled,snap["session"])
    def ping(self):
        snap=self.bridge.state.snapshot();future=self.bridge.request("bridge.ping",dict(nonce=fresh_id()),expected_session=snap["session"])
        self.pending.append((future,"Connection round trip confirmed."));self.status.set("Testing approved bridge connection…")
    def selection(self):
        names=self.selected_names();snap=self.bridge.state.snapshot()
        if not names:self.details.set("Select a capability.");return
        name=names[0];definition=snap["advertised"].get(name,{})
        presets=definition.get("presets",{})
        text="\n".join(f"{key}: {value}" for key,value in presets.items())
        self.details.set(name+("\nClient-defined local presets: "+text if text else "\n"+(CAPABILITIES[name].title if name in CAPABILITIES else "Unsupported; it cannot be enabled.")))
    def action_changed(self):
        name=self.action.get();snap=self.bridge.state.snapshot()
        if name in ("safety.player_preset","safety.focus_group"):
            options=tuple(k for k in snap["capabilities"].get(name,{}).get("presets",{}) if name!="safety.focus_group" or k!="normal")
        elif name=="safety.avatar_effects":options=("normal","reduced","minimal")
        elif name in ("safety.voice_mute","safety.microphone_mute"):options=("Muted","Unmuted")
        elif name=="safety.avatar_visibility":options=("Hide","Show")
        else:options=("Disable","Enable")
        self.value_box.configure(values=options)
        if self.value.get() not in options:self.value.set(options[0] if options else "")
    def action_parameters(self):
        name,value=self.action.get(),self.value.get();target=self.target.get().strip()
        bool_options={"safety.microphone_mute":("Muted","Unmuted"),"safety.voice_mute":("Muted","Unmuted"),"safety.avatar_visibility":("Hide","Show")}
        if name not in ("safety.focus_group","safety.player_preset","safety.avatar_effects") and value not in bool_options.get(name,("Disable","Enable")):
            raise BridgeError("Select a valid local control value.")
        if name=="safety.focus_group":return dict(user_ids=[v.strip() for v in target.replace("\n",",").split(",") if v.strip()],outside_preset=value)
        if name=="safety.microphone_mute":return dict(muted=value=="Muted")
        field="muted" if name=="safety.voice_mute" else "visible" if name=="safety.avatar_visibility" else "preset" if name=="safety.player_preset" else "mode" if name=="safety.avatar_effects" else "enabled"
        selected=value if field in ("preset","mode") else value in ("Muted","Show","Enable")
        return dict(user_id=target,**{field:selected})
    def apply(self):
        snap=self.bridge.state.snapshot();name=self.action.get()
        if name not in snap["available"] or name not in CAPABILITIES or not CAPABILITIES[name].game:raise BridgeError("No approved local game action is available.")
        params=parameters(name,self.action_parameters(),snap["capabilities"][name]);session=snap["session"]
        if not self.confirm("Review local client request",f"Client: {snap['client']['name']} {snap['client']['version']}\nAction: {CAPABILITIES[name].title}\n\n"+json.dumps(params,ensure_ascii=False,indent=2)+"\n\nRequest this local change from the connected client?"):return
        self.sync_environment();future=self.bridge.request(name,params,expected_session=session);self.pending.append((future,"The connected client confirmed the local request."));self.status.set("Local request queued. No automatic retry.")
    def show_ledger(self):
        rows=self.bridge.state.snapshot()["ledger"]
        self.write_text("Recent bridge requests (memory only; no payloads or pairing secrets):\n"+"\n".join(f"{r['time']}  {r['capability']}  {r['outcome']}" for r in rows))
        self.rendered=("ledger",self.bridge.state.revision)
    def write_text(self,value):
        self.telemetry.configure(state="normal");self.telemetry.delete("1.0","end");self.telemetry.insert("1.0",value[:24000]);self.telemetry.configure(state="disabled")
    def tick(self):
        if self.closed:return
        self.sync_environment()
        snap=self.bridge.state.snapshot();session=snap["session"]
        if session:
            client=snap["client"];runtime=snap["context"]
            self.identity.set(f"{client['name']} {client['version']} · {client['kind']} · protocol 1.0\nClient-reported VRChat attachment: {'Yes' if runtime['attached'] else 'No'} · local user: {runtime.get('local_user_id') or 'Unavailable'}\n{len(snap['grants'])} approved capabilities · game context {'ready' if snap['game_ready'] else 'unavailable / account mismatch'}")
        else:self.identity.set(snap["message"])
        selected=self.selected_names();names=sorted(snap["advertised"])
        signature=(session,tuple(names),tuple(snap["available"]),tuple((k,None if v is None else int(v)) for k,v in snap["grants"].items()))
        if signature!=getattr(self,"table_signature",None):
            previous_session=getattr(self,"table_signature",(None,))[0]
            self.table_signature=signature;children=self.table.tree.get_children()
            if children:self.table.tree.delete(*children)
            self.table.records={name:name for name in names}
            for name in names:
                spec=CAPABILITIES.get(name);approved=name in snap["grants"]
                state="Unsupported" if name not in snap["capabilities"] else "Available" if name in snap["available"] else "Approved; waiting / locked" if approved else "Quarantined"
                if approved:state+=" · connection" if snap["grants"][name] is None else f" · {int(snap['grants'][name])}s"
                self.table.tree.insert("","end",iid=name,values=(name,spec.kind if spec else "Unknown",state,spec.title if spec else "Not supported by VRC Eye"))
            keep=[name for name in selected if name in self.table.records]
            if keep and session==previous_session:self.table.tree.selection_set(keep)
            if session!=previous_session:self.details.set("Select a capability for this connection.");self.target.set("")
        self.controls.set(snap["controls_enabled"]);self.paused.set(snap["requests_paused"])
        self.ping_button.configure(state="normal" if "bridge.ping" in snap["available"] else "disabled")
        actions=[name for name in snap["available"] if CAPABILITIES[name].kind=="action" and CAPABILITIES[name].game and not name.startswith("lab.")]
        self.action_box.configure(values=actions)
        if actions:
            self.actions_frame.pack(fill="x",before=self.telemetry,pady=3)
            if self.action.get() not in actions:self.action.set(actions[0]);self.action_changed()
        else:self.actions_frame.pack_forget();self.action.set("");self.target.set("")
        for future,label in tuple(self.pending):
            if future.done():
                self.pending.remove((future,label))
                try:future.result();self.status.set(label)
                except Exception:self.status.set("Request unconfirmed or rejected. Refresh client state before trying again; VRC Eye did not retry it.")
        names=self.selected_names();name=names[0] if names else ""
        sample=self.bridge.get_sample(name) if name else None
        rendered=(session,name,json.dumps(sample.get("value"),sort_keys=True) if sample else None)
        if self.rendered!=rendered and not (isinstance(self.rendered,tuple) and self.rendered and self.rendered[0]=="ledger" and self.rendered[1]==snap["revision"]):
            self.rendered=rendered
            self.write_text("Client-reported, fresh telemetry: "+name+"\n"+json.dumps(sample["value"],ensure_ascii=False,indent=2) if sample else "No fresh approved telemetry selected. Unknown, expired or disconnected measurements are not treated as zero.")
        self.window.after(200,self.tick)
    def close(self):
        if self.closed:return
        self.closed=True;self.clear_clipboard();self.window.destroy()
