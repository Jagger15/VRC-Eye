"""Bounded digital mixing. No device access, files, recording or OSC side effects."""
from array import array
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Channel:
    gain: float = 0.5
    mute: bool = False
    outgoing: bool = False
    monitor: bool = False

    def __post_init__(self):
        if not math.isfinite(self.gain) or not 0 <= self.gain <= 2:
            raise ValueError("Gain must be finite and between 0 and 2.")


class Mixer:
    """Stereo, linked sample-peak limiter; private cue cannot enter outgoing."""
    def __init__(self, rate=48000, ceiling=0.89):
        if rate not in (44100, 48000, 96000) or not 0.1 <= ceiling <= 0.99:
            raise ValueError("Unsupported mixer format.")
        self.rate, self.ceiling = rate, ceiling
        self.reduction = {"outgoing": 1.0, "monitor": 1.0}

    @staticmethod
    def decode(data, channels, frames):
        if channels not in (1, 2) or not 0 < frames <= 4096 or len(data) != frames * channels * 4:
            raise ValueError("Unexpected capture format; audio stopped.")
        result = array("f")
        result.frombytes(data)
        if any(not math.isfinite(x) for x in result):
            raise ValueError("Non-finite audio sample; audio stopped.")
        if channels == 1:
            result = array("f", (x for sample in result for x in (sample, sample)))
        return result

    def _limit(self, samples, bus):
        gain = self.reduction[bus]
        release = math.exp(-1 / (self.rate * 0.080))
        lowest = 1.0
        for i in range(0, len(samples), 2):
            peak = max(abs(samples[i]), abs(samples[i + 1]))
            target = min(1.0, self.ceiling / peak) if peak else 1.0
            gain = target if target < gain else target + (gain - target) * release
            lowest = min(lowest, gain)
            samples[i] *= gain
            samples[i + 1] *= gain
        self.reduction[bus] = gain
        return -20 * math.log10(max(lowest, 1e-12))

    def process(self, inputs, settings, frames):
        if not 0 < frames <= 4096:
            raise ValueError("Invalid audio block size.")
        buses = {name: array("f", [0]) * (frames * 2) for name in ("outgoing", "monitor")}
        peaks = {}
        for name, data in inputs.items():
            if name not in ("microphone", "music", "cue", "clip_private", "soundboard") or len(data) != frames * 2:
                raise ValueError("Unknown audio channel or invalid sample count.")
            channel = settings.get(name, Channel())
            peaks[name] = max((abs(x) for x in data), default=0)
            if any(not math.isfinite(x) for x in data):
                raise ValueError("Non-finite audio sample; audio stopped.")
            if channel.mute:
                continue
            for bus in buses:
                allowed = channel.monitor if bus == "monitor" else channel.outgoing and name not in ("cue", "clip_private")
                if allowed:
                    for i, value in enumerate(data):
                        buses[bus][i] += value * channel.gain
        reduction = {name: self._limit(data, name) for name, data in buses.items()}
        output_peaks = {name: max(map(abs, data), default=0) for name, data in buses.items()}
        return buses, dict(inputs=peaks, outputs=output_peaks, reduction_db=reduction)


def dbfs(value):
    return "−∞" if value <= 0 else f"{20 * math.log10(value):.1f}"


def spectrum(samples, bands=16):
    """Small display-only DFT, never used as limiter or acoustic measurement."""
    if not samples:
        return (0.0,) * bands
    mono = [(samples[i] + samples[i + 1]) * 0.5 for i in range(0, len(samples), 2)]
    n = min(128, len(mono))
    values = [mono[int(i * len(mono) / n)] * (0.5 - 0.5 * math.cos(2 * math.pi * i / max(1, n - 1))) for i in range(n)]
    result = []
    for band in range(bands):
        k = 1 + int((n // 2 - 1) * band / max(1, bands - 1))
        real = sum(x * math.cos(2 * math.pi * k * i / n) for i, x in enumerate(values))
        imag = sum(x * math.sin(2 * math.pi * k * i / n) for i, x in enumerate(values))
        result.append(min(1.0, 4 * math.hypot(real, imag) / n))
    return tuple(result)
