/* VRC Eye's bounded, memory-only ufbx bridge. See LICENSE for vendored ufbx.
 * This module is imported before containment, called only inside the worker.
 * No caller-controlled options, filename, file API or callbacks are exposed.
 * Returned Python values own their storage; the ufbx scene is always freed.
 */
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <math.h>
#include "ufbx.h"
#if UFBX_VERSION != ufbx_pack_version(0, 23, 1)
#error VRC_Eye_requires_the_pinned_ufbx_0_23_1_header
#endif

static PyObject *vec(ufbx_vec3 v) { return Py_BuildValue("(ddd)",v.x,v.y,v.z); }
static PyObject *mat(ufbx_matrix m) {
    return Py_BuildValue("(dddddddddddddddd)",m.m00,m.m10,m.m20,0.,m.m01,m.m11,m.m21,0.,m.m02,m.m12,m.m22,0.,m.m03,m.m13,m.m23,1.);
}
static PyObject *str(ufbx_string s) {
    return PyUnicode_DecodeUTF8(s.data,(Py_ssize_t)(s.length>1024?1024:s.length),"replace");
}
/* Set steals our temporary reference, but the dictionary keeps its own. */
static int put(PyObject *d,const char *k,PyObject *v) {
    if(!v)return -1;
    int r=PyDict_SetItemString(d,k,v);Py_DECREF(v);return r;
}
#define SET(d,k,v) do { if(put(d,k,v)<0)goto fail; } while(0)
#define LIMIT(ok,msg) do { if(!(ok)){PyErr_SetString(PyExc_ValueError,msg);goto fail;} } while(0)
#define LIST(d,k,n) do { list=PyList_New(n);if(!list)goto fail;SET(d,k,list); } while(0)
#define ROW(i) do { row=PyDict_New();if(!row)goto fail;PyList_SET_ITEM(list,i,row); } while(0)

static PyObject *snapshot(PyObject *self,PyObject *args) {
    const char *data;Py_ssize_t size;int take=-1;double at=0.;
    if(!PyArg_ParseTuple(args,"y#|id",&data,&size,&take,&at))return NULL;
    if(take < -1 || take > 63 || !isfinite(at) || fabs(at)>86400.){PyErr_SetString(PyExc_ValueError,"Invalid FBX take or sample time.");return NULL;}
    if(size<32 || size>32*1024*1024){PyErr_SetString(PyExc_ValueError,"FBX source must be 32 bytes–32 MiB.");return NULL;}
    ufbx_load_opts opts={0};ufbx_error error;
    opts.file_format=UFBX_FILE_FORMAT_FBX;
    opts.no_format_from_content=true;opts.no_format_from_extension=true;
    opts.load_external_files=false;opts.evaluate_caches=false;
    opts.evaluate_skinning=true;opts.force_single_thread_ascii_parsing=true;
    opts.node_depth_limit=64;opts.index_error_handling=UFBX_INDEX_ERROR_HANDLING_ABORT_LOADING;
    opts.target_axes=ufbx_axes_right_handed_y_up;opts.target_unit_meters=1.0;
    opts.space_conversion=UFBX_SPACE_CONVERSION_TRANSFORM_ROOT;
    opts.temp_allocator.memory_limit=256*1024*1024;opts.result_allocator.memory_limit=256*1024*1024;
    opts.temp_allocator.allocation_limit=100000;opts.result_allocator.allocation_limit=100000;
    ufbx_scene *s=ufbx_load_memory(data,(size_t)size,&opts,&error);
    if(!s){PyErr_SetString(PyExc_ValueError,"FBX data is malformed, unsupported or exceeds the native parser budget.");return NULL;}
    ufbx_scene *base=s;
    PyObject *out=NULL,*list=NULL,*row=NULL;
    LIMIT(s->nodes.count<=512 && s->meshes.count<=512 && s->materials.count<=128 && s->textures.count<=128 && s->texture_files.count<=128 && s->anim_stacks.count<=64 && s->elements.count<=16384,"FBX exceeds the scene catalog budget.");
    if(take>=0){
        LIMIT((size_t)take<s->anim_stacks.count,"Select an existing FBX take.");
        ufbx_anim_stack *a=s->anim_stacks.data[take];
        LIMIT(at>=a->time_begin && at<=a->time_end,"Sample time is outside the selected FBX take.");
        ufbx_evaluate_opts eval={0};
        eval.evaluate_skinning=true;eval.evaluate_caches=false;eval.load_external_files=false;
        eval.temp_allocator.memory_limit=256*1024*1024;eval.result_allocator.memory_limit=256*1024*1024;
        eval.temp_allocator.allocation_limit=100000;eval.result_allocator.allocation_limit=100000;
        s=ufbx_evaluate_scene(base,a->anim,at,&eval,&error);
        LIMIT(s!=NULL,"FBX take evaluation failed or exceeded its native budget.");
    }
    out=PyDict_New();
    if(!out)goto fail;
    LIMIT(s->metadata.file_format==UFBX_FILE_FORMAT_FBX,"The selected bytes are not FBX.");
    LIMIT(s->nodes.count<=512 && s->meshes.count<=512 && s->materials.count<=128 && s->textures.count<=128 && s->texture_files.count<=128 && s->anim_stacks.count<=64 && s->elements.count<=16384,"FBX exceeds the scene catalog budget.");
    SET(out,"version",PyLong_FromUnsignedLong(s->metadata.version));
    SET(out,"ascii",PyBool_FromLong(s->metadata.ascii));
    SET(out,"units",PyFloat_FromDouble(s->settings.unit_meters));
    SET(out,"axes",Py_BuildValue("(iii)",s->settings.axes.right,s->settings.axes.up,s->settings.axes.front));
    SET(out,"fps",PyFloat_FromDouble(s->settings.frames_per_second));
    SET(out,"bones",PyLong_FromSize_t(s->bones.count));
    SET(out,"unsupported",PyLong_FromSize_t(s->nurbs_surfaces.count+s->nurbs_curves.count+s->line_curves.count+s->procedural_geometries.count));
    SET(out,"constraints",PyLong_FromSize_t(s->constraints.count));
    LIST(out,"nodes",s->nodes.count);
    for(size_t i=0;i<s->nodes.count;i++){
        ufbx_node *n=s->nodes.data[i];ROW(i);
        SET(row,"id",PyLong_FromUnsignedLong(n->typed_id));SET(row,"parent",PyLong_FromLong(n->parent?(long)n->parent->typed_id:-1));
        SET(row,"name",str(n->name));SET(row,"matrix",mat(n->node_to_world));SET(row,"geometry",mat(n->geometry_to_world));
        SET(row,"mesh",PyLong_FromLong(n->mesh?(long)n->mesh->typed_id:-1));SET(row,"visible",PyBool_FromLong(n->visible));
        LIMIT(n->materials.count<=128,"FBX node exceeds 128 materials.");
        PyObject *materials=PyList_New(n->materials.count);if(!materials)goto fail;SET(row,"materials",materials);
        for(size_t j=0;j<n->materials.count;j++){PyObject *v=PyLong_FromUnsignedLong(n->materials.data[j]->typed_id);if(!v)goto fail;PyList_SET_ITEM(materials,j,v);}
    }
    LIST(out,"meshes",s->meshes.count);
    size_t total_vertices=0,total_triangles=0;
    for(size_t i=0;i<s->meshes.count;i++){
        ufbx_mesh *m=s->meshes.data[i];ROW(i);
        total_vertices+=m->num_indices;total_triangles+=m->num_triangles;
        LIMIT(!(m->skin_deformers.count && m->instances.count>1),"Instanced skinned FBX meshes require a different importer.");
        LIMIT(total_vertices<=100000 && total_triangles<=30000 && m->num_vertices<=100000 && m->max_face_triangles<=62,"FBX geometry exceeds 100,000 corners / 30,000 triangles / 64 corners per face.");
        SET(row,"id",PyLong_FromUnsignedLong(m->typed_id));SET(row,"name",str(m->name));
        SET(row,"vertices",PyLong_FromSize_t(m->num_vertices));SET(row,"faces",PyLong_FromSize_t(m->num_faces));
        SET(row,"local",PyBool_FromLong(m->skinned_is_local));
        SET(row,"skins",PyLong_FromSize_t(m->skin_deformers.count));SET(row,"blends",PyLong_FromSize_t(m->blend_deformers.count));
        SET(row,"caches",PyLong_FromSize_t(m->cache_deformers.count));
        SET(row,"subdivision",PyLong_FromUnsignedLong(m->subdivision_preview_levels));
        size_t channels=0,targets=0;for(size_t j=0;j<m->blend_deformers.count;j++){ufbx_blend_deformer *b=m->blend_deformers.data[j];channels+=b->channels.count;for(size_t k=0;k<b->channels.count;k++)targets+=b->channels.data[k]->keyframes.count;}
        SET(row,"channels",PyLong_FromSize_t(channels));SET(row,"targets",PyLong_FromSize_t(targets));
        PyObject *points=PyList_New(m->num_indices),*uvs=PyList_New(m->vertex_uv.exists?m->num_indices:0);
        if(!points || !uvs){Py_XDECREF(points);Py_XDECREF(uvs);goto fail;}
        if(put(row,"points",points)<0){Py_DECREF(uvs);goto fail;}SET(row,"uvs",uvs);
        SET(row,"uv_name",str(m->uv_sets.count?m->uv_sets.data[0].name:ufbx_empty_string));
        for(size_t j=0;j<m->num_indices;j++){
            ufbx_vec3 p=ufbx_get_vertex_vec3(&m->skinned_position,j);PyObject *v=vec(p);if(!v)goto fail;PyList_SET_ITEM(points,j,v);
            if(m->vertex_uv.exists){ufbx_vec2 uv=ufbx_get_vertex_vec2(&m->vertex_uv,j);v=Py_BuildValue("(dd)",uv.x,uv.y);if(!v)goto fail;PyList_SET_ITEM(uvs,j,v);}
        }
        PyObject *triangles=PyList_New(0);if(!triangles)goto fail;SET(row,"triangles",triangles);
        for(size_t j=0;j<m->faces.count;j++){
            ufbx_face face=m->faces.data[j];LIMIT(face.num_indices>=3 && face.num_indices<=64,"FBX contains unsupported point/line/oversized faces.");
            uint32_t indices[186];uint32_t num=ufbx_triangulate_face(indices,186,m,face);
            LIMIT(num>0 && num<=62,"FBX face could not be triangulated.");
            uint32_t material=m->face_material.count?m->face_material.data[j]:0;
            for(uint32_t k=0;k<num;k++){
                PyObject *v=Py_BuildValue("(IIII)",indices[k*3],indices[k*3+1],indices[k*3+2],material);if(!v)goto fail;
                int ok=PyList_Append(triangles,v);Py_DECREF(v);if(ok<0)goto fail;
            }
        }
    }
    LIST(out,"materials",s->materials.count);
    for(size_t i=0;i<s->materials.count;i++){
        ufbx_material *m=s->materials.data[i];ROW(i);
        ufbx_material_map *color=&m->fbx.diffuse_color;
        SET(row,"name",str(m->name));SET(row,"color",vec(color->has_value?color->value_vec3:(ufbx_vec3){1,1,1}));
        SET(row,"factor",PyFloat_FromDouble(m->fbx.diffuse_factor.has_value?m->fbx.diffuse_factor.value_real:1.0));
        SET(row,"texture",PyLong_FromLong(color->texture && color->texture_enabled?(long)color->texture->typed_id:-1));
    }
    LIST(out,"textures",s->textures.count);
    size_t embedded=0;
    for(size_t i=0;i<s->textures.count;i++){
        ufbx_texture *t=s->textures.data[i];ROW(i);
        embedded+=t->content.size;LIMIT(embedded<=16*1024*1024,"Embedded FBX textures exceed 16 MiB.");
        SET(row,"name",str(t->name));SET(row,"filename",str(t->relative_filename.length?t->relative_filename:t->filename));
        SET(row,"content",PyBytes_FromStringAndSize(t->content.data,t->content.size));
        SET(row,"type",PyLong_FromLong(t->type));SET(row,"uv_name",str(t->uv_set));
        SET(row,"transform",mat(t->uv_to_texture));
        SET(row,"wrap",Py_BuildValue("(ii)",t->wrap_u,t->wrap_v));
    }
    LIST(out,"takes",s->anim_stacks.count);
    for(size_t i=0;i<s->anim_stacks.count;i++){
        ufbx_anim_stack *a=s->anim_stacks.data[i];ROW(i);
        SET(row,"name",str(a->name));SET(row,"start",PyFloat_FromDouble(a->time_begin));SET(row,"end",PyFloat_FromDouble(a->time_end));SET(row,"layers",PyLong_FromSize_t(a->layers.count));
    }
    LIMIT(s->metadata.warnings.count<=64,"FBX has too many parser warnings.");
    LIST(out,"warnings",s->metadata.warnings.count);
    for(size_t i=0;i<s->metadata.warnings.count;i++){ufbx_warning w=s->metadata.warnings.data[i];PyObject *v=Py_BuildValue("(iK)",w.type,(unsigned long long)w.count);if(!v)goto fail;PyList_SET_ITEM(list,i,v);}
    if(s!=base)ufbx_free_scene(s);
    ufbx_free_scene(base);return out;
fail:
    Py_XDECREF(out);if(s!=base)ufbx_free_scene(s);
    ufbx_free_scene(base);return NULL;
}
static PyMethodDef methods[]={{"snapshot",snapshot,METH_VARARGS,"Bounded FBX bytes to detached scene data."},{NULL,NULL,0,NULL}};
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"vrc_eye_ufbx",NULL,-1,methods};
PyMODINIT_FUNC PyInit_vrc_eye_ufbx(void){
    if(ufbx_source_version!=ufbx_pack_version(0,23,1)){PyErr_SetString(PyExc_ImportError,"Unexpected ufbx source version");return NULL;}
    PyObject *m=PyModule_Create(&module);if(!m)return NULL;
    if(PyModule_AddStringConstant(m,"UFBX_VERSION","0.23.1")<0 || PyModule_AddIntConstant(m,"ADAPTER_VERSION",2)<0){Py_DECREF(m);return NULL;}return m;
}
