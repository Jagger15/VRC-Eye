from setuptools import setup, Extension
setup(name="vrc-eye-ufbx", version="0.2.0", description="VRC Eye contained FBX adapter (ufbx 0.23.1)",
      ext_modules=[Extension("vrc_eye_ufbx", ["adapter.c", "ufbx.c"], define_macros=[("UFBX_NO_STDIO", "1")])])
