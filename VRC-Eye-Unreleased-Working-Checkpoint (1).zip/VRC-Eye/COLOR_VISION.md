# Color vision support

Open **Accessibility → Display → Color vision support**, choose a palette,
then select **Apply display settings**. The four status examples preview the
choice before applying it. Tool search also accepts “colorblind” or “colour”.

| Option | Purpose |
| --- | --- |
| Off | Use theme colors; retain labels, shapes and patterns. |
| Deuteranopia | Red–green option using blue, orange and purple status colors. |
| Protanopia | Red–green option using blue, gold and purple status colors. |
| Tritanopia | Blue–yellow option using teal, pink and red status colors. |
| Monochrome | Neutral interface colors with the same non-color cues. |

Choose the option that is easiest for you to distinguish. These are adaptable
presentation palettes, not clinical simulations or a guarantee that one preset
will suit everyone. High-contrast modes remain available alongside them.

Changes apply to existing and newly opened desktop views. They use the shared
presentation record, accessibility profiles, appearance profiles, reset and
**Undo last accessibility change**. Demo and Safe mode keep changes in the
current session. Existing profiles without this field continue to work.

Custom accent settings remain saved. In the three color presets, a custom accent
still controls decorative accents; status/chart colors use the selected preset.
Monochrome neutralizes the interface without overwriting the stored accent.
High-contrast mode continues to control its own accent. Switching back restores
the applicable theme/custom accent. Photos, imported maps, avatar materials,
textures and other user artwork retain their colors.

## Meaning without color

- Status tables keep their visible event/quality labels. The Accessibility
  preview pairs colors with `[OK]`, `[!]`, `[X]` and `[i]` plus words.
- World maps use a triangle for you, circles for other players, a square frame
  and `[selected]` label for the selection, and diamonds for waypoints. Opaque
  label backings and marker halos separate annotations from map imagery.
- Population charts use circles and solid lines for observed/confirmed samples,
  diamonds and dashed lines for other quality. Session boundaries and unknown
  intervals retain their gaps; exact observations remain in the table/Reading view.
- Activity heatmaps use empty cells and one to four marks for increasing bands
  relative to the current view’s maximum. Bands are not event counts. The adjacent
  tables retain exact values and repeated daylight-saving hours separately.
- Resource graphs use capped bars for min/max ranges and a dashed maximum line.
- Selected navigation labels are underlined with the same font metrics, padding
  and reserved borders as unselected labels.
- Incident, Unity, social-history, audio-spectrum and generic mannequin graphics
  follow shared semantic colors while retaining their geometric meaning.

Status text and meaningful strokes are derived to meet a 4.5:1 contrast ratio
against the supported background and panel colors. The automated matrix covers
all built-in themes, both high-contrast modes, presets and custom accents. This
is implementation evidence, not a claim of whole-app WCAG certification.

Palette application updates existing paint options only. It does not reload
accounts, restart devices, fetch observations or reconstruct cleared private
content. Existing anonymization, session boundaries and permission controls
remain authoritative. Desktop text-size controls still support 100–500%.

## Verification

See `COLOR_VISION_QUALIFICATION.json` and the `color_vision_update` record in
`PENDING_WORKING_VALIDATION.json` for exact source hashes and test results.
Portable tests cover palette contrast, profile compatibility, Apply/Undo/save
policy, live repaint, cleared-content handling, image preservation, chart quality
shapes/gaps, heatmap bands/DST data, marker shapes and discovery.

Seven real-Tk acceptance cases are supplied in `tests/test_color_vision_native.py`.
They require a graphical Windows/Linux session and were not executable in this
environment. Native visual inspection, keyboard use with the palette control,
platform DPI and user evaluation of the presets remain acceptance tasks. Raster
exports, VR overlays and external programs use their existing presentation.

Design references: [W3C use of color](https://www.w3.org/WAI/WCAG22/Understanding/use-of-color.html)
and [W3C non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html).
