"""Reviewed, exclusive diagnostic bundle export with checksums."""
import hashlib
import json
from pathlib import Path
import zipfile
from crash_model import bundle


def export_bundle(path,incident,include_metrics=True):
    data=bundle(incident,include_metrics)
    content={name:json.dumps(value,indent=2,allow_nan=False).encode() for name,value in (
        ('summary.json',data['summary']),('timeline.json',data['timeline']),('manifest.json',dict(schema=1,**data['preview'])))}
    content['SHA256SUMS.txt']=''.join(hashlib.sha256(value).hexdigest()+'  '+name+'\n' for name,value in content.items()).encode()
    target=Path(path);created=False
    try:
        with target.open('xb') as stream:
            created=True
            with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
                for name,value in content.items():archive.writestr(name,value)
    except Exception:
        if created:target.unlink(missing_ok=True)
        raise
    return str(target)
