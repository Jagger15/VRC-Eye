# VRC Eye 1.21.0 — Development checkpoint 1

Built from the verified 1.20.0 Development 8 source package after authorization
to begin the 1.21.0 build. This checkpoint delivers working integration and
interface features; the full preparation backlog remains staged.

## Start

Close the old app, extract this ZIP into its own folder, open `VRC-Eye`, and run
`Start.cmd` on Windows. The launcher prepares this copy's Python dependencies.
`Demo.cmd` and `Safe-mode.cmd` remain available and do not install dependencies.
For an existing Python 3.10+ environment with Tk, install `requirements.txt` and
run `python vrc_eye.py`. Linux audio also needs the system PortAudio library.
Python imports and opening pages never start media discovery or audio capture.

Use an isolated extraction; keep your previous copy for rollback. Existing local
data remains subject to its existing per-user storage location. Copying the app
folder does not copy or isolate your account database or saved login preferences.
No VRChat or VRCX installation binaries are redistributed in this source ZIP.

## Account and navigation

The top of the main window shows the confirmed active account across pages.
An API-supplied username is preferred; a display name is explicitly identified
when the username is unavailable. The Hide account identity switch and existing
presentation/privacy settings conceal names. A failed replacement login keeps
the existing confirmed account active. Opening the connection window while
signed in now shows an account summary; switching accounts opens the login form.

Native tabs and the shared quick-tab strip reserve constant padding and borders.
The selected tab uses the accent colour without growing or rearranging adjacent
buttons. Overflow stays in the section selector; keyboard focus remains distinct.

## Media & Audio

Open **VRC Eye → Media & Audio** or use **Ctrl+K**. Discover supported players
explicitly, then select a source. Windows uses GSMTC; Linux uses MPRIS on the
current user's session bus. The app shows each player's advertised capabilities,
track metadata and reported/estimated position. Unsupported controls stay unavailable.
Seek and transport commands recheck the selected player, track and context.

Now Playing text requires a preview and uses the existing OSC permissions and
chatbox scheduler. A final producer check cancels stale source/track text before
transmission. Stopping media cancels Eye observation and queued publications; it
does not automatically pause unrelated external players.

History is optional and account-scoped. Bookmarks and an ordered DJ cue list
retain observed sources and positions. The DJ page controls the pinned player;
independent audio decks, beatmatching and automatic cue playback are not included.
Private listening hides metadata and stops the associated Eye publication path.

The Mixer offers explicit named input/output selection, microphone level tests,
microphone/music/private-cue gain and mute, and separate monitor/outgoing buses.
Private cue cannot enter outgoing audio. Outgoing routing starts only after its
session switch is enabled and the selected mix is started. The linked sample-peak
limiter limits stereo digital peaks; it is not a true-peak or acoustic safety meter.
No recording is made by the mixer. Device changes or capture faults stop output;
there is no automatic default-device fallback or automatic rearming.

This capture backend uses 48 kHz float32 input and stereo output. Choose an
existing named virtual endpoint for outgoing audio and configure VRChat's input
in the game. The app does not install a driver, create a PipeWire virtual source,
capture arbitrary application processes, or prove remote audibility. Those native
routes and platform acceptance checks remain separate work.

## Installation and local interoperability

**Unity Player → Installation** inspects a selected folder or ZIP without running
its programs or extracting an installation. It reports bounded file inventory,
passive engine/version/architecture/import evidence, component roles and declared
SteamVR actions/bindings. Optional selected-file hashes, saved baselines, comparison,
exact runtime association and sanitized reports preserve partial/unknown states.

The shared VRChat configuration reader recognizes photo folder, date split and
cache directory fields. Steam/Proton candidates and configured folders remain
explicit choices. Photos can inspect supported VRCX JSON and VRChat XMP metadata
with provenance and conflict reporting; sensitive identity/instance/roster fields
are hidden by default. Inspection does not silently write annotations or sessions,
and existing metadata-free export preserves the original source image.

VRCX interoperability includes a custom-column CSV preview/mapping flow, local
favorite-group membership import, richer selected avatar observations, separate
local tags, and selected-record handoff. Original VRCX databases stay read-only.
Imports do not turn cached metadata into current VRChat ownership or asset authority.

Social notification details remain bounded and source-labelled. Account-scoped
status presets fill the existing profile draft and retain its review step. Saved
searches and optional recent searches restore form fields; opening or selecting
one does not issue a network search automatically.

See `IMPLEMENTATION_STATUS_1_21.md` for every prepared package's status and
`VALIDATION_1_21.md` for executed checks and remaining native validation.
