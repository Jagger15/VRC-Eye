"""Local declaration bookmarks and bounded structural comparisons of two packs."""
from collections import Counter
from hashlib import sha256
import json
import time

from inspection_inputs import checkpoint
from native_library import scope,plain
from metadata_reference import digest


def identity(reference):
    return digest(reference.identity['metadata_sha256'])+':'+digest(reference.identity['native_types_sha256'])


def key(row):return row['assembly'],row['name'],row['kind']


def declaration(reference,index):
    if type(index) is not int or not 0<=index<len(reference.rows):raise ValueError('Select a declaration in this pack.')
    return reference.rows[index]


class Bookmarks:
    def __init__(self,store):
        self.store=store
        with store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS metadata_bookmarks(account TEXT NOT NULL,reference TEXT NOT NULL,declaration TEXT NOT NULL,label TEXT NOT NULL,created REAL NOT NULL,PRIMARY KEY(account,reference,declaration))')

    def save(self,account,reference,index,label=''):
        account=scope(account);row=declaration(reference,index);ref=identity(reference);name=json.dumps(key(row),ensure_ascii=False)
        if sum(key(other)==key(row) for other in reference.rows)!=1:raise ValueError('Duplicate qualified declarations cannot be bookmarked unambiguously.')
        label=plain(label or row['name'],4096,empty=False)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing=db.execute('SELECT 1 FROM metadata_bookmarks WHERE account=? AND reference=? AND declaration=?',(account,ref,name)).fetchone()
            if not existing and db.execute('SELECT count(*) FROM metadata_bookmarks WHERE account=?',(account,)).fetchone()[0]>=500:raise ValueError('Keep up to 500 declaration bookmarks per account.')
            db.execute('INSERT OR REPLACE INTO metadata_bookmarks VALUES(?,?,?,?,?)',(account,ref,name,label,time.time()))

    def rows(self,account,reference):
        with self.store.connect() as db:
            return [dict(key=json.loads(row[0]),label=row[1]) for row in db.execute('SELECT declaration,label FROM metadata_bookmarks WHERE account=? AND reference=? ORDER BY label,declaration',(scope(account),identity(reference)))]

    def remove(self,account,reference,index):
        row=declaration(reference,index)
        with self.store.connect() as db:db.execute('DELETE FROM metadata_bookmarks WHERE account=? AND reference=? AND declaration=?',(scope(account),identity(reference),json.dumps(key(row),ensure_ascii=False)))

    def resolve(self,reference,bookmark):
        found=[row['index'] for row in reference.rows if key(row)==tuple(bookmark['key'])]
        if len(found)!=1:raise ValueError('The declaration is unavailable or ambiguous in this exact reference pack.')
        return found[0]


def signature(reference,index,*,stop=None,deadline=None):
    first=reference.detail(index);count=first['total_members']
    if count>20000:return None,count,'Type exceeds the 20,000-member comparison limit'
    members=[];complete=not first['interfaces_truncated']
    for offset in range(0,max(1,count),200):
        checkpoint(stop,deadline);page=first if offset==0 else reference.detail(index,offset=offset)
        for member in page['members']:
            if '[arguments truncated]' in member['name']:complete=False
            members.append(json.dumps(member,sort_keys=True,ensure_ascii=False,allow_nan=False))
    value=dict(parent=first['parent'],interfaces=sorted(first['interfaces']),members=sorted(members),total_members=count)
    if not complete:return None,count,'Some interface or parameter declarations are truncated'
    return sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),count,''


def compare(before,after,*,stop=None,progress=lambda value:None,max_types=10000,max_members=200000,seconds=30):
    """Semantic declaration comparison; addresses, indices and code never execute."""
    deadline=time.monotonic()+seconds
    a={};b={}
    for reference,mapping in ((before,a),(after,b)):
        for row in reference.rows:
            checkpoint(stop,deadline);mapping.setdefault(key(row),[]).append(row['index'])
    rows=[];counts=Counter();members=0;checked=0;omitted=0
    for name in sorted(a.keys()|b.keys()):
        checkpoint(stop,deadline);left=a.get(name,[]);right=b.get(name,[]);reason='';old=new=None
        if len(left)>1 or len(right)>1:state='Ambiguous';reason='Duplicate qualified declaration name'
        elif not left:state='Added'
        elif not right:state='Removed'
        elif checked>=max_types or members>=max_members:state='Not compared';reason='Structural comparison budget reached'
        else:
            needed=sum(r.get(k,0) for r in (before.rows[left[0]],after.rows[right[0]]) for k in ('fields','properties','methods','events'))
            if needed>max_members-members:
                counts['Not compared']+=1
                if len(rows)<2000:rows.append(dict(assembly=name[0],name=name[1],kind=name[2],state='Not compared',reason='Member comparison budget reached',before_hash=None,after_hash=None))
                else:omitted+=1
                continue
            old,used,reason=signature(before,left[0],stop=stop,deadline=deadline);members+=used
            new,used,other=signature(after,right[0],stop=stop,deadline=deadline);members+=used;checked+=1
            reason=reason or other
            state='Changed' if old is not None and new is not None and old!=new else 'Unchanged' if old is not None and new is not None else 'Not compared'
        counts[state]+=1
        if state!='Unchanged':
            if len(rows)<2000:rows.append(dict(assembly=name[0],name=name[1],kind=name[2],state=state,reason=reason,before_hash=old,after_hash=new))
            else:omitted+=1
    complete=not counts['Not compared'] and not counts['Ambiguous']
    progress(f"Compared {checked} shared declarations")
    return dict(schema='vrc-eye-metadata-comparison-1',before=dict(before.identity),after=dict(after.identity),
        counts=dict(counts),rows=rows,rows_omitted=omitted,complete=complete,
        scope='Declared names, parents, interfaces and retained member signatures/constants only. No code, native addresses, runtime behavior or public API compatibility is inferred.')
