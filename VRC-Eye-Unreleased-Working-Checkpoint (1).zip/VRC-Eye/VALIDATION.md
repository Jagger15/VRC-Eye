> Current build: [Development 6 validation](VALIDATION_1_21.md). Older results below are historical.

# Validation

## Version 1.19.9 — Remembered sign-in and keyboard login

Built on 1.19.8 and checked on **2026-10-02**, using Python **3.13.5**, pytest
9.0.2, Linux Xvfb and native Tk. The full source regression initially passed
2,805 tests; three final edge-case regressions raised the complete suite to
**2,808 tests and 1,141 subtests**, including **81 new tests** compared with
1.19.8. The sole warning is the pre-existing TestListener collection warning.
The final clean-extracted source suite passed in **63.26 seconds**, with no
failures or skips. The packaged source and tests are byte-identical to that
tested tree; only validation documentation and metadata were finalized afterward.

The focused group contains **97 storage/login tests**, including **eight native
Tk tests**. The separate packaging test also confirms the saved-login JSON is
not included. Coverage includes independent remember combinations, save only after
full sign-in, failed/cancelled/closed attempt isolation, immediate independent
forgetting, password-only account matching, storage failures without a plaintext
fallback, corrupt/deeply nested/malformed-Unicode records, Enter and keypad Enter,
repeated-key suppression, automatic verification focus, Tab/Space, Escape,
continuations, and Demo/Safe-mode checks including a mode change mid-attempt.

The Windows wrapper is tested using synthetic native-call doubles and real
ctypes buffers/structure layouts, not a native Windows credential set. Its fixed
target, same-user/computer persistence flag, bounded UTF-8 record, returned-buffer
cleanup, deletion and missing/locked/error paths are exercised. No real VRChat
account credentials are used. Codes and cookies remain session-only.

A separate native UI capture at standard and larger text sizes found no callback
errors or controls beyond the window bounds, with **zero OSC packets** and **no
bridge listener**. All **292 Python source/test files** parse with Python 3.10
grammar. The four launchers and requirements.txt are byte-identical to 1.19.8.
Other services retain their behavior; existing version stamps and sign-in help
copy are updated. The existing **77 navigation destinations** are preserved.

**Unverified:** Windows-native credential storage and UI/DPI, live VRChat sign-in,
and live verification. Non-Windows password remembering is intentionally disabled
rather than using a plaintext fallback. This release does not claim platform
approval or resolve the inherited public-distribution authentication review.

The full-source release excludes login-preferences.json, caches, runtime
databases and credentials. BUILD_VALIDATION.json records the final clean-archive
checks; prior measurements below retain their historical scope.

## Version 1.19.8 — Client Bridge Lab

Checked on **2026-10-02**, using Python **3.13.5**, pytest 9.0.2
and native Tk under Linux Xvfb. Final source suite: **2,727 tests and
1,141 subtests passed**, one pre-existing TestListener collection warning,
**59.18 seconds**. No final-run failures. The recovered 1.19.7 baseline
was also measured before editing: 2,533 passed, 21 native-display tests skipped,
and 1,125 subtests passed without Xvfb. The previous full-display release count
was 2,554; this release adds **173 tests**.

The new coverage comprises 169 Client Lab cases (including eight native Tk and
seven provider-SDK cases), one packaging test, and three deterministic peer-state
cleanup cases. Tests cover all new capability schemas, built-in read-only rules,
unknown fields/capabilities, bounded values and leases, context/permission changes,
review expiry, rejected/unknown outcomes, no duplicate writes, competing revisions,
conditional restore and restore-budget waiting, creator manifest authority scope,
correlated recovery health, API/OSC evidence limitations, data-only Replay,
redaction, provider freshness checks, opt-in cards and current-session acceptance.

The optional Python SDK was exercised through an **authenticated native Unix
socket** using the real host and an in-memory synthetic provider. It executed a
reviewed parameter command, received separate observation, and confirmed the
provider-reported conditional restoration. No VRChat client was contacted or
modified. Windows named-pipe and real runtime effects were not tested here.

All **77 indexed destinations** are exercised by the existing broad native Tk
navigation test; the eight new lab views retain the same application services.
A separate native screenshot walkthrough recorded **zero callback errors, zero
OSC packets, zero OSC grants, no bridge listener, and peer mode Private**, with
the lab in Sandbox. Main and 1060×720 Larger-text/Compact screenshots were
inspected after responsive wrapping and form-row changes. Vertical page scrolling
remains necessary at small sizes. This is not accessibility or Windows DPI
certification.

**Networking observations and correction:** An intermediate full run exposed a
real state-publication race: a joined transport could remove its last peer before
changing CONNECTED to DISCONNECTED. The update makes those fields change under
one lock before socket disposal. A deterministic regression test first reproduced
the old behavior; three cases now verify joined, hosting and private states.
The original native disconnect/rejoin test also remains in the suite.

A separate earlier run raised `sqlite3.DatabaseError: file is not a database`
in an existing named-VPN/loopback test using temporary local SQLite files. Its
cause was **not established**. Ten targeted repeats (four adapter-fixture cases
each), and subsequent full-suite runs, did not reproduce that SQLite error.
This release does not claim to have repaired that separate issue. The fixtures
exercise loopback TLS and selected-source binding, not actual external VPNs.

All **289 Python files** parse with Python 3.10 grammar. Actual execution
here uses Python 3.13.5, not Python 3.10. Runtime --version reports
1.19.8. The four Windows launchers and requirements.txt are byte-for-byte identical
to 1.19.7. The release packager explicitly includes the existing runtime catalog,
new reference catalog and validation metadata, excludes arbitrary private JSON
and caches, verifies ZIP contents and refuses to overwrite an existing release.

The new bridge catalog has **seven telemetry channels and six action contracts**.
The existing web API catalog is unchanged at **37 reads, 18 writes and three
reference-only entries**. The supplied Client Bridge Lab proposal is retained
byte-for-byte; the implementation matrix names remaining work rather than treating
the whole proposal as completed. Provider implementation and lease enforcement
remain requirements of any separately supplied compatible live integration.

**Not validated:** live VRChat authentication/endpoints, actual client/avatar/world
effects, real creator authority, a Windows desktop/named-pipe runtime, external
multiplayer playtests, real hardware performance changes, or independently proven
provider claims. The new lab's Replay is read-only report inspection, not a full
bridge-event replay engine. There is no VRChat-specific runtime provider in this
archive. Existing creator, OSC and API runtime limitations still apply.

## Version 1.19.7 — Developer / Black Lab

Checked on 2026-10-02 using Python **3.13.5**, pytest 9.0.2 and native Tk under a Linux Xvfb display.

The recovered 1.19.6.1 baseline passed **2,249 tests and 1,125 subtests** before changes. The new full suite passed **2,554 tests and 1,125 subtests**, with **one pre-existing TestListener collection warning**, in **44.12 seconds**. No failures.

The **305 new tests** comprise 295 developer service/transport/data tests and 10 native Tk action tests. They cover every executable catalog entry with bounded example validation, Sandbox execution, fake-HTTP execution through the original API transport and unknown-field rejection. They also cover account/resource scope, one-use request fingerprints, expiry, disarming, context cancellation, stale responses, uncertain outcomes, no duplicate writes, cache invalidation, pagination, strict imports, redaction, pipeline decoding, deterministic replay, parser fuzzing, read-only databases, explicit connection close and private/sanitized export boundaries.

Native tests exercise all eight developer sections, Sandbox read/prepare/review/send/verify, declining and invalidating confirmation, response comparison, changed pagination requests, Replay, Demo/Safe live restrictions, guided forms, report previews, local fuzzing and small-window wrapping. The broader existing native navigation test now opens **all 67 tool destinations**.

A separate native screenshot walkthrough recorded **zero Tk callback errors**, **zero OSC packets**, **no OSC grants**, **no bridge listener**, and peer mode **Private** in its isolated Demo/Sandbox setup. API Workbench, Overview and 1060×720 Larger-text/Compact layout screenshots were inspected. This does not certify every accessibility or Windows DPI case.

All **277 Python files** parse with Python 3.10 grammar. Runtime executes here on Python 3.13.5, not on Python 3.10 or Windows. All four Windows launchers and requirements.txt remain **byte-for-byte unchanged from 1.19.6.1**.

**Not validated:** live VRChat authentication, permission decisions, production endpoint compatibility, Windows-native appearance/DPI, real client avatar/instance completion, live OSC devices, external peers or SDK projects. The suite uses fixtures/fake HTTP, plus existing isolated local transport tests; no live VRChat account was used. The supplied 67-section design is a roadmap, not a completion claim.

The catalog has **58 entries: 37 executable reads, 18 executable writes and 3 reference-only entries**. The public-profile documentation link was corrected after the full run; it changes a reference URL, not request behavior.

Checked on 2026-10-01 using Python 3.12 in the build environment. Earlier-release checks below retain their original scope.

## Version 1.19.6.1 — Friendlier interface (minor update)

- The unchanged 1.19.5 baseline passed **2,208 tests** and **1,125 subtests**
  before UI work began. The updated full suite passed **2,249 tests** and
  **1,125 subtests**, with no failures, using Python 3.12 and native Tk under
  an Xvfb Linux display (47.76 seconds). The single collection warning for
  `TestListener` having a constructor also exists in the baseline.
- **41 additional tests** cover validated presentation preferences, local tool
  search, four-component release numbers, runtime version consistency, and
  **11 native Tk tests**. The pre-existing UI fixture assertions were updated
  for intentional navigation and disclosure-parent changes, not removed.
- The native route test and a separate screenshot walkthrough opened all
  **57 indexed destinations**. They switched Casual / Advanced / Developer,
  changed spacing/text size, and used the tool palette. There were **zero Tk
  callback errors**, the same existing OSC/peer/creator service instances were
  retained, OSC permissions remained empty, the OSC sent-packet count remained
  zero, and peer mode remained Private in the isolated Demo/Safe setup.
- Native widget tests verify that search cannot enable a disabled tab, a hidden
  creator tab can be reached without changing the global view, and font/spacing
  changes preserve local tab selection, disclosure state and column overrides.
  They also cover search singleton behavior, no-match disabling, selection-only
  log picking, cancel behavior, and invalid navigation routes.
- Native tests verify that Demo and Safe mode do not save display preferences,
  and the normal-mode appearance update writes only the dedicated
  `ui.presentation` record. Changing a view is not a permission grant or a
  service reset. Existing service authorization tests remain in the full suite.
- Home, avatar activity, Players, OSC, Settings and tool-search screenshots were
  inspected. The 1060 × 720 Settings layout with Larger text and Compact spacing
  was checked after fixing responsive label wrapping. Home and Settings scroll;
  horizontal scrollbars hide when not needed. This is not a claim of full
  accessibility certification or a redesign of every specialized editor.
- All **269 application, test and tooling Python files** parse with Python 3.10
  grammar. Help/version commands run without dependency installation. Runtime
  reports **1.19.6.1**; next ordinary release is **1.19.7**, and next minor update
  is **1.19.6.2**. All four Windows launchers and requirements.txt are
  **byte-for-byte unchanged** from 1.19.5.
- **Not runtime-verified:** Windows-native appearance/input, Windows DPI scaling,
  screen readers, live VRChat, live peers/LAN/VPN, real microphone/camera/tracking
  hardware, overlays, multicast discovery, or Unity compilation. A clean local
  UI walkthrough does not establish endpoint execution or platform compatibility.
  The earlier OSC and creator runtime limitations below still apply.

Reproduce the full UI-enabled suite from the source directory on Linux with a
native display or Xvfb:

```sh
xvfb-run -a -s '-screen 0 1500x1100x24' python -m pytest -q
```

Without a usable display, the 11 native tests skip explicitly; other tests can
still run with `python -m pytest -q`. Tests use isolated temporary data and
Demo/Safe UI setup rather than a live account or game session.

## Version 1.19.5 — Shared OSC controls

- **2,208 automated tests pass** across the full application suite. New OSC tests
  exercise the real shared service and controllers, deterministic clocks and
  in-memory transports, real loopback UDP, real bounded OSCQuery HTTP, and
  headless UI callbacks. No test sends a real peer message or controls VRChat.
- Ten OSC workspace tabs and the Networking transport panel build with the
  headless Tk fixtures. Tests execute reviewed UI callbacks, scoped source
  grants, release-on-focus-loss momentary controls, import review, eligible-avatar
  selection, simulator isolation and metadata-only export. Native Windows
  appearance and interaction still require native testing.
- Avatar Link, World camera capture and rangefinder views share one application
  service. Attaching/detaching a view cannot replace another view's socket or
  change transport settings. Real creator-workspace tests reject any attempt to
  use its old standalone camera sender. Standalone compatibility helpers remain
  separately tested; the application's live paths use the shared scheduler.
- Exact OSC Bool/Int/Float/String and multiargument messages reject malformed,
  nonfinite, excessive and unsupported input. Immediate bundles, bounded queues,
  source filtering, occupied ports, optional free-port fallback, stop/reconnect
  generations and a 32 KiB Dolly-string boundary are tested. Float observations
  compare their actual Float32 wire values without implicit numeric conversion.
- Session/account/world changes and every avatar initialization, including a
  same-ID reload, invalidate old work. Releases use only owned native controls or
  explicit ephemeral manifest cleanup; previous-avatar neutral values cannot be
  sent into the new avatar. Old Avatar Link contracts cannot rearm against a new
  shared avatar, and releasing one manual writer preserves sibling ownership.
- Discovery results carry their request-start context. A response started before
  an avatar transition cannot install the previous avatar's schema. Removed
  query parameters become unavailable, Toolkit declarations remain independent,
  changed ranges/access invalidate old actions, and changing advertised values
  alone does not invalidate the schema or unrelated queued actions.
- Microphone unknown-state behavior, bounded holds/toggles, one corrective privacy
  attempt, concurrent user changes, publication priorities and expiry, camera
  cancellation/native handoff, scaling overrides, safe avatar switching and
  individually reported safety steps are covered. Unrelated grants preserve
  privacy monitoring and accepted countdowns; scoped revocation cancels only
  controls that lose authorization.
- Managed routes require explicit source/address matching, exact typed transforms,
  fresh samples and separate grants. VRChat feedback cannot become route commands.
  Tests cover one eye representation, paired body pose ownership, source loss
  without zero poses, edge/cooldown rules and selective preset restoration.
- Accepted authenticated Eye-to-Eye countdowns require immutable, one-use local
  photo review. Scheduling uses the peer service's monotonic deadline. Session,
  context, privacy and permission changes cancel before the OSC send stage;
  local acceptance sends no new message to the peer.
- Configuration resumes inactive, with no saved held controls, captured poses,
  publications or peer work. Startup keeps the single dependency list and four
  CRLF launchers. All **263 Python files** parse as Python 3.10; all **147 root
  application modules** import with optional packages deliberately blocked.
  Help/version commands work without dependency installation; versions report
  **1.19.5** and the packager reports **1.19.6** as the next release.
- The supplied OSC design is preserved byte-for-byte (81,693 bytes) in
  OSC_CONTROLS_DESIGN_INPUT.md. The existing optional Avatar Toolkit remains
  version 1.19.3; this release does not claim a new Unity package build.
- **Not runtime-verified:** native Windows UI, live VRChat endpoints, actual mDNS
  registration/discovery with zeroconf, LAN/VPN interoperability, real microphone
  state, camera/Dolly execution, tracking devices, overlays or Unity compilation.
  UDP transmission, matching observations and file evidence remain distinct from
  confirmed rendered outcomes. Camera pose/audio conflicts and unfamiliar Dolly
  schemas require deliberate current-client compatibility verification.

## Version 1.19.4 — Automatic startup setup

- **1,983 automated tests pass**, including 26 new bootstrap/launcher checks and
  the full existing application suite. No feature package was downloaded or
  installed, and no device/provider/peer connection was started during these checks.
- Removed all seven `Install-*.cmd` scripts and consolidated seven dependency lists
  into one `requirements.txt`, preserving all ten distribution constraints and
  the Windows-only pycaw marker. Four launchers remain: Start, Safe-mode, Demo and
  the existing optional bridge example.
- Startup creates or reuses the app-local environment, checks installed versions
  under its interpreter, and runs pip only when requirements are unsatisfied.
  Healthy reuse, missing/outdated packages, missing pip, failed downloads, bounded
  timeouts, offline fallback and next-launch retries are covered by injected
  subprocess fixtures. Requirement parsing and platform markers use the actual
  bundled packaging parser; the tests do not pretend to download real wheels.
- Safe Mode, Demo, help and version flags skip setup and filesystem writes.
  Application arguments, paths with spaces and process exit codes are preserved.
  Real bootstrap help/version commands were exercised without package operations.
- Setup commands use the verified virtual environment, isolated Python/pip,
  disabled pip configuration files and no user installation. Tests reject external
  install-directory overrides, linked/junction environments and outward install
  paths. Existing unusable environments are retained; launcher-owned interrupted
  environments are retried in place without deletion or `--clear`.
- A real OS advisory lock prevents overlapping setup and releases after an
  exception. A second launch does not open a half-prepared application or remove
  another launch's lock. Native Windows lock behavior still needs Windows testing.
- All **241 Python files** parse as Python 3.10; all **137 application modules**
  import with optional packages blocked. All **four launchers** retain CRLF.
  Both app version entry points and bootstrap report **1.19.4**; next version is
  **1.19.5**. Current setup guides and missing-package messages point to Start.cmd.
- Prior design-input files and the experimental Unity Avatar Toolkit are
  byte-identical to the 1.19.3 archive; the unchanged toolkit retains version
  1.19.3. No creator/runtime behavior changes are part of this cleanup.
- **Not verified here:** native Windows CMD/Tk launch, package downloads or wheel
  compatibility on the user's Python installation. The build environment cannot
  load its native Tk runtime in a fresh isolated environment; the probe correctly
  rejects that environment. Python 3.10+ with working Tkinter remains required.
  Safe Mode and core fallback do not install Python, SteamVR, Unity, OBS or VPNs.

## Version 1.19.3 — Avatar Creator

- **1,957 automated tests pass**, 219 more than 1.19.2. Existing World Creator,
  networking, Wellness, recovery, player, Unity Player and VRCX flows are included.
  Primary → Avatars now has Activity plus nine lazy creator tabs; World tabs remain.
- Strict manifest/storage tests verify canonical avatar and local project scopes,
  bounds, typed parameters, built-in read-only parameters, costs, dependency and
  validity cycles, privacy, binding conflicts, platform order and immutable records.
- Avatar Link tests include real localhost UDP and explicit localhost HTTP OSCQuery.
  They cover exact typing, source/session isolation, pre-review queue cancellation,
  separate public gates, bounded held-contact requests, expiry/rearm, per-parameter
  ownership, source freshness, best-effort neutral states and scoped profile restore.
  These local fixtures do not constitute VRChat runtime verification.
- Controller tests cover pin/platform persistence, manifest/workspace/account
  changes, review invalidation, active-run detachment, no automatic actions,
  reviewed reminders/camera requests, camera failure without retry, count-only
  Black Box markers, bounded bookmark windows, mapping presets and shared World /
  Avatar overlay ownership. Demo/Safe Mode blocks live connection/output adapters.
- Complete headless tab and handler tests exercise all nine tabs, incomplete drafts,
  typed presets, real module composer and guided test records, report snapshots,
  compatible baseline comparison, provider controls, OBS-secret handling and
  selected-field peer review through a fake existing transport. No real person was
  messaged. Tests do not establish native Tk layout quality.
- Provider tests verify unavailable/stale versus zero data, explicit device roles,
  local hashed identities, charging validity, manual status precedence, bounded
  WAV analysis, opt-in test-signal routing, normalized metrics, sustained warnings,
  typed starter mappings and a real local read-only OBS WebSocket fixture.
  Worker/disconnect tests verify cached nonblocking reads and no automatic reconnect.
- Local workflow/report tests cover evidence modes, completed-run immutability,
  simulation not verifying runtime fixes, profile compatibility, finite recipes,
  source/build comparisons, portable handoffs, redaction, HTML/Markdown/CSV safety,
  exact reviewed bytes, overwrite refusal and permitted bounded static references.
- Unity contract tests inspect the editor-only package, cloned installation policy,
  private Contacts/menu alternatives, heartbeat/privacy gates, recovery ownership,
  source export and all twelve literal starter recipes against the Python schema.
  The package contains **six native EditMode tests**, including scene save/reopen
  journal recovery. **Those native tests were supplied but not executed here.**
- All **239 Python files** parse as Python 3.10; all **136 application modules**
  import with optional packages blocked. Offline workspace/run/bookmark/tick/report
  export succeeds with sockets and DNS blocked. All **eleven Windows launchers**
  retain CRLF. Both app version commands report **1.19.3**; next version is **1.19.4**.
  The original **85,765-byte supplied avatar specification** is preserved exactly.
- **Not verified here:** native Windows/Tk rendering; Unity C# compilation, SDK
  installation/build processing and supplied EditMode tests; physical hardware;
  real SteamVR cards; Contact/Animator execution or an uploaded VRChat avatar.
  The Unity toolkit is experimental. No avatar was published, user project edited,
  production client controlled, provider installed on the user's computer, or
  external peer message sent during these checks.
- Optional live Unity editor integration, generated-build processing hooks, general
  imported-model 3D rendering, live audio capture, full arbitrary animator graph
  analysis and interactive SteamVR controls are not implemented. Current local,
  source-file, static-preview, guided-test and read-only-overlay alternatives are
  documented in AVATAR_CREATOR_SETUP.md and AVATAR_TOOLKIT_SETUP.md. The complete
  specification coverage map is in AVATAR_CREATOR_DESIGN_INPUT.md.

## Version 1.19.2 — World Creator

- **1,738 automated tests pass**, 189 more than 1.19.1, including the existing World, player,
  networking, bridge, recovery, Unity Player, VRCX Companion and Wellness flows.
  World now has Players, Map and eight Creator tabs; the sidebar category
  structure is unchanged.
- Local SQLite tests verify atomic writes, strict JSON budgets, fixed world/kind
  ownership, immutable run/profile/checklist snapshots, literal scoped search,
  protected evidence retention, and private records surviving context changes.
- Metadata/API tests cover editable versus service-classification fields,
  three-way conflicts, incomplete draft preservation, read-only minimal API
  evidence, cancellation and account mismatch. No real publication or account
  mutation was performed; SDK export never claims successful remote submission.
- Real model/UI-handler tests exercise saved profiles and recipe lines becoming
  guided runs, separate build record UUIDs and declared helper IDs, manual evidence
  gates, environment-specific coverage, verified fixes, baseline compatibility,
  release requirements and unknown/blocked outcomes.
- Diagnostics tests cover bounded rate/retention, aggregate roster uncertainty,
  event/receipt ordering, source/build/object error groups, copied bookmark windows,
  missing/stale metrics, point-sample capacity summaries, separate recording
  sessions and actual existing-provider data flowing into the analysis layer.
- Reports are generated from exact record selections and frozen previews. Tests
  cover nested credentials, private text, identifiers, paths, URLs, arbitrary
  manifest fields, HTML/Markdown injection, CSV formula protection, byte-for-byte
  export after store edits and rejection of a tampered preview. No arbitrary
  attachment paths are read or bundled.
- Seventeen complete lazy-tab/widget tests plus separate form and peer callback
  suites exercise tab construction, operational buttons, stable table refresh,
  draft conflict and incomplete-input preservation, selected exports, explicit
  session association, population gaps, peer review and MIDI review behavior.
- Lifecycle tests verify stale metadata cancellation, unpublished session binding,
  pinned workspaces, account/world/build/run changes, no historical log capture,
  no completed-run recapture, preservation of local notes and pause on storage
  errors. Creator metadata auto-reads begin after a creator tab is opened.
- Optional helper tests cover closed finite manifests, malformed packets, context,
  manifest and selected MIDI-port binding, expiry, replay prevention, partial sends,
  untrusted helper-reported status, independent local verification and missing
  packages. Source contract checks compare the Python framing/slots with the
  supplied Unity exporter and finite Udon receiver.
- Peer tests exercise the existing service's ready state and permissions, exact
  selected field/recipient previews, stale/reused reviews, historical run identity,
  source-record duplicate detection across new message IDs and restarts, and
  reported-only imports. No real person was messaged.
- SteamVR fixtures verify one existing runtime owner, separate creator card,
  bounded monotonic TTL, placement/opacity, dashboard behavior, privacy hiding,
  disconnect behavior and no automatic redisplay after reconnect. Demo/Safe Mode
  gates block creator device control and presentation.
- All **216 Python files** parse as Python 3.10; all **125 application modules**
  import with optional packages blocked, including MIDI and VR dependencies.
  Offline project, checklist/run, bookmark and report preview workflows work with
  socket creation and DNS blocked. All **ten Windows launchers** retain CRLF.
  Both app version commands report **1.19.2**; next-version reports **1.19.3**.
  The original **74,301-byte supplied creator specification** is preserved exactly.
- **Not verified here:** native Windows/Tk layout, Unity/UdonSharp compilation,
  physical or virtual MIDI routing, real SteamVR rendering, or an uploaded VRChat
  multiplayer world. No software/provider was installed on the user's computer,
  public service deployed, production persistence reset or VRChat world published.
  See WORLD_CREATOR_SETUP.md and CREATOR_HELPER_SETUP.md for native test steps and
  explicit boundaries. Automated source/fixture checks are not native execution.

## Version 1.19.1 — Networking category and VPN options

- **1,549 automated tests pass**, a net increase of 83 from 1.19.0. The existing
  bridge, player, recovery, Wellness, VRCX Companion and local peer workflows pass.
  The sidebar has thirteen categories, with **Networking** under **VRC Eye**.
- Networking owns all peer host/join controls, invitations, adapters, connection
  profiles, relay-only policy, connection details and disconnect actions. Primary
  retains the seven local/activity/permissions tabs and a Networking shortcut.
  Independent workflow tests verify both pages use one app-owned peer service;
  navigating or closing a page does not create or close a connection.
- **16 adapter tests** cover bounded local enumeration, optional-package failure,
  Windows registry driver metadata, current link state, IPv4/IPv6 normalization,
  provider-name hints including NetBird's wt0 and Tailscale's tailscale0, incorrect
  provider/address combinations, ambiguous adapters, explicit Other VPN selection,
  custom pools, broadcasts and excluded scoped/link-local IPv6. Registry-only
  information remains configured/unknown, not a claim of live connectivity.
- **31 transport tests** pass, retaining actual pinned TLS and relay exchange,
  authenticated invitations and teardown coverage. Named provider modes use the
  selected source; missing/changed adapters and failed binds stop without fallback.
- **Nine independent integration tests** exercise real loopback TLS with explicit
  adapter fixtures for NetBird, ZeroTier, Radmin VPN and Other VPN. The host observes
  the actual selected loopback source. Live direct connections end when relay-only
  is enabled; an existing relay tunnel remains usable. These are protocol/source
  binding tests, not tests of the third-party providers or Windows VPN routes.
- **14 independent policy tests** verify enforcement before DNS, socket creation,
  adapter lookup and identity provisioning, plus cancellation while DNS, TCP
  connection and host startup are in progress. An OS DNS lookup already running
  cannot be forcibly stopped, but its completion cannot start a disallowed TCP
  connection. No relay failure silently attempts a direct route.
- **22 settings tests** cover strict bounded profiles, no credential/invitation
  persistence, offline invitation review, invalid-input isolation, durable privacy
  and corrupt-data recovery. Invalid saved settings default to relay-only, preserve
  an explicit recovery notice and cannot encode contradictory recovery/protection
  states. A failed persistence write cannot relax the current live policy.
- The **49 Primary/Networking UI tests** cover the moved controls, all supported
  modes, local profile save/load without networking, review cancellation, changed
  settings/policy/account during review, explicit VPN source selection, secret
  clearing after context changes, adapter status and the shared service lifetime.
- The actual **1.19.0 transport source from its release ZIP** accepts unchanged
  LAN/Hamachi/Relay tokens and rejects all five new VPN mode tokens. The 1.19.1
  parser accepts all eight modes. The application message protocol stays version 1.
- All **114 application modules** import with eight optional dependencies blocked.
  In a fresh process with socket creation and DNS resolution blocked, private
  bio/note/countdown tools, saved connection profiles, offline Relay invitation
  inspection and both UI imports work: **zero socket and DNS calls**.
- All **191 Python files** parse as Python 3.10 (114 application modules, 76 test
  modules and one helper). All nine Windows launchers retain CRLF. Both application
  version commands report **1.19.1**; next-version is **1.19.2**. The original
  supplied peer design remains unchanged after its annotated implementation map.
- **Not verified here:** native Windows/Tk layout, real Tailscale/ZeroTier/Radmin/
  NetBird/Hamachi networks, provider account/access rules, Windows adapter routing,
  internet relay hosting or physical VR hardware. No provider was installed,
  firewall changed, public service deployed or real person messaged. See
  NETWORKING_SETUP.md for the supported connection workflow and privacy boundaries.

## Version 1.19.0 — optional Eye-to-Eye services and Private Mode

- **1,466 automated tests pass**, 180 more than 1.18.10, including the existing
  navigation, player, bridge, Wellness, recovery and VRCX Companion workflows.
  The new workspace replaces the VRC Eye Primary preparation placeholder.
- Real loopback pinned-TLS tests cover LAN and the opaque relay tunnel, including
  three installations sharing a host-owned party board and individual readiness
  responses. Tests reject wrong pins/device keys/signatures, reused/expired
  invitations, malformed/oversized frames, spoofed senders, duplicate sequences,
  stale contexts and guest attempts to claim host authority.
- Transport tests exercise bidirectional relay bursts, pending TLS handshake
  interruption, bounded queues/receipts, explicit close and no automatic reconnect.
  Hamachi checks exercise detected IPv4 mesh interfaces, address validation and
  source binding using controlled adapter/socket fixtures; no real VPN was opened.
- Real temporary SQLite stores and injected clocks verify private profile/draft
  isolation, explicit field sharing, permissions and expiry, denial precedence,
  blocks, emergency revoke, local/offline history policy, manual queue flush,
  replay cache saturation, context invalidation and per-peer confirmation receipts.
  Timers normalize measured clock offsets and expire using a monotonic clock.
- Widget workflows cover all eight tabs, local item editors, group sharing/ready
  checks, typed recommendations, incoming consent/replies, offline queue review,
  profile changes during review, and Casual/Advanced/Developer presentation.
  The library fetches all saved items when the bounded 250-item snapshot is full.
- Independent integration regressions verify additive Player/Wellness privacy,
  saved streamer preferences before page creation, account and storage-error
  shutdown, local device-link save/unlink, and closing all tracked private windows.
  A fake OpenVR provider verifies notices expire in the input worker even when Tk
  stops refreshing; the existing Wellness overlay and action queue remain separate.
- Preset tests cover closed allowlists, diff, atomic writes, verification, rollback
  refusal after later edits and live view refresh. An actual Wellness engine keeps
  its active session/provider identities; a simulated UI refresh failure restores
  both durable settings and the running engine.
- All **111 application modules** import with cryptography, psutil, openvr, Pillow,
  pycaw, comtypes, websocket-client and lz4 blocked. A fresh Private Mode service
  saves a bio/note and runs a countdown with socket creation blocked: **zero socket
  calls**, no peer transport import and no optional dependency import.
- All **183 Python files** parse as Python 3.10 (111 application modules, 71 test
  modules and one packaging helper). All nine Windows launchers retain CRLF.
  Application version commands report **1.19.0**; next-version is **1.19.1**.
  The supplied peer design is preserved byte-for-byte after its implementation map.
- **Not verified here:** native Windows/Tk layout, an actual Hamachi network,
  internet-hosted relay availability/firewall policy, physical SteamVR display or
  real VRChat operation. No public server was deployed or real person messaged.
  This is functional/security regression coverage, not an independent cryptographic
  audit. See PEER_SERVICES_SETUP.md and PEER_SERVICES_DESIGN_INPUT.md for scope.

## Preparation for 1.19.0 — VRC Eye sidebar

- Added the independent **VRC Eye** section and **VRC Eye Primary** placeholder.
  No peer service, Private Mode or Hamachi features are implemented in this step.
- **47 existing navigation, companion, bridge and World UI tests pass.** Updated
  the existing category assertions for the twelfth entry. A focused widget-double
  smoke check verified section placement, selection, page reuse, account changes,
  shutdown and that opening the placeholder performs no network access.
- The placeholder has no action buttons. Native Windows/Tk layout remains
  unverified; the application version stays 1.18.10 for this preparation snapshot.

## Version 1.18.10 — VRCX Companion

- **1,286 automated tests pass**, 147 more than 1.18.9. They cover the new
  coordinator, handoffs, exchange, page workflows and cross-feature integration.
  The requested **Advanced → VRCX Companion** is the eleventh sidebar category.
- Controlled process samples cover optional dependency failure, exact process
  names/creation identity, child-process grouping, ambiguous roots, bounded scans,
  incomplete observations, expiry, distinct absence confirmation and independent
  return/retry. Process presence never implies verified external feature activity.
- Pure model/service tests cover opt-in defaults, presets/overrides, protected
  categories, user-declared settings, actual own-app availability, Solo Mode,
  ownership retention during uncertainty, configured conflicts and bounded events.
  Export validation excludes process paths/PIDs, handoff IDs and runtime tokens.
- Cross-feature tests use one real coordinator with mocked OS providers: Unity
  launch/recovery, Resource Guard close and Wellness exit share a reservation.
  Concurrent requests, stale reviews, changed targets/settings/runtime/environment,
  wrong operation kinds, queued cancellation, post-reservation stop, handler failure,
  lease expiry and submission cooldown are covered. No real process was terminated.
- Notification checks preserve roster/session processing while suppressing eligible
  banners. Ownership is checked again at display; already queued banners and a
  previously shown social banner are cleared after ownership transfers. The old
  manual suppression setting survives migration and stale settings-dialog saves.
- Real temporary SQLite stores verify whole-file validation, native header-first/
  header-last CSV, escaped multiline fields, exact typed IDs, friends JSON,
  duplicates, discarded memos, 2 MiB/10,000-record bounds, transactional rollback,
  insert-only merges preserving existing metadata, complete ID-list exports and
  exclusive destinations. Imported/exported IDs remain explicit user-reviewed data.
- Actual Tk callbacks run with the established widget doubles: five scrollable
  pages, Casual/Advanced/Developer visibility, settings, temporary Solo, central
  legacy tools, declined/accepted handoffs and exchange previews, report export,
  simulation, Demo/Safe Mode guards and dialog shutdown. Entering Demo suspends
  the coordinator synchronously; open legacy cache callbacks recheck the environment.
- Duplicate global connection controls were consolidated into the sidebar, avatar
  search into Search and recovery launch into Unity Player. Navigation remains
  scrollable; selection-specific actions stay with their data. Tests exercise the
  new destinations and confirm no direct Steam launch from Crash & Diagnostics.
- A read-only Linux smoke test with the real optional psutil **7.2.2** detector
  confirmed VRCX absence from distinct samples, released local ownership and
  joined the worker on close. No VRCX files or operating-system settings changed.
- All **99 application modules** import with psutil, openvr, pycaw, comtypes,
  Pillow, websocket-client, lz4 and cryptography blocked. All **163 Python files**
  (99 application, 63 test, one packaging helper) parse as Python 3.10.
  Windows launchers retain CRLF. `--version` reports **1.18.10**; next-version is
  **1.19.0**. The complete uploaded design remains byte-for-byte after the map in
  VRCX_COMPANION_DESIGN_INPUT.md.
- VRCX URI/export contracts were checked against the pinned primary source listed
  in VRCX_COMPANION_SETUP.md. No supported local settings/heartbeat/restart/RPC
  coordination API was identified; the UI distinguishes user declarations from
  process evidence and does not claim an external lock or acknowledgement.
- **Not verified here:** native Tk layout, native Windows process enumeration,
  real VRCX/Steam URI handlers, VRCX login, actual VRChat tandem operation or
  hardware/VR behavior. No live VRCX/VRChat launch, close, move, remote favorite
  update or VRCX database/configuration write occurred during this build.

## Version 1.18.9 — Unity Player

- **1,139 automated tests pass**, including 71 new runtime model, provider,
  launch, bridge, history/export and UI workflow checks. The sidebar now includes
  the requested **Advanced → Unity Player** category.
- Controlled process/window samples cover identity generations, distinct absence
  confirmation, stale/ambiguous providers, startup measurement eligibility,
  hang/recovery timing, observation gaps, qualified versus unknown exits,
  metadata parsing and immutable snapshots. Freshness expires independently for
  process, resources, window and bridge fields; graphs reject another process's
  measurements.
- Window contract checks cover reviewed process/generation/geometry/topology
  binding, expiry, changed-target cancellation, work-area clamping, primary-display
  placement and session-local known-good geometry. Launch checks cover supported
  typed flags, fixed Steam URIs, fresh absence checks, duplicate suppression and
  cancellation. OS mutations and URI launches use test substitutes.
- Bridge tests exercise matching PID/creation time, generation changes, consent
  expiry/disconnection, strict schemas, sample expiry and single counting of
  runtime error batches. Normalized Black Box forwarding excludes process paths
  and identifiers; delayed runtime exits cannot close a newer player session.
- Temporary-file checks cover bounded summary retention, atomic persistence,
  malformed/oversized input, field sanitization, clear/disable behavior and
  exclusive exports that preserve existing files. No real user history was used.
- Actual Tk callbacks run with the established widget doubles: eight pages,
  Casual/Advanced/Developer visibility, background start, Demo isolation, profile
  validation, reviewed window/launch/export/retention actions, pending-operation
  guards, source display and isolated simulation.
- A read-only Linux smoke check with psutil **7.2.2** exercised the real independent
  core collector, fresh process-absence reporting, default no-history behavior
  and joined shutdown. It exposed a collection-timestamp ordering issue that was
  corrected and covered by a worker regression test.
- All **92 application modules** import with optional psutil, openvr, pycaw,
  comtypes, Pillow, websocket-client, lz4 and cryptography blocked. All **151 Python
  files** (92 application, 58 test, one packaging helper) parse as Python 3.10.
  Windows launchers retain CRLF; `--version` reports **1.18.9**, and the next-version
  helper returns **1.18.10**. The complete uploaded discussion is preserved
  byte-for-byte after the implementation map in UNITY_PLAYER_DESIGN_INPUT.md.
- **Not verified here:** native Tk layout, Windows window APIs and mixed-DPI or
  multiple-monitor recovery, Steam URI argument handling, real VRChat sessions,
  GPU/VR hardware or an actual compatible runtime adapter. These remain target-
  system checks. No live game was launched, moved or terminated during validation.
  UNITY_PLAYER_SETUP.md describes the implemented scope and later roadmap items.

## Version 1.18.8 — Crash & Diagnostics

- **1,068 automated tests pass**, including 59 new diagnostics storage/model,
  process-state, platform-parser, export, startup-guard and UI workflow tests.
  Existing sidebar tests now include the ninth requested category.
- A child Python process committed Black Box records and terminated immediately
  with `os._exit(0)`. A fresh store recovered the valid WAL-backed records into an
  incident before opening a new ring. This tests abrupt process termination,
  not a real power loss, BSOD or storage-controller failure.
- Real temporary SQLite stores cover clean/unclean stops, exclusive writers,
  checksums/corruption, sequence holes, ring rotation, incident preservation,
  count/age pruning, budget failure, history while disabled, selective deletion,
  opted-in recovery-target erasure, OS evidence and exclusive ZIP export.
- Controlled samples cover unknown/ambiguous process state, repeated/stale
  observations, process identity changes, reviewed normal close, sustained
  unresponsiveness/loading grace, source expiry, queue overflow, replay gaps,
  checkpoint comparison and next-boot OS events preserving the last measured time.
- Privacy checks cover strict field allowlists, invalid/nonfinite measurements,
  raw text/credentials/paths/private-instance exclusion and export revalidation.
  Windows XML tests cover provider/ID/time matching, application filtering,
  size/entity rejection and stripping personal paths.
- Native Tk callbacks run with established widget doubles: sidebar and mode
  visibility, replay/graph/timeline, Demo rejection, pending-task mutation
  prevention, export/deletion/retention cancellation, fresh recovery checks,
  changed-process cancellation and private-instance-free world-page recovery.
- A read-only Linux smoke test with psutil 7.2.2 exercised the independent core
  fallback, fresh system RAM and VRC Eye RSS, disk-backed heartbeat, incident
  preservation/loading and a joined clean writer shutdown.
- All **86 application modules** import with optional psutil, openvr, pycaw,
  comtypes, Pillow, websocket-client, lz4 and cryptography blocked. All **143 Python
  files** (86 application, 56 test, one packaging helper) parse as Python 3.10.
  Windows launchers retain CRLF; `--version` reports **1.18.8**. The entire
  uploaded design remains byte-for-byte at the end of its implementation map.
- **Not verified here:** native Tk layout, Windows responsiveness/Event Log access,
  GPU/VR driver behavior, VRChat/Steam URI launch, headset inputs, a real game
  crash, BSOD, power loss or filesystem/device failure. These require a target
  Windows/VRChat test session. No live game was killed or restarted during testing.

## Version 1.18.7 — Performance & Security

- **1,009 automated tests pass** (55 new Resource Guard/backend/journal/UI checks).
  The full prior suite remains included; two sidebar assertions now expect the
  explicitly requested eighth category. Tests ran with the optional recovery
  dependencies and with psutil absent from the ordinary interpreter.
- All **79 application modules, 54 test modules and the packaging helper** pass
  Python 3.10 grammar checks in the build interpreter. All application modules
  import with psutil, openvr, pycaw, comtypes, Pillow, websocket-client, lz4 and
  cryptography blocked. The app reports **1.18.7**; next-version is **1.18.8**.
  All Windows launchers, including Install-performance.cmd, retain CRLF.
- Controlled monotonic samples cover sustained thresholds, hysteresis, recovery,
  cooldown, missing/stale metrics, suspend/time rollback, composite unknown logic,
  process restarts, disabled rules, threshold validation and GPU-load non-escalation.
  Bounded history checks cover peaks, min/max/mean, 24-hour capacity and trend reset.
- Controlled psutil/NVIDIA/AMDGPU/disk inputs cover CPU warm-up/normalization,
  ambiguous processes, executable/PID/creation-time changes, process exit during
  collection, independent sensor errors, units, invalid counters and GPU timeout.
  Device-wide GPU memory is never reported as process VRAM.
- Real temporary journals verify checksums, damaged/truncated tails, clean-stop
  flushing, size rejection, action-free replay, retention count and deletion that
  preserves unrelated files. Service checks cover privacy, context replay filtering,
  multiple nearby event types, missing disk space, warning snooze/escalation,
  process-bound close review expiry, Demo rejection and no automatic close even
  during simulated emergencies.
- Actual Tk callbacks run with widget substitutes: sidebar page and five panels,
  mode visibility, persistent settings, unit conversion, invalid-edit preservation,
  close confirmation/cancellation/expiry, Demo preference isolation, isolated
  simulation, graph paths and account-change invalidation.
- A separate read-only Linux smoke check used the existing psutil **7.2.2** wheel:
  live system RAM/CPU, VRC Eye RSS/CPU and data/system-drive counters produced fresh
  values. GPU unavailability did not stop collection. All worker threads stopped
  cleanly; default session-only mode created no journal. No VRChat process was
  present, and no actual process close or bridge action was performed.
- Native Tk visual inspection was attempted with the existing Xvfb binary, but
  this environment could not create its display sockets. Scrollable panels and
  headless callback checks do **not** replace live visual verification. Windows
  commit/private-memory readings, actual GPU/thermal hardware, Windows launchers,
  native window layout and normal-close interaction still need target-system checks.
- The original uploaded proposal is preserved byte-for-byte following the release
  implementation map. Later-stage automatic shutdown, overlays, OS containment,
  watchdogs, full Black Box and longitudinal baselines are not claimed as complete.

## Version 1.18.6 — Player sessions

- **954 automated tests pass** with the optional recovery dependencies present
  (68 added for player sessions, bridge integration, role/relationship lookups,
  history, replay, UI workflows and image caching). The three new player test
  modules also pass separately after the final source-age/shutdown refinements.
- All **74 application modules**, **52 test modules** and the packaging helper
  pass Python 3.10 syntax/compilation checks in Python 3.12. Application imports
  work with cryptography, lz4, Pillow, websocket-client, psutil, openvr, pycaw and
  comtypes blocked. Both version entry points return **1.18.6**; the next-version
  helper returns **1.18.7**. Windows launchers retain CRLF.
- Real temporary SQLite databases verify encounters, incomplete visits, separate
  world sessions within one read batch, replay idempotence, rejoin gap exclusion,
  crash reconciliation, per-user opt-out, expiry, incognito removal, suppression
  markers, category exports, explicit deletion and preservation of notes/favorites
  when clearing encounters. The bounded serial worker tests cancellation policies,
  queue overflow and shutdown. No real player database was used in these tests.
- Controlled-clock/state tests cover source precedence, expiry, provisional IDs,
  ambiguous names, stale logs, immutable cards, scoped friend snapshots, observed
  avatar changes, explicit local incidents and ambiguous pre/post RAM correlations.
  Deterministic shuffled duplicate events verify 128 distinct account sessions.
- The real bridge permission/state engine exercises exact instance binding, voice
  sample age and release smoothing, feet conversion and selection preference,
  associated avatar performance, disconnect/revocation, loading timeouts, stale
  action reviews, selection matching and Demo isolation. API tests use controlled
  responses for roles, identity mismatches, account-scoped caches and the documented
  friend-status endpoint; no live VRChat account or custom client was connected.
- Actual Tk callbacks run with widget substitutes: Casual/Advanced tabs, selected
  player/profile navigation, notes/tags/favorites, unknown IDs, asynchronous history
  reads, complete-category export, deletion reviews, presentation hiding/draft
  restoration, settings validation, context changes, absent bridge controls and
  incremental 100-row pages. An isolated 128-player CLI simulation completes with
  zero history writes; offline replay reports omit names, IDs and instance codes.
- A native Linux Tk preview was attempted, but Xvfb could not create its listening
  sockets in this execution environment. **Native Windows layout, real logs from
  the user's current VRChat build, live API visibility, process RAM monitoring and
  a real client adapter remain target-system checks.** Automated tests do not
  establish that every community-documented API field is visible to every account.
- The two input uploads have identical SHA-256 hashes. Exactly one byte-preserved
  copy follows the implementation map in **PLAYER_LIST_DESIGN_INPUT.md**.
  **PLAYER_LIST_SETUP.md** documents implemented behavior and later blueprint phases.
  Dedicated player wrist/VR/phone views, peer discovery/ready checks/shared bookmarks,
  photo integration and full Black Box/Safety Center integration are not claimed.

- VRC Eye **1.18.5** passes **886 automated tests** with optional recovery dependencies present (**102 new Wellness checks**). All 63 application modules, 49 test modules and the packaging helper pass Python 3.10 syntax/compilation checks. Both application entry points return `1.18.5`; the next-version helper returns `1.18.6`. Windows launchers retain CRLF, including **Install-wellness.cmd**. The original 56-part Wellness input is preserved byte-for-byte after the implementation-map preface in **WELLNESS_DESIGN_INPUT.md**.
- Controlled-clock tests cover first/repeat delays, future reminder consolidation, fairness for separately displayed reminders, explicit short snoozes, per-reminder and visible-batch acknowledgements, Focus/DND/Creator holds, quiet clocks, calendar-day bedtimes and midnight wind-down, missed ticks/clock rollback, meaningful versus brief breaks, manual posture, sensor expiry/unknowns, overlapping process/wear time, fresh/recharged batteries, digital-audio notice opt-ins/expiry, session markers, migration, unchanged-row progress, frozen summaries, opt-in counts and erasure of completed measurements.
- Real SQLite retention checks span more than 200 records, preview before deleting, preserve unknown legacy timestamps unless explicitly deleted, and leave unrelated settings intact. Templates round-trip configuration only, preserve private preferences, reject duplicate/unknown/private fields, invalid numbers and oversized input, and refuse silent overwrites. Existing manual reminder behavior and legacy saved-history preferences are preserved by migration.
- Actual Wellness and Sidebar callbacks use Tk substitutes to check Casual/Advanced construction and scroll reachability, profiles, isolated simulation including forced due reminders, notification previews, static scrollable cards, Streamer preview suppression, no-history/memory-only/retained summaries, explicit export opt-in, deletion reviews, reviewed template imports, canceled/stale local controls, Demo isolation, process-session lifecycle, old versus fresh log delays, session-bound overlay buttons, timer visibility and shutdown. Native Tk visual layout has not been interactively verified.
- Process/OpenVR/COM tests use controlled providers, never real game processes. Checks include exact name/PID/creation-time matching, no passive volume/exit mutations, queue and event bounds, canceled/expired/stale-generation requests, worker-failure cleanup, process switch after review, unknown proximity, no movement-to-wear inference, optional package failures, battery capability/charge state, in-memory RGBA HUD/dashboard/thumbnail textures, missing wrist anchors, left-button event filtering, session-bound overlay actions, default-output audio-session identity and explicit halve-volume/mute behavior. Windows `WM_CLOSE`, COM audio routing, real SteamVR driver readings and overlay placement/interaction remain live-environment checks.
- The generated large-text overlay texture was visually inspected; its text and buttons fit the fixed canvas. The PCM chime was checked for format, duration and amplitude, without playing audio. The inspected optional-package wheels are openvr **2.12.1401**, psutil **7.2.2**, and pycaw **20260927**; their source/API contracts and Python requirements informed the optional installer. Downloading/inspecting wheels is not a Windows/SteamVR integration test. No device runtime was started, no real volume was changed, and no game process was terminated.
- All application modules import with cryptography, lz4, Pillow, websocket-client, psutil, openvr, pycaw and comtypes blocked. Manual Wellness stays available without optional components. No Safety Center, automatic social break-status sharing, Resource Guard, health inference, per-player audio attribution, or automatic game/audio intervention is claimed by this release. Full operation and remaining scope are documented in **WELLNESS_SETUP.md** and **WELLNESS_DESIGN_INPUT.md**.

- VRC Eye **1.18.4** passes **784 automated tests** with the optional recovery dependencies present (79 added for the bridge). Its 60 application modules, 46 test modules and packaging helper pass Python 3.10 syntax checks and compile. All application modules import with cryptography, lz4, Pillow and websocket-client blocked. Both version entry points return `1.18.4`; the next-version helper returns `1.18.5`. Windows launchers, including the diagnostic bridge example launcher, preserve CRLF endings. No new external dependency is required for the bridge.
- Protocol/state tests cover bounded JSON/framing, duplicate fields, nonfinite/oversized/deep records, HMAC binding of role/nonce/payload/key, incompatible versions, declared presets, all typed telemetry/action schemas, unknown capabilities, claimed diagnostic/game identity, disconnected/quarantined/acknowledgement/control gates, account mismatch and changes, exact heartbeat/consent/sample expiry, clock reversal, stale session reviews, pause/revoke, queue bounds, canceled/expired/failed requests, exact confirmations, duplicate results, inbound-command rejection, copied snapshots and payload-free bounded ledgers.
- Actual host and SDK I/O threads exchange framed messages through **controlled in-memory message-pipe endpoints**. Tests exercise mutual authentication, quarantine, approved ping/telemetry, explicit main-thread dispatch to test callbacks, handler failures, revoke/disconnect before dispatch, reconnect with new consent, disabled listener/secret invalidation, repeated bad authentication isolation, API account change, lease loss after UI pruning, canceled handshakes that finish late, and hostile client-to-host commands. Worker shutdown is checked. SDK-specific checks cover dispatch expiry, stale/repeated permissions, missing heartbeats, duplicate requests, wrong runtimes, unimplemented handlers and nonlocal pairing codes. No real game handler, account or VRChat process is involved.
- Transport tests use substitutes to check stream fragmentation/coalescing, incomplete/oversized frames, one-frame-per-message pipe encoding, same-UID requirements and private socket metadata checks before connecting. Windows API substitutes verify local-only/first-instance/overlapped flags, one pipe instance, current-token SID DACL construction, non-inherited security attributes, accept cancellation, handle ownership and cleanup on constructor failure. **These are platform contract tests, not native IPC runtime tests.** An attempted native Unix listener was rejected by this build environment with `PermissionError: Operation not permitted` when creating an AF_UNIX socket. Native Windows is unavailable. No TCP fallback was added to the production bridge.
- Actual Advanced bridge panel callbacks run with Tk substitutes: disabled startup, seven unchanged primary categories, no Safety placeholder, window reuse, diagnostic/quarantine hiding, individual/multiple approvals with duration, rejected reviews, changed connections/accounts during review, separate local-control enable, exact-ID/parameter review and client confirmation, invalid UI values, preset descriptions, unsupported capabilities, clearing stale telemetry/targets on disconnect, connection-code clipboard handling and app-versus-panel shutdown. No native graphical layout or Windows launcher was run. A real compatible-client session remains unverified.
- The complete supplied Safety specification is retained byte-for-byte after the status preface in **SAFETY_DESIGN_INPUT.md**. Its 56 planned sections are not all implemented in this release. **BRIDGE_SETUP.md** and **BRIDGE_PROTOCOL.md** describe the completed bridge foundation, client-author responsibilities, temporary consent, uncertain in-flight outcomes, open message contract and native-runtime limitations. Existing avatar/world backup authorization and all seven companion pages remain independent of bridge data.

- VRC Eye **1.18.3** passed **705 automated tests** with the optional recovery dependencies present (74 new tests). Its 54 application modules, 41 test modules and packaging helper passed Python 3.10 syntax checks and compilation. All application modules imported with cryptography, lz4, Pillow and websocket-client blocked. Both version entry points returned `1.18.3`; the next-version helper returned `1.18.4`. Windows launchers retained CRLF endings. The updated extras installer includes websocket-client but has not been run on Windows.
- The real shared API client and companion operations run against controlled responses for user/world/group search, exact IDs, friend-list/notification pagination, account favorite limits, owned favorite lists, favorite record IDs, add/remove favorites, friend requests, group invite acceptance/decline, and mute/block resets. Tests cover malformed records, hidden fields, stale/forged/cross-account invitations, queued expiry, cancellation, uncertain confirmations and no automatic write retry. No real account or social action was used.
- SQLite tests retain and page 1,234 local favorites, beyond the game and online browsing limits, with full CSV export/import, Unicode and formula-looking names, literal filters, transaction rollback, unique IDs and account-scoped Feed history. Feed tests distinguish baseline observations from changes, image changes from avatar IDs, newly visible groups from exact joins, private/offline locations, status changes, unrelated pipeline events, and unknown friendship-removal actors.
- Live Feed uses a controlled connector to test the fixed WSS host, auth-cookie selection, redirect refusal, successful upgrade requirement, receive-only friend packets, disconnect, stop/account/demo cancellation, missing optional dependency and credential-free error messages. No connection was made to VRChat's live pipeline. The implementation and redirect behavior were checked against websocket-client's source documentation; native package/network compatibility still requires live testing.
- Game Log tests exercise actual classification, bounded retention/paging, known credential redaction, non-clickable secret URLs, stack context, video load uncertainty/start/end, VRCX video markers, rotation and normal exit versus explicit crash markers. Public-image tests use controlled HTTPS objects and real image decoding to check protocol/redirect/MIME/size limits, no credentials, private-address refusal, DNS address pinning, cancellation and connection closure. No real remote media was retrieved.
- Actual sidebar/page callbacks run with Tk widget substitutes. All seven pages construct without network access, and Primary keeps Avatars/World navigation. Workflows cover user and exact-avatar search, VRCA routing, changed queries/accounts, local and game favorites, confirmed social actions and rejected reviews, Feed snapshots including partial group denial, image preview surviving log-follow updates, demo separation, wellness profiles, reminders, summaries and failed-save shutdown choices. These checks do not establish native visual layout.
- Injected-clock wellness tests cover all-off defaults, optional sessions, consolidation, prompt spacing, queued bedtime, midnight wind-down, quiet hours, snooze with newly due messages, breaks and active time, manually marked standing, fresh/stale/manual battery readings and recharging, motion mode, invalid inputs, settings changes, frozen finished summaries and wall-clock changes. No health sensors, clinical measurements, wellness scoring or VRChat lifetime playtime are claimed.
- Read **COMPANION_SETUP.md** for operating steps, bounded log/history retention, account limits, local data and backup formats, opt-in polling, and features that depend on API visibility. Existing modules and workflows remain covered by the earlier 631 tests.

- VRC Eye **1.18.2** passed **631 automated tests** with the optional recovery dependencies present (52 added for this release). Its 42 application modules, 35 test modules and packaging helper pass Python 3.10 syntax checks and compile. All application modules import with cryptography, lz4 and Pillow blocked. Both version entry points return `1.18.2`; the next-version command returns `1.18.3`. Windows launchers retain CRLF line endings. The optional extras installer is included but has not been run on Windows.
- Profile/API tests use the real client with controlled responses to verify public/user/private-profile paths, exact identities, limited retained fields, credential/nonce filtering, own-account credits/uploads, favorite owner parameters, mutual pagination, denied versus empty results, cache behavior and exported-profile reimport. Account and avatar edits exercise actual PUT construction with only changed allowlisted fields, own-account/author checks, ownership expiry including queue delay, cancellation, changed accounts, stale responses and no automatic write retry. Boops use a single confirmed POST. No real VRChat account was read, edited or booped.
- Local SQLite tests verify persistent per-ID notes, Unicode/parameter binding, deletion, bounded observed-name history, preserved first-seen time, transactions and closed connections. Actual player-window callbacks run against Tk substitutes: roster selection/window reuse, nine tabs, My account navigation without a roster row, unavailable/name-only behavior, local note autosave and failure preventing shutdown, collections, link opening, explicit edit/boop confirmation, form state, invalid ownership changes, login continuation and late-result rejection. These do not establish native Windows layout quality.
- Whisper tests exchange messages between two real loopback HTTP clients and the bundled relay. A second test uses a real loopback TLS listener and temporary certificate, rejects an untrusted certificate, then exchanges a message with an explicitly trusted test CA. Other checks cover private invitation identity binding, both encryption directions, nonce uniqueness, tampering/wrong keys/reflection/age, exact reply cursor/IDs, duplicate suppression, bounded requests, redirect refusal, absence of VRChat credentials, operator-token rejection, rate limits, duplicate acknowledgements, conflicts and retention. The actual whisper worker/controller callbacks test explicit pairing/send, preserved drafts, failed sends, received messages and queued work canceled by an account change. No public relay was deployed and no real friend was messaged. This is not an independent cryptographic audit or a test of the user's internet hosting.
- Image tests check HTTPS host/path/cookie restrictions, credential removal on redirects, response-size/type limits, account changes during loading and invalid-image errors. Native image decoding/rendering in Tk and live VRChat/CDN access remain unverified. Profile endpoint/field definitions were reviewed against the community-maintained API project and VRCX source; server access and live behavior can differ. Setup and capability limits are documented in PLAYER_PROFILE_SETUP.md and WHISPER_SETUP.md.
- All 579 automated tests passed for VRC Eye 1.18.1, with no skips when cryptography 46.0.0 and lz4 4.4.5 were available. The 34 application modules, 31 test modules, and packaging helper pass Python 3.10 syntax checks and compile. All application modules import with optional recovery packages blocked; the new and legacy version commands return `1.18.1`. Windows launchers preserve CRLF line endings. The next-version command returns `1.18.2`; rollover tests verify `1.18.9 → 1.18.10 → 1.19.0` and invalid last components are rejected.
- Version 1.18.1 adds 50 tests for world/player visits, summaries, metadata, helper fields, UI callbacks, and version policy. They check room name/ID lines in either order, intervening player joins, duplicate joins/leaves, rejoining with a separate visit, local initialization before join, unknown joins, orphan leaves, duplicate display-name ambiguity, three room-exit formats, frozen elapsed time, missing exits, midnight/invalid dates, immutable snapshots, and bounded visit history. A real temporary-log monitor delivers roster updates with no avatar changes and clears them on log rotation.
- Summary tests distinguish observed log counts from fresh helper totals, world capacity from recommended capacity/world-wide occupants, and missing friend data from a known empty list. They cover exact-ID friend membership, unknown/partial rosters, source-count disagreement, exits, and retained previous exit timestamps. API tests use controlled HTTP responses and the real client to check metadata cache reuse, exact world IDs, minimal retained summary/friend data, shared metadata waiting, cancellation, account revision changes, expired authentication, and disconnect during responses. Summary lookups never grant world-backup permission.
- Headless World-page tests exercise the actual Players/Map navigation, no-map/no-avatar roster flow, departed-history filters, full timestamp details, selected-user lookup, preserving roster metadata during avatar refresh, friend/capacity/elapsed display, helper expiry, wrong-world/old-instance isolation, single automatic lookup, explicit refresh, partial API failure, cancellation, close, and late results after account/world/selection changes. The previously required map calibration no longer blocks starting the helper feed. These checks use widget substitutes and do not establish native layout quality.
- Updated helper parsing tests cover backward compatibility with the old optional-field-free packet, VR-mode/OS distinctions, local-only FPS/platform, missing/invalid/nonfinite measurements, total-count bounds, strict source/time association, duplicate names, and explicit unverified display-name associations. No Quest brand, phone model, remote FPS, or player ping is inferred. All three included C# helpers passed syntax parsing; the updated Udon reporter was not compiled in Unity or run in a live world. Local FPS is a Unity frame-count average over the reporting interval, not a measured remote/headset-rendering rate.
- World/player source notes were checked on 2026-09-30 against the available VRCX parser source, VRChat's player/networking documentation, Unity's frame-count documentation, and the community-maintained VRChat API definitions. These sources describe data fields, not a successful request with the user's account. API access, log formats, helper behavior, actual instance-specific capacity, and friendship/device freshness still require verification in the user's environment. See WORLD_PLAYERS_SETUP.md for sources and setup.
- Version 1.18 adds 49 world-backup tests. They cover strict world/page IDs, author and current-friend verification, rejecting nonfriends/public-only/pending-request records, account-bound permission snapshots, refresh/expiry/revocation, and explicit platform/build/variant selection. API responses use test doubles; the actual lookup and session-validation code runs.
- VRCW transfer tests write and compare actual temporary files. They verify unchanged download/cache bytes, SHA-256, supplied-key download-plus-decrypt and cache recovery, every encrypted chunk's authentication, wrong keys/tampering, unknown/plain formats, missing dependencies before network access, and partial/staged output cleanup. Exact cache file/version/revision/variant matching, source preservation, locks, changed files, forbidden cache destinations, access errors, invalid responses, 2 GiB bounds, no overwrite, cancellation, and context checks at publication are covered. These fixtures contain no real world assets or keys.
- The actual world-backup UI callbacks run against Tk substitutes. Tests cover World-tab navigation, single-window reuse, owner/friend controls, multiple/missing builds, a successful file save and digest, key clearing/masking, a complete friend download/decrypt path, cache scan/save, locked/empty results, stale selection, account changes during the save picker, expiry, delayed results after disconnect/cancel, sign-in continuation, log-session reset, clipboard errors without secret disclosure, and shutdown cancellation. A disconnect between worker completion and UI delivery is explicitly tested. This is not native Windows rendering or live-world testing.
- Version 1.17 adds 26 camera tests. A real loopback UDP socket receives the documented camera preparation requests and capture press/release sequence. Tests check typed OSC arguments, camera-only address restrictions, invalid ports, and cancellation before shutter activation. These checks do not demonstrate that a live VRChat camera receives or acts on the packets.
- Photo tests use actual temporary directories and complete synthetic PNGs. They cover configured photo folders without modifying configuration, monthly subfolders, absent first-photo folders, scan limits, ignored links/deeper folders/non-PNGs, excluding old or overwritten photos, two matching nonzero file observations, source changes, bounds, exact PNG saving, and refusing existing destinations. A real watcher thread finds a newly appended file, leaves old photos unchanged, and stops; timeout does not import the newest old photo.
- Camera dialog callbacks run against controlled Tk substitutes. Tests cover preview before replacing a map, no inherited calibration/world ID, cancelled unsaved-map replacement, new captures clearing old previews, manual shutter mode without OSC, ignored late results, failed/changed photos, saved PNG bytes, existing destinations, worker errors, closed-window picker results, and main-window shutdown. A 3840×2160 synthetic photo takes the resize path to 1920×1080 with the source unchanged; the Tk decoder/subsampler/writer is substituted in this test and has not received a native rendering check.
- The camera feature uses manual camera positioning, the official capture/mask OSC endpoints, and local PNG observation. It does not write camera poses, read game memory, convert perspective into orthographic projection, remove occluders, generate unseen geometry, or supply live player coordinates. Current camera source notes disagree on pose writability; this release avoids that dependency. Live camera behavior, actual photo-file output and timing, map alignment, and Windows/Tk rendering remain untested. Source references are included in WORLD_MAP_SETUP.md.
- Version 1.16 adds 39 tests for the World tab. Geometry tests check image/world projection, reversed axes, off-map values, and 3D feet. Profile tests cover image-only versus calibrated maps, bounded PNG/GIF headers, portable image/waypoint round trips, invalid input, atomic replacement, failed publication preserving the existing file, and no persisted live roster.
- Real tab/controller callbacks run against Tk widget substitutes. They check separate Avatars/World parents, retained avatar actions, Rangefinder's new location, image import, calibration, map saving/opening, failed imports preserving the previous map, cancelled unsaved-map replacement, waypoints, marker/roster updates, display-name filtering, selection clearing after instance changes, off-map players, follow/pan/zoom, demo restrictions, worker cancellation, late results, and application shutdown. These are not native Tk rendering tests.
- Position parsing tests exercise direct and Udon-prefixed log entries, names and IDs, malformed/nonfinite data, duplicate player names versus duplicate IDs, exactly one local player, freshness from log and receive time, old/future entries, duplicate/out-of-order sequences, world changes, and world-ID mismatches. Leaving a room blocks subsequent reporter entries until another room begins. Existing avatar parsing remains independent of map messages.
- A real worker follows an actual temporary UTF-8 log, skips preexisting snapshots, receives an appended snapshot, and stops. Tail-only tests also cover partial lines, Unicode byte splits, UTF-16 LE/BE with odd initial offsets, an initially empty UTF-16 log, truncation, and log rotation. The UI removes positions once expired instead of presenting old file history as live movement.
- The included `VRCEyeMapReporter.cs` uses VRChat's documented Udon player API, VRCJSON serialization, and local Debug.Log output. All three C# helpers parse without syntax errors. This is not a Unity/UdonSharp compilation or live-client test. The reporter must be installed and built into the world, and PC Udon debug logging must be enabled. Map image/calibration accuracy, world compatibility, log buffering, and live marker accuracy remain unverified in an actual VRChat session. No universal world map or all-player position API is claimed.
- Version 1.15 adds 26 tests for public-avatar archiving. They cover direct API Public status, rejecting Private/Unknown/local-cache status and mismatched avatar/file IDs, missing URLs, build-specific Windows-safe filenames, selected-row/search routing, and explicit selection of multiple platform builds. Real cache copying and HTTP byte streaming are exercised with optional crypto/LZ4 packages blocked; saved bytes, hashes, and the original cache are verified. These copies deliberately do not decrypt or claim that the payload is a loadable avatar.
- The public archive dialog's actual callbacks run against widget substitutes. Tests cover no JSON-import fallback, exact lookup IDs, sign-in continuation, cache routing without a download, stale account/session/input/metadata changes, closed windows, failed Public rechecks clearing old controls, existing/cancelled destinations, denied downloads without retry, cancellation cleanup, non-daemon transfer workers, and no log-row relinking. A connection change while the native save picker is simulated prevents the transfer. No real VRChat account, avatar URL, or Windows UI was used.
- The API project's current avatar/file documentation and VRChat's public avatar/download discussions were checked on 2026-09-28. These sources do not establish that arbitrary public avatars can be downloaded by third-party clients. No keyless cache decryption, encryption detector, alternate access path, or universal file-access claim was added.
- Version 1.14 adds 42 tests. Synthetic encrypted UnityFS fixtures cover format versions 6–8, multiple blocks/chunks, front/end metadata, alignment, raw/LZ4 metadata, and retained compressed data. Recovered files are compared byte-for-byte with independently assembled expected plaintext containers. These tests use a synthetic key and payloads, not real avatar files or user keys.
- Recovery failures cover wrong keys, altered tags/ciphertext, truncation, already-readable and unsupported files, bad lengths, bounded metadata, cancellation before/after partial writes, existing/racing destinations, cache locks, source changes before/during recovery, and refusing output inside the cache. Tests verify original preservation, SHA-256 results, temporary-file cleanup, and keeping unidentified results as `.bundle`. Dependency failures provide installation instructions. Recovery workers are non-daemon so normal app shutdown allows cancellation cleanup.
- Real key-dialog callbacks with widget substitutes cover masked input, explicit clipboard paste of hex/Base64, invalid/unreadable clipboard contents without echoing secrets, field clearing, cancelled save prompts, disabled paste during work, window closure, and session cancellation. The key is not stored in settings or exports; no secure-memory-erasure or clipboard-clearing claim is made.
- Cache-rescue tests cover signed-out browsing without JSON/IDs, selected-row context, unique versus ambiguous PC builds, a remembered build, other-platform choices, exact-ID API results, missing/inaccessible metadata, mismatch rejection, sign-in continuation, and JSON fallback. Late callbacks after input edits, window closure, session/account changes, expired sign-in, or a newer import are rejected. Existing log-row associations are preserved. Real cache-browser callbacks scan temporary directories and route matched/unidentified entries to recovery, while refusing locked entries. No friend profile or friendship API check is needed for local cache preservation.
- The encrypted record framing was checked against the published VRChatStudio source, and AESGCM/LZ4 APIs against their documentation. This does not establish compatibility with every cache or current live-client build. Recovery authenticates encrypted chunks; Unity loading, unencrypted metadata authenticity, avatar identity for unidentified entries, and full project restoration are not established. The optional Windows installer and its environment selection have source/line-ending checks, not a Windows execution test.
- Version 1.13 adds 26 tests covering all five performance labels, independent platform summaries, ratings without download URLs, conflicting builds, missing values, impostor exclusion, malformed identities, build-count limits, current trust-tag mapping, legacy tags, missing tags versus empty lists, confirmed versus probable negative-trust flags, and rank-only API responses without platform information.
- Shader-report tests exercise CSV quoting, exact-ID matching, platform/time/schema validation, missing materials, mixed reports, malformed fields, file/row bounds, and per-platform storage. Real dialog callbacks are exercised with widget substitutes for primary online lookup, shader import, rendering, and rejecting a late response after an import. Lifecycle tests cover relinking, log reset, disconnect cleanup, CSV provenance, and preserving legacy settings during the rename.
- Both Unity editor helpers passed C# tree-sitter syntax parsing. This is not Unity compilation. Shader reports inspect assigned renderer materials (including inactive objects), not animation material swaps, build processor output, uploaded bundles, or other players' live avatars.
- Rank/API mappings and limitations were checked on 2026-09-28 against VRChat's performance/trust documentation, the API project's public user tags/moderation documentation, and VRCX's avatar-package parsing. The real API was not queried with an account. Block detection is deliberately unavailable; the test suite does not claim that any user blocked the account.
- The packaged ZIP is verified for CRC errors and byte-for-byte equality with the release source, with a versioned filename and a VRC-Eye root folder.
- Version 1.12 adds 34 tests for OSC decoding, range measurement state, loopback sockets, and the rangefinder's real UI callbacks with widget substitutes. Protocol checks cover supported argument types, bounded nested bundles, malformed/truncated/oversized inputs, future timetags, unrelated parameters, and whole-packet rejection. State tests cover meter-to-feet conversion, missing versus zero distance, hit loss/reacquisition, a changing heartbeat during stationary readings, rejection of a static default heartbeat, stale/repeated/missing heartbeats, avatar changes, invalid/nonfinite values, and clearing old readings before recovery.
- Actual UDP loopback tests verify reception, invalid-signal clearing, an exclusive loopback binding, port conflicts, and releasing the port after shutdown. Dialog checks cover explicit start, readout updates, missed hits, invalid settings, bind failures, stop/restart, window reuse, discarding closed-window callbacks, main-app shutdown, and keep-on-top behavior. These tests do not simulate VRChat's complete OSC timing or UDP packet loss patterns.
- The editor-only Unity helper's C# syntax was checked with a syntax parser. Thirty-three referenced public SDK members were checked against official VRChat 3.10.5 assemblies; raycast behavior, OSC ports/parameters, and layer numbers were checked against VRChat documentation. These are source/metadata checks, not C# compilation or a Unity runtime test. The build environment has no Unity editor, C# compiler, or live VRChat client. The generated avatar copy, its FX/heartbeat behavior, OSC emission, actual collider distances, and compatibility across worlds still need live verification.
- Release packaging uses `tools/package_release.py`, deriving `VRC-Eye-vX.Y.Z.zip` from the app version. It includes source, tests, documentation, launchers, and the Unity helper, excludes build caches and downloaded SDK references, validates ZIP entries against source bytes, and refuses to overwrite an existing archive.
- Version 1.11 adds 37 tests for API collection search, local cache search, standalone downloads, and search-dialog workflows. API tests check own/favorites/featured endpoint parameters, page bounds, distinct same-named IDs, malformed records, missing file URLs, reported build platforms, full pages with invalid records, unexpected response envelopes, recent-page reuse/expiry, shared rate waiting, access errors, cancellation, and disconnect during a response. No unsupported global-name-search or arbitrary user-ID parameter is sent.
- Local search tests cover Unicode name and creator substrings, literal wildcard characters, bound SQL parameters, page boundaries with invalid IDs, legacy schemas, and an unchanged database hash. Search-result filtering preserves distinct IDs and deduplicates repeated IDs across pages.
- Headless search tests exercise the actual callbacks for exact-ID/page-link lookup, rejected unrelated URLs, sign-in continuation, signed-out VRCX search, filters with no first-page matches, explicit pagination, changed queries/sources, later-page failures, selected-result links/downloads, cancellation, window closure, and account/session changes. Download-controller tests verify that result file metadata is reused without JSON or log-row association, missing files trigger an exact-ID lookup, mismatched or stale results cannot install metadata, and the standalone VRCA dialog can refresh online with JSON fallback. These substitutes do not establish native-window layout or live-service compatibility.
- Version 1.10 adds 35 tests for direct authentication, metadata, cookie isolation, and online/fallback controllers. Authentication tests cover separately encoded credentials, limiting Basic authorization to sign-in, authenticator/email/recovery verification endpoints, rejected/unsupported verification, credential-field clearing, cancellation/disconnection during sign-in, and session disposal. These use synthetic credentials and controlled HTTP responses, not a live VRChat account.
- Metadata tests cover exact avatar/user ID validation, file URLs and date/status parsing, metadata without downloadable files, minimal retained user fields, cache reuse without changing lookup time, cancellation during the 60-second wait, 429 cooldown without automatic retry, access errors, malformed/oversized/encoded responses, and discarding responses after disconnect. Metadata/sign-in redirects are refused and closed.
- Cookie-policy tests verify that connected file operations use only the auth cookie on the exact HTTPS API file host/path, without forwarding it to CDNs, other VRChat hosts, unrelated domains, HTTP, or user endpoints. Unconnected transfers retain their original credential-free behavior. This does not establish that all live CDN and authentication formats remain compatible.
- Workflow tests cover online lookup before JSON prompts, explicit JSON fallback, remembered metadata, asking for an avatar ID without guessing by name, local/size action routing, rejecting stale/relinked/import-overwritten results, API status precedence over VRCX cache, account-change cleanup, and lookup-dialog completion/error/cancellation. Headless sign-in tests exercise the actual login and verification callbacks and ensure that cancelled/disconnected work cannot install a late session.
- Version 1.9 adds 30 tests for the row menu, player identity, and user-platform imports. Menu tests cover right-click versus previous selection, keyboard access, live row reordering, filtered/relinked/reset targets, unknown avatar IDs, demo mode, and the player action. They exercise the actual controller methods with controlled Tk substitutes.
- Player tests cover explicit join IDs, departure/world resets, same-name conflicts, duplicate joins, missing/invalid IDs, and display-name reuse. Platform tests cover PC/Android/iOS, presence/platform/last-platform precedence, unsupported values, strict user-ID matching, JSON bounds/duplicates/depth/types, and refusing to infer a device from avatar package lists. CSV retains import provenance and explicitly distinguishes import time from unknown source/event-time freshness.
- Headless player-dialog tests cover file and pasted imports, cancelled/bad imports preserving data, updating only matching users, paused rows, changing selection while a dialog is open, rejecting stale session callbacks, missing-ID controls, clearing records, and discarding platform snapshots on reset.
- VRCX's join parser, user metadata fields, user coordinator, and in-memory user cache were inspected. Version 1.9 added explicit user JSON import; version 1.10 adds direct API lookup. No actual user JSON export or log from the user's installation was supplied; synthetic data cannot establish current player-device accuracy. Even API-returned last_platform is a last-known value, not guaranteed historical/live device evidence.
- Inspection confirmed that the old size feature accepted supplied values only and was disabled for unlinked rows. A standard avatar export did not supply its separate analysis data. No error message, export, or log from the user's current installation was provided, so the precise user-side failure has not been reproduced.
- Version 1.8.0 adds 35 tests for header-only size lookup, preserving HEAD across redirects, a one-byte range fallback, servers ignoring ranges, unavailable/permission-denied URLs, invalid sizes/types/encodings, missing totals, cancellation, and no response-body reads or credential headers.
- Size tests cover unique versus ambiguous platform builds, independent platform failures, partial merges retaining older values and provenance, conservative stale markers, and rejecting mismatched IDs. Headless tests exercise the real size-dialog callbacks for successful main-list updates, failure messages, pending manual edits, cancellation, and discarding results after relinking or another size edit.
- Selected-row workflow tests cover standard VRCX JSON import, event-specific unverified associations, reuse of remembered PC choices, build ambiguity, cancelled imports, completed-download byte counts, changed exports, and session reset invalidation. These tests do not establish an automatic player-to-file mapping from instance logs.
- Version 1.7.0 adds 26 tests for default/custom cache locations, malformed/bounded configuration, known cache hash/version values, variant revisions, exact file-version filtering, multiple matching variants, case and version-prefix differences, and refusing avatar-name/page matching. Cache path derivation was checked against VRCX's AssetBundleManager source on 2026-09-27.
- Synthetic cache tests cover unidentified bundles, raw/empty payloads, metadata/image exclusion, locked files, locks created after scanning or during copying, changed/replaced/deleted files, source symlinks, bounded scans, cancellation, byte-for-byte preservation, checksums, existing destinations, and refusing writes inside the cache. No actual VRChat or VRCX cache was supplied. Ordinary copying preserves encryption unchanged; the separate version 1.14 recovery tests are described above.
- Version 1.6.0 adds 29 automated tests for VRCA files. They cover local damaged/empty-file preservation, unchanged original bytes, existing destinations, competing destination creation, dangling symlinks, source changes during copying, cancellation before/during transfer, partial-file cleanup, expected SHA-256 matching/mismatch, and accurate unknown-size/header reporting.
- Simulated HTTP responses cover complete and truncated transfers, read failures after partial data, size limits with and without Content-Length, invalid lengths, HTML/JSON/empty responses, unsuitable content types, compressed responses, partial status/range responses, access-denied/unavailable files, and URL/redirect validation. Requests are checked for absence of Cookie and Authorization headers. These are controlled response objects, not downloads from VRChat's live servers.
- VRCX JSON tests cover avatar-ID matching, PC/iOS/Android choices, multiple builds, duplicate URLs, standard/security variants, omitted impostors, missing URLs, malformed entries, and bounded/deeply nested JSON. The export shape was checked against VRCX source; no user export was supplied.
- Version 1.5.0 checks UTC date conversion across day boundaries, leap dates, invalid/sentinel/missing dates, legacy caches without date fields, and using avatar creation/update dates rather than cache-added/read times.
- Platform-size tests cover PC/iOS/Android ordering in a single cell, decimal versus binary units, zero versus unknown, invalid/nonfinite/unbounded input, explicit fileSize bytes, ID mismatch, failed analysis, oversized/nested JSON, and refusing to substitute uncompressed/texture sizes. Tests verify that standard avatar JSON exports are not claimed to include analysis data.
- New row/CSV checks cover exact-ID associations, supplied-data provenance, date timestamps, and unverified/stale markers. A headless controller test confirms that refreshing dates keeps supplied sizes and that a previously detected stale state survives a later failed cache read.
- Version 1.4.0 covers exact-ID visibility lookup, public/private/unknown normalization, missing status columns, conflicting duplicate IDs, case normalization, requests across multiple batches, and fresh WAL reads after status changes/deletion. Visibility queries are included in the unchanged-database-hash check.
- Presentation tests verify that matching names do not assign status, relinking uses the new ID, unverified selections keep their asterisk, and CSV retains status/provenance/read time. Headless controller tests verify paused-list refreshes, failed lookups clearing old values, late results not overwriting newer selections, reset cancellation, and demo/disabled VRCX behavior. These use controlled callback/thread substitutes, not a live Tk display.
- Version 1.3.0 adds VRCX schema checks, read-only SQLite queries, local settings, and creator/source metadata in the avatar chooser.
- The integration is tested using temporary SQLite files matching the current VRCX avatar-cache schema. Coverage includes live WAL commits, locked databases, unsupported schemas and views, malformed files/IDs, Unicode names, query parameter binding, duplicate names, cross-source merging, and persisted connection preferences.
- A test attempts a write through the read-only connection and verifies rejection and an unchanged source database hash.
- Version 1.2.0 adds tests for official URL validation, rejecting unrelated URLs, browser dispatch, local candidate lookup, duplicate-name handling, and link provenance in CSV exports.
- Version 1.1.0 adds regression coverage for header variations, BOM-marked UTF-16 (including byte-by-byte reads), explicit log selection, and diagnostic classification.
- The source is checked with `py_compile`, the version command, and the full automated test suite before packaging.
- A background monitor read an actual temporary log, detected an appended avatar change, preserved its previous avatar, and stopped cleanly.
- Tested byte-by-byte UTF-8 reads, CRLF, incomplete lines, oversized lines, new log files, truncation, and atomic file replacement.
- Tested Unicode names, player departure/rejoin, world changes, local-player identification, first loads, reloads, ambiguous delimiters, and CSV output.

The VRChat switch-entry format was checked against the maintained VRCX log parser. Tests use synthetic local log data, not an actual VRChat session. The user's actual log has not been supplied, so the exact cause of their empty feed is not yet confirmed.

The user confirmed that version 1.0 opened and read their log on their PC, but displayed no avatars. Version 1.18.5 has not been run inside Windows, against their VRChat installation, with a real account, or against their actual VRCX database/analysis/export output. The available build environment has no graphical display or Xvfb, so the updated native Tk sidebar, Advanced client bridge dialog and Feed/Game Log/Search/Favorites/Social/Wellness pages, secondary profile/account/whisper window, Avatars/World and Players/Map tabs, map canvas, calibration and camera capture dialogs, Shader Watch/player details/rangefinder/search/sign-in/lookup dialogs, row submenu, player import, size-lookup, VRCW world-backup and VRCA/cache/rescue/key/public-archive dialogs, and Windows launchers have not received an interactive runtime check. Browser tests use a test double; they validate the opened URL, not successful access to a real avatar page. Windows-specific file publication and shutdown of active transfers through the graphical interface remain untested. No actual avatar or world bundle was downloaded, loaded, repaired, decrypted, or reuploaded during validation. Synthetic container decryption is not a live-client compatibility test. The complete source and tests are included for inspection.

## Final Development 6 validation

The clean-extracted candidate passed **3,554 tests and 1,141 subtests**, with zero
failures, errors or skips. This includes **66 new cases**, 12 using native Tk
workflows. All **341 Python files** passed Python 3.10 grammar checks.

The full-suite guard blocked 48 datagram attempts from the optional Zeroconf
provider; no external socket traffic was allowed. The focused new-feature run
and synthetic native preview recorded zero blocked attempts. Two warnings remain:
the pre-existing TestListener collection warning and a deprecation in existing
OBS websocket handling with the installed websockets 17.1 test dependency.

All 454 Development 5 paths are retained in the 462-file archive. The 383-file
runtime/test/launcher/catalog/Unity manifest matches the clean-tested candidate.
Final metadata and these release-note results were added after that test run.
Native Windows and the live-provider limitations above remain unchanged.

## Final Development 7 validation

The clean-extracted package passed **3,776 tests and 1,141 subtests**,
with no failures, errors or skips. This includes **222 new test cases**,
37 using real Tk workflows. All **350 Python files** passed Python 3.10 grammar
checks. The **392-file** source manifest matches the clean-tested code.

The external-socket guard reported 0 blocked attempts in this final run;
no external socket traffic was allowed. The synthetic native preview recorded
zero blocked attempts and performed only controlled reads, with no live account,
remote writes, OSC sends or bridge listener. Two pre-existing test/dependency
warnings remain; details are in BUILD_VALIDATION.json.

The **473-file archive** retains all 462 Development 6 paths. Launchers and
requirements.txt are byte-identical. Final documentation and validation metadata
were added after the clean-code suite; runtime/test bytes were rechecked against
that tested source before packaging.

## Final Development 8 validation

The clean-extracted package passed **4,044 tests and 1,141 subtests**,
with no failures, errors or skips. This includes **268 new test cases**,
63 using real Tk workflows. All **368 Python files** passed Python 3.10 grammar
checks. The **414-file** source manifest matches the clean-tested code.

The external-socket guard reported 8 blocked attempts in the final run;
no external socket traffic was allowed. Two pre-existing test/dependency warnings
remain; details are in BUILD_VALIDATION.json. Validation used synthetic inputs and
accounts, temporary stores and Linux/Tk. No live VRChat write or third-party
recovery executable was run.

Both new C# files passed syntax parsing and Python contract checks. These checks
do not establish Unity compilation or runtime behavior. The 37 supplied native
Unity test cases remain unexecuted. Native Windows and installed Unity/VPM
verification remain pending.

The **497-file archive** retains all 473 Development 7 paths. Launchers and
requirements.txt are byte-identical. Final documentation and validation metadata
were added after the clean-code suite; runtime/test/Unity bytes were rechecked
against that tested source before packaging.
