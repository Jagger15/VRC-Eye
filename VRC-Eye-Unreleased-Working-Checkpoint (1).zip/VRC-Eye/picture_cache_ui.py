"""Local picture cache controls; disk work uses the existing bounded page job."""

from text_viewport import window_body
from companion_ui import line,button,choice
from vrcx_ui_jobs import LocalPage
from picture_cache import service_for,LIMITS


def show(shell):
    dialog=getattr(shell,'picture_cache_dialog',None)
    if dialog and not dialog.closed:dialog.window.lift();return dialog
    shell.picture_cache_dialog=CacheDialog(shell);return shell.picture_cache_dialog


class CacheDialog(LocalPage):
    def __init__(self,shell):
        app=shell.app;self.window=app.tk.Toplevel(app.root)
        self.window.title('Picture cache');self.window.geometry('760x460');self.window.minsize(600,400)
        pane=app.ttk.Frame(window_body(self.window),padding=18);pane.pack(fill='both',expand=True)
        super().__init__(shell,pane,'Picture cache',task_controls=False)
        self.service=service_for(app);self.setup_privacy()
        self.enabled=self.tk.BooleanVar(value=self.service.cache.policy['enabled'])
        self.limit=self.tk.StringVar(value=str(self.service.cache.policy['limit_mb']))
        self.ttk.Checkbutton(pane,text='Keep pictures across restarts for this device',variable=self.enabled).pack(anchor='w',pady=6)
        row=line(self);self.ttk.Label(row,text='Picture data limit (MiB)').pack(side='left',padx=6)
        choice(self,row,self.limit,tuple(map(str,LIMITS)),width=9);button(self,row,'Save settings',self.apply)
        self.ttk.Label(pane,text='Avatar, player and world previews are separated by signed-in account. Online pictures refresh after 24 hours; offline previews can be up to 30 days old. The oldest pictures are removed to keep within the selected limit and 3,000 entries. Database overhead is additional.',wraplength=690).pack(anchor='w',pady=8)
        self.stats_text=self.tk.StringVar(value='Choose Inspect usage to read the local cache.')
        self.ttk.Label(pane,textvariable=self.stats_text,wraplength=690).pack(anchor='w',pady=8)
        row=line(self);button(self,row,'Inspect usage',self.inspect)
        button(self,row,'Clear this account',lambda:self.clear(False));button(self,row,'Clear all pictures',lambda:self.clear(True))
        self.ttk.Label(pane,text='Clearing removes stored previews and prevents older pending downloads from saving them again. Pictures already displayed stay visible. Disabling persistence keeps existing files until you clear them.',wraplength=690).pack(anchor='w',pady=6)
        button(self,line(self),'Close',self.close)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(300,self.tick)

    def show_stats(self,value):
        self.stats_text.set(f"{value['count']:,} pictures · {value['bytes']/1024**2:.1f} MiB picture data · {value['disk_bytes']/1024**2:.1f} MiB database on disk")

    def inspect(self):
        self.ready();cache=self.service.cache
        self.start(lambda c,s,p:(cache.maintain(),cache.stats())[1],self.show_stats)

    def apply(self):
        self.ready();self.service.configure(dict(enabled=bool(self.enabled.get()),limit_mb=int(self.limit.get())))
        self.inspect()

    def clear(self,all_accounts):
        self.ready();account=None if all_accounts else self.connected().user_id
        cache=self.service.cache;token=self.token()
        def work(c,s,p):
            self.verify(token)
            if s.is_set():raise ValueError('Canceled cache clear.')
            cache.clear(account);return cache.stats()
        def done(value):
            self.service.clear_memory();self.service.sync();self.show_stats(value)
            self.status.set('Stored pictures cleared. New requests can cache pictures again when enabled.')
        self.start(work,done,mutation=True)

    def clear_preview(self):
        if hasattr(self,'stats_text'):self.stats_text.set('Cache details cleared.')

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(300,self.tick)

    def close(self):
        if self.closed:return True
        super().close()
        if getattr(self,'timer',None):self.app.root.after_cancel(self.timer)
        self.window.destroy();return True
