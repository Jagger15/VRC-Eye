@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0.recovery-env\Scripts\python.exe" (
    "%~dp0.recovery-env\Scripts\python.exe" -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 (
        "%~dp0.recovery-env\Scripts\python.exe" "%~dp0bridge_example.py" %*
        pause
        exit /b
    )
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 (
        py -3 "%~dp0bridge_example.py" %*
        pause
        exit /b
    )
)
where python >nul 2>nul
if not errorlevel 1 (
    python -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 (
        python "%~dp0bridge_example.py" %*
        pause
        exit /b
    )
)
echo The diagnostic adapter needs Python 3.10 or newer.
echo Enable the bridge in VRC Eye first; see BRIDGE_SETUP.md.
pause
