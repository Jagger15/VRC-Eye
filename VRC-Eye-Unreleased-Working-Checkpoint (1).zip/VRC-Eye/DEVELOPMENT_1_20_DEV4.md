# VRC Eye 1.20.0 — Development checkpoint 4

This checkpoint adds the first substantial local Photos workspace and reviewed
World Visits / Invite Me. It is **not the completed 1.20 roadmap** and does not
claim all 43 sections of the photo plan or all Social/Accounts work are complete.

Baseline: the actual Development 3 ZIP, SHA-256
`46a1ce0c835847a8251dd31479adca2aaa9da13afa4f64a1dcd93468faf8357f`.
The previous ZIP is unchanged. No code was reconstructed from claimed progress.

## Start and preserve your data

Close the running VRC Eye copy. Back up its local settings/databases and your
original photos. Extract the **entire Development 4 ZIP into a new folder**, open
`VRC-Eye` and run **Start.cmd**. Do not run two builds against the same databases.
Keep the previous application folder. This remains the source application with its
existing launcher, not a newly compiled or signed Windows executable.

All four launchers and requirements.txt remain unchanged. Existing login controls,
Enter/keypad Enter sign-in, Avatar Library, VCC/creator tools, Social/Accounts,
OSC, networking, safety, wellness and accessibility foundations remain present.

## Delivered in this checkpoint

**You → VRChat Photos.** Six internal tabs: Library, Sources, Albums & Sessions,
Review & Export, Photo Booth, Activity. Use the workspace dropdown to reach every
section in Casual view or smaller windows. Works without signing in or opening VRCX.
Opening the page does not scan folders, load originals, start a watcher or send
network requests. It reads only its local catalog/disposable thumbnails.

The library supports explicit file imports; selected approved-source scans; list
and card views; combined text/favorite/date/world/file-state filters; paging;
local titles/notes; hide/restore references; exact-byte duplicate groups; and
bounded image previews with zoom/pan. Original files are not moved or changed.
Rechecks and same-byte relinking distinguish missing, changed, unreadable and
replaced references. New bytes at an old path get a different photo identity.

Sources have explicit approval, folder identity checks and no link traversal.
Suggestions read the configured screenshot path, Windows Pictures known-folder
adapter, Linux XDG Pictures declaration or explicit Proton C: mapping. They do
not approve or scan the suggested folder. Windows adapter ABI fixtures passed;
actual Windows redirection behavior has not been exercised here.

Manual and saved-filter albums reuse photo references. Album covers and manual
session links/covers refer to the existing retained session history, not a second
session tracker. Private or forgotten history is not reconstructed. History is
still local OS-user history, not a claim of complete multi-account migration.

**Original-preserving export.** A data-only recipe provides crop, opaque black
rectangles, downscaling and a static White/Dark border. The actual flattened PNG
is reviewed before a separate exclusive save. Export removes source metadata and
hidden alpha, retains no original/layer/sidecar, and never overwrites a file.
Visible text/people/screens still require manual review; there is no privacy
clearance or automatic OCR/face recognition. Current recipes are not a saved,
versioned non-destructive-edit project system.

**Local recovery.** Import/export receipts and a durable pre-save destination
record make partial/cancelled/interrupted outcomes inspectable. No operation is
replayed automatically. A finished PNG with a failed catalog update is explicitly
reported as saved with incomplete records. Account changes cannot assign the
completed export to the new account. Local receipt-save retry never repeats a
file export or remote request.

**Community → Invite Me.** Explicit world reads and exact-instance inspection,
separately reviewed personal instance creation, and a one-use self-invite action
through Development 3's original authenticated transport, lock, request budget
and account-action receipts. Creation never automatically sends an invitation.
No client launch or game join is issued. Access/capacity/eligibility are not
bypassed. World search, local/game favorites and manually linked photos can
prefill this page without sending anything.

Private exact instance tokens remain in current input/snapshots/reviews; receipt
targets use a world ID plus a digest. A modal action review reveals the exact
selected destination so it can be verified. Uncertain outcomes are not retried.
The shared service covers these routes, not every legacy write in the application.

See **PHOTOS_1_20.md**, **WORLD_VISITS_1_20.md** and the implementation matrix for
steps, storage, limits, privacy and remaining scope.

## Validation boundary

All new account reads/writes were tested against controlled fixtures through the
real existing transport. No live VRChat/VRCX account, user credentials, real
invitations, installed Unity/VPM, C# compilation or native Windows run was used.
Screen-reader and XR interoperability remain unverified. No ARC binary/helper,
FACS source, new runtime dependency or silent updater was introduced.

The final clean-extracted results are recorded in BUILD_VALIDATION.json. Historical
BASELINE_DEV3_VALIDATION.json and older reports are not new test results.

## Remaining roadmap

The photo foundation is delivered, not a fully automatic library: persistent
watching, physical move/rename/trash/delete, multilayer imports, saved edit
projects, contact sheets/strips, automatic session correlation, visible-content
scanning, direct image sharing, a full backup/recovery product and per-source
VRCX automation coordination remain pending. Photo Booth currently supplies
static-border exports and navigation to existing OSC/peer planners, not a new
camera-trigger or full photo-booth session engine.

Retained multiple authenticated logins and full account isolation, live social
notifications/outbound friend-invite composition, separate SDK/VCC release
archive downloads, advanced 3D/Unity repair/recovery and remaining accessibility,
XR and VCC work are still pending or conditional. Existing startup behavior is
preserved; no silent runtime updater is implied by this checkpoint.

## Final validation result

The clean-extracted source passed **3,295 tests and 1,141 subtests**
with zero failures, errors or skips in 118.89 seconds. One pre-existing
TestListener collection warning remains. The external-socket guard recorded
zero blocked attempts; loopback fixtures remained enabled. This is
**193 additional tests**, including **34 new native Tk workflow cases**
and nine Windows known-folder ABI fixtures (not native Windows execution).

All **328 Python files** passed Python 3.10 grammar checks. The suite ran on
Python 3.13.5 under Linux/Xvfb. The archive contains **442 files**,
retains all **426 Development 3 paths**, adds 16 paths and modifies 17 baseline
files. All four launchers and requirements.txt are byte-identical to Development 3.
Final executable source, tests, runtime catalogs and Unity source match the
clean-tested copy. Only final validation metadata and these results were
added afterward.

A separate native preview run imported six synthetic photos and saved a reviewed
flattened PNG without changing original bytes. It recorded no Tk callback errors,
external socket attempts, OSC sends or active bridge listener. Its one HTTP read
was a fixture, not a live service call, and it made no HTTP writes. The new
workspaces were exercised at 100% and 200% shared UI scale.
