"""Reviewed, restartable avatar transfers. HTTP semantics: RFC 9110 §13–15.

Only a fresh URL/opener in memory may resume a job. Credentials and signed URLs
are never journaled. A partial is usable only with a strong ETag, exact range,
unchanged parent/inode, and a rehashed committed prefix. Startup never dispatches.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
from email.utils import parsedate_to_datetime
from hashlib import sha256
from http.client import HTTPException
import json
import os
from pathlib import Path
import re
import ssl
import stat
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit,parse_qsl,urlencode
from urllib.request import Request
import uuid

from avatar_library import scope_id, validate_avatar_id, stamp, _TABLE
from avatar_library_files import check_cancel, InspectionCancelled
from vrca_files import (validate_asset_url, _new_destination, _expected_hash,
    _publication_parent, _file_identity, _file_content_state, _save_stream,
    MAX_DOWNLOAD_BYTES, BLOCK_SIZE, SavedVRCA, VRCAError, VRCACancelled)

ACTIVE=('Opening','Downloading','Publishing')
TRANSIENT_CODES=(408,425,429,500,502,503,504)
MAX_PARTIALS=16


def source_key(url,validate=validate_asset_url):
    parsed=urlsplit(validate(url))
    signing={'signature','expires','key-pair-id','x-amz-algorithm','x-amz-credential','x-amz-date',
             'x-amz-expires','x-amz-signedheaders','x-amz-signature','x-amz-security-token'}
    query=urlencode(sorted((k,v) for k,v in parse_qsl(parsed.query,keep_blank_values=True,max_num_fields=100) if k.casefold() not in signing))
    return sha256((parsed.scheme+'://'+parsed.netloc+parsed.path+'?'+query).encode()).hexdigest()


def strong_etag(value):
    return value if isinstance(value,str) and re.fullmatch(r'"[\x21\x23-\x7e]{0,500}"',value) else ''


def length(value):
    if value is None:return None
    if not isinstance(value,str) or not re.fullmatch('[0-9]{1,12}',value) or not 0<int(value)<=MAX_DOWNLOAD_BYTES:
        raise ValueError('Invalid or oversized transfer length (maximum 2 GiB).')
    return int(value)


class Transient(ValueError):
    def __init__(self,message,delay=2):super().__init__(message);self.delay=delay


class Budget:
    """One shared asset-host cooldown, independent of metadata's existing budget."""
    def __init__(self):self.lock=threading.Lock();self.until={}
    def defer(self,host,now,seconds):
        with self.lock:self.until[host]=max(self.until.get(host,0),now+seconds)
    def remaining(self,host,now):
        with self.lock:return max(0,self.until.get(host,0)-now)


@dataclass(frozen=True)
class Plan:
    scope: str
    payload: str = field(repr=False)
    url: str = field(repr=False)
    expires: float
    previous: str = field(repr=False,default='')
    retry: bool = False
    @property
    def data(self):return json.loads(self.payload)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


class Transfers:
    table=_TABLE
    suffixes=('.vrca',)
    account_scope=staticmethod(scope_id)
    key=staticmethod(source_key)
    validate_url=staticmethod(validate_asset_url)

    def subject(self,account,avatar):
        avatar=validate_avatar_id(avatar)
        if account=='local' or avatar.startswith('local:'):raise ValueError('Sign in and select an online catalog avatar.')
        if not self.library.get(account,avatar):raise ValueError('The selected avatar is no longer catalogued.')
        return avatar

    def new_destination(self,value):
        return _new_destination(Path(value).expanduser().absolute(),suffixes=self.suffixes)

    def response_key(self,url):
        return self.key(url)

    def __init__(self,library,*,clock=time.monotonic,wall=time.time,wait=None,budget=None):
        self.library=library;self.clock=clock;self.wall=wall;self.wait=wait or (lambda seconds:threading.Event().wait(seconds))
        self.lock=threading.Lock();self.plans={}
        if not hasattr(library,'_transfer_budget'):library._transfer_budget=Budget()
        self.budget=budget or library._transfer_budget

    def rows(self,account):
        rows=self.library.records(account,'transfer',limit=100)
        for row in rows:
            if row['state'] in ACTIVE and row.get('boot_id')!=self.library.boot_id:row['state']='Interrupted'
        return rows

    def prepare(self,account,avatar,url,destination=None,*,expected_hash='',build_id='',resume='',retry=False):
        account=self.account_scope(account);avatar=self.subject(account,avatar)
        self.validate_url(url)
        if type(retry) is not bool:raise ValueError('Choose whether transient retries are allowed.')
        previous=''
        if resume:
            data=self.library.record(account,'transfer',resume)
            if not data or data['avatar_id']!=avatar:raise ValueError('Select a transfer in this avatar workspace.')
            if data['state'] in ('Complete','Discarded','Discarding','Blocked'):raise ValueError('This transfer cannot resume; inspect its receipt or start a new download.')
            if data['state'] in ACTIVE and data.get('boot_id')==self.library.boot_id:raise ValueError('Wait for this transfer to stop.')
            if data['source_key']!=self.key(url):raise ValueError('The current asset URL identifies a different file. Start a new transfer.')
            if data['offset'] and (not strong_etag(data.get('etag')) or not data.get('total')):
                raise ValueError('This partial has no strong server validator and total length. Discard it and start a new download.')
            previous=canonical(data)
            destination=Path(data['destination'])
            _publication_parent(destination.parent,tuple(data['parent_identity']))
            if destination.exists() or destination.is_symlink():raise ValueError('A destination already exists. Use Check saved outcome before resuming.')
        else:
            destination=self.new_destination(destination)
            parent=_publication_parent(destination.parent)
            checksum=_expected_hash(expected_hash)
            if build_id:
                build=self.library.record(account,'build',build_id)
                if not build or build['avatar_id']!=avatar:raise ValueError('Choose a build belonging to this avatar.')
            ref=str(uuid.uuid4())
            data=dict(schema=1,id=ref,account=account,avatar_id=avatar,build_id=build_id,
                destination=str(destination),parent_identity=list(parent),partial=str(destination.parent/('.eye-transfer-'+ref+'.part')),
                source_key=self.key(url),response_key='',expected_sha256=checksum,offset=0,total=None,etag='',partial_identity=None,partial_state=None,
                prefix_sha256=sha256(b'').hexdigest(),state='Prepared',created_at=stamp(self.library.clock),updated_at='',
                boot_id=self.library.boot_id,attempts=0,next_retry_at=0,partial_retained=True,message='',result=None)
        plan=Plan(account,canonical(data),url,self.clock()+300,previous,retry)
        with self.lock:
            self.plans={k:p for k,p in self.plans.items() if p.expires>self.clock()}
            if len(self.plans)>=8:raise ValueError('Close an existing transfer review first.')
            self.plans[id(plan)]=plan
        return plan

    def clear(self):
        with self.lock:self.plans.clear()

    def discard_plan(self,plan):
        with self.lock:self.plans.pop(id(plan),None)

    def _save(self,data):
        data['updated_at']=stamp(self.library.clock)
        with self.library.store._transaction() as db:
            self.library._put(db,data['account'],'transfer',data['id'],data['avatar_id'],data)
        self.library.revision+=1

    def _check_path(self,data,stream=None):
        parent=Path(data['destination']).parent
        _publication_parent(parent,tuple(data['parent_identity']))
        path=Path(data['partial'])
        if path.parent!=parent or path.name!='.eye-transfer-'+data['id']+'.part':raise ValueError('Invalid partial-file location.')
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:raise ValueError('The partial file was replaced or linked.')
        if data.get('partial_identity')!=list(_file_identity(info)):raise ValueError('The partial file identity changed; it was preserved for inspection.')
        if stream is not None and _file_content_state(info)!=_file_content_state(os.fstat(stream.fileno())):
            raise ValueError('The partial file changed during this operation.')
        return path,info

    @contextmanager
    def _owned(self,data,*,new=False):
        path=Path(data['partial']);parent=path.parent
        _publication_parent(parent,tuple(data['parent_identity']))
        if not new:self._check_path(data)
        flags=os.O_RDWR|getattr(os,'O_BINARY',0)|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)
        if new:flags|=os.O_CREAT|os.O_EXCL
        descriptor=os.open(path,flags,0o600)
        with os.fdopen(descriptor,'r+b') as stream:
            if new:data['partial_identity']=list(_file_identity(os.fstat(descriptor)))
            self._check_path(data,stream)
            try:
                if os.name=='nt':
                    import msvcrt
                    stream.seek(0);msvcrt.locking(descriptor,msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError:raise ValueError('Another process owns this partial download. Wait for it to stop.') from None
            # Closing the descriptor releases its OS lock, including on errors.
            yield stream

    def _verify_prefix(self,data,stream,check):
        self._check_path(data,stream)
        if os.fstat(stream.fileno()).st_size!=data['offset']:raise ValueError('Partial length differs from its committed checkpoint. Start a new transfer.')
        stream.seek(0);digest=sha256();prefix=b''
        while True:
            check();block=stream.read(BLOCK_SIZE)
            if not block:break
            digest.update(block)
            if not prefix:prefix=block[:512]
        if digest.hexdigest()!=data['prefix_sha256']:raise ValueError('Partial bytes changed. They were not resumed or deleted.')
        self._check_path(data,stream)
        return digest,prefix

    def _delay(self,seconds,check,lease):
        end=self.clock()+seconds
        if end>=lease:raise ValueError('The provider delay exceeds this ten-minute review. Review again later.')
        while self.clock()<end:
            check();self.wait(min(.2,end-self.clock()))
        check()

    def _response(self,opener,request):
        try:return opener.open(request,timeout=10)
        except HTTPError as error:
            limited=error.code==429 or error.code==403 and error.headers and error.headers.get('X-RateLimit-Remaining')=='0'
            if error.code in TRANSIENT_CODES or limited:
                delay=2;value=error.headers.get('Retry-After','') if error.headers else ''
                try:
                    delay=int(value) if value.isdigit() else int(parsedate_to_datetime(value).timestamp()-self.wall()) if value else 60 if limited else 2
                except (ValueError,TypeError,OverflowError):delay=60
                error.close()
                raise Transient(f'Provider temporarily unavailable (HTTP {error.code}).',max(1,min(delay,86400))) from None
            code=error.code;error.close()
            raise ValueError(f'Download stopped (HTTP {code}). Refresh access or asset metadata before reviewing again.') from None
        except URLError as error:
            if isinstance(error.reason,(ssl.SSLError,ssl.CertificateError)):
                raise ValueError('TLS validation failed. The transfer will not retry automatically.') from None
            raise Transient('The asset connection could not be established.') from None
        except (TimeoutError,ConnectionError,HTTPException):raise Transient('The asset connection was interrupted.') from None

    def run(self,plan,opener,*,guard,stop=None,progress=None):
        with self.lock:
            if not isinstance(plan,Plan) or self.plans.pop(id(plan),None) is not plan:raise ValueError('This transfer review was used or cleared. Review again.')
        if self.clock()>=plan.expires:raise ValueError('The transfer review expired.')
        data=plan.data;lease=self.clock()+600;new=not plan.previous
        def check():
            check_cancel(stop);guard()
        check()
        with self.library.store._transaction() as db:
            old=self.library._load(db,plan.scope,'transfer',data['id'])
            if (canonical(old) if old else '')!=plan.previous:raise ValueError('This transfer changed after review.')
            if new:
                retained=sum(bool(json.loads(r[0]).get('partial_retained',True)) for r in db.execute(f"SELECT data FROM {self.table} WHERE kind='transfer'"))
                if retained>=MAX_PARTIALS:raise ValueError('This catalog has 16 retained partials. Review and discard unneeded partials before starting another.')
                self.library._put(db,plan.scope,'transfer',data['id'],data['avatar_id'],data)
        reserved=canonical(data)
        host=urlsplit(plan.url).hostname;published=False;owned=False
        try:
            with self._owned(data,new=new) as stream:
                with self.library.store._transaction() as db:
                    current=self.library._load(db,plan.scope,'transfer',data['id'])
                    if canonical(current)!=reserved:raise ValueError('The transfer changed before its file lock was acquired.')
                    data.update(state='Opening',boot_id=self.library.boot_id,message='')
                    data['partial_state']=json.loads(canonical(_file_content_state(os.fstat(stream.fileno()))))
                    self.library._put(db,plan.scope,'transfer',data['id'],data['avatar_id'],data)
                owned=True
                self._save(data)
                digest,prefix=self._verify_prefix(data,stream,check)
                # A complete checkpoint still needs an HTTP validator on resume.
                for attempt in range(4 if plan.retry else 1):
                    check()
                    if self.clock()>=lease:raise ValueError('Review expired before the next request. Review the retained partial again.')
                    self._delay(self.budget.remaining(host,self.clock()),check,lease)
                    self._check_path(data,stream)
                    if Path(data['destination']).exists() or Path(data['destination']).is_symlink():raise ValueError('Destination was created by another operation; it was not overwritten.')
                    offset=data['offset'];headers={'User-Agent':'VRC-Eye/1.21.0 avatar-transfers','Accept-Encoding':'identity'}
                    # Revalidate the last byte of a fully committed checkpoint.
                    start=offset-1 if offset and offset==data['total'] else offset
                    if offset:
                        if not data['etag'] or not data['total']:raise ValueError('Interrupted transfer has no strong validator. Start a new download.')
                        headers.update(Range=f'bytes={start}-',**{'If-Range':data['etag']})
                    data['attempts']+=1;data['state']='Downloading';data['next_retry_at']=0;self._save(data)
                    try:
                        with self._response(opener,Request(plan.url,headers=headers,method='GET')) as response:
                            response_key=self.response_key(response.geturl())
                            media=response.headers.get('Content-Type','').split(';')[0].strip().lower()
                            if media.startswith(('text/','image/','audio/','video/','multipart/')) or 'json' in media or 'xml' in media:
                                raise ValueError('The server returned media or an error page instead of a bundle.')
                            if response.headers.get('Content-Encoding','identity').lower() not in ('','identity'):raise ValueError('Encoded responses cannot be resumed safely.')
                            count=length(response.headers.get('Content-Length'))
                            tag=strong_etag(response.headers.get('ETag',''))
                            if offset:
                                expected=f"bytes {start}-{data['total']-1}/{data['total']}"
                                if response.status!=206 or response.headers.get('Content-Range')!=expected or tag!=data['etag'] or count!=data['total']-start or response_key!=data['response_key']:
                                    raise ValueError('The server did not confirm this exact range and validator. Start a new download; old bytes were preserved.')
                            else:
                                if response.status!=200 or response.headers.get('Content-Range'):raise ValueError('A complete initial response was required.')
                                data.update(total=count,etag=tag,response_key=response_key);self._save(data)
                            deadline=self.clock()+3600;read=getattr(response,'read1',response.read);received=0
                            while True:
                                check()
                                if self.clock()>=deadline:raise ValueError('This transfer exceeded its one-hour read budget.')
                                try:block=read(BLOCK_SIZE)
                                except (URLError,ConnectionError,TimeoutError,HTTPException):raise Transient('The transfer stream was interrupted.') from None
                                check()
                                if not block:break
                                received+=len(block)
                                if count is not None and received>count:raise ValueError('The response exceeded its declared length.')
                                if start<offset:
                                    stream.seek(offset-1)
                                    if block[:1]!=stream.read(1):raise ValueError('The last committed byte no longer matches the server.')
                                    block=block[1:];start=offset
                                if not block:continue
                                prefix=(prefix+block)[:512]
                                if prefix.lstrip().lower().startswith((b'<html',b'<!doctype',b'<?xml',b'{',b'[')):
                                    raise ValueError('The server returned a text/error body instead of a bundle.')
                                if data['offset']+len(block)>MAX_DOWNLOAD_BYTES:raise ValueError('The transfer exceeds 2 GiB.')
                                self._check_path(data,stream);stream.seek(data['offset']);stream.write(block);stream.flush();os.fsync(stream.fileno())
                                digest.update(block);data['offset']+=len(block);data['prefix_sha256']=digest.hexdigest()
                                data['partial_state']=json.loads(canonical(_file_content_state(os.fstat(stream.fileno()))));self._save(data)
                                if progress:progress(data['offset'],data['total'])
                            if count is not None and received!=count:raise Transient('The server ended the transfer before the declared length.')
                            if not data['offset']:raise ValueError('The server returned an empty file.')
                            if data['expected_sha256'] and digest.hexdigest()!=data['expected_sha256']:raise ValueError('The completed bytes do not match the reviewed SHA-256.')
                            break
                    except Transient as error:
                        delay=max(error.delay,2**(attempt+1));self.budget.defer(host,self.clock(),delay)
                        data['next_retry_at']=self.wall()+delay;self._save(data)
                        if not plan.retry or attempt==3:raise ValueError(str(error)+' Partial retained; review to continue.') from None
                        if data['offset'] and (not data['etag'] or not data['total']):raise ValueError('Interrupted bytes cannot resume without a strong validator and total size.') from None
                        if progress:progress(f'Waiting for a transient retry ({attempt+1}/3). Cancel is available.')
                check();self._verify_prefix(data,stream,check)
                data['state']='Publishing';self._save(data);stream.seek(0)
                def commit():
                    check();self._check_path(data,stream)
                    _publication_parent(Path(data['destination']).parent,tuple(data['parent_identity']))
                result=_save_stream(stream,Path(data['destination']),data['offset'],data['prefix_sha256'],stop,progress,network=False,before_commit=commit,suffixes=self.suffixes)
                published=True
                data.update(state='Complete',message='Saved bytes verified. Catalog association is a separate review.',result=dict(
                    size=result.size,sha256=result.sha256,expected_hash_matched=bool(data['expected_sha256']),length_checked=data['total'] is not None,bundle_header=result.bundle_header))
                self._save(data)
            if self._cleanup(data):data['partial_retained']=False;self._save(data)
            return SavedVRCA(result.path,result.size,result.sha256,bool(data['expected_sha256']),data['total'] is not None,result.bundle_header)
        except (InspectionCancelled,VRCACancelled):
            if owned and not published:data.update(state='Paused',message='Cancelled. The committed partial remains for a fresh review.');self._save(data)
            raise InspectionCancelled('Transfer paused; inspect Transfers to resume or discard its partial.') from None
        except (ValueError,VRCAError,OSError) as error:
            if owned and not published:
                # No exception text from a network provider (possibly containing
                # a signed URL) is persisted. The UI gets our sanitized errors.
                data.update(state='Paused',message='Transfer stopped. Check partial and destination before continuing.');self._save(data)
            if isinstance(error,OSError):raise ValueError('Local transfer I/O failed. Check free space and file permissions; inspect the retained job.') from None
            raise ValueError(str(error)) from None

    def _cleanup(self,data):
        """Delete only the exact owned checkpoint, never a replacement occupant."""
        try:
            path,info=self._check_path(data)
            if info.st_size!=data['offset'] or canonical(_file_content_state(info))!=canonical(data.get('partial_state')):return False
            # Pin the directory for Unix unlink; Windows lacks dir_fd.
            if os.unlink in os.supports_dir_fd:
                fd=os.open(path.parent,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0))
                try:
                    if list(_file_identity(os.fstat(fd)))!=data['parent_identity']:return False
                    current=os.stat(path.name,dir_fd=fd,follow_symlinks=False)
                    if _file_content_state(current)!=_file_content_state(info):return False
                    os.unlink(path.name,dir_fd=fd)
                finally:os.close(fd)
            else:
                self._check_path(data);path.unlink()
            return True
        except (ValueError,VRCAError,OSError):return False

    def inspect_outcome(self,account,ref,*,guard,stop=None,progress=None):
        """Reconcile the publication crash window without a network request."""
        from avatar_library_files import inspect_file
        data=self.library.record(account,'transfer',ref)
        if not data:raise ValueError('Select an existing transfer.')
        guard();check_cancel(stop)
        _publication_parent(Path(data['destination']).parent,tuple(data['parent_identity']))
        if data['state']=='Discarded':raise ValueError('This transfer was discarded.')
        evidence=inspect_file(data['destination'],stop=stop,progress=progress)
        if data['state'] not in ('Publishing','Complete') or evidence['size']!=data['offset'] or evidence['sha256']!=data['prefix_sha256']:
            raise ValueError('The destination cannot be reconciled with a completed publication checkpoint. It was left unchanged.')
        guard();check_cancel(stop)
        with self.library.store._transaction() as db:
            current=self.library._load(db,self.account_scope(account),'transfer',ref)
            if canonical(current)!=canonical(data):raise ValueError('Transfer changed during inspection. Inspect again.')
            data.update(state='Complete',message='Destination rehashed and matched the recorded publication checkpoint.',result=dict(size=evidence['size'],sha256=evidence['sha256'],expected_hash_matched=bool(data['expected_sha256']),length_checked=data['total'] is not None,bundle_header=evidence['header']=='Unity bundle header'))
            self.library._put(db,self.account_scope(account),'transfer',ref,data['avatar_id'],data)
        self.library.revision+=1
        return evidence

    def discard(self,account,ref,*,guard,stop=None):
        data=self.library.record(account,'transfer',ref)
        if not data or not data.get('partial_retained',True):raise ValueError('Select a transfer with a retained partial.')
        completed=data['state']=='Complete'
        guard();check_cancel(stop)
        if data['state'] in ACTIVE and data.get('boot_id')==self.library.boot_id:raise ValueError('Wait for the transfer to stop first.')
        with self._owned(data) as stream:
            self._verify_prefix(data,stream,lambda:(guard(),check_cancel(stop)))
            with self.library.store._transaction() as db:
                current=self.library._load(db,self.account_scope(account),'transfer',ref)
                if canonical(current)!=canonical(data):raise ValueError('The transfer changed before discard. Review again.')
                data.update(state='Discarding',boot_id=self.library.boot_id)
                self.library._put(db,self.account_scope(account),'transfer',ref,data['avatar_id'],data)
        guard();check_cancel(stop)
        if not self._cleanup(data):raise ValueError('The partial changed or is unavailable. No file was deleted.')
        data.update(state='Complete' if completed else 'Discarded',partial_retained=False,message='Owned partial removed after verification. Destination was not changed.');self._save(data)


def summary(plan):
    data=plan.data
    return (f"Avatar: {data['avatar_id']}\nAccount: {plan.scope}\nDestination: {data['destination']}\n"
        f"Committed bytes: {data['offset']:,}\nExpected SHA-256: {data['expected_sha256'] or 'Not supplied'}\n\n"
        'Save an authorized copy, up to 2 GiB; at most 16 retained partials per catalog. Existing files are never replaced. '
        'Partial bytes remain on disk after cancellation or interruption and can be removed from Transfers. '
        'Resume requires a strong server validator, exact range and rechecked local bytes. '
        'No job resumes at startup.\n\nTransient retries: '+('up to 3 within this ten-minute review.' if plan.retry else 'disabled.'))
