"""Advanced / Crash & Diagnostics: local incident review and recovery."""
from datetime import datetime
import json
from pathlib import Path
import time
import webbrowser

from companion_ui import Page,Table,button,choice,line
from crash_model import settings,bundle,replay_point,WORLD
from crash_service import CrashService
from resource_core import METRICS,format_value


def clock_text(wall):
    return datetime.fromtimestamp(wall).strftime('%Y-%m-%d %H:%M:%S') if wall else 'Unknown'


class CrashPage(Page):
    def __init__(self,shell,parent):
        self.shell=shell;self.app=shell.app;self.parent=parent;self.tk=self.app.tk;self.ttk=self.app.ttk
        self.closed=False;self.job=None;self.revision=0;self.account=self.context();self.incident=None;self.rows=[];self.last_draw=0
        self.status=self.tk.StringVar(value='Black Box keeps a local rolling record, even while this page is closed.')
        try:self.settings=settings(shell.store.option('crash.settings',None))
        except ValueError:self.settings=settings({'enabled':False});self.status.set('Invalid saved diagnostics settings; recording disabled.')
        self.service=CrashService(shell.store.path,self.settings);self.started=False;self.was_demo=bool(self.app.demo)
        self.ttk.Label(parent,text='Crash & Diagnostics',style='Title.TLabel').pack(anchor='w')
        self.ttk.Label(parent,textvariable=self.status,wraplength=930).pack(anchor='w',pady=4)
        self.summary=self.tk.StringVar(value='Demo — recording disabled' if self.app.demo else 'Starting Black Box…')
        self.ttk.Label(parent,textvariable=self.summary,wraplength=930,style='Accent.TLabel').pack(anchor='w',pady=5)
        row=line(self);self.view=self.tk.StringVar(value=self.settings['view'])
        choice(self,row,self.view,('Casual','Advanced','Developer'),self.apply_view,12)
        button(self,row,'Preserve now',self.preserve);button(self,row,'Refresh incidents',self.refresh)
        self.tabs=self.ttk.Notebook(parent);self.tabs.pack(fill='both',expand=True);self.frames={}
        for name in ('Overview','Incidents','Replay','Error Center','Recorder & privacy','Developer'):
            frame=self.ttk.Frame(self.tabs);self.tabs.add(frame,text=name);self.frames[name]=frame
        self.build_overview();self.build_incidents();self.build_replay();self.build_settings()
        self.errors=Table(self,self.frames['Error Center'],(('time','Time',175),('kind','Observed event',220),('source','Source',100),('count','Count',80)),height=12)
        self.ttk.Label(self.frames['Error Center'],text='Normalized events only. Raw exception text, player names and personal paths are not stored. Historical events appear in the selected incident timeline.',wraplength=900).pack(anchor='w',pady=5)
        self.developer=self.tk.StringVar(value='Recorder schema 1. Waiting for availability…')
        from resource_ui import ResourcePage
        developer_pane=ResourcePage.scrolling_pane(self,self.frames['Developer'])
        self.ttk.Label(developer_pane,textvariable=self.developer,wraplength=900).pack(anchor='w',pady=8)
        button(self,line(self,developer_pane),'Inspect selected timeline record',self.inspect_record)
        self.record_detail=self.tk.StringVar(value='Select an event in Replay, then inspect its stored sequence, timestamps, provenance and metric age here. Stored records already exclude personal identifiers and raw log text.')
        self.ttk.Label(developer_pane,textvariable=self.record_detail,wraplength=900,justify='left').pack(anchor='w',pady=5)
        self.apply_visibility()
    def build_overview(self):
        pane=self.frames['Overview'];self.overview=self.tk.StringVar(value='No incident selected. Open Incidents to review a recording.')
        self.ttk.Label(pane,textvariable=self.overview,wraplength=900,justify='left').pack(anchor='w',pady=8)
        row=line(self,pane);button(self,row,'Review recovery launch…',self.launch);button(self,row,'Open previous world…',self.rejoin)
        self.ttk.Label(pane,text='Recovery is always manual. Launch VRChat uses normal Steam startup; saved launch options can change the starting world. Previous world opens its website so you can choose a fresh instance. No private instance codes are retained.',wraplength=900,style='Muted.TLabel').pack(anchor='w',pady=8)
    def build_incidents(self):
        pane=self.frames['Incidents']
        self.incidents=Table(self,pane,(('time','Saved',175),('title','Incident',410),('confidence','Confidence',110)),height=9,select=self.select_incident)
        row=line(self,pane);button(self,row,'Review export…',self.export);button(self,row,'Delete selected…',self.delete)
        self.export_metrics=self.tk.BooleanVar(value=True)
        self.ttk.Checkbutton(pane,text='Include resource measurements in reviewed exports',variable=self.export_metrics).pack(anchor='w')
        self.ttk.Label(pane,text='Unfinished recordings are recovered on startup. Windows event evidence may arrive later. A power-loss event alone does not explain why the computer stopped.',wraplength=900).pack(anchor='w',pady=8)
    def build_replay(self):
        pane=self.frames['Replay'];row=line(self,pane)
        self.metric=self.tk.StringVar(value='vrchat.rss');choice(self,row,self.metric,tuple(METRICS),self.draw_graph,28)
        self.position=self.tk.DoubleVar(value=0)
        self.slider=self.ttk.Scale(pane,from_=0,to=1,variable=self.position,command=lambda *_:self.scrub());self.slider.pack(fill='x',pady=6)
        self.replay=self.tk.StringVar(value='Select an incident. Missing measurements remain unknown.')
        self.ttk.Label(pane,textvariable=self.replay,wraplength=900).pack(anchor='w')
        self.canvas=self.tk.Canvas(pane,height=155,background='#141b26',highlightthickness=0);self.canvas.pack(fill='x',pady=5)
        from color_vision import canvas_ink
        canvas_ink(self.canvas)
        self.canvas.bind('<Configure>',lambda _:self.draw_graph())
        self.timeline=Table(self,pane,(('time','Recorded time',175),('kind','Event',220),('source','Source / confidence',220)),height=5,select=self.select_event)
    def build_settings(self):
        from resource_ui import ResourcePage
        pane=ResourcePage.scrolling_pane(self,self.frames['Recorder & privacy'])
        self.enabled=self.tk.BooleanVar(value=self.settings['enabled']);self.remember=self.tk.BooleanVar(value=self.settings['remember_world']);self.windows=self.tk.BooleanVar(value=self.settings['windows_evidence'])
        for label,var in (('Enable disk-backed Black Box',self.enabled),('Remember public world ID for manual recovery (local only)',self.remember),('Correlate Windows events after an unfinished recording',self.windows)):
            self.ttk.Checkbutton(pane,text=label,variable=var).pack(anchor='w',pady=4)
        self.window=self.tk.StringVar(value=str(self.settings['window_minutes']));self.days=self.tk.StringVar(value=str(self.settings['retain_days']));self.maximum=self.tk.StringVar(value=str(self.settings['max_incidents']))
        for label,var,values in (('Rolling history (minutes)',self.window,('5','10','15')),('Incident retention (days; 0 = no age deletion)',self.days,('0','7','30','90')),('Maximum incidents (0 = no count deletion)',self.maximum,('0','10','25','50'))):
            row=line(self,pane);self.ttk.Label(row,text=label).pack(side='left');choice(self,row,var,values,width=6)
        button(self,line(self,pane),'Apply recorder settings',self.apply_settings)
        self.ttk.Label(pane,text='Default: 10-minute ring, 30 days, 10 incidents. Capacity: 10,000 active records / 16 MiB payload; preserved evidence has a 64 MiB payload budget. SQLite adds storage overhead. Retention changes can delete old incidents immediately. Turning off world recovery removes stored recovery targets.\n\nSmall committed writes preserve completed records; storage or power failure can still lose the last uncommitted interval. Normal samples: 5 seconds; pressure: 1 second. Sensors keep their own cadence and expiry. Credentials, player/account/avatar IDs, raw logs, private instances and personal paths are excluded before writing. Incident history is separate from player history.',wraplength=900,justify='left').pack(anchor='w',pady=10)
    def active(self):
        if self.app.demo:raise ValueError('Diagnostics recording, exports and recovery are disabled in Demo.')
        if not self.started:raise ValueError('Recorder is starting. Try again shortly.')
    def request(self,op,args,done):
        self.active()
        if self.job:raise ValueError('A diagnostics task is pending. Wait for it to finish.')
        future=self.service.submit(op,*args)
        self.start(lambda client,stop,progress:future.result(timeout=15),done,api=False)
    def refresh(self):self.request('list',(),self.show_list)
    def show_list(self,rows):
        self.rows=rows;self.incidents.set(rows,lambda r:(clock_text(r['created']),r['title'],r['confidence']))
        if not rows:self.status.set('No preserved incidents. The active ring remains separate.')
    def preserve(self):self.request('preserve',(),lambda ref:self.status.set('Snapshot preserved. Refresh incidents to open it.'))
    def select_incident(self):
        selected=self.incidents.selected()
        if selected:self.request('load',(selected['id'],),self.show_incident)
    def show_incident(self,value):
        self.incident=value;s=value['summary'];similar=sum(r.get('signature')==s['signature'] for r in self.rows)
        text=s['title']+'\nConfidence: '+s['confidence']+'\n'+clock_text(s['start'])+' — '+clock_text(s['end'])+'\n\n'+'\n'.join(s['observations'])
        for c in s['comparison']:text+='\n'+METRICS[c['metric']][0]+': '+format_value(c['metric'],c['before'])+' → '+format_value(c['metric'],c['after'])
        if similar>1:text+=f'\n{similar} retained incidents share these broad observations; this is not proof of a common cause.'
        self.overview.set(text+'\n\n'+s['caveat'])
        records=sorted(value['records'],key=lambda r:(r['at'],r['seq']));self.timeline.set(records,lambda r:(clock_text(r['wall']),r['kind'],r['source']+' / '+r['confidence']))
        live=[r for r in records if r['kind']!='os.evidence'];self.origin=live[0]['at'] if live else 0;self.duration=max(0,live[-1]['at']-self.origin) if live else 0
        self.slider.configure(to=max(1,self.duration));self.position.set(self.duration);self.scrub();self.draw_graph()
        self.tabs.select(self.frames['Overview'])
    def select_event(self):
        event=self.timeline.selected()
        if event and event['kind']!='os.evidence':self.position.set(max(0,event['at']-self.origin));self.scrub()
        elif event:self.status.set('Windows wall time is evidence from the OS; its monotonic timeline position is estimated.')
    def scrub(self):
        if not self.incident:return
        point=replay_point(sorted(self.incident['records'],key=lambda r:(r['at'],r['seq'])),self.origin+float(self.position.get()))
        key=self.metric.get();value=point['metrics'].get(key)
        self.replay.set(f"T+{float(self.position.get()):.1f}s · {METRICS[key][0]}: {format_value(key,value)} · {point['state']}"+(' · Evidence gap' if point['gap'] else ' · Last measured value; no interpolation'))
    def draw_graph(self):
        from color_vision import canvas_ink
        canvas = canvas_ink(self.canvas)
        canvas.delete('all')
        from screen_reader_alternatives import chart
        chart(self.canvas,'Incident replay',())
        if not self.incident:return
        self.scrub();key=self.metric.get();points=[]
        for r in sorted(self.incident['records'],key=lambda r:r['at']):
            if r['kind']=='gap':points.append((r['at'],None));continue
            if r['kind']!='sample':continue
            m=r['payload'].get('metrics',{}).get(key);v=m.get('value') if m and m['age']<=m['ttl'] else None;points.append((r['at'],v))
        chart(self.canvas,METRICS[key][0],[(f'T+{at-self.origin:.1f} seconds',value,value) for at,value in points],lambda v:format_value(key,v),range_label='Incident replay',events=self.replay.get())
        valid=[v for _,v in points if v is not None]
        if not valid:canvas.create_text(20,40,text='No measurements available',fill='@muted',anchor='w');return
        width=max(400,canvas.winfo_width())-30;high=max(valid) or 1;previous=None
        for t,v in points:
            if v is None:previous=None;continue
            x=15+(t-self.origin)/max(1,self.duration)*width;y=140-v/high*120
            canvas.create_oval(x-2,y-2,x+2,y+2,fill='@info',outline='')
            if previous and t-previous[0]<=6:canvas.create_line(previous[1],previous[2],x,y,fill='@info')
            previous=(t,x,y)
    def inspect_record(self):
        event=self.timeline.selected()
        if not event:raise ValueError('Select a timeline event in Replay first.')
        value=json.dumps(event,indent=2,allow_nan=False)
        self.record_detail.set(value if len(value)<=12000 else value[:12000]+'\n[Preview truncated; reviewed export contains the complete sanitized record.]')
    def selected_data(self):
        if not self.incident:raise ValueError('Select and load an incident first.')
        return self.incident
    def export(self):
        self.active();data=self.selected_data();include=bool(self.export_metrics.get());preview=bundle(data,include)['preview']
        text='Included:\n'+ '\n'.join(preview['included'])+'\n\nExcluded:\n'+'\n'.join(preview['excluded'])+f"\n\n{preview['records']} records. Exact event times and resource measurements remain in the bundle. Save this reviewed export?"
        if not self.confirm('Diagnostic export preview',text):return
        from tkinter import filedialog
        from crash_export import export_bundle
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Save reviewed diagnostic bundle',defaultextension='.zip',initialfile='VRC-Eye-diagnostic.zip',filetypes=[('ZIP bundle','*.zip')])
        if path:self.start(lambda client,stop,progress:export_bundle(path,data,include),lambda _:self.status.set('Reviewed bundle saved. Existing files are never overwritten.'),api=False)
    def delete(self):
        self.active();data=self.selected_data()
        if self.confirm('Delete incident','Permanently delete this preserved incident? Export it first if you need a copy.'):
            self.request('delete',(data['id'],),self.deleted)
    def deleted(self,_):
        self.incident=None;self.overview.set('Incident deleted. Refresh the list.');self.timeline.set([],lambda _:());self.canvas.delete('all');self.replay.set('Select an incident.')
    def apply_visibility(self):
        self.tabs.tab(self.frames['Developer'],state='normal' if self.view.get()=='Developer' else 'hidden')
        for name in ('Replay','Error Center'):self.tabs.tab(self.frames[name],state='hidden' if self.view.get()=='Casual' else 'normal')
    def apply_view(self):
        self.apply_visibility()
        if not self.app.demo:
            self.settings=settings(dict(self.settings,view=self.view.get()));self.shell.store.set_option('crash.settings',self.settings)
    def apply_settings(self):
        self.active();value=settings(dict(self.settings,enabled=bool(self.enabled.get()),remember_world=bool(self.remember.get()),windows_evidence=bool(self.windows.get()),window_minutes=int(self.window.get()),retain_days=int(self.days.get()),max_incidents=int(self.maximum.get()),view=self.view.get()))
        deleting=value['retain_days']!=self.settings['retain_days'] or value['max_incidents']!=self.settings['max_incidents'] or self.settings['remember_world'] and not value['remember_world']
        if deleting and not self.confirm('Apply retention changes','These settings can permanently remove old incidents or saved world recovery targets. Apply them?'):return
        def applied(result):
            self.settings=result;self.shell.store.set_option('crash.settings',result)
            if not result['remember_world'] and self.incident:self.incident['world']=''
            self.status.set('Recorder settings applied.')
        self.request('configure',(value,),applied)
    def recovery_review(self):
        self.active()
        if self.service.snapshot()['process']!='not_running':raise ValueError('Recovery requires a fresh observation that VRChat is not running. Reopen Start.cmd online to finish dependency setup if process status is unavailable.')
    def launch(self):
        self.recovery_review()
        self.shell.show('Unity Player')
        page=self.shell.pages.get('Unity Player')
        if page:
            page.tabs.select(page.frames['Startup & launch'])
            page.launch_purpose.set('Recovery')
            page.status.set('Review a launch profile here. The shared companion coordinator checks launch ownership and pending recovery before submission.')
    def rejoin(self):
        self.recovery_review();data=self.selected_data();world=data.get('world','')
        if not self.service.config['remember_world'] or not WORLD.fullmatch(world):raise ValueError('This incident has no opted-in world recovery target.')
        similar=sum(r.get('signature')==data['summary']['signature'] for r in self.rows)
        warning='Repeated similar incidents are present. Consider a different world.\n\n' if similar>=3 else ''
        if self.confirm('Safe Rejoin review',warning+'Open the previous world website to choose a fresh instance? Returning may reproduce the problem. No automatic join will occur.'):
            self.recovery_review();webbrowser.open('https://vrchat.com/home/world/'+world)
    def on_events(self,batch,items):
        if self.app.demo:return
        from world_players import log_epoch
        for event in getattr(batch,'player_events',()):
            stamp=log_epoch(event.stamp)
            if not event.reconstructed and stamp is not None and event.kind in ('instance.entered','instance.left','player.joined','player.left','avatar.changed','avatar.load'):
                self.service.offer(event.kind,'log',{},stamp=stamp,key=('player',event.event_id))
                if event.kind in ('instance.entered','instance.left') and 0<=time.time()-stamp<=15:
                    self.service.world=''
                    if event.kind=='instance.entered' and self.service.config['remember_world']:
                        world=getattr(getattr(batch,'roster',None),'world_id','')
                        if WORLD.fullmatch(world or ''):self.service.world=world
        for item in items:
            stamp=log_epoch(item.stamp)
            if stamp is None:continue
            kind='log.crash' if item.category=='Crashes' else 'log.error' if item.category=='Errors' else 'log.warning' if item.severity.lower() in ('warning','warn') else None
            if kind:self.service.offer(kind,'log',{'count':1,'category':'VRChat'},stamp=stamp,key=('log',item.source,item.serial))
    def tick(self):
        super().tick()
        if self.app.demo:
            if self.started:self.service.close();self.started=False
            self.summary.set('Demo — recording and recovery disabled');self.was_demo=True;return
        if self.was_demo:self.service=CrashService(self.shell.store.path,self.settings);self.was_demo=False
        resource=self.shell.pages.get('Performance & Security')
        if resource:self.service.provider=resource.service
        if not self.started:self.service.start();self.started=True
        bridge=self.app.bridge.state.snapshot()
        connected=bool(bridge['session'] and bridge['available'])
        if connected!=getattr(self,'last_bridge',None):
            self.service.offer('bridge.connected' if connected else 'bridge.disconnected','bridge',{'bridge':'connected' if connected else 'disconnected'});self.last_bridge=connected
        wellness=self.shell.pages.get('Wellness')
        if wellness and time.monotonic()-getattr(self,'last_vr',0)>=5:
            observation=wellness.runtime.snapshot();received=observation.get('received')
            if received is not None and 0<=time.monotonic()-received<=5:
                self.service.offer('vr.state','steamvr',{'steam_running':observation.get('steam_running'), 'worn':observation.get('worn'), 'count':len(observation.get('batteries',[]))})
            self.last_vr=time.monotonic()
        if time.monotonic()-self.last_draw<1:return
        self.last_draw=time.monotonic();snap=self.service.snapshot()
        self.summary.set(f"{snap['status']} · {snap['seconds']:.0f}s retained · {snap['incidents']} incidents · VRChat: {snap['process']}")
        self.errors.set(snap['errors'],lambda r:(clock_text(r['wall']),r['kind'],r['source'],r['count']))
        self.developer.set('Schema 1 · SHA-256 records · SQLite WAL / FULL synchronous commits\n'+snap['os_status']+'\nSensors: resource cadence 1–5s; window responsiveness Windows only; SteamVR process and network interface link from psutil. Tracking quality, driver attribution and per-avatar resource attribution are unavailable without an explicit provider.\nNo memory inspection, injection, process termination, credential export or automatic recovery.')
        if snap.get('incident_warning'):self.status.set(snap['incident_warning'])
        elif snap.get('recovered'):self.status.set('An unfinished recording was recovered. Refresh incidents to analyze it. '+snap['os_status'])
    def close(self):
        self.service.close();return super().close()
