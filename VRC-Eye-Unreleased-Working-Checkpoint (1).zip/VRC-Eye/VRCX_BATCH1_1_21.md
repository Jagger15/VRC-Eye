# Missing VRCX features — first batch, Development 5

This batch extends the existing VRC Eye import, Groups, Inventory and media
workspaces. VRCX remains an optional migration source; its application and code
are not bundled. The full parity roadmap remains in progress.

## Added workflows

| Location | Added behavior |
| --- | --- |
| Favorites / VRCX data → VRCX import | Prepare an import, then **Choose conflicting fields…**. Compare local and incoming values, choose either value for a field or an entire record, and apply those choices to the review. **Commit reviewed import…** performs the write. |
| Social → Groups → Roles | **Delete selected role** reviews an ordinary role and its effect on members. Default and management roles are protected. Permissions and the selected role are refreshed before deletion. |
| Social → Groups → Galleries | Browse galleries; create a gallery, edit its name/description/access roles, or delete the selected gallery. **Open selected gallery images** opens the existing image browser. |
| Accounts → Inventory | Filter current or archived inventory by item type, equipment slot, tag and seen state. **Unequip selected item** clears its observed slot and keeps the item in inventory. |
| Accounts → Inventory → Equip | Adds icon-frame, nameplate-effect and profile-effect slots to drone, warp, portal and loading screen. Compatibility and entitlement remain server decisions. |
| Accounts → My media → Emoji → Upload image | Animated GIF/WebP staging now includes playback of the outgoing frames, pause, frame stepping, an atlas view and 8/12/24 FPS presets. Custom 1–64 FPS values remain available. |

Reward redemption now accepts the documented list response and correlates it
with the reviewed code. The code remains excluded from persistent receipts.

## Import behavior

Existing Keep, Fill and Replace policies remain the defaults for unselected
fields. Nested object fields can be selected independently. Lists, and changes
between an object and a scalar, are selected as whole values. The comparison
distinguishes an absent field from null or an empty value; choosing an absent
incoming field explicitly removes that field.

Choices are immutable after application to the review. Reopening the comparison
allows another reviewed revision; it does not extend the original expiry.
Source-file checks, destination fingerprints, account/workspace boundaries,
cancellation, deletion markers and transaction/rollback behavior still apply.
A newer local edit blocks a conflicting write. Before-images and the chosen
field sources are retained for changed records. Privacy, account or import-form
changes clear the open comparison and invalidate the affected review.

The existing 10,000-record / 32 MiB incoming import limit remains. Existing
conflict values have a separate 32 MiB review budget, and a review supports up
to 10,000 explicit field choices. Lists are not merged by guessed identities.
This is a two-source comparison; complete three-way history and per-field
ancestry across every source version remain unfinished.

## Media and account boundaries

Playback uses the exact staged PNG atlas rather than rereading the original
animation. Padded atlas cells are not played. Reduced motion disables autoplay
and timed playback; frame stepping remains available. Changing the FPS clears
the staged preview, so a new upload cannot silently reuse the old frame rate.
Closing the window or changing account/privacy state stops playback and clears
its frames. Upload still uses the existing separate action review.

Group and inventory changes use the shared account action service, request
pacing and one-use receipts. Uncertain replies are surfaced without automatic
resubmission. Unequip reviews and rechecks both the selected item holder and its
observed slot. Group selection cannot reuse permission evidence from a different
group. Gallery deletion does not delete local source photos.

## Contract references

The additional routes and response shapes were checked on 2026-10-04 against
the API community's own generated clients and model definitions. These are
community contracts, not an official VRChat API support guarantee or a live test.
The existing loading-screen contract is retained from VRCX 2026.09.16.

- [Group routes and return shapes](https://docs.rs/vrchatapi/latest/src/vrchatapi/apis/groups_api.rs.html): gallery create/edit/delete and remaining-role-list response for role deletion.
- [Create gallery model](https://docs.rs/crate/vrchatapi/latest/source/docs/CreateGroupGalleryRequest.md) and [update gallery model](https://docs.rs/crate/vrchatapi/latest/source/docs/UpdateGroupGalleryRequest.md): names, descriptions, member visibility and role access lists.
- [Group role model](https://docs.rs/crate/vrchatapi/latest/source/docs/GroupRole.md) and [group permissions](https://docs.rs/crate/vrchatapi/latest/source/docs/GroupPermissions.md): protected role flags and gallery/role management permission names.
- [Inventory routes](https://docs.rs/vrchatapi/latest/src/vrchatapi/apis/inventory_api.rs.html): inventory filters, slot-based unequip with a JSON string reply, and reward-redemption list reply.
- [Equipment slots](https://docs.rs/crate/vrchatapi/latest/source/docs/InventoryEquipSlot.md) and [item types](https://docs.rs/crate/vrchatapi/latest/source/docs/InventoryItemType.md): bounded selection choices.
- [Redemption response model](https://docs.rs/crate/vrchatapi/latest/source/src/models/reward_redemption_result.rs): reward results correlated to the submitted code.

## Remaining scope

Gallery image upload, image approval/removal and reordering remain unfinished;
this batch adds gallery administration. Every emoji mask/motion preset is not
implemented. Dedicated cosmetic/template drilldowns, exhaustive filters, the
complete older-history timeline, whole-application backup, lock/auto-lock,
larger moderation batches and the other ledger gaps remain future work.

Source coverage is in `tests/test_vrcx_missing_features_batch1.py` and
`tests/test_vrcx_missing_features_ui.py`, with the existing regression suite.
Headless widget tests exercise actual page callbacks; they do not establish
native Tk layout or Windows acceptance. See [validation](VALIDATION_1_21.md) and
the [feature ledger](IMPLEMENTATION_STATUS_1_21.md).
