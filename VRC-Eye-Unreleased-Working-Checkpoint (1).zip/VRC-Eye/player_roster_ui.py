"""Player-list controls and rendering. All facts come from the session service."""
from dataclasses import replace
import queue
import tkinter as tk
from tkinter import ttk,messagebox

from player_sessions import PlayerSessionService,utc
from player_session_model import seconds_label
from player_session_settings import shown_columns
from world_players import PlayerRow,PlayerVisit

ALL_COLUMNS=("name","distance","state","joined","left","platform","trust","fps","ping","relation","elapsed","avatar","roles","seen","flags","user_id")


class RosterPanel:
    def __init__(self,view):
        self.view=view;self.app=view.app;self.dialogs={};self.cards={};self.sampler=None;self.resource_status=""
        self.service=PlayerSessionService(getattr(self.app,"player_store_path",None),companion_path=getattr(self.app,"companion_store_path",None),demo=self.app.demo)
        self.app.player_sessions=self.service
        self.service.companion=getattr(self.app,"vrcx_companion",None)
        self.service.peer=getattr(self.app,"peer_service",None)
        self.mode=tk.StringVar(value="Casual");self.layout=tk.StringVar(value="Standard");self.sort=tk.StringVar(value="Pinned / friends");self.filter=tk.StringVar(value="Everyone")
        self.summary=tk.StringVar();self.authority=tk.StringVar();self.page=0;self.last_query=None;self.settings_revision=None;self.last_selection="";self.last_resource=0.
    def build(self,parent):
        from player_session_settings import SORTS,FILTERS
        bar=ttk.Frame(parent);bar.pack(fill="x",pady=4)
        for title,var,values in (("View",self.layout,("Compact","Standard","Detailed","Columns")),("Mode",self.mode,("Casual","Advanced","Developer")),("Sort",self.sort,SORTS),("Filter",self.filter,FILTERS)):
            ttk.Label(bar,text=title).pack(side="left",padx=(0,4))
            box=ttk.Combobox(bar,textvariable=var,values=values,state="readonly",width=17 if title in ("Sort","Filter") else 10)
            box.pack(side="left",padx=(0,8));box.bind("<<ComboboxSelected>>",lambda _:self.preferences())
        bar=ttk.Frame(parent);bar.pack(fill="x",pady=(0,6))
        for label,command in (("Player settings…",self.settings_dialog),("Session timeline…",self.timeline),("Diagnostics…",self.diagnostics),("Previous 100",lambda:self.paging(-1)),("Next 100",lambda:self.paging(1))):ttk.Button(bar,text=label,command=command).pack(side="left",padx=(0,8))
        ttk.Label(parent,textvariable=self.summary,style="Muted.TLabel",wraplength=1050).pack(anchor="w")
        ttk.Label(parent,textvariable=self.authority,style="Muted.TLabel",wraplength=1050).pack(anchor="w",pady=(0,6))
    def preferences(self):
        self.presentation_mode = None
        value=dict(self.service.settings);value.update(mode=self.mode.get(),layout=self.layout.get(),sort=self.sort.get(),filter=self.filter.get())
        try:self.service.configure(value);self.page=0;self.view.draw()
        except ValueError as error:self.summary.set(str(error))
    def paging(self,delta):self.page=max(0,self.page+delta);self.view.draw()
    def settings_dialog(self):
        from player_session_dialog import PlayerSettings
        PlayerSettings(self)
    def tick(self):
        service=self.service
        if service.demo!=bool(self.app.demo):
            service.close()
            for d in tuple(self.dialogs.values()):d.close()
            self.service=PlayerSessionService(getattr(self.app,"player_store_path",None),companion_path=getattr(self.app,"companion_store_path",None),demo=self.app.demo)
            self.app.player_sessions=self.service;service=self.service;self.settings_revision=None
            service.companion=getattr(self.app,"vrcx_companion",None)
            service.peer=getattr(self.app,"peer_service",None)
        service.tick();service.enrich_friends(self.app.api)
        from player_bridge import poll_bridge
        poll_bridge(service,self.app.bridge)
        settings=service.settings
        if settings["large_rows"] and not getattr(self,"large_style_applied",False):
            ttk.Style(self.app.root).configure("PlayerRoster.Treeview",rowheight=38)
            self.view.roster.configure(style="PlayerRoster.Treeview");self.large_style_applied=True
        if settings["presentation"]:
            self.app.sidebar.banner.set("")
            for window in getattr(self.app,"player_private_windows",[]):
                try:window.destroy()
                except tk.TclError:pass
            self.app.player_private_windows=[]
        signature=(settings["mode"],settings["layout"],settings["sort"],settings["filter"])
        if signature!=self.settings_revision:
            self.settings_revision=signature
            for var,value in zip((self.mode,self.layout,self.sort,self.filter),signature):var.set(value)
        if settings["resource_monitor"] and not self.app.demo:
            if self.sampler is None:
                from player_resource import ResourceSampler
                self.sampler=ResourceSampler();self.sampler.start()
            try:
                data,self.resource_status=self.sampler.output.get_nowait()
                if data and not service.bridge_bound:service.resource_sample(data,utc(service.wall()))
            except queue.Empty:pass
        elif self.sampler is not None:self.sampler.close();self.sampler=None;self.resource_status=""
        coordinator=getattr(service,'companion',None)
        desktop=getattr(self.app.sidebar,'desktop_service',None)
        if desktop and not desktop.delivery.player('Allowed',desktop.policy):
            service.notifications.clear();self.app.sidebar.banner.set('')
        suppressed=coordinator and coordinator.snapshot()['ownership']['SOCIAL']['owner']=='VRCX'
        if suppressed or any(settings[key] for key in ('presentation','notifications_muted','companion_notifications')):
            if suppressed:
                for _ in service.notifications:coordinator.notify('SOCIAL')
            service.notifications.clear();self.app.sidebar.banner.set('')
        elif service.notifications:
            message=service.notifications.popleft()
            desktop=getattr(self.app.sidebar,'desktop_service',None)
            if desktop:message=desktop.delivery.player(message,desktop.policy)
            self.app.sidebar.banner.set(message if not coordinator or coordinator.notify('SOCIAL')['allow'] else '')
        if settings["follow_selection"] and service.bridge_selection and service.bridge_selection!=self.last_selection:
            self.last_selection=service.bridge_selection
            key=next((k for k,c in self.cards.items() if c.key==service.bridge_selection),None)
            if key:
                self.view.selected_row=key;self.view.roster.selection_set(key)
                if settings["open_selected"]:self.open(key)
        for dialog in tuple(self.dialogs.values()):dialog.tick()
    def render(self,rows):
        service=self.service;service.observe_roster(self.view.log_roster())
        from peer_player import player_index
        peer_links = player_index(self.app)
        query=self.view.filter.get()
        if query!=self.last_query:self.page=0;self.last_query=query
        cards=service.cards(query,departed=self.view.show_departed.get())
        self.cards={};result=[]
        if service.rows:
            for card in cards:
                record=service.rows[card.key]
                choices=[r for r in rows if r.visit and (r.visit.user_id==record.user_id if record.user_id else not r.visit.user_id and r.name==record.name) and (r.visit.joined==record.joined_at or any(r.visit.joined==segment[0] for segment in record.visit_segments) or not record.joined_at)]
                base=next((r for r in choices if r.visit.active==card.active),choices[-1] if choices else None)
                if base is None:
                    visit=PlayerVisit(0,record.name,record.user_id,record.joined_at,record.left_at,record.first_observed,"Present" if card.active else "Left")
                    base=PlayerRow(card.key,record.name,visit,None,None,record.local,(record.name,"Unknown",card.primary_status,record.joined_at[11:19] or "Unknown",record.left_at[11:19] or "—","Unknown","Unknown","Unavailable","Unavailable"))
                original=dict(zip(ALL_COLUMNS,base.values))
                role_label=(", ".join(card.roles[:3])+(f" +{len(card.roles)-3}" if len(card.roles)>3 else "")) or "Unknown"
                original.update(name=card.name+(" (you)" if card.local else ""),state=card.primary_status,relation=card.relationship.value or "Unknown",elapsed=seconds_label(card.duration_seconds),avatar=card.avatar_name.value or "Unknown",roles=role_label,seen=str(card.encounters) if not service.settings["presentation"] else "Hidden",flags=", ".join(card.secondary_flags),user_id=card.user_id or "Unknown")
                if card.distance.value is not None:original["distance"]=str(card.distance.value)
                if card.speaking.value is True:original["state"] += " · Speaking"
                if card.user_id in peer_links:original["state"] += " · Eye linked"
                self.cards[base.key]=card;result.append(replace(base,values=tuple(original.get(k,"Unknown") for k in ALL_COLUMNS)))
            # Helper-only markers remain visible but never acquire an account ID from a display name.
            if not query:
                for row in rows:
                    if row.visit is None:
                        if service.settings["anonymize"]:row=replace(row,values=("Helper player",)+row.values[1:])
                        result.append(row)
        else:result=list(rows)
        if service.rows:
            display = dict(service.settings)
            presentation = getattr(self, "presentation_mode", None)
            if presentation:
                display["mode"] = presentation
                if presentation == "Casual": display["layout"] = "Compact"
            self.view.roster.configure(displaycolumns=shown_columns(display))
        else:self.view.roster.configure(displaycolumns=ALL_COLUMNS[:9])
        maximum=max(0,(len(result)-1)//100);self.page=min(self.page,maximum)
        active=sum(r.active for r in service.rows.values());uncertain=sum(r.conflict or not r.user_id for r in service.rows.values() if r.active)
        storage="Incognito" if service.settings["incognito"] else service.settings["history"]
        self.summary.set(f"{active} observed present · {uncertain} uncertain identities · {len(result)} matches · page {self.page+1}/{maximum+1} · Log: {service.health.lower()} · History: {storage}" + (" · "+service.status if "unavailable" in service.status.lower() else ""))
        allcards=[service.card(r) for r in service.rows.values() if r.active]
        groups=sum(any(x.startswith("Group ") for x in c.roles) for c in allcards);staff=sum("VRChat Staff" in c.roles for c in allcards)
        owner=next((c.name for c in allcards if "Instance Owner" in c.roles),"Unknown")
        self.authority.set(f"Authority: instance owner {owner} · {groups} known group staff · {staff} known VRChat staff · Roles not yet retrieved remain unknown.")
        return tuple(result[self.page*100:self.page*100+100])
    def select(self,key):
        card=self.cards.get(key);self.service.selected=card.key if card else ""
        if card:
            self.view.selection_info.set(f"{card.name} · {card.primary_status} · {seconds_label(card.duration_seconds)} observed together\nJoined: {card.joined_at or 'Unknown'} · Left: {card.left_at or 'Not observed'}"+(" · Reconstructed from log" if card.reconstructed else ""))
    def open(self,key=None):
        key=key or self.view.selected_row;card=self.cards.get(key)
        if not card:return False
        from player_session_dialog import PlayerDetails
        if card.key in self.dialogs:self.dialogs[card.key].window.lift()
        else:
            if len(self.dialogs)>=8:messagebox.showinfo("Player details","Close a player window before opening another.",parent=self.app.root);return True
            self.dialogs[card.key]=PlayerDetails(self,card.key,key)
        return True
    def context_menu(self,event=None):
        key=self.view.roster.identify_row(event.y) if event is not None else self.view.selected_row
        card=self.cards.get(key)
        if not card:return
        self.view.roster.selection_set(key);self.view.selected_row=key
        menu=tk.Menu(self.app.root,tearoff=False)
        def action(fn):
            def call():
                try:fn()
                except (ValueError,KeyError) as error:messagebox.showerror("Player action",str(error),parent=self.app.root)
            return call
        menu.add_command(label="Player details…",command=lambda:self.open(key))
        menu.add_command(label="Notes and tags…",command=lambda:self.open_tab(key,"Notes"))
        menu.add_command(label="Local incident bookmark…",command=lambda:self.open_tab(key,"incident"))
        menu.add_command(label="Unpin" if card.pinned else "Pin for this session",command=action(lambda:self.service.pin(card.key)))
        if card.user_id:
            from peer_player import open_peer_player
            menu.add_command(label="VRC Eye link…",command=action(lambda:open_peer_player(self.app,card.user_id,card.name)))
            menu.add_command(label="Remove VRC Eye favorite" if card.favorite else "Favorite in VRC Eye",command=action(lambda:self.service.update_local(card.user_id,favorite=not card.favorite)))
            menu.add_command(label="Copy user ID",command=action(lambda:self.copy(card.user_id)))
        menu.add_command(label="Copy display name",command=action(lambda:self.copy(card.name)))
        if card.avatar_id.value:menu.add_command(label="Copy avatar ID",command=action(lambda:self.copy(card.avatar_id.value)))
        menu.tk_popup(event.x_root,event.y_root) if event else menu.tk_popup(self.app.root.winfo_rootx()+100,self.app.root.winfo_rooty()+100)
    def copy(self,text):
        if self.service.settings["presentation"]:raise ValueError("Clipboard actions are disabled in presentation mode.")
        self.app.root.clipboard_clear();self.app.root.clipboard_append(text)
    def open_tab(self,key,name):
        if self.open(key):
            dialog=self.dialogs.get(self.cards[key].key)
            if dialog:
                if name=="incident":dialog.incident()
                elif name in dialog.pages:dialog.tabs.select(dialog.pages[name])
    def diagnostics(self):
        from player_session_dialog import PlayerDiagnostics
        PlayerDiagnostics(self)
    def timeline(self):
        from player_session_dialog import text_window
        if self.service.settings["presentation"]:text_window(self.app,"Session timeline","Disable presentation mode to view the private session timeline.");return
        text_window(self.app,"Session timeline","\n".join(" · ".join(v) for v in self.service.timeline) or "No observed session events.")
    def close(self):
        for dialog in tuple(self.dialogs.values()):dialog.close()
        if self.sampler:self.sampler.close()
        self.service.close()
