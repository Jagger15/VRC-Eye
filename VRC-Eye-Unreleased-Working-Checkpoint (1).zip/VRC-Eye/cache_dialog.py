"""Local cache browser with explicit, non-overwriting copies."""

from text_viewport import window_body

import queue
import threading
from datetime import datetime, timezone
from pathlib import Path

from avatar_details import format_download_size
from vrca_cache import cache_location, save_cache_entry, scan_cache, target_from_url
from vrca_files import VRCAError


def show_cache_dialog(app, asset_url="", avatar_id=""):
    from tkinter import filedialog, messagebox
    tk, ttk = app.tk, app.ttk
    window = tk.Toplevel(app.root)
    window.title("Browse VRChat cache")
    window.geometry("1000x740")
    window.minsize(960, 690)
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=20)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Browse VRChat cache", font='EyeTitleFont').pack(anchor="w")
    ttk.Label(frame, text="VRCX stores avatar records and preview images. Avatar bundles are looked up in VRChat's cache using an asset URL, or listed for you to inspect.",
              style="Muted.TLabel", wraplength=910).pack(anchor="w", pady=(8, 10))
    initial, initial_note = cache_location(Path(app.folder.get()))
    folder = tk.StringVar(value=str(initial))
    location_row = ttk.Frame(frame)
    location_row.pack(fill="x", pady=(0, 8))
    location_entry = ttk.Entry(location_row, textvariable=folder)
    location_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
    browse_button = ttk.Button(location_row, text="Browse…")
    browse_button.pack(side="left")
    identity = "Avatar declared by loaded file metadata: " + avatar_id if avatar_id else "Avatar identity unknown. Use Rescue cached avatar to match an exact avatar ID, or load file metadata in Save VRCA."
    ttk.Label(frame, text=identity, style="Muted.TLabel", wraplength=910).pack(anchor="w", pady=(0, 6))
    if asset_url:
        source = tk.StringVar(value=asset_url)
        ttk.Entry(frame, textvariable=source, state="readonly").pack(fill="x", pady=(0, 6))
    actions = ttk.Frame(frame)
    actions.pack(fill="x", pady=(0, 8))
    match_button = ttk.Button(actions, text="Find URL match")
    match_button.pack(side="left", padx=(0, 8))
    all_button = ttk.Button(actions, text="List all cache files")
    all_button.pack(side="left", padx=(0, 8))
    cancel_button = ttk.Button(actions, text="Cancel", state="disabled")
    cancel_button.pack(side="left")
    list_frame = ttk.Frame(frame)
    list_frame.pack(fill="both", expand=True)
    list_frame.rowconfigure(0, weight=1)
    list_frame.columnconfigure(0, weight=1)
    table = ttk.Treeview(list_frame, columns=("kind", "size", "modified", "match", "state"),
                         show="headings", selectmode="browse", height=7)
    for column, label, width in (("kind", "FILE TYPE", 175), ("size", "CACHED SIZE", 110),
                                 ("modified", "MODIFIED (UTC)", 185), ("match", "ASSOCIATION", 170),
                                 ("state", "STATE", 140)):
        table.heading(column, text=label)
        table.column(column, width=width, minwidth=85)
    table.grid(row=0, column=0, sticky="nsew")
    scroll = ttk.Scrollbar(list_frame, orient="vertical", command=table.yview)
    scroll.grid(row=0, column=1, sticky="ns")
    table.configure(yscrollcommand=scroll.set)
    path_text = tk.StringVar(value="Select a file to see its cache path.")
    ttk.Entry(frame, textvariable=path_text, state="readonly").pack(fill="x", pady=(8, 6))
    save_row = ttk.Frame(frame)
    save_row.pack(fill="x", pady=(0, 8))
    save_button = ttk.Button(save_row, text="Save selected…", state="disabled", style="Accent.TButton")
    save_button.pack(side="left", padx=(0, 12))
    decrypt_button = ttk.Button(save_row, text="Decrypt with key…", state="disabled")
    decrypt_button.pack(side="left", padx=(0, 12))
    export_note = tk.StringVar(value="Copies are saved outside the cache. Originals are kept.")
    ttk.Label(save_row, textvariable=export_note, style="Muted.TLabel", wraplength=490).pack(side="left")
    progress_bar = ttk.Progressbar(frame, maximum=100)
    progress_bar.pack(fill="x", pady=(0, 8))
    status = tk.StringVar(value=initial_note)
    ttk.Label(frame, textvariable=status, style="Muted.TLabel", wraplength=910).pack(anchor="w", pady=(0, 8))
    digest = tk.StringVar()
    ttk.Label(frame, text="Saved copy SHA-256", style="Muted.TLabel").pack(anchor="w")
    ttk.Entry(frame, textvariable=digest, state="readonly").pack(fill="x", pady=(4, 8))
    ttk.Label(frame, text="A header does not distinguish an avatar from a world or prove it will load. Unidentified bundles use .bundle; unrecognized data uses .bin. Save selected copies bytes unchanged. Decrypt with key is an optional, experimental recovery path; it needs the matching key and cannot repair missing data.",
              style="Muted.TLabel", wraplength=910).pack(anchor="w")
    entries = []
    active_stop = None
    latest = (0, None)

    def selected_entry():
        selection = table.selection()
        return entries[int(selection[0])] if selection else None

    def extension(entry):
        return ".vrca" if avatar_id and entry.matched and entry.kind == "Unity bundle" else entry.suggested_suffix

    def select(_event=None):
        entry = selected_entry()
        if not entry:
            save_button.configure(state="disabled")
            decrypt_button.configure(state="disabled")
            return
        path_text.set(str(entry.path))
        save_button.configure(state="normal" if entry.can_save and active_stop is None else "disabled")
        decrypt_button.configure(state="normal" if entry.can_save and entry.kind == "Unity bundle" and active_stop is None else "disabled")
        export_note.set((f"Will save as {extension(entry)}. Contents remain unverified." if entry.can_save else
                         "Locked or too large to copy. Close VRChat and rescan if locked."))

    table.bind("<<TreeviewSelect>>", select)

    def clear_results(*_):
        children = table.get_children()
        if children:
            table.delete(*children)
        entries.clear()
        save_button.configure(state="disabled")
        decrypt_button.configure(state="disabled")
        path_text.set("Scan this folder, then select a file.")
        export_note.set("Copies are saved outside the cache. Originals are kept.")

    folder.trace_add("write", clear_results)

    def browse():
        path = filedialog.askdirectory(parent=window, title="Select VRChat's Cache-WindowsPlayer folder")
        if path:
            folder.set(path)
            status.set("Folder changed. Choose Find URL match or List all cache files.")

    browse_button.configure(command=browse)

    def run_job(operation, complete, copying=False):
        nonlocal active_stop, latest
        if active_stop is not None:
            return
        active_stop = threading.Event()
        job_stop = active_stop
        app.transfer_stops.append(job_stop)
        latest = (0, None)
        result_queue = queue.Queue(maxsize=1)
        for button in (match_button, all_button, browse_button, save_button, decrypt_button):
            button.configure(state="disabled")
        location_entry.configure(state="disabled")
        cancel_button.configure(state="normal", command=job_stop.set)
        digest.set("")
        progress_bar.configure(value=0)

        def progress(count, total):
            nonlocal latest
            latest = (count, total)

        def worker():
            try:
                result_queue.put((operation(job_stop, progress), ""))
            except (VRCAError, OSError, ValueError, RuntimeError) as error:
                result_queue.put((None, str(error)))
            finally:
                app.transfer_stops.remove(job_stop)

        def poll():
            nonlocal active_stop
            if not window.winfo_exists():
                return
            try:
                result, error = result_queue.get_nowait()
            except queue.Empty:
                count, total = latest
                if job_stop.is_set():
                    status.set("Cancelling…")
                elif copying and count:
                    status.set(f"Copying {format_download_size(count)} / {format_download_size(total)}")
                    if total:
                        progress_bar.configure(value=min(99, count / total * 100))
                elif count:
                    status.set(f"Checked {count:,} folder entries; found {total:,} cache files…")
                app.root.after(100, poll)
                return
            active_stop = None
            location_entry.configure(state="normal")
            for button in (all_button, browse_button):
                button.configure(state="normal")
            match_button.configure(state="normal" if asset_url else "disabled")
            cancel_button.configure(state="disabled")
            if error:
                status.set(error)
                progress_bar.configure(value=0)
            else:
                complete(result)
            select()

        threading.Thread(target=worker).start()
        app.root.after(100, poll)

    def start_scan(matching=False):
        if active_stop is not None:
            return
        try:
            target = target_from_url(asset_url) if matching else None
        except VRCAError as error:
            status.set(str(error))
            return
        path = Path(folder.get())
        clear_results()
        status.set("Looking for the asset's cache entries…" if matching else "Reading local cache entries…")

        def complete(result):
            entries[:] = result.entries
            for index, entry in enumerate(entries):
                state = "Locked" if entry.locked else "Over 2 GiB" if not entry.can_save else "Available"
                association = ("Avatar URL match" if avatar_id else "Asset URL match") if entry.matched else "Unidentified"
                try:
                    modified = datetime.fromtimestamp(entry.mtime_ns / 1e9, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                except (OverflowError, ValueError, OSError):
                    modified = "Unknown"
                table.insert("", "end", iid=str(index), values=(entry.kind, format_download_size(entry.size), modified, association, state))
            message = f"Found {len(entries):,} files; skipped {result.skipped:,} unreadable, linked, image, or metadata entries."
            if result.limited:
                message += " Scan limit reached; results are partial. Use a URL match to narrow the lookup."
            elif not entries:
                message += " Check the folder and file version. VRCX.sqlite3 and ImageCache do not contain avatar bundles."
            status.set(message)
            progress_bar.configure(value=100)

        run_job(lambda stop, progress: scan_cache(path, target=target, stop=stop, progress=progress), complete)

    def save():
        entry = selected_entry()
        if not entry or not entry.can_save or active_stop is not None:
            return
        suffix = extension(entry)
        name = (avatar_id if suffix == ".vrca" else entry.path.parent.parent.name) + "-" + entry.path.parent.name
        destination = filedialog.asksaveasfilename(parent=window, title="Save outside the cache",
            initialfile=name + suffix, defaultextension=suffix, confirmoverwrite=False,
            filetypes=[("VRCA avatar bundle" if suffix == ".vrca" else "Unity bundle" if suffix == ".bundle" else "Raw cache backup", "*" + suffix)])
        if not destination:
            return
        destination = Path(destination)
        if destination.exists() or destination.is_symlink():
            messagebox.showerror("Choose a new filename", "That destination already exists and will not be overwritten.", parent=window)
            return
        status.set("Copying the selected cache file…")

        def complete(result):
            progress_bar.configure(value=100)
            digest.set(result.sha256)
            status.set(f"Saved {format_download_size(result.size)} to {result.path}. Original preserved. Encryption, if present, is unchanged. The checksum identifies the copied bytes; it does not prove the avatar is usable.")

        run_job(lambda stop, progress: save_cache_entry(entry, destination, avatar_known=bool(avatar_id),
                                                        stop=stop, progress=progress), complete, copying=True)

    def decrypt():
        entry = selected_entry()
        if entry and entry.can_save and entry.kind == "Unity bundle" and active_stop is None:
            from recovery_dialog import show_recovery_dialog
            show_recovery_dialog(app, entry, avatar_id=avatar_id, parent=window)

    decrypt_button.configure(command=decrypt)
    match_button.configure(command=lambda: start_scan(True), state="normal" if asset_url else "disabled")
    all_button.configure(command=start_scan)
    save_button.configure(command=save)

    def close():
        if active_stop:
            active_stop.set()
        window.destroy()

    window.protocol("WM_DELETE_WINDOW", close)
    # The user has explicitly opened the cache browser; scan only this folder.
    window.after(0, lambda: start_scan(bool(asset_url)))
