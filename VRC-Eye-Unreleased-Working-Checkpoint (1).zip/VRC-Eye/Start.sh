#!/usr/bin/env bash
# Linux launcher: package setup remains confined to bootstrap's app-local environment.
set -u
eye_script=$(readlink -f -- "$0") || exit 1
eye_dir=$(dirname -- "$eye_script")
cd -- "$eye_dir" || exit 1
eye_python=''
if [[ -x "$eye_dir/.recovery-env/bin/python" ]] &&
   "$eye_dir/.recovery-env/bin/python" -c 'import sys, tkinter; assert sys.version_info >= (3, 10)' >/dev/null 2>&1; then
    eye_python="$eye_dir/.recovery-env/bin/python"
elif command -v python3 >/dev/null 2>&1 &&
     python3 -c 'import sys, tkinter; assert sys.version_info >= (3, 10)' >/dev/null 2>&1; then
    eye_python=$(command -v python3)
fi
if [[ -z "$eye_python" ]]; then
    printf '%s\n' 'VRC Eye needs Python 3.10 or newer with Tkinter and venv support.' \
        'Install those components using your Linux distribution, then run Start.sh again.' >&2
    exit 1
fi
exec "$eye_python" "$eye_dir/bootstrap.py" "$@"
