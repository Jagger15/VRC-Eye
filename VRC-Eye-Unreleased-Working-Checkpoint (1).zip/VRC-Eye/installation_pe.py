"""Passive, bounded PE metadata reader; no executable code or certificates run.

Layout references: Microsoft PE/COFF format and VERSIONINFO resource documentation.
https://learn.microsoft.com/en-us/windows/win32/debug/pe-format
https://learn.microsoft.com/en-us/windows/win32/menurc/versioninfo-resource

``read_at(offset, length)`` must return exactly the requested bytes. Its exceptions
propagate so the caller can enforce cancellation, source stability and job budgets.
Only DOS/PE headers, direct-import DLL names and RT_VERSION resources are read.
Unknown layouts are parser limitations, not corruption or authenticity verdicts.
"""
from __future__ import annotations

import re
import struct
import unicodedata

HEADER_LIMIT = 64 * 1024
RESOURCE_LIMIT = 512 * 1024
IMPORT_LIMIT = 128 * 1024
MAX_SECTIONS = 96
MAX_IMPORTS = 256
MAX_RESOURCE_NODES = 128
MAX_RESOURCE_ENTRIES = 512
VERSION_KEYS = frozenset(("CompanyName", "FileDescription", "FileVersion",
                          "InternalName", "OriginalFilename", "ProductName",
                          "ProductVersion"))
_ARCH = {0x14C: "x86", 0x8664: "x86_64", 0x1C0: "arm", 0x1C2: "arm",
         0x1C4: "arm", 0xAA64: "arm64", 0xA641: "arm64ec", 0xA64E: "arm64x"}


class _LayoutError(Exception):
    """Fixed, non-payload error code only."""


def _u16(data, offset=0):
    return struct.unpack_from("<H", data, offset)[0]


def _u32(data, offset=0):
    return struct.unpack_from("<I", data, offset)[0]


def _aligned(value):
    return (value + 3) & ~3


class _Reader:
    def __init__(self, read_at, size):
        self.read_at, self.size = read_at, size
        self.used = {"header": 0, "resource": 0, "import": 0}

    def read(self, offset, length, category):
        if offset < 0 or length < 0 or offset > self.size or length > self.size - offset:
            raise _LayoutError("file-range-out-of-bounds")
        limit = {"header": HEADER_LIMIT, "resource": RESOURCE_LIMIT,
                 "import": IMPORT_LIMIT}[category]
        if category == "header" and offset + length > HEADER_LIMIT:
            raise _LayoutError("header-limit")
        if length > limit - self.used[category]:
            raise _LayoutError(category + "-read-limit")
        self.used[category] += length
        data = self.read_at(offset, length)
        if not isinstance(data, bytes) or len(data) != length:
            raise _LayoutError("short-or-invalid-read")
        return data


class _Image:
    def __init__(self, reader, headers_size, sections):
        self.reader, self.headers_size, self.sections = reader, headers_size, sections

    def validate(self):
        raw_ranges, virtual_ranges = [], []
        for virtual, virtual_size, raw, raw_size in self.sections:
            extent = max(virtual_size, raw_size)
            if extent:
                if virtual < self.headers_size or virtual + extent > 0x100000000:
                    raise _LayoutError("unsupported-section-layout")
                virtual_ranges.append((virtual, virtual + extent))
            if raw_size:
                if raw < self.headers_size or raw > self.reader.size or raw_size > self.reader.size - raw:
                    raise _LayoutError("section-range-out-of-bounds")
                raw_ranges.append((raw, raw + raw_size))
        for ranges in (raw_ranges, virtual_ranges):
            ordered = sorted(ranges)
            if any(first[1] > second[0] for first, second in zip(ordered, ordered[1:])):
                raise _LayoutError("overlapping-sections")

    def span(self, rva):
        """Return unambiguous raw offset and bytes remaining in its mapping."""
        choices = []
        if 0 <= rva < self.headers_size:
            choices.append((rva, self.headers_size - rva))
        for virtual, virtual_size, raw, raw_size in self.sections:
            extent = max(virtual_size, raw_size)
            if virtual <= rva < virtual + extent:
                delta = rva - virtual
                # Virtual-only bytes cannot be read from a disk image.
                choices.append((raw + delta, max(0, raw_size - delta)))
        if len(choices) != 1:
            raise _LayoutError("ambiguous-or-unmapped-rva")
        offset, available = choices[0]
        if not available or offset > self.reader.size or available > self.reader.size - offset:
            raise _LayoutError("unbacked-rva")
        return offset, available

    def read(self, rva, length, category):
        offset, available = self.span(rva)
        if length > available:
            raise _LayoutError("rva-range-out-of-bounds")
        return self.reader.read(offset, length, category)


def _imports(image, rva, length, out):
    if not rva and not length:
        out["imports_state"] = "absent"
        return
    if not rva or length < 20:
        raise _LayoutError("invalid-import-directory")
    # No thunk, function, ordinal, delay-import or executable section decoding.
    for index in range(min(length // 20, MAX_IMPORTS + 1)):
        desc = image.read(rva + index * 20, 20, "import")
        if desc == b"\0" * 20:
            out["imports_state"] = "parsed"
            return
        if index == MAX_IMPORTS:
            raise _LayoutError("import-count-limit")
        name_rva = _u32(desc, 12)
        if not name_rva:
            raise _LayoutError("invalid-import-name")
        offset, available = image.span(name_rva)
        data = image.reader.read(offset, min(129, available), "import")
        end = data.find(b"\0")
        if not 0 < end <= 128:
            raise _LayoutError("import-name-limit-or-termination")
        name = data[:end]
        # DLL basenames only; never retain paths, control bytes or arbitrary text.
        if not re.fullmatch(rb"[A-Za-z0-9_.+\-]{1,128}", name):
            raise _LayoutError("unsupported-import-name")
        value = name.decode("ascii")
        if value.casefold() not in {n.casefold() for n in out["direct_imports"]}:
            out["direct_imports"].append(value)
    raise _LayoutError("unterminated-import-directory")


def _version_blob(blob, out):
    """Parse only bounded VS_FIXEDFILEINFO and allowlisted string-table fields."""
    nodes = 0

    def block(offset, end):
        nonlocal nodes
        nodes += 1
        if nodes > 512:
            raise _LayoutError("version-node-limit")
        if offset + 6 > end:
            raise _LayoutError("truncated-version-block")
        length, value_length, value_type = struct.unpack_from("<HHH", blob, offset)
        stop = offset + length
        if length < 6 or stop > end or value_type not in (0, 1):
            raise _LayoutError("invalid-version-block")
        cursor = offset + 6
        key_start = cursor
        while cursor + 2 <= stop and cursor - key_start <= 256:
            if blob[cursor:cursor + 2] == b"\0\0":
                break
            cursor += 2
        else:
            raise _LayoutError("version-key-limit-or-termination")
        try:
            key = blob[key_start:cursor].decode("utf-16-le")
        except UnicodeDecodeError:
            raise _LayoutError("invalid-version-text") from None
        start = _aligned(cursor + 2)
        value_end = start + value_length * (2 if value_type == 1 else 1)
        if value_end > stop or (value_length and start > stop):
            raise _LayoutError("version-value-out-of-bounds")
        return key, value_type, blob[start:value_end], _aligned(value_end), stop

    def children(start, end):
        while start < end:
            if end - start <= 3 and not any(blob[start:end]):
                break
            item = block(start, end)
            yield item
            start = _aligned(item[4])

    key, kind, value, child, end = block(0, len(blob))
    if key != "VS_VERSION_INFO" or kind != 0:
        raise _LayoutError("unsupported-version-root")
    if value:
        if len(value) != 52 or _u32(value) != 0xFEEF04BD:
            raise _LayoutError("invalid-fixed-version")
        for field, pos in (("fixed_file_version", 8), ("fixed_product_version", 16)):
            high, low = _u32(value, pos), _u32(value, pos + 4)
            version = ".".join(str(n) for n in (high >> 16, high & 65535,
                                                low >> 16, low & 65535))
            if out[field] is not None and out[field] != version:
                raise _LayoutError("conflicting-fixed-versions")
            out[field] = version
    for name, _, _, start, stop in children(child, end):
        if name != "StringFileInfo":
            continue
        for table, _, _, string_start, string_stop in children(start, stop):
            if not re.fullmatch(r"[0-9A-Fa-f]{8}", table):
                raise _LayoutError("unsupported-version-string-table")
            for field, value_type, raw, _, _ in children(string_start, string_stop):
                if field not in VERSION_KEYS:
                    continue
                if value_type != 1 or len(raw) > 2048:
                    raise _LayoutError("version-string-limit-or-type")
                try:
                    text = raw.decode("utf-16-le").rstrip("\0")
                except UnicodeDecodeError:
                    raise _LayoutError("invalid-version-text") from None
                # Keep human metadata; remove control, surrogate and bidi format
                # characters. No path/file read is derived from this content.
                text = "".join(c for c in text if not unicodedata.category(c).startswith("C"))
                previous = out["version_strings"].get(field)
                if previous is not None and previous != text:
                    # Multiple language tables may legitimately differ. Keep the
                    # first observed value and report the ambiguity explicitly.
                    if "multiple-version-string-values" not in out["errors"]:
                        out["errors"].append("multiple-version-string-values")
                else:
                    out["version_strings"][field] = text


def _resources(image, rva, length, out):
    if not rva and not length:
        out["version_state"] = "absent"
        return
    if not rva or length < 16:
        raise _LayoutError("invalid-resource-directory")
    visited, entries_seen, versions, claimed = set(), 0, 0, []

    def claim(offset, size):
        if any(offset < end and start < offset + size for start, end in claimed):
            raise _LayoutError("overlapping-resource-structures")
        claimed.append((offset, offset + size))

    def relative(offset, size):
        if offset < 0 or size < 0 or offset > length or size > length - offset:
            raise _LayoutError("resource-range-out-of-bounds")
        return image.read(rva + offset, size, "resource")

    def directory(offset, depth):
        nonlocal entries_seen, versions
        if offset in visited:
            raise _LayoutError("resource-cycle-or-alias")
        if len(visited) >= MAX_RESOURCE_NODES:
            raise _LayoutError("resource-node-limit")
        visited.add(offset)
        header = relative(offset, 16)
        count = _u16(header, 12) + _u16(header, 14)
        entries_seen += count
        if entries_seen > MAX_RESOURCE_ENTRIES:
            raise _LayoutError("resource-entry-limit")
        claim(offset, 16 + count * 8)
        data = relative(offset + 16, count * 8)
        for i in range(count):
            name, target = struct.unpack_from("<II", data, i * 8)
            if depth == 0 and name != 16:  # Only numeric RT_VERSION.
                continue
            is_directory = bool(target & 0x80000000)
            target &= 0x7FFFFFFF
            if depth < 2:
                if not is_directory:
                    raise _LayoutError("unsupported-resource-depth")
                directory(target, depth + 1)
            else:
                if is_directory:
                    raise _LayoutError("unsupported-resource-depth")
                if target in visited:
                    raise _LayoutError("resource-cycle-or-alias")
                if len(visited) >= MAX_RESOURCE_NODES:
                    raise _LayoutError("resource-node-limit")
                visited.add(target)
                claim(target, 16)
                entry = relative(target, 16)
                blob_rva, size = _u32(entry), _u32(entry, 4)
                if not 6 <= size <= 65535:
                    raise _LayoutError("version-resource-size-limit")
                # Data may be mapped elsewhere, but must be within the declared
                # resource range; do not follow arbitrary executable pointers.
                claim(blob_rva - rva, size)
                blob = relative(blob_rva - rva, size)
                _version_blob(blob, out)
                versions += 1
    directory(0, 0)
    out["version_state"] = "parsed" if versions else "absent"


def inspect_pe(read_at, size: int, *, details: bool = True) -> dict:
    """Inspect declared metadata with independent partial-result states.

    ``certificate_table_present`` means a nonempty, in-bounds PE certificate
    directory declaration, not certificate validation or signature trust.
    ``details=False`` never reads import/resource/certificate payloads.
    """
    out = dict(state="unsupported", machine=None, architecture="unknown", format=None,
               fixed_file_version=None, fixed_product_version=None, version_strings={},
               direct_imports=[], certificate_table_present=None, signature_trust="unverified",
               header_state="unsupported", version_state="not-inspected",
               imports_state="not-inspected", certificate_state="not-inspected", errors=[])
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        out["errors"].append("invalid-file-size")
        return out
    reader = _Reader(read_at, size)
    try:
        if size < 2 or reader.read(0, 2, "header") != b"MZ":
            out.update(state="not-pe", header_state="not-pe")
            return out
        dos = reader.read(0, 64, "header")
        offset = _u32(dos, 60)
        if offset < 64:
            raise _LayoutError("invalid-pe-header-offset")
        head = reader.read(offset, 24, "header")
        if head[:4] != b"PE\0\0":
            raise _LayoutError("invalid-pe-signature")
        machine, section_count = _u16(head, 4), _u16(head, 6)
        out.update(machine=machine, architecture=_ARCH.get(machine, "unknown"))
        optional_length = _u16(head, 20)
        if optional_length < 2 or optional_length > 4096 or section_count > MAX_SECTIONS:
            raise _LayoutError("header-layout-limit")
        optional = reader.read(offset + 24, optional_length, "header")
        magic = _u16(optional)
        if magic not in (0x10B, 0x20B):
            raise _LayoutError("unsupported-optional-header")
        out["format"] = "PE32" if magic == 0x10B else "PE32+"
        base = 96 if magic == 0x10B else 112
        if optional_length < base:
            raise _LayoutError("truncated-optional-header")
        directory_count = _u32(optional, base - 4)
        if min(directory_count, 16) * 8 > optional_length - base:
            raise _LayoutError("truncated-data-directories")
        headers_size = _u32(optional, 60)
        table_offset = offset + 24 + optional_length
        if headers_size < table_offset + section_count * 40 or headers_size > size:
            raise _LayoutError("invalid-headers-size")
        table = reader.read(table_offset, section_count * 40, "header")
        sections = []
        for i in range(section_count):
            start = i * 40
            virtual_size, virtual, raw_size, raw = struct.unpack_from("<IIII", table, start + 8)
            sections.append((virtual, virtual_size, raw, raw_size))
        out["header_state"] = "parsed"
        out["state"] = "parsed"
    except _LayoutError as exc:
        out["errors"].append(str(exc))
        out["state"] = "partial" if out["machine"] is not None else "unsupported"
        return out

    def data_directory(index):
        return struct.unpack_from("<II", optional, base + index * 8) if index < directory_count else (0, 0)

    certificate_offset, certificate_size = data_directory(4)
    if not certificate_offset and not certificate_size:
        out.update(certificate_table_present=False, certificate_state="absent")
    elif (certificate_offset % 8 or certificate_size < 8 or certificate_offset < headers_size
          or certificate_offset > size or certificate_size > size - certificate_offset
          or any(raw_size and certificate_offset < raw + raw_size
                 and raw < certificate_offset + certificate_size
                 for _, _, raw, raw_size in sections)):
        out["certificate_state"] = "unsupported"
        out["errors"].append("invalid-certificate-directory")
    else:
        out.update(certificate_table_present=True, certificate_state="declared")

    if details:
        image = _Image(reader, headers_size, sections)
        for key, index, parser in (("imports_state", 1, _imports), ("version_state", 2, _resources)):
            try:
                image.validate()
                parser(image, *data_directory(index), out)
            except _LayoutError as exc:
                out[key] = "limited" if "limit" in str(exc) else "unsupported"
                if str(exc) not in out["errors"]:
                    out["errors"].append(str(exc))
    if out["errors"]:
        out["state"] = "partial"
    return out
