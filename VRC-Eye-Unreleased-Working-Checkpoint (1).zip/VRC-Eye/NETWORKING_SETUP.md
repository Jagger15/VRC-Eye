# VRC Eye Networking — 1.19.1

Open **VRC Eye → Networking**. Connection setup has moved here from VRC Eye
Primary. Primary continues to hold profiles, drafts, messages, planners, creator
tools, diagnostics and sharing permissions. Both categories use one application
peer service; changing pages does not disconnect it or create another service.

## Starting and staying private

Every launch starts in Private Mode. Merely opening Networking, inspecting local
adapters, reviewing an invitation or saving/loading a connection profile opens no
peer connection. No profile, private note or saved plan is published by connecting.

**Start.cmd** automatically prepares cryptography and adapter-discovery
packages in the app's local environment. An offline setup failure leaves available
core features usable; a later normal launch retries missing packages. It does not install a VPN, join its
network, authenticate to a provider, change router/firewall rules or open ports.
Install/configure your chosen provider using its own application first.

## Connection options

| Mode | Preparation outside VRC Eye | VRC Eye behavior |
|---|---|---|
| LAN | Computers have a reachable local network route | Host on a specific local address; pair using a reviewed invitation |
| Hamachi | Both devices join the intended Hamachi IPv4 mesh | Bind the detected Hamachi adapter; use 25.x.x.x mesh addresses |
| Tailscale | Install Tailscale and authorize the intended devices and access rules | Select its detected adapter and permitted Tailscale address |
| ZeroTier | Install ZeroTier and authorize both devices on the intended network | Select its detected adapter; custom configured address pools remain possible |
| Radmin VPN | Install Radmin VPN and join the intended private network | Use its detected virtual adapter; Radmin remote desktop is not needed |
| NetBird | Install NetBird and grant the intended device-to-device access | Use its detected adapter, including configured custom address pools |
| Other VPN | Configure a reachable private route, such as an existing WireGuard tunnel | Explicitly choose the local interface/address; VRC Eye does not certify its provider |
| Relay | Obtain a reachable compatible relay address, port and certificate fingerprint from its operator | Use the existing opaque tunnel with a separate pinned TLS session between peers |

Provider detection uses local adapter information, not an IP prefix alone. A
provider label identifies an apparent adapter; it does not prove account login,
membership, remote reachability or a verified VPN tunnel. An adapter being up
does not mean the other person is connected. Only a completed VRC Eye handshake
establishes the peer connection.

Refresh the adapter list after changing VPN configuration. If multiple matching
addresses exist, select the intended source rather than relying on an arbitrary
first adapter. VPN joins bind the chosen source address. Missing or unusable
adapters stop the requested connection; the app does not install or repair a VPN.
The Other VPN mode requires an explicit local address selection.
Global/unique-local IPv6 addresses are supported where the selected provider
permits them. Scoped and link-local IPv6 addresses are excluded from this release;
Hamachi remains IPv4 mesh only.

VRC Eye does not inspect a provider's account, credentials, network passwords,
contacts, administration API or traffic. It also does not claim to know whether
the provider itself used a direct route or its own relay. Provider-side access
controls and network membership remain separate from VRC Eye's sharing consent.

## Host, invite and join

1. Choose a mode and local adapter, or enter a compatible relay's address, port
   and trusted TLS certificate fingerprint.
2. Review and start hosting. Wait for the listening/ready state.
3. Create a one-use invitation for one person. Treat the invitation as a secret.
4. The other person pastes the invitation into Networking. Review its mode,
   destination, device identity and expiry; select a matching VPN source if needed.
5. Join explicitly, then select the peer in VRC Eye Primary for messages or sharing.

Use one fresh invitation for each guest. Device identities authenticate an
installation, not a VRChat account or a real person. Verify the invitation through
a trusted channel. A connection does not grant automatic access to private data.
Host-to-guest group topology remains unchanged: guests do not gain an automatic
route to each other through the host.

Network calls and TLS handshakes run in transport workers. A failed handshake is
reported as a failed connection, not as evidence that the provider is offline.
The app does not silently change the chosen provider or retry over another route.

## Easy Connect and saved profiles

Easy Connect guides setup using a configured connection profile and fresh
invitations. Save a meaningful profile name with its mode, address, port and, for
Relay, the trusted certificate fingerprint. Load it to review the settings before
starting. Profiles are local preferences, not scheduled jobs or permission grants.

Profiles do not store pairing invitations, private keys, VPN passwords or account
credentials. Joining always needs a fresh invitation; a saved host profile cannot
replay an old pairing secret. A remembered endpoint or certificate pin remains
local connection information and should be treated accordingly.

There is no public VRC Eye Easy Connect service provisioned by this release.
The relay operator can be you, your group or a hosting provider running the
compatible relay. An arbitrary TURN, Tailscale DERP, HTTP proxy or Iroh relay is
not compatible with this relay protocol.

WebRTC and Iroh remain possible future transport engines, not installed options
or hidden fallbacks in 1.19.1. The new provider support reuses the existing pinned
TLS protocol over already configured interfaces.

## Hide my IP from peers

Enable **Hide my IP from peers (relay only)** to permit only the Relay transport.
It rejects LAN, Hamachi and other VPN host/join attempts before starting a
connection. Enabling it during a direct connection ends that connection and its
pending work. The setting persists, while network connections do not.

This policy does not assume that a VPN's private-looking address guarantees IP
anonymity. VPN providers can establish direct connections or disclose endpoint
information to the participating machines. Provider relay fallback is not the
same as VRC Eye's enforced relay-only policy.

In the supported Relay transport, the other VRC Eye peer sees the relay endpoint.
The relay operator still sees client addresses and traffic metadata. Inner
pinned TLS protects application payloads from the relay. A relay outage produces
a disconnected/error state; it never relaxes the policy and connects directly.

This setting concerns connection addresses. It cannot remove an address that
you voluntarily type into a message, erase data previously shared with another
person, or conceal unrelated VRChat/VPN/browser traffic.

## Lifecycle and compatibility

- **Private Mode** stops listeners and peer connections. Local work remains usable.
- Closing the Networking page does not stop the application-owned peer service.
- Demo, startup Safe Mode, inherited Incognito and an account change retain their
  existing connection restrictions. No profile can bypass them.
- Sharing approvals and blocks remain in Primary. A profile or provider never
  overrides a sharing denial or enables automatic publication.
- The ordinary 1.19.0 LAN/Hamachi/Relay invitation format remains supported.
  New provider-mode invitations require 1.19.1 on the receiving side; older
  versions reject unfamiliar modes rather than treating them as LAN.
- Application data schemas remain protocol version 1. Updating the application
  version does not silently migrate private content into online storage.

## Checks on your installation

Test with another device after installing/configuring the provider: host, join,
exchange an explicitly approved Whisper, disconnect, and confirm Private Mode
leaves local records available. Repeat with relay-only enabled to confirm direct
modes are blocked. Native Windows adapter detection, your VPN memberships/routes,
firewall configuration and real internet relay hosting must be checked on the
target machines. Automated coverage is recorded in VALIDATION.md.

## Provider documentation

- Tailscale connections: https://tailscale.com/docs/reference/connection-types
- Tailscale device sharing: https://tailscale.com/docs/features/sharing
- ZeroTier: https://docs.zerotier.com/
- Radmin VPN: https://www.radmin-vpn.com/help/index.html
- NetBird: https://docs.netbird.io/about-netbird/how-netbird-works
- WireGuard: https://www.wireguard.com/quickstart/
- Hamachi: https://vpn.net/

The providers are independently operated products. Their plans, terms and
availability are governed by their own services.

## Shared OSC transport in 1.19.5

**OSC transport** owns the OSC destination and receive addresses, ports, free-port
fallback, optional LAN exposure and OSCQuery subscriptions. These settings are
independent of Eye-to-Eye peer invitations and relay profiles. Loopback is the
default. Discovery is passive; selecting a candidate loads descriptions. Review
its advertised destination, apply transport settings, then connect. Windows
VRChat OSCQuery discovery is normally same-machine; explicit LAN/VPN routing
requires its own review and does not authenticate a UDP sender.

The OSC Controls workspace under **VRC Eye Primary** owns actions and capability
permissions. No peer invitation exposes a raw OSC remote-control interface.
See [OSC_CONTROLS_SETUP.md](OSC_CONTROLS_SETUP.md).
