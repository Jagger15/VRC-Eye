"""Immutable field choices layered over a reviewed native import.

Object fields can be chosen individually. Lists and object/scalar changes are
atomic values; no unreviewed element matching or three-way ancestry is implied.
"""
from copy import deepcopy
from dataclasses import replace
import json
import uuid

from native_library import (Plan, MAX_BATCH_BYTES, canonical, digest, document,
                            fill_missing, validate_record)
from vrcx_sources import stopped

MAX_CHOICES=10000


def key(record):return (record['scope'],record['kind'],record['id'])


def differences(local,incoming,path=()):
    """Presence is separate from null/empty, so deleting a field is explicit."""
    out=[]
    for name in sorted(set(local)|set(incoming)):
        left=name in local;right=name in incoming;a=local.get(name);b=incoming.get(name);field=path+(name,)
        if left and right and isinstance(a,dict) and isinstance(b,dict):out.extend(differences(a,b,field))
        elif not left or not right or canonical(a)!=canonical(b):
            out.append(dict(path=field,local=a,incoming=b,local_present=left,incoming_present=right))
    return out


def base_record(before,incoming,policy):
    if policy=='replace':return deepcopy(incoming)
    if policy in ('keep','merge'):return deepcopy(before)
    merged=fill_missing(before['data'],incoming['data'])
    if before['kind']=='entity' and before['data'].get('name')==before['data'].get('entity_id'):
        merged['name']=incoming['data'].get('name') or merged.get('name')
    return dict(deepcopy(before),data=deepcopy(merged))


def assign(data,path,value,present):
    parent=data
    for segment in path[:-1]:parent=parent[segment]
    if present:parent[path[-1]]=deepcopy(value)
    else:parent.pop(path[-1],None)


def resolve(library,plan,choices,*,stop=None,check=None):
    if not isinstance(plan,Plan) or library._plans.get(plan.id) is not plan or not 0<=library.clock()-plan.created<900:
        raise ValueError('The import review expired, changed or was already used. Prepare it again.')
    if not isinstance(choices,list) or len(choices)>MAX_CHOICES:raise ValueError('Review at most 10,000 field choices at once.')
    pairs={key(a):(a,b) for a,b in json.loads(plan.conflict_records_json)}
    selected={};field_cache={}
    for choice in json.loads(plan.choices_json)+choices:
        stopped(stop)
        if not isinstance(choice,dict) or set(choice)!={'key','path','choice'} or choice['choice'] not in ('local','incoming','policy'):
            raise ValueError('Choose Local, Incoming or Import policy for a reviewed field.')
        if (not isinstance(choice['key'],list) or len(choice['key'])!=3 or any(not isinstance(v,str) for v in choice['key'])
            or not isinstance(choice['path'],list) or not choice['path'] or any(not isinstance(v,str) for v in choice['path'])):
            raise ValueError('Choose a field from the current conflict review.')
        ref=tuple(choice['key']);path=tuple(choice['path'])
        if ref not in pairs:raise ValueError('This record is not in the conflict review.')
        if ref not in field_cache:field_cache[ref]={tuple(r['path']):r for r in differences(pairs[ref][0]['data'],pairs[ref][1]['data'])}
        if path not in field_cache[ref]:raise ValueError('This field is not in the conflict review.')
        ident=(ref,path)
        if choice['choice']=='policy':selected.pop(ident,None)
        else:selected[ident]=choice['choice']
    if len(selected)>MAX_CHOICES:raise ValueError('Split this import into smaller field reviews.')
    grouped={}
    for (ref,path),take in selected.items():grouped.setdefault(ref,[]).append((path,take))
    records={key(r):r for r in plan.records if key(r) not in pairs}
    expected={tuple(k):v for k,v in plan.expected if tuple(k) not in pairs}
    with library.connect() as db:
        db.execute('BEGIN')
        for ref,(before,incoming) in pairs.items():
            stopped(stop)
            if check:check()
            current=library._find(db,*ref)
            if not current or current['fingerprint']!=digest(before):raise ValueError('A local conflict value changed after review. Prepare the import again.')
            if db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',ref).fetchone():raise ValueError('A reviewed record was forgotten. Prepare again.')
            fields=field_cache.get(ref,{})
            defaults={key(r):r for r in json.loads(plan.merge_defaults_json)} if plan.policy=='merge' else {}
            draft=deepcopy(defaults.get(ref)) if ref in defaults else base_record(before,incoming,plan.policy)
            manual=[]
            for path,take in grouped.get(ref,[]):
                row=fields[path];assign(draft['data'],path,row[take],row[take+'_present'])
                manual.append(dict(path=list(path),choice=take))
            if canonical(draft['data'])==canonical(before['data']):continue
            if manual:
                draft['provenance']=dict(draft['provenance'],field_resolution={
                    'policy':plan.policy,'incoming':incoming['provenance'],'fields':manual})
            records[ref]=validate_record(draft);expected[ref]=digest(before)
    if len(document(list(records.values())).encode())>MAX_BATCH_BYTES:raise ValueError('Resolved values exceed the 32 MiB review limit. Split the import.')
    stopped(stop)
    if check:check()
    if library._plans.get(plan.id) is not plan or not 0<=library.clock()-plan.created<900:raise ValueError('The original review changed or expired. Prepare again.')
    resolved=replace(plan,id=str(uuid.uuid4()),records_json=document(list(records.values())),
        expected_json=document([[list(k),v] for k,v in expected.items()]),
        choices_json=document([dict(key=list(k),path=list(p),choice=v) for (k,p),v in sorted(selected.items())]))
    library.discard(plan);library._plans[resolved.id]=resolved
    return resolved
