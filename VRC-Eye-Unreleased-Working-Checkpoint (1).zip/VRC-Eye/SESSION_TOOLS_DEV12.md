# VRC Eye 1.21.0 — Development 12

Open **Session tools…** near the top of the sidebar. The new window has Plans, Session, Audio, Composer, Diagnostics and Mascot tabs. Creator hierarchy browsing is inside **Players & avatars → Avatars → Preview**.

This source build adds a bounded desktop implementation for each of the 25 accepted proposal areas. The table specifies the working scope and the extensions still open; it does **not** mark every optional idea or the full ARC/VRCX roadmap complete. Existing Development 11 picture-cache/search fixes and all earlier work are retained.

## Start and use

Extract the complete ZIP to a new folder. On Windows run **Start.cmd**; on Linux run **Start.sh**. Python 3.10+ with Tk is required. These launchers prepare the app-local environment. This is runnable source, not a compiled executable or signed installer.

For soundboard playback, open Media & Audio, discover named devices, choose your monitor/output and start the desired route. You may start an output-only route without a capture input. Load a clip in Session tools → Audio, review its preflight, then preview or explicitly arm/review outgoing playback. Stop all clears clip/event arming. The selected outgoing endpoint must still be configured in VRChat by the user.

Typed composition works without recognition. Optional speech needs **requirements-speech.txt** installed in the same app environment plus a user-selected extracted local Vosk model. Windows: `.recovery-env\Scripts\python.exe -m pip install -r requirements-speech.txt`. Linux: `.recovery-env/bin/python -m pip install -r requirements-speech.txt`. Choose a named microphone in Media & Audio. Hold the Composer button, release to finish the private draft, edit it, review the segments and confirm sending through the existing OSC permissions. No model downloads or unattended sends occur. Transcription arms no new output route; previously enabled microphone routes remain active.

New card collections are scoped to the signed-in account, or the explicit signed-out shared workspace. Each type holds up to 100 cards/96 KiB. Local screenshots are linked and fingerprinted; originals are not copied into a backup. Audio and image files must remain at their reviewed local paths. Privacy/account changes cancel pending work and clear displayed private data.

## Accepted proposal status

| # | Proposal | Added behavior | Remaining scope / prerequisite |
|---|---|---|---|
| 1 | Soundboard | Audio tab: bounded WAV/MP3/FLAC/OGG preflight, saved clip list, private preview, separately armed outgoing route, loop and Stop all on the shared mixer. | Folder scanning, recording and per-clip button-grid customization remain later refinements. |
| 2 | Avatar Tryout Board | Plans → tryouts: stable IDs, Keep/Maybe/Pass, notes, starting-avatar bookmark, catalog pictures or verified local screenshots, previous-card comparison and Avatar Library handoff. | Synchronized dual OBJ views and automatic/avatar-external appearance substitution are not included. |
| 3 | Known-creator browsing | Plans: exact author-ID lookup across retained native metadata/favorites/imports plus Avatar Library observations, deduplicated by avatar ID; show sources and add a tryout. | A complete live creator portfolio, an external creator directory and a one-click action on every legacy result surface are not implemented. |
| 4 | Quick controls | Session: reorderable saved pins for existing workspaces, DND and shared Stop controls; visible effective state. | The existing OSC deck owns live typed controls. A new arbitrary macro editor, detached control deck and extra sliders are not added. |
| 5 | Integration readiness | Diagnostics: bounded current shared-owner states, check times, transition history and suggested next workspaces. | This is a practical initial view, not a complete capability/dependency graph for every provider. |
| 6 | Settings history / restore | Session: old/new values and source for ten desktop presentation/notification fields, per-account history, reviewed undo that preserves later conflicting edits. | Other independent settings stores, authentication and output authority are outside this history. |
| 7 | Feature cost view | Diagnostics: per-page callback counts, elapsed/mean/max wall time, rate and slow-call count; reset and bounded export. | Wall time is not process CPU attribution, proof of a cause, or a promised VRChat FPS improvement. |
| 8 | Private event sounds | Audio: explicitly enabled decoded cue for already permitted notification batches, private monitor only, existing quiet/DND/category/ownership checks and burst cooldown. | One selected session cue; per-type libraries, observed mute cues and paired peer cue IDs remain extensions. |
| 9 | Intermission card | Session: manual/new-log transition view, elapsed time, checklist, known-world picture and optional explicitly played private cue; dismiss or close after observed player activity. | No fabricated loading percentage or game-audio/UI replacement; log activity is not verified loading completion. |
| 10 | Custom mascot packs | Mascot: bounded data-only local PNG plus plain phrases, preview, hash-checked Home presentation and built-in rollback. | Expression maps and private sound variations require a fuller pack format; missing/changed images fall back. |
| 11 | Automatic Eye efficiency | Hidden/minimized mode reduces optional presentation cadence while preserving the selected power preference and service owners. | Comprehensive sensor throttling, unfocused-window policies and VR/mobile consumer coordination remain broader work. |
| 12 | Avatar setup cards | Plans → setup: posture/provider/frame/offset details, known-good state, review date/version, notes and verified screenshot. | Automatic revision/device mismatch prompts and direct typed links to every OSC/SpaceCal record remain refinements; no game calibration writes. |
| 13 | Creator hierarchy browser | Avatar Creator → Preview: stable-ID tree, component/name search, breadcrumbs, selected subtree, previous-manifest component/name/parent changes, removed nodes and flat fallback. | This is creator-declared data, not a live game hierarchy or a real serialized Unity dependency graph. |
| 14 | OSC ignored-input reasons | Diagnostics: rate/source-policy/queue/malformed counters, last times, rolling minute buckets, transport generation and configured budgets. | Reasons cover the shared transport; direct traffic outside Eye is not monitored. |
| 15 | Accessible private composer | Composer: typed/pasted draft, Unicode grapheme-aware UTF-16/line splitting, reviewed paced OSC segments, cancel unsent work; optional local Vosk hold-to-transcribe on the selected shared microphone. | Vosk and an extracted local model are optional prerequisites. Native ASR, VR subtitles/haptics and release-to-send require further acceptance/design. |
| 16 | Contact/route feedback | Diagnostics: current managed-route raw/transformed samples, transform steps, edge classification, route status and suppression reason alongside existing simulator tools. | No force, tactile feedback or broad physical haptic output is enabled; hardware-specific output remains conditional. |
| 17 | World comfort cards | Plans → comfort: stairs/seated/effects/audio/control notes, world revision/date, screenshot and saved map/waypoint references. | Expanded creator-owned world/Udon export schemas and validated frame-specific map guidance are not implemented. |
| 18 | Compact audio status | Audio: compact pin reports shared capture/outgoing-route state, meters/limiter metrics and dropouts; mic check and device selection use the existing Audio panel. | Meter activity is not proof that VRChat or another person heard the output. |
| 19 | Named session presets | Session: Quiet/Social/Creator/custom supported-setting presets, exact before/after preview and temporary restore that preserves subsequent edits. | No presets grant output, startup, network or process authority; unrelated store settings remain outside the preset. |
| 20 | World outing board | Plans → outings: persistent ordered world cards, planning notes, state-change history, map references and the existing fresh World Visits handoff. | Game assets are not prefetched. Multiple itinerary containers and bulk metadata preparation remain refinements. |
| 21 | Interrupted-session return plan | Session: prepare a current observed instance for fifteen minutes, see existing recovery status, then explicitly reinspect before the existing join review. | Automatic private-instance rejoin / one-shot delegation is not enabled. |
| 22 | Media bookmark context | Audio: reviewed public Vimeo oEmbed title/author, optional allowlisted artwork preview, selected-log URL evidence and save into the existing Media library. Existing YouTube and LibreTranslate remain in Social optional providers. | Broader providers and generalized resolution/error correlation remain incomplete; no video downloader or player is bundled. |
| 23 | Photo shot list | Plans → shots: setup notes, state/history and retake state; request through existing armed OSC camera controls; associate a stable verified image with path/bytes/SHA-256 receipt. | Association is explicit and does not prove that a particular camera request caused the file; unattended per-shot matching remains a refinement. |
| 24 | What Eye sent and why | Diagnostics: bounded redacted API transport category/method/status/duration and explicit audio/composer/provider receipts, current grants and export. | This covers instrumented Eye work; it is not a packet sniffer, complete process audit or evidence about other applications. |
| 25 | Event-host worksheet | Plans → hosts: expected helper IDs/roles, notes, manual state, current stable-ID roster observation and follow-up history. | The existing roster owns tags/roles. No automated moderator powers, whitelist enforcement or attendance certainty is implied. |

## Optional ideas retained for later work

- Actual legacy AvatarSearcher/NativePreferences/ReAvatar/ReModCE JSON, FavCat text and instance-history adapters remain conditional on real user data to preview and verify. No live VRCX database or BinaryFormatter migration was added.
- Custom peer event cue identifiers, richer mascot expressions, paired model previews, a creator directory and VR subtitle/haptic delivery need explicit data/provider contracts and native acceptance.
- Quick-control macro/sliders, per-event clip mapping, direct typed setup links, frame-validated waypoint handoff, richer structured comfort checklists, clip-folder scanning and automatic shot/file correlation remain refinements.
- Rich world hierarchy/Udon reference exports require an actual creator-owned export and a schema extension. Existing tags/pronouns, saved map waypoints, crash recovery, photo metadata and ordinary OSC control/simulator features remain shared owners.

## Engineering and validation

New code is original desktop coordination and data models. Uploaded mods, executable payloads, build scripts and their service endpoints were not run or copied into Eye. No release publication, signed auto-updater, game injection or live VRChat write was performed.

The new tests cover scoped persistence, reordering and state history, cancellation/privacy changes, restore conflicts, source deduplication, grapheme boundaries, paced chat cancellation, clip decoding/private routing and lifecycle, stale speech workers, input-drop counters, hierarchy comparisons, provider validation and mascot/photo bounds. A headless widget adapter also constructs every new screen and saves real cards. Exact final totals and excluded native tests are in VALIDATION_1_21.md.

Native Tk/Windows/Linux display, actual audio endpoints, Vosk recognition, Unity, SteamVR, tray/Discord and live-service behavior remain unverified here. Xvfb could not open its local socket, and the execution policy rejected an elevated native test run. Native test files remain included for a suitable machine.

## Reference contracts

- Public Vimeo oEmbed: https://developer.vimeo.com/api/oembed/videos — title/author/artwork metadata only; returned HTML is not used.
- SoundFile: https://python-soundfile.readthedocs.io/en/latest/index.html — short local clip decoding.
- Vosk: https://alphacephei.com/vosk/ — optional local recognition; no bundled model.
- regex: https://pypi.org/project/regex/ — Unicode grapheme segmentation.

Full ARC/VRCX gap report: **ARC_VRCX_REMAINING_DEV12.md**. The application version remains 1.21.0 and the development checkpoint advances to 12.
