"""Explicitly associate an imported photo reference with selected current bytes.

VRCX's cache has no original fingerprint: this records a reviewed association,
never a claim that the chosen file is byte-identical to the historical image.
"""
from dataclasses import dataclass,field
import json
import sqlite3
import time
from native_library import canonical
from photo_files import inspect_photo,verified_data
from photo_metadata import inspect_metadata


@dataclass(frozen=True)
class Review:
    source_json:str=field(repr=False)
    observation_json:str=field(repr=False)
    scope:str
    world:str
    evidence:str
    expires:float


class PhotoReferenceLink:
    def __init__(self,library,service):self.library,self.service=library,service;self.review=None

    def prepare(self,source,path,*,stop=None):
        current=self.library.get(source['scope'],'photo-reference',source['id'])
        if current!=source:raise ValueError('The imported reference changed. Refresh it before linking.')
        scope=self.service.scope()
        if source['scope'] not in ('shared',scope):raise ValueError('Switch to the reference account before selecting a photo.')
        token=self.service.token();self.service.check(token,stop)
        observation=inspect_photo(path,stop=stop);raw=verified_data(observation,stop=stop)
        report=inspect_metadata(raw) if observation['format']=='PNG' else {'candidates':[],'conflicts':[]}
        if report['conflicts']:raise ValueError('This photo contains conflicting declarations. Resolve them before linking a historical reference.')
        declared=source['data'].get('declared',{});world=declared.get('world_id','')
        worlds={r['value'] for r in report['candidates'] if r['field']=='world_id'}
        if worlds and world and worlds!={world}:raise ValueError('The selected file declares a different world from the imported reference.')
        evidence='Matching world declaration' if world and worlds=={world} else 'Manual association; metadata cannot establish a match'
        # Thumbnail bytes are not part of the review payload; inspect again on
        # commit and compare the exact fingerprint and SHA-256 before import.
        observed={k:observation[k] for k in ('path','sha256','fingerprint','width','height','format')}
        self.service.check(token,stop)
        self.review=Review(canonical(source),canonical(observed),scope,world,evidence,time.monotonic()+300)
        return self.review

    def commit(self,review):
        if review is not self.review or time.monotonic()>=review.expires:raise ValueError('Photo association review expired or was already used.')
        self.review=None
        source=json.loads(review.source_json);observation=json.loads(review.observation_json)
        def work(scope,token,stop,progress):
            self.service.check(token,stop)
            if scope!=review.scope:raise ValueError('The photo destination workspace changed.')
            current=self.library.get(source['scope'],'photo-reference',source['id'])
            if current!=source:raise ValueError('The historical reference changed. Review it again.')
            observed=inspect_photo(observation['path'],expected=observation['fingerprint'],stop=stop)
            if observed['sha256']!=observation['sha256']:raise ValueError('The selected photo bytes changed after review.')
            self.service.check(token,stop)
            photo,state=self.service.store.observe(scope,observed)
            # The Photos catalog and native library have independent commit
            # boundaries. A failed second commit remains explicit and retryable.
            try:
                self.service.check(token,stop)
                if self.library.get(source['scope'],'photo-reference',source['id'])!=source:
                    raise ValueError('The reference changed during photo import.')
                data=dict(source['data'],linked=True,photo_id=photo,photo_scope=scope,
                          selected_sha256=observed['sha256'],link_evidence=review.evidence,
                          coverage='Reviewed association to currently verified bytes; historical byte identity unknown')
                incoming=dict(source,data=data)
                plan=self.library.prepare([incoming],policy='replace',source='Selected photo association')
                def check():
                    self.service.check(token,stop)
                    if self.library.get(source['scope'],'photo-reference',source['id'])!=source:
                        raise ValueError('The historical reference changed before association commit.')
                self.library.commit(plan,stop=stop,check=check)
            except (ValueError,OSError,sqlite3.Error) as error:
                return {'photo':photo},'Partial','Photo catalog import completed; reference association did not complete. Refresh and review the same file again. '+str(error)[:300]
            return {'photo':photo,'scope':scope},'Complete','Selected photo imported and reference associated. Historical byte identity remains unknown; existing photo notes and manual context were preserved.'
        return work
