"""Explicit exact-byte rules, atomic reference batches and conditional mass undo.

Rules run only during the existing user-started matching scan. They never start
folder watchers, infer ownership from names, or move/delete original files.
"""
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import json
import time
import uuid
from avatar_library import scope_id,stamp,_TABLE
from avatar_folder_discovery import validate_source,_candidate_path
from avatar_library_files import checked_stream,validate_evidence

RULES='avatar_association_rules_v21'
RECEIPTS='avatar_association_receipts_v21'


def encoded(value):
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
    if len(raw.encode())>2*1024*1024:raise ValueError('Association batch exceeds 2 MiB.')
    return raw


def schema(db):
    db.execute(f'CREATE TABLE IF NOT EXISTS {RULES}(scope TEXT NOT NULL,id TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(scope,id))')
    db.execute(f'CREATE TABLE IF NOT EXISTS {RECEIPTS}(scope TEXT NOT NULL,id TEXT NOT NULL,created REAL NOT NULL,data TEXT NOT NULL,PRIMARY KEY(scope,id))')


def rows(library,account,*,receipts=False):
    account=scope_id(account)
    with library.store._transaction() as db:
        schema(db)
        return [json.loads(r[0]) for r in db.execute(f'SELECT data FROM {RECEIPTS if receipts else RULES} WHERE scope=? ORDER BY '+('created DESC' if receipts else 'id'),(account,))]


def enable(library,account,source,record,*,check=lambda:None):
    account=scope_id(account);check();validate_source(source)
    # Pin the entire original recorded association; later changes require a review.
    if library.record(account,'file',record['id'])!=record:raise ValueError('The recorded association changed. Scan and review again.')
    identifier=str(uuid.uuid5(uuid.NAMESPACE_URL,encoded([source.path,record['id']])))
    value=dict(id=identifier,scope=account,folder=source.path,identity=list(source.identity),anchor=deepcopy(record),
               enabled=True,revision=uuid.uuid4().hex,created=stamp(library.clock))
    with library.store._transaction() as db:
        schema(db)
        if library._load(db,account,'file',record['id'])!=record:raise ValueError('Association changed during review.')
        count=db.execute(f'SELECT count(*) FROM {RULES} WHERE scope=? AND id<>?',(account,identifier)).fetchone()[0]
        if count>=64:raise ValueError('This workspace has reached its 64-rule limit. Remove an unused rule first.')
        db.execute(f'INSERT OR REPLACE INTO {RULES} VALUES(?,?,?)',(account,identifier,encoded(value)))
        check();validate_source(source)
    library.revision+=1
    return value


def revoke(library,account,identifier=None,*,check=lambda:None,remove=False):
    """None revokes every rule in this scope, including rules for other folders."""
    account=scope_id(account);check()
    with library.store._transaction() as db:
        schema(db)
        selected=db.execute(f'SELECT id,data FROM {RULES} WHERE scope=?'+(' AND id=?' if identifier else ''),(account,identifier) if identifier else (account,)).fetchall()
        if not selected:raise ValueError('No matching association rules in this workspace.')
        for ref,raw in selected:
            if remove:db.execute(f'DELETE FROM {RULES} WHERE scope=? AND id=?',(account,ref))
            else:
                value=json.loads(raw);value.update(enabled=False,revision=uuid.uuid4().hex)
                db.execute(f'UPDATE {RULES} SET data=? WHERE scope=? AND id=?',(encoded(value),account,ref))
        check()
    library.revision+=1
    return len(selected)


def prepare(library,account,source,items):
    account=scope_id(account);validate_source(source)
    if not isinstance(items,list) or len(items)>128:raise ValueError('Use one bounded matching scan of at most 128 files.')
    active=[r for r in rows(library,account) if r['enabled'] and r['folder']==source.path and r['identity']==list(source.identity)]
    changes=[];skipped=[];seen=set()
    for item in items:
        evidence=item.get('evidence')
        if not evidence:continue
        evidence=validate_evidence(evidence)
        matches=[r for r in active if (r['anchor']['sha256'],r['anchor']['size'])==(evidence['sha256'],evidence['size'])]
        if not matches:continue
        targets={(r['anchor']['avatar_id'],r['anchor'].get('build_id',''),r['anchor']['role']) for r in matches}
        if len(targets)!=1:
            skipped.append(dict(file=item['name'],reason='Conflicting enabled rule targets; review or revoke rules.'));continue
        # Duplicate rules with the same target are equivalent; prefer a fresh anchor.
        rule=next((r for r in matches if library.record(account,'file',r['anchor']['id'])==r['anchor']),None)
        if rule is None:
            skipped.append(dict(file=item['name'],reason='Recorded anchor changed or was removed; review the rule again.'));continue
        avatar,build,role=next(iter(targets))
        identifier=str(uuid.uuid5(uuid.NAMESPACE_URL,'vrc-eye-file:'+avatar+':'+build+':'+evidence['path']+':'+role))
        if identifier in seen or library.record(account,'file',identifier) is not None:continue
        if str(_candidate_path(source,item['candidate']))!=evidence['path'] or item['candidate']['fingerprint']!=evidence['fingerprint']:
            raise ValueError('Candidate evidence changed. Scan again.')
        seen.add(identifier);changes.append(dict(id=identifier,evidence=evidence,rule=rule))
    return dict(scope=account,source=asdict(source),rules=active,changes=changes,skipped=skipped,expires=time.monotonic()+300)


def summary(plan):
    lines=[f"{len(plan['changes'])} new local references; {len(plan['skipped'])} rule conflicts/stale anchors.",
           'Existing references are never overwritten. Original files are not moved or deleted.']
    for change in plan['changes']:
        a=change['rule']['anchor'];lines.append(f"{Path(change['evidence']['path']).name} → {a['avatar_id']} · {a.get('build_id') or 'avatar only'} · {a['role']}")
    lines.extend(r['file']+': '+r['reason'] for r in plan['skipped'])
    return '\n'.join(lines)


def apply(library,plan,*,check=lambda:None):
    from avatar_folder_discovery import Source
    plan=deepcopy(plan);account=scope_id(plan['scope']);check()
    if time.monotonic()>plan['expires']:raise ValueError('Matching evidence expired. Run a fresh scan.')
    source=Source(plan['source']['path'],tuple(plan['source']['identity']));validate_source(source)
    changes=plan['changes']
    if not changes:return None
    if len(changes)>128:raise ValueError('Association batch exceeds 128 files.')
    receipt=dict(id=uuid.uuid4().hex,scope=account,created=stamp(library.clock),entries=[],undone=[])
    def current_files():
        check();validate_source(source)
        for change in changes:
            evidence=validate_evidence(change['evidence']);path=Path(evidence['path'])
            if not path.is_relative_to(Path(source.path)):raise ValueError('A candidate is outside the reviewed folder.')
            with checked_stream(path,expected=evidence['fingerprint']):pass
    current_files()
    with library.store._transaction() as db:
        schema(db)
        current_rules=[json.loads(r[0]) for r in db.execute(f'SELECT data FROM {RULES} WHERE scope=? ORDER BY id',(account,))]
        current_rules=[r for r in current_rules if r['enabled'] and r['folder']==source.path and r['identity']==list(source.identity)]
        if current_rules!=plan['rules']:raise ValueError('Folder rules changed during matching. Run a fresh scan.')
        for change in changes:
            rule=change['rule'];anchor=rule['anchor']
            raw=db.execute(f'SELECT data FROM {RULES} WHERE scope=? AND id=?',(account,rule['id'])).fetchone()
            if not raw or json.loads(raw[0])!=rule or not rule['enabled'] or rule['folder']!=source.path or rule['identity']!=list(source.identity):
                raise ValueError('An association rule was changed or revoked. Nothing was applied.')
            if library._load(db,account,'file',anchor['id'])!=anchor:raise ValueError('The recorded association changed. Scan and review again.')
            evidence=validate_evidence(change['evidence'])
            if (evidence['sha256'],evidence['size'])!=(anchor['sha256'],anchor['size']):raise ValueError('Rule byte evidence does not match.')
            if library._load(db,account,'file',change['id']) is not None:raise ValueError('A candidate was already registered. Scan again; existing edits are preserved.')
            row=library._register_file_into(db,account,anchor['avatar_id'],evidence,build_id=anchor.get('build_id',''),role=anchor['role'],provenance='Enabled exact-byte rule '+rule['id'])
            if row['id']!=change['id']:raise ValueError('Candidate association identity changed.')
            receipt['entries'].append(dict(rule_id=rule['id'],after=row))
        current_files()
        db.execute(f'INSERT INTO {RECEIPTS} VALUES(?,?,?,?)',(account,receipt['id'],time.time(),encoded(receipt)))
        # Bounded local history: newest 100 receipts within 8 MiB.
        used=0
        for n,(identifier,size) in enumerate(db.execute(f'SELECT id,length(CAST(data AS BLOB)) FROM {RECEIPTS} WHERE scope=? ORDER BY created DESC,id DESC',(account,)).fetchall()):
            used+=size
            if n>=100 or used>8*1024*1024:db.execute(f'DELETE FROM {RECEIPTS} WHERE scope=? AND id=?',(account,identifier))
        check()
    library.revision+=1
    return receipt


def prepare_undo(library,account,identifier):
    account=scope_id(account);receipt=next((r for r in rows(library,account,receipts=True) if r['id']==identifier),None)
    if receipt is None:raise ValueError('That association receipt is unavailable in this workspace.')
    eligible=[];preserved=[]
    for entry in receipt['entries']:
        after=entry['after']
        if after['id'] in receipt['undone']:continue
        if library.record(account,'file',after['id'])==after:eligible.append(after)
        else:preserved.append(after['id'])
    if not eligible:raise ValueError('No unchanged references remain to undo. Later edits and removed records are preserved.')
    return dict(scope=account,receipt=receipt,eligible=eligible,preserved=preserved)


def undo(library,plan,*,check=lambda:None):
    plan=deepcopy(plan);account=scope_id(plan['scope']);receipt=plan['receipt'];check()
    with library.store._transaction() as db:
        schema(db);saved=db.execute(f'SELECT data FROM {RECEIPTS} WHERE scope=? AND id=?',(account,receipt['id'])).fetchone()
        if not saved or json.loads(saved[0])!=receipt:raise ValueError('Undo receipt changed. Review it again.')
        for after in plan['eligible']:
            if not any(e['after']==after for e in receipt['entries']) or after['id'] in receipt['undone']:
                raise ValueError('That reference is not part of this undo review.')
            if library._load(db,account,'file',after['id'])!=after:raise ValueError('A reference changed during undo review. Nothing was removed.')
            db.execute(f"DELETE FROM {_TABLE} WHERE scope=? AND kind='file' AND id=?",(account,after['id']))
        receipt['undone']+= [r['id'] for r in plan['eligible']]
        db.execute(f'UPDATE {RECEIPTS} SET data=? WHERE scope=? AND id=?',(encoded(receipt),account,receipt['id']))
        check()
    library.revision+=1
    return len(plan['eligible'])
