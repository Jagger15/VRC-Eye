"""Lazy, account-scoped role lookup using API IDs and permissions, never titles."""
from copy import deepcopy
from urllib.parse import quote
import re
from player_api import context,check_context,lock,stamp
from player_session_model import exact_id,ROLE_ORDER
from vrchat_api import APIError


def cached(client,path,expected,*,many=False,ttl=300,stop=None,progress=None,checks=None):
    key=("player-roles",expected,path)
    lock(client,stop)
    try:
        check_context(client,expected,stop)
        found=client.cache.get(key)
        if found and 0<=client.clock()-found[0]<ttl:
            if checks is not None:checks.append(found[2])
            return deepcopy(found[1])
        client._wait_metadata(stop,progress);check_context(client,expected,stop)
        data=client._request(path,expect_list=many);check_context(client,expected,stop)
        if many and (not isinstance(data,list) or len(data)>500):raise ValueError("Too many group roles.")
        observed=stamp();client.cache[key]=(client.clock(),deepcopy(data),observed)
        if checks is not None:checks.append(observed)
        if len(client.cache)>200:client.cache.pop(next(iter(client.cache)))
        return data
    finally:client.lock.release()


def member_roles(group,member,roles,user,group_id):
    if group.get("id")!=group_id or member.get("groupId")!=group_id or member.get("userId",member.get("user",{}).get("id"))!=user:raise ValueError("Group member identity mismatch.")
    result=[]
    if group.get("ownerId")==user:result.append("Group Owner")
    if member.get("membershipStatus")!="member":return tuple(result)
    ids=member.get("roleIds",[])
    if not isinstance(ids,list):raise ValueError("Invalid group membership roles.")
    permissions=set()
    for role in roles:
        if role.get("groupId")!=group_id or not (role.get("id") in ids or role.get("defaultRole") is True):continue
        p=role.get("permissions",[])
        if isinstance(p,list):permissions.update(x for x in p if isinstance(x,str))
    if "*" in permissions:result.append("Group Admin")
    if "group-instance-moderate" in permissions or "*" in permissions:result.append("Group Moderator")
    return tuple(result)


def read_roles(client,world,instance,user,*,stop=None,progress=None):
    exact_id(world,"wrld");exact_id(user,"usr")
    if not isinstance(instance,str) or not 1<=len(instance)<=1024 or any(ord(c)<32 for c in instance):raise ValueError("An exact observed instance is required.")
    expected=context(client);location=world+":"+instance;checks=[]
    def get(path,*,many=False,ttl=120):return cached(client,path,expected,many=many,ttl=ttl,stop=stop,progress=progress,checks=checks)
    data=get("instances/"+quote(location,safe=""))
    if not isinstance(data,dict) or data.get("worldId",data.get("world",{}).get("id"))!=world or data.get("instanceId",data.get("id"))!=instance:raise ValueError("API instance did not match the observed world and instance.")
    result={};observations={}
    def role(uid,name,observed=None,ttl=300):
        try:exact_id(uid,"usr")
        except ValueError:return
        result.setdefault(uid,[]).append(name)
        observations.setdefault(uid,[]).append((name,observed or checks[-1],ttl))
    role(data.get("world",{}).get("authorId"),"World Creator",ttl=3600)
    if data.get("type")!="group":role(data.get("ownerId"),"Instance Owner")
    group_id=data.get("ownerId") if data.get("type")=="group" else None
    incomplete=""
    if group_id:
        exact_id(group_id,"grp")
        try:
            group=get("groups/"+group_id)
            role(group.get("ownerId"),"Group Owner")
            roles=get("groups/"+group_id+"/roles",many=True)
            roles_at=checks[-1]
            member=get("groups/"+group_id+"/members/"+user)
            for name in member_roles(group,member,roles,user,group_id):role(user,name,min(roles_at,checks[-1]))
        except APIError:
            check_context(client,expected,stop)
            incomplete="Group permissions were unavailable; group staff remains unknown."
    profile=get("users/"+user)
    if profile.get("id")!=user:raise ValueError("API user identity mismatch.")
    if "admin_moderator" in profile.get("tags",[]):role(user,"VRChat Staff")
    check_context(client,expected,stop)
    return dict(account=expected,world=world,instance=instance,checked=client.clock(),stamp=min(checks),roles={u:tuple(r for r in ROLE_ORDER if r in names) for u,names in result.items()},observations=observations,selected=user,incomplete=incomplete)


def read_relationship(client,user,*,stop=None,progress=None):
    exact_id(user,"usr");expected=context(client);checks=[]
    data=cached(client,"user/"+user+"/friendStatus",expected,ttl=60,stop=stop,progress=progress,checks=checks)
    if not isinstance(data,dict) or any(type(data.get(k)) is not bool for k in ("isFriend","incomingRequest","outgoingRequest")):raise ValueError("VRChat did not return a supported friend status.")
    state="Friend" if data["isFriend"] else "Request received" if data["incomingRequest"] else "Request sent" if data["outgoingRequest"] else "Not friend"
    return dict(kind="relationship",account=expected,user=user,state=state,stamp=min(checks))
