# VRC Eye Avatar Toolkit 1.19.3

The optional package in `Unity/AvatarToolkit` authors a selected avatar in your own Unity project. The desktop creator workspace works without Unity. This package is experimental: the release's Python checks inspect contracts; they do not compile Unity C#, build an avatar, or verify Contacts, OSC, rendering, shaders, or an uploaded avatar.

## Install locally

1. Back up the project or commit it to source control. Use a separate test copy for this first toolkit release.
2. Open an existing VRChat **Avatars** project in its supported Unity editor. The authoring target is SDK **3.10.x** and Unity **2022.3**. The tool checks the installed SDK and probes required serialized fields before applying changes; it does not upgrade packages. Compatibility with every patch is not asserted as tested.
3. Copy `Unity/AvatarToolkit` to `Packages/com.vrceye.avatar-toolkit` as an embedded local package, or use Package Manager's **Add package from disk** and select its `package.json`. Its `vpmDependencies` records the SDK dependency for VPM tooling. This release does not publish a VPM repository/download URL and does not invent author contact details; local installation requires the SDK already installed through Creator Companion.
4. Open **VRC Eye → Avatar Toolkit**. Select the avatar's root descriptor in a **saved scene with no pending scene edits**, confirm permission, and choose an anchor inside that avatar. Left wrist, right wrist and chest buttons suggest humanoid anchors; generic rigs use a manual transform. Position, orientation, visual size and touch radius are separate controls.
5. Choose modules and press **Analyze and preview proposed changes**. Review parameters, costs and the exact change policy, then **Install reviewed plan**. Save the scene after installation.

There is no custom runtime script attached to avatars, no client modification, no uploader, no blueprint-ID detachment, no automatic SDK change, and no remote editor listener. This first backend creates explicit source assets; it does not register an NDMF/Modular Avatar build pass. Projects using those processors must validate their actual generated output and rename mappings independently.

## Included finite authoring modules

| Module | Generated authoring behavior |
| --- | --- |
| Wrist | Adjustable rigid primitive shell; does not animate the rig. |
| Status | Small finite-state symbols for selected presentation, separate from VRChat account status. |
| Safety | Self-only local Contact and expression-menu request button, plus independently reported applied-profile indicator. |
| Battery | Normalized meter and a separate validity/unknown representation. |
| Streamer | Finite recording state and source validity, not process-detection claims. |
| Music | Bounded, non-flashing meter driven by normalized selected-source intensity. No Unity audio capture. |
| Camera | Local shutter-request Contact/menu button and separate touch/acceptance feedback. Acceptance is not capture completion. |
| Availability | Manual quiet toggle and distinct read-only native AFK indicator. Neither sets native VRChat DND. |
| Connection | Changing heartbeat with an initial unconfirmed state and approximately five-second animator timeout. |
| Hardware | Normalized provider meter plus validity; no device identifiers. |
| Resource | Finite observed pressure warning plus validity; no attribution of blame. |
| Media | Finite playback-state indicator plus validity; no track names or paths. |

These are functional primitive starter modules, not polished commissioned prefab art or universal integrations. Source materials use the SDK's `VRChat/Mobile/Diffuse` shader. Missing required shaders/components stop installation. The same parameter layout can be exported for Windows, Android and iOS, but choosing a platform label does not prove a platform build passed.

All generated custom parameters default to **unsaved, unsynchronized, private** and zero/false. Manual `EYE_In_Quiet` is a non-ephemeral preference eligible for reviewed local presets; provider state, heartbeat and requests remain ephemeral. The original expression ordering is preserved and new definitions are appended. A changing-heartbeat dependency is always included; provider visuals and reported action feedback become hidden when that heartbeat expires. Manual controls and native AFK remain available. Validity flags further distinguish missing data from a measured zero while the link is fresh. Animator culling or suspension can prevent the timeout from evaluating: these are best-effort displays, never authenticated safety signals.

Generated displays are gated by the built-in read-only `IsLocal` parameter. Test actual local, remote, mirror, photo and capture paths before relying on presentation privacy. Unsynchronized parameters alone do not establish owner-only rendering. Your own recording can still capture a local display. The toolkit does not expose a public-data toggle; deliberate public variants require a reviewed creator-authored contract.

## Contact and expression-menu controls

Contacts are **Constant** receivers with `allowSelf=true`, `allowOthers=false`, `localOnly=true`, collision tag `Finger`, and an independently configured radius. Local Only and Self Only are distinct settings. Contact tags do not authenticate a person. The `EYE_Out_Camera` and `EYE_Out_Safety` Boolean requests remain high while touched; they are not next-frame `OnEnter` pulses. The broker must verify routing and apply hold/debounce, rising-edge detection, cooldown and release-to-rearm. A held contact must not repeatedly take photos. The matching expression-menu buttons are accessible alternatives.

The visible states mean touch detected and broker acceptance/applied report. There is no fabricated acknowledgment or capture completion. `EYE_In_CameraAccepted` declares semantic `accepted_request:request_photo` and is acceptance only. `EYE_In_SafetyApplied` declares semantic `applied_profile:safety_profile` and reports the configured companion profile, not a claim that VRChat's safety policy changed. If entering a safety profile disarms Avatar Link before feedback is sent, the avatar-side result remains unconfirmed. All external actions remain subject to VRC Eye's local grants and capabilities.

## Installation, update, undo and recovery

The installer clones the expression parameter asset, root expression menu and assigned FX controller into `Assets/VRC Eye Generated/<installation-id>`. Original source assets and original controller layers are retained. New state machines animate only generated descendants and set Write Defaults only for their own new states. Existing Write Defaults are not rewritten. A full original root menu becomes an **Original menu** submenu of a new wrapper; generated pages are bounded to eight entries.

Colliding expression/FX names fail the reviewed plan. The tool never coerces types, guesses semantic equivalence or silently overwrites an unrelated definition. All twelve starter modules consume zero additional synchronized bits; the existing avatar must still fit the documented 256-bit / 8192-custom-parameter limits. Reinstalling an active journal is blocked. The initial explicit update path is: inspect/export → remove unchanged installation → review replacement installation. No untested in-place merge is claimed.

Each installation records original and installed references, stable identity, an avatar-relative owned-root locator (scene references are not persisted in assets), ownership, asset dependency hashes, generated-object fingerprints and a local `before-descriptor.json` backup. The backup stays inside the project and can contain source information; it is never part of the sanitized manifest. On failure, the installer restores descriptor references and removes its newly created scene root while retaining generated assets and the failure journal for inspection.

**Remove unchanged installation using journal** restores recorded references only when the selected descriptor, generated hierarchy and owned assets still match. Any intervening edits stop automatic removal. Generated assets are deliberately retained because another avatar may reference them. Inspect the journal's original references to perform a manual, selective repair if a creator edited the installation. Unity Undo supports descriptor/scene-object changes, while the persistent journal handles file history; Undo does not promise deletion of asset files.

## Export and inspect

**Inspect source configuration** checks source parameter cost, duplicate names, selected rig category, missing components, selected PhysBone references and Contact local/others configuration. Findings explicitly retain not-tested states. Use the SDK's own rig/build/performance validator for its full rules. No blanket repair, PhysBone live-property tuning, raycast configuration, arbitrary hierarchy mutation or runtime skeleton reconstruction is performed.

**Review and export source manifest** emits the desktop schema-1 contract. It includes ordered actual expression parameters, finite module definitions, measured source component counts, animation bindings, selected source context and a sanitized hierarchy. By default the hierarchy contains only toolkit descendants and anchor ancestors; full selected-avatar hierarchy and source labels are separate opt-ins. Parameter names must remain exact for compatibility. The export stops instead of truncating unsupported names or exceeding 512 parameters / 2000 hierarchy objects / 2000 bindings / 256 KiB. Source-derived costs are not final uploaded performance rank.

A blueprint ID is read only when present; otherwise a stable local avatar ID from the journal identifies the workspace. The export always has `stage: "source"` and an empty generated build ID. It does not claim that the source is the currently worn avatar or the output of a later build processor. **Do not relabel a source manifest as generated** without an independently inspected final build.

**Static preview PNG** is a separate, explicitly reviewed local export. It draws existing selected-source meshes/materials, at their current pose, with orthographic front/back/left/right views. It does not instantiate arbitrary avatar scripts, modify source poses, create a T-pose, fetch an avatar, or represent VRChat runtime rendering. Limits are 256 renderers, 500,000 vertices and 1024×1024 output. No continuous renderer runs when the window is hidden. The creator decides separately whether the image may be shared.

The desktop module composer accepts data-only recipes; its planning export does not automatically execute editor code or install a third-party package. This Unity backend currently installs the twelve fixed, reviewed starter recipes. A custom composer recipe must be implemented and tested in the creator's Unity source before it can be advertised as an installed module.

## Native verification checklist

The package includes EditMode tests in `Tests/EyeAuthoringTests.cs`. Run them in Unity with SDK 3.10.x and the Unity Test Framework. They exercise actual installation/privacy settings, duplicate protection, changed-object refusal, removal restoration, scene save/reopen recovery and source-export labeling. They have **not** been executed in this release's Linux Python environment.

Before distribution, additionally verify: compile/import; a fresh avatar and one with existing FX/menus; full menu wrapping; every selected module; Undo/reload and journal removal; existing asset preservation; postprocessor output; cross-platform synchronized parameter positions/types; self/others Contacts; held/short requests and release rearm; OSC output configuration; avatar reload; initial and stale heartbeat; provider disappearance; local/remote/mirror/photo rendering; menu alternatives; generic and humanoid anchors; left/right placement; shader/platform builds; image permissions; and SDK performance constraints. Keep request acceptance distinct from observed completion.

## Official references checked for this implementation

- VPM local/package format and dependencies: https://vcc.docs.vrchat.com/vpm/packages/
- Current SDK releases (3.10.5 at review): https://creators.vrchat.com/releases/
- Current Unity editor: https://creators.vrchat.com/sdk/upgrade/current-unity-version/
- Parameter types, synchronization budget and ordering: https://creators.vrchat.com/avatars/animator-parameters/
- Expression menu controls and persistence: https://creators.vrchat.com/avatars/expression-menu-and-controls/
- Contact receiver behavior and filtering: https://creators.vrchat.com/common-components/contacts/
- PhysBone authoring and supported signals: https://creators.vrchat.com/common-components/physbones/
- Platform overrides: https://creators.vrchat.com/avatars/per-platform-avatar-overrides/

Documentation review establishes the design target, not native compatibility certification.
