# VRC Eye 1.21.0 — Development 21

This checkpoint adds the five approved ARC/VRCX extensions to the complete Development 20 source. The implementation uses existing Eye owners and data stores. Supplied utility or mod implementation code and binaries were not copied or executed.

## Start

Extract into a separate folder. Run **Start.cmd** on Windows or **bash Start.sh** on Linux. The existing launchers and requirements remain available. This package is runnable Python source, not a compiled executable or signed installer.

## Changes and entry points

| Addition | Where to find it | What to try |
|---|---|---|
| Deeper material and texture inspection | Avatar Library → 3D preview → Materials, textures & mesh health | Open a static GLB. Select a material, isolate it and restore the full scene. Inspect embedded textures as composite/RGB/alpha, zoom retained pixels and show a bounded UV overlay. The renderer now handles vertex colors and UV0 texture transforms. |
| Mesh health | The same expanded inspector → Mesh health | Select a primitive to highlight its node. Review topology, unused vertices, degenerate/duplicate triangles, normal/tangent coverage and UV findings. Source geometry is not repaired or rewritten. |
| Automatic association rules | Avatar Library matching tools → Enable exact-match rule; Rules & batch undo | Bind a recorded reference to the selected folder. Later Find exact matches scans can add matching references automatically. Review active rules, revoke one/all, then review batch undo. Undo preserves references edited after the batch. |
| Broader observed history | Friend feed → Observed changes | Filter appearance, identity/bio, avatar, presence/location or relationships/tags. Details show previous/current observation time and source. New supplied appearance and preference fields participate alongside existing profile changes. |
| More settings backup and undo | Settings backup and undo | Choose Saved composer blocks and OSC view/pinned controls among ten sections. Restore or undo through the existing review. Saved composer blocks contain typed text; use Load saved blocks to replace an open draft deliberately. |

## Material and mesh coverage

- Static GLB remains bounded to 32 MiB, 100,000 used vertices, 30,000 triangles and 512 nodes/primitive instances. Skinning and morph geometry remain unsupported. No new FBX, VRCA or Unity-bundle importer is introduced.
- COLOR_0 supports FLOAT or normalized unsigned byte/short VEC3/VEC4. Colors multiply base color and texture in linear RGB; alpha remains linear. KHR_texture_transform supports UV0 scale, rotation and offset. Unsupported required extensions are rejected; unsupported optional texture paths retain the explained fallback.
- Embedded PNG/JPEG only: at most 16 textures, 4 megapixels each and 8 megapixels combined, with retained thumbnails at most 256 pixels per edge. Inspecting 1x/2x/4x enlarges retained pixels, not the original full-resolution image. The overlay shows up to 2,048 selected-material triangles in the unit tile before wrapping; it is not a full UV editor.
- Existing rendering bounds remain: 480 × 320 frame, four million bounding-box pixel visits, four seconds and a cancellable latest-frame worker. PBR/Unity shader parity, other material maps, multiple UV sets and full-resolution filtering remain open. Blend sorting is approximate. External/data URI images are never opened; OBJ remains geometry-only.
- Mesh findings use source-local primitive geometry and source indices. Open meshes and indexed seams can produce boundary edges. Health is not a self-intersection/deformation check, runtime performance grade or universal validity verdict. Normal/tangent findings do not add normal-mapped rendering or repairs.
- GLB interpretation follows the [Khronos glTF 2.0 specification](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html) and [KHR_texture_transform specification](https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_texture_transform). The parser process provides fault separation, not an operating-system sandbox.

## Association rule behavior

- Rules require explicit enablement for a reviewed folder identity and a recorded association with exact SHA-256 and size. They run on user-started matching scans; there is no startup scan or filesystem watcher. Matching does not establish ownership or prove semantic avatar identity.
- Existing scanner limits remain 128 files and 4 GiB per scan. Up to 64 rules per workspace; changed anchors and conflicting targets require review. Rule plans expire after five minutes and are rechecked against current rules, folder identity, file evidence and account context before commit.
- A batch adds only missing catalog references, atomically with its undo receipt. It does not overwrite a preexisting reference or modify any source file. Revocation stops later rule applications but retains previously added references.
- Undo removes only references that still match the batch result. Later modifications and already removed references are preserved and reported. Revoke a rule first if a later matching scan should not recreate the reference.
- The newest 100 receipts are retained within 8 MiB per workspace; a batch receipt is at most 2 MiB. Rules and undo receipts are excluded from settings/profile backups. Catalog references retain their existing backup coverage.

## History and settings behavior

- History records supplied observations, not the exact moment a remote change occurred. Missing, null or malformed fields do not erase previously observed evidence. Explicitly older observations cannot regress newer field baselines. Unobserved changes and hidden fields cannot be reconstructed.
- New history coverage includes typed avatar-copy/boop preferences, languages, banner/background/theme fields, icon frames and nameplate/profile effects. Existing profile and pipeline readers supply these fields without an additional network request. Appearance values are validated and old receipts remain readable.
- Selective settings backup now has ten sections. New composer sections contain private typed text, not frozen live-provider snapshots or send authority. OSC coverage is limited to the view and pinned control buttons; routes, endpoint/setup choices, voice and grants are excluded.
- Selective OSC restore preserves unrelated current operating preferences. Full sanitized profile backup uses default operating preferences plus the saved display choices. New sections require a Development 21 reader; older bundles remain readable.
- Supported direct edits and selective restores use the existing shared history and conditional undo. Active OSC display choices refresh after restore. Open unsaved composer drafts remain until the user loads saved blocks.

## Validation and remaining work

The final portable run passed 5,160 tests and 1,059 subtests, including all 45 new Development 21 cases. See DEVELOPMENT_21_VALIDATION.md and BUILD_VALIDATION.json for exclusions, skips, exact command and environment limits.

ARC-21 advances to source implemented with native/live acceptance open. The 106-area ARC/VRCX ledger now has 39 partial and 7 missing areas; the broader 160-package roadmap has 51 source-implemented, 70 partial and 39 pending packages. These are different inventories. Native Windows/Linux layout, keyboard, high contrast, large text, rendering performance and live-provider acceptance remain open. See ARC_VRCX_REMAINING_DEV21.md for the full remaining inventory.
