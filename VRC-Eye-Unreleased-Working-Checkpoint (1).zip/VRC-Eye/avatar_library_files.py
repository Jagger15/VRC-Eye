"""Bounded local avatar/file/image/package inspection. Never extracts or runs code.

ZIP and a deliberately restricted TAR subset are read as data. TAR extension
records, links, encrypted ZIPs, traversal names and special files are rejected.
No changes are made to selected source files or Unity projects.
"""
from __future__ import annotations

from contextlib import contextmanager
from hashlib import sha256
from io import BytesIO
from pathlib import Path, PurePosixPath
import gzip
import json
import os
import re
import stat
import tarfile
import warnings
import zipfile

from creator_projects import assert_no_links, local_path, version_text

FILE_LIMIT = 2 * 1024**3
PACKAGE_LIMIT = 256 * 1024**2
EXPANDED_LIMIT = 512 * 1024**2
MEMBER_LIMIT = 128 * 1024**2
ENTRY_LIMIT = 4096
TEXT_LIMIT = 256 * 1024
TEXT_BUDGET = 16 * 1024**2
IMAGE_LIMIT = 8 * 1024**2
SHADER_SUFFIXES = (".shader", ".shadergraph", ".shadersubgraph", ".hlsl", ".cginc", ".compute")


class InspectionCancelled(ValueError):
    pass


def check_cancel(stop):
    if stop is not None and stop.is_set():
        raise InspectionCancelled("Task cancelled. Existing source files were not changed.")


def fingerprint(info):
    return {"device": str(info.st_dev), "inode": str(info.st_ino), "size": info.st_size,
            "mtime_ns": info.st_mtime_ns, "ctime_ns": info.st_ctime_ns}


@contextmanager
def checked_stream(path, *, limit=FILE_LIMIT, expected=None):
    path = assert_no_links(local_path(path))
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("Select a regular file within the inspection size limit.")
    except BaseException:
        os.close(descriptor)
        raise
    with os.fdopen(descriptor, "rb") as stream:
        if expected is not None and fingerprint(before) != expected:
            raise ValueError("The selected file changed since review. Inspect it again.")
        yield path, stream, before
        after = os.fstat(stream.fileno())
        assert_no_links(path)
        if fingerprint(before) != fingerprint(after) or fingerprint(path.stat()) != fingerprint(after):
            raise ValueError("The selected file changed during inspection. No new evidence was accepted.")


def inspect_file(path, *, stop=None, progress=None, limit=FILE_LIMIT):
    check_cancel(stop)
    with checked_stream(path, limit=limit) as (path, stream, before):
        digest, total, prefix = sha256(), 0, b""
        while True:
            check_cancel(stop)
            block = stream.read(1024 * 1024)
            if not block:
                break
            total += len(block)
            if total > limit:
                raise ValueError("The file grew past its inspection budget.")
            digest.update(block)
            if not prefix: prefix = block[:32]
            if progress: progress(total, before.st_size)
        if total != before.st_size:
            raise ValueError("The source size changed during inspection.")
    check_cancel(stop)
    header = "Unity bundle header" if prefix.startswith((b"UnityFS\0", b"UnityWeb\0", b"UnityRaw\0")) else "Other / unrecognized header"
    return {"path": str(path), "name": path.name, "size": total, "sha256": digest.hexdigest(),
            "fingerprint": fingerprint(before), "header": header}


def validate_evidence(value):
    if not isinstance(value, dict): raise ValueError("Expected local file evidence.")
    path = local_path(value.get("path", ""))
    size, digest, fp = value.get("size"), value.get("sha256"), value.get("fingerprint")
    if type(size) is not int or not 0 <= size <= FILE_LIMIT or not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
        raise ValueError("File evidence needs a bounded size and a SHA-256 digest.")
    if not isinstance(fp, dict) or set(fp) != {"device", "inode", "size", "mtime_ns", "ctime_ns"} or fp["size"] != size:
        raise ValueError("File evidence needs the original file fingerprint.")
    if any(type(fp[k]) is not int for k in ("size", "mtime_ns", "ctime_ns")) or any(not isinstance(fp[k], str) or len(fp[k]) > 64 for k in ("device", "inode")):
        raise ValueError("Invalid local file fingerprint.")
    return {"path": str(path), "name": path.name[:512], "size": size, "sha256": digest,
            "fingerprint": dict(fp), "header": "Unity bundle header" if value.get("header") == "Unity bundle header" else "Other / unrecognized header"}


def verify_file(record, *, stop=None, progress=None):
    result = {"expected_sha256": record["sha256"], "observed_sha256": ""}
    try:
        found = inspect_file(record["path"], stop=stop, progress=progress)
    except InspectionCancelled:
        raise
    except FileNotFoundError:
        return dict(result, availability="Unavailable")
    except (OSError, ValueError):
        return dict(result, availability="Unreadable")
    return dict(result, observed_sha256=found["sha256"], availability=("Matches recorded bytes" if found["sha256"] == record["sha256"] and found["size"] == record["size"] else "Changed"))


def copy_record(record, destination, *, stop=None, progress=None, before_commit=None):
    """Reuse VRC Eye's bounded, exclusive-publication copy primitive."""
    from vrca_files import _save_stream, VRCAError, VRCACancelled
    record = validate_evidence(record)
    if before_commit is not None and not callable(before_commit):
        raise ValueError("The copy validation callback must be callable.")
    source = assert_no_links(record["path"])
    destination = assert_no_links(local_path(destination))
    if destination.exists() or destination.is_symlink():
        raise ValueError("Choose a new destination filename. Existing files are never overwritten.")
    if not destination.parent.is_dir():
        raise ValueError("Select an existing destination folder.")
    check_cancel(stop)
    def source_check(info):
        assert_no_links(source)
        assert_no_links(destination.parent)
        if not stat.S_ISREG(info.st_mode) or fingerprint(info) != record["fingerprint"]:
            raise ValueError("The source changed since it was catalogued. Reinspect it before copying.")
    # Check before the shared helper opens, including protection against FIFOs.
    source_check(source.stat())
    try:
        with checked_stream(source, expected=record["fingerprint"]) as (_, stream, before):
            def validate_commit():
                source_check(os.fstat(stream.fileno()))
                source_check(source.stat())
                if before_commit is not None:
                    before_commit()
            saved = _save_stream(stream, destination, before.st_size, record["sha256"], stop, progress,
                                 network=False, suffixes=(destination.suffix.lower(),), before_commit=validate_commit)
    except VRCACancelled as error:
        raise InspectionCancelled(str(error)) from error
    except VRCAError as error:
        raise ValueError(str(error)) from error
    # Publication has already completed. Do not erase its successful outcome if a
    # cancel arrives now. A later recheck can independently verify the saved bytes.
    with checked_stream(destination, expected=None) as (_, _, info):
        evidence = {"path": str(destination), "name": destination.name, "size": saved.size,
                    "sha256": saved.sha256, "fingerprint": fingerprint(info),
                    "header": "Unity bundle header" if saved.bundle_header else "Other / unrecognized header"}
        if info.st_size != saved.size:
            raise ValueError("A copy was published but then changed; inspect the destination before using it.")
    return evidence


def image_preview(data, size=(900, 650)):
    """Single-frame, metadata-free PNG. Never disables Pillow's own protections."""
    if not isinstance(data, bytes) or not 0 < len(data) <= IMAGE_LIMIT:
        raise ValueError("Preview images must be nonempty and at most 8 MiB.")
    if not isinstance(size, tuple) or len(size) != 2 or any(type(v) is not int or not 1 <= v <= 1600 for v in size):
        raise ValueError("Preview dimensions must be within 1–1,600 pixels.")
    try:
        from PIL import Image, ImageOps
    except ImportError as error:
        raise ValueError("Image preview requires the existing Pillow startup dependency.") from error
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(data)) as original:
                if original.format not in ("PNG", "JPEG", "WEBP", "GIF") or original.width > 8192 or original.height > 8192 or original.width * original.height > 16000000:
                    raise ValueError("Unsupported image format or decoded image dimensions.")
                original.seek(0)
                working = ImageOps.exif_transpose(original).convert("RGBA")
                working.thumbnail(size, Image.Resampling.LANCZOS)
                # A new image drops arbitrary textual/EXIF metadata.
                clean = Image.new("RGBA", working.size)
                clean.paste(working)
                output = BytesIO()
                clean.save(output, "PNG")
                return output.getvalue()
    except (ValueError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as error:
        raise ValueError("This image could not be decoded within the preview limits.") from error


def local_preview(record, size=(900, 650), *, stop=None):
    evidence = validate_evidence(record)
    check_cancel(stop)
    with checked_stream(evidence["path"], limit=IMAGE_LIMIT, expected=evidence["fingerprint"]) as (_, stream, _):
        data = stream.read(IMAGE_LIMIT + 1)
    if sha256(data).hexdigest() != evidence["sha256"]:
        raise ValueError("The preview file no longer matches the recorded bytes.")
    check_cancel(stop)
    return image_preview(data, size)


def _member_name(name):
    if not isinstance(name, str) or not name or len(name) > 1024 or "\\" in name or any(ord(c) < 32 for c in name):
        raise ValueError("Package contains an unsupported member name.")
    if name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        raise ValueError("Package contains an absolute member path.")
    pieces = name.rstrip("/").split("/")
    if any(p in ("", ".", "..") or ":" in p for p in pieces):
        raise ValueError("Package contains a traversal or ambiguous member path.")
    return name.rstrip("/")


def _parse_text(data):
    try: return data.decode("utf-8-sig")
    except UnicodeError: return ""


def _wanted(name):
    lower = name.lower()
    return lower.endswith(SHADER_SUFFIXES + (".mat", ".meta")) or PurePosixPath(lower).name in ("package.json", "pathname", "asset", "asset.meta") or "license" in PurePosixPath(lower).name


def _read_zip(stream, *, stop=None):
    entries, names, total, retained = [], set(), 0, 0
    try:
        with zipfile.ZipFile(stream) as archive:
            members = archive.infolist()
            if len(members) > ENTRY_LIMIT: raise ValueError("Package contains more than 4,096 members.")
            for member in members:
                check_cancel(stop)
                name = _member_name(member.filename)
                if name.casefold() in names: raise ValueError("Package contains duplicate or case-colliding member names.")
                names.add(name.casefold())
                mode = member.external_attr >> 16
                if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)) or member.flag_bits & 1:
                    raise ValueError("Package links, special files and encrypted members are not supported.")
                if member.is_dir(): continue
                if member.file_size < 0 or member.file_size > MEMBER_LIMIT:
                    raise ValueError("A package member exceeds the 128 MiB limit.")
                total += member.file_size
                if total > EXPANDED_LIMIT: raise ValueError("Expanded package exceeds the 512 MiB limit.")
                data, digest = b"", ""
                wanted = _wanted(name)
                if wanted:
                    hasher, count, chunks = sha256(), 0, []
                    keep = min(TEXT_LIMIT, max(0, TEXT_BUDGET - retained))
                    with archive.open(member, "r") as member_stream:
                        while True:
                            check_cancel(stop)
                            block = member_stream.read(64 * 1024)
                            if not block: break
                            count += len(block)
                            if count > member.file_size or count > MEMBER_LIMIT: raise ValueError("A package member exceeded its declared size.")
                            hasher.update(block)
                            if keep:
                                part = block[:keep]; chunks.append(part); keep -= len(part); retained += len(part)
                    if count != member.file_size: raise ValueError("Truncated package member.")
                    data, digest = b"".join(chunks), hasher.hexdigest()
                entries.append({"name": name, "size": member.file_size, "content": data, "sha256": digest,
                                "content_complete": wanted and len(data) == member.file_size})
    except (zipfile.BadZipFile, NotImplementedError, RuntimeError) as error:
        raise ValueError("Unsupported, damaged or encrypted ZIP package.") from error
    return entries, total


def _read_tar(stream, *, compressed, stop=None):
    """Parse fixed headers; never let TAR extension payloads allocate memory."""
    entries, names, total, expanded, retained = [], set(), 0, 0, 0
    reader = gzip.GzipFile(fileobj=stream, mode="rb") if compressed else stream
    def take(count):
        nonlocal expanded
        check_cancel(stop)
        if count > 64 * 1024: raise ValueError("Internal TAR read exceeds its chunk budget.")
        data = reader.read(count)
        expanded += len(data)
        if expanded > EXPANDED_LIMIT + ENTRY_LIMIT * 1024:
            raise ValueError("Expanded package exceeded its read budget.")
        return data
    try:
        while True:
            header = take(512)
            if not header:
                break
            if len(header) != 512: raise ValueError("Truncated TAR header.")
            if not any(header):
                # The format ends at two zero blocks. Reject concatenated or
                # non-padding data rather than silently ignoring hidden members.
                second = take(512)
                if len(second) != 512 or any(second): raise ValueError("Invalid TAR end marker.")
                while True:
                    padding = take(64 * 1024)
                    if not padding: break
                    if any(padding): raise ValueError("Unexpected data after the TAR end marker.")
                break
            if len(entries) >= ENTRY_LIMIT: raise ValueError("Package contains more than 4,096 members.")
            try: member = tarfile.TarInfo.frombuf(header, "utf-8", "strict")
            except (tarfile.HeaderError, UnicodeError, ValueError) as error: raise ValueError("Invalid TAR header.") from error
            name = _member_name(member.name)
            if name.casefold() in names: raise ValueError("Duplicate package member name.")
            names.add(name.casefold())
            if len(names) > ENTRY_LIMIT: raise ValueError("Package contains too many members.")
            if member.type not in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.DIRTYPE):
                raise ValueError("TAR links, sparse files, long-name/PAX extensions and special members are not supported.")
            if member.isdir():
                if member.size: raise ValueError("Invalid nonempty directory member.")
                continue
            if not 0 <= member.size <= MEMBER_LIMIT: raise ValueError("A package member exceeds 128 MiB.")
            total += member.size
            if total > EXPANDED_LIMIT: raise ValueError("Expanded package exceeds 512 MiB.")
            wanted = _wanted(name)
            remaining, chunks, hasher = member.size, [], sha256()
            keep = min(TEXT_LIMIT, max(0, TEXT_BUDGET - retained)) if wanted else 0
            while remaining:
                block = take(min(64 * 1024, remaining))
                if not block: raise ValueError("Truncated TAR member.")
                remaining -= len(block)
                if wanted: hasher.update(block)
                if keep:
                    part = block[:keep]; chunks.append(part); keep -= len(part); retained += len(part)
            padding = (-member.size) % 512
            if padding and len(take(padding)) != padding: raise ValueError("Truncated TAR member padding.")
            data = b"".join(chunks)
            entries.append({"name": name, "size": member.size, "content": data,
                            "sha256": hasher.hexdigest() if wanted else "", "content_complete": wanted and len(data) == member.size})
        if not entries: raise ValueError("Package contains no regular files.")
    except (OSError, EOFError) as error:
        raise ValueError("The compressed package is damaged or unsupported.") from error
    finally:
        if compressed: reader.close()
    return entries, total


def _logical_entries(entries):
    """Resolve Unitypackage GUID/pathname pairs only as descriptive names."""
    paths = {}
    for e in entries:
        pieces = e["name"].split("/")
        if len(pieces) == 2 and re.fullmatch(r"[a-fA-F0-9]{32}", pieces[0]) and pieces[1] == "pathname":
            value = _parse_text(e["content"]).strip().strip("\x00")
            if not value or not e["content_complete"]: raise ValueError("Invalid Unitypackage pathname entry.")
            paths[pieces[0].lower()] = _member_name(value)
    result, logical_names = [], set()
    for e in entries:
        pieces = e["name"].split("/")
        guid = pieces[0].lower() if len(pieces) == 2 and re.fullmatch(r"[a-fA-F0-9]{32}", pieces[0]) else ""
        if guid and pieces[1] in ("asset", "asset.meta"):
            if guid not in paths:
                # Retain as opaque data; never invent its original path/type.
                continue
            e = dict(e, name=paths[guid] + (".meta" if pieces[1] == "asset.meta" else ""), guid=guid)
        elif guid and pieces[1] in ("pathname", "preview.png"):
            continue
        if e["name"].casefold() in logical_names: raise ValueError("Package maps multiple members to the same logical asset.")
        logical_names.add(e["name"].casefold()); result.append(e)
    return result


def summarize_entries(entries):
    entries = _logical_entries(entries)
    shaders, materials, manifests, licenses, issues, guid_map = [], [], [], [], [], {}
    for e in entries:
        name, content = e["name"], _parse_text(e["content"])
        if name.lower().endswith(".meta"):
            match = re.search(r"(?m)^guid:\s*([a-fA-F0-9]{32})\s*$", content)
            if match: guid_map[match[1].lower()] = name[:-5]
        elif e.get("guid"): guid_map[e["guid"]] = name
    shader_count = material_count = 0
    for e in entries:
        name, lower, content = e["name"], e["name"].lower(), _parse_text(e["content"])
        if lower.endswith(SHADER_SUFFIXES):
            shader_count += 1
            if len(shaders) < 200:
                declared = re.search(r'\bShader\s*"([^"\r\n]{1,256})"', content)
                shaders.append({"path": name, "declared_name": declared[1] if declared else "",
                                "format": PurePosixPath(name).suffix, "bytes": e["size"],
                                "sha256": e["sha256"], "text_complete": e["content_complete"]})
        if lower.endswith(".mat"):
            material_count += 1
            if len(materials) < 200:
                match = re.search(r"m_Shader:\s*\{([^}]{0,1024})\}", content)
                guid = re.search(r"guid:\s*([a-fA-F0-9]{32})", match[1]) if match else None
                ref = guid[1].lower() if guid else ""
                material = {"path": name, "shader_guid": ref,
                            "reference_state": "Found in selected package" if ref in guid_map else
                            "External / unresolved here" if ref else "Not determined from bounded text", "text_complete": e["content_complete"]}
                if ref in guid_map: material["referenced_asset"] = guid_map[ref]
                materials.append(material)
        if PurePosixPath(lower).name == "package.json" and len(manifests) < 20:
            if not e["content_complete"]:
                issues.append("A package manifest exceeded the bounded text budget.")
                continue
            try:
                from avatar_library import decode_document, text
                raw = decode_document(e["content"])
                dependencies = raw.get("vpmDependencies", raw.get("dependencies", {}))
                if not isinstance(dependencies, dict) or len(dependencies) > 256:
                    raise ValueError("Invalid dependency list.")
                manifests.append({"path": name, "name": text(raw.get("name"), 200), "version": version_text(raw.get("version")),
                                  "license_declaration": text(raw.get("license"), 512),
                                  "dependencies": {text(k, 200): version_text(v) for k, v in dependencies.items()}})
            except (ValueError, TypeError, RecursionError):
                issues.append("A package manifest was malformed or unsupported.")
        if "license" in PurePosixPath(lower).name and len(licenses) < 50:
            licenses.append(name)
    if shader_count > len(shaders) or material_count > len(materials):
        issues.append("The detailed listing was truncated to 200 shader and 200 material entries; counts cover all recognized names.")
    if any(not e["content_complete"] for e in entries if _wanted(e["name"])):
        issues.append("Some text was not retained completely; absent declarations are unknown, not proof they do not exist.")
    if not licenses and not any(m["license_declaration"] for m in manifests):
        issues.append("No license declaration found in inspected entries. This is not permission to reuse or redistribute.")
    duplicates = {}
    for shader in shaders:
        if shader["sha256"]: duplicates.setdefault(shader["sha256"], []).append(shader["path"])
    return {"shader_count": shader_count, "material_count": material_count, "shaders": shaders, "materials": materials,
            "manifests": manifests, "license_files": licenses, "issues": list(dict.fromkeys(issues)),
            "duplicate_shader_bytes": {k: v for k, v in duplicates.items() if len(v) > 1},
            "limitations": "Read-only bounded text/package inventory. No scripts executed, assets extracted, shaders compiled, licenses certified or project dependencies resolved. External material references are not confirmed missing shaders."}


def inspect_package(path, *, stop=None, progress=None):
    evidence = inspect_file(path, stop=stop, progress=progress, limit=PACKAGE_LIMIT)
    path = local_path(evidence["path"])
    with checked_stream(path, limit=PACKAGE_LIMIT, expected=evidence["fingerprint"]) as (_, stream, _):
        prefix = stream.read(4); stream.seek(0)
        if prefix.startswith(b"PK"):
            entries, expanded = _read_zip(stream, stop=stop)
            format_name = "ZIP"
        elif path.name.lower().endswith((".unitypackage", ".tgz", ".tar.gz", ".tar")):
            compressed = prefix.startswith(b"\x1f\x8b")
            entries, expanded = _read_tar(stream, compressed=compressed, stop=stop)
            format_name = "Unitypackage / TAR" if path.suffix.lower() == ".unitypackage" else "TAR"
        elif path.suffix.lower() in SHADER_SUFFIXES:
            if evidence["size"] > TEXT_LIMIT: raise ValueError("Individual shader text is limited to 256 KiB.")
            data = stream.read(TEXT_LIMIT + 1)
            entries, expanded = [{"name": path.name, "size": len(data), "content": data, "sha256": evidence["sha256"], "content_complete": True}], len(data)
            format_name = "Shader source"
        else:
            raise ValueError("Select a ZIP, Unitypackage, TGZ/TAR or shader source file. Executables and DLLs are not inspected as packages.")
    check_cancel(stop)
    result = dict(evidence, schema="vrc-eye-package-inspection-1", format=format_name,
                  entry_count=len(entries), expanded_bytes=expanded, **summarize_entries(entries))
    from avatar_creator_store import json_copy
    # The same 256 KiB record ceiling applies even to large package descriptions.
    return json_copy(result)
