"""Bounded, versioned data contracts and consent rules for VRC Eye peers.

These contracts describe user data, never executable instructions. Device identity
and transport authentication belong to peer_transport; a valid envelope alone is
not authenticated. Local objects use these same validators without opening a socket.
"""
from __future__ import annotations

from collections import OrderedDict
import copy
import json
import math
import re
import threading
import time
import uuid

PROTOCOL_VERSION = 1
APP_VERSION = "1.21.0"
MAX_FRAME_BYTES = 65536
MAX_CLOCK_SKEW = 120
FAMILIES = ("profile", "presence", "whisper", "bookmark", "coordination",
            "safety", "diagnostics", "troubleshooting", "config", "creator",
            "performance", "confirmation", "notice", "novelty", "encounter")


def _feature(label, family, ttl=300, queueable=False, max_bytes=8192, context=False):
    return dict(label=label, family=family, ttl=ttl, queueable=queueable,
                max_bytes=max_bytes, context_required=context)


FEATURES = {
    "profile.update": _feature("Profile", "profile", 3600),
    "presence.update": _feature("Availability", "presence", 120),
    "session.card": _feature("Session card", "presence", 300),
    "whisper.message": _feature("Whisper", "whisper", 86400, True),
    "bookmark.card": _feature("Bookmark", "bookmark", 86400, True),
    "recommend.world": _feature("World recommendation", "bookmark", 86400, True),
    "recommend.avatar": _feature("Avatar recommendation", "bookmark", 86400, True),
    "party.snapshot": _feature("Party board", "coordination", 3600, max_bytes=24576, context=True),
    "ready.request": _feature("Ready check", "coordination", 300, context=True),
    "ready.response": _feature("Ready response", "coordination", 300, context=True),
    "countdown.start": _feature("Countdown", "coordination", 120, context=True),
    "photo.plan": _feature("Photo plan", "coordination", 3600, context=True),
    "media.cue": _feature("Media cue", "coordination", 120, context=True),
    "safety.checkin": _feature("Safety check-in", "safety", 300),
    "safety.response": _feature("Check-in response", "safety", 300),
    "safety.alert": _feature("Safety Mode alert", "safety", 120),
    "lab.observation": _feature("Client Lab playtest observation", "diagnostics", 600, max_bytes=4096, context=True),
    "diagnostics.card": _feature("Diagnostic card", "diagnostics", 600, max_bytes=24576),
    "troubleshooting.request": _feature("Troubleshooting request", "troubleshooting", 300),
    "troubleshooting.response": _feature("Troubleshooting response", "troubleshooting", 300),
    "config.package": _feature("Preset package", "config", 600, True, 24576),
    "creator.snapshot": _feature("Creator playtest", "creator", 3600, max_bytes=24576, context=True),
    "performance.card": _feature("Performance card", "performance", 600, max_bytes=24576),
    "diagnostic.confirm": _feature("Diagnostic confirmation", "confirmation", 300, context=True),
    "encounter.confirm": _feature("Encounter confirmation", "encounter", 3600, context=True),
    "role.assign": _feature("Session role", "coordination", 3600, context=True),
    "checklist.snapshot": _feature("Creator checklist", "creator", 3600, max_bytes=24576, context=True),
    "notice.show": _feature("Overlay notice", "notice", 60),
    "novelty.confetti": _feature("Confetti", "novelty", 30),
}
for _kind, _definition in FEATURES.items():
    _definition["capability"] = _kind + ":1"


def capabilities():
    return sorted(v["capability"] for v in FEATURES.values())


class ProtocolError(ValueError):
    """A deliberately non-payload-bearing validation error."""


def _fail(reason="Invalid peer data"):
    raise ProtocolError(reason)


def _text(value, maximum=256, minimum=0):
    if not isinstance(value, str) or not minimum <= len(value) <= maximum:
        _fail("Invalid text length")
    # Newlines and tabs are harmless plain text; bidi controls/other invisible
    # directional overrides can make confirmation screens deceptive.
    if any((ord(c) < 32 and c not in "\n\t") or 0x7f <= ord(c) < 0xa0 or
           0x202a <= ord(c) <= 0x202e or 0x2066 <= ord(c) <= 0x2069 or
           0xd800 <= ord(c) <= 0xdfff for c in value):
        _fail("Unsupported text control character")
    return value


def _id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", value):
        _fail("Invalid identifier")
    return value


def _uuid(value):
    if not isinstance(value, str):
        _fail("Invalid message identifier")
    try:
        if str(uuid.UUID(value)) != value:
            _fail("Noncanonical message identifier")
    except (ValueError, AttributeError):
        _fail("Invalid message identifier")
    return value


def _reference(value, prefix):
    if not isinstance(value, str) or not re.fullmatch(prefix + r"_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", value):
        _fail("Invalid VRChat reference")
    return value.lower()


def _number(value, maximum=1e12, minimum=0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not minimum <= value <= maximum or not math.isfinite(value):
        _fail("Invalid number")
    return value


def _integer(value, maximum=2147483647, minimum=0):
    if type(value) is not int or not minimum <= value <= maximum:
        _fail("Invalid integer")
    return value


def _bool(value):
    if type(value) is not bool:
        _fail("Invalid boolean")
    return value


def _enum(*choices):
    def validate(value):
        if not isinstance(value, str) or value not in choices:
            _fail("Unsupported option")
        return value
    return validate


def _list(validator, maximum=64):
    def validate(value):
        if not isinstance(value, list) or len(value) > maximum:
            _fail("Invalid list")
        return [validator(v) for v in value]
    return validate


def _object(value, required, optional=None):
    optional = optional or {}
    if not isinstance(value, dict) or not set(required).issubset(value) or set(value) - set(required) - set(optional):
        _fail("Invalid object fields")
    return {k: (required.get(k) or optional[k])(v) for k, v in value.items()}


def _roles(value):
    if not isinstance(value, dict) or len(value) > 32:
        _fail("Invalid role map")
    return {_id(k): _role(v) for k, v in value.items()}


_role = _enum("Host", "Co-Host", "Photographer", "DJ", "Tester", "Observer", "Coordinator", "None")
_short = lambda v: _text(v, 120)
_body = lambda v: _text(v, 2048)
_title = lambda v: _text(v, 160, 1)
_revision = lambda v: _integer(v)
_world = lambda v: _reference(v, "wrld")
_avatar = lambda v: _reference(v, "avtr")


def _check_item(v):
    return _object(v, {"item_id": _id, "title": _title, "status": _enum("TODO", "IN_PROGRESS", "PASS", "FAIL", "SKIPPED")},
                   {"note": _body, "assignee": _id, "description": _body, "diagnostic_event": _id})


SCHEMAS = {
    "profile.update": ({}, {"alias": _short, "bio": _body, "pronouns": _short, "status_text": _short,
                            "favorite_color": lambda v: _text(v, 32), "icon": lambda v: _text(v, 16),
                            "creator_mode": _bool, "streamer_status": _bool, "revision": _revision}),
    "presence.update": ({"availability": _enum("AVAILABLE", "DND", "AFK", "BUSY", "BREAK")}, {"status_text": _short}),
    "whisper.message": ({"text": lambda v: _text(v, 4096, 1)}, {"reply_to": _uuid}),
    "bookmark.card": ({"target_type": _enum("world", "avatar"), "target_id": _id}, {"label": _short, "note": _body}),
    "recommend.world": ({"world_id": _world}, {"label": _short, "note": _body}),
    "recommend.avatar": ({"avatar_id": _avatar}, {"label": _short, "note": _body}),
    "party.snapshot": ({"party_id": _id, "revision": _revision, "title": _title},
                       {"members": _list(_id, 32), "roles": _roles, "current_destination": _world,
                        "next_destination": _world, "notes": _body, "host": _id}),
    "ready.request": ({"request_id": _id, "prompt": _title, "deadline": _number}, {"recipients": _list(_id, 32)}),
    "ready.response": ({"request_id": _id, "state": _enum("READY", "NOT_READY", "DECLINED")}, {}),
    "countdown.start": ({"countdown_id": _id, "target_at": _number}, {"title": _title}),
    "photo.plan": ({"title": _title}, {"shots": _list(_title, 40), "notes": _body, "photographer": _id}),
    "media.cue": ({"cue": _enum("PLAY", "PAUSE", "SEEK", "NEXT_MARKER", "START_AT", "STOP"), "media_session_id": _id},
                  {"position": lambda v: _number(v, 86400), "execute_at": _number, "label": _short}),
    "safety.checkin": ({"request_id": _id}, {"prompt": _title}),
    "safety.response": ({"request_id": _id, "state": _enum("OK", "NEED_MINUTE", "LEAVING", "DISMISSED")}, {}),
    "safety.alert": ({"state": _enum("ACTIVE", "CLEARED"), "trigger": _enum("MANUAL", "AUTOMATIC")}, {"note": _short}),
    "troubleshooting.request": ({"request_id": _id, "sections": _list(_enum("runtime", "metrics", "errors"), 3)}, {"note": _body}),
    "troubleshooting.response": ({"request_id": _id, "accepted": _bool}, {"note": _body}),
    "creator.snapshot": ({"playtest_id": _id, "revision": _revision, "title": _title},
                         {"phase": _short, "target": _short, "notes": _body, "participants": _list(_id, 32)}),
    "diagnostic.confirm": ({"event_id": _id, "category": _enum("frame_spike", "load_timeout", "disconnect", "runtime_unresponsive", "other"),
                            "time_bucket": _integer, "context_hash": _id}, {}),
    "encounter.confirm": ({"encounter_id": _id, "context_hash": _id}, {}),
    "role.assign": ({"role": _role, "peer_id": _id}, {"revision": _revision}),
    "checklist.snapshot": ({"checklist_id": _id, "revision": _revision, "title": _title, "items": _list(_check_item, 80)}, {}),
    "notice.show": ({"title": _title}, {"body": lambda v: _text(v, 500), "category": _enum("general", "ready", "photo", "creator", "safety"),
                                       "duration": lambda v: _number(v, 15, 1)}),
    "novelty.confetti": ({"execute_at": _number, "style_id": _enum("gentle", "celebrate", "stars")}, {}),
}


def _json_size(value):
    try:
        return len(json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8"))
    except (ValueError, TypeError, UnicodeError, RecursionError):
        _fail("Invalid JSON value")


def validate_payload(kind, payload):
    if not isinstance(kind, str) or kind not in FEATURES:
        _fail("Unsupported message type")
    if _json_size(payload) > FEATURES[kind]["max_bytes"]:
        _fail("Payload exceeds limit")
    if kind in SCHEMAS:
        clean = _object(payload, *SCHEMAS[kind])
    else:
        # Card validators are pure local helpers, not network/optional dependencies.
        from peer_tools import (validate_diagnostic_card, validate_performance_card,
                                validate_session_card, validate_config_package)
        from bridge_lab_peers import validate_card as validate_lab_card
        validators = {"lab.observation": validate_lab_card, "diagnostics.card": validate_diagnostic_card,
                      "performance.card": validate_performance_card,
                      "session.card": validate_session_card,
                      "config.package": validate_config_package}
        try:
            clean = validators[kind](payload)
        except (TypeError, ValueError, KeyError, OverflowError, RecursionError):
            _fail("Invalid shared card")
    if kind == "bookmark.card":
        clean["target_id"] = _reference(clean["target_id"], "wrld" if clean["target_type"] == "world" else "avtr")
    if kind == "checklist.snapshot":
        ids = [x["item_id"] for x in clean["items"]]
        if len(ids) != len(set(ids)):
            _fail("Duplicate checklist identifier")
    if kind == "media.cue" and clean["cue"] == "SEEK" and "position" not in clean:
        _fail("Seek requires a position")
    return clean


def envelope(kind, payload, *, sender, recipient, session, now=None, context="", generation=0):
    now = time.time() if now is None else now
    if not isinstance(kind, str) or kind not in FEATURES:
        _fail("Unsupported message type")
    raw = dict(protocol_version=PROTOCOL_VERSION, message_id=str(uuid.uuid4()), kind=kind,
               sender=sender, recipient=recipient, session=session, created_at=now,
               expires_at=now + FEATURES[kind]["ttl"], context=context,
               generation=generation, payload=payload)
    return validate_envelope(raw, now=now)


def validate_envelope(raw, now=None):
    now = time.time() if now is None else _number(now)
    if _json_size(raw) > MAX_FRAME_BYTES:
        _fail("Envelope exceeds limit")
    clean = _object(raw, {"protocol_version": lambda v: _integer(v, PROTOCOL_VERSION, PROTOCOL_VERSION),
                         "message_id": _uuid, "kind": _id, "sender": _id, "recipient": _id, "session": _id,
                         "created_at": _number, "expires_at": _number,
                         "context": lambda v: "" if v == "" else _id(v), "generation": _revision,
                         "payload": lambda v: v})
    feature = FEATURES.get(clean["kind"])
    if feature is None:
        _fail("Unsupported message type")
    if (clean["expires_at"] <= now or clean["created_at"] > now + MAX_CLOCK_SKEW or
            clean["expires_at"] <= clean["created_at"] or
            clean["expires_at"] - clean["created_at"] > feature["ttl"] + 0.001):
        _fail("Expired or invalid message lifetime")
    if feature["context_required"] and not clean["context"]:
        _fail("Shared action requires a context")
    clean["payload"] = validate_payload(clean["kind"], clean["payload"])
    p = clean["payload"]
    if clean["kind"] in ("ready.request", "countdown.start", "novelty.confetti", "media.cue"):
        field = {"ready.request": "deadline", "countdown.start": "target_at", "novelty.confetti": "execute_at", "media.cue": "execute_at"}[clean["kind"]]
        if field in p and (p[field] <= now or p[field] > clean["expires_at"]):
            _fail("Scheduled action is outside its lifetime")
    return clean


def encode(raw, now=None):
    return json.dumps(validate_envelope(raw, now), ensure_ascii=False, allow_nan=False,
                      separators=(",", ":")).encode("utf-8")


def _pairs(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            _fail("Duplicate JSON field")
        result[k] = v
    return result


def decode(data, now=None):
    if not isinstance(data, (bytes, str)) or not 1 <= len(data) <= MAX_FRAME_BYTES:
        _fail("Invalid frame size")
    try:
        if isinstance(data, bytes):
            data = data.decode("utf-8", "strict")
        if len(data.encode("utf-8")) > MAX_FRAME_BYTES:
            _fail("Invalid frame size")
        raw = json.loads(data, object_pairs_hook=_pairs, parse_constant=lambda _: _fail("Nonfinite JSON number"))
    except (ValueError, TypeError, UnicodeError, RecursionError):
        _fail("Invalid peer JSON")
    return validate_envelope(raw, now)


class ReplayWindow:
    """Reject duplicate IDs; a full unexpired window fails closed."""
    def __init__(self, maximum=4096, clock=time.time):
        self.maximum = _integer(maximum, 65536, 1)
        self.clock = clock
        self._seen = OrderedDict()
        self._lock = threading.RLock()

    def accept(self, message, now=None):
        now = self.clock() if now is None else now
        key = (_id(message["sender"]), _id(message["session"]), _uuid(message["message_id"]))
        expires = _number(message["expires_at"])
        with self._lock:
            for old in [k for k, expiry in self._seen.items() if expiry <= now]:
                self._seen.pop(old, None)
            if expires <= now or key in self._seen or len(self._seen) >= self.maximum:
                return False
            self._seen[key] = expires
            return True

    def clear(self):
        with self._lock:
            self._seen.clear()


class RateLimiter:
    """Bounded per-device, per-family token buckets using a monotonic clock."""
    LIMITS = {"novelty": (1, 10), "safety": (2, 60), "troubleshooting": (2, 60),
              "notice": (3, 10), "diagnostics": (3, 30), "config": (2, 60)}

    def __init__(self, clock=time.monotonic, maximum=1024):
        self.clock, self.maximum = clock, maximum
        self._buckets = OrderedDict()
        self._lock = threading.RLock()

    def allow(self, peer, family, now=None):
        _id(peer)
        if family not in FAMILIES and family != "control":
            _fail("Unknown permission family")
        now = self.clock() if now is None else now
        capacity, seconds = self.LIMITS.get(family, (12, 10))
        with self._lock:
            key = (peer, family)
            if key not in self._buckets and len(self._buckets) >= self.maximum:
                # Only evict inactive buckets whose full capacity has recovered.
                for stale, (_, previous) in list(self._buckets.items()):
                    if now - previous >= 60:
                        self._buckets.pop(stale)
                if len(self._buckets) >= self.maximum:
                    return False
            tokens, previous = self._buckets.get(key, (float(capacity), now))
            tokens = min(capacity, tokens + max(0, now - previous) * capacity / seconds)
            allowed = tokens >= 1
            self._buckets[key] = (tokens - 1 if allowed else tokens, max(previous, now))
            return allowed


class PermissionEngine:
    """Explicit directional consent. A once rule is bound to one message.

    Persistent DENY takes precedence over any temporary ALLOW. Session/context
    rules are exact matches and never carry into a reconnect. Nothing grants trust
    from an alias, network membership, or a claimed VRChat friendship.
    """
    def __init__(self, clock=time.time):
        self.clock = clock
        self._rules = []
        self._blocked = set()
        self._global_denied = set()
        self._paused = False
        self._lock = threading.RLock()

    def _prune(self, now):
        self._rules[:] = [r for r in self._rules if r["expires_at"] is None or r["expires_at"] > now]

    def set(self, peer, family, decision, scope="persistent", direction="receive", *,
            session="", context="", message_id="", now=None):
        peer = _id(peer)
        if family not in FAMILIES:
            _fail("Unknown permission family")
        decision = _enum("allow", "deny", "ask")(decision)
        scope = _enum("once", "session", "hour", "persistent")(scope)
        direction = _enum("send", "receive")(direction)
        now = self.clock() if now is None else _number(now)
        if session:
            _id(session)
        if context:
            _id(context)
        if scope == "session" and not session:
            _fail("Session permission requires a session")
        if scope == "once":
            _uuid(message_id)
        elif message_id:
            _fail("Message binding is for once permission")
        rule = dict(peer=peer, family=family, decision=decision, scope=scope, direction=direction,
                    session=session if scope in ("once", "session") else "", context=context,
                    message_id=message_id, created_at=now,
                    expires_at=now + (300 if scope == "once" else 3600) if scope in ("once", "hour") else None)
        with self._lock:
            self._prune(now)
            self._rules[:] = [r for r in self._rules if not all(r[k] == rule[k] for k in
                              ("peer", "family", "scope", "direction", "session", "context", "message_id"))]
            if len(self._rules) >= 4096:
                _fail("Permission rule limit reached")
            self._rules.append(rule)
        return copy.deepcopy(rule)

    def decide(self, peer, family, direction="receive", *, session="", context="", message_id="", now=None, consume=False):
        _id(peer)
        if family not in FAMILIES:
            _fail("Unknown permission family")
        _enum("send", "receive")(direction)
        now = self.clock() if now is None else now
        def result(decision, reason, scope=""):
            return dict(decision=decision, allow=decision == "allow", reason=reason, scope=scope)
        with self._lock:
            self._prune(now)
            if self._paused:
                return result("deny", "Peer networking paused")
            if peer in self._blocked:
                return result("deny", "Peer blocked")
            if (family, direction) in self._global_denied:
                return result("deny", "Feature disabled")
            matches = [r for r in self._rules if r["peer"] == peer and r["family"] == family and r["direction"] == direction
                       and (not r["context"] or r["context"] == context)
                       and (not r["session"] or r["session"] == session)
                       and (r["scope"] != "once" or r["message_id"] == message_id)]
            denied = [r for r in matches if r["decision"] == "deny"]
            if denied:
                return result("deny", "Explicit peer denial", denied[-1]["scope"])
            if not matches:
                return result("ask", "No matching permission")
            rank = {"once": 4, "session": 3, "hour": 2, "persistent": 1}
            rule = max(matches, key=lambda r: (rank[r["scope"]], r["created_at"]))
            answer = result(rule["decision"], "Explicit user permission", rule["scope"])
            if consume and rule["scope"] == "once":
                self._rules.remove(rule)
            return answer

    def revoke(self, peer=None, family=None, temporary_only=False, *, decisions=None):
        if decisions is not None:
            if not isinstance(decisions, (tuple, list, set)) or not set(decisions).issubset({"allow", "deny", "ask"}):
                _fail("Invalid revocation decision filter")
        with self._lock:
            self._rules[:] = [r for r in self._rules if not ((peer is None or r["peer"] == peer) and
                (family is None or r["family"] == family) and (not temporary_only or r["scope"] != "persistent") and
                (decisions is None or r["decision"] in decisions))]

    def block(self, peer, blocked=True):
        _id(peer)
        _bool(blocked)
        with self._lock:
            if blocked:
                if len(self._blocked) >= 4096 and peer not in self._blocked:
                    _fail("Blocked peer limit reached")
                self._blocked.add(peer)
                self.revoke(peer)
            else:
                self._blocked.discard(peer)

    def set_paused(self, paused):
        with self._lock:
            self._paused = _bool(paused)

    def deny_family(self, family, direction="receive", denied=True):
        if family not in FAMILIES:
            _fail("Unknown permission family")
        _enum("send", "receive")(direction)
        with self._lock:
            if _bool(denied):
                self._global_denied.add((family, direction))
            else:
                self._global_denied.discard((family, direction))

    def end_session(self, session):
        with self._lock:
            self._rules[:] = [r for r in self._rules if r["session"] != session]

    def end_context(self, context):
        if not context:
            return
        with self._lock:
            self._rules[:] = [r for r in self._rules if r["context"] != context]

    def snapshot(self, persistent_only=False):
        with self._lock:
            self._prune(self.clock())
            return dict(rules=copy.deepcopy([r for r in self._rules if not persistent_only or r["scope"] == "persistent"]),
                        blocked=sorted(self._blocked), global_denied=[list(v) for v in sorted(self._global_denied)],
                        paused=self._paused)

    def restore(self, snapshot):
        """Restore only persistent settings; never resurrect temporary consent."""
        if not isinstance(snapshot, dict):
            _fail("Invalid permission settings")
        rules, blocked, denied = snapshot.get("rules", []), snapshot.get("blocked", []), snapshot.get("global_denied", [])
        if not isinstance(rules, list) or len(rules) > 4096 or not isinstance(blocked, list) or len(blocked) > 4096:
            _fail("Invalid permission settings")
        fresh = PermissionEngine(self.clock)
        for r in rules:
            if not isinstance(r, dict):
                _fail("Invalid permission rule")
            if r.get("scope") != "persistent":
                continue
            fresh.set(r.get("peer"), r.get("family"), r.get("decision"), direction=r.get("direction"), context=r.get("context", ""))
        for peer in blocked:
            fresh.block(peer)
        if not isinstance(denied, list) or len(denied) > len(FAMILIES) * 2:
            _fail("Invalid global permissions")
        for row in denied:
            if not isinstance(row, list) or len(row) != 2:
                _fail("Invalid global permission")
            fresh.deny_family(*row)
        with self._lock:
            self._rules, self._blocked, self._global_denied = fresh._rules, fresh._blocked, fresh._global_denied
