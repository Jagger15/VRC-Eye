> Development 6 extends this foundation with opt-in persistent source watching,
> contact sheets/strips and saved projects. See [the current automation guide](PHOTOS_AUTOMATION_1_20.md).
> The Development 4 descriptions of absent watching/strips below are historical.

# VRChat Photos — Development 4 guide

## Open and choose a workspace

Open **You → VRChat Photos**, or use Ctrl+K and search **VRChat Photos**. The
workspace has Library, Sources, Albums & Sessions, Review & Export, Photo Booth
and Activity. These are views of one catalog in the existing companion database.
Use the workspace dropdown to reach all six sections in Casual view or smaller
windows, where only a subset is presented as visible tabs.

A connected account uses its validated user ID for logical catalog scope. When
not connected, the workspace is **local**. Signing in changes the visible scope;
it does not silently transfer your local photos into an account. There is still
one active authentication session in VRC Eye. Logical photo separation is not an
encrypted store, physical file separation or a complete account-isolation upgrade.
Two accounts can explicitly reference the same physical image; byte equality
never merges their identities, notes, thumbnails or memberships.

Demo and Safe Mode do not grant write permission. Local use in normal mode needs
neither VRChat authentication nor VRCX, a Unity project, a bridge or a GPU sensor.
Opening Photos reads its existing catalog; no original-folder scan, original-image
load, network request, OSC send or listener starts automatically.

## First import

Choose **Import selected files…**, select local images and review their exact
locations and workspace. A background task reads and fingerprints supported
images, prepares bounded thumbnails and creates references. Nothing is copied
into a managed original store. Moving/removing an original later affects its
reference; back up originals separately from VRC Eye's database.

Supported input is PNG, JPEG and single-frame WebP, at most 64 MiB and 32 megapixels
with a 16,384-pixel maximum edge. Animated/multilayer inputs and unsupported formats
are rejected rather than silently discarding layers. EXIF orientation is applied
for the displayed geometry. Color-management/ICC fidelity and every decoder edge
case are not certified; this is not an archival color-proofing tool.

An explicit import/scan processes at most 256 new/changed candidates, 512 MiB of
input and approximately 120 seconds between bounded steps. Cancellation is checked
between I/O/decode steps; a native decode is not a separately killable sandbox.
Memory has per-image/queue bounds, not an OS-enforced process memory quota.

## Approve and scan folders

In Sources, choose a real folder, label it and select whether subfolders should be
included. Approval only records the source. **Scan selected source** requires a
second review. A source is tied to its observed directory identity, not just the
text of its path. A replaced/remounted directory requires review/reapproval.

One workspace allows 64 sources and rejects overlapping recursive ownership.
Discovery visits at most 20,000 directory entries and eight nested levels. Links,
Windows reparse points and unsupported special files are not traversed. The scan
skips managed export/trash directory names and known VRC Eye export destinations.
It does not depend on changing VRCX settings or on a second VRCX detector.

Unchanged known files are skipped using stat evidence, without claiming a new
content hash. Explicitly recheck a photo for fresh byte evidence. Subsequent
manual scans advance through bounded batches. A missing-file result is assigned
only after complete discovery under the same approved root; a missing/offline
root or incomplete scan does not erase the catalog. Last-known state is not
continuous monitoring. New/changed files too recent to import are skipped for a
later explicit retry.

**Find folder suggestions** reads the selected log folder's config.json and its
picture_output_folder declaration where present. On Windows a read-only adapter
requests the current Pictures known-folder location without creating or verifying
it. Lookup failure is shown and a fallback remains only a candidate. On Linux,
XDG Pictures declarations are parsed without running shell text. Explicitly select
a real Proton prefix to map a configured C: path; custom drive mappings/UNC paths
must be selected manually. No global home-directory or Steam-prefix search occurs.

Suggestions are not approval, existence checks or evidence that a directory holds
VRChat captures. Windows known-folder behavior was ABI-fixture tested, not run on
Windows. Flatpak permissions, cloud placeholders and network drives require
native validation; this checkpoint does not request broader sandbox permissions.

## Browse, annotate and maintain references

Library provides a stable-ID list and a 12-card page; list pages contain 48 rows.
Text, favorites, date, manually linked world and last-known file-state filters
combine. Source, album or retained-session selection can narrow that view. Use
Reset filters to leave those contexts. Text queries search local title/notes,
not remote VRChat or hidden recognized text.

Select an image to edit its local title, notes or exact manual world link. Saving
notes does not write the original file, EXIF or a sidecar. Favorites are local
photo state, not VRChat game favorites. Metadata world candidates are never
adopted as verified identity, ownership or instance-access evidence.

**Hide / restore reference** changes catalog visibility, not the file. Hidden
photos can be viewed deliberately and restored. This checkpoint has no original
trash/permanent-delete/move/rename command. Deleting an album deletes only that
album and memberships, not photos. Exact-byte duplicate reports do not merge
records or select a file for deletion.

**Recheck** compares fresh bytes with the retained digest. Different bytes become
Changed until explicitly imported; a normal re-import at the same path creates a
new photo identity, leaving the previous version Replaced. The new version does
not inherit the old favorite, notes, session/world link or privacy review. Missing
or unreadable sources keep records and clear stale thumbnails.

**Relink identical bytes** lets a moved original retain its photo identity,
favorites and albums after a full hash check. Different bytes are rejected; a
path already occupied by another logical photo is not merged. Relinking clears
its old source association; a later explicit source scan can reassociate it.

Thumbnails are a disposable, scope-bound cache, limited to 32 MiB per workspace
and 220 × 160 pixels each. Eviction or Clear disposable thumbnails leaves the
original/catalog intact. Recheck/import rebuilds a selected thumbnail. Eviction
does not silently open all originals to regenerate an entire gallery.

## Albums, sessions and covers

Create a manual album and add/remove selected photo references. A smart album
stores the current supported text/date/world/favorite/state filters; membership
is evaluated, not copied. Album membership is further narrowed by visible
filters. A workspace allows 256 albums. Covers require visible, last-known
available photos; manual album covers also require membership.

**Load retained sessions** reads the existing PlayerHistory, 100 at a time. It
never reconstructs deliberately forgotten or private history, captures a second
roster, or treats someone present in a session as pictured. This old history is
local OS-user history, not verified account ownership. Linking a photo to a
session is an explicit manual correction; image timestamps do not prove it.

A session cover is a local photo reference within Photos. It is not uploaded and
is not yet a global session-card/streamer cover publisher. Link/preview actions
recheck whether the session remains available and nonprivate. A removed/private
session can leave an inert local ID association until unlinked, but its hidden
world/roster details are not reconstructed. User-driven views refresh on action;
the page does not subscribe to all history changes in real time.

## Preview and privacy review

The 2D image window supports bounded fit/zoom/reset and panning/scrolling. It is
not an original-file external-editor handoff, full-resolution archival renderer,
3D viewer or facial-recognition system. The selected original is read only after
an explicit preview request.

**Metadata presence report** contains field names, bounded unverified world-ID
candidates, date candidates/basis/conflicts and GPS/text presence indicators.
Unreadable EXIF produces unknown GPS state, not a false privacy clearance. Raw
GPS coordinates, embedded text/URLs and private instance tokens are not retained
as photo metadata. An image name, local notes or world ID can still be private.

EXIF and filename times are labeled declarations with unknown timezone when no
trusted zone is established. Filesystem modified time is explicitly not capture
time. Date filters use the declared date labels, not a normalized proof that two
captures happened at the same instant. No automatic session association occurs.

Visible pixels are **not scanned** by OCR, face matching or an online model.
Review names, screens, QR codes, people and other details yourself. Metadata
removal alone is not a guarantee that a photo is safe to share.

## Produce a separate flattened export

Select a photo, then Review & Export. The recipe supports a rectangular crop,
up to 32 opaque black redaction rectangles, maximum image edge 256–8192 pixels,
and optional static White/Dark border. Coordinates refer to the EXIF-oriented
source image before crop/resize, as x0,y0,x1,y1 with right/bottom exclusive.
Separate redaction rectangles with semicolons. Numeric entry is the keyboard
alternative; an interactive drag-to-redact editor is not implemented.

Masks are painted before crop and downscale. Transparency is flattened onto white;
there is no hidden alpha layer. The maximum image edge applies before the optional
border. Generate reviewed output to view the actual rendered bytes, then inspect
again as needed. A changed recipe, selection, privacy/account context or expired
five-minute review invalidates the result. Do not rely on a previous privacy
review after changing the image.

**Export reviewed PNG…** asks for a new .png destination, shows the exact account,
source and output location, rechecks source stat/hash, and saves exclusively. It
never overwrites the original or any existing file. A neutral output name is
suggested; a user-chosen filename may still disclose information. No share,
clipboard, drag-out or remote upload is performed by export.

The final RGB PNG is validated to contain only IHDR/IDAT/IEND chunks with valid
checksums and no appended data. Source EXIF/text/ICC metadata, embedded source
previews, originals, hidden layers and sidecars are not included. This does not
remove information already visible in pixels or guarantee color fidelity.

The current recipe/review is in memory. Successful export records the recipe and
digests for activity evidence, but there is no saved/reopenable editing-project UI,
versioned recipe manager or automatic future rerendering.

## Photo Booth

The delivered creative feature is static bordered export. The tab also navigates
to the existing shared OSC Camera and Eye-to-Eye Planner. Navigation does not arm
OSC, capture, prepare the map-camera preset, hide players, start a countdown or
transmit an image. Full booth sessions, strips, contact sheets, custom templates,
new trigger attribution and automatic captured-file association are pending.

## Tasks, interruptions and privacy

Activity shows the latest 100 tasks/export destination reviews. A durable task
receipt precedes import/export execution. A durable private destination/hash
record precedes opening an output file. If the PNG finishes but its completion
record cannot be saved, the result explicitly says the PNG WAS SAVED; inspect
the recorded destination instead of blindly repeating it.

Cancellation leaves already completed imports/exports intact and waits for the
photo worker slot to stop before accepting another task. Account changes cancel
remaining work and clear old images/drafts/reviews, but completed records remain
under the initiating workspace. Restarted Running tasks are shown as interrupted,
not replayed. Acknowledge only after checking the outcome. An acknowledgement is
not proof that a file operation completed.

Retry receipt save locally only saves an in-memory task outcome and does not
repeat an export. Clear completed history removes completed/acknowledged local
receipts, not originals or export inventory. An identifier-free selected receipt
export excludes photo titles, account IDs, paths, notes, images and raw errors.
The private database itself still contains local paths and user organization.

A workspace supports 20,000 logical photos, 20,000 export inventory records and
2,000 task/export-recovery records per relevant table. It does not silently prune
original references at those limits. Clear reviewed terminal history to free task
capacity. Export inventory retention/compaction and a dedicated full-library
backup/portability workflow remain pending; database backup alone is not an
original-photo backup.

Privacy view clears this page's thumbnails, preview windows, notes, candidates,
paths, selected identities and pending reviews. Local paths are hidden by default
outside explicit reviews. This is **page-specific privacy**, not an app-wide
streamer mode, database encryption or a screen-reader certification.

## References and validation

Pillow's primary API documentation informed bounded image decoding and output;
all new file/recipe/account behavior is exercised with synthetic local fixtures.
Actual Windows, cloud-drive, native assistive technology and XR behavior remain
unverified. No original user image or live VRChat account was used for validation.

Pillow Image API: https://pillow.readthedocs.io/en/stable/reference/Image.html
Microsoft known folders: https://learn.microsoft.com/en-us/windows/win32/shell/known-folders
SHGetKnownFolderPath: https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shgetknownfolderpath
Known-folder flags: https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/ne-shlobj_core-known_folder_flag
CoInitializeEx: https://learn.microsoft.com/en-us/windows/win32/api/combaseapi/nf-combaseapi-coinitializeex
Retrieved October 2, 2026. These references do not establish native compatibility.
