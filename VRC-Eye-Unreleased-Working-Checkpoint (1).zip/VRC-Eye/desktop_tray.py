"""Optional tray lifecycle; no window is hidden until a tray reports ready."""
import os
from pathlib import Path
import queue
import sys
import threading


class Tray:
    def __init__(self):self.icon=None;self.ready=False;self.closed=False;self.events=queue.Queue(8);self.status='Not started';self.thread=None
    def start(self):
        if self.icon or self.closed:return
        try:
            import pystray
            from PIL import Image,ImageDraw
            if not pystray.Icon.HAS_MENU:raise ValueError('This desktop tray cannot provide a reliable Show / Quit menu.')
            icon=Image.new('RGBA',(64,64),(18,26,38,255));draw=ImageDraw.Draw(icon)
            draw.ellipse((7,18,57,46),outline=(94,234,190,255),width=5);draw.ellipse((25,25,39,39),fill=(94,234,190,255))
            def event(name):
                try:self.events.put_nowait(name)
                except queue.Full:pass
            self.icon=pystray.Icon('VRC-Eye',icon,'VRC Eye is running',pystray.Menu(
                pystray.MenuItem('Show VRC Eye',lambda *_:event('show'),default=True),
                pystray.MenuItem('Quit VRC Eye',lambda *_:event('quit'))))
            def setup(icon):icon.visible=True;self.ready=True;self.status='Tray ready'
            self.icon.run_detached(setup=setup);self.status='Waiting for desktop tray'
        except Exception:
            self.icon=None;self.ready=False;self.status='Tray unavailable; use normal minimize / quit'
    def close(self):
        self.closed=True;self.ready=False
        if self.icon:
            try:self.icon.stop()
            except Exception:self.status='Tray cleanup unconfirmed'
            self.icon=None


def startup(enabled):
    """Only an installed executable can register itself; source runs cannot."""
    if type(enabled) is not bool or not getattr(sys,'frozen',False):raise ValueError('Start with OS is available only for an installed executable build.')
    from creator_projects import assert_no_links,local_path
    exe=assert_no_links(local_path(sys.executable))
    if not exe.is_file():raise ValueError('Installed executable unavailable.')
    if os.name=='nt':
        import winreg
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Windows\CurrentVersion\Run') as key:
            if enabled:winreg.SetValueEx(key,'VRC Eye',0,winreg.REG_SZ,'"'+str(exe)+'"')
            else:
                try:winreg.DeleteValue(key,'VRC Eye')
                except FileNotFoundError:pass
    elif sys.platform.startswith('linux'):
        root=Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')/'autostart';assert_no_links(root);root.mkdir(parents=True,exist_ok=True)
        path=root/'vrc-eye.desktop';assert_no_links(path)
        if enabled:
            quoted=str(exe).replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$').replace('%','%%')
            from photo_organize import publish
            if path.exists():
                current=path.read_text()
                if 'X-VRC-Eye-Owned=true\n' not in current:raise ValueError('A different startup entry already occupies this path.')
                path.unlink()
            publish(path,('[Desktop Entry]\nType=Application\nName=VRC Eye\nExec="'+quoted+'"\nX-VRC-Eye-Owned=true\n').encode())
        elif path.exists():
            if 'X-VRC-Eye-Owned=true\n' not in path.read_text():raise ValueError('Startup entry ownership is unconfirmed.')
            path.unlink()
    else:raise ValueError('Start with OS supports Windows and Linux only.')
    return 'Start with OS enabled' if enabled else 'Start with OS disabled'
