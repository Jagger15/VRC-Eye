"""Stable-ID hierarchy and component changes from creator-declared manifests."""
from mod_workflows import hierarchy_nodes


class HierarchyPanel:
    def __init__(self,page,parent):
        self.page=page;self.manifest={};self.baseline=None;self.nodes={};tk,ttk=page.tk,page.ttk
        frame=ttk.LabelFrame(parent,text='Creator hierarchy browser',padding=8);frame.pack(fill='both',expand=True,pady=6)
        row=ttk.Frame(frame);row.pack(fill='x');self.query=tk.StringVar();self.root=tk.StringVar();self.changed=tk.BooleanVar()
        ttk.Label(row,text='Search names / components').pack(side='left');search=ttk.Entry(row,textvariable=self.query,width=28);search.pack(side='left',padx=5);search.bind('<Return>',lambda _:self.refresh())
        for label,action in (('Search',self.refresh),('Scope to selected',self.scope),('Whole tree',self.clear_scope),('Compare manifest…',self.load_baseline)):
            ttk.Button(row,text=label,command=lambda fn=action:page._call(fn)).pack(side='left',padx=3)
        ttk.Checkbutton(frame,text='Show changed nodes and their parents',variable=self.changed,command=self.refresh).pack(anchor='w')
        self.tree=ttk.Treeview(frame,columns=('components','change'),height=10);self.tree.heading('#0',text='Declared hierarchy');self.tree.heading('components',text='Components');self.tree.heading('change',text='Change')
        self.tree.column('#0',width=290);self.tree.column('components',width=350);self.tree.column('change',width=180)
        scroll=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True)
        self.breadcrumb=tk.StringVar(value='Select a node. Stable IDs come from the imported manifest.');ttk.Label(frame,textvariable=self.breadcrumb,wraplength=920).pack(anchor='w')
        self.tree.bind('<<TreeviewSelect>>',lambda _:self.select())
    def set_manifest(self,manifest):self.manifest=manifest;self.refresh()
    def select(self):
        selected=self.tree.selection()
        if selected and selected[0] in self.nodes:self.breadcrumb.set(self.nodes[selected[0]]['breadcrumb'])
    def scope(self):
        selected=self.tree.selection()
        if selected and selected[0].startswith('current:'):self.root.set(selected[0][8:]);self.refresh()
    def clear_scope(self):self.root.set('');self.refresh()
    def load_baseline(self):
        from tkinter.filedialog import askopenfilename
        from avatar_library_files import checked_stream
        from avatar_manifest import load_manifest
        path=askopenfilename(parent=self.page.app.root,title='Compare a previous creator manifest',filetypes=[('JSON','*.json')])
        if not path:return
        with checked_stream(path,limit=2*1024**2) as (_,stream,_):raw=stream.read(2*1024**2+1)
        self.baseline=load_manifest(raw);self.refresh()
    def refresh(self):
        selected=self.tree.selection();old=selected[0] if selected else None
        values,removed=hierarchy_nodes(self.manifest,self.query.get(),self.root.get(),self.baseline,self.changed.get())
        self.tree.delete(*self.tree.get_children());self.nodes={};pending={r['id']:r for r in values}
        while pending:
            progress=False
            for key,row in list(pending.items()):
                parent=row.get('parent','')
                if parent in pending:continue
                identifier='current:'+key;parent_id='current:'+parent if 'current:'+parent in self.nodes else ''
                self.tree.insert(parent_id,'end',iid=identifier,text=row.get('name',key),values=(', '.join(row.get('components',[])),row['change']),open=True);self.nodes[identifier]=row;del pending[key];progress=True
            if not progress:
                # Invalid/cyclic declared trees stay visible as a flat fallback.
                for key,row in pending.items():
                    identifier='current:'+key;self.tree.insert('','end',iid=identifier,text=row.get('name',key),values=(', '.join(row.get('components',[])),'Unresolved parent'));self.nodes[identifier]=row
                break
        if removed:
            self.tree.insert('','end',iid='removed',text='Removed from previous manifest',open=True)
            for row in removed:
                identifier='old:'+row['id'];self.tree.insert('removed','end',iid=identifier,text=row.get('name',row['id']),values=(', '.join(row.get('components',[])),'Removed'));self.nodes[identifier]=row
        if old in self.nodes:self.tree.selection_set(old)
        self.breadcrumb.set(f'{len(values)} current nodes · {len(removed)} removed · declared manifest only')
