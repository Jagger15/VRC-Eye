> **Development 2 addition:** the existing creator workspace now also includes
> an Avatar Library page. This guide describes the retained creator tools; see
> [Avatar Library guide](AVATAR_LIBRARY_1_20.md) for the new catalog/build/file/
> shader-inventory sections. Actual-model rendering and Unity repair remain
> separate conditional work.

# Avatar Creator workspace — VRC Eye 1.19.5

The creator tools live under **Primary → Avatars**. Existing avatar lookup and backup controls remain available. Creator records are local by default, and the workspace works without VRChat, Unity, an Eye-to-Eye connection or a custom client.

The optional editor package is described separately in [AVATAR_TOOLKIT_SETUP.md](AVATAR_TOOLKIT_SETUP.md). Importing a manifest does not install that package, fetch a model, authorize an editor connection or publish an avatar.

## Workspace tabs

| Tab | What it does |
| --- | --- |
| Creator | Choose or pin an avatar workspace, create a local project identity, import and validate a manifest, save notes and incident bookmarks. |
| Modules | Inspect the 23-concept catalog, review selected platform/tier plans and estimated costs, and compose finite data-only recipes. Saving a plan does not install it. |
| Avatar Link | Connect a reviewed local OSC route, inspect state, arm the current manifest, and review incoming action requests. |
| Parameters | Inspect declared parameters and observed values, freeze a view, review an individual write, and inspect writer ownership and freshness. |
| Preview | Use a generic mannequin or explicitly permitted static reference; record fit and viewpoint observations. |
| Tests | Start a frozen guided checklist, record step results and evidence, finish an immutable run, and inspect isolated contract demonstrations. |
| Diagnostics | Inspect available local signals, select device/provider sources, configure a finite mapping, and enable reviewed routing. |
| Profiles | Save local presets associated with a manifest revision, package, platform and optional account; review supported and unsupported values before applying. |
| History | Work with typed worksheets, builds, issues, release records, manifest comparisons and selected reports/handoffs. |

The identity strip separates a local project or pinned workspace from the avatar currently reported by the client. Recognition changes context, not permissions. A source manifest, local build record and worn published avatar are different evidence. Leaving an avatar does not delete its local notes.

## Start offline

1. Open **Primary → Avatars → Creator** and create a local project, use the selected avatar or pin an explicit avatar ID.
2. Import a creator-supplied schema-1 manifest if available. Import validates bounded JSON and never follows its asset references. The imported source/generated stage and revision stay visible.
3. Run validation. The results include severity, affected object/parameter, evidence and a suggested remedy. Missing supplied information remains unknown.
4. Review a module plan, record an attachment or platform worksheet, and try the generic preview. These operations do not need a provider or running VRChat client.
5. Start a guided test profile and record the actual evidence mode. Keep source, simulation, Unity and live-client results separate.

If no manifest exists yet, author one through the optional Unity package or create a schema-compatible contract in your own authorized workflow. A manifest declares compatibility; it does not prove that the current runtime build exposes the same parameters.

## Local Avatar Link

Enable OSC in VRChat using its own controls. Configure the single shared service under **VRC Eye → Networking → OSC transport**, then select **Attach to shared OSC** here. Usual receive/send ports are **9001 / 9000**; optional free-port fallback and OSCQuery allow coexistence without displacing another listener. Avatar Link does not open a second socket or maintain separate port settings.

Connect first, inspect the current context and imported contract, then use **Review and arm outputs**. A connected socket alone does not enable writes. Private and deliberately public avatar parameters are reviewed separately. When the account, avatar, platform, manifest or relevant session changes, old writers and pending requests are suspended and previous reviews expire. Reconnection requires a fresh context review.

Avatar Link retains bounded, read-only OSC configuration import. Passive OSCQuery discovery and manual inspection now live in the shared OSC controls and Networking pages. Discovery does not arm outputs. Detaching Avatar Link leaves the shared observation service and unrelated reviewed controls available. A global **Stop Controls** suspends all shared writers. See [OSC_CONTROLS_SETUP.md](OSC_CONTROLS_SETUP.md).

Read the displayed evidence literally:

- **Sent** means a local message was transmitted.
- **Observed** means a corresponding parameter update was received.
- **Acknowledged** requires a declared acknowledgment signal.
- **Action confirmed** requires the action destination to report completion.

An echo is not proof of a visible material change, a completed photograph or what another participant sees. Loopback OSC is not cryptographic proof of authorship or intent. Camera and protective-mode requests require a separate desktop review; no arbitrary command or URL from a manifest executes.

The application tracks its own parameter writers. Manual, profile, test and provider writes follow explicit ownership priorities. It cannot identify every competing external application. A stale provider becomes unavailable/neutral where possible; a suspended or unreachable avatar cannot be guaranteed to visibly reset.

Eye-to-Eye and OSC transport settings both live under **VRC Eye → Networking**, with independent permissions. Avatar-side camera requests also require the shared camera capability to be armed; an armed manifest alone does not authorize camera control.

## Signals and privacy

The Diagnostics tab uses already available local sources and records validity, source, sample time and scope. It does not silently start native tracking or a microphone capture service.

Battery/hardware observations come from selected available device roles. Device identity assignments stay local; scalar avatar signals do not carry serial numbers. Process resource observations describe the process, not the cost caused by one avatar. Manual status is labeled manual. Unsupported or stale sources show unavailable instead of a reassuring zero.

Local media choices are bounded and explicit: an isolated synthetic envelope or a selected local PCM WAV analysis cursor. WAV analysis does not play audio, capture system audio or infer the current song. Synthetic values remain labeled and require a separate routing choice before any live use.

Use **Review starter mappings** to prepare the exact matching toolkit inputs, then enable routing separately. Battery lowest uses only assigned devices explicitly included in that summary. The normalized hardware meter needs a selected metric and range; resource thresholds use the displayed metric units. Manual media state is a declared symbol, not inferred playback.

**Start.cmd** automatically prepares the OBS WebSocket dependency; enable the
WebSocket server separately in OBS. If setup cannot complete offline, local
authoring still opens and a later normal launch retries missing dependencies. Connect using its local port and password in Diagnostics. The password is not saved. Connection and read-only polling run off the UI thread; disconnect does not retry automatically.

Privacy has four destinations: local presentation, avatar-public parameters, Eye-to-Eye sharing and exports. Turning off one does not automatically rewrite the other channels. Avatar synchronization is authored into the avatar. Public values are withheld from unapproved routes; the companion cannot dynamically rewrite a parameter asset's Synced setting. Your own camera or capture path can record an otherwise local display.

## Profiles, plans and composer

An **installation preset** describes authoring choices. A **runtime preset** sets only existing, compatible input parameters. Runtime presets cannot add meshes, Contacts, animation layers or missing capabilities.

A profile preview checks exact names, parameter types/ranges, direction, ephemeral/action status, package identity, manifest revision and platform. It does not substitute a similarly named parameter. Public destinations require their own permission path and are not silently approved by importing a preset. Pending actions, heartbeat state and other ephemeral values are excluded from preset application.

Applying several values is not atomic. Each result retains its own sent/rejected/unconfirmed state. The broker has a scoped restore mechanism that refuses to overwrite a newer manual change; a global rollback of unrelated settings is not implied.

The composer combines a finite vocabulary: value display, state indicator, button request, progress meter, acknowledgment and timeout. Its output is inspectable data with an owned-only removal policy and no granted runtime permissions. A theme does not acquire an action permission. Custom recipes are planning documents; this release's Unity backend installs its fixed reviewed starter modules. It does not execute arbitrary downloaded editor code or turn every custom recipe into generated assets automatically.

Estimated costs are labeled estimates. Shared materials, final build processing and platform variants can change actual totals. Final synchronized parameter layouts and generated costs require the relevant build output. Hiding a module at runtime is different from removing it at build time.

## Tests, issues and comparisons

The built-in guided suites cover module initialization/removal, request lifecycle, privacy transitions, fit/accessibility, PhysBones/Contacts, platform parity, test-world stations, raycasts and OSC/profile coexistence. Starting a run copies its instructions and context. Later template edits do not rewrite history.

Record a note or evidence for every Passed/Failed step. Untested, blocked and unavailable steps remain unresolved. A finished run is immutable; start another run to repeat or revise it. The mode labels record the evidence context, not a certification that VRC Eye independently verified every manual claim.

The six isolated demonstrations illustrate provider loss, avatar switching, held-button rearm, missing acknowledgment, privacy transitions and raycast states. They send **zero live commands** and are labeled demonstrations rather than passed runtime tests. Source validation is executable; the full guided live suites still require actual user observations in the relevant client/editor.

Issue state distinguishes **Fix implemented** from **Verified fixed**. Verification requires a completed passing run in the same avatar workspace; a demonstration cannot verify a runtime fix. Record the affected build, fix build and reproduction evidence so another reader can assess the scope.

Baseline comparisons require matching avatar context, source, platform, environment, metric, units, conditions and evidence mode, plus finite repeated samples. An incompatible comparison yields no numerical delta. A compatible difference is descriptive, not proof of a cause.

Local build records keep source revision, toolkit configuration revision, build identity, platform, manifest revision and published association separate. Release states are creator decisions—Draft, Experimental, Ready or Withdrawn—not VRChat moderation or publication results. Nothing in this workspace uploads or publishes an avatar.

## Preview and supplied hierarchy

The generic mannequin provides front, side, back and three-quarter views; T-pose, relaxed and seated demonstrations; left/right/both wrist layouts; independent visual/touch sizes; attachment offsets; and synthetic module state. It does not represent the actual avatar's proportions, rig, materials, collisions or PhysBone simulation. The simulated camera button does not take a photograph.

An explicitly permitted local PNG or single-frame GIF may be displayed as a static reference. Limits are **8 MiB, 2048 pixels per dimension and 4,194,304 pixels total**. Animated content, arbitrary model packages and executable shaders are not loaded. A selected reference stays a reference; the pose controls operate on the generic mannequin. Rendering is event-driven and skips hidden panes.

Creator-supplied hierarchy snapshots are read-only evidence with source/build association. The viewer does not inspect avatars belonging to nearby users. Unity may separately export a static preview from an authorized selected project; that image is not guaranteed to match VRChat rendering.

## Reports, handoffs and optional playtests

Select the exact History records to include, choose HTML, Markdown, JSON or CSV, and review the frozen report. Public/collaborator reports withhold unselected free text, private identifiers, paths and credentials by default. Explicitly enabling free text requires careful review because arbitrary names cannot always be recognized automatically.

Export writes the exact preview and refuses a silent overwrite. HTML contains no scripts or external resources. Markdown embeds untrusted content as data, and CSV cells are guarded against formula interpretation. An attachment reference is never followed merely because a selected record contains it.

A handoff ZIP contains only **avatar-contract.json** and generated **READ-ME.txt** instructions. Source projects, meshes, preview images, private hierarchy, credentials and unselected notes are excluded. The handoff is a portable integration contract, not a complete source-manifest reimport or a Unity installation package. Select and share other authorized assets separately.

Optional playtests reuse the existing peer service. Only explicitly selected sanitized results are shared; readiness and roles do not grant avatar control. Disconnection preserves local records. Avatar test-world worksheets and station checklists work with manual markers; a world helper requires its own independent authorization and supported route.

## Specification coverage and current limits

| Specification features | Implemented surface and boundary |
| --- | --- |
| 1–4: Avatar Link, Unity toolkit, parameter installer, validator | Local OSC broker and reviewed fixed-module editor installer; declarative/source validation. Native Unity and VRChat behavior still requires verification. |
| 5–16: Wrist, status, safety, battery, streamer, music, camera, DND/AFK, connection, hardware, resource, media | Twelve editor-authored primitive starter modules plus local provider/mapping controls. No arbitrary avatar modification, universal media capture or native account-status mutation. |
| 17–18: Contacts and PhysBone debugging | Self-only starter Contact controls, source declarations/validation, worksheets and guided interaction tests. No arbitrary live PhysBone inspector or remote participant control. |
| 19: Profiles | Installation/runtime distinction, exact compatibility preview and reviewed runtime values; unsupported values remain unsupported. |
| 20–21: Authorized hierarchy and manifests | Bounded creator-supplied snapshots, contract validation, provenance and semantic comparison. No model discovery or automatic asset fetching. |
| 22–23: Authorized preview and generic mannequin | Static permitted references and optional Unity-rendered source PNG; interactive generic geometric demonstration. General-purpose imported 3D model rendering/retargeting is not included. |
| 24–25: Workspace and parameter debugger | Dedicated tabs, workspace/context isolation, live values, ownership/freshness evidence, freeze and selected trace/bookmark records. External writers remain uncertain. |
| 26: Property conflicts | Supplied-binding overlap/subtree analysis and investigation worksheet. Full arbitrary animator state-graph analysis and automatic controller repair are not included. |
| 27: Tests and Black Box | Frozen guided runs, isolated demonstrations, source validation and selected incident records/bookmarks. No claim that a simulated pass verifies the client. |
| 28–29: Builds and platform budget | Separate revision records, semantic manifest comparisons, parity checks, scoped baselines and estimated plans. Generated-build measurements need supplied evidence. |
| 30–31: Rig/fit/viewpoint and raycast tools | Typed worksheets, attachment simulation and guided hit/miss/unavailable tests. No live skeleton reconstruction or automatically authored raycast backend. |
| 32: Creator overlay / universal controls | Optional shared overlay presenter and desktop actions. Availability and capture visibility depend on the native runtime; desktop tools remain available. |
| 33–34: Module SDK/composer and handoff | Finite data-only recipes, manifest contract, generated portable instructions and reviewed exports. Custom recipes require creator implementation in Unity. |
| 35–36: Test-world and peer playtests | Manual station workflows and optional selected peer coordination; separate world authority, no raw remote OSC forwarding or source transfer. |

This release's Linux checks do not constitute native Windows, Unity, SteamVR, audio-device, Contact or uploaded-avatar verification. Use the editor package's native checklist and the recorded evidence modes when validating a release for distribution.
