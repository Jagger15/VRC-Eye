# Resume VRC Eye from Development 21

Use VRC-Eye-v1.21.0-Development-21.zip as the current source baseline. It extends the complete Development 20 archive, SHA-256 87a3354528a4c783804159ceafca0e99ca10c9ba87851288d8abbba3f367aee0. Preserve the earlier archives and review artifacts.

The user approved five additions: deeper material/texture inspection, read-only mesh health, explicitly enabled exact-byte association rules with revoke/undo, broader observed profile history, and saved-composer/OSC-display settings backup and undo. All are implemented through existing owners. No supplied utility/mod code or binary was copied or executed.

Read DEVELOPMENT_21_RELEASE_NOTES.md, DEVELOPMENT_21_VALIDATION.md, BUILD_VALIDATION.json and ARC_VRCX_REMAINING_DEV21.md. The complete ARC/VRCX inventory is ARC_VRCX_GAP_LEDGER_DEV21.json. There are 39 Partial and 7 Missing areas; ARC-21 is source implemented with native acceptance open. The separate 160-package roadmap has 51 source-implemented, 70 partial and 39 pending packages.

Final portable evidence: 5,160 passed, 1,059 subtests passed, 475 native-display skips, one inherited deselection and two inherited warnings. All 45 new cases ran. The 13 inherited module exclusions are listed in the validation record. All 665 frozen source hashes and 620 Python grammar checks passed.

Native Windows/Linux rendering/accessibility/account-switch workflows and live/installed-provider qualification remain open. Rules run only on later user-started matching scans, not watchers. Backups exclude rules/receipts and operating grants. Texture zoom enlarges retained thumbnails. Mesh health does not repair geometry. History is observed evidence, not reconstructed remote change time.

Rigs, animations, new FBX/VRCA/Unity-bundle imports, additional bounds corrections, Discord joining and remaining utility proposals were not part of this batch. Do not treat them as implemented or silently enable them. Launch with Start.cmd on Windows or bash Start.sh on Linux after extracting separately. This is not a signed installer or a full 1.21 parity release.
