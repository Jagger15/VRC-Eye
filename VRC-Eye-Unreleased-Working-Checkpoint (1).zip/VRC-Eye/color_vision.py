"""Desktop semantic colors and non-color cues; never filters user media.

Canvas roles retain only item IDs and paint options. Applying a palette repaints
existing items without collecting data, refreshing pages or rebuilding private
content. Tk deletes remain authoritative, including privacy-driven clears.
"""
from functools import lru_cache
import math

from ui_preferences import Presentation

ORIGINAL = ('#11151e', '#1b2230', '#edf3fc', '#a5b2c7', '#65dbbf')
PRESET_ACCENTS = {'Deuteranopia': '#56b4e9', 'Protanopia': '#56b4e9', 'Tritanopia': '#cc79a7'}
DESCRIPTIONS = {
    'Off': 'Theme colors. Labels, marker shapes and chart patterns remain available.',
    'Deuteranopia': 'Red–green option: blue, orange and purple status colors.',
    'Protanopia': 'Red–green option: blue, gold and purple status colors.',
    'Tritanopia': 'Blue–yellow option: teal, pink and red status colors.',
    'Monochrome': 'Neutral interface colors with text, shapes and patterns.',
}
# These are selectable presentation options, not a simulation or a claim of
# clinical suitability. Contrast is derived separately for the actual surfaces.
SEEDS = {
    'Off': ('#65dbbf', '#efc377', '#ff8794', '#69b6ff'),
    'Deuteranopia': ('#56b4e9', '#e69f00', '#cc79a7', '#009e73'),
    'Protanopia': ('#56b4e9', '#f0c442', '#b785dc', '#009e73'),
    'Tritanopia': ('#009e9e', '#cc79a7', '#e66a50', '#69b6ff'),
    'Monochrome': ('#cccccc', '#aaaaaa', '#eeeeee', '#bbbbbb'),
}
STATUS_SAMPLES = (('success', '[OK] Ready'), ('warning', '[!] Needs attention'),
                  ('error', '[X] Unavailable'), ('info', '[i] Information'))
MAP_LEGEND = 'Map markers: triangle = you; circle = player; square frame = selected; diamond = waypoint.'
POPULATION_LEGEND = 'Population: circle / solid = observed or confirmed; diamond / dashed = other quality. Gaps are not zero.'
HEAT_LEGEND = 'Heatmap: empty = no retained activity; 1–4 marks = increasing activity bands relative to this view’s maximum. Select a date for exact hourly values, including repeated daylight-saving hours.'


def neutral(color):
    from appearance_colors import luminance, hex_color
    value = luminance(color)
    value = 12.92 * value if value <= .0031308 else 1.055 * value ** (1 / 2.4) - .055
    return hex_color((value, value, value))


@lru_cache(maxsize=128)
def _roles(vision, base):
    from appearance_colors import readable_accent
    bg, panel, text, muted, accent = base
    values = dict(zip(('success', 'warning', 'error', 'info'),
                      (readable_accent(c, (bg, panel)) for c in SEEDS[vision])))
    values.update(bg=bg, panel=panel, text=text, muted=muted, accent=accent,
                  line=readable_accent(muted, (bg, panel)))
    return tuple(values.items())


def semantic_colors(preferences, base=None):
    from appearance_colors import palette
    base = tuple(base or palette(preferences, ORIGINAL))
    return dict(_roles(preferences.color_vision, base))


def activity_band(value, maximum):
    """Zero has no marks; positive values have one to four equally sized bins."""
    return min(4, max(1, math.ceil(4 * value / maximum))) if value > 0 and maximum > 0 else 0


class CanvasInk:
    def __init__(self, canvas, app=None):
        self.canvas = canvas
        self.app = app
        self.items = {}
        self.colors = {}
        self.refresh()

    def __getattr__(self, name):
        return getattr(self.canvas, name)

    def refresh(self, colors=None):
        if colors is None:
            root = self.canvas._root() if callable(getattr(self.canvas, '_root', None)) else None
            colors = getattr(root, '_eye_semantic_colors', None)
            if not isinstance(colors, dict):
                preferences = getattr(getattr(self.app, 'experience', None), 'preferences', None)
                colors = semantic_colors(preferences if isinstance(preferences, Presentation) else Presentation())
        self.colors = colors
        self.canvas.configure(background=colors['panel'])
        for item, options in tuple(self.items.items()):
            # A privacy clear may delete items directly on the original Canvas.
            # Never create missing items or retain a removed label's text.
            if not self.canvas.type(item):
                self.items.pop(item, None)
                continue
            self.canvas.itemconfigure(item, **{key: colors[role] for key, role in options.items()})

    def delete(self, *items):
        self.canvas.delete(*items)
        if 'all' in items:
            self.items.clear()

    def create(self, kind, *coordinates, **options):
        roles = {key: value[1:] for key, value in options.items()
                 if key in ('fill', 'outline') and isinstance(value, str) and value.startswith('@')}
        for key, role in roles.items():
            options[key] = self.colors[role]
        item = getattr(self.canvas, 'create_' + kind)(*coordinates, **options)
        if roles:
            self.items[item] = roles
        return item

    def create_text(self, *args, **kw): return self.create('text', *args, **kw)
    def create_line(self, *args, **kw): return self.create('line', *args, **kw)
    def create_oval(self, *args, **kw): return self.create('oval', *args, **kw)
    def create_rectangle(self, *args, **kw): return self.create('rectangle', *args, **kw)
    def create_polygon(self, *args, **kw): return self.create('polygon', *args, **kw)

    def backed_text(self, *args, **kw):
        """Opaque backing keeps map labels readable over arbitrary images."""
        item = self.create_text(*args, **kw)
        bounds = self.canvas.bbox(item)
        if bounds:
            x1, y1, x2, y2 = bounds
            backing = self.create_rectangle(x1-2, y1-1, x2+2, y2+1, fill='@panel', outline='')
            self.canvas.tag_lower(backing, item)
        return item


def canvas_ink(canvas, app=None):
    ink = getattr(canvas, '_eye_canvas_ink', None)
    if not isinstance(ink, CanvasInk):
        ink = CanvasInk(canvas, app)
        canvas._eye_canvas_ink = ink
    return ink


def apply_widget_colors(widget, colors):
    ink = getattr(widget, '_eye_canvas_ink', None)
    if isinstance(ink, CanvasInk):
        ink.refresh(colors)
    tags = getattr(widget, '_eye_color_tags', None)
    if isinstance(tags, dict):
        for tag, role in tags.items():
            widget.tag_configure(tag, foreground=colors[role])


def status_tags(widget, app):
    widget._eye_color_tags = dict(changed='success', muted='muted', uncertain='warning')
    colors = getattr(app.root, '_eye_semantic_colors', None)
    apply_widget_colors(widget, colors if isinstance(colors, dict) else semantic_colors(Presentation()))
