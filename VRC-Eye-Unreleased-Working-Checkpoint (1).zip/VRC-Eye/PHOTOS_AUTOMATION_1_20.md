# Photo watching, contact sheets and strips — Development 6

These tools extend the existing Photos catalog, source approvals, image validator,
worker slot, export inventory and account-scoped receipts. They do not need VRChat
sign-in, a bridge, VRCX, Unity or an additional runtime dependency.

## Enable source watching

1. Open **You → VRChat Photos → Sources**. The workspace dropdown also reaches Sources.
2. Approve an exact folder, and explicitly choose whether to include subfolders.
3. Select that source. Choose a 10, 30, 60 or 300 second interval; default is 30.
4. Choose **Enable / resume watching…** and review the scope, path and behavior.
5. Use **Pause selected watch** to stop future passes. Pauses persist after restart.

Approval alone still does not scan. A watch opt-in is separate and saved per photo
workspace. Local/offline scope and each connected account have different grants.
At most eight sources in the active workspace can be enabled. Watches run only
while VRC Eye is running, including when another page is visible. There is no OS
startup task or standalone background service. Remembered grants reconcile after
restart, even if Photos has not been opened yet. Returning to a workspace with an
enabled grant permits its next pass; selecting a local account label is not login.

**Privacy view in Photos, Demo, Safe Mode and shutdown stop automatic imports.**
Account/context changes cancel remaining work; completed imports remain associated
with the workspace that started them. A pass keeps the existing shared photo task
slot until it ends. Pause a source before a long manual photo task if needed.
Cancel pending task stops the current pass; Pause stops future passes as well.

## Stable-file ingestion and recovery

This implementation uses portable polling, not OS filesystem event subscriptions.
It reconciles the approved folder at the selected interval. Existing archives and
newly appearing files follow the same validation; an import is not declared a new
VRChat capture, and no photographer/account ownership is inferred.

A changed/new candidate must have matching file identity/stat evidence across two
observations at least two seconds apart, and a modified time at least two seconds
old at decode. The importer then performs the existing bounded stable-handle read,
full hash, supported-image validation and thumbnail creation. Changing files restart
stability checks. Static malformed or inaccessible candidate images get up to three
decode attempts per unchanged fingerprint in the current run; after that the status
asks for manual retry. Re-enable the source to retry deliberately. A new fingerprint
or application restart establishes fresh retry/stability state.

One pass has independent 15-second discovery/stat/import step budgets, checked
between operations. It imports at most 32 candidates and reads at most 128 MiB of
candidate image bytes. Individual images retain the 64 MiB/32 megapixel limits.
Discovery retains the existing 20,000-entry/eight-depth bounds. These are cooperative
limits, not a killable decoder or hard filesystem timeout. An OS call on an offline
network mount can still take longer. Prefer local folders until those mounts are
validated on your own platform.

Links and Windows reparse points are skipped. Exact VRC Eye export destinations
(including uncertain pre-save records), `.vrc-eye-exports` and `.vrc-eye-trash`
directories are suppressed. This is not a shared VRCX capture/organization protocol;
VRCX settings are unchanged. External copies of exported images can be imported as
ordinary selected photos and are not recognized by image content alone.

Unchanged known references skip fresh decoding. Existing manually imported photos
can acquire their watched source association after validation without losing their
identity, notes or favorites. Different bytes at an old path become a new version
with a new photo identity; they do not inherit annotations or privacy reviews.

A fully discovered, still-identical root can update missing reference states. An
offline root, failed walk or incomplete discovery does not imply deletion. A
replaced/remounted root disables its watch and requires source reapproval. Reapproving
or removing a source clears its old watch grant. Failures back off to at most five
minutes; smaller sources are needed if discovery repeatedly exceeds its bounds.

Each source has one durable latest watch status, rather than adding endless idle
receipts. Batches that attempt imports write the existing task receipt before their
first import. An initial receipt failure prevents that batch; completion-save
failure uses the existing local receipt-retry facility. Activity capacity remains
2,000 task records per workspace; explicitly clear completed history when full.
The latest source status gives new/version/unchanged/waiting/retry/deferred counts.
No per-photo notifications or automatic image sharing are added.

## Build a contact sheet or strip

1. In Library, select a photo and choose **Add selected to contact sheet**, or open
   **Photo Booth** and add the selected photo there.
2. Add 2–24 slots. **Add this visible page** adds the current page in its shown
   order, and refuses the whole action if it would exceed 24 slots. It does not
   silently choose the first 24. Cards shows 12 photos per page.
3. Move a selected slot up/down or remove it. Repeating a photo is allowed only
   when you explicitly add it again; unavailable slots are never silently replaced.
4. Choose Grid, Vertical strip or Horizontal strip. Set grid columns (1–6), cell
   width/height (128–1600), spacing (0–96), White/Dark background and optional numbers.
5. Choose **Generate sheet preview** and inspect the actual combined image.
6. Choose **Export reviewed sheet…**, select a new PNG filename and confirm the
   reviewed destination. Existing files are never overwritten.

Images fit inside their cells with padding. They are not enlarged or automatically
cropped. Output is at most 8192 pixels per edge and 16 megapixels; combined input is
limited to 256 MiB per render, and output to 64 MiB. Sources are decoded one at a
time, using the existing EXIF-orientation and transparency-flattening pipeline.
Numbers label slot positions only. Names, filenames, notes, world/account IDs and
session labels are not inserted into the exported pixels.

**Add selected with current edits** captures the current single-photo crop,
redaction rectangles, edge limit and border from Review & Export into that slot.
Plain Add uses no crop or masks. Later changes to the single-photo form do not
retroactively edit queued slots: remove/re-add the slot to revise its recipe.
Crops and opaque masks are applied before resizing. Sheet layout changes do not
change the sources or other saved projects.

The preview is bounded for screen display. Every source is hash-checked again
before export. Changed/hidden/missing sources, expired or already-used reviews,
changed drafts and different account contexts require a fresh preview. A durable
private destination intent precedes file creation. Successful output is saved as
a separate flattened RGB PNG with only structural PNG chunks, no source metadata,
originals or sidecars. If completion recording fails after save, the UI says the
PNG **WAS SAVED**, and the destination remains in Activity for inspection.

Metadata stripping and redaction controls do not certify visible-content privacy.
Review people, names, screens and codes in every slot. No OCR, facial recognition,
remote upload or image-sharing endpoint is added.

## Save and reopen an editable project

Name the draft and choose **Save new project**. A workspace can retain 64 projects.
Projects contain ordered photo IDs, each slot's data-only edit recipe, and layout.
They are stored alongside the existing catalog; source bytes and previews are not
bundled. Saving a project is not a backup of its source files.

Select a saved project and choose **Load selected project…** to replace the current
unsaved draft after review. A loaded project can be explicitly updated, or saved
under a new identity. **Delete project only…** removes the layout and references,
leaving catalog photos, originals and exported PNGs intact. Every new rendering
requires a new output review; saving/loading never retains an old privacy approval.

Privacy view and account changes clear the in-memory draft, titles, project list,
image windows and reviewed bytes. Logical workspace isolation does not encrypt the
local database, separate physical files, or complete multi-login account isolation.

## Still outside this checkpoint

Physical move/rename/trash, automatic session correlation, arbitrary collage panels,
custom image templates, free-text captions, multi-page PDF sheets, direct publishing,
full backup/restore and XR capture sessions remain pending. Screen-reader, native
Windows, Flatpak, network/cloud-mount and live-provider interoperability have not
been verified here. Linux/Tk workflows use synthetic local images.

Primary implementation references: [Pillow ImageOps](https://pillow.readthedocs.io/en/stable/reference/ImageOps.html)
and [Python threading](https://docs.python.org/3/library/threading.html), retrieved
October 2, 2026. These references do not establish platform certification.
