# ARC continuation: containment and provider identity

This unreleased checkpoint advances ARC-01, ARC-07 and ARC-08 and rechecks the
original acceptance of all 16 inherited ARC partial areas. It does **not** close
all 16: 13 have implemented source awaiting native/provider acceptance, and 3
retain platform/provider implementation or qualification blockers. The six
separately missing ARC capabilities remain in the backlog.

## Implemented

### Linux GLB worker containment — ARC-01

The bundled worker preloads trusted parser code, then installs a libseccomp
syscall allowlist before reading any model bytes. Filesystem access, socket
creation, process creation, new file descriptors and unlisted syscalls return
EPERM. The worker accepts pipe input/output only and refuses unexpected inherited
descriptors or existing threads. It retains the prior CPU/address-space,
streaming output, cancellation and wall-time budgets. The parent requires the
current policy identifier before accepting a successful Linux result; this
identifier is a trusted-bootstrap consistency check, not independent attestation.

Real subprocess tests on Linux x86-64 with libseccomp 2.5.5 verify denied file
reads/writes/metadata/links/renames, IPv4/IPv6/Unix sockets, process creation and
descriptor duplication. Other fixtures verify no input read on policy failure,
extra-descriptor rejection, and real PNG/JPEG, skin and morph parsing under the
filter. Only synthetic temporary files are used in denied-access tests.

Linux GLB preview now requires the distribution's `libseccomp.so.2` and kernel
seccomp support. If installation or policy loading fails, parsing stops with an
explicit diagnostic; there is no silent uncontained fallback. Existing OBJ and
manual workflows remain available. Windows and other platforms retain their
previous resource-limited worker and are explicitly labeled without OS file or
network containment. This Linux policy does not apply to external exporters.

### Recovery installation evidence — ARC-07

Selecting a native AssetRipper executable now snapshots its dedicated installation
folder: at most 4,096 entries and 2 GiB, regular files/directories only. Every file
has a SHA-256 and observed identity. The app rechecks installation contents both
before staging and immediately before launch; changed, added, removed or linked
dependencies invalidate the review. Installation evidence is retained in the job
receipt, including hashes and observed license/notice filenames.

License-file presence and matching hashes are displayed as local evidence.
They do not establish publisher authenticity, license entitlement, actual release
version, provenance of system-loaded dependencies or a supported release adapter.
The snapshot is an application freshness check, not an atomic execution lock.
An installed official release has not been obtained or qualified here.

### Recovery launch environment — ARC-08

Managed recovery now uses a minimal environment and closes inherited descriptors.
It omits app credentials, proxies, dynamic-library preload paths, .NET startup
hooks and the user's configuration paths. Default home/config/cache/temp and .NET
bundle-extraction locations point into the new job's `ProviderState` directory.
The new state folder is exclusive, and logs/partial output remain available.

This changes launch defaults; it does not constrain the exporter's OS access.
Actual AssetRipper success/failure/cancellation, Windows process-tree shutdown,
exporter filesystem/network containment, and exact installed-release qualification
remain open. No exporter was downloaded or launched during this work.

## Remaining gates

| Area | Required before end-to-end closure |
| --- | --- |
| ARC-01 | Windows file/network containment and supported-host qualification; broader providers need their own policies |
| ARC-04, ARC-05 | Native desktop canvas, accessibility and posed-renderer acceptance |
| ARC-07 | Exact official installed release, publisher/license/dependency evidence and qualified adapter registry |
| ARC-08 | Real provider outcomes/cancellation, exporter containment and Windows descendants |
| ARC-09 | Real Unity import and semantic object/fileID/material/rig acceptance |
| ARC-13 through ARC-18 | Compile/run supplied Unity tools and EditMode fixtures; qualify actual imports, shaders, serialized references and copy semantics |
| ARC-19 | Unity domain reload/import callbacks, installed VPM and host recovery/rollback behavior |
| ARC-22, ARC-23 | Real authorized origin range/validator/rate-limit behavior and target-host transfer publication |
| ARC-24 | Native VPM/process/filesystem and power-loss reconciliation acceptance |

No Unity editor, C# compiler, graphical desktop or Windows runtime is available in
this execution environment. All 29 previously supplied new Unity EditMode methods
remain **unrun**, and no desktop/native skip is counted as a pass. In a separate
qualified Unity project containing this package and its existing SDK dependencies,
the provided editor fixtures can be selected with Unity Test Framework:

```text
Unity -batchmode -projectPath <test-project> -runTests -testPlatform EditMode -assemblyNames VrcEye.AvatarToolkit.Tests -testResults <new-results.xml> -logFile <new-editor.log>
```

Passing these fixtures still does not replace the per-platform/pipeline and
interactive acceptance above. See `PARTIAL_COMPLETION_STATUS.json` for the full
original acceptance, `ARC_QUALIFICATION_STATUS.json` for this pass, and
`PENDING_WORKING_VALIDATION.json` → `arc_containment_update` for final evidence.

The public build identity remains `2026.05.10.02.47.1`, compatibility `1.21.0`.
No numbered release, compiled executable or installer was created. The existing
translation work, all earlier ARC/VRCX changes and their historical evidence are
preserved.

Implementation references: [libseccomp API and documentation](https://github.com/seccomp/libseccomp/tree/main/doc),
[Linux no_new_privs](https://docs.kernel.org/userspace-api/no_new_privs.html),
[Unity Test Framework command line](https://docs.unity3d.com/Packages/com.unity.test-framework@2.0/manual/reference-command-line.html).
