# VRC Eye 1.21.0 — Development 13 validation

The final portable regression passed **4,725 tests and 1,059 subtests**,
with **zero failures/errors** and **zero blocked external-socket attempts**, in
118.80 seconds. The run used the final frozen runtime/test source. No runtime,
test, launcher or dependency bytes changed after this run.

There are **475 skipped native-GUI cases**, **1 deselected Unix bridge case**,
and the same **13 excluded local-transport modules** as Development 12. Exclusions
and skips are not passes. Two pre-existing warnings remain: the test-listener
constructor and a deliberately duplicated archive member.

All **557 Python files** parse with the Python 3.10 grammar. The source
manifest covers **602 runtime/test/launcher/requirements/Unity files**.
All **724 Development 12 archive paths** are retained. Launchers and
requirements are unchanged. Package creation verifies every archived byte against
the source and checks the archive CRCs.

Development 13 adds **42 tests** covering transactional profile history, partial/null
observations, observation timestamps, duplicate suppression, stable group/tag comparison,
image-query token redaction, existing history owners, exact/ambiguous file matches,
missing/changed files, candidate changes during commit, account isolation, read budgets,
metadata conflicts, API rate-limit stops, scope/privacy/cancellation boundaries,
restart interruption, optional image failures, null-provider preservation and atomic
metadata/result publication. Headless widget checks construct both new panels and
exercise reviewed matching, metadata batches, continuation and private-state clearing.

Native Tk could not start without a display. A local Xvfb attempt failed to bind
local/Unix sockets. No sandbox escalation was requested this turn. Native Windows/Linux
rendering/accessibility, live VRChat metadata/images, protected credential stores,
hardware audio, Unity, SteamVR, tray and Discord remain **unverified**. Headless
widgets and synthetic provider fixtures do not certify those environments.

Earlier exploratory runs passed 4,723 tests before the final two regression cases
were added for commit-time file changes and null provider fields. Those fixes and
all 42 new cases are included in the final 4,725-test result above.

This is a **runnable Windows/Linux source ZIP**, not a compiled executable or signed
installer. No live VRChat action, uploaded mod execution or update publication was
performed. Complete command/exclusions are in BUILD_VALIDATION.json; remaining
ARC/VRCX functions are in ARC_VRCX_REMAINING_DEV13.md.
