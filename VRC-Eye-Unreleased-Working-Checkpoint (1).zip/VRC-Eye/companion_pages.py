"""Search and Social pages; other sidebar pages are kept in focused modules."""
from dataclasses import replace
import json

import companion_api as api
from companion_data import Entity, entity, entity_id, stamp
from companion_ui import Page, Table, line, button, entry, choice, note
from game_log_ui import GameLogPage
from favorites_ui import FavoritesPage
from feed_ui import FeedPage
from friendly_ui import ScrollPane,flow_line as line


def details(page, record):
    if record: page.detail.set(f"{record.name}\n{record.id}\n{record.detail}")
    else: page.detail.set("Select a result.")


class SearchPage(Page):
    def context(self):
        from account_header import boundary,private
        return boundary(self.app),private(self.app)

    def __init__(self, shell, parent):
        self.viewport = ScrollPane(shell.app, parent,min_width=520)
        parent = self.viewport.body
        super().__init__(shell, parent, "Search")
        self.kind = self.tk.StringVar(value="Users"); self.query = self.tk.StringVar(value="")
        self.scope = self.tk.StringVar(value="Public / featured"); self.detail = self.tk.StringVar(value="Select a result.")
        self.result = None; self.loaded = None
        self.local_due=None;self.instant_local=self.tk.BooleanVar(value=True)
        row = line(self)
        choice(self, row, self.kind, ("Users", "Worlds", "Groups", "Avatars"), self.reset)
        entry(self, row, self.query, 35).bind('<Return>', lambda _: (self.guard(lambda:self.search(0)), 'break')[-1]); button(self, row, "Search / load", lambda: self.search(0))
        row = line(self)
        choice(self, row, self.scope, ("Public / featured", "My uploads", "My avatar favorites"), self.reset)
        button(self, row, "Previous", lambda: self.page(-1)); button(self, row, "Next", lambda: self.page(1))
        button(self, row, "Search avatars…", self.app.search_avatars)
        button(self,row,'Search local library',self.local_search)
        button(self,row,'Global quick search…',lambda: __import__('quick_search_ui').show(self.shell))
        button(self,line(self),'Search AVTRdb metadata…',self.external_avatars)
        self.ttk.Checkbutton(row,text='Instant local matches',variable=self.instant_local).pack(side='left')
        note(self, "Users, worlds and groups support API name search or exact IDs. Avatar names filter the current collection page; use Next for later pages. Avatar scopes are your uploads, favorites or featured. Exact avtr_ IDs are also supported.")
        from search_tiles import ResultTiles
        self.table = ResultTiles(self, parent, self.selection)
        pictures=line(self);button(self,pictures,'Retry pictures',self.table.retry_images)
        button(self,pictures,'Picture cache…',lambda:__import__('picture_cache_ui').show(self.shell))
        self.ttk.Label(parent, textvariable=self.detail, wraplength=1020).pack(anchor="w", pady=5)
        row = line(self)
        button(self, row, "Open VRChat page", lambda: self.open_item(self.table.selected()))
        button(self, row, "Player profile…", lambda: self.profile(self.table.selected()))
        button(self,row,'Saved fields and annotations…',self.saved_details)
        button(self,row,'Translate name / text…',lambda:__import__('text_translation_ui').show_entity(self))
        button(self, row, "Save VRC Eye favorite…", lambda: self.favorite(self.table.selected()))
        button(self, row, "Avatar VRCA…", self.download)
        button(self, row, "Invite Me to world…", lambda: __import__("world_visits_ui").open_for_world(self.shell,self.table.selected()))
        from account_local_ui import SavedSearches
        self.saved = SavedSearches(self, parent)
        self.query.trace_add('write',lambda *_:self.queue_local())

    def saved_details(self):
        row=self.table.selected()
        if not row:raise ValueError('Select a result first.')
        return __import__('native_saved_details').show(self.shell,row.kind,row.id)

    def queue_local(self):
        import time
        self.local_due=time.monotonic()+.25 if self.instant_local.get() and len(self.query.get().strip())>=2 else None

    def external_avatars(self):
        from public_services import avatar_search
        from account_header import private
        import time
        if self.app.demo or getattr(self.app,'safe_mode',False) or private(self.app):raise ValueError('Leave Demo / Safe Mode and reveal information before requesting an external search.')
        if self.job or time.monotonic()<getattr(self,'external_due',0):raise ValueError('Wait for the current task or the 15-second provider budget.')
        query=self.query.get().strip();context=self.context()
        if not 3<=len(query)<=100:raise ValueError('Enter an avatar name between 3 and 100 characters.')
        if not self.confirm('Share avatar search with AVTRdb','Provider: https://api.avtrdb.com\nExact search: '+query+'\n\nRequest up to 100 public metadata results? No VRChat account cookies or IDs are sent. Results require a separate VRChat lookup before use.'):return
        if context!=self.context() or query!=self.query.get().strip() or private(self.app):raise ValueError('Search or privacy changed.')
        self.external_due=time.monotonic()+15;self.local_due=None;self.kind.set('Avatars')
        def done(rows):
            if context!=self.context() or query!=self.query.get().strip() or private(self.app):return
            self.result=None;self.loaded=None;self.table.set(rows);self.detail.set('AVTRdb metadata; availability, ownership and asset access are unverified.');self.status.set(f'{len(rows)} third-party avatar matches.')
        self.start(lambda c,s,p:avatar_search(query),done,api=False)

    def local_search(self):
        from avatar_library import active_scope
        from native_search import search
        from account_header import private
        if private(self.app):raise ValueError('Reveal account information before searching local records.')
        kind={'Users':'user','Worlds':'world','Groups':'group','Avatars':'avatar'}[self.kind.get()]
        query=self.query.get().strip();target=active_scope(self.app);expected=(kind,query,self.scope.get());self.local_due=None
        def done(rows):
            if private(self.app) or ({'Users':'user','Worlds':'world','Groups':'group','Avatars':'avatar'}[self.kind.get()],self.query.get().strip(),self.scope.get())!=expected:return
            self.result=None;self.loaded=None;self.table.set(rows);self.detail.set('Local observations may be stale. Use Search / load for an explicit VRChat lookup.')
            self.status.set(f'{len(rows)} local matches (up to 100). No API search was requested.')
        self.start(lambda c,s,p:search(self.shell.store,target,kind,query,stop=s),done,api=False)

    def reset(self):
        __import__('text_translation_ui').close_for(self)
        sync=getattr(self.shell,'automatic_sync',None)
        if sync:sync.unwatch('search')
        self.cancel(); self.result = self.loaded = None; self.table.set([], lambda x: ()); self.detail.set("Search to load this selection.")

    def account_changed(self):
        self.reset(); self.query.set(''); self.kind.set('Users'); self.scope.set('Public / featured')
        if hasattr(self, 'saved'):
            self.saved.refresh()

    def tick(self):
        super().tick()
        import time
        if self.local_due and time.monotonic()>=self.local_due and not self.job:
            self.local_due=None
            if self.shell.current=='Search':self.guard(self.local_search)
        self.saved.tick()
        self.table.tick()

    def close(self):
        __import__('text_translation_ui').close_for(self)
        sync=getattr(self.shell,'automatic_sync',None)
        if sync:sync.unwatch('search')
        self.table.close()
        return super().close()
    def selection(self): details(self, self.table.selected())

    def search(self, offset):
        from account_header import private
        if private(self.app):raise ValueError('Reveal account information before searching.')
        from live_catalog import catalog_for
        catalog=catalog_for(self.shell);catalog.refresh();after=catalog.revision
        from automatic_sync import sync_for
        sync=sync_for(self.shell);sync.unwatch('search');read_after=[after];registered=[False]
        self.local_due=None
        kind = {"Users": "user", "Worlds": "world", "Groups": "group", "Avatars": "avatar"}[self.kind.get()]
        query, scope = self.query.get().strip(), self.scope.get()
        selected = (kind, query, scope)
        def work(client, stop, progress):
            read_after[0]=catalog.revision
            if kind != "avatar":
                return api.read(client, kind+"-search", query=query, offset=offset, scope="mine" if scope == "My uploads" else "public", stop=stop, progress=progress)
            if query.startswith(("avtr_", "https://vrchat.com/")):
                ref = entity_id("avatar", query); found = client.lookup("avatar", ref, stop=stop, progress=progress)
                from search_tiles import avatar_entity
                row = avatar_entity(found)
                return api.Result("avatar-search", [row], (client.user_id, client.session_revision), client.clock(), stamp())
            page = client.search_avatars({"My uploads": "mine", "My avatar favorites": "favorites"}.get(scope, "featured"), offset, stop=stop, progress=progress)
            from avatar_search import filter_items
            from search_tiles import search_entity
            rows = [search_entity(item)
                    for item in filter_items(page.items, query)]
            return api.Result("avatar-search", rows, (client.user_id, client.session_revision), client.clock(), stamp(), offset, page.has_more)
        def done(result):
            if private(self.app):return
            if selected != ({"Users": "user", "Worlds": "world", "Groups": "group", "Avatars": "avatar"}[self.kind.get()], self.query.get().strip(), self.scope.get()):
                self.status.set("Search options changed. Search again to show matching results."); return
            self.result = result; self.loaded = selected
            catalog.publish(result.data,after=read_after[0])
            self.table.set(catalog.project(result.data), lambda x: (x.name, x.detail[:200], x.id)); self.selection()
            self.status.set(f"{len(result.data)} results on page at offset {result.offset}. Checked {result.checked_at}." + (" More pages available." if result.more else " End of this result set."))
            if offset == 0 and self.saved.remember.get():
                try:
                    self.saved.record(dict(schema=1, kind=self.kind.get(), query=query, scope=scope, sort='Provider default'))
                except (ValueError, OSError, __import__('sqlite3').Error):
                    self.status.set(self.status.get() + ' Recent query was not saved.')
            if not registered[0]:
                registered[0]=True
                def valid():
                    return (not self.closed and not private(self.app) and not self.job and self.shell.current=='Search'
                        and self.loaded==selected and self.result is not None and self.result.offset==offset
                        and selected==({'Users':'user','Worlds':'world','Groups':'group','Avatars':'avatar'}[self.kind.get()],self.query.get().strip(),self.scope.get()))
                sync.watch('search',lambda c,s:work(c,s,lambda _:None),done,valid)
        self.start(work, done)

    def page(self, direction):
        if not self.result or not self.loaded: raise ValueError("Search first.")
        current = ({"Users": "user", "Worlds": "world", "Groups": "group", "Avatars": "avatar"}[self.kind.get()], self.query.get().strip(), self.scope.get())
        if current != self.loaded: raise ValueError("Search options changed. Start a new search.")
        if direction > 0 and not self.result.more: raise ValueError("No later page was reported.")
        size = 50 if self.loaded[0] == "avatar" else 100
        self.search(max(0, self.result.offset + direction*size))

    def download(self):
        record = self.table.selected()
        if not record or record.kind != "avatar": raise ValueError("Select an avatar result.")
        client = self.connected()
        from avatar_search import AvatarSearchItem
        item = AvatarSearchItem(record.id, record.name, "", "", (), "VRChat API", stamp())
        self.app.open_search_download(item, client=client, generation=self.app.data_generation)


# Kept as a re-export for existing imports and navigation callers.
from social_workspace_ui import SocialPage
