"""Native, keyboard-accessible session tools on the shared shell services."""

from text_viewport import window_body
from copy import deepcopy
import json
from pathlib import Path
import queue
import time

from companion_ui import Table,Picture
from vrcx_ui_jobs import LocalPage
from mod_workflows import KINDS,STATES,PRESETS,DESKTOP_KEYS,segments
from mod_tools import service_for,presentation_due

LABELS={'tryouts':'Avatar tryouts','outings':'World outings','setup':'Avatar setup','comfort':'World comfort','shots':'Photo shot list','hosts':'Event hosts'}
DETAILS={'tryouts':'Fit / performance comparison','outings':'Plan / meeting notes','setup':'Posture · provider · coordinate frame · offsets',
         'comfort':'Stairs · seated views · effects · audio controls','shots':'Pose · camera · lighting setup','hosts':'Helper role · arrival / follow-up notes'}
SHORTCUTS={'Players':'Primary','OSC controls':'Networking','Avatar library':'Primary','World visits':'World Visits','Audio devices':'Media & Audio','Photos':'Photos','Creator tools':'Creator Projects','Privacy':'Customization','Stop OSC':'stop-osc','Stop audio':'stop-audio','Do not disturb':'dnd'}


class ToolsDialog(LocalPage):
    def __init__(self,shell):
        self.owner=service_for(shell);app=shell.app
        self.window=app.tk.Toplevel(app.root);self.window.title('VRC Eye · Session tools');self.window.geometry('1080x800')
        body=app.ttk.Frame(window_body(self.window),padding=12);body.pack(fill='both',expand=True)
        self.preview=None;self.private_value=False
        super().__init__(shell,body,'Session tools',task_controls=False)
        self.private=self.tk.BooleanVar(value=False);self.account=self.context()
        self.tabs=self.ttk.Notebook(body);self.tabs.pack(fill='both',expand=True)
        from friendly_ui import ScrollPane
        self.frames={}
        for name in ('Plans','Session','Audio','Composer','Diagnostics','Mascot'):
            container=self.ttk.Frame(self.tabs);self.tabs.add(container,text=name)
            self.frames[name]=ScrollPane(app,container,min_width=780).body
        self.card=None;self.clip=None;self.picture_url='';self.clip_rows=[];self.pack_preview=None
        self.build_plans();self.build_session();self.build_audio();self.build_composer();self.build_diagnostics();self.build_mascot()
        self.owner.dialog=self;self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.window.bind('<FocusOut>',self.focus_lost,add='+');self.guard(self.refresh_cards)

    def line(self,parent):
        row=self.ttk.Frame(parent);row.pack(fill='x',pady=4);return row
    def button(self,parent,title,action):
        widget=self.ttk.Button(parent,text=title,command=lambda:self.guard(action));widget.pack(side='left',padx=(0,6));return widget
    def label(self,parent,text):self.ttk.Label(parent,text=text,wraplength=940).pack(anchor='w',pady=4)
    def field(self,parent,title,value='',width=70):
        row=self.line(parent);self.ttk.Label(row,text=title,width=25).pack(side='left');var=self.tk.StringVar(value=value)
        self.ttk.Entry(row,textvariable=var,width=width).pack(side='left',fill='x',expand=True);return var
    def text(self,parent,height=5):
        box=self.tk.Text(parent,height=height,wrap='word',undo=True);box.pack(fill='x',pady=4);return box
    def put(self,box,value):
        state=box.cget('state');box.configure(state='normal');box.delete('1.0','end');box.insert('1.0',value);box.configure(state=state)
    def selection(self):
        item=self.cards_table.selected()
        if not item:raise ValueError('Select a saved card first.')
        return deepcopy(item)
    def ready(self):
        super().ready();self.owner.ready()

    def build_plans(self):
        frame=self.frames['Plans'];self.kind=self.tk.StringVar(value='tryouts')
        row=self.line(frame);box=self.ttk.Combobox(row,textvariable=self.kind,values=tuple(KINDS),state='readonly',width=18);box.pack(side='left')
        box.bind('<<ComboboxSelected>>',lambda _:self.guard(self.change_kind))
        for title,action in (('Refresh',self.refresh_cards),('New',self.new_card),('Save card',self.save_card),('Remove',self.remove_card),('↑',lambda:self.move_card(-1)),('↓',lambda:self.move_card(1))):self.button(row,title,action)
        self.cards_table=Table(self,frame,(('title','Card',220),('state','State',95),('ref','VRChat ID',310),('detail','Planning detail',280)),height=6)
        self.cards_table.tree.bind('<<TreeviewSelect>>',lambda _:self.guard(self.select_card))
        self.ref=self.field(frame,'Avatar ID / world ID / user ID');self.title=self.field(frame,'Card title')
        row=self.line(frame);self.state=self.tk.StringVar(value=STATES['tryouts'][0]);self.state_box=self.ttk.Combobox(row,textvariable=self.state,values=STATES['tryouts'],state='readonly');self.state_box.pack(side='left')
        self.button(row,'Use current observation',self.use_current);self.button(row,'Open existing workspace',self.open_card)
        self.detail_label=self.tk.StringVar(value=DETAILS['tryouts']);self.ttk.Label(frame,textvariable=self.detail_label).pack(anchor='w')
        self.detail=self.field(frame,'Details');self.version=self.field(frame,'Version / review date');self.notes=self.text(frame,4)
        self.map_file=self.field(frame,'Existing map file');self.map_point=self.field(frame,'Existing waypoint name')
        self.label(frame,'Notes and state are manual. Avatar/world IDs are stable references; saved plans do not reserve an instance or preload game assets. Host cards never grant moderator powers.')
        row=self.line(frame);self.button(row,'Attach local screenshot…',self.attach_photo);self.button(row,'Compare selected + previous',self.compare_cards)
        self.button(row,'Request OSC photo',self.request_photo);self.button(row,'Mark current helper observed',self.observe_helper)
        self.photos=self.line(frame);self.picture=Picture(self,self.photos,'Selected');self.other_picture=Picture(self,self.photos,'Comparison')
        self.receipt=self.tk.StringVar(value='No verified local screenshot attached.');self.ttk.Label(frame,textvariable=self.receipt,wraplength=940).pack(anchor='w')
        self.compare_text=self.text(frame,4)
        row=self.line(frame);self.button(row,'Remember starting avatar',self.start_avatar);self.button(row,'Show starting avatar',self.show_start_avatar)
        self.author=self.field(frame,'Known creator user ID');row=self.line(frame);self.button(row,'Browse saved creator observations',self.browse_creator)
        self.creator_table=Table(self,frame,(('name','Avatar',220),('id','ID',310),('sources','Saved sources',230),('updated','Last observed',160)),height=5)
        row=self.line(frame);self.button(row,'Add creator selection to tryouts',self.creator_tryout);self.button(row,'Load creator picture',self.creator_picture)

    def change_kind(self):self.new_card();self.refresh_cards()
    def new_card(self):
        self.card=None
        for var in (self.ref,self.title,self.detail,self.version,self.map_file,self.map_point):var.set('')
        self.put(self.notes,'');kind=self.kind.get();self.state_box.configure(values=STATES[kind]);self.state.set(STATES[kind][0]);self.detail_label.set(DETAILS[kind])
        self.picture.clear();self.other_picture.clear();self.receipt.set('No verified local screenshot attached.')
    def refresh_cards(self):
        self.owner.ready();kind=self.kind.get();values=self.owner.cards.load(kind)
        self.cards_table.set(values,lambda r:(r['title'],r['state'],r['ref'],r['detail']))
        self.status.set(LABELS[kind]+f' · {len(values)} saved cards · current account workspace')
    def select_card(self):
        self.card=self.selection()
        for key,var in (('ref',self.ref),('title',self.title),('detail',self.detail),('version',self.version),('state',self.state),('map_file',self.map_file),('map_point',self.map_point)):var.set(self.card.get(key,''))
        self.put(self.notes,self.card['notes']);self.receipt.set(json.dumps(self.card.get('photo'),ensure_ascii=False) if self.card.get('photo') else 'No verified local screenshot attached.')
        self.picture.clear();self.other_picture.clear();self.load_card_picture(self.card,self.picture)
        if self.card.get('changes'):self.put(self.compare_text,'State history: '+json.dumps(self.card['changes'],indent=2))
    def candidate(self):
        value=deepcopy(self.card or {});value.update(ref=self.ref.get(),title=self.title.get(),state=self.state.get(),detail=self.detail.get(),version=self.version.get(),notes=self.notes.get('1.0','end-1c'),map_file=self.map_file.get(),map_point=self.map_point.get());return value
    def save_card(self):
        self.ready();self.card=self.owner.cards.save(self.kind.get(),self.candidate());self.refresh_cards();self.status.set('Card saved. Notes and completion state are local.')
    def remove_card(self):
        self.ready();selected=self.selection()
        if self.confirm('Remove local card',selected['title']+'\nRemove this planning card?'):self.ready();self.owner.cards.remove(self.kind.get(),selected['id']);self.new_card();self.refresh_cards()
    def move_card(self,delta):self.ready();self.owner.cards.move(self.kind.get(),self.selection()['id'],delta);self.refresh_cards()
    def use_current(self):
        self.ready();kind=self.kind.get()
        if KINDS[kind]=='avatar':ref=getattr(getattr(self.app,'osc_controller',None),'service',None);value=getattr(ref,'avatar_id','')
        elif KINDS[kind]=='world':value=getattr(getattr(self.app,'player_sessions',None),'meta',{}).get('world_id','')
        else:value=getattr(getattr(self.app,'api',None),'user_id','')
        if not value:raise ValueError('No matching current observation is available; enter the known ID.')
        self.ref.set(value)
    def open_card(self):
        self.ready();card=self.selection();kind=KINDS[self.kind.get()]
        if kind=='world':
            from companion_data import Entity
            from world_visits_ui import open_for_world
            open_for_world(self.shell,Entity('world',card['ref'],card['title']))
        elif kind=='avatar':
            self.app.experience.open_tool('avatar-library');self.app.root.clipboard_clear();self.app.root.clipboard_append(card['ref'])
            page=getattr(getattr(self.app.avatar_creator,'panel',None),'library_page',None)
            if page and page.library.get(page.scope,card['ref']):page.select_avatar(card['ref'])
            self.status.set('Avatar Library opened; ID copied. Existing avatar actions retain their reviews.')
        else:self.shell.show('Primary')
    def attach_photo(self):
        self.ready();card=self.selection();kind=self.kind.get()
        from tkinter.filedialog import askopenfilename
        path=askopenfilename(parent=self.window,title='Attach a finished local screenshot',filetypes=[('Images','*.png *.jpg *.jpeg *.webp')])
        if not path:return
        def done(receipt):
            current=next((r for r in self.owner.cards.load(kind) if r['id']==card['id']),None)
            if current!=card:raise ValueError('The card changed while inspecting this file; attach again.')
            card['photo']=receipt;card['screenshot']=receipt['path']
            if kind=='shots':card['state']='Captured';card['attempts']=(card['attempts']+[dict(at=time.time(),state='Manually associated stable photo',photo=receipt)])[-20:]
            self.owner.cards.save(kind,card);self.refresh_cards();self.receipt.set('Verified stable local file · SHA-256 '+receipt['sha256']+' · user associated; capture causality not proven')
        self.start(lambda c,s,p:self.owner.photo_receipt(path,s),done,api=False)
    def load_card_picture(self,card,picture):
        if not card.get('photo'):
            kind=KINDS[self.kind.get()];url=self.owner.picture_for(kind,card['ref']) if kind in ('avatar','world') else ''
            if url and self.app.api and self.app.api.authenticated:
                from profile_images import fetch_preview
                self.start(lambda c,s,p:fetch_preview(c,url,stop=s),picture.show,api=True)
            return
        receipt=card['photo']
        def read(c,stop,progress):
            from photo_files import read_photo,render
            import hashlib
            data,_=read_photo(receipt['path'],stop=stop)
            if hashlib.sha256(data).hexdigest()!=receipt['sha256']:raise ValueError('The attached screenshot changed; inspect it again.')
            return render(data,preview_edge=300)
        self.start(read,picture.show,api=False)
    def compare_cards(self):
        self.ready();card=self.selection();rows=self.owner.cards.load(self.kind.get());index=next(i for i,r in enumerate(rows) if r['id']==card['id'])
        if index==0:raise ValueError('Select a card after the first to compare it with the previous card.')
        previous=rows[index-1];self.put(self.compare_text,'Previous: '+previous['title']+'\n'+previous['detail']+'\n'+previous['notes']+'\n\nSelected: '+card['title']+'\n'+card['detail']+'\n'+card['notes'])
        self.load_card_picture(previous,self.other_picture)
    def request_photo(self):
        self.ready()
        if self.kind.get()!='shots':raise ValueError('Choose the Photo shot list first.')
        card=self.selection()
        if self.confirm('Request one photo',card['title']+'\nRequest an OSC camera capture using the current armed camera permissions? A file is not guaranteed.'):
            self.ready();self.owner.capture(card);self.refresh_cards()
    def observe_helper(self):
        self.ready()
        if self.kind.get()!='hosts':raise ValueError('Choose Event hosts first.')
        card=self.selection();players=getattr(self.app,'player_sessions',None)
        rows=getattr(players,'rows',{})
        if isinstance(rows,dict):rows=list(rows.values())
        if callable(rows):rows=rows()
        # Match a current stable user ID only. Presentation names are not identity.
        found=next((r for r in rows if getattr(r,'user_id','')==card['ref'] and getattr(r,'active',False)),None)
        if found is None:raise ValueError('No matching current roster observation. Review Players and record an arrival manually if appropriate.')
        card['state']='Observed';self.owner.cards.save('hosts',card);self.refresh_cards()
    def start_avatar(self):
        self.ready();value=getattr(getattr(getattr(self.app,'osc_controller',None),'service',None),'avatar_id','')
        from companion_data import entity_id
        self.owner.save('starting-avatar',{'id':entity_id('avatar',value),'at':time.time()});self.status.set('Observed starting avatar remembered. Restoring requires the existing reviewed avatar action.')
    def show_start_avatar(self):self.ready();self.ref.set(self.owner.record('starting-avatar').get('id',''));self.status.set('Starting avatar loaded into the ID field; no avatar change was sent.')
    def browse_creator(self):
        self.ready();rows,coverage=self.owner.known_creator(self.author.get());self.creator_table.set(rows,lambda r:(r['name'],r['id'],', '.join(r['sources']),r['updated']));self.status.set(coverage)
    def creator_tryout(self):
        self.ready();selected=self.creator_table.selected()
        if not selected:raise ValueError('Choose a creator avatar.')
        self.kind.set('tryouts');self.change_kind();self.ref.set(selected['id']);self.title.set(selected['name']);self.save_card()
    def creator_picture(self):
        self.ready();selected=self.creator_table.selected()
        if not selected or not selected['image']:raise ValueError('No retained preview URL for this avatar.')
        from profile_images import fetch_preview
        self.start(lambda c,s,p:fetch_preview(c,selected['image'],stop=s),self.picture.show,api=True)

    def build_session(self):
        f=self.frames['Session'];self.label(f,'Pins open existing owners or perform an explicitly selected local control. Saved presets contain presentation and notification settings only.')
        self.pins=self.ttk.Treeview(f,columns=('name',),show='headings',height=5);self.pins.heading('name',text='Quick controls');self.pins.pack(fill='x')
        self.pin_choice=self.tk.StringVar(value='Do not disturb');row=self.line(f);self.ttk.Combobox(row,textvariable=self.pin_choice,values=tuple(SHORTCUTS),state='readonly').pack(side='left')
        for title,action in (('Pin',self.add_pin),('Run selected',self.run_pin),('Remove',self.remove_pin),('↑',lambda:self.move_pin(-1)),('↓',lambda:self.move_pin(1))):self.button(row,title,action)
        self.quick_state=self.tk.StringVar();self.ttk.Label(f,textvariable=self.quick_state,wraplength=940).pack(anchor='w')
        self.preset=self.tk.StringVar(value='Quiet');row=self.line(f);self.ttk.Combobox(row,textvariable=self.preset,values=tuple(PRESETS),state='readonly').pack(side='left')
        self.button(row,'Preview / apply preset',self.apply_preset);self.button(row,'Save current as named preset…',self.save_preset);self.button(row,'Restore temporary preset',self.restore_preset)
        self.history=Table(self,f,(('source','Setting change source',260),('at','Time',180),('changes','Changed settings',480)),height=6)
        row=self.line(f);self.button(row,'Refresh change history',self.refresh_history);self.button(row,'Review / undo selected',self.undo)
        self.efficient=self.tk.BooleanVar(value=self.owner.efficient);self.ttk.Checkbutton(f,text='Reduce Eye presentation work while minimized (capture, sync and safety services continue)',variable=self.efficient,command=lambda:self.guard(self.save_efficiency)).pack(anchor='w',pady=8)
        row=self.line(f);self.button(row,'Prepare return to current instance',self.arm_return);self.button(row,'Inspect prepared return target',self.owner.inspect_return);self.button(row,'Clear return plan',lambda:setattr(self.owner,'return_plan',None))
        self.return_status=self.tk.StringVar(value='No return plan. Existing crash recovery remains independently controlled.');self.ttk.Label(f,textvariable=self.return_status,wraplength=940).pack(anchor='w')
        self.intermission=self.tk.StringVar(value='No new world transition observed.');self.ttk.Label(f,textvariable=self.intermission,wraplength=940).pack(anchor='w',pady=8)
        row=self.line(f);self.button(row,'Open intermission',self.open_intermission);self.button(row,'Dismiss intermission',lambda:setattr(self.owner,'intermission',None))
        row=self.line(f);self.button(row,'Load observed world picture',self.intermission_picture);self.button(row,'Play loaded private cue',lambda:self.play_clip(True))
        self.intermission_photo=Picture(self,self.line(f),'World')
        for text in ('Headset and seating comfortable','Selected audio routes checked','Ready to join friends'):
            self.ttk.Checkbutton(f,text=text).pack(anchor='w')
        self.refresh_pins()
    def pin_values(self):return self.owner.record('pins',{'items':['Players','World visits','Audio devices','Do not disturb','Stop audio']})['items']
    def refresh_pins(self):
        self.pins.delete(*self.pins.get_children())
        for i,name in enumerate(self.pin_values()):self.pins.insert('', 'end',iid=str(i),values=(name,))
    def add_pin(self):
        self.ready();values=self.pin_values();name=self.pin_choice.get()
        if name not in values:values.append(name)
        self.owner.save('pins',{'items':values});self.refresh_pins()
    def selected_pin(self):
        selected=self.pins.selection()
        if not selected:raise ValueError('Select a quick control.')
        return int(selected[0])
    def remove_pin(self):self.ready();values=self.pin_values();values.pop(self.selected_pin());self.owner.save('pins',{'items':values});self.refresh_pins()
    def move_pin(self,delta):
        self.ready();values=self.pin_values();i=self.selected_pin();j=max(0,min(len(values)-1,i+delta));values.insert(j,values.pop(i));self.owner.save('pins',{'items':values});self.refresh_pins();self.pins.selection_set(str(j))
    def run_pin(self):
        self.ready();name=self.pin_values()[self.selected_pin()];action=SHORTCUTS.get(name)
        if action=='stop-audio':self.stop_audio()
        elif action=='stop-osc':self.app.osc_controller.stop_controls('Quick control Stop')
        elif action=='dnd':self.owner.desktop.configure(dict(self.owner.desktop.policy,dnd=not self.owner.desktop.policy['dnd']),source='Quick control')
        elif action:self.shell.show(action)
    def refresh_history(self):
        self.ready();values=list(reversed(self.owner.record('settings',{'rows':[]})['rows']));self.history.set(values,lambda r:(r['source'],time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(r['at'])),json.dumps(r['changes'],ensure_ascii=False)))
    def apply_preset(self):
        self.ready();name=self.preset.get();values=self.owner.record('presets',{'values':PRESETS})['values'][name];token=self.owner.token()
        preview='\n'.join(f'{k}: {self.owner.desktop.policy[k]} → {v}' for k,v in values.items())
        if self.confirm('Apply temporary '+name,preview+'\n\nLater manual changes are preserved by restore.'):
            self.ready()
            if not self.owner.valid(token):raise ValueError('Context changed. Review again.')
            self.owner.apply_preset(name,values);self.refresh_history()
    def save_preset(self):
        self.ready()
        from tkinter.simpledialog import askstring
        name=askstring('Named session preset','Name (up to 40 characters):',parent=self.window)
        if not name:return
        from native_library import plain
        name=plain(name,40,empty=False);saved=self.owner.record('presets',{'values':deepcopy(PRESETS)})
        if len(saved['values'])>=20 and name not in saved['values']:raise ValueError('At most twenty presets.')
        saved['values'][name]={k:self.owner.desktop.policy[k] for k in DESKTOP_KEYS};self.owner.save('presets',saved)
        for widget in self.frames['Session'].winfo_children():
            for child in widget.winfo_children():
                if isinstance(child,self.ttk.Combobox) and str(child.cget('textvariable'))==str(self.preset):child.configure(values=tuple(saved['values']))
        self.preset.set(name)
    def restore_entry(self,entry,temporary=False):
        restore,conflicts=self.owner.restore_preview(entry);token=self.owner.token()
        if self.confirm('Restore supported local settings',json.dumps(restore,indent=2)+'\nKept because changed later: '+', '.join(conflicts)):
            self.ready()
            if not self.owner.valid(token):raise ValueError('Context changed. Review again.')
            self.owner.restore(entry,temporary);self.refresh_history()
    def restore_preset(self):self.ready();self.restore_entry(self.owner.record('preset-active'),True)
    def undo(self):
        self.ready();entry=self.history.selected()
        if not entry:raise ValueError('Select a setting history entry.')
        self.restore_entry(entry)
    def save_efficiency(self):self.ready();self.owner.efficient=self.efficient.get();self.owner.store.set_option('workflow.efficient',self.owner.efficient)
    def arm_return(self):self.ready();self.owner.arm_return();self.status.set('Manual return plan ready for fifteen minutes. Inspect it after recovery before using any join action.')
    def intermission_picture(self):
        self.ready();world=getattr(getattr(self.app,'player_sessions',None),'meta',{}).get('world_id','');url=self.owner.picture_for('world',world) if world else ''
        if not url:raise ValueError('No retained image for the current observed world.')
        from profile_images import fetch_preview
        self.start(lambda c,s,p:fetch_preview(c,url,stop=s),self.intermission_photo.show,api=True)
    def open_intermission(self):self.ready();self.owner.intermission=dict(started=time.monotonic(),world='',reported='Manually opened; game loading progress unavailable.',done=False)

    def build_audio(self):
        f=self.frames['Audio'];self.label(f,'Choose devices in Media & Audio first. Preview uses only the already selected private monitor; outgoing playback requires this session’s separate arm and review. WAV/MP3 support depends on the installed decoder.')
        row=self.line(f);self.button(row,'Configure shared audio devices',lambda:self.shell.show('Media & Audio'));self.button(row,'Load clip…',self.load_clip);self.button(row,'Stop all audio',self.stop_audio);self.button(row,'Compact audio pin',self.audio_pin)
        self.clip_table=Table(self,f,(('name','Clip',220),('seconds','Seconds',70),('rate','Source Hz',90),('peak','Peak',80),('path','Selected local file',420)),height=6)
        row=self.line(f);self.button(row,'Reload selected saved clip',self.reload_clip);self.button(row,'Remove saved clip',self.remove_clip)
        self.loop=self.tk.BooleanVar();self.outgoing=self.tk.BooleanVar();self.ttk.Checkbutton(f,text='Loop selected clip',variable=self.loop).pack(anchor='w');self.ttk.Checkbutton(f,text='Arm this clip for the selected outgoing endpoint (session only)',variable=self.outgoing).pack(anchor='w')
        row=self.line(f);self.button(row,'Private preview',lambda:self.play_clip(True));self.button(row,'Review outgoing playback',lambda:self.play_clip(False));self.button(row,'Stop clip',self.stop_clip)
        self.audio_state=self.tk.StringVar(value='No clip decoded.');self.ttk.Label(f,textvariable=self.audio_state,wraplength=940).pack(anchor='w',pady=6)
        self.event_sound=self.tk.BooleanVar();self.ttk.Checkbutton(f,text='Use this decoded clip for permitted notification batches (private monitor, this session only)',variable=self.event_sound,command=lambda:self.guard(self.set_event_sound)).pack(anchor='w')
        self.label(f,'Event cues obey the existing notification ownership, DND, quiet hours, muted categories and cooldowns. They never open a device or interrupt a playing clip. Stop all clears outgoing and event arming.')
        self.media_url=self.field(f,'Public Vimeo URL');self.media_result=None
        row=self.line(f);self.button(row,'Resolve title…',self.resolve_media);self.button(row,'Load provider artwork…',self.media_artwork);self.button(row,'Save enriched bookmark',self.save_media)
        self.media_caption=self.tk.StringVar(value='On-demand adapter: public Vimeo videos. Unsupported URLs remain available in Media & Audio bookmarks.');self.ttk.Label(f,textvariable=self.media_caption,wraplength=940).pack(anchor='w')
        self.media_picture=Picture(self,self.line(f),'Media artwork')
        self.guard(self.refresh_clips)
    def resolve_media(self):
        self.ready();url=self.media_url.get()
        from media_enrichment import video_url,resolve
        video_url(url);epoch=self.owner.token()
        if not self.confirm('Look up public video metadata',url+'\nSend this URL to Vimeo to obtain its title and artwork link? No playback or video download.'):return
        self.ready()
        if not self.owner.valid(epoch) or url!=self.media_url.get():raise ValueError('URL or context changed; review again.')
        self.media_result=None;self.media_picture.clear()
        def done(value):
            if url!=self.media_url.get():raise ValueError('URL changed while loading; inspect again.')
            self.media_result=value;self.media_caption.set(value['title']+' · '+value['artist']+' · provider metadata observed; playback unverified')
            observed=[x.message[:300] for x in list(self.shell.log.items)[-1000:] if url in getattr(x,'urls',())]
            if observed:self.media_caption.set(self.media_caption.get()+'\nRecent selected-log evidence: '+observed[-1])
            self.owner.flow('Media metadata','Vimeo oEmbed','User requested public title','Public video URL','Observed')
        self.start(lambda c,s,p:resolve(url,s),done,api=False)
    def media_artwork(self):
        self.ready();value=self.media_result
        if not value or value['url']!=self.media_url.get() or not value['thumbnail']:raise ValueError('Resolve the current video and its supported artwork link first.')
        if not self.confirm('Load video artwork','Request this provider-declared thumbnail from i.vimeocdn.com?'):return
        self.ready()
        from media_enrichment import artwork
        self.start(lambda c,s,p:artwork(value['thumbnail'],s),self.media_picture.show,api=False)
    def save_media(self):
        self.ready();value=self.media_result
        if not value or value['url']!=self.media_url.get():raise ValueError('Resolve the current video first.')
        from media_history import MediaHistory
        from avatar_library import active_scope
        history=MediaHistory(self.owner.store);history.save(active_scope(self.app),dict(value,origin='manual'),source_key=value['url'])
        self.status.set('Saved to the existing Media & Audio library. Provider artwork remains an on-demand preview.')
    def refresh_clips(self):
        rows=self.owner.record('clips',{'rows':[]})['rows'];self.clip_table.set(rows,lambda r:(r['name'],round(r['seconds'],2),r['rate'],round(r['peak'],3),r['path']))
    def load_clip(self):
        self.ready()
        from tkinter.filedialog import askopenfilename
        path=askopenfilename(parent=self.window,title='Choose a short local clip',filetypes=[('Audio','*.wav *.mp3 *.flac *.ogg')])
        if path:self.decode_clip(path)
    def reload_clip(self):
        self.ready();selected=self.clip_table.selected()
        if not selected:raise ValueError('Select a saved clip.')
        self.decode_clip(selected['path'],selected['sha256'])
    def decode_clip(self,path,expected=None):
        from local_audio import read_clip
        def done(clip):
            if expected and clip.sha256!=expected:raise ValueError('The clip changed; use Load clip to inspect and save it again.')
            self.clip=clip;self.outgoing.set(False);self.event_sound.set(False);self.owner.event_enabled=False;self.owner.event_clip=None
            rows=self.owner.record('clips',{'rows':[]})['rows'];rows=[r for r in rows if r['path']!=clip.path]
            rows.append(dict(name=Path(clip.path).stem,path=clip.path,sha256=clip.sha256,seconds=clip.seconds,rate=clip.rate,channels=clip.channels,peak=clip.peak))
            self.owner.save('clips',{'rows':rows[-50:]});self.refresh_clips();self.status.set(f'Decoded {clip.seconds:.2f}s · {clip.rate} Hz · {clip.channels} channels · peak {clip.peak:.3f}; ready for private preview.')
        self.start(lambda c,s,p:read_clip(path,s),done,api=False)
    def remove_clip(self):
        self.ready();selected=self.clip_table.selected()
        if not selected:raise ValueError('Select a saved clip.')
        rows=self.owner.record('clips',{'rows':[]})['rows'];self.owner.save('clips',{'rows':[r for r in rows if r['path']!=selected['path']]});self.refresh_clips()
    def play_clip(self,private=True):
        self.ready()
        if self.clip is None:raise ValueError('Load and decode a clip first.')
        token=self.owner.token();clip=self.clip
        if not private:
            if not self.outgoing.get():raise ValueError('Arm outgoing clip playback for this session first.')
            if not self.confirm('Play through selected outgoing endpoint',Path(clip.path).name+'\nSend this clip through the already enabled outgoing audio route?'):return
            self.ready()
            if not self.owner.valid(token) or self.clip is not clip:raise ValueError('Context changed; review again.')
        from local_audio import engine_for
        engine_for(self.app).play_clip(clip,private=private,loop=self.loop.get())
        self.owner.flow('Soundboard','Selected monitor' if private else 'Selected outgoing endpoint','User requested clip','Decoded audio samples','Started; remote hearing unverified')
    def stop_clip(self):
        engine=getattr(self.app,'shared_audio',None)
        if engine:engine.clips.stop()
    def stop_audio(self):
        self.outgoing.set(False);self.event_sound.set(False);self.owner.event_enabled=False;self.owner.event_clip=None
        if self.owner.speech:self.owner.speech.stop(discard=True)
        engine=getattr(self.app,'shared_audio',None)
        if engine:engine.stop()
        panel=getattr(self.shell.pages.get('Media & Audio'),'audio_extension',None)
        if panel:panel.arm.set(False)
    def set_event_sound(self):
        self.ready()
        if self.event_sound.get() and self.clip is None:self.event_sound.set(False);raise ValueError('Decode a clip first.')
        self.owner.event_clip=self.clip;self.owner.event_enabled=self.event_sound.get()
    def audio_pin(self):
        self.ready()
        if self.owner.pin and self.owner.pin.winfo_exists():self.owner.pin.lift();return
        w=self.tk.Toplevel(self.window);w.title('Eye audio');w.geometry('480x155');self.owner.pin=w
        self.ttk.Label(window_body(w),textvariable=self.audio_state,wraplength=455).pack(fill='x',padx=10,pady=10)
        row=self.line(w);self.button(row,'Stop all',self.stop_audio);self.button(row,'Devices',lambda:self.shell.show('Media & Audio'))
        w.protocol('WM_DELETE_WINDOW',lambda:(w.destroy(),setattr(self.owner,'pin',None)))

    def build_composer(self):
        f=self.frames['Composer'];self.label(f,'Typed or local speech drafts stay private until you review and send. Each segment uses the existing OSC chat permissions, queue and pacing. Cancelling cannot recall already submitted text.')
        from composer_blocks_ui import Editor
        self.block_editor=Editor(self,f)
        self.model=self.field(f,'Local Vosk model folder');row=self.line(f);self.button(row,'Choose local model…',self.choose_model);self.button(row,'Choose microphone in Audio',lambda:self.shell.show('Media & Audio'))
        hold=self.button(row,'Hold to transcribe',lambda:None);hold.bind('<ButtonPress-1>',lambda _:self.guard(self.start_speech));hold.bind('<ButtonRelease-1>',lambda _:self.stop_speech());hold.bind('<KeyPress-space>',lambda _:self.guard(self.start_speech));hold.bind('<KeyRelease-space>',lambda _:self.stop_speech());hold.bind('<FocusOut>',lambda _:self.stop_speech())
        self.button(row,'Stop private capture',self.stop_speech)
        self.draft=self.text(f,8);self.speech_status=self.tk.StringVar(value='No microphone capture.');self.ttk.Label(f,textvariable=self.speech_status,wraplength=940).pack(anchor='w')
        row=self.line(f);self.button(row,'Paste as draft',self.paste_draft);self.button(row,'Insert wave 👋',lambda:self.draft.insert('insert','👋'));self.button(row,'Review segments',self.preview_segments);self.button(row,'Confirm send reviewed draft',self.send_draft);self.button(row,'Cancel unsent segments',self.cancel_chat)
        self.review=self.text(f,7);self.reviewed=None;self.speech_base='';self.label(f,'Optional offline recognition: install requirements-speech.txt, then select an extracted Vosk model. No model or executable is downloaded automatically. Releasing the button or moving focus out stops capture.')
    def choose_model(self):
        self.ready()
        from tkinter.filedialog import askdirectory
        path=askdirectory(parent=self.window,title='Select extracted local Vosk model')
        if path:self.model.set(path)
    def start_speech(self):
        self.ready();panel=getattr(self.shell.pages.get('Media & Audio'),'audio_extension',None)
        if panel is None:raise ValueError('Open Media & Audio and select a named microphone first.')
        selected=panel._selected(panel.inputs).get('microphone')
        if selected is None:raise ValueError('Select a named microphone in Media & Audio.')
        epoch=self.owner.token();self.speech_base=self.draft.get('1.0','end-1c');self.owner.speech_service().start(self.model.get(),selected,lambda:self.owner.valid(epoch))
        self.owner.flow('Speech draft','Local Vosk model','Private transcription','Microphone PCM; draft text','Requested; no network recognition')
    def stop_speech(self):
        if self.owner.speech:self.owner.speech.stop()
    def focus_lost(self,event):
        def check():
            if not self.closed:
                focused=self.window.focus_get()
                if focused is None or focused.winfo_toplevel()!=self.window:self.stop_speech()
        self.window.after_idle(check)
    def paste_draft(self):self.ready();self.draft.insert('insert',self.window.clipboard_get()[:6000]);self.reviewed=None
    def preview_segments(self):
        self.ready();value=self.draft.get('1.0','end-1c');parts=segments(value);self.reviewed=value;self.put(self.review,'\n\n'.join(f'{i+1}/{len(parts)} ({len(p.encode("utf-16-le"))//2} UTF-16 units)\n{p}' for i,p in enumerate(parts)))
    def send_draft(self):
        self.ready();value=self.draft.get('1.0','end-1c')
        if value!=self.reviewed:raise ValueError('The draft changed. Review its segments again.')
        epoch=self.owner.token()
        if self.confirm('Send reviewed chat segments',f'Submit {len(segments(value))} reviewed segments through OSC chat?'):
            self.ready()
            if not self.owner.valid(epoch) or self.draft.get('1.0','end-1c')!=value:raise ValueError('Draft or context changed; review again.')
            self.owner.compose(value);self.owner.flow('Composer','Configured OSC destination','Reviewed chat publication','User-reviewed text; contents omitted','Queued')
    def cancel_chat(self):
        if self.owner.composer:self.owner.composer.cancel()

    def build_diagnostics(self):
        f=self.frames['Diagnostics'];self.label(f,'Readiness is observed, not assumed. Cost figures measure instrumented callback wall time, not total CPU or a proven cause. Data-flow receipts describe Eye’s own observed work only.')
        row=self.line(f);self.button(row,'Refresh diagnostics',self.refresh_diagnostics);self.button(row,'Export this bounded report…',self.export_diagnostics);self.button(row,'Reset cost capture',self.reset_costs)
        self.diagnostics_text=self.text(f,30);self.diagnostic_report=None
    def refresh_diagnostics(self):self.ready();self.diagnostic_report=self.owner.diagnostics();self.put(self.diagnostics_text,json.dumps(self.diagnostic_report,indent=2,ensure_ascii=False,default=str))
    def reset_costs(self):
        self.ready()
        from mod_workflows import Costs
        self.owner.costs=Costs();self.refresh_diagnostics()
    def export_diagnostics(self):
        self.ready();self.refresh_diagnostics()
        from tkinter.filedialog import asksaveasfilename
        path=asksaveasfilename(parent=self.window,defaultextension='.json',initialfile='Eye-session-diagnostics.json')
        if not path:return
        from photo_files import save_new
        save_new(path,json.dumps(self.diagnostic_report,indent=2,ensure_ascii=False,default=str).encode());self.status.set('Bounded report exported. Local route labels/parameters may be personal; review before sharing.')

    def build_mascot(self):
        f=self.frames['Mascot'];self.label(f,'Custom mascot packs contain a local PNG and plain phrases only. No downloaded scripts, animation code or sound autoplay. The built-in mascot remains available for rollback.')
        self.pack_path=self.field(f,'Local PNG');self.phrases=self.text(f,4);self.put(self.phrases,'Ready when you are.\nTake a comfortable break.');self.pack_picture=Picture(self,self.line(f),'Pack preview')
        row=self.line(f);self.button(row,'Choose PNG…',self.choose_pack);self.button(row,'Preview pack',self.preview_pack);self.button(row,'Use reviewed pack',self.save_pack);self.button(row,'Restore built-in mascot',self.restore_pack)
    def choose_pack(self):
        self.ready()
        from tkinter.filedialog import askopenfilename
        path=askopenfilename(parent=self.window,filetypes=[('PNG image','*.png')])
        if path:self.pack_path.set(path);self.pack_preview=None
    def preview_pack(self):
        self.ready();path=self.pack_path.get();phrases=[x.strip() for x in self.phrases.get('1.0','end-1c').splitlines() if x.strip()]
        from native_library import plain
        if not 1<=len(phrases)<=20:raise ValueError('Use one to twenty short phrases.')
        phrases=[plain(x,200,empty=False) for x in phrases]
        def read(c,s,p):
            from mascot_pack import prepare
            return prepare(path,phrases,s)
        def done(value):self.pack_preview=value;self.pack_picture.show(value['png']);self.status.set('Pack preview ready; applying changes Home’s mascot presentation only.')
        self.start(read,done,api=False)
    def save_pack(self):
        self.ready();value=self.pack_preview
        if not value or value['path']!=str(Path(self.pack_path.get()).resolve()) or value['phrases']!=[x.strip() for x in self.phrases.get('1.0','end-1c').splitlines() if x.strip()]:raise ValueError('Preview the current pack and phrases first.')
        self.owner.save('mascot',{k:v for k,v in value.items() if k!='png'});self.status.set('Custom pack saved. Home loads the verified selected PNG; changed/missing files fall back to the built-in drawing.')
    def restore_pack(self):self.ready();self.owner.save('mascot',{});self.pack_preview=None;self.pack_picture.clear();self.status.set('Built-in mascot restored.')

    def clear_preview(self):
        if not hasattr(self,'cards_table'):return
        self.card=None;self.clip=None;self.pack_preview=None;self.reviewed=None;self.speech_base=''
        for table in (self.cards_table,self.creator_table,self.clip_table,self.history):table.set([],lambda r:())
        for box in (self.notes,self.compare_text,self.draft,self.review,self.diagnostics_text,self.phrases):self.put(box,'')
        self.block_editor.clear();self.reviewed=None
        for var in (self.ref,self.title,self.detail,self.version,self.map_file,self.map_point,self.author,self.model,self.pack_path):var.set('')
        for pic in (self.picture,self.other_picture,self.pack_picture,self.intermission_photo):pic.clear()
        self.media_result=None;self.media_url.set('');self.media_picture.clear();self.media_caption.set('Private media details cleared.')
        self.receipt.set('Private details cleared.');self.return_status.set('Return plan cleared.');self.intermission.set('Intermission cleared.')
        self.outgoing.set(False);self.event_sound.set(False);self.diagnostic_report=None
        self.audio_state.set('Private audio details cleared.');self.speech_status.set('Draft and capture cleared.');self.quick_state.set('Controls require a fresh review.')
    def tick_tools(self):
        self.tick_job()
        if self.closed:return
        speech=self.owner.speech
        if speech:
            self.draft.configure(state='disabled' if speech.running else 'normal')
            for _ in range(16):
                try:generation,text,final=speech.events.get_nowait()
                except queue.Empty:break
                if generation==speech.generation:self.put(self.draft,(self.speech_base+' '+text).strip());self.reviewed=None
            self.speech_status.set(speech.state+(' · '+self.owner.composer.state if self.owner.composer else ''))
        elif self.owner.composer:self.speech_status.set(self.owner.composer.state)
        if not presentation_due(self.app,'session tools',.5):return
        engine=getattr(self.app,'shared_audio',None)
        self.audio_state.set((engine.state+'\n'+str(engine.metrics)+' · dropouts '+str(engine.drops)+' · capture '+str(bool(engine.active_sources))+' · outgoing route '+str(bool(engine.active_outputs.get('outgoing')))) if engine else 'Audio stopped · no capture or outgoing route')
        self.quick_state.set('DND '+str(self.owner.desktop.policy['dnd'])+' · desired power '+self.owner.desktop.policy['power']+' · hidden presentation reduction '+str(self.owner.efficient and self.app.root.state() in ('iconic','withdrawn')))
        plan=self.owner.return_plan;self.return_status.set('Return plan: '+str(max(0,int(plan['expires']-time.monotonic())))+'s remaining · '+self.owner.desktop.automation.status if plan else 'No return plan. Existing crash recovery remains independently controlled.')
        inter=self.owner.intermission
        self.intermission.set((f"Intermission {int(time.monotonic()-inter['started'])}s · "+inter['reported']) if inter else 'No new world transition observed.')
    def close(self):
        if self.closed:return
        self.cancel_chat();self.stop_speech();self.stop_clip();super().close()
        if self.owner.pin:self.owner.pin.destroy();self.owner.pin=None
        self.owner.dialog=None;self.window.destroy()


def show(shell):
    owner=service_for(shell)
    if owner.dialog and not owner.dialog.closed:owner.dialog.window.deiconify();owner.dialog.window.lift();return owner.dialog
    return ToolsDialog(shell)
