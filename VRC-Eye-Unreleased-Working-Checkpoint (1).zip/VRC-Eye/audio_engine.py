"""Explicit PortAudio capture/mixing, owned streams, no default-device fallback."""
from dataclasses import dataclass
import queue
import threading
import time
from audio_mixer import Channel, Mixer, spectrum


@dataclass(frozen=True)
class Device:
    index: int
    name: str
    host: str
    inputs: int
    outputs: int

    @property
    def label(self):
        return f"{self.name} · {self.host} [{self.index}]"


class AudioEngine:
    RATE = 48000
    FRAMES = 480

    def __init__(self, backend=None):
        self.backend = backend
        self.thread = None
        self.halt = threading.Event()
        self._lock = threading.Lock()
        self._settings = {name: Channel() for name in ("microphone", "music", "cue")}
        self.state = "Stopped · capture and outgoing mix are off."
        self.metrics = {}
        self.drops = 0
        self.closed = False
        self.generation = 0
        self.unreleased_streams = []
        from local_audio import ClipPlayer
        self.clips = ClipPlayer()
        self.active_sources, self.active_outputs = {}, {}
        self.microphone_tap = None
        self.capture_owner = None

    def _backend(self):
        if self.backend is None:
            try:
                import sounddevice
                self.backend = sounddevice
            except (ImportError, OSError) as exc:
                raise ValueError("Audio requires sounddevice and the system PortAudio library. Restart with the app launcher after installing them.") from exc
        return self.backend

    def devices(self):
        sd = self._backend()
        try:
            hosts = sd.query_hostapis()
            return tuple(Device(i, str(d["name"]), str(hosts[d["hostapi"]]["name"]),
                                int(d["max_input_channels"]), int(d["max_output_channels"]))
                         for i, d in enumerate(sd.query_devices()))
        except Exception as exc:
            raise ValueError("Audio device discovery failed. Check system audio permissions and PortAudio.") from exc

    @property
    def running(self):
        return self.thread is not None and self.thread.is_alive()

    def configure(self, settings):
        if set(settings) - {"microphone", "music", "cue"} or any(not isinstance(x, Channel) for x in settings.values()):
            raise ValueError("Invalid audio channel settings.")
        with self._lock:
            self._settings = dict(settings)

    def start(self, sources, outputs=None, *, meter_only=False, expected_generation=None, capture_owner=None, cancel=None):
        # The UI captures this ticket before dispatching setup to its worker.
        # A delayed setup must not adopt the generation created by Stop.
        with self._lock:
            generation = self.generation if expected_generation is None else expected_generation
            if generation != self.generation or cancel is not None and cancel.is_set():
                raise ValueError("Audio start cancelled; review devices and start again.")
            if self.unreleased_streams:
                raise ValueError("Device release could not be confirmed. Retry device release before capturing again.")
            if self.closed or self.running:
                raise ValueError("Stop the previous audio session before changing devices.")
        sources, outputs = dict(sources), dict(outputs or {})
        if (not sources and (not outputs or meter_only)) or set(sources) - {"microphone", "music", "cue"} or set(outputs) - {"outgoing", "monitor"}:
            raise ValueError("Select at least one capture input and valid output buses.")
        if meter_only:
            outputs = {}
        selected = tuple(sources.values()) + tuple(outputs.values())
        current = self.devices()
        if any(not isinstance(d, Device) or d not in current for d in selected):
            raise ValueError("A selected device changed. Refresh devices and select it again.")
        if any(d.name.casefold() in ("default", "sysdefault", "pulse", "pipewire") for d in selected):
            raise ValueError("Select a named hardware or virtual endpoint; default aliases can redirect audio unexpectedly.")
        if len({d.index for d in sources.values()}) != len(sources) or len({d.index for d in outputs.values()}) != len(outputs):
            raise ValueError("Choose different devices for each input and output bus.")
        if {d.index for d in sources.values()} & {d.index for d in outputs.values()}:
            raise ValueError("An input and output use the same endpoint; choose a separate route to avoid feedback.")
        if any(d.inputs < 1 for d in sources.values()) or any(d.outputs < 2 for d in outputs.values()):
            raise ValueError("Capture needs one or two channels; this mixer requires stereo output endpoints.")
        sd = self._backend()
        for d in sources.values():
            sd.check_input_settings(device=d.index, channels=min(2, d.inputs), dtype="float32", samplerate=self.RATE)
        for d in outputs.values():
            sd.check_output_settings(device=d.index, channels=2, dtype="float32", samplerate=self.RATE)
        with self._lock:
            if self.closed or self.running or generation != self.generation or cancel is not None and cancel.is_set():
                raise ValueError("Audio start cancelled; review devices and start again.")
            self.halt = threading.Event()
            self.active_sources, self.active_outputs = dict(sources), dict(outputs)
            self.capture_owner = capture_owner
            self.metrics, self.drops = {}, 0
            self.state = "Starting level-only capture…" if meter_only else "Starting selected audio routes…"
            # The UI closes without blocking, but Python must not finalize while
            # PortAudio still owns callbacks into this interpreter. The owner
            # thread releases every stream in finally before process exit.
            self.thread = threading.Thread(target=self._run, args=(sources, outputs, meter_only, self.halt), name="Eye audio", daemon=False)
            self.thread.start()

    def _run(self, sources, outputs, meter_only, halt):
        streams, incoming, outgoing = [], {}, {}
        error = False
        try:
            sd = self._backend()
            for role, device in sources.items():
                if halt.is_set():
                    return
                q = incoming[role] = queue.Queue(maxsize=3)
                channels = min(2, device.inputs)
                def capture(data, frames, timing, status, q=q, channels=channels, role=role):
                    if halt.is_set():
                        return
                    if frames != self.FRAMES or len(data) != frames * channels * 4:
                        self.state = "Capture format changed; audio stopped."
                        halt.set()
                        return
                    if status:
                        self.drops += 1
                    tap = self.microphone_tap
                    if role == "microphone" and tap is not None:
                        try: tap(bytes(data), channels)
                        except Exception: self.microphone_tap = None
                    try:
                        q.put_nowait((bytes(data), time.monotonic()))
                    except queue.Full:
                        self.drops += 1
                stream = sd.RawInputStream(device=device.index, samplerate=self.RATE, blocksize=self.FRAMES,
                    channels=channels, dtype="float32", latency="high", callback=capture)
                streams.append(stream)
            for bus, device in outputs.items():
                if halt.is_set():
                    return
                q = outgoing[bus] = queue.Queue(maxsize=3)
                def render(buffer, frames, timing, status, q=q):
                    if halt.is_set():
                        buffer[:] = bytes(len(buffer))
                        return
                    if status:
                        self.drops += 1
                    try:
                        data = q.get_nowait()
                    except queue.Empty:
                        data = b""
                        self.drops += 1
                    buffer[:] = data if len(data) == len(buffer) else bytes(len(buffer))
                stream = sd.RawOutputStream(device=device.index, samplerate=self.RATE, blocksize=self.FRAMES,
                    channels=2, dtype="float32", latency="high", callback=render)
                streams.append(stream)
            for stream in streams:
                if halt.is_set():
                    return
                stream.start()
            if halt.is_set():
                return
            self.state = "Capturing levels only · no output or recording." if meter_only else "Capture active · selected buses only · VRChat input selection unknown."
            mixer = Mixer(self.RATE)
            deadline = checked = analysed = time.monotonic()
            last = {role: deadline for role in sources}
            while not halt.is_set():
                now = time.monotonic()
                if now - checked >= 1:
                    current = self.devices()
                    if any(d not in current for d in (*sources.values(), *outputs.values())) or any(not s.active for s in streams):
                        raise ValueError("An audio device disconnected or changed; select and start the route again.")
                    checked = now
                blocks = {}
                for role, q in incoming.items():
                    try:
                        data, stamp = q.get_nowait()
                        if now - stamp > 0.15:
                            self.drops += 1
                            continue
                        blocks[role] = mixer.decode(data, min(2, sources[role].inputs), self.FRAMES)
                        last[role] = now
                    except queue.Empty:
                        pass
                    if now - last[role] > 1.5:
                        raise ValueError("No recent samples from a selected input; audio stopped.")
                with self._lock:
                    settings = dict(self._settings)
                if meter_only:
                    settings = {name: Channel(gain=c.gain, mute=c.mute) for name, c in settings.items()}
                clip = self.clips.pull(self.FRAMES) if not meter_only else None
                if clip:
                    samples, private, gain = clip
                    name = "clip_private" if private else "soundboard"
                    blocks[name] = samples
                    settings[name] = Channel(gain=gain, monitor=True, outgoing=not private)
                buses, metrics = mixer.process(blocks, settings, self.FRAMES)
                metrics["dropouts"] = self.drops
                if now - analysed >= 0.1:
                    metrics["spectrum"] = spectrum(next(iter(blocks.values()), ()))
                    analysed = now
                else:
                    metrics["spectrum"] = self.metrics.get("spectrum", ())
                self.metrics = metrics
                for bus, q in outgoing.items():
                    try:
                        q.put_nowait(buses[bus].tobytes())
                    except queue.Full:
                        self.drops += 1
                deadline = max(deadline + self.FRAMES / self.RATE, now)
                halt.wait(max(0, deadline - time.monotonic()))
        except Exception as exc:
            error = True
            self.state = "Audio stopped: " + (str(exc)[:220] if isinstance(exc, ValueError) else "device unavailable, unsupported format or permission denied.")
        finally:
            halt.set()
            unreleased = []
            for stream in reversed(streams):
                try:
                    stream.abort()
                except Exception:
                    pass
                try:
                    stream.close()
                except Exception:
                    unreleased.append(stream)
            self.unreleased_streams = unreleased
            self.metrics = {}
            self.clips.stop()
            self.active_sources, self.active_outputs = {}, {}
            if unreleased:
                self.state = "Audio stopped: device release could not be confirmed. Retry device release before capturing again."
            elif not error and "format changed" not in self.state:
                self.state = "Stopped · capture and outgoing mix are off."

    def set_microphone_tap(self, callback):
        if callback is not None and not callable(callback):raise ValueError("Invalid microphone subscriber.")
        with self._lock:
            if callback is not None and self.microphone_tap is not None and self.microphone_tap != callback:
                raise ValueError("A private microphone consumer is already active. Stop voice transcription or captions first.")
            self.microphone_tap = callback

    def clear_microphone_tap(self, callback):
        with self._lock:
            if self.microphone_tap == callback:self.microphone_tap = None

    def play_clip(self, clip, *, private=True, loop=False, gain=.5):
        bus = "monitor" if private else "outgoing"
        if self.closed or self.halt.is_set() or not self.running or bus not in self.active_outputs:
            raise ValueError("Start the selected " + bus + " route in Media & Audio first.")
        self.clips.play(clip, private=private, loop=loop, gain=gain)

    def stop(self):
        self.clips.stop()
        with self._lock:
            self.generation += 1
            self.halt.set()
            if self.running:
                self.state = "Stopping audio…"

    def stop_owned(self, owner):
        """Stop only a capture actually started by this exact private owner."""
        with self._lock:
            if self.capture_owner is not owner:return False
            self.generation += 1;self.halt.set()
            if self.running:self.state = "Stopping audio…"
        self.clips.stop()
        return True

    def retry_cleanup(self):
        """Retry only previously owned resources, never discover or open devices."""
        with self._lock:
            if self.running:
                raise ValueError("Wait for the audio owner to finish stopping.")
            if not self.unreleased_streams:
                return
            streams = tuple(self.unreleased_streams)
            self.state = "Retrying audio device release…"
            def release():
                failed = []
                for stream in streams:
                    try: stream.abort()
                    except Exception: pass
                    try: stream.close()
                    except Exception: failed.append(stream)
                self.unreleased_streams = failed
                self.state = ("Audio stopped: device release still could not be confirmed. Retry after resolving the device error."
                              if failed else "Stopped · capture and outgoing mix are off.")
            self.thread = threading.Thread(target=release, daemon=False, name="Eye audio cleanup")
            self.thread.start()

    def close(self):
        self.closed = True
        self.stop()
