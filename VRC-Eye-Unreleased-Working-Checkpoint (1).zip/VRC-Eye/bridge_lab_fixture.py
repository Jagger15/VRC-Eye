"""In-memory cooperative provider for the isolated Client Bridge Lab Sandbox.

No listener, pairing secret, API client, credential, process access or OSC sender.
Uses the real protocol validator, BridgeState gates, command queue and result path.
"""
from copy import deepcopy
import time

from bridge_protocol import fresh_id, CAPABILITIES, BridgeError
from bridge_lab_contract import CONTRACTS, same, validate_action
from client_bridge import BridgeState

from developer_catalog import SAMPLES
ACCOUNT = SAMPLES['userId']
AVATAR = SAMPLES['avatarId']
WORLD = SAMPLES['worldId']
TARGET = SAMPLES['targetUserId']


class LabSandbox:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.state = BridgeState(clock)
        self.context = dict(revision=1, runtime_session=fresh_id(), account_id=ACCOUNT,
                            avatar_id=AVATAR, world_id=WORLD, world_session=fresh_id(), config_revision=1)
        self.parameters = [dict(name='AccessoryEnabled', type='bool', value=False, writable=True, synced='unknown', saved='unknown', revision=1),
                           dict(name='Blend', type='float', value=0.0, writable=True, synced='no', saved='no', revision=1),
                           dict(name='Upright', type='float', value=1.0, writable=False, synced='yes', saved='no', revision=1),
                           dict(name='TrackingType', type='int', value=3, writable=False, synced='yes', saved='no', revision=1)]
        self.targets = [dict(target_user_id=TARGET, avatar_hidden=False, audio_suppressed=False, effects='standard', revision=1)]
        self.modules = [dict(id='diagnostic.overlay', kind='overlay', version='1.0', config_revision=1, paused=False, can_pause=True, revision=1),
                        dict(id='diagnostic.routing', kind='input_routing', version='1.0', config_revision=1, paused=False, can_pause=True, revision=1),
                        dict(id='privacy.guard', kind='privacy', version='1.0', config_revision=1, paused=False, can_pause=True, revision=1)]
        self.manifest = dict(id=fresh_id(), revision=1, author_id=ACCOUNT, authority_account=ACCOUNT,
                             authority_kind='explicit_playtest', authority_expires_ms=15000,
                             fields=[dict(key='round_started', value=False), dict(key='serialization_count', value=0)],
                             controls=[dict(id='debug_round_reset', effect='Reset the synthetic creator-defined test round only',
                                            scope='shared_test', authorized=True, persistent=False, destructive=False)])
        self.health = dict(channel='diagnostics', state='healthy', telemetry_revision=1)
        self.phase = 'ready'
        self.failure = ''
        self.leases = {}
        self.dispatched = 0
        self.last_publish = float('-inf')
        hello = dict(protocol=dict(major=1, minor=0),
                     client=dict(id=fresh_id(), name='Sandbox fixture — not a live client', version='1.0', kind='vrchat'),
                     context=dict(attached=True, runtime_session=self.context['runtime_session'], local_user_id=ACCOUNT),
                     capabilities={k: {'version': 1} for k in (*CONTRACTS, 'unity.runtime_health')})
        self.state.connect(hello, fresh_id())
        self.state.grant(list(hello['capabilities']), self.state.session)
        self.state.controls(True, self.state.session)
        self._send('permissions_ack', dict(revision=self.state.permission_revision))
        self.publish()

    def _send(self, kind, data):
        if not self.state.session: return
        self.state.ingest(dict(session=self.state.session, seq=self.state.sequence + 1, kind=kind, data=data))

    def _sample(self, name, value):
        self._send('telemetry', dict(capability=name, permission_revision=self.state.permission_revision, sample_age_ms=0, value=value))

    def publish(self):
        if not self.state.session: return
        self._send('heartbeat', dict(context=self.state.context))
        self._sample('lab.context', dict(context=self.context, capture_cost_ms=0.15, compatibility='unvalidated'))
        self._sample('lab.self_avatar', dict(context=self.context, event='snapshot', phase=self.phase,
                     tracking_type=3, vr_mode=False, upright=next(p['value'] for p in self.parameters if p['name']=='Upright'),
                     in_station=False, animator_state='Locomotion.Standing' if self.phase=='ready' else 'Locomotion.Transition', controller_revision=1))
        self._sample('lab.parameters', dict(context=self.context, parameters=self.parameters))
        self._sample('lab.presentation', dict(context=self.context, targets=self.targets))
        self._sample('lab.modules', dict(context=self.context, modules=self.modules))
        self._sample('lab.health', dict(context=self.context, **self.health))
        self._sample('lab.creator', dict(context=self.context, manifest=self.manifest))
        # Explicitly synthetic correlation, not a VRChat performance promise.
        frame_ms = 16.0 - (3.0 if self.targets[0]['avatar_hidden'] else 0) - (1.0 if self.modules[0]['paused'] else 0)
        self._sample('unity.runtime_health', dict(frame_ms=frame_ms, fps=1000/frame_ms, working_set_bytes=1024**3))
        self.last_publish = self.clock()

    def _record(self, capability, target):
        items, key = {'lab.parameter_set': (self.parameters, 'name'),
                      'lab.presentation_reduce': (self.targets, 'target_user_id'),
                      'lab.module_pause': (self.modules, 'id')}[capability]
        return next(row for row in items if row[key] == target)

    def _value(self, capability, row):
        if capability == 'lab.parameter_set': return row['value']
        if capability == 'lab.module_pause': return row['paused']
        return {k: row[k] for k in ('avatar_hidden', 'audio_suppressed', 'effects')}

    def _write(self, capability, row, value):
        if capability == 'lab.parameter_set': row['value'] = value; row['writer'] = 'sandbox.lab'
        elif capability == 'lab.module_pause': row['paused'] = value
        else: row.update(value)
        row['revision'] += 1
        return row['revision']

    def _restore(self, experiment_id, expected_revision=None):
        lease = self.leases.get(experiment_id)
        if not lease or not same(lease['context'], self.context): raise BridgeError('Lease context is no longer valid.')
        row = self._record(lease['capability'], lease['target'])
        if row['revision'] != lease['revision'] or expected_revision is not None and row['revision'] != expected_revision or not same(self._value(lease['capability'], row), lease['applied']):
            self.leases.pop(experiment_id, None)
            raise BridgeError('Newer state preserved; compare-and-restore did not apply.')
        revision = self._write(lease['capability'], row, lease['baseline'])
        self.leases.pop(experiment_id, None)
        return revision

    def _handle(self, name, params):
        validate_action(name, params)
        if not same(params['context'], self.context): raise BridgeError('Context changed.')
        result = dict(acknowledged=True, experiment_id=params['experiment_id'], context_revision=self.context['revision'])
        if name in ('lab.parameter_set', 'lab.presentation_reduce', 'lab.module_pause'):
            target = params.get('name', params.get('target_user_id', params.get('module_id')))
            row = self._record(name, target)
            baseline = deepcopy(self._value(name, row))
            expected_revision = params.get('expected_revision', params.get('expected', {}).get('revision') if isinstance(params.get('expected'), dict) else None)
            if row['revision'] != expected_revision: raise BridgeError('Observed revision changed.')
            if name == 'lab.parameter_set':
                if not same(row['value'], params['expected']): raise BridgeError('Parameter changed.')
                value = params['value']
            elif name == 'lab.module_pause':
                from bridge_lab_contract import ELIGIBLE_MODULES
                if row['kind'] not in ELIGIBLE_MODULES or not row['can_pause'] or row['paused']: raise BridgeError('Module is not eligible.')
                value = True
            else:
                if not same(params['expected'], {k: row[k] for k in ('avatar_hidden', 'audio_suppressed', 'effects', 'revision')}): raise BridgeError('Presentation changed.')
                value = deepcopy(baseline)
                if params['mode'] == 'hide': value['avatar_hidden'] = True
                elif params['mode'] == 'suppress_audio': value['audio_suppressed'] = True
                else: value['effects'] = 'minimal' if params['mode']=='minimal_effects' or baseline['effects']=='minimal' else 'reduced'
            revision = self._write(name, row, value)
            self.leases[params['experiment_id']] = dict(capability=name, target=target, context=deepcopy(self.context),
                       baseline=baseline, applied=deepcopy(value), revision=revision, expires=self.clock()+params['duration_ms']/1000)
            result['applied_revision'] = revision
        elif name == 'lab.restore':
            lease = self.leases.get(params['experiment_id'])
            if not lease or lease['capability'] != params['original_capability']: raise BridgeError('Wrong lease type.')
            result['applied_revision'] = self._restore(params['experiment_id'], params['expected_revision'])
        elif name == 'lab.recover':
            self.health.update(telemetry_revision=self.health['telemetry_revision']+1, recovery_id=params['experiment_id'],
                               state='degraded' if self.failure == 'recovery_unhealthy' else 'healthy')
        elif name == 'lab.creator_action':
            control=next((r for r in self.manifest['controls'] if r['id']==params['control_id']),None)
            if params['manifest_id']!=self.manifest['id'] or params['manifest_revision']!=self.manifest['revision'] or not control or not control['authorized'] or control['persistent'] or control['destructive']:
                raise BridgeError('Creator control is unavailable.')
            self.manifest['fields'][0]['value'] = False
        return result

    def tick(self):
        if not self.state.session: return
        try:self._send('heartbeat', dict(context=self.state.context))
        except BridgeError:
            self.state.disconnect('Synthetic heartbeat expired; reset Sandbox to begin a fresh fixture.');return
        command = self.state.next_command()
        if command:
            self.state.authorize_send(self.state.session, command)
            self.dispatched += 1
            # A lost response is modeled after dispatch. Never retried.
            try:
                value = self._handle(command['capability'], command['params'])
                if self.failure != 'lost_ack': self._send('result', dict(id=command['id'], ok=True, value=value))
            except (BridgeError, StopIteration, KeyError):
                self._send('result', dict(id=command['id'], ok=False, error='not_applied'))
            self.failure = '' if self.failure == 'lost_ack' else self.failure
            self.publish()
        for key, lease in list(self.leases.items()):
            if self.clock() >= lease['expires']:
                try: self._restore(key)
                except BridgeError: pass
                self.publish()
        if self.clock()-self.last_publish>=0.75: self.publish()

    def inject(self, failure):
        if failure not in ('posture_transition', 'competing_writer', 'context_change', 'disconnect', 'lost_ack', 'recovery_unhealthy'):
            raise ValueError('Choose a supported isolated lab scenario.')
        if failure == 'disconnect': self.state.disconnect('Synthetic disconnect; no real connection was touched.'); return
        if failure == 'context_change':
            self.context.update(revision=self.context['revision']+1, config_revision=self.context['config_revision']+1)
            self.leases.clear()
        elif failure == 'competing_writer':
            row=self.parameters[0]; row.update(value=not row['value'], revision=row['revision']+1); row.pop('writer',None)
        elif failure == 'posture_transition':
            self.phase='transition'
            row=next(p for p in self.parameters if p['name']=='Upright'); row.update(value=0.72, revision=row['revision']+1)
        else: self.failure=failure
        self.publish()
