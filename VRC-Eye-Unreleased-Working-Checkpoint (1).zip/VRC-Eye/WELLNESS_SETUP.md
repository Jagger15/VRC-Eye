# Wellness Center — VRC Eye 1.18.5

Open **Wellness** in the sidebar. The **Casual** dashboard has session controls,
the next reminders, Focus/DND, a consolidated message area, and four quick
switches. **Advanced** opens five pages: Reminders, Schedule / behavior,
Inputs / comfort, Privacy / history, and Profiles / testing. Both scrollbars
keep the controls accessible when the window is small.

Wellness works locally without VRCX, VRChat login, a client bridge, manual JSON,
or internet access. The app must remain open. No reminder is enabled on a fresh
installation, and no session or device connection starts without an opt-in.
The supplied timings are editable preferences, not health prescriptions.

## Start with a profile

Choose **Short Session**, **Long Social Session**, **Standing VR**, **Seated VR**,
**Desktop**, **Quiet Night**, or **Custom**, then **Apply profile**. Profiles
change reminder preferences; they do not start a session, connect a device, or
share your status. Choose **Start session** when ready. You can save your own
profile under a new name in Profiles / testing. Built-in profiles stay available.

VR/Desktop suggestions never apply themselves. Automatic VR mode is reported
only when SteamVR identifies the observed VRChat process as its scene process.
Otherwise mode is unknown until you choose it. A headset being connected does
not establish whether VRChat is running in VR.

## Reminders and timers

Select a reminder in Advanced → Reminders to edit its switch, message, first
delay, repeat interval, snooze interval, timing basis, VR/Desktop condition,
consolidation choice, and optional process/headset requirements. Blank first
delay uses the repeat interval. Applying a row restarts only that changed row;
changing presentation or privacy does not discard other timers' progress.

| Reminder | Behavior |
| --- | --- |
| Hydration | Editable first/repeat delay; no prescribed volume or intake tracking |
| General break, headset off, eye rest | Editable intervals and active/session/observed-wear timing |
| Posture, gentle movement, temperature/comfort, hearing comfort | Neutral self-checks; no posture, temperature, discomfort or health diagnosis is inferred |
| Standing, sitting | Timed only after the corresponding **Manual posture** selection; entering a break clears posture |
| Meal/snack | Interval reminders or 1–8 daily clock times; no calories, portions or food judgments |
| Bathroom | An ordinary private reminder, with the same snooze and disable controls |
| Bedtime, wind-down | Local clock schedules, including per-calendar-day overrides and wind-down across midnight |
| Room safety | Optional VR session-start check and interval checks; no playspace inspection or automatic recalibration detection |
| Low battery | Fresh manual or driver-reported device percentages; low devices combine into one message |
| Doing okay? | Dismiss, snooze or take a break; **I'm doing okay** records no emotional response |
| Session time markers | Plain elapsed-time notices at your chosen minute marks; no achievements or streaks |

Timing bases are **active** (outside breaks), **session** (elapsed session),
**worn** (observed/manual headset wear outside breaks), and **continuous**
(observed/manual wear since a meaningful break). Optional process and wear
requirements use only overlapping observed time. Unknown or expired inputs do
not accumulate observed game or wear time. A manual Worn/Removed choice stays
in effect until changed; its source is labeled. The separate continuous-worn
display resets when the device is removed or its reading expires.

### Breaks

**I'm taking a break** pauses prompts and active timers. **Resume session** is
always your choice. A default **five-minute minimum meaningful break** prevents
a brief headset lift from resetting the last-break timer. Change this minimum
in Schedule / behavior. A qualifying break resets break/eye/headset/posture/
movement/standing/sitting/check-in reminders and reminders already waiting when
the break began. A short break preserves waiting prompts and remaining timer
progress; session-based due times shift by the short pause duration.

Optional reported headset removal can start a break. Putting the headset back
on offers a resume message and does not resume automatically. An unavailable
sensor is never interpreted as removal. Break duration and active time are
tracked even when a break is shorter than your meaningful-break preference.

**Motion comfort** starts a quiet rest and opens Inputs / comfort, where local
volume and exit controls are available. It does not change audio or close the
game automatically. Resume switches Motion comfort off.

### Consolidation, clocks and busy periods

- The default minimum between new prompts is 15 minutes. A chosen snooze time
  is honored even when shorter. Unanswered prompts do not repeatedly chime.
- A five-minute default consolidation window can hold a due interval reminder
  briefly to combine it with another due soon. Both values are editable.
- **Done / dismiss**, **Skip once**, **Snooze**, and **Dismiss for session** act
  on the visible batch. Unseen uncombined reminders remain queued. Advanced
  also has per-reminder snooze, disable and skip-for-today controls.
- **Snooze all 30m**, Focus, DND and Creator / playtest busy hold Wellness
  prompts. When a hold ends, eligible reminders form one batch. Requests to
  keep individual reminders separate still respect minimum prompt spacing.
- Fresh world-entry log lines delay Wellness by the chosen loading delay.
  Explicit fresh crash markers delay it for five minutes. Old log history,
  silence and Demo events do not imply a new load or crash.
- Quiet hours cross midnight. Equal start/end means quiet all day. Ordinary
  intervals restart when quiet hours end, avoiding a catch-up burst. You can
  permit bedtime/wind-down/clock-meal reminders quietly during quiet hours.
- Clock schedules use the computer's timezone. The seven override positions
  are **Monday through Sunday**; `-` skips a day. For a 1 AM bedtime after
  Friday night, set Saturday to `01:00`. Clock reminders crossed between ticks
  are retained; clock rollback does not duplicate an already observed target.
- After three matching snoozes in this session, **Use suggested snooze** can
  offer that interval for the selected reminder. You review the change. These
  in-memory notification preferences do not become health history.

These holds apply to Wellness. They are not application-wide controls for
Feed, social notifications, or a future Safety Center. No safety alert is
reclassified as an ordinary Wellness reminder.

## Optional local inputs and SteamVR overlay

1. Run **Start.cmd** in the extracted folder. It creates/reuses `.recovery-env`
   and automatically prepares dependencies, including psutil, pyopenvr and the
   Windows audio packages. If setup cannot finish offline, manual Wellness still
   opens; reopen **Start.cmd** when online to retry missing packages.
2. In **Advanced → Inputs / comfort**, choose any SteamVR or audio inputs you
   want and click **Connect local inputs**. Process detection is included in
   this connection. Starting this connector does not start VRChat or SteamVR.
3. For SteamVR, start your normal SteamVR session before connecting. VRC Eye
   connects as an overlay application. Missing components or unsupported
   hardware remain unavailable. Reconnect after starting/restarting SteamVR.
4. Optionally enable **Follow observed VRChat process sessions** and apply input
   preferences. This saved opt-in prepares process monitoring at VRC Eye startup
   without opening Wellness. A new process identity starts a session from the
   time VRC Eye detects it; two consecutive confirmed absences end an automatic
   session. A manually ended session does not restart for the same process, and
   a manually started session is not ended just because VRChat disappears.
5. **Start break when headset removal is reported** is a separate saved choice.
   SteamVR/audio connection choices and overlay visibility remain session-only;
   reconnect those explicitly after reopening the app.

| Input | Source and limits |
| --- | --- |
| VRChat process | Exact process name plus PID and creation time; no memory reads, injection, command-line collection or game files inspected |
| Headset worn | SteamVR driver advertises a proximity sensor and supplies a valid proximity bit; activity or movement is not used as a substitute |
| Batteries | Connected SteamVR devices that advertise battery support; labels use roles/local indices, not serial numbers |
| Posture | Manual only; profile names and headset pose never infer standing/sitting |
| Audio | VRChat audio sessions on the default Windows output device; no per-player attribution or recording |

The worker samples about twice a second and keeps only the latest bounded
snapshot. UI wear/battery readings expire after three seconds, process claims
after five seconds, and disconnected/stale snapshots become unknown. Manual
battery values expire after five minutes. A low-battery notice clears when the
reading expires or charging/recharge is reported; the same low device is not
repeatedly announced until recharge/charging releases its latch.

Enable **SteamVR Wellness overlay** for an in-memory static overlay. Choose
head-relative, left wrist, or right wrist placement; adjust width; choose
reminders-only, always, or on-demand visibility. **Show overlay for 20 seconds**
temporarily reveals it. An unavailable wrist anchor hides the HUD rather than
guessing a position. A dashboard tile is also created while the overlay is
enabled. Buttons offer **Take a break**, **Snooze 15m**, and **Dismiss**; resume
is on the desktop. Event queues are bounded and tied to the current session.
No texture files or screenshots are saved. Driver support and actual placement/
controller interaction require a live SteamVR check on your hardware.

### Audio and local controls

The optional Windows meter shows a normalized digital peak. It is not sound
pressure at your ears and does not establish that a volume is safe. Brief
sampled peaks can be missed between polls. Enable **Digital peak notices**
and/or **Sustained digital peak notices** separately, choose thresholds and
duration, then apply input preferences. Both start off. Their messages share
Wellness consolidation, quiet hours and busy holds; stale notices expire.
There is no automatic lowering or muting.

**Lower VRChat volume…** halves matching VRChat sessions' current volume on the
default Windows output. **Mute VRChat…** sets those sessions to muted. They do
not change the system master volume, track individual speakers, or automatically
restore previous volume. **Request VRChat exit…** posts a normal close request
to matching visible windows on Windows (SIGTERM on POSIX); no force-kill
fallback is used. An accepted request does not establish that VRChat exited.

Every action needs a fresh observed process and an explicit review. Process
identity and connection generation are checked again when executing. Requests
expire, are canceled on disconnect, and are never automatically retried.
An action already submitted to the OS cannot be undone by disconnecting.
Demo disables real inputs and local controls. These are external OS controls;
they do not require or substitute for client-bridge game capabilities.

## Presentation, privacy and history

**Subtle** uses the dashboard and cross-page banner. **Normal** and **Prominent**
add small/large static desktop cards; **Audio + Visual** adds an opt-in,
volume-controlled Windows chime. The VR overlay has its own explicit switch
and size controls. Large text and reduced-motion preferences are available;
all current cards/overlays are static regardless. No popup grabs keyboard focus.
Long card text scrolls. Sounds are suppressed during quiet hours and motion
comfort. Ordinary Wellness never automatically shuts down the game.

Streamer mode hides desktop notification previews and the VR overlay, leaving
a generic reminder banner. **It cannot guarantee that capturing the Wellness
page conceals its contents.** Session timers can show always, after one hour,
on demand while Wellness is open, or never. An enabled session milestone can
still announce its selected time separately.

Fresh installs keep only the latest completed summary in memory. Choose **none**,
**session**, **7 days**, **30 days**, or **keep** in Privacy / history. Retention
deletions are reviewed when changing policy; an existing day-based policy is
applied on reopening Wellness and after saving sessions. Starting a new session
clears the previous memory-only summary. No-history mode erases the completed
measurements. Saved history shows up to the latest 100 entries; Delete selected
and Delete all have explicit reviews.

Summaries include session/active/break durations, longest active and break
stretches, profile, source, and observed/manual wear intervals. Unknown wear
stays unknown rather than zero. Optional category counts count prompts
presented, never failures, compliance, health scores, streaks, calories or moods.
Counts are off by default and only apply to future presentations.

The local `companion.sqlite3` stores preferences, named profiles and any history
you choose to save. Wellness data is not sent to VRChat, VRCX, the client bridge,
whispers, cloud storage, telemetry, or the existing diagnostics report. A whole
database backup that you make yourself naturally includes its saved records.
Choose **Include selected wellness history in export** before exporting a
specific summary; exports never silently overwrite an existing file.

Existing 1.18.3/1.18.4 settings migrate without losing saved profiles, enabled
reminders, intervals or stored summaries. Existing installations retain their
previous history-saving behavior (**keep**) until you change retention. Older
manual headset/room reminders keep working without new sensor requirements.
No device integration is silently enabled by migration.

## Templates and tests

**Export template** writes a `.vrcwellness` configuration file, containing no
session history or private integration/retention/motion/Streamer preferences.
Import is size-limited and validated, rejects unknown/duplicate fields and
nonfinite numbers, preserves your private settings, and requires review before
applying. Templates are data only. Built-in and imported profiles never execute
code or connect a device.

**Test selected notification** previews presentation without creating a live
reminder or summary. **Run isolated simulation** uses session minutes, time
since meaningful break, worn/desktop state, and optional forced hydration/
bedtime due flags. It uses a separate engine and sends no device requests.
Quiet hours and motion holds are disabled inside the simulation only so you
can inspect consolidation. It does not alter your real session, history or
current settings.

The original 56-part proposal and its implementation map are preserved in
**WELLNESS_DESIGN_INPUT.md**. Automatic social break-status sharing, cross-module
notification coordination, Resource Guard integration, automatic room/pose
detection, non-SteamVR headset runtimes and per-player audio analysis remain
future work. There are no nonfunctional enable switches for these proposals.

## Verification and implementation references

See **VALIDATION.md** for exact test scope. Logic, provider contracts, SQLite
retention and real UI callbacks have automated coverage with controlled clocks
and native-provider/widget substitutes. Windows/Tk layout, audio routing,
SteamVR sensors and overlay interaction still require live desktop/hardware
testing. No real game process was controlled during development.

Primary references reviewed 2026-10-01:

- Valve OpenVR: https://github.com/ValveSoftware/openvr/blob/master/headers/openvr.h
- Valve overlay interfaces: https://github.com/ValveSoftware/openvr/wiki/IVROverlay_Overview
- Python OpenVR binding and its inspected 2.12.1401 wheel: https://github.com/cmbruns/pyopenvr
- Pycaw API and inspected 20260927 wheel: https://andremiras.github.io/pycaw/api/index.html
- Pycaw process-volume example: https://github.com/AndreMiras/pycaw/blob/develop/examples/volume_by_process_example.py
- Windows digital peak meters: https://learn.microsoft.com/en-us/windows/win32/coreaudio/peak-meters
- Windows close requests: https://learn.microsoft.com/en-us/windows/win32/winmsg/wm-close
