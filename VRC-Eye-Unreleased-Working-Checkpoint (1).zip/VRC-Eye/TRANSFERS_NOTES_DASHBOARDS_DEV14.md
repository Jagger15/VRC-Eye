# VRC Eye 1.21.0 — Development 14

This checkpoint adds resumable avatar transfers, structured Home tables and shared
private notes on top of the complete Development 13 source. It is a runnable
Windows/Linux Python source package, not a compiled executable or signed installer.
Launch using the existing Start.cmd or Start.sh; dependencies are unchanged.

## Avatar transfers

Open **Primary → Avatars → Avatar Library → Transfers**, select a catalog avatar,
then **Load available builds**. Choose a build and **Review new download…**.
The ordinary complete-download dialog remains available. Only download copies you
own or have permission to preserve; normal account access still applies.

The new path checkpoints partial bytes beside the chosen destination. An interrupted
job stays in this account's Transfers list. Load available builds again, select the
matching job/build, then **Review resume…**. There is no startup auto-resume.
Resume needs a matching strong ETag, exact Content-Range/length and resource identity;
the committed prefix is rehashed first. A complete HTTP 200 response is never
appended to a partial. Missing validator/range support needs a freshly reviewed new
download. Known signing parameters may rotate; other URL query changes stop resume.

The optional retry checkbox allows at most three transient retries during a
ten-minute request lease. Each request checks the current context; reads have a
one-hour ceiling and a ten-second socket timeout. Shared asset-host cooldowns honor
Retry-After within this process. Access denial, integrity mismatch, malformed input,
disk failures and cancellation are not retried. This is separate from the existing
metadata request budget. Cross-process cooldown persistence remains a gap.

**Pause transfer** keeps its committed partial. **Discard partial…** verifies and
deletes only that owned partial. There can be at most 16 retained partials per
catalog, at most 2 GiB each. Publication temporarily requires another file-sized
copy, so keep free space available. A source mismatch or uncheckpointed write is
preserved for manual inspection rather than silently repaired or truncated.
Only the latest 100 jobs are listed; no completed receipt is silently deleted.

**Check saved outcome** rehashes a destination against its publication checkpoint,
including a crash after publication but before its completion receipt. **Record
verified file…** separately associates rechecked bytes with the catalog. A checksum
proves a supplied expected digest match only when that expected digest is trusted;
it does not prove ownership or successful avatar loading. URLs/cookies are never
journaled. Local receipts and partials are private data; standard catalog reports
omit them. World, SDK/VCC and external recovery jobs keep their existing workflows.

## Home tables

Home data cards now display rows with sortable headings and per-card filters.
Use **Customization → Home layout** to choose ordered columns, sort direction,
layout and card size. Saved layouts round-trip these options. Duplicate cards
consume the existing desktop snapshot; they do not start extra API clients or
pollers. Current summaries, media, presence, inbox, health and resource observations
join the retained history, world, photo, project and release-download projections.
Tables show bounded sampled rows, not an exhaustive search of every underlying store.
Avatar transfer receipts live in Transfers; the Home Downloads card still shows
release-manager jobs. Quick notes, timers and shortcuts keep their local controls.
Privacy clears visible rows and filter text; account boundaries clear snapshots.

## Shared private notes

Player-profile notes, online-avatar catalog notes and favorites/saved-details
annotations now use the same native annotation owner. Open **Favorites → Notes /
tags…** or **Saved details → Edit shared notes / tags…** for the common editor.
Existing profile and avatar note fields save through that owner too.

Earlier text is shown for review. Choose the shared text or include earlier text
in the draft, then save. User/friend aliases, note edits, tags and acknowledgement
commit together. A stale editor must reload rather than overwrite newer notes.
Earlier source text is retained; a later change there requires another review.
Clearing the shared note does not resurrect previously acknowledged older text.
Unchanged tag colors are preserved. Shared and signed-in workspaces remain distinct.
Private notes never become remote VRChat writes. Creator notebooks, quick notes and
photo notes retain their separate purposes; automatic external-app synchronization
and exhaustive historical migration schemas remain unimplemented.

## Validation and remaining work

The checkpoint adds 54 fixture/headless tests covering actual model persistence and
workflow wiring. See VALIDATION_1_21.md for the final regression counts and exclusions.
Native Tk rendering, Windows locks/filesystems, live VRChat/CDN behavior, Discord,
SteamVR, Unity and installer acceptance remain unverified in this environment.

The full remaining-feature ledger is ARC_VRCX_REMAINING_DEV14.md and ARC_VRCX_GAP_LEDGER_DEV14.json. This is the
first concrete part of the approved batch; textured VRCA/FBX rendering, rig/animation
controls, automatic AssetRipper recovery, interactive Discord/VR actions and a signed
Eye updater have not been added by this checkpoint. Existing manual recovery,
presence and overlay features remain available.

## Provider prerequisites checked

- HTTP range/validator behavior: https://www.rfc-editor.org/rfc/rfc9110.html#section-13.1.5
- The checked AssetRipper GUI argument source exposes server/logging/browser options,
  not a qualified input/output extraction CLI. A pinned provider/version and owned
  process/output contract still need selection and native tests:
  https://github.com/AssetRipper/AssetRipper/blob/master/Source/AssetRipper.GUI.Web/Arguments.cs
- Discord documents event subscriptions and ACTIVITY_JOIN_REQUEST. Eye's current
  presence transport does not yet implement the complete interactive dispatch/response
  lifecycle: https://docs.discord.com/developers/topics/rpc
- An Eye-owned signed feed, publisher key, platform package/install contract and
  rollback tests remain prerequisites in UPDATER_PLAN_DEV10.md. No third-party updater
  feed, signing key or executable has been substituted.

Primary pages checked October 4, 2026. No downloaded mods or provider binaries were
executed, no live account actions were sent, and no update was published.
