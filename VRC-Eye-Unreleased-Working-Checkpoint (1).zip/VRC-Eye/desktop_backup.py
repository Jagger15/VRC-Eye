"""Verified profile bundles and recovery into a new, isolated profile.

Login/keyring material, executable approvals, network grants and original photo
bytes are outside this portable data contract. Sources are never overwritten.
"""
from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import shutil
import sqlite3
import stat
import tempfile
import time
import zipfile
from creator_projects import assert_no_links,local_path
from vrcx_sources import stopped
from native_snapshot import capture_group

STORES=('companion.sqlite3','players.sqlite3','avatar_creator.sqlite3','world_creator.sqlite3')
TABLES=frozenset('favorites options feed_profiles feed_events wellness_sessions social_accounts_v3 social_receipts_v3 account_local_121 avatar_library_120_records media_items_v121 media_forgotten_v121 creator_projects_120 creator_project_links_120 creator_project_receipts_120 notes names roster_settings player_local encounter_sessions encounters avatar_observations player_incidents encounter_suppression deleted_player_records player_category_suppression private_player_sessions creator_records'.split())
TABLES=TABLES|{'metadata_bookmarks'}
PREFIXES=('eye_native_','photo_','native_batch')
OPTIONS=frozenset(('ui.presentation','ui.sidebar.sections.v1','ui.customization','ui.shortcuts.v1','desktop.native.settings.v1','resources.settings','wellness.settings','wellness.profiles','spatial.compass.settings','native.history.private-text','osc.preferences','vr.center','crash.settings','unity.settings'))
MAX_BYTES=1024*1024*1024


def safe_table(name):return name in TABLES or name.startswith(PREFIXES) and re.fullmatch('[a-z0-9_]{1,100}',name)


def sanitize(path,stop=None):
    """Data stays in SQLite; strip all code-bearing schema and opt-in services."""
    db=sqlite3.connect(path)
    try:
        db.execute('PRAGMA trusted_schema=OFF');deadline=time.monotonic()+60
        db.set_progress_handler(lambda:int(time.monotonic()>deadline or stop is not None and stop.is_set()),1000)
        objects=db.execute("SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'").fetchall()
        for kind,name,sql in objects:
            stopped(stop)
            if kind in ('trigger','view') or kind=='index' and sql or kind=='table' and not safe_table(name):
                db.execute('DROP '+kind.upper()+' "'+name.replace('"','""')+'"')
            elif kind=='table' and ('VIRTUAL TABLE' in (sql or '').upper() or 'GENERATED' in (sql or '').upper()):
                raise ValueError('Profile backup contains an unsupported virtual or generated table.')
        tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'options' in tables:
            for key,raw in db.execute('SELECT key,value FROM options').fetchall():
                if key not in OPTIONS and not key.startswith(('ui.dashboard.note.','tags.saved-views.v1.','friends.locations.filters.v1.','photos.session-day.v1.','composer.blocks.v1.')):
                    db.execute('DELETE FROM options WHERE key=?',(key,));continue
                if key=='desktop.native.settings.v1':
                    from desktop_service import settings,GRANTS
                    value=settings(json.loads(raw))
                    for grant in GRANTS:value[grant]=False
                    value.update(discord_application='',discord_details='',background_feed=False,background_photos=False,autolock_minutes=0)
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(value),key))
                if key=='native.history.private-text':db.execute("UPDATE options SET value='false' WHERE key=?",(key,))
                if key in ('wellness.settings','wellness.profiles','spatial.compass.settings'):
                    from settings_bundle import section,combine
                    name={'wellness.settings':'wellness_preferences','wellness.profiles':'wellness_profiles','spatial.compass.settings':'compass_display'}[key]
                    value=combine(name,section(name,json.loads(raw),'shared'),None,'shared')
                    if key=='wellness.settings':value.update(enabled=False,history='none')
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(value),key))
                if key=='osc.preferences':
                    from settings_bundle import section
                    from osc_app import DEFAULT_PREFERENCES
                    value=dict(DEFAULT_PREFERENCES,**section('osc_display',json.loads(raw),'shared'))
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(value),key))
                if key=='vr.center':
                    from settings_bundle import section,combine
                    value=combine('vr_checklists',section('vr_checklists',json.loads(raw),'shared'),None,'shared')
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(value),key))
                if key in ('crash.settings','unity.settings'):
                    from settings_bundle import section,display_owner
                    name='crash_display' if key=='crash.settings' else 'unity_display'
                    value=dict(display_owner(name,None),**section(name,json.loads(raw),'shared'),enabled=False)
                    if key=='crash.settings':value.update(remember_world=False,windows_evidence=False)
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(value),key))
                if key.startswith('composer.blocks.v1.'):
                    from composer_blocks import validate,KEY as COMPOSER
                    from native_library import scope
                    scope(key[len(COMPOSER):]);validate(json.loads(raw))
                if key=='ui.sidebar.sections.v1':
                    from sidebar_state import validate
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(validate(json.loads(raw))),key))
                if key.startswith('photos.session-day.v1.'):
                    from photo_session_day import settings as grouping,KEY as GROUPING
                    from native_library import scope
                    scope(key[len(GROUPING):]);grouping(json.loads(raw))
                if key=='ui.shortcuts.v1':
                    from ui_shortcuts import parse_profile,profile
                    db.execute('UPDATE options SET value=? WHERE key=?',(json.dumps(profile(parse_profile(json.loads(raw)))),key))
                if key.startswith('tags.saved-views.v1.'):
                    from shared_tags import saved_views,VIEW_KEY
                    from native_library import scope
                    scope(key[len(VIEW_KEY):]);saved_views(json.loads(raw))
                if key.startswith('friends.locations.filters.v1.'):
                    from friend_filters import settings as filter_settings,KEY as FILTER_KEY
                    from native_library import scope
                    filter_settings(json.loads(raw),scope(key[len(FILTER_KEY):]))
            # A recovered profile starts with its background network service off.
            db.execute("INSERT OR REPLACE INTO options(key,value) VALUES('network.automatic_sync.v1','false')")
        if 'photo_watches_v6' in tables:
            db.execute('DELETE FROM photo_watches_v6')
        if 'photo_compatible_rules' in tables:db.execute('UPDATE photo_compatible_rules SET enabled=0')
        if 'native_batch_items' in tables:
            db.execute("UPDATE native_batch_items SET state='Uncertain' WHERE state='Claimed'")
        if 'roster_settings' in tables:
            for ref,raw in db.execute('SELECT id,value FROM roster_settings').fetchall():
                value=json.loads(raw);value.update(history='Session only',incognito=True)
                db.execute('UPDATE roster_settings SET value=? WHERE id=?',(json.dumps(value),ref))
        db.commit()
        if db.execute('PRAGMA quick_check').fetchone()[0]!='ok':raise ValueError('Profile database integrity check failed.')
        db.execute('VACUUM');db.execute('PRAGMA journal_mode=DELETE')
        return sorted(t for t in tables if t!='sqlite_sequence')
    except sqlite3.Error:raise ValueError('Profile database is unsupported or exceeded its verification budget.') from None
    finally:db.close()


def sources(shell):
    root=shell.store.path.parent;result={'companion.sqlite3':shell.store.path}
    players=getattr(getattr(getattr(shell.app,'player_sessions',None),'worker',None),'store',None)
    result['players.sqlite3']=getattr(players,'base_path',root/'players.sqlite3')
    if players and getattr(players,'account_scope','shared')!='shared':result['players-'+players.account_scope+'.sqlite3']=players.path
    for name in STORES[2:]:result[name]=root/name
    # Scoped roster files are explicitly named and bounded; arbitrary files,
    # secret stores and symlinks are never swept into a profile archive.
    for path in list(root.glob('players-usr_*.sqlite3'))[:100]:result[path.name]=path
    return {name:assert_no_links(local_path(path)) for name,path in result.items() if path.exists()}


def create(paths,destination,*,stop=None,check=lambda:None):
    target=assert_no_links(local_path(destination));assert_no_links(target.parent)
    manifest=dict(format='vrc-eye-profile-backup',schema=1,created=time.time(),files=[],
        scope='Local collections, annotations, history, photos catalog, account labels, creator records and presentation settings',
        excluded=['Login sessions and keyring secrets','Network and executable approvals','Original photos and Unity project files','Unrecognized component stores'],
        consistency='All included stores were captured during one unchanged DB/WAL observation window; no cross-store write transaction is implied.')
    with tempfile.TemporaryDirectory(prefix='vrceye-backup-') as folder:
        if any(not valid_name(name) for name in paths):raise ValueError('Unsupported profile store name.')
        manifest['capture'] = capture_group(paths, folder, stop=stop, check=check)
        for name,path in paths.items():
            stopped(stop);check();copy=Path(folder)/name
            tables=sanitize(copy,stop);data=copy.read_bytes()
            manifest['files'].append(dict(name=name,size=len(data),sha256=sha256(data).hexdigest(),tables=tables))
        if not manifest['files']:raise ValueError('No supported profile data stores were found.')
        package=Path(folder)/'bundle.zip'
        with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('manifest.json',json.dumps(manifest,indent=2))
            for row in manifest['files']:archive.write(Path(folder)/row['name'],row['name'])
        check();stopped(stop)
        from photo_organize import publish
        publish(target,package.read_bytes(),check)
    return manifest


def valid_name(name):
    return isinstance(name,str) and (name in STORES or re.fullmatch(r'players-usr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\.sqlite3',name))


def _manifest(archive):
    """Check the declared shape before decompressing database members."""
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result: raise ValueError('Repeated profile manifest keys are not accepted.')
            result[key] = value
        return result
    entries = archive.infolist()
    if not 2 <= len(entries) <= 105 or len({i.filename for i in entries}) != len(entries):
        raise ValueError('Invalid or repeated profile backup entries.')
    for item in entries:
        mode = item.external_attr >> 16
        if (item.flag_bits & 1 or item.is_dir()
                or stat.S_IFMT(mode) not in (0, stat.S_IFREG)
                or item.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
            raise ValueError('Unsupported profile backup entry type or compression.')
    info = archive.getinfo('manifest.json')
    if info.file_size > 128 * 1024: raise ValueError('Backup manifest exceeds its limit.')
    manifest = json.loads(archive.read(info), object_pairs_hook=pairs)
    if (not isinstance(manifest, dict) or manifest.get('format') != 'vrc-eye-profile-backup'
            or type(manifest.get('schema')) is not int or manifest['schema'] != 1):
        raise ValueError('Select a supported profile backup.')
    created = manifest.get('created')
    if type(created) not in (int, float) or not math.isfinite(created) or created < 0:
        raise ValueError('Invalid profile backup date.')
    rows = manifest.get('files')
    if not isinstance(rows, list) or not 1 <= len(rows) <= 104 or any(not isinstance(r, dict) for r in rows):
        raise ValueError('Invalid profile store count.')
    names = [r.get('name') for r in rows]
    if any(not valid_name(n) for n in names) or len(names) != len(set(names)):
        raise ValueError('Invalid or repeated store name.')
    if set(archive.namelist()) != {'manifest.json', *names}:
        raise ValueError('The bundle contains unexpected files.')
    total = 0
    for row in rows:
        size = row.get('size'); digest = row.get('sha256'); tables = row.get('tables')
        if type(size) is not int or not 0 < size <= MAX_BYTES:
            raise ValueError('Invalid profile store size.')
        if not isinstance(digest, str) or not re.fullmatch('[a-f0-9]{64}', digest):
            raise ValueError('Invalid profile store checksum.')
        if (not isinstance(tables, list) or len(tables) > 1024
                or any(not isinstance(t, str) or not safe_table(t) for t in tables)
                or len(tables) != len(set(tables))):
            raise ValueError('Invalid profile table inventory.')
        total += size
        if archive.getinfo(row['name']).file_size != size or total > MAX_BYTES:
            raise ValueError('Backup exceeds its expanded byte limit.')
    return manifest


def _copy_member(archive, row, output=None, *, stop=None, check=lambda: None):
    checksum = sha256(); size = 0
    with archive.open(row['name']) as data:
        while True:
            stopped(stop); check()
            block = data.read(1024 * 1024)
            if not block: break
            size += len(block)
            if size > row['size']: raise ValueError('Backup bytes exceeded the reviewed size.')
            checksum.update(block)
            if output is not None: output.write(block)
    if size != row['size'] or checksum.hexdigest() != row['sha256']:
        raise ValueError('Backup checksum failed or bytes changed during restore.')


def inspect(path, *, stop=None, check=lambda: None):
    from avatar_library_files import checked_stream
    stopped(stop); check()
    try:
        with checked_stream(path,limit=MAX_BYTES) as (_,stream,_),zipfile.ZipFile(stream) as archive:
            manifest = _manifest(archive)
            for row in manifest['files']: _copy_member(archive, row, stop=stop, check=check)
        stopped(stop); check()
        return manifest
    except (zipfile.BadZipFile, KeyError, UnicodeError, json.JSONDecodeError, RecursionError, OverflowError):
        raise ValueError('Invalid or damaged profile backup.') from None


def verify(path, *, stop=None, check=lambda: None):
    """Dry-run recovery in temporary copies; never publish or alter a profile."""
    from avatar_library_files import checked_stream
    stopped(stop); check(); stores = []
    try:
        with tempfile.TemporaryDirectory(prefix='vrceye-verify-') as folder:
            with checked_stream(path, limit=MAX_BYTES) as (_, stream, _), zipfile.ZipFile(stream) as archive:
                manifest = _manifest(archive)
                for row in manifest['files']:
                    copy = Path(folder) / row['name']
                    with copy.open('xb') as out:
                        _copy_member(archive, row, out, stop=stop, check=check)
                    tables = sanitize(copy, stop)
                    if tables != sorted(row['tables']):
                        raise ValueError('Profile table inventory does not match the recovered database.')
                    stopped(stop); check()
                    stores.append(dict(name=row['name'], size=row['size'], tables=tables,
                                       database_check='ok', recovery_check='ok'))
        stopped(stop); check()
        return dict(manifest=manifest, stores=stores)
    except (zipfile.BadZipFile, KeyError, UnicodeError, json.JSONDecodeError, RecursionError, OverflowError):
        raise ValueError('Invalid or damaged profile backup.') from None


def verification_summary(report):
    lines = ['Profile backup verification passed', '',
             'Member checksums, SQLite integrity and recovery sanitization passed in temporary copies.',
             'No profile was created or changed. This checks recoverability; it does not prove publisher identity or completeness.', '']
    for row in report['stores']:
        lines += [row['name'] + ' · ' + f"{row['size']:,} bytes · {len(row['tables'])} tables",
                  '  ' + ', '.join(row['tables'])]
    lines += ['', report['manifest'].get('consistency', 'Legacy bundle: each store is a separate committed snapshot.'),
              'Original photos, avatar files, Unity projects, login sessions, service grants and unrecognized stores are excluded.',
              'Recovery uses a new folder. Background services need separate authorization.']
    return '\n'.join(lines)


def restore(path,destination,review,*,stop=None,check=lambda:None):
    """Mark a new profile launchable only after every store has been recovered."""
    target=assert_no_links(local_path(destination));assert_no_links(target.parent)
    if target.exists():raise ValueError('Choose a new, unused profile folder.')
    manifest=inspect(path,stop=stop,check=check)
    if manifest!=review:raise ValueError('The backup changed after review.')
    stage=Path(tempfile.mkdtemp(prefix='.vrceye-recovery-',dir=target.parent))
    try:
        from avatar_library_files import checked_stream
        with checked_stream(path,limit=MAX_BYTES) as (_,stream,_),zipfile.ZipFile(stream) as archive:
            if _manifest(archive) != manifest: raise ValueError('The backup changed after review.')
            for row in manifest['files']:
                stopped(stop);check();out=stage/row['name']
                with out.open('xb') as destination_file:
                    _copy_member(archive,row,destination_file,stop=stop,check=check)
                tables=sanitize(out,stop)
                if tables != sorted(row['tables']): raise ValueError('Profile table inventory does not match the recovered database.')
                os.chmod(out,0o600)
        check();stopped(stop)
        # Claim the unused name first. Directory publication never replaces
        # an existing profile, including a destination created during review.
        target.mkdir();os.chmod(target,0o700)
        try:
            # Install the incomplete-recovery record before the first store.
            # The launcher must never mistake a partly populated folder for a
            # normal profile just because its manifest was copied last.
            with (target/'RECOVERY.json').open('x',encoding='utf-8') as record:
                json.dump(manifest,record,indent=2);record.flush();os.fsync(record.fileno())
            for child in stage.iterdir():
                check();stopped(stop);os.replace(child,target/child.name)
            check();stopped(stop)
            with (target/'.RECOVERY_COMPLETE.tmp').open('x',encoding='ascii') as marker:
                marker.write('1\n');marker.flush();os.fsync(marker.fileno())
            check();stopped(stop)
            os.replace(target/'.RECOVERY_COMPLETE.tmp',target/'RECOVERY_COMPLETE')
        except BaseException:
            # An interrupted folder lacks RECOVERY_COMPLETE and cannot launch.
            raise
        return str(target)
    finally:shutil.rmtree(stage,ignore_errors=True)
