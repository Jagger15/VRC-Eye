"""Local peer tools. Capture existing observations; never start providers or networking.

Cards use closed schemas so raw logs, provider errors, process identities, paths and
credentials cannot accidentally become shareable diagnostics. A card is a point-in-
time observation, not a benchmark. Preference imports alter only documented safe
leaves in CompanionStore, in one SQLite transaction after the caller's review.
"""
from copy import deepcopy
from dataclasses import dataclass, field
import json
import math
from pathlib import Path
import time

SCHEMA = 1
RUNTIME_STATES = frozenset(('UNKNOWN', 'NOT_RUNNING', 'STARTING', 'INITIALIZING', 'RUNNING', 'DEGRADED', 'UNRESPONSIVE', 'EXITED_CLEANLY', 'CRASHED', 'UNKNOWN_EXIT'))
LIVE_STATES = RUNTIME_STATES - {'UNKNOWN', 'NOT_RUNNING', 'EXITED_CLEANLY', 'CRASHED', 'UNKNOWN_EXIT'}
RESOURCE_STATES = frozenset(('UNKNOWN', 'HEALTHY', 'ELEVATED', 'WARNING', 'CRITICAL', 'EMERGENCY'))
MODES = ('unknown', 'desktop', 'vr')
SOURCES = ('unavailable', 'resource_guard', 'unity_player', 'client_reported')
QUALITIES = ('unavailable', 'single_sample', 'observed')
METRICS = {'fps': ('fps', 10000), 'frame_ms': ('milliseconds', 600000),
           'vrchat.rss': ('bytes', 2**60), 'vrchat.private': ('bytes', 2**60),
           'vrchat.cpu': ('fraction', 1), 'gpu.used': ('bytes', 2**60),
           'gpu.process': ('bytes', 2**60), 'gpu.load': ('fraction', 1),
           'ram.available': ('bytes', 2**60)}
REDACTIONS = ('credentials', 'paths', 'device_identifiers', 'account_identifiers',
              'instance_codes', 'raw_logs', 'private_notes', 'player_history')


def _number(value, low=0, high=2**60, *, nullable=False):
    if nullable and value is None:
        return None
    if type(value) not in (int, float) or not low <= value <= high or not math.isfinite(value):
        raise ValueError('Expected a finite number within the supported range.')
    return value


def _exact(raw, keys):
    if not isinstance(raw, dict) or set(raw) != set(keys):
        raise ValueError('Unsupported card fields.')
    if type(raw.get('schema')) is not int or raw['schema'] != SCHEMA:
        raise ValueError('Unsupported card schema.')


def _enum(value, choices):
    if not isinstance(value, str) or value not in choices:
        raise ValueError('Unsupported card value.')
    return value


def _text(value, limit=120):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 or 0x7f <= ord(c) <= 0x9f or 0x202a <= ord(c) <= 0x202e or 0x2066 <= ord(c) <= 0x2069 or 0xd800 <= ord(c) <= 0xdfff for c in value):
        raise ValueError('Use a short plain-text label.')
    return value


def _metrics(raw):
    if not isinstance(raw, dict) or set(raw) - set(METRICS):
        raise ValueError('Unsupported measurement.')
    clean = {}
    for key, row in raw.items():
        if not isinstance(row, dict) or set(row) != {'value', 'unit', 'source', 'quality', 'sample_count'}:
            raise ValueError('Unsupported measurement fields.')
        unit, maximum = METRICS[key]
        if row['unit'] != unit:
            raise ValueError('Measurement unit does not match its metric.')
        value = _number(row['value'], high=maximum, nullable=True)
        _enum(row['source'], SOURCES); _enum(row['quality'], QUALITIES)
        count = row['sample_count']
        if type(count) is not int or not 0 <= count <= 1000000:
            raise ValueError('Invalid measurement sample count.')
        if value is None:
            if count != 0 or row['source'] != 'unavailable' or row['quality'] != 'unavailable':
                raise ValueError('Unavailable measurements must be labeled unavailable.')
        elif count == 0 or row['source'] == 'unavailable' or row['quality'] == 'unavailable':
            raise ValueError('Available measurements require provenance and samples.')
        clean[key] = dict(row)
    return clean


def validate_session_card(raw):
    _exact(raw, ('schema', 'runtime_state', 'duration_seconds', 'mode', 'source'))
    _enum(raw['runtime_state'], RUNTIME_STATES); _enum(raw['mode'], MODES)
    _enum(raw['source'], ('unavailable', 'unity_player', 'black_box'))
    _number(raw['duration_seconds'], high=31536000, nullable=True)
    if raw['runtime_state'] not in LIVE_STATES and raw['duration_seconds'] is not None:
        raise ValueError('An inactive or unknown runtime cannot claim a live duration.')
    return dict(raw)


def validate_diagnostic_card(raw):
    _exact(raw, ('schema', 'runtime_state', 'resource_state', 'duration_seconds', 'incidents', 'metrics', 'redactions'))
    _enum(raw['runtime_state'], RUNTIME_STATES); _enum(raw['resource_state'], RESOURCE_STATES)
    _number(raw['duration_seconds'], high=31536000, nullable=True)
    if raw['runtime_state'] not in LIVE_STATES and raw['duration_seconds'] is not None:
        raise ValueError('An inactive runtime cannot claim a live duration.')
    if raw['incidents'] is not None and (type(raw['incidents']) is not int or not 0 <= raw['incidents'] <= 1000000):
        raise ValueError('Invalid incident count.')
    if not isinstance(raw['redactions'], list) or raw['redactions'] != list(REDACTIONS):
        raise ValueError('Unsupported diagnostic redaction declaration.')
    result = dict(raw); result['metrics'] = _metrics(raw['metrics']); result['redactions'] = list(REDACTIONS)
    return result


def validate_performance_card(raw):
    _exact(raw, ('schema', 'context', 'captured_at', 'period_seconds', 'sample_count', 'metrics', 'mode'))
    _text(raw['context']); _number(raw['captured_at'], high=253402300799)
    _number(raw['period_seconds'], high=86400); _enum(raw['mode'], MODES)
    if type(raw['sample_count']) is not int or not 0 <= raw['sample_count'] <= 1000000:
        raise ValueError('Invalid sample count.')
    result = dict(raw); result['metrics'] = _metrics(raw['metrics'])
    if raw['sample_count'] < max((r['sample_count'] for r in result['metrics'].values()), default=0):
        raise ValueError('Card sample count cannot be smaller than its measurements.')
    return result


def collect_snapshots(app):
    """Only read already-created service snapshots; no provider creation or API calls."""
    if app is None or getattr(app, 'demo', False) or getattr(app, 'safe_mode', False):
        return {}
    pages = getattr(getattr(app, 'sidebar', None), 'pages', {})
    result = {}
    for key, page in (('unity', 'Unity Player'), ('resources', 'Performance & Security'), ('crash', 'Crash & Diagnostics')):
        service = getattr(pages.get(page), 'service', None)
        if service is not None:
            try:
                value = service.snapshot()
                if isinstance(value, dict):
                    result[key] = value
            except Exception:
                # Error strings often include local filenames; unavailable is sufficient.
                pass
    return result


def _snapshots(snapshots, app):
    if snapshots is None:
        return collect_snapshots(app)
    if not isinstance(snapshots, dict):
        raise ValueError('Supply named provider snapshots.')
    return {k: v for k, v in snapshots.items() if k in ('unity', 'resources', 'crash') and isinstance(v, dict)}


def _runtime(snapshots):
    unity = snapshots.get('unity', {})
    state = unity.get('state', 'UNKNOWN')
    if unity.get('enabled') is False or state not in RUNTIME_STATES:
        state = 'UNKNOWN'
    source = 'unity_player' if state != 'UNKNOWN' else 'unavailable'
    if state == 'UNKNOWN':
        other = snapshots.get('crash', {}).get('process')
        if other in ('running', 'not_running'):
            state = 'RUNNING' if other == 'running' else 'NOT_RUNNING'; source = 'black_box'
    duration = unity.get('duration') if source == 'unity_player' and state in LIVE_STATES else None
    try:
        _number(duration, high=31536000, nullable=True)
    except ValueError:
        duration = None
    return state, duration, source


def _bridge(snapshots):
    unity = snapshots.get('unity', {})
    if unity.get('enabled') is False or unity.get('state') not in LIVE_STATES:
        return {}
    row = unity.get('bridge', {}).get('runtime.summary', {})
    # RuntimeService has already matched runtime.summary to OS process identity.
    age = row.get('age')
    if type(age) not in (int, float) or not math.isfinite(age) or not 0 <= age <= 3:
        return {}
    value = row.get('value')
    return value if isinstance(value, dict) else {}


def session_card(snapshots=None, *, app=None):
    snapshots = _snapshots(snapshots, app)
    state, duration, source = _runtime(snapshots)
    mode = _bridge(snapshots).get('vr_mode', 'unknown')
    return validate_session_card(dict(schema=SCHEMA, runtime_state=state, duration_seconds=duration,
                                      mode=mode if mode in MODES else 'unknown', source=source))


def _measurement(value, key, source):
    try:
        _number(value, high=METRICS[key][1])
    except ValueError:
        value = None
    return dict(value=value, unit=METRICS[key][0], source=source if value is not None else 'unavailable',
                quality='single_sample' if value is not None else 'unavailable', sample_count=1 if value is not None else 0)


def _capture_metrics(snapshots):
    rows = {key: _measurement(None, key, 'unavailable') for key in METRICS}
    resources = snapshots.get('resources', {})
    sample = resources.get('sample')
    if resources.get('stale') is False and sample is not None:
        age = resources.get('age')
        # ResourceService snapshots report age; explicitly require it for freshness.
        if type(age) in (int, float) and math.isfinite(age) and 0 <= age <= 5:
            for key in METRICS.keys() - {'fps', 'frame_ms'}:
                try:
                    value = sample.get(key, sample.at + age)
                except (AttributeError, TypeError, ValueError):
                    value = None
                rows[key] = _measurement(value, key, 'resource_guard')
    unity = snapshots.get('unity', {})
    if unity.get('enabled') is not False and unity.get('state') in LIVE_STATES:
        for key in METRICS.keys() - {'fps', 'frame_ms'}:
            if rows[key]['value'] is not None:
                continue
            row = unity.get('resources', {}).get(key, {})
            age, ttl = row.get('age'), row.get('ttl')
            if type(age) in (int, float) and type(ttl) in (int, float) and math.isfinite(age) and math.isfinite(ttl) and 0 <= age <= min(ttl, 5):
                rows[key] = _measurement(row.get('value'), key, 'unity_player')
    bridge = _bridge(snapshots)
    for key in ('fps', 'frame_ms'):
        rows[key] = _measurement(bridge.get(key), key, 'client_reported')
    return rows


def performance_card(snapshots=None, *, app=None, context='', wall=time.time):
    snapshots = _snapshots(snapshots, app); metrics = _capture_metrics(snapshots)
    mode = _bridge(snapshots).get('vr_mode', 'unknown')
    return validate_performance_card(dict(schema=SCHEMA, context=_text(context), captured_at=wall(),
         period_seconds=0., sample_count=max(r['sample_count'] for r in metrics.values()), metrics=metrics,
         mode=mode if mode in MODES else 'unknown'))


def diagnostic_card(snapshots=None, *, app=None):
    snapshots = _snapshots(snapshots, app)
    state, duration, _ = _runtime(snapshots)
    resource = snapshots.get('resources', {})
    severity = resource.get('summary', {}).get('severity') if resource.get('stale') is False else 'UNKNOWN'
    incidents = snapshots.get('crash', {}).get('incidents')
    if type(incidents) is not int or not 0 <= incidents <= 1000000:
        incidents = None
    return validate_diagnostic_card(dict(schema=SCHEMA, runtime_state=state,
        resource_state=severity if severity in RESOURCE_STATES else 'UNKNOWN', duration_seconds=duration,
        incidents=incidents, metrics=_capture_metrics(snapshots), redactions=list(REDACTIONS)))


def compare_performance(current, baseline):
    current = validate_performance_card(current); baseline = validate_performance_card(baseline)
    warnings = ['Measurements show differences, not their cause. Hardware and scene conditions may differ.']
    if min(current['sample_count'], baseline['sample_count']) <= 1:
        warnings.append('At least one card is a single observation; it is not a benchmark average.')
    if current['context'] != baseline['context']:
        warnings.append('Context labels differ; these may describe different activities.')
    if current['mode'] != baseline['mode']:
        warnings.append('Runtime modes differ.')
    if current['period_seconds'] != baseline['period_seconds']:
        warnings.append('Measurement periods differ.')
    rows = []
    for key in sorted(set(current['metrics']) | set(baseline['metrics'])):
        a = current['metrics'].get(key, _measurement(None, key, 'unavailable'))
        b = baseline['metrics'].get(key, _measurement(None, key, 'unavailable'))
        matching = a['source'] == b['source'] and a['source'] != 'unavailable'
        available = a['value'] is not None and b['value'] is not None
        delta = a['value'] - b['value'] if available and matching else None
        rows.append(dict(metric=key, unit=METRICS[key][0], current=a['value'], baseline=b['value'],
            delta=delta, percent_change=100 * delta / b['value'] if delta is not None and b['value'] else None,
            source_match=matching))
    if any(row['current'] is not None and row['baseline'] is not None and not row['source_match'] for row in rows):
        warnings.append('Sources differ for some measurements; their deltas are withheld.')
    comparable = any(row['delta'] is not None for row in rows)
    if not comparable:
        warnings.append('No available measurements have matching sources.')
    return dict(comparable=comparable, warnings=warnings, metrics=rows)


# Safe, portable leaves. No arbitrary names, reminder text, paths, account fields,
# history preferences, networking settings, permissions, external actions or secrets.
WELLNESS_KEYS = frozenset(('view', 'presentation', 'large_text', 'reduced_motion',
                         'spacing', 'combine_window', 'minimum_break', 'overlay_mode',
                         'overlay_anchor', 'overlay_size', 'session_display'))
REMINDER_KEYS = frozenset(('enabled', 'minutes', 'first_minutes', 'snooze', 'combine',
                         'mode', 'basis', 'only_running', 'only_worn'))
SECTIONS = ('wellness.settings', 'resources.settings')


def validate_preferences(package):
    _exact(package, ('schema', 'sections'))
    sections = package['sections']
    if not isinstance(sections, dict) or not sections or set(sections) - set(SECTIONS):
        raise ValueError('Only supported wellness and resource display preferences can be transferred.')
    from wellness_config import defaults, validate, REMINDERS
    clean = {}
    for section, raw in sections.items():
        if not isinstance(raw, dict) or not raw:
            raise ValueError('Preference sections must have supported fields.')
        if section == 'resources.settings':
            if set(raw) != {'view'} or raw['view'] not in ('Casual', 'Advanced', 'Developer'):
                raise ValueError('Only the Resource Guard view preference can be transferred.')
            clean[section] = dict(raw)
            continue
        if set(raw) - (WELLNESS_KEYS | {'reminders'}):
            raise ValueError('Preference package contains a private or unsupported setting.')
        value = defaults()
        for key, val in raw.items():
            if key != 'reminders':
                value[key] = deepcopy(val)
        if 'reminders' in raw:
            rows = raw['reminders']
            if not isinstance(rows, dict) or not rows or set(rows) - set(REMINDERS):
                raise ValueError('Unsupported reminder selection.')
            for name, row in rows.items():
                if not isinstance(row, dict) or not row or set(row) - REMINDER_KEYS:
                    raise ValueError('Reminder packages cannot contain custom text or unsupported fields.')
                value['reminders'][name].update(row)
        verified = validate(value)
        clean[section] = {k: deepcopy(verified[k]) for k in raw if k != 'reminders'}
        if 'reminders' in raw:
            clean[section]['reminders'] = {k: {field: verified['reminders'][k][field] for field in row}
                                               for k, row in raw['reminders'].items()}
    return dict(schema=SCHEMA, sections=clean)


validate_config_package = validate_preferences


def export_preferences(store):
    from wellness_config import defaults, validate
    from resource_core import validate_settings
    wellness = validate(store.option('wellness.settings', defaults()))
    resources = validate_settings(store.option('resources.settings', None))
    safe = {key: deepcopy(wellness[key]) for key in WELLNESS_KEYS}
    safe['reminders'] = {name: {key: deepcopy(row[key]) for key in REMINDER_KEYS} for name, row in wellness['reminders'].items()}
    return validate_preferences(dict(schema=SCHEMA, sections={'wellness.settings': safe,
                                                       'resources.settings': {'view': resources['view']}}))


def _merge(section, current, patch):
    from wellness_config import defaults, validate
    from resource_core import validate_settings
    if section == 'resources.settings':
        result = validate_settings(current)
        result.update(patch)
        return validate_settings(result)
    result = validate(defaults() if current is None else current)
    for key, value in patch.items():
        if key == 'reminders':
            for name, row in value.items():
                result[key][name].update(deepcopy(row))
        else:
            result[key] = deepcopy(value)
    return validate(result)


def _leaves(patch, prefix=''):
    for key, value in patch.items():
        path = prefix + key
        if isinstance(value, dict):
            yield from _leaves(value, path + '.')
        else:
            yield path


def _get(value, path):
    for key in path.split('.'):
        value = value[key]
    return value


def preview_preferences(store, package):
    package = validate_preferences(package); changes = []
    for section, patch in package['sections'].items():
        current = _merge(section, store.option(section, None), {})
        after = _merge(section, current, patch)
        for path in sorted(_leaves(patch)):
            before_value, after_value = _get(current, path), _get(after, path)
            if before_value != after_value:
                changes.append(dict(section=section, path=path, before=before_value, after=after_value))
    return changes


@dataclass
class PreferencesCheckpoint:
    """Opaque, local-only undo receipt. Never serialize or share this object."""
    _store_path: str = field(repr=False)
    _rows: tuple = field(repr=False)
    used: bool = False


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def _read_row(db, section):
    row = db.execute('SELECT value FROM options WHERE key=?', (section,)).fetchone()
    return row[0] if row else None


def _write_row(db, section, raw):
    db.execute('INSERT INTO options(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (section, raw))


def apply_preferences(store, package):
    """Apply an already-reviewed package atomically; verification failure rolls back."""
    package = validate_preferences(package); checkpoint = []
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        for section, patch in package['sections'].items():
            before = _read_row(db, section)
            current = json.loads(before) if before is not None else None
            after = _encoded(_merge(section, current, patch))
            _write_row(db, section, after)
            if _read_row(db, section) != after:
                raise ValueError('Preference verification failed; changes rolled back.')
            checkpoint.append((section, before, after))
    return PreferencesCheckpoint(str(Path(store.path).resolve()), tuple(checkpoint))


def rollback_preferences(store, checkpoint):
    if not isinstance(checkpoint, PreferencesCheckpoint) or checkpoint.used:
        raise ValueError('No unused local preference checkpoint is available.')
    if checkpoint._store_path != str(Path(store.path).resolve()):
        raise ValueError('This checkpoint belongs to another preference store.')
    with store.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        for section, _, after in checkpoint._rows:
            if _read_row(db, section) != after:
                raise ValueError('Preferences changed after import; rollback canceled to preserve those changes.')
        for section, before, _ in checkpoint._rows:
            if before is None:
                db.execute('DELETE FROM options WHERE key=?', (section,))
            else:
                _write_row(db, section, before)
            if _read_row(db, section) != before:
                raise ValueError('Rollback verification failed; current preferences were preserved.')
    checkpoint.used = True
    return True


class SoloCountdown:
    """Monotonic, one-shot local timer; wall-clock adjustments cannot fire it early."""
    def __init__(self, *, clock=time.monotonic):
        self.clock = clock; self.deadline = None; self.label = ''; self.delivered = False

    def start(self, seconds, label='Countdown'):
        _number(seconds, 1, 86400); self.label = _text(label)
        self.deadline = self.clock() + seconds; self.delivered = False
        return self.snapshot()

    def cancel(self):
        self.deadline = None; self.delivered = False

    def snapshot(self):
        remaining = None if self.deadline is None else max(0., self.deadline - self.clock())
        return dict(state='idle' if remaining is None else 'finished' if remaining == 0 else 'running',
                    label=self.label, remaining=remaining)

    def take_due(self):
        if self.deadline is None or self.delivered or self.clock() < self.deadline:
            return None
        self.delivered = True
        return dict(kind='local.countdown', label=self.label)
