"""Account-scoped native records shared by migration, collections and history.

One SQLite transaction owns records, provenance, before-images and receipts.
Imported observations never confer remote authority. No source credentials or
source databases are copied into this store.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import math
import re
import sqlite3
import time
import uuid

from companion_data import CompanionStore, entity_id, stamp
from vrcx_sources import stopped

TYPES = frozenset(('entity', 'collection', 'membership', 'annotation', 'event',
    'aggregate', 'notification', 'relationship', 'preference', 'saved-search',
    'photo-reference', 'source', 'coverage', 'profile'))
SECRET_KEYS = frozenset(('password', 'cookies', 'cookie', 'authorization', 'auth',
    'authcookie', 'twofactorauth', 'savedcredentials', 'apikey', 'api_key',
    'token', 'secret', 'sessiontoken', 'session_token', 'access_token', 'refresh_token'))
SECRET_NAMES=frozenset(re.sub('[-_]','',key) for key in SECRET_KEYS)|frozenset(('authtoken','apitoken','twofactorcookie','authkey'))
MAX_RECORD = 128 * 1024
MAX_BATCH = 10000
MAX_BATCH_BYTES = 32 * 1024 * 1024


def scope(value='shared'):
    return 'shared' if value in ('', 'local', 'shared') else entity_id('user', value)


def plain(value, limit=1000, *, empty=True):
    if not isinstance(value, str) or len(value) > limit or (not empty and not value.strip()):
        raise ValueError('A text field is missing or too long.')
    if any(ord(c) < 32 and c not in '\n\t' or c in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069' for c in value):
        raise ValueError('Unsupported control characters in a text field.')
    return value


def clean(value, depth=0):
    if depth > 12:
        raise ValueError('Record nesting exceeds 12 levels.')
    if isinstance(value, dict):
        if len(value) > 256:
            raise ValueError('Too many fields in one record.')
        out = {}
        for k, v in value.items():
            plain(k, 120, empty=False)
            normalized=re.sub('[-_]','',k.casefold())
            if normalized in SECRET_NAMES:
                raise ValueError('Credentials and secret fields are excluded from native records.')
            out[k] = clean(v, depth + 1)
        return out
    if isinstance(value, list):
        if len(value) > 2000:
            raise ValueError('Too many values in one record.')
        return [clean(v, depth + 1) for v in value]
    if isinstance(value, str):
        plain(value, 20000)
        return re.sub(r'~nonce\([^)]*\)', '~nonce(REDACTED)', value)
    if value is None or type(value) in (bool, int):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    raise ValueError('Unsupported record value.')


def canonical(value):
    return json.dumps(clean(value), sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False)


def document(value):
    """Encode an already individually validated record collection."""
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',', ':'),allow_nan=False)


def digest(value):
    return sha256(canonical(value).encode()).hexdigest()


def identity(*parts):
    return sha256(canonical(list(parts)).encode()).hexdigest()


def identifier(value):
    plain(value, 240, empty=False)
    if not re.fullmatch(r'[A-Za-z0-9_.:@+-]{1,240}', value):
        raise ValueError('Unsupported native record identifier.')
    return value


def fill_missing(old,new):
    if isinstance(old,dict) and isinstance(new,dict):
        return {k:fill_missing(old[k],v) if k in old else v for k,v in {**old,**new}.items()}
    return new if old in ('',None,[],{}) else old


def validate_record(record):
    if not isinstance(record, dict) or set(record) != {'scope', 'kind', 'id', 'data', 'provenance'}:
        raise ValueError('Invalid native record.')
    result = dict(scope=scope(record['scope']), kind=record['kind'], id=identifier(record['id']),
                  data=clean(record['data']), provenance=clean(record['provenance']))
    if result['kind'] not in TYPES or not isinstance(result['data'], dict) or not isinstance(result['provenance'], dict):
        raise ValueError('Unsupported native record type.')
    if len(canonical(result).encode()) > MAX_RECORD:
        raise ValueError('A native record exceeds 128 KiB.')
    data=result['data']
    if result['kind']=='entity':
        kind=data.get('entity_kind'); ref=data.get('entity_id')
        if kind not in ('user','friend','world','avatar','group','print'):
            raise ValueError('Unsupported entity kind.')
        if kind=='print':
            from companion_data import reference
            reference(ref,('prnt',))
        else: entity_id(kind,ref)
        if result['id']!=kind+':'+ref:raise ValueError('Entity identity mismatch.')
    elif result['kind']=='collection':
        plain(data.get('name'),100,empty=False)
        if data.get('entity_kind') not in ('friend','world','avatar','print','mixed'):
            raise ValueError('Unsupported collection type.')
    elif result['kind']=='membership':
        identifier(data.get('collection'));identifier(data.get('entity'))
    elif result['kind']=='annotation':
        if data.get('type') not in ('memo','note','nickname','tag','label'):
            raise ValueError('Unsupported annotation type.')
        plain(data.get('value'),20000);identifier(data.get('entity'))
    return result


@dataclass(frozen=True)
class Plan:
    id: str
    revision: int
    created: float
    records_json: str
    expected_json: str
    conflicts: tuple
    suppressed: tuple
    policy: str
    source: str
    conflict_records_json: str = field(default='[]',repr=False)
    choices_json: str = field(default='[]',repr=False)
    ancestors_json: str = field(default='[]',repr=False)
    merge_defaults_json: str = field(default='[]',repr=False)
    @property
    def records(self):return json.loads(self.records_json)
    @property
    def expected(self):return json.loads(self.expected_json)


class NativeLibrary:
    def __init__(self, companion, *, clock=time.monotonic):
        self.companion = companion if isinstance(companion,CompanionStore) else CompanionStore(companion)
        self.clock = clock
        self._plans = {}
        with self.connect():pass

    @contextmanager
    def connect(self):
        with self.companion.connect() as db:
            db.row_factory=sqlite3.Row
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_records(
                scope TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL,
                data TEXT NOT NULL, provenance TEXT NOT NULL, fingerprint TEXT NOT NULL,
                updated TEXT NOT NULL, PRIMARY KEY(scope,kind,id))''')
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_meta(key TEXT PRIMARY KEY,value INTEGER NOT NULL)''')
            if not db.execute("SELECT 1 FROM eye_native_meta WHERE key='revision'").fetchone():
                db.execute("INSERT INTO eye_native_meta VALUES('revision',0)")
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_batches(
                id TEXT PRIMARY KEY,source TEXT NOT NULL,created TEXT NOT NULL,state TEXT NOT NULL,
                summary TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_changes(
                batch TEXT NOT NULL,scope TEXT NOT NULL,kind TEXT NOT NULL,id TEXT NOT NULL,
                before_json TEXT,after_fingerprint TEXT NOT NULL,rolled_back INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(batch,scope,kind,id))''')
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_suppressed(
                scope TEXT NOT NULL,kind TEXT NOT NULL,id TEXT NOT NULL,created TEXT NOT NULL,
                PRIMARY KEY(scope,kind,id))''')
            db.execute('CREATE INDEX IF NOT EXISTS eye_native_records_scope ON eye_native_records(scope,kind,updated)')
            db.execute('CREATE INDEX IF NOT EXISTS eye_native_changes_record ON eye_native_changes(scope,kind,id)')
            db.execute('''CREATE TABLE IF NOT EXISTS eye_native_ancestors(scope TEXT,kind TEXT,id TEXT,lineage TEXT,
                data TEXT NOT NULL,PRIMARY KEY(scope,kind,id,lineage))''')
            yield db

    @staticmethod
    def _row(row):
        return None if row is None else dict(scope=row['scope'],kind=row['kind'],id=row['id'],
            data=json.loads(row['data']),provenance=json.loads(row['provenance']))

    @staticmethod
    def _find(db,scope_,kind,ref):
        return db.execute('SELECT * FROM eye_native_records WHERE scope=? AND kind=? AND id=?',
                          (scope_,kind,ref)).fetchone()

    def revision(self):
        with self.connect() as db:return db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]

    def get(self,scope_,kind,ref):
        with self.connect() as db:return self._row(self._find(db,scope(scope_),kind,ref))

    def rows(self,scope_,kind=None,query='',*,offset=0,limit=100):
        page=self.search_page(scope_,kind,query,offset=offset,limit=limit)
        return page['records'],page['total']

    def search_page(self,scope_,kind=None,query='',*,offset=0,limit=100,revision=None,stop=None):
        """A bounded, revision-bound page across the whole selected library."""
        if type(offset)is not int or offset<0 or type(limit)is not int or not 1<=limit<=1000:
            raise ValueError('Invalid native-library page.')
        plain(query,512)
        clauses=['scope=?'];values=[scope(scope_)]
        if kind:
            if kind not in TYPES:raise ValueError('Unknown record type.')
            clauses.append('kind=?');values.append(kind)
        if query:clauses.append("instr(eye_casefold(id||' '||data),?)>0");values.append(query.casefold())
        where=' AND '.join(clauses)
        with self.connect() as db:
            stopped(stop);db.execute('BEGIN')
            current=db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]
            if revision is not None and revision!=current:raise ValueError('The local library changed between pages. Refresh from the first page.')
            deadline=time.monotonic()+2
            db.create_function('eye_casefold',1,lambda value:value.casefold(),deterministic=True)
            db.set_progress_handler(lambda:int(time.monotonic()>deadline or stop is not None and stop.is_set()),500)
            try:
                total=db.execute('SELECT count(*) FROM eye_native_records WHERE '+where,values).fetchone()[0]
                records=db.execute('SELECT * FROM eye_native_records WHERE '+where+' ORDER BY updated DESC,kind,id LIMIT ? OFFSET ?',values+[limit,offset]).fetchall()
                stopped(stop)
            except sqlite3.OperationalError as error:
                stopped(stop)
                if 'interrupt' in str(error).lower():raise ValueError('Library search exceeded its time budget. Narrow the record type or query.') from None
                raise
            finally:db.set_progress_handler(None,0)
        return dict(records=[self._row(r) for r in records],total=total,revision=current,offset=offset,limit=limit)

    def favorite_ids(self,scope_,kind,*,limit=20001):
        if kind not in ('friend','avatar','world','print') or type(limit)is not int or not 1<=limit<=50001:raise ValueError('Invalid favorite projection.')
        with self.connect() as db:
            return tuple(row[0].split(':',1)[1] for row in db.execute("""SELECT DISTINCT e.id FROM eye_native_records e
                JOIN eye_native_records m ON m.scope=e.scope AND m.kind='membership' AND json_extract(m.data,'$.entity')=e.id
                WHERE e.scope=? AND e.kind='entity' AND json_extract(e.data,'$.entity_kind')=? ORDER BY e.id LIMIT ?""",(scope(scope_),kind,limit)))

    def prepare(self,records,*,source='Local edit',policy='keep',stop=None,record_limit=MAX_BATCH):
        # A bounded 10,000-item ID exchange expands into up to 30,003 native
        # entities, memberships and collections; byte and transaction gates stay.
        if type(record_limit)is not int or not 1<=record_limit<=30003:raise ValueError('Invalid native batch limit.')
        if policy not in ('keep','replace','fill','merge'):raise ValueError('Choose keep, replace, fill-missing or three-way merge.')
        plain(source,200,empty=False)
        incoming=[];seen=set();size=0
        for value in records:
            stopped(stop);r=validate_record(value);key=(r['scope'],r['kind'],r['id'])
            if key in seen:raise ValueError('The proposed batch contains duplicate record identities.')
            seen.add(key);incoming.append(r);size+=len(canonical(r).encode())
            if len(incoming)>record_limit or size>MAX_BATCH_BYTES:raise ValueError(f'Split this import into batches of at most {record_limit:,} native records / 32 MiB.')
        changes=[];expected=[];conflicts=[];suppressed=[];conflict_records=[];review_size=0;ancestors=[];merge_defaults=[]
        from native_ancestry import lineage,merge
        with self.connect() as db:
            db.execute('BEGIN')
            revision=db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]
            for r in incoming:
                stopped(stop);key=(r['scope'],r['kind'],r['id'])
                if db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():
                    suppressed.append(key);continue
                old=self._find(db,*key)
                origin=lineage(r);base=None
                if origin:
                    ancestors.append([list(key),origin,r['data']])
                    found=db.execute('SELECT data FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=? AND lineage=?',(*key,origin)).fetchone()
                    if found:base=json.loads(found[0])
                if old:
                    old_record=self._row(old)
                    if canonical(old_record['data'])==canonical(r['data']):continue
                    if policy=='merge' and base is not None:
                        merged,concurrent=merge(base,old_record['data'],r['data'])
                        draft=dict(old_record,data=merged)
                        merge_defaults.append(draft)
                        if not concurrent:
                            if merged!=old_record['data']:changes.append(draft);expected.append([list(key),old['fingerprint']])
                            continue
                    conflicts.append(key)
                    review_size+=len(canonical(old_record).encode())
                    if review_size>MAX_BATCH_BYTES:raise ValueError('Split this review: existing conflict values exceed 32 MiB.')
                    conflict_records.append([old_record,r])
                    if policy=='keep':continue
                    if policy=='merge':
                        if base is None:continue
                        r=draft
                        if r['data']==old_record['data']:continue
                    if policy=='fill':
                        merged=fill_missing(old_record['data'],r['data'])
                        if r['kind']=='entity' and old_record['data'].get('name')==old_record['data'].get('entity_id'):
                            merged['name']=r['data'].get('name') or merged['name']
                        r=dict(r,data=merged,provenance=old_record['provenance'])
                        if r['data']==old_record['data']:continue
                changes.append(r);expected.append([list(key),old['fingerprint'] if old else None])
        plan = Plan(str(uuid.uuid4()),revision,self.clock(),document(changes),document(expected),
                    tuple(conflicts),tuple(suppressed),policy,source,document(conflict_records),
                    ancestors_json=document(ancestors),merge_defaults_json=document(merge_defaults))
        self._plans = {k:v for k,v in self._plans.items() if 0 <= self.clock()-v.created < 900}
        if len(self._plans) >= 8:
            self._plans.pop(next(iter(self._plans)))
        self._plans[plan.id] = plan
        return plan

    def resolve_fields(self,plan,choices,*,stop=None,check=None):
        from native_conflicts import resolve
        return resolve(self,plan,choices,stop=stop,check=check)

    def discard(self,plan):
        if isinstance(plan,Plan) and self._plans.get(plan.id) is plan:self._plans.pop(plan.id,None)

    def commit(self,plan,*,stop=None,check=None,suppressions=()):
        if not isinstance(plan,Plan) or not 0<=self.clock()-plan.created<900:
            raise ValueError('The import review expired. Prepare it again.')
        if self._plans.pop(plan.id, None) is not plan:
            raise ValueError('This review was already used or is not owned by this workspace. Prepare again.')
        records=plan.records;expected={tuple(k):v for k,v in plan.expected}
        suppressed_keys=set()
        for r in suppressions:
            if not isinstance(r,dict) or set(r)!={'scope','kind','id','created'} or r['kind'] not in TYPES:
                raise ValueError('Invalid deletion-history record.')
            suppressed_keys.add((scope(r['scope']),r['kind'],identifier(r['id'])))
        if any((r['scope'],r['kind'],r['id']) in suppressed_keys for r in records):
            raise ValueError('A backup contains both a live record and its deletion marker.')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE');stopped(stop)
            if check:check()
            if plan.ancestors_json!='[]' and db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]!=plan.revision:
                raise ValueError('Data or import ancestry changed after review. Prepare this import again.')
            if db.execute('SELECT 1 FROM eye_native_batches WHERE id=?',(plan.id,)).fetchone():
                raise ValueError('This reviewed batch was already used.')
            for key in suppressed_keys:
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',key)
                db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*key,stamp()))
            for r in records:
                key=(r['scope'],r['kind'],r['id']);current=self._find(db,*key)
                if (current['fingerprint'] if current else None)!=expected[key]:
                    raise ValueError('A destination record changed after review. Prepare again.')
                if db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():
                    raise ValueError('A selected record was forgotten after review.')
            now=stamp()
            db.execute('INSERT INTO eye_native_batches VALUES(?,?,?,?,?)',(plan.id,plan.source,now,'Committed',
                canonical(dict(changed=len(records),conflicts=len(plan.conflicts),suppressed=len(plan.suppressed)))))
            for r in records:
                stopped(stop)
                if check:check()
                key=(r['scope'],r['kind'],r['id']);old=self._row(self._find(db,*key));fingerprint=digest(r)
                db.execute('INSERT INTO eye_native_changes VALUES(?,?,?,?,?,?,0)',
                    (plan.id,*key,canonical(old) if old else None,fingerprint))
                db.execute('INSERT INTO eye_native_records VALUES(?,?,?,?,?,?,?) ON CONFLICT(scope,kind,id) DO UPDATE SET data=excluded.data,provenance=excluded.provenance,fingerprint=excluded.fingerprint,updated=excluded.updated',
                    (*key,canonical(r['data']),canonical(r['provenance']),fingerprint,now))
            self._validate_links(db,{r['scope'] for r in records}|{k[0] for k in suppressed_keys})
            for key,origin,data in json.loads(plan.ancestors_json):
                if not db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():
                    db.execute('INSERT OR REPLACE INTO eye_native_ancestors VALUES(?,?,?,?,?)',(*key,origin,canonical(data)))
            stopped(stop)
            if check:check()
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return dict(id=plan.id,changed=len(records),conflicts=len(plan.conflicts),suppressed=len(plan.suppressed))

    @staticmethod
    def _validate_links(db,scopes):
        for s in scopes:
            for row in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='membership'",(s,)):
                data=json.loads(row[0])
                if not NativeLibrary._find(db,s,'collection',data['collection']) or not NativeLibrary._find(db,s,'entity',data['entity']):
                    raise ValueError('Every membership must reference an existing collection and entity in its scope.')

    def put(self,scope_,kind,ref,data,*,provenance=None):
        r=dict(scope=scope(scope_),kind=kind,id=ref,data=data,provenance=provenance or {'source':'VRC Eye local edit'})
        return self.commit(self.prepare([r],source='Local edit',policy='replace'))

    def forget(self,scope_,kind,ref):
        """Remove payload and before-images; suppression survives future imports."""
        key=(scope(scope_),kind,identifier(ref))
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE');keys=[key]
            if kind in ('collection','entity'):
                field='collection' if kind=='collection' else 'entity'
                for row in db.execute("SELECT kind,id,data FROM eye_native_records WHERE scope=? AND kind IN ('membership','annotation')",(key[0],)):
                    if json.loads(row['data']).get(field)==ref:keys.append((key[0],row['kind'],row['id']))
            for k in keys:
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',k)
                db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',k)
                db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',k)
                db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*k,stamp()))
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return len(keys)

    def allow_restore(self,scope_,kind,ref):
        with self.connect() as db:
            db.execute('DELETE FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',(scope(scope_),kind,identifier(ref)))
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")

    def rollback(self,batch,*,selected=None,stop=None):
        """All selected before-images are restored atomically, or none are."""
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows=db.execute('SELECT * FROM eye_native_changes WHERE batch=? AND rolled_back=0',(batch,)).fetchall()
            if selected is not None:rows=[r for r in rows if (r['scope'],r['kind'],r['id']) in selected]
            if not rows:raise ValueError('No remaining changes selected for rollback.')
            for r in rows:
                stopped(stop);key=(r['scope'],r['kind'],r['id']);current=self._find(db,*key)
                if not current or current['fingerprint']!=r['after_fingerprint']:
                    raise ValueError('A record has newer edits. Roll back other selected records or review this conflict.')
                if db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():
                    raise ValueError('A forgotten record cannot be resurrected by rollback.')
            for r in rows:
                stopped(stop);key=(r['scope'],r['kind'],r['id'])
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                if r['before_json'] is None:db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                else:
                    old=json.loads(r['before_json'])
                    db.execute('UPDATE eye_native_records SET data=?,provenance=?,fingerprint=?,updated=? WHERE scope=? AND kind=? AND id=?',
                        (canonical(old['data']),canonical(old['provenance']),digest(old),stamp(),*key))
                db.execute('UPDATE eye_native_changes SET rolled_back=1 WHERE batch=? AND scope=? AND kind=? AND id=?',(batch,*key))
            self._validate_links(db,{r['scope'] for r in rows})
            remaining=db.execute('SELECT count(*) FROM eye_native_changes WHERE batch=? AND rolled_back=0',(batch,)).fetchone()[0]
            db.execute('UPDATE eye_native_batches SET state=? WHERE id=?',('Partly rolled back' if remaining else 'Rolled back',batch))
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return len(rows)

    def batches(self,scope_=None):
        with self.connect() as db:
            if scope_ is None:return [dict(r) for r in db.execute('SELECT * FROM eye_native_batches ORDER BY rowid DESC LIMIT 100')]
            return [dict(r) for r in db.execute('''SELECT DISTINCT b.* FROM eye_native_batches b JOIN eye_native_changes c ON c.batch=b.id
                WHERE c.scope=? ORDER BY b.created DESC LIMIT 100''',(scope(scope_),))]

    def collection(self,scope_,kind,name,*,ref=None):
        matching=next((r for r in self.collections(scope_,kind) if r['data']['name']==name),None)
        if matching and ref and matching['id']!=ref:raise ValueError('Another collection already has that name.')
        if matching and not ref:ref=matching['id']
        ref=ref or identity('collection',kind,plain(name,100,empty=False))
        self.allow_restore(scope_,'collection',ref)
        self.put(scope_,'collection',ref,dict(entity_kind=kind,name=name))
        return ref

    def collections(self, scope_, kind=None):
        with self.connect() as db:
            rows = [self._row(r) for r in db.execute("SELECT * FROM eye_native_records WHERE scope=? AND kind='collection' ORDER BY id", (scope(scope_),))]
        return sorted((r for r in rows if kind is None or r['data']['entity_kind'] in (kind,'mixed')),
                      key=lambda r: (r['data']['name'].casefold(),r['id']))

    def annotations(self, scope_, entity):
        with self.connect() as db:
            return [self._row(r) for r in db.execute("SELECT * FROM eye_native_records WHERE scope=? AND kind='annotation' ORDER BY id",(scope(scope_),))
                    if json.loads(r['data']).get('entity')==entity]

    def annotate(self, scope_, entity, kind, value, *, color=''):
        if kind not in ('memo','note','nickname','tag','label'):raise ValueError('Choose an annotation type.')
        if not self.get(scope_,'entity',entity):raise ValueError('Save the item before annotating it.')
        if color and not re.fullmatch(r'#[0-9a-fA-F]{6}',color):raise ValueError('A tag color uses #RRGGBB.')
        ref=identity('annotation',entity,kind,value if kind in ('tag','label') else '')
        self.allow_restore(scope_,'annotation',ref)
        self.put(scope_,'annotation',ref,dict(entity=entity,type=kind,value=plain(value,20000),color=color))
        return ref

    def replace_annotations(self,scope_,entity,previous,note,tags):
        """Validate everything, then replace selected annotations in one commit."""
        target=scope(scope_);plain(note,20000)
        if not isinstance(tags,list) or len(tags)>50:raise ValueError('Keep up to 50 tags.')
        for value in tags:plain(value,100,empty=False)
        selected=[r for r in previous if r['data']['type'] in ('memo','note','tag','label')]
        desired=[]
        for kind,value in ([('memo',note)] if note else [])+[('tag',v) for v in dict.fromkeys(tags)]:
            ref=identity('annotation',entity,kind,value if kind=='tag' else '')
            desired.append(validate_record(dict(scope=target,kind='annotation',id=ref,
                data=dict(entity=entity,type=kind,value=value,color=''),provenance={'source':'VRC Eye local edit'})))
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not self._find(db,target,'entity',entity):raise ValueError('The saved item was removed.')
            actual=[self._row(r) for r in db.execute("SELECT * FROM eye_native_records WHERE scope=? AND kind='annotation' AND json_extract(data,'$.entity')=?",(target,entity))]
            actual=[r for r in actual if r['data']['type'] in ('memo','note','tag','label')]
            if {r['id']:digest(r) for r in actual}!={r['id']:digest(r) for r in selected}:raise ValueError('Notes or tags changed. Reopen the editor.')
            now=stamp()
            for row in selected:
                key=(target,'annotation',row['id'])
                db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',key)
                db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*key,now))
            for row in desired:
                key=(target,'annotation',row['id'])
                db.execute('DELETE FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key)
                db.execute('INSERT INTO eye_native_records VALUES(?,?,?,?,?,?,?)',(*key,canonical(row['data']),canonical(row['provenance']),digest(row),now))
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return len(desired)

    def move_membership(self, scope_, member, *, rank=None, collection=None):
        record=self.get(scope_,'membership',member)
        if not record:raise ValueError('Select an existing collection member.')
        data=record['data']
        if rank is not None:
            if type(rank)is not int or not -1000000000<=rank<=1000000000:raise ValueError('Enter a whole-number order between -1 billion and 1 billion.')
            data['rank']=rank
        if collection is not None:
            if not self.get(scope_,'collection',collection):raise ValueError('Choose an existing destination collection.')
            data['collection']=collection
        return self.put(scope_,'membership',member,data)

    def favorite(self,scope_,kind,ref,name,collection='General',data=None):
        kind='friend' if kind=='user' else kind;ref=entity_id(kind,ref);entity_ref=kind+':'+ref
        coll=next((r['id'] for r in self.collections(scope_,kind) if r['data']['name']==collection),None) or identity('collection',kind,plain(collection,100,empty=False));member=identity(coll,entity_ref)
        records=[dict(scope=scope(scope_),kind=k,id=i,data=d,provenance={'source':'VRC Eye local edit'}) for k,i,d in (
            ('entity',entity_ref,dict(entity_kind=kind,entity_id=ref,name=plain(name,512),fields=clean(data or {}))),
            ('collection',coll,dict(entity_kind=kind,name=collection)),
            ('membership',member,dict(collection=coll,entity=entity_ref,added=stamp(),rank=None)))]
        for r in records:
            self.allow_restore(r['scope'],r['kind'],r['id'])
            previous=self.get(r['scope'],r['kind'],r['id'])
            if previous:
                if r['kind']=='entity':
                    fields=dict(previous['data'].get('fields',{}));fields.update(r['data']['fields']);r['data']['fields']=fields
                else:r['data']=previous['data']
        return self.commit(self.prepare(records,policy='replace',source='Save favorite'))

    def collection_items(self,scope_,kind,query='',collection='',*,offset=0,limit=100):
        plain(query,512);plain(collection,100)
        if type(offset)is not int or offset<0 or type(limit)is not int or not 1<=limit<=1000:raise ValueError('Invalid collection page.')
        # JSON functions are not required: one cursor streams memberships and joins
        # referenced rows by primary key; only matching page records are retained.
        out=[];total=0
        with self.connect() as db:
            for row in db.execute("SELECT * FROM eye_native_records WHERE scope=? AND kind='membership' ORDER BY coalesce(json_extract(data,'$.rank'),2147483647),updated DESC,id",(scope(scope_),)):
                m=json.loads(row['data']);c=self._find(db,scope(scope_),'collection',m['collection']);a=self._find(db,scope(scope_),'entity',m['entity'])
                if not c or not a:continue
                c=json.loads(c['data']);a=json.loads(a['data'])
                if a.get('entity_kind')!=kind or collection and c['name']!=collection:continue
                terms=a.get('name','')+' '+a['entity_id']+' '+c['name']
                if query:
                    for note in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='annotation'",(scope(scope_),)):
                        annotation=json.loads(note[0])
                        if annotation.get('entity')==m['entity']:terms+=' '+annotation.get('value','')
                if query.casefold() not in terms.casefold():continue
                if offset<=total<offset+limit:out.append(dict(id=a['entity_id'],name=a.get('name') or a['entity_id'],collection=c['name'],
                    collection_id=m['collection'],membership_id=row['id'],data=a.get('fields',{}),updated=row['updated']))
                total+=1
        return out,total

    def migrate_legacy(self):
        """Explicitly shared legacy data stays shared; original tables are retained."""
        batch=str(uuid.uuid4());now=stamp();changed=suppressed=0
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT count(*) FROM favorites').fetchone()[0]>500000:raise ValueError('Legacy favorites exceed the 500,000-item migration budget.')
            db.execute('INSERT INTO eye_native_batches VALUES(?,?,?,?,?)',(batch,'Legacy Eye favorites',now,'Committed','{}'))
            for kind,ref,name,group,data,updated in db.execute('SELECT kind,id,name,collection,data,updated FROM favorites'):
                entity_ref=kind+':'+ref;coll=identity('collection',kind,group)
                membership=identity(coll,entity_ref)
                if any(db.execute("SELECT 1 FROM eye_native_suppressed WHERE scope='shared' AND kind=? AND id=?",key).fetchone()
                       for key in (('entity',entity_ref),('collection',coll),('membership',membership))):suppressed+=1;continue
                for k,i,d in (('entity',entity_ref,dict(entity_kind=kind,entity_id=ref,name=name,fields=json.loads(data))),
                    ('collection',coll,dict(entity_kind=kind,name=group)),
                    ('membership',membership,dict(collection=coll,entity=entity_ref,added=updated,rank=None))):
                    if self._find(db,'shared',k,i):continue
                    record=validate_record(dict(scope='shared',kind=k,id=i,data=d,provenance={'source':'Legacy Eye favorites'}))
                    fingerprint=digest(record)
                    db.execute('INSERT INTO eye_native_changes VALUES(?,?,?,?,?,?,0)',(batch,'shared',k,i,None,fingerprint))
                    db.execute('INSERT INTO eye_native_records VALUES(?,?,?,?,?,?,?)',('shared',k,i,canonical(d),canonical(record['provenance']),fingerprint,updated))
                    changed+=1
            self._validate_links(db,['shared'])
            db.execute('UPDATE eye_native_batches SET summary=? WHERE id=?',(canonical(dict(changed=changed,suppressed=suppressed)),batch))
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return dict(id=batch,changed=changed,conflicts=0,suppressed=suppressed)

    def scopes(self):
        with self.connect() as db:
            return [r[0] for r in db.execute('SELECT DISTINCT scope FROM eye_native_records UNION SELECT DISTINCT scope FROM eye_native_suppressed ORDER BY scope')]

    def prune(self, scope_, before, *, kinds=('event','notification'), preview=True):
        cutoff=datetime.fromisoformat(before.replace('Z','+00:00'))
        if cutoff.tzinfo is None:raise ValueError('Retention cutoff must include a time zone.')
        if not set(kinds)<= {'event','notification','relationship','aggregate','photo-reference'}:raise ValueError('Choose historical record types for retention.')
        selected=[]
        with self.connect() as db:
            for row in db.execute('SELECT * FROM eye_native_records WHERE scope=?',(scope(scope_),)):
                if row['kind'] not in kinds:continue
                data=json.loads(row['data']);when=data.get('reported_time') or data.get('latest_use') or row['updated']
                try:
                    moment=datetime.fromisoformat(str(when).replace('Z','+00:00'))
                    if moment.tzinfo and moment<cutoff:selected.append((row['kind'],row['id']))
                except ValueError:pass
            if not preview:
                for kind,ref in selected:
                    key=(scope(scope_),kind,ref)
                    db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*key,stamp()))
                db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return len(selected)

    def export_backup(self,path,scopes,*,stop=None):
        chosen=tuple(dict.fromkeys(scope(s) for s in scopes))
        if not chosen:raise ValueError('Choose at least one workspace.')
        target=Path(path);created=False;count=0;checksum=sha256()
        try:
            with target.open('x',encoding='utf-8',newline='\n') as stream,self.connect() as db:
                created=True;db.execute('BEGIN')
                stream.write(canonical({'format':'vrc-eye-native-backup','schema':1,'scopes':list(chosen),'created':stamp()})+'\n')
                for s in chosen:
                    for row in db.execute('SELECT * FROM eye_native_records WHERE scope=? ORDER BY kind,id',(s,)):
                        stopped(stop);line=canonical({'record':self._row(row)})+'\n';stream.write(line);checksum.update(line.encode());count+=1
                    for row in db.execute('SELECT scope,kind,id,created FROM eye_native_suppressed WHERE scope=? ORDER BY kind,id',(s,)):
                        stopped(stop);line=canonical({'suppression':dict(row)})+'\n';stream.write(line);checksum.update(line.encode());count+=1
                stream.write(canonical({'count':count,'sha256':checksum.hexdigest()})+'\n')
                stream.flush();__import__('os').fsync(stream.fileno())
            return count
        except Exception:
            if created:target.unlink(missing_ok=True)
            raise

    def read_backup(self,path,*,stop=None):
        from native_migration import strict_json
        p=Path(path)
        if p.stat().st_size>256*1024*1024:raise ValueError('Backup exceeds the 256 MiB import budget.')
        records=[];suppressed=[];checksum=sha256();count=0
        with p.open('rb') as stream:
            header=strict_json(stream.readline(MAX_RECORD+1))
            if header.get('format')!='vrc-eye-native-backup' or header.get('schema')!=1:raise ValueError('Choose a supported native backup.')
            scopes={scope(s) for s in header.get('scopes',[])}
            while True:
                stopped(stop);line=stream.readline(MAX_RECORD+1)
                if not line or len(line)>MAX_RECORD:raise ValueError('Incomplete or oversized backup record.')
                obj=strict_json(line)
                if set(obj)=={'count','sha256'}:
                    if obj['count']!=count or obj['sha256']!=checksum.hexdigest() or stream.read(1):raise ValueError('Backup checksum/count mismatch.')
                    break
                checksum.update(line);count+=1
                if count>MAX_BATCH:raise ValueError('Restore selected exports with at most 10,000 records per transaction.')
                if set(obj)=={'record'}:
                    r=validate_record(obj['record'])
                    if r['scope'] not in scopes:raise ValueError('Unexpected backup workspace.')
                    records.append(r)
                elif set(obj)=={'suppression'}:
                    r=obj['suppression']
                    if set(r)!={'scope','kind','id','created'} or scope(r['scope']) not in scopes or r['kind'] not in TYPES:raise ValueError('Invalid backup suppression.')
                    identifier(r['id']);suppressed.append(r)
                else:raise ValueError('Unknown backup record.')
        return records,suppressed

    def restore_backup(self,plan,suppressions,*,stop=None,check=None):
        return self.commit(plan,stop=stop,check=check,suppressions=suppressions)
