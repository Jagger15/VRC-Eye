"""Creator copy jobs use the shared original-preserving repair journal.

The destination is a workspace containing raw/, project/ and history/. A
review binds the source, destination and exact VPM command before copying.
Restart only exposes durable receipts; it never resumes a tool automatically.
"""
from dataclasses import asdict,dataclass,replace
import json
from pathlib import Path
import os
import time
import uuid

from creator_project_jobs import make_plan,make_template_plan,ToolInfo,tool_digest,run_bounded
from creator_projects import inspect_project,cancelled,assert_no_links,local_path
from recovery_journal import Journal,Review,encode,identity
import recovery_helper as helper
import recovery_diagnostics as diagnostics

BOOT_ID=uuid.uuid4().hex


@dataclass(frozen=True)
class CopyReview:
    review: Review

    def review_text(self):
        value=json.loads(self.review.payload)
        return value['review_text']+'\n\nRecovery workspace: '+value['copy']['destination']+(
            '\nraw/ preserves the source; project/ is the editable copy; history/ stores repair content. '
            'Allow space for two source copies plus later changes. Package changes receive a before/after '
            'journal record with reviewed, conditional file undo. Empty directories and file modes are '
            'outside content undo. Interrupted work is retained, never automatically replayed. '
            'Open Recovery history to inspect partial copies or undo a completed change checkpoint.')


@dataclass(frozen=True)
class TemplateReview(CopyReview):
    def review_text(self):
        value=json.loads(self.review.payload)
        return value['review_text']+('\n\nThe template is generated in this new workspace under generated/. '
            'A successful generation is preserved in recovery/raw/ and copied to recovery/project/ with shared repair history. '
            'The generated baseline is retained. Failure receipts and partial files remain for inspection; nothing replays automatically.')


class CreatorRecovery:
    def __init__(self,store,*,clock=time.monotonic):
        self.store=store;self.journal=Journal(store,clock=clock)
        with store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS creator_recovery_jobs(id TEXT PRIMARY KEY,account TEXT NOT NULL,updated REAL NOT NULL,data TEXT NOT NULL)')

    def discard(self,plan):
        with self.journal.mutex:self.journal.plans.pop(plan.review.id,None)

    def prepare(self,account,source,destination,operation,*,tool=None,package='',version='',stop=None,progress=lambda text:None):
        job=make_plan(source,destination,operation,tool=tool,package=package,version=version,stop=stop,progress=progress)
        copy=self.journal.prepare_create(account,job.source,job.destination,Path(source).name[:80]+' · Creator copy',stop=stop,progress=progress)
        value=self.journal.consume(copy)
        if value['snapshot']['digest']!=job.source_digest:raise ValueError('Source changed while preparing the copy review.')
        job=replace(job,destination=str(Path(job.destination)/'project'))
        payload=dict(copy=value,operation=operation,tool=asdict(job.tool) if job.tool else None,package=package,version=version,
            command=list(job.command()),review_text=job.review_text())
        return CopyReview(self.journal.offer(account,'Creator project copy job','',payload))

    def prepare_template(self,account,destination,template,tool):
        job=make_template_plan(destination,template,tool)
        root=Path(job.destination)
        # The parent exists at review time; generated/ is created only after
        # a durable intent is recorded, so the CLI never owns the workspace.
        job=replace(job,destination=str(root/'generated'/'Template'))
        payload=dict(destination=str(root),parent=list(identity(root.parent)),template=template,
            tool=asdict(tool),command=list(job.command()),review_text=job.review_text())
        return TemplateReview(self.journal.offer(account,'Creator template job','',payload))

    def _save(self,receipt):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not db.execute('SELECT 1 FROM creator_recovery_jobs WHERE id=?',(receipt['id'],)).fetchone():
                if db.execute('SELECT count(*) FROM creator_recovery_jobs').fetchone()[0]>=2000:
                    raise ValueError('Creator recovery history reached 2,000 jobs. Existing receipts are preserved.')
            db.execute('INSERT OR REPLACE INTO creator_recovery_jobs VALUES(?,?,?,?)',
                (receipt['id'],receipt['account'],time.time(),encode(receipt)))

    def receipts(self,account):
        from native_library import scope
        with self.store.connect() as db:
            rows=[json.loads(r[0]) for r in db.execute('SELECT data FROM creator_recovery_jobs WHERE account=? ORDER BY updated DESC LIMIT 200',(scope(account),))]
            for row in rows:
                if row.get('boot_id')!=BOOT_ID and row['state'] in ('Prepared','Copying','Copy ready','Helper prepared','Template submitted','Preserving template'):
                    row.update(saved_phase=row['state'],state='Interrupted / outcome unverified',
                        message='Earlier process stopped before a final receipt. Inspect the workspace and helper history; no automatic replay.')
                    if not row['recovery_workspace']:
                        workspace=db.execute('SELECT id FROM recovery_workspaces WHERE account=? AND root=?',(row['account'],row['workspace_root'])).fetchone()
                        if workspace:row['recovery_workspace']=workspace[0]
            return rows

    def _verified(self,receipt,*,stop=None,progress=lambda text:None):
        working=Path(receipt['destination'])
        receipt.update(files_state='Recorded working copy',working_identity=list(identity(working)),
            working_digest=diagnostics.snapshot(working,stop=stop,progress=progress)['digest'],catalog_state='Pending')
        self._save(receipt)

    def publish_catalog(self,receipt,snapshot,*,origin=None,stop=None,guard=lambda:None):
        """Catalog, scoped receipts and publication marker share one transaction."""
        from creator_projects import ProjectStore
        catalog=ProjectStore(self.store);row=self.journal.load(receipt['account'],receipt['recovery_workspace'])
        def check():cancelled(stop);guard()
        with self.journal.lock(row['root']) as stable:
            check();stable();self.journal.baseline(row,stop=stop)
            path=row['root']/'project'
            if str(path)!=receipt['destination'] or list(identity(path))!=receipt.get('working_identity') or diagnostics.snapshot(path,stop=stop)['digest']!=receipt.get('working_digest'):
                raise ValueError('The recorded working copy changed; catalog reconciliation stopped.')
            if os.path.normcase(str(local_path(snapshot['path'])))!=os.path.normcase(str(path)):raise ValueError('Catalog snapshot does not belong to this working copy.')
            with self.store.connect() as db:
                db.execute('BEGIN IMMEDIATE');check();stable()
                saved=db.execute('SELECT data FROM creator_recovery_jobs WHERE id=? AND account=?',(receipt['id'],receipt['account'])).fetchone()
                if not saved:raise ValueError('Creator receipt is unavailable in this account.')
                current=json.loads(saved[0])
                if current.get('catalog_state')=='Published':
                    ref=current['catalog_project_id'];found=db.execute('SELECT path FROM creator_projects_120 WHERE id=?',(ref,)).fetchone()
                    if not found or found[0]!=os.path.normcase(str(path)):raise ValueError('Published catalog entry was removed or changed; it is not recreated automatically.')
                    return ref
                if current!=receipt or current.get('catalog_state')!='Pending':raise ValueError('Creator receipt changed after review.')
                ref=catalog.save(snapshot,_db=db);published=dict(current,catalog_state='Published',catalog_project_id=ref)
                if origin:
                    source=db.execute('SELECT path FROM creator_projects_120 WHERE id=?',(origin,)).fetchone()
                    if not source or source[0]!=os.path.normcase(str(local_path(receipt['source']))):raise ValueError('Original catalog selection changed.')
                    catalog.receipt(origin,published,_db=db,_identity='creator-job:'+receipt['id']+':'+origin)
                catalog.receipt(ref,published,_db=db,_identity='creator-job:'+receipt['id']+':'+ref)
                db.execute('UPDATE creator_recovery_jobs SET updated=?,data=? WHERE id=? AND account=?',(time.time(),encode(published),receipt['id'],receipt['account']))
                check();stable()
            receipt.update(published);return ref

    def prepare_catalog_reconcile(self,account,receipt_id,*,stop=None,progress=lambda text:None):
        from native_library import scope
        with self.store.connect() as db:
            row=db.execute('SELECT data FROM creator_recovery_jobs WHERE id=? AND account=?',(receipt_id,scope(account))).fetchone()
        if not row:raise ValueError('Creator receipt is unavailable in this account.')
        receipt=json.loads(row[0])
        if receipt.get('catalog_state')!='Pending' or receipt.get('files_state')!='Recorded working copy':raise ValueError('Select a verified working-copy receipt awaiting catalog publication.')
        workspace=self.journal.load(account,receipt['recovery_workspace']);self.journal.baseline(workspace,stop=stop,progress=progress)
        path=workspace['root']/'project'
        if str(path)!=receipt['destination'] or list(identity(path))!=receipt['working_identity'] or diagnostics.snapshot(path,stop=stop,progress=progress)['digest']!=receipt['working_digest']:
            raise ValueError('The retained working copy changed or its path was replaced. Inspect it manually before adding a fresh catalog entry.')
        snapshot=inspect_project(path,stop=stop)
        return self.journal.offer(account,'Reconcile creator catalog',receipt['recovery_workspace'],dict(receipt=receipt,snapshot=snapshot))

    def reconcile_catalog(self,plan,*,stop=None,guard=lambda:None):
        value=self.journal.consume(plan)
        if plan.operation!='Reconcile creator catalog':raise ValueError('Choose a creator catalog reconciliation review.')
        return self.publish_catalog(value['receipt'],value['snapshot'],stop=stop,guard=guard)

    def execute(self,plan,*,stop=None,progress=lambda text:None,guard=lambda:None,runner=run_bounded):
        if isinstance(plan,TemplateReview):return self._template(plan,stop=stop,progress=progress,guard=guard,runner=runner)
        value=self.journal.consume(plan.review)
        if plan.review.operation!='Creator project copy job':raise ValueError('Choose a reviewed Creator copy job.')
        cancelled(stop);guard();tool=ToolInfo(**value['tool']) if value['tool'] else None
        if tool and tool_digest(tool.path)!=tool.digest:raise ValueError('The reviewed CLI changed. Prepare a fresh review.')
        receipt=dict(schema=1,id=plan.review.id,boot_id=BOOT_ID,account=plan.review.account,operation=value['operation'],
            source=value['copy']['source'],destination=str(Path(value['copy']['destination'])/'project'),
            workspace_root=value['copy']['destination'],recovery_workspace='',helper_receipt='',
            command=value['command'],state='Prepared',message='Copy not submitted; no automatic replay.')
        self._save(receipt)
        try:
            receipt.update(state='Copying',message='Preserving raw baseline and working copy.');self._save(receipt)
            copy=self.journal.offer(plan.review.account,'Create working copy','',value['copy'])
            workspace=self.journal.create(copy,stop=stop,progress=progress,guard=guard)
            receipt.update(recovery_workspace=workspace,state='Copy ready',message='Raw baseline and working copy verified.');self._save(receipt)
            if value['operation']!='Copy only':
                cancelled(stop);guard()
                working=Path(receipt['destination'])
                if diagnostics.snapshot(working,stop=stop,progress=progress)['digest']!=value['copy']['snapshot']['digest']:
                    raise ValueError('Working copy changed before the helper was prepared. No CLI was run.')
                review=helper.prepare(self.journal,plan.review.account,workspace,value['operation'],tool,
                    package=value['package'],version=value['version'],stop=stop,progress=progress)
                details=json.loads(review.payload)
                if details['command']!=value['command'] or details['working_digest']!=value['copy']['snapshot']['digest']:
                    raise ValueError('The helper no longer matches the reviewed copy job.')
                receipt.update(helper_receipt=review.id,state='Helper prepared',message='Inspect the shared helper receipt for submission and checkpoint outcome.');self._save(receipt)
                ref=helper.execute(self.journal,review,stop=stop,progress=progress,guard=guard,runner=runner)
                result=next(r for r in self.journal.history(plan.review.account,workspace) if r['id']==ref)
                receipt.update(state=result['state'],message=result['outcome'],after_checkpoint=result['after_checkpoint'])
            else:receipt.update(state='Completed',message='Journaled copy ready. Future edits can be checkpointed in Recovery history.')
            snapshot=inspect_project(receipt['destination'],stop=stop)
            self._verified(receipt,stop=stop,progress=progress)
            return receipt,snapshot
        except BaseException as error:
            # Even if copying did not return, Journal.create persisted its workspace
            # before files. Link that incomplete workspace for restart inspection.
            if not receipt['recovery_workspace']:
                with self.store.connect() as db:
                    row=db.execute('SELECT id FROM recovery_workspaces WHERE account=? AND root=?',
                        (plan.review.account,receipt['workspace_root'])).fetchone()
                if row:receipt['recovery_workspace']=row[0]
            receipt.update(state='Interrupted; inspect recovery history',message=str(error)[:1000] or 'Operation interrupted; no automatic replay.')
            self._save(receipt)
            if not isinstance(error,Exception):raise
            return receipt,None

    def _template(self,plan,*,stop,progress,guard,runner):
        value=self.journal.consume(plan.review)
        if plan.review.operation!='Creator template job':raise ValueError('Choose a template review.')
        root=assert_no_links(local_path(value['destination']));tool=ToolInfo(**value['tool'])
        def check():
            cancelled(stop);guard();assert_no_links(root)
            if identity(root.parent)!=tuple(value['parent']):raise ValueError('The template destination parent changed.')
            if tool_digest(tool.path)!=tool.digest:raise ValueError('The template CLI changed after review.')
        check()
        if root.exists():raise ValueError('Choose an unused template workspace.')
        receipt=dict(schema=1,id=plan.review.id,boot_id=BOOT_ID,account=plan.review.account,operation='Create from template',
            source='',destination=str(root/'recovery'/'project'),workspace_root=str(root/'recovery'),
            generated=str(root/'generated'/'Template'),recovery_workspace='',helper_receipt='',command=value['command'],
            state='Prepared',message='Template not submitted; no automatic replay.',cli_exit=None)
        self._save(receipt)
        try:
            check();root.mkdir(mode=0o700)
            with self.journal.lock(root) as stable:
                def guarded():check();stable()
                guarded();(root/'generated').mkdir(mode=0o700)
                # Rebuild the documented command against the exact now-created
                # parent. A changed capability/path cannot alter reviewed args.
                job=make_template_plan(receipt['generated'],value['template'],tool)
                if list(job.command())!=value['command']:raise ValueError('The template command changed after review.')
                guarded();receipt.update(state='Template submitted',message='CLI may be running; no automatic replay.');self._save(receipt)
                code,_=runner(job.command(),cwd=root/'generated',stop=stop,timeout=600);receipt['cli_exit']=code
                guarded()
                if code!=0:raise ValueError('Template CLI returned a nonzero exit code. Inspect retained generated files.')
                result=inspect_project(receipt['generated'],stop=stop)
                if result['state']=='Unavailable':raise ValueError('Template CLI did not produce the reviewed project.')
                receipt.update(state='Preserving template',message='Template generated; preserving baseline and working copy.');self._save(receipt)
                review=self.journal.prepare_create(plan.review.account,receipt['generated'],root/'recovery',value['template']+' template',stop=stop,progress=progress)
                receipt['recovery_workspace']=self.journal.create(review,stop=stop,progress=progress,guard=guarded)
                guarded();snapshot=inspect_project(receipt['destination'],stop=stop)
                receipt.update(state='CLI completed; Unity validation required',message='Template baseline and editable copy are journaled. Unity compilation has not been tested.')
                self._verified(receipt,stop=stop,progress=progress);return receipt,snapshot
        except BaseException as error:
            if not receipt['recovery_workspace']:
                with self.store.connect() as db:
                    row=db.execute('SELECT id FROM recovery_workspaces WHERE account=? AND root=?',(plan.review.account,receipt['workspace_root'])).fetchone()
                if row:receipt['recovery_workspace']=row[0]
            receipt.update(state='Interrupted; inspect recovery history',message=str(error)[:1000] or 'Template interrupted; no automatic replay.')
            self._save(receipt)
            if not isinstance(error,Exception):raise
            return receipt,None
