"""Native Developer / Black Lab workspace; no UI callback silently sends a request."""
from __future__ import annotations

from text_viewport import window_body
from copy import deepcopy
from pathlib import Path
import json
import time
from companion_ui import Page, Table, button, choice, entry, line
from developer_catalog import BY_KEY, OPERATIONS, FAMILIES, validate_request, fingerprint, request_path
from developer_core import bounded_json, canonical, schema_diff, value_diff, redact
from developer_service import ENVIRONMENTS, CONTACT_KEY
from developer_lab import FAILURES, parse_log, fuzz
from developer_data import (state_snapshot, integrations, database_paths, inspect_database,
                            backup_database, report_preview, export_report)

TABS = ('Overview','API Workbench','Traffic','Events & State','Testing Lab','Data & Recovery','Integrations','Client Bridge Lab','Reports')


def pretty(value): return json.dumps(value,ensure_ascii=False,indent=2,default=str,allow_nan=False)


class DeveloperPage(Page):
    def __init__(self,shell,parent):
        super().__init__(shell,parent,'Developer / Black Lab')
        self.service = shell.developer
        self.selected_operation = BY_KEY['account.get']
        self.prepared_action = None
        self.preview_bundle = None
        self.last_refresh = 0.0
        self.last_sequence = -1
        self.response = None
        self.trace_rows = []
        self.header = self.tk.StringVar()
        self.environment = self.tk.StringVar(value=self.service.environment)
        self.armed = self.tk.BooleanVar(value=False)
        row=line(self)
        self.ttk.Label(row,text='Environment').pack(side='left',padx=(0,8))
        choice(self,row,self.environment,ENVIRONMENTS,self.change_environment,width=12)
        self.ttk.Checkbutton(row,text='Arm live API writes',variable=self.armed,
                             command=lambda:self.guard(self.change_arm)).pack(side='left',padx=8)
        button(self,row,'API settings',self.open_networking)
        self.note(parent,self.header)
        self.tabs=self.ttk.Notebook(parent);self.tabs.pack(fill='both',expand=True)
        self.frames,self.panes={},{}
        from resource_ui import ResourcePage
        for name in TABS:
            frame=self.ttk.Frame(self.tabs);self.tabs.add(frame,text=name);self.frames[name]=frame
            self.panes[name]=ResourcePage.scrolling_pane(self,frame)
        self.build_overview();self.build_workbench();self.build_traffic();self.build_state()
        self.build_lab();self.build_data();self.build_integrations();self.build_reports()
        from bridge_lab_ui import ClientLabPanel
        self.bridge_lab_panel=ClientLabPanel(self,self.panes['Client Bridge Lab'])
        self.load_example();self.refresh_header();self.refresh_overview()
        self.status.set('Sandbox is isolated in memory. No live requests, sign-in, listeners or permissions are started by opening this workspace.')

    def note(self,parent,value):
        from ui_theme import responsive_wrap
        kwargs={'textvariable':value} if hasattr(value,'get') else {'text':value}
        label=responsive_wrap(self.ttk.Label(parent,wraplength=840,justify='left',**kwargs),maximum=1040)
        label.pack(anchor='w',fill='x',pady=5)
        return label

    def heading(self,parent,text):
        from ui_theme import responsive_wrap
        responsive_wrap(self.ttk.Label(parent,text=text,style='Title.TLabel',justify='left'),maximum=1040).pack(anchor='w',fill='x',pady=(12,6))

    def text_box(self,parent,*,height=12,editable=False):
        frame=self.ttk.Frame(parent);frame.pack(fill='both',expand=True,pady=5)
        box=self.tk.Text(frame,height=height,width=40,wrap='word',undo=editable)
        scroll=self.ttk.Scrollbar(frame,orient='vertical',command=box.yview)
        box.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');box.pack(fill='both',expand=True)
        if not editable:box.configure(state='disabled')
        return box

    def put(self,box,value,*,editable=False):
        text=value if isinstance(value,str) else pretty(value)
        box.configure(state='normal');box.delete('1.0','end');box.insert('1.0',text)
        if not editable:box.configure(state='disabled')

    def get_request(self):
        _,request=validate_request(self.composer.get('1.0','end-1c'))
        return request

    def open_networking(self):
        exp=getattr(self.app,'experience',None)
        if exp:exp.open_tool('network:Developer API')
        else:self.shell.show('Networking')

    def change_environment(self):
        self.cancel()
        self.service.switch(self.environment.get())
        self.prepared_action=None;self.response=None;self.preview_bundle=None
        self.armed.set(False)
        self.bridge_lab_panel.clear();self.bridge_lab_panel.tick()
        self.put(self.response_box,{'state':'Environment changed; previous response cleared.'})
        self.put(self.review_box,{'state':'Previous confirmation invalidated.'})
        self.put(self.state_box,{'state':'Refresh the selected environment’s state.'})
        self.put(self.report_box,{'state':'Generate a new report preview.'})
        self.refresh_header();self.refresh_overview()
        self.status.set('Environment changed. Pending tasks and prior approvals were cancelled. Review the request’s target IDs before using it.')

    def change_arm(self):
        value=bool(self.armed.get())
        try:
            if value and not self.confirm('Arm developer API writes?',
                'This enables individually reviewed account/resource operations in Live. It does not grant platform permissions, arm OSC, or affect Sandbox. Every action still requires its own exact preview. Continue?'):
                self.armed.set(False);return
            self.service.arm(value)
        finally:
            self.armed.set(self.service.live_writes)
            self.refresh_header()

    def refresh_header(self):
        account=getattr(getattr(self.app,'api',None),'user_id','')
        alias=('Connected account …'+account[-8:]) if account else 'No connected account'
        label='LIVE API WRITES ARMED' if self.service.live_writes else 'Live API writes disarmed'
        self.header.set(f'{self.service.environment}  •  {alias}  •  {label}  •  Shared API pacing; no automatic write retry')
        self.environment.set(self.service.environment);self.armed.set(self.service.live_writes)

    def build_overview(self):
        pane=self.panes['Overview']
        self.heading(pane,'One workbench. The real application services.')
        self.note(pane,'Inspect VRC Eye’s own API traffic, compose reviewed operations, compare responses, and reproduce failures. Developer visibility needs no key. Live account access and each action’s authorization remain separate.')
        row=line(self,pane)
        for title,target in (('Open API Workbench','API Workbench'),('Inspect traffic','Traffic'),('Open Testing Lab','Testing Lab')):
            button(self,row,title,lambda name=target:self.tabs.select(self.frames[name]))
        from inspection_reports_ui import show as show_reports
        button(self,line(self,pane),'Local metadata & inspection reports…',lambda:show_reports(self.shell))
        self.note(pane,'Sandbox uses fake resources and an in-memory executor. Replay feeds normalized events through the real player model with no network or history writer. Live uses the existing account and shared request budget.')
        self.overview_box=self.text_box(pane,height=17)
        button(self,line(self,pane),'Refresh overview',self.refresh_overview)
        self.note(pane,'This release implements the first shared foundation and API adapters—not every item in the full roadmap. Group-role writes, invitation sending, full migration/repair automation, SDK orchestration and extension hosting remain future work.')

    def refresh_overview(self):self.put(self.overview_box,self.service.snapshot())

    def build_workbench(self):
        pane=self.panes['API Workbench']
        row=line(self,pane)
        self.search=self.tk.StringVar(value='');self.family=self.tk.StringVar(value='All')
        self.ttk.Label(row,text='Find an operation').pack(side='left',padx=(0,8))
        entry(self,row,self.search,width=24)
        choice(self,row,self.family,('All',)+FAMILIES,self.filter_catalog,width=16)
        button(self,row,'Filter',self.filter_catalog)
        self.catalog=Table(self,pane,(('method','Method',65),('title','Operation',300),('family','Area',110),('support','Support',190)),height=5,select=self.select_operation)
        self.catalog_detail=self.tk.StringVar()
        self.note(pane,self.catalog_detail)
        row=line(self,pane)
        button(self,row,'Guided fields…',self.guided_form)
        button(self,row,'Load example',self.load_example)
        button(self,row,'Validate only',self.validate)
        button(self,row,'Import request…',self.import_request)
        button(self,row,'Save request…',self.save_request)
        self.note(pane,'Request JSON — the operation field below determines what runs. Selecting a catalog row does not overwrite your draft; use Guided fields or Load example.')
        self.composer=self.text_box(pane,height=11,editable=True)
        row=line(self,pane)
        button(self,row,'Read',lambda:self.run_operation('read'))
        button(self,row,'Fresh read',lambda:self.run_operation('fresh'))
        button(self,row,'Next page',self.next_page)
        button(self,row,'Pin response',self.pin_response)
        button(self,row,'Compare response',self.compare_response)
        row=line(self,pane)
        button(self,row,'1. Prepare write',lambda:self.run_operation('prepare'))
        button(self,row,'2. Review & send…',self.review_send)
        button(self,row,'Verify without repeating',lambda:self.run_operation('verify'))
        self.note(pane,'Preflight, dispatch and verification share the normal request interval. A success response does not establish that the VRChat client joined an instance, loaded an avatar, or applied an immediate safety effect.')
        self.heading(pane,'Response / comparison')
        self.response_box=self.text_box(pane,height=15)
        self.heading(pane,'Prepared action preview')
        self.review_box=self.text_box(pane,height=12)
        self.filter_catalog()

    def filter_catalog(self):
        terms=self.search.get().casefold().split()[:10];family=self.family.get()
        rows=[o for o in OPERATIONS if (family=='All' or o.family==family) and
              all(t in (o.key+' '+o.title+' '+o.route+' '+o.family).casefold() for t in terms)]
        self.catalog.set(rows,lambda o:(o.method,o.title,o.family,'Adapter · live unverified' if o.live else 'Reference only'))

    def select_operation(self):
        operation=self.catalog.selected()
        if operation:
            self.selected_operation=operation
            self.catalog_detail.set(f'{operation.method} /{operation.route}  •  {operation.scope}\n{operation.notes}\nReference: {operation.source}  |  No live verification recorded in this release.')
            self.status.set('Operation selected. Load its example or open Guided fields to replace the current draft.')

    def load_example(self):
        operation=self.selected_operation
        if not operation.live:
            self.put(self.response_box,operation.describe())
            self.status.set('Reference-only entry. No executor is attached.');return
        value=operation.example()
        if self.service.environment=='Live':
            account=getattr(getattr(self.app,'api',None),'user_id','')
            for key in value['path']:
                value['path'][key]=account if key=='userId' and operation.scope=='Own account only' else ''
            for key in ('worldId','favoriteId','moderated'):
                if key in value['body']:value['body'][key]=''
            if 'ownerId' in value['body']:value['body']['ownerId']=account
        self.put(self.composer,value,editable=True)
        self.prepared_action=None
        self.catalog_detail.set(f'{operation.method} /{operation.route}  •  {operation.scope}\n{operation.notes}\nReference: {operation.source}')
        self.put(self.review_box,{'state':'No prepared action. Changes to this draft require a new preview.'})

    def validate(self):
        request=self.get_request();op=BY_KEY[request['operation']]
        self.put(self.response_box,{'valid':True,'network_requests':0,'operation':op.describe(),
                                   'request_fingerprint':fingerprint(request),'route':request_path(op,request)})
        self.status.set('Local schema validation passed. This does not establish server permission or current service compatibility.')

    def run_operation(self,kind):
        request=self.get_request();generation=self.service.generation;environment=self.service.environment
        def work(client,stop,progress):
            if generation!=self.service.generation or environment!=self.service.environment or stop.is_set():
                raise ValueError('The environment changed before this task started.')
            if kind in ('read','fresh'):return self.service.read(request,stop=stop,progress=progress,fresh=kind=='fresh')
            if kind=='prepare':return self.service.prepare(request,stop=stop,progress=progress)
            if kind=='verify':return self.service.verify(request,stop=stop,progress=progress)
            raise ValueError('Unsupported workbench task.')
        def done(value):
            if generation!=self.service.generation:return
            if kind=='prepare':
                self.prepared_action=value
                self.put(self.review_box,value['preview'])
                self.status.set('Prepared only. Review & send is still required; no mutation was submitted.')
            else:self.show_result(value)
        self.start(work,done,api=environment=='Live')

    def show_result(self,value):
        self.response=deepcopy(value);self.put(self.response_box,value)
        self.refresh_header();self.refresh_overview()
        self.status.set(value.get('outcome','Task complete.')+' — '+value.get('verification','Inspect the response and its observation time.'))

    def review_send(self):
        if self.prepared_action is None:raise ValueError('Prepare this exact write first.')
        request=self.get_request()
        if fingerprint(request)!=self.prepared_action['fingerprint']:
            self.prepared_action=None;raise ValueError('Draft changed. Prepare a new exact preview.')
        preview=self.prepared_action['preview']
        if self.service.environment=='Live' and not self.service.live_writes:
            raise ValueError('Arm live API writes explicitly before sending. Developer visibility alone is not permission.')
        text=(f"Environment: {preview['environment']}\nAccount: {preview['account']}\n"
              f"Operation: {preview['operation']}\nScope: {preview['scope']}\n\n"
              'EXACT REQUEST\n'+pretty(request)+'\n\nCURRENT VALUES\n'+pretty(preview['current_values'])+
              '\n\nOne attempt only. An uncertain outcome will not be automatically retried. Submit this request?')
        if not self.confirm('Review developer API action',text):return
        token=self.prepared_action['token'];self.prepared_action=None
        generation=self.service.generation;environment=self.service.environment
        def work(client,stop,progress):
            return self.service.execute(token,request,stop=stop,progress=progress)
        self.start(work,lambda value:self.show_result(value) if generation==self.service.generation else None,
                   api=environment=='Live',mutation=True)

    def next_page(self):
        request=self.get_request()
        if not self.response or self.response.get('operation')!=request['operation']:
            raise ValueError('Read the current list operation first.')
        page=self.response.get('pagination')
        if not page or page.get('next_offset') is None:raise ValueError('This response does not advertise a next inspection page.')
        # A changed resource or query must not reuse unrelated continuation state.
        op=BY_KEY[request['operation']]
        from developer_core import safe_route
        if self.response.get('request_fingerprint')!=fingerprint(request):
            raise ValueError('The request changed since the last page. Read it first.')
        request['query']['offset']=page['next_offset']
        self.put(self.composer,request,editable=True);self.run_operation('read')

    def pin_response(self):
        if self.response is None:raise ValueError('Read a response before pinning it.')
        self.service.comparison_response=deepcopy(self.response)
        self.status.set('Sanitized response pinned in memory for this environment/account. It is not saved to disk.')

    def compare_response(self):
        a,b=self.service.comparison_response,self.response
        if not a or not b:raise ValueError('Pin an earlier response, then read another response.')
        self.put(self.response_box,{'before_operation':a.get('operation'),'after_operation':b.get('operation'),
             'comparison_scope':'Sanitized on-device responses; omitted private values cannot be compared',
             'schema_changes':schema_diff(a.get('response',{}),b.get('response',{})),
             'value_changes':value_diff(a.get('response',{}),b.get('response',{}))})

    def import_request(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title='Import a data-only request',filetypes=[('JSON request','*.json')])
        if not path:return
        with open(path,'rb') as stream:value=stream.read(256*1024+1)
        op,request=validate_request(value)
        self.selected_operation=op;self.put(self.composer,request,editable=True);self.prepared_action=None
        self.status.set('Imported and validated as data only. Nothing was executed; no scripts, headers or alternate hosts are supported.')

    def save_request(self):
        from tkinter import filedialog
        request=self.get_request()
        if not self.confirm('Save this request as plain JSON?',
                'The file will include the target IDs and the text you entered. It will not contain credentials. Keep personal drafts private. Continue?'):return
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Save a new request file',defaultextension='.json',filetypes=[('JSON request','*.json')])
        if not path:return
        with open(path,'x',encoding='utf-8') as stream:stream.write(pretty(request)+'\n')
        self.status.set('Request saved. Importing it later will not execute it.')

    def guided_form(self):
        op=self.selected_operation
        if not op.live:raise ValueError('This reference-only entry has no request form.')
        try:
            current=self.get_request()
            if current['operation']!=op.key:current=op.example()
        except ValueError:current=op.example()
        win=self.tk.Toplevel(self.app.root);win.title('Guided request · '+op.title);win.geometry('760x650')
        outer=self.ttk.Frame(window_body(win),padding=14);outer.pack(fill='both',expand=True)
        self.note(outer,'Build a draft from reviewed fields. This form does not send requests. Unchecked optional fields are omitted.')
        from resource_ui import ResourcePage
        holder=self.ttk.Frame(outer);holder.pack(fill='both',expand=True)
        pane=ResourcePage.scrolling_pane(self,holder)
        variables=[]
        for part,fields in (('path',op.path_fields),('query',op.query_fields),('body',op.body_fields)):
            if not fields:continue
            self.heading(pane,part.title())
            for name,descriptor in fields.items():
                row=line(self,pane)
                included=self.tk.BooleanVar(value=descriptor.required or name in current[part])
                check=self.ttk.Checkbutton(row,text=name,variable=included,width=24);check.pack(side='left')
                if descriptor.required:check.configure(state='disabled')
                val=current[part].get(name,descriptor.example)
                value=self.tk.StringVar(value=canonical(val) if descriptor.kind!='string' else val)
                options=descriptor.choices or (('true','false') if descriptor.kind=='boolean' else ())
                if options:choice(self,row,value,options,width=29)
                else:entry(self,row,value,width=36)
                variables.append((part,name,descriptor,included,value))
                self.note(pane,f'{descriptor.kind}; '+('required' if descriptor.required else 'optional')+f'; local bounds {descriptor.minimum}–{descriptor.maximum}')
        error=self.tk.StringVar();self.note(outer,error)
        def apply():
            try:
                draft={'operation':op.key,'path':{},'query':{},'body':{}}
                for part,name,descriptor,included,value in variables:
                    if included.get():
                        raw=value.get()
                        draft[part][name]=raw if descriptor.kind=='string' else bounded_json(raw)
                _,draft=validate_request(draft)
                self.put(self.composer,draft,editable=True);self.prepared_action=None;win.destroy()
                self.status.set('Guided draft created. Validate, read, or prepare it explicitly.')
            except ValueError as exc:error.set(str(exc))
        row=self.ttk.Frame(outer);row.pack(fill='x',pady=8)
        self.ttk.Button(row,text='Use this draft',command=apply).pack(side='left')
        self.ttk.Button(row,text='Cancel',command=win.destroy).pack(side='right')

    def build_traffic(self):
        pane=self.panes['Traffic']
        self.note(pane,'This observes requests made by VRC Eye’s shared API client, plus its existing receive-only pipeline. It does not intercept VRChat, browser traffic, or another application’s sessions. Payloads are redacted before entering the recorder.')
        row=line(self,pane);self.traffic_search=self.tk.StringVar(value='')
        entry(self,row,self.traffic_search,width=30)
        button(self,row,'Refresh / filter',self.refresh_traffic)
        button(self,row,'Pin selected trace',self.pin_trace)
        button(self,row,'Clear recorder',self.clear_recorder)
        self.traffic=Table(self,pane,(('sequence','#',60),('environment','Environment',95),('kind','Event',155),('operation','Operation / origin',215),('status','Outcome',155)),height=10,select=self.select_trace)
        self.trace_box=self.text_box(pane,height=18)

    def refresh_traffic(self):
        self.trace_rows=self.service.recorder.snapshot(query=self.traffic_search.get(),limit=500)
        self.traffic.set(self.trace_rows,lambda r:(r['sequence'],r['environment'],r['kind'],r['operation'] or r['origin'],r['payload'].get('outcome',r['payload'].get('status',r['payload'].get('phase','')))))
        self.last_sequence=self.service.recorder.stats()['sequence']

    def select_trace(self):
        row=self.traffic.selected()
        if row:self.put(self.trace_box,row)

    def pin_trace(self):
        row=self.traffic.selected()
        if not row:raise ValueError('Select an event to pin.')
        self.service.recorder.pin(row['sequence']);self.status.set('Redacted event pinned in memory. Pin limit: 20.')

    def clear_recorder(self):
        if self.confirm('Clear developer recordings?','Remove this session’s retained events and pins? This does not erase application history or make API requests.'):
            self.service.recorder.clear();self.preview_bundle=None
            self.put(self.trace_box,{});self.refresh_traffic()

    def build_state(self):
        pane=self.panes['Events & State'];self.state_kind=self.tk.StringVar(value='Players')
        self.note(pane,'Live shows the existing player model with per-field candidates, selected source, freshness and confidence. Sandbox shows only synthetic records. Replay shows its isolated player model. API cache inspection reads the shared client cache without fetching records.')
        row=line(self,pane)
        choice(self,row,self.state_kind,('Players','Session','Last API result','API cache','Providers'),width=24)
        button(self,row,'Inspect state',self.refresh_state)
        button(self,row,'Invalidate live API cache…',self.clear_cache)
        self.state_box=self.text_box(pane,height=28)

    def refresh_state(self):self.put(self.state_box,state_snapshot(self.app,self.service,self.state_kind.get()))

    def clear_cache(self):
        if self.confirm('Invalidate the local API cache?',
            'Only cached API observations are cleared. Notes and history remain. Nothing is fetched automatically; a later feature read may request fresh data. Continue?'):
            self.put(self.state_box,self.service.invalidate_cache())

    def build_lab(self):
        pane=self.panes['Testing Lab']
        self.heading(pane,'Synthetic API failures')
        self.note(pane,'These failures apply only to the Sandbox executor. “Lose write response” waits through preflight reads, applies the mutation to a fixture, then loses the response. The live transport is never fuzzed.')
        row=line(self,pane);self.failure=self.tk.StringVar(value='None')
        choice(self,row,self.failure,FAILURES,width=28)
        button(self,row,'Inject next Sandbox failure',self.inject_failure)
        button(self,row,'Reset Sandbox fixtures',self.reset_fixtures)
        self.heading(pane,'Deterministic player replay')
        self.note(pane,'The built-in scenario includes duplicate joins, avatar changes and a departure. Step it through the real PlayerSessionService with virtual time and a history worker that rejects writes. These controls never perform API requests, even when Live is selected.')
        row=line(self,pane)
        button(self,row,'Reset scenario',self.reset_replay)
        button(self,row,'Step one event',lambda:self.step_replay(1))
        button(self,row,'Run remaining events',lambda:self.step_replay(2000))
        button(self,row,'Import scenario…',self.import_replay)
        row=line(self,pane)
        button(self,row,'Run 250 local fuzz cases',self.run_fuzz)
        self.lab_box=self.text_box(pane,height=13)
        self.heading(pane,'Real log-parser workbench')
        self.note(pane,'Paste a bounded log segment. Parsing is local; raw pasted text is not recorded or included in reports. Lines with no normalized player event are counted, not claimed to be parser failures.')
        self.log_input=self.text_box(pane,height=7,editable=True)
        button(self,line(self,pane),'Parse pasted text',lambda:self.put(self.lab_box,parse_log(self.log_input.get('1.0','end-1c'))))

    def inject_failure(self):
        if self.service.environment!='Sandbox':raise ValueError('Choose Sandbox before injecting a fixture failure.')
        self.service.sandbox.inject(self.failure.get());self.status.set('One-shot offline failure configured. Live services are unchanged.')

    def reset_fixtures(self):
        self.cancel();self.put(self.lab_box,self.service.reset_sandbox());self.prepared_action=None

    def reset_replay(self):self.put(self.lab_box,self.service.replay.load_builtin())
    def step_replay(self,count):self.put(self.lab_box,self.service.replay.step(count))

    def import_replay(self):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title='Import normalized replay scenario',filetypes=[('JSON scenario','*.json')])
        if not path:return
        with open(path,'rb') as stream:text=stream.read(256*1024+1)
        self.put(self.lab_box,self.service.replay.import_events(text))

    def run_fuzz(self):
        self.start(lambda client,stop,progress:fuzz(stop=stop),lambda result:self.put(self.lab_box,result),api=False)

    def build_data(self):
        pane=self.panes['Data & Recovery']
        self.note(pane,'Inspect VRC Eye’s own SQLite schema, table counts and integrity with fixed read-only queries. No row contents, arbitrary SQL or VRCX database access. Select Live to inspect actual application data; VRChat sign-in is not required for local database work.')
        row=line(self,pane);self.database=self.tk.StringVar(value='Companion')
        self.db_choice=choice(self,row,self.database,('Companion',),width=26)
        button(self,row,'Refresh database list',self.refresh_databases)
        button(self,row,'Inspect read-only',self.inspect_database)
        button(self,line(self,pane),'Create consistent backup…',self.backup_database)
        self.note(pane,'A database backup contains original private data and is NOT a sanitized report. This release never repairs or replaces the active database. Full migration/rollback and staged repair automation remain roadmap items.')
        self.data_box=self.text_box(pane,height=26)
        self.refresh_databases()

    def refresh_databases(self):
        self.db_paths=database_paths(self.app);values=tuple(self.db_paths) or ('Companion',)
        self.db_choice.configure(values=values)
        if self.database.get() not in values:self.database.set(values[0])

    def database_path(self):
        if self.service.environment!='Live':raise ValueError('Choose Live for explicit inspection of actual VRC Eye data. Sandbox and Replay do not read these stores.')
        self.refresh_databases()
        path=self.db_paths.get(self.database.get())
        if path is None:raise ValueError('This store is not initialized.')
        return path

    def inspect_database(self):
        path=self.database_path();generation=self.service.generation
        self.start(lambda client,stop,progress:inspect_database(path,stop),
                   lambda result:self.put(self.data_box,result) if generation==self.service.generation else None,api=False)

    def backup_database(self):
        path=self.database_path()
        if not self.confirm('Create a private database backup?',
            'This copies original VRC Eye data, which may include personal history and notes. It is not a bug-report export. The active database will not be edited. Continue?'):return
        from tkinter import filedialog
        target=filedialog.asksaveasfilename(parent=self.app.root,title='New private database backup',defaultextension='.sqlite3',filetypes=[('SQLite backup','*.sqlite3')])
        if not target:return
        self.start(lambda client,stop,progress:backup_database(path,target,stop),lambda result:self.put(self.data_box,result),api=False)

    def build_integrations(self):
        pane=self.panes['Integrations']
        self.note(pane,'Inspect initialized OSC, peer, bridge, runtime and companion-ownership providers. These are observations only: no bridge listener starts, no controls are granted, and no second pipeline connection is created.')
        row=line(self,pane)
        button(self,row,'Refresh provider snapshots',lambda:self.put(self.integration_box,integrations(self.app,self.service)))
        row=line(self,pane)
        for title,route in (('OSC inspector','osc:Inspector'),('Peer diagnostics','peer:Developer'),('Runtime tools','unity')):
            button(self,row,title,lambda key=route:self.open_index(key))
        self.integration_box=self.text_box(pane,height=26)
        self.note(pane,'Use the existing creator SDK/helper workspaces for project contracts. This release does not add an arbitrary Unity executor, remote API relay, asset extractor or new SDK upload implementation.')

    def open_index(self,key):
        from ui_navigation import TOOL_BY_KEY
        if key not in TOOL_BY_KEY:
            if key=='unity':self.shell.show('Unity Player');return
            raise ValueError('This navigation destination is unavailable.')
        self.app.experience.open_tool(key)

    def build_reports(self):
        pane=self.panes['Reports']
        self.note(pane,'Generate a preview before export. Reports contain redacted event metadata and counters, with fresh per-bundle pseudonyms. They exclude raw databases, logs, response files, message bodies, notes, credentials and wellness data.')
        row=line(self,pane)
        button(self,row,'Generate report preview',self.preview_report)
        button(self,row,'Export reviewed report…',self.save_report)
        button(self,row,'Clear preview',self.clear_report)
        self.report_box=self.text_box(pane,height=28)

    def preview_report(self):
        self.preview_bundle=report_preview(self.service);self.put(self.report_box,self.preview_bundle)
        self.status.set('Report preview generated in memory. Review before exporting; no file was created.')

    def save_report(self):
        if self.preview_bundle is None:raise ValueError('Generate and review the report preview first.')
        from tkinter import filedialog
        path=filedialog.asksaveasfilename(parent=self.app.root,title='New sanitized developer report',defaultextension='.zip',filetypes=[('ZIP report','*.zip')])
        if not path:return
        export_report(path,self.preview_bundle);self.status.set('The reviewed sanitized bundle was exported. Review it again before sharing.')

    def clear_report(self):
        self.preview_bundle=None;self.put(self.report_box,{})

    def tick(self):
        super().tick()
        if self.closed:return
        if self.shell.current!='Developer' or time.monotonic()-self.last_refresh<1:return
        self.last_refresh=time.monotonic();self.refresh_header()
        selected=self.tabs.select()
        if selected==str(self.frames['Client Bridge Lab']):self.bridge_lab_panel.tick()
        if selected==str(self.frames['Overview']):self.refresh_overview()
        elif selected==str(self.frames['Traffic']) and self.service.recorder.stats()['sequence']!=self.last_sequence:
            self.refresh_traffic()

    def account_changed(self):
        self.service.account_changed();self.prepared_action=None;self.response=None;self.preview_bundle=None
        if hasattr(self,'bridge_lab_panel'):self.bridge_lab_panel.clear()
        if hasattr(self,'response_box'):
            for box in (self.response_box,self.review_box,self.state_box,self.trace_box,self.report_box,self.data_box,self.integration_box):
                self.put(box,{'state':'Account context changed; prior presentation cleared.'})
            self.refresh_traffic();self.refresh_header()

    def close(self):
        if hasattr(self,'bridge_lab_panel'):self.bridge_lab_panel.close()
        self.prepared_action=None;self.preview_bundle=None;return super().close()


class DeveloperNetworkPanel:
    """Single configuration home for API application identity, not another auth store."""
    def __init__(self,page,parent):
        self.page,self.app,self.parent=page,page.app,parent
        self.service=getattr(page.shell,'developer',None)
        page.heading(parent,'Developer API identity & request policy')
        if self.service is None:
            page.note(parent,'The application-owned developer service is unavailable in this embedding. Networking remains usable; no second API client is created.')
            return
        page.note(parent,'Live developer requests use the existing account session, fixed VRChat API host, redirect rejection, shared cache and shared 60-second local metadata interval. This interval is VRC Eye’s policy, not a promised server quota. HTTP 429 cooldowns may extend it.')
        self.contact=page.field(parent,'Application contact',self.service.contact,width=54)
        page.note(parent,'Enter the real contact email or HTTPS project URL for your application’s User-Agent. No example contact is installed. This is not a username, password, authentication token or credential field.')
        row=line(page,parent)
        button(page,row,'Save API identity',self.save)
        button(page,row,'Open Developer workbench',lambda:page.shell.show('Developer'))
        page.note(parent,'VRChat’s web API is community-documented and unsupported for public use. These adapters are live-unverified. The inherited sign-in flow still needs a separate public-distribution review; a local encrypted credential store or User-Agent would not by itself establish compliance.')
        page.note(parent,'No developer entitlement key is required. No proxy host, secret viewer, credential import, remote account executor, automated login, background API polling or write retries are added.')

    def save(self):
        if self.service is None: raise ValueError('The application-owned developer service is unavailable.')
        value=self.service.configure_contact(self.contact.get())
        if self.app.demo or getattr(self.app,'safe_mode',False):
            self.page.status.set('Application identity updated for this session only. Live requests remain disabled in Demo/Safe Mode.')
        else:
            self.page.shell.store.set_option(CONTACT_KEY,value)
            self.page.status.set('Application identity saved. Previous live-write approvals were invalidated; no request was sent.')
