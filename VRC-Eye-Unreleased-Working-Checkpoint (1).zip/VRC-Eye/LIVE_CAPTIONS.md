# Live captions

This unreleased source checkpoint adds offline live captions at **Accessibility → Live captions**. The header's **Live captions** button opens these controls; while capture is active it becomes **Stop live captions**.

## Start

1. Launch VRC Eye with its normal launcher to prepare the speech dependencies. **Open setup health** reports whether Vosk and SoundCard are available.
2. Download a speech model for the spoken language from the [official Vosk model list](https://alphacephei.com/vosk/models). Extract it and choose the extracted model folder in caption settings. The app does not download models automatically.
3. Choose **Discover caption audio sources**, then select a named source:
   - **Input**: a microphone or virtual input endpoint. To share a running mixer, select the same endpoint assigned to its microphone channel.
   - **Desktop**: an output endpoint exposed by the system as loopback capture. This includes all audio on that endpoint, including music, other apps and any monitor audio. Endpoint availability depends on the audio backend and operating system.
4. Press **Start captions**. Local model loading can take time; Stop works during loading. The status reports loading, capture, stopping and errors.
5. Optionally choose **Detach caption window**. Resize or move it like a normal desktop window. Closing this window stops capture. It is a desktop window, not a SteamVR or in-headset overlay.

Nothing starts automatically at launch, on account changes or after a device error. Discovery lists endpoints without starting a recording. Sources are session-only and must be selected again after privacy or account changes. No default-device or fuzzy-name fallback is used.

## Readability and controls

- Caption font size: 12–48 points, with the existing app-wide text scale applied on top, up to 500%. Existing Ctrl+0 text-size recovery remains available.
- Visible caption lines: 1–8; wrapped text follows the newest captions.
- Colors: app theme, white on black, black on white or yellow on black.
- Optional always-on-top window, provisional speech and elapsed timestamps.
- Retained finalized captions: 10–200 in memory. The panel reports how many older captions have rolled out.
- Apply, Undo and Reset use the existing settings store. Demo/Safe settings are session-only.
- Caption controls are keyboard focusable, participate in the existing accessibility framework and have five optional mappings in the hotkey editor: settings, Start, Stop, detached window, and Stop/clear. They have no default chords. The app now has 156 mappable actions across the existing 121 tool destinations and local commands.

Live text is not automatically spoken by VRC Eye's reader, avoiding an audio feedback cycle. Assistive technology behavior still needs native acceptance testing.

## Capture, privacy and export

Recognition runs in a separate local worker process using the selected Vosk model. The caption path has no cloud speech service, audio upload, automatic audio recording, transcript database, chatbox forwarding or peer broadcast.

**Stop** discards provisional speech and leaves finalized captions available in memory. **Clear transcript** stops capture and clears the transcript, including queued speech. Starting a new session clears the previous transcript. Privacy changes, account changes, Demo/Safe Mode and app shutdown stop capture and clear caption content. Exports are blocked in those modes and recheck the account and transcript after the destination dialog closes.

**Export transcript TXT** and **Export subtitles SRT** explicitly save only retained finalized captions. They never include provisional text or audio and refuse to overwrite an existing file. Choose a new filename. SRT timings are approximate elapsed recognition times, not word-aligned media timings. Captions that have rolled out of the bounded history cannot be exported.

Input captions share the existing private microphone tap. Stop voice transcription in Session Tools before using input captions, and vice versa. Attaching captions to an already running mixer does not stop that mixer when captions stop. Caption-owned microphone capture opens no output route. Loopback capture uses its own selected endpoint in the worker. An overflowing audio/display queue stops the session instead of accumulating an unbounded backlog.

## Limits and troubleshooting

The selected model determines the recognized language. This feature does not translate speech, identify speakers, attach player names or isolate individual VRChat users. Accuracy depends on the model, speech and input mix. Overlapping voices, music and noise may produce omissions or incorrect words.

If an endpoint disappears, discover and select it again. If a shared mixer changes or stops, captions stop. An incompatible/missing model, unavailable speech package, backend or device is reported in the status. Restart through the normal launcher for missing Python packages; system audio services and device permissions are supplied by the operating system. SoundCard loopback support and behavior vary by platform; a named virtual input is another supported source.

The worker can be terminated during model loading or blocked loopback recording without blocking the Tk UI. Failure to confirm worker release is reported and prevents starting another capture until release succeeds. The existing audio-engine release controls continue to govern shared input devices.

## Verification scope

Portable tests cover settings validation, PCM conversion, bounded transcripts, final/partial results, TXT/SRT output, exact endpoint selection, mixer ownership, model-load cancellation, subprocess transport, forced shutdown, queue overflow, privacy/account clearing, export races and hotkey dispatch. These use deterministic speech/audio fixtures; they do not establish recognition accuracy with a real acoustic model.

Six native Tk acceptance cases cover the caption tab, detached window, 500% scaling, export protection, privacy and hotkeys. They are supplied but unexecuted in this environment. Windows/Linux graphical operation, actual Vosk inference, physical microphone/loopback permissions, endpoint routing, latency and assistive-device interoperability remain acceptance tasks. See `LIVE_CAPTIONS_QUALIFICATION.json` for exact regression results and exclusions.

Build identity remains **2026.05.10.02.47.1**, compatibility **1.21.0**. This checkpoint contains source; no executable, installer or numbered release was created. Existing ARC/VRCX end-to-end qualification counts are unchanged. Captions do not close the separate durable voice-notes backlog item.
