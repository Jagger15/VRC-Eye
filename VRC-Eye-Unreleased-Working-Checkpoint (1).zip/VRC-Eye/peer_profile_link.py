"""Profile-window navigation into the app-owned VRC Eye peer service."""
from player_platforms import parse_user_id


def open_peer_player(app, user_id, alias=""):
    """Import lazily so opening a local profile never initializes networking."""
    from peer_player import open_peer_player as open_shared
    return open_shared(app, user_id, alias)


class PeerWhisperPane:
    """A profile shortcut; conversations and consent live in VRC Eye Primary."""

    def __init__(self, dialog, parent):
        self.dialog, self.app = dialog, dialog.app
        tk, ttk = self.app.tk, self.app.ttk
        self.status = tk.StringVar(value="Whispers use the shared VRC Eye connection and sharing permissions.")
        ttk.Label(parent, text="VRC Eye Whispers", style="Accent.TLabel").pack(anchor="w")
        ttk.Label(parent, text="Open VRC Eye Primary to select a paired device, review its association with this player, and send a whisper.\n"
                  "A local player association is your own label; it does not verify the peer's VRChat identity.\n"
                  "Local drafts remain available in Private Mode. Sending requires an explicit connection and permission.",
                  wraplength=910, style="Muted.TLabel").pack(anchor="w", pady=6)
        self.open_button = ttk.Button(parent, text="Open VRC Eye Whispers…", command=self.open)
        self.open_button.pack(anchor="w", pady=6)
        ttk.Label(parent, textvariable=self.status, wraplength=910, style="Muted.TLabel").pack(anchor="w", pady=6)
        self.tick()

    def allowed(self):
        players = getattr(self.app, "player_sessions", None)
        if self.dialog.closed or self.app.demo or (players and players.settings.get("presentation")):
            return False
        try:
            parse_user_id(self.dialog.user_id)
        except ValueError:
            return False
        return True

    def open(self):
        if not self.allowed():
            self.status.set("Select a player with an exact account ID outside Demo and presentation mode.")
            return
        try:
            open_peer_player(self.app, self.dialog.user_id, self.dialog.row.name)
            self.status.set("Opened the local device association. Pair in Networking; consent and messages are in VRC Eye Primary.")
        except (ValueError, RuntimeError) as error:
            self.status.set(str(error))

    def tick(self):
        self.open_button.configure(state="normal" if self.allowed() else "disabled")

    def close(self):
        # The sidebar owns connection lifetime, including across API account changes.
        pass
