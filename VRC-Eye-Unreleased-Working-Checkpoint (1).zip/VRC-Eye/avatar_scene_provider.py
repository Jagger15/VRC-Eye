"""Explicit GLB loads through the bundled, cancellable parser subprocess.

Linux workers install a fail-closed seccomp policy before reading model bytes.
Other platforms currently provide fault separation and resource budgets only.
The source snapshot is read and verified by the parent; the parser receives
bytes, never a source path or app credentials. No external resources are read.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from avatar_library_files import checked_stream,check_cancel
from avatar_scene import Scene,SceneNode,ScenePart,MAX_BYTES,MAX_OUTPUT,MAX_NODES,MAX_VERTICES,MAX_TRIANGLES,integer,vector,bounds
from avatar_scene_process import exchange,close as close_process

TIMEOUT=30.


def decode(data,source,*,stop=None,required_containment=None):
    if len(data)>MAX_OUTPUT:raise ValueError('The scene provider exceeded its result budget.')
    try:
        result=json.loads(data)
        if not isinstance(result,dict) or type(result.get('protocol')) is not int or result['protocol']!=1:
            raise ValueError('Unsupported scene provider protocol.')
        if 'error' in result:
            error=result['error']
            if not isinstance(error,str) or len(error)>300:raise ValueError('Invalid scene provider diagnostic.')
            raise ValueError(error)
        if required_containment is not None and result.get('containment')!=required_containment:
            raise ValueError('The scene worker did not establish the required kernel containment. No preview was accepted.')
        raw=result['scene']
        fields={'nodes','parts','bounds','sha256','source_bytes','notices','materials','textures','skins'}
        if not isinstance(raw,dict) or not fields<=set(raw) or set(raw)-fields-{'import_report','animations'}:
            raise ValueError('Invalid scene provider result.')
        if raw['sha256']!=sha256(source).hexdigest() or raw['source_bytes']!=len(source):
            raise ValueError('Scene provider result does not match the selected bytes.')
        if not isinstance(raw['nodes'],list) or not 1<=len(raw['nodes'])<=MAX_NODES or not isinstance(raw['parts'],list) or not 1<=len(raw['parts'])<=512:
            raise ValueError('Scene provider exceeded its node or mesh budget.')
        nodes=[];known=set()
        for item in raw['nodes']:
            i=integer(item['index'],0,MAX_NODES-1);parent=integer(item['parent'],-1,MAX_NODES-1);label=item['name']
            if i in known or parent!=-1 and parent not in known or not isinstance(label,str) or not 1<=len(label)<=120 or not label.isprintable():
                raise ValueError('Invalid scene provider hierarchy.')
            from avatar_scene_deform import affine
            nodes.append(SceneNode(i,parent,label,affine(item['matrix'])));known.add(i)
        from avatar_scene_deform import decode_skin,decode_part,positions,MAX_SKINS
        if not isinstance(raw['skins'],list) or len(raw['skins'])>MAX_SKINS:raise ValueError('Invalid skin result budget.')
        skins=tuple(decode_skin(row,{n.index:n.parent for n in nodes}) for row in raw['skins'])
        if sum(len(s.joints) for s in skins)>2048:raise ValueError('Too many joint references in provider result.')
        morph_budget=[0];world={n.index:n.matrix for n in nodes};morph_nodes={}
        from avatar_scene_appearance import decode as appearance
        materials,textures=appearance(raw['materials'],raw['textures'])
        parts=[];vertices=0;triangles=0;deadline=time.monotonic()+10
        for item in raw['parts']:
            check_cancel(stop)
            node=integer(item['node'],0,MAX_NODES-1)
            if node not in known or not isinstance(item['vertices'],list) or not isinstance(item['triangles'],list):raise ValueError('Invalid scene mesh owner.')
            vertices+=len(item['vertices']);triangles+=len(item['triangles'])
            if vertices>MAX_VERTICES or triangles>MAX_TRIANGLES or not item['vertices'] or not item['triangles']:raise ValueError('Scene provider exceeded its geometry budget.')
            points=tuple(vector(v,3) for v in item['vertices']);faces=[]
            for face in item['triangles']:
                if not isinstance(face,list) or len(face)!=3:raise ValueError('Invalid scene triangle.')
                tri=tuple(integer(v,0,len(points)-1) for v in face)
                if len(set(tri))!=3:raise ValueError('Invalid scene triangle.')
                faces.append(tri)
            uv=item['uvs']
            if not isinstance(uv,list) or len(uv) not in (0,len(points)):raise ValueError('Invalid scene UV count.')
            material=integer(item['material'],-1,len(materials)-1)
            color=item['colors']
            if not isinstance(color,list) or len(color) not in (0,len(points)):raise ValueError('Invalid vertex color count.')
            from avatar_scene_appearance import factor
            from avatar_mesh_health import decode as health_result
            colors=tuple(tuple(factor(v) for v in vector(row,4)) for row in color)
            health=health_result(item['health'])
            rig=decode_part(item['rig'],len(points),skins,morph_budget)
            if rig:
                actual_points=positions(rig,skins,world,stop=stop,deadline=deadline)
                if any(abs(a-b)>1e-7*max(1,abs(a),abs(b)) for p,q in zip(points,actual_points) for a,b in zip(p,q)):
                    raise ValueError('Provider skin/morph positions do not match the declared geometry.')
                previous=morph_nodes.setdefault(node,(rig.morph_names,rig.morph_weights))
                if previous!=(rig.morph_names,rig.morph_weights):raise ValueError('Provider morph defaults disagree across a mesh node.')
            parts.append(ScenePart(node,points,tuple(faces),tuple(vector(v,2) for v in uv),material,colors,health,rig))
        actual=bounds(tuple(v for p in parts for v in p.vertices))
        if tuple(vector(v,3) for v in raw['bounds'])!=actual:raise ValueError('Scene provider bounds do not match geometry.')
        notices=raw['notices']
        if not isinstance(notices,list) or len(notices)>8 or any(not isinstance(v,str) or len(v)>300 for v in notices):raise ValueError('Invalid scene coverage notes.')
        from avatar_fbx_report import decode as import_report
        report=import_report(raw.get('import_report'))
        scene=Scene(tuple(nodes),tuple(parts),actual,raw['sha256'],raw['source_bytes'],tuple(notices),materials,textures,skins,report)
        from avatar_animation import decode as animation
        from dataclasses import replace
        return replace(scene,animations=animation(raw.get('animations'),scene))
    except (KeyError,TypeError,IndexError,UnicodeError,json.JSONDecodeError,RecursionError):
        raise ValueError('Invalid scene provider response.') from None


def load(path,*,stop=None,progress=None,bundle=False,fbx=False,textures=(),take_request=None,expected_scene=None):
    check_cancel(stop)
    if bundle and fbx:raise ValueError('Choose one scene import format.')
    if take_request is not None:
        from avatar_animation_fbx import request
        take_request=request(take_request)
        if not fbx or expected_scene is None or expected_scene.import_report is None:raise ValueError('Import the FBX before preparing a take.')
    if fbx and not sys.platform.startswith('linux'):
        raise ValueError('FBX preview requires Linux kernel containment. Windows FBX import is not enabled yet.')
    if bundle and not sys.platform.startswith('linux'):
        raise ValueError('Unity bundle preview requires Linux kernel containment. Windows bundle decoding is not enabled yet; inspect/copy/manual recovery remain available.')
    if not bundle and Path(path).suffix.lower()!=('.fbx' if fbx else '.glb'):raise ValueError('Choose an FBX file.' if fbx else 'Choose a static GLB 2.0 scene.')
    if textures and not fbx:raise ValueError('Explicit external textures are supported only for FBX.')
    with checked_stream(path,limit=MAX_BYTES) as (_,stream,before):
        blocks=[];total=0
        while True:
            check_cancel(stop);block=stream.read(1024**2)
            if not block:break
            total+=len(block)
            if total>MAX_BYTES:raise ValueError('Scene source exceeds 32 MiB.')
            blocks.append(block)
            if progress:progress(total,before.st_size)
        if total!=before.st_size:raise ValueError('Scene source changed during reading.')
    source=b''.join(blocks);check_cancel(stop)
    if expected_scene is not None and sha256(source).hexdigest()!=expected_scene.sha256:raise ValueError('The source changed since import. Import and review it again before preparing a take.')
    selected={};payload=source
    if fbx:
        from avatar_fbx_input import stage,pack
        selected=stage(textures,stop);payload=pack(source,selected)
        if expected_scene is not None:
            evidence={(n,size,digest) for n,state,size,digest,used in expected_scene.import_report.dependencies if state in ('selected','unused')}
            if evidence!={(n,len(b),sha256(b).hexdigest()) for n,b in selected.items()}:raise ValueError('The selected textures changed since import. Import and review them again.')
    worker=Path(__file__).with_name('avatar_scene_worker.py').resolve()
    env={k:v for k,v in os.environ.items() if k in ('SystemRoot','WINDIR','TEMP','TMP','LANG','LC_ALL')}
    mode=['--fbx-take',json.dumps(take_request,separators=(',',':'),allow_nan=False)] if take_request is not None else ['--bundle'] if bundle else ['--fbx'] if fbx else []
    process=subprocess.Popen([sys.executable,'-I','-B',str(worker)]+mode,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,cwd=str(worker.parent),env=env,close_fds=True,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0,bufsize=0)
    try:
        output=exchange(process,payload,limit=MAX_OUTPUT,timeout=TIMEOUT,stop=stop,kernel_memory_limit=os.name=='posix')
        check_cancel(stop)
        if process.returncode!=0:raise ValueError('The scene parser stopped unexpectedly. No preview was accepted.')
        from avatar_scene_sandbox import POLICY
        scene=decode(output,source,stop=stop,required_containment=POLICY if sys.platform.startswith('linux') else None)
        if fbx:
            if scene.import_report is None:raise ValueError('FBX provider omitted its inspection report.')
            evidence=[(n,size,digest) for n,state,size,digest,used in scene.import_report.dependencies if state in ('selected','unused')]
            expected=sorted((n,len(b),sha256(b).hexdigest()) for n,b in selected.items())
            if sorted(set(evidence))!=expected:raise ValueError('FBX dependency report does not match the selected texture bytes.')
        return scene
    finally:
        close_process(process)


def load_bundle(path,*,authorized=False,stop=None,progress=None):
    if authorized is not True:raise ValueError('Confirm ownership or permission before decoding the selected bundle.')
    return load(path,stop=stop,progress=progress,bundle=True)


def load_fbx(path,*,authorized=False,textures=(),stop=None,progress=None):
    if authorized is not True:raise ValueError('Confirm ownership or permission before importing the selected FBX and textures.')
    return load(path,stop=stop,progress=progress,fbx=True,textures=textures)


def load_fbx_take(path,scene,*,authorized=False,textures=(),take,start,end,rate,stop=None,progress=None):
    if authorized is not True:raise ValueError('Import an authorized FBX before preparing a take.')
    result=load(path,fbx=True,textures=textures,stop=stop,progress=progress,expected_scene=scene,take_request=dict(take=take,start=start,end=end,rate=rate))
    from dataclasses import replace
    if replace(result,animations=scene.animations)!=scene:raise ValueError('Prepared take does not match the imported scene snapshot. Import the source again.')
    if result.animations is None or len(result.animations.clips)!=1:raise ValueError('FBX provider omitted the prepared take.')
    clip=result.animations.clips[0]
    if (clip.start,clip.end)!=(float(start),float(end)) or clip.reason or not clip.frames:raise ValueError('FBX provider returned a different take range.')
    import math
    steps=math.ceil((end-start)*rate)
    times=tuple(end if i==steps else start+i/rate for i in range(steps+1))
    if clip.name!=scene.import_report.takes[take][0] or tuple(f.time for f in clip.frames)!=times:raise ValueError('FBX provider returned different take samples.')
    return result
