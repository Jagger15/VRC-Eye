"""Bounded profile snapshots and presentation, with explicit unknown values."""
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import re
from urllib.parse import urlsplit

from avatar_links import parse_avatar_reference
from player_platforms import parse_user_id
from player_trust import trust_from_tags

UNKNOWN = "Unavailable / not supplied"
MAX_PROFILE = 2 * 1024 * 1024
STATUSES = {"Online": "active", "Join me": "join me", "Ask me": "ask me", "Busy": "busy", "Offline": "offline"}
# Deliberately omit authToken, friendKey, email, birthday, login credentials and account recovery fields.
FIELDS = set("""id displayName name description bio bioLinks pronouns status statusDescription state
ageVerified ageVerificationStatus date_joined tags trustTags isFriend isBoopingEnabled
hasSharedConnectionsOptOut hasDiscordFriendsOptOut allowWorldsToCountFriendsInInstance allowAvatarCopying
discordId discordDetails global_name currentAvatar currentAvatarName currentAvatarAuthorName
currentAvatarImageUrl currentAvatarThumbnailImageUrl profilePicOverride profilePicOverrideThumbnail
userIcon iconUrl iconType bannerUrl bannerCustomUrl bannerType bannerColor badges badgeId badgeName
badgeDescription badgeImageUrl assignedAt updatedAt hidden showcased isQuantifiable groups count list
groupId representedGroup isRepresenting memberVisibility privacy shortCode discriminator memberCount
worldFavoriteLists publicWorlds totalPublicWorldsCount ownerId ownerDisplayName type visibility
favoriteId favorites avatar world authorId authorName releaseStatus thumbnailImageUrl imageUrl
created_at updated_at last_activity last_login last_mobile last_platform platform location worldId
instanceId activity pastDisplayNames reverted balance noTransactions""".split())

# Observed public appearance fields shared with the native profile editor.
FIELDS.update('backgroundType backgroundTextureId backgroundGradientBottom backgroundGradientTop backgroundTemplateId themeId themeButtonColor themeIconColor themeSubtextColor iconFrame nameplateEffect profileEffect languages'.split())


def clean(value, depth=0):
    if depth > 8:
        raise ValueError("Profile data is too deeply nested.")
    if isinstance(value, dict):
        if len(value) > 500:
            raise ValueError("Profile contains too many fields.")
        return {k: clean(v, depth + 1) for k, v in value.items() if k in FIELDS}
    if isinstance(value, list):
        if len(value) > 2000:
            raise ValueError("Profile contains too many records.")
        return [clean(v, depth + 1) for v in value]
    if isinstance(value, str):
        if len(value) > 20000:
            raise ValueError("A profile field is too large.")
        # Join nonces are bearer-like invitation data and are not needed by this viewer.
        return re.sub(r"~nonce\([^)]*\)", "~nonce(REDACTED)", value)
    if value is None or type(value) in (bool, int):
        return value
    return None


@dataclass(frozen=True)
class ProfileSection:
    user_id: str
    section: str
    checked_at: str
    data: object
    offset: int = 0
    more: bool = False


def section_snapshot(document, reference, section, checked, *, offset=0, more=False, identity=True):
    reference = parse_user_id(reference)
    if identity and (not isinstance(document, dict) or parse_user_id(document.get("id")) != reference):
        raise ValueError("The profile ID does not match the selected player.")
    return ProfileSection(reference, section, checked, clean(document), offset, more)


def read_profile_json(text, reference):
    if len(text.encode("utf-8")) > MAX_PROFILE:
        raise ValueError("Profile JSON exceeds 2 MiB.")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON fields are not accepted.")
            result[key] = value
        return result
    try:
        data = json.loads(text, object_pairs_hook=pairs)
    except (json.JSONDecodeError, RecursionError):
        raise ValueError("Choose a supported user/profile JSON object.") from None
    if isinstance(data, dict) and data.get("filtered") is True:
        if parse_user_id(data.get("userId")) != parse_user_id(reference) or not isinstance(data.get("sections"), list) or len(data["sections"]) > 100:
            raise ValueError("This exported snapshot does not match the selected player.")
        profiles = {}
        for index, entry in enumerate(data["sections"]):
            if not isinstance(entry, dict): raise ValueError("Invalid exported profile section.")
            if entry.get("source") not in ("public", "account", "activity", "import"): continue
            checked = entry.get("checked_at")
            if not isinstance(checked, str) or len(checked) > 64: raise ValueError("Invalid snapshot timestamp.")
            profiles[index] = section_snapshot(entry.get("data"), reference, entry["source"], checked)
        if not profiles: raise ValueError("The export has no user/profile snapshots to import.")
        data = merged_profile(profiles)
    return section_snapshot(data, reference, "import", datetime.now(timezone.utc).isoformat(timespec="seconds"))


def merged_profile(sections):
    # Sources are applied in check-time order so newer snapshots replace older values.
    result = {}
    for snapshot in sorted(sections.values(), key=lambda s: s.checked_at):
        if snapshot.section in ("public", "account", "activity", "import") and isinstance(snapshot.data, dict):
            result.update(snapshot.data)
            if "trustTags" not in snapshot.data and "tags" in snapshot.data:
                result["trustTags"] = snapshot.data["tags"]
            activity = snapshot.data.get("activity")
            if isinstance(activity, dict):
                result.update(activity)
    return result


def scalar(data, key, default=UNKNOWN):
    value = data.get(key)
    if isinstance(value, str):
        return value if value else "Not set / not shared"
    if type(value) is bool:
        return "Yes" if value else "No"
    if type(value) is int:
        return str(value)
    return default


def age_label(data):
    value = data.get("ageVerified")
    if value is True:
        category = data.get("ageVerificationStatus")
        return "Verified" + (f" ({category})" if isinstance(category, str) and category else "")
    if value is False:
        return "Not shown as verified (does not establish age)"
    return UNKNOWN


def privacy_label(data):
    location = data.get("location")
    if location == "private":
        return "Location withheld / private"
    if location == "offline":
        return "Offline location response"
    if location == "traveling":
        return "Traveling; destination visibility not established"
    if isinstance(location, str) and location.startswith("wrld_"):
        # Classification is confined to an API-visible location, never a inferred hidden location.
        if "~private(" in location: return "Visible invite instance"
        if "~friends(" in location: return "Visible friends instance"
        if "~hidden(" in location: return "Visible friends-plus instance"
        if "~group(" in location: return "Visible group instance; access rules may vary"
        return "Location visible to this account; instance access not verified"
    return "Location privacy unavailable"


def summary_text(data, *, local_name="", platform="Unknown"):
    trust, note = trust_from_tags(data.get("trustTags", data.get("tags")))
    status = next((label for label, raw in STATUSES.items() if raw == data.get("status")), scalar(data, "status"))
    discord = data.get("discordDetails")
    discord_name = discord.get("global_name") if isinstance(discord, dict) else None
    discord_id = data.get("discordId") or (discord.get("id") if isinstance(discord, dict) else None)
    group = data.get("representedGroup")
    group_text = scalar(group, "name") if isinstance(group, dict) else "None reported" if "representedGroup" in data else UNKNOWN
    lines = [("Display name", scalar(data, "displayName", local_name or UNKNOWN)),
        ("Status / joinability", status), ("Status text", scalar(data, "statusDescription")),
        ("Privacy / location visibility", privacy_label(data)), ("Age verification", age_label(data)),
        ("Game join date", scalar(data, "date_joined")), ("Pronouns", scalar(data, "pronouns")),
        ("Trust rank (snapshot)", trust), ("Platform (snapshot)", platform),
        ("Booping enabled", scalar(data, "isBoopingEnabled")), ("Friend", scalar(data, "isFriend")),
        ("Discord connection", " · ".join(str(v) for v in (discord_name, discord_id) if v) or UNKNOWN),
        ("Current avatar", scalar(data, "currentAvatarName", scalar(data, "currentAvatar"))),
        ("Represented group", group_text),
        ("Lifetime playtime", "Unavailable from supported VRChat profile data"),
        ("Credits", "Load on Account tab; own signed-in account only")]
    return "\n".join(f"{key}: {value}" for key, value in lines) + ("\nTrust note: " + note if note else "") + "\n\nBio\n" + scalar(data, "bio")


def safe_link(value):
    if not isinstance(value, str) or len(value) > 4096 or any(ord(c) <= 32 or ord(c) == 127 for c in value) or "\\" in value:
        return ""
    try:
        url = urlsplit(value)
        if url.scheme not in ("https", "http") or not url.hostname or url.username or url.password:
            return ""
        if url.port is not None and not 1 <= url.port <= 65535:
            return ""
    except ValueError:
        return ""
    return value


def profile_links(data, reference):
    links = [("VRChat profile", f"https://vrchat.com/home/user/{parse_user_id(reference)}")]
    supplied = data.get("bioLinks")
    values = supplied if isinstance(supplied, list) else []
    bio = data.get("bio")
    if isinstance(bio, str):
        values = values + [v.rstrip(".,;!?)\"]}") for v in re.findall(r"https?://[^\s<>]+", bio)]
    for value in values:
        if safe_link(value) and not any(link == value for _, link in links):
            links.append(("Bio link", value))
    for title, fields in (("Profile picture", ("iconUrl", "profilePicOverride", "userIcon", "currentAvatarThumbnailImageUrl", "currentAvatarImageUrl")),
                          ("Banner", ("bannerUrl", "bannerCustomUrl")),
                          ("Current avatar image", ("currentAvatarThumbnailImageUrl", "currentAvatarImageUrl"))):
        value = next((data.get(k) for k in fields if safe_link(data.get(k))), "")
        if value:
            links.append((title, value))
    try:
        avatar = parse_avatar_reference(data.get("currentAvatar", ""))
        links.append(("Current avatar page", "https://vrchat.com/home/avatar/" + avatar))
    except ValueError:
        pass
    return links[:100]


def self_patch(values):
    allowed = {"status", "statusDescription", "pronouns", "isBoopingEnabled", "hasSharedConnectionsOptOut", "hasDiscordFriendsOptOut"}
    if not isinstance(values, dict) or not values or set(values) - allowed:
        raise ValueError("Unsupported account edit.")
    result = {}
    for key, value in values.items():
        if key == "status":
            if value not in STATUSES.values(): raise ValueError("Choose a supported status.")
        elif key in ("statusDescription", "pronouns"):
            maximum = 32 if key == "pronouns" else 32
            if not isinstance(value, str) or len(value) > maximum or any(ord(c) < 32 for c in value):
                raise ValueError(f"{key} must be a single line of at most {maximum} characters.")
        elif type(value) is not bool:
            raise ValueError("Privacy and boop preferences must be boolean.")
        result[key] = value
    return result


def avatar_patch(values):
    allowed = {"name", "description", "releaseStatus", "tags"}
    if not isinstance(values, dict) or not values or set(values) - allowed:
        raise ValueError("Only avatar name, description, public/private status and tags are editable here.")
    result = {}
    for key, value in values.items():
        if key == "releaseStatus":
            if value not in ("public", "private"): raise ValueError("Choose public or private.")
        elif key == "tags":
            if (not isinstance(value, list) or len(value) > 50 or any(not isinstance(v, str) or
                    not re.fullmatch(r"[a-zA-Z0-9_ -]{1,100}", v) for v in value)):
                raise ValueError("Supply at most 50 supported avatar tags.")
        elif (not isinstance(value, str) or (key == "name" and not value.strip()) or
              len(value) > (100 if key == "name" else 5000)):
            raise ValueError("Avatar name is empty or name/description exceeds the editor limit (100 / 5000 characters).")
        result[key] = value
    return result
