"""Selected Avatar Creator peer cards and optional read-only SteamVR cards.

No source assets, manifests, raw parameter traffic, device IDs or notes are
automatically transmitted. This adapter never starts a networking connection.
"""
from __future__ import annotations

from copy import deepcopy
import json
import re
import time
import uuid

from creator_integrations import (CreatorPeerCoordinator, CreatorOverlayPresenter,
                                  _text, _scalar, _identifier, _json, _digest,
                                  _selected_steps, overlay_payload)
from peer_protocol import validate_payload


SCHEMA = 'vrc-eye-avatar-creator-1'
SHARE_FIELDS = {
    'test_run': ('status', 'outcome', 'platform', 'environment', 'summary', 'steps'),
    'run': ('status', 'outcome', 'platform', 'environment', 'summary', 'steps'),
    'checklist': ('steps',),
    'feedback': ('happened', 'expected', 'doing', 'repeated', 'step_id'),
    'issue': ('observed', 'expected', 'repro', 'status', 'platform'),
    'observation': ('source', 'scope', 'value', 'unit', 'quality', 'label'),
    'bookmark': ('label', 'note', 'step_id'),
    'validation': ('severity', 'code', 'summary', 'platform'),
}


class AvatarPeerCoordinator(CreatorPeerCoordinator):
    """Existing peer transport, distinct Avatar Creator document schema."""
    def available_fields(self, record):
        return tuple(field for field in SHARE_FIELDS.get(record.get('kind'), ())
                     if field in record.get('data', {}))

    def preview(self, record, *, avatar_id, build_id='', run_id='', fields=(), context_token='', peer_ids=()):
        _identifier(avatar_id)
        _identifier(build_id, optional=True)
        _identifier(run_id, optional=True)
        if not isinstance(record, dict) or not isinstance(record.get('data'), dict):
            raise ValueError('Select a saved Avatar Creator result.')
        if record.get('avatar_id') != avatar_id:
            raise ValueError('The record belongs to a different avatar workspace.')
        kind = record.get('kind')
        if kind not in SHARE_FIELDS:
            raise ValueError('This record stays local. Select a test result, checklist or observation.')
        data = record['data']
        if kind in ('run', 'test_run') and run_id != record.get('id'):
            raise ValueError('Keep the original test-run identifier.')
        for key, expected in (('build_id', build_id), ('run_id', run_id)):
            if data.get(key) not in (None, '', expected):
                raise ValueError('The selected build or run does not match the record.')
        if not isinstance(fields, (list, tuple)) or any(field not in SHARE_FIELDS[kind] for field in fields):
            raise ValueError('Select only the listed shareable fields.')
        fields = list(dict.fromkeys(fields))
        metadata = dict(schema=SCHEMA, kind=kind, record_id=_identifier(record.get('id')),
                        avatar_id=avatar_id, build_id=build_id, run_id=run_id)
        metadata['selected'] = {field: _scalar(data[field]) for field in fields if field != 'steps' and field in data}
        title = _text(data.get('title', 'Avatar Creator ' + kind), 160)
        identifier = str(uuid.uuid4())
        if 'steps' in fields or kind == 'checklist':
            marker = dict(item_id='avatar-context', title='Avatar / build / run context (not a test)',
                          status='SKIPPED', description=_json(metadata))
            steps = _selected_steps(data.get('steps', [])) if 'steps' in fields else []
            payload = dict(checklist_id=identifier, revision=1, title=title, items=[marker, *steps])
            message_kind = 'checklist.snapshot'
        else:
            notes = _json(metadata)
            if len(notes) > 2048:
                raise ValueError('Selected content exceeds one peer card. Select fewer fields.')
            payload = dict(playtest_id=identifier, revision=1, title=title, phase='Avatar Creator',
                           target=avatar_id, notes=notes)
            message_kind = 'creator.snapshot'
        payload = validate_payload(message_kind, payload)
        snapshot = self.service.snapshot() if self.service is not None else {}
        sessions = {peer['peer_id']: peer.get('session', '') for peer in snapshot.get('peers', [])
                    if peer.get('state') == 'READY'}
        if peer_ids:
            if not isinstance(peer_ids, (list, tuple)) or not 1 <= len(peer_ids) <= 32 or any(peer not in sessions for peer in peer_ids):
                raise ValueError('Select connected peers in Networking before reviewing a send.')
            sessions = {peer: sessions[peer] for peer in dict.fromkeys(peer_ids)}
        review = dict(id=str(uuid.uuid4()), kind=message_kind, payload=payload, context=identifier,
                      avatar_id=avatar_id, build_id=build_id, run_id=run_id, fields=fields,
                      peer_ids=list(sessions), preview_text=json.dumps(payload, ensure_ascii=False, indent=2))
        self._reviews[review['id']] = dict(review=deepcopy(review), digest=_digest(review),
            token=deepcopy(context_token), deadline=self.clock() + 120, sessions=sessions)
        while len(self._reviews) > 20:
            self._reviews.popitem(last=False)
        return review

    def received(self, *, avatar_id, build_id='', run_id=''):
        """Read reviewed peer reports; they never pass a local assertion or act."""
        if self.service is None:
            return []
        result = []
        for message in self.service.snapshot().get('inbox', [])[-250:]:
            if message.get('direction') != 'incoming' or message.get('status') != 'ACCEPTED':
                continue
            kind = message.get('kind')
            if kind not in ('creator.snapshot', 'checklist.snapshot'):
                continue
            try:
                payload = validate_payload(kind, message.get('payload', {}))
                if kind == 'creator.snapshot':
                    metadata = json.loads(payload.get('notes', '{}'))
                else:
                    rows = payload['items']
                    if not rows or rows[0].get('item_id') != 'avatar-context':
                        continue
                    metadata = json.loads(rows[0]['description'])
                if not isinstance(metadata, dict) or metadata.get('schema') != SCHEMA:
                    continue
                if (metadata.get('avatar_id'), metadata.get('build_id'), metadata.get('run_id')) != (avatar_id, build_id, run_id):
                    continue
                record_kind = metadata.get('kind')
                selected = metadata.get('selected', {})
                if record_kind not in SHARE_FIELDS or not isinstance(selected, dict) or any(key not in SHARE_FIELDS[record_kind] or key == 'steps' for key in selected):
                    continue
                selected = {key: _scalar(value) for key, value in selected.items()}
                result.append(dict(message_id=message.get('message_id', message.get('id', '')),
                    peer_id=message.get('peer_id', ''), title=payload['title'], selected=selected,
                    checklist=deepcopy(payload.get('items', [])[1:]),
                    provenance='Reported by a peer; not independently verified. No local assertion changed.'))
            except (ValueError, TypeError, KeyError):
                continue
        return result


class AvatarOverlayController(CreatorOverlayPresenter):
    """Uses the existing native owner; application coordinates shared card slot."""
    def show(self, title, step='', status='', *, placement='right', size=.55, opacity=.9, seconds=30):
        title, step, status = _text(title, 180), _text(step, 300), _text(status, 300)
        text = 'Avatar Creator · read-only\n' + title
        if step:
            text += '\nStep: ' + step
        if status:
            text += '\n' + status
        text += '\nControls and tests remain available on the desktop.\nCapture visibility depends on your recording setup.'
        payload = overlay_payload(dict(enabled=True, text=text, placement=placement,
                                       size=size, opacity=opacity, seconds=seconds))
        snap = self.runtime.snapshot() if self.runtime is not None else {}
        available = snap.get('steamvr_available') is True and hasattr(self.runtime, 'display_creator')
        if available:
            self.runtime.display_creator(payload)
        self._deadline = self.clock() + seconds if available else 0.
        self._state = dict(enabled=available,
            status='Read-only card requested on the existing SteamVR connection.' if available else
                   'SteamVR is unavailable. Connect optional inputs in Wellness; desktop actions remain available.',
            text=text, placement=placement, size=size, opacity=opacity, reduced_motion=True, interactive=False)
        return self.snapshot()
