"""Setup and dependency view usable during Safe Startup without enabling services."""
import json
from companion_ui import Page,Table,button
from friendly_ui import ScrollPane,flow_line as line
from creator_projects_ui import text_area,set_text,review_document
from dashboard_actions import context
import desktop_health as health


def show(shell):
    from account_header import private
    if private(shell.app):raise ValueError('Reveal private information before opening setup observations.')
    old=getattr(shell,'setup_health_window',None)
    if old and not old.closed:old.window.lift();return old
    shell.setup_health_window=SetupHealth(shell);return shell.setup_health_window


class SetupHealth(Page):
    def __init__(self,shell):
        app=shell.app;self.window=app.tk.Toplevel(app.root);self.window.title('Setup health and dependencies')
        self.window.geometry('1000x720');self.window.minsize(640,480)
        self.scroll=ScrollPane(app,self.window,min_width=580)
        super().__init__(shell,self.scroll.body,'Setup health and dependencies')
        self.report=None;self.checked=None;self.view_context=None
        row=line(self);button(self,row,'Refresh checks',self.refresh);button(self,row,'Check local databases',self.check_databases)
        button(self,row,'Export reviewed report…',self.export)
        self.table=Table(self,self.parent,(('name','Feature / provider',280),('state','Availability',200),('detail','Explanation',400)),height=12)
        button(self,line(self),'Open selected workspace',self.open_selected)
        self.output=text_area(self,self.parent,height=8)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.refresh();self.timer=self.app.root.after(300,self.tick)

    def readable(self):
        from account_header import private
        if self.closed or private(self.app):raise ValueError('Reveal private information before opening setup observations.')

    def refresh(self):
        self.readable();self.cancel();health.available.cache_clear();self.view_context=context(self.app)
        self.report=health.snapshot(self.shell);self.checked=None
        self.table.set(self.report['rows'],lambda r:(r['name'],r['state'],r['detail']),identity=lambda r:r['id'])
        set_text(self.output,self.report['scope']);self.status.set('Checks read current owners. No service was started or permission enabled.')

    def check_databases(self):
        self.readable();token=context(self.app)
        def done(value):
            self.readable()
            if token!=context(self.app):raise ValueError('Context changed. Run the check again.')
            self.checked=value;set_text(self.output,json.dumps(value,indent=2))
        self.start(lambda c,s,p:health.integrity(self.shell,stop=s,progress=p),done,api=False)

    def open_selected(self):
        self.readable()
        if self.view_context!=context(self.app):raise ValueError('Context changed. Refresh checks first.')
        row=self.table.selected()
        if not row:raise ValueError('Select a feature first.')
        route=row['route']
        if route in self.shell.buttons:self.shell.show(route)
        else:self.status.set('Open '+route+' from its existing creator workspace.')

    def export(self):
        self.readable();token=context(self.app)
        if self.view_context!=token or self.report is None:raise ValueError('Refresh checks first.')
        value=dict(setup=self.report,databases=self.checked);text=json.dumps(value,indent=2,ensure_ascii=False)
        if not review_document(self.app,'Review setup report',text,'Choose destination'):return
        self.readable()
        if context(self.app)!=token:raise ValueError('Context changed; report not exported.')
        from tkinter import filedialog
        from pathlib import Path
        from photo_organize import publish
        path=filedialog.asksaveasfilename(parent=self.window,initialfile='VRC-Eye-Setup-Health.json',defaultextension='.json',confirmoverwrite=False)
        def guard():
            self.readable()
            if context(self.app)!=token:raise ValueError('Context changed; report not exported.')
        guard()
        if path:publish(Path(path),text.encode(),guard)

    def tick(self):
        if self.closed:return
        from account_header import private
        if private(self.app) or self.view_context!=context(self.app):
            self.cancel();self.table.set([],lambda r:());set_text(self.output,'Observations cleared. Refresh after revealing the workspace.');self.report=None;self.checked=None
        else:super().tick()
        self.timer=self.app.root.after(300,self.tick)

    def close(self):
        if self.closed:return
        if hasattr(self,'timer'):self.app.root.after_cancel(self.timer)
        super().close();self.window.destroy()
