# Development 8 — persistent automatic API sync

This checkpoint builds on the complete Development 7 source package. The existing
VRChat client and protected saved-session controller remain the authentication
owners. A single application-owned service now starts live observation after a
confirmed sign-in, including a successful saved-session restore. The Feed page
does not need to be opened first.

## Everyday use

- Automatic sync is enabled by default after sign-in. In **Feed**, clear
  **Automatic sync after sign-in**, or choose **Pause sync**, to disable it.
  This preference is remembered on this device. **Resume sync** enables it again.
- **Sync now** queues a catch-up. Repeated clicks combine with work already
  queued. Existing manual page and profile refresh controls remain available.
- The service runs while VRC Eye is open, including tray mode when the existing
  **background Feed** setting permits it. Closing the application stops it;
  this is not an operating-system daemon or a new startup registration.
- Feed, Social's **Inbox**, Home, and Accounts show shared sync status. Feed
  rows distinguish saved observations, live observations, snapshot age, and
  potentially stale data. Previously stored friend observations can display
  before the first network request. They do not establish current presence.
- Accounts shows current observed name/status information separately from its
  editable profile form. Live updates never replace an unsaved edit draft.

## Live events and catch-up

Friend online/website/offline, location, profile, addition and removal events use
the existing feed/history model. Own-account `user-update` events merge supported
presentation fields into the shared current-account view and account header.
Private locations are still limited to what the service returns.

The shared inbox now applies legacy read/hide/clear events, NotificationV2 partial
patches, and multi-ID deletions. Partial updates preserve other observed fields.
Deleted notifications remain suppressed from older snapshots. The view preserves
selection and scroll position as records change. Live observations and imported
history are not action authorization: an action on a live-only row fetches a
current API page before opening the existing one-use review. If that page does
not contain the notification, or its selection changes, no action is submitted.

Catch-up covers online and offline friend pages, both inbox families, and the
current account profile. Only one background snapshot worker runs at a time.
Pages rotate between datasets; a failed dataset does not prevent the others
from updating. Late results cannot cross client/session/account/privacy changes.
Per-record ordering prevents an older in-flight snapshot from undoing a newer
live friend or notification update. A returned complete friend-ID list can
remove older cached membership; missing rows on a partial page cannot.

The unchanged shared metadata budget is **one request per 60 seconds**, including
interactive operations and pipeline-token requests. The automatic scheduler
does not occupy that lock while waiting for its next dispatch. Known interactive
page jobs and a busy transport take precedence. Server rate-limit cooldowns are
honored. Catch-up targets another cycle five minutes after its previous cycle
finishes, or fifteen minutes in Low Power mode. Queue length, pagination and
server cooldowns can make freshness substantially slower; this is not a promise
to reload every dataset every five minutes.

Each cycle reads at most 20 pages of 100 records per friend family, and three
pages per inbox family. Coverage remains marked partial when a cap is reached.
The shared current inbox is bounded to 1,000 records. Startup friend-cache loading
is bounded to 1,000 rows / 4 MiB. Notification bodies are retained in on-disk
history only under the existing private-text history preference.

## Recovery and notifications

The existing pipeline's bounded reconnect attempts are followed by application
cooldowns, so a network interruption does not require another Start gesture.
Sleep or a long pause triggers a new connection and catch-up, without replaying
every overdue timer. Queue overflow and disconnects retain explicit coverage
gaps. Snapshots recover current observations; they cannot recreate missed events
or establish their exact times.

Automatic work stops at sign-out, rejected authentication, account changes,
privacy/lock boundaries, offline policy, Demo and Safe mode. Inactive saved
accounts never poll. The existing local lock still disconnects the account and
requires explicit reconnection after unlocking. Recovered profile bundles set
automatic sync off for fresh setup.

**Desktop controls → Notifications** adds an arrival-grouping window (default
two seconds, adjustable from zero to ten) and a same-sender/type alert cooldown
(default fifteen seconds, adjustable from zero to 300). Read or hidden items
are removed from pending alerts. Quiet hours suppress pending alerts. These
controls do not remove inbox records. Initial and periodic snapshots are silent.

## Validation and remaining work

The new tests exercise connection/worker ownership, pacing and Retry-After,
sleep/reconnect behavior, cancellation, client/session/privacy boundaries,
cached observations, late-result ordering, profile merges, partial/deleted
notifications, silent catch-up, alert grouping and live-row action preflight.
UI checks use real callbacks with headless widget fixtures.

Native Windows/Linux GUI and live VRChat acceptance remain unperformed here.
See [validation](VALIDATION_1_21.md) for actual test counts and environment limits.
This checkpoint is runnable source, not a compiled executable or signed installer.

Watchlists, owned-content monitoring, automatic image/tile updates throughout
Search, a dedicated catch-up summary, generalized per-account sync profiles,
and a full application-wide priority scheduler remain future work. This release
does not claim complete VRCX parity.

Protocol reference: [VRChat community WebSocket documentation](https://vrchat.community/websocket),
reviewed October 4, 2026. The existing pipeline token handshake from the supplied
VRCX source contract is retained; its live-service acceptance remains open.
