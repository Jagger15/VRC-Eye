"""A bounded view of recorded game activity; no memory inspection or crash guessing."""
from collections import deque
from dataclasses import dataclass, replace
import re
import time
from urllib.parse import urlsplit, parse_qsl, urlencode, urlunsplit

from player_profile import safe_link

HEADER=re.compile(r"^\ufeff?\s*(\d{4}[./-]\d{2}[./-]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+(Log|Info|Debug|Warning|Error|Exception|Assert|Fatal)\s*-?\s*(.*)$",re.I)
URL=re.compile(r"(?:https?|rtsp[ts]?|rtmp)://[^\s<>\"']+",re.I)
SECRETS=re.compile(r"(?i)(\b(?:authToken|authcookie|twoFactorAuth|authorization|cookie|password|friendKey|access_token|refresh_token|api[_-]?key)\b\s*[=:]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)")
QUERY_SECRET=re.compile(r"^(?:auth|authToken|token|access_token|refresh_token|api[_-]?key|key|secret|password|signature|sig)$",re.I)
CATEGORIES=("All","Worlds","Players","Avatars","Assets","Videos","Images","Strings","Errors","Crashes","Events","Other")


def redact(text):
    text=re.sub(r"authcookie_[A-Za-z0-9_-]+","authcookie_REDACTED",text)
    text=re.sub(r"~nonce\([^)]*\)","~nonce(REDACTED)",text)
    text=SECRETS.sub(lambda m:m[1]+"[REDACTED]",text)
    text=re.sub(r"(?i)(?:Bearer|Basic)\s+[A-Za-z0-9+/=_-]+","[AUTH REDACTED]",text)
    def url_hide(match):
        value=match[0]
        try:
            p=urlsplit(value)
            if p.username or p.password:
                return "[URL WITH CREDENTIALS REDACTED]"
            args=parse_qsl(p.query,keep_blank_values=True)
            if any(QUERY_SECRET.fullmatch(k) for k,v in args):
                return urlunsplit((p.scheme,p.netloc,p.path,urlencode([(k,"REDACTED" if QUERY_SECRET.fullmatch(k) else v) for k,v in args]),p.fragment))
        except ValueError: return "[INVALID URL]"
        return value
    return URL.sub(url_hide,text)


@dataclass(frozen=True)
class LogItem:
    serial:int
    stamp:str
    category:str
    severity:str
    message:str
    urls:tuple[str,...]
    world:str
    source:str
    playback:str=""


class GameLog:
    def __init__(self,limit=10000):
        self.items=deque(maxlen=limit)
        self.serial=0; self.revision=0; self.dropped=0
        self.source=""; self.world=""; self.latest_video=None; self.last_stamp=""
        self.ended=False;self.generation=0;self.observed_at=None

    def reset(self,source=""):
        self.items.clear(); self.serial=0; self.dropped=0; self.source=source; self.world=""
        self.latest_video=None; self.last_stamp=""; self.ended=False; self.revision+=1;self.generation+=1;self.observed_at=None

    def add_lines(self,lines,source,reset=False):
        if reset or self.source!=source: self.reset(source)
        for raw in lines:
            match=HEADER.match(raw)
            if match:
                when,severity,message=match.groups(); self.last_stamp=when
            else:
                when,severity,message=self.last_stamp,"Continuation",raw
            if not message.strip(): continue
            lower=message.casefold()
            category="Other"; playback=""
            # Only explicit markers are classified as crashes. Silence/EOF is not a crash.
            if (re.match(r"^(?:Crash!!!|\[CrashHandler\]|Fatal error:|Received signal \d+|Access violation)",message,re.I)
                    or (severity.lower()=="fatal" and "crash" in lower)):
                category="Crashes"
            elif severity.lower() in ("error","exception","assert","fatal") or "udonvmexception" in lower: category="Errors"
            elif "[image download]" in lower or "attempting to load image from url" in lower: category="Images"
            elif "[string download]" in lower or "attempting to load string from url" in lower: category="Strings"
            elif (any(tag in lower for tag in ("[video playback]","[avprovideo]","[usharpvideo]")) or
                  " added url " in lower or re.search(r"\[vrcx\]\s*videoplay",lower)):
                category="Videos"
                playback="Load requested / playback unconfirmed" if any(v in lower for v in ("resolv","load","added url")) else "Video event"
                if re.search(r"\b(?:started playing|playback started|onvideostart|video started)\b",lower): playback="Playback start reported"
                elif re.search(r"\b(?:stopped|ended|onvideoend)\b",lower): playback="Playback stop/end reported"
            elif "entering room:" in lower or "joining wrld_" in lower:
                category="Worlds"
                self.world=redact(message[:1000]); self.latest_video=None; self.ended=False
            elif any(v in lower for v in ("onplayerleftroom","onleftroom","successfully left room","onapplicationquit")):
                category="Events"; self.ended=True; self.latest_video=None
            elif any(v in lower for v in ("onplayerjoined","onplayerleft","initialized playerapi")): category="Players"
            elif " to avatar " in lower or "avtr_" in lower: category="Avatars"
            elif any(v in lower for v in ("assetbundle","asset bundle","download","loading asset","loaded asset","shader","texture","prefab")): category="Assets"
            elif any(v in lower for v in ("disconnect","connection","kick","microphone","audio device","onapplication","timeout","exception")): category="Events"
            urls=tuple(v.rstrip(".,;)]}") for v in URL.findall(message)[:16])
            # Log URLs with credentials/known secret query arguments are not made actionable.
            urls=tuple(u for u in urls if len(u)<=8192 and redact(u)==u)
            self.serial+=1
            item=LogItem(self.serial,when,category,severity,redact(message[:20000]),urls,self.world,source,playback)
            if len(self.items)==self.items.maxlen: self.dropped+=1
            self.items.append(item); self.revision+=1;self.observed_at=time.monotonic()
            if category=="Videos":
                if playback=="Playback stop/end reported": self.latest_video=None
                elif urls: self.latest_video=item
                elif playback=="Playback start reported" and self.latest_video:
                    self.latest_video=replace(self.latest_video,playback=playback,stamp=when)

    def projection(self,category='All',query='',offset=0,limit=200):
        if category not in CATEGORIES or type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=1000:
            raise ValueError('Choose a supported log category and bounded page.')
        if not isinstance(query,str) or len(query)>2000:raise ValueError('Keep log filters within 2,000 characters.')
        rows=[r for r in reversed(self.items) if (category=='All' or r.category==category) and query.casefold() in (r.message+' '+r.world).casefold()]
        return dict(generation=self.generation,revision=self.revision,rows=tuple(rows[offset:offset+limit]),total=len(rows),
            retained=len(self.items),dropped=self.dropped,offset=offset,observed_at=self.observed_at)

    def page(self,category="All",query="",offset=0):
        value=self.projection(category,query,offset)
        return list(value['rows']),value['total']

    def around(self,serial,radius=4):
        return "\n".join(f"{x.stamp} [{x.severity}] {x.message}" for x in self.items if abs(x.serial-serial)<=radius)
