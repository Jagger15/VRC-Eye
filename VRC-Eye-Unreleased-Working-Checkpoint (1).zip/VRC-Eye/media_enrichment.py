"""Explicit public Vimeo oEmbed reads. No browser, executable or video download."""
import json
import re
import time
from urllib.parse import urlsplit,urlencode
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError,URLError

CONTRACT='https://developer.vimeo.com/api/oembed/videos'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise ValueError('Provider redirected this lookup. No redirect was followed.')


def video_url(value):
    if not isinstance(value,str) or not re.fullmatch(r'https://vimeo\.com/[0-9]{1,14}',value):
        raise ValueError('This adapter supports public https://vimeo.com/VIDEO_ID links. Other providers and private links remain local bookmarks.')
    return value


def _read(url,limit,stop,opener=None):
    opener=opener or build_opener(NoRedirect());started=time.monotonic()
    try:
        request=Request(url,headers={'User-Agent':'VRC-Eye/1.21 (explicit media metadata lookup)','Accept-Encoding':'identity'})
        with opener.open(request,timeout=8) as response:
            if response.status!=200 or response.headers.get('Content-Encoding','identity')!='identity':raise ValueError('Unexpected provider response.')
            chunks=[];size=0
            while True:
                if stop and stop.is_set():raise ValueError('Lookup cancelled.')
                if time.monotonic()-started>12:raise ValueError('Provider read deadline exceeded.')
                chunk=response.read(min(8192,limit-size+1))
                if not chunk:break
                size+=len(chunk)
                if size>limit:raise ValueError('Provider response exceeded its size budget.')
                chunks.append(chunk)
        return b''.join(chunks)
    except HTTPError as exc:raise ValueError('Vimeo lookup returned HTTP '+str(exc.code)+'. No automatic retry.') from None
    except (URLError,TimeoutError,OSError):raise ValueError('Vimeo lookup failed or timed out. Playback state remains unverified.') from None


def resolve(value,stop=None,opener=None):
    from native_library import plain
    value=video_url(value);data=json.loads(_read('https://vimeo.com/api/oembed.json?'+urlencode({'url':value}),65536,stop,opener))
    if not isinstance(data,dict) or data.get('provider_name')!='Vimeo' or data.get('type')!='video' or str(data.get('video_id'))!=value.rsplit('/',1)[-1]:raise ValueError('Provider identity did not match the reviewed video.')
    title=plain(data.get('title'),512,empty=False);author=plain(data.get('author_name',''),512)
    thumbnail=data.get('thumbnail_url','');parts=urlsplit(thumbnail)
    if parts.scheme!='https' or parts.netloc!='i.vimeocdn.com' or not parts.path.startswith('/video/') or parts.username or parts.password or len(thumbnail)>2048:thumbnail=''
    return dict(url=value,title=title,artist=author,thumbnail=thumbnail,checked=time.time(),source='Vimeo oEmbed',evidence='Provider metadata observed on demand; playback not verified')


def artwork(value,stop=None,opener=None):
    parts=urlsplit(value)
    if parts.scheme!='https' or parts.netloc!='i.vimeocdn.com' or not parts.path.startswith('/video/') or len(value)>2048:raise ValueError('Unsupported Vimeo thumbnail URL.')
    from profile_images import preview_png
    return preview_png(_read(value,1024*1024,stop,opener))
