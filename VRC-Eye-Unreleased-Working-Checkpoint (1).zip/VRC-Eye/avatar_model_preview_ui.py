"""Account-scoped RAM-only OBJ preview within the existing Avatar Library."""
from pathlib import Path
from tkinter import filedialog

from companion_ui import button, choice
from friendly_ui import focus_scroll_target, flow_line as line
import avatar_model_preview as model


class ModelPreviewPanel:
    """Integration: create in the 3D preview frame; call clear/tick/close hooks."""
    def __init__(self, page, parent):
        self.page, self.parent = page, parent
        # AvatarCreatorPanel already places Library inside one scrolling canvas.
        # A second Canvas requests only its default height, clipping the mesh
        # even when the outer viewport has ample room. Use the existing content.
        self.body = parent
        self.scroll_canvas = None; self.scroll_content = None
        ancestor = parent
        while getattr(ancestor, 'master', None) is not None:
            if ancestor.master.winfo_class() == 'Canvas':
                self.scroll_canvas, self.scroll_content = ancestor.master, ancestor
                break
            ancestor = ancestor.master
        self.mesh = None; self.camera = model.Camera(); self.source = '';self.fbx_textures=()
        self.generation = 0; self.draw_generation = 0; self.render_after = None
        self.loading = False; self.closed = False; self.drag = None
        self.last = self.context(); self.palette = self.colors()
        self.mode = page.tk.StringVar(value='Solid')
        self.info = page.tk.StringVar(value='Select an avatar, then choose a local OBJ mesh to preview.')
        self.camera_info = page.tk.StringVar()
        self.label('Actual local 3D geometry · OBJ, GLB, FBX and supported Unity bundles with bounded skinning and blendshape previews. Choose a source explicitly. Source files are read without changes; opening this section does not load a model.')
        row = line(page, self.body)
        button(page, row, 'Choose local OBJ mesh…', self.choose)
        button(page, row, 'Choose GLB scene…', self.choose_scene)
        button(page, row, 'Choose authorized Unity bundle…', self.choose_bundle)
        button(page, row, 'Choose authorized FBX…', self.choose_fbx)
        button(page, row, 'Clear 3D preview', self.clear)
        choice(page, row, self.mode, ('Solid', 'Wireframe', 'Base color', 'Textured'), self.schedule_render, width=14)
        page.ttk.Label(self.body, textvariable=self.info, wraplength=1000).pack(anchor='w', pady=5)
        self.canvas = page.tk.Canvas(self.body, width=640, height=420, background=page.app.PANEL,
                                     highlightthickness=3, highlightbackground=page.app.MUTED,
                                     highlightcolor=page.app.ACCENT, takefocus=True)
        from screen_reader_model import annotate
        annotate(self.canvas,name='Local 3D model preview',value=lambda:self.info.get()+'. '+self.camera_info.get(),description='Use the scene hierarchy, material and mesh-health tables for geometry details. Orbit, pan, zoom, fit and reset all have buttons.')
        self.canvas.pack(fill='x', expand=True, pady=5)
        row = line(page, self.body)
        for label, action in (('Orbit left', lambda: self.orbit(-15, 0)), ('Orbit right', lambda: self.orbit(15, 0)),
                              ('Orbit up', lambda: self.orbit(0, 15)), ('Orbit down', lambda: self.orbit(0, -15))):
            button(page, row, label, action)
        row = line(page, self.body)
        for label, action in (('Pan left', lambda: self.pan(-.08, 0)), ('Pan right', lambda: self.pan(.08, 0)),
                              ('Pan up', lambda: self.pan(0, -.08)), ('Pan down', lambda: self.pan(0, .08))):
            button(page, row, label, action)
        row = line(page, self.body)
        button(page, row, 'Zoom in', lambda: self.zoom(1.2))
        button(page, row, 'Zoom out', lambda: self.zoom(1 / 1.2))
        button(page, row, 'Fit model', self.fit)
        button(page, row, 'Reset view', self.reset)
        page.ttk.Label(self.body, textvariable=self.camera_info, wraplength=1000).pack(anchor='w', pady=4)
        self.label('Canvas controls: arrow keys orbit; Shift+arrows pan; +/− zoom; F fits; Home resets. Left drag orbits; Shift+left drag and right drag pan; wheel zooms. All actions also have buttons. There is no automatic rotation.')
        self.label('Orthographic preview. GLB Base color/Textured modes show unlit base color, vertex colors and bounded embedded textures with supported transforms; OBJ remains flat geometry. Texture previews use up to 256 px and frames up to 480 × 320. Blend transparency is approximate. Animation timeline supports GLB transform/morph clips and prepared Linux FBX take ranges. PBR/Unity shaders, controllers, humanoid retargeting and PhysBones remain unavailable. No preview demonstrates in-game appearance.')
        self.label('Preview limits: 16 MiB text; 20,000 declared vertices; 8,000 triangles; 64 vertices per polygon. Unsupported or oversized files fail with an explanation. Export a triangulated or reduced OBJ copy from your own source editor when needed; VRC Eye does not modify or simplify the original.')
        self.label('GLB limits: 32 MiB, 512 nodes, 100,000 used vertices and 30,000 triangles. Skinning supports four influences per vertex and 256 joints per skin. Position morphs support 32 targets per mesh, 200,000 target vertices total and weights from -4 to 4. Sparse/compressed geometry and most required extensions remain unsupported. Parsing uses a cancellable subprocess; blendshape updates use the existing cancellable Library task.')
        self.label('Unity bundle subset: Linux with libseccomp and optional requirements-bundles.txt; UnityFS v6–8, Unity 2022.3 release builds, serialized v22 little-endian Windows64/Linux64/Android data. 32 MiB input / 64 MiB expanded; existing scene geometry limits apply. Textures, packed meshes, multi-frame blendshapes and animation playback remain unsupported. Unknown bundles retain inspection and manual recovery.')
        from avatar_scene_ui import SceneControls
        self.scene_controls=SceneControls(self)
        self.canvas.bind('<Configure>', lambda event: self.schedule_render())
        self.canvas.bind('<KeyPress>', self.key)
        self.canvas.bind('<ButtonPress-1>', lambda event: self.begin_drag(event, False))
        self.canvas.bind('<ButtonPress-3>', lambda event: self.begin_drag(event, True))
        self.canvas.bind('<B1-Motion>', self.move_drag)
        self.canvas.bind('<B3-Motion>', self.move_drag)
        self.canvas.bind('<ButtonRelease-1>', lambda event: self.end_drag())
        self.canvas.bind('<ButtonRelease-3>', lambda event: self.end_drag())
        self.canvas.bind('<MouseWheel>', self.wheel)
        self.canvas.bind('<Button-4>', lambda event: self.wheel(event, 1))
        self.canvas.bind('<Button-5>', lambda event: self.wheel(event, -1))
        self.bind_focus(self.body)
        self.update_camera_info(); self.schedule_render()

    def label(self, text):
        self.page.ttk.Label(self.body, text=text, wraplength=1000, style='Muted.TLabel').pack(anchor='w', pady=5)

    def bind_focus(self, parent):
        for child in parent.winfo_children():
            child.bind('<FocusIn>', self.focus_visible, add='+')
            self.bind_focus(child)

    def focus_visible(self, event):
        """Reveal focused mesh/buttons in the single outer Library viewport."""
        canvas, content, widget = self.scroll_canvas, self.scroll_content, event.widget
        if self.closed or canvas is None:
            return
        try:
            if not widget.winfo_ismapped():
                return
            box = canvas.bbox('all')
            if not box or box[3] <= 0:
                return
            top = widget.winfo_rooty() - content.winfo_rooty()
            height = widget.winfo_height(); view = canvas.winfo_height()
            start = canvas.canvasy(0)
            target = focus_scroll_target(top, height, view, start)
            if target != start:
                canvas.yview_moveto(min(1., target / box[3]))
        except self.page.tk.TclError:
            pass  # A close or section switch may destroy/unmap the focused view.

    def colors(self):
        return self.page.app.PANEL, self.page.app.TEXT, self.page.app.ACCENT, self.page.app.MUTED, self.page.app.BG

    def context(self):
        return self.page.context(), self.page.privacy.get(), self.page.selected_id, bool(getattr(self.page.app,'safe_mode',False)), bool(getattr(self.page.app,'demo',False))

    def require(self):
        self.page.writable()
        if self.closed:
            raise ValueError('The 3D preview is closed.')
        if self.context() != self.last:
            self.clear()
        if self.page.job:
            raise ValueError('Wait for the current Avatar Library task to finish or stop before loading a model.')

    def choose(self):
        self.require(); self.page.selected()
        token = self.context()
        selected = filedialog.askopenfilename(parent=self.page.app.root, title='Choose a local OBJ polygon mesh',
                                             filetypes=(('Wavefront OBJ polygon mesh', '*.obj'),))
        if selected:
            if token != self.context():
                self.clear()
                raise ValueError('The account, privacy setting or selected avatar changed while choosing a model. Choose it again.')
            self.load_file(selected)

    def load_file(self, path, *, bundle=False, fbx=False, textures=(), authorized=False):
        self.require(); avatar = self.page.selected()['id']
        if (bundle or fbx) and authorized is not True:raise ValueError('Confirm ownership or permission before importing this source.')
        self.clear(); self.loading = True
        token, generation = self.context(), self.generation
        is_scene=bundle or fbx or Path(path).suffix.lower()=='.glb'
        label='Unity bundle scene' if bundle else 'FBX scene' if fbx else 'GLB scene' if is_scene else 'OBJ mesh'
        self.info.set('Reading the selected '+label+'…')
        def done(mesh):
            self.loading = False
            if self.closed or generation != self.generation or token != self.context():
                return
            self.mesh = mesh; self.source = str(path); self.camera = model.Camera()
            self.fbx_textures=tuple(textures) if fbx else ()
            if is_scene:self.scene_controls.attach(mesh)
            self.update_info(); self.schedule_render()
            self.page.status.set(label+' loaded locally. Source files, worn avatar and Unity are unchanged.')
        try:
            if fbx:
                loader=lambda path,**kwargs:__import__('avatar_scene_provider').load_fbx(path,authorized=True,textures=textures,**kwargs)
            elif bundle:
                loader=lambda path,**kwargs:__import__('avatar_scene_provider').load_bundle(path,authorized=True,**kwargs)
            else:loader=__import__('avatar_scene_provider').load if is_scene else model.read_obj
            self.page.start_task(lambda stop, progress: loader(path, stop=stop, progress=progress), done,
                                 avatar=avatar, operation=label+' preview')
        except Exception:
            self.loading = False
            raise

    def choose_scene(self):
        self.require();self.page.selected();token=self.context()
        selected=filedialog.askopenfilename(parent=self.page.app.root,title='Choose a GLB 2.0 scene',filetypes=(('Binary glTF scene','*.glb'),))
        if selected:
            if token!=self.context():
                self.clear();raise ValueError('Account, privacy or avatar changed while choosing a scene. Choose it again.')
            self.load_file(selected)

    def choose_bundle(self):
        self.require();self.page.selected();token=self.context()
        selected=filedialog.askopenfilename(parent=self.page.app.root,title='Choose your authorized local Unity bundle',filetypes=(('Unity bundles','*.vrca *.vrcw *.bundle *.unity3d'),('All files','*')))
        if not selected:return
        if token!=self.context():
            self.clear();raise ValueError('Account, privacy or avatar changed while choosing a bundle.')
        if not self.page.review('Decode selected Unity bundle?',
            'Decode only a bundle you own or have permission to inspect. The selected file is read into a contained worker; no scripts run and no external assets are fetched. '+
            'This experimental Linux preview supports a bounded Unity 2022.3 subset. Other versions, oversized or unsupported content keep their inspect/copy/manual-recovery path. '+
            'Saved material colors approximate appearance; Unity shaders and animation do not run.', 'I have permission — decode'):
            return
        if token!=self.context():
            self.clear();raise ValueError('Account, privacy or avatar changed during the bundle review.')
        self.load_file(selected,bundle=True,authorized=True)

    def choose_fbx(self):
        self.require();self.page.selected();token=self.context()
        selected=filedialog.askopenfilename(parent=self.page.app.root,title='Choose your authorized local FBX',filetypes=(('FBX scene','*.fbx'),))
        if not selected:return
        if token!=self.context():
            self.clear();raise ValueError('Account, privacy or avatar changed while choosing FBX.')
        textures=filedialog.askopenfilenames(parent=self.page.app.root,title='Optional FBX PNG/JPEG textures — Cancel skips external textures',filetypes=(('PNG/JPEG textures','*.png *.jpg *.jpeg'),))
        if token!=self.context():
            self.clear();raise ValueError('Account, privacy or avatar changed while choosing textures.')
        if not self.page.review('Import selected FBX?',
            'Import only an FBX and textures you own or have permission to inspect. '+
            f'{len(textures)} external textures selected; only exact plain filename references can match them. No other files or network locations are opened. '+
            'The Linux preview uses the optional native/fbx adapter. It shows a static stored pose in meters, with source units, axes, rigs, blendshapes and takes recorded separately. '+
            'You may explicitly prepare a bounded take range in Animation timeline. Interactive FBX posing, constraints, controllers and shaders are unavailable. Your source files stay unchanged.', 'I have permission — import'):
            return
        if token!=self.context():
            self.clear();raise ValueError('Account, privacy or avatar changed during FBX review.')
        self.load_file(selected,fbx=True,textures=tuple(textures),authorized=True)

    def update_info(self):
        if not self.mesh:
            return
        if isinstance(self.mesh,__import__('avatar_scene').Scene):self.scene_controls.info();return
        name = self.source if self.page.show_paths.get() else Path(self.source).name
        ignored = ', '.join(f'{keyword}: {count}' for keyword, count in self.mesh.ignored) or 'None'
        self.info.set(f'{name}\n{len(self.mesh.vertices):,} used vertices / {self.mesh.source_vertices:,} declared · '
                      f'{self.mesh.source_faces:,} source faces → {len(self.mesh.triangles):,} preview triangles\n'
                      f'Source SHA-256: {self.mesh.sha256}\nIgnored appearance/group declarations: {ignored}. '
                      'This is an in-memory snapshot of the selected bytes, not proof of ownership or current source state.')

    def tick(self):
        if self.closed:
            return
        if self.context() != self.last:
            self.clear()
        if self.scene_controls.deform_pending and not self.page.job:self.scene_controls.deform_pending=False
        timeline=self.scene_controls.timeline
        if timeline and timeline.preparing and not self.page.job:
            timeline.preparing=False;timeline.state.set('Preparation stopped. Inspect the task outcome above; the previous pose is retained.')
        bounds=self.scene_controls.bounds_inspection
        if bounds and bounds.pending and not self.page.job:
            bounds.pending=False;bounds.detail.set('Observation stopped. Inspect the task outcome above, then inspect again.')
        skin=self.scene_controls.skin_optimization
        if skin and skin.pending and not self.page.job:
            skin.pending=False;skin.detail.set('Trial stopped. Inspect the task outcome above, then measure again.')
        if self.loading and not self.page.job:
            self.loading = False
            if not self.mesh:
                self.info.set('No model retained. Inspect the task outcome above, then choose a source explicitly.')
        if self.colors() != self.palette:
            self.palette = self.colors(); self.schedule_render()

    def cancel_render(self):
        self.draw_generation += 1
        if hasattr(self,'scene_controls'):self.scene_controls.cancel()
        if self.render_after is not None:
            try:
                self.canvas.after_cancel(self.render_after)
            except self.page.tk.TclError:
                pass
            self.render_after = None

    def clear(self):
        if self.loading and self.page.job:
            self.page.cancel()
        self.generation += 1; self.loading = False; self.mesh = None; self.source = ''; self.drag = None;self.fbx_textures=()
        self.camera = model.Camera(); self.last = self.context()
        if hasattr(self,'scene_controls'):self.scene_controls.clear()
        self.info.set('No model or source path retained. Select an avatar and explicitly choose an OBJ, GLB, authorized FBX or Unity bundle.')
        self.cancel_render(); self.update_camera_info()
        if not self.closed:
            self.schedule_render()

    def close(self):
        self.clear(); self.closed = True; self.cancel_render()
        self.scene_controls.close()
        if self.canvas.winfo_exists():
            self.canvas.delete('all')

    def usable(self):
        if self.closed or self.page.closed:
            return False
        if self.page.privacy.get() or self.context() != self.last:
            if self.mesh is not None or self.loading or self.source or self.context() != self.last:
                self.clear()
            return False
        return self.mesh is not None

    def orbit(self, yaw, pitch):
        if self.usable():
            self.camera = model.orbit(self.camera, yaw, pitch); self.schedule_render()

    def pan(self, x, y):
        if self.usable():
            self.camera = model.pan(self.camera, x, y); self.schedule_render()

    def zoom(self, factor):
        if self.usable():
            self.camera = model.zoom(self.camera, factor); self.schedule_render()

    def fit(self):
        if self.usable():
            self.camera = model.fit(self.camera); self.schedule_render()

    def reset(self):
        if self.usable():
            self.camera = model.Camera(); self.schedule_render()

    def update_camera_info(self):
        self.camera_info.set(f'View: {self.camera.yaw:.0f}° yaw, {self.camera.pitch:.0f}° pitch · '
                             f'Zoom {self.camera.zoom:.2f}× · Pan {self.camera.pan_x:.2f}, {self.camera.pan_y:.2f} · {self.mode.get()}')

    def schedule_render(self):
        if self.closed or not self.canvas.winfo_exists():
            return
        self.cancel_render(); self.update_camera_info()
        token = self.draw_generation
        self.render_after = self.canvas.after(1, lambda: self.render(token))

    def render(self, token):
        self.render_after = None
        if self.closed or token != self.draw_generation or not self.canvas.winfo_exists():
            return
        self.canvas.delete('all')
        self.canvas.configure(background=self.page.app.PANEL, highlightbackground=self.page.app.MUTED,
                              highlightcolor=self.page.app.ACCENT)
        width = max(1, min(10000, self.canvas.winfo_width())); height = max(1, min(10000, self.canvas.winfo_height()))
        if not self.usable():
            self.canvas.create_text(width/2, height/2, text='No 3D mesh loaded', fill=self.page.app.TEXT, font='TkDefaultFont')
            return
        if self.mode.get() not in ('Solid', 'Wireframe', 'Base color', 'Textured'):
            raise ValueError('Choose Solid, Wireframe, Base color or Textured preview.')
        if isinstance(self.mesh,__import__('avatar_scene').Scene):
            self.scene_controls.render(token,width,height);return
        faces = model.project(self.mesh, self.camera, width, height)
        mesh, context = self.mesh, self.context()
        accent = self.page.app.ACCENT
        rgb = tuple(v // 257 for v in self.canvas.winfo_rgb(accent))
        wire = self.mode.get() == 'Wireframe'
        def batch(start=0):
            self.render_after = None
            if self.closed or token != self.draw_generation or mesh is not self.mesh or context != self.context():
                return
            for face in faces[start:start+200]:
                fill = '' if wire else '#' + ''.join(f'{round(value*face.shade):02x}' for value in rgb)
                self.canvas.create_polygon(face.points, fill=fill, outline=accent if wire else self.page.app.BG,
                                           width=1, tags=('mesh',))
            if start + 200 < len(faces):
                self.render_after = self.canvas.after(1, lambda: batch(start+200))
        batch()

    def key(self, event):
        # Ignore Caps/Num Lock; leave Control, Alt and system chords to the app.
        if event.state & (4 | 8 | 64 | 128 | 0x20000):
            return
        keys = {'Left': (-1, 0), 'Right': (1, 0), 'Up': (0, -1), 'Down': (0, 1)}
        if event.keysym in keys:
            x, y = keys[event.keysym]
            if event.state & 1: self.pan(x*.05, y*.05)
            else: self.orbit(x*8, -y*8)
        elif event.keysym in ('plus', 'equal', 'KP_Add'): self.zoom(1.15)
        elif event.keysym in ('minus', 'KP_Subtract'): self.zoom(1/1.15)
        elif event.keysym in ('f', 'F'): self.fit()
        elif event.keysym == 'Home': self.reset()
        else: return
        return 'break'

    def begin_drag(self, event, pan_mode):
        if self.usable():
            self.canvas.focus_set(); self.drag = (event.x, event.y, pan_mode or bool(event.state & 1))
        return 'break'

    def move_drag(self, event):
        if self.drag and self.usable():
            x, y, pan_mode = self.drag; self.drag = (event.x, event.y, pan_mode)
            if pan_mode: self.pan((event.x-x)/max(1,self.canvas.winfo_width()), (event.y-y)/max(1,self.canvas.winfo_height()))
            else: self.orbit((event.x-x)*.4, (event.y-y)*.4)
        return 'break'

    def end_drag(self):
        self.drag = None
        return 'break'

    def wheel(self, event, direction=None):
        if self.usable():
            value = direction if direction is not None else (1 if event.delta > 0 else -1 if event.delta < 0 else 0)
            if value: self.zoom(1.15 if value > 0 else 1/1.15)
        return 'break'
