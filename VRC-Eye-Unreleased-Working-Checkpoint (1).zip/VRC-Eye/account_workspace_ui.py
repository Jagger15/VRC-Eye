"""Local account organization, single-session status and reviewed profile edits."""
from dataclasses import replace
import json
from pathlib import Path

from account_actions import AccountStore, ROLES, account_id, display, local_writable, service_for
from companion_data import entity_id
from companion_ui import Page, Table, line, button, choice, entry, note
from player_profile import STATUSES
import companion_api as api
from friendly_ui import ScrollPane


class WorkspacePane(ScrollPane):
    """Scroll the whole task, not just its rows, including at high text scale.

    Natural control-row width is preserved. Narrow views get horizontal scrolling
    rather than silently dropping packed buttons. Focus scrolls within this pane;
    it never activates the control or changes the account.
    """
    def __init__(self, app, parent):
        super().__init__(app, parent, min_width=760)
        self.body.bind("<Configure>", self.refit, add="+")

    def resize(self, event):
        self.refit()

    def refit(self, event=None):
        width = max(self.min_width, self.canvas.winfo_width(), self.body.winfo_reqwidth())
        self.canvas.itemconfigure(self.item, width=width)
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.wrap_labels(self.body)
        self._bind_focus(self.body)



def account_caption(app, *, private=False):
    own = account_id(app)
    if private:
        return "Privacy view: account identities hidden. Reveal before acting."
    reported = getattr(getattr(app, "player_sessions", None), "local_user_id", "")
    text = "Viewing / acting VRChat account: " + (own or "Not signed in")
    if reported:
        text += "\nLast log-observed game account (may be stale): " + reported
        if own and own != reported:
            text += " — DIFFERENT; Social actions still use the VRC Eye account above."
    else:
        text += "\nRunning-game identity: not established. No match is assumed."
    return text


def submit_review(page, action, *, view_guard=None, done=None, **args):
    """One shared review path for Social, Game Favorites and My profile."""
    if page.job:
        raise ValueError("Wait for or cancel the pending task before reviewing another action.")
    page.connected()
    service = service_for(page.shell)
    review = service.prepare(action, **args)
    try:
        state = view_guard() if view_guard else None
        summary = review.summary()
        # Avatar descriptions/tags and saved invitation text can exceed a native
        # message box's screen height. Keep every reviewed value scrollable.
        if len(summary) > 3000 or summary.count('\n') > 32:
            from creator_projects_ui import review_document
            accepted = review_document(page.app, "Review account-bound action", summary,
                                       accept="Submit this one action")
        else:
            accepted = page.confirm("Review account-bound action", summary)
        if not accepted:
            return
        if view_guard and view_guard() != state:
            raise ValueError("The account, selection or draft changed. Review again.")
        service.validate_review(review)
        automation=getattr(page.shell,'status_rules',None)
        if action=='update-self' and automation:automation.manual_override()
        def finished(outcome):
            if done:
                done(outcome)
            else:
                page.status.set(outcome.value if outcome.state == "Confirmed" and isinstance(outcome.value, str) else outcome.message)
        page.start(lambda client, stop, progress, prepared=review: service.execute(prepared, stop=stop, progress=progress), finished, mutation=True)
        review = None  # Worker owns the one-use review now.
    finally:
        if review is not None:
            service.discard(review)


class HistoryPanel:
    """Local-only history for a supplied account; never sends or retries actions."""
    def __init__(self, page, parent, scope, *, private=lambda: False):
        self.page, self.scope, self.private = page, scope, private
        self.parent = parent; self.offset = 0; self.total = 0; self.last = None
        self.status = page.tk.StringVar(value="Refresh local history for the selected account.")
        self.detail = page.tk.StringVar(value="Select a receipt. No action is retried from history.")
        row = line(page, parent)
        button(page, row, "Refresh local history", lambda: self.refresh(0))
        button(page, row, "Previous", lambda: self.refresh(max(0, self.offset - 100)))
        button(page, row, "Next", self.next)
        page.ttk.Label(parent, textvariable=self.status, wraplength=980).pack(anchor="w", pady=4)
        self.table = Table(page, parent, (("time", "Time", 170), ("action", "Action", 175), ("state", "Outcome", 190), ("target", "Target", 300)), height=9, select=self.selection)
        page.ttk.Label(parent, textvariable=self.detail, wraplength=980).pack(anchor="w", pady=5)
        row = line(page, parent)
        button(page, row, "Acknowledge uncertain outcome…", self.acknowledge)
        button(page, row, "Clear completed history…", self.clear)
        button(page, row, "Export selected receipt…", self.export)
        row = line(page, parent)
        button(page, row, "Retry saving outcome locally", self.retry_save)
        page.ttk.Label(parent, text="Local history only. Acknowledgement is not proof of success. Messages, profile field values and credentials are not kept in receipts.", wraplength=980, style="Muted.TLabel").pack(anchor="w", pady=5)

    def store(self):
        return service_for(self.page.shell)

    def refresh(self, offset=None):
        if offset is not None:
            self.offset = offset
        own = self.scope()
        self.last = (own, self.private())
        if not own or self.private():
            self.table.set([], lambda r: ())
            self.total = 0
            self.status.set("Identities hidden." if self.private() else "Select an account or connect before viewing its local history.")
            self.detail.set("No receipt selected.")
            return
        service = self.store()
        selected = self.table.selected()
        selected_id = selected["id"] if selected else ""
        rows, self.total = service.store.receipts(own, service.run, offset=self.offset)
        if self.offset and not rows:
            self.offset = max(0, (max(0, self.total - 1) // 100) * 100)
            rows, self.total = service.store.receipts(own, service.run, offset=self.offset)
        self.table.set(rows, lambda r: (r["created"], r["operation"].replace('-', ' '), r["display_state"], r["target"]))
        for key, item in self.table.records.items():
            if item["id"] == selected_id:
                self.table.tree.selection_set(key)
        volatile = service.volatile_outcomes(own)
        self.status.set(f"{self.total} receipts for this account · page {self.offset // 100 + 1}." +
                        (" WARNING: " + " | ".join(r.message for r in volatile) if volatile else ""))
        self.selection()

    def next(self):
        if self.offset + 100 < self.total:
            self.refresh(self.offset + 100)

    def selected(self):
        if self.private() or self.last != (self.scope(), self.private()):
            self.refresh(0)
            raise ValueError("The history account or privacy view changed. Select a receipt again.")
        row = self.table.selected()
        if not row or row["account"] != self.scope():
            raise ValueError("Select a receipt for the current history account.")
        return row

    def selection(self):
        row = self.table.selected()
        if not row or self.private():
            self.detail.set("Select a receipt. No action is retried from history.")
            return
        self.detail.set(f"{row['display_state']}\n{row['reason']}\nLocal uncertainty acknowledgement: {'yes' if row['acknowledged'] else 'no'}.")

    def retry_save(self):
        local_writable(self.page.app)
        row = self.selected(); own = self.scope()
        service = self.store()
        service.retry_receipt_save(own, row["id"])
        self.refresh()
        self.page.status.set("In-memory outcome saved locally. No remote action was retried.")

    def acknowledge(self):
        local_writable(self.page.app)
        row = self.selected(); own = self.scope()
        if not self.page.confirm("Acknowledge uncertainty", "Check the live state independently before repeating this operation. This only records that you reviewed the uncertainty; it does not mark the action as successful or retry it.\n\nAccount: " + own + "\nAction: " + row["operation"] + "\nTarget: " + row["target"] + "\n\nAcknowledge?"):
            return
        if self.scope() != own or self.selected()["id"] != row["id"]:
            raise ValueError("History selection changed. Review again.")
        local_writable(self.page.app)
        service = self.store()
        service.store.acknowledge(own, row["id"], service.run, service.active_ids)
        self.refresh()

    def clear(self):
        local_writable(self.page.app)
        own = self.scope()
        if not own or self.private():
            raise ValueError("Reveal and select an account first.")
        if not self.page.confirm("Clear completed history", "Remove confirmed, rejected and not-sent local receipts for\n" + own + "?\n\nQueued/running or uncertain outcomes stay. This cannot undo any VRChat action."):
            return
        if self.scope() != own or self.private():
            raise ValueError("History account changed. Review again.")
        local_writable(self.page.app)
        service = self.store(); count = service.store.clear_completed(own, service.run)
        self.refresh(0); self.page.status.set(f"Removed {count} completed local receipts. VRChat was not changed.")

    def export(self):
        local_writable(self.page.app)
        row = self.selected(); own = self.scope(); service = self.store()
        report = service.store.export_receipt(own, row["id"], service.run)
        if not self.page.confirm("Export selected receipt", "Export only operation, outcome, timestamps and uncertainty acknowledgement? Account, target, session, aliases, messages and profile values are omitted. This report does not prove current server state."):
            return
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.page.app.root, initialfile="VRC-Eye-action-receipt.json", defaultextension=".json", filetypes=[("JSON", "*.json")])
        if not path:
            return
        local_writable(self.page.app)
        if own != self.scope() or self.selected()["id"] != row["id"]:
            raise ValueError("The receipt selection changed. Export again.")
        # Exclusive creation; existing files and symlinks are not overwritten.
        with open(path, "x", encoding="utf-8") as stream:
            stream.write(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        self.page.status.set("Selected receipt exported without account/target identifiers or payloads.")


class AccountsPage(Page):
    def __init__(self, shell, parent):
        self.viewport = WorkspacePane(shell.app, parent)
        parent = self.viewport.body
        super().__init__(shell, parent, "Accounts")
        self.actions = service_for(shell)
        self.private = self.tk.BooleanVar(value=False)
        self.caption = self.tk.StringVar(value="")
        self.current_history = ""
        self.profile_result = None
        self.profile_text = self.tk.StringVar(value="Load your profile to edit. Background observations do not replace an unsaved draft.")
        self.live_profile=self.tk.StringVar()
        self.ttk.Label(parent,textvariable=self.live_profile,wraplength=1000).pack(anchor='w',pady=4)
        self.ref = self.tk.StringVar(value=""); self.label = self.tk.StringVar(value=""); self.role = self.tk.StringVar(value="Other")
        self.profile_status = self.tk.StringVar(value=""); self.profile_description = self.tk.StringVar(value=""); self.profile_pronouns = self.tk.StringVar(value="")
        row = line(self)
        button(self, row, "Connect / replace connection…", self.connect)
        button(self, row, "Disconnect current session…", self.disconnect)
        self.ttk.Checkbutton(row, text="Privacy view (this page)", variable=self.private, command=lambda: self.guard(self.privacy_changed)).pack(side="left", padx=10)
        from ui_theme import responsive_wrap
        responsive_wrap(self.ttk.Label(parent, textvariable=self.caption, wraplength=1000)).pack(anchor="w", pady=5)
        self.tabs = self.ttk.Notebook(parent); self.tabs.pack(fill="both", expand=True)
        self.frames = {name: self.ttk.Frame(self.tabs) for name in ("Accounts & logins", "My profile", "My avatars", "Action history")}
        for name, frame in self.frames.items():
            self.tabs.add(frame, text=name)
        self._build_accounts(self.frames["Accounts & logins"])
        from retained_accounts import install as install_retained
        install_retained(self,self.frames['Accounts & logins'])
        self._build_profile(self.frames["My profile"])
        from owned_avatars_ui import OwnedAvatarsPanel
        self.owned_avatars = OwnedAvatarsPanel(self, self.frames["My avatars"])
        frame = self.frames["Action history"]
        self.history_scope = self.tk.StringVar(value="Active account")
        row = line(self, frame)
        choice(self, row, self.history_scope, ("Active account", "Selected local account"), lambda: self.history.refresh(0), 27)
        self.history = HistoryPanel(self, frame, self.history_account, private=self.private.get)
        from native_service_ui import install_accounts
        install_accounts(self)
        self.account_changed()

    def _build_accounts(self, frame):
        self.ttk.Label(frame, text="Active VRC Eye logins in this process", style="Heading.TLabel").pack(anchor="w", pady=5)
        self.active_table = Table(self, frame, (("account", "Account", 350), ("state", "Session", 260)), height=1)
        self.ttk.Label(frame, text="One account is active at a time. Local labels organize accounts; retained sign-ins below use protected OS storage. Select Switch to validate a saved session before activating it.", wraplength=1000, style="Muted.TLabel").pack(anchor="w", pady=5)
        self.table = Table(self, frame, (("label", "Local label", 210), ("role", "Role", 100), ("account", "Account ID", 350)), height=5, select=self.selection)
        row = line(self, frame)
        self.ttk.Label(row, text="Account ID:").pack(side="left", padx=4); entry(self, row, self.ref, 48)
        button(self, row, "Use active ID", self.use_active)
        row = line(self, frame)
        self.ttk.Label(row, text="Local label:").pack(side="left", padx=4); entry(self, row, self.label, 24)
        choice(self, row, self.role, ROLES, width=12)
        button(self, row, "Save local label…", self.save_label)
        button(self, row, "Forget selected label…", self.forget_label)
        self.ttk.Label(frame, text="Local-only organization on this OS account. IDs and labels are not encrypted. Forgetting a label does not remove history, credentials, avatar records or your VRChat account.", wraplength=1000, style="Muted.TLabel").pack(anchor="w", pady=5)

    def _build_profile(self, frame):
        row = line(self, frame)
        button(self, row, "Refresh my profile", self.load_profile)
        button(self, row, "Discard form edits", self.restore_form)
        self.ttk.Label(frame, textvariable=self.profile_text, wraplength=1000).pack(anchor="w", pady=7)
        row = line(self, frame)
        self.ttk.Label(row, text="Status:").pack(side="left", padx=4)
        self.status_box = choice(self, row, self.profile_status, tuple(STATUSES), width=20)
        row = line(self, frame)
        self.ttk.Label(row, text="Status text (32 characters):").pack(side="left", padx=4)
        self.status_entry = entry(self, row, self.profile_description, 40)
        row = line(self, frame)
        self.ttk.Label(row, text="Pronouns (32 characters):").pack(side="left", padx=4)
        self.pronouns_entry = entry(self, row, self.profile_pronouns, 40)
        row = line(self, frame); button(self, row, "Review changed fields…", self.update_profile)
        self.ttk.Label(frame, text="Session-only draft. Only changed, returned fields are sent. Unsupported/missing fields stay disabled. These are live profile writes, not local labels. Account changes discard this form. Review shows old and new values; it is not a server-side compare-and-swap guarantee.", wraplength=1000, style="Muted.TLabel").pack(anchor="w", pady=7)
        from account_local_ui import StatusPresets
        self.presets = StatusPresets(self, frame)
        button(self,line(self,frame),'Automatic status rules…',lambda:__import__('status_rules_ui').show(self.shell))

    def history_account(self):
        return self.current_history if self.history_scope.get() == "Selected local account" else account_id(self.app)

    def require_revealed(self):
        if self.private.get():
            raise ValueError("Turn off this page's Privacy view and select again before acting.")
        if self.account != self.context():
            self.cancel(); self.account = self.context(); self.account_changed()
            raise ValueError("The account or session changed. Select again.")

    def refresh_labels(self):
        self.table.set([] if self.private.get() else self.actions.store.accounts(), lambda r: (r["label"], r["role"], r["account"]))

    def account_changed(self):
        if hasattr(self,'retained'):self.retained.account_changed()
        if hasattr(self,'live_profile'):self.live_profile.set('Account observations cleared.')
        for panel in getattr(self,'native_panels',[]):panel.account_changed()
        self.profile_result = None; self.current_history = ""
        self.ref.set(""); self.label.set(""); self.role.set("Other")
        self.caption.set(account_caption(self.app, private=self.private.get()))
        own = account_id(self.app)
        self.active_table.set([{"account": own}] if own and not self.private.get() else [], lambda r: (r["account"], "Active in this process (not revalidated here)"))
        self.refresh_labels(); self.clear_profile()
        if hasattr(self, 'presets'):
            self.presets.refresh()
        if hasattr(self, "owned_avatars"):
            self.owned_avatars.clear()
        if hasattr(self, "history"):
            self.history.refresh(0)

    def privacy_changed(self):
        self.cancel(); self.actions.invalidate(); self.account_changed()

    def close(self):
        if hasattr(self,'retained'):self.retained.clear_candidate()
        for panel in getattr(self,'native_panels',[]):panel.close()
        return super().close()

    def tick(self):
        super().tick()
        if hasattr(self,'live_profile'):
            from automatic_sync import sync_for
            sync=sync_for(self.shell);text=sync.summary();data=sync.self_profile
            if not self.private.get() and not __import__('account_header').private(self.app) and data:
                text=(data.get('displayName') or 'Current account')+' · '+str(data.get('status','Status unavailable'))+' · '+str(data.get('statusDescription',''))+'\nObserved '+sync.self_checked+' · '+text
            self.live_profile.set('Private information hidden' if self.private.get() else text)
        for panel in getattr(self,'native_panels',[]):panel.guard(panel.tick)
        if hasattr(self, 'presets'):
            self.presets.tick()

    def clear_profile(self):
        self.profile_result = None
        self.profile_status.set(""); self.profile_description.set(""); self.profile_pronouns.set("")
        for control in (self.status_box, self.status_entry, self.pronouns_entry):
            control.configure(state="disabled")
        self.profile_text.set("Profile not loaded. Refresh explicitly after revealing this page; no saved draft or automatic request.")

    def selection(self):
        row = self.table.selected()
        if not row or self.private.get():
            self.current_history = ""; return
        self.current_history = row["account"]
        self.ref.set(row["account"]); self.label.set(row["label"]); self.role.set(row["role"])
        if hasattr(self, "history") and self.history_scope.get() == "Selected local account":
            self.history.refresh(0)

    def use_active(self):
        self.require_revealed()
        own = account_id(self.app)
        if not own:
            raise ValueError("No active account ID is available.")
        self.ref.set(own)

    def save_label(self):
        local_writable(self.app); self.require_revealed()
        values = (entity_id("user", self.ref.get()), self.label.get(), self.role.get())
        if not self.confirm("Save local account label", f"Save label {display(values[1])!r} ({values[2]}) for\n{values[0]}?\n\nLocal organization only; no sign-in or network request. This does not establish account ownership."):
            return
        self.require_revealed(); local_writable(self.app)
        if values != (entity_id("user", self.ref.get()), self.label.get(), self.role.get()):
            raise ValueError("The local account form changed. Review again.")
        self.actions.store.save_account(*values)
        self.refresh_labels(); self.status.set("Local label saved. Live session and remembered sign-in unchanged.")

    def forget_label(self):
        local_writable(self.app); self.require_revealed()
        row = self.table.selected()
        if not row:
            raise ValueError("Select a local account label first.")
        if not self.confirm("Forget local account label", "Forget only this label?\n" + row["account"] + "\n\nNo credentials, histories, avatar files or remote accounts are deleted."):
            return
        self.require_revealed(); local_writable(self.app)
        if self.table.selected() is not row:
            raise ValueError("Selection changed. Review again.")
        self.actions.store.forget_account(row["account"])
        self.current_history = ""; self.ref.set(""); self.label.set(""); self.refresh_labels(); self.history.refresh(0)
        self.status.set("Local label forgotten. Connection and other records retained.")

    def connect(self):
        self.require_revealed()
        token = self.context()
        if account_id(self.app) and not self.confirm("Replace the active connection", "This build keeps one active VRC Eye login. Signing in successfully as another account will close the previous session, cancel pending jobs and clear account views. Saved labels and the existing remembered-sign-in settings are separate.\n\nOpen the connection dialog?"):
            return
        if token != self.context():
            raise ValueError("The active account changed. Open the connection dialog again.")
        super().connect()

    def disconnect(self):
        self.require_revealed()
        own = account_id(self.app); token = self.context()
        if not own:
            raise ValueError("No active session to disconnect.")
        if self.confirm("Disconnect current session", "Discard this process's session for\n" + own + "?\n\nPending actions are canceled where possible; already sent actions cannot be undone. Local labels and deliberately remembered sign-in remain. This does not revoke other devices' sessions."):
            if token != self.context():
                raise ValueError("The account changed. Review again.")
            self.app.set_api_client(None)
            self.status.set("Disconnected locally. Saved labels and remembered sign-in are unchanged.")

    def load_profile(self):
        self.require_revealed(); local_writable(self.app)
        self.clear_profile()
        def done(result):
            self.profile_result = result; self.restore_form()
            self.status.set("Own profile snapshot loaded. Nothing was changed on VRChat.")
        self.start(lambda c,s,p: api.read(c, "self-profile", stop=s, progress=p), done)

    def restore_form(self):
        self.require_revealed()
        result = self.profile_result
        if result is None:
            raise ValueError("Refresh your profile first.")
        data = result.data
        for key, variable, widget in (("status", self.profile_status, self.status_box), ("statusDescription", self.profile_description, self.status_entry), ("pronouns", self.profile_pronouns, self.pronouns_entry)):
            value = data.get(key)
            available = value in STATUSES.values() if key == "status" else isinstance(value, str) and len(value) <= 32
            if key == "status":
                value = next((label for label, raw in STATUSES.items() if raw == value), "")
            variable.set(value if available else "")
            widget.configure(state=("readonly" if key == "status" else "normal") if available else "disabled")
        self.profile_text.set("Own profile: " + display(data.get("displayName"), 120) + "\nChecked " + result.checked_at + " · snapshot. Biography and appearance are available in their profile tab.")

    def draft(self):
        result = self.profile_result
        if result is None:
            raise ValueError("Refresh your profile first.")
        values = {}
        data = result.data
        if data.get("status") in STATUSES.values():
            values["status"] = STATUSES.get(self.profile_status.get(), "")
        for key, variable in (("statusDescription", self.profile_description), ("pronouns", self.profile_pronouns)):
            if isinstance(data.get(key), str) and len(data[key]) <= 32:
                values[key] = variable.get()
        return values

    def update_profile(self):
        self.require_revealed()
        values = self.draft(); result = self.profile_result
        def done(outcome):
            self.clear_profile(); self.history.refresh(0); self.status.set(outcome.message)
        submit_review(self, "update-self", result=result, values=values, description="Your own status and pronoun fields",
                      view_guard=lambda: (self.context(), self.private.get(), self.profile_result is result, self.draft()), done=done)
