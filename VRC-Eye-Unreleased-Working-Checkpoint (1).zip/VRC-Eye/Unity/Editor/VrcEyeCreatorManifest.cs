// Explicit, read-only export from your own Worlds project. No private paths or credentials.
#if UNITY_EDITOR
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Data;

public static class VrcEyeCreatorManifest
{
    [MenuItem("Tools/VRC Eye/Export creator helper manifest")]
    private static void Export()
    {
        var selected = Selection.activeGameObject;
        var helper = selected ? selected.GetComponentInParent<VrcEyeCreatorHelper>() : null;
        if (!helper)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Select the VrcEyeCreatorHelper object in your own Worlds scene.", "OK");
            return;
        }
        if (!Regex.IsMatch(helper.worldId ?? "", @"^(?:wrld_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|local:[A-Za-z0-9][A-Za-z0-9_.-]{0,79})$")
            || !Regex.IsMatch(helper.buildId ?? "", @"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}$")
            || helper.midiChannel < 0 || helper.midiChannel > 15)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Set a valid world ID, a unique build ID, and MIDI channel 0–15 first.", "OK");
            return;
        }
        string platform;
        switch (EditorUserBuildSettings.activeBuildTarget)
        {
            case BuildTarget.StandaloneWindows:
            case BuildTarget.StandaloneWindows64: platform = "standalonewindows"; break;
            case BuildTarget.Android: platform = "android"; break;
            case BuildTarget.iOS: platform = "ios"; break;
            default: platform = "other"; break;
        }
        DataDictionary manifest = new DataDictionary();
        manifest.Add("schema", 1);
        manifest.Add("world_id", helper.worldId);
        manifest.Add("build_id", helper.buildId);
        manifest.Add("platform", platform);
        manifest.Add("project_revision", "");
        manifest.Add("notes", "Creator-exported declarations. Export does not prove upload, runtime state, or account authority.");
        DataList controls = new DataList();
        controls.Add(Control(helper, "diagnostic-labels", "Set local diagnostic labels", "toggle", "local", 1,
            "Sets only the assigned local visual labels object. Assign no shared gameplay object.", true,
            "Shared gameplay, other players, and saved progress are unchanged."));
        DataDictionary level = Control(helper, "debug-level", "Set helper diagnostic level", "selection", "helper", 2,
            "Selects Off, Events, or Verbose for this local helper.", true,
            "VRChat launch-time logging settings and other scripts are unchanged.");
        DataList options = new DataList();
        options.Add("Off"); options.Add("Events"); options.Add("Verbose");
        level.Add("options", options);
        controls.Add(level);
        controls.Add(Control(helper, "bookmark", "Record a local test bookmark", "button", "helper", 3,
            "Writes one named local helper log observation.", false, "World state is unchanged."));
        controls.Add(Control(helper, "reset-local-diagnostics", "Reset local helper diagnostics", "button", "helper", 4,
            "Turns off this helper's diagnostic labels and sets its output level to Off.", true,
            "Shared rounds, the instance, other players, and saved progress are unchanged."));
        manifest.Add("controls", controls);
        DataList telemetry = new DataList();
        DataDictionary labelsValue = new DataDictionary();
        labelsValue.Add("id", "diagnostic-labels"); labelsValue.Add("label", "Local labels active");
        labelsValue.Add("unit", "boolean"); labelsValue.Add("scope", "local");
        labelsValue.Add("description", "Reported every 10 seconds at Verbose level, if the labels reference exists.");
        telemetry.Add(labelsValue); manifest.Add("telemetry", telemetry);
        DataList assertions = new DataList();
        DataDictionary assertion = new DataDictionary();
        assertion.Add("id", "local-label-reference");
        assertion.Add("label", "Local diagnostic labels reference exists");
        assertion.Add("scope", "local"); assertion.Add("timing", "every 10 seconds while locally enabled");
        assertion.Add("severity", "warning"); assertion.Add("grace_seconds", 10); assertion.Add("budget_ms", 1);
        assertions.Add(assertion);
        manifest.Add("assertions", assertions);
        manifest.Add("zones", new DataList());
        manifest.Add("contracts", new DataList());
        DataList dependencies = new DataList();
        foreach (var package in UnityEditor.PackageManager.PackageInfo.GetAllRegisteredPackages())
        {
            if (dependencies.Count >= 256)
            {
                EditorUtility.DisplayDialog("VRC Eye", "More than 256 project packages; narrow the inventory explicitly before exporting.", "OK"); return;
            }
            // Package name/version only: never resolvedPath, URLs, Git revision URLs, or package.json contents.
            if (!Regex.IsMatch(package.name ?? "", @"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}$")
                || !Regex.IsMatch(package.version ?? "", @"^[A-Za-z0-9_.+\-]{1,128}$")) continue;
            DataDictionary dependency = new DataDictionary();
            dependency.Add("id", package.name); dependency.Add("version", package.version);
            dependency.Add("owner", ""); dependency.Add("credit", ""); dependency.Add("provenance", "Creator project package registry");
            dependency.Add("documentation", ""); dependency.Add("source_available", false); dependency.Add("tests", new DataList());
            dependencies.Add(dependency);
        }
        manifest.Add("dependencies", dependencies);
        DataDictionary debug = new DataDictionary();
        debug.Add("verbose_logging", false); debug.Add("test_ui", true); debug.Add("world_debugging", "unknown");
        debug.Add("external_dependencies", new DataList()); manifest.Add("debug", debug);
        DataToken json;
        if (!VRCJson.TrySerializeToJson(manifest, JsonExportType.Beautify, out json))
        {
            EditorUtility.DisplayDialog("VRC Eye", "Manifest serialization failed.", "OK"); return;
        }
        byte[] bytes = new UTF8Encoding(false).GetBytes(json.String);
        if (bytes.Length > 256 * 1024)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Manifest exceeds the 256 KiB import limit.", "OK"); return;
        }
        string destination = EditorUtility.SaveFilePanel("Export creator manifest", "", helper.buildId + "-" + platform + "-creator", "json");
        if (string.IsNullOrEmpty(destination)) return;
        try
        {
            File.WriteAllBytes(destination, bytes);
            EditorUtility.DisplayDialog("VRC Eye", "Manifest saved. Import under Primary > World > Controls or Builds.\n\nThis is a declaration, not proof of the loaded build. Add your own semantic contracts and attribution records before comparing builds.", "OK");
        }
        catch (Exception error)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Could not save the manifest: " + error.Message, "OK");
        }
    }

    private static DataDictionary Control(VrcEyeCreatorHelper helper, string id, string label, string type,
        string scope, int number, string description, bool retrySafe, string unchanged)
    {
        DataDictionary row = new DataDictionary();
        row.Add("id", id); row.Add("label", label); row.Add("type", type); row.Add("scope", scope);
        row.Add("description", description); row.Add("retry_safe", retrySafe); row.Add("test_only", true);
        row.Add("state_available", type != "button"); row.Add("requirements", new DataList());
        DataList affected = new DataList(); affected.Add("local creator helper"); row.Add("affected_systems", affected);
        row.Add("leaves_unchanged", unchanged);
        if (helper.allowLocalMidi)
        {
            DataDictionary midi = new DataDictionary(); midi.Add("channel", helper.midiChannel); midi.Add("number", number);
            row.Add("midi", midi);
        }
        return row;
    }
}
#endif
