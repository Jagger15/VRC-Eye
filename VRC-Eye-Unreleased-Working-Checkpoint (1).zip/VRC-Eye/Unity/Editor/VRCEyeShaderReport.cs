// Read-only inspection of renderer materials in your own Unity avatar project.
// Does not download avatars, modify materials, or scan the VRChat client.
#if UNITY_EDITOR
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using VRC.Core;
using VRC.SDK3.Avatars.Components;

public static class VRCEyeShaderReport
{
    [MenuItem("Tools/VRC Eye/Export shader report")]
    private static void Export()
    {
        var selected = Selection.activeGameObject;
        var avatar = selected ? selected.GetComponentInParent<VRCAvatarDescriptor>() : null;
        if (!avatar)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Select an avatar root or an object inside it.", "OK");
            return;
        }
        var pipeline = avatar.GetComponent<PipelineManager>();
        string id = pipeline ? pipeline.blueprintId : "";
        if (string.IsNullOrEmpty(id) || !Regex.IsMatch(id, @"^avtr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
        {
            EditorUtility.DisplayDialog("VRC Eye", "This avatar needs its uploaded avtr_ blueprint ID to match a report in VRC Eye.", "OK");
            return;
        }
        string platform;
        switch (EditorUserBuildSettings.activeBuildTarget)
        {
            case BuildTarget.StandaloneWindows:
            case BuildTarget.StandaloneWindows64: platform = "PC"; break;
            case BuildTarget.Android: platform = "Android"; break;
            case BuildTarget.iOS: platform = "iOS"; break;
            default:
                EditorUtility.DisplayDialog("VRC Eye", "Select a Windows, Android, or iOS build target first.", "OK");
                return;
        }
        var output = new StringBuilder("format,avatar_id,platform,captured_at,renderer,material,shader\r\n");
        string stamp = DateTime.UtcNow.ToString("o");
        int count = 0;
        foreach (var renderer in avatar.GetComponentsInChildren<Renderer>(true))
        {
            string path = AnimationUtility.CalculateTransformPath(renderer.transform, avatar.transform);
            if (string.IsNullOrEmpty(path)) path = "(avatar root)";
            var materials = renderer.sharedMaterials;
            for (int slot = 0; slot < materials.Length; slot++)
            {
                if (++count > 5000)
                {
                    EditorUtility.DisplayDialog("VRC Eye", "This report exceeds the 5,000-slot limit.", "OK");
                    return;
                }
                var material = materials[slot];
                output.AppendLine(string.Join(",", new[] {
                    Cell("VRC-Eye-Shaders-1"), Cell(id), Cell(platform), Cell(stamp),
                    Cell(path + " [" + renderer.GetType().Name + " slot " + slot + "]"),
                    Cell(material ? material.name : "(missing material)"),
                    Cell(material && material.shader ? material.shader.name : "Unknown") }));
            }
        }
        if (count == 0)
        {
            EditorUtility.DisplayDialog("VRC Eye", "No renderer material slots were found.", "OK");
            return;
        }
        byte[] bytes = new UTF8Encoding(false).GetBytes(output.ToString());
        if (bytes.Length > 2 * 1024 * 1024)
        {
            EditorUtility.DisplayDialog("VRC Eye", "The report exceeds the 2 MiB limit.", "OK");
            return;
        }
        string destination = EditorUtility.SaveFilePanel("Export VRC Eye shader report", "", id + "-" + platform + "-shaders", "csv");
        if (string.IsNullOrEmpty(destination)) return;
        try
        {
            File.WriteAllBytes(destination, bytes);
            EditorUtility.DisplayDialog("VRC Eye", "Shader report saved. Import it in Performance & Shader Watch.\n\nIncludes inactive renderers; excludes animation swaps and build-time changes.", "OK");
        }
        catch (Exception error)
        {
            EditorUtility.DisplayDialog("VRC Eye", "Could not save the report: " + error.Message, "OK");
        }
    }

    private static string Cell(string value)
    {
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
#endif
