// VRC Eye 1.13.0. Editor-only setup for the VRChat Avatars SDK 3.10.5+.
// Copy into Assets/VRCEye/Editor. No custom runtime script is uploaded.
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.Core;
using VRC.Dynamics;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDK3.Dynamics.Constraint.Components;

public sealed class VRCEyeRangefinderSetup : EditorWindow
{
    private const string RigName = "AWRangeRig";
    private const string Hit = "AWRange_Hit";
    private const string Ratio = "AWRange_Ratio";
    private const string Heartbeat = "AWRange_Heartbeat";
    private const float RayLength = 100f;
    private VRCAvatarDescriptor source;
    private int anchorChoice;
    private string resultMessage = "";

    [MenuItem("Tools/VRC Eye/Set up pointing rangefinder")]
    public static void Open()
    {
        var window = GetWindow<VRCEyeRangefinderSetup>("VRC Eye setup");
        window.minSize = new Vector2(440, 290);
        if (Selection.activeGameObject != null)
            window.source = Selection.activeGameObject.GetComponentInParent<VRCAvatarDescriptor>();
    }

    private void OnGUI()
    {
        EditorGUILayout.LabelField("Pointing rangefinder", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Creates a separate avatar copy, copies its FX controller and expression parameters, and adds a local rangefinder. The copy's blueprint ID is cleared for a new upload. No upload is started.", MessageType.Info);
        source = (VRCAvatarDescriptor)EditorGUILayout.ObjectField("Scene avatar", source, typeof(VRCAvatarDescriptor), true);
        anchorChoice = EditorGUILayout.Popup("Point with", anchorChoice, new[] { "Right hand", "Left hand", "Head (desktop or VR)" });
        EditorGUILayout.LabelField("Ray length: 100 meters (328.1 feet)");
        EditorGUILayout.HelpBox("Measures the first remote Player-layer collider along the ray. It does not identify usernames. The marker is visible only on your local avatar. Test alignment before uploading.", MessageType.None);
        using (new EditorGUI.DisabledScope(source == null || EditorApplication.isPlaying))
            if (GUILayout.Button("Create rangefinder avatar copy")) CreateCopy();
        if (!string.IsNullOrEmpty(resultMessage))
            EditorGUILayout.HelpBox(resultMessage, MessageType.Info);
    }

    private void CreateCopy()
    {
        GameObject copy = null;
        string folder = null;
        try
        {
            if (source == null || EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid())
                throw new InvalidOperationException("Choose an avatar instance in a scene, not a project prefab asset.");
            if (source.transform.Find(RigName) != null)
                throw new InvalidOperationException("This avatar already has AWRangeRig. Start with the original avatar, or use its existing setup.");
            var animator = source.GetComponent<Animator>();
            if (animator == null || !animator.isHuman)
                throw new InvalidOperationException("This helper needs a humanoid avatar with a configured Animator.");
            if (LayerMask.NameToLayer("Player") != 9 || LayerMask.NameToLayer("PlayerLocal") != 10)
                throw new InvalidOperationException("Set up VRChat's project layers in the SDK first. Player must be layer 9 and PlayerLocal layer 10.");
            if (source.baseAnimationLayers == null || !source.baseAnimationLayers.Any(x => x.type == VRCAvatarDescriptor.AnimLayerType.FX))
                throw new InvalidOperationException("The avatar has no FX layer entry. Check its Avatar Descriptor setup.");

            const string parent = "Assets/VRCEyeGenerated";
            if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", "VRCEyeGenerated");
            string unique = AssetDatabase.GenerateUniqueAssetPath(parent + "/Rangefinder");
            string guid = AssetDatabase.CreateFolder(parent, System.IO.Path.GetFileName(unique));
            folder = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(folder)) throw new InvalidOperationException("Could not create the generated-assets folder.");

            copy = Instantiate(source.gameObject, source.transform.parent);
            copy.name = source.name + " - VRC Eye rangefinder";
            var descriptor = copy.GetComponent<VRCAvatarDescriptor>();
            var copyAnimator = copy.GetComponent<Animator>();
            var boneType = anchorChoice == 0 ? HumanBodyBones.RightHand : anchorChoice == 1 ? HumanBodyBones.LeftHand : HumanBodyBones.Head;
            Transform bone = copyAnimator.GetBoneTransform(boneType);
            if (bone == null) throw new InvalidOperationException("The selected hand/head bone is missing on this avatar.");

            var rig = new GameObject(RigName);
            rig.transform.SetParent(copy.transform, false);
            rig.transform.SetPositionAndRotation(bone.position, bone.rotation);
            var follow = rig.AddComponent<VRCParentConstraint>();
            follow.TargetTransform = rig.transform;
            follow.Sources = new VRCConstraintSourceKeyableList(new[] { new VRCConstraintSource(bone, 1f) });
            follow.GlobalWeight = 1f;
            follow.IsActive = true;
            follow.Locked = true;
            follow.SolveInLocalSpace = false;
            follow.FreezeToWorld = false;
            follow.AffectsPositionX = follow.AffectsPositionY = follow.AffectsPositionZ = true;
            follow.AffectsRotationX = follow.AffectsRotationY = follow.AffectsRotationZ = true;
            follow.ApplyConfigurationChanges();

            Vector3 direction = copy.transform.forward;
            if (anchorChoice != 2)
            {
                var finger = copyAnimator.GetBoneTransform(anchorChoice == 0 ? HumanBodyBones.RightMiddleProximal : HumanBodyBones.LeftMiddleProximal);
                if (finger != null && (finger.position - bone.position).sqrMagnitude > 0.000001f)
                    direction = (finger.position - bone.position).normalized;
            }
            var emitter = new GameObject("Emitter - aim its blue Z axis");
            emitter.transform.SetParent(rig.transform, false);
            Vector3 origin = anchorChoice == 2 ? copy.transform.TransformPoint(descriptor.ViewPosition) : bone.position;
            Vector3 up = Mathf.Abs(Vector3.Dot(direction, copy.transform.up)) > 0.99f ? copy.transform.right : copy.transform.up;
            emitter.transform.SetPositionAndRotation(origin + direction * 0.03f, Quaternion.LookRotation(direction, up));
            var result = new GameObject("Hit result");
            result.transform.SetParent(rig.transform, false);

            var ray = emitter.AddComponent<VRCRaycast>();
            ray.RootTransform = emitter.transform;
            ray.RaycastDirection = Vector3.forward;
            ray.Distance = RayLength;
            ray.ApplyTransformScale = false;
            ray.RaycastCollisionMode = VRCRaycast.CollisionMode.HitCustomLayers;
            ray.CustomCollisionLayers = 1 << 9; // Remote Player only; exclude the local capsule and world geometry.
            ray.ResultTransform = result.transform;
            ray.ApplyRotation = false;
            ray.BehaviorOnMiss = VRCRaycast.MissBehavior.SnapToStart;
            ray.Parameter = "AWRange";

            AddMarker(emitter, folder);
            AnimatorController fx = CopyFX(descriptor, folder);
            AddParameter(fx, Hit, AnimatorControllerParameterType.Bool);
            AddParameter(fx, Ratio, AnimatorControllerParameterType.Float);
            AddParameter(fx, Heartbeat, AnimatorControllerParameterType.Float);
            AddParameter(fx, "IsLocal", AnimatorControllerParameterType.Bool, false);
            AddHeartbeatLayer(fx, folder);
            CopyExpressions(descriptor, folder);
            rig.SetActive(false); // The IsLocal state enables it on the wearer only.

            var pipeline = copy.GetComponent<PipelineManager>();
            if (pipeline != null) pipeline.blueprintId = "";
            copy.SetActive(true);
            EditorUtility.SetDirty(descriptor);
            EditorUtility.SetDirty(fx);
            AssetDatabase.SaveAssets();
            Undo.RegisterCreatedObjectUndo(copy, "Create VRC Eye rangefinder copy");
            Undo.RecordObject(source.gameObject, "Disable original avatar for testing");
            source.gameObject.SetActive(false);
            EditorSceneManager.MarkSceneDirty(copy.scene);
            Selection.activeGameObject = emitter;
            resultMessage = "Created the copy and assets in " + folder + ". Original avatar is disabled, not deleted. Inspect the emitter direction, test the heartbeat and hit values, then upload the copy. Read RANGEFINDER_SETUP.md.";
        }
        catch (Exception error)
        {
            if (copy != null) DestroyImmediate(copy);
            if (!string.IsNullOrEmpty(folder)) AssetDatabase.DeleteAsset(folder);
            resultMessage = "Setup stopped: " + error.Message;
            Debug.LogException(error);
        }
    }

    private static AnimatorController CopyFX(VRCAvatarDescriptor descriptor, string folder)
    {
        var layers = descriptor.baseAnimationLayers;
        int index = Array.FindIndex(layers, x => x.type == VRCAvatarDescriptor.AnimLayerType.FX);
        var old = layers[index];
        string destination = folder + "/FX.controller";
        AnimatorController fx;
        if (descriptor.customizeAnimationLayers && !old.isDefault && old.animatorController != null)
        {
            var original = old.animatorController as AnimatorController;
            if (original == null) throw new InvalidOperationException("Animator Override Controllers are not supported by this helper. Use a standard FX AnimatorController.");
            string path = AssetDatabase.GetAssetPath(original);
            if (string.IsNullOrEmpty(path) || !AssetDatabase.CopyAsset(path, destination))
                throw new InvalidOperationException("Could not copy the FX controller. Save it as a project asset first.");
            fx = AssetDatabase.LoadAssetAtPath<AnimatorController>(destination);
        }
        else fx = AnimatorController.CreateAnimatorControllerAtPath(destination);
        if (fx == null) throw new InvalidOperationException("Could not create the FX controller copy.");
        if (fx.layers.Any(x => x.name == "VRC Eye rangefinder" || x.name == "AvatarWatch rangefinder"))
            throw new InvalidOperationException("The FX controller already contains an VRC Eye layer.");
        old.animatorController = fx;
        old.isDefault = false;
        old.isEnabled = true;
        layers[index] = old;
        descriptor.baseAnimationLayers = layers;
        descriptor.customizeAnimationLayers = true;
        return fx;
    }

    private static void AddParameter(AnimatorController fx, string name, AnimatorControllerParameterType type, bool reserved = true)
    {
        var existing = fx.parameters.FirstOrDefault(x => x.name == name);
        if (existing != null)
        {
            if (reserved || existing.type != type)
                throw new InvalidOperationException("Parameter conflict: " + name + ". Start from an avatar without an earlier rangefinder setup.");
            return;
        }
        fx.AddParameter(name, type);
    }

    private static void AddHeartbeatLayer(AnimatorController fx, string folder)
    {
        var active = new AnimationClip { name = "Rangefinder local clock", frameRate = 30 };
        var inactive = new AnimationClip { name = "Rangefinder remote off", frameRate = 30 };
        // Values change continuously; a motionless ray still has a live heartbeat.
        active.SetCurve("", typeof(Animator), Heartbeat, new AnimationCurve(
            new Keyframe(0, 0.1f), new Keyframe(0.5f, 0.9f), new Keyframe(1f, 0.1f)));
        active.SetCurve(RigName, typeof(GameObject), "m_IsActive", AnimationCurve.Constant(0, 1, 1));
        inactive.SetCurve(RigName, typeof(GameObject), "m_IsActive", AnimationCurve.Constant(0, 1, 0));
        inactive.SetCurve("", typeof(Animator), Heartbeat, AnimationCurve.Constant(0, 1, 0));
        var settings = AnimationUtility.GetAnimationClipSettings(active);
        settings.loopTime = true;
        AnimationUtility.SetAnimationClipSettings(active, settings);
        AssetDatabase.CreateAsset(active, folder + "/Clock.anim");
        AssetDatabase.CreateAsset(inactive, folder + "/RemoteOff.anim");
        fx.AddLayer("VRC Eye rangefinder");
        var layers = fx.layers;
        var layer = layers[layers.Length - 1];
        layer.defaultWeight = 1;
        var remote = layer.stateMachine.AddState("Remote off");
        var local = layer.stateMachine.AddState("Local measuring");
        remote.motion = inactive;
        local.motion = active;
        remote.writeDefaultValues = local.writeDefaultValues = false;
        layer.stateMachine.defaultState = remote;
        var enter = remote.AddTransition(local);
        enter.hasExitTime = false;
        enter.duration = 0;
        enter.AddCondition(AnimatorConditionMode.If, 0, "IsLocal");
        var exit = local.AddTransition(remote);
        exit.hasExitTime = false;
        exit.duration = 0;
        exit.AddCondition(AnimatorConditionMode.IfNot, 0, "IsLocal");
        layers[layers.Length - 1] = layer;
        fx.layers = layers;
    }

    private static void CopyExpressions(VRCAvatarDescriptor descriptor, string folder)
    {
        var parameters = descriptor.expressionParameters != null ? Instantiate(descriptor.expressionParameters)
            : ScriptableObject.CreateInstance<VRCExpressionParameters>();
        AssetDatabase.CreateAsset(parameters, folder + "/Parameters.asset");
        var entries = new List<VRCExpressionParameters.Parameter>(parameters.parameters ?? new VRCExpressionParameters.Parameter[0]);
        foreach (string name in new[] { Hit, Ratio, Heartbeat })
        {
            if (entries.Any(x => x != null && x.name == name))
                throw new InvalidOperationException("Expression parameter conflict: " + name);
            entries.Add(new VRCExpressionParameters.Parameter { name = name,
                valueType = name == Hit ? VRCExpressionParameters.ValueType.Bool : VRCExpressionParameters.ValueType.Float,
                saved = false, networkSynced = false, defaultValue = 0 });
        }
        parameters.parameters = entries.ToArray();
        if (parameters.parameters.Length > VRCExpressionParameters.MAX_PARAMETER_COUNT || parameters.CalcTotalCost() > VRCExpressionParameters.MAX_PARAMETER_COST)
            throw new InvalidOperationException("The copied avatar exceeds the SDK expression-parameter limit.");
        descriptor.expressionParameters = parameters;
        descriptor.customExpressions = true;
        if (descriptor.expressionsMenu == null)
        {
            var menu = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
            menu.controls = new List<VRCExpressionsMenu.Control>();
            AssetDatabase.CreateAsset(menu, folder + "/Menu.asset");
            descriptor.expressionsMenu = menu;
        }
        EditorUtility.SetDirty(parameters);
    }

    private static void AddMarker(GameObject emitter, string folder)
    {
        Shader shader = Shader.Find("Unlit/Color");
        if (shader == null) throw new InvalidOperationException("The Unity Unlit/Color shader is missing.");
        var material = new Material(shader) { name = "VRC Eye cyan marker", color = new Color(0.2f, 1f, 0.8f, 1f) };
        AssetDatabase.CreateAsset(material, folder + "/Marker.mat");
        var line = emitter.AddComponent<LineRenderer>();
        line.sharedMaterial = material;
        line.useWorldSpace = false;
        line.positionCount = 2;
        line.SetPosition(0, Vector3.zero);
        line.SetPosition(1, Vector3.forward * 0.3f);
        line.startWidth = 0.003f;
        line.endWidth = 0.001f;
        line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        line.receiveShadows = false;
    }
}
#endif
