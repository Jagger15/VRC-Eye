using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.PackageManager;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace VrcEye.EditorCore
{
    // Editor-only and explicitly invoked: no InitializeOnLoad, update loop,
    // sockets, credentials, scene mutations, build dispatch or publishing hooks.
    [Serializable] public sealed class EyePackageSnapshot
    {
        public string name;
        public string version;
        public string source;
    }

    [Serializable] public sealed class EyeEditorSnapshot
    {
        public int schema = 1;
        public string product = "VRC Eye Editor Core";
        public string created_utc;
        public string unity_version;
        public string active_build_target;
        public bool compiling;
        public bool playing;
        public int selected_objects;
        public int dirty_scenes;
        public int package_count;
        public bool packages_truncated;
        public EyePackageSnapshot[] packages;
    }

    public sealed class EyeProjectSnapshotWindow : EditorWindow
    {
        private string preview = "Use Capture local snapshot to inspect the current editor state.";
        private Vector2 scroll;
        private bool hasSnapshot;

        [MenuItem("Tools/VRC Eye/Local Project Snapshot")]
        public static void OpenWindow()
        {
            GetWindow<EyeProjectSnapshotWindow>("VRC Eye · Local Snapshot");
        }

        public static EyeEditorSnapshot Capture()
        {
            var report = new EyeEditorSnapshot
            {
                created_utc = DateTime.UtcNow.ToString("o"),
                unity_version = Application.unityVersion,
                active_build_target = EditorUserBuildSettings.activeBuildTarget.ToString(),
                compiling = EditorApplication.isCompiling,
                playing = EditorApplication.isPlaying,
                selected_objects = Math.Min(100000, Selection.objects.Length)
            };
            for (int i = 0; i < Math.Min(512, SceneManager.sceneCount); i++)
            {
                if (SceneManager.GetSceneAt(i).isDirty) report.dirty_scenes++;
            }
            var installed = PackageInfo.GetAllRegisteredPackages() ?? new PackageInfo[0];
            Array.Sort(installed, (a, b) => StringComparer.Ordinal.Compare(a.name, b.name));
            report.package_count = Math.Min(100000, installed.Length);
            var rows = new List<EyePackageSnapshot>();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var package in installed)
            {
                if (rows.Count >= 256) break;
                if (!Regex.IsMatch(package.name ?? "", @"\A[a-z0-9][a-z0-9._-]{1,159}\z") ||
                    !Regex.IsMatch(package.version ?? "", @"\A[0-9A-Za-z.+-]{1,80}\z") ||
                    !seen.Add(package.name)) continue;
                rows.Add(new EyePackageSnapshot
                {
                    name = package.name,
                    version = package.version,
                    source = package.source.ToString()
                });
            }
            report.packages_truncated = installed.Length != rows.Count;
            report.packages = rows.ToArray();
            return report;
        }

        private void OnGUI()
        {
            EditorGUILayout.HelpBox(
                "Development preview. Captures local editor/package state only. No project paths, " +
                "object names, account IDs, credentials or raw logs are exported. This is not proof " +
                "of successful compilation, SDK compatibility, a build or an upload.", MessageType.Info);
            if (GUILayout.Button("Capture local snapshot"))
            {
                try
                {
                    preview = JsonUtility.ToJson(Capture(), true);
                    hasSnapshot = Encoding.UTF8.GetByteCount(preview) <= 128 * 1024;
                    if (!hasSnapshot) preview = "Snapshot exceeded the supported size. Nothing exported.";
                }
                catch (Exception)
                {
                    hasSnapshot = false;
                    preview = "Editor snapshot unavailable. No project data was changed.";
                }
            }
            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.TextArea(preview, GUILayout.ExpandHeight(true));
            EditorGUILayout.EndScrollView();
            using (new EditorGUI.DisabledScope(!hasSnapshot))
            {
                if (GUILayout.Button("Review and export JSON…")) Export();
            }
        }

        private void Export()
        {
            if (!EditorUtility.DisplayDialog("Export local editor report?",
                "The report includes package names/versions, Unity version, build-target label, " +
                "editor state, counts and time. No paths, object names, credentials or raw logs. " +
                "Review the displayed report before sharing it.", "Choose new file", "Cancel")) return;
            string path = EditorUtility.SaveFilePanel("Save new VRC Eye report", "", "VRC-Eye-Editor-Report", "json");
            if (String.IsNullOrEmpty(path)) return;
            try
            {
                using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(preview);
            }
            catch (IOException)
            {
                EditorUtility.DisplayDialog("Report not saved", "Choose a new, writable filename. Existing files are never overwritten.", "OK");
            }
            catch (UnauthorizedAccessException)
            {
                EditorUtility.DisplayDialog("Report not saved", "The selected destination is not writable.", "OK");
            }
        }
    }
}
