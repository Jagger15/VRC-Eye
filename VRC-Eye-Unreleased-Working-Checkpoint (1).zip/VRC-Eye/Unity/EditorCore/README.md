# VRC Eye Editor Core — development preview 1.20.0

Editor-only local snapshot exporter. This package contains original VRC Eye code, not code or binaries from the uploaded ARC application. It uses UnityEditor APIs, not the VRChat API. It does not open a listener, pair devices, run remote commands, alter scenes, restore dependencies, build, upload, or collect account information.

**Native Unity compilation and EditMode testing have not been performed in this build environment.** The package targets the Unity 2022.3 editor API. The desktop tests validate package structure and the report contract, not Unity compilation.

After separately reviewing/trusting the package, extract its ZIP into a local package folder. In Unity's Package Manager, add its `package.json` using the local-package workflow. Package import executes editor code; this is a deliberate user action, not something VRC Eye does automatically. The export ZIP is VPM-shaped package content, not a published VCC repository or an automatically installable remote listing.

Open **Tools → VRC Eye → Local Project Snapshot**. Capture a snapshot, review its text, then export to a new JSON filename. Import the report from VRC Eye's **Creator Projects → Templates & tools**. Desktop association is manual and unauthenticated, so importing a file never replaces independently inspected manifest evidence.

The core package has no VRChat SDK dependency. The separate existing `Unity/AvatarToolkit` package retains its own version and bounded avatar SDK requirement. A world extension, live paired helper, build/test automation and a public package repository remain separate work; they are not implied by this exporter.
