# VRC Eye Avatar Toolkit — unreleased Development 30 source candidate

The original **VRC Eye → Avatar Repair Copies** editor tools are described in the
[Development 8 guide](../../ARC_FEATURES_1_20_DEV8.md). They add material shader
replacement, missing-normal mesh repair, animation-path remapping and missing-script
prefab cleanup on separate copies, plus bounded OBJ export. The editor code has
not been compiled or run in Unity here. The original module/manifest contract
remains version 1.19.3.

The optional package in `Unity/AvatarToolkit` authors a selected avatar in your own Unity project. The desktop creator workspace works without Unity. This package is experimental: the release's Python checks inspect contracts; they do not compile Unity C#, build an avatar, or verify Contacts, OSC, rendering, shaders, or an uploaded avatar.

## Install locally

1. Back up the project or commit it to source control. Use a separate test copy for this experimental package.
2. Open an existing VRChat **Avatars** project in its supported Unity editor. The authoring target is SDK **3.10.x** and Unity **2022.3**. The tool checks the installed SDK and probes required serialized fields before applying changes; it does not upgrade packages. Compatibility with every patch is not asserted as tested.
3. Copy `Unity/AvatarToolkit` to `Packages/com.vrceye.avatar-toolkit` as an embedded local package, or use Package Manager's **Add package from disk** and select its `package.json`. Its `vpmDependencies` records the SDK dependency for VPM tooling. This release does not publish a VPM repository/download URL and does not invent author contact details; local installation requires the SDK already installed through Creator Companion.
4. Open **VRC Eye → Avatar Toolkit**. Select the avatar's root descriptor in a **saved scene**, confirm permission, and choose an anchor inside that avatar. Left wrist, right wrist and chest buttons suggest humanoid anchors; generic rigs use a manual transform. Position, orientation, visual size and touch radius are separate controls.
5. Choose modules and press **Analyze and preview proposed changes**. Review parameters, costs and the exact change policy, then **Install reviewed plan**. Save the scene after installation.

There is no custom runtime script attached to avatars, no client modification, no uploader, no blueprint-ID detachment, no automatic SDK change, and no remote editor listener. This first backend creates explicit source assets; it does not register an NDMF/Modular Avatar build pass. Projects using those processors must validate their actual generated output and rename mappings independently.

## Unreleased SDK performance report exporter

After installing this local package, open **VRC Eye → Avatar Performance Report**.
Select a scene avatar root with its existing SDK blueprint ID, choose the intended
Unity build target, and capture. Review the displayed snapshot, export to a new
JSON file, then open **Avatar Library → Details & Builds → Performance reports**
in Eye. No avatar module installation or installation journal is needed.

The exporter calls the installed SDK's public source-performance calculator using
its exact supported signature. It records the Avatars and Base package versions,
Unity version, platform and capture time. Unsupported signatures stop capture;
absent counters remain unknown. Download/uncompressed build size and final rank
remain unknown because source analysis precedes build processors. Recapture after
editing the avatar, packages or target. Comparison requires matching source/build
stage and SDK/Unity context. No upload, runtime hook or source edit is performed.

This pending C# implementation and its included EditMode tests have not been
compiled or run in Unity here. Validate it in a test project before relying on its
measurements. It is retained under the Development 30 release hold.

## Autonomous completion additions (native qualification pending)

These source additions have not been compiled or run in Unity. Run the supplied
EditMode fixtures in a separate Unity 2022.3 project before using them on production assets.
The application build identity and package compatibility contract remain unchanged.

| Menu | Reviewed action | Boundary |
| --- | --- | --- |
| Avatar Repair Copies | Generate missing tangents on a separate mesh | Requires valid normals/UV0; verifies skin, blendshape, topology and slot correspondence |
| Typed Material Mapping | Map declared properties, texture transforms, keywords and optional render queue | Exact shader, pipeline and build-target identities; explicit dropped properties; separate material |
| Typed Material Mapping → Compile and save diagnostic observation | Export current material pass results with exact context and fingerprints | Current editor variants only; other platforms require separate builds |
| Controller Dependency Copies | Copy controller, clip and mask closure; optionally replace a clip | Retains serialized layers/transitions/parameters; ambiguous IDs, cycles and conflicting parameter names stop the operation |
| Animation Binding Copies | Map every float/object binding to a selected prefab property; replace selected object-curve asset values | Unity-reported animatable targets and serialized reference types; preserved keyframes/events; no playback or automatic assignment |
| Component Graph and Copies | Inspect serialized references and add an allowlisted component to a separate prefab | Explicit hierarchy reference maps, declared required components, unique save identities and save/reload checks |
| Repair Copy History | Inspect durable operation phases and per-output hashes | No automatic replay, deletion or assignment; partial outputs remain available |

Native copy receipts live in the project's `Library/VrcEyeCopyHistory` folder.
They survive editor/domain reload, but clearing Library removes this local history.
Preserve a VRC Eye recovery workspace checkpoint before cleanup. The desktop's
conditional content undo preserves edited or referenced assets; Unity Undo is not
an asset-file rollback mechanism. Directory metadata and empty directories are
outside content undo. Review imported scripts before opening a project copy.

The desktop Recovery Journal additionally supports reviewed Assets-only shader ZIP
installation and removal. Install receipts contain file identities and before/after
diffs; compilation remains explicitly `not_run` until independently measured in
Unity. Save the current-material diagnostic JSON for that project and target; a
successful file installation alone does not establish shader compatibility.

## Development 8 repair copies

The repair window is separate from the original **Avatar Toolkit** authoring window.
After installation, open **VRC Eye → Avatar Repair Copies**, select the source root
and an asset you own or are authorized to modify, and confirm your permission.
Use **Scan selected root (read-only)**, choose the operation and exact settings,
then **Prepare copy and review changes**. Approve only the displayed operation.
Reviews expire after five minutes and source changes require another review.

Material, mesh, animation and prefab outputs use a fresh folder under
`Assets/VRC Eye Repairs`. Existing renderer/controller assignments are retained;
inspect and assign the new assets manually. Prefab cleanup requires a saved
`.prefab` asset, unpacks copied prefab links and removes missing components only
on that copy. It does not reconstruct their scripts or behavior. A failed operation
can leave a partial new output for inspection. Existing project editor/import
callbacks may run, so use a trusted project copy.

The OBJ operation exports one referenced mesh to a new `.obj` file you select. It uses
mesh-local geometry; a skinned mesh stays in source/bind pose. The export has the
desktop viewer's 16 MiB, 20,000-vertex and 8,000-triangle limits. It does not export
rigs, blendshapes, materials, textures or animation, and it refuses existing output
files. This editor source is neither an ARC/AssetRipper integration nor a bundle
extractor. See the Development 8 guide for each operation's limits.

## Included finite authoring modules

| Module | Generated authoring behavior |
| --- | --- |
| Wrist | Adjustable rigid primitive shell; does not animate the rig. |
| Status | Small finite-state symbols for selected presentation, separate from VRChat account status. |
| Safety | Self-only local Contact and expression-menu request button, plus independently reported applied-profile indicator. |
| Battery | Normalized meter and a separate validity/unknown representation. |
| Streamer | Finite recording state and source validity, not process-detection claims. |
| Music | Bounded, non-flashing meter driven by normalized selected-source intensity. No Unity audio capture. |
| Camera | Local shutter-request Contact/menu button and separate touch/acceptance feedback. Acceptance is not capture completion. |
| Availability | Manual quiet toggle and distinct read-only native AFK indicator. Neither sets native VRChat DND. |
| Connection | Changing heartbeat with an initial unconfirmed state and approximately five-second animator timeout. |
| Hardware | Normalized provider meter plus validity; no device identifiers. |
| Resource | Finite observed pressure warning plus validity; no attribution of blame. |
| Media | Finite playback-state indicator plus validity; no track names or paths. |

These are functional primitive starter modules, not polished commissioned prefab art or universal integrations. Source materials use the SDK's `VRChat/Mobile/Diffuse` shader. Missing required shaders/components stop installation. The same parameter layout can be exported for Windows, Android and iOS, but choosing a platform label does not prove a platform build passed.

All generated custom parameters default to **unsaved, unsynchronized, private** and zero/false. Manual `EYE_In_Quiet` is a non-ephemeral preference eligible for reviewed local presets; provider state, heartbeat and requests remain ephemeral. The original expression ordering is preserved and new definitions are appended. A changing-heartbeat dependency is always included; provider visuals and reported action feedback become hidden when that heartbeat expires. Manual controls and native AFK remain available. Validity flags further distinguish missing data from a measured zero while the link is fresh. Animator culling or suspension can prevent the timeout from evaluating: these are best-effort displays, never authenticated safety signals.

Generated displays are gated by the built-in read-only `IsLocal` parameter. Test actual local, remote, mirror, photo and capture paths before relying on presentation privacy. Unsynchronized parameters alone do not establish owner-only rendering. Your own recording can still capture a local display. The toolkit does not expose a public-data toggle; deliberate public variants require a reviewed creator-authored contract.

## Contact and expression-menu controls

Contacts are **Constant** receivers with `allowSelf=true`, `allowOthers=false`, `localOnly=true`, collision tag `Finger`, and an independently configured radius. Local Only and Self Only are distinct settings. Contact tags do not authenticate a person. The `EYE_Out_Camera` and `EYE_Out_Safety` Boolean requests remain high while touched; they are not next-frame `OnEnter` pulses. The broker must verify routing and apply hold/debounce, rising-edge detection, cooldown and release-to-rearm. A held contact must not repeatedly take photos. The matching expression-menu buttons are accessible alternatives.

The visible states mean touch detected and broker acceptance/applied report. There is no fabricated acknowledgment or capture completion. `EYE_In_CameraAccepted` declares semantic `accepted_request:request_photo` and is acceptance only. `EYE_In_SafetyApplied` declares semantic `applied_profile:safety_profile` and reports the configured companion profile, not a claim that VRChat's safety policy changed. If entering a safety profile disarms Avatar Link before feedback is sent, the avatar-side result remains unconfirmed. All external actions remain subject to VRC Eye's local grants and capabilities.

## Installation, update, undo and recovery

The installer clones the expression parameter asset, root expression menu and assigned FX controller into `Assets/VRC Eye Generated/<installation-id>`. Original source assets and original controller layers are retained. New state machines animate only generated descendants and set Write Defaults only for their own new states. Existing Write Defaults are not rewritten. A full original root menu becomes an **Original menu** submenu of a new wrapper; generated pages are bounded to eight entries.

Colliding expression/FX names fail the reviewed plan. The tool never coerces types, guesses semantic equivalence or silently overwrites an unrelated definition. All twelve starter modules consume zero additional synchronized bits; the existing avatar must still fit the documented 256-bit / 8192-custom-parameter limits. Reinstalling an active journal is blocked. The initial explicit update path is: inspect/export → remove unchanged installation → review replacement installation. No untested in-place merge is claimed.

Each installation records original and installed references, stable identity, an avatar-relative owned-root locator (scene references are not persisted in assets), ownership, asset dependency hashes, generated-object fingerprints and a local `before-descriptor.json` backup. The backup stays inside the project and can contain source information; it is never part of the sanitized manifest. On failure, the installer restores descriptor references and removes its newly created scene root while retaining generated assets and the failure journal for inspection.

**Remove unchanged installation using journal** restores recorded references only when the selected descriptor, generated hierarchy and owned assets still match. Any intervening edits stop automatic removal. Generated assets are deliberately retained because another avatar may reference them. Inspect the journal's original references to perform a manual, selective repair if a creator edited the installation. Unity Undo supports descriptor/scene-object changes, while the persistent journal handles file history; Undo does not promise deletion of asset files.

## Export and inspect

**Inspect source configuration** checks source parameter cost, duplicate names, selected rig category, missing components, selected PhysBone references and Contact local/others configuration. Findings explicitly retain not-tested states. Use the SDK's own rig/build/performance validator for its full rules. No blanket repair, PhysBone live-property tuning, raycast configuration, arbitrary hierarchy mutation or runtime skeleton reconstruction is performed.

**Review and export source manifest** emits the desktop schema-1 contract. It includes ordered actual expression parameters, finite module definitions, measured source component counts, animation bindings, selected source context and a sanitized hierarchy. By default the hierarchy contains only toolkit descendants and anchor ancestors; full selected-avatar hierarchy and source labels are separate opt-ins. Parameter names must remain exact for compatibility. The export stops instead of truncating unsupported names or exceeding 512 parameters / 2000 hierarchy objects / 2000 bindings / 256 KiB. Source-derived costs are not final uploaded performance rank.

A blueprint ID is read only when present; otherwise a stable local avatar ID from the journal identifies the workspace. The export always has `stage: "source"` and an empty generated build ID. It does not claim that the source is the currently worn avatar or the output of a later build processor. **Do not relabel a source manifest as generated** without an independently inspected final build.

**Static preview PNG** is a separate, explicitly reviewed local export. It draws existing selected-source meshes/materials, at their current pose, with orthographic front/back/left/right views. It does not instantiate arbitrary avatar scripts, modify source poses, create a T-pose, fetch an avatar, or represent VRChat runtime rendering. Limits are 256 renderers, 500,000 vertices and 1024×1024 output. No continuous renderer runs when the window is hidden. The creator decides separately whether the image may be shared.

The desktop module composer accepts data-only recipes; its planning export does not automatically execute editor code or install a third-party package. This Unity backend currently installs the twelve fixed, reviewed starter recipes. A custom composer recipe must be implemented and tested in the creator's Unity source before it can be advertised as an installed module.

## Native verification checklist

The package includes EditMode tests in `Tests/EyeAuthoringTests.cs` and
`Tests/EyeAvatarRepairTests.cs`, and `Tests/EyeCompletionTests.cs`. Run them in Unity with SDK 3.10.x and the Unity
Test Framework. The authoring tests cover installation/privacy settings, duplicate
protection, changed-object refusal, removal restoration and source-export labeling.
The repair tests cover separate asset copies, binding remaps, changed-source refusal
and bounded OBJ export. Neither suite has been run in Unity here. Python static
checks and C# syntax parsing do not compile the package or prove editor compatibility.

Before distribution, additionally verify: compile/import; a fresh avatar and one with existing FX/menus; full menu wrapping; every selected module; Undo/reload and journal removal; existing asset preservation; postprocessor output; cross-platform synchronized parameter positions/types; self/others Contacts; held/short requests and release rearm; OSC output configuration; avatar reload; initial and stale heartbeat; provider disappearance; local/remote/mirror/photo rendering; menu alternatives; generic and humanoid anchors; left/right placement; shader/platform builds; image permissions; and SDK performance constraints. Keep request acceptance distinct from observed completion.

## Official references checked for this implementation

- VPM local/package format and dependencies: https://vcc.docs.vrchat.com/vpm/packages/
- Current SDK releases (3.10.5 at review): https://creators.vrchat.com/releases/
- Current Unity editor: https://creators.vrchat.com/sdk/upgrade/current-unity-version/
- Parameter types, synchronization budget and ordering: https://creators.vrchat.com/avatars/animator-parameters/
- Expression menu controls and persistence: https://creators.vrchat.com/avatars/expression-menu-and-controls/
- Contact receiver behavior and filtering: https://creators.vrchat.com/common-components/contacts/
- PhysBone authoring and supported signals: https://creators.vrchat.com/common-components/physbones/
- Platform overrides: https://creators.vrchat.com/avatars/per-platform-avatar-overrides/

Documentation review establishes the design target, not native compatibility certification.

## Reviewed renderer and importer setting transfers (ARC-11)

**VRC Eye → Mesh and Importer Setting Transfers** compares two explicitly chosen
compatible assets. Choose renderer values on saved prefab copies, or selected
ModelImporter policies on copied FBX files with explicit reimport. Every setting
starts deselected; transferred references require a chosen destination identity
or explicit null. Ordered stream/submesh/material/bone/hierarchy observations
are written to `setting-transfer.json` and linked to Repair Copy History.

Unity compilation and native execution remain pending. Run the 13 new
`EyeSettingTransferTests.cs` methods with the supplied inert FBX fixture and
the existing Toolkit suite in a disposable authorized Unity 2022.3 project.
The desktop can inspect these JSON observations from Avatar Library → Recovery,
but does not authenticate native execution or apply settings from them.
See [ARC-11 scope and qualification](../../ARC11_SETTING_TRANSFERS.md).

## Renderer bounds observations and copies (ARC-10)

**VRC Eye → Renderer Bounds Copies** provides an experimental Unity 2022.3
workflow for one skinned renderer in a saved, authorized prefab. Observe imported
and explicitly sampled clip poses in its root-bone frame, review finite margins
or explicit bounds, then create a separate prefab. Source/dependency fingerprints,
copy reload/graph checks and Repair Copy History preserve the reviewed scope.
The original renderer and scene assignments are not changed by this operation.

This source has not been compiled or run in Unity here. Run the 13 new
`Tests/EyeBoundsTests.cs` methods and the existing Toolkit tests in a disposable
project before creator use. An explicit internal root bone, readable saved mesh,
unambiguous hierarchy and supported local-transform/blendshape clips are required.
Finite samples do not cover procedural deformation or prove FPS improvements.
See [ARC-10 usage, limits and qualification](../../ARC10_RENDERER_BOUNDS.md).

## Shader observations and imported repair-copy verification

Shader observations now export schema 2 with typed pass/support/error results,
saved source/dependency hashes and editor context. Save the selected assets,
export outside the project, close Unity, and import the report from the desktop
Recovery history's completed shader installation. The desktop records a separate
reviewed observation and preserves installation-time `not_run`. Matching files
are applicability evidence; an editable report is not authenticated compiler or
publisher attestation. Other targets, variants and package shaders remain untested.

Material and mesh repair copies reload after synchronous import and compare
actual typed output with a pre-publication snapshot. Changed outputs interrupt
the journal operation and remain available for inspection. Six additional
EditMode methods exercise these paths; they have not been compiled or run in
Unity here. See `../../ARC_REPAIR_CONTINUATION.md` for the workflow and limits.

## ARC-12 skin influence copies

**VRC Eye → Skin Influence Copies** measures a selected weight cap over the imported pose and explicit clip times, then offers a reviewed new mesh asset when the measured maximum error is within the entered tolerance. Geometry, bind poses, ordered material submeshes and blendshape frames are preserved; no original mesh or assignment changes. Unknown/dynamic components block this narrow data-only prefab workflow. Bone deletion, renderer consolidation and runtime speed claims remain unavailable. See [ARC-12 scope and qualification](../../ARC12_SKIN_OPTIMIZATION.md). The 13 new EditMode tests are supplied but unrun here.
