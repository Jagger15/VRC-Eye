using System;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeSkinInfluenceWindow:EditorWindow
    {
        GameObject root;SkinnedMeshRenderer renderer;bool authorized;int limit=2;float tolerance=.001f;
        EyeBoundsRange[] ranges=Array.Empty<EyeBoundsRange>();EyeSkinPlan plan;Vector2 scroll;
        string report="Choose a saved data-only prefab and readable skin mesh. Measure first; then review a new mesh copy.";
        [MenuItem("VRC Eye/Skin Influence Copies")]
        public static void Open(){GetWindow<EyeSkinInfluenceWindow>("Skin Influence Copies");}
        void Invalidate(){EyeSkinInfluenceCopies.Cancel(plan);plan=null;}
        void OnDisable(){Invalidate();}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("Experimental Unity 2022.3 source: native compilation and EditMode qualification are required. This subset supports up to four stored weights per vertex and data-only prefabs. Unknown components, Animator, cloth and constraints block editing. It never removes components or bones.",MessageType.Warning);
            EditorGUI.BeginChangeCheck();var next=(GameObject)EditorGUILayout.ObjectField("Saved prefab root",root,typeof(GameObject),false);
            if(next!=root){root=next;renderer=null;authorized=false;}
            var renderers=root?root.GetComponentsInChildren<SkinnedMeshRenderer>(true):Array.Empty<SkinnedMeshRenderer>();
            if(renderers.Length>0){int index=EditorGUILayout.Popup("Skinned renderer",Math.Max(0,Array.IndexOf(renderers,renderer)),renderers.Select(r=>AnimationUtility.CalculateTransformPath(r.transform,root.transform)).ToArray());renderer=renderers[index];}
            else {renderer=null;EditorGUILayout.LabelField("No skinned renderer available");}
            limit=EditorGUILayout.IntSlider("Maximum stored influences",limit,1,4);tolerance=EditorGUILayout.FloatField("Maximum error (source units)",tolerance);
            int count=EditorGUILayout.IntSlider("Explicit clip ranges",ranges.Length,0,8);if(count!=ranges.Length)Array.Resize(ref ranges,count);
            for(int i=0;i<ranges.Length;i++) {
                var r=ranges[i];var clip=(AnimationClip)EditorGUILayout.ObjectField("Clip "+(i+1),r==null?null:r.clip,typeof(AnimationClip),false);
                float start=EditorGUILayout.FloatField("Start seconds",r==null?0:r.start),end=EditorGUILayout.FloatField("End seconds",r==null?(clip?clip.length:1):r.end);
                int samples=EditorGUILayout.IntField("Endpoint-inclusive samples",r==null?16:r.count);ranges[i]=new EyeBoundsRange(clip,start,end,samples);
            }
            authorized=EditorGUILayout.ToggleLeft("I own or have permission to inspect and create copies of these assets",authorized);
            if(EditorGUI.EndChangeCheck())Invalidate();
            using(new EditorGUI.DisabledScope(!root||!renderer||!authorized))if(GUILayout.Button("Measure reduction"))Run(()=>{Invalidate();plan=EyeSkinInfluenceCopies.Prepare(root,renderer,limit,tolerance,ranges,true);report=plan.summary;});
            using(new EditorGUI.DisabledScope(plan==null||!authorized||plan.maximum>plan.tolerance))if(GUILayout.Button("Review and create new mesh copy…"))Run(()=>{
                var reviewed=plan;
                if(!EditorUtility.DisplayDialog("Create skin influence copy?",reviewed.summary,"Create new mesh copy","Cancel")){Invalidate();return;}
                string saved=EyeSkinInfluenceCopies.Execute(reviewed,()=>this&&authorized&&ReferenceEquals(plan,reviewed));plan=null;
                report="Created "+saved+"\nInspect the new mesh and review text before a separate manual assignment. No original asset or assignment changed.";
            });
            if(GUILayout.Button("Open copy history"))EyeCopyHistoryWindow.Open();
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(250));EditorGUILayout.EndScrollView();
        }
        void Run(Action action){try{action();}catch(Exception e){Invalidate();report="Stopped: "+e.Message;}Repaint();}
    }
}
