// ARC-10. Read-only observations from a data-only hierarchy, never an Animator.
// Unity 2022.3 compile/EditMode qualification remains required.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeBoundsRange
    {
        public readonly AnimationClip clip;public readonly float start,end;public readonly int count;
        public EyeBoundsRange(AnimationClip clip,float start,float end,int count){this.clip=clip;this.start=start;this.end=end;this.count=count;}
        public float[] Times() {
            EyeBoundsMath.Finite(start);EyeBoundsMath.Finite(end);
            if(!clip||start<0||end<start||end>clip.length||end-start>60||count<1||count>128||((start==end)!=(count==1)))throw new InvalidOperationException("Choose a saved clip range up to 60 seconds, with 2–128 samples, or one sample for a single time.");
            return Enumerable.Range(0,count).Select(i=>i==count-1?end:start+(end-start)*i/(count-1)).ToArray();
        }
    }
    public sealed class EyeBoundsSample
    {
        public readonly string clip;public readonly float seconds;public readonly Bounds bounds;
        internal EyeBoundsSample(string clip,float seconds,Bounds bounds){this.clip=clip;this.seconds=seconds;this.bounds=bounds;}
    }
    public sealed class EyeBoundsObservation
    {
        internal readonly GameObject root;internal readonly SkinnedMeshRenderer renderer;
        internal readonly EyeBoundsRange[] ranges;internal readonly EyeBoundsSample[] samples;
        internal readonly string fingerprint,rendererKey;internal readonly double expires;
        public readonly Bounds meshLocal,meshInRootBone,rendererLocal,observed;
        public readonly string report;
        internal EyeBoundsObservation(GameObject root,SkinnedMeshRenderer renderer,EyeBoundsRange[] ranges,EyeBoundsSample[] samples,string fingerprint,string key,Bounds mesh,Bounds mapped,Bounds current,Bounds observed,string report)
        {this.root=root;this.renderer=renderer;this.ranges=ranges;this.samples=samples;this.fingerprint=fingerprint;rendererKey=key;meshLocal=mesh;meshInRootBone=mapped;rendererLocal=current;this.observed=observed;this.report=report;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeBoundsMath
    {
        public static void Finite(float n){if(float.IsNaN(n)||float.IsInfinity(n)||Mathf.Abs(n)>1000000)throw new InvalidOperationException("Bounds values must be finite and within one million source units.");}
        public static void Finite(Vector3 v){Finite(v.x);Finite(v.y);Finite(v.z);}
        public static Bounds Check(Bounds b){Finite(b.center);Finite(b.size);Finite(b.min);Finite(b.max);if(b.size.x<0||b.size.y<0||b.size.z<0)throw new InvalidOperationException("Bounds size must be nonnegative.");return b;}
        public static void Matrix(Matrix4x4 m) {
            for(int i=0;i<16;i++)Finite(m[i]);
            double a=m.GetColumn(0).magnitude,b=m.GetColumn(1).magnitude,c=m.GetColumn(2).magnitude;
            if(a*b*c==0||Math.Abs(m.determinant)<=a*b*c*1e-10)throw new InvalidOperationException("A zero or near-singular transform prevents reliable bounds-space conversion.");
        }
        public static Bounds Points(IEnumerable<Vector3> points) {
            bool any=false;Bounds result=new Bounds();
            foreach(var p in points){Finite(p);if(!any){result=new Bounds(p,Vector3.zero);any=true;}else result.Encapsulate(p);}
            if(!any)throw new InvalidOperationException("No vertices to measure.");return Check(result);
        }
        public static Bounds Transform(Bounds box,Matrix4x4 matrix) {
            Check(box);Matrix(matrix);var points=new Vector3[8];
            for(int i=0;i<8;i++)points[i]=matrix.MultiplyPoint3x4(new Vector3((i&1)==0?box.min.x:box.max.x,(i&2)==0?box.min.y:box.max.y,(i&4)==0?box.min.z:box.max.z));
            return Points(points);
        }
        public static Bounds Union(Bounds a,Bounds b){Check(a);Check(b);a.Encapsulate(b.min);a.Encapsulate(b.max);return Check(a);}
        public static Bounds Expand(Bounds value,Vector3 margin) {
            Check(value);Finite(margin);if(margin.x<0||margin.y<0||margin.z<0||margin.x>1000||margin.y>1000||margin.z>1000)throw new InvalidOperationException("Per-side margins must be from 0 to 1,000 source units.");
            value.SetMinMax(value.min-margin,value.max+margin);return Check(value);
        }
        public static bool Contains(Bounds outer,Bounds inner) {
            Check(outer);Check(inner);var a=outer.min;var b=outer.max;var c=inner.min;var d=inner.max;
            return a.x<=c.x&&a.y<=c.y&&a.z<=c.z&&b.x>=d.x&&b.y>=d.y&&b.z>=d.z;
        }
        public static string Text(Bounds b){return "center "+b.center.ToString("G9")+"; size "+b.size.ToString("G9");}
    }
    public static class EyeBoundsDiagnostics
    {
        public const string Limits="Finite samples do not verify between-sample motion, unselected clips, controllers, retargeting, IK, constraints, PhysBones, cloth, custom scripts or shader deformation. No FPS improvement is established by changed bounds.";
        internal static Dictionary<string,Object> Source(GameObject root,SkinnedMeshRenderer renderer) {
            if(!Application.unityVersion.StartsWith("2022.3.",StringComparison.Ordinal))throw new InvalidOperationException("This serialized bounds workflow currently supports Unity 2022.3 only; qualify other versions separately.");
            if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Stop Play Mode and wait for compilation.");
            string path=root?AssetDatabase.GetAssetPath(root):"";
            if(!path.StartsWith("Assets/",StringComparison.Ordinal)||!path.EndsWith(".prefab",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadAssetAtPath<GameObject>(path)!=root)throw new InvalidOperationException("Choose a saved .prefab root under Assets, not a scene instance or imported model.");
            var objects=EyeComponentCopies.Objects(root);var names=new HashSet<string>();
            foreach(var go in objects.Values.OfType<GameObject>()) {
                if(string.IsNullOrEmpty(go.name)||go.name.Contains("/")||!names.Add(go.name))throw new InvalidOperationException("Use distinct, nonempty object names without slashes for unambiguous clip and prefab save matching.");
                var components=go.GetComponents<Component>();
                if(components.Any(c=>!c)||components.GroupBy(c=>c.GetType()).Any(g=>g.Count()>1))throw new InvalidOperationException("Missing or repeated component types need a separate reviewed cleanup before bounds correction.");
            }
            if(objects.Values.Any(EditorUtility.IsDirty))throw new InvalidOperationException("Save the source prefab before inspecting bounds.");
            if(!renderer||!objects.Values.Contains(renderer)||!renderer.sharedMesh||!renderer.sharedMesh.isReadable||renderer.sharedMesh.vertexCount<1||renderer.sharedMesh.vertexCount>200000)throw new InvalidOperationException("Select a renderer beneath this prefab with a readable mesh of 1–200,000 vertices.");
            if(!renderer.rootBone||!objects.Values.Contains(renderer.rootBone))throw new InvalidOperationException("Choose a renderer with an explicit root bone inside the prefab. An implicit native root-bone fallback is not guessed.");
            if(renderer.bones.Length>512||renderer.bones.Any(b=>!b||!objects.Values.Contains(b)))throw new InvalidOperationException("Resolve all skin bones inside the selected prefab (up to 512). No external or missing bone is guessed.");
            if(renderer.sharedMesh.blendShapeCount>128)throw new InvalidOperationException("Bounds sampling supports up to 128 blendshapes.");
            Saved(renderer.sharedMesh);SerializedBounds(renderer);
            return objects;
        }
        internal static void Saved(Object value) {
            string path=value?AssetDatabase.GetAssetPath(value):"";
            if(!value||EditorUtility.IsDirty(value)||!path.StartsWith("Assets/",StringComparison.Ordinal))throw new InvalidOperationException("Save mesh/clip assets under Assets before bounds observation. Import settings are never changed.");
        }
        internal static Bounds SerializedBounds(SkinnedMeshRenderer renderer) {
            var s=new SerializedObject(renderer);var b=s.FindProperty("m_AABB");var dirty=s.FindProperty("m_DirtyAABB");
            if(b==null||b.propertyType!=SerializedPropertyType.Bounds||dirty==null||dirty.propertyType!=SerializedPropertyType.Boolean)throw new InvalidOperationException("Unsupported serialized renderer bounds schema.");
            return EyeBoundsMath.Check(b.boundsValue);
        }
        internal static string Fingerprint(GameObject root,SkinnedMeshRenderer renderer,EyeBoundsRange[] ranges) {
            var objects=Source(root,renderer);var text=new StringBuilder(Application.unityVersion+"|"+QualitySettings.skinWeights+"\n");
            foreach(var item in objects.OrderBy(x=>x.Key,StringComparer.Ordinal)){text.Append(item.Key).Append('|').Append(EyeMaterialMapping.ObjectEvidence(item.Value)).Append('\n');if(text.Length>32*1024*1024)throw new InvalidOperationException("Bounds object evidence exceeds 32 MiB.");}
            text.Append(EyeAvatarRepair.MeshEvidence(renderer.sharedMesh));
            foreach(var range in ranges){Saved(range.clip);text.Append(EyeAvatarRepair.ClipEvidence(range.clip)).Append('|').Append(range.start.ToString("R",CultureInfo.InvariantCulture)).Append('|').Append(range.end.ToString("R",CultureInfo.InvariantCulture)).Append('|').Append(range.count);}
            var roots=new[]{AssetDatabase.GetAssetPath(root),AssetDatabase.GetAssetPath(renderer.sharedMesh)}.Concat(ranges.Select(r=>AssetDatabase.GetAssetPath(r.clip))).Distinct().ToArray();
            var deps=AssetDatabase.GetDependencies(roots,true);if(deps.Length>512)throw new InvalidOperationException("Bounds source dependency graph exceeds 512 assets.");
            var paths=new HashSet<string>(roots.Concat(deps).Where(p=>p.StartsWith("Assets/",StringComparison.Ordinal)||p.StartsWith("Packages/",StringComparison.Ordinal)),StringComparer.Ordinal);
            paths.Add("ProjectSettings/ProjectVersion.txt");
            foreach(string path in paths.ToArray())if(File.Exists(Path.Combine(EyeShaderFileEvidence.ProjectRoot,path+".meta")))paths.Add(path+".meta");
            long total=0;
            foreach(string path in paths.OrderBy(p=>p,StringComparer.Ordinal)) {
                // Unmaterialized package dependencies stop rather than claim a byte hash.
                var f=EyeShaderFileEvidence.Read(path);total+=f.bytes;if(total>128L*1024*1024)throw new InvalidOperationException("Bounds source evidence exceeds 128 MiB.");
                text.Append('\n').Append(f.path).Append('|').Append(f.bytes).Append('|').Append(f.sha256);
            }
            if(text.Length>32*1024*1024)throw new InvalidOperationException("Bounds source evidence exceeds 32 MiB.");return EyeMaterialMapping.Hash(text.ToString());
        }
        internal sealed class Curve {
            internal Transform source;internal AnimationCurve curve;internal string property;internal int blend=-1;
        }
        internal static Curve[] Curves(GameObject root,SkinnedMeshRenderer renderer,AnimationClip clip,out int ignored) {
            Saved(clip);if(clip.humanMotion)throw new InvalidOperationException("Humanoid/muscle clips require a validated retargeting provider. Export explicit local transform curves for this sampler.");
            if(AnimationUtility.GetObjectReferenceCurveBindings(clip).Length>0)throw new InvalidOperationException("Object-reference curves are outside bounds sampling. Export a local-transform/blendshape-only clip; no object swap is executed.");
            var bindings=AnimationUtility.GetCurveBindings(clip);if(bindings.Length==0||bindings.Length>2000)throw new InvalidOperationException("Choose a clip with 1–2,000 float bindings.");
            var result=new List<Curve>();var seen=new HashSet<string>();var rotations=new Dictionary<Transform,string>();int keys=0;ignored=0;
            foreach(var b in bindings) {
                string key=EyeAnimationCopies.Key(b);if(!seen.Add(key))throw new InvalidOperationException("Duplicate animation binding.");
                var target=string.IsNullOrEmpty(b.path)?root.transform:root.transform.Find(b.path);if(!target)throw new InvalidOperationException("Animation path is missing: "+b.path);
                var curve=AnimationUtility.GetEditorCurve(clip,b);keys+=curve.length;if(keys>200000)throw new InvalidOperationException("Bounds clip key budget exceeds 200,000.");
                foreach(var k in curve.keys){EyeBoundsMath.Finite(k.time);EyeBoundsMath.Finite(k.value);}
                var entry=new Curve{source=target,curve=curve,property=b.propertyName};
                if(b.type==typeof(Transform)) {
                    string[] pieces=b.propertyName.Split('.');if(pieces.Length!=2)throw new InvalidOperationException("Unsupported transform curve: "+b.propertyName);
                    string prefix=pieces[0],axis=pieces[1];bool rotation=prefix=="m_LocalRotation",euler=prefix=="localEulerAnglesRaw";
                    if(!(prefix=="m_LocalPosition"||prefix=="m_LocalScale"||rotation||euler)||axis.Length!=1||!(rotation?"xyzw":"xyz").Contains(axis))throw new InvalidOperationException("Only local position, scale, quaternion or raw Euler rotation curves can be sampled.");
                    if(rotation||euler){string mode=euler?"Euler":"Quaternion",old;if(rotations.TryGetValue(target,out old)&&old!=mode)throw new InvalidOperationException("Mixed Euler and quaternion curves on one transform are unsupported.");rotations[target]=mode;}
                } else if(b.type==typeof(SkinnedMeshRenderer)&&b.propertyName.StartsWith("blendShape.",StringComparison.Ordinal)) {
                    var skin=target.GetComponent<SkinnedMeshRenderer>();if(!skin||!skin.sharedMesh)throw new InvalidOperationException("Missing blendshape renderer.");
                    entry.blend=skin.sharedMesh.GetBlendShapeIndex(b.propertyName.Substring(11));if(entry.blend<0)throw new InvalidOperationException("Missing blendshape target.");
                    if(skin!=renderer){ignored++;continue;}
                } else throw new InvalidOperationException("Unsupported curve: "+key+". No script, constraint or controller binding is executed.");
                result.Add(entry);
            }
            return result.ToArray();
        }
        internal sealed class Pose:IDisposable {
            internal GameObject root;internal SkinnedMeshRenderer skin;internal readonly Dictionary<Transform,Transform> transforms=new Dictionary<Transform,Transform>();
            readonly SkinnedMeshRenderer source;
            internal Pose(GameObject original,SkinnedMeshRenderer source,Dictionary<string,Object> objects) {
                this.source=source;
                try {
                    foreach(var go in objects.Where(x=>x.Value is GameObject).OrderBy(x=>x.Key.Count(c=>c=='/')).Select(x=>(GameObject)x.Value)) {
                        var copy=new GameObject(go.name){hideFlags=HideFlags.HideAndDontSave};copy.SetActive(false);if(go==original)root=copy;
                        var t=copy.transform;transforms.Add(go.transform,t);if(go!=original)t.SetParent(transforms[go.transform.parent],false);
                    }
                    skin=transforms[source.transform].gameObject.AddComponent<SkinnedMeshRenderer>();skin.enabled=false;skin.sharedMesh=source.sharedMesh;skin.rootBone=transforms[source.rootBone];skin.bones=source.bones.Select(b=>transforms[b]).ToArray();skin.quality=source.quality;skin.updateWhenOffscreen=false;Reset();
                } catch {Dispose();throw;}
            }
            internal void Reset() {
                foreach(var pair in transforms){pair.Value.localPosition=pair.Key.localPosition;pair.Value.localRotation=pair.Key.localRotation;pair.Value.localScale=pair.Key.localScale;}
                for(int i=0;i<source.sharedMesh.blendShapeCount;i++)skin.SetBlendShapeWeight(i,source.GetBlendShapeWeight(i));
            }
            internal void Apply(Curve[] curves,float seconds) {
                Reset();var quats=new Dictionary<Transform,Quaternion>();var eulers=new Dictionary<Transform,Vector3>();
                foreach(var c in curves) {
                    float v=c.curve.Evaluate(seconds);EyeBoundsMath.Finite(v);var t=transforms[c.source];
                    if(c.blend>=0){if(Mathf.Abs(v)>1000)throw new InvalidOperationException("Blendshape sample exceeds +/-1,000 percent.");skin.SetBlendShapeWeight(c.blend,v);continue;}
                    int axis="xyzw".IndexOf(c.property[c.property.Length-1]);
                    if(c.property.StartsWith("m_LocalRotation.",StringComparison.Ordinal)){Quaternion q;if(!quats.TryGetValue(t,out q))q=t.localRotation;q[axis]=v;quats[t]=q;}
                    else if(c.property.StartsWith("localEulerAnglesRaw.",StringComparison.Ordinal)){Vector3 e;if(!eulers.TryGetValue(t,out e))e=t.localEulerAngles;e[axis]=v;eulers[t]=e;}
                    else if(c.property.StartsWith("m_LocalPosition.",StringComparison.Ordinal)){var p=t.localPosition;p[axis]=v;t.localPosition=p;}
                    else {var s=t.localScale;s[axis]=v;t.localScale=s;}
                }
                foreach(var pair in quats){var q=pair.Value;float length=Mathf.Sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w);if(length<1e-8f)throw new InvalidOperationException("Animation produced a zero quaternion.");pair.Key.localRotation=new Quaternion(q.x/length,q.y/length,q.z/length,q.w/length);}
                foreach(var pair in eulers)pair.Key.localRotation=Quaternion.Euler(pair.Value);
            }
            internal Vector3[] Vertices(bool rootBoneSpace=true) {
                EyeBoundsMath.Matrix(skin.transform.localToWorldMatrix);EyeBoundsMath.Matrix(skin.rootBone.localToWorldMatrix);
                var convert=rootBoneSpace?skin.rootBone.worldToLocalMatrix*skin.transform.localToWorldMatrix:skin.transform.localToWorldMatrix;var baked=new Mesh{hideFlags=HideFlags.HideAndDontSave};
                try {skin.BakeMesh(baked,false);if(baked.vertexCount!=source.sharedMesh.vertexCount)throw new InvalidOperationException("Baked mesh vertex count changed.");var result=baked.vertices.Select(p=>convert.MultiplyPoint3x4(p)).ToArray();foreach(var p in result)EyeBoundsMath.Finite(p);return result;}
                finally {Object.DestroyImmediate(baked);}
            }
            internal Bounds Measure(){return EyeBoundsMath.Points(Vertices());}
            public void Dispose(){if(root)Object.DestroyImmediate(root);root=null;transforms.Clear();}
        }
        public static EyeBoundsObservation Observe(GameObject root,SkinnedMeshRenderer renderer,IEnumerable<EyeBoundsRange> selected,bool progress=false) {
            var ranges=(selected??Array.Empty<EyeBoundsRange>()).Take(9).ToArray();if(ranges.Length>8||ranges.Any(r=>r==null))throw new InvalidOperationException("Select up to eight explicit clip ranges.");
            var objects=Source(root,renderer);var points=ranges.Select(r=>r.Times()).ToArray();int count=1+points.Sum(p=>p.Length);
            if(count>257||(long)count*renderer.sharedMesh.vertexCount>8000000)throw new InvalidOperationException("Bounds sampling exceeds 257 poses or eight million baked vertices. Reduce the range samples or mesh size.");
            var clips=new List<Curve[]>();var coverage=new List<string>();
            foreach(var r in ranges){int ignored;clips.Add(Curves(root,renderer,r.clip,out ignored));coverage.Add(r.clip.name+": ignored "+AnimationUtility.GetAnimationEvents(r.clip).Length+" events and "+ignored+" unrelated-renderer blendshape bindings; no runtime controller.");}
            string before=Fingerprint(root,renderer,ranges);string key=objects.Single(p=>p.Value==renderer).Key;
            EyeBoundsMath.Matrix(renderer.transform.localToWorldMatrix);EyeBoundsMath.Matrix(renderer.rootBone.localToWorldMatrix);
            var mesh=EyeBoundsMath.Check(renderer.sharedMesh.bounds);var mapped=EyeBoundsMath.Transform(mesh,renderer.rootBone.worldToLocalMatrix*renderer.transform.localToWorldMatrix);var stored=SerializedBounds(renderer);
            var samples=new List<EyeBoundsSample>();double deadline=EditorApplication.timeSinceStartup+20;
            try {
                using(var pose=new Pose(root,renderer,objects)) {
                    samples.Add(new EyeBoundsSample("Imported pose",0,pose.Measure()));
                    for(int i=0;i<ranges.Length;i++)foreach(float at in points[i]) {
                        if(EditorApplication.timeSinceStartup>deadline)throw new InvalidOperationException("Bounds observation exceeded 20 seconds; reduce sample scope.");
                        if(progress&&EditorUtility.DisplayCancelableProgressBar("VRC Eye bounds observation",ranges[i].clip.name+" at "+at.ToString("G9",CultureInfo.InvariantCulture)+" s",(float)samples.Count/count))throw new OperationCanceledException("Bounds observation canceled; no source was changed.");
                        pose.Apply(clips[i],at);samples.Add(new EyeBoundsSample(ranges[i].clip.name,at,pose.Measure()));
                    }
                }
            } finally {if(progress)EditorUtility.ClearProgressBar();}
            if(before!=Fingerprint(root,renderer,ranges))throw new InvalidOperationException("Source changed while measuring bounds. Observe again.");
            var observed=samples.Select(s=>s.bounds).Aggregate(EyeBoundsMath.Union);
            string report="Unity "+Application.unityVersion+" | root "+root.name+" | renderer "+renderer.name+"\nBounds frame: explicit root bone "+renderer.rootBone.name+"; each sample uses its own root-bone inverse.\nSource mesh bounds (mesh local): "+EyeBoundsMath.Text(mesh)+"\nMesh box in imported root-bone frame (eight corners): "+EyeBoundsMath.Text(mapped)+"\nSerialized renderer bounds (root-bone local): "+EyeBoundsMath.Text(stored)+"\nSample union (root-bone local): "+EyeBoundsMath.Text(observed)+"\nStored bounds cover sampled vertices: "+EyeBoundsMath.Contains(stored,observed)+"\nSkin quality: "+renderer.quality+"; project skin weights: "+QualitySettings.skinWeights+"; updateWhenOffscreen: "+renderer.updateWhenOffscreen+" (unchanged; Unity may recompute bounds when enabled).\n"+string.Join("\n",coverage)+"\nSamples:\n"+string.Join("\n",samples.Select(s=>s.clip+" @ "+s.seconds.ToString("G9",CultureInfo.InvariantCulture)+" s | "+EyeBoundsMath.Text(s.bounds)))+"\n"+Limits+"\nSource fingerprint: "+before;
            return new EyeBoundsObservation(root,renderer,ranges,samples.ToArray(),before,key,mesh,mapped,stored,observed,report);
        }
        internal static void Fresh(EyeBoundsObservation observation) {
            if(observation==null||EditorApplication.timeSinceStartup>=observation.expires)throw new InvalidOperationException("Bounds observation expired; observe again.");
            if(observation.fingerprint!=Fingerprint(observation.root,observation.renderer,observation.ranges))throw new InvalidOperationException("Source prefab, mesh, clip, dependencies or project context changed after bounds review.");
        }
    }
}
