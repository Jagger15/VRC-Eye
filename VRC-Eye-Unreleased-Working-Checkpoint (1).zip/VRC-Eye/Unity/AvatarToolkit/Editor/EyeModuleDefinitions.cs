// Copyright VRC Eye. Editor-only: no custom MonoBehaviour is attached to an avatar.
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    [Serializable] public sealed class EyeParameter
    {
        public string name, type, direction, module, semantic, validity = "", action = "";
        public float max = 1; public bool ephemeral = true;
        public EyeParameter(string n, string t, string d, string m, string meaning, float upper = 1)
        { name = n; type = t; direction = d; module = m; semantic = meaning; max = upper; }
        public Dictionary<string, object> Manifest()
        {
            object zero = type == "Bool" ? (object)false : type == "Int" ? (object)0 : (object)0.0;
            return EyeJson.Map("name", name, "type", type, "direction", direction, "default", zero,
                "neutral", zero, "min", 0, "max", max, "synced", false, "saved", false,
                "privacy", "private", "module", module, "semantic", semantic, "validity", validity,
                "freshness_seconds", 5, "ephemeral", ephemeral, "action", action, "acknowledgment", "", "rate_hz", 10);
        }
    }
    public sealed class EyeModule
    {
        public string id, label, description; public EyeParameter[] parameters;
        public EyeModule(string i, string l, string text, params EyeParameter[] p)
        { id = i; label = l; description = text; parameters = p; }
    }
    public static class EyeModules
    {
        static EyeParameter Input(string module, string name, string type, string text, float max = 1)
        { return new EyeParameter("EYE_In_" + name, type, "in", module, text, max) { ephemeral = name != "Quiet" }; }
        static EyeParameter Valid(string module, string name, string type, string text, float max = 1)
        { var p = Input(module, name, type, text, max); p.validity = "EYE_In_" + name + "Valid"; return p; }
        public static readonly EyeModule[] All = {
            new EyeModule("wrist", "Wrist shell", "Small rigid panel; adjustable anchor, size and orientation. No rig pose edits."),
            new EyeModule("status", "Status symbols", "Finite manual/provider states: unknown, available, busy, away, quiet.", Valid("status","Status","Int","Coarse selected presentation; not native account status",4), Input("status","StatusValid","Bool","Selected status source is current")),
            new EyeModule("safety", "Safety request bracelet", "Held local request plus independently reported applied state; no guarantee of safety.", new EyeParameter("EYE_Out_Safety","Bool","out","safety","Held safety request") { action="safety_profile" }, Input("safety","SafetyApplied","Bool","applied_profile:safety_profile")),
            new EyeModule("battery", "Battery meter", "Normalized selected-device charge with a separate unknown state.", Valid("battery","Battery","Float","Normalized selected device charge"), Input("battery","BatteryValid","Bool","Battery source is current")),
            new EyeModule("streamer", "Recording symbols", "Unknown / stopped / recording / paused / streaming; provider or explicitly manual input.", Valid("streamer","Recording","Int","Coarse user-approved recording state",4), Input("streamer","RecordingValid","Bool","Recording source is current")),
            new EyeModule("music", "Music meter", "Bounded non-flashing scale meter; no microphone or audio capture in Unity.", Valid("music","Audio","Float","Selected local source normalized energy"), Input("music","AudioValid","Bool","Selected audio source is current")),
            new EyeModule("camera", "Camera request button", "Held shutter request; cyan feedback means broker acceptance only, not capture completion.", new EyeParameter("EYE_Out_Camera","Bool","out","camera","Held camera request") { action="request_photo" }, Input("camera","CameraAccepted","Bool","accepted_request:request_photo")),
            new EyeModule("availability", "Quiet / native AFK", "Separate manual quiet indicator and read-only native AFK presentation.", Input("availability","Quiet","Bool","Manual companion quiet presentation; does not set VRChat DND")),
            new EyeModule("connection", "Changing heartbeat", "Best-effort changing-heartbeat timeout; initial and stale state unconfirmed.", Input("connection","Heartbeat","Bool","heartbeat")),
            new EyeModule("hardware", "Hardware meter", "Normalized selected-provider value with explicit validity; no serial numbers.", Valid("hardware","Hardware","Float","Normalized selected hardware metric"), Input("hardware","HardwareValid","Bool","Selected hardware source is current")),
            new EyeModule("resource", "Resource warning", "Finite observed pressure; does not attribute the cause to this avatar.", Valid("resource","Resource","Int","Observed pressure: unknown, normal, elevated, high",3), Input("resource","ResourceValid","Bool","Observed pressure source is current")),
            new EyeModule("media", "Media state", "Finite stopped / playing / paused states; no track metadata.", Valid("media","Media","Int","Finite selected-source playback state",3), Input("media","MediaValid","Bool","Selected media source is current"))
        };
        public static EyeModule Get(string id) { return All.Single(x => x.id == id); }
    }
    // A bounded schema adapter avoids a hard reference to undocumented SDK assembly names.
    // Missing/changed serialized SDK fields fail closed before applying a change.
    public static class EyeSdk
    {
        public static Type Type(string fullName)
        { return AppDomain.CurrentDomain.GetAssemblies().Select(a => a.GetType(fullName, false)).FirstOrDefault(t => t != null); }
        public static Type DescriptorType { get { return Type("VRC.SDK3.Avatars.Components.VRCAvatarDescriptor"); } }
        public static SerializedProperty Field(SerializedObject obj, string name)
        { var p = obj.FindProperty(name); if (p == null) throw new InvalidOperationException("SDK field unavailable: " + name); return p; }
        public static SerializedProperty Child(SerializedProperty parent, string name)
        { var p = parent.FindPropertyRelative(name); if (p == null) throw new InvalidOperationException("SDK field unavailable: " + name); return p; }
        public static void Enum(SerializedProperty p, string name)
        { int i = Array.IndexOf(p.enumNames, name); if (i < 0) throw new InvalidOperationException("SDK enum unsupported: " + name); p.enumValueIndex = i; }
        public static ScriptableObject Asset(string typeName)
        { var type = Type(typeName); if (type == null) throw new InvalidOperationException("Install matching Avatars SDK first: " + typeName); return ScriptableObject.CreateInstance(type); }
        public static string Version()
        {
            if (DescriptorType == null) return "missing";
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssembly(DescriptorType.Assembly);
            return package == null ? "unrecognized" : package.version;
        }
        public static Component Descriptor(GameObject go)
        { return go && DescriptorType != null ? go.GetComponent(DescriptorType) : null; }
        public static SerializedProperty Fx(SerializedObject descriptor)
        {
            var layers = Field(descriptor, "baseAnimationLayers");
            for (int i=0;i<layers.arraySize;i++) { var layer=layers.GetArrayElementAtIndex(i); var type=Child(layer,"type");
                if (type.enumNames[type.enumValueIndex] == "FX") return layer; }
            throw new InvalidOperationException("Avatar descriptor has no FX slot.");
        }
        public static string StableObject(Object obj) { return obj ? GlobalObjectId.GetGlobalObjectIdSlow(obj).ToString() : ""; }
    }
    public static class EyeJson
    {
        public static Dictionary<string, object> Map(params object[] pairs)
        { var d = new Dictionary<string,object>(); for(int i=0;i<pairs.Length;i+=2) d.Add((string)pairs[i], pairs[i+1]); return d; }
        public static string Write(object obj)
        {
            if (obj == null) return "null";
            if (obj is string) { var s=(string)obj; var b=new StringBuilder("\""); foreach(char c in s) {
                if(c=='\"'||c=='\\') b.Append('\\').Append(c); else if(c<32) b.Append("\\u").Append(((int)c).ToString("x4")); else b.Append(c); } return b.Append('"').ToString(); }
            if (obj is bool) return (bool)obj ? "true" : "false";
            if (obj is IDictionary) { var d=(IDictionary)obj; var parts=new List<string>(); foreach(DictionaryEntry p in d) parts.Add(Write((string)p.Key)+":"+Write(p.Value)); return "{"+string.Join(",",parts)+"}"; }
            if (obj is IEnumerable) { var parts=new List<string>(); foreach(var p in (IEnumerable)obj) parts.Add(Write(p)); return "["+string.Join(",",parts)+"]"; }
            if(obj is float || obj is double) { double number=Convert.ToDouble(obj,CultureInfo.InvariantCulture); if(double.IsNaN(number)||double.IsInfinity(number))throw new InvalidOperationException("Cannot export non-finite source values."); }
            return Convert.ToString(obj, CultureInfo.InvariantCulture);
        }
    }
}
