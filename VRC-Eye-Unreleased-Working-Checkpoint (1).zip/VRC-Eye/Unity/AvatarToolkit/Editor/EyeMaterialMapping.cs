// Reviewed, exact-shader typed mappings. Requires Unity 2022.3 EditMode qualification.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    [Serializable] public sealed class EyePropertyMap { public string source, target; }
    [Serializable] public sealed class EyeShaderObservation
    {
        public int schema=2;public string capturedUtc,unity,buildTarget,graphicsApi,pipeline,shaderIdentity,materialEvidence,report;
        public bool compilationRequested;public string scope="Current editor/material variants only; other target builds and runtime stripping remain unverified";
        public string projectPath,materialPath,shaderPath;
        public EyeShaderSourceFile[] files=Array.Empty<EyeShaderSourceFile>();
        public string[] unverifiedDependencies=Array.Empty<string>();
        public EyeShaderPass[] passes=Array.Empty<EyeShaderPass>();
        public bool supported,hasErrors,sourceSaved;
    }
    [Serializable] public sealed class EyeMaterialProfile
    {
        public int schema=1;
        public string unity, sourceShader, targetShader, pipeline;
        public bool renderQueue;
        public EyePropertyMap[] properties=Array.Empty<EyePropertyMap>();
        public string[] keywords=Array.Empty<string>();
    }
    public sealed class EyeMaterialPlan
    {
        internal readonly Material source; internal readonly Shader target;
        internal readonly string profile, evidence;
        internal readonly double expires; internal bool consumed;
        public readonly string summary;
        internal EyeMaterialPlan(Material source, Shader target, string profile, string evidence, string summary)
        {this.source=source;this.target=target;this.profile=profile;this.evidence=evidence;this.summary=summary;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeMaterialMapping
    {
        public static string Hash(string value)
        {using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-","").ToLowerInvariant();}
        static void Idle()
        {if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Stop Play Mode and wait for compilation before reviewing materials.");}
        public static string[] Properties(Shader shader)
        {
            if(!shader||shader.GetPropertyCount()>512)throw new InvalidOperationException("Select a shader with at most 512 declared properties.");
            return Enumerable.Range(0,shader.GetPropertyCount()).Select(shader.GetPropertyName).ToArray();
        }
        public static string ObjectEvidence(Object value)
        {
            if(!value)return "null";
            string path=AssetDatabase.GetAssetPath(value);
            string json=EditorJsonUtility.ToJson(value);
            if(json.Length>4*1024*1024)throw new InvalidOperationException("Object exceeds material review budget.");
            return value.GetInstanceID()+"|"+path+"|"+json+"|"+(path.Length>0?AssetDatabase.GetAssetDependencyHash(path).ToString():"unsaved");
        }
        public static string ShaderIdentity(Shader shader)
        {
            var names=Properties(shader);var text=new StringBuilder(Application.unityVersion+"|"+shader.name+"|"+AssetDatabase.GetAssetPath(shader));
            string path=AssetDatabase.GetAssetPath(shader);
            if(path.Length>0)text.Append('|').Append(AssetDatabase.GetAssetDependencyHash(path));
            for(int i=0;i<names.Length;i++) {
                text.Append('|').Append(names[i]).Append(':').Append(shader.GetPropertyType(i));
                if(shader.GetPropertyType(i)==ShaderPropertyType.Texture)text.Append(':').Append(shader.GetPropertyTextureDimension(i));
            }
            foreach(var keyword in shader.keywordSpace.keywords.OrderBy(k=>k.name))text.Append('|').Append(keyword.name);
            return Hash(text.ToString());
        }
        public static string PipelineIdentity()
        {
            var pipeline=GraphicsSettings.currentRenderPipeline;
            string path=pipeline?AssetDatabase.GetAssetPath(pipeline):"";
            return Hash(Application.unityVersion+"|"+EditorUserBuildSettings.activeBuildTarget+"|"+path+"|"+
                (pipeline?EditorJsonUtility.ToJson(pipeline):"Built-in")+"|"+(path.Length>0?AssetDatabase.GetAssetDependencyHash(path).ToString():""));
        }
        static string Evidence(Material source,Shader target)
        {
            if(!source||!source.shader)throw new InvalidOperationException("A material with a declared source shader is required for typed mapping.");
            var text=new StringBuilder(ObjectEvidence(source)+"|"+ShaderIdentity(source.shader)+"|"+ShaderIdentity(target));
            foreach(var name in Properties(source.shader))
                if(source.shader.GetPropertyType(source.shader.FindPropertyIndex(name))==ShaderPropertyType.Texture)
                    text.Append('|').Append(ObjectEvidence(source.GetTexture(name)));
            text.Append('|').Append(EditorUserBuildSettings.activeBuildTarget).Append('|').Append(ObjectEvidence(GraphicsSettings.currentRenderPipeline));
            return Hash(text.ToString());
        }
        public static EyeMaterialProfile EmptyProfile(Material source,Shader target)
        {
            Idle();if(!source||!source.shader)throw new InvalidOperationException("Select a source material with a shader.");
            return new EyeMaterialProfile {unity=Application.unityVersion,sourceShader=ShaderIdentity(source.shader),targetShader=ShaderIdentity(target),pipeline=PipelineIdentity()};
        }
        static void Finite(float value)
        {if(float.IsNaN(value)||float.IsInfinity(value))throw new InvalidOperationException("Non-finite material values cannot be transferred.");}
        static void Finite(Vector4 value) {Finite(value.x);Finite(value.y);Finite(value.z);Finite(value.w);}
        static void Validate(Material source,Shader target,EyeMaterialProfile profile)
        {
            Idle();if(!source||!source.shader||!target||profile==null||profile.schema!=1)throw new InvalidOperationException("Select a source material, target shader and supported mapping profile.");
            if(profile.unity!=Application.unityVersion||profile.sourceShader!=ShaderIdentity(source.shader)||profile.targetShader!=ShaderIdentity(target)||profile.pipeline!=PipelineIdentity())
                throw new InvalidOperationException("Shader version, declared properties, render pipeline, platform or Unity version changed. Prepare a new exact-shader profile.");
            if(profile.properties==null||profile.properties.Length>512||profile.keywords==null||profile.keywords.Length>256)throw new InvalidOperationException("Mapping profile exceeds its budget.");
            var used=new HashSet<string>();var sources=new HashSet<string>();
            foreach(var map in profile.properties) {
                if(map==null||string.IsNullOrEmpty(map.source)||string.IsNullOrEmpty(map.target)||!used.Add(map.target)||!sources.Add(map.source))throw new InvalidOperationException("Missing or repeated material mapping.");
                int from=source.shader.FindPropertyIndex(map.source),to=target.FindPropertyIndex(map.target);
                if(from<0||to<0||source.shader.GetPropertyType(from)!=target.GetPropertyType(to))throw new InvalidOperationException("Property types must match exactly: "+map.source+" → "+map.target);
                switch(source.shader.GetPropertyType(from)) {
                    case ShaderPropertyType.Float:case ShaderPropertyType.Range:
                        float number=source.GetFloat(map.source);Finite(number);
                        if(target.GetPropertyType(to)==ShaderPropertyType.Range) {var limits=target.GetPropertyRangeLimits(to);if(number<limits.x||number>limits.y)throw new InvalidOperationException("Value is outside the target range: "+map.target);}
                        break;
                    case ShaderPropertyType.Int:break;
                    case ShaderPropertyType.Color:Finite((Vector4)source.GetColor(map.source));break;
                    case ShaderPropertyType.Vector:Finite(source.GetVector(map.source));break;
                    case ShaderPropertyType.Texture:
                        var texture=source.GetTexture(map.source);var dimension=target.GetPropertyTextureDimension(to);
                        if(source.shader.GetPropertyTextureDimension(from)!=dimension||texture&&texture.dimension!=dimension)throw new InvalidOperationException("Texture dimensions do not match: "+map.target);
                        if(texture&&!EditorUtility.IsPersistent(texture))throw new InvalidOperationException("Save the source texture asset before mapping.");
                        var scale=source.GetTextureScale(map.source);var offset=source.GetTextureOffset(map.source);Finite(new Vector4(scale.x,scale.y,offset.x,offset.y));break;
                    default:throw new InvalidOperationException("Unsupported material property type.");
                }
            }
            var available=new HashSet<string>(target.keywordSpace.keywords.Select(k=>k.name));
            if(profile.keywords.Distinct().Count()!=profile.keywords.Length||profile.keywords.Any(k=>!available.Contains(k)||!source.IsKeywordEnabled(k)))
                throw new InvalidOperationException("Only explicitly selected enabled source keywords declared by the target can be transferred.");
            if(profile.renderQueue&&(source.renderQueue < -1||source.renderQueue>5000))throw new InvalidOperationException("Unsupported render queue.");
        }
        public static EyeMaterialPlan Prepare(Material source,Shader target,EyeMaterialProfile profile)
        {
            Validate(source,target,profile);
            var lines=new List<string>{"Create a separate material from target shader defaults.","Source shader: "+source.shader.name,"Target shader: "+target.name,"Shader fingerprints: "+profile.sourceShader+" / "+profile.targetShader};
            foreach(var map in profile.properties)lines.Add(map.source+" → "+map.target+" ("+source.shader.GetPropertyType(source.shader.FindPropertyIndex(map.source))+"): "+ValueText(source,map.source));
            var mapped=new HashSet<string>(profile.properties.Select(m=>m.source));
            lines.Add("Dropped source properties: "+string.Join(", ",Properties(source.shader).Where(p=>!mapped.Contains(p))));
            lines.Add("Copied keywords: "+string.Join(", ",profile.keywords));
            lines.Add("Dropped source keywords: "+string.Join(", ",source.shaderKeywords.Except(profile.keywords)));
            lines.Add(profile.renderQueue?"Copy render queue: "+source.renderQueue:"Use target shader render queue.");
            lines.Add("Unmapped target properties use shader defaults. Texture references, offsets and scales transfer together. No color/number/vector conversions or guessed shader semantics. Review expires in five minutes; avatar assignments stay unchanged.");
            return new EyeMaterialPlan(source,target,JsonUtility.ToJson(profile),Evidence(source,target),string.Join("\n",lines));
        }
        static string ValueText(Material material,string property)
        {
            var type=material.shader.GetPropertyType(material.shader.FindPropertyIndex(property));
            switch(type) {
                case ShaderPropertyType.Float:case ShaderPropertyType.Range:return material.GetFloat(property).ToString("R",CultureInfo.InvariantCulture);
                case ShaderPropertyType.Int:return material.GetInteger(property).ToString(CultureInfo.InvariantCulture);
                case ShaderPropertyType.Color:return material.GetColor(property).ToString("F6");
                case ShaderPropertyType.Vector:return material.GetVector(property).ToString("F6");
                case ShaderPropertyType.Texture:
                    var texture=material.GetTexture(property);return (texture?texture.name+" ["+AssetDatabase.GetAssetPath(texture)+"]":"None")+"; scale "+material.GetTextureScale(property).ToString("F6")+"; offset "+material.GetTextureOffset(property).ToString("F6");
                default:return "Unsupported";
            }
        }
        public static string Compare(EyeMaterialPlan plan,Material copy)
        {
            var profile=JsonUtility.FromJson<EyeMaterialProfile>(plan.profile);
            return "Typed before → after comparison\n"+string.Join("\n",profile.properties.Select(row=>row.source+" → "+row.target+": "+ValueText(plan.source,row.source)+" → "+ValueText(copy,row.target)))+
                "\nQueue: "+plan.source.renderQueue+" → "+copy.renderQueue+"\nOutput keywords: "+string.Join(", ",copy.shaderKeywords)+
                "\nThese values do not establish equivalent shader lighting or appearance. Avatar assignment remains separate.";
        }
        public static void VerifyCopy(Material expected,Material actual)
        {
            if(!expected||!actual||expected.shader!=actual.shader||expected.renderQueue!=actual.renderQueue||
                expected.enableInstancing!=actual.enableInstancing||expected.doubleSidedGI!=actual.doubleSidedGI||expected.globalIlluminationFlags!=actual.globalIlluminationFlags||
                !expected.shaderKeywords.OrderBy(v=>v,StringComparer.Ordinal).SequenceEqual(actual.shaderKeywords.OrderBy(v=>v,StringComparer.Ordinal)))
                throw new InvalidOperationException("Published material shader, flags, queue or keywords changed during import.");
            foreach(string property in Properties(expected.shader)) {
                bool same=false;
                switch(expected.shader.GetPropertyType(expected.shader.FindPropertyIndex(property))) {
                    case ShaderPropertyType.Float:case ShaderPropertyType.Range:same=expected.GetFloat(property).Equals(actual.GetFloat(property));break;
                    case ShaderPropertyType.Int:same=expected.GetInteger(property)==actual.GetInteger(property);break;
                    case ShaderPropertyType.Color:same=expected.GetColor(property).Equals(actual.GetColor(property));break;
                    case ShaderPropertyType.Vector:same=expected.GetVector(property).Equals(actual.GetVector(property));break;
                    case ShaderPropertyType.Texture:same=expected.GetTexture(property)==actual.GetTexture(property)&&expected.GetTextureScale(property).Equals(actual.GetTextureScale(property))&&expected.GetTextureOffset(property).Equals(actual.GetTextureOffset(property));break;
                }
                if(!same)throw new InvalidOperationException("Published material property changed during import: "+property);
            }
        }
        public static Material BuildCopy(EyeMaterialPlan plan)
        {
            if(plan==null||plan.consumed||EditorApplication.timeSinceStartup>=plan.expires)throw new InvalidOperationException("Mapping review expired or was used.");
            var profile=JsonUtility.FromJson<EyeMaterialProfile>(plan.profile);Validate(plan.source,plan.target,profile);
            if(plan.evidence!=Evidence(plan.source,plan.target))throw new InvalidOperationException("Material, textures, shader or pipeline changed after review.");
            var copy=new Material(plan.target) {name=plan.source.name+" (mapped copy)"};
            try {
                foreach(var map in profile.properties) {
                    switch(plan.target.GetPropertyType(plan.target.FindPropertyIndex(map.target))) {
                        case ShaderPropertyType.Float:case ShaderPropertyType.Range:copy.SetFloat(map.target,plan.source.GetFloat(map.source));break;
                        case ShaderPropertyType.Int:copy.SetInteger(map.target,plan.source.GetInteger(map.source));break;
                        case ShaderPropertyType.Color:copy.SetColor(map.target,plan.source.GetColor(map.source));break;
                        case ShaderPropertyType.Vector:copy.SetVector(map.target,plan.source.GetVector(map.source));break;
                        case ShaderPropertyType.Texture:
                            copy.SetTexture(map.target,plan.source.GetTexture(map.source));copy.SetTextureScale(map.target,plan.source.GetTextureScale(map.source));copy.SetTextureOffset(map.target,plan.source.GetTextureOffset(map.source));break;
                    }
                }
                copy.shaderKeywords=Array.Empty<string>();foreach(var keyword in profile.keywords)copy.EnableKeyword(keyword);
                if(profile.renderQueue)copy.renderQueue=plan.source.renderQueue;
                return copy;
            } catch {Object.DestroyImmediate(copy);throw;}
        }
        public static string Execute(EyeMaterialPlan plan)
        {
            if(plan==null)throw new InvalidOperationException("Prepare a material copy first.");
            using(var history=EyeCopyHistory.Begin("Typed material mapping",plan.evidence,plan.summary)) {
                string result=ExecuteCore(plan);history.Complete(result);return result;
            }
        }
        static string ExecuteCore(EyeMaterialPlan plan)
        {
            var copy=BuildCopy(plan);var expected=new Material(copy);plan.consumed=true;string folder="";
            try {
                folder=EyeAvatarRepair.NewFolder();
                if(plan.evidence!=Evidence(plan.source,plan.target))throw new InvalidOperationException("Source changed before material publication.");
                string path=folder+"/material-mapped.mat";EyeAvatarRepair.CreateAsset(copy,path);
                EyeCopyHistory.Before(path);EyeAvatarRepair.CheckProjectOutput(path);
                AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
                EyeCopyHistory.After(path);
                if(plan.evidence!=Evidence(plan.source,plan.target))throw new InvalidOperationException("Source changed during material import. Inspect retained output.");
                VerifyCopy(expected,AssetDatabase.LoadAssetAtPath<Material>(path));return path;
            } catch {if(copy&&!AssetDatabase.Contains(copy))Object.DestroyImmediate(copy);throw;}
            finally {Object.DestroyImmediate(expected);}
        }
        public static string Diagnostics(Material source,bool compile=false)
        {return DiagnosticsCore(source,compile,null);}
        static string DiagnosticsCore(Material source,bool compile,EyeShaderObservation observation)
        {
            Idle();if(!source||!source.shader)throw new InvalidOperationException("Select a material with a shader.");
            if(source.passCount>128)throw new InvalidOperationException("Material pass budget exceeded.");
            // Compile current material variants on a disposable copy; no keyword,
            // build-target, quality or source-asset settings are changed.
            var copy=new Material(source);
            try {
                var lines=new List<string>{"Unity: "+Application.unityVersion,"Active build target: "+EditorUserBuildSettings.activeBuildTarget,"Editor graphics API: "+SystemInfo.graphicsDeviceType,"Pipeline: "+(GraphicsSettings.currentRenderPipeline?GraphicsSettings.currentRenderPipeline.name:"Built-in"),"Shader supported on this editor: "+source.shader.isSupported,"Render queue: "+source.renderQueue};
                var passes=new List<EyeShaderPass>();
                for(int pass=0;pass<copy.passCount;pass++) {
                    if(compile)ShaderUtil.CompilePass(copy,pass,true);
                    bool compiled=ShaderUtil.IsPassCompiled(copy,pass);string name=copy.GetPassName(pass);
                    passes.Add(new EyeShaderPass{index=pass,name=name,compiled=compiled});
                    lines.Add("Pass "+pass+" "+name+": "+(compiled?"Compiled":"Not compiled"));
                }
                if(observation!=null) {observation.passes=passes.ToArray();observation.supported=source.shader.isSupported;observation.hasErrors=ShaderUtil.ShaderHasError(source.shader);}
                lines.Add("Compiler has errors: "+ShaderUtil.ShaderHasError(source.shader));
                foreach(var message in ShaderUtil.GetShaderMessages(source.shader).Take(100))lines.Add(message.severity+": "+message.message);
                foreach(var name in Properties(source.shader)) {
                    var type=source.shader.GetPropertyType(source.shader.FindPropertyIndex(name));
                    lines.Add(name+" : "+type+(type==ShaderPropertyType.Texture?" = "+(source.GetTexture(name)?source.GetTexture(name).name:"None"):""));
                }
                lines.Add("Enabled keywords: "+string.Join(", ",source.shaderKeywords));
                lines.Add("This reports the current editor/pipeline/material variants. Other platforms, quality levels and runtime variant stripping need separate builds.");
                return string.Join("\n",lines);
            } finally {Object.DestroyImmediate(copy);}
        }
        public static string ExportDiagnostics(Material source,string path,bool compile=false)
        {
            Idle();if(string.IsNullOrWhiteSpace(path)||!path.EndsWith(".json",StringComparison.OrdinalIgnoreCase))throw new IOException("Choose a new JSON observation file.");
            string before=ObjectEvidence(source),shader=source&&source.shader?ShaderIdentity(source.shader):"";
            if(!source||!source.shader)throw new InvalidOperationException("Select a material with a shader.");
            string pipeline=PipelineIdentity();var files=EyeShaderFileEvidence.Capture(source);bool saved=EyeShaderFileEvidence.Saved(source);
            var row=new EyeShaderObservation{capturedUtc=DateTime.UtcNow.ToString("O"),unity=Application.unityVersion,buildTarget=EditorUserBuildSettings.activeBuildTarget.ToString(),
                graphicsApi=SystemInfo.graphicsDeviceType.ToString(),pipeline=pipeline,shaderIdentity=shader,materialEvidence=Hash(before),compilationRequested=compile,
                projectPath=EyeShaderFileEvidence.ProjectRoot,materialPath=AssetDatabase.GetAssetPath(source),shaderPath=AssetDatabase.GetAssetPath(source.shader),
                files=files.files,unverifiedDependencies=files.unverified,sourceSaved=saved};
            string report=DiagnosticsCore(source,compile,row);row.report=report;
            if(ObjectEvidence(source)!=before||ShaderIdentity(source.shader)!=shader||PipelineIdentity()!=pipeline||EyeShaderFileEvidence.Saved(source)!=saved||EyeShaderFileEvidence.Capture(source).Identity!=files.Identity)
                throw new InvalidOperationException("Material, shader, pipeline or dependency files changed while diagnostics ran; capture again.");
            string json=JsonUtility.ToJson(row,true);if(Encoding.UTF8.GetByteCount(json)>2*1024*1024)throw new IOException("Shader observations exceed 2 MiB.");
            using(var history=EyeCopyHistory.Begin("Shader diagnostic export",row.materialEvidence,"Record measured current-editor shader observations; no material or assignment changes")) {
                EyeCopyHistory.Before(path,true);
                using(var file=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var writer=new StreamWriter(file,new UTF8Encoding(false)))writer.Write(json);
                EyeCopyHistory.After(path,true);history.Complete(path);
            }
            return report+"\n\nSaved observation: "+path;
        }
    }
    public sealed class EyeMaterialMappingWindow : EditorWindow
    {
        Material source;Shader target;EyeMaterialProfile profile;EyeMaterialPlan plan;
        bool authorized;Vector2 scroll;string report="Select a material and an exact target shader.";
        [MenuItem("VRC Eye/Typed Material Mapping")]
        public static void Open() {GetWindow<EyeMaterialMappingWindow>("Material Mapping");}
        void Run(Action action) {try{action();}catch(Exception error){plan=null;report="Stopped: "+error.Message;}}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);EditorGUI.BeginChangeCheck();
            source=(Material)EditorGUILayout.ObjectField("Source material",source,typeof(Material),false);
            target=(Shader)EditorGUILayout.ObjectField("Target shader",target,typeof(Shader),false);
            if(EditorGUI.EndChangeCheck()){profile=null;plan=null;authorized=false;}
            authorized=EditorGUILayout.ToggleLeft("I have permission to inspect and copy these assets",authorized);
            using(new EditorGUI.DisabledScope(!source||!authorized)) {
                if(GUILayout.Button("Read current shader diagnostics"))Run(()=>report=EyeMaterialMapping.Diagnostics(source));
                if(GUILayout.Button("Compile and inspect current material variants…"))Run(()=>{if(EditorUtility.DisplayDialog("Compile current variants?","Compile the selected material passes in the current editor. This can take time and does not validate other platforms.","Compile","Cancel"))report=EyeMaterialMapping.Diagnostics(source,true);});
                if(GUILayout.Button("Compile and save diagnostic observation…"))Run(()=>{
                    string path=EditorUtility.SaveFilePanel("New current-editor shader observation","","VRC-Eye-Shader-Observation.json","json");if(path.Length==0)return;
                    if(EditorUtility.DisplayDialog("Compile and record current variants?","Compile the selected material in the current editor, then save file hashes, local project path and measured per-pass results. Save the material first; close Unity before importing the JSON in desktop Recovery History against its shader installation. Other platforms need separate builds.","Compile and save","Cancel"))report=EyeMaterialMapping.ExportDiagnostics(source,path,true);
                });
            }
            using(new EditorGUI.DisabledScope(!source||!target||!authorized)) {
                if(GUILayout.Button("Start exact-shader mapping"))Run(()=>{profile=EyeMaterialMapping.EmptyProfile(source,target);profile.properties=EyeMaterialMapping.Properties(source.shader).Select(p=>new EyePropertyMap{source=p,target=""}).ToArray();plan=null;});
                if(GUILayout.Button("Load mapping profile…"))Run(()=>{
                    string path=EditorUtility.OpenFilePanel("Mapping profile","","json");if(path.Length==0)return;
                    if(new FileInfo(path).Length>256*1024)throw new IOException("Mapping profile exceeds 256 KiB.");
                    var loaded=JsonUtility.FromJson<EyeMaterialProfile>(File.ReadAllText(path));EyeMaterialMapping.Prepare(source,target,loaded);profile=loaded;plan=null;
                });
            }
            if(profile!=null&&source&&target)Run(()=>{
                EditorGUI.BeginChangeCheck();var names=new[]{"(Drop / use target default)"}.Concat(EyeMaterialMapping.Properties(target)).ToArray();
                foreach(var row in profile.properties) {
                    int chosen=Array.IndexOf(names,row.target);chosen=Math.Max(0,chosen);
                    int selected=EditorGUILayout.Popup(row.source,chosen,names);row.target=selected==0?"":names[selected];
                }
                profile.renderQueue=EditorGUILayout.ToggleLeft("Transfer source render queue",profile.renderQueue);
                var keywords=new HashSet<string>(profile.keywords);
                foreach(var key in source.shaderKeywords.Intersect(target.keywordSpace.keywords.Select(k=>k.name))) {
                    if(EditorGUILayout.ToggleLeft("Transfer keyword "+key,keywords.Contains(key)))keywords.Add(key);else keywords.Remove(key);
                }
                profile.keywords=keywords.OrderBy(k=>k).ToArray();if(EditorGUI.EndChangeCheck())plan=null;
                Func<EyeMaterialProfile> selectedProfile=()=>new EyeMaterialProfile {schema=profile.schema,unity=profile.unity,sourceShader=profile.sourceShader,targetShader=profile.targetShader,pipeline=profile.pipeline,renderQueue=profile.renderQueue,keywords=profile.keywords,properties=profile.properties.Where(p=>!string.IsNullOrEmpty(p.target)).ToArray()};
                if(GUILayout.Button("Review typed transfer")){plan=EyeMaterialMapping.Prepare(source,target,selectedProfile());report=plan.summary;}
                if(GUILayout.Button("Save exact-shader profile…")) {
                    var candidate=selectedProfile();EyeMaterialMapping.Prepare(source,target,candidate);
                    string path=EditorUtility.SaveFilePanel("New mapping profile","","VRC-Eye-Material-Mapping.json","json");
                    if(path.Length>0)using(var file=new FileStream(path,FileMode.CreateNew,FileAccess.Write))using(var writer=new StreamWriter(file))writer.Write(JsonUtility.ToJson(candidate,true));
                }
                using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Create reviewed material copy…")) {
                    var reviewed=plan;if(EditorUtility.DisplayDialog("Create material copy?",reviewed.summary,"Create","Cancel")) {plan=null;string path=EyeMaterialMapping.Execute(reviewed);report="Created: "+path+"\n"+EyeMaterialMapping.Compare(reviewed,AssetDatabase.LoadAssetAtPath<Material>(path));}
                }
            });
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(200));EditorGUILayout.EndScrollView();
        }
    }
}
