// Explicit animation binding/value maps into separate clips. Unity qualification required.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeBindingMap
    {
        public readonly EditorCurveBinding source,target;
        public EyeBindingMap(EditorCurveBinding source,EditorCurveBinding target){this.source=source;this.target=target;}
    }
    public sealed class EyeAnimationPlan
    {
        internal readonly AnimationClip source;internal readonly GameObject root;
        internal readonly EyeBindingMap[] maps;internal readonly Dictionary<Object,Object> values;
        internal readonly string fingerprint;internal readonly double expires;internal bool used;
        public readonly string summary;
        internal EyeAnimationPlan(AnimationClip source,GameObject root,EyeBindingMap[] maps,Dictionary<Object,Object> values,string evidence,string summary)
        {this.source=source;this.root=root;this.maps=maps;this.values=values;fingerprint=evidence;this.summary=summary;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeAnimationCopies
    {
        const int MaxBindings=2000,MaxKeys=200000;
        public static string Key(EditorCurveBinding value)
        {return value.path+" | "+(value.type==null?"missing type":value.type.FullName)+" | "+value.propertyName+" | "+(value.isPPtrCurve?"object":"float");}
        static void Idle()
        {if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Stop Play Mode and wait for compilation.");}
        public static EditorCurveBinding[] Bindings(AnimationClip source)
        {
            Idle();if(!source||!EditorUtility.IsPersistent(source))throw new InvalidOperationException("Choose a saved animation clip.");
            var bindings=AnimationUtility.GetCurveBindings(source).Concat(AnimationUtility.GetObjectReferenceCurveBindings(source)).ToArray();
            if(bindings.Length==0||bindings.Length>MaxBindings)throw new InvalidOperationException("Choose a clip with 1–2,000 explicit float/object bindings. Humanoid muscle retargeting is unsupported.");
            if(bindings.Select(Key).Distinct().Count()!=bindings.Length)throw new InvalidOperationException("Source binding identities collide.");
            int keys=0;
            foreach(var binding in bindings) {
                if(binding.type==null)throw new InvalidOperationException("A source binding type is missing.");
                if(binding.isPPtrCurve)keys+=AnimationUtility.GetObjectReferenceCurve(source,binding).Length;
                else keys+=AnimationUtility.GetEditorCurve(source,binding).length;
                if(keys>MaxKeys)throw new InvalidOperationException("Animation exceeds 200,000 keys.");
            }
            return bindings;
        }
        public static EditorCurveBinding[] Targets(GameObject root)
        {
            Idle();if(!root||!EditorUtility.IsPersistent(root)||!AssetDatabase.GetAssetPath(root).EndsWith(".prefab",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GetAssetPath(root))!=root)
                throw new InvalidOperationException("Choose the saved target prefab root. This operation creates a clip and never assigns it.");
            var objects=EyeComponentCopies.Objects(root);var paths=new HashSet<string>();var targets=new List<EditorCurveBinding>();
            foreach(var go in objects.Values.OfType<GameObject>()) {
                string path=AnimationUtility.CalculateTransformPath(go.transform,root.transform);
                if(!paths.Add(path))throw new InvalidOperationException("Duplicate hierarchy paths make binding targets ambiguous.");
                if(go.GetComponents<Component>().Where(c=>c).GroupBy(c=>c.GetType()).Any(g=>g.Count()>1))throw new InvalidOperationException("Repeated component types make binding targets ambiguous.");
                targets.AddRange(AnimationUtility.GetAnimatableBindings(go,root));
                if(targets.Count>100000)throw new InvalidOperationException("Target hierarchy exceeds 100,000 animatable properties.");
            }
            return targets.GroupBy(Key).Select(g=>g.First()).OrderBy(Key,StringComparer.Ordinal).ToArray();
        }
        public static Object[] ReferenceValues(AnimationClip source)
        {
            var values=Bindings(source).Where(b=>b.isPPtrCurve).SelectMany(b=>AnimationUtility.GetObjectReferenceCurve(source,b)).Select(k=>k.value).Where(v=>v).Distinct().Take(257).ToArray();
            if(values.Length>256)throw new InvalidOperationException("Animation exceeds 256 distinct object-curve assets.");return values;
        }
        static string Fingerprint(AnimationClip source,GameObject root,Dictionary<Object,Object> values)
        {
            var parts=new List<string>{Application.unityVersion,EyeMaterialMapping.ObjectEvidence(source)};long size=0;
            foreach(var item in EyeComponentCopies.Objects(root).Values.Concat(ReferenceValues(source)).Concat(values.Values).Distinct()) {
                string value=EyeMaterialMapping.ObjectEvidence(item);size+=value.Length;if(size>32*1024*1024)throw new InvalidOperationException("Animation review evidence exceeds 32 MiB.");parts.Add(value);
            }
            return EyeMaterialMapping.Hash(string.Join("\n",parts));
        }
        static void ValueTypes(AnimationClip source,GameObject root,EyeBindingMap[] maps,Dictionary<Object,Object> values)
        {
            foreach(var map in maps.Where(m=>m.target.isPPtrCurve)) {
                var node=map.target.path.Length==0?root.transform:root.transform.Find(map.target.path);
                if(!node)throw new InvalidOperationException("Missing object-curve target.");
                Object owner=map.target.type==typeof(GameObject)?(Object)node.gameObject:node.GetComponent(map.target.type);
                if(!owner)throw new InvalidOperationException("Missing object-curve component.");
                var property=new SerializedObject(owner).FindProperty(map.target.propertyName);
                if(property==null||property.propertyType!=SerializedPropertyType.ObjectReference||!property.type.StartsWith("PPtr<",StringComparison.Ordinal)||!property.type.EndsWith(">",StringComparison.Ordinal))
                    throw new InvalidOperationException("Unity did not expose the declared target reference type: "+Key(map.target));
                string expected=property.type.Substring(5,property.type.Length-6).TrimStart('$');
                foreach(var key in AnimationUtility.GetObjectReferenceCurve(source,map.source)) {
                    Object value=key.value,replacement;if(value&&values.TryGetValue(value,out replacement))value=replacement;
                    if(!value)continue;
                    Type type=value.GetType();while(type!=null&&type.Name!=expected)type=type.BaseType;
                    if(type==null)throw new InvalidOperationException("Object curve value is incompatible with target reference type "+expected);
                }
            }
        }
        public static EyeAnimationPlan Prepare(AnimationClip source,GameObject root,IEnumerable<EyeBindingMap> selected,IDictionary<Object,Object> replacements=null)
        {
            var bindings=Bindings(source);var targets=Targets(root);var maps=(selected??Array.Empty<EyeBindingMap>()).Take(MaxBindings+1).ToArray();
            var sourceKeys=new HashSet<string>(bindings.Select(Key));var targetKeys=new HashSet<string>(targets.Select(Key));var seen=new HashSet<string>();var output=new HashSet<string>();
            if(maps.Length!=bindings.Length)throw new InvalidOperationException("Map every source binding exactly once; dropping curves is unsupported.");
            foreach(var map in maps) {
                if(map==null||!sourceKeys.Contains(Key(map.source))||!seen.Add(Key(map.source))||!targetKeys.Contains(Key(map.target)))throw new InvalidOperationException("Choose an existing source binding and a verified target property for every curve.");
                if(map.source.type!=map.target.type||map.source.isPPtrCurve!=map.target.isPPtrCurve)throw new InvalidOperationException("Binding component type and float/object representation must match exactly.");
                if(!output.Add(Key(map.target)))throw new InvalidOperationException("Multiple curves collide at one destination binding.");
            }
            var values=replacements==null?new Dictionary<Object,Object>():new Dictionary<Object,Object>(replacements);var originals=ReferenceValues(source);
            if(values.Count>originals.Length)throw new InvalidOperationException("Unused object-reference replacements are unsupported.");
            foreach(var pair in values)if(!pair.Key||!pair.Value||!originals.Contains(pair.Key)||!EditorUtility.IsPersistent(pair.Value)||pair.Key.GetType()!=pair.Value.GetType()||pair.Value is GameObject||pair.Value is Component)
                throw new InvalidOperationException("Replace only referenced assets with saved assets of the same exact type. Scene/hierarchy object values are unsupported.");
            foreach(var value in originals)if(!EditorUtility.IsPersistent(value)||value is GameObject||value is Component)throw new InvalidOperationException("Object curves must reference saved non-hierarchy assets.");
            ValueTypes(source,root,maps,values);
            string summary="Create a separate animation clip for target prefab "+root.name+". All "+maps.Length+" bindings resolve to Unity-reported animatable properties.\n"+
                "No source or target assignment is changed; no animation/event is played. Float keyframes, interpolation and clip settings are retained. Object-key times are retained; only listed asset values change. This is property mapping, not humanoid retargeting or semantic equivalence. Review expires in five minutes.\n\n"+
                string.Join("\n",maps.Select(m=>Key(m.source)+" → "+Key(m.target)))+"\n\nObject replacements:\n"+string.Join("\n",values.Select(p=>AssetDatabase.GetAssetPath(p.Key)+" → "+AssetDatabase.GetAssetPath(p.Value)));
            return new EyeAnimationPlan(source,root,maps,values,Fingerprint(source,root,values),summary);
        }
        static void Fresh(EyeAnimationPlan plan)
        {
            Idle();Targets(plan.root);Bindings(plan.source);ValueTypes(plan.source,plan.root,plan.maps,plan.values);
            if(Fingerprint(plan.source,plan.root,plan.values)!=plan.fingerprint)throw new InvalidOperationException("Clip, target hierarchy or referenced asset changed after review.");
        }
        static Object Mapped(EyeAnimationPlan plan,Object value)
        {Object replacement;return value&&plan.values.TryGetValue(value,out replacement)?replacement:value;}
        static void Verify(EyeAnimationPlan plan,AnimationClip copy)
        {
            if(copy.frameRate!=plan.source.frameRate||copy.legacy!=plan.source.legacy||copy.wrapMode!=plan.source.wrapMode)throw new InvalidOperationException("Copied clip settings changed.");
            if(!new HashSet<string>(Bindings(copy).Select(Key)).SetEquals(plan.maps.Select(m=>Key(m.target))))throw new InvalidOperationException("Saved binding identities differ from the review.");
            foreach(var map in plan.maps) {
                if(map.source.isPPtrCurve) {
                    var original=AnimationUtility.GetObjectReferenceCurve(plan.source,map.source);var current=AnimationUtility.GetObjectReferenceCurve(copy,map.target);
                    if(original.Length!=current.Length)throw new InvalidOperationException("Object key count changed.");
                    for(int i=0;i<original.Length;i++)if(original[i].time!=current[i].time||Mapped(plan,original[i].value)!=current[i].value)throw new InvalidOperationException("Object curve values did not survive save/reload.");
                } else {
                    var original=AnimationUtility.GetEditorCurve(plan.source,map.source);var current=AnimationUtility.GetEditorCurve(copy,map.target);
                    if(original.preWrapMode!=current.preWrapMode||original.postWrapMode!=current.postWrapMode||!original.keys.SequenceEqual(current.keys))throw new InvalidOperationException("Float keys or interpolation changed after save/reload.");
                }
            }
            var a=AnimationUtility.GetAnimationEvents(plan.source);var b=AnimationUtility.GetAnimationEvents(copy);
            if(a.Length!=b.Length)throw new InvalidOperationException("Animation events changed.");
            for(int i=0;i<a.Length;i++)if(a[i].time!=b[i].time||a[i].functionName!=b[i].functionName||a[i].floatParameter!=b[i].floatParameter||a[i].intParameter!=b[i].intParameter||a[i].stringParameter!=b[i].stringParameter||a[i].objectReferenceParameter!=b[i].objectReferenceParameter||a[i].messageOptions!=b[i].messageOptions)throw new InvalidOperationException("Animation event data changed.");
        }
        public static string Execute(EyeAnimationPlan plan)
        {
            if(plan==null||plan.used||EditorApplication.timeSinceStartup>=plan.expires)throw new InvalidOperationException("Animation review expired or was used.");
            Fresh(plan);plan.used=true;
            using(var history=EyeCopyHistory.Begin("Animation binding/value copy",plan.fingerprint,plan.summary)) {
                string path=EyeAvatarRepair.NewFolder()+"/animation-mapped.anim";var copy=Object.Instantiate(plan.source);
                try {
                    foreach(var binding in AnimationUtility.GetCurveBindings(copy))AnimationUtility.SetEditorCurve(copy,binding,null);
                    foreach(var binding in AnimationUtility.GetObjectReferenceCurveBindings(copy))AnimationUtility.SetObjectReferenceCurve(copy,binding,null);
                    foreach(var map in plan.maps) {
                        if(map.source.isPPtrCurve) {
                            var keys=AnimationUtility.GetObjectReferenceCurve(plan.source,map.source);
                            for(int i=0;i<keys.Length;i++)keys[i].value=Mapped(plan,keys[i].value);
                            AnimationUtility.SetObjectReferenceCurve(copy,map.target,keys);
                        } else AnimationUtility.SetEditorCurve(copy,map.target,AnimationUtility.GetEditorCurve(plan.source,map.source));
                    }
                    Fresh(plan);EyeAvatarRepair.CreateAsset(copy,path);
                    EyeCopyHistory.Before(path);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);EyeCopyHistory.After(path);
                    var saved=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);if(!saved)throw new IOException("Copied clip could not be reloaded.");
                    Fresh(plan);Verify(plan,saved);history.Complete(path);return path;
                } finally {if(copy&&!AssetDatabase.Contains(copy))Object.DestroyImmediate(copy);}
            }
        }
    }
    public sealed class EyeAnimationCopiesWindow:EditorWindow
    {
        AnimationClip source;GameObject target;bool authorized;Vector2 scroll;EyeAnimationPlan plan;int bindingPage;
        EditorCurveBinding[] bindings=Array.Empty<EditorCurveBinding>(),targets=Array.Empty<EditorCurveBinding>();
        readonly Dictionary<string,EditorCurveBinding> choices=new Dictionary<string,EditorCurveBinding>();readonly Dictionary<Object,Object> replacements=new Dictionary<Object,Object>();
        Object[] values=Array.Empty<Object>();string report="Choose a saved clip and target prefab. Every binding needs an explicit target.";
        [MenuItem("VRC Eye/Animation Binding Copies")]
        public static void Open(){GetWindow<EyeAnimationCopiesWindow>("Animation Copies");}
        void Run(Action action){try{action();}catch(Exception error){plan=null;report="Stopped: "+error.Message;}}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);EditorGUI.BeginChangeCheck();
            source=(AnimationClip)EditorGUILayout.ObjectField("Source clip",source,typeof(AnimationClip),false);
            target=(GameObject)EditorGUILayout.ObjectField("Target prefab",target,typeof(GameObject),false);
            authorized=EditorGUILayout.ToggleLeft("I have permission to copy these assets",authorized);
            if(EditorGUI.EndChangeCheck()){plan=null;bindingPage=0;bindings=Array.Empty<EditorCurveBinding>();targets=Array.Empty<EditorCurveBinding>();choices.Clear();replacements.Clear();values=Array.Empty<Object>();}
            using(new EditorGUI.DisabledScope(!authorized||!source||!target))if(GUILayout.Button("Inspect binding choices"))Run(()=>{bindings=EyeAnimationCopies.Bindings(source);targets=EyeAnimationCopies.Targets(target);values=EyeAnimationCopies.ReferenceValues(source);plan=null;bindingPage=0;choices.Clear();replacements.Clear();});
            if(bindings.Length>25) {
                EditorGUILayout.LabelField("Binding page "+(bindingPage+1)+" / "+((bindings.Length+24)/25)+"; mapped "+choices.Count+" / "+bindings.Length);
                EditorGUILayout.BeginHorizontal();using(new EditorGUI.DisabledScope(bindingPage==0))if(GUILayout.Button("Previous bindings"))bindingPage--;
                using(new EditorGUI.DisabledScope((bindingPage+1)*25>=bindings.Length))if(GUILayout.Button("Next bindings"))bindingPage++;EditorGUILayout.EndHorizontal();
            }
            foreach(var binding in bindings.Skip(bindingPage*25).Take(25)) {
                var compatible=targets.Where(t=>t.type==binding.type&&t.isPPtrCurve==binding.isPPtrCurve).ToArray();var labels=new[]{"(Choose target property)"}.Concat(compatible.Select(EyeAnimationCopies.Key)).ToArray();
                EditorCurveBinding current;int selected=choices.TryGetValue(EyeAnimationCopies.Key(binding),out current)?Array.FindIndex(compatible,t=>EyeAnimationCopies.Key(t)==EyeAnimationCopies.Key(current))+1:0;
                int next=EditorGUILayout.Popup(EyeAnimationCopies.Key(binding),Math.Max(0,selected),labels);
                if(next!=selected){plan=null;if(next==0)choices.Remove(EyeAnimationCopies.Key(binding));else choices[EyeAnimationCopies.Key(binding)]=compatible[next-1];}
            }
            foreach(var original in values) {
                Object current;replacements.TryGetValue(original,out current);
                var next=EditorGUILayout.ObjectField("Replace "+original.name+" (optional)",current,original.GetType(),false);
                if(next!=current){plan=null;if(next)replacements[original]=next;else replacements.Remove(original);}
            }
            using(new EditorGUI.DisabledScope(!authorized||bindings.Length==0||choices.Count!=bindings.Length))if(GUILayout.Button("Review animation copy"))Run(()=>{plan=EyeAnimationCopies.Prepare(source,target,bindings.Select(b=>new EyeBindingMap(b,choices[EyeAnimationCopies.Key(b)])),replacements);report=plan.summary;});
            using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Create reviewed animation copy…"))Run(()=>{var reviewed=plan;if(EditorUtility.DisplayDialog("Create separate animation?",reviewed.summary,"Create","Cancel")){plan=null;report="Created: "+EyeAnimationCopies.Execute(reviewed);}});
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(220));EditorGUILayout.EndScrollView();
        }
    }
}
