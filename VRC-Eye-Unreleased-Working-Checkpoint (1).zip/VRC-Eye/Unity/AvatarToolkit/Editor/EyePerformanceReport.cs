using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEngine;

namespace VrcEye.AvatarToolkit
{
    // Explicit, editor-only source analysis. No build/upload hook or SDK installation.
    // Reflect only the named public SDK contract; unsupported signatures stop capture.
    public static class EyePerformanceReport
    {
        public const string Schema = "vrc-eye-avatar-performance-1";
        static readonly string[] Counts = {
            "polyCount", "skinnedMeshCount", "meshCount", "materialCount", "animatorCount", "boneCount",
            "lightCount", "particleSystemCount", "particleTotalCount", "particleMaxMeshPolyCount",
            "trailRendererCount", "lineRendererCount", "clothCount", "clothMaxVertices", "physicsColliderCount",
            "physicsRigidbodyCount", "audioSourceCount", "contactCount", "contactCompleteCount",
            "constraintsCount", "constraintDepth", "raycastCount" };
        static readonly string[] PhysBones = { "componentCount", "transformCount", "colliderCount", "collisionCheckCount" };
        static readonly Regex Id = new Regex(@"\Aavtr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\z");
        static readonly Regex Version = new Regex(@"\A\d+\.\d+\.\d+(?:[-+.][A-Za-z0-9.-]+)?\z");

        static object Field(object owner, string name)
        {
            if (owner == null) return null;
            var field = owner.GetType().GetField(name, BindingFlags.Public | BindingFlags.Instance);
            return field == null ? null : field.GetValue(owner);
        }

        static object Count(object value, string field)
        {
            if (value == null) return null;
            if (!(value is int || value is long || value is uint || value is ushort || value is byte || value is short))
                throw new InvalidOperationException("SDK counter has an unsupported type: " + field);
            long number = Convert.ToInt64(value, CultureInfo.InvariantCulture);
            if (number < 0 || number > 9007199254740991L) throw new InvalidOperationException("Invalid SDK counter: " + field);
            return number;
        }

        public static Dictionary<string, object> Build(object measured, string avatarId, string platform,
            string sdkVersion, string baseVersion, string unityVersion, DateTimeOffset observed)
        {
            if (measured == null || !Id.IsMatch(avatarId ?? "")) throw new InvalidOperationException("Select an avatar with a valid SDK blueprint ID.");
            if (!new[] { "standalonewindows", "android", "ios" }.Contains(platform)) throw new InvalidOperationException("Unsupported active build target.");
            if (!Version.IsMatch(sdkVersion ?? "") || !Version.IsMatch(baseVersion ?? "") || sdkVersion.Length > 80 || baseVersion.Length > 80)
                throw new InvalidOperationException("Installed Avatars and Base SDK package versions must be available.");
            if (String.IsNullOrWhiteSpace(unityVersion) || unityVersion.Length > 80 || unityVersion.Any(Char.IsControl))
                throw new InvalidOperationException("Unity version is unavailable.");
            var stats = new Dictionary<string, object>();
            foreach (string key in Counts) stats[key] = Count(Field(measured, key), key);
            foreach (string key in new[] { "particleTrailsEnabled", "particleCollisionEnabled" })
            {
                object value = Field(measured, key);
                if (value != null && !(value is bool)) throw new InvalidOperationException("SDK flag has an unsupported type: " + key);
                stats[key] = value;
            }
            object texture = Field(measured, "textureMegabytes");
            if (texture != null)
            {
                if (!(texture is float || texture is double || texture is int || texture is long))
                    throw new InvalidOperationException("SDK texture memory has an unsupported type.");
                double value = Convert.ToDouble(texture, CultureInfo.InvariantCulture);
                if (Double.IsNaN(value) || Double.IsInfinity(value) || value < 0 || value > 1e9)
                    throw new InvalidOperationException("SDK texture memory is invalid.");
                texture = value;
            }
            stats["textureMegabytes"] = texture;
            // Source analysis cannot establish sizes of an actual built/compressed artifact.
            stats["downloadSizeBytes"] = null;
            stats["uncompressedSizeBytes"] = null;
            var phys = new Dictionary<string, object>();
            object physStats = Field(measured, "physBone");
            foreach (string key in PhysBones) phys[key] = Count(Field(physStats, key), "physBone." + key);
            stats["physBone"] = phys;
            if (!stats.Any(p => p.Key != "physBone" && p.Value != null) && !phys.Values.Any(v => v != null))
                throw new InvalidOperationException("The SDK supplied no recognized measurements.");
            return EyeJson.Map("schema", Schema, "avatar_id", avatarId.ToLowerInvariant(), "platform", platform,
                "sdk_version", sdkVersion, "sdk_base_version", baseVersion, "unity_version", unityVersion,
                "measurement_stage", "source", "measured_at", observed.ToUniversalTime().ToString("o"),
                "source", "VRC Eye SDK exporter 1; selected source avatar before build processing",
                "reported_rank", null, "stats", stats);
        }

        public static string ActivePlatform()
        {
            switch (EditorUserBuildSettings.activeBuildTarget)
            {
                case BuildTarget.StandaloneWindows: case BuildTarget.StandaloneWindows64: return "standalonewindows";
                case BuildTarget.Android: return "android";
                case BuildTarget.iOS: return "ios";
                default: throw new InvalidOperationException("Select a Windows, Android or iOS build target in Unity first.");
            }
        }

        public static string Capture(GameObject avatar)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating)
                throw new InvalidOperationException("Wait for the editor to finish compiling/importing, outside Play mode.");
            if (!avatar || EditorUtility.IsPersistent(avatar) || !avatar.scene.IsValid() || !EyeSdk.Descriptor(avatar))
                throw new InvalidOperationException("Select a scene avatar root with an Avatars SDK descriptor.");
            var pipelineType = EyeSdk.Type("VRC.Core.PipelineManager");
            var pipeline = pipelineType == null ? null : avatar.GetComponent(pipelineType);
            var idProperty = pipeline ? new SerializedObject(pipeline).FindProperty("blueprintId") : null;
            string avatarId = idProperty == null ? "" : idProperty.stringValue;
            if (!Id.IsMatch(avatarId)) throw new InvalidOperationException("The selected avatar needs an existing valid SDK blueprint ID; Eye never invents or assigns one.");
            string platform = ActivePlatform();
            var packages = PackageInfo.GetAllRegisteredPackages() ?? new PackageInfo[0];
            var avatars = packages.SingleOrDefault(p => p.name == "com.vrchat.avatars");
            var sdkBase = packages.SingleOrDefault(p => p.name == "com.vrchat.base");
            if (avatars == null || sdkBase == null) throw new InvalidOperationException("Install Avatars and Base SDK packages before capture.");
            var statsType = EyeSdk.Type("VRC.SDKBase.Validation.Performance.Stats.AvatarPerformanceStats");
            var calculatorType = EyeSdk.Type("VRC.SDKBase.Validation.Performance.AvatarPerformance");
            if (statsType == null || calculatorType == null) throw new InvalidOperationException("SDK performance analysis is unavailable.");
            var constructor = statsType.GetConstructor(new[] { typeof(bool) });
            var calculate = calculatorType.GetMethod("CalculatePerformanceStats", BindingFlags.Public | BindingFlags.Static,
                null, new[] { typeof(string), typeof(GameObject), statsType, typeof(bool) }, null);
            if (constructor == null || calculate == null || calculate.ReturnType != typeof(void))
                throw new InvalidOperationException("Installed SDK performance-analysis signature is unsupported. No report was created.");
            bool mobile = platform != "standalonewindows";
            object stats = constructor.Invoke(new object[] { mobile });
            try { calculate.Invoke(null, new object[] { "Selected source avatar", avatar, stats, mobile }); }
            catch (TargetInvocationException) { throw new InvalidOperationException("SDK analysis failed. Inspect the SDK Console; no partial report was exported."); }
            var report = Build(stats, avatarId, platform, avatars.version, sdkBase.version, Application.unityVersion, DateTimeOffset.UtcNow);
            string json = EyeJson.Write(report);
            if (Encoding.UTF8.GetByteCount(json) > 256 * 1024) throw new InvalidOperationException("Performance report exceeds 256 KiB.");
            return json;
        }
    }

    public sealed class EyePerformanceReportWindow : EditorWindow
    {
        GameObject selected;
        string report = "", status = "Select a scene avatar, then capture its SDK source measurements.";
        Vector2 scroll;
        [MenuItem("VRC Eye/Avatar Performance Report")]
        public static void OpenWindow() { GetWindow<EyePerformanceReportWindow>("Eye Performance Report"); }
        void OnEnable() { selected = Selection.activeGameObject; }
        void OnGUI()
        {
            EditorGUILayout.HelpBox("Source-project snapshot before build processing. Uses the active Unity target and installed SDK. Build sizes and final performance rank remain unknown. No avatar modules need to be installed.", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            selected = (GameObject)EditorGUILayout.ObjectField("Avatar root", selected, typeof(GameObject), true);
            if (EditorGUI.EndChangeCheck()) { report = ""; status = "Selection changed. Capture a new report."; }
            EditorGUILayout.LabelField("Active target", EditorUserBuildSettings.activeBuildTarget.ToString());
            if (GUILayout.Button("Capture SDK source measurements"))
            {
                report = "";
                try { report = EyePerformanceReport.Capture(selected); status = "Captured snapshot. Recapture after editing the avatar, packages or build target."; }
                catch (Exception error) { status = "Capture stopped: " + error.Message; }
            }
            EditorGUILayout.HelpBox(status, MessageType.Info);
            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.TextArea(report, GUILayout.ExpandHeight(true));
            EditorGUILayout.EndScrollView();
            using (new EditorGUI.DisabledScope(String.IsNullOrEmpty(report)))
            if (GUILayout.Button("Review and export captured report…"))
            {
                if (!EditorUtility.DisplayDialog("Export captured avatar measurements?", "Includes the avatar ID, SDK/Unity versions, platform, capture time and measured counters. It is the displayed snapshot, not a fresh build. Import it through Eye's Avatar Library → Performance reports.", "Choose new file", "Cancel")) return;
                string path = EditorUtility.SaveFilePanel("New avatar performance report", "", "VRC-Eye-Avatar-Performance.json", "json");
                if (String.IsNullOrEmpty(path)) return;
                try
                {
                    using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(report);
                    status = "Captured report saved. Import it in VRC Eye to inspect or compare.";
                }
                catch (IOException) { status = "Choose a new writable filename. Existing files are not overwritten."; }
                catch (UnauthorizedAccessException) { status = "The selected destination is not writable."; }
            }
        }
    }
}
