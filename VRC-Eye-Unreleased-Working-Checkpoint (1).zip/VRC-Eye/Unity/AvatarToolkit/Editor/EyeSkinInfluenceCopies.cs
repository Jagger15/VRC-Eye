// ARC-12: narrow, copy-only reduction. Unity 2022.3 execution is unqualified here.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeSkinError
    {
        public readonly string pose;public readonly float seconds;public readonly int vertices,worstVertex;
        public readonly double maximum,rms;
        internal EyeSkinError(string pose,float seconds,int vertices,int worst,double maximum,double rms)
        {this.pose=pose;this.seconds=seconds;this.vertices=vertices;worstVertex=worst;this.maximum=maximum;this.rms=rms;}
    }
    public sealed class EyeSkinPlan
    {
        internal readonly GameObject root;internal readonly SkinnedMeshRenderer renderer;internal readonly EyeBoundsRange[] ranges;
        internal readonly string fingerprint,expectedMesh;internal readonly double expires;internal bool consumed;
        public readonly int limit,influencesBefore,influencesAfter,changedVertices;
        public readonly double maximum,rms;public readonly float tolerance;public readonly string summary;
        readonly EyeSkinError[] samples;
        public EyeSkinError[] Samples{get{return (EyeSkinError[])samples.Clone();}}
        internal EyeSkinPlan(GameObject root,SkinnedMeshRenderer renderer,EyeBoundsRange[] ranges,string fingerprint,string expectedMesh,int limit,float tolerance,int before,int after,int changed,EyeSkinError[] samples,string summary)
        {this.root=root;this.renderer=renderer;this.ranges=ranges;this.fingerprint=fingerprint;this.expectedMesh=expectedMesh;this.limit=limit;this.tolerance=tolerance;influencesBefore=before;influencesAfter=after;changedVertices=changed;this.samples=samples;maximum=samples.Max(s=>s.maximum);rms=Math.Sqrt(samples.Sum(s=>s.rms*s.rms*s.vertices)/samples.Sum(s=>(double)s.vertices));this.summary=summary;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeSkinInfluenceCopies
    {
        public const string Limits="Finite poses cannot certify between-sample motion, unselected clips, shader deformation, normals/tangents, controllers or target runtime behavior. No bone removal, renderer merging, bounds change or assignment is performed. No speed or memory improvement is established without target profiling. Bone slots with no weights are not proven unused.";
        internal static Dictionary<string,Object> Source(GameObject root,SkinnedMeshRenderer renderer)
        {
            var objects=EyeBoundsDiagnostics.Source(root,renderer);
            foreach(var c in objects.Values.OfType<Component>()) {
                var type=c.GetType();
                if(type!=typeof(Transform)&&type!=typeof(SkinnedMeshRenderer)&&type!=typeof(MeshRenderer)&&type!=typeof(MeshFilter))
                    throw new InvalidOperationException("Unknown/dynamic dependency blocks influence editing: "+type.FullName+". This subset requires a separate data-only prefab; it never removes components for you.");
            }
            if(renderer.sharedMesh.bindposes.Length!=renderer.bones.Length||renderer.bones.Length==0)throw new InvalidOperationException("Every bind pose needs its corresponding renderer bone slot.");
            foreach(var matrix in renderer.sharedMesh.bindposes)EyeBoundsMath.Matrix(matrix);
            if(renderer.sharedMaterials.Length!=renderer.sharedMesh.subMeshCount)throw new InvalidOperationException("Material slots must match submeshes; no material correspondence is guessed.");
            return objects;
        }
        static BoneWeight[] Reduce(Mesh mesh,int boneCount,int limit,out int before,out int after,out int changed,out int unused)
        {
            if(limit<1||limit>4)throw new InvalidOperationException("Choose 1–4 influences per vertex.");
            var counts=mesh.GetBonesPerVertex();var weights=mesh.GetAllBoneWeights();
            if(counts.Length!=mesh.vertexCount||counts.Length<1||counts.Length>200000||weights.Length>800000)throw new InvalidOperationException("A complete skin of up to 200,000 vertices and four stored influences per vertex is required.");
            var output=new BoneWeight[counts.Length];int offset=0;before=after=changed=0;var used=new HashSet<int>();
            for(int v=0;v<counts.Length;v++) {
                int count=counts[v];if(count<1||count>4||offset+count>weights.Length)throw new InvalidOperationException("This initial sampler requires 1–4 stored influences at every vertex; higher-count skins remain unavailable.");
                var row=new List<BoneWeight1>();var seen=new HashSet<int>();double sum=0;
                for(int i=0;i<count;i++) {
                    var w=weights[offset++];EyeBoundsMath.Finite(w.weight);
                    if(w.weight<=0||w.weight>1||w.boneIndex<0||w.boneIndex>=boneCount||!seen.Add(w.boneIndex))throw new InvalidOperationException("Skin weights need unique valid bone indices and positive normalized values.");
                    sum+=w.weight;row.Add(w);used.Add(w.boneIndex);
                }
                if(Math.Abs(sum-1)>0.001)throw new InvalidOperationException("Stored skin weights must sum to one within 0.001.");
                var kept=row.OrderByDescending(w=>w.weight).ThenBy(w=>w.boneIndex).Take(limit).ToArray();double total=kept.Sum(w=>(double)w.weight);
                var b=new BoneWeight();
                for(int i=0;i<kept.Length;i++) {
                    int joint=kept[i].boneIndex;float value=(float)(kept[i].weight/total);
                    switch(i){case 0:b.boneIndex0=joint;b.weight0=value;break;case 1:b.boneIndex1=joint;b.weight1=value;break;case 2:b.boneIndex2=joint;b.weight2=value;break;case 3:b.boneIndex3=joint;b.weight3=value;break;}
                }
                output[v]=b;before+=count;after+=kept.Length;if(count>limit)changed++;
            }
            if(offset!=weights.Length)throw new InvalidOperationException("Skin weight stream has trailing entries.");
            unused=boneCount-used.Count;return output;
        }
        static Mesh Candidate(SkinnedMeshRenderer renderer,int limit,out int before,out int after,out int changed,out int unused)
        {
            var source=renderer.sharedMesh;var weights=Reduce(source,renderer.bones.Length,limit,out before,out after,out changed,out unused);
            if(changed==0)throw new InvalidOperationException("The selected cap removes no influences; no optimization copy is needed.");
            var copy=Object.Instantiate(source);copy.hideFlags=HideFlags.HideAndDontSave;
            try {
                copy.boneWeights=weights;
                if(EyeAvatarRepair.MeshEvidence(source,false)!=EyeAvatarRepair.MeshEvidence(copy,false))throw new InvalidOperationException("Reduction changed geometry, bind poses, non-skin streams, material submeshes or blendshape frames. This layout is unsupported.");
                // Re-read the actual stored representation, including any Unity quantization.
                int actualBefore,actualAfter,actualChanged,actualUnused;Reduce(copy,renderer.bones.Length,limit,out actualBefore,out actualAfter,out actualChanged,out actualUnused);
                if(actualChanged!=0||actualBefore!=after)throw new InvalidOperationException("Unity did not retain the proposed influence cap.");
                return copy;
            } catch {Object.DestroyImmediate(copy);throw;}
        }
        static EyeSkinError Measure(EyeBoundsDiagnostics.Pose pose,Mesh original,Mesh candidate,string label,float at)
        {
            var morph=Enumerable.Range(0,original.blendShapeCount).Select(pose.skin.GetBlendShapeWeight).ToArray();
            Action<Mesh> assign=mesh=>{pose.skin.sharedMesh=mesh;for(int i=0;i<morph.Length;i++)pose.skin.SetBlendShapeWeight(i,morph[i]);};
            assign(original);var a=pose.Vertices(false);assign(candidate);var b=pose.Vertices(false);assign(original);
            if(a.Length!=b.Length||a.Length==0)throw new InvalidOperationException("Sample vertex correspondence was lost.");
            double sum=0,maximum=-1;int worst=0;
            for(int i=0;i<a.Length;i++){double x=(double)a[i].x-b[i].x,y=(double)a[i].y-b[i].y,z=(double)a[i].z-b[i].z,error=x*x+y*y+z*z;sum+=error;if(error>maximum){maximum=error;worst=i;}}
            return new EyeSkinError(label,at,a.Length,worst,Math.Sqrt(maximum),Math.Sqrt(sum/a.Length));
        }
        public static EyeSkinPlan Prepare(GameObject root,SkinnedMeshRenderer renderer,int limit,float tolerance,IEnumerable<EyeBoundsRange> selected,bool progress=false)
        {
            EyeBoundsMath.Finite(tolerance);if(tolerance<0||tolerance>1000)throw new InvalidOperationException("Choose a maximum sampled error of 0–1,000 source world units.");
            var ranges=(selected??Array.Empty<EyeBoundsRange>()).Take(9).ToArray();if(ranges.Length>8||ranges.Any(r=>r==null))throw new InvalidOperationException("Choose up to eight explicit clip ranges.");
            var objects=Source(root,renderer);var points=ranges.Select(r=>r.Times()).ToArray();int count=1+points.Sum(t=>t.Length);
            if(count>257||(long)count*renderer.sharedMesh.vertexCount*2>8000000)throw new InvalidOperationException("Trial exceeds 257 poses or eight million baked vertex visits.");
            string fingerprint=EyeBoundsDiagnostics.Fingerprint(root,renderer,ranges);var curves=new List<EyeBoundsDiagnostics.Curve[]>();var coverage=new List<string>();
            foreach(var r in ranges){int ignored;curves.Add(EyeBoundsDiagnostics.Curves(root,renderer,r.clip,out ignored));coverage.Add(r.clip.name+": ignored "+AnimationUtility.GetAnimationEvents(r.clip).Length+" events, "+ignored+" unrelated blendshape bindings.");}
            int before,after,changed,unused;var mesh=Candidate(renderer,limit,out before,out after,out changed,out unused);var samples=new List<EyeSkinError>();double deadline=EditorApplication.timeSinceStartup+20;
            try {
                using(var pose=new EyeBoundsDiagnostics.Pose(root,renderer,objects)) {
                    // All four stored weights, independent of project quality. Original settings stay unchanged.
                    pose.skin.quality=SkinQuality.Bone4;samples.Add(Measure(pose,renderer.sharedMesh,mesh,"Imported pose",0));
                    for(int i=0;i<ranges.Length;i++)foreach(float at in points[i]) {
                        if(EditorApplication.timeSinceStartup>deadline)throw new InvalidOperationException("Skin trial exceeded 20 seconds; reduce sample scope.");
                        if(progress&&EditorUtility.DisplayCancelableProgressBar("VRC Eye skin influence trial",ranges[i].clip.name,(float)samples.Count/count))throw new OperationCanceledException("Trial canceled; no output asset created.");
                        pose.Apply(curves[i],at);samples.Add(Measure(pose,renderer.sharedMesh,mesh,ranges[i].clip.name,at));
                    }
                }
                if(EditorApplication.timeSinceStartup>deadline)throw new InvalidOperationException("Skin trial exceeded 20 seconds; reduce sample scope.");
                Source(root,renderer);if(fingerprint!=EyeBoundsDiagnostics.Fingerprint(root,renderer,ranges))throw new InvalidOperationException("Source or dependencies changed during measurement.");
                double maximum=samples.Max(s=>s.maximum),rms=Math.Sqrt(samples.Sum(s=>s.rms*s.rms*s.vertices)/samples.Sum(s=>(double)s.vertices));
                string expected=EyeAvatarRepair.MeshEvidence(mesh);
                string report="Skin influence reduction: "+root.name+" / "+renderer.name+"\nUnity "+Application.unityVersion+"; source fingerprint "+fingerprint+"\nLimit "+limit+"; stored influences "+before+" → "+after+"; reduced vertices "+changed+"; zero-weight bone slots "+unused+" (not deletion proof).\n"+
                    "Sampling: source world coordinates; temporary renderer uses Bone4 for all stored weights. Original renderer quality "+renderer.quality+" and project quality "+QualitySettings.skinWeights+" stay unchanged.\nMaximum error "+maximum.ToString("G17",CultureInfo.InvariantCulture)+"; RMS "+rms.ToString("G17",CultureInfo.InvariantCulture)+"; maximum tolerance "+tolerance.ToString("R",CultureInfo.InvariantCulture)+"; within tolerance "+(maximum<=tolerance)+".\n"+
                    string.Join("\n",samples.Select(s=>s.pose+" @ "+s.seconds.ToString("R",CultureInfo.InvariantCulture)+" s; max "+s.maximum.ToString("G17",CultureInfo.InvariantCulture)+"; RMS "+s.rms.ToString("G17",CultureInfo.InvariantCulture)+"; worst vertex "+s.worstVertex))+"\n"+string.Join("\n",coverage)+"\n"+Limits+
                    "\nCreates only a new mesh asset and this review text. Geometry, non-skin streams, bind poses, ordered submesh indices and every blendshape frame are checked. Stored weight quantization is included in the measured candidate. Manual assignment is separate; sources and their material/animation references remain untouched. Existing project import callbacks can run. Review expires after five minutes; exceeding the maximum tolerance blocks copying.";
                return new EyeSkinPlan(root,renderer,ranges,fingerprint,expected,limit,tolerance,before,after,changed,samples.ToArray(),report);
            } finally {Object.DestroyImmediate(mesh);if(progress)EditorUtility.ClearProgressBar();}
        }
        public static void Cancel(EyeSkinPlan plan){if(plan!=null)plan.consumed=true;}
        static void Fresh(EyeSkinPlan plan,Func<bool> current)
        {
            if(plan==null||plan.consumed||EditorApplication.timeSinceStartup>=plan.expires||current!=null&&!current())throw new InvalidOperationException("Review is canceled, expired, already used or no longer selected.");
            Source(plan.root,plan.renderer);
            if(plan.fingerprint!=EyeBoundsDiagnostics.Fingerprint(plan.root,plan.renderer,plan.ranges))throw new InvalidOperationException("Source, dependencies, clips or project context changed after review.");
        }
        public static string Execute(EyeSkinPlan plan,Func<bool> current=null)
        {
            Fresh(plan,current);
            if(plan.maximum>plan.tolerance)throw new InvalidOperationException("Sampled maximum error exceeds the reviewed tolerance. Change the cap or review a different explicit tolerance.");
            int before,after,changed,unused;var candidate=Candidate(plan.renderer,plan.limit,out before,out after,out changed,out unused);bool saved=false;
            try {
                if(EyeAvatarRepair.MeshEvidence(candidate)!=plan.expectedMesh)throw new InvalidOperationException("Rebuilt candidate differs from the measured mesh.");
                using(var history=EyeCopyHistory.Begin("Skin influence mesh copy",plan.fingerprint,plan.summary)) {
                    Fresh(plan,current);string folder=EyeAvatarRepair.NewFolder(),path=folder+"/skin-influence-copy.asset";
                    EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);candidate.hideFlags=HideFlags.None;
                    if(File.Exists(path))throw new IOException("Output already exists.");
                    AssetDatabase.CreateAsset(candidate,path);saved=AssetDatabase.Contains(candidate);AssetDatabase.SaveAssetIfDirty(candidate);EyeCopyHistory.After(path);Fresh(plan,current);
                    EyeCopyHistory.Before(path);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);EyeCopyHistory.After(path);Fresh(plan,current);
                    var loaded=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                    if(!loaded||EyeAvatarRepair.MeshEvidence(loaded)!=plan.expectedMesh)throw new InvalidOperationException("Saved mesh differs from the measured candidate. Partial output retained for review.");
                    string reportPath=folder+"/skin-influence-review.txt";EyeAvatarRepair.CheckProjectOutput(reportPath);EyeCopyHistory.Before(reportPath);
                    using(var stream=new FileStream(reportPath,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var writer=new StreamWriter(stream,new UTF8Encoding(false)))writer.Write(plan.summary);
                    AssetDatabase.ImportAsset(reportPath,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
                    if(File.ReadAllText(reportPath)!=plan.summary)throw new IOException("Review text changed during import.");EyeCopyHistory.After(reportPath);Fresh(plan,current);
                    if(EyeAvatarRepair.MeshEvidence(loaded)!=plan.expectedMesh)throw new InvalidOperationException("Mesh changed during report publication.");
                    history.Complete(path);return path;
                }
            } finally {plan.consumed=true;if(!saved&&candidate&&!AssetDatabase.Contains(candidate))Object.DestroyImmediate(candidate);}
        }
    }
}
