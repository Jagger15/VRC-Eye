// Explicit reference mappings into separate prefab copies. Unity 2022.3 gate.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeComponentReference
    {
        public readonly string property;public readonly Object source;
        internal EyeComponentReference(string property,Object source){this.property=property;this.source=source;}
    }
    public sealed class EyeComponentPlan
    {
        internal readonly GameObject sourceRoot,destinationRoot,target;
        internal readonly Component source;
        internal readonly Dictionary<string,string> mappings;
        internal readonly string fingerprint,targetKey;
        internal readonly double expires;
        internal bool used;
        public readonly string summary;
        internal EyeComponentPlan(GameObject sourceRoot,Component source,GameObject destinationRoot,GameObject target,Dictionary<string,string> mappings,string fingerprint,string targetKey,string summary)
        {this.sourceRoot=sourceRoot;this.source=source;this.destinationRoot=destinationRoot;this.target=target;this.mappings=mappings;this.fingerprint=fingerprint;this.targetKey=targetKey;this.summary=summary;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeComponentCopies
    {
        const int MaxObjects=10000,MaxProperties=100000;
        static readonly HashSet<Type> Allowed=new HashSet<Type>{typeof(MeshFilter),typeof(MeshRenderer),typeof(SkinnedMeshRenderer),typeof(BoxCollider),typeof(SphereCollider),typeof(CapsuleCollider),typeof(MeshCollider),typeof(Rigidbody),typeof(Light),typeof(Camera),typeof(AudioSource),typeof(Animator)};
        static readonly HashSet<string> Ownership=new HashSet<string>{"m_GameObject","m_CorrespondingSourceObject","m_PrefabInstance","m_PrefabAsset","m_ObjectHideFlags"};
        static bool OwnedField(string path){return Ownership.Contains(path.Split('.')[0]);}
        static void Idle()
        {if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Stop Play Mode and wait for compilation.");}
        static void SavedRoot(GameObject root)
        {
            Idle();if(!root)throw new InvalidOperationException("Select a saved prefab root.");
            string path=AssetDatabase.GetAssetPath(root);
            if(!EditorUtility.IsPersistent(root)||!path.EndsWith(".prefab",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadAssetAtPath<GameObject>(path)!=root)
                throw new InvalidOperationException("Select a saved .prefab asset root, not a scene instance or imported model.");
        }
        public static Dictionary<string,Object> Objects(GameObject root)
        {
            if(!root)throw new InvalidOperationException("Missing prefab root.");
            var result=new Dictionary<string,Object>();var pending=new Queue<KeyValuePair<string,Transform>>();pending.Enqueue(new KeyValuePair<string,Transform>("root",root.transform));int nodes=0;
            while(pending.Count>0) {
                var next=pending.Dequeue();if(++nodes>2000)throw new InvalidOperationException("Hierarchy exceeds 2,000 objects.");
                result.Add(next.Key,next.Value.gameObject);var components=next.Value.GetComponents<Component>();
                if(result.Count+components.Length>MaxObjects)throw new InvalidOperationException("Component graph exceeds 10,000 objects.");
                for(int i=0;i<components.Length;i++)if(components[i])result.Add(next.Key+"#"+i+":"+components[i].GetType().FullName,components[i]);
                if(nodes+pending.Count+next.Value.childCount>2000)throw new InvalidOperationException("Hierarchy exceeds 2,000 objects.");
                for(int i=0;i<next.Value.childCount;i++)pending.Enqueue(new KeyValuePair<string,Transform>(next.Key+"/"+i,next.Value.GetChild(i)));
            }
            return result;
        }
        static IEnumerable<SerializedProperty> Properties(Object source)
        {
            var serialized=new SerializedObject(source);var property=serialized.GetIterator();int count=0;
            while(property.Next(true)) {
                if(++count>MaxProperties)throw new InvalidOperationException("Serialized property budget exceeded.");
                if(!OwnedField(property.propertyPath))yield return property.Copy();
            }
        }
        public static EyeComponentReference[] RequiredMappings(Component source)
        {
            if(!source||!Allowed.Contains(source.GetType()))throw new InvalidOperationException("Only listed built-in component types can be copied. Transform, scripts, constraints and custom components are unsupported.");
            return Properties(source).Where(p=>p.propertyType==SerializedPropertyType.ObjectReference&&(p.objectReferenceValue is Component||p.objectReferenceValue is GameObject))
                .Select(p=>new EyeComponentReference(p.propertyPath,p.objectReferenceValue)).ToArray();
        }
        public static string Inspect(GameObject root)
        {
            SavedRoot(root);var objects=Objects(root);var keys=objects.ToDictionary(k=>k.Value,k=>k.Key);var lines=new List<string>();int properties=0,edges=0,missing=0;
            var adjacency=objects.Values.ToDictionary(v=>v,v=>new List<Object>());
            foreach(var entry in objects) {
                if(entry.Value is GameObject go)missing+=GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(go);
                lines.Add(entry.Key+" | "+entry.Value.name+" | "+entry.Value.GetType().Name+(entry.Value is Component&&!Allowed.Contains(entry.Value.GetType())?" | not copyable":""));
                if(entry.Value is Component component)foreach(RequireComponent required in component.GetType().GetCustomAttributes(typeof(RequireComponent),true))
                    foreach(var type in new[]{required.m_Type0,required.m_Type1,required.m_Type2}.Where(t=>t!=null))lines.Add("  Declared required component: "+type.FullName+" | "+(component.GetComponent(type)?"present":"missing"));
                foreach(var property in Properties(entry.Value)) {
                    if(++properties>MaxProperties)throw new InvalidOperationException("Whole graph exceeds 100,000 serialized properties.");
                    if(property.propertyType!=SerializedPropertyType.ObjectReference)continue;
                    Object target=property.objectReferenceValue;
                    if(!target) {if(property.objectReferenceInstanceIDValue!=0){missing++;lines.Add("  Missing reference: "+property.propertyPath);}continue;}
                    edges++;string key;
                    if(keys.TryGetValue(target,out key)){adjacency[entry.Value].Add(target);lines.Add("  "+property.propertyPath+" → "+key);}
                    else lines.Add("  "+property.propertyPath+" → asset "+AssetDatabase.GetAssetPath(target)+" / "+target.name);
                }
            }
            // Kahn's algorithm reports cycle participation without recursive
            // traversal. Cycles are shown, never silently flattened or copied.
            var degree=objects.Values.ToDictionary(v=>v,v=>0);foreach(var list in adjacency.Values)foreach(var value in list)degree[value]++;
            var pending=new Queue<Object>(degree.Where(v=>v.Value==0).Select(v=>v.Key));int removed=0;
            while(pending.Count>0){var value=pending.Dequeue();removed++;foreach(var target in adjacency[value])if(--degree[target]==0)pending.Enqueue(target);}
            return "Prefab component/reference graph\nObjects: "+objects.Count+"; reference edges: "+edges+"; missing scripts/references observed: "+missing+
                "; nodes in or downstream of reference cycles: "+(objects.Count-removed)+"\n"+
                "This inspects loaded Unity serialization. Unknown scripts are listed, never selected for copy. Absent references that Unity exposes as ordinary null cannot be inferred. Nested prefab links and external assets remain visible.\n\n"+string.Join("\n",lines);
        }
        static void DestinationNames(GameObject root)
        {
            var objects=Objects(root);var names=new HashSet<string>();
            foreach(var go in objects.Values.OfType<GameObject>()) {
                if(!names.Add(go.name))throw new InvalidOperationException("Destination prefab object names must be unique for Unity save/reload reference matching.");
                var components=go.GetComponents<Component>();
                if(components.Any(c=>!c))throw new InvalidOperationException("Resolve missing destination scripts with the separate missing-script copy workflow first.");
                if(components.GroupBy(c=>c.GetType()).Any(g=>g.Count()>1))throw new InvalidOperationException("Repeated component types make Unity prefab save matching ambiguous.");
            }
        }
        static string Fingerprint(GameObject source,GameObject destination)
        {
            var parts=new List<string>{Application.unityVersion};long length=0;
            foreach(var root in new[]{source,destination})foreach(var item in Objects(root)) {
                string evidence=item.Key+"|"+EyeMaterialMapping.ObjectEvidence(item.Value);length+=evidence.Length;
                if(length>32*1024*1024)throw new InvalidOperationException("Component review exceeds 32 MiB of evidence.");parts.Add(evidence);
            }
            return EyeMaterialMapping.Hash(string.Join("\n",parts));
        }
        public static EyeComponentPlan Prepare(GameObject sourceRoot,Component source,GameObject destinationRoot,GameObject target,IDictionary<string,Object> mappings)
        {
            SavedRoot(sourceRoot);SavedRoot(destinationRoot);DestinationNames(destinationRoot);
            var sources=Objects(sourceRoot);var destinations=Objects(destinationRoot);
            if(!source||!sources.Values.Contains(source)||!target||!destinations.Values.Contains(target))throw new InvalidOperationException("Choose a source component and destination object inside the reviewed prefabs.");
            if(target.GetComponent(source.GetType()))throw new InvalidOperationException("The destination already contains this component type; existing components are not replaced.");
            if(source is MeshRenderer&&!target.GetComponent<MeshFilter>())throw new InvalidOperationException("Copy a MeshFilter into the target first, then review the resulting prefab for a MeshRenderer copy.");
            var required=RequiredMappings(source);var keys=destinations.ToDictionary(k=>k.Value,k=>k.Key);var selected=new Dictionary<string,string>();
            if(mappings==null||mappings.Count!=required.Length)throw new InvalidOperationException("Map every hierarchy reference explicitly and remove unused mappings.");
            foreach(var reference in required) {
                Object value;
                if(!mappings.TryGetValue(reference.property,out value)||!value||!keys.ContainsKey(value)||!reference.source.GetType().IsAssignableFrom(value.GetType()))throw new InvalidOperationException("Select a compatible destination hierarchy object for "+reference.property);
                selected.Add(reference.property,keys[value]);
            }
            foreach(var p in Properties(source))if(p.propertyType==SerializedPropertyType.ObjectReference&&!p.objectReferenceValue&&p.objectReferenceInstanceIDValue!=0)throw new InvalidOperationException("Resolve missing source reference: "+p.propertyPath);
            string summary="Create an independent, unpacked copy of "+destinationRoot.name+" and add "+source.GetType().Name+" on "+target.name+".\n"+
                "Original prefabs, scenes and assignments remain unchanged. Every hierarchy reference is explicitly mapped; external mesh/material/controller/audio assets remain shared. No custom scripts, Transform, constraint or SDK component copying. Existing project import/editor callbacks can run when loading/saving the new copy. Partial outputs remain on failure.\n\n"+
                string.Join("\n",selected.Select(k=>k.Key+" → "+k.Value+" / "+destinations[k.Value].name))+"\n\nSerialized values and references are checked again after saving and reloading. Review expires in five minutes.";
            return new EyeComponentPlan(sourceRoot,source,destinationRoot,target,selected,Fingerprint(sourceRoot,destinationRoot),keys[target],summary);
        }
        static void Fresh(EyeComponentPlan plan)
        {
            SavedRoot(plan.sourceRoot);SavedRoot(plan.destinationRoot);
            if(Fingerprint(plan.sourceRoot,plan.destinationRoot)!=plan.fingerprint)throw new InvalidOperationException("Source or destination prefab changed after review.");
        }
        static void Verify(EyeComponentPlan plan,Component copy,Dictionary<string,Object> destinations)
        {
            var serialized=new SerializedObject(copy);
            foreach(var original in Properties(plan.source)) {
                var current=serialized.FindProperty(original.propertyPath);
                if(current==null||current.propertyType!=original.propertyType)throw new InvalidOperationException("Copied component schema changed: "+original.propertyPath);
                if(original.propertyType==SerializedPropertyType.ObjectReference) {
                    string key;Object expected=plan.mappings.TryGetValue(original.propertyPath,out key)?destinations[key]:original.objectReferenceValue;
                    if(current.objectReferenceValue!=expected)throw new InvalidOperationException("Copied reference did not survive save/reload: "+original.propertyPath);
                } else if(original.propertyType!=SerializedPropertyType.Generic&&!SerializedProperty.DataEquals(original,current))throw new InvalidOperationException("Copied value did not survive save/reload: "+original.propertyPath);
            }
        }
        public static string Execute(EyeComponentPlan plan)
        {
            if(plan==null)throw new InvalidOperationException("Prepare a component copy first.");
            using(var history=EyeCopyHistory.Begin("Component copy",plan.fingerprint,plan.summary)) {
                string result=ExecuteCore(plan);history.Complete(result);return result;
            }
        }
        static string ExecuteCore(EyeComponentPlan plan)
        {
            if(plan==null||plan.used||EditorApplication.timeSinceStartup>=plan.expires)throw new InvalidOperationException("Component review expired or was used.");
            Fresh(plan);plan.used=true;string path=EyeAvatarRepair.NewFolder()+"/component-copy.prefab";GameObject contents=null;
            try {
                Fresh(plan);EyeAvatarRepair.CheckProjectOutput(path);
                EyeCopyHistory.Before(path);
                if(File.Exists(path)||!AssetDatabase.CopyAsset(AssetDatabase.GetAssetPath(plan.destinationRoot),path))throw new IOException("Could not create a separate destination prefab.");
                EyeCopyHistory.After(path);
                Fresh(plan);contents=PrefabUtility.LoadPrefabContents(path);
                foreach(var go in Objects(contents).Values.OfType<GameObject>())if(PrefabUtility.IsOutermostPrefabInstanceRoot(go))PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
                var destinations=Objects(contents);var target=(GameObject)destinations[plan.targetKey];var before=target.GetComponents<Component>();
                Fresh(plan);var copy=target.AddComponent(plan.source.GetType());
                if(!copy||target.GetComponents<Component>().Length!=before.Length+1)throw new InvalidOperationException("Unity added an unreviewed required component; inspect the retained output.");
                var from=new SerializedObject(plan.source);var to=new SerializedObject(copy);var property=from.GetIterator();bool enter=true;int count=0;
                while(property.Next(enter)) {
                    enter=false;if(++count>MaxProperties)throw new InvalidOperationException("Component property budget exceeded.");
                    if(!OwnedField(property.propertyPath))to.CopyFromSerializedProperty(property);
                }
                foreach(var map in plan.mappings)to.FindProperty(map.Key).objectReferenceValue=destinations[map.Value];
                to.ApplyModifiedPropertiesWithoutUndo();
                if(copy.gameObject!=target)throw new InvalidOperationException("Component owner changed unexpectedly.");
                Verify(plan,copy,destinations);Fresh(plan);EyeAvatarRepair.CheckProjectOutput(path);
                EyeCopyHistory.Before(path);bool success;PrefabUtility.SaveAsPrefabAsset(contents,path,out success);if(!success)throw new IOException("Unity could not save the copied component.");EyeCopyHistory.After(path);
                PrefabUtility.UnloadPrefabContents(contents);contents=null;Fresh(plan);
                contents=PrefabUtility.LoadPrefabContents(path);destinations=Objects(contents);target=(GameObject)destinations[plan.targetKey];copy=target.GetComponent(plan.source.GetType());
                if(!copy)throw new InvalidOperationException("Copied component was absent after reload.");Verify(plan,copy,destinations);Fresh(plan);return path;
            } finally {if(contents)PrefabUtility.UnloadPrefabContents(contents);}
        }
    }
    public sealed class EyeComponentCopiesWindow:EditorWindow
    {
        GameObject sourceRoot,destinationRoot,target;Component source;bool authorized;
        Dictionary<string,Object> mappings=new Dictionary<string,Object>();EyeComponentReference[] references=Array.Empty<EyeComponentReference>();
        EyeComponentPlan plan;Vector2 scroll;string report="Select saved source and destination prefabs. Graph inspection is read-only.";
        [MenuItem("VRC Eye/Component Graph and Copies")]
        public static void Open(){GetWindow<EyeComponentCopiesWindow>("Component Copies");}
        void Run(Action action){try{action();}catch(Exception error){plan=null;report="Stopped: "+error.Message;}}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);EditorGUI.BeginChangeCheck();
            sourceRoot=(GameObject)EditorGUILayout.ObjectField("Source prefab root",sourceRoot,typeof(GameObject),false);
            source=(Component)EditorGUILayout.ObjectField("Source component",source,typeof(Component),false);
            destinationRoot=(GameObject)EditorGUILayout.ObjectField("Destination prefab root",destinationRoot,typeof(GameObject),false);
            target=(GameObject)EditorGUILayout.ObjectField("Target inside destination",target,typeof(GameObject),false);
            if(EditorGUI.EndChangeCheck()){plan=null;references=Array.Empty<EyeComponentReference>();mappings.Clear();authorized=false;}
            authorized=EditorGUILayout.ToggleLeft("I have permission to inspect and copy these source assets",authorized);
            using(new EditorGUI.DisabledScope(!sourceRoot))if(GUILayout.Button("Inspect source component graph"))Run(()=>report=EyeComponentCopies.Inspect(sourceRoot));
            using(new EditorGUI.DisabledScope(!source||!authorized))if(GUILayout.Button("List references requiring explicit mapping"))Run(()=>{references=EyeComponentCopies.RequiredMappings(source);mappings=references.ToDictionary(r=>r.property,r=>(Object)null);plan=null;});
            EditorGUI.BeginChangeCheck();
            foreach(var reference in references){EditorGUILayout.LabelField(reference.property+" ← "+reference.source.name);mappings[reference.property]=EditorGUILayout.ObjectField("Destination reference",mappings[reference.property],reference.source.GetType(),false);}
            if(EditorGUI.EndChangeCheck())plan=null;
            using(new EditorGUI.DisabledScope(!authorized||!source||!target))if(GUILayout.Button("Prepare component copy review"))Run(()=>{plan=EyeComponentCopies.Prepare(sourceRoot,source,destinationRoot,target,mappings);report=plan.summary;});
            using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Review and create separate prefab"))Run(()=>{
                var selected=plan;if(!EditorUtility.DisplayDialog("Create component copy?",selected.summary,"Create copy","Cancel"))return;
                if(plan!=selected||!authorized)throw new InvalidOperationException("Review changed.");plan=null;report="Created and reloaded: "+EyeComponentCopies.Execute(selected)+"\nInspect in Unity and the SDK before manual assignment.";
            });
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(220));EditorGUILayout.EndScrollView();
        }
    }
}
