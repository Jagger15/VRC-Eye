// ARC-11 source implementation. Native compile/EditMode qualification is pending.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeSettingPlan
    {
        internal readonly GameObject sourceRoot,destinationRoot;internal readonly Renderer sourceRenderer,destinationRenderer;
        internal readonly EyeSettingSpec[] specs;internal readonly string[] values;internal readonly Dictionary<string,Object> assets;
        internal readonly Dictionary<string,string> nodes;internal readonly string fingerprint,targetKey,modelBytes;
        internal readonly EyeSettingInventory before;internal readonly EyeSettingRow[] rows;internal readonly double expires;
        internal bool used,canceled;public readonly string summary;public readonly bool importer;
        internal EyeSettingPlan(GameObject sr,GameObject dr,Renderer s,Renderer d,EyeSettingSpec[] specs,string[] values,Dictionary<string,Object> assets,Dictionary<string,string> nodes,string fingerprint,string targetKey,string modelBytes,EyeSettingInventory before,EyeSettingRow[] rows,string summary,bool importer)
        {sourceRoot=sr;destinationRoot=dr;sourceRenderer=s;destinationRenderer=d;this.specs=specs;this.values=values;this.assets=assets;this.nodes=nodes;this.fingerprint=fingerprint;this.targetKey=targetKey;this.modelBytes=modelBytes;this.before=before;this.rows=rows;this.summary=summary;this.importer=importer;expires=EditorApplication.timeSinceStartup+300;}
        public void Cancel(){canceled=true;}
    }
    public static class EyeSettingTransfers
    {
        const string Notice="Creates a fresh destination copy only. Originals and existing assignments are never written by this operation. Existing project import/editor callbacks can run; changed source/output evidence interrupts the receipt and retains partial outputs. Review expires in five minutes. Reimport can change streams, submeshes, material/bone order and hierarchy. Inspect the output and ordered report before manual use. No FPS or deformation-equivalence claim.";
        static bool ReferenceKey(string key){return key=="probeAnchor"||key=="lightProbeProxyVolumeOverride"||key.StartsWith("material[",StringComparison.Ordinal);}
        internal static string Property(string key)
        {return key=="probeAnchor"?"m_ProbeAnchor":key=="lightProbeProxyVolumeOverride"?"m_LightProbeVolumeOverride":"m_Materials.Array.data["+Slot(key)+"]";}
        static int Slot(string key)
        {int n;if(!key.StartsWith("material[",StringComparison.Ordinal)||!key.EndsWith("]",StringComparison.Ordinal)||!int.TryParse(key.Substring(9,key.Length-10),out n)||n<0||n>=256||key!="material["+n+"]")throw new InvalidOperationException("Unsupported material slot.");return n;}
        internal static Object GetReference(Renderer renderer,string key)
        {return key=="probeAnchor"?renderer.probeAnchor:key=="lightProbeProxyVolumeOverride"?renderer.lightProbeProxyVolumeOverride:renderer.sharedMaterials[Slot(key)];}
        static string Fingerprint(EyeSettingPlan plan)
        {return EyeSettingEvidence.Fingerprint(new Object[]{plan.sourceRoot,plan.destinationRoot}.Concat(plan.assets.Values.Where(v=>v)).ToArray());}
        static void Fresh(EyeSettingPlan plan,Func<bool> current=null)
        {
            EyeSettingEvidence.Idle();if(plan==null||plan.canceled||EditorApplication.timeSinceStartup>=plan.expires||current!=null&&!current())throw new InvalidOperationException("Setting review was canceled, changed or expired. Prepare a new review.");
            if(plan.fingerprint!=Fingerprint(plan))throw new InvalidOperationException("Source, destination, mapped asset, importer or dependency changed after review.");
        }
        public static EyeSettingPlan PrepareRenderer(GameObject sourceRoot,Renderer source,GameObject destinationRoot,Renderer destination,IEnumerable<string> selected,IDictionary<string,Object> mappings)
        {
            var sourceObjects=EyeSettingEvidence.Prefab(sourceRoot);var destinations=EyeSettingEvidence.Prefab(destinationRoot);
            if(!source||!destination||source.GetType()!=destination.GetType()||!sourceObjects.Values.Contains(source)||!destinations.Values.Contains(destination))throw new InvalidOperationException("Choose existing renderers of exactly the same supported type inside the two saved prefabs.");
            var keys=(selected??Array.Empty<string>()).Take(257).ToArray();if(keys.Length<1||keys.Length>256||keys.Distinct().Count()!=keys.Length)throw new InvalidOperationException("Select 1–256 distinct settings individually.");
            var refs=keys.Where(ReferenceKey).ToArray();var specs=EyeSettingSpecs.Select(EyeSettingSpecs.Renderer(source),keys.Except(refs));
            mappings=mappings??new Dictionary<string,Object>();if(mappings.Count!=refs.Length||mappings.Keys.Any(k=>!refs.Contains(k)))throw new InvalidOperationException("Every selected reference requires an explicit mapping, including explicit null. Unselected mappings are refused.");
            var assets=new Dictionary<string,Object>();var nodes=new Dictionary<string,string>();var rows=new List<EyeSettingRow>();var risks=new List<string>();
            var values=specs.Select(s=>s.Read(source)).ToArray();
            foreach(var spec in specs)RequireProperty(source,destination,spec.serialized);
            foreach(var spec in specs){rows.Add(new EyeSettingRow{key=spec.key,kind=spec.kind,before=spec.Read(destination),after=spec.Read(source)});risks.Add(spec.key+": "+spec.risk);}
            foreach(string key in refs) {
                Object value=mappings[key];string mapped=null;
                if(key.StartsWith("material[",StringComparison.Ordinal)) {
                    int slot=Slot(key);if(source.sharedMaterials.Length!=destination.sharedMaterials.Length||slot>=source.sharedMaterials.Length)throw new InvalidOperationException("Material transfer requires matching slot counts and a valid explicitly selected slot.");
                    if(value&&(!(value is Material)||!AssetDatabase.GetAssetPath(value).StartsWith("Assets/",StringComparison.Ordinal)||EditorUtility.IsDirty(value)))throw new InvalidOperationException("Map each material slot to a saved Material under Assets, or explicitly clear it.");assets.Add(key,value);
                } else {
                    if(value&&(!(key=="probeAnchor"?value is Transform:value is GameObject)||!destinations.Values.Contains(value)))throw new InvalidOperationException("Map the anchor/proxy to a compatible object inside the destination prefab, or explicitly clear it.");
                    mapped=value?destinations.Single(p=>p.Value==value).Key:null;nodes.Add(key,mapped);
                }
                rows.Add(new EyeSettingRow{key=key,kind="reference",before=EyeSettingEvidence.Reference(GetReference(destination,key),destinations),after=mapped!=null?"node:"+mapped:EyeSettingEvidence.Reference(value)});
                risks.Add(key+": donor reference "+EyeSettingEvidence.Reference(GetReference(source,key),sourceObjects)+"; explicit chosen mapping "+rows.Last().after+". No reference is matched by name.");
            }
            string evidence=EyeSettingEvidence.Fingerprint(new Object[]{sourceRoot,destinationRoot}.Concat(assets.Values.Where(v=>v)).ToArray());
            string summary="Renderer settings only: "+source.name+" → new copy of "+destination.name+" ("+source.GetType().Name+").\n"+Notice+"\nMesh, bones, bounds and unselected renderer values remain the destination's. Nested/variant prefab links are unpacked in the copy.\n"+string.Join("\n",rows.Select(r=>r.key+" ["+r.kind+"]: "+r.before+" → "+r.after))+"\n\n"+string.Join("\n",risks)+"\nSource evidence: "+evidence;
            return new EyeSettingPlan(sourceRoot,destinationRoot,source,destination,specs,values,assets,nodes,evidence,destinations.Single(p=>p.Value==destination).Key,"",EyeSettingEvidence.Inventory(destinationRoot),rows.ToArray(),summary,false);
        }
        internal static ModelImporter Model(GameObject root)
        {
            EyeSettingEvidence.Idle();string path=root?AssetDatabase.GetAssetPath(root):"";var importer=AssetImporter.GetAtPath(path) as ModelImporter;
            if(!root||!importer||AssetDatabase.LoadAssetAtPath<GameObject>(path)!=root||!path.StartsWith("Assets/",StringComparison.Ordinal)||!path.EndsWith(".fbx",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Importer transfer currently requires saved FBX model roots under Assets. A mesh/prefab without ModelImporter is unsupported.");
            if(importer.materialImportMode!=ModelImporterMaterialImportMode.None&&importer.materialLocation!=ModelImporterMaterialLocation.InPrefab)throw new InvalidOperationException("Legacy external-material generation is outside this copy workflow. Use an authorized FBX with embedded material import or no material import.");
            if(EditorUtility.IsDirty(importer))throw new InvalidOperationException("Apply or revert pending importer edits first.");return importer;
        }
        public static EyeSettingPlan PrepareImporter(GameObject source,GameObject destination,IEnumerable<string> selected)
        {
            var from=Model(source);var to=Model(destination);var specs=EyeSettingSpecs.Select(EyeSettingSpecs.Importer(),selected);if(specs.Length==0)throw new InvalidOperationException("Select importer settings individually; none are selected by default.");
            foreach(var spec in specs)RequireProperty(from,to,spec.serialized);
            var values=specs.Select(s=>s.Read(from)).ToArray();var rows=specs.Select(s=>new EyeSettingRow{key=s.key,kind=s.kind,before=s.Read(to),after=s.Read(from)}).ToArray();
            string evidence=EyeSettingEvidence.Fingerprint(source,destination),bytes=EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(destination)).sha256;
            string summary="ModelImporter settings only: "+source.name+" → new FBX copy of "+destination.name+".\n"+Notice+"\nRenderer values, avatar/clip settings and material remap references are not transferred from the donor. Existing destination remaps remain exact; no material search by name is invoked. File contents stay identical; the new metadata is reimported.\n"+string.Join("\n",rows.Select(r=>r.key+" ["+r.kind+"]: "+r.before+" → "+r.after))+"\n\n"+string.Join("\n",specs.Select(s=>s.key+": "+s.risk))+"\nSource evidence: "+evidence;
            return new EyeSettingPlan(source,destination,null,null,specs,values,new Dictionary<string,Object>(),new Dictionary<string,string>(),evidence,"",bytes,EyeSettingEvidence.Inventory(destination),rows,summary,true);
        }
        static bool Owned(string path){return new[]{"m_ObjectHideFlags","m_GameObject","m_CorrespondingSourceObject","m_PrefabInstance","m_PrefabAsset"}.Contains(path.Split('.')[0]);}
        static void RequireProperty(Object source,Object destination,string path)
        {
            var a=new SerializedObject(source).FindProperty(path);var b=new SerializedObject(destination).FindProperty(path);
            if(a==null||b==null||a.propertyType!=b.propertyType)throw new InvalidOperationException("Unsupported Unity setting serialization: "+path);
        }
        static void CompareObjects(Object original,Object copy,Func<string,bool> skip,Func<Object,Object> map)
        {
            var from=new SerializedObject(original);var to=new SerializedObject(copy);var p=from.GetIterator();int count=0;
            while(p.Next(true)) {
                if(++count>100000)throw new InvalidOperationException("Setting verification exceeds 100,000 properties per object.");if(Owned(p.propertyPath)||skip(p.propertyPath))continue;
                var q=to.FindProperty(p.propertyPath);if(q==null||q.propertyType!=p.propertyType)throw new InvalidOperationException("Unreviewed serialized schema change: "+p.propertyPath);
                if(p.propertyType==SerializedPropertyType.ObjectReference) {
                    if(!p.objectReferenceValue&&p.objectReferenceInstanceIDValue!=0||q.objectReferenceValue!=map(p.objectReferenceValue))throw new InvalidOperationException("Unreviewed reference change: "+p.propertyPath);
                } else if(p.propertyType!=SerializedPropertyType.Generic&&!SerializedProperty.DataEquals(p,q))throw new InvalidOperationException("Unreviewed value change: "+p.propertyPath);
            }
        }
        static void VerifyRenderer(EyeSettingPlan plan,GameObject copy)
        {
            var original=EyeComponentCopies.Objects(plan.destinationRoot);var output=EyeComponentCopies.Objects(copy);if(!original.Keys.OrderBy(k=>k,StringComparer.Ordinal).SequenceEqual(output.Keys.OrderBy(k=>k,StringComparer.Ordinal)))throw new InvalidOperationException("Copied object/component correspondence changed.");
            var lookup=original.ToDictionary(p=>p.Value,p=>p.Key);var allowed=plan.specs.Select(s=>s.serialized).Concat(plan.assets.Keys.Concat(plan.nodes.Keys).Select(Property)).ToArray();
            foreach(var entry in original)CompareObjects(entry.Value,output[entry.Key],p=>entry.Key=="root"&&p=="m_Name"||entry.Key==plan.targetKey&&allowed.Any(a=>p==a||p.StartsWith(a+".",StringComparison.Ordinal)),v=>{string key;return v&&lookup.TryGetValue(v,out key)?output[key]:v;});
            var renderer=output[plan.targetKey] as Renderer;if(!renderer)throw new InvalidOperationException("Copied renderer lost.");
            for(int i=0;i<plan.specs.Length;i++)if(plan.specs[i].Read(renderer)!=plan.values[i])throw new InvalidOperationException("Selected setting did not survive reload: "+plan.specs[i].key);
            foreach(var pair in plan.assets)if(GetReference(renderer,pair.Key)!=pair.Value)throw new InvalidOperationException("Mapped material did not survive reload.");
            foreach(var pair in plan.nodes)if(GetReference(renderer,pair.Key)!=(pair.Value==null?null:output[pair.Value]))throw new InvalidOperationException("Mapped destination reference did not survive reload.");
        }
        static void ApplyRenderer(EyeSettingPlan plan,GameObject contents)
        {
            foreach(var go in EyeComponentCopies.Objects(contents).Values.OfType<GameObject>())if(PrefabUtility.IsOutermostPrefabInstanceRoot(go))PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
            var nodes=EyeComponentCopies.Objects(contents);var target=(Renderer)nodes[plan.targetKey];for(int i=0;i<plan.specs.Length;i++)plan.specs[i].write(target,plan.values[i]);
            var serialized=new SerializedObject(target);foreach(var key in plan.assets.Keys.Concat(plan.nodes.Keys)) {
                var property=serialized.FindProperty(Property(key));if(property==null||property.propertyType!=SerializedPropertyType.ObjectReference)throw new InvalidOperationException("Unsupported reference serialization.");
                string node;property.objectReferenceValue=plan.nodes.TryGetValue(key,out node)?(node==null?null:nodes[node]):plan.assets[key];
            }
            serialized.ApplyModifiedPropertiesWithoutUndo();VerifyRenderer(plan,contents);
        }
        static void VerifyImporterBaseline(ModelImporter original,ModelImporter copy)
        {
            CompareObjects(original,copy,p=>p=="m_Name",v=>v);
        }
        static void VerifyImporterDraft(EyeSettingPlan plan,ModelImporter copy)
        {
            var original=Model(plan.destinationRoot);var allowed=plan.specs.Select(s=>s.serialized).ToArray();
            CompareObjects(original,copy,p=>p=="m_Name"||allowed.Contains(p),v=>v);
            foreach(var spec in EyeSettingSpecs.Importer()) {
                int index=Array.FindIndex(plan.specs,s=>s.key==spec.key);string expected=index<0?spec.Read(original):plan.values[index];
                if(spec.Read(copy)!=expected)throw new InvalidOperationException("An importer policy changed outside its individual review: "+spec.key);
            }
        }
        public static string Execute(EyeSettingPlan plan,Func<bool> current=null)
        {
            if(plan==null||plan.used)throw new InvalidOperationException("Prepare an unused setting-transfer plan.");Fresh(plan,current);plan.used=true;
            Action fresh=()=>Fresh(plan,current);
            using(var history=EyeCopyHistory.Begin(plan.importer?"Model importer setting transfer":"Renderer setting transfer",plan.fingerprint,plan.summary)) {
                string folder=EyeAvatarRepair.NewFolder(),path=folder+"/"+Path.GetFileName(AssetDatabase.GetAssetPath(plan.destinationRoot));GameObject contents=null;
                try {
                    fresh();EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);
                    if(!AssetDatabase.CopyAsset(AssetDatabase.GetAssetPath(plan.destinationRoot),path))throw new IOException("Could not create a fresh destination copy.");EyeCopyHistory.After(path);fresh();
                    EyeSettingInventory after;
                    if(plan.importer) {
                        var importer=AssetImporter.GetAtPath(path) as ModelImporter;if(!importer)throw new InvalidOperationException("Copied ModelImporter is unavailable.");VerifyImporterBaseline(Model(plan.destinationRoot),importer);
                        for(int i=0;i<plan.specs.Length;i++)plan.specs[i].write(importer,plan.values[i]);
                        VerifyImporterDraft(plan,importer);
                        string expected=EditorJsonUtility.ToJson(importer);fresh();EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);EditorUtility.SetDirty(importer);importer.SaveAndReimport();EyeCopyHistory.After(path);fresh();
                        importer=AssetImporter.GetAtPath(path) as ModelImporter;
                        if(!importer||EditorJsonUtility.ToJson(importer)!=expected)throw new InvalidOperationException("Importer settings changed beyond the exact reviewed draft during reimport. Inspect the retained output; no assignment was made.");
                        VerifyImporterDraft(plan,importer);
                        for(int i=0;i<plan.specs.Length;i++)if(plan.specs[i].Read(importer)!=plan.values[i])throw new InvalidOperationException("Selected importer value changed during reimport.");
                        if(EyeShaderFileEvidence.Read(path).sha256!=plan.modelBytes)throw new IOException("Copied FBX bytes changed during import.");
                        after=EyeSettingEvidence.Inventory(AssetDatabase.LoadAssetAtPath<GameObject>(path));
                        EyeSettingEvidence.Report(folder,new EyeSettingReport{receiptId=history.Id,kind="ModelImporter",sourceEvidence=plan.fingerprint,source=AssetDatabase.GetAssetPath(plan.sourceRoot),destination=AssetDatabase.GetAssetPath(plan.destinationRoot),output=path,rows=plan.rows,before=plan.before,after=after},fresh);
                        if(EditorJsonUtility.ToJson(AssetImporter.GetAtPath(path))!=expected||EyeShaderFileEvidence.Read(path).sha256!=plan.modelBytes)throw new IOException("Copied importer or FBX changed while publishing its report.");
                    } else {
                        contents=PrefabUtility.LoadPrefabContents(path);fresh();ApplyRenderer(plan,contents);fresh();EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);
                        bool success;PrefabUtility.SaveAsPrefabAsset(contents,path,out success);if(!success)throw new IOException("Could not save renderer-setting copy.");EyeCopyHistory.After(path);
                        PrefabUtility.UnloadPrefabContents(contents);contents=null;fresh();contents=PrefabUtility.LoadPrefabContents(path);VerifyRenderer(plan,contents);fresh();after=EyeSettingEvidence.Inventory(contents);
                        EyeSettingEvidence.Report(folder,new EyeSettingReport{receiptId=history.Id,kind=plan.sourceRenderer.GetType().Name,sourceEvidence=plan.fingerprint,source=AssetDatabase.GetAssetPath(plan.sourceRoot),destination=AssetDatabase.GetAssetPath(plan.destinationRoot),output=path,rows=plan.rows,before=plan.before,after=after},fresh);VerifyRenderer(plan,contents);
                    }
                    fresh();history.Complete(path);return path;
                } finally {if(contents)PrefabUtility.UnloadPrefabContents(contents);}
            }
        }
    }
}
