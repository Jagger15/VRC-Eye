// ARC-11: typed settings only. Geometry, bones and controller swaps are excluded.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeSettingSpec
    {
        public readonly string key,kind,risk,serialized;
        internal readonly Func<Object,string> read;internal readonly Action<Object,string> write;
        internal EyeSettingSpec(string key,string kind,string risk,string serialized,Func<Object,string> read,Action<Object,string> write)
        {this.key=key;this.kind=kind;this.risk=risk;this.serialized=serialized;this.read=read;this.write=write;}
        public string Read(Object value){return read(value);}
    }
    public static class EyeSettingSpecs
    {
        static string Angle(ModelImporter source){float value=source.normalSmoothingAngle;if(float.IsNaN(value)||float.IsInfinity(value)||value<0||value>180)throw new InvalidOperationException("Unsupported smoothing angle.");return value.ToString("R",CultureInfo.InvariantCulture);}
        static EyeSettingSpec B<T>(string key,string path,string risk,Func<T,bool> get,Action<T,bool> set) where T:Object
        {return new EyeSettingSpec(key,"bool",risk,path,o=>get((T)o)?"true":"false",(o,v)=>{if(v!="true"&&v!="false")throw new InvalidOperationException("Invalid boolean.");set((T)o,v=="true");});}
        static EyeSettingSpec E<T,V>(string key,string path,string risk,Func<T,V> get,Action<T,V> set) where T:Object where V:struct
        {return new EyeSettingSpec(key,"enum",risk,path,o=>{var v=get((T)o);if(!Enum.IsDefined(typeof(V),v))throw new InvalidOperationException("Unsupported "+key+" enum.");return v.ToString();},(o,v)=>{V n;if(!Enum.TryParse(v,out n)||!Enum.IsDefined(typeof(V),n))throw new InvalidOperationException("Unsupported enum.");set((T)o,n);});}
        public static EyeSettingSpec[] Renderer(Renderer source)
        {
            if(!source||(source.GetType()!=typeof(MeshRenderer)&&source.GetType()!=typeof(SkinnedMeshRenderer)))throw new InvalidOperationException("Select a MeshRenderer or SkinnedMeshRenderer.");
            var rows=new List<EyeSettingSpec>{
                B<Renderer>("enabled","m_Enabled","Changes whether this renderer draws.",x=>x.enabled,(x,v)=>x.enabled=v),
                E<Renderer,ShadowCastingMode>("shadowCastingMode","m_CastShadows","Changes shadows.",x=>x.shadowCastingMode,(x,v)=>x.shadowCastingMode=v),
                B<Renderer>("receiveShadows","m_ReceiveShadows","Changes shadow reception.",x=>x.receiveShadows,(x,v)=>x.receiveShadows=v),
                E<Renderer,LightProbeUsage>("lightProbeUsage","m_LightProbeUsage","Changes probe lighting; required anchors are not inferred.",x=>x.lightProbeUsage,(x,v)=>x.lightProbeUsage=v),
                E<Renderer,ReflectionProbeUsage>("reflectionProbeUsage","m_ReflectionProbeUsage","Changes reflection lighting.",x=>x.reflectionProbeUsage,(x,v)=>x.reflectionProbeUsage=v),
                B<Renderer>("allowOcclusionWhenDynamic","m_AllowOcclusionWhenDynamic","Changes occlusion behavior.",x=>x.allowOcclusionWhenDynamic,(x,v)=>x.allowOcclusionWhenDynamic=v),
                E<Renderer,MotionVectorGenerationMode>("motionVectorGenerationMode","m_MotionVectors","Changes motion-vector rendering.",x=>x.motionVectorGenerationMode,(x,v)=>x.motionVectorGenerationMode=v)};
            if(source is SkinnedMeshRenderer)rows.AddRange(new[]{
                E<SkinnedMeshRenderer,SkinQuality>("quality","m_Quality","Changes runtime skin influences; deformation needs separate validation.",x=>x.quality,(x,v)=>x.quality=v),
                B<SkinnedMeshRenderer>("updateWhenOffscreen","m_UpdateWhenOffscreen","Changes offscreen skin updates and bounds behavior.",x=>x.updateWhenOffscreen,(x,v)=>x.updateWhenOffscreen=v),
                B<SkinnedMeshRenderer>("skinnedMotionVectors","m_SkinnedMotionVectors","Changes skin motion-vector buffering.",x=>x.skinnedMotionVectors,(x,v)=>x.skinnedMotionVectors=v)});
            return rows.ToArray();
        }
        public static EyeSettingSpec[] Importer()
        {
            return new[]{
                B<ModelImporter>("isReadable","m_IsReadable","INDIVIDUAL REVIEW: changes CPU mesh accessibility and memory retention.",x=>x.isReadable,(x,v)=>x.isReadable=v),
                E<ModelImporter,ModelImporterMeshCompression>("meshCompression","m_MeshCompression","INDIVIDUAL REVIEW: lossy compression can change vertex streams and deformation.",x=>x.meshCompression,(x,v)=>x.meshCompression=v),
                B<ModelImporter>("optimizeMeshPolygons","meshOptimizationFlags","INDIVIDUAL REVIEW: changes polygon/index order.",x=>x.optimizeMeshPolygons,(x,v)=>x.optimizeMeshPolygons=v),
                B<ModelImporter>("optimizeMeshVertices","meshOptimizationFlags","INDIVIDUAL REVIEW: changes vertex/stream order.",x=>x.optimizeMeshVertices,(x,v)=>x.optimizeMeshVertices=v),
                B<ModelImporter>("weldVertices","weldVertices","Can merge vertices and change topology/indices.",x=>x.weldVertices,(x,v)=>x.weldVertices=v),
                B<ModelImporter>("keepQuads","keepQuads","Changes submesh topology and index counts.",x=>x.keepQuads,(x,v)=>x.keepQuads=v),
                E<ModelImporter,ModelImporterIndexFormat>("indexFormat","indexFormat","Changes index width and supported mesh size.",x=>x.indexFormat,(x,v)=>x.indexFormat=v),
                E<ModelImporter,ModelImporterNormals>("importNormals","normalImportMode","Changes normal streams; shading needs visual review.",x=>x.importNormals,(x,v)=>x.importNormals=v),
                E<ModelImporter,ModelImporterTangents>("importTangents","tangentImportMode","Changes tangent streams; shading needs visual review.",x=>x.importTangents,(x,v)=>x.importTangents=v),
                E<ModelImporter,ModelImporterNormalCalculationMode>("normalCalculationMode","normalCalculationMode","Changes normal weighting.",x=>x.normalCalculationMode,(x,v)=>x.normalCalculationMode=v),
                new EyeSettingSpec("normalSmoothingAngle","float","Changes normal smoothing; 0–180 degrees.","normalSmoothAngle",o=>Angle((ModelImporter)o),(o,v)=>{float n;if(!float.TryParse(v,NumberStyles.Float,CultureInfo.InvariantCulture,out n)||float.IsNaN(n)||float.IsInfinity(n)||n<0||n>180)throw new InvalidOperationException("Invalid normal smoothing angle.");((ModelImporter)o).normalSmoothingAngle=n;}),
                B<ModelImporter>("preserveHierarchy","m_PreserveHierarchy","INDIVIDUAL REVIEW: can change root hierarchy and animation paths.",x=>x.preserveHierarchy,(x,v)=>x.preserveHierarchy=v),
                B<ModelImporter>("optimizeGameObjects","m_OptimizeGameObjects","INDIVIDUAL REVIEW: can hide/remove transform hierarchy; bone paths and external consumers need review.",x=>x.optimizeGameObjects,(x,v)=>x.optimizeGameObjects=v),
                B<ModelImporter>("importBlendShapes","m_ImportBlendShapes","Can remove blendshape streams and break animation bindings.",x=>x.importBlendShapes,(x,v)=>x.importBlendShapes=v)};
        }
        internal static EyeSettingSpec[] Select(EyeSettingSpec[] allowed,IEnumerable<string> selection)
        {
            var keys=(selection??Array.Empty<string>()).Take(257).ToArray();if(keys.Length>256||keys.Distinct().Count()!=keys.Length||keys.Any(k=>!allowed.Any(s=>s.key==k)))throw new InvalidOperationException("Unsupported or repeated setting. Select allowlisted settings individually.");
            return keys.Select(k=>allowed.Single(s=>s.key==k)).ToArray();
        }
    }
    [Serializable]public sealed class EyeSettingRow {public string key,kind,before,after;}
    [Serializable]public sealed class EyeSettingInventory
    {public string[] streams=Array.Empty<string>(),submeshes=Array.Empty<string>(),materials=Array.Empty<string>(),bones=Array.Empty<string>(),hierarchy=Array.Empty<string>();}
    [Serializable]public sealed class EyeSettingReport
    {
        public string schema="vrc-eye.setting-transfer.v1",unity=Application.unityVersion,kind,sourceEvidence,source,destination,output,receiptId,status="copy_observed_no_assignment";
        public EyeSettingRow[] rows;public EyeSettingInventory before,after;
    }
    public static class EyeSettingEvidence
    {
        internal static void Idle()
        {if(!Application.unityVersion.StartsWith("2022.3.",StringComparison.Ordinal)||EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Use Unity 2022.3 in idle Edit Mode. Other versions require separate qualification.");}
        internal static Dictionary<string,Object> Prefab(GameObject root)
        {
            Idle();string path=root?AssetDatabase.GetAssetPath(root):"";
            if(!path.StartsWith("Assets/",StringComparison.Ordinal)||!path.EndsWith(".prefab",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadAssetAtPath<GameObject>(path)!=root)throw new InvalidOperationException("Choose a saved prefab root under Assets.");
            var objects=EyeComponentCopies.Objects(root);var names=new HashSet<string>();
            foreach(var go in objects.Values.OfType<GameObject>()) {
                if(string.IsNullOrEmpty(go.name)||go.name.Contains("/")||!names.Add(go.name)||go.GetComponents<Component>().Any(c=>!c)||go.GetComponents<Component>().GroupBy(c=>c.GetType()).Any(g=>g.Count()>1))throw new InvalidOperationException("Prefab correspondence requires distinct names, no missing scripts and no repeated component types.");
            }
            if(objects.Values.Any(EditorUtility.IsDirty))throw new InvalidOperationException("Save source/destination prefab objects first.");return objects;
        }
        public static string Reference(Object value,Dictionary<string,Object> nodes=null,string ownAsset="")
        {
            if(!value)return "null";
            if(nodes!=null){var key=nodes.FirstOrDefault(p=>p.Value==value).Key;if(key!=null)return "node:"+key;}
            string guid;long id;if(!AssetDatabase.TryGetGUIDAndLocalFileIdentifier(value,out guid,out id))throw new InvalidOperationException("References must identify saved assets or mapped destination objects.");
            return (AssetDatabase.GetAssetPath(value)==ownAsset?"self":("asset:"+guid))+":"+id+":"+value.GetType().FullName;
        }
        internal static string Fingerprint(params Object[] roots)
        {
            Idle();var paths=new HashSet<string>();var text=new StringBuilder(Application.unityVersion+"\n");
            foreach(var value in roots.Where(v=>v).Distinct()) {
                string path=AssetDatabase.GetAssetPath(value);
                if(!path.StartsWith("Assets/",StringComparison.Ordinal)||EditorUtility.IsDirty(value))throw new InvalidOperationException("Save reviewed assets under Assets before transfer.");paths.Add(path);
                var go=value as GameObject;
                foreach(var obj in go?(IEnumerable<Object>)EyeComponentCopies.Objects(go).Values:new[]{value}) {
                    if(EditorUtility.IsDirty(obj))throw new InvalidOperationException("A reviewed object has unsaved changes.");text.Append(EyeMaterialMapping.ObjectEvidence(obj)).Append('\n');
                    if(text.Length>32*1024*1024)throw new InvalidOperationException("Setting evidence exceeds 32 MiB.");
                }
                if(go)text.Append(JsonUtility.ToJson(Inventory(go))).Append('\n');
                var importer=AssetImporter.GetAtPath(path);if(importer){if(EditorUtility.IsDirty(importer))throw new InvalidOperationException("Apply/revert pending importer edits first.");text.Append(EditorJsonUtility.ToJson(importer)).Append('\n');}
            }
            foreach(string path in AssetDatabase.GetDependencies(paths.ToArray(),true))if(path.StartsWith("Assets/",StringComparison.Ordinal)||path.StartsWith("Packages/",StringComparison.Ordinal))paths.Add(path);
            if(paths.Count>512)throw new InvalidOperationException("Setting dependency graph exceeds 512 assets.");
            foreach(string path in new[]{"ProjectSettings/ProjectVersion.txt","ProjectSettings/GraphicsSettings.asset","ProjectSettings/QualitySettings.asset","Packages/manifest.json","Packages/packages-lock.json"})if(File.Exists(Path.Combine(EyeShaderFileEvidence.ProjectRoot,path)))paths.Add(path);
            foreach(string path in paths.ToArray())if(File.Exists(Path.Combine(EyeShaderFileEvidence.ProjectRoot,path+".meta")))paths.Add(path+".meta");
            long total=0;foreach(string path in paths.OrderBy(p=>p,StringComparer.Ordinal)){var f=EyeShaderFileEvidence.Read(path);total+=f.bytes;if(total>128L*1024*1024)throw new InvalidOperationException("Setting dependency bytes exceed 128 MiB.");text.Append(f.path).Append('|').Append(f.sha256).Append('\n');}
            return EyeMaterialMapping.Hash(text.ToString());
        }
        public static EyeSettingInventory Inventory(GameObject root)
        {
            var objects=EyeComponentCopies.Objects(root);string own=AssetDatabase.GetAssetPath(root);var streams=new List<string>();var subs=new List<string>();var materials=new List<string>();var bones=new List<string>();var hierarchy=new List<string>();long vertices=0,indices=0;
            foreach(var entry in objects) {
                var go=entry.Value as GameObject;if(go)hierarchy.Add(entry.Key+" | "+go.name);
                Mesh mesh=null;var filter=entry.Value as MeshFilter;var skin=entry.Value as SkinnedMeshRenderer;var renderer=entry.Value as Renderer;
                if(filter)mesh=filter.sharedMesh;if(skin)mesh=skin.sharedMesh;
                if(mesh) {
                    vertices+=mesh.vertexCount;if(vertices>500000)throw new InvalidOperationException("Inventory exceeds 500,000 mesh vertices.");
                    streams.Add(entry.Key+" | vertices="+mesh.vertexCount+" | readable="+mesh.isReadable+" | indexFormat="+mesh.indexFormat+" | "+string.Join(",",mesh.GetVertexAttributes().Select(a=>a.attribute+":"+a.format+":"+a.dimension+":stream"+a.stream)));
                    streams.Add(entry.Key+" | ordered mesh data="+(mesh.isReadable?EyeAvatarRepair.MeshEvidence(mesh):"unavailable_not_readable"));
                    for(int i=0;i<mesh.subMeshCount;i++){indices+=(long)mesh.GetIndexCount(i);if(indices>2000000)throw new InvalidOperationException("Inventory exceeds two million indices.");subs.Add(entry.Key+" | slot="+i+" | topology="+mesh.GetTopology(i)+" | indices="+mesh.GetIndexCount(i)+" | baseVertex="+mesh.GetBaseVertex(i)+" | indexOrder="+(mesh.isReadable?EyeMaterialMapping.Hash(string.Join(",",mesh.GetIndices(i))):"unavailable_not_readable"));}
                }
                if(renderer){if(renderer.sharedMaterials.Length>256)throw new InvalidOperationException("Renderer exceeds 256 material slots.");for(int i=0;i<renderer.sharedMaterials.Length;i++)materials.Add(entry.Key+" | slot="+i+" | "+Reference(renderer.sharedMaterials[i],objects,own));}
                if(skin){if(skin.bones.Length>512)throw new InvalidOperationException("Skin exceeds 512 bones.");bones.Add(entry.Key+" | root="+Reference(skin.rootBone,objects,own));for(int i=0;i<skin.bones.Length;i++)bones.Add(entry.Key+" | bone="+i+" | "+Reference(skin.bones[i],objects,own));}
            }
            if(new[]{streams,subs,materials,bones,hierarchy}.Any(v=>v.Count>10000))throw new InvalidOperationException("Inventory category exceeds 10,000 entries.");
            if(new[]{streams,subs,materials,bones,hierarchy}.SelectMany(v=>v).Any(v=>v.Length>2048||v.Any(char.IsControl)))throw new InvalidOperationException("Inventory labels contain unsupported control characters or exceed 2,048 characters.");
            var result=new EyeSettingInventory{streams=streams.ToArray(),submeshes=subs.ToArray(),materials=materials.ToArray(),bones=bones.ToArray(),hierarchy=hierarchy.ToArray()};if(JsonUtility.ToJson(result).Length>512*1024)throw new InvalidOperationException("Inventory exceeds 512 KiB.");return result;
        }
        internal static string Report(string folder,EyeSettingReport report,Action fresh)
        {
            string path=folder+"/setting-transfer.json",json=JsonUtility.ToJson(report,true);if(Encoding.UTF8.GetByteCount(json)>2*1024*1024)throw new InvalidOperationException("Setting report exceeds two MiB.");
            fresh();EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);
            using(var stream=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var writer=new StreamWriter(stream,new UTF8Encoding(false)))writer.Write(json);
            AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);if(File.ReadAllText(path)!=json)throw new IOException("Setting report changed during import.");EyeCopyHistory.After(path);fresh();return path;
        }
    }
}
