using System;
using UnityEngine;
using Object = UnityEngine.Object;
namespace VrcEye.AvatarToolkit
{
    public sealed class EyeInstallJournal : ScriptableObject
    {
        public string installationId, descriptorId, localAvatarId, createdUtc, phase, rootFingerprint, installedDescriptorFingerprint;
        public Object originalParameters, originalMenu, originalFx, installedParameters, installedMenu, installedFx;
        public bool originalCustomExpressions, originalCustomizeLayers, originalFxDefault;
        public string generatedRootPath;
        [NonSerialized] public GameObject generatedRoot;
        public GameObject ResolveRoot(Component avatar)
        {
            if(!avatar || descriptorId!=EyeSdk.StableObject(avatar))return null;
            if(!string.IsNullOrEmpty(generatedRootPath)) { var t=avatar.transform.Find(generatedRootPath);generatedRoot=t?t.gameObject:null; }
            return generatedRoot;
        }
        public string[] modules, ownedAssets, ownedHashes;
        public string anchorId, platform = "Windows", revision = "source-1";
    }
}
