using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public static class EyeManifestExport
    {
        static readonly Dictionary<string,string> Capabilities=new Dictionary<string,string> {
            {"wrist","wrist_controller"},{"status","status_display"},{"safety","safety_profile"},{"battery","battery_display"},
            {"streamer","streamer_badge"},{"music","music_visualizer"},{"camera","camera_request"},{"availability","dnd_afk"},
            {"connection","connection_indicator"},{"hardware","hardware_status"},{"resource","resource_warning"},{"media","media_effect"}};
        static object[] Vec(Vector3 v) {return new object[]{v.x,v.y,v.z};}
        static string Label(string text,int max=128) { return new string(text.Where(c=>c>=32&&c!=127).Take(max).ToArray()); }
        static string AvatarId(Component avatar,EyeInstallJournal journal)
        {
            var type=EyeSdk.Type("VRC.Core.PipelineManager");var component=type!=null?avatar.GetComponent(type):null;
            if(component) { var p=new SerializedObject(component).FindProperty("blueprintId");
                if(p!=null && Regex.IsMatch(p.stringValue,@"^avtr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")) return p.stringValue.ToLowerInvariant(); }
            return journal.localAvatarId;
        }
        public static string Build(Component avatar,EyeInstallJournal journal,string platform,string revision,bool fullHierarchy,bool labels)
        {
            if(!avatar || !journal || journal.phase!="installed" || journal.descriptorId!=EyeSdk.StableObject(avatar)) throw new InvalidOperationException("Select the avatar owned by the installation journal.");
            if(!new[]{"Windows","Android","iOS","Generic"}.Contains(platform) || string.IsNullOrWhiteSpace(revision) || revision.Length>80) throw new InvalidOperationException("Select a platform and short source revision.");
            journal.ResolveRoot(avatar);
            var descriptor=new SerializedObject(avatar);var pAsset=EyeSdk.Field(descriptor,"expressionParameters").objectReferenceValue;
            if(!pAsset || !journal.generatedRoot) throw new InvalidOperationException("Installation references missing; inspect before export.");
            var installed=journal.modules.SelectMany(x=>EyeModules.Get(x).parameters).ToDictionary(x=>x.name,x=>x);
            var pArray=EyeSdk.Field(new SerializedObject(pAsset),"parameters");if(pArray.arraySize>512)throw new InvalidOperationException("Manifest export supports at most 512 expression parameters; nothing was truncated.");
            var parameters=new List<object>();var names=new HashSet<string>();
            for(int i=0;i<pArray.arraySize;i++) {
                var p=pArray.GetArrayElementAtIndex(i);string name=EyeSdk.Child(p,"name").stringValue;if(string.IsNullOrEmpty(name))continue;
                if(!Regex.IsMatch(name,@"^[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*$") || name.Split('/').Any(x=>x=="."||x=="..") || name.Length>128 || !names.Add(name)) throw new InvalidOperationException("Unsupported or duplicate external name: "+name+"; export stopped without renaming source parameters.");
                var kind=EyeSdk.Child(p,"valueType");string type=kind.enumNames[kind.enumValueIndex];float value=EyeSdk.Child(p,"defaultValue").floatValue;
                bool synced=EyeSdk.Child(p,"networkSynced").boolValue,saved=EyeSdk.Child(p,"saved").boolValue;
                Dictionary<string,object> item;
                if(installed.ContainsKey(name)) {item=installed[name].Manifest();if(type!=installed[name].type)throw new InvalidOperationException("Installed parameter type changed: "+name);}
                else {item=EyeJson.Map("name",name,"type",type,"direction","in","module","existing","semantic","Existing source parameter; external route unverified","min",type=="Float"?-1:0,"max",type=="Int"?255:1,"ephemeral",false);}
                item["default"]=type=="Bool"?(object)(value!=0):type=="Int"?(object)(int)value:(object)value;
                item["neutral"]=type=="Bool"?(object)false:type=="Int"?(object)0:(object)0f;
                item["synced"]=synced;item["saved"]=saved;item["privacy"]=synced?"public":"private";
                parameters.Add(item);
            }
            foreach(var expected in installed.Keys)if(!names.Contains(expected))throw new InvalidOperationException("Installed parameter missing: "+expected);
            var all=avatar.GetComponentsInChildren<Transform>(true);var selected=new HashSet<Transform>();
            if(fullHierarchy) foreach(var t in all)selected.Add(t);
            else { foreach(var t in journal.generatedRoot.GetComponentsInChildren<Transform>(true))selected.Add(t);
                for(var t=journal.generatedRoot.transform.parent;t!=null;t=t.parent){selected.Add(t);if(t==avatar.transform)break;} }
            if(selected.Count>2000)throw new InvalidOperationException("Hierarchy exceeds 2000 objects; choose toolkit subtree export.");
            var nodes=all.Where(selected.Contains).ToArray();var ids=nodes.Select((t,i)=>new{t,id="object_"+i}).ToDictionary(x=>x.t,x=>x.id);
            var nodeModule=new Dictionary<Transform,string>();var hierarchy=new List<object>();
            foreach(var t in nodes) {
                string module="";for(var n=t;n!=null&&n!=avatar.transform;n=n.parent) if(journal.modules.Contains(n.name)&&n.parent&&n.parent.name=="Display"&&n.parent.parent==journal.generatedRoot.transform){module=n.name;break;}
                nodeModule[t]=module;
                var components=t.GetComponents<Component>().Select(x=>x?Label(x.GetType().Name):"Missing script").Take(64).ToArray();
                hierarchy.Add(EyeJson.Map("id",ids[t],"parent",t.parent&&ids.ContainsKey(t.parent)?ids[t.parent]:"","name",labels?Label(t.name):(module!=""?module+" "+ids[t]:"Source "+ids[t]),"module",module,"components",components,"anchor",t==journal.generatedRoot.transform.parent,"generated_id",""));
            }
            var modules=new List<object>();
            foreach(string id in journal.modules) {
                var module=EyeModules.Get(id);var objects=nodes.Where(x=>nodeModule[x]==id).ToArray();
                var renderers=objects.SelectMany(x=>x.GetComponents<Renderer>()).ToArray();
                modules.Add(EyeJson.Map("id",id,"version","1.19.3","dependencies",id=="connection"?new string[0]:new[]{"connection"},"platforms",new[]{platform},
                    "owned_objects",objects.Select(x=>ids[x]).ToArray(),"anchors",new[]{ids[journal.generatedRoot.transform.parent]},"menu_entries",module.parameters.Where(x=>x.direction=="out"||x.name=="EYE_In_Quiet").Select(x=>module.label).ToArray(),
                    "tier","minimal","costs",EyeJson.Map("renderers",renderers.Length,"materials",renderers.SelectMany(x=>x.sharedMaterials).Where(x=>x).Distinct().Count(),"contacts",objects.Sum(x=>x.GetComponents<Component>().Count(c=>c&&c.GetType().Name=="VRCContactReceiver")),"physbones",0),"description",module.description,"uninstall","owned_only"));
            }
            modules.Add(EyeJson.Map("id","existing","version","source","platforms",new[]{platform},"description","Existing avatar parameters; not toolkit-owned. No external route inferred."));
            var bindings=new List<object>();var fx=EyeSdk.Child(EyeSdk.Fx(descriptor),"animatorController").objectReferenceValue as AnimatorController;
            if(fx) foreach(var layer in fx.layers) foreach(var motion in Motions(layer.stateMachine)) foreach(var curve in AnimationUtility.GetCurveBindings(motion)) {
                var t=avatar.transform.Find(curve.path);if(!t||!ids.ContainsKey(t))continue;
                bindings.Add(EyeJson.Map("object",ids[t],"property",Label(curve.propertyName),"module",nodeModule[t]==""?"existing":nodeModule[t],"layer",Label(layer.name,80)));
                if(bindings.Count>2000)throw new InvalidOperationException("More than 2000 animation bindings; export stopped, not silently truncated.");
            }
            var animator=avatar.GetComponent<Animator>();var bones=new Dictionary<string,object>();
            if(animator&&animator.isHuman)foreach(HumanBodyBones bone in Enum.GetValues(typeof(HumanBodyBones))) {
                if(bone==HumanBodyBones.LastBone)continue;var t=animator.GetBoneTransform(bone);if(t&&ids.ContainsKey(t))bones[bone.ToString()]=ids[t]; }
            var viewpoint=descriptor.FindProperty("ViewPosition");var root=journal.generatedRoot.transform;
            var rig=EyeJson.Map("kind",animator?(animator.isHuman?"humanoid":"generic"):"unknown","bones",bones,"viewpoint",viewpoint!=null?Vec(viewpoint.vector3Value):null,
                "sockets",new[]{EyeJson.Map("id","installation_anchor","object",ids[root.parent],"module","","side","manual","position",Vec(root.localPosition),"rotation",Vec(root.localEulerAngles),"scale",Vec(root.localScale))});
            var data=EyeJson.Map("schema",1,"avatar_id",AvatarId(avatar,journal),"package_id","eye-"+journal.installationId,"platform",platform,"revision",Label(revision,80),"build_id","","stage","source","toolkit_version","1.19.3","label",labels?Label(avatar.name):"Selected avatar source",
                "parameters",parameters,"modules",modules,"hierarchy",hierarchy,"bindings",bindings,"rig",rig,
                "capabilities",journal.modules.Select(x=>Capabilities[x]).ToArray(),"actions",installed.Values.Select(x=>x.action).Where(x=>x!="").Distinct().ToArray());
            string json=EyeJson.Write(data);if(Encoding.UTF8.GetByteCount(json)>256*1024)throw new InvalidOperationException("Manifest exceeds 256 KiB; choose a smaller reviewed source export.");return json;
        }
        static IEnumerable<AnimationClip> Motions(AnimatorStateMachine sm)
        {
            foreach(var state in sm.states) foreach(var clip in Clips(state.state.motion))yield return clip;
            foreach(var child in sm.stateMachines)foreach(var clip in Motions(child.stateMachine))yield return clip;
        }
        static IEnumerable<AnimationClip> Clips(Motion motion)
        {if(motion is AnimationClip)yield return (AnimationClip)motion;else if(motion is BlendTree)foreach(var child in ((BlendTree)motion).children)foreach(var clip in Clips(child.motion))yield return clip;}
        public static List<string> Inspect(Component avatar)
        {
            var findings=new List<string>{"NOT TESTED: generated build, runtime OSC, rendering privacy, Contacts and per-platform SDK validation."};
            if(!avatar){findings.Add("ERROR: select a descriptor.");return findings;}
            var animator=avatar.GetComponent<Animator>();findings.Add(animator?"INFO: rig "+(animator.isHuman?"humanoid":"generic"):"WARNING: no Animator on descriptor root.");
            var so=new SerializedObject(avatar);var parameters=EyeSdk.Field(so,"expressionParameters").objectReferenceValue;
            if(parameters){var p=EyeSdk.Field(new SerializedObject(parameters),"parameters");int bits=0;var names=new HashSet<string>();
                for(int i=0;i<p.arraySize;i++){var e=p.GetArrayElementAtIndex(i);var name=EyeSdk.Child(e,"name").stringValue;if(name!=""&&!names.Add(name))findings.Add("ERROR: duplicate expression parameter "+name);
                    if(EyeSdk.Child(e,"networkSynced").boolValue){var type=EyeSdk.Child(e,"valueType");bits+=type.enumNames[type.enumValueIndex]=="Bool"?1:8;}}
                findings.Add((bits>256?"ERROR":"INFO")+": synchronized parameter cost "+bits+" / 256; source array count "+p.arraySize+" / 8192.");}
            foreach(var t in avatar.GetComponentsInChildren<Transform>(true)) foreach(var c in t.GetComponents<Component>()) {
                if(!c){findings.Add("ERROR: missing source component on a selected-avatar object.");continue;}
                if(c.GetType().Name.Contains("PhysBone")){var s=new SerializedObject(c);var property=s.GetIterator();int inspected=0;
                    while(property.NextVisible(true)&&++inspected<1000) if(property.propertyType==SerializedPropertyType.ObjectReference&&property.objectReferenceValue==null&&property.objectReferenceInstanceIDValue!=0) findings.Add("WARNING: missing PhysBone reference: "+Label(property.name));}
                if(c.GetType().Name=="VRCContactReceiver"){var s=new SerializedObject(c);var local=s.FindProperty("localOnly");var others=s.FindProperty("allowOthers");
                    if(local!=null&&others!=null&&local.boolValue&&others.boolValue)findings.Add("INFO: local-only Contact permits others; local-only is not self-only.");}
                if(c.GetType().Name=="VRCRaycast")findings.Add("NOT TESTED: raycast result/origin dependency; review selected component and hit/miss behavior in SDK.");
            }
            findings.Add("INFO: disabled components still count toward applicable SDK limits; runtime hiding is not build removal.");return findings;
        }
    }
}
