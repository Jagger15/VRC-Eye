using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    // Generated primitives use only supported transforms, meshes, renderers, animator assets and SDK Contacts.
    // Every curve binds only to a newly created descendant; existing rig/controller layers are untouched.
    public static class EyeVisuals
    {
        static readonly Color[] Palette = { new Color(.35f,.35f,.35f), new Color(.15f,.8f,.45f), new Color(.95f,.6f,.1f), new Color(.85f,.15f,.25f), new Color(.3f,.55f,.95f) };
        static string folder; static List<string> owned; static int serial;
        public static void Build(EyePlan plan,GameObject root,AnimatorController controller,string destination,List<string> assets)
        {
            folder=destination;owned=assets;serial=0;
            var display=new GameObject("Display");display.transform.SetParent(root.transform,false);display.SetActive(false);
            var displayOff=Clip("Private display off",plan.avatar.transform,new Dictionary<GameObject,bool>{{display,false}});
            var displayOn=Clip("Private display on",plan.avatar.transform,new Dictionary<GameObject,bool>{{display,true}});
            var gate=Machine(controller,"EYE private display");var off=State(gate,"Remote or unconfirmed",displayOff);var on=State(gate,"Local wearer",displayOn);gate.defaultState=off;
            Transition(off,on,"IsLocal",AnimatorConditionMode.If);Transition(on,off,"IsLocal",AnimatorConditionMode.IfNot);
            int index=0;var freshnessTargets=new List<GameObject>();
            foreach(string id in plan.modules) {
                var module=EyeModules.Get(id);var part=new GameObject(id);part.transform.SetParent(display.transform,false);
                part.transform.localPosition=new Vector3((index%3)*.04f,0,(index/3)*.024f);index++;
                // Visual scale affects only visuals; contact radius remains independently authored.
                var visual=new GameObject("Visual");visual.transform.SetParent(part.transform,false);visual.transform.localScale=Vector3.one*plan.visualSize;
                if(id=="wrist") { Cube(visual.transform,"Panel",new Vector3(.07f,.004f,.045f),Palette[0]);continue; }
                if(id=="connection") continue;
                if(id=="camera" || id=="safety") {
                    // Constant state survives beyond one frame. The external broker owns hold/rearm/cooldown policy.
                    var contact=new GameObject("Self touch request");contact.transform.SetParent(part.transform,false);
                    EyeInstallation.ConfigureContact(contact,module.parameters[0].name,plan.touchRadius);
                    var idle=Cube(visual.transform,"Idle",new Vector3(.022f,.005f,.018f),Palette[0]);
                    var touched=Cube(visual.transform,"Touched",new Vector3(.022f,.005f,.018f),Palette[2]);
                    var feedback=new GameObject("Feedback freshness");feedback.transform.SetParent(visual.transform,false);freshnessTargets.Add(feedback);
                    var accepted=Cube(feedback.transform,"Accepted not completion",new Vector3(.012f,.006f,.01f),new Color(.1f,.8f,.9f));
                    var sm=Machine(controller,"EYE "+id+" touch");
                    var a=State(sm,"Idle",Clip(id+" idle",plan.avatar.transform,new Dictionary<GameObject,bool>{{idle,true},{touched,false}}));
                    var b=State(sm,"Held request",Clip(id+" touched",plan.avatar.transform,new Dictionary<GameObject,bool>{{idle,false},{touched,true}}));sm.defaultState=a;
                    Transition(a,b,module.parameters[0].name,AnimatorConditionMode.If);Transition(b,a,module.parameters[0].name,AnimatorConditionMode.IfNot);
                    Boolean(controller,plan.avatar.transform,accepted,module.parameters[1].name,"EYE "+id+" reported feedback");
                    continue;
                }
                if(id!="availability") freshnessTargets.Add(visual);
                var input=module.parameters[0];
                if(input.type=="Float") Meter(controller,plan.avatar.transform,visual.transform,input);
                else if(input.type=="Bool") {
                    var symbol=Cube(visual.transform,"Selected",new Vector3(.018f,.005f,.018f),Palette[2]);Boolean(controller,plan.avatar.transform,symbol,input.name,"EYE "+id);
                    if(id=="availability") { var native=Cube(visual.transform,"Native AFK",new Vector3(.008f,.007f,.008f),Palette[4]);native.transform.localPosition=new Vector3(.015f,0,0);Boolean(controller,plan.avatar.transform,native,"AFK","EYE native AFK read only"); }
                } else FiniteState(controller,plan.avatar.transform,visual.transform,input);
            }
            var connection=display.transform.Find("connection/Visual");
            Heartbeat(controller,plan.avatar.transform,connection,freshnessTargets);
        }
        static GameObject Cube(Transform parent,string name,Vector3 size,Color color)
        {
            var go=GameObject.CreatePrimitive(PrimitiveType.Cube);go.name=name;go.transform.SetParent(parent,false);go.transform.localScale=size;
            var collider=go.GetComponent<Collider>();if(collider)Object.DestroyImmediate(collider);
            // Mobile Diffuse is an SDK shader; fail rather than silently substituting an unsupported mobile shader.
            var shader=Shader.Find("VRChat/Mobile/Diffuse"); if(!shader) throw new InvalidOperationException("Required VRChat/Mobile/Diffuse shader unavailable.");
            var material=new Material(shader){name="Eye "+name,color=color};string path=folder+"/Material"+(serial++)+".mat";AssetDatabase.CreateAsset(material,path);owned.Add(path);
            go.GetComponent<Renderer>().sharedMaterial=material;return go;
        }
        static AnimatorStateMachine Machine(AnimatorController c,string name)
        {
            var sm=new AnimatorStateMachine{name=name};AssetDatabase.AddObjectToAsset(sm,c);
            c.AddLayer(new AnimatorControllerLayer{name=name,stateMachine=sm,defaultWeight=1,blendingMode=AnimatorLayerBlendingMode.Override});return sm;
        }
        static AnimatorState State(AnimatorStateMachine sm,string name,Motion clip)
        {var s=sm.AddState(name);s.motion=clip;s.writeDefaultValues=false;return s;}
        static AnimationClip Clip(string name,Transform root,Dictionary<GameObject,bool> visibility)
        {
            var c=new AnimationClip{name=name,frameRate=30};
            foreach(var pair in visibility) c.SetCurve(AnimationUtility.CalculateTransformPath(pair.Key.transform,root),typeof(GameObject),"m_IsActive",AnimationCurve.Constant(0,1,pair.Value?1:0));
            string path=folder+"/Clip"+(serial++)+".anim";AssetDatabase.CreateAsset(c,path);owned.Add(path);return c;
        }
        static AnimatorStateTransition Transition(AnimatorState from,AnimatorState to,string parameter,AnimatorConditionMode mode,float threshold=0)
        {var t=from.AddTransition(to);t.hasExitTime=false;t.duration=0;t.canTransitionToSelf=false;t.AddCondition(mode,threshold,parameter);return t;}
        static void Boolean(AnimatorController c,Transform root,GameObject go,string parameter,string label)
        {
            var sm=Machine(c,label);var off=State(sm,"Neutral",Clip(label+" off",root,new Dictionary<GameObject,bool>{{go,false}}));
            var on=State(sm,"Selected",Clip(label+" on",root,new Dictionary<GameObject,bool>{{go,true}}));sm.defaultState=off;
            Transition(off,on,parameter,AnimatorConditionMode.If);Transition(on,off,parameter,AnimatorConditionMode.IfNot);go.SetActive(false);
        }
        static void FiniteState(AnimatorController c,Transform root,Transform visual,EyeParameter input)
        {
            var sm=Machine(c,"EYE "+input.module);var symbols=new List<GameObject>();
            for(int i=0;i<=input.max;i++) symbols.Add(Cube(visual,"State "+i,new Vector3(.012f+i*.002f,.005f,.014f),Palette[Math.Min(i,Palette.Length-1)]));
            var unknown=Cube(visual,"Unknown or stale",new Vector3(.006f,.006f,.006f),Palette[2]);
            var unknownMotion=Clip(input.module+" unknown",root,symbols.Concat(new[]{unknown}).ToDictionary(x=>x,x=>x==unknown));
            var fallback=State(sm,"Unknown",unknownMotion);sm.defaultState=fallback;
            for(int i=0;i<=input.max;i++) {
                int selected=i;var state=State(sm,"Value "+i,Clip(input.module+" value "+i,root,symbols.Concat(new[]{unknown}).ToDictionary(x=>x,x=>x==symbols[selected])));
                var enter=sm.AddAnyStateTransition(state);enter.hasExitTime=false;enter.duration=0;enter.canTransitionToSelf=false;enter.AddCondition(AnimatorConditionMode.Equals,i,input.name);
                if(input.validity!="") {enter.AddCondition(AnimatorConditionMode.If,0,input.validity);Transition(state,fallback,input.validity,AnimatorConditionMode.IfNot);}
                Transition(state,fallback,input.name,AnimatorConditionMode.Greater,input.max);
                Transition(state,fallback,input.name,AnimatorConditionMode.Less,0);
            }
            foreach(var symbol in symbols) symbol.SetActive(false);
        }
        static void Meter(AnimatorController c,Transform root,Transform visual,EyeParameter input)
        {
            var meter=Cube(visual,"Normalized meter",new Vector3(.025f,.006f,.012f),Palette[1]);
            var unknown=Cube(visual,"Unknown or stale",new Vector3(.006f,.006f,.006f),Palette[2]);
            var sm=Machine(c,"EYE "+input.module);var unknownClip=Clip(input.module+" unknown",root,new Dictionary<GameObject,bool>{{meter,false},{unknown,true}});
            var min=Clip(input.module+" minimum",root,new Dictionary<GameObject,bool>{{meter,true},{unknown,false}});
            var max=Clip(input.module+" maximum",root,new Dictionary<GameObject,bool>{{meter,true},{unknown,false}});
            string path=AnimationUtility.CalculateTransformPath(meter.transform,root);
            min.SetCurve(path,typeof(Transform),"m_LocalScale.x",AnimationCurve.Constant(0,1,.001f));max.SetCurve(path,typeof(Transform),"m_LocalScale.x",AnimationCurve.Constant(0,1,.025f));
            EditorUtility.SetDirty(min);EditorUtility.SetDirty(max);
            var blend=new BlendTree{name="Bounded meter",blendType=BlendTreeType.Simple1D,blendParameter=input.name,useAutomaticThresholds=false};
            AssetDatabase.AddObjectToAsset(blend,c);blend.AddChild(min,0);blend.AddChild(max,1);
            var neutral=State(sm,"Unknown",unknownClip);var valid=State(sm,"Current normalized value",blend);sm.defaultState=neutral;
            Transition(neutral,valid,input.validity,AnimatorConditionMode.If);Transition(valid,neutral,input.validity,AnimatorConditionMode.IfNot);meter.SetActive(false);
        }
        static void Heartbeat(AnimatorController c,Transform root,Transform visual,List<GameObject> freshnessTargets)
        {
            var live=Cube(visual,"Recent changing heartbeat",new Vector3(.012f,.005f,.012f),Palette[1]);
            var stale=Cube(visual,"Unconfirmed",new Vector3(.006f,.006f,.006f),Palette[2]);
            var recent=freshnessTargets.ToDictionary(x=>x,x=>true);recent.Add(live,true);recent.Add(stale,false);
            var expired=freshnessTargets.ToDictionary(x=>x,x=>false);expired.Add(live,false);expired.Add(stale,true);
            var yes=Clip("Heartbeat recent",root,recent);
            var no=Clip("Heartbeat unknown",root,expired);
            var sm=Machine(c,"EYE changing heartbeat");var initial=State(sm,"Initial unconfirmed",no);
            var alive0=State(sm,"Recent zero",yes);var alive1=State(sm,"Recent one",yes);var stale0=State(sm,"Stale zero",no);var stale1=State(sm,"Stale one",no);sm.defaultState=initial;
            Transition(initial,alive1,"EYE_In_Heartbeat",AnimatorConditionMode.If);
            Transition(alive0,alive1,"EYE_In_Heartbeat",AnimatorConditionMode.If);Transition(alive1,alive0,"EYE_In_Heartbeat",AnimatorConditionMode.IfNot);
            Transition(stale0,alive1,"EYE_In_Heartbeat",AnimatorConditionMode.If);Transition(stale1,alive0,"EYE_In_Heartbeat",AnimatorConditionMode.IfNot);
            foreach(var pair in new[]{new[]{alive0,stale0},new[]{alive1,stale1}}) {var t=pair[0].AddTransition(pair[1]);t.hasExitTime=true;t.exitTime=5;t.duration=0;}
            live.SetActive(false);foreach(var target in freshnessTargets) target.SetActive(false);
        }
    }
}
