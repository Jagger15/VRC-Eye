using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeToolkitWindow : EditorWindow
    {
        GameObject selected; Transform anchor; readonly HashSet<string> modules=new HashSet<string>{"wrist","battery","connection"};
        Vector3 position=new Vector3(0,.025f,0),rotation;float size=1,radius=.012f;
        EyePlan plan;string report="Select a saved scene avatar. All authoring is local. No account sign-in or upload is performed.";
        string revision="source-1";int platform,view;bool authorized,labels,fullHierarchy;Vector2 scroll;
        [MenuItem("VRC Eye/Avatar Toolkit")]
        static void ShowWindow() { GetWindow<EyeToolkitWindow>("VRC Eye Avatar Toolkit"); }
        void OnEnable() { if(Selection.activeGameObject && EyeSdk.Descriptor(Selection.activeGameObject)) selected=Selection.activeGameObject; }
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("Experimental editor authoring. Source validation does not establish generated-build or runtime compatibility. SDK target 3.10.x; native Unity verification remains required.",MessageType.Warning);
            EditorGUI.BeginChangeCheck();
            selected=(GameObject)EditorGUILayout.ObjectField("Selected avatar root",selected,typeof(GameObject),true);
            var avatar=EyeSdk.Descriptor(selected);
            authorized=EditorGUILayout.ToggleLeft("I am authorized to modify and export this selected source avatar",authorized);
            anchor=(Transform)EditorGUILayout.ObjectField("Confirmed attachment anchor",anchor,typeof(Transform),true);
            EditorGUILayout.BeginHorizontal();
            if(GUILayout.Button("Suggest left wrist"))SuggestAnchor(HumanBodyBones.LeftHand);
            if(GUILayout.Button("Suggest right wrist"))SuggestAnchor(HumanBodyBones.RightHand);
            if(GUILayout.Button("Suggest chest"))SuggestAnchor(HumanBodyBones.Chest);
            EditorGUILayout.EndHorizontal();
            position=EditorGUILayout.Vector3Field("Local position (meters)",position);rotation=EditorGUILayout.Vector3Field("Local rotation",rotation);
            size=EditorGUILayout.Slider("Visual size",size,.25f,4);radius=EditorGUILayout.Slider("Touch radius (meters)",radius,.004f,.04f);
            EditorGUILayout.LabelField("Install finite starter modules",EditorStyles.boldLabel);
            foreach(var module in EyeModules.All) {
                bool enabled=EditorGUILayout.ToggleLeft(module.label+(module.id=="connection"?" (required freshness dependency)":""),module.id=="connection"||modules.Contains(module.id));
                if(enabled)modules.Add(module.id);else modules.Remove(module.id);
            }
            modules.Add("connection");
            if(EditorGUI.EndChangeCheck())plan=null;
            using(new EditorGUI.DisabledScope(!authorized||!avatar)) {
                if(GUILayout.Button("Analyze and preview proposed changes"))Run(()=>{
                    plan=EyeInstallation.Analyze(avatar,anchor,modules.OrderBy(x=>x).ToArray(),position,rotation,size,radius);
                    report=string.Join("\n\n",plan.messages)+"\n\nParameters:\n"+string.Join("\n",plan.Parameters.Select(x=>x.name+" | "+x.type+" | "+x.direction+" | private / unsaved / unsynced"));
                });
                using(new EditorGUI.DisabledScope(plan==null)) if(GUILayout.Button("Install reviewed plan"))Run(()=>{
                    if(!EditorUtility.DisplayDialog("Install reviewed VRC Eye changes?",string.Join("\n\n",plan.messages),"Install clones","Cancel"))return;
                    var journal=EyeInstallation.Install(plan);Selection.activeObject=journal;report="Installed local source modules. Save the scene. Journal and original-reference backup: "+AssetDatabase.GetAssetPath(journal)+"\nRun SDK Build & Test and the supplied runtime checklist before release.";plan=null;
                });
                EditorGUILayout.Space();EditorGUILayout.LabelField("Inspect and export",EditorStyles.boldLabel);
                if(GUILayout.Button("Inspect source configuration"))Run(()=>report=string.Join("\n",EyeManifestExport.Inspect(avatar)));
                platform=EditorGUILayout.Popup("Source platform",platform,new[]{"Windows","Android","iOS","Generic"});
                revision=EditorGUILayout.TextField("Source revision",revision);
                fullHierarchy=EditorGUILayout.ToggleLeft("Include entire selected-avatar hierarchy (default: toolkit subtree + anchor ancestors)",fullHierarchy);
                labels=EditorGUILayout.ToggleLeft("Include source object labels (default: sanitized labels)",labels);
                if(GUILayout.Button("Review and export source manifest"))Run(()=>{
                    var journal=EyeInstallation.Find(avatar);string json=EyeManifestExport.Build(avatar,journal,new[]{"Windows","Android","iOS","Generic"}[platform],revision,fullHierarchy,labels);
                    report="Prepared SOURCE manifest: "+Encoding.UTF8.GetByteCount(json)+" bytes. No mesh, texture, private project path, account credential or upload token is included. Hierarchy: "+(fullHierarchy?"entire selected avatar":"toolkit subtree and anchor ancestors")+". Labels: "+(labels?"source names":"sanitized")+". Original expression names are preserved so parameter contracts remain accurate.";
                    if(!EditorUtility.DisplayDialog("Export local source manifest?",report+"\nSource stage is not the generated or currently worn build.","Choose file","Cancel"))return;
                    string path=EditorUtility.SaveFilePanel("Save source manifest","","avatar-source-manifest.json","json");if(path!="")File.WriteAllText(path,json,new UTF8Encoding(false));
                });
                view=EditorGUILayout.Popup("Static preview view",view,new[]{"Front","Back","Left","Right"});
                if(GUILayout.Button("Export selected-source static preview PNG"))Run(()=>{
                    if(!EditorUtility.DisplayDialog("Export a rendered source preview?","Renders selected source meshes/materials in their current pose. This includes visible creator assets and is a separate local export. It is not a T-pose conversion or a VRChat-runtime preview.","Choose file","Cancel"))return;
                    string path=EditorUtility.SaveFilePanel("Save source preview","","avatar-source-preview.png","png");if(path!=""){EyeStaticPreview.Export(selected,path,view);report="Saved static source preview. Current source pose; no source transforms or runtime avatar changed.";}
                });
                if(GUILayout.Button("Remove unchanged installation using journal"))Run(()=>{
                    var journal=EyeInstallation.Find(avatar);if(!journal)throw new InvalidOperationException("No active owned journal found.");
                    if(!EditorUtility.DisplayDialog("Restore recorded original references?","Removal checks descriptor, generated objects and asset hashes. Edited installations stop for manual review. Generated assets remain retained in case another avatar uses them.","Restore unchanged installation","Cancel"))return;
                    EyeInstallation.Remove(avatar,journal);plan=null;report="Recorded original references restored. Generated assets and journal retained. Save scene; no source asset was deleted.";
                });
            }
            EditorGUILayout.Space();EditorGUILayout.LabelField("Result / proposed diff",EditorStyles.boldLabel);
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(180));EditorGUILayout.EndScrollView();
        }
        void SuggestAnchor(HumanBodyBones bone)
        {
            var animator=selected?selected.GetComponent<Animator>():null;
            if(!animator||!animator.isHuman){report="Humanoid anchor unavailable. Assign a manual transform inside this avatar.";return;}
            anchor=animator.GetBoneTransform(bone);plan=null;report="Suggested "+bone+". Inspect placement and confirm by reviewing the plan; no rig pose was changed.";
        }
        void Run(Action action) {try{action();}catch(Exception error){report="Operation stopped: "+error.Message;Debug.LogException(error);}Repaint();}
    }
    public static class EyeStaticPreview
    {
        public static void Export(GameObject avatar,string path,int side)
        {
            var renderers=avatar.GetComponentsInChildren<Renderer>(true).Where(x=>x.enabled&&x.gameObject.activeInHierarchy&&(x is MeshRenderer||x is SkinnedMeshRenderer)).ToArray();
            if(renderers.Length==0||renderers.Length>256)throw new InvalidOperationException("Static preview requires 1–256 enabled mesh renderers.");
            var meshes=new List<Mesh>();var items=new List<Tuple<Mesh,Matrix4x4,Material[]>>();long vertices=0;
            var bounds=renderers[0].bounds;var preview=new PreviewRenderUtility();Texture2D image=null;
            try {
                foreach(var r in renderers){bounds.Encapsulate(r.bounds);Mesh mesh;
                    if(r is SkinnedMeshRenderer){mesh=new Mesh();((SkinnedMeshRenderer)r).BakeMesh(mesh);meshes.Add(mesh);}
                    else {var filter=r.GetComponent<MeshFilter>();mesh=filter?filter.sharedMesh:null;}
                    if(!mesh)continue;vertices+=mesh.vertexCount;if(vertices>500000)throw new InvalidOperationException("Static preview vertex limit exceeded (500,000). Supply a lighter authorized preview.");
                    items.Add(Tuple.Create(mesh,r.localToWorldMatrix,r.sharedMaterials));}
                float extent=Mathf.Max(.1f,bounds.extents.magnitude);Vector3 direction=new[]{Vector3.forward,Vector3.back,Vector3.right,Vector3.left}[Mathf.Clamp(side,0,3)];
                preview.BeginStaticPreview(new Rect(0,0,1024,1024));preview.camera.orthographic=true;preview.camera.orthographicSize=extent*1.1f;
                preview.camera.nearClipPlane=.01f;preview.camera.farClipPlane=extent*10+10;preview.camera.transform.position=bounds.center+direction*extent*3;preview.camera.transform.LookAt(bounds.center);
                preview.camera.backgroundColor=new Color(.12f,.12f,.14f);preview.camera.clearFlags=CameraClearFlags.Color;
                preview.lights[0].intensity=1;preview.lights[0].transform.rotation=Quaternion.Euler(40,40,0);preview.lights[1].intensity=.5f;
                foreach(var item in items)for(int sub=0;sub<Math.Min(item.Item1.subMeshCount,item.Item3.Length);sub++) if(item.Item3[sub])preview.DrawMesh(item.Item1,item.Item2,item.Item3[sub],sub);
                preview.Render();image=preview.EndStaticPreview();File.WriteAllBytes(path,image.EncodeToPNG());
            }finally{preview.Cleanup();foreach(var mesh in meshes)Object.DestroyImmediate(mesh);if(image)Object.DestroyImmediate(image);}
        }
    }
}
