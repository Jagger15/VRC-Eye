// Durable receipts for separate copy operations; no startup replay or assignment.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace VrcEye.AvatarToolkit
{
    [Serializable] public sealed class EyeCopyFile
    {public string path,sha256,metaSha256,phase;public long bytes;public bool external;}
    [Serializable] public sealed class EyeCopyReceipt
    {
        public int schema=1;public string id,operation,sourceEvidence,review,unity,createdUtc,updatedUtc,phase,result;
        public EyeCopyFile[] files=Array.Empty<EyeCopyFile>();
    }
    public static class EyeCopyHistory
    {
        [ThreadStatic]static Scope active;
        static string Root {get{return Path.Combine(Path.GetDirectoryName(Application.dataPath),"Library","VrcEyeCopyHistory");}}
        static string Absolute(string path){return Path.IsPathRooted(path)?path:Path.Combine(Path.GetDirectoryName(Application.dataPath),path);}
        static void NoLinks(string path)
        {
            string current=Path.GetFullPath(path);
            while(!string.IsNullOrEmpty(current)) {
                try {if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Copy receipt/output path contains a link or reparse point.");}
                catch(FileNotFoundException){}catch(DirectoryNotFoundException){}
                string parent=Path.GetDirectoryName(current);if(parent==current)break;current=parent;
            }
        }
        static string Digest(string path,out long bytes)
        {
            NoLinks(path);var before=new FileInfo(path);bytes=before.Length;var time=before.LastWriteTimeUtc;
            if(bytes>512L*1024*1024)throw new IOException("Copy receipt file evidence exceeds 512 MiB.");
            string value;
            using(var input=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))
            using(var hash=SHA256.Create())value=BitConverter.ToString(hash.ComputeHash(input)).Replace("-","").ToLowerInvariant();
            NoLinks(path);var after=new FileInfo(path);
            if(after.Length!=bytes||after.LastWriteTimeUtc!=time)throw new IOException("Copy output changed during evidence capture.");return value;
        }
        static EyeCopyFile Evidence(string path,bool external)
        {
            if(!external)EyeAvatarRepair.CheckProjectOutput(path);
            long length,metaLength;string full=Absolute(path);string hash=Digest(full,out length);
            string meta=external?"":Digest(full+".meta",out metaLength);
            return new EyeCopyFile{path=path,sha256=hash,metaSha256=meta,bytes=length,external=external,phase="Recorded"};
        }
        static bool Matches(EyeCopyFile expected)
        {
            try {var current=Evidence(expected.path,expected.external);return current.sha256==expected.sha256&&current.metaSha256==expected.metaSha256&&current.bytes==expected.bytes;}
            catch(IOException){return false;}catch(UnauthorizedAccessException){return false;}
        }
        public sealed class Scope:IDisposable
        {
            readonly EyeCopyReceipt receipt;readonly string path;string previous="";bool complete,disposed;
            public string Id {get{return receipt.id;}}
            internal Scope(string operation,string evidence,string review)
            {
                if(active!=null)throw new InvalidOperationException("Another copy operation is still active.");
                if((review??"").Length>256*1024)throw new InvalidOperationException("Copy review exceeds its receipt budget.");
                NoLinks(Root);Directory.CreateDirectory(Root);NoLinks(Root);
                if(Directory.EnumerateFiles(Root,"*.json").Take(2000).Count()>=2000)throw new IOException("Copy history reached 2,000 receipts. Preserve and archive it before creating more copies.");
                receipt=new EyeCopyReceipt{id=Guid.NewGuid().ToString("N"),operation=operation,sourceEvidence=evidence,review=review,
                    unity=Application.unityVersion,createdUtc=DateTime.UtcNow.ToString("O"),phase="Prepared"};
                path=Path.Combine(Root,receipt.id+".json");Save();active=this;
            }
            void Save()
            {
                receipt.updatedUtc=DateTime.UtcNow.ToString("O");string json=JsonUtility.ToJson(receipt,true);
                if(Encoding.UTF8.GetByteCount(json)>2*1024*1024)throw new IOException("Copy receipt exceeds 2 MiB.");
                NoLinks(path);long count;
                if(previous.Length==0&&File.Exists(path)||previous.Length>0&&(!File.Exists(path)||Digest(path,out count)!=previous))throw new IOException("The copy receipt changed; it was not overwritten.");
                string temporary=Path.Combine(Root,Guid.NewGuid().ToString("N")+".pending");NoLinks(temporary);
                using(var stream=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None)) {
                    byte[] data=Encoding.UTF8.GetBytes(json);stream.Write(data,0,data.Length);stream.Flush(true);
                }
                NoLinks(path);NoLinks(temporary);
                if(previous.Length==0)File.Move(temporary,path);
                else {if(Digest(path,out count)!=previous)throw new IOException("The receipt changed before publication; pending evidence was retained.");File.Replace(temporary,path,null);}
                previous=Digest(path,out count);
            }
            internal void Before(string output,bool external)
            {
                if(disposed)throw new InvalidOperationException("Copy receipt is closed.");
                if(!external)EyeAvatarRepair.CheckProjectOutput(output);NoLinks(Absolute(output));
                var old=receipt.files.SingleOrDefault(f=>f.path==output);
                if(old!=null&&!Matches(old))throw new IOException("A previously recorded output changed; it was not overwritten.");
                if(old==null) {
                    if(File.Exists(Absolute(output))||File.Exists(Absolute(output)+".meta"))throw new IOException("New output or metadata path is already occupied.");
                    if(receipt.files.Length>=1024)throw new IOException("Copy operation exceeds 1,024 output files.");
                    old=new EyeCopyFile{path=output,external=external};receipt.files=receipt.files.Concat(new[]{old}).ToArray();
                }
                old.phase="Writing";receipt.phase="Writing; output may be partial";Save();
            }
            internal void After(string output,bool external)
            {
                int index=Array.FindIndex(receipt.files,f=>f.path==output&&f.phase=="Writing"&&f.external==external);
                if(index<0)throw new IOException("Output write was not recorded before submission.");
                receipt.files[index]=Evidence(output,external);Save();
            }
            public void Complete(string result)
            {
                if(receipt.files.Length==0||receipt.files.Any(f=>f.phase!="Recorded"||!Matches(f)))throw new IOException("One or more copy outputs are incomplete or changed.");
                receipt.result=result;receipt.phase="Completed; no assignment";Save();complete=true;
            }
            public void Dispose()
            {
                if(disposed)return;disposed=true;active=null;
                if(!complete) {receipt.phase="Interrupted; inspect retained outputs";try{Save();}catch(IOException){Debug.LogWarning("VRC Eye copy receipt could not be finalized; inspect retained receipt and pending files.");}catch(UnauthorizedAccessException){Debug.LogWarning("VRC Eye copy receipt access changed; existing evidence was retained.");}}
            }
        }
        public static Scope Begin(string operation,string evidence,string review){return new Scope(operation,evidence,review);}
        public static void Before(string path,bool external=false){if(active!=null)active.Before(path,external);}
        public static void After(string path,bool external=false){if(active!=null)active.After(path,external);}
        public static EyeCopyReceipt[] Read()
        {
            NoLinks(Root);if(!Directory.Exists(Root))return Array.Empty<EyeCopyReceipt>();
            var files=Directory.EnumerateFiles(Root,"*.json").Take(2001).ToArray();
            if(files.Length>2000)throw new IOException("Copy history exceeds 2,000 receipts; retain/archive the history folder before further inspection.");
            var result=new List<EyeCopyReceipt>();long total=0;
            foreach(string path in files) {
                NoLinks(path);long length=new FileInfo(path).Length;total+=length;if(length>2*1024*1024||total>32*1024*1024)throw new IOException("Copy receipts exceed their read budget.");
                var row=JsonUtility.FromJson<EyeCopyReceipt>(File.ReadAllText(path));
                if(row==null||row.schema!=1||row.id!=Path.GetFileNameWithoutExtension(path)||row.files==null||row.files.Length>1024)throw new IOException("Unsupported copy receipt.");result.Add(row);
            }
            return result.OrderByDescending(r=>r.createdUtc,StringComparer.Ordinal).ToArray();
        }
        public static string Report(EyeCopyReceipt row)
        {
            string phase=row.phase.StartsWith("Completed",StringComparison.Ordinal)?row.phase:row.phase+" — outcome requires inspection; never resumed automatically";
            return row.operation+"\n"+phase+"\nUnity: "+row.unity+"\nSource evidence: "+row.sourceEvidence+"\n"+row.review+"\n\n"+
                string.Join("\n",row.files.Select(f=>f.phase+" | "+f.path+" | SHA-256 "+f.sha256+(f.phase=="Recorded"?" | "+(Matches(f)?"still matches":"changed/unavailable; preserve for review"):"")))+
                "\n\nNo original assignment was changed. Outputs are retained. Use the parent VRC Eye recovery workspace's reviewed content checkpoints for file rollback; Unity Undo alone does not provide asset-file recovery. Receipts survive editor/domain reload, but Library cleanup removes this local history. Preserve the project recovery checkpoint before cleanup.";
        }
    }
    public sealed class EyeCopyHistoryWindow:EditorWindow
    {
        EyeCopyReceipt[] rows=Array.Empty<EyeCopyReceipt>();int selected;Vector2 scroll;string report="Refresh local copy receipts explicitly. No output is opened, replayed or deleted.";
        [MenuItem("VRC Eye/Repair Copy History")]
        public static void Open(){GetWindow<EyeCopyHistoryWindow>("Copy History");}
        void OnGUI()
        {
            if(GUILayout.Button("Refresh copy receipts"))try{rows=EyeCopyHistory.Read();selected=0;report=rows.Length>0?EyeCopyHistory.Report(rows[0]):"No copy receipts.";}catch(Exception error){report="Stopped: "+error.Message;}
            if(rows.Length>0){int next=EditorGUILayout.Popup("Receipt",selected,rows.Select(r=>r.createdUtc+" · "+r.operation).ToArray());if(next!=selected){selected=next;try{report=EyeCopyHistory.Report(rows[selected]);}catch(Exception error){report="Stopped: "+error.Message;}}}
            scroll=EditorGUILayout.BeginScrollView(scroll);EditorGUILayout.TextArea(report,GUILayout.MinHeight(300));EditorGUILayout.EndScrollView();
        }
    }
}
