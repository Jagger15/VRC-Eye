using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyePlan
    {
        public Component avatar; public Transform anchor; public string[] modules;
        public Vector3 position, rotation; public float visualSize = 1, touchRadius = .012f;
        public string fingerprint; public int existingBits, additionalBits, existingParameters;
        public readonly List<string> messages = new List<string>();
        public EyeParameter[] Parameters { get { return modules.SelectMany(x=>EyeModules.Get(x).parameters).ToArray(); } }
    }
    public static class EyeInstallation
    {
        public const string GeneratedFolder = "Assets/VRC Eye Generated";
        const string ParamsType = "VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionParameters";
        const string MenuType = "VRC.SDK3.Avatars.ScriptableObjects.VRCExpressionsMenu";
        public static string Fingerprint(Component avatar)
        {
            var so = new SerializedObject(avatar);
            var data = StableSerialized(avatar,avatar.transform);
            var p = EyeSdk.Field(so,"expressionParameters").objectReferenceValue;
            var m = EyeSdk.Field(so,"expressionsMenu").objectReferenceValue;
            var f = EyeSdk.Child(EyeSdk.Fx(so),"animatorController").objectReferenceValue;
            foreach (var o in new[]{p,m,f}) if(o) data += AssetDatabase.GetAssetDependencyHash(AssetDatabase.GetAssetPath(o)).ToString();
            using(var hash=SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(data))).Replace("-","");
        }
        public static EyeInstallJournal Find(Component avatar)
        {
            if (!avatar || !AssetDatabase.IsValidFolder(GeneratedFolder)) return null;
            string id = EyeSdk.StableObject(avatar);
            foreach(string guid in AssetDatabase.FindAssets("t:EyeInstallJournal",new[]{GeneratedFolder})) {
                var j=AssetDatabase.LoadAssetAtPath<EyeInstallJournal>(AssetDatabase.GUIDToAssetPath(guid));
                if(j && j.descriptorId==id && j.phase=="installed") {
                    var so=new SerializedObject(avatar);
                    j.ResolveRoot(avatar);
                    bool referenced=EyeSdk.Field(so,"expressionParameters").objectReferenceValue==j.installedParameters || EyeSdk.Field(so,"expressionsMenu").objectReferenceValue==j.installedMenu || EyeSdk.Child(EyeSdk.Fx(so),"animatorController").objectReferenceValue==j.installedFx;
                    if(j.generatedRoot || referenced) return j; // A complete Unity Undo leaves only retained asset history.
                }
            }
            return null;
        }
        public static EyePlan Analyze(Component avatar, Transform anchor, string[] modules, Vector3 pos, Vector3 rot, float size, float radius)
        {
            if (!avatar || !EyeSdk.DescriptorType.IsInstanceOfType(avatar)) throw new InvalidOperationException("Select an avatar descriptor in a saved local scene.");
            if (EditorUtility.IsPersistent(avatar) || !avatar.gameObject.scene.IsValid() || string.IsNullOrEmpty(avatar.gameObject.scene.path))
                throw new InvalidOperationException("Use a selected scene instance and save its scene first; source prefab assets are never edited in place.");
            if (avatar.gameObject.scene.isDirty)
                throw new InvalidOperationException("Save the scene before analysis so the selected avatar and anchor have persistent identities.");
            if (!anchor || !(anchor == avatar.transform || anchor.IsChildOf(avatar.transform))) throw new InvalidOperationException("Choose an anchor inside the selected avatar.");
            if (!EyeSdk.Version().StartsWith("3.10.",StringComparison.Ordinal)) throw new InvalidOperationException("Authoring requires SDK 3.10.x. Existing assets can be inspected. This tool never upgrades the SDK.");
            if (Find(avatar)) throw new InvalidOperationException("Already installed. Inspect the journal or remove the unchanged installation before creating a reviewed replacement.");
            if (modules==null || modules.Length==0 || modules.Distinct().Count()!=modules.Length || modules.Length>EyeModules.All.Length)
                throw new InvalidOperationException("Select at least one distinct module.");
            if (float.IsNaN(size) || float.IsNaN(radius) || size<.25f || size>4 || radius<.004f || radius>.04f || !Finite(pos) || !Finite(rot)) throw new InvalidOperationException("Invalid module placement or touch volume.");
            modules=modules.Contains("connection")?modules:new[]{"connection"}.Concat(modules).ToArray();
            for(var t=anchor;t!=null&&t!=avatar.transform;t=t.parent) if(t.name.Contains("/") || t.parent.Cast<Transform>().Count(x=>x.name==t.name)>1) throw new InvalidOperationException("Attachment path must have unique object names without slash separators. Rename only the chosen source path explicitly before installation.");
            var plan=new EyePlan {avatar=avatar,anchor=anchor,modules=modules,position=pos,rotation=rot,visualSize=size,touchRadius=radius};
            var so=new SerializedObject(avatar);
            EyeSdk.Field(so,"customExpressions"); EyeSdk.Field(so,"customizeAnimationLayers");
            var fx=EyeSdk.Fx(so); EyeSdk.Child(fx,"isDefault");
            var oldFx=EyeSdk.Child(fx,"animatorController").objectReferenceValue;
            if(oldFx && !(oldFx is AnimatorController)) throw new InvalidOperationException("This explicit backend requires an AnimatorController FX asset, not an override controller.");
            if(oldFx && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(oldFx))) throw new InvalidOperationException("Save the existing FX controller as an asset before cloning.");
            var names=new HashSet<string>(StringComparer.Ordinal);
            var parameters=EyeSdk.Field(so,"expressionParameters").objectReferenceValue;
            if(parameters) {
                var entries=EyeSdk.Field(new SerializedObject(parameters),"parameters"); plan.existingParameters=entries.arraySize;
                for(int i=0;i<entries.arraySize;i++) { var p=entries.GetArrayElementAtIndex(i); string n=EyeSdk.Child(p,"name").stringValue;
                    if(string.IsNullOrEmpty(n)) continue;
                    if(!names.Add(n)) throw new InvalidOperationException("Duplicate existing expression parameter: "+n);
                    if(EyeSdk.Child(p,"networkSynced").boolValue) plan.existingBits += EyeSdk.Child(p,"valueType").enumNames[EyeSdk.Child(p,"valueType").enumValueIndex]=="Bool"?1:8;
                }
            }
            foreach(var p in plan.Parameters) {
                if(!names.Add(p.name)) throw new InvalidOperationException("Parameter collision: "+p.name+". No existing definition will be reused or overwritten; resolve the source conflict explicitly.");
                if(oldFx && ((AnimatorController)oldFx).parameters.Any(x=>x.name==p.name)) throw new InvalidOperationException("Existing FX parameter conflicts: "+p.name);
            }
            if(plan.existingBits>256 || plan.existingParameters+plan.Parameters.Length>8192) throw new InvalidOperationException("Expression parameter budget exceeded.");
            ProbeAssetSchemas();
            if(modules.Contains("camera") || modules.Contains("safety")) ProbeContactSchema();
            plan.fingerprint=Fingerprint(avatar);
            plan.messages.Add("Clone expression parameters, root menu and assigned FX; original assets remain unchanged.");
            plan.messages.Add("Add "+plan.Parameters.Length+" private, unsaved, unsynchronized parameters; "+plan.existingBits+" existing synced bits + 0 new bits / 256.");
            plan.messages.Add("Generate "+modules.Length+" finite primitive modules on the selected anchor; no avatar runtime script or upload operation.");
            plan.messages.Add("Full menus receive a wrapper with the original menu as a submenu; each generated menu contains at most eight entries.");
            plan.messages.Add("IsLocal gates generated displays. Local rendering still requires in-client/camera validation and is not protection from your own captures.");
            plan.messages.Add("Source inspection only. SDK 3.10.x is the declared compatibility target; native Unity / build / runtime tests have not been run for this release.");
            return plan;
        }
        static bool Finite(Vector3 v) { return !float.IsNaN(v.x)&&!float.IsInfinity(v.x)&&!float.IsNaN(v.y)&&!float.IsInfinity(v.y)&&!float.IsNaN(v.z)&&!float.IsInfinity(v.z); }
        static void ProbeAssetSchemas()
        {
            ScriptableObject p=null,m=null;
            try {
                p=EyeSdk.Asset(ParamsType); var s=new SerializedObject(p); var a=EyeSdk.Field(s,"parameters"); a.arraySize=1; var e=a.GetArrayElementAtIndex(0);
                foreach(var name in new[]{"name","valueType","defaultValue","saved","networkSynced"}) EyeSdk.Child(e,name);
                m=EyeSdk.Asset(MenuType); s=new SerializedObject(m); a=EyeSdk.Field(s,"controls"); a.arraySize=1; e=a.GetArrayElementAtIndex(0);
                foreach(var name in new[]{"name","type","parameter","value","subMenu"}) EyeSdk.Child(e,name);
            } finally {if(p) Object.DestroyImmediate(p);if(m) Object.DestroyImmediate(m);}
        }
        static Type ContactType { get { return EyeSdk.Type("VRC.SDK3.Dynamics.Contact.Components.VRCContactReceiver"); } }
        static void ProbeContactSchema()
        {
            if(ContactType==null) throw new InvalidOperationException("SDK Contact receiver unavailable.");
            var go=new GameObject("Eye schema probe") {hideFlags=HideFlags.HideAndDontSave};
            try { var c=go.AddComponent(ContactType); var s=new SerializedObject(c);
                foreach(var n in new[]{"allowSelf","allowOthers","localOnly","parameter","receiverType","shapeType","radius","collisionTags"}) EyeSdk.Field(s,n);
                EyeSdk.Enum(EyeSdk.Field(s,"receiverType"),"Constant"); EyeSdk.Enum(EyeSdk.Field(s,"shapeType"),"Sphere");
            } finally {Object.DestroyImmediate(go);}
        }
        public static EyeInstallJournal Install(EyePlan plan)
        {
            // Re-run analysis and compare the reviewed source immediately before mutation.
            Analyze(plan.avatar,plan.anchor,plan.modules,plan.position,plan.rotation,plan.visualSize,plan.touchRadius);
            if(Fingerprint(plan.avatar)!=plan.fingerprint) throw new InvalidOperationException("Avatar/assets changed since review. Generate a new plan.");
            if(!AssetDatabase.IsValidFolder(GeneratedFolder)) AssetDatabase.CreateFolder("Assets","VRC Eye Generated");
            string id=Guid.NewGuid().ToString("N"), folder=GeneratedFolder+"/"+id;
            AssetDatabase.CreateFolder(GeneratedFolder,id);
            var journal=ScriptableObject.CreateInstance<EyeInstallJournal>();
            journal.installationId=id; journal.descriptorId=EyeSdk.StableObject(plan.avatar); journal.localAvatarId="local:"+Guid.NewGuid().ToString();
            journal.modules=plan.modules; journal.createdUtc=DateTime.UtcNow.ToString("O"); journal.phase="preparing"; journal.anchorId=EyeSdk.StableObject(plan.anchor);
            var descriptor=new SerializedObject(plan.avatar); var fx=EyeSdk.Fx(descriptor);
            journal.originalParameters=EyeSdk.Field(descriptor,"expressionParameters").objectReferenceValue;
            journal.originalMenu=EyeSdk.Field(descriptor,"expressionsMenu").objectReferenceValue;
            journal.originalFx=EyeSdk.Child(fx,"animatorController").objectReferenceValue;
            journal.originalCustomExpressions=EyeSdk.Field(descriptor,"customExpressions").boolValue;
            journal.originalCustomizeLayers=EyeSdk.Field(descriptor,"customizeAnimationLayers").boolValue;
            journal.originalFxDefault=EyeSdk.Child(fx,"isDefault").boolValue;
            AssetDatabase.CreateAsset(journal,folder+"/Installation.asset"); AssetDatabase.SaveAssets();
            var owned=new List<string>(); int undo=Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("Install VRC Eye modules");
            try {
                // Store a readable pre-mutation journal separately; existing source assets never change.
                File.WriteAllText(folder+"/before-descriptor.json",EditorJsonUtility.ToJson(plan.avatar,true),new UTF8Encoding(false));
                journal.installedParameters=CloneOrNew(journal.originalParameters,ParamsType,folder+"/Parameters.asset",owned);
                if(!journal.originalParameters) { var blank=new SerializedObject(journal.installedParameters); EyeSdk.Field(blank,"parameters").arraySize=0; blank.ApplyModifiedPropertiesWithoutUndo(); }
                AppendParameters(journal.installedParameters,plan.Parameters);
                journal.installedMenu=CreateMenu(journal.originalMenu,plan.Parameters,folder,owned);
                AnimatorController controller;
                if(journal.originalFx) {
                    string dest=folder+"/FX.controller";
                    if(!AssetDatabase.CopyAsset(AssetDatabase.GetAssetPath(journal.originalFx),dest)) throw new IOException("FX clone failed.");
                    controller=AssetDatabase.LoadAssetAtPath<AnimatorController>(dest); owned.Add(dest);
                } else { controller=AnimatorController.CreateAnimatorControllerAtPath(folder+"/FX.controller"); owned.Add(folder+"/FX.controller"); }
                journal.installedFx=controller;
                foreach(var p in plan.Parameters) controller.AddParameter(p.name,p.type=="Bool"?AnimatorControllerParameterType.Bool:p.type=="Int"?AnimatorControllerParameterType.Int:AnimatorControllerParameterType.Float);
                EnsureBuiltin(controller,"IsLocal",AnimatorControllerParameterType.Bool);
                if(plan.modules.Contains("availability")) EnsureBuiltin(controller,"AFK",AnimatorControllerParameterType.Bool);
                var root=new GameObject("VRC Eye "+id.Substring(0,8)); Undo.RegisterCreatedObjectUndo(root,"Create VRC Eye modules");
                root.transform.SetParent(plan.anchor,false); root.transform.localPosition=plan.position; root.transform.localEulerAngles=plan.rotation;
                journal.generatedRoot=root; journal.generatedRootPath=AnimationUtility.CalculateTransformPath(root.transform,plan.avatar.transform);
                EyeVisuals.Build(plan,root,controller,folder,owned);
                Undo.RecordObject(plan.avatar,"Assign VRC Eye cloned assets");
                EyeSdk.Field(descriptor,"expressionParameters").objectReferenceValue=journal.installedParameters;
                EyeSdk.Field(descriptor,"expressionsMenu").objectReferenceValue=journal.installedMenu;
                EyeSdk.Field(descriptor,"customExpressions").boolValue=true; EyeSdk.Field(descriptor,"customizeAnimationLayers").boolValue=true;
                EyeSdk.Child(fx,"animatorController").objectReferenceValue=controller; EyeSdk.Child(fx,"isDefault").boolValue=false;
                descriptor.ApplyModifiedProperties(); PrefabUtility.RecordPrefabInstancePropertyModifications(plan.avatar);
                EditorUtility.SetDirty(controller); AssetDatabase.SaveAssets();
                journal.ownedAssets=owned.ToArray(); journal.ownedHashes=owned.Select(x=>AssetDatabase.GetAssetDependencyHash(x).ToString()).ToArray();
                journal.rootFingerprint=RootFingerprint(root); journal.installedDescriptorFingerprint=Fingerprint(plan.avatar);
                journal.phase="installed"; EditorUtility.SetDirty(journal); AssetDatabase.SaveAssets();
                EditorSceneManager.MarkSceneDirty(plan.avatar.gameObject.scene); Undo.CollapseUndoOperations(undo);
                return journal;
            } catch {
                RestoreReferences(plan.avatar,journal); if(journal.generatedRoot) Object.DestroyImmediate(journal.generatedRoot);
                journal.phase="failed-restored"; EditorUtility.SetDirty(journal); AssetDatabase.SaveAssets();
                // Retain failed generated assets and the backup journal for recovery; never delete uncertain references.
                throw;
            }
        }
        static void EnsureBuiltin(AnimatorController c,string name,AnimatorControllerParameterType type)
        {
            var p=c.parameters.FirstOrDefault(x=>x.name==name);
            if(p!=null && p.type!=type) throw new InvalidOperationException("Built-in parameter type conflict: "+name);
            if(p==null) c.AddParameter(name,type);
        }
        static Object CloneOrNew(Object original,string type,string path,List<string> owned)
        {
            var obj=original?Object.Instantiate(original):EyeSdk.Asset(type); obj.name=Path.GetFileNameWithoutExtension(path);
            AssetDatabase.CreateAsset(obj,path); owned.Add(path); return obj;
        }
        static void AppendParameters(Object obj,EyeParameter[] parameters)
        {
            var s=new SerializedObject(obj); var a=EyeSdk.Field(s,"parameters");
            int count=a.arraySize; a.arraySize=count+parameters.Length;
            for(int i=0;i<parameters.Length;i++) { var p=parameters[i]; var e=a.GetArrayElementAtIndex(count+i);
                EyeSdk.Child(e,"name").stringValue=p.name; EyeSdk.Enum(EyeSdk.Child(e,"valueType"),p.type);
                EyeSdk.Child(e,"defaultValue").floatValue=0; EyeSdk.Child(e,"saved").boolValue=false; EyeSdk.Child(e,"networkSynced").boolValue=false;
            } s.ApplyModifiedPropertiesWithoutUndo(); EditorUtility.SetDirty(obj);
        }
        static Object NewMenu(string path,List<string> owned) { var o=CloneOrNew(null,MenuType,path,owned); var s=new SerializedObject(o); EyeSdk.Field(s,"controls").arraySize=0; s.ApplyModifiedPropertiesWithoutUndo(); return o; }
        static void Control(Object menu,string label,string type,string parameter,Object submenu=null)
        {
            var s=new SerializedObject(menu); var a=EyeSdk.Field(s,"controls"); if(a.arraySize>=8) throw new InvalidOperationException("Menu capacity exceeded.");
            int i=a.arraySize; a.arraySize=i+1; var e=a.GetArrayElementAtIndex(i);
            // Array growth duplicates the last serialized entry: clear all fields before assigning the new control.
            EyeSdk.Child(e,"name").stringValue=label; EyeSdk.Enum(EyeSdk.Child(e,"type"),type);
            EyeSdk.Child(EyeSdk.Child(e,"parameter"),"name").stringValue=parameter;
            EyeSdk.Child(e,"value").floatValue=1; EyeSdk.Child(e,"subMenu").objectReferenceValue=submenu;
            var icon=e.FindPropertyRelative("icon"); if(icon!=null) icon.objectReferenceValue=null;
            foreach(var field in new[]{"subParameters","labels"}) { var p=e.FindPropertyRelative(field); if(p!=null&&p.isArray) p.arraySize=0; }
            s.ApplyModifiedPropertiesWithoutUndo(); EditorUtility.SetDirty(menu);
        }
        static Object CreateMenu(Object original,EyeParameter[] parameters,string folder,List<string> owned)
        {
            var page=NewMenu(folder+"/EyeMenu.asset",owned); var root=original?CloneOrNew(original,MenuType,folder+"/Menu.asset",owned):NewMenu(folder+"/Menu.asset",owned);
            var controls=parameters.Where(x=>x.direction=="out"||x.name=="EYE_In_Quiet").ToArray();
            if(controls.Length==0)return root;
            var rootCount=EyeSdk.Field(new SerializedObject(root),"controls").arraySize;
            if(rootCount>=8) { root=NewMenu(folder+"/MenuWrapper.asset",owned); Control(root,"Original menu","SubMenu","",original); }
            Control(root,"VRC Eye","SubMenu","",page);
            int n=0; foreach(var p in controls) {
                if(EyeSdk.Field(new SerializedObject(page),"controls").arraySize>=7) {var next=NewMenu(folder+"/EyeMenu"+(++n)+".asset",owned);Control(page,"More","SubMenu","",next);page=next;}
                Control(page,EyeModules.Get(p.module).label,p.direction=="out"?"Button":"Toggle",p.name);
            }
            return root;
        }
        public static void ConfigureContact(GameObject go,string parameter,float radius)
        {
            var receiver=go.AddComponent(ContactType); var s=new SerializedObject(receiver);
            EyeSdk.Field(s,"allowSelf").boolValue=true; EyeSdk.Field(s,"allowOthers").boolValue=false; EyeSdk.Field(s,"localOnly").boolValue=true;
            EyeSdk.Field(s,"parameter").stringValue=parameter; EyeSdk.Enum(EyeSdk.Field(s,"receiverType"),"Constant"); EyeSdk.Enum(EyeSdk.Field(s,"shapeType"),"Sphere");
            EyeSdk.Field(s,"radius").floatValue=radius; var tags=EyeSdk.Field(s,"collisionTags"); tags.arraySize=1; tags.GetArrayElementAtIndex(0).stringValue="Finger";
            s.ApplyModifiedPropertiesWithoutUndo();
        }
        static string StableSerialized(Object obj,Transform scope)
        {
            var so=new SerializedObject(obj);var p=so.GetIterator();var text=new StringBuilder();
            while(p.Next(true)) {
                text.Append(p.propertyPath).Append(':').Append(p.propertyType).Append('=');
                switch(p.propertyType) {
                    case SerializedPropertyType.ObjectReference:
                        var target=p.objectReferenceValue;
                        if(!target)text.Append("null");
                        else {var component=target as Component;var go=target as GameObject;var t=component?component.transform:go?go.transform:null;
                            if(t&&(t==scope||t.IsChildOf(scope)))text.Append(AnimationUtility.CalculateTransformPath(t,scope)).Append(':').Append(target.GetType().FullName);
                            else if(EditorUtility.IsPersistent(target)&&AssetDatabase.TryGetGUIDAndLocalFileIdentifier(target,out string guid,out long localId)&&!string.IsNullOrEmpty(guid))text.Append(guid).Append(':').Append(localId);
                            else text.Append(EyeSdk.StableObject(target));}
                        break;
                    case SerializedPropertyType.String: text.Append(p.stringValue);break;
                    case SerializedPropertyType.Integer: text.Append(p.longValue);break;
                    case SerializedPropertyType.Float: text.Append(p.doubleValue.ToString("R",System.Globalization.CultureInfo.InvariantCulture));break;
                    case SerializedPropertyType.Boolean: text.Append(p.boolValue);break;
                    case SerializedPropertyType.Enum: text.Append(p.enumValueIndex);break;
                    case SerializedPropertyType.ArraySize: text.Append(p.intValue);break;
                }
                text.Append('\n');
            }
            return text.ToString();
        }
        public static string RootFingerprint(GameObject root)
        {
            if(!root) return "missing";
            var b=new StringBuilder(); foreach(var t in root.GetComponentsInChildren<Transform>(true)) { b.Append(AnimationUtility.CalculateTransformPath(t,root.transform));b.Append(StableSerialized(t.gameObject,root.transform));
                foreach(var c in t.GetComponents<Component>()) b.Append(c?StableSerialized(c,root.transform):"missing-component"); }
            using(var hash=SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(b.ToString()))).Replace("-","");
        }
        public static void Remove(Component avatar,EyeInstallJournal j)
        {
            if(!j || j.phase!="installed" || j.descriptorId!=EyeSdk.StableObject(avatar)) throw new InvalidOperationException("This journal does not own the selected installation.");
            j.ResolveRoot(avatar);
            if(Fingerprint(avatar)!=j.installedDescriptorFingerprint || RootFingerprint(j.generatedRoot)!=j.rootFingerprint)
                throw new InvalidOperationException("Descriptor or generated objects changed after installation. Automatic removal stopped; use the journal to restore only reviewed references manually.");
            for(int i=0;i<j.ownedAssets.Length;i++) if(AssetDatabase.GetAssetDependencyHash(j.ownedAssets[i]).ToString()!=j.ownedHashes[i])
                throw new InvalidOperationException("A generated asset or dependency was edited. Automatic removal stopped: "+j.ownedAssets[i]);
            Undo.RecordObject(avatar,"Remove unchanged VRC Eye installation"); RestoreReferences(avatar,j);
            if(j.generatedRoot) Undo.DestroyObjectImmediate(j.generatedRoot);
            j.phase="removed-assets-retained"; EditorUtility.SetDirty(j); AssetDatabase.SaveAssets(); EditorSceneManager.MarkSceneDirty(avatar.gameObject.scene);
            // Assets are retained, even when unchanged, because other avatars may now reference them.
        }
        static void RestoreReferences(Component avatar,EyeInstallJournal j)
        {
            var s=new SerializedObject(avatar); var fx=EyeSdk.Fx(s);
            EyeSdk.Field(s,"expressionParameters").objectReferenceValue=j.originalParameters; EyeSdk.Field(s,"expressionsMenu").objectReferenceValue=j.originalMenu;
            EyeSdk.Field(s,"customExpressions").boolValue=j.originalCustomExpressions; EyeSdk.Field(s,"customizeAnimationLayers").boolValue=j.originalCustomizeLayers;
            EyeSdk.Child(fx,"animatorController").objectReferenceValue=j.originalFx; EyeSdk.Child(fx,"isDefault").boolValue=j.originalFxDefault;
            s.ApplyModifiedProperties(); PrefabUtility.RecordPrefabInstancePropertyModifications(avatar);
        }
    }
}
