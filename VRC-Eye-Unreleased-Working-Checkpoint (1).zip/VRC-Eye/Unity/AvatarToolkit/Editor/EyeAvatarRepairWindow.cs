// Optional source-project utilities. Native Unity compile/EditMode validation is required.
// Does not load bundles, recover proprietary source, upload avatars, or edit original assets.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public enum EyeRepairKind { MaterialShader, MissingNormals, AnimationPaths, PrefabMissingScripts, MeshObj, MissingTangents }

    // Constructed only by Prepare. All review inputs are immutable and bound to fresh source evidence.
    public sealed class EyeRepairPlan
    {
        public readonly GameObject root;
        public readonly Object source;
        public readonly Shader shader;
        public readonly EyeRepairKind kind;
        public readonly string oldPrefix, newPrefix, fingerprint, summary;
        public readonly double expires;
        internal bool consumed;
        internal EyeRepairPlan(GameObject root, Object source, Shader shader, EyeRepairKind kind,
            string oldPrefix, string newPrefix, string fingerprint, string summary)
        {
            this.root=root; this.source=source; this.shader=shader; this.kind=kind;
            this.oldPrefix=oldPrefix; this.newPrefix=newPrefix; this.fingerprint=fingerprint;
            this.summary=summary; expires=EditorApplication.timeSinceStartup+300;
        }
    }

    public sealed class EyeAvatarRepairWindow : EditorWindow
    {
        GameObject root; Material material; Mesh mesh; AnimationClip clip; Shader shader;
        EyeRepairKind kind; string oldPrefix="OldPath",newPrefix="NewPath";
        bool authorized; EyeRepairPlan plan; Vector2 scroll;
        string report="Select an avatar root and source asset you are authorized to modify. Scan is read-only.";
        [MenuItem("VRC Eye/Avatar Repair Copies")]
        static void Open() { GetWindow<EyeAvatarRepairWindow>("Avatar Repair Copies"); }
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("Experimental Unity source tools. Repairs create separate assets for manual inspection and assignment. Test copies in Unity and the SDK before use. This does not reconstruct source from VRChat bundles.",MessageType.Warning);
            EditorGUI.BeginChangeCheck();
            var nextRoot=(GameObject)EditorGUILayout.ObjectField("Authorized avatar root",root,typeof(GameObject),true);
            if(nextRoot!=root) { root=nextRoot; authorized=false; material=null; mesh=null; clip=null; }
            authorized=EditorGUILayout.ToggleLeft("I own or have permission to modify and export the selected source assets",authorized);
            kind=(EyeRepairKind)EditorGUILayout.EnumPopup("Copy operation",kind);
            if(kind==EyeRepairKind.MaterialShader) {
                material=(Material)EditorGUILayout.ObjectField("Referenced material",material,typeof(Material),false);
                shader=(Shader)EditorGUILayout.ObjectField("Explicit replacement shader",shader,typeof(Shader),false);
            }
            if(kind==EyeRepairKind.MissingNormals||kind==EyeRepairKind.MissingTangents||kind==EyeRepairKind.MeshObj)
                mesh=(Mesh)EditorGUILayout.ObjectField("Referenced mesh",mesh,typeof(Mesh),false);
            if(kind==EyeRepairKind.AnimationPaths) {
                clip=(AnimationClip)EditorGUILayout.ObjectField("Authorized source clip",clip,typeof(AnimationClip),false);
                oldPrefix=EditorGUILayout.TextField("Old binding path prefix",oldPrefix);
                newPrefix=EditorGUILayout.TextField("New prefix (empty = root)",newPrefix);
                EditorGUILayout.HelpBox("The explicitly selected clip can be outside the currently assigned controller. Every remapped target must exist beneath the selected avatar. Controllers and original clips remain unchanged.",MessageType.Info);
            }
            if(kind==EyeRepairKind.PrefabMissingScripts)
                EditorGUILayout.HelpBox("Select the saved .prefab asset root in the Project view. The new copy is unpacked before missing components are removed; nested source prefabs remain unchanged. Unity's existing project editor callbacks may run while importing/loading the copy.",MessageType.Info);
            if(kind==EyeRepairKind.MeshObj)
                EditorGUILayout.HelpBox("Exports one mesh's source-local geometry, including UV0/normals when present. Skinned meshes remain in source/bind pose. No rig, textures, material/shader, animation or blendshape export. Preview limit: 20,000 vertices, 8,000 triangles, 16 MiB; oversized meshes stop without truncation.",MessageType.Info);
            if(EditorGUI.EndChangeCheck())plan=null;
            using(new EditorGUI.DisabledScope(!root)) if(GUILayout.Button("Scan selected root (read-only)"))Run(()=>report=EyeAvatarRepair.Scan(root));
            using(new EditorGUI.DisabledScope(!root||!authorized)) {
                if(GUILayout.Button("Prepare copy and review changes"))Run(()=>{
                    Object source=kind==EyeRepairKind.MaterialShader?(Object)material:
                        kind==EyeRepairKind.AnimationPaths?(Object)clip:kind==EyeRepairKind.PrefabMissingScripts?(Object)root:mesh;
                    plan=EyeAvatarRepair.Prepare(root,source,kind,shader,oldPrefix,newPrefix);
                    report=plan.summary;
                });
                using(new EditorGUI.DisabledScope(plan==null)) if(GUILayout.Button("Review and create separate copy"))Run(()=>{
                    var reviewed=plan;
                    if(!EditorUtility.DisplayDialog("Create reviewed source copy?",reviewed.summary,"Create copy","Cancel"))return;
                    string destination="";
                    if(reviewed.kind==EyeRepairKind.MeshObj) {
                        destination=EditorUtility.SaveFilePanel("New OBJ preview file","","avatar-mesh-preview.obj","obj");
                        if(string.IsNullOrEmpty(destination))return;
                        if(!EditorUtility.DisplayDialog("Confirm geometry export destination",reviewed.summary+"\n\nNew file: "+destination,"Export new file","Cancel"))return;
                    }
                    if(!authorized||root!=reviewed.root||plan!=reviewed)throw new InvalidOperationException("Selection or permission changed; prepare again.");
                    plan=null;
                    string saved=EyeAvatarRepair.Execute(reviewed,destination);
                    report="Created: "+saved+"\nOriginal assets and avatar assignments are unchanged. Inspect the new output before manually assigning it. No upload was performed.";
                });
            }
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(220));
            EditorGUILayout.EndScrollView();
        }
        void Run(Action action) { try { action(); } catch(Exception error) { plan=null; report="Stopped: "+error.Message; } Repaint(); }
    }

    public static class EyeAvatarRepair
    {
        public const int MaxNodes=2000, MaxVertices=200000, MaxTriangles=400000;
        public const int ObjVertices=20000, ObjTriangles=8000, ObjBytes=16*1024*1024;
        const int MaxBindings=4000,MaxKeys=200000,MaxEvidence=32*1024*1024;
        public const string OutputRoot="Assets/VRC Eye Repairs";
        static Transform[] Nodes(GameObject root)
        {
            if(!root)throw new InvalidOperationException("Select an existing source avatar root.");
            if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Stop Play Mode before source operations.");
            // Traverse incrementally: do not allocate an unbounded component hierarchy first.
            var nodes=new List<Transform>();var pending=new Stack<Transform>();pending.Push(root.transform);
            while(pending.Count>0) {
                var node=pending.Pop();nodes.Add(node);
                if(nodes.Count>MaxNodes)throw new InvalidOperationException("Selected hierarchy exceeds 2,000 objects.");
                if(node.childCount+pending.Count+nodes.Count>MaxNodes)throw new InvalidOperationException("Selected hierarchy exceeds 2,000 objects.");
                for(int i=node.childCount-1;i>=0;i--)pending.Push(node.GetChild(i));
            }
            return nodes.ToArray();
        }
        public static string Scan(GameObject root)
        {
            var nodes=Nodes(root);var meshes=new HashSet<Mesh>();var materials=new HashSet<Material>();
            int missing=0;var issues=new List<string>();
            foreach(var node in nodes) {
                missing+=GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(node.gameObject);
                foreach(var renderer in node.GetComponents<Renderer>())foreach(var m in renderer.sharedMaterials)if(m)materials.Add(m);
                var filter=node.GetComponent<MeshFilter>();if(filter&&filter.sharedMesh)meshes.Add(filter.sharedMesh);
                var skin=node.GetComponent<SkinnedMeshRenderer>();if(skin&&skin.sharedMesh)meshes.Add(skin.sharedMesh);
            }
            foreach(var m in meshes) {
                if(!m.isReadable)issues.Add("Mesh is not readable; no importer setting is changed: "+m.name);
                else if(m.vertexCount>MaxVertices)issues.Add("Mesh exceeds repair vertex limit: "+m.name);
                else if(m.normals.Length!=m.vertexCount)issues.Add("Missing/incomplete normals: "+m.name);
            }
            foreach(var m in materials)if(!m.shader||m.shader.name=="Hidden/InternalErrorShader")issues.Add("Missing/error shader: "+m.name);
            return "Read-only source scan\nObjects: "+nodes.Length+"\nDistinct meshes: "+meshes.Count+"\nDistinct materials: "+materials.Count+
                "\nMissing script components: "+missing+"\n\n"+string.Join("\n",issues.Take(100))+
                (issues.Count>100?"\nAdditional findings omitted from this display.":"")+"\n\nNo source was changed. Shader compatibility, runtime rig behavior, complete dependencies and VRChat performance rank are not established by this scan.";
        }
        public static EyeRepairPlan Prepare(GameObject root,Object source,EyeRepairKind kind,Shader shader=null,string oldPrefix="",string newPrefix="")
        {
            Nodes(root);
            if(!source)throw new InvalidOperationException("Select an explicit source asset.");
            string detail=ValidateOperation(root,source,kind,shader,oldPrefix,newPrefix);
            string summary="Selected root: "+root.name+"\nSource: "+source.name+"\nOperation: "+kind+"\n"+detail+
                "\n\nCreates a separate output. Original source assets, controllers and scene assignments remain unchanged. Source and settings are rechecked after confirmation. This review expires after five minutes.";
            return new EyeRepairPlan(root,source,shader,kind,oldPrefix,newPrefix,Fingerprint(root,source,shader),summary);
        }
        public static void Validate(EyeRepairPlan plan)
        {
            if(plan==null||plan.consumed||EditorApplication.timeSinceStartup>plan.expires)throw new InvalidOperationException("Review is expired or already used; prepare again.");
            ValidateOperation(plan.root,plan.source,plan.kind,plan.shader,plan.oldPrefix,plan.newPrefix);
            if(plan.fingerprint!=Fingerprint(plan.root,plan.source,plan.shader))throw new InvalidOperationException("Source or avatar changed after review; prepare again.");
        }
        static string ValidateOperation(GameObject root,Object source,EyeRepairKind kind,Shader shader,string oldPrefix,string newPrefix)
        {
            var nodes=Nodes(root);
            if(!source)throw new InvalidOperationException("Reviewed source no longer exists.");
            switch(kind) {
                case EyeRepairKind.MaterialShader:
                    var material=source as Material;
                    if(!material||!shader)throw new InvalidOperationException("Select a material and an explicit replacement shader.");
                    if(!nodes.Any(n=>n.GetComponents<Renderer>().Any(r=>r.sharedMaterials.Contains(material))))throw new InvalidOperationException("Selected material is not referenced beneath this root.");
                    if(material.shader==shader)throw new InvalidOperationException("Replacement shader matches the existing shader.");
                    return "Material copy: "+(material.shader?material.shader.name:"missing")+" → "+shader.name+". Existing property data is copied, but shader properties, keywords and platform compatibility require manual inspection. No guessed mapping is applied.";
                case EyeRepairKind.MissingNormals:
                case EyeRepairKind.MissingTangents:
                case EyeRepairKind.MeshObj:
                    var mesh=source as Mesh;
                    if(!mesh||!nodes.Any(n=> {var f=n.GetComponent<MeshFilter>();var s=n.GetComponent<SkinnedMeshRenderer>();return(f&&f.sharedMesh==mesh)||(s&&s.sharedMesh==mesh);}))throw new InvalidOperationException("Selected mesh is not referenced beneath this root.");
                    int triangles=CheckMesh(mesh,kind==EyeRepairKind.MeshObj?ObjVertices:MaxVertices,kind==EyeRepairKind.MeshObj?ObjTriangles:MaxTriangles);
                    if(kind==EyeRepairKind.MissingNormals&&mesh.normals.Length==mesh.vertexCount)throw new InvalidOperationException("Mesh already contains one normal per vertex; no missing-normal repair is proposed.");
                    if(kind==EyeRepairKind.MissingTangents) {
                        if(mesh.tangents.Length==mesh.vertexCount)throw new InvalidOperationException("Mesh already contains tangents; existing tangent data is not rewritten.");
                        if(mesh.normals.Length!=mesh.vertexCount||mesh.uv.Length!=mesh.vertexCount)throw new InvalidOperationException("Tangent generation requires complete normals and UV0. Prepare missing normals separately.");
                        foreach(var normal in mesh.normals) {Finite(normal);if(normal.sqrMagnitude<1e-12f)throw new InvalidOperationException("Zero-length normal prevents tangent generation.");}
                        foreach(var uv in mesh.uv)Finite(new Vector3(uv.x,uv.y,0));
                        var uv0=mesh.uv;var indices=mesh.triangles;
                        for(int i=0;i<indices.Length;i+=3) {
                            var a=uv0[indices[i+1]]-uv0[indices[i]];var b=uv0[indices[i+2]]-uv0[indices[i]];
                            if(Mathf.Abs(a.x*b.y-a.y*b.x)<1e-12f)throw new InvalidOperationException("Degenerate UV triangle prevents a reliable tangent basis.");
                        }
                        return "New mesh asset: generate missing tangents from reviewed normals and UV0. Unity may convert position/normal/UV streams to Float32 and creates Float32 tangents. Geometry, skin weights, bind poses, submesh indices and blendshape frames are checked before publication. No source assignment, vertex welding or topology changes. Validate deformed shading separately.";
                    }
                    return kind==EyeRepairKind.MeshObj?"Geometry export: "+mesh.vertexCount+" vertices / "+triangles+" triangles; mesh-local coordinates, source/bind pose, no materials, textures, rig or animation. New .obj file only; existing destinations are refused.":
                        "New mesh asset: recalculate missing normals on the duplicate. Vertex positions may become Float32; normals at split UV seams may remain discontinuous. Tangents are not generated. Existing topology, weights and blendshapes are copied, not repaired.";
                case EyeRepairKind.AnimationPaths:
                    var clip=source as AnimationClip;if(!clip)throw new InvalidOperationException("Select an AnimationClip.");
                    return "New clip: "+CheckBindings(root,clip,oldPrefix,newPrefix)+" binding paths remapped from '"+oldPrefix+"' to '"+newPrefix+"'. Float and object-reference curves are preserved. Existing controllers, clip events and other bindings are retained unchanged; inspect event behavior separately.";
                case EyeRepairKind.PrefabMissingScripts:
                    string path=AssetDatabase.GetAssetPath(root);
                    if(source!=root||!path.StartsWith("Assets/",StringComparison.Ordinal)||!path.EndsWith(".prefab",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadAssetAtPath<GameObject>(path)!=root)
                        throw new InvalidOperationException("Choose the saved .prefab root asset under Assets, not a scene instance or imported model.");
                    int missing=nodes.Sum(n=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(n.gameObject));
                    if(nodes.Any(n=>EditorUtility.IsDirty(n.gameObject)||n.GetComponents<Component>().Any(c=>c&&EditorUtility.IsDirty(c))))throw new InvalidOperationException("Save the source prefab before preparing its disk copy.");
                    if(missing==0)throw new InvalidOperationException("No missing script components were found.");
                    return "New prefab copy: remove "+missing+" missing script components. The copy's variant/nested prefab links are unpacked; original prefabs remain unchanged. Existing project editor callbacks may run during copy import/loading. This cannot restore the missing scripts or their behavior.";
                default: throw new InvalidOperationException("Unknown repair operation.");
            }
        }
        static int CheckMesh(Mesh mesh,int vertexLimit,int triangleLimit)
        {
            if(!mesh.isReadable)throw new InvalidOperationException("Mesh is not readable. Import settings are not modified automatically.");
            if(mesh.vertexCount<3||mesh.vertexCount>vertexLimit)throw new InvalidOperationException("Mesh vertex limit: 3–"+vertexLimit+".");
            if(mesh.subMeshCount<1||mesh.subMeshCount>256)throw new InvalidOperationException("Mesh submesh limit: 1–256.");
            long indices=0;
            for(int sub=0;sub<mesh.subMeshCount;sub++) {
                if(mesh.GetTopology(sub)!=MeshTopology.Triangles)throw new InvalidOperationException("Only triangle mesh topology is supported.");
                var count=mesh.GetIndexCount(sub);if(count%3!=0)throw new InvalidOperationException("Incomplete triangle index data.");
                indices+=count;if(indices>(long)triangleLimit*3)throw new InvalidOperationException("Mesh triangle limit exceeded: "+triangleLimit+".");
            }
            if(indices==0)throw new InvalidOperationException("Mesh contains no triangles.");
            foreach(var vertex in mesh.vertices)Finite(vertex);
            foreach(int index in mesh.triangles)if(index<0||index>=mesh.vertexCount)throw new InvalidOperationException("Mesh index is outside its vertex array.");
            return (int)(indices/3);
        }
        static void Prefix(string value,bool allowEmpty)
        {
            if(value==null||value.Length>512||(!allowEmpty&&value.Length==0)||value.Any(c=>char.IsControl(c)||c=='\\'))throw new InvalidOperationException("Invalid animation path prefix.");
            if(value.Length>0&&value.Split('/').Any(s=>s.Length==0||s=="."||s==".."))throw new InvalidOperationException("Use an exact avatar-relative path without empty, dot or parent segments.");
        }
        public static string RemapPath(string path,string oldPrefix,string newPrefix)
        {
            Prefix(oldPrefix,false);Prefix(newPrefix,true);
            if(path==oldPrefix)return newPrefix;
            if(path.StartsWith(oldPrefix+"/",StringComparison.Ordinal))return (newPrefix.Length==0?"":newPrefix+"/")+path.Substring(oldPrefix.Length+1);
            return path;
        }
        static string BindingKey(EditorCurveBinding binding) {return binding.path+"\n"+binding.type.AssemblyQualifiedName+"\n"+binding.propertyName;}
        static int CheckBindings(GameObject root,AnimationClip clip,string oldPrefix,string newPrefix)
        {
            Prefix(oldPrefix,false);Prefix(newPrefix,true);
            if(oldPrefix==newPrefix)throw new InvalidOperationException("Old and new prefixes are identical.");
            var floats=AnimationUtility.GetCurveBindings(clip);var objects=AnimationUtility.GetObjectReferenceCurveBindings(clip);
            if(floats.Length+objects.Length>MaxBindings)throw new InvalidOperationException("Clip binding limit exceeded (4,000).");
            var keys=new HashSet<string>();int changed=0;long frames=0;
            foreach(var binding in floats.Concat(objects)) {
                var next=binding;next.path=RemapPath(binding.path,oldPrefix,newPrefix);
                if(!keys.Add(BindingKey(next)))throw new InvalidOperationException("Remap collides with another binding: "+next.path+" / "+next.propertyName);
                if(next.path!=binding.path) {
                    changed++;var target=next.path.Length==0?root.transform:root.transform.Find(next.path);
                    if(!target||(next.type!=typeof(GameObject)&&!target.GetComponent(next.type)))throw new InvalidOperationException("Remapped object/component does not exist: "+next.path+" / "+next.type.Name);
                }
            }
            foreach(var binding in floats) {frames+=AnimationUtility.GetEditorCurve(clip,binding).length;if(frames>MaxKeys)throw new InvalidOperationException("Clip keyframe limit exceeded (200,000).");}
            foreach(var binding in objects) {frames+=AnimationUtility.GetObjectReferenceCurve(clip,binding).Length;if(frames>MaxKeys)throw new InvalidOperationException("Clip keyframe limit exceeded (200,000).");}
            if(changed==0)throw new InvalidOperationException("No binding paths match the selected prefix.");
            return changed;
        }
        static string Fingerprint(GameObject root,Object source,Shader shader)
        {
            var text=new StringBuilder();
            Action<Object> add=obj=> {
                if(!obj) {text.Append("null\n");return;}
                text.Append(obj.GetInstanceID()).Append('|').Append(EditorJsonUtility.ToJson(obj)).Append('\n');
                string path=AssetDatabase.GetAssetPath(obj);
                if(path.Length>0)text.Append(path).Append('|').Append(AssetDatabase.GetAssetDependencyHash(path)).Append('\n');
                if(text.Length>MaxEvidence)throw new InvalidOperationException("Source evidence exceeds the bounded review limit.");
            };
            int components=0;
            foreach(var node in Nodes(root)) {
                add(node.gameObject);text.Append(node.parent?node.parent.GetInstanceID():0).Append('|').Append(node.GetSiblingIndex()).Append('\n');
                foreach(var component in node.GetComponents<Component>()) {if(++components>10000)throw new InvalidOperationException("Source component limit exceeded (10,000).");add(component);}
            }
            add(source);if(shader)add(shader);
            // Native asset JSON coverage is not used as the sole evidence for mesh/clip contents.
            if(source is Mesh)text.Append(MeshEvidence((Mesh)source));
            if(source is AnimationClip)text.Append(ClipEvidence((AnimationClip)source));
            using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(text.ToString()))).Replace("-","");
        }
        internal static string MeshEvidence(Mesh mesh,bool includeWeights=true)
        {
            using(var stream=new MemoryStream())using(var write=new BinaryWriter(stream)) {
                Action<Vector3> vector=v=>{write.Write(v.x);write.Write(v.y);write.Write(v.z);};
                Action bound=()=>{if(stream.Length>MaxEvidence)throw new InvalidOperationException("Mesh review evidence limit exceeded.");};
                write.Write(mesh.vertexCount);vector(mesh.bounds.center);vector(mesh.bounds.size);
                foreach(var attribute in mesh.GetVertexAttributes()) {
                    if(!includeWeights&&(attribute.attribute==UnityEngine.Rendering.VertexAttribute.BlendWeight||attribute.attribute==UnityEngine.Rendering.VertexAttribute.BlendIndices))continue;
                    write.Write((int)attribute.attribute);write.Write((int)attribute.format);write.Write(attribute.dimension);write.Write(attribute.stream);
                }
                foreach(var v in mesh.vertices)vector(v);
                write.Write(mesh.normals.Length);foreach(var v in mesh.normals)vector(v);bound();
                write.Write(mesh.tangents.Length);foreach(var v in mesh.tangents){write.Write(v.x);write.Write(v.y);write.Write(v.z);write.Write(v.w);}bound();
                var uv=new List<Vector4>();for(int channel=0;channel<8;channel++) {
                    mesh.GetUVs(channel,uv);write.Write(uv.Count);
                    foreach(var v in uv){write.Write(v.x);write.Write(v.y);write.Write(v.z);write.Write(v.w);}bound();
                }
                write.Write(mesh.colors.Length);foreach(var color in mesh.colors){write.Write(color.r);write.Write(color.g);write.Write(color.b);write.Write(color.a);}bound();
                // Include all variable-count skin weights (not only the legacy four-weight view).
                // These arrays are views into mesh-owned memory. Never dispose or mutate them.
                if(includeWeights) {
                var bones=mesh.GetBonesPerVertex();write.Write(bones.Length);foreach(var b in bones)write.Write(b);
                var weights=mesh.GetAllBoneWeights();
                if((long)weights.Length*8+stream.Length>MaxEvidence)throw new InvalidOperationException("Mesh skin-weight review evidence limit exceeded.");
                write.Write(weights.Length);foreach(var b in weights){write.Write(b.boneIndex);write.Write(b.weight);}bound();
                }
                write.Write(mesh.bindposes.Length);foreach(var matrix in mesh.bindposes)for(int i=0;i<16;i++)write.Write(matrix[i]);bound();
                write.Write(mesh.subMeshCount);for(int sub=0;sub<mesh.subMeshCount;sub++) {
                    write.Write((int)mesh.GetTopology(sub));var indices=mesh.GetIndices(sub);write.Write(indices.Length);foreach(var i in indices)write.Write(i);bound();
                }
                write.Write(mesh.blendShapeCount);var dv=new Vector3[mesh.vertexCount];var dn=new Vector3[mesh.vertexCount];var dt=new Vector3[mesh.vertexCount];
                for(int shape=0;shape<mesh.blendShapeCount;shape++) {
                    write.Write(mesh.GetBlendShapeName(shape));int frames=mesh.GetBlendShapeFrameCount(shape);write.Write(frames);
                    for(int frame=0;frame<frames;frame++) {
                        write.Write(mesh.GetBlendShapeFrameWeight(shape,frame));mesh.GetBlendShapeFrameVertices(shape,frame,dv,dn,dt);
                        foreach(var v in dv)vector(v);foreach(var v in dn)vector(v);foreach(var v in dt)vector(v);bound();
                    }
                }
                using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(stream.ToArray()));
            }
        }
        internal static string ClipEvidence(AnimationClip clip)
        {
            using(var stream=new MemoryStream())using(var write=new BinaryWriter(stream)) {
                write.Write(clip.frameRate);write.Write(clip.legacy);write.Write((int)clip.wrapMode);
                foreach(var b in AnimationUtility.GetCurveBindings(clip)) {
                    write.Write(BindingKey(b));var curve=AnimationUtility.GetEditorCurve(clip,b);
                    write.Write((int)curve.preWrapMode);write.Write((int)curve.postWrapMode);
                    foreach(var key in curve.keys) {write.Write(key.time);write.Write(key.value);write.Write(key.inTangent);write.Write(key.outTangent);write.Write(key.inWeight);write.Write(key.outWeight);write.Write((int)key.weightedMode);}
                    if(stream.Length>MaxEvidence)throw new InvalidOperationException("Clip review evidence limit exceeded.");
                }
                foreach(var b in AnimationUtility.GetObjectReferenceCurveBindings(clip)) {
                    write.Write(BindingKey(b));foreach(var key in AnimationUtility.GetObjectReferenceCurve(clip,b)) {write.Write(key.time);write.Write(key.value?key.value.GetInstanceID():0);}
                    if(stream.Length>MaxEvidence)throw new InvalidOperationException("Clip review evidence limit exceeded.");
                }
                foreach(var e in AnimationUtility.GetAnimationEvents(clip)) {write.Write(e.time);write.Write(e.functionName??"");write.Write(e.stringParameter??"");write.Write(e.intParameter);write.Write(e.floatParameter);write.Write(e.objectReferenceParameter?e.objectReferenceParameter.GetInstanceID():0);write.Write((int)e.messageOptions);}
                using(var hash=SHA256.Create())return BitConverter.ToString(hash.ComputeHash(stream.ToArray()));
            }
        }
        static void CheckNoLinks(string path)
        {
            string current=Path.GetFullPath(path);
            while(!string.IsNullOrEmpty(current)) {
                try {if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Output path contains a symbolic link or reparse point.");}
                catch(FileNotFoundException) {} catch(DirectoryNotFoundException) {}
                var parent=Path.GetDirectoryName(current);if(parent==current)break;current=parent;
            }
        }
        static string ProjectAbsolute(string path) {return Path.Combine(Path.GetDirectoryName(Application.dataPath),path);}
        internal static void CheckProjectOutput(string path)
        {
            if(path!=OutputRoot&&!path.StartsWith(OutputRoot+"/",StringComparison.Ordinal))throw new IOException("Output is outside the repair folder.");
            CheckNoLinks(ProjectAbsolute(path));
        }
        static void Fresh(EyeRepairPlan plan)
        {
            ValidateOperation(plan.root,plan.source,plan.kind,plan.shader,plan.oldPrefix,plan.newPrefix);
            if(plan.fingerprint!=Fingerprint(plan.root,plan.source,plan.shader))throw new InvalidOperationException("Source changed at the write boundary; prepare again.");
        }
        internal static string NewFolder()
        {
            CheckProjectOutput(OutputRoot);
            if(!AssetDatabase.IsValidFolder(OutputRoot)) {
                if(File.Exists(ProjectAbsolute(OutputRoot))||Directory.Exists(ProjectAbsolute(OutputRoot)))throw new IOException("Repair output root exists but is not a recognized Unity folder.");
                if(string.IsNullOrEmpty(AssetDatabase.CreateFolder("Assets","VRC Eye Repairs")))throw new IOException("Could not create repair output root.");
            }
            string id=Guid.NewGuid().ToString("N");string folder=OutputRoot+"/"+id;
            CheckProjectOutput(folder);
            if(Directory.Exists(ProjectAbsolute(folder))||File.Exists(ProjectAbsolute(folder))||string.IsNullOrEmpty(AssetDatabase.CreateFolder(OutputRoot,id)))throw new IOException("Could not create an exclusive output folder.");
            return folder;
        }
        internal static void CreateAsset(Object copy,string path)
        {
            CheckProjectOutput(path);
            if(File.Exists(ProjectAbsolute(path))||AssetDatabase.LoadMainAssetAtPath(path))throw new IOException("Output already exists; it will not be replaced.");
            EyeCopyHistory.Before(path);
            AssetDatabase.CreateAsset(copy,path);
            if(AssetDatabase.LoadMainAssetAtPath(path)!=copy)throw new IOException("Unity did not create the requested copy.");
            CheckProjectOutput(path);
            if(AssetDatabase.GetAssetPath(copy)!=path)throw new IOException("New asset moved during import; save stopped.");
            AssetDatabase.SaveAssetIfDirty(copy);
            EyeCopyHistory.After(path);
        }
        static void Correspondence(Mesh source,Mesh copy)
        {
            if(source.vertexCount!=copy.vertexCount||source.subMeshCount!=copy.subMeshCount||source.blendShapeCount!=copy.blendShapeCount||
                !source.vertices.SequenceEqual(copy.vertices)||!source.bindposes.SequenceEqual(copy.bindposes))throw new InvalidOperationException("Mesh copy changed geometry, skin or material-slot correspondence.");
            if(!source.colors.SequenceEqual(copy.colors))throw new InvalidOperationException("Mesh copy changed vertex colors.");
            var sourceUv=new List<Vector4>();var copyUv=new List<Vector4>();
            for(int channel=0;channel<8;channel++) {
                sourceUv.Clear();copyUv.Clear();source.GetUVs(channel,sourceUv);copy.GetUVs(channel,copyUv);
                if(!sourceUv.SequenceEqual(copyUv))throw new InvalidOperationException("Mesh copy changed UV channel "+channel);
            }
            for(int sub=0;sub<source.subMeshCount;sub++)if(source.GetTopology(sub)!=copy.GetTopology(sub)||!source.GetIndices(sub).SequenceEqual(copy.GetIndices(sub)))throw new InvalidOperationException("Mesh copy changed submesh indices.");
            using(var a=source.GetBonesPerVertex())using(var b=copy.GetBonesPerVertex())if(!a.SequenceEqual(b))throw new InvalidOperationException("Mesh copy changed per-vertex bone counts.");
            using(var a=source.GetAllBoneWeights())using(var b=copy.GetAllBoneWeights())if(!a.SequenceEqual(b))throw new InvalidOperationException("Mesh copy changed bone weights.");
            var av=new Vector3[source.vertexCount];var an=new Vector3[source.vertexCount];var at=new Vector3[source.vertexCount];
            var bv=new Vector3[source.vertexCount];var bn=new Vector3[source.vertexCount];var bt=new Vector3[source.vertexCount];
            for(int shape=0;shape<source.blendShapeCount;shape++) {
                int frames=source.GetBlendShapeFrameCount(shape);
                if(source.GetBlendShapeName(shape)!=copy.GetBlendShapeName(shape)||frames!=copy.GetBlendShapeFrameCount(shape))throw new InvalidOperationException("Mesh copy changed blendshape identities.");
                for(int frame=0;frame<frames;frame++) {
                    source.GetBlendShapeFrameVertices(shape,frame,av,an,at);copy.GetBlendShapeFrameVertices(shape,frame,bv,bn,bt);
                    if(source.GetBlendShapeFrameWeight(shape,frame)!=copy.GetBlendShapeFrameWeight(shape,frame)||!av.SequenceEqual(bv)||!an.SequenceEqual(bn)||!at.SequenceEqual(bt))throw new InvalidOperationException("Mesh copy changed blendshape frames.");
                }
            }
        }
        public static string Execute(EyeRepairPlan plan,string objPath="")
        {
            Validate(plan);
            using(var history=EyeCopyHistory.Begin(plan.kind.ToString(),plan.fingerprint,plan.summary)) {
                string result=ExecuteCore(plan,objPath);history.Complete(result);return result;
            }
        }
        static string ExecuteCore(EyeRepairPlan plan,string objPath)
        {
            Validate(plan);plan.consumed=true;
            if(plan.kind==EyeRepairKind.MeshObj) {
                if(string.IsNullOrWhiteSpace(objPath)||!objPath.EndsWith(".obj",StringComparison.OrdinalIgnoreCase))throw new IOException("Choose a new .obj destination.");
                string data=BuildObj((Mesh)plan.source);
                // Build and final freshness checks happen before opening the exclusive destination.
                Fresh(plan);CheckNoLinks(objPath);
                EyeCopyHistory.Before(objPath,true);
                using(var stream=new FileStream(objPath,FileMode.CreateNew,FileAccess.Write,FileShare.None))
                using(var writer=new StreamWriter(stream,new UTF8Encoding(false)))writer.Write(data);
                EyeCopyHistory.After(objPath,true);
                return objPath;
            }
            string folder=NewFolder();Object copy=null;Mesh expectedMesh=null;Material expectedMaterial=null;
            try {
                Fresh(plan);
                if(plan.kind==EyeRepairKind.PrefabMissingScripts)return CopyPrefab(plan,folder+"/avatar-repaired.prefab");
                if(plan.kind==EyeRepairKind.MaterialShader) {var m=new Material((Material)plan.source);m.shader=plan.shader;copy=m;}
                else if(plan.kind==EyeRepairKind.MissingNormals) {var m=Object.Instantiate((Mesh)plan.source);copy=m;m.RecalculateNormals();if(m.normals.Length!=m.vertexCount)throw new InvalidOperationException("Normal generation failed.");}
                else if(plan.kind==EyeRepairKind.MissingTangents) {
                    var m=Object.Instantiate((Mesh)plan.source);copy=m;m.RecalculateTangents();
                    if(m.tangents.Length!=m.vertexCount)throw new InvalidOperationException("Tangent generation failed.");
                    foreach(var t in m.tangents) {Finite(new Vector3(t.x,t.y,t.z));if(float.IsNaN(t.w)||float.IsInfinity(t.w)||Mathf.Abs(t.w)!=1)throw new InvalidOperationException("Generated tangent handedness is invalid.");}
                }
                else if(plan.kind==EyeRepairKind.AnimationPaths)copy=CopyClip((AnimationClip)plan.source,plan.oldPrefix,plan.newPrefix);
                else throw new InvalidOperationException("Unknown copy operation.");
                if(plan.kind==EyeRepairKind.MissingNormals||plan.kind==EyeRepairKind.MissingTangents)Correspondence((Mesh)plan.source,(Mesh)copy);
                copy.name=plan.source.name+" (VRC Eye copy)";
                if(copy is Mesh)expectedMesh=Object.Instantiate((Mesh)copy);
                if(copy is Material)expectedMaterial=new Material((Material)copy);
                string path=folder+(plan.kind==EyeRepairKind.AnimationPaths?"/animation-remapped.anim":plan.kind==EyeRepairKind.MaterialShader?"/material-shader.mat":plan.kind==EyeRepairKind.MissingTangents?"/mesh-tangents.asset":"/mesh-normals.asset");
                Fresh(plan);CreateAsset(copy,path);
                EyeCopyHistory.Before(path);CheckProjectOutput(path);
                AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);EyeCopyHistory.After(path);Fresh(plan);
                if(expectedMesh) {
                    var saved=AssetDatabase.LoadAssetAtPath<Mesh>(path);if(!saved)throw new IOException("Published mesh could not be reloaded.");
                    Correspondence(expectedMesh,saved);
                    if(!expectedMesh.normals.SequenceEqual(saved.normals)||!expectedMesh.tangents.SequenceEqual(saved.tangents))throw new InvalidOperationException("Published mesh normals or tangents changed during import.");
                }
                if(expectedMaterial)EyeMaterialMapping.VerifyCopy(expectedMaterial,AssetDatabase.LoadAssetAtPath<Material>(path));
                return path;
            } catch(Exception error) {
                if(copy&&!AssetDatabase.Contains(copy))Object.DestroyImmediate(copy);
                throw new InvalidOperationException("Copy stopped. Inspect any retained partial outputs in "+folder+". Original assets were not intentionally modified. "+error.Message,error);
            }
            finally {if(expectedMesh)Object.DestroyImmediate(expectedMesh);if(expectedMaterial)Object.DestroyImmediate(expectedMaterial);}
        }
        static AnimationClip CopyClip(AnimationClip source,string oldPrefix,string newPrefix)
        {
            var copy=Object.Instantiate(source);
            try {
                var floats=AnimationUtility.GetCurveBindings(source);var objects=AnimationUtility.GetObjectReferenceCurveBindings(source);
                // Clear old bindings first so path chains (A→A/B) cannot overwrite another copied curve.
                foreach(var b in floats)AnimationUtility.SetEditorCurve(copy,b,null);
                foreach(var b in objects)AnimationUtility.SetObjectReferenceCurve(copy,b,null);
                foreach(var b in floats) {var next=b;next.path=RemapPath(b.path,oldPrefix,newPrefix);AnimationUtility.SetEditorCurve(copy,next,AnimationUtility.GetEditorCurve(source,b));}
                foreach(var b in objects) {var next=b;next.path=RemapPath(b.path,oldPrefix,newPrefix);AnimationUtility.SetObjectReferenceCurve(copy,next,AnimationUtility.GetObjectReferenceCurve(source,b));}
                return copy;
            } catch {Object.DestroyImmediate(copy);throw;}
        }
        static string CopyPrefab(EyeRepairPlan plan,string path)
        {
            Fresh(plan);CheckProjectOutput(path);
            if(File.Exists(ProjectAbsolute(path))||AssetDatabase.LoadMainAssetAtPath(path))throw new IOException("Output prefab already exists.");
            EyeCopyHistory.Before(path);
            if(!AssetDatabase.CopyAsset(AssetDatabase.GetAssetPath(plan.root),path))throw new IOException("Could not copy the source prefab.");
            EyeCopyHistory.After(path);
            GameObject copy=null;
            try {
                Fresh(plan);CheckProjectOutput(path);
                copy=PrefabUtility.LoadPrefabContents(path);
                // All unpacking is restricted to the newly copied prefab's isolated contents.
                foreach(var node in Nodes(copy))if(PrefabUtility.IsOutermostPrefabInstanceRoot(node.gameObject))
                    PrefabUtility.UnpackPrefabInstance(node.gameObject,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
                int removed=0;
                foreach(var node in Nodes(copy))removed+=GameObjectUtility.RemoveMonoBehavioursWithMissingScript(node.gameObject);
                if(removed==0||Nodes(copy).Any(n=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(n.gameObject)>0))throw new InvalidOperationException("Unity could not remove all missing script components from the copy.");
                Fresh(plan);CheckProjectOutput(path);
                EyeCopyHistory.Before(path);
                bool success;PrefabUtility.SaveAsPrefabAsset(copy,path,out success);
                if(!success)throw new IOException("Unity could not save the repaired prefab copy.");
                EyeCopyHistory.After(path);
                return path;
            } finally {if(copy)PrefabUtility.UnloadPrefabContents(copy);}
        }
        static void Finite(Vector3 value) {if(float.IsNaN(value.x)||float.IsNaN(value.y)||float.IsNaN(value.z)||float.IsInfinity(value.x)||float.IsInfinity(value.y)||float.IsInfinity(value.z))throw new InvalidOperationException("Mesh contains non-finite coordinates.");}
        static void ObjFinite(Vector3 value) {Finite(value);if(Math.Abs(value.x)>1e12||Math.Abs(value.y)>1e12||Math.Abs(value.z)>1e12)throw new InvalidOperationException("OBJ coordinate exceeds the preview magnitude limit.");}
        static string Number(float value) {return value.ToString("R",CultureInfo.InvariantCulture);}
        public static string BuildObj(Mesh mesh)
        {
            CheckMesh(mesh,ObjVertices,ObjTriangles);
            var vertices=mesh.vertices;var normals=mesh.normals;var uv=mesh.uv;
            foreach(var v in vertices)ObjFinite(v);
            var all=mesh.triangles;for(int i=0;i<all.Length;i+=3) {
                var a=vertices[all[i]];var b=vertices[all[i+1]];var c=vertices[all[i+2]];
                double span=Math.Max(Math.Max(Math.Max(a.x,Math.Max(b.x,c.x))-Math.Min(a.x,Math.Min(b.x,c.x)),Math.Max(a.y,Math.Max(b.y,c.y))-Math.Min(a.y,Math.Min(b.y,c.y))),Math.Max(a.z,Math.Max(b.z,c.z))-Math.Min(a.z,Math.Min(b.z,c.z)));
                if(span<=1e-12)throw new InvalidOperationException("OBJ contains a degenerate or too-small triangle.");
                double bx=(b.x-(double)a.x)/span,by=(b.y-(double)a.y)/span,bz=(b.z-(double)a.z)/span;
                double cx=(c.x-(double)a.x)/span,cy=(c.y-(double)a.y)/span,cz=(c.z-(double)a.z)/span;
                double nx=by*cz-bz*cy,ny=bz*cx-bx*cz,nz=bx*cy-by*cx;
                if(nx*nx+ny*ny+nz*nz<=1e-20)throw new InvalidOperationException("OBJ contains a degenerate triangle; repair it in the source editor first.");
            }
            bool hasNormals=normals.Length==vertices.Length,hasUv=uv.Length==vertices.Length;
            var text=new StringBuilder("# VRC Eye source mesh preview; local coordinates; no rig, materials or animation\no source_mesh\n");
            foreach(var v in vertices)text.Append("v ").Append(Number(v.x)).Append(' ').Append(Number(v.y)).Append(' ').Append(Number(v.z)).Append('\n');
            if(hasUv)foreach(var v in uv) {ObjFinite(new Vector3(v.x,v.y,0));text.Append("vt ").Append(Number(v.x)).Append(' ').Append(Number(v.y)).Append('\n');}
            if(hasNormals)foreach(var v in normals) {ObjFinite(v);text.Append("vn ").Append(Number(v.x)).Append(' ').Append(Number(v.y)).Append(' ').Append(Number(v.z)).Append('\n');}
            for(int sub=0;sub<mesh.subMeshCount;sub++) {
                text.Append("g submesh_").Append(sub).Append('\n');var triangles=mesh.GetTriangles(sub);
                for(int i=0;i<triangles.Length;i+=3) {
                    text.Append('f');for(int k=0;k<3;k++) {int index=triangles[i+k]+1;text.Append(' ').Append(index);
                        if(hasUv||hasNormals) {text.Append('/');if(hasUv)text.Append(index);if(hasNormals)text.Append('/').Append(index);}}
                    text.Append('\n');
                }
            }
            if(Encoding.UTF8.GetByteCount(text.ToString())>ObjBytes)throw new InvalidOperationException("OBJ exceeds 16 MiB; export stopped without truncation.");
            return text.ToString();
        }
    }
}
