// Separate controller/animation dependency copies; original assets are never assigned.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeControllerPlan
    {
        internal readonly RuntimeAnimatorController source;
        internal readonly AnimationClip oldClip,newClip;
        internal readonly Object[] objects;
        internal readonly string fingerprint;
        internal readonly double expires;
        internal bool used;
        public readonly string summary;
        internal EyeControllerPlan(RuntimeAnimatorController source,AnimationClip oldClip,AnimationClip newClip,Object[] objects,string fingerprint,string summary)
        {this.source=source;this.oldClip=oldClip;this.newClip=newClip;this.objects=objects;this.fingerprint=fingerprint;this.summary=summary;expires=EditorApplication.timeSinceStartup+300;}
    }
    public static class EyeControllerCopies
    {
        const int MaxObjects=10000,MaxAssets=512,MaxProperties=200000;
        static bool OwnedType(Object value)
        {return value is RuntimeAnimatorController||value is Motion||value is AvatarMask||value is AnimatorState||value is AnimatorStateMachine||value is AnimatorTransitionBase||value is StateMachineBehaviour;}
        static void Idle()
        {if(EditorApplication.isPlayingOrWillChangePlaymode||EditorApplication.isCompiling)throw new InvalidOperationException("Stop Play Mode and wait for compilation.");}
        static IEnumerable<Object> References(Object value)
        {
            var serialized=new SerializedObject(value);var property=serialized.GetIterator();int count=0;
            while(property.Next(true)) {
                if(++count>MaxProperties)throw new InvalidOperationException("Controller property budget exceeded.");
                if(property.propertyType!=SerializedPropertyType.ObjectReference)continue;
                var target=property.objectReferenceValue;
                if(!target&&property.objectReferenceInstanceIDValue!=0)throw new InvalidOperationException("Missing object reference: "+value.name+" / "+property.propertyPath);
                if(target)yield return target;
            }
        }
        static void MotionCycles(Motion motion,HashSet<int> active,HashSet<int> done,int depth)
        {
            if(!motion)return;
            if(depth>128||!active.Add(motion.GetInstanceID()))throw new InvalidOperationException("Cyclic or excessively deep blend tree.");
            if(!done.Contains(motion.GetInstanceID())&&motion is BlendTree tree)foreach(var child in tree.children)MotionCycles(child.motion,active,done,depth+1);
            active.Remove(motion.GetInstanceID());done.Add(motion.GetInstanceID());
        }
        static void StateCycles(AnimatorStateMachine machine,HashSet<int> active,HashSet<int> done,int depth)
        {
            if(!machine)return;
            if(depth>128||!active.Add(machine.GetInstanceID()))throw new InvalidOperationException("Cyclic or excessively deep state machine hierarchy.");
            if(!done.Contains(machine.GetInstanceID()))foreach(var child in machine.stateMachines)StateCycles(child.stateMachine,active,done,depth+1);
            active.Remove(machine.GetInstanceID());done.Add(machine.GetInstanceID());
        }
        public static Object[] Closure(RuntimeAnimatorController root,AnimationClip replacement=null)
        {
            Idle();if(!root||!EditorUtility.IsPersistent(root))throw new InvalidOperationException("Select a saved controller asset.");
            var visited=new HashSet<Object>();var queue=new Queue<Object>();queue.Enqueue(root);if(replacement)queue.Enqueue(replacement);
            while(queue.Count>0) {
                var value=queue.Dequeue();if(!value||!visited.Add(value))continue;
                if(visited.Count>MaxObjects)throw new InvalidOperationException("Controller closure exceeds 10,000 objects.");
                if(!EditorUtility.IsPersistent(value))throw new InvalidOperationException("Save every controller dependency before reviewing copies.");
                foreach(var reference in References(value)) {
                    if(OwnedType(reference))queue.Enqueue(reference);
                    else if(!EditorUtility.IsPersistent(reference))throw new InvalidOperationException("Controller contains an unsaved or scene object reference.");
                }
            }
            if(visited.Select(AssetDatabase.GetAssetPath).Distinct().Count()>MaxAssets)throw new InvalidOperationException("Controller closure exceeds 512 source assets.");
            foreach(var controller in visited.OfType<AnimatorController>()) {
                if(controller.parameters.Any(p=>string.IsNullOrWhiteSpace(p.name))||controller.parameters.GroupBy(p=>p.name,StringComparer.Ordinal).Any(g=>g.Count()>1))
                    throw new InvalidOperationException("Controller parameter names are missing, repeated or conflicting.");
            }
            var motionDone=new HashSet<int>();var machineDone=new HashSet<int>();
            foreach(var motion in visited.OfType<Motion>())MotionCycles(motion,new HashSet<int>(),motionDone,0);
            foreach(var machine in visited.OfType<AnimatorStateMachine>())StateCycles(machine,new HashSet<int>(),machineDone,0);
            foreach(var controller in visited.OfType<AnimatorOverrideController>()) {
                var chain=new HashSet<int>();RuntimeAnimatorController current=controller;
                while(current is AnimatorOverrideController next) {if(!chain.Add(current.GetInstanceID()))throw new InvalidOperationException("Cyclic override-controller chain.");current=next.runtimeAnimatorController;}
                if(!current)throw new InvalidOperationException("Override controller has no base controller.");
            }
            return visited.OrderBy(v=>AssetDatabase.GetAssetPath(v),StringComparer.Ordinal).ThenBy(v=>v.GetInstanceID()).ToArray();
        }
        static string Fingerprint(IEnumerable<Object> objects)
        {
            long length=0;var parts=new List<string>{Application.unityVersion};
            foreach(var item in objects) {string evidence=EyeMaterialMapping.ObjectEvidence(item);length+=evidence.Length;if(length>32*1024*1024)throw new InvalidOperationException("Controller review exceeds 32 MiB.");parts.Add(evidence);}
            return EyeMaterialMapping.Hash(string.Join("\n",parts));
        }
        public static EyeControllerPlan Prepare(RuntimeAnimatorController root,AnimationClip oldClip=null,AnimationClip newClip=null)
        {
            if((bool)oldClip!=(bool)newClip)throw new InvalidOperationException("Choose both clips for a swap, or neither to clone only.");
            var original=Closure(root);
            if(oldClip&&(!original.Contains(oldClip)||oldClip==newClip))throw new InvalidOperationException("The old clip must be a distinct dependency of this controller.");
            var objects=Closure(root,newClip);
            string summary="Clone "+root.name+" and its animation/controller/mask dependency closure.\n"+objects.Length+" serialized objects in "+objects.Select(AssetDatabase.GetAssetPath).Distinct().Count()+" source assets.\n"+
                (oldClip?"Replace every reviewed reference to "+oldClip.name+" with an independent copy of "+newClip.name+".\n":"No clip replacement.\n")+
                "Layers, masks, states, transitions, blend trees, parameters, behaviours and override chains are serialized into separate copies. Object-reference curves and events retain their asset references; events are not played. Existing project import/editor callbacks can run. Other referenced assets and scripts remain shared. No avatar/controller assignment or upload. Source changes invalidate review; partial outputs remain if import or reference validation fails.\n\n"+
                string.Join("\n",objects.Select(AssetDatabase.GetAssetPath).Distinct());
            return new EyeControllerPlan(root,oldClip,newClip,objects,Fingerprint(objects),summary);
        }
        static void Fresh(EyeControllerPlan plan)
        {
            Idle();var current=Closure(plan.source,plan.newClip);
            if(!current.SequenceEqual(plan.objects)||Fingerprint(current)!=plan.fingerprint)throw new InvalidOperationException("Controller dependencies changed after review.");
        }
        static long LocalId(Object value)
        {
            string guid;long id;
            if(!AssetDatabase.TryGetGUIDAndLocalFileIdentifier(value,out guid,out id))throw new InvalidOperationException("Unity did not resolve an object fileID.");
            return id;
        }
        public static string Execute(EyeControllerPlan plan)
        {
            if(plan==null)throw new InvalidOperationException("Prepare a controller copy first.");
            using(var history=EyeCopyHistory.Begin("Controller dependency copies",plan.fingerprint,plan.summary)) {
                string result=ExecuteCore(plan);history.Complete(result);return result;
            }
        }
        static string ExecuteCore(EyeControllerPlan plan)
        {
            if(plan==null||plan.used||EditorApplication.timeSinceStartup>=plan.expires)throw new InvalidOperationException("Controller review expired or was used.");
            Fresh(plan);plan.used=true;string folder=EyeAvatarRepair.NewFolder();var map=new Dictionary<Object,Object>();var outputs=new List<string>();
            try {
                int index=0;
                foreach(var group in plan.objects.GroupBy(AssetDatabase.GetAssetPath)) {
                    Fresh(plan);string path=group.Key;string extension=Path.GetExtension(path).ToLowerInvariant();
                    bool individual=extension!=".controller"&&extension!=".overridecontroller"&&extension!=".anim"&&extension!=".mask"&&extension!=".asset";
                    if(individual) {
                        foreach(var item in group) {
                            if(!(item is AnimationClip))throw new InvalidOperationException("Unsupported imported controller dependency: "+path);
                            Fresh(plan);var copy=Object.Instantiate(item);string output=folder+"/clip-"+(index++)+".anim";
                            EyeAvatarRepair.CreateAsset(copy,output);map.Add(item,copy);outputs.Add(output);
                        }
                    } else {
                        string output=folder+"/dependency-"+(index++)+extension;EyeAvatarRepair.CheckProjectOutput(output);
                        EyeCopyHistory.Before(output);
                        if(File.Exists(output)||!AssetDatabase.CopyAsset(path,output))throw new IOException("Unity could not create a separate dependency copy: "+path);
                        EyeCopyHistory.After(output);
                        outputs.Add(output);Fresh(plan);
                        var copies=AssetDatabase.LoadAllAssetsAtPath(output);
                        if(copies.Length>MaxObjects)throw new InvalidOperationException("Imported copy exceeds object budget.");
                        foreach(var item in group) {
                            var matches=copies.Where(c=>c&&c.GetType()==item.GetType()&&LocalId(c)==LocalId(item)).ToArray();
                            if(matches.Length!=1)throw new InvalidOperationException("Copied object fileIDs are ambiguous or changed: "+item.name);
                            map.Add(item,matches[0]);
                        }
                    }
                }
                // All destinations exist before links are rewritten, so shared
                // and cyclic serialized references keep their original topology.
                foreach(var copy in map.Values.Distinct()) {
                    Fresh(plan);EyeAvatarRepair.CheckProjectOutput(AssetDatabase.GetAssetPath(copy));
                    var serialized=new SerializedObject(copy);var property=serialized.GetIterator();int count=0;
                    while(property.Next(true)) {
                        if(++count>MaxProperties)throw new InvalidOperationException("Copy property budget exceeded.");
                        if(property.propertyType!=SerializedPropertyType.ObjectReference)continue;
                        var target=property.objectReferenceValue;if(!target)continue;
                        Object mapped;
                        if(plan.oldClip&&(target==plan.oldClip||target==map[plan.oldClip]))property.objectReferenceValue=map[plan.newClip];
                        else if(map.TryGetValue(target,out mapped))property.objectReferenceValue=mapped;
                    }
                    Fresh(plan);EyeCopyHistory.Before(AssetDatabase.GetAssetPath(copy));serialized.ApplyModifiedPropertiesWithoutUndo();EditorUtility.SetDirty(copy);AssetDatabase.SaveAssetIfDirty(copy);EyeCopyHistory.After(AssetDatabase.GetAssetPath(copy));
                }
                Fresh(plan);
                foreach(var output in outputs) {
                    EyeAvatarRepair.CheckProjectOutput(output);
                    foreach(var copy in AssetDatabase.LoadAllAssetsAtPath(output).Where(v=>v&&OwnedType(v)))
                        foreach(var reference in References(copy))if(map.ContainsKey(reference))throw new InvalidOperationException("A copied dependency still refers to an original animation object.");
                }
                var result=(RuntimeAnimatorController)map[plan.source];Closure(result);
                return AssetDatabase.GetAssetPath(result);
            } catch(Exception error) {throw new InvalidOperationException("Controller copy stopped; inspect retained outputs in "+folder+". "+error.Message,error);}
        }
    }
    public sealed class EyeControllerCopiesWindow:EditorWindow
    {
        RuntimeAnimatorController source;AnimationClip oldClip,newClip;bool authorized;EyeControllerPlan plan;Vector2 scroll;string report="Choose a saved controller. Clip replacement is optional.";
        [MenuItem("VRC Eye/Controller Dependency Copies")]
        public static void Open(){GetWindow<EyeControllerCopiesWindow>("Controller Copies");}
        void Run(Action action){try{action();}catch(Exception error){plan=null;report="Stopped: "+error.Message;}}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);EditorGUI.BeginChangeCheck();
            source=(RuntimeAnimatorController)EditorGUILayout.ObjectField("Source controller",source,typeof(RuntimeAnimatorController),false);
            oldClip=(AnimationClip)EditorGUILayout.ObjectField("Replace clip (optional)",oldClip,typeof(AnimationClip),false);
            newClip=(AnimationClip)EditorGUILayout.ObjectField("Replacement clip",newClip,typeof(AnimationClip),false);
            authorized=EditorGUILayout.ToggleLeft("I have permission to copy these assets",authorized);
            if(EditorGUI.EndChangeCheck())plan=null;
            using(new EditorGUI.DisabledScope(!source||!authorized))if(GUILayout.Button("Review dependency closure"))Run(()=>{plan=EyeControllerCopies.Prepare(source,oldClip,newClip);report=plan.summary;});
            using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Create reviewed copies…"))Run(()=>{var reviewed=plan;if(EditorUtility.DisplayDialog("Clone controller dependencies?",reviewed.summary,"Create copies","Cancel")){plan=null;report="Created: "+EyeControllerCopies.Execute(reviewed)+"\nInspect and test before assigning.";}});
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(250));EditorGUILayout.EndScrollView();
        }
    }
}
