using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeSettingTransferWindow:EditorWindow
    {
        GameObject source,destination;Renderer from,to;bool importer,authorized;int generation;Vector2 scroll;
        readonly HashSet<string> selected=new HashSet<string>();readonly Dictionary<string,Object> mapped=new Dictionary<string,Object>();readonly HashSet<string> clear=new HashSet<string>();
        EyeSettingPlan plan;string report="Select source and destination assets, then select each setting to transfer. All setting selections begin off.";
        [MenuItem("VRC Eye/Mesh and Importer Setting Transfers")]
        public static void Open(){GetWindow<EyeSettingTransferWindow>("Setting Transfers");}
        void Invalidate(){generation++;if(plan!=null)plan.Cancel();plan=null;}
        void OnDisable(){Invalidate();authorized=false;}
        Renderer PickRenderer(string label,GameObject root,Renderer current)
        {
            var renderers=root?root.GetComponentsInChildren<Renderer>(true).Where(r=>r.GetType()==typeof(MeshRenderer)||r.GetType()==typeof(SkinnedMeshRenderer)).ToArray():Array.Empty<Renderer>();
            if(renderers.Length==0){EditorGUILayout.LabelField(label,"No supported renderer");return null;}
            var labels=renderers.Select(r=>r.GetType().Name+" · "+(r.transform==root.transform?"Prefab root":AnimationUtility.CalculateTransformPath(r.transform,root.transform))).ToArray();
            return renderers[EditorGUILayout.Popup(label,Math.Max(0,Array.IndexOf(renderers,current)),labels)];
        }
        void Toggle(string key,string text)
        {bool before=selected.Contains(key),after=EditorGUILayout.ToggleLeft(text,before);if(before!=after){Invalidate();if(after)selected.Add(key);else {selected.Remove(key);mapped.Remove(key);clear.Remove(key);}}}
        void ReferenceRow(string key,Type type,Dictionary<string,Object> nodes=null)
        {
            Toggle(key,"Transfer "+key+" with explicit mapping");if(!selected.Contains(key))return;
            bool old=clear.Contains(key),empty=EditorGUILayout.ToggleLeft("Explicitly clear "+key,old);if(old!=empty){Invalidate();if(empty)clear.Add(key);else clear.Remove(key);}
            if(empty){mapped[key]=null;return;}Object value;mapped.TryGetValue(key,out value);Object chosen=value;
            if(nodes!=null) {
                var candidates=nodes.Where(p=>type.IsInstanceOfType(p.Value)).ToArray();var labels=new[]{"Select destination object…"}.Concat(candidates.Select(p=>p.Key+" · "+p.Value.name)).ToArray();
                int oldIndex=Array.FindIndex(candidates,p=>p.Value==value)+1;int index=EditorGUILayout.Popup("Destination for "+key,oldIndex,labels);chosen=index==0?null:candidates[index-1].Value;
            } else chosen=EditorGUILayout.ObjectField("Chosen asset for "+key,value,type,false);
            if(chosen!=value)Invalidate();mapped[key]=chosen;
        }
        void Run(Action work){try{work();}catch(Exception e){Invalidate();report="Stopped: "+e.Message;}Repaint();}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("Experimental Unity 2022.3 source workflow. Compile and run the EditMode tests in an authorized disposable project first. Reimports can change geometry/ordering. Existing editor/import callbacks can run. Outputs are retained for inspection; assignment is separate.",MessageType.Warning);
            EditorGUI.BeginChangeCheck();importer=EditorGUILayout.ToggleLeft("ModelImporter transfer (new FBX + reimport)",importer);
            source=(GameObject)EditorGUILayout.ObjectField(importer?"Source FBX root":"Source saved prefab",source,typeof(GameObject),false);
            destination=(GameObject)EditorGUILayout.ObjectField(importer?"Destination FBX root":"Destination saved prefab",destination,typeof(GameObject),false);
            if(!importer){from=PickRenderer("Source renderer",source,from);to=PickRenderer("Destination renderer",destination,to);}
            if(EditorGUI.EndChangeCheck()){Invalidate();selected.Clear();mapped.Clear();clear.Clear();authorized=false;}
            bool permission=EditorGUILayout.ToggleLeft("I own or have permission to inspect and create copies of both assets and mapped materials",authorized);if(permission!=authorized){authorized=permission;Invalidate();}
            Object left=from,right=to;EyeSettingSpec[] specs=Array.Empty<EyeSettingSpec>();
            try {
                if(importer&&source&&destination){left=EyeSettingTransfers.Model(source);right=EyeSettingTransfers.Model(destination);specs=EyeSettingSpecs.Importer();}
                else if(!importer&&from&&to&&from.GetType()==to.GetType())specs=EyeSettingSpecs.Renderer(from);
                else EditorGUILayout.HelpBox("Choose two supported compatible assets/renderers.",MessageType.Info);
                foreach(var spec in specs){Toggle(spec.key,spec.key+" · destination "+spec.Read(right)+" → source "+spec.Read(left));EditorGUILayout.LabelField(spec.risk,EditorStyles.wordWrappedMiniLabel);}
                if(!importer&&from&&to&&from.GetType()==to.GetType()) {
                    var nodes=EyeComponentCopies.Objects(destination);ReferenceRow("probeAnchor",typeof(Transform),nodes);ReferenceRow("lightProbeProxyVolumeOverride",typeof(GameObject),nodes);
                    if(from.sharedMaterials.Length==to.sharedMaterials.Length&&from.sharedMaterials.Length<=256)for(int i=0;i<from.sharedMaterials.Length;i++)ReferenceRow("material["+i+"]",typeof(Material));
                    else EditorGUILayout.HelpBox("Material-slot transfer requires equal slot counts (up to 256). No material mapping is guessed.",MessageType.Info);
                }
            } catch(Exception e){EditorGUILayout.HelpBox(e.Message,MessageType.Info);}
            using(new EditorGUI.DisabledScope(!authorized||selected.Count==0))if(GUILayout.Button("Prepare individually selected setting review"))Run(()=>{
                foreach(var p in mapped)if(selected.Contains(p.Key)&&!p.Value&&!clear.Contains(p.Key))throw new InvalidOperationException("Select an explicit target or check Explicitly clear for "+p.Key);
                Invalidate();plan=importer?EyeSettingTransfers.PrepareImporter(source,destination,selected):EyeSettingTransfers.PrepareRenderer(source,from,destination,to,selected,mapped);report=plan.summary;
            });
            using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Review and create separate copy"))Run(()=>{
                var reviewed=plan;int token=generation;
                if(!EditorUtility.DisplayDialog("Create reviewed setting copy?",reviewed.summary,"Create separate copy","Cancel")){Invalidate();report="Canceled. No setting copy was submitted.";return;}
                Func<bool> current=()=>this&&authorized&&plan==reviewed&&generation==token;
                string path=EyeSettingTransfers.Execute(reviewed,current);Invalidate();report="Created and verified: "+path+"\nInspect setting-transfer.json and Repair Copy History for the final phase and ordered changes. Original assignments remain unchanged.";
            });
            if(GUILayout.Button("Cancel prepared review")){Invalidate();report="Prepared review canceled. Existing outputs are retained.";}
            if(GUILayout.Button("Open Repair Copy History"))EyeCopyHistoryWindow.Open();
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(240));EditorGUILayout.EndScrollView();
        }
    }
}
