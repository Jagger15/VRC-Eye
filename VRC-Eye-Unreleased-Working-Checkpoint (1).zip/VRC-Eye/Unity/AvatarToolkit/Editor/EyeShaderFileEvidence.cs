// Local file evidence for matching an editor observation to a desktop receipt.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace VrcEye.AvatarToolkit
{
    [Serializable] public sealed class EyeShaderSourceFile {public string path,sha256;public long bytes;}
    [Serializable] public sealed class EyeShaderPass {public int index;public string name;public bool compiled;}
    public sealed class EyeShaderFiles
    {
        public EyeShaderSourceFile[] files;
        public string[] unverified;
        public string Identity {get{return string.Join("\n",files.Select(f=>f.path+"|"+f.bytes+"|"+f.sha256))+"\nUnverified\n"+string.Join("\n",unverified);}}
    }
    public static class EyeShaderFileEvidence
    {
        public static string ProjectRoot {get{return Path.GetFullPath(Path.Combine(Application.dataPath,".."));}}
        static void NoLinks(string path)
        {
            string current=Path.GetFullPath(path);
            while(!string.IsNullOrEmpty(current)) {
                if((File.GetAttributes(current)&FileAttributes.ReparsePoint)!=0)throw new IOException("Observation dependency contains a link or reparse point.");
                string parent=Path.GetDirectoryName(current);if(parent==current)break;current=parent;
            }
        }
        public static EyeShaderSourceFile Read(string relative)
        {
            if(string.IsNullOrEmpty(relative)||relative.Length>4096||relative.Contains("\\")||relative.Contains(":")||relative.Any(char.IsControl)||relative.Split('/').Any(s=>s==""||s=="."||s=="..")||
                !(relative.StartsWith("Assets/",StringComparison.Ordinal)||relative.StartsWith("Packages/",StringComparison.Ordinal)||relative.StartsWith("ProjectSettings/",StringComparison.Ordinal)))
                throw new IOException("Observation file must remain beneath this project's Assets, Packages or ProjectSettings.");
            string full=Path.Combine(ProjectRoot,relative);NoLinks(full);
            var before=new FileInfo(full);long size=before.Length;DateTime modified=before.LastWriteTimeUtc;
            if(size>64L*1024*1024)throw new IOException("An observation dependency exceeds 64 MiB.");
            string checksum;
            using(var stream=new FileStream(full,FileMode.Open,FileAccess.Read,FileShare.Read))
            using(var hash=SHA256.Create())checksum=BitConverter.ToString(hash.ComputeHash(stream)).Replace("-","").ToLowerInvariant();
            NoLinks(full);var after=new FileInfo(full);
            if(after.Length!=size||after.LastWriteTimeUtc!=modified)throw new IOException("A shader dependency changed during observation capture.");
            return new EyeShaderSourceFile{path=relative,bytes=size,sha256=checksum};
        }
        public static bool Saved(Material source)
        {
            return source&&source.shader&&AssetDatabase.Contains(source)&&!EditorUtility.IsDirty(source)&&!EditorUtility.IsDirty(source.shader)&&
                (!GraphicsSettings.currentRenderPipeline||!EditorUtility.IsDirty(GraphicsSettings.currentRenderPipeline));
        }
        public static EyeShaderFiles Capture(Material source)
        {
            var roots=new[]{AssetDatabase.GetAssetPath(source),source&&source.shader?AssetDatabase.GetAssetPath(source.shader):"",
                GraphicsSettings.currentRenderPipeline?AssetDatabase.GetAssetPath(GraphicsSettings.currentRenderPipeline):""}
                .Where(p=>p.StartsWith("Assets/",StringComparison.Ordinal)||p.StartsWith("Packages/",StringComparison.Ordinal)).Distinct().ToArray();
            var dependencies=roots.Length==0?Array.Empty<string>():AssetDatabase.GetDependencies(roots,true);
            if(dependencies.Length>1024)throw new IOException("Shader dependency graph exceeds 1,024 assets.");
            var names=new HashSet<string>(dependencies,StringComparer.Ordinal);
            foreach(string root in roots)names.Add(root);
            foreach(string path in new[]{"ProjectSettings/ProjectVersion.txt","ProjectSettings/GraphicsSettings.asset","ProjectSettings/QualitySettings.asset","Packages/manifest.json","Packages/packages-lock.json"})
                if(File.Exists(Path.Combine(ProjectRoot,path)))names.Add(path);
            foreach(string path in names.ToArray())if(File.Exists(Path.Combine(ProjectRoot,path+".meta")))names.Add(path+".meta");
            if(names.Count>2048)throw new IOException("Shader evidence exceeds 2,048 files.");
            var files=new List<EyeShaderSourceFile>();var unknown=new List<string>();long total=0;
            foreach(string path in names.OrderBy(p=>p,StringComparer.Ordinal)) {
                if(!(path.StartsWith("Assets/",StringComparison.Ordinal)||path.StartsWith("Packages/",StringComparison.Ordinal)||path.StartsWith("ProjectSettings/",StringComparison.Ordinal))||!File.Exists(Path.Combine(ProjectRoot,path))) {unknown.Add(path);continue;}
                var entry=Read(path);total+=entry.bytes;if(total>256L*1024*1024)throw new IOException("Shader evidence exceeds 256 MiB.");files.Add(entry);
            }
            return new EyeShaderFiles{files=files.ToArray(),unverified=unknown.ToArray()};
        }
    }
}
