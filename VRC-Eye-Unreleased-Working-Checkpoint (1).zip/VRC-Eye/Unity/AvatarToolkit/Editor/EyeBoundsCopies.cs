// Reviewed changes to one renderer in a new prefab. Source assets never assigned.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit
{
    public sealed class EyeBoundsPlan
    {
        internal readonly EyeBoundsObservation observation;internal bool used;
        public readonly Bounds proposed;public readonly Vector3 margin;public readonly bool explicitValues;
        public readonly string summary;
        internal EyeBoundsPlan(EyeBoundsObservation observation,Bounds proposed,Vector3 margin,bool explicitValues,string summary)
        {this.observation=observation;this.proposed=proposed;this.margin=margin;this.explicitValues=explicitValues;this.summary=summary;}
    }
    public static class EyeBoundsCopies
    {
        public static EyeBoundsPlan Prepare(EyeBoundsObservation observation,Vector3 margin,Bounds? explicitBounds=null)
        {
            EyeBoundsDiagnostics.Fresh(observation);EyeBoundsMath.Finite(margin);
            var required=EyeBoundsMath.Union(observation.observed,observation.meshInRootBone);
            var proposed=explicitBounds.HasValue?EyeBoundsMath.Check(explicitBounds.Value):EyeBoundsMath.Expand(EyeBoundsMath.Union(required,observation.rendererLocal),margin);
            if(explicitBounds.HasValue&&margin!=Vector3.zero)throw new InvalidOperationException("Choose explicit bounds or per-side margins, not both.");
            if(!EyeBoundsMath.Contains(proposed,required))throw new InvalidOperationException("Proposed bounds exclude sampled vertices or the imported mesh box in the root-bone frame. Enlarge them.");
            string summary=observation.report+"\n\nCorrection mode: "+(explicitBounds.HasValue?"Explicit center and size":"Union with stored bounds plus per-side margins")+"\nPer-side margin: "+margin.ToString("G9")+"\nProposed root-bone-local bounds: "+EyeBoundsMath.Text(proposed)+
                "\nContains original renderer bounds: "+EyeBoundsMath.Contains(proposed,observation.rendererLocal)+"\nChanges only m_AABB and clears m_DirtyAABB on one renderer in a NEW prefab; original mesh/renderer/scene assignments remain unchanged. The copy is unpacked from nested/variant links. Its asset root name may follow the new filename. Existing project import/editor callbacks can run during copy loading/saving. The saved clone is reloaded and compared, including mapped bone references. No updateWhenOffscreen toggle, shader change or FPS promise. Review expires five minutes after observation.";
            return new EyeBoundsPlan(observation,proposed,margin,explicitBounds.HasValue,summary);
        }
        static bool Owned(string property){return new[]{"m_GameObject","m_CorrespondingSourceObject","m_PrefabInstance","m_PrefabAsset","m_ObjectHideFlags"}.Contains(property.Split('.')[0]);}
        static bool BoundsField(string property){return property=="m_AABB"||property.StartsWith("m_AABB.",StringComparison.Ordinal)||property=="m_DirtyAABB";}
        internal static void Verify(EyeBoundsPlan plan,GameObject copy)
        {
            var original=EyeComponentCopies.Objects(plan.observation.root);var output=EyeComponentCopies.Objects(copy);
            if(!original.Keys.OrderBy(k=>k,StringComparer.Ordinal).SequenceEqual(output.Keys.OrderBy(k=>k,StringComparer.Ordinal)))throw new InvalidOperationException("Prefab copy changed object/component correspondence.");
            var keys=original.ToDictionary(p=>p.Value,p=>p.Key);int count=0;
            foreach(var entry in original) {
                var from=new SerializedObject(entry.Value);var to=new SerializedObject(output[entry.Key]);var p=from.GetIterator();
                while(p.Next(true)) {
                    if(++count>200000)throw new InvalidOperationException("Prefab verification exceeds 200,000 properties.");
                    if(Owned(p.propertyPath)||entry.Key=="root"&&p.propertyPath=="m_Name"||entry.Key==plan.observation.rendererKey&&BoundsField(p.propertyPath))continue;
                    var q=to.FindProperty(p.propertyPath);if(q==null||q.propertyType!=p.propertyType)throw new InvalidOperationException("Copied property schema changed: "+entry.Key+" / "+p.propertyPath);
                    if(p.propertyType==SerializedPropertyType.ObjectReference) {
                        string key;var expected=p.objectReferenceValue&&keys.TryGetValue(p.objectReferenceValue,out key)?output[key]:p.objectReferenceValue;
                        if(q.objectReferenceValue!=expected||!p.objectReferenceValue&&p.objectReferenceInstanceIDValue!=0)throw new InvalidOperationException("A copied reference was lost or points outside the reviewed clone: "+p.propertyPath);
                    } else if(p.propertyType!=SerializedPropertyType.Generic&&!SerializedProperty.DataEquals(p,q))throw new InvalidOperationException("Unreviewed copied value changed: "+entry.Key+" / "+p.propertyPath);
                }
            }
            var skin=output[plan.observation.rendererKey] as SkinnedMeshRenderer;
            if(!skin||!EyeBoundsDiagnostics.SerializedBounds(skin).Equals(plan.proposed)||new SerializedObject(skin).FindProperty("m_DirtyAABB").boolValue)throw new InvalidOperationException("Corrected bounds did not survive save/reload exactly.");
        }
        public static string Execute(EyeBoundsPlan plan)
        {
            if(plan==null||plan.used)throw new InvalidOperationException("Prepare an unused bounds review first.");
            EyeBoundsDiagnostics.Fresh(plan.observation);plan.used=true;
            using(var history=EyeCopyHistory.Begin("Renderer bounds copy",plan.observation.fingerprint,plan.summary)) {
                string folder=EyeAvatarRepair.NewFolder(),path=folder+"/bounds-copy.prefab";GameObject contents=null;
                try {
                    EyeBoundsDiagnostics.Fresh(plan.observation);EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);
                    if(File.Exists(path)||!AssetDatabase.CopyAsset(AssetDatabase.GetAssetPath(plan.observation.root),path))throw new IOException("Could not create a new bounds prefab copy.");
                    EyeCopyHistory.After(path);EyeBoundsDiagnostics.Fresh(plan.observation);
                    contents=PrefabUtility.LoadPrefabContents(path);
                    foreach(var go in EyeComponentCopies.Objects(contents).Values.OfType<GameObject>())if(PrefabUtility.IsOutermostPrefabInstanceRoot(go))PrefabUtility.UnpackPrefabInstance(go,PrefabUnpackMode.Completely,InteractionMode.AutomatedAction);
                    var copied=EyeComponentCopies.Objects(contents);var skin=copied[plan.observation.rendererKey] as SkinnedMeshRenderer;if(!skin)throw new InvalidOperationException("Reviewed renderer correspondence was lost.");
                    var serialized=new SerializedObject(skin);EyeBoundsDiagnostics.SerializedBounds(skin);
                    serialized.FindProperty("m_AABB").boundsValue=plan.proposed;serialized.FindProperty("m_DirtyAABB").boolValue=false;serialized.ApplyModifiedPropertiesWithoutUndo();
                    Verify(plan,contents);EyeBoundsDiagnostics.Fresh(plan.observation);EyeAvatarRepair.CheckProjectOutput(path);EyeCopyHistory.Before(path);
                    bool success;PrefabUtility.SaveAsPrefabAsset(contents,path,out success);if(!success)throw new IOException("Could not save the bounds copy.");EyeCopyHistory.After(path);
                    PrefabUtility.UnloadPrefabContents(contents);contents=null;EyeBoundsDiagnostics.Fresh(plan.observation);
                    contents=PrefabUtility.LoadPrefabContents(path);Verify(plan,contents);EyeBoundsDiagnostics.Fresh(plan.observation);
                    // A separate text asset contains exactly the reviewed sample scope;
                    // the durable ARC-19 receipt hashes both files and their metadata.
                    string reportPath=folder+"/bounds-review.txt";EyeAvatarRepair.CheckProjectOutput(reportPath);EyeCopyHistory.Before(reportPath);
                    using(var stream=new FileStream(reportPath,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var writer=new StreamWriter(stream,new UTF8Encoding(false)))writer.Write(plan.summary);
                    AssetDatabase.ImportAsset(reportPath,ImportAssetOptions.ForceSynchronousImport|ImportAssetOptions.ForceUpdate);
                    if(File.ReadAllText(reportPath)!=plan.summary)throw new IOException("Bounds review text changed during import.");EyeCopyHistory.After(reportPath);
                    Verify(plan,contents);EyeBoundsDiagnostics.Fresh(plan.observation);history.Complete(path);return path;
                } finally {if(contents)PrefabUtility.UnloadPrefabContents(contents);}
            }
        }
    }
    public sealed class EyeBoundsCopiesWindow:EditorWindow
    {
        GameObject root;SkinnedMeshRenderer renderer;bool authorized,explicitValues;Vector3 margin=Vector3.one*.05f,center,size=Vector3.one;
        EyeBoundsRange[] ranges=Array.Empty<EyeBoundsRange>();EyeBoundsObservation observation;EyeBoundsPlan plan;Vector2 scroll;
        string report="Select a saved prefab and one skinned renderer. Observe first; only a reviewed new copy can receive bounds changes.";
        [MenuItem("VRC Eye/Renderer Bounds Copies")]
        public static void Open(){GetWindow<EyeBoundsCopiesWindow>("Renderer Bounds Copies");}
        void OnGUI()
        {
            scroll=EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.HelpBox("Experimental Unity 2022.3 source workflow; compile and run its EditMode tests in your project before relying on results. Finite samples cannot certify procedural deformation or performance. Import/editor callbacks in the existing project can run during copy operations.",MessageType.Warning);
            EditorGUI.BeginChangeCheck();var next=(GameObject)EditorGUILayout.ObjectField("Saved prefab root",root,typeof(GameObject),false);
            if(next!=root){root=next;renderer=null;authorized=false;}
            var renderers=root?root.GetComponentsInChildren<SkinnedMeshRenderer>(true):Array.Empty<SkinnedMeshRenderer>();
            if(renderers.Length>0) {
                var labels=renderers.Select(r=>{string path=AnimationUtility.CalculateTransformPath(r.transform,root.transform);return string.IsNullOrEmpty(path)?"Prefab root":path;}).ToArray();
                int index=EditorGUILayout.Popup("Skinned renderer in prefab",Math.Max(0,Array.IndexOf(renderers,renderer)),labels);renderer=renderers[index];
            } else {renderer=null;EditorGUILayout.LabelField("Skinned renderer in prefab","No skinned renderers found");}
            int count=EditorGUILayout.IntSlider("Explicit clip ranges",ranges.Length,0,8);
            if(count!=ranges.Length)Array.Resize(ref ranges,count);
            for(int i=0;i<ranges.Length;i++) {
                var r=ranges[i];var clip=(AnimationClip)EditorGUILayout.ObjectField("Clip "+(i+1),r==null?null:r.clip,typeof(AnimationClip),false);
                float start=EditorGUILayout.FloatField("Start seconds",r==null?0:r.start),end=EditorGUILayout.FloatField("End seconds",r==null?(clip?clip.length:1):r.end);
                int samples=EditorGUILayout.IntField("Endpoint-inclusive samples",r==null?16:r.count);ranges[i]=new EyeBoundsRange(clip,start,end,samples);
            }
            if(EditorGUI.EndChangeCheck()){observation=null;plan=null;}
            authorized=EditorGUILayout.ToggleLeft("I own or have permission to inspect and create copies of this prefab, mesh and selected clips",authorized);
            using(new EditorGUI.DisabledScope(!root||!renderer||!authorized))if(GUILayout.Button("Observe imported pose and selected samples (read-only)"))Run(()=>{observation=EyeBoundsDiagnostics.Observe(root,renderer,ranges,true);plan=null;report=observation.report;center=observation.rendererLocal.center;size=observation.rendererLocal.size;});
            EditorGUI.BeginChangeCheck();explicitValues=EditorGUILayout.ToggleLeft("Use explicit bounds instead of margins",explicitValues);
            if(explicitValues){center=EditorGUILayout.Vector3Field("Root-bone-local center",center);size=EditorGUILayout.Vector3Field("Root-bone-local size",size);}
            else margin=EditorGUILayout.Vector3Field("Per-side margin XYZ",margin);
            if(EditorGUI.EndChangeCheck())plan=null;
            using(new EditorGUI.DisabledScope(observation==null||!authorized))if(GUILayout.Button("Prepare bounds correction review"))Run(()=>{plan=EyeBoundsCopies.Prepare(observation,explicitValues?Vector3.zero:margin,explicitValues?(Bounds?)new Bounds(center,size):null);report=plan.summary;});
            using(new EditorGUI.DisabledScope(plan==null||!authorized))if(GUILayout.Button("Review and create separate prefab"))Run(()=>{
                var reviewed=plan;if(!EditorUtility.DisplayDialog("Create reviewed bounds copy?",reviewed.summary,"Create new prefab","Cancel"))return;
                if(!authorized||plan!=reviewed||observation!=reviewed.observation||root!=observation.root||renderer!=observation.renderer)throw new InvalidOperationException("Selection or permission changed; review again.");
                plan=null;report="Created: "+EyeBoundsCopies.Execute(reviewed)+"\nOriginal assignments remain unchanged. Inspect the prefab, sample report and Repair Copy History before manual use.";
            });
            if(GUILayout.Button("Open Repair Copy History"))EyeCopyHistoryWindow.Open();
            EditorGUILayout.TextArea(report,GUILayout.MinHeight(260));EditorGUILayout.EndScrollView();
        }
        void Run(Action action){try{action();}catch(Exception e){plan=null;report="Stopped: "+e.Message;}Repaint();}
    }
}
