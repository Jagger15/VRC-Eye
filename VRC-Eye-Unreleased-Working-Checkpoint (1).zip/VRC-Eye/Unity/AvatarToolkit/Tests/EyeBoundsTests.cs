// Native qualification gate: run in Unity 2022.3 EditMode. Not Python tests.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyeBoundsTests
    {
        string folder;GameObject source;SkinnedMeshRenderer skin;Mesh mesh;
        readonly List<string> outputs=new List<string>();
        [SetUp]public void Setup()
        {
            if(!Application.unityVersion.StartsWith("2022.3.",StringComparison.Ordinal))Assert.Ignore("Bounds serialization is qualified for the 2022.3 gate only.");
            string name="EyeBoundsFixture-"+Guid.NewGuid().ToString("N");AssetDatabase.CreateFolder("Assets",name);folder="Assets/"+name;
            var root=new GameObject("BoundsFixture");
            try {
                root.transform.localPosition=new Vector3(7,-2,1);root.transform.localScale=new Vector3(-2,3,.5f);
                var bone=new GameObject("RootBone");bone.transform.SetParent(root.transform,false);bone.transform.localPosition=new Vector3(.5f,1,0);
                var tip=new GameObject("Tip");tip.transform.SetParent(bone.transform,false);
                var body=new GameObject("Body");body.transform.SetParent(root.transform,false);body.transform.localPosition=new Vector3(2,0,0);body.transform.localScale=new Vector3(-1,2,.5f);
                mesh=new Mesh{name="Bounds triangle"};mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};mesh.triangles=new[]{0,1,2};mesh.RecalculateNormals();mesh.RecalculateBounds();
                mesh.bindposes=new[]{tip.transform.worldToLocalMatrix*body.transform.localToWorldMatrix};
                mesh.boneWeights=Enumerable.Repeat(new BoneWeight{boneIndex0=0,weight0=1},3).ToArray();
                mesh.AddBlendShapeFrame("Raised",100,new[]{Vector3.forward*2,Vector3.zero,Vector3.zero},new Vector3[3],new Vector3[3]);
                AssetDatabase.CreateAsset(mesh,folder+"/mesh.asset");
                var renderer=body.AddComponent<SkinnedMeshRenderer>();renderer.sharedMesh=mesh;renderer.bones=new[]{tip.transform};renderer.rootBone=bone.transform;renderer.quality=SkinQuality.Bone1;renderer.localBounds=new Bounds(Vector3.zero,Vector3.one*.2f);
                source=PrefabUtility.SaveAsPrefabAsset(root,folder+"/source.prefab");
            } finally {Object.DestroyImmediate(root);}
            AssetDatabase.SaveAssets();skin=source.GetComponentInChildren<SkinnedMeshRenderer>(true);
        }
        [TearDown]public void Cleanup()
        {
            EyeBoundsImportCallback.action=null;
            foreach(string output in outputs)AssetDatabase.DeleteAsset(output);outputs.Clear();
            if(!string.IsNullOrEmpty(folder))AssetDatabase.DeleteAsset(folder);
        }
        AnimationClip Clip(string path="RootBone/Tip",Type type=null,string property="m_LocalPosition.x",float end=2)
        {
            var clip=new AnimationClip{name="Bounds sample"};
            AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,type??typeof(Transform),property),AnimationCurve.Linear(0,0,1,end));
            AssetDatabase.CreateAsset(clip,folder+"/"+Guid.NewGuid().ToString("N")+".anim");AssetDatabase.SaveAssetIfDirty(clip);return clip;
        }
        EyeBoundsObservation Observe(params EyeBoundsRange[] ranges){return EyeBoundsDiagnostics.Observe(source,skin,ranges);}
        string Retain(string path){outputs.Add(Path.GetDirectoryName(path).Replace('\\','/'));return path;}
        static void Near(Vector3 a,Vector3 b){Assert.Less((a-b).magnitude,.0001f);}
        [Test]public void ImportedVerticesUseExplicitRootBoneWithNegativeNonuniformTransforms()
        {
            string before=EditorJsonUtility.ToJson(skin);var observation=Observe();
            Near(new Vector3(.5f,-1,0),observation.observed.min);Near(new Vector3(1.5f,1,0),observation.observed.max);
            Assert.IsFalse(EyeBoundsMath.Contains(observation.rendererLocal,observation.observed));Assert.AreEqual(before,EditorJsonUtility.ToJson(skin));
            StringAssert.Contains("root-bone",observation.report);StringAssert.Contains("No FPS improvement",observation.report);
        }
        [Test]public void AnimatedBoneAndBlendshapeSamplesExpandBoundsWithoutChangingSource()
        {
            var clip=Clip();AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve("Body",typeof(SkinnedMeshRenderer),"blendShape.Raised"),AnimationCurve.Linear(0,0,1,100));AssetDatabase.SaveAssetIfDirty(clip);
            string before=EditorJsonUtility.ToJson(source),meshBefore=EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(mesh)).sha256;
            var observation=Observe(new EyeBoundsRange(clip,0,1,3));
            Near(new Vector3(3.5f,1,1),observation.observed.max);StringAssert.Contains("@ 0.5 s",observation.report);
            Assert.AreEqual(before,EditorJsonUtility.ToJson(source));Assert.AreEqual(meshBefore,EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(mesh)).sha256);Assert.AreEqual(0,skin.GetBlendShapeWeight(0));
        }
        [Test]public void MovingRootBoneUsesItsOwnSampleFrame()
        {
            var clip=Clip("RootBone",end=8);var result=Observe(new EyeBoundsRange(clip,0,1,3));
            Near(new Vector3(.5f,-1,0),result.observed.min);Near(new Vector3(1.5f,1,0),result.observed.max);
        }
        [Test]public void SavedCorrectionChangesOnlyClonedRendererAndRemapsBones()
        {
            string sourcePath=AssetDatabase.GetAssetPath(source),sourceHash=EyeShaderFileEvidence.Read(sourcePath).sha256,meshHash=EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(mesh)).sha256;
            Bounds original=skin.localBounds;var plan=EyeBoundsCopies.Prepare(Observe(),new Vector3(.1f,.2f,.3f));string path=Retain(EyeBoundsCopies.Execute(plan));
            var loaded=PrefabUtility.LoadPrefabContents(path);
            try {
                var copy=loaded.GetComponentInChildren<SkinnedMeshRenderer>(true);Assert.AreEqual(plan.proposed,new SerializedObject(copy).FindProperty("m_AABB").boundsValue);
                Assert.AreSame(mesh,copy.sharedMesh);Assert.AreSame(loaded.transform.Find("RootBone"),copy.rootBone);Assert.AreSame(loaded.transform.Find("RootBone/Tip"),copy.bones.Single());Assert.AreNotSame(skin.rootBone,copy.rootBone);
                Assert.AreEqual(skin.updateWhenOffscreen,copy.updateWhenOffscreen);Assert.AreEqual(skin.quality,copy.quality);
            } finally {PrefabUtility.UnloadPrefabContents(loaded);}
            Assert.AreEqual(original,skin.localBounds);Assert.AreEqual(sourceHash,EyeShaderFileEvidence.Read(sourcePath).sha256);Assert.AreEqual(meshHash,EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(mesh)).sha256);
            var receipt=EyeCopyHistory.Read().Single(r=>r.result==path);Assert.AreEqual("Completed; no assignment",receipt.phase);Assert.AreEqual(2,receipt.files.Length);StringAssert.Contains("still matches",EyeCopyHistory.Report(receipt));
            Assert.AreEqual(plan.summary,File.ReadAllText(Path.GetDirectoryName(path)+"/bounds-review.txt"));Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Execute(plan));
        }
        [Test]public void ExplicitBoundsRejectUndercoverageAndNonzeroMargins()
        {
            var observation=Observe();Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Prepare(observation,Vector3.zero,new Bounds(Vector3.zero,Vector3.zero)));
            var big=new Bounds(Vector3.zero,Vector3.one*20);Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Prepare(observation,Vector3.one,big));
            var plan=EyeBoundsCopies.Prepare(observation,Vector3.zero,big);Assert.AreEqual(big,plan.proposed);Assert.IsTrue(plan.explicitValues);
        }
        [Test]public void ChangedMeshInvalidatesReviewBeforeCopy()
        {
            var plan=EyeBoundsCopies.Prepare(Observe(),Vector3.zero);mesh.vertices=new[]{Vector3.one,Vector3.right,Vector3.up};EditorUtility.SetDirty(mesh);
            Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Execute(plan));
        }
        [Test]public void ChangedClipBytesInvalidateEvenWithoutReimport()
        {
            var clip=Clip();var observation=Observe(new EyeBoundsRange(clip,0,1,2));File.AppendAllText(AssetDatabase.GetAssetPath(clip),"\n# external change\n");
            Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Prepare(observation,Vector3.zero));
        }
        [Test]public void MissingRootBoneAndSingularTransformAreRejected()
        {
            var clip=Clip("Body",typeof(Transform),"m_LocalScale.x",0);
            Assert.Throws<InvalidOperationException>(()=>Observe(new EyeBoundsRange(clip,1,1,1)));
            skin.rootBone=null;EditorUtility.SetDirty(skin);AssetDatabase.SaveAssets();
            Assert.Throws<InvalidOperationException>(()=>Observe());
        }
        [Test]public void ClipEventsAreReportedButNeverDispatched()
        {
            var clip=Clip();AnimationUtility.SetAnimationEvents(clip,new[]{new AnimationEvent{time=.5f,functionName="ThisMethodDoesNotExistAndMustNotBeCalled"}});AssetDatabase.SaveAssetIfDirty(clip);
            var result=Observe(new EyeBoundsRange(clip,0,1,3));StringAssert.Contains("ignored 1 events",result.report);
            UnityEngine.TestTools.LogAssert.NoUnexpectedReceived();
        }
        [Test]public void UnsupportedAndMissingBindingsCannotMasqueradeAsSamples()
        {
            var scriptLike=Clip("Body",typeof(SkinnedMeshRenderer),"m_Enabled",1);
            Assert.Throws<InvalidOperationException>(()=>Observe(new EyeBoundsRange(scriptLike,0,1,2)));
            var missing=Clip("NotInPrefab");Assert.Throws<InvalidOperationException>(()=>Observe(new EyeBoundsRange(missing,0,1,2)));
        }
        [Test]public void AabbTransformUsesAllCornersAndMarginsArePerSide()
        {
            var box=new Bounds(Vector3.zero,new Vector3(2,4,6));var matrix=Matrix4x4.TRS(new Vector3(3,4,5),Quaternion.Euler(0,0,90),new Vector3(-2,3,.5f));
            var result=EyeBoundsMath.Transform(box,matrix);Near(new Vector3(-3,2,3.5f),result.min);Near(new Vector3(9,6,6.5f),result.max);
            var enlarged=EyeBoundsMath.Expand(result,new Vector3(1,2,3));Near(result.min-new Vector3(1,2,3),enlarged.min);Near(result.max+new Vector3(1,2,3),enlarged.max);
            Assert.Throws<InvalidOperationException>(()=>EyeBoundsMath.Expand(box,new Vector3(float.NaN,0,0)));Assert.Throws<InvalidOperationException>(()=>EyeBoundsMath.Expand(box,-Vector3.one));
        }
        [Test]public void SampleRangeRejectsInvalidCountsAndPreservesEndpoints()
        {
            var clip=Clip();CollectionAssert.AreEqual(new[]{0f,.5f,1f},new EyeBoundsRange(clip,0,1,3).Times());CollectionAssert.AreEqual(new[]{.25f},new EyeBoundsRange(clip,.25f,.25f,1).Times());
            Assert.Throws<InvalidOperationException>(()=>new EyeBoundsRange(clip,0,1,129).Times());Assert.Throws<InvalidOperationException>(()=>new EyeBoundsRange(clip,0,1,1).Times());Assert.Throws<InvalidOperationException>(()=>new EyeBoundsRange(clip,0,2,3).Times());
        }
        [Test]public void SourceChangeDuringCopyImportLeavesInterruptedReceipt()
        {
            var plan=EyeBoundsCopies.Prepare(Observe(),Vector3.zero);string output="";
            EyeBoundsImportCallback.action=path=>{output=path;Retain(path);mesh.vertices=new[]{Vector3.one,Vector3.right,Vector3.up};EditorUtility.SetDirty(mesh);};
            Assert.Throws<InvalidOperationException>(()=>EyeBoundsCopies.Execute(plan));Assert.IsNotEmpty(output);Assert.IsTrue(File.Exists(output));
            StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
    }
    public sealed class EyeBoundsImportCallback:AssetPostprocessor
    {
        public static Action<string> action;
        static void OnPostprocessAllAssets(string[] imported,string[] deleted,string[] moved,string[] movedFrom)
        {
            if(action==null)return;
            foreach(string path in imported)if(path.StartsWith(EyeAvatarRepair.OutputRoot+"/",StringComparison.Ordinal)&&path.EndsWith("/bounds-copy.prefab",StringComparison.Ordinal)) {
                var callback=action;action=null;callback(path);break;
            }
        }
    }
}
