// Run explicitly in Unity's EditMode Test Runner with Avatars SDK 3.10.x installed.
// These tests are supplied, not claimed as executed by the Python release checks.
using System;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyeAuthoringTests
    {
        Scene scene; GameObject avatar; Component descriptor; string scenePath; EyeInstallJournal journal;
        [SetUp] public void SetUp()
        {
            if(EyeSdk.DescriptorType==null || !EyeSdk.Version().StartsWith("3.10.")) Assert.Ignore("Requires Avatars SDK 3.10.x.");
            scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Additive);
            scenePath="Assets/EyeToolkitTest-"+Guid.NewGuid().ToString("N")+".unity";
            avatar=new GameObject("Authorized test avatar");SceneManager.MoveGameObjectToScene(avatar,scene);
            avatar.AddComponent<Animator>();descriptor=avatar.AddComponent(EyeSdk.DescriptorType);
            // Default descriptor layer arrays vary by SDK reset state; explicitly create a test FX slot.
            var so=new SerializedObject(descriptor);var layers=EyeSdk.Field(so,"baseAnimationLayers");layers.arraySize=1;
            var fx=layers.GetArrayElementAtIndex(0);EyeSdk.Enum(EyeSdk.Child(fx,"type"),"FX");EyeSdk.Child(fx,"isDefault").boolValue=true;
            EyeSdk.Child(fx,"animatorController").objectReferenceValue=null;so.ApplyModifiedPropertiesWithoutUndo();
            EditorSceneManager.SaveScene(scene,scenePath);
        }
        [TearDown] public void TearDown()
        {
            if(scene.IsValid())EditorSceneManager.CloseScene(scene,true);
            if(journal)AssetDatabase.DeleteAsset(System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(journal)).Replace('\\','/'));
            if(!string.IsNullOrEmpty(scenePath))AssetDatabase.DeleteAsset(scenePath);
        }
        EyePlan Plan(params string[] modules) {return EyeInstallation.Analyze(descriptor,avatar.transform,modules,Vector3.zero,Vector3.zero,1,.012f);}
        [Test] public void InstallationIsPrivateAndDuplicateSafe()
        {
            var plan=Plan("battery","camera");Assert.AreEqual(0,plan.additionalBits);Assert.Contains("connection",plan.modules);
            journal=EyeInstallation.Install(plan);var so=new SerializedObject(journal.installedParameters);var entries=EyeSdk.Field(so,"parameters");
            for(int i=0;i<entries.arraySize;i++){var p=entries.GetArrayElementAtIndex(i);Assert.IsFalse(EyeSdk.Child(p,"networkSynced").boolValue);Assert.IsFalse(EyeSdk.Child(p,"saved").boolValue);}
            Assert.Throws<InvalidOperationException>(()=>Plan("battery"));
            var receiver=journal.generatedRoot.GetComponentsInChildren<Component>(true).First(x=>x&&x.GetType().Name=="VRCContactReceiver");var contact=new SerializedObject(receiver);
            Assert.IsTrue(EyeSdk.Field(contact,"localOnly").boolValue);Assert.IsTrue(EyeSdk.Field(contact,"allowSelf").boolValue);Assert.IsFalse(EyeSdk.Field(contact,"allowOthers").boolValue);
        }
        [Test] public void ChangedGeneratedObjectPreventsAutomaticRemoval()
        {
            journal=EyeInstallation.Install(Plan("battery"));journal.generatedRoot.transform.localPosition=Vector3.one;
            Assert.Throws<InvalidOperationException>(()=>EyeInstallation.Remove(descriptor,journal));
            Assert.IsNotNull(journal.generatedRoot);
        }
        [Test] public void UnchangedRemovalRestoresOriginalReferencesAndRetainsHistory()
        {
            journal=EyeInstallation.Install(Plan("battery"));EyeInstallation.Remove(descriptor,journal);
            var so=new SerializedObject(descriptor);Assert.AreEqual(journal.originalParameters,EyeSdk.Field(so,"expressionParameters").objectReferenceValue);
            Assert.AreEqual("removed-assets-retained",journal.phase);Assert.IsTrue(AssetDatabase.LoadAssetAtPath<Object>(journal.ownedAssets[0]));
        }
        [Test] public void RootResolvesWithoutPersistingASceneReferenceInAnAsset()
        {
            journal=EyeInstallation.Install(Plan("battery"));var before=journal.generatedRoot;
            journal.generatedRoot=null;Assert.AreEqual(before,journal.ResolveRoot(descriptor));
            before.SetActive(false);Assert.Throws<InvalidOperationException>(()=>EyeInstallation.Remove(descriptor,journal));
        }
        [Test] public void ManifestIsSourceAndNeverClaimsPublishedBuild()
        {
            journal=EyeInstallation.Install(Plan("battery"));string json=EyeManifestExport.Build(descriptor,journal,"Windows","test",false,false);
            StringAssert.Contains("\"stage\":\"source\"",json);StringAssert.Contains("\"build_id\":\"\"",json);
            StringAssert.DoesNotContain(scenePath,json);StringAssert.DoesNotContain("Authorized test avatar",json);
        }
        [Test] public void JournalRemovalSurvivesSavingAndReopeningTheScene()
        {
            journal=EyeInstallation.Install(Plan("battery"));
            EditorSceneManager.SaveScene(scene,scenePath);EditorSceneManager.CloseScene(scene,true);
            scene=EditorSceneManager.OpenScene(scenePath,OpenSceneMode.Additive);
            avatar=scene.GetRootGameObjects().Single(x=>x.name=="Authorized test avatar");
            descriptor=avatar.GetComponent(EyeSdk.DescriptorType);
            Assert.AreEqual(journal,EyeInstallation.Find(descriptor));
            EyeInstallation.Remove(descriptor,journal);
            Assert.AreEqual("removed-assets-retained",journal.phase);
        }
    }
}
