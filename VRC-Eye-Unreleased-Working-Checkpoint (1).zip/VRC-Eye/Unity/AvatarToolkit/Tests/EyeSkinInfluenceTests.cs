// Supplied tests, not executed outside the Unity 2022.3 EditMode gate.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyeSkinInfluenceTests
    {
        string folder;GameObject source;SkinnedMeshRenderer skin;Mesh mesh;
        readonly List<string> outputs=new List<string>();
        [SetUp]public void Setup()
        {
            if(!Application.unityVersion.StartsWith("2022.3.",StringComparison.Ordinal))Assert.Ignore("Unity 2022.3 qualification gate.");
            string name="EyeSkinFixture-"+Guid.NewGuid().ToString("N");AssetDatabase.CreateFolder("Assets",name);folder="Assets/"+name;
            var root=new GameObject("SkinFixture");
            try {
                root.transform.localScale=new Vector3(-2,3,.5f);root.transform.localPosition=new Vector3(7,-2,1);
                var a=new GameObject("BoneA");a.transform.SetParent(root.transform,false);var b=new GameObject("BoneB");b.transform.SetParent(a.transform,false);
                var body=new GameObject("Body");body.transform.SetParent(root.transform,false);
                mesh=new Mesh{name="Skin triangle"};mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};mesh.triangles=new[]{0,1,2};mesh.uv=new[]{Vector2.zero,Vector2.right,Vector2.up};mesh.colors=new[]{Color.red,Color.green,Color.blue};mesh.RecalculateNormals();mesh.RecalculateBounds();
                mesh.bindposes=new[]{Matrix4x4.identity,Matrix4x4.identity};mesh.boneWeights=Enumerable.Repeat(new BoneWeight{boneIndex0=0,weight0=.75f,boneIndex1=1,weight1=.25f},3).ToArray();
                mesh.AddBlendShapeFrame("Raised",50,new[]{Vector3.forward,Vector3.zero,Vector3.zero},new Vector3[3],new Vector3[3]);
                mesh.AddBlendShapeFrame("Raised",100,new[]{Vector3.forward*2,Vector3.zero,Vector3.zero},new Vector3[3],new Vector3[3]);
                AssetDatabase.CreateAsset(mesh,folder+"/mesh.asset");var renderer=body.AddComponent<SkinnedMeshRenderer>();renderer.sharedMesh=mesh;renderer.bones=new[]{a.transform,b.transform};renderer.rootBone=a.transform;renderer.quality=SkinQuality.Bone1;renderer.sharedMaterials=new Material[]{null};renderer.SetBlendShapeWeight(0,25);
                source=PrefabUtility.SaveAsPrefabAsset(root,folder+"/source.prefab");
            }finally{Object.DestroyImmediate(root);}
            AssetDatabase.SaveAssets();skin=source.GetComponentInChildren<SkinnedMeshRenderer>(true);
        }
        [TearDown]public void Cleanup(){EyeSkinImportCallback.action=null;foreach(string p in outputs.Distinct())AssetDatabase.DeleteAsset(p);outputs.Clear();if(!string.IsNullOrEmpty(folder))AssetDatabase.DeleteAsset(folder);}
        AnimationClip Clip(string path="BoneA/BoneB",string property="m_LocalPosition.x",Type type=null)
        {
            var clip=new AnimationClip{name="Skin pose"};AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve(path,type??typeof(Transform),property),AnimationCurve.Linear(0,0,1,2));
            AssetDatabase.CreateAsset(clip,folder+"/"+Guid.NewGuid().ToString("N")+".anim");AssetDatabase.SaveAssetIfDirty(clip);return clip;
        }
        EyeSkinPlan Prepare(float tolerance=2,params EyeBoundsRange[] ranges){return EyeSkinInfluenceCopies.Prepare(source,skin,1,tolerance,ranges);}
        string Retain(string path){outputs.Add(Path.GetDirectoryName(path).Replace('\\','/'));return path;}
        [Test]public void FullStoredWeightsAreMeasuredDespiteRendererQualityAndNegativeScale()
        {
            string before=EditorJsonUtility.ToJson(skin);var plan=Prepare(2,new EyeBoundsRange(Clip(),0,1,3));
            Assert.AreEqual(1,plan.maximum,.0001);Assert.AreEqual(Math.Sqrt(1.25/4),plan.rms,.0001);
            CollectionAssert.AreEqual(new[]{0f,0f,.5f,1f},plan.Samples.Select(s=>s.seconds));Assert.AreEqual(6,plan.influencesBefore);Assert.AreEqual(3,plan.influencesAfter);Assert.AreEqual(3,plan.changedVertices);
            Assert.AreEqual(before,EditorJsonUtility.ToJson(skin));Assert.AreEqual(SkinQuality.Bone1,skin.quality);
        }
        [Test]public void CopyPreservesSourceBytesFramesBindPosesAndManualAssignment()
        {
            var before=File.ReadAllBytes(AssetDatabase.GetAssetPath(mesh));var prefab=File.ReadAllBytes(AssetDatabase.GetAssetPath(source));var plan=Prepare();string path=Retain(EyeSkinInfluenceCopies.Execute(plan));var copy=AssetDatabase.LoadAssetAtPath<Mesh>(path);
            CollectionAssert.AreEqual(before,File.ReadAllBytes(AssetDatabase.GetAssetPath(mesh)));CollectionAssert.AreEqual(prefab,File.ReadAllBytes(AssetDatabase.GetAssetPath(source)));Assert.AreSame(mesh,skin.sharedMesh);
            CollectionAssert.AreEqual(mesh.vertices,copy.vertices);CollectionAssert.AreEqual(mesh.colors,copy.colors);CollectionAssert.AreEqual(mesh.uv,copy.uv);CollectionAssert.AreEqual(mesh.bindposes,copy.bindposes);CollectionAssert.AreEqual(mesh.triangles,copy.triangles);
            Assert.AreEqual(2,copy.GetBlendShapeFrameCount(0));Assert.AreEqual(50,copy.GetBlendShapeFrameWeight(0,0));Assert.AreEqual(100,copy.GetBlendShapeFrameWeight(0,1));
            Assert.IsTrue(copy.GetBonesPerVertex().All(b=>b==1));Assert.AreEqual(plan.summary,File.ReadAllText(Path.GetDirectoryName(path)+"/skin-influence-review.txt"));
            var receipt=EyeCopyHistory.Read().Single(r=>r.result==path);Assert.AreEqual("Completed; no assignment",receipt.phase);Assert.AreEqual(2,receipt.files.Length);Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));
        }
        [Test]public void ErrorThresholdBlocksCopyBeforeAnyOutput()
        {
            var plan=Prepare(.01f,new EyeBoundsRange(Clip(),0,1,2));int before=EyeCopyHistory.Read().Length;
            Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));Assert.AreEqual(before,EyeCopyHistory.Read().Length);
        }
        [Test]public void EqualWeightsUseStableBoneIndexOrder()
        {
            mesh.boneWeights=Enumerable.Repeat(new BoneWeight{boneIndex0=1,weight0=.5f,boneIndex1=0,weight1=.5f},3).ToArray();EditorUtility.SetDirty(mesh);AssetDatabase.SaveAssetIfDirty(mesh);
            string path=Retain(EyeSkinInfluenceCopies.Execute(Prepare()));Assert.IsTrue(AssetDatabase.LoadAssetAtPath<Mesh>(path).boneWeights.All(w=>w.boneIndex0==0&&w.weight0==1));
        }
        [Test]public void NoReductionAndBadToleranceAreRefused()
        {
            Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Prepare(source,skin,4,1,null));
            Assert.Throws<InvalidOperationException>(()=>Prepare(float.NaN));Assert.Throws<InvalidOperationException>(()=>Prepare(-1));
        }
        [Test]public void UnknownComponentsBlockBeforeSamplingOrCopy()
        {
            var contents=PrefabUtility.LoadPrefabContents(AssetDatabase.GetAssetPath(source));try{contents.AddComponent<Animator>();PrefabUtility.SaveAsPrefabAsset(contents,AssetDatabase.GetAssetPath(source));}finally{PrefabUtility.UnloadPrefabContents(contents);}
            source=AssetDatabase.LoadAssetAtPath<GameObject>(folder+"/source.prefab");skin=source.GetComponentInChildren<SkinnedMeshRenderer>(true);
            StringAssert.Contains("dependency",Assert.Throws<InvalidOperationException>(()=>Prepare()).Message);
        }
        [Test]public void MissingBoneAndMaterialCorrespondenceAreRefused()
        {
            skin.bones=new[]{skin.bones[0]};EditorUtility.SetDirty(skin);AssetDatabase.SaveAssets();Assert.Throws<InvalidOperationException>(()=>Prepare());
            skin.bones=new[]{source.transform.Find("BoneA"),source.transform.Find("BoneA/BoneB")};skin.sharedMaterials=Array.Empty<Material>();EditorUtility.SetDirty(skin);AssetDatabase.SaveAssets();Assert.Throws<InvalidOperationException>(()=>Prepare());
        }
        [Test]public void SourceMeshMutationAndRawClipMutationInvalidateReview()
        {
            var clip=Clip();var plan=Prepare(2,new EyeBoundsRange(clip,0,1,2));File.AppendAllText(AssetDatabase.GetAssetPath(clip),"\n# changed\n");Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));
            var other=Prepare();mesh.vertices=new[]{Vector3.one,Vector3.right,Vector3.up};EditorUtility.SetDirty(mesh);Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(other));
        }
        [Test]public void CanceledAndChangedContextPlansCannotPublish()
        {
            var plan=Prepare();EyeSkinInfluenceCopies.Cancel(plan);Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));
            var next=Prepare();Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(next,()=>false));
        }
        [Test]public void EventsRemainDataAndUnsupportedBindingsFail()
        {
            var clip=Clip();AnimationUtility.SetAnimationEvents(clip,new[]{new AnimationEvent{time=.5f,functionName="NeverRun"}});AssetDatabase.SaveAssetIfDirty(clip);
            StringAssert.Contains("ignored 1 events",Prepare(2,new EyeBoundsRange(clip,0,1,2)).summary);UnityEngine.TestTools.LogAssert.NoUnexpectedReceived();
            var bad=Clip("Body","m_Enabled",typeof(SkinnedMeshRenderer));Assert.Throws<InvalidOperationException>(()=>Prepare(2,new EyeBoundsRange(bad,0,1,2)));
        }
        [Test]public void BlendshapeSamplingRetainsAllFramesAndPoseWeightsAcrossMeshSwaps()
        {
            var clip=Clip("Body","blendShape.Raised",typeof(SkinnedMeshRenderer));AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve("Body",typeof(SkinnedMeshRenderer),"blendShape.Raised"),AnimationCurve.Linear(0,0,1,100));
            AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve("BoneA/BoneB",typeof(Transform),"m_LocalScale.z"),AnimationCurve.Linear(0,1,1,2));AssetDatabase.SaveAssetIfDirty(clip);
            var plan=Prepare(2,new EyeBoundsRange(clip,1,1,1));Assert.AreEqual(.25,plan.maximum,.0001);Assert.AreEqual(25,skin.GetBlendShapeWeight(0));Assert.AreEqual(2,mesh.GetBlendShapeFrameCount(0));
        }
        [Test]public void SourceMutationDuringImportRetainsInterruptedOutput()
        {
            var plan=Prepare();string output="";EyeSkinImportCallback.action=p=>{output=Retain(p);mesh.vertices=new[]{Vector3.one,Vector3.right,Vector3.up};EditorUtility.SetDirty(mesh);};
            Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));Assert.IsNotEmpty(output);Assert.IsTrue(File.Exists(output));StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
        [Test]public void OutputMutationDuringImportCannotBeCompleted()
        {
            var plan=Prepare();string output="";EyeSkinImportCallback.action=p=>{output=Retain(p);var m=AssetDatabase.LoadAssetAtPath<Mesh>(p);m.vertices=new[]{Vector3.one,Vector3.right,Vector3.up};EditorUtility.SetDirty(m);AssetDatabase.SaveAssetIfDirty(m);};
            Assert.Throws<InvalidOperationException>(()=>EyeSkinInfluenceCopies.Execute(plan));StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
    }
    public sealed class EyeSkinImportCallback:AssetPostprocessor
    {
        public static Action<string> action;
        static void OnPostprocessAllAssets(string[] imported,string[] deleted,string[] moved,string[] movedFrom)
        {
            if(action==null)return;foreach(string p in imported)if(p.StartsWith(EyeAvatarRepair.OutputRoot+"/",StringComparison.Ordinal)&&p.EndsWith("/skin-influence-copy.asset",StringComparison.Ordinal)){var callback=action;action=null;callback(p);break;}
        }
    }
}
