// Supplied native behavior tests: run in Unity 2022.3 EditMode, not Python.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyeSettingTransferTests
    {
        string folder;Mesh mesh;Material a,b,c;readonly List<string> outputs=new List<string>();
        [SetUp]public void Setup()
        {
            if(!Application.unityVersion.StartsWith("2022.3.",StringComparison.Ordinal))Assert.Ignore("Requires Unity 2022.3.");
            string name="EyeSettingFixture-"+Guid.NewGuid().ToString("N");AssetDatabase.CreateFolder("Assets",name);folder="Assets/"+name;
            mesh=new Mesh{name="Triangle"};mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};mesh.triangles=new[]{0,1,2};mesh.RecalculateNormals();mesh.RecalculateBounds();AssetDatabase.CreateAsset(mesh,folder+"/mesh.asset");
            var shader=Shader.Find("Standard");if(!shader)Assert.Ignore("Built-in fixture shader unavailable in this pipeline.");
            a=new Material(shader){name="Donor material"};b=new Material(shader){name="Destination material"};c=new Material(shader){name="Explicit mapped material"};
            AssetDatabase.CreateAsset(a,folder+"/a.mat");AssetDatabase.CreateAsset(b,folder+"/b.mat");AssetDatabase.CreateAsset(c,folder+"/c.mat");AssetDatabase.SaveAssets();
        }
        [TearDown]public void Cleanup()
        {EyeSettingImportCallback.action=null;foreach(string p in outputs)AssetDatabase.DeleteAsset(p);outputs.Clear();if(!string.IsNullOrEmpty(folder))AssetDatabase.DeleteAsset(folder);}
        GameObject Prefab(string name,bool donor=false,bool skinned=false)
        {
            var root=new GameObject(name);
            try {
                var anchor=new GameObject("Anchor");anchor.transform.SetParent(root.transform,false);
                var second=new GameObject("Second");second.transform.SetParent(root.transform,false);
                Renderer r;
                if(skinned){mesh.bindposes=new[]{Matrix4x4.identity,Matrix4x4.identity};mesh.boneWeights=Enumerable.Repeat(new BoneWeight{boneIndex0=0,weight0=1},3).ToArray();EditorUtility.SetDirty(mesh);AssetDatabase.SaveAssetIfDirty(mesh);var s=root.AddComponent<SkinnedMeshRenderer>();s.sharedMesh=mesh;s.rootBone=anchor.transform;s.bones=new[]{anchor.transform,second.transform};r=s;}
                else {root.AddComponent<MeshFilter>().sharedMesh=mesh;r=root.AddComponent<MeshRenderer>();}
                r.enabled=!donor;r.receiveShadows=!donor;r.sharedMaterial=donor?a:b;r.probeAnchor=anchor.transform;
                return PrefabUtility.SaveAsPrefabAsset(root,folder+"/"+name+".prefab");
            } finally {Object.DestroyImmediate(root);}
        }
        EyeSettingPlan Plan(GameObject s,GameObject d,params string[] keys)
        {return EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),keys,new Dictionary<string,Object>());}
        string Retain(string path){outputs.Add(Path.GetDirectoryName(path).Replace('\\','/'));return path;}
        EyeSettingReport Report(string path){return JsonUtility.FromJson<EyeSettingReport>(File.ReadAllText(Path.GetDirectoryName(path)+"/setting-transfer.json"));}
        [Test]public void SelectedRendererValuesPersistWhileMeshesAndSourcesStayUnchanged()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");string sh=EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(s)).sha256,dh=EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(d)).sha256;
            var plan=Plan(s,d,"enabled");string path=Retain(EyeSettingTransfers.Execute(plan));var copy=AssetDatabase.LoadAssetAtPath<GameObject>(path);
            Assert.IsFalse(copy.GetComponent<Renderer>().enabled);Assert.IsTrue(copy.GetComponent<Renderer>().receiveShadows);Assert.AreSame(b,copy.GetComponent<Renderer>().sharedMaterial);Assert.AreSame(mesh,copy.GetComponent<MeshFilter>().sharedMesh);
            Assert.IsTrue(d.GetComponent<Renderer>().enabled);Assert.AreEqual(sh,EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(s)).sha256);Assert.AreEqual(dh,EyeShaderFileEvidence.Read(AssetDatabase.GetAssetPath(d)).sha256);
            var report=Report(path);Assert.AreEqual("enabled",report.rows.Single().key);Assert.AreEqual("copy_observed_no_assignment",report.status);
            var receipt=EyeCopyHistory.Read().Single(r=>r.id==report.receiptId);Assert.AreEqual("Completed; no assignment",receipt.phase);Assert.AreEqual(2,receipt.files.Length);Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan));
        }
        [Test]public void MissingMaterialMappingIsRejectedAndExplicitMaterialWinsOverDonor()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");Assert.Throws<InvalidOperationException>(()=>Plan(s,d,"material[0]"));
            var mappings=new Dictionary<string,Object>{{"material[0]",c}};
            var plan=EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),new[]{"material[0]"},mappings);
            mappings["material[0]"]=a;string path=Retain(EyeSettingTransfers.Execute(plan));
            Assert.AreSame(c,AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<Renderer>().sharedMaterial);Assert.AreSame(b,d.GetComponent<Renderer>().sharedMaterial);
        }
        [Test]public void AnchorMappingTargetsCloneByObjectIdentityAndRejectsDonorObject()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var maps=new Dictionary<string,Object>{{"probeAnchor",s.transform.Find("Anchor")}};
            Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),new[]{"probeAnchor"},maps));
            maps["probeAnchor"]=d.transform.Find("Second");var plan=EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),new[]{"probeAnchor"},maps);
            var copy=AssetDatabase.LoadAssetAtPath<GameObject>(Retain(EyeSettingTransfers.Execute(plan)));Assert.AreSame(copy.transform.Find("Second"),copy.GetComponent<Renderer>().probeAnchor);Assert.AreNotSame(d.transform.Find("Second"),copy.GetComponent<Renderer>().probeAnchor);
        }
        [Test]public void ExplicitNullClearsOnlySelectedReference()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var plan=EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),new[]{"probeAnchor"},new Dictionary<string,Object>{{"probeAnchor",null}});
            var copy=AssetDatabase.LoadAssetAtPath<GameObject>(Retain(EyeSettingTransfers.Execute(plan)));Assert.IsNull(copy.GetComponent<Renderer>().probeAnchor);Assert.IsNotNull(d.GetComponent<Renderer>().probeAnchor);Assert.AreSame(b,copy.GetComponent<Renderer>().sharedMaterial);
        }
        [Test]public void CanceledAndChangedContextPlansCannotWrite()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var plan=Plan(s,d,"enabled");plan.Cancel();Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan));
            plan=Plan(s,d,"enabled");Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan,()=>false));
        }
        [Test]public void DraftSelectionMutationDoesNotChangeFrozenReview()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var keys=new List<string>{"enabled"};
            var plan=EyeSettingTransfers.PrepareRenderer(s,s.GetComponent<Renderer>(),d,d.GetComponent<Renderer>(),keys,new Dictionary<string,Object>());keys.Add("receiveShadows");
            var copy=AssetDatabase.LoadAssetAtPath<GameObject>(Retain(EyeSettingTransfers.Execute(plan)));Assert.IsFalse(copy.GetComponent<Renderer>().enabled);Assert.IsTrue(copy.GetComponent<Renderer>().receiveShadows);
        }
        [Test]public void IncompatibleTypesAndUnsupportedSettingsAreRejected()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination",skinned:true);
            Assert.Throws<InvalidOperationException>(()=>Plan(s,d,"enabled"));Assert.Throws<InvalidOperationException>(()=>Plan(s,s,"sharedMesh"));Assert.Throws<InvalidOperationException>(()=>Plan(s,s,"enabled","enabled"));
            Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.PrepareImporter(s,s,new[]{"isReadable"}));
        }
        [Test]public void SameCountsWithDifferentBoneOrderProduceDifferentInventory()
        {
            var s=Prefab("Skin",skinned:true);var before=EyeSettingEvidence.Inventory(s);var skin=s.GetComponent<SkinnedMeshRenderer>();skin.bones=skin.bones.Reverse().ToArray();var after=EyeSettingEvidence.Inventory(s);
            Assert.AreEqual(before.bones.Length,after.bones.Length);CollectionAssert.AreNotEqual(before.bones,after.bones);CollectionAssert.AreEqual(before.streams,after.streams);
        }
        [Test]public void SourceBytesChangedWithoutReimportInvalidateReview()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var plan=Plan(s,d,"enabled");File.AppendAllText(AssetDatabase.GetAssetPath(d),"\n# external edit\n");
            Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan));
        }
        GameObject Model(string name,Action<ModelImporter> configure)
        {
            var files=AssetDatabase.FindAssets("setting-transfer").Select(AssetDatabase.GUIDToAssetPath).Where(p=>p.EndsWith("/Tests/Fixtures/setting-transfer.fbx.bytes",StringComparison.Ordinal)).ToArray();
            Assert.AreEqual(1,files.Length,"Install the inert FBX fixture supplied with these tests.");
            string path=folder+"/"+name+".fbx";File.WriteAllBytes(path,File.ReadAllBytes(files[0]));AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
            var importer=AssetImporter.GetAtPath(path) as ModelImporter;Assert.IsNotNull(importer);importer.materialImportMode=ModelImporterMaterialImportMode.None;configure(importer);EditorUtility.SetDirty(importer);importer.SaveAndReimport();
            return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }
        [Test]public void ImporterTransferReimportsCopyAndPreservesBothSourceFilesAndMetadata()
        {
            var s=Model("Readable",i=>i.isReadable=true);var d=Model("Destination",i=>i.isReadable=false);string sp=AssetDatabase.GetAssetPath(s),dp=AssetDatabase.GetAssetPath(d);
            string[] files={sp,sp+".meta",dp,dp+".meta"};var hashes=files.Select(p=>EyeShaderFileEvidence.Read(p).sha256).ToArray();
            var plan=EyeSettingTransfers.PrepareImporter(s,d,new[]{"isReadable"});StringAssert.Contains("INDIVIDUAL REVIEW",plan.summary);string path=Retain(EyeSettingTransfers.Execute(plan));
            Assert.IsTrue(((ModelImporter)AssetImporter.GetAtPath(path)).isReadable);Assert.IsFalse(((ModelImporter)AssetImporter.GetAtPath(dp)).isReadable);Assert.AreEqual(hashes[2],EyeShaderFileEvidence.Read(path).sha256);
            CollectionAssert.AreEqual(hashes,files.Select(p=>EyeShaderFileEvidence.Read(p).sha256).ToArray());var report=Report(path);Assert.IsNotEmpty(report.before.streams);Assert.IsNotEmpty(report.after.submeshes);CollectionAssert.AreNotEqual(report.before.streams,report.after.streams);Assert.AreEqual("ModelImporter",report.kind);
        }
        [Test]public void ImporterCompressionAndHierarchyPoliciesNeedExplicitSelection()
        {
            var s=Model("Donor",i=>{i.meshCompression=ModelImporterMeshCompression.High;i.preserveHierarchy=true;i.optimizeMeshVertices=true;});var d=Model("Destination",i=>{i.meshCompression=ModelImporterMeshCompression.Off;i.preserveHierarchy=false;i.optimizeMeshVertices=false;});
            var plan=EyeSettingTransfers.PrepareImporter(s,d,new[]{"meshCompression"});string path=Retain(EyeSettingTransfers.Execute(plan));var copy=(ModelImporter)AssetImporter.GetAtPath(path);
            Assert.AreEqual(ModelImporterMeshCompression.High,copy.meshCompression);Assert.IsFalse(copy.preserveHierarchy);Assert.IsFalse(copy.optimizeMeshVertices);Assert.AreEqual("meshCompression",Report(path).rows.Single().key);
            Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.PrepareImporter(s,d,new[]{"sourceAvatar"}));
        }
        [Test]public void CopyImportCallbackCannotApplyCanceledPlan()
        {
            var s=Prefab("Donor",true);var d=Prefab("Destination");var plan=Plan(s,d,"enabled");string output="";
            EyeSettingImportCallback.action=p=>{output=p;Retain(p);plan.Cancel();};Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan));
            Assert.IsNotEmpty(output);Assert.IsTrue(d.GetComponent<Renderer>().enabled);StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
        [Test]public void ImportCallbackChangingUnselectedPolicyInterruptsCopy()
        {
            var s=Model("Donor",i=>i.isReadable=true);var d=Model("Destination",i=>i.isReadable=false);var plan=EyeSettingTransfers.PrepareImporter(s,d,new[]{"isReadable"});string output="";
            EyeSettingImportCallback.action=p=>{output=p;Retain(p);var importer=(ModelImporter)AssetImporter.GetAtPath(p);importer.globalScale=2;EditorUtility.SetDirty(importer);importer.SaveAndReimport();};
            Assert.Throws<InvalidOperationException>(()=>EyeSettingTransfers.Execute(plan));Assert.IsNotEmpty(output);StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
    }
    public sealed class EyeSettingImportCallback:AssetPostprocessor
    {
        public static Action<string> action;
        static void OnPostprocessAllAssets(string[] imported,string[] deleted,string[] moved,string[] movedFrom)
        {
            if(action==null)return;
            foreach(string path in imported)if(path.StartsWith(EyeAvatarRepair.OutputRoot+"/",StringComparison.Ordinal)&&(path.EndsWith(".prefab",StringComparison.Ordinal)||path.EndsWith(".fbx",StringComparison.Ordinal))) {
                var callback=action;action=null;callback(path);break;
            }
        }
    }
}
