// Run in Unity EditMode. These checks are not executed by Python regression.
using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyePerformanceReportTests
    {
        const string Avatar = "avtr_11111111-1111-1111-1111-111111111111";
        public sealed class Stats
        {
            public int? polyCount = 12;
            public int? lightCount = 0;
            public float? textureMegabytes = null;
            public bool? particleTrailsEnabled = false;
            public long downloadSizeBytes = 999;
            public Phys? physBone = new Phys { componentCount = 0 };
        }
        public struct Phys { public int? componentCount; }
        public sealed class WrongType { public bool polyCount = true; }
        static Dictionary<string, object> Report(object stats)
        { return EyePerformanceReport.Build(stats, Avatar, "android", "3.10.2", "3.10.2", "2022.3.22f1", DateTimeOffset.Parse("2026-10-05T00:00:00Z")); }

        [Test] public void MissingAndZeroAreDistinctAndSizesRemainUnknown()
        {
            var report = Report(new Stats()); var stats = (Dictionary<string, object>)report["stats"];
            Assert.AreEqual(12L, stats["polyCount"]); Assert.AreEqual(0L, stats["lightCount"]);
            Assert.IsNull(stats["textureMegabytes"]); Assert.IsNull(stats["contactCount"]);
            Assert.IsNull(stats["downloadSizeBytes"]); Assert.IsNull(stats["uncompressedSizeBytes"]);
            Assert.AreEqual(false, stats["particleTrailsEnabled"]);
            Assert.AreEqual(0L, ((Dictionary<string, object>)stats["physBone"])["componentCount"]);
            Assert.IsNull(report["reported_rank"]); Assert.AreEqual("source", report["measurement_stage"]);
            Assert.AreEqual("android", report["platform"]);
            Assert.AreEqual("3.10.2", report["sdk_base_version"]);
            StringAssert.Contains("\"textureMegabytes\":null", EyeJson.Write(report));
        }
        [Test] public void InvalidSdkValuesNeverBecomeMeasurements()
        {
            Assert.Throws<InvalidOperationException>(() => Report(new Stats { polyCount = -1 }));
            Assert.Throws<InvalidOperationException>(() => Report(new Stats { textureMegabytes = float.NaN }));
            Assert.Throws<InvalidOperationException>(() => Report(new WrongType()));
            Assert.Throws<InvalidOperationException>(() => Report(new object()));
        }
        [Test] public void CaptureIdentityAndPackageVersionsAreRequired()
        {
            Assert.Throws<InvalidOperationException>(() => EyePerformanceReport.Build(new Stats(), "", "android", "3.10.2", "3.10.2", "2022.3", DateTimeOffset.UtcNow));
            Assert.Throws<InvalidOperationException>(() => EyePerformanceReport.Build(new Stats(), Avatar, "android", "unknown", "3.10.2", "2022.3", DateTimeOffset.UtcNow));
            Assert.Throws<InvalidOperationException>(() => EyePerformanceReport.Build(new Stats(), Avatar, "linux", "3.10.2", "3.10.2", "2022.3", DateTimeOffset.UtcNow));
        }
    }
}
