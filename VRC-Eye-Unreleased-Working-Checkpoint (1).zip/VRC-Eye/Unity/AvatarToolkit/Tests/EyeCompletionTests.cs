using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using Object=UnityEngine.Object;

namespace VrcEye.AvatarToolkit.Tests
{
    public class EyeCompletionTests
    {
        string folder;readonly List<string> outputs=new List<string>();Material material;
        [SetUp]public void Setup()
        {
            string name="EyeCompletionFixture-"+Guid.NewGuid().ToString("N");AssetDatabase.CreateFolder("Assets",name);folder="Assets/"+name;
        }
        [TearDown]public void Cleanup()
        {
            EyeCompletionImportCallback.action=null;
            if(material&&!AssetDatabase.Contains(material))Object.DestroyImmediate(material);
            foreach(var output in outputs)AssetDatabase.DeleteAsset(output);outputs.Clear();AssetDatabase.DeleteAsset(folder);
        }
        Material Source(string name="Standard")
        {
            var shader=Shader.Find(name);if(!shader)Assert.Ignore("Built-in fixture shader unavailable in this pipeline.");
            material=new Material(shader);return material;
        }
        string Retain(string path)
        {outputs.Add(System.IO.Path.GetDirectoryName(path).Replace('\\','/'));return path;}
        [Test]public void TypedColorCopyPreservesSourceAndDropsUnmappedData()
        {
            var source=Source();source.SetColor("_Color",Color.magenta);source.renderQueue=2999;
            var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);profile.properties=new[]{new EyePropertyMap{source="_Color",target="_Color"}};
            var before=EditorJsonUtility.ToJson(source);string path=Retain(EyeMaterialMapping.Execute(EyeMaterialMapping.Prepare(source,source.shader,profile)));
            var copy=AssetDatabase.LoadAssetAtPath<Material>(path);Assert.AreEqual(Color.magenta,copy.GetColor("_Color"));Assert.AreEqual(before,EditorJsonUtility.ToJson(source));Assert.AreNotEqual(2999,copy.renderQueue);
        }
        [Test]public void TypeMismatchNeverCreatesAPlan()
        {
            var source=Source();var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);profile.properties=new[]{new EyePropertyMap{source="_Color",target="_Glossiness"}};
            Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.Prepare(source,source.shader,profile));
        }
        [Test]public void TextureMappingPreservesOffsetAndScale()
        {
            var source=Source();var texture=new Texture2D(2,2);AssetDatabase.CreateAsset(texture,folder+"/texture.asset");
            source.SetTexture("_MainTex",texture);source.SetTextureScale("_MainTex",new Vector2(2,3));source.SetTextureOffset("_MainTex",new Vector2(.2f,.7f));
            var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);profile.properties=new[]{new EyePropertyMap{source="_MainTex",target="_MainTex"}};
            var copy=EyeMaterialMapping.BuildCopy(EyeMaterialMapping.Prepare(source,source.shader,profile));
            try {Assert.AreSame(texture,copy.GetTexture("_MainTex"));Assert.AreEqual(new Vector2(2,3),copy.GetTextureScale("_MainTex"));Assert.AreEqual(new Vector2(.2f,.7f),copy.GetTextureOffset("_MainTex"));}
            finally {Object.DestroyImmediate(copy);}
        }
        [Test]public void MutatingTheDraftDoesNotChangeReviewedTransfer()
        {
            var source=Source();var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);profile.renderQueue=true;source.renderQueue=2999;
            var plan=EyeMaterialMapping.Prepare(source,source.shader,profile);profile.renderQueue=false;
            var copy=EyeMaterialMapping.BuildCopy(plan);try {Assert.AreEqual(2999,copy.renderQueue);}finally {Object.DestroyImmediate(copy);}
        }
        [Test]public void ChangedMaterialRejectsReviewedCopy()
        {
            var source=Source();var plan=EyeMaterialMapping.Prepare(source,source.shader,EyeMaterialMapping.EmptyProfile(source,source.shader));source.SetColor("_Color",Color.red);
            Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.Execute(plan));
        }
        [Test]public void RepeatedTargetMappingIsRejected()
        {
            var source=Source();var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);
            profile.properties=new[]{new EyePropertyMap{source="_Color",target="_Color"},new EyePropertyMap{source="_EmissionColor",target="_Color"}};
            Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.Prepare(source,source.shader,profile));
        }
        [Test]public void WrongShaderVersionProfileIsRejected()
        {
            var source=Source();var profile=EyeMaterialMapping.EmptyProfile(source,source.shader);profile.targetShader="changed";
            Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.Prepare(source,source.shader,profile));
        }
        [Test]public void DiagnosticReadDoesNotChangeSource()
        {
            var source=Source();string before=EditorJsonUtility.ToJson(source);var report=EyeMaterialMapping.Diagnostics(source);
            StringAssert.Contains("Editor graphics API",report);Assert.AreEqual(before,EditorJsonUtility.ToJson(source));
        }
        AnimatorController Controller(out AnimationClip clip)
        {
            clip=new AnimationClip{name="Original"};clip.SetCurve("Child",typeof(Transform),"m_LocalPosition.x",AnimationCurve.Linear(0,0,1,1));AssetDatabase.CreateAsset(clip,folder+"/original.anim");
            var controller=AnimatorController.CreateAnimatorControllerAtPath(folder+"/original.controller");controller.AddParameter("Speed",AnimatorControllerParameterType.Float);
            var state=controller.layers[0].stateMachine.AddState("Idle");state.motion=clip;state.speed=1.25f;controller.layers[0].stateMachine.defaultState=state;
            EditorUtility.SetDirty(controller);AssetDatabase.SaveAssetIfDirty(controller);return controller;
        }
        [Test]public void ControllerClosureCopiesClipAndPreservesStateParameters()
        {
            AnimationClip clip;var source=Controller(out clip);var before=EditorJsonUtility.ToJson(source);
            string path=Retain(EyeControllerCopies.Execute(EyeControllerCopies.Prepare(source)));
            AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
            var copy=AssetDatabase.LoadAssetAtPath<AnimatorController>(path);Assert.AreNotSame(source,copy);
            Assert.AreEqual("Speed",copy.parameters.Single().name);Assert.AreEqual(1.25f,copy.layers[0].stateMachine.defaultState.speed);
            Assert.AreNotSame(clip,copy.animationClips.Single());Assert.AreEqual(before,EditorJsonUtility.ToJson(source));
            Assert.IsFalse(EyeControllerCopies.Closure(copy).Contains(clip));
        }
        [Test]public void ClipReplacementUsesAnIndependentReplacementCopy()
        {
            AnimationClip old;var source=Controller(out old);var replacement=new AnimationClip{name="Replacement"};AssetDatabase.CreateAsset(replacement,folder+"/replacement.anim");
            string path=Retain(EyeControllerCopies.Execute(EyeControllerCopies.Prepare(source,old,replacement)));
            var copy=AssetDatabase.LoadAssetAtPath<AnimatorController>(path);Assert.AreNotSame(replacement,copy.animationClips.Single());Assert.AreEqual("Replacement",copy.animationClips.Single().name);Assert.AreSame(old,source.animationClips.Single());
        }
        [Test]public void OverrideControllerUsesClonedBaseAndClonedOverrides()
        {
            AnimationClip original;var source=Controller(out original);var replacement=new AnimationClip{name="Override"};AssetDatabase.CreateAsset(replacement,folder+"/override.anim");
            var wrapper=new AnimatorOverrideController(source);wrapper[original]=replacement;AssetDatabase.CreateAsset(wrapper,folder+"/wrapper.overrideController");
            string path=Retain(EyeControllerCopies.Execute(EyeControllerCopies.Prepare(wrapper)));
            var copy=AssetDatabase.LoadAssetAtPath<AnimatorOverrideController>(path);Assert.AreNotSame(source,copy.runtimeAnimatorController);Assert.AreNotSame(replacement,copy.animationClips.Single());Assert.AreSame(source,wrapper.runtimeAnimatorController);
        }
        [Test]public void ChangedDependencyInvalidatesControllerReview()
        {
            AnimationClip clip;var source=Controller(out clip);var plan=EyeControllerCopies.Prepare(source);clip.frameRate=12;
            Assert.Throws<InvalidOperationException>(()=>EyeControllerCopies.Execute(plan));
        }
        [Test]public void UnrelatedReplacementSourceIsRejected()
        {
            AnimationClip clip;var source=Controller(out clip);var unrelated=new AnimationClip();AssetDatabase.CreateAsset(unrelated,folder+"/unrelated.anim");
            Assert.Throws<InvalidOperationException>(()=>EyeControllerCopies.Prepare(source,unrelated,clip));
        }
        [Test]public void TangentRepairCopiesNormalsUvAndTopology()
        {
            var root=new GameObject("Tangent fixture");var mesh=new Mesh();root.AddComponent<MeshFilter>().sharedMesh=mesh;
            try {
                mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};mesh.triangles=new[]{0,1,2};mesh.uv=new[]{Vector2.zero,Vector2.right,Vector2.up};mesh.RecalculateNormals();
                string path=Retain(EyeAvatarRepair.Execute(EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingTangents)));var copy=AssetDatabase.LoadAssetAtPath<Mesh>(path);
                Assert.AreEqual(3,copy.tangents.Length);Assert.AreEqual(0,mesh.tangents.Length);CollectionAssert.AreEqual(mesh.triangles,copy.triangles);Assert.AreSame(mesh,root.GetComponent<MeshFilter>().sharedMesh);
            }finally {Object.DestroyImmediate(root);Object.DestroyImmediate(mesh);}
        }
        [Test]public void DegenerateUvRejectsTangentRepair()
        {
            var root=new GameObject("Bad UV fixture");var mesh=new Mesh();root.AddComponent<MeshFilter>().sharedMesh=mesh;
            try {mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.up};mesh.triangles=new[]{0,1,2};mesh.uv=new[]{Vector2.zero,Vector2.zero,Vector2.zero};mesh.RecalculateNormals();Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingTangents));}
            finally {Object.DestroyImmediate(root);Object.DestroyImmediate(mesh);}
        }
        GameObject Prefab(string name,Action<GameObject> configure)
        {
            var root=new GameObject(name);
            try {configure(root);return PrefabUtility.SaveAsPrefabAsset(root,folder+"/"+name+".prefab");}
            finally {Object.DestroyImmediate(root);}
        }
        [Test]public void ComponentCopyReloadsValuesWithoutChangingEitherSource()
        {
            var source=Prefab("Source",go=>{var collider=go.AddComponent<BoxCollider>();collider.center=new Vector3(1,2,3);collider.size=new Vector3(4,5,6);collider.isTrigger=true;});
            var target=Prefab("Target",go=>{});string before=EditorJsonUtility.ToJson(source.GetComponent<BoxCollider>());
            var plan=EyeComponentCopies.Prepare(source,source.GetComponent<BoxCollider>(),target,target,new Dictionary<string,Object>());
            string path=Retain(EyeComponentCopies.Execute(plan));var output=AssetDatabase.LoadAssetAtPath<GameObject>(path);var copied=output.GetComponent<BoxCollider>();
            Assert.AreEqual(new Vector3(1,2,3),copied.center);Assert.AreEqual(new Vector3(4,5,6),copied.size);Assert.IsTrue(copied.isTrigger);
            Assert.IsNull(target.GetComponent<BoxCollider>());Assert.AreEqual(before,EditorJsonUtility.ToJson(source.GetComponent<BoxCollider>()));
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.Execute(plan));
        }
        [Test]public void MeshFilterCopyRetainsReviewedExternalMesh()
        {
            var mesh=new Mesh{name="Shared mesh"};AssetDatabase.CreateAsset(mesh,folder+"/shared.asset");
            var source=Prefab("Source",go=>go.AddComponent<MeshFilter>().sharedMesh=mesh);var target=Prefab("Target",go=>{});
            string path=Retain(EyeComponentCopies.Execute(EyeComponentCopies.Prepare(source,source.GetComponent<MeshFilter>(),target,target,new Dictionary<string,Object>())));
            Assert.AreSame(mesh,AssetDatabase.LoadAssetAtPath<GameObject>(path).GetComponent<MeshFilter>().sharedMesh);
        }
        [Test]public void SkinBonesRequireExplicitDestinationMappingsAndSurviveReload()
        {
            var source=Prefab("Source",go=>{var bone=new GameObject("Bone");bone.transform.SetParent(go.transform,false);var skin=go.AddComponent<SkinnedMeshRenderer>();skin.rootBone=bone.transform;skin.bones=new[]{bone.transform};});
            var target=Prefab("Target",go=>{var bone=new GameObject("NewBone");bone.transform.SetParent(go.transform,false);});
            var skinSource=source.GetComponent<SkinnedMeshRenderer>();var references=EyeComponentCopies.RequiredMappings(skinSource);
            Assert.GreaterOrEqual(references.Length,2);
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.Prepare(source,skinSource,target,target,new Dictionary<string,Object>()));
            var mappings=references.ToDictionary(r=>r.property,r=>(Object)target.transform.GetChild(0));
            string path=Retain(EyeComponentCopies.Execute(EyeComponentCopies.Prepare(source,skinSource,target,target,mappings)));
            var copy=AssetDatabase.LoadAssetAtPath<GameObject>(path);var skin=copy.GetComponent<SkinnedMeshRenderer>();
            Assert.AreSame(copy.transform.GetChild(0),skin.rootBone);Assert.AreSame(copy.transform.GetChild(0),skin.bones[0]);Assert.AreNotSame(source.transform.GetChild(0),skin.rootBone);
        }
        [Test]public void ChangedDestinationInvalidatesComponentReview()
        {
            var source=Prefab("Source",go=>go.AddComponent<BoxCollider>());var target=Prefab("Target",go=>{});
            var plan=EyeComponentCopies.Prepare(source,source.GetComponent<BoxCollider>(),target,target,new Dictionary<string,Object>());
            target.transform.localScale=Vector3.one*2;
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.Execute(plan));
        }
        [Test]public void AmbiguousDestinationNamesAndExistingComponentsStopBeforeCopy()
        {
            var source=Prefab("Source",go=>go.AddComponent<BoxCollider>());
            var target=Prefab("Target",go=>{new GameObject("Repeat").transform.SetParent(go.transform,false);new GameObject("Repeat").transform.SetParent(go.transform,false);});
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.Prepare(source,source.GetComponent<BoxCollider>(),target,target,new Dictionary<string,Object>()));
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.Prepare(source,source.GetComponent<BoxCollider>(),source,source,new Dictionary<string,Object>()));
        }
        [Test]public void TransformIsInspectableButCannotBeCopied()
        {
            var source=Prefab("Source",go=>{});StringAssert.Contains("Transform",EyeComponentCopies.Inspect(source));
            Assert.Throws<InvalidOperationException>(()=>EyeComponentCopies.RequiredMappings(source.transform));
        }
        AnimationClip FloatClip(params string[] properties)
        {
            var clip=new AnimationClip{name="Source clip"};
            foreach(var property in properties)AnimationUtility.SetEditorCurve(clip,EditorCurveBinding.FloatCurve("Old",typeof(Transform),property),AnimationCurve.Linear(0,1,2,3));
            AnimationUtility.SetAnimationEvents(clip,new[]{new AnimationEvent{time=.5f,functionName="RetainedButNeverExecuted",intParameter=7}});
            AssetDatabase.CreateAsset(clip,folder+"/curves.anim");return clip;
        }
        [Test]public void AnimationPropertyMapPreservesKeyframesEventsAndSource()
        {
            var target=Prefab("Target",go=>{});var clip=FloatClip("m_LocalPosition.x");var binding=EyeAnimationCopies.Bindings(clip).Single();
            var destination=EyeAnimationCopies.Targets(target).Single(b=>b.path==""&&b.type==typeof(Transform)&&b.propertyName=="m_LocalPosition.y");
            string before=EditorJsonUtility.ToJson(clip);var plan=EyeAnimationCopies.Prepare(clip,target,new[]{new EyeBindingMap(binding,destination)});
            string path=Retain(EyeAnimationCopies.Execute(plan));var copy=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
            CollectionAssert.AreEqual(AnimationUtility.GetEditorCurve(clip,binding).keys,AnimationUtility.GetEditorCurve(copy,destination).keys);
            Assert.AreEqual("RetainedButNeverExecuted",AnimationUtility.GetAnimationEvents(copy).Single().functionName);Assert.AreEqual(before,EditorJsonUtility.ToJson(clip));
            Assert.Throws<InvalidOperationException>(()=>EyeAnimationCopies.Execute(plan));
        }
        [Test]public void AnimationRejectsMissingAndCollidingTargets()
        {
            var target=Prefab("Target",go=>{});var clip=FloatClip("m_LocalPosition.x","m_LocalPosition.y");var bindings=EyeAnimationCopies.Bindings(clip);
            var destination=EyeAnimationCopies.Targets(target).Single(b=>b.path==""&&b.type==typeof(Transform)&&b.propertyName=="m_LocalPosition.z");
            Assert.Throws<InvalidOperationException>(()=>EyeAnimationCopies.Prepare(clip,target,bindings.Select(b=>new EyeBindingMap(b,destination))));
            destination.propertyName="missingProperty";
            Assert.Throws<InvalidOperationException>(()=>EyeAnimationCopies.Prepare(clip,target,bindings.Select(b=>new EyeBindingMap(b,destination))));
        }
        [Test]public void AnimationReferenceCurveUsesReviewedSavedAssetReplacement()
        {
            var first=Source();AssetDatabase.CreateAsset(first,folder+"/first.mat");var second=new Material(first);AssetDatabase.CreateAsset(second,folder+"/second.mat");
            var target=Prefab("Target",go=>go.AddComponent<MeshRenderer>().sharedMaterial=first);
            var destination=EyeAnimationCopies.Targets(target).Single(b=>b.isPPtrCurve&&b.propertyName=="m_Materials.Array.data[0]");
            var original=destination;original.path="Old";
            var clip=new AnimationClip();AnimationUtility.SetObjectReferenceCurve(clip,original,new[]{new ObjectReferenceKeyframe{time=0,value=first},new ObjectReferenceKeyframe{time=1,value=null}});AssetDatabase.CreateAsset(clip,folder+"/objects.anim");
            var plan=EyeAnimationCopies.Prepare(clip,target,new[]{new EyeBindingMap(original,destination)},new Dictionary<Object,Object>{{first,second}});
            var copy=AssetDatabase.LoadAssetAtPath<AnimationClip>(Retain(EyeAnimationCopies.Execute(plan)));
            Assert.AreSame(second,AnimationUtility.GetObjectReferenceCurve(copy,destination)[0].value);Assert.IsNull(AnimationUtility.GetObjectReferenceCurve(copy,destination)[1].value);
            Assert.AreSame(first,AnimationUtility.GetObjectReferenceCurve(clip,original)[0].value);Assert.AreSame(first,target.GetComponent<MeshRenderer>().sharedMaterial);
        }
        [Test]public void AnimationRejectsChangedTargetAndAmbiguousPaths()
        {
            var target=Prefab("Target",go=>{});var clip=FloatClip("m_LocalPosition.x");var binding=EyeAnimationCopies.Bindings(clip).Single();
            var destination=EyeAnimationCopies.Targets(target).Single(b=>b.path==""&&b.type==typeof(Transform)&&b.propertyName=="m_LocalPosition.x");
            var plan=EyeAnimationCopies.Prepare(clip,target,new[]{new EyeBindingMap(binding,destination)});target.transform.localScale=Vector3.one*2;
            Assert.Throws<InvalidOperationException>(()=>EyeAnimationCopies.Execute(plan));
            var ambiguous=Prefab("Ambiguous",go=>{new GameObject("Child").transform.SetParent(go.transform,false);new GameObject("Child").transform.SetParent(go.transform,false);});
            Assert.Throws<InvalidOperationException>(()=>EyeAnimationCopies.Targets(ambiguous));
        }
        [Test]public void ControllerRejectsConflictingParameterNames()
        {
            AnimationClip clip;var source=Controller(out clip);
            source.parameters=new[]{new AnimatorControllerParameter{name="Repeated",type=AnimatorControllerParameterType.Float},new AnimatorControllerParameter{name="Repeated",type=AnimatorControllerParameterType.Bool}};
            Assert.Throws<InvalidOperationException>(()=>EyeControllerCopies.Prepare(source));
        }
        [Test]public void ShaderObservationRecordsContextWithoutInventingCompilation()
        {
            var source=Source();string path=folder+"/observation.json",before=EditorJsonUtility.ToJson(source);
            EyeMaterialMapping.ExportDiagnostics(source,path,false);
            var observation=JsonUtility.FromJson<EyeShaderObservation>(System.IO.File.ReadAllText(path));
            Assert.AreEqual(Application.unityVersion,observation.unity);Assert.AreEqual(EyeMaterialMapping.ShaderIdentity(source.shader),observation.shaderIdentity);Assert.IsFalse(observation.compilationRequested);
            StringAssert.Contains("other target builds",observation.scope);Assert.AreEqual(before,EditorJsonUtility.ToJson(source));
            Assert.Throws<System.IO.IOException>(()=>EyeMaterialMapping.ExportDiagnostics(source,path,false));
        }
        [Test]public void CopyHistorySurvivesReloadAndDetectsChangedOutput()
        {
            var source=Source();string path=Retain(EyeMaterialMapping.Execute(EyeMaterialMapping.Prepare(source,source.shader,EyeMaterialMapping.EmptyProfile(source,source.shader))));
            var receipt=EyeCopyHistory.Read().Single(r=>r.result==path);Assert.AreEqual("Completed; no assignment",receipt.phase);Assert.AreEqual(1,receipt.files.Length);
            StringAssert.Contains("still matches",EyeCopyHistory.Report(receipt));
            var copied=AssetDatabase.LoadAssetAtPath<Material>(path);copied.renderQueue=2888;EditorUtility.SetDirty(copied);AssetDatabase.SaveAssetIfDirty(copied);
            StringAssert.Contains("changed/unavailable",EyeCopyHistory.Report(EyeCopyHistory.Read().Single(r=>r.id==receipt.id)));
        }
        [Test]public void InterruptedWriteKeepsDurableIntentAndPartialOutput()
        {
            string output=EyeAvatarRepair.OutputRoot+"/"+Guid.NewGuid().ToString("N");
            if(!AssetDatabase.IsValidFolder(EyeAvatarRepair.OutputRoot))AssetDatabase.CreateFolder("Assets","VRC Eye Repairs");
            AssetDatabase.CreateFolder(EyeAvatarRepair.OutputRoot,System.IO.Path.GetFileName(output));outputs.Add(output);string path=output+"/partial.asset";
            using(var history=EyeCopyHistory.Begin("Interrupted fixture","fixture","No assignment")) {
                EyeCopyHistory.Before(path);System.IO.File.WriteAllText(path,"partial output");
            }
            var receipt=EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==path));
            StringAssert.StartsWith("Interrupted",receipt.phase);Assert.AreEqual("Writing",receipt.files.Single().phase);Assert.IsTrue(System.IO.File.Exists(path));
        }
        [Test]public void PublishedMaterialComparisonRejectsTinyColorChanges()
        {
            var expected=Source();expected.SetColor("_Color",new Color(.1f,.2f,.3f,1));var actual=new Material(expected);
            try {
                EyeMaterialMapping.VerifyCopy(expected,actual);
                actual.SetColor("_Color",new Color(.1000001f,.2f,.3f,1));
                Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.VerifyCopy(expected,actual));
            } finally {Object.DestroyImmediate(actual);}
        }
        [Test]public void PublishedMaterialComparisonRejectsChangedTextureTransformAndQueue()
        {
            var expected=Source();var actual=new Material(expected);
            try {
                actual.SetTextureOffset("_MainTex",new Vector2(.1f,0));Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.VerifyCopy(expected,actual));
                actual.SetTextureOffset("_MainTex",expected.GetTextureOffset("_MainTex"));actual.renderQueue=2999;
                Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.VerifyCopy(expected,actual));
            } finally {Object.DestroyImmediate(actual);}
        }
        [Test]public void ShaderFileEvidenceIncludesSavedMaterialAndMetadata()
        {
            var source=Source();AssetDatabase.CreateAsset(source,folder+"/source.mat");AssetDatabase.SaveAssetIfDirty(source);
            var evidence=EyeShaderFileEvidence.Capture(source);
            Assert.IsTrue(evidence.files.Any(f=>f.path==folder+"/source.mat"));Assert.IsTrue(evidence.files.Any(f=>f.path==folder+"/source.mat.meta"));
            Assert.IsTrue(evidence.files.Any(f=>f.path=="ProjectSettings/ProjectVersion.txt"));
            Assert.IsTrue(EyeShaderFileEvidence.Saved(source));
            source.renderQueue=2888;EditorUtility.SetDirty(source);Assert.IsFalse(EyeShaderFileEvidence.Saved(source));
        }
        [Test]public void ShaderFileEvidenceRefusesEscapingPathsAndDetectsChangedBytes()
        {
            Assert.Throws<System.IO.IOException>(()=>EyeShaderFileEvidence.Read("Assets/../../outside.txt"));
            string path=folder+"/dependency.hlsl";System.IO.File.WriteAllText(path,"first");
            var before=EyeShaderFileEvidence.Read(path);System.IO.File.WriteAllText(path,"other");
            Assert.AreNotEqual(before.sha256,EyeShaderFileEvidence.Read(path).sha256);
        }
        [Test]public void ShaderObservationHasStructuredPassesAndExplicitUnsavedSource()
        {
            var source=Source();string path=folder+"/structured-observation.json";
            EyeMaterialMapping.ExportDiagnostics(source,path,false);
            var observation=JsonUtility.FromJson<EyeShaderObservation>(System.IO.File.ReadAllText(path));
            Assert.AreEqual(2,observation.schema);Assert.IsFalse(observation.sourceSaved);Assert.IsFalse(observation.compilationRequested);
            Assert.AreEqual(source.passCount,observation.passes.Length);Assert.AreEqual(EyeShaderFileEvidence.ProjectRoot,observation.projectPath);
            Assert.AreEqual(source.shader.isSupported,observation.supported);
        }
        [Test]public void MaterialImportCallbackCannotSilentlyChangePublishedQueue()
        {
            var source=Source();var plan=EyeMaterialMapping.Prepare(source,source.shader,EyeMaterialMapping.EmptyProfile(source,source.shader));string output="";
            EyeCompletionImportCallback.action=path=> {
                output=path;outputs.Add(System.IO.Path.GetDirectoryName(path).Replace('\\','/'));
                var material=AssetDatabase.LoadAssetAtPath<Material>(path);material.renderQueue=2999;EditorUtility.SetDirty(material);
            };
            Assert.Throws<InvalidOperationException>(()=>EyeMaterialMapping.Execute(plan));
            Assert.IsNotEmpty(output);Assert.IsTrue(System.IO.File.Exists(output));
            StringAssert.StartsWith("Interrupted",EyeCopyHistory.Read().Single(r=>r.files.Any(f=>f.path==output)).phase);
        }
    }
    // Only armed by the fixture above; exercises real Unity import callbacks.
    public sealed class EyeCompletionImportCallback:AssetPostprocessor
    {
        public static Action<string> action;
        static void OnPostprocessAllAssets(string[] imported,string[] deleted,string[] moved,string[] movedFrom)
        {
            if(action==null)return;
            foreach(string path in imported)if(path.StartsWith(EyeAvatarRepair.OutputRoot+"/",StringComparison.Ordinal)&&path.EndsWith("/material-mapped.mat",StringComparison.Ordinal)) {
                var callback=action;action=null;callback(path);break;
            }
        }
    }
}
