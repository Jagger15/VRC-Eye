// Actual Unity EditMode behavior tests; supplied source, not executed by Python validation.
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;
namespace VrcEye.AvatarToolkit.Tests
{
    public sealed class EyeAvatarRepairTests
    {
        GameObject root;Mesh mesh;Material material;AnimationClip clip;
        readonly System.Collections.Generic.List<string> outputs=new System.Collections.Generic.List<string>();
        string temporaryFolder;
        [SetUp] public void SetUp()
        {
            root=new GameObject("Source avatar");
            var target=new GameObject("NewPath");target.transform.SetParent(root.transform);
            mesh=new Mesh {name="Source triangle",vertices=new[]{Vector3.zero,Vector3.right,Vector3.up},triangles=new[]{0,1,2}};
            root.AddComponent<MeshFilter>().sharedMesh=mesh;
            root.AddComponent<MeshRenderer>();
            clip=new AnimationClip {name="Source animation"};
            temporaryFolder=Path.Combine(Path.GetTempPath(),"EyeRepairTests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temporaryFolder);
        }
        [TearDown] public void TearDown()
        {
            foreach(var path in outputs)if(AssetDatabase.IsValidFolder(path)||AssetDatabase.LoadMainAssetAtPath(path))AssetDatabase.DeleteAsset(path);
            outputs.Clear();if(root)Object.DestroyImmediate(root);if(mesh)Object.DestroyImmediate(mesh);
            if(material)Object.DestroyImmediate(material);if(clip)Object.DestroyImmediate(clip);
            if(Directory.Exists(temporaryFolder))Directory.Delete(temporaryFolder,true);
        }
        string Run(EyeRepairPlan plan)
        {
            string path=EyeAvatarRepair.Execute(plan);outputs.Add(Path.GetDirectoryName(path).Replace('\\','/'));return path;
        }
        [Test] public void ScanDoesNotAssignOrChangeSourceMesh()
        {
            string before=EditorJsonUtility.ToJson(mesh);string report=EyeAvatarRepair.Scan(root);
            StringAssert.Contains("Missing/incomplete normals",report);Assert.AreEqual(before,EditorJsonUtility.ToJson(mesh));
            Assert.AreSame(mesh,root.GetComponent<MeshFilter>().sharedMesh);
        }
        [Test] public void NormalsAreCreatedOnlyOnSeparateAsset()
        {
            string before=EditorJsonUtility.ToJson(mesh);
            string path=Run(EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals));
            var copy=AssetDatabase.LoadAssetAtPath<Mesh>(path);Assert.AreNotSame(mesh,copy);
            Assert.AreEqual(3,copy.normals.Length);Assert.AreEqual(before,EditorJsonUtility.ToJson(mesh));
            CollectionAssert.AreEqual(mesh.triangles,copy.triangles);Assert.AreSame(mesh,root.GetComponent<MeshFilter>().sharedMesh);
        }
        [Test] public void ExistingNormalsAreNotRewritten()
        {
            mesh.RecalculateNormals();Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals));
        }
        [Test] public void ChangedMeshInvalidatesReview()
        {
            var plan=EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals);
            mesh.vertices=new[]{Vector3.zero,Vector3.right*2,Vector3.up};
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Execute(plan));
        }
        [Test] public void ChangedRootInvalidatesReview()
        {
            var plan=EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals);root.transform.localScale=Vector3.one*2;
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Execute(plan));
        }
        [Test] public void ChangedSelectionReferenceInvalidatesReview()
        {
            var plan=EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals);root.GetComponent<MeshFilter>().sharedMesh=null;
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Execute(plan));
        }
        [Test] public void ReviewIsOneUse()
        {
            var plan=EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MissingNormals);Run(plan);
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Execute(plan));
        }
        [Test] public void UnrelatedMeshIsRejected()
        {
            var unrelated=new Mesh();try {Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,unrelated,EyeRepairKind.MeshObj));}
            finally {Object.DestroyImmediate(unrelated);}
        }
        [Test] public void ShaderReplacementPreservesOriginalAndAssignment()
        {
            var first=Shader.Find("Unlit/Color");var second=Shader.Find("Unlit/Texture");
            if(!first||!second)Assert.Ignore("Built-in fixture shaders unavailable in this rendering pipeline.");
            material=new Material(first);root.GetComponent<MeshRenderer>().sharedMaterial=material;
            string before=EditorJsonUtility.ToJson(material);
            string path=Run(EyeAvatarRepair.Prepare(root,material,EyeRepairKind.MaterialShader,second));
            var copy=AssetDatabase.LoadAssetAtPath<Material>(path);Assert.AreSame(second,copy.shader);
            Assert.AreEqual(before,EditorJsonUtility.ToJson(material));Assert.AreSame(material,root.GetComponent<MeshRenderer>().sharedMaterial);
        }
        [TestCase("Old","Old","New","New")]
        [TestCase("Old/Child","Old","New","New/Child")]
        [TestCase("Oldish/Child","Old","New","Oldish/Child")]
        [TestCase("Old/Child","Old","","Child")]
        [TestCase("Old","Old","","")]
        public void PrefixRemapRespectsPathBoundaries(string path,string oldPath,string newPath,string expected)
        {Assert.AreEqual(expected,EyeAvatarRepair.RemapPath(path,oldPath,newPath));}
        [TestCase("", "New")]
        [TestCase("../Old", "New")]
        [TestCase("Old/", "New")]
        [TestCase("Old", "/New")]
        [TestCase("Old", "New//Child")]
        [TestCase("Old", "New\\Child")]
        public void InvalidPrefixesAreRejected(string oldPath,string newPath)
        {Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.RemapPath("Old/Child",oldPath,newPath));}
        static EditorCurveBinding FloatBinding(string path) {return EditorCurveBinding.FloatCurve(path,typeof(Transform),"m_LocalPosition.x");}
        [Test] public void AnimationRemapPreservesCurveAndOriginal()
        {
            var curve=AnimationCurve.Linear(0,0,1,3);curve.preWrapMode=WrapMode.PingPong;
            AnimationUtility.SetEditorCurve(clip,FloatBinding("OldPath"),curve);
            string before=EditorJsonUtility.ToJson(clip);
            string path=Run(EyeAvatarRepair.Prepare(root,clip,EyeRepairKind.AnimationPaths,null,"OldPath","NewPath"));
            var copy=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);
            Assert.AreEqual("NewPath",AnimationUtility.GetCurveBindings(copy).Single().path);
            Assert.AreEqual(3,AnimationUtility.GetEditorCurve(copy,FloatBinding("NewPath")).Evaluate(1));
            Assert.AreEqual(before,EditorJsonUtility.ToJson(clip));
        }
        [Test] public void AnimationCollisionStopsBeforeCopy()
        {
            AnimationUtility.SetEditorCurve(clip,FloatBinding("OldPath"),AnimationCurve.Linear(0,0,1,1));
            AnimationUtility.SetEditorCurve(clip,FloatBinding("NewPath"),AnimationCurve.Linear(0,0,1,2));
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,clip,EyeRepairKind.AnimationPaths,null,"OldPath","NewPath"));
        }
        [Test] public void MissingAnimationTargetStopsBeforeCopy()
        {
            AnimationUtility.SetEditorCurve(clip,FloatBinding("OldPath"),AnimationCurve.Linear(0,0,1,1));
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,clip,EyeRepairKind.AnimationPaths,null,"OldPath","Unknown"));
        }
        [Test] public void ObjectReferenceCurvesArePreservedDuringRemap()
        {
            string meshPath="Assets/EyeRepairMesh-"+Guid.NewGuid().ToString("N")+".asset";outputs.Add(meshPath);AssetDatabase.CreateAsset(mesh,meshPath);
            var old=EditorCurveBinding.PPtrCurve("OldPath",typeof(MeshFilter),"m_Mesh");
            root.transform.Find("NewPath").gameObject.AddComponent<MeshFilter>();
            AnimationUtility.SetObjectReferenceCurve(clip,old,new[]{new ObjectReferenceKeyframe {time=0,value=mesh}});
            string path=Run(EyeAvatarRepair.Prepare(root,clip,EyeRepairKind.AnimationPaths,null,"OldPath","NewPath"));
            var copy=AssetDatabase.LoadAssetAtPath<AnimationClip>(path);var binding=AnimationUtility.GetObjectReferenceCurveBindings(copy).Single();
            Assert.AreEqual("NewPath",binding.path);Assert.AreSame(mesh,AnimationUtility.GetObjectReferenceCurve(copy,binding)[0].value);
            Assert.AreEqual("OldPath",AnimationUtility.GetObjectReferenceCurveBindings(clip).Single().path);
        }
        [Test] public void ObjUsesInvariantCultureAndFiniteTriangleIndices()
        {
            var previous=CultureInfo.CurrentCulture;
            try {
                CultureInfo.CurrentCulture=CultureInfo.GetCultureInfo("de-DE");mesh.vertices=new[]{new Vector3(.5f,0,0),Vector3.right,Vector3.up};
                string obj=EyeAvatarRepair.BuildObj(mesh);StringAssert.Contains("v 0.5 0 0",obj);StringAssert.Contains("f 1 2 3",obj);
                StringAssert.DoesNotContain("mtllib",obj);StringAssert.DoesNotContain("usemtl",obj);
            } finally {CultureInfo.CurrentCulture=previous;}
        }
        [Test] public void ObjPreservesUvAndNormalsWhenPresent()
        {
            mesh.uv=new[]{Vector2.zero,Vector2.right,Vector2.up};mesh.RecalculateNormals();
            string obj=EyeAvatarRepair.BuildObj(mesh);StringAssert.Contains("vt 0 0",obj);StringAssert.Contains("vn 0 0 1",obj);
            StringAssert.Contains("f 1/1/1 2/2/2 3/3/3",obj);
        }
        [Test] public void ObjRefusesToReplaceExistingFile()
        {
            string path=Path.Combine(temporaryFolder,"existing.obj");File.WriteAllText(path,"original");
            var plan=EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MeshObj);
            Assert.Throws<IOException>(()=>EyeAvatarRepair.Execute(plan,path));Assert.AreEqual("original",File.ReadAllText(path));
        }
        [Test] public void ObjCreatesOnlyTheChosenNewFile()
        {
            string path=Path.Combine(temporaryFolder,"new.obj");string source=EditorJsonUtility.ToJson(mesh);
            EyeAvatarRepair.Execute(EyeAvatarRepair.Prepare(root,mesh,EyeRepairKind.MeshObj),path);
            Assert.AreEqual(EyeAvatarRepair.BuildObj(mesh),File.ReadAllText(path));Assert.AreEqual(source,EditorJsonUtility.ToJson(mesh));
        }
        [Test] public void ObjRejectsNonFiniteGeometry()
        {
            mesh.vertices=new[]{Vector3.zero,new Vector3(float.NaN,0,0),Vector3.up};
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.BuildObj(mesh));
        }
        [Test] public void ObjRejectsTooManyVerticesWithoutTruncating()
        {
            mesh.vertices=Enumerable.Repeat(Vector3.zero,EyeAvatarRepair.ObjVertices+1).ToArray();mesh.triangles=new[]{0,1,2};
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.BuildObj(mesh));
        }
        [Test] public void ObjRejectsTooManyTrianglesWithoutTruncating()
        {
            mesh.triangles=Enumerable.Repeat(new[]{0,1,2},EyeAvatarRepair.ObjTriangles+1).SelectMany(x=>x).ToArray();
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.BuildObj(mesh));
        }
        [Test] public void ChangedClipCurveInvalidatesReview()
        {
            AnimationUtility.SetEditorCurve(clip,FloatBinding("OldPath"),AnimationCurve.Linear(0,0,1,1));
            var plan=EyeAvatarRepair.Prepare(root,clip,EyeRepairKind.AnimationPaths,null,"OldPath","NewPath");
            AnimationUtility.SetEditorCurve(clip,FloatBinding("OldPath"),AnimationCurve.Linear(0,0,1,9));
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Execute(plan));
        }
        [Test] public void ObjRejectsDegenerateTriangles()
        {
            mesh.vertices=new[]{Vector3.zero,Vector3.right,Vector3.right*2};
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.BuildObj(mesh));
        }
        [Test] public void ObjRejectsCoordinatesOutsideViewerRange()
        {
            mesh.vertices=new[]{Vector3.zero,new Vector3(2e12f,0,0),Vector3.up};
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.BuildObj(mesh));
        }
        [Test] public void MissingScriptCleanupCreatesIndependentPrefabAndPreservesOriginalBytes()
        {
            string path="Assets/EyeMissingFixture-"+Guid.NewGuid().ToString("N")+".prefab";outputs.Add(path);
            root.GetComponent<MeshFilter>().sharedMesh=null;PrefabUtility.SaveAsPrefabAsset(root,path);
            string yaml=File.ReadAllText(path);
            var id=System.Text.RegularExpressions.Regex.Match(yaml,@"--- !u!1 &(-?[0-9]+)");
            if(!id.Success)Assert.Ignore("Requires text-serialized prefab fixtures.");
            yaml=new System.Text.RegularExpressions.Regex(@"m_Component:\r?\n").Replace(yaml,"m_Component:\n  - component: {fileID: 11499999}\n",1);
            yaml+="\n--- !u!114 &11499999\nMonoBehaviour:\n  m_ObjectHideFlags: 0\n  m_CorrespondingSourceObject: {fileID: 0}\n  m_PrefabInstance: {fileID: 0}\n  m_PrefabAsset: {fileID: 0}\n  m_GameObject: {fileID: "+id.Groups[1].Value+"}\n  m_Enabled: 1\n  m_EditorHideFlags: 0\n  m_Script: {fileID: 11500000, guid: ffffffffffffffffffffffffffffffff, type: 3}\n  m_Name: \n  m_EditorClassIdentifier: \n";
            bool previous=UnityEngine.TestTools.LogAssert.ignoreFailingMessages;
            try {
                UnityEngine.TestTools.LogAssert.ignoreFailingMessages=true; // Deliberately missing-script fixture logs are expected.
                File.WriteAllText(path,yaml);AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceUpdate);
                var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(path);byte[] before=File.ReadAllBytes(path);
                Assert.AreEqual(1,GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(prefab));
                string result=Run(EyeAvatarRepair.Prepare(prefab,prefab,EyeRepairKind.PrefabMissingScripts));
                var copy=AssetDatabase.LoadAssetAtPath<GameObject>(result);
                Assert.AreEqual(0,copy.GetComponentsInChildren<Transform>(true).Sum(n=>GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(n.gameObject)));
                CollectionAssert.AreEqual(before,File.ReadAllBytes(path));
                Assert.AreEqual(1,GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(prefab));
            } finally {UnityEngine.TestTools.LogAssert.ignoreFailingMessages=previous;}
        }
        [Test] public void SceneRootCannotBeUsedForPrefabCleanup()
        {Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(root,root,EyeRepairKind.PrefabMissingScripts));}
        [Test] public void ValidPrefabWithoutMissingComponentsHasNoCleanupPlan()
        {
            string path="Assets/EyeRepairFixture-"+Guid.NewGuid().ToString("N")+".prefab";outputs.Add(path);
            // No transient mesh reference may be serialized into this prefab fixture.
            root.GetComponent<MeshFilter>().sharedMesh=null;
            var prefab=PrefabUtility.SaveAsPrefabAsset(root,path);
            Assert.Throws<InvalidOperationException>(()=>EyeAvatarRepair.Prepare(prefab,prefab,EyeRepairKind.PrefabMissingScripts));
        }
    }
}
