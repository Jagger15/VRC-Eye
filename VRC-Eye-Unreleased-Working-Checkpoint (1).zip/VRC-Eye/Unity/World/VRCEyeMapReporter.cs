// Install in a VRChat WORLDS project with UdonSharp. Not an avatar component.
// See WORLD_MAP_SETUP.md. One reporter per scene. Reporting is local and opt-in.
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.SDK3.Data;

[UdonBehaviourSyncMode(BehaviourSyncMode.None)]
public class VRCEyeMapReporter : UdonSharpBehaviour
{
    [Tooltip("Exact world ID used in VRC Eye, or local:my-world for an unpublished Build & Test world.")]
    public string worldId = "local:my-world";

    [Tooltip("Seconds between complete snapshots. Clamped to 1–5 seconds.")]
    public float intervalSeconds = 2f;

    [Tooltip("Normally leave off. Interact with this object to enable reporting on your own client.")]
    public bool reportOnStart = false;

    private bool reporting;
    private int sequence;
    private string streamId;
    private VRCPlayerApi[] players = new VRCPlayerApi[100];
    private int previousFrame;
    private float previousTime;

    private void Start()
    {
        reporting = reportOnStart;
        streamId = Time.realtimeSinceStartup.ToString("R");
        previousFrame = Time.frameCount;
        previousTime = Time.realtimeSinceStartup;
        SendCustomEventDelayedSeconds(nameof(PublishMap), 2f);
    }

    public override void Interact()
    {
        reporting = !reporting;
        previousFrame = Time.frameCount;
        previousTime = Time.realtimeSinceStartup;
        Debug.Log(reporting ? "VRC Eye map reporting enabled locally." : "VRC Eye map reporting stopped locally.");
    }

    public void PublishMap()
    {
        // Schedule exactly once, including when reporting is off.
        SendCustomEventDelayedSeconds(nameof(PublishMap), Mathf.Clamp(intervalSeconds, 1f, 5f));
        if (!reporting || !Utilities.IsValid(Networking.LocalPlayer)) return;
        int count = VRCPlayerApi.GetPlayerCount();
        if (count < 1 || count > players.Length) return;
        VRCPlayerApi.GetPlayers(players);
        float elapsed = Time.realtimeSinceStartup - previousTime;
        float fps = elapsed > 0.1f ? (Time.frameCount - previousFrame) / elapsed : 0f;
        previousFrame = Time.frameCount;
        previousTime = Time.realtimeSinceStartup;
        DataList positions = new DataList();
        for (int i = 0; i < count; i++)
        {
            VRCPlayerApi player = players[i];
            if (!Utilities.IsValid(player)) continue;
            Vector3 position = player.GetPosition();
            DataDictionary entry = new DataDictionary();
            entry.Add("id", player.playerId);
            entry.Add("name", player.displayName);
            entry.Add("x", position.x);
            entry.Add("y", position.y);
            entry.Add("z", position.z);
            entry.Add("yaw", player.GetRotation().eulerAngles.y);
            entry.Add("local", player.isLocal);
            entry.Add("in_vr", player.IsUserInVR());
            // Build platform identifies this local client only. A remote player's
            // avatar package or our own build cannot identify their device.
            if (player.isLocal)
            {
#if UNITY_ANDROID
                entry.Add("platform", "android");
#elif UNITY_IOS
                entry.Add("platform", "ios");
#elif UNITY_STANDALONE_WIN || UNITY_EDITOR
                entry.Add("platform", "standalonewindows");
#endif
                if (fps > 0f && fps <= 2000f) entry.Add("fps", fps);
            }
            positions.Add(entry);
        }
        DataDictionary packet = new DataDictionary();
        packet.Add("version", 1);
        packet.Add("world", worldId);
        packet.Add("stream", streamId);
        packet.Add("sequence", sequence++);
        packet.Add("player_count", count);
        packet.Add("players", positions);
        DataToken json;
        if (VRCJson.TrySerializeToJson(packet, JsonExportType.Minify, out json))
        {
            Debug.Log("[VRCEyeMap] " + json.String);
        }
    }
}
