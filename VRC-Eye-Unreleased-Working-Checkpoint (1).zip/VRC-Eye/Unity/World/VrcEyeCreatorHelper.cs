// Optional WORLDS/UdonSharp helper. See CREATOR_HELPER_SETUP.md before installation.
// Local observations and four finite local actions only. No networking or persistence.
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.SDK3.Data;

[UdonBehaviourSyncMode(BehaviourSyncMode.None)]
public class VrcEyeCreatorHelper : UdonSharpBehaviour
{
    [Tooltip("Exact uploaded wrld_ ID, or copy the local:UUID ID from your VRC Eye creator workspace.")]
    public string worldId = "";
    [Tooltip("Change for each actual build. This is not the published VRChat version.")]
    public string buildId = "test-build-1";
    [Range(0, 15)] public int midiChannel = 15;
    [Tooltip("Assign a local visual-only labels object; never a shared gameplay object.")]
    public GameObject diagnosticLabels;
    [Tooltip("A separate opt-in from reporting. Interact with this helper in the test world to arm it locally.")]
    public bool allowLocalMidi = false;

    private bool reporting;
    private bool armed;
    private int debugLevel = 1;
    private int sequence;
    private int frameStep;
    private int requestId;
    private int controlNumber;
    private int controlValue;
    private float frameStarted;
    private float lastCommandAt = -10f;
    private int[] recentRequests = new int[64];
    private int recentCursor;

    private void Start()
    {
        reporting = false;
        armed = false;
        frameStep = 0;
        SendCustomEventDelayedSeconds(nameof(PublishIdentity), 10f);
    }

    public override void Interact()
    {
        reporting = !reporting;
        armed = reporting && allowLocalMidi;
        frameStep = 0;
        Debug.Log(reporting
            ? "VRC Eye creator observations enabled locally. MIDI controls: " + (armed ? "armed" : "disabled")
            : "VRC Eye creator observations and MIDI controls disabled locally.");
        if (reporting) Emit("identity", 0, "", "", 0);
    }

    public void PublishIdentity()
    {
        SendCustomEventDelayedSeconds(nameof(PublishIdentity), 10f);
        if (!reporting) return;
        Emit("identity", 0, "", "", 0);
        if (debugLevel > 0)
        {
            DataDictionary assertion = Packet("assertion");
            assertion.Add("assertion", "local-label-reference");
            assertion.Add("state", Utilities.IsValid(diagnosticLabels) ? "pass" : "unresolved");
            WritePacket(assertion);
        }
        if (debugLevel == 2)
        {
            if (Utilities.IsValid(diagnosticLabels))
                Emit("state", 0, "diagnostic-labels", "", diagnosticLabels.activeSelf ? 1 : 0);
            Emit("state", 0, "debug-level", "", debugLevel);
        }
    }

    public override void MidiControlChange(int channel, int number, int value)
    {
        if (!armed || !reporting || channel != midiChannel || value < 0 || value > 127) return;
        // Only CC16..22 belong to this protocol. Other instruments are ignored.
        if (number < 16 || number > 22) return;
        if (number == 16)
        {
            frameStep = value == 95 ? 1 : 0;
            frameStarted = Time.realtimeSinceStartup;
            requestId = 0;
            return;
        }
        if (frameStep == 0 || Time.realtimeSinceStartup - frameStarted > 2f || number != 16 + frameStep)
        {
            frameStep = 0;
            return;
        }
        if (number == 17) requestId = value;
        else if (number == 18) requestId += value * 128;
        else if (number == 19) requestId += value * 16384;
        else if (number == 20) controlNumber = value;
        else if (number == 21) controlValue = value;
        else if (number == 22)
        {
            frameStep = 0;
            if (value != 85 || requestId <= 0) return;
            for (int i = 0; i < recentRequests.Length; i++)
                if (recentRequests[i] == requestId) return;
            // Bound local work and log output to four requests/second.
            if (Time.realtimeSinceStartup - lastCommandAt < 0.25f) return;
            lastCommandAt = Time.realtimeSinceStartup;
            recentRequests[recentCursor] = requestId;
            recentCursor = (recentCursor + 1) % recentRequests.Length;
            ApplyLocalControl();
            return;
        }
        frameStep++;
    }

    private void ApplyLocalControl()
    {
        // Finite dispatch only. Never execute a supplied method, URL, or program.
        string control = "";
        bool applied = false;
        if (controlNumber == 1 && (controlValue == 0 || controlValue == 1))
        {
            control = "diagnostic-labels";
            if (Utilities.IsValid(diagnosticLabels) && diagnosticLabels != gameObject)
            {
                diagnosticLabels.SetActive(controlValue == 1);
                applied = diagnosticLabels.activeSelf == (controlValue == 1);
            }
        }
        else if (controlNumber == 2 && controlValue >= 0 && controlValue <= 2)
        {
            control = "debug-level";
            debugLevel = controlValue;
            applied = true;
        }
        else if (controlNumber == 3 && controlValue == 1)
        {
            control = "bookmark";
            Emit("bookmark", requestId, control, "", 1);
            applied = true;
        }
        else if (controlNumber == 4 && controlValue == 1)
        {
            control = "reset-local-diagnostics";
            debugLevel = 0;
            if (Utilities.IsValid(diagnosticLabels) && diagnosticLabels != gameObject)
                diagnosticLabels.SetActive(false);
            applied = true;
        }
        else return;
        // The companion displays this as a helper-reported result, not trusted proof.
        Emit("control-report", requestId, control, applied ? "applied" : "failed", controlValue);
    }

    private DataDictionary Packet(string eventName)
    {
        DataDictionary packet = new DataDictionary();
        packet.Add("schema", 1);
        packet.Add("world_id", worldId);
        packet.Add("build_id", buildId);
        packet.Add("event", eventName);
        packet.Add("sequence", sequence++);
        return packet;
    }

    private void Emit(string eventName, int command, string control, string state, int value)
    {
        DataDictionary packet = Packet(eventName);
        if (command > 0) packet.Add("request", command);
        if (control != "") packet.Add("control", control);
        if (state != "") packet.Add("state", state);
        if (eventName == "control-report" || eventName == "state") packet.Add("value", value);
        WritePacket(packet);
    }

    private void WritePacket(DataDictionary packet)
    {
        if (!reporting) return;
        DataToken json;
        if (VRCJson.TrySerializeToJson(packet, JsonExportType.Minify, out json))
            Debug.Log("[VRCEyeCreator] " + json.String);
    }
}
