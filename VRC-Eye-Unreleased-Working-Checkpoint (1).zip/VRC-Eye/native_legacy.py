"""Projection and reviewed consolidation of earlier Eye import records."""
import json
from native_library import identity, scope


def prepare_earlier_imports(library,target):
    target=scope(target);records={}
    def add(kind,ref,data):records[(kind,ref)]=dict(scope=target,kind=kind,id=ref,data=data,provenance={'source':'Earlier VRC Eye VRCX import'})
    with library.companion.connect() as db:
        names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'vrcx121_groups' in names:
            for kind,name in db.execute('SELECT kind,name FROM vrcx121_groups WHERE scope=?',(target,)):
                add('collection',identity('collection',kind,name),dict(entity_kind=kind,name=name))
        if 'vrcx121_memberships' in names:
            for kind,group,ref,name,added in db.execute('SELECT kind,group_name,item_id,name,imported_at FROM vrcx121_memberships WHERE scope=?',(target,)):
                er=kind+':'+ref;coll=identity('collection',kind,group)
                add('entity',er,dict(entity_kind=kind,entity_id=ref,name=name,fields={}))
                add('collection',coll,dict(entity_kind=kind,name=group))
                add('membership',identity(coll,er),dict(entity=er,collection=coll,added=added,rank=None))
        if 'vrcx121_avatars' in names:
            for ref,raw,checked in db.execute('SELECT id,payload,checked FROM vrcx121_avatars WHERE scope=?',(target,)):
                a=json.loads(raw);er='avatar:'+ref
                fields={k:a.get(k,'') for k in ('author_id','author_name','description','release','created','updated')}
                add('entity',er,dict(entity_kind='avatar',entity_id=ref,name=a.get('name') or ref,fields=fields))
                for tag,color in a.get('tags',[]):add('annotation',identity('annotation',er,'tag',tag),dict(entity=er,type='tag',value=tag,color=color))
    return library.prepare(records.values(),source='Consolidate earlier VRCX imports',policy='fill')


def avatar_projection(library,target,ref):
    """One authoritative native read; no second-database migration write."""
    target=scope(target);record=library.get(target,'entity','avatar:'+ref)
    if not record:return None
    d=record['data'];f=d.get('fields',{});annotations=library.annotations(target,'avatar:'+ref)
    with library.connect() as db:
        favorite=bool(db.execute("SELECT 1 FROM eye_native_records WHERE scope=? AND kind='membership' AND json_extract(data,'$.entity')=? LIMIT 1",(target,'avatar:'+ref)).fetchone())
    from shared_notes import marker_id
    shared_notes=bool(library.get(target,'preference',marker_id('avatar:'+ref))) or any(a['data']['type'] in ('memo','note') for a in annotations)
    now=record['provenance'].get('imported_at') or f.get('added_at','')
    source=record['provenance'].get('source','VRC Eye native library')
    release=f.get('release_status') or f.get('release') or 'unknown'
    return dict(id=ref,name=d.get('name') or ref,author=f.get('author_name',''),author_id=f.get('author_id',''),
        description=f.get('description',''),visibility=release.casefold(),platforms=[],tags=[],
        local_tags=[a['data']['value'] for a in annotations if a['data']['type'] in ('tag','label')],
        favorite=favorite,notes='\n\n'.join(a['data']['value'] for a in annotations if a['data']['type'] in ('memo','note')),
        first_seen=now,last_seen=now,field_evidence={'native':{'source':source,'historical':True}},sources=[source],source=source,
        history=[],thumbnail='',notes_shared=shared_notes,updated_at=f.get('updated_at') or f.get('updated') or '',
        created_at=f.get('created_at') or f.get('created') or '',native_projection=True)


def merge_avatar(native,existing):
    if not native:return existing
    if not existing:return native
    merged=dict(native);merged.update(existing)
    if native.get('notes_shared'):merged['notes']=native['notes'];merged['notes_shared']=True
    merged['local_tags']=list(dict.fromkeys(native.get('local_tags',[])+existing.get('local_tags',[])))
    return merged
