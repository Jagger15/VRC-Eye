# Desktop text size

Open **Accessibility → Display → Text size (%)**. Drag the slider or type a
whole percentage from **100 to 500** in the adjacent box. The sample updates
immediately; **Apply text size** updates the desktop and saves the setting.
Settings and Customization expose the same percentage control. Demo and Safe
Mode keep changes in the current session only.

- Arrow keys on the slider change by 1 percentage point; Shift+arrows and
  Page Up/Down change by 10. Home/End select 100/500.
- Empty or invalid intermediate input keeps the last valid preview. Apply
  rejects invalid values; it never silently applies an out-of-range value.
- **Reset text to 100%** resets the draft; Apply commits it.
- **Ctrl+0** immediately restores 100% from app windows, including dialogs.
  It respects modal ownership and is suspended during shortcut capture.
- **Undo last accessibility change** restores the preceding Accessibility
  change. Customization retains its existing appearance Undo.
- Normal saved preferences, accessibility profiles, appearance profiles and
  settings backups include the percentage. Older profiles keep their combined
  text-size setting until an explicit percentage is chosen or imported.

The percentage is absolute: 500% is five times the standard font size, rather
than a multiplier on top of control spacing or legacy text settings. Existing
point-size hierarchy and OS DPI scaling still apply. Control spacing, contrast,
bold text, focus outlines and reduced motion remain independent preferences.

Shared styles, classic Tk text, menus, combo lists, fixed-width editors, titles,
legacy dialog labels and desktop canvas text use live named or shared fonts.
Existing widgets and windows opened later receive the same setting. List row
height follows measured font line height, including display DPI.

Above 200%, desktop windows retain their requested content size inside real
canvas viewports. Settings panes also preserve the width needed by enlarged
controls. Scrollbars, wheel scrolling (Shift for horizontal scrolling), native
list scrolling and keyboard focus reveal keep the content reachable. Original
controllers, selected entities, text variables, modal ownership and callbacks
are retained. Typography changes do not grant permissions or start services.

This is desktop UI scaling. Raster images, generated reports, SteamVR textures,
external programs and OS-provided file/message dialogs use their own sizing.
Standard Tk prompt dialogs supplied by the platform also retain their platform
layout; the app's reader-friendly alternatives use the shared viewport.

## Verification

`TEXT_SCALING_QUALIFICATION.json` records the source manifest, portable tests,
regression results and environment exclusions. Ten native graphical acceptance
cases are supplied in `tests/test_text_scaling_native.py`; they cover live font
metrics, persistence, focus/reset, packed/gridded dialogs and synchronized
settings. They have not run here: the environment has no usable graphical
Tk display. Windows/Linux layout at 500%, native dialog usability, actual device
DPI and assistive-technology interoperability still require platform acceptance.
No installer, executable or numbered release is produced by this checkpoint.
