"""World-owned creator workspace: local records and explicit observation capture."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import queue
import re
import sqlite3
import threading
import time
import uuid

from creator_api import read_world
from creator_store import CreatorStore
from creator_workflows import CreatorWorkflows
from creator_diagnostics import CreatorDiagnostics
from creator_helper import CommandLedger, load_manifest, parse_helper_log
from creator_midi import MIDIAdapter
from creator_integrations import CreatorOverlayPresenter, CreatorPeerCoordinator
from vrchat_api import APIError
from vrca_files import VRCAError
from world_backup import parse_world_reference


class CreatorWorkspace:
    def __init__(self, view, *, store=None, build_ui=True):
        self.view, self.app = view, view.app
        self.tk, self.ttk = self.app.tk, self.app.ttk
        self.panel = None
        self.closed = False
        self.message = "Local creator workspace. Capture and sharing are off."
        if store is None:
            path = self.app.sidebar.store.path
            try:
                store = CreatorStore(path.with_name(path.stem + "-creators.sqlite3"))
            except (OSError, ValueError, sqlite3.Error):
                store = CreatorStore(":memory:")
                self.message = "Creator storage is unavailable. These records last only until this app closes; export them before exiting."
        self.store = store
        self.workflows = CreatorWorkflows(store)
        self.diagnostics = CreatorDiagnostics(store)
        self.context = {}
        self.guard_token = ""
        self._context_signature = None
        self._context_revision = 0
        self.world_info = {}
        self.helper_manifest = None
        self.ledger = CommandLedger()
        self.midi = MIDIAdapter()
        self.overlay = CreatorOverlayPresenter()
        self._peer_coordinator = None
        self._peer_service = None
        self.capture_enabled = False
        self.active_run_id = None
        self.loaded_build_id = ""
        self.pinned = False
        self.job = None
        self._requested = None
        self._last_refresh = 0.
        self._live_boundary = None
        self._local_test_boundary = None
        self._last_batch = None
        self._last_sample = 0.
        self._metadata_token = None
        self._metadata_received = 0.
        worlds = self.store.list("world", limit=1)
        self.world_id = worlds[0]["world_id"] if worlds else "local:" + str(uuid.uuid4())
        if not worlds:
            self.store.save("world", self.world_id, {"name": "My local world", "local_project": True})
        self.refresh_context()
        if build_ui:
            from creator_ui import CreatorPanel
            self.panel = CreatorPanel(self, view.sections)
            self.panel.status.set(self.message)

    def current_world(self):
        return self.world_id

    def announce(self, text):
        self.message = str(text)[:4000]
        if self.panel:
            self.panel.status.set(self.message)
            self.panel.refresh()

    def set_workspace(self, world_id, name=""):
        if not world_id:
            world_id = "local:" + str(uuid.uuid4())
        if not world_id.startswith("local:"):
            try:
                world_id = parse_world_reference(world_id)
            except VRCAError as error:
                raise ValueError(str(error)) from None
        existing = self.store.list("world", world_id, limit=1)
        data = dict(existing[0]["data"]) if existing else {}
        data.update(name=name or data.get("name") or world_id, local_project=world_id.startswith("local:"))
        self.store.save("world", world_id, data, existing[0]["id"] if existing else None)
        if self.world_id != world_id:
            self.loaded_build_id = ""
            self.capture_enabled = False
            self.midi.close()
            self.clear_overlay()
        self.world_id, self.pinned = world_id, True
        self.refresh_context()
        self.announce("Workspace pinned. Local records remain available after leaving the world.")
        return world_id

    def follow_current_world(self):
        self.pinned = False
        self._local_test_boundary = None
        self.refresh_context()
        self.announce("Following the observed world; capture must be enabled for each new session.")

    def bind_local_test_session(self):
        """Associate an unpublished test log only after an explicit operator choice."""
        self.refresh_context()
        roster = self.view.log_roster()
        if (not self.world_id.startswith("local:") or not roster.source or roster.ended
                or self.view.world_reference() or self.app.demo or getattr(self.app, "safe_mode", False)):
            raise ValueError("Select a local project and an active unpublished test log before associating this session.")
        self._local_test_boundary = self._boundary()
        self.pinned = True
        self.refresh_context()
        self.announce("Unpublished test session associated with this local project by your declaration. Enable capture separately.")

    def _boundary(self):
        roster = self.view.log_roster()
        client = getattr(self.app, "api", None)
        return (id(client), getattr(self.app, "data_generation", 0),
                getattr(client, "session_revision", None),
                getattr(client, "user_id", "") if getattr(client, "authenticated", False) else "",
                roster.identity, roster.instance_id, roster.ended,
                self.view.world_reference(), bool(self.app.demo), bool(getattr(self.app, "safe_mode", False)))

    def refresh_context(self):
        roster = self.view.log_roster()
        boundary = self._boundary()
        live_world = self.view.world_reference() if not roster.ended else ""
        local_session = (not live_world and self.world_id.startswith("local:") and roster.source
                         and not roster.ended and boundary == self._local_test_boundary)
        if local_session:
            live_world = self.world_id
        if live_world and not self.pinned:
            self.world_id = live_world
            if not self.store.list("world", live_world, limit=1):
                self.store.save("world", live_world, {"name": roster.room or live_world, "local_project": False})
        changed = self._live_boundary is not None and boundary != self._live_boundary
        if changed:
            self._local_test_boundary = None
            self.loaded_build_id = ""
            self.capture_enabled = False
            self.clear_overlay()
            self.midi.close()
        self._live_boundary = boundary
        if self.helper_manifest and self.helper_manifest["world_id"] != self.world_id:
            self.helper_manifest = None
            self.ledger.set_manifest(None)
        if self.active_run_id:
            run = self.store.get(self.active_run_id)
            if not run or run["world_id"] != self.world_id or run["data"].get("status") != "Active":
                self.active_run_id = None
            elif (self.loaded_build_id and run["data"].get("build_id")
                    and self.loaded_build_id != run["data"]["build_id"]):
                self.active_run_id = None
                self.capture_enabled = False
                self.message = "The selected run belongs to another build. Start or select a matching run before capture."
        signature = (boundary, self.world_id, self.loaded_build_id, self.active_run_id)
        if signature != self._context_signature:
            self._context_signature = signature
            self._context_revision += 1
        token = hashlib.sha256(repr((signature, self._context_revision)).encode()).hexdigest()
        if token != self.guard_token:
            if self.job:
                self.job["stop"].set()
                self.job = None
            self.guard_token = token
            self._requested = None
            self.ledger.set_context(self.helper_context() if self.loaded_build_id else None)
            self.clear_overlay()
            if self._peer_coordinator is not None:
                self._peer_coordinator.clear()
        if self.world_info.get("id") != self.world_id:
            records = self.store.list("metadata_snapshot", self.world_id, limit=1)
            self.world_info = dict(records[0]["data"]) if records else {}
            self._metadata_token = None
        account = boundary[3]
        author = self.world_info.get("authorId", "")
        fresh = self._metadata_token == token and bool(account) and time.monotonic() - self._metadata_received < 300
        if self.world_id.startswith("local:"):
            recognition = "Local project creator"
        elif account and author == account:
            recognition = "Confirmed author" if fresh else "Previously recognized (cached)"
        elif fresh and author:
            recognition = "Not author"
        else:
            recognition = "Unresolved"
        self.context = {"world_id": self.world_id, "live_world_id": live_world,
                        "instance_id": roster.instance_id if live_world == self.world_id else "",
                        "account_id": account, "session_revision": boundary[2],
                        "build_id": self.loaded_build_id, "recognition": recognition,
                        "source": "VRChat API" if author else "Local workspace",
                        "freshness": "Current lookup" if fresh else "Cached / unresolved",
                        "guard_token": token, "capture_enabled": self.capture_enabled,
                        "pinned": self.pinned, "local_session_declared": bool(local_session), "message": self.message}
        return self.context

    def helper_context(self):
        return {"world_id": self.world_id, "build_id": self.loaded_build_id,
                "generation": self.guard_token, "account_id": self._boundary()[3],
                "client_session": repr(self._boundary()[4])}

    def refresh_metadata(self, callback=None):
        self.refresh_context()
        client = getattr(self.app, "api", None)
        if self.app.demo or getattr(self.app, "safe_mode", False) or not client or not client.authenticated or self.world_id.startswith("local:"):
            error = "A connected VRChat account and published world ID are required for metadata refresh. Local drafts remain available."
            if callback:
                callback({}, error)
            else:
                self.announce(error)
            return
        if self.job:
            self.job["stop"].set()
        token, reference = self.guard_token, self.world_id
        stop, output = threading.Event(), queue.Queue(maxsize=1)
        job = {"token": token, "stop": stop, "output": output, "callback": callback}
        self.job, self._requested = job, token
        self.app.transfer_stops.append(stop)
        def worker():
            try:
                value = read_world(client, reference, stop=stop)
                output.put((value, ""))
            except (APIError, ValueError, OSError) as error:
                output.put(({}, str(error)))
            finally:
                if stop in self.app.transfer_stops:
                    self.app.transfer_stops.remove(stop)
        threading.Thread(target=worker, daemon=True).start()

    def _poll_metadata(self):
        if not self.job:
            return
        job = self.job
        try:
            value, error = job["output"].get_nowait()
        except queue.Empty:
            return
        self.job = None
        if job["stop"].is_set() or job["token"] != self.guard_token:
            return
        if value:
            self.world_info = value
            self._metadata_token = self.guard_token
            self._metadata_received = time.monotonic()
            previous = self.store.list("metadata_snapshot", self.world_id, limit=1)
            self.store.save("metadata_snapshot", self.world_id, value, previous[0]["id"] if previous else None)
            self.refresh_context()
        if job["callback"]:
            job["callback"](value, error)
        self.announce(error or "World metadata refreshed. Authorship is recognition; publishing uses the official SDK or website.")

    def set_capture(self, enabled):
        self.refresh_context()
        if enabled:
            if self.app.demo or getattr(self.app, "safe_mode", False):
                raise ValueError("Creator capture is disabled in Demo and startup Safe Mode.")
            if self.context["live_world_id"] != self.world_id:
                raise ValueError("Open this world in the observed client before capturing. Local notes and manual test results remain available.")
            batch = getattr(self.app, "batch", None)
            if batch is not None and batch.offset < batch.size:
                raise ValueError("Wait until the current log has finished loading before starting capture.")
        self.capture_enabled = bool(enabled)
        if enabled:
            self.diagnostics.ingest_roster(self.world_id, self.view.log_roster(),
                build_id=self.loaded_build_id or None, run_id=self.active_run_id)
        self.announce("Capturing new observations for this world session." if enabled else "Creator observation capture stopped. Existing records are preserved.")

    def sample_metrics(self):
        """Reuse already enabled providers. No monitoring providers are started here."""
        self.refresh_context()
        if self.context.get("live_world_id") != self.world_id:
            return []
        from peer_tools import performance_card
        card = performance_card(app=self.app, context="World creator local observation")
        saved = []
        for name, metric in card["metrics"].items():
            if metric["value"] is None:
                continue
            saved.append(self.diagnostics.observe(self.world_id, "metric", name, metric["source"],
                scope="local client / process" if name.startswith(("vrchat.", "fps", "frame")) else "local device",
                build_id=self.loaded_build_id or None, run_id=self.active_run_id,
                value=metric["value"], unit=metric["unit"], sample_count=1,
                quality="single_sample", period_seconds=0,
                details={"coverage": "Point sample from an already enabled provider; process values are not world-only costs.",
                         "creator_overlay": self.overlay.snapshot().get("enabled", False)}))
        return saved

    def ingest(self, batch):
        self.refresh_context()
        if not self.capture_enabled or self.context["live_world_id"] != self.world_id:
            return
        batch_key = (str(batch.source), batch.offset, batch.modified)
        if batch_key == self._last_batch:
            return
        self._last_batch = batch_key
        if batch.reset or batch.offset < batch.size:
            self.capture_enabled = False
            self.announce("Capture paused because the log changed or is reading history. Enable capture after it catches up.")
            return
        # A mixed-world batch has no reliable per-line workspace attribution.
        if any(re.search(r"Joining wrld_|OnLeftRoom|OnApplicationQuit", line, re.I) for line in batch.lines):
            self.capture_enabled = False
            self.announce("Capture paused at a world/session boundary; mixed-context lines were omitted.")
            return
        for line in batch.lines:
            self.diagnostics.ingest_log(self.world_id, line, source="VRChat local log",
                build_id=self.loaded_build_id or None, run_id=self.active_run_id)
            try:
                helper = parse_helper_log(line)
            except ValueError:
                helper = None
            if helper and helper["world_id"] == self.world_id:
                matching = bool(self.helper_manifest and helper["build_id"] == self.helper_manifest["build_id"])
                if matching:
                    kind = helper["event"] if helper["event"] in ("assertion", "zone") else "helper"
                    self.diagnostics.observe(self.world_id, kind, "Helper reported " + helper["event"],
                        "Creator helper log (untrusted declaration)", quality="helper_declared",
                        build_id=helper["build_id"], run_id=self.active_run_id,
                        zone=helper.get("zone", ""), details=helper,
                        source_event_id=str((self.guard_token, helper["build_id"], helper["sequence"])))
                if self.loaded_build_id:
                    self.ledger.record_helper_report(helper, self.helper_context())
        self.diagnostics.ingest_roster(self.world_id, self.view.log_roster(),
                build_id=self.loaded_build_id or None, run_id=self.active_run_id)

    def add_bookmark(self, label="Quick marker", **kwargs):
        self.refresh_context()
        result = self.diagnostics.bookmark(self.world_id, label=label,
            build_id=self.loaded_build_id or None, run_id=self.active_run_id, **kwargs)
        self.announce("Bookmark saved locally with its selected evidence window.")
        return result

    def import_manifest(self, path):
        manifest = load_manifest(path)
        if manifest["world_id"] != self.world_id:
            raise ValueError("The manifest belongs to a different workspace. Select that world first.")
        self.store.save("manifest", self.world_id, manifest)
        self.helper_manifest = manifest
        self.ledger.set_manifest(manifest)
        self.loaded_build_id = ""
        self.refresh_context()
        self.announce("Manifest imported as creator-declared project evidence. Loaded build remains unconfirmed.")
        return manifest

    def confirm_test_build(self, build_id):
        """Explicit local operator declaration, never inferred from a remote revision."""
        self.refresh_context()
        if (not self.helper_manifest or build_id != self.helper_manifest.get("build_id")
                or self.helper_manifest.get("world_id") != self.world_id):
            raise ValueError("Select the exact build from the imported manifest.")
        if self.context.get("live_world_id") != self.world_id:
            raise ValueError("The observed client must be in this world before confirming a test build.")
        self.loaded_build_id = build_id
        self.refresh_context()
        self.announce("Loaded build manually confirmed for this session. This is an operator declaration, not API verification.")

    def review_control(self, control_id, value):
        self.refresh_context()
        if not self.helper_manifest:
            raise ValueError("Import this build's helper manifest first.")
        if self.app.demo or getattr(self.app, "safe_mode", False):
            raise ValueError("Helper control is disabled in Demo and startup Safe Mode.")
        if not self.midi.connected:
            raise ValueError("Select and connect the intended MIDI output before reviewing a control.")
        return self.ledger.review(self.helper_manifest, control_id, value, self.helper_context(),
                                  transport_id=self.midi.transport_id)

    def execute_control(self, request_id, consent=True):
        self.refresh_context()
        if self.app.demo or getattr(self.app, "safe_mode", False):
            raise ValueError("Helper control is disabled in Demo and startup Safe Mode.")
        result = self.ledger.dispatch(request_id, self.helper_context(), self.midi, consent=consent)
        self.store.save("control", self.world_id, result)
        return result

    def control_requests(self):
        return self.ledger.requests()

    def midi_ports(self):
        return self.midi.list_ports()

    def open_midi(self, port):
        self.refresh_context()
        if self.app.demo or getattr(self.app, "safe_mode", False):
            raise ValueError("MIDI output is disabled in Demo and startup Safe Mode.")
        return self.midi.open(port, consent=True)

    @property
    def peer_coordinator(self):
        service = getattr(self.app, "peer_service", None)
        if service is None:
            raise ValueError("VRC Eye peer services are unavailable.")
        if service is not self._peer_service:
            self._peer_service = service
            self._peer_coordinator = CreatorPeerCoordinator(service)
        return self._peer_coordinator

    def show_overlay(self, step="", error="", **settings):
        self.refresh_context()
        if self.app.demo or getattr(self.app, "safe_mode", False):
            self.clear_overlay()
            raise ValueError("Creator presentation is disabled in Demo and startup Safe Mode.")
        avatar = getattr(self.app, "avatar_creator", None)
        if avatar is not None:
            avatar.clear_overlay()
        self.app._creator_overlay_owner = "world"
        wellness = self.app.sidebar.pages.get("Wellness")
        runtime = getattr(wellness, "runtime", None)
        if self.overlay.runtime is not runtime:
            self.clear_overlay()
        self.overlay.runtime = runtime
        self.app._creator_overlay_owner = "world"
        return self.overlay.show(self.world_id + " · " + (self.loaded_build_id or "loaded build unknown"), step, error, **settings)

    def clear_overlay(self):
        if getattr(self.app, "_creator_overlay_owner", "world") == "avatar":
            runtime, self.overlay.runtime = self.overlay.runtime, None
            try:
                return self.overlay.clear()
            finally:
                self.overlay.runtime = runtime
        self.app._creator_overlay_owner = None
        return self.overlay.clear()

    def import_peer_results(self):
        self.refresh_context()
        selection = dict(world_id=self.world_id, build_id=self.loaded_build_id, run_id=self.active_run_id or "")
        cards = self.peer_coordinator.accepted_claims(**selection)
        saved = []
        for card in cards:
            fingerprint = hashlib.sha256(json.dumps({key: card.get(key) for key in
                ("peer_id", "world_id", "build_id", "run_id", "kind", "record_id", "title", "data")},
                sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
            previous = self.store.list("feedback", self.world_id, limit=10000)
            if any(row["data"].get("fingerprint") == fingerprint or
                   row["data"].get("reported", {}).get("message_id") == card["message_id"] for row in previous):
                continue
            saved.append(self.store.save("feedback", self.world_id, {"reported": card, "fingerprint": fingerprint,
                "verification": "Reported by a peer; not locally verified"}))
            self.peer_coordinator.import_claim(card["message_id"], **selection)
        return saved

    def export_report(self, record_ids, profile, format, path):
        from creator_reports import preview_report, export_report
        return export_report(preview_report(self.store, self.world_id, record_ids, profile=profile, format=format), path)

    def tick(self):
        if self.closed:
            return
        try:
            self.refresh_context()
            self._poll_metadata()
            self.ledger.expire()
            if self.capture_enabled and time.monotonic() - self._last_sample >= 5:
                self._last_sample = time.monotonic()
                self.sample_metrics()
            client = getattr(self.app, "api", None)
            if (self._requested != self.guard_token and not self.job and client and client.authenticated
                    and not self.world_id.startswith("local:") and not self.app.demo
                    and not getattr(self.app, "safe_mode", False) and self.panel and self.panel.built):
                self.refresh_metadata()
            if self.panel and time.monotonic() - self._last_refresh >= 1:
                self._last_refresh = time.monotonic()
                self.panel.refresh()
        except (OSError, ValueError, sqlite3.Error) as error:
            self.capture_enabled = False
            self.message = "Creator workspace paused: " + str(error)
            if self.panel:
                self.panel.status.set(self.message)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.job:
            self.job["stop"].set()
            self.job = None
        self.capture_enabled = False
        self.midi.close()
        self.clear_overlay()
        if self.panel:
            self.panel.close()
        self.store.close()
