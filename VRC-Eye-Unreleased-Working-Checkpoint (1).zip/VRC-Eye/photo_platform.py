"""Read-only Windows Pictures known-folder adapter. Native validation still pending.

Uses the installed OS libraries from System32 only. Never creates/redirects the
folder, changes permissions, scans contents or accesses another user's token.
Microsoft SHGetKnownFolderPath / CoInitializeEx references retrieved 2026-10-02.
"""
import ctypes
import os
from pathlib import PureWindowsPath
from uuid import UUID

PICTURES_GUID='33e28130-4e1e-4676-835a-98395c3bc3bb'
DONT_VERIFY=0x4000


class GUID(ctypes.Structure):
    _fields_=[('data1',ctypes.c_uint32),('data2',ctypes.c_uint16),('data3',ctypes.c_uint16),('data4',ctypes.c_ubyte*8)]


def _query_pictures(shell,ole):
    """An injectable ABI boundary for fixture tests, not an arbitrary DLL loader."""
    get=shell.SHGetKnownFolderPath
    get.argtypes=[ctypes.POINTER(GUID),ctypes.c_uint32,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)]
    get.restype=ctypes.c_int32
    init=ole.CoInitializeEx;init.argtypes=[ctypes.c_void_p,ctypes.c_uint32];init.restype=ctypes.c_int32
    free=ole.CoTaskMemFree;free.argtypes=[ctypes.c_void_p];free.restype=None
    uninit=ole.CoUninitialize;uninit.argtypes=[];uninit.restype=None
    initialized=int(init(None,2))  # COINIT_APARTMENTTHREADED on this calling thread.
    if initialized not in (0,1):
        raise OSError('Windows Pictures lookup could not initialize its calling thread.')
    result=ctypes.c_void_p()
    try:
        guid=GUID.from_buffer_copy(UUID(PICTURES_GUID).bytes_le)
        status=int(get(ctypes.byref(guid),DONT_VERIFY,None,ctypes.byref(result)))
        if status!=0 or not result.value:raise OSError('Windows did not return its Pictures folder.')
        value=ctypes.wstring_at(result.value)
        if not 1<=len(value)<=32767 or any(ord(c)<32 for c in value) or not PureWindowsPath(value).is_absolute():
            raise ValueError('Windows returned an unsupported Pictures location.')
        return value
    finally:
        if result.value:free(result)
        uninit()  # Balance S_OK AND S_FALSE; never uninitialize a failed call.


def windows_pictures():
    if os.name!='nt':raise OSError('Windows known-folder lookup is unavailable on this platform.')
    # LOAD_LIBRARY_SEARCH_SYSTEM32 prevents searching the application/current path.
    shell=ctypes.WinDLL('shell32.dll',winmode=0x800)
    ole=ctypes.WinDLL('ole32.dll',winmode=0x800)
    return _query_pictures(shell,ole)
