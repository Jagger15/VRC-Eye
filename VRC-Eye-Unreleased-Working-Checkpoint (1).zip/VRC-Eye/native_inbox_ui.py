"""One native inbox for both notification families, using the shared API owner."""
from companion_ui import Page,Table,line,button,entry,choice
from account_workspace_ui import submit_review
import companion_api
import native_api
from native_events import hub_for
from automatic_sync import sync_for


class UnifiedInbox(Page):
    def __init__(self,owner,parent):
        self.owner=owner;super().__init__(owner.shell,parent,'Inbox')
        self.sync=sync_for(self.shell);self.hub=hub_for(self.shell);self.seen=-1
        self.live=self.tk.StringVar(value=self.sync.summary())
        self.ttk.Label(parent,textvariable=self.live,wraplength=950).pack(anchor='w',pady=4)
        self.results={};self.offset=0;self.query=self.tk.StringVar();self.unread=self.tk.BooleanVar();self.response=self.tk.StringVar()
        row=line(self);entry(self,row,self.query,35);button(self,row,'Filter loaded records',self.render)
        self.ttk.Checkbutton(row,text='Unread only',variable=self.unread,command=lambda:self.guard(self.render)).pack(side='left')
        row=line(self);button(self,row,'Refresh both inboxes',lambda:self.load(0));button(self,row,'Previous',lambda:self.load(max(0,self.offset-100)));button(self,row,'Next',lambda:self.load(self.offset+100))
        self.table=Table(self,parent,(('source','Family',85),('type','Type',180),('sender','Sender',180),('text','Title / message',350),('date','Time',180),('checked','Observed (UTC)',180)),height=10,select=self.selection)
        row=line(self);button(self,row,'Mark selected read…',lambda:self.mutate('read'));button(self,row,'Hide selected…',lambda:self.mutate('hide'))
        button(self,row,'Compose invitation reply',self.compose)
        row=line(self);self.response_box=choice(self,row,self.response,(),width=60);button(self,row,'Submit selected response…',lambda:self.mutate('respond'))
        self.ttk.Label(parent,text='Live observations update automatically, up to 1,000 records. Refreshing does not mark anything read. Acting on a live-only row first fetches current API evidence for review. Historical imports remain nonactionable.',wraplength=950).pack(anchor='w',pady=8)
    def require(self):self.owner.require_revealed()
    def load(self,offset):
        self.require()
        after=self.hub.revision
        def work(c,s,p):
            legacy=companion_api.read(c,'notifications',offset=offset,stop=s,progress=p)
            modern=native_api.read(c,'notifications-v2',offset=offset,stop=s,progress=p)
            return {'v1':legacy,'v2':modern}
        def done(results):
            self.results=results;self.offset=offset
            for family,snapshot in results.items():
                self.sync.observe_inbox(snapshot,after=after)
            self.render();self.status.set('Two current inbox pages loaded; more pages may exist. '+hub_for(self.shell).project()['coverage'])
        self.start(work,done)
    def render(self):
        self.require();query=self.query.get().casefold();rows=[]
        self.hub.project()
        evidence={(family,row['id']):row for family,result in self.results.items() for row in result.data}
        for key,r in self.hub.records.items():
            family,ref=key.split(':',1)
            if self.hub.notifications.get(key,{}).get('deleted'):continue
            if self.unread.get() and r.get('seen') is not False:continue
            if query and query not in ' '.join(str(r.get(k,'')) for k in ('type','senderUsername','message','title')).casefold():continue
            original=evidence.get((family,ref))
            if original is not None and native_api.bounded(original)==r:r=original
            rows.append((family,r))
        rows.sort(key=lambda pair:str(pair[1].get('createdAt') or pair[1].get('created_at') or ''),reverse=True)
        self.table.set(rows,lambda pair:(pair[0],pair[1].get('type',''),pair[1].get('senderUsername',''),pair[1].get('title') or pair[1].get('message',''),pair[1].get('createdAt') or pair[1].get('created_at',''),self.hub.notifications.get(pair[0]+':'+pair[1]['id'],{}).get('observed_at','')),identity=lambda pair:(pair[0],pair[1]['id']))
        self.seen=self.hub.revision
        self.selection()
    def selection(self):
        selected=self.table.selected();old=self.response.get();self.responses={}
        if selected and selected[0]=='v2':
            for n,response in enumerate(selected[1].get('responses',[])):
                if isinstance(response,dict) and isinstance(response.get('type'),str):self.responses[str(n+1)+' · '+str(response.get('text') or response['type'])[:150]]=response
        self.response_box.configure(values=tuple(self.responses));self.response.set(old if old in self.responses else next(iter(self.responses),''))

    def evidence_ready(self):
        selected=self.table.selected()
        if not selected:return False
        family,row=selected;result=self.results.get(family)
        try:
            if family=='v2':native_api.selected(self.app.api,result,row,'notifications-v2')
            else:companion_api.selected_record(self.app.api,result,row,'notifications')
            return True
        except (ValueError,AttributeError):return False

    def refresh_selected(self,again):
        """Fetch evidence, then open the existing one-use review; never auto-write."""
        family,row=self.table.selected();ref=row['id'];response=self.response.get();after=self.hub.revision
        previous=self.results.get(family)
        offset=self.offset if previous and any(r.get('id')==ref for r in previous.data) else 0
        def work(c,s,p):
            reader=native_api.read if family=='v2' else companion_api.read
            return reader(c,'notifications-v2' if family=='v2' else 'notifications',offset=offset,stop=s,progress=p)
        def done(result):
            selected=self.table.selected()
            if not selected or (selected[0],selected[1]['id'])!=(family,ref) or self.response.get()!=response:
                raise ValueError('Selection changed. Choose the action again.')
            self.results[family]=result;self.sync.observe_inbox(result,after=after);self.render()
            selected=self.table.selected()
            if not selected or (selected[0],selected[1]['id'])!=(family,ref) or not self.evidence_ready():
                raise ValueError('This notification was not confirmed on the current page, or changed during refresh. Review the inbox again.')
            if self.response.get()!=response:raise ValueError('Available responses changed. Choose a response again.')
            again()
        self.start(work,done)
    def signature(self):return self.context(),self.owner.private.get(),id(self.table.selected()),self.response.get(),tuple((k,id(v)) for k,v in self.results.items())
    def mutate(self,operation):
        self.require();selected=self.table.selected()
        if not selected:raise ValueError('Select a current returned notification.')
        if not self.evidence_ready():self.refresh_selected(lambda:self.mutate(operation));return
        family,row=selected;result=self.results[family];values={}
        if family=='v2':
            action={'read':'notification2-see','hide':'notification2-hide','respond':'notification2-respond'}[operation]
            if operation=='respond':values={'response':self.responses.get(self.response.get())}
        else:
            if operation=='respond':raise ValueError('Use Compose invitation reply for a legacy invitation.')
            action='see-notification' if operation=='read' else 'hide-notification'
        submit_review(self,action,result=result,row=row,values=values,view_guard=self.signature,done=lambda _:self.load(self.offset))
    def compose(self):
        self.require();selected=self.table.selected()
        if not selected or selected[0]!='v1':raise ValueError('Choose a current legacy invitation or request.')
        if not self.evidence_ready():self.refresh_selected(self.compose);return
        import social_outbound
        family,row=selected;evidence=social_outbound.selected_request(self.app.api,self.results[family],row)
        panel=self.owner.invitations;panel.clear();panel.mode.set('Reply to invitation' if row['type']=='invite' else 'Reply to invite request')
        panel.recipient.set(evidence.recipient);panel.request_result=evidence;panel.info.set('Selected returned notification for '+evidence.name)
        self.owner.tabs.select(self.owner.frames['Send invitations'])
    def account_changed(self):
        self.cancel();self.results={};self.table.set([],lambda r:());self.responses={};self.response.set('');self.query.set('')
        self.seen=-1

    def tick(self):
        from account_header import private
        if self.owner.private.get() or private(self.app):
            if self.results or self.table.records:self.account_changed()
            self.live.set('Private information hidden');return
        super().tick();self.live.set(self.sync.summary())
        self.hub.project()
        if self.hub.revision!=self.seen and self.app.api and self.app.api.authenticated:self.render()
