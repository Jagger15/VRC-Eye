"""Bounded, read-only OBJ polygon preview. No Unity/VRCA decode or code loading.

The supported subset follows Wavefront's Appendix B1 (archived at
https://www.paulbourke.net/dataformats/obj/): finite polygon vertices, optional
texture/normal indices, and positive or relative indices. Material references
are counted but never opened. Curves, surfaces and extension commands fail
explicitly rather than silently pretending to render a complete model.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
import math
from pathlib import Path
import re

from avatar_library_files import checked_stream, check_cancel, fingerprint, InspectionCancelled

MAX_BYTES = 16 * 1024 * 1024
MAX_LINE = 16384
MAX_LINES = 200000
MAX_VERTICES = 20000
MAX_TRIANGLES = 8000
MAX_FACE_VERTICES = 64
MAX_AUXILIARY = 40000
COORDINATE_LIMIT = 1e12
EPSILON = 1e-10
NUMBER = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z')
INTEGER = re.compile(r'[+-]?[0-9]{1,9}\Z')
IGNORED = frozenset(('mtllib', 'usemtl', 'o', 'g', 's'))


@dataclass(frozen=True)
class MeshPreview:
    vertices: tuple
    triangles: tuple
    source_vertices: int
    source_faces: int
    source_bytes: int
    sha256: str
    bounds: tuple
    ignored: tuple
    fingerprint: tuple
    uvs: tuple=()
    material: int=-1
    colors: tuple=()


@dataclass(frozen=True)
class Camera:
    yaw: float = 30.
    pitch: float = -15.
    zoom: float = 1.
    pan_x: float = 0.
    pan_y: float = 0.


@dataclass(frozen=True)
class ProjectedFace:
    points: tuple
    depth: float
    shade: float
    triangle: tuple=()
    depths: tuple=()


def _number(value):
    if not isinstance(value, str) or len(value) > 64 or not NUMBER.fullmatch(value):
        raise ValueError('Expected a finite, bounded decimal coordinate.')
    result = float(value)
    if not math.isfinite(result) or abs(result) > COORDINATE_LIMIT:
        raise ValueError('Coordinates must be finite and within the supported magnitude.')
    return result


def _index(value, count):
    if not isinstance(value, str) or not INTEGER.fullmatch(value):
        raise ValueError('Face references must be bounded integer indices.')
    index = int(value)
    result = index - 1 if index > 0 else count + index
    if index == 0 or not 0 <= result < count:
        raise ValueError('A face references an unavailable vertex, texture coordinate or normal.')
    return result


def _face_reference(value, vertices, textures, normals):
    parts = value.split('/')
    if len(parts) > 3 or not parts[0] or (len(parts) == 2 and not parts[1]) or (len(parts) == 3 and not parts[2]):
        raise ValueError('Use vertex, vertex/texture, vertex//normal or vertex/texture/normal references.')
    vertex = _index(parts[0], vertices)
    if len(parts) >= 2 and parts[1]:
        _index(parts[1], textures)
    if len(parts) == 3:
        _index(parts[2], normals)
    return vertex, (len(parts), bool(len(parts) >= 2 and parts[1]))


def _cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def _on_segment(a, b, p):
    return abs(_cross(a, b, p)) <= EPSILON and all(min(a[k], b[k]) - EPSILON <= p[k] <= max(a[k], b[k]) + EPSILON for k in (0, 1))


def _segments_intersect(a, b, c, d):
    ac, ad, ca, cb = _cross(a, b, c), _cross(a, b, d), _cross(c, d, a), _cross(c, d, b)
    if ((ac > EPSILON and ad < -EPSILON or ac < -EPSILON and ad > EPSILON) and
            (ca > EPSILON and cb < -EPSILON or ca < -EPSILON and cb > EPSILON)):
        return True
    return _on_segment(a, b, c) or _on_segment(a, b, d) or _on_segment(c, d, a) or _on_segment(c, d, b)


def triangulate(indices, vertices, *, stop=None):
    """Ear clipping of simple planar polygons; bounded by 64 vertices."""
    check_cancel(stop)
    if not 3 <= len(indices) <= MAX_FACE_VERTICES or len(set(indices)) != len(indices):
        raise ValueError('Faces need 3–64 distinct vertex references.')
    points = [vertices[index] for index in indices]
    low = [min(p[k] for p in points) for k in range(3)]
    span = max(max(p[k] for p in points) - low[k] for k in range(3))
    if not span > 1e-12:
        raise ValueError('A face is degenerate or too small for a stable preview.')
    points = [tuple((p[k] - low[k]) / span for k in range(3)) for p in points]
    # Newell normal is stable for a concave planar polygon with consistent order.
    normal = [0., 0., 0.]
    for a, b in zip(points, points[1:] + points[:1]):
        normal[0] += (a[1] - b[1]) * (a[2] + b[2])
        normal[1] += (a[2] - b[2]) * (a[0] + b[0])
        normal[2] += (a[0] - b[0]) * (a[1] + b[1])
    length = math.sqrt(sum(v * v for v in normal))
    if length <= EPSILON:
        raise ValueError('A face is degenerate, self-intersecting or has unsupported winding.')
    normal = [v / length for v in normal]
    if any(abs(sum(normal[k] * (p[k] - points[0][k]) for k in range(3))) > 1e-5 for p in points):
        raise ValueError('Non-planar polygon faces must be triangulated in the source editor first.')
    axis = max(range(3), key=lambda k: abs(normal[k]))
    projected = [tuple(p[k] for k in range(3) if k != axis) for p in points]
    size = len(projected)
    for i in range(size):
        check_cancel(stop)
        for j in range(i + 1, size):
            if j == i + 1 or i == 0 and j == size - 1:
                continue
            if _segments_intersect(projected[i], projected[(i + 1) % size], projected[j], projected[(j + 1) % size]):
                raise ValueError('Self-intersecting or touching polygon edges are unsupported.')
    signed_area = sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(projected, projected[1:] + projected[:1]))
    direction = 1 if signed_area > 0 else -1
    remaining = list(range(size)); output = []
    # Collinear boundary points are removable; the retained polygon is unchanged.
    while len(remaining) > 3:
        check_cancel(stop)
        found = False
        for k, middle in enumerate(remaining):
            previous, following = remaining[k - 1], remaining[(k + 1) % len(remaining)]
            a, b, c = projected[previous], projected[middle], projected[following]
            area = _cross(a, b, c) * direction
            if abs(area) <= EPSILON and _on_segment(a, c, b):
                del remaining[k]; found = True; break
            if area <= EPSILON:
                continue
            if any(all(_cross(x, y, projected[n]) * direction >= -EPSILON for x, y in ((a, b), (b, c), (c, a)))
                   for n in remaining if n not in (previous, middle, following)):
                continue
            output.append((indices[previous], indices[middle], indices[following]))
            del remaining[k]; found = True; break
        if not found:
            raise ValueError('The polygon could not be triangulated reliably. Export triangles from the source editor.')
    if len(remaining) == 3:
        a, b, c = (projected[n] for n in remaining)
        if abs(_cross(a, b, c)) <= EPSILON:
            raise ValueError('The polygon has a degenerate final triangle.')
        output.append(tuple(indices[n] for n in remaining))
    return tuple(output)


def read_obj(path, *, stop=None, progress=None):
    """Parse one explicitly selected regular file without following links."""
    check_cancel(stop)
    if Path(path).suffix.lower() != '.obj':
        raise ValueError('Select a local .obj polygon mesh. VRCA, FBX and Unity bundles are not supported by this viewer.')
    vertices, triangles, textures, normals = [], [], 0, 0
    ignored = {}; faces = 0; total = 0; digest = sha256()
    with checked_stream(path, limit=MAX_BYTES) as (_, stream, before):
        for number in range(1, MAX_LINES + 2):
            check_cancel(stop)
            raw = stream.readline(MAX_LINE + 1)
            if not raw:
                break
            total += len(raw); digest.update(raw)
            if total > MAX_BYTES or len(raw) > MAX_LINE or number > MAX_LINES:
                raise ValueError('The OBJ exceeds the byte, line-length or line-count preview limit.')
            try:
                line = raw.decode('utf-8-sig' if number == 1 else 'utf-8')
            except UnicodeDecodeError:
                raise ValueError('Use a UTF-8 or ASCII OBJ text file.') from None
            if any(ord(c) < 32 and c not in '\t\r\n' or ord(c) == 127 for c in line):
                raise ValueError('OBJ text contains unsupported control characters.')
            words = line.split('#', 1)[0].split()
            if not words:
                continue
            keyword, values = words[0], words[1:]
            try:
                if keyword == 'v':
                    if len(vertices) >= MAX_VERTICES or len(values) not in (3, 4):
                        raise ValueError('Use at most 20,000 vertices with x, y, z and optional homogeneous w; vertex colors are unsupported.')
                    xyz = tuple(_number(v) for v in values[:3])
                    if len(values) == 4:
                        w = _number(values[3])
                        if abs(w) < 1e-12:
                            raise ValueError('A vertex homogeneous weight must be nonzero.')
                        xyz = tuple(v / w for v in xyz)
                        if any(not math.isfinite(v) or abs(v) > COORDINATE_LIMIT for v in xyz):
                            raise ValueError('Homogeneous coordinates exceed the supported magnitude.')
                    vertices.append(xyz)
                elif keyword in ('vt', 'vn'):
                    if (keyword == 'vt' and not 1 <= len(values) <= 3 or keyword == 'vn' and len(values) != 3):
                        raise ValueError('Texture coordinates need 1–3 values; normals need 3.')
                    tuple(_number(v) for v in values)
                    if keyword == 'vt': textures += 1
                    else: normals += 1
                    if textures + normals > MAX_AUXILIARY:
                        raise ValueError('Texture and normal declarations exceed the bounded preview budget.')
                elif keyword == 'f':
                    if not 3 <= len(values) <= MAX_FACE_VERTICES:
                        raise ValueError('Faces need 3–64 vertex references.')
                    if len(triangles) + len(values) - 2 > MAX_TRIANGLES:
                        raise ValueError('The mesh exceeds 8,000 preview triangles. Export a reduced mesh copy.')
                    refs = [_face_reference(v, len(vertices), textures, normals) for v in values]
                    if len({r[1] for r in refs}) != 1:
                        raise ValueError('All vertices in a face must use the same reference format.')
                    triangles.extend(triangulate(tuple(r[0] for r in refs), vertices, stop=stop)); faces += 1
                elif keyword in IGNORED:
                    ignored[keyword] = ignored.get(keyword, 0) + 1
                else:
                    raise ValueError('This file contains unsupported statements; only polygon mesh geometry is previewed.')
            except InspectionCancelled:
                raise
            except ValueError as error:
                # Report only the line number and fixed diagnostic, never source paths/text.
                raise ValueError(f'OBJ line {number}: {error}') from None
            if progress and number % 256 == 0:
                progress(total, before.st_size)
        if total != before.st_size:
            raise ValueError('The OBJ size changed while reading. Select the source again.')
    check_cancel(stop)
    if not triangles:
        raise ValueError('The OBJ contains no supported nondegenerate polygon faces.')
    used = tuple(sorted({v for triangle in triangles for v in triangle}))
    low = tuple(min(vertices[n][k] for n in used) for k in range(3))
    high = tuple(max(vertices[n][k] for n in used) for k in range(3))
    center = tuple((low[k] + high[k]) / 2 for k in range(3))
    radius = max(math.sqrt(sum((vertices[n][k] - center[k]) ** 2 for k in range(3))) for n in used)
    if not radius > 1e-12:
        raise ValueError('The polygon bounds are degenerate.')
    normalized = tuple(tuple((vertices[n][k] - center[k]) / radius for k in range(3)) for n in used)
    remap = {old: new for new, old in enumerate(used)}
    remapped = tuple(tuple(remap[n] for n in triangle) for triangle in triangles)
    if textures: ignored['vt (UVs not rendered)'] = textures
    if normals: ignored['vn (flat face shading used)'] = normals
    if progress: progress(total, total)
    check_cancel(stop)
    return MeshPreview(normalized, remapped, len(vertices), faces, total, digest.hexdigest(),
                       (low, high), tuple(sorted(ignored.items())), tuple(sorted(fingerprint(before).items())))


def validate_camera(camera):
    if not isinstance(camera, Camera) or any(type(v) not in (int, float) or not math.isfinite(v)
            for v in (camera.yaw, camera.pitch, camera.zoom, camera.pan_x, camera.pan_y)):
        raise ValueError('Camera values must be finite numbers.')
    if not -180 <= camera.yaw <= 180 or not -89.9 <= camera.pitch <= 89.9 or not .1 <= camera.zoom <= 12 or max(abs(camera.pan_x), abs(camera.pan_y)) > 2:
        raise ValueError('Camera movement exceeds the bounded preview range.')
    return camera


def orbit(camera, yaw=0., pitch=0.):
    validate_camera(camera); yaw, pitch = _delta(yaw), _delta(pitch)
    return replace(camera, yaw=(camera.yaw + yaw + 180) % 360 - 180,
                   pitch=max(-89.9, min(89.9, camera.pitch + pitch)))


def _delta(value):
    if type(value) not in (int, float) or not math.isfinite(value) or abs(value) > 10000:
        raise ValueError('Preview movement must be finite and bounded.')
    return value


def pan(camera, x=0., y=0.):
    validate_camera(camera); x, y = _delta(x), _delta(y)
    return replace(camera, pan_x=max(-2., min(2., camera.pan_x + x)), pan_y=max(-2., min(2., camera.pan_y + y)))


def zoom(camera, factor):
    validate_camera(camera); factor = _delta(factor)
    if factor <= 0:
        raise ValueError('Zoom must use a positive factor.')
    return replace(camera, zoom=max(.1, min(12., camera.zoom * factor)))


def fit(camera):
    return replace(validate_camera(camera), zoom=1., pan_x=0., pan_y=0.)


def project(mesh, camera, width, height, *, stop=None,coordinate_limit=1.000001):
    """Orthographic flat faces; scene callers may retain fixed animation framing."""
    validate_camera(camera)
    if type(coordinate_limit) not in (int,float) or not math.isfinite(coordinate_limit) or not 1<=coordinate_limit<=10000:raise ValueError('Invalid projection coordinate budget.')
    if not isinstance(mesh, MeshPreview) or len(mesh.vertices) > MAX_VERTICES or len(mesh.triangles) > MAX_TRIANGLES:
        raise ValueError('A bounded parsed mesh is required.')
    if (not isinstance(mesh.vertices, tuple) or not isinstance(mesh.triangles, tuple) or
            not mesh.vertices or not mesh.triangles or any(not isinstance(v, tuple) or len(v) != 3 or
            any(type(n) not in (int, float) or not math.isfinite(n) or abs(n) > coordinate_limit for n in v)
            for v in mesh.vertices) or any(not isinstance(t, tuple) or len(t) != 3 or
            any(type(n) is not int or not 0 <= n < len(mesh.vertices) for n in t) or len(set(t)) != 3 for t in mesh.triangles)):
        raise ValueError('Mesh coordinates and triangle references must be finite and valid.')
    if any(type(value) is not int or not 1 <= value <= 10000 for value in (width, height)):
        raise ValueError('Viewport dimensions must be between 1 and 10,000 pixels.')
    cy, sy = math.cos(math.radians(camera.yaw)), math.sin(math.radians(camera.yaw))
    cp, sp = math.cos(math.radians(camera.pitch)), math.sin(math.radians(camera.pitch))
    rotated = []
    for i, (x, y, z) in enumerate(mesh.vertices):
        if i % 256 == 0: check_cancel(stop)
        rx, rz = cy * x + sy * z, -sy * x + cy * z
        rotated.append((rx, cp * y - sp * rz, sp * y + cp * rz))
    scale = min(width, height) * .42 * camera.zoom
    ox, oy = width * (.5 + camera.pan_x), height * (.5 + camera.pan_y)
    output = []
    for i, triangle in enumerate(mesh.triangles):
        if i % 256 == 0: check_cancel(stop)
        a, b, c = (rotated[n] for n in triangle)
        u = tuple(b[k] - a[k] for k in range(3)); v = tuple(c[k] - a[k] for k in range(3))
        normal = (u[1]*v[2] - u[2]*v[1], u[2]*v[0] - u[0]*v[2], u[0]*v[1] - u[1]*v[0])
        length = math.sqrt(sum(n*n for n in normal))
        shade = .35 + .65 * abs((normal[0]*.25 + normal[1]*.45 + normal[2]*.857321409974) / length) if length > EPSILON else .35
        points = tuple(value for point in (a, b, c) for value in (ox + point[0]*scale, oy - point[1]*scale))
        output.append(ProjectedFace(points, sum(point[2] for point in (a, b, c))/3, min(1., shade),triangle,tuple(point[2] for point in (a,b,c))))
    check_cancel(stop)
    return tuple(sorted(output, key=lambda face: face.depth))
