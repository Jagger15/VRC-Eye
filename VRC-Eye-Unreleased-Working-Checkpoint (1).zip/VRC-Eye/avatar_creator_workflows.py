"""Bounded, local avatar authoring records and isolated contract demonstrations.

No function here opens a socket, changes an avatar or publishes a build. Manual,
source, simulation and live observations remain distinct in every saved run.
"""
from copy import deepcopy
import hashlib
import json
import math
import re
import time
import uuid

SCHEMA = 1
STEP_STATUSES = ('Not started', 'In progress', 'Passed', 'Failed', 'Blocked',
                 'Not applicable', 'Needs verification')
MODES = ('manual', 'source', 'simulation', 'unity', 'live')
PLATFORMS = ('Windows', 'Android', 'iOS', 'Generic')
PRIMITIVES = ('value_display', 'state_indicator', 'button_request', 'progress_meter',
              'acknowledgment', 'timeout')
ACTION_IDS = ('select_profile', 'acknowledge_reminder', 'request_photo',
              'pause_effect', 'diagnostic_bookmark')
SIMULATION_SCENARIOS = ('provider_disconnect', 'avatar_switch', 'held_button',
                        'missing_acknowledgment', 'privacy_transition', 'raycast_states')


def _module(identifier, name, description, kind='avatar', parameters=(), capabilities=(), **costs):
    return dict(id=identifier, name=name, description=description, kind=kind,
                parameters=list(parameters), capabilities=list(capabilities),
                platforms=list(PLATFORMS),
                costs={key: costs.get(key, 0) for key in
                       ('renderers', 'materials', 'contacts', 'physbones', 'animations')},
                estimate_only=True, permission='private by default')


MODULE_CATALOG = {
    'avatar_link': _module('avatar_link', 'Avatar Link', 'Supported local parameter communication; explicit live arming.', 'runtime'),
    'unity_toolkit': _module('unity_toolkit', 'Unity Avatar Toolkit', 'Reviewed editor authoring; no avatar runtime scripts.', 'authoring'),
    'parameter_installer': _module('parameter_installer', 'Parameter installer', 'Proposed parameter, menu and ownership changes.', 'authoring'),
    'validator': _module('validator', 'Unity validator', 'Source and generated contract checks with evidence scope.', 'authoring'),
    'wrist': _module('wrist', 'Wrist controller', 'Left/right/manual attachment shell and external control alternatives.', renderers=1, materials=1),
    'status': _module('status', 'Status display', 'Finite creator-authored symbols; local text stays in the companion.', parameters=('EYE_In_Status',), capabilities=('status',), renderers=1, materials=1, animations=1),
    'safety': _module('safety', 'Safety bracelet', 'Reminder presentation and deliberate local request; no safety guarantee.', parameters=('EYE_In_Safety', 'EYE_Out_SafetyRequest'), capabilities=('acknowledge_reminder',), renderers=1, materials=1, contacts=1, animations=1),
    'battery': _module('battery', 'Battery display', 'Private normalized value and an independent validity indicator.', parameters=('EYE_In_BatteryLeft', 'EYE_In_BatteryLeftValid'), capabilities=('battery',), renderers=1, materials=1, animations=2),
    'streamer': _module('streamer', 'Streamer badge', 'Creator-authored recording indicator; never proof that no capture exists.', parameters=('EYE_In_Recording',), capabilities=('recording_status',), renderers=1, materials=1, animations=1),
    'music': _module('music', 'Music visualizer', 'Bounded local sample envelope; unavailable input has a neutral state.', parameters=('EYE_In_MusicLevel', 'EYE_In_MusicValid'), capabilities=('media_level',), renderers=1, materials=1, animations=2),
    'camera': _module('camera', 'Camera control', 'Finite local photo request with completion separately reported.', parameters=('EYE_Out_CameraRequest', 'EYE_In_CameraResult'), capabilities=('request_photo',), renderers=1, materials=1, contacts=1, animations=2),
    'availability': _module('availability', 'DND / AFK indicators', 'Separate authored availability values with user-selected disclosure.', parameters=('EYE_In_Availability',), capabilities=('availability',), renderers=1, materials=1, animations=1),
    'connection': _module('connection', 'Connection indicator', 'Heartbeat, acknowledgment and freshness; sent is not confirmed.', parameters=('EYE_In_Heartbeat', 'EYE_Out_HeartbeatAck'), capabilities=('heartbeat',), renderers=1, materials=1, animations=2),
    'hardware': _module('hardware', 'Hardware status', 'Coarse selected provider status; no full inventory disclosure.', parameters=('EYE_In_HardwareStatus',), capabilities=('hardware_status',), renderers=1, materials=1, animations=1),
    'resource': _module('resource', 'Resource warning', 'Local process-level warning with its source and validity.', parameters=('EYE_In_ResourceWarning',), capabilities=('resource_warning',), renderers=1, materials=1, animations=1),
    'media': _module('media', 'Local media effects', 'Finite media response; theme changes do not acquire action permissions.', parameters=('EYE_In_MediaLevel', 'EYE_In_MediaValid'), capabilities=('media_level',), renderers=1, materials=1, animations=2),
    'contact': _module('contact', 'Physical Contact buttons', 'Self-only request/release/hold/rearm testing and menu alternatives.', 'authoring', contacts=1),
    'physbone': _module('physbone', 'PhysBone diagnostics', 'Creator-supplied interaction declarations and manual runtime evidence.', 'authoring', physbones=1),
    'profile': _module('profile', 'Avatar profiles', 'Separate installation composition and supported runtime values.', 'workspace'),
    'hierarchy': _module('hierarchy', 'Authorized hierarchy', 'Read-only creator-supplied snapshot with provenance.', 'workspace'),
    'manifest': _module('manifest', 'Creator manifest', 'Versioned declarative contracts; no automatic asset fetching.', 'workspace'),
    'preview': _module('preview', 'Authorized reference preview', 'Explicitly selected bounded static reference; not runtime rendering.', 'workspace'),
    'mannequin': _module('mannequin', 'Generic mannequin', 'Isolated geometric demonstration; no actual avatar proportions.', 'workspace'),
}

# Final starter names match the editor package; these are proposed toolkit names,
# never a claim that the current avatar exposes them.
_STARTER_PARAMETERS = {
    'status': ('EYE_In_Status', 'EYE_In_StatusValid'),
    'safety': ('EYE_Out_Safety', 'EYE_In_SafetyApplied'),
    'battery': ('EYE_In_Battery', 'EYE_In_BatteryValid'),
    'streamer': ('EYE_In_Recording', 'EYE_In_RecordingValid'),
    'music': ('EYE_In_Audio', 'EYE_In_AudioValid'),
    'camera': ('EYE_Out_Camera', 'EYE_In_CameraAccepted'),
    'availability': ('EYE_In_Quiet',), 'connection': ('EYE_In_Heartbeat',),
    'hardware': ('EYE_In_Hardware', 'EYE_In_HardwareValid'),
    'resource': ('EYE_In_Resource', 'EYE_In_ResourceValid'),
    'media': ('EYE_In_Media', 'EYE_In_MediaValid'),
}
for _identifier, _parameters in _STARTER_PARAMETERS.items():
    MODULE_CATALOG[_identifier]['parameters'] = list(_parameters)
_CAPABILITIES = {'wrist': 'wrist_controller', 'status': 'status_display', 'safety': 'safety_profile',
    'battery': 'battery_display', 'streamer': 'streamer_badge', 'music': 'music_visualizer',
    'camera': 'camera_request', 'availability': 'dnd_afk', 'connection': 'connection_indicator',
    'hardware': 'hardware_status', 'resource': 'resource_warning', 'media': 'media_effect',
    'contact': 'contact_button', 'physbone': 'physbone_debug'}
for _identifier, _capability in _CAPABILITIES.items():
    MODULE_CATALOG[_identifier]['capabilities'] = [_capability]
MODULE_CATALOG['connection']['description'] = 'Changing heartbeat with an authored expiry; receipt is not authenticated proof.'


def _sheet(label, fields, help_text):
    return dict(label=label, fields=[(name, name.replace('_', ' ').title(),
                'multiline' if name in ('notes', 'expected', 'observed', 'evidence',
                    'limitations', 'steps', 'dependencies', 'known_issues', 'remedy') else 'text')
                for name in fields], help=help_text)


WORKSHEET_SCHEMAS = {
    'note': _sheet('Notes / TODOs', ('title', 'build_id', 'module_id', 'notes'), 'Private local notes. Export includes only a reviewed selection.'),
    'issue': _sheet('Issue and verification', ('title', 'build_id', 'module_id', 'status', 'expected', 'observed', 'steps', 'fix_build_id', 'verification_run_id', 'evidence'), 'Open, Fix implemented and Verified fixed are distinct; verification requires a completed passing run.'),
    'rig': _sheet('Rig and attachment fit', ('title', 'rig_type', 'platform', 'anchor', 'hand', 'pose', 'position', 'rotation', 'scale', 'touch_target_size', 'expected', 'observed', 'evidence'), 'Creator-supplied anchors only. Visual size and touch size are independent. Do not modify proportions to fit a module.'),
    'viewpoint': _sheet('Viewpoint comparison', ('title', 'build_id', 'pose', 'authored_height', 'observed_height', 'unit', 'source', 'expected', 'observed', 'evidence'), 'Source viewpoint, observed camera height and pose do not establish a single cause.'),
    'physbone': _sheet('PhysBone interaction', ('title', 'build_id', 'object_id', 'parameter', 'case', 'grab', 'pose', 'stretch', 'squish', 'source', 'expected', 'observed', 'evidence'), 'Test declared outputs, release and neutral behavior. No runtime hierarchy access is implied.'),
    'contacts': _sheet('Contact input testing', ('title', 'build_id', 'object_id', 'receiver', 'self_only', 'hand', 'hold_seconds', 'cooldown_seconds', 'release_policy', 'expected', 'observed', 'evidence'), 'Touch, request acceptance and action completion are different evidence. Test held/repeated input and release.'),
    'privacy': _sheet('Privacy data paths', ('title', 'signal', 'local_display', 'avatar_public', 'peer_share', 'report_export', 'neutral', 'validity', 'expected', 'observed', 'evidence'), 'Four independent destinations. Local Eye privacy cannot rewrite avatar Synced configuration or guarantee removal from other viewers.'),
    'platform': _sheet('Platform variant', ('title', 'platform', 'build_id', 'manifest_revision', 'tier', 'omitted_modules', 'fallback', 'synchronized_layout', 'runtime_test', 'limitations'), 'Build-time omission changes counted assets. Runtime visibility does not remove build cost.'),
    'property_conflict': _sheet('Property conflict investigation', ('title', 'object_id', 'property', 'writers', 'conditions', 'module_subtree', 'expected', 'observed', 'remedy'), 'Static overlap is a possible conflict. Preserve controller conventions and test the affected combination.'),
    'raycast': _sheet('Raycast setup and cases', ('title', 'origin', 'direction', 'result_transform', 'collision_selection', 'case', 'expected', 'observed', 'evidence'), 'Hit, miss, disabled and unavailable are separate. A ray hit grants no permission or player identity.'),
    'accessibility': _sheet('Accessible module controls', ('title', 'hand', 'pose', 'control_alternative', 'touch_target_size', 'contrast', 'reduced_motion', 'expected', 'observed', 'evidence'), 'Test left/right, one-handed, seated and external/menu alternatives without requiring a diagnosis.'),
    'build': _sheet('Build history', ('title', 'source_revision', 'configuration_revision', 'build_id', 'platform', 'manifest_revision', 'avatar_association', 'association_evidence', 'generated_at', 'limitations'), 'A local build record is separate from publication and the currently worn build.'),
    'release': _sheet('Release readiness', ('title', 'build_id', 'platforms', 'validation_record_id', 'test_run_ids', 'status', 'known_issues', 'limitations'), 'Draft, Experimental, Ready and Withdrawn are creator labels. This workflow never publishes.'),
    'handoff': _sheet('Handoff and repair guidance', ('title', 'build_id', 'audience', 'supported_modules', 'unsupported_modules', 'preset_revision', 'permissions', 'remedy', 'limitations'), 'No source assets are included automatically; portable documentation must match the selected manifest.'),
    'test_world': _sheet('Avatar test-world stations', ('title', 'world_id', 'world_build_id', 'avatar_build_id', 'station', 'lighting', 'pose', 'platform', 'expected', 'observed', 'evidence'), 'World authority remains separate. A manual station marker never invokes Udon or grants world-helper access.'),
    'playtest': _sheet('Optional creator playtest', ('title', 'build_id', 'role', 'selected_categories', 'sources_expected', 'sources_reporting', 'limitations'), 'Local until explicit reviewed sharing through VRC Eye Networking. Roles grant no control over another avatar.'),
    'dependency': _sheet('Dependency and attribution record', ('title', 'module_id', 'version', 'dependencies', 'source', 'permissions', 'notes'), 'Creator-supplied provenance is recorded, not ownership certification. No package is automatically installed.'),
    'baseline': _sheet('Comparable baseline', ('title', 'run_id', 'platform', 'build_id', 'manifest_revision', 'environment', 'source', 'metric', 'unit', 'value', 'sample_count', 'conditions'), 'Comparable source, environment, platform, units and conditions are required; missing values stay unknown.'),
}
WORKSHEETS = WORKSHEET_SCHEMAS


def _template(title, rows):
    return dict(schema=SCHEMA, version=1, title=title,
                steps=[dict(id=str(index + 1), title=name, expected=expected,
                            status='Not started', note='', evidence=[])
                       for index, (name, expected) in enumerate(rows)])


TEST_TEMPLATES = {
    'module_contract': _template('Module contract and removal', [
        ('Initialize', 'The declared neutral state appears before valid input.'),
        ('Valid value', 'The declared private input is represented; record the observed source.'),
        ('Provider disconnect', 'Stale/invalid input is unavailable rather than a frozen valid value.'),
        ('Avatar switch', 'Old queued commands and old writers stop before another avatar is armed.'),
        ('Repeat installation', 'The reviewed installation contains no duplicate owned objects.'),
        ('Remove', 'Only owned generated assets are removed; unrelated content remains.')]),
    'request_lifecycle': _template('Contact and action lifecycle', [
        ('Touch', 'Touching indicates input without claiming action completion.'),
        ('Hold / rapid repeat', 'A held or repeated request is bounded until deliberate release/rearm.'),
        ('Acknowledgment', 'Observed signal and module acknowledgment are recorded separately.'),
        ('Timeout', 'Missing completion is unconfirmed after a bounded timeout.'),
        ('Release / reconnect', 'A stale pending request never executes after reconnection.')]),
    'privacy_transition': _template('Privacy transition', [
        ('Review destinations', 'Local display, avatar-public, peer and export routes are individually identified.'),
        ('Public opt-in', 'Only the selected pre-authored public channel receives approved values.'),
        ('Return private', 'Neutral public state is requested; receipt and visual result remain separate.'),
        ('Unreachable avatar', 'Failure to reset is reported honestly; no guaranteed remote invisibility.')]),
    'fit_accessibility': _template('Fit, viewpoints and alternatives', [
        ('Left and right', 'The selected wrist layout is readable and reachable on both tested sides.'),
        ('Seated / standing', 'The module follows its declared anchor without forcing a body pose.'),
        ('Viewpoint', 'Authored and observed heights retain pose, units and source.'),
        ('Alternative input', 'Essential capability remains available through the menu or desktop UI.')]),
    'physbone_contacts': _template('PhysBone and Contact diagnostics', [
        ('Declared relationships', 'Relevant supplied objects and parameters match the recorded manifest.'),
        ('Grab / pose / stretch', 'Selected interaction values retain actual source and freshness.'),
        ('Self / other policy', 'The authored Contact permission behaves as declared.'),
        ('Release', 'State returns to the declared neutral/rearm condition without duplicate action.')]),
    'platform_parity': _template('Platform comparison', [
        ('Shared contract', 'Synchronized parameter position, type and semantics agree.'),
        ('Intentional differences', 'Omitted visuals have a documented replacement or limitation.'),
        ('Client test', 'Results distinguish actual target-client tests from source inspection.')]),
    'test_world': _template('Creator-authored test-world stations', [
        ('Environment', 'Record world/build, avatar build, lighting and station context.'),
        ('Readability', 'Selected wrist/status controls are readable in the recorded lighting.'),
        ('Interaction', 'Contact, pose and framing cases retain manual or declared-helper provenance.'),
        ('Coverage', 'Untested stations and absent world-helper evidence remain unknown.')]),
    'raycast': _template('Raycast states', [
        ('Hit', 'A declared hit moves only the intended result transform.'),
        ('Miss', 'Miss state has an explicit neutral presentation.'),
        ('Disabled / unavailable', 'No stale hit is presented as current.'),
        ('Dependency', 'The result transform does not move its own ray origin recursively.')]),
    'coexistence': _template('Profiles and OSC coexistence', [
        ('Manual override', 'A manual control is not overwritten by a lower-priority provider.'),
        ('Unsupported profile', 'Missing or incompatible settings are reported before application.'),
        ('Other tools', 'Another OSC application keeps its configured ports and routes.'),
        ('Partial restore', 'Restoring old settings preserves newer deliberate manual changes.')]),
}
TEMPLATES = TEST_TEMPLATES


def _copy(value):
    encoded = json.dumps(value, allow_nan=False, ensure_ascii=False)
    if len(encoded.encode('utf-8')) > 512 * 1024:
        raise ValueError('The selected workflow exceeds 512 KiB.')
    return json.loads(encoded)


def _text(value, limit=4000):
    if not isinstance(value, str) or len(value) > limit or '\x00' in value:
        raise ValueError('Expected bounded text without NUL characters.')
    return value.strip()


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def plan_modules(module_ids, platform='Windows', tier='minimal'):
    if platform not in PLATFORMS or tier not in ('minimal', 'standard', 'elaborate'):
        raise ValueError('Choose a supported platform and quality tier.')
    if not isinstance(module_ids, (list, tuple)) or len(module_ids) > 23:
        raise ValueError('Select at most 23 catalog entries.')
    selected = list(dict.fromkeys(module_ids))
    if any(identifier not in MODULE_CATALOG for identifier in selected):
        raise ValueError('Unknown module catalog entry.')
    requested = list(selected)
    if any(MODULE_CATALOG[identifier]['kind'] == 'avatar' for identifier in selected) and 'connection' not in selected:
        selected.append('connection')
    modules = [deepcopy(MODULE_CATALOG[identifier]) for identifier in selected]
    costs = {key: sum(module['costs'][key] for module in modules)
             for key in ('renderers', 'materials', 'contacts', 'physbones', 'animations')}
    return dict(modules=modules, requested_modules=requested,
                dependencies_added=[identifier for identifier in selected if identifier not in requested],
                platform=platform, tier=tier, estimated_costs=costs,
                private_synced_bits=0, parameter_names=sorted({name for module in modules for name in module['parameters']}),
                status='Authoring plan', generated_build_measured=False,
                limitations=['Counts estimate standalone primitives; sharing and build processing can change totals.',
                             'The selected tier is a design target, not a generated-build measurement.',
                             'Actual synchronized bits require the final parameter contract.',
                             'Saving this plan does not install or publish assets.'])


class AvatarWorkflows:
    def __init__(self, store, clock=time.time):
        self.store, self.clock = store, clock

    def templates(self):
        return deepcopy(TEST_TEMPLATES)

    def install_template(self, avatar_id, template_id):
        if template_id not in TEST_TEMPLATES:
            raise ValueError('Unknown avatar test template.')
        return self.store.save('checklist', avatar_id, dict(template_id=template_id,
                               **deepcopy(TEST_TEMPLATES[template_id])))

    def start_run(self, avatar_id, template_id='module_contract', *, context=None, mode='manual'):
        if mode not in MODES or template_id not in TEST_TEMPLATES:
            raise ValueError('Unknown test mode or template.')
        template = deepcopy(TEST_TEMPLATES[template_id])
        context = _copy(context or {})
        if not isinstance(context, dict):
            raise ValueError('A test context must be an object.')
        if str(context.get('environment', '')).casefold() in ('simulation', 'isolated simulation'):
            mode = 'simulation'
        return self.store.save('run', avatar_id, dict(schema=SCHEMA, title=template['title'],
            template_id=template_id, template_snapshot=template,
            template_hash=_fingerprint(template), context=context, context_hash=_fingerprint(context),
            mode=mode, simulated=mode == 'simulation', status='In progress', started_at=self.clock(),
            finished_at=None, steps=deepcopy(template['steps']),
            limitations='Results apply only to the recorded evidence mode and context.'))

    def _run(self, run_id):
        run = self.store.get(run_id)
        if not run or run['kind'] != 'run':
            raise ValueError('Choose an existing avatar test run.')
        data = deepcopy(run['data'])
        if data.get('finished_at') is not None:
            raise ValueError('Completed runs are immutable. Start another run.')
        if _fingerprint(data['template_snapshot']) != data['template_hash'] or _fingerprint(data['context']) != data['context_hash']:
            raise ValueError('The run snapshot changed; preserve it and start another run.')
        return run, data

    def set_step_result(self, run_id, step_id, status, note='', evidence=None):
        if status not in STEP_STATUSES:
            raise ValueError('Unknown test-step status.')
        run, data = self._run(run_id)
        step = next((s for s in data['steps'] if s['id'] == str(step_id)), None)
        if step is None:
            raise ValueError('The step is not in this run snapshot.')
        note = _text(note)
        evidence = _copy(evidence or [])
        if not isinstance(evidence, list) or len(evidence) > 50:
            raise ValueError('Select at most 50 evidence entries.')
        if status in ('Passed', 'Failed') and not (note or evidence):
            raise ValueError('Record an observation or selected evidence for a pass/fail result.')
        step.update(status=status, note=note, evidence=evidence, recorded_at=self.clock(),
                    evidence_mode=data['mode'])
        return self.store.save('run', run['avatar_id'], data, record_id=run_id)

    def finish_run(self, run_id):
        run, data = self._run(run_id)
        states = [s['status'] for s in data['steps']]
        if 'Failed' in states:
            outcome = 'Failed'
        elif states and all(s in ('Passed', 'Not applicable') for s in states) and 'Passed' in states:
            outcome = 'Passed'
        else:
            outcome = 'Needs verification'
        data.update(status=outcome, finished_at=self.clock())
        return self.store.save('run', run['avatar_id'], data, record_id=run_id)

    def save_worksheet(self, avatar_id, worksheet_type, values, record_id=None):
        if worksheet_type not in WORKSHEET_SCHEMAS or not isinstance(values, dict):
            raise ValueError('Unknown worksheet or invalid fields.')
        allowed = {field[0] for field in WORKSHEET_SCHEMAS[worksheet_type]['fields']}
        if set(values) - allowed:
            raise ValueError('The worksheet contains unsupported fields.')
        data = {key: _text(value) for key, value in values.items()}
        if not data.get('title'):
            raise ValueError('Give the worksheet a title.')
        if worksheet_type == 'issue':
            status = data.get('status') or 'Open'
            if status not in ('Open', 'Investigation', 'Fix implemented', 'Verified fixed', 'Closed'):
                raise ValueError('Choose Open, Investigation, Fix implemented, Verified fixed or Closed.')
            if status == 'Verified fixed':
                verified = self.store.get(data.get('verification_run_id', ''))
                if not verified or verified.get('avatar_id') != avatar_id or verified['kind'] != 'run' or verified['data'].get('status') != 'Passed' or verified['data'].get('finished_at') is None:
                    raise ValueError('Verification needs a completed passing run for this avatar.')
                if (verified['data'].get('mode') == 'simulation' or
                        str(verified['data'].get('context', {}).get('environment', '')).casefold() in ('simulation', 'isolated simulation')):
                    raise ValueError('An isolated demonstration cannot verify a runtime fix.')
            data['status'] = status
        for key in ('authored_height', 'observed_height', 'hold_seconds', 'cooldown_seconds', 'touch_target_size'):
            if data.get(key):
                try:
                    number = float(data[key])
                except (TypeError, ValueError):
                    raise ValueError(key.replace('_', ' ') + ' must be a finite nonnegative number.') from None
                if not math.isfinite(number) or not 0 <= number <= 100000:
                    raise ValueError('Worksheet number is outside the supported range.')
        if data.get('hand') and data['hand'].casefold() not in ('left', 'right', 'both', 'manual'):
            raise ValueError('Choose left, right, both or manual handedness.')
        if worksheet_type == 'release' and data.get('status') not in ('', None, 'Draft', 'Experimental', 'Ready', 'Withdrawn'):
            raise ValueError('Choose Draft, Experimental, Ready or Withdrawn release state.')
        data.update(schema=SCHEMA, worksheet_type=worksheet_type, source='manual',
                    help=WORKSHEET_SCHEMAS[worksheet_type]['help'])
        return self.store.save(worksheet_type, avatar_id, data, record_id=record_id)

    plan_modules = staticmethod(plan_modules)

    def save_plan(self, avatar_id, module_ids, platform='Windows', tier='minimal'):
        return self.store.save('installation_plan', avatar_id, plan_modules(module_ids, platform, tier))

    def compose_module(self, avatar_id, recipe):
        if not isinstance(recipe, dict) or set(recipe) - {'id', 'title', 'version', 'platforms', 'primitives', 'theme'}:
            raise ValueError('A module recipe must be declarative and contain supported fields only.')
        identifier = _text(recipe.get('id', ''), 64)
        if not re.fullmatch(r'[a-z][a-z0-9_-]{0,63}', identifier):
            raise ValueError('Use a lowercase module identifier.')
        primitives = recipe.get('primitives', [])
        if not isinstance(primitives, list) or not 1 <= len(primitives) <= 32:
            raise ValueError('Compose between 1 and 32 finite primitives.')
        clean = []
        for primitive in primitives:
            if not isinstance(primitive, dict) or set(primitive) - {'type', 'parameter', 'label', 'action', 'neutral', 'timeout_seconds'}:
                raise ValueError('Unsupported primitive fields.')
            kind = primitive.get('type')
            if kind not in PRIMITIVES:
                raise ValueError('Unknown finite primitive.')
            parameter = _text(primitive.get('parameter', ''), 128)
            if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,127}', parameter):
                raise ValueError('Use a safe final parameter name.')
            action = primitive.get('action', '')
            if action and (kind != 'button_request' or action not in ACTION_IDS):
                raise ValueError('Actions are finite local requests on button primitives only.')
            timeout = primitive.get('timeout_seconds', 5)
            if type(timeout) not in (int, float) or not math.isfinite(timeout) or not .1 <= timeout <= 60:
                raise ValueError('Choose a timeout between 0.1 and 60 seconds.')
            neutral = primitive.get('neutral', 0)
            if type(neutral) not in (bool, int, float) or isinstance(neutral, float) and not math.isfinite(neutral):
                raise ValueError('A neutral value must be finite and typed.')
            clean.append(dict(type=kind, parameter=parameter, label=_text(primitive.get('label', ''), 120),
                              action=action, neutral=neutral, timeout_seconds=timeout))
        platforms = recipe.get('platforms', ['Windows'])
        if not isinstance(platforms, list) or not platforms or any(p not in PLATFORMS for p in platforms):
            raise ValueError('Choose supported platform targets.')
        theme = _text(recipe.get('theme', 'minimal'), 64)
        return self.store.save('module_recipe', avatar_id, dict(schema=1, id=identifier,
            title=_text(recipe.get('title', identifier), 160), version=_text(recipe.get('version', '1.0.0'), 32),
            platforms=list(dict.fromkeys(platforms)), primitives=clean, theme=theme,
            status='Data-only authoring recipe', uninstall='owned_only', permissions=[],
            limitations='This recipe is inspectable source data. Review and install supported components in Unity separately.'))

    def save_profile(self, avatar_id, profile, record_id=None):
        allowed = {'title', 'kind', 'manifest_revision', 'platform', 'settings', 'values',
                   'modules', 'privacy', 'description', 'account_id', 'package_id', 'allow_public', 'visibility'}
        if not isinstance(profile, dict) or set(profile) - allowed:
            raise ValueError('Unknown profile fields; pending requests and connection state cannot be saved.')
        kind = profile.get('kind', 'runtime')
        if kind not in ('runtime', 'installation'):
            raise ValueError('Choose a runtime or installation preset.')
        if 'settings' in profile and 'values' in profile:
            raise ValueError('Supply values or settings, not both.')
        values = profile.get('values', {})
        if not isinstance(values, dict):
            raise ValueError('Profile values must map parameter names to typed values.')
        settings = profile.get('settings', [dict(parameter=k, value=v) for k, v in values.items()])
        if not isinstance(settings, list) or len(settings) > 256:
            raise ValueError('A preset may contain at most 256 explicit settings.')
        for item in settings:
            if not isinstance(item, dict) or set(item) != {'parameter', 'value'} or not isinstance(item['parameter'], str):
                raise ValueError('Each preset setting needs only parameter and value.')
            if type(item['value']) not in (bool, int, float) or not math.isfinite(float(item['value'])):
                raise ValueError('Preset values must be finite Bool, Int or Float values.')
        if len({item['parameter'] for item in settings}) != len(settings):
            raise ValueError('A preset cannot contain competing settings for the same parameter.')
        for name in (item['parameter'] for item in settings):
            if not name or len(name) > 128 or not re.fullmatch(r'[A-Za-z0-9_./-]+', name) or any(part in ('', '.', '..') for part in name.split('/')):
                raise ValueError('Preset parameters must be exact supported relative parameter names.')
        if profile.get('platform') and profile['platform'] not in PLATFORMS:
            raise ValueError('Choose a supported profile platform.')
        for key in ('manifest_revision', 'package_id'):
            if profile.get(key) and not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]{0,79}', profile[key]):
                raise ValueError('Profile revision and package IDs must be portable identifiers.')
        account = profile.get('account_id', '')
        if account:
            try:
                canonical = 'usr_' + str(uuid.UUID(account[4:]))
            except (ValueError, TypeError, AttributeError):
                raise ValueError('Use a stable canonical account identifier or leave it unbound.') from None
            if account != canonical:
                raise ValueError('Use a stable canonical account identifier or leave it unbound.')
        if type(profile.get('allow_public', False)) is not bool:
            raise ValueError('Public-channel intent must be an explicit Boolean.')
        if profile.get('visibility', 'private') != 'private':
            raise ValueError('Saved profile visibility is local private; sharing is a separate reviewed action.')
        privacy = profile.get('privacy', 'private')
        if isinstance(privacy, dict):
            if set(privacy) - {'local_display', 'avatar_public', 'peer_share', 'report_export'} or any(type(v) is not bool for v in privacy.values()):
                raise ValueError('Privacy paths must use supported explicit Boolean choices.')
        elif privacy not in ('private', 'reviewed_public'):
            raise ValueError('Choose a supported privacy intent.')
        if 'description' in profile:
            _text(profile['description'])
        data = _copy(profile)
        data.pop('settings', None)
        data['values'] = {item['parameter']: item['value'] for item in settings}
        data.update(schema=1, kind=kind, title=_text(profile.get('title', ''), 160),
                    limitations='Saving does not apply values or add missing avatar assets.')
        if not data['title']:
            raise ValueError('Give the profile a title.')
        return self.store.save('profile', avatar_id, data, record_id=record_id)

    @staticmethod
    def preview_profile(profile, manifest):
        profile = profile.get('data', profile)
        manifest_available = isinstance(manifest, dict)
        manifest = manifest if manifest_available else {}
        params = {p['name']: p for p in manifest.get('parameters', [])}
        supported, unsupported = [], []
        revision_match = not profile.get('manifest_revision') or profile['manifest_revision'] == manifest.get('revision')
        platform_match = not profile.get('platform') or profile['platform'] == manifest.get('platform')
        package_match = not profile.get('package_id') or profile['package_id'] == manifest.get('package_id')
        settings = profile.get('settings', [dict(parameter=k, value=v) for k, v in profile.get('values', {}).items()])
        for setting in settings:
            parameter = params.get(setting['parameter'])
            reason = ''
            if profile.get('kind', 'runtime') != 'runtime':
                reason = 'Installation presets are authoring plans, not runtime parameter controls.'
            elif not manifest_available:
                reason = 'No selected manifest; import a matching contract before previewing runtime values.'
            elif not revision_match or not platform_match or not package_match:
                reason = 'Manifest revision, package or platform differs; explicit migration is required.'
            elif parameter is None:
                reason = 'Parameter is absent; no similar-name substitution.'
            elif parameter.get('direction') != 'in':
                reason = 'Output parameters are observations, not writable preset controls.'
            elif parameter.get('ephemeral') or parameter.get('action'):
                reason = 'Ephemeral state and pending actions are excluded from presets.'
            elif parameter.get('privacy') == 'public' or parameter.get('synced'):
                reason = 'A public destination requires separate runtime approval.'
            else:
                value, kind = setting['value'], parameter.get('type')
                if (kind == 'Bool' and type(value) is not bool or kind == 'Int' and type(value) is not int
                        or kind == 'Float' and type(value) not in (int, float)):
                    reason = 'The setting type differs from the declared contract.'
                elif type(value) in (int, float) and not parameter.get('min', -1) <= value <= parameter.get('max', 255):
                    reason = 'The setting is outside the declared range.'
            row = dict(setting, reason=reason)
            if not reason and parameter.get('type') == 'Float':
                row['value'] = float(row['value'])
            (unsupported if reason else supported).append(row)
        return dict(supported=supported, unsupported=unsupported, applied=False,
                    limitations='Preview only. Runtime application is not atomic; newer manual overrides must be preserved.')

    @staticmethod
    def compare(left_manifest, right_manifest):
        from avatar_manifest import compare_manifests
        return dict(changes=compare_manifests(left_manifest, right_manifest),
                    evidence='Supplied manifest comparison',
                    limitations='A declaration or build difference does not prove the currently worn runtime build.')

    @staticmethod
    def compare_baselines(left, right):
        a, b = left.get('data', left), right.get('data', right)
        fields = ('platform', 'environment', 'source', 'metric', 'unit', 'conditions')
        mismatches = [key for key in fields if not a.get(key) or not b.get(key) or a[key] != b[key]]
        if left.get('avatar_id') != right.get('avatar_id'):
            mismatches.append('avatar_id')
        if a.get('mode') != b.get('mode'):
            mismatches.append('mode')
        if mismatches:
            return dict(comparable=False, mismatches=mismatches, delta=None)
        try:
            x, y = float(a['value']), float(b['value'])
            samples = (int(a['sample_count']), int(b['sample_count']))
        except (KeyError, ValueError, TypeError):
            return dict(comparable=False, mismatches=['measurement or sample count unavailable'], delta=None)
        if not all(math.isfinite(v) for v in (x, y)) or min(samples) < 2:
            return dict(comparable=False, mismatches=['finite repeated samples required'], delta=None)
        return dict(comparable=True, mismatches=[], delta=y-x, unit=a['unit'],
                    limitations='Descriptive difference under supplied conditions; causation is unconfirmed.')

    def simulate(self, avatar_id, scenario='provider_disconnect', context=None):
        scenarios = {
            'provider_disconnect': [('neutral', None, False), ('valid sample', .65, True), ('source unavailable', None, False)],
            'avatar_switch': [('avatar A pending', None, False), ('switch invalidates queue', None, False), ('avatar B unarmed', None, False)],
            'held_button': [('released', False, True), ('press accepted once', True, True), ('held; no repeat', True, True), ('release rearms', False, True)],
            'missing_acknowledgment': [('request sent in simulation', None, True), ('timeout; completion unconfirmed', None, False)],
            'privacy_transition': [('private by default', 0, True), ('public explicitly approved', 1, True), ('private requests neutral', 0, True)],
            'raycast_states': [('simulated hit', .5, True), ('simulated miss', None, False), ('disabled', None, False)],
        }
        if scenario not in scenarios:
            raise ValueError('Choose a built-in isolated simulation.')
        events = [dict(sequence=i+1, state=state, value=value, valid=valid,
                       source='isolated demonstration', simulated=True)
                  for i, (state, value, valid) in enumerate(scenarios[scenario])]
        return self.store.save('simulation', avatar_id, dict(title=scenario.replace('_', ' ').title(),
            scenario=scenario, context=_copy(context or {}), mode='simulation', simulated=True,
            events=events, status='Demonstration complete', live_commands_sent=0,
            limitations='A deterministic teaching fixture, not an executed live test or validation of an installed module.'))
