"""Steam/VRChat status from the existing resource owner, never a second scan."""


def observed(snapshot):
    sample=snapshot.get('sample');age=snapshot.get('age')
    available=sample is not None and not snapshot.get('stale',True)
    rows={name:(state,count) for name,state,count in getattr(sample,'applications',())} if available else {}
    result={}
    for name in ('Steam','VRChat'):
        state,count=rows.get(name,('Unknown',None))
        result[name]=dict(name=name,state=state,count=count,age=age if available else None,
            running=True if state=='Running' else False if state=='Not observed' else None,
            source='Shared OS process observation' if available else 'Monitoring disabled, stale or unavailable')
    return result


def snapshot(shell):
    page=getattr(shell,'pages',{}).get('Performance & Security')
    return observed(page.service.snapshot() if page else {})
