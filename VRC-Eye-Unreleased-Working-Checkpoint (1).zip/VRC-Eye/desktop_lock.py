"""Local passphrase lock: privacy boundary plus active-session disconnection."""

from text_viewport import window_body
import hashlib
import hmac
import os
import time

KEY='desktop.lock.verifier.v1'


def verifier(secret,salt=None):
    if not isinstance(secret,str) or not 8<=len(secret)<=256:raise ValueError('Use a local lock passphrase of 8–256 characters.')
    salt=salt or os.urandom(16)
    return dict(schema=1,salt=salt.hex(),digest=hashlib.scrypt(secret.encode('utf-8'),salt=salt,n=16384,r=8,p=1,dklen=32).hex())


class AppLock:
    def __init__(self,app,store,*,clock=time.monotonic):
        self.app,self.store,self.clock=app,store,clock;self.last_input=clock();self.failures=0;self.retry_at=0;self.hidden_before=False;self.closed=False
        self.curtain=None;self.hidden_windows=[]
        self.app.desktop_locked=False
        for event in ('<KeyPress>','<ButtonPress>','<Motion>'):
            app.root.bind_all(event,self.input,add='+')
    def input(self,event=None):
        if not self.closed and not self.app.desktop_locked:self.last_input=self.clock()
    def setup(self,secret):
        if self.app.desktop_locked:raise ValueError('Unlock before changing the passphrase.')
        if self.store.option(KEY):raise ValueError('Remove the existing lock with its passphrase before replacing it.')
        self.store.set_option(KEY,verifier(secret));self.input()
    def verify(self,secret):
        if self.clock()<self.retry_at:raise ValueError('Wait before the next unlock attempt.')
        record=self.store.option(KEY)
        if not record:raise ValueError('Set a local lock passphrase first.')
        if not isinstance(record,dict) or record.get('schema')!=1:raise ValueError('The local lock record is invalid.')
        if not isinstance(record.get('salt'),str) or len(record['salt'])!=32 or not isinstance(record.get('digest'),str) or len(record['digest'])!=64:
            raise ValueError('The local lock record is invalid.')
        try:actual=verifier(secret,bytes.fromhex(record['salt']))['digest']
        except (ValueError,KeyError,TypeError):actual=''
        if not hmac.compare_digest(actual,str(record.get('digest',''))):
            self.failures+=1;self.retry_at=self.clock()+min(60,2**min(self.failures,6));raise ValueError('The local lock passphrase did not match.')
        self.failures=0;self.retry_at=0
    def remove(self,secret):
        self.verify(secret);self.store.set_option(KEY,None)
    def lock(self):
        if not self.store.option(KEY):raise ValueError('Set a local lock passphrase first.')
        if self.app.desktop_locked:return
        self.hidden_before=bool(getattr(self.app,'account_identity_hidden',False));self.app.desktop_locked=True
        self.app.account_identity_hidden=True;self.app._native_private=True
        restore=getattr(self.app,'session_restore',None)
        if restore:restore.disconnect()
        self.app.set_api_client(None)
        for stop in tuple(getattr(self.app,'transfer_stops',())):stop.set()
        self.show_curtain()
    def show_curtain(self):
        """Hide existing windows as well as data projections; keep unlock reachable."""
        root=self.app.root
        if self.curtain is not None:
            self.curtain.deiconify();self.curtain.lift();return
        def visit(widget):
            for child in widget.winfo_children():
                if child.winfo_toplevel() is child:
                    self.hidden_windows.append((child,child.state()));child.withdraw()
                else:visit(child)
        visit(root);self.root_state=root.state();root.withdraw()
        tk,ttk=self.app.tk,self.app.ttk
        win=tk.Toplevel(root);self.curtain=win;win.title('VRC Eye · locked');win.geometry('450x220')
        frame=ttk.Frame(window_body(win),padding=20);frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='VRC Eye is locked.',style='Title.TLabel').pack(anchor='w')
        ttk.Label(frame,text='Unlock with your local passphrase. Reconnect your account after unlocking.',wraplength=395).pack(anchor='w',pady=8)
        secret=tk.StringVar();message=tk.StringVar()
        field=ttk.Entry(frame,textvariable=secret,show='•');field.pack(fill='x');field.focus_set()
        def submit(event=None):
            try:self.unlock(secret.get())
            except ValueError as error:message.set(str(error));secret.set('')
        ttk.Label(frame,textvariable=message,wraplength=395).pack(anchor='w',pady=5)
        ttk.Button(frame,text='Unlock',command=submit).pack(anchor='e')
        win.bind('<Return>',submit);win.protocol('WM_DELETE_WINDOW',lambda:win.iconify())
        win.grab_set();win.lift()
    def unlock(self,secret):
        self.verify(secret);self.app.desktop_locked=False;self.app.account_identity_hidden=self.hidden_before
        from account_header import private
        self.app._native_private=private(self.app);self.input()
        if self.curtain is not None:
            self.curtain.grab_release();self.curtain.destroy();self.curtain=None
            for win,state in self.hidden_windows:
                try:
                    if win.winfo_exists() and state!='withdrawn':win.state(state)
                except self.app.tk.TclError:pass
            self.hidden_windows=[]
            self.app.root.state(self.root_state if self.root_state!='withdrawn' else 'normal')
        return 'Unlocked. Sign in or explicitly restore a saved session to reconnect.'
    def tick(self,minutes):
        if minutes and not self.app.desktop_locked and self.store.option(KEY) and self.clock()-self.last_input>=minutes*60:self.lock()
    def close(self):self.closed=True
