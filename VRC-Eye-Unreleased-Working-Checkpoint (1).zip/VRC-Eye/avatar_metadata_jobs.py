"""Scoped catalog backfill, sharing the API owner and durable catalog receipts."""
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import base64
import json
import time
import uuid

from avatar_library import (scope_id, stamp, normalize_observation, document_from_item,
                            _TABLE)
from avatar_library_files import check_cancel, image_preview, InspectionCancelled
from vrchat_api import APIError, avatar_search_item

MODES = ('Fill missing', 'Refresh stale (7 days)', 'Refresh selected')
FIELDS = ('name', 'author', 'author_id', 'description', 'visibility', 'tags',
          'created_at', 'updated_at', 'version', 'platforms', 'current_builds')
LIMIT = 100


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def field_digest(row, key):
    return sha256(canonical([key in row, row.get(key), row.get('field_evidence', {}).get(key)]).encode()).hexdigest()


def missing(row, key):
    value = row.get(key)
    return value in (None, '', [], {}, 'unknown', 'Unknown name', 'Unknown creator') or key == 'name' and value == row['id']


def due(row, key, mode, now):
    if mode == 'Refresh selected' or missing(row, key): return True
    if mode == 'Fill missing': return False
    evidence = row.get('field_evidence', {}).get(key, {})
    # Locally attached pictures are preserved by stale-provider refreshes.
    if key == 'thumbnail' and evidence.get('source') != 'VRChat API': return False
    try:
        observed = datetime.fromisoformat(evidence['observed_at'].replace('Z', '+00:00'))
        return observed.tzinfo is None or now - observed.timestamp() >= 7 * 86400
    except (KeyError, TypeError, ValueError, OverflowError): return True


@dataclass(frozen=True)
class Plan:
    scope: str
    payload: str
    expires: float

    @property
    def data(self): return json.loads(self.payload)


def prepare(library, account, identifiers, *, mode='Fill missing', thumbnails=False):
    account = scope_id(account)
    if account == 'local': raise ValueError('Sign in before preparing provider metadata updates.')
    if mode not in MODES or type(thumbnails) is not bool: raise ValueError('Choose valid metadata update options.')
    identifiers = tuple(dict.fromkeys(identifiers))
    if not 1 <= len(identifiers) <= LIMIT: raise ValueError('Choose 1–100 catalog avatars.')
    items = []; now = library.clock()
    for ref in identifiers:
        row = library.get(account, ref)
        if row is None: raise ValueError('A selected avatar was removed. Prepare again.')
        if ref.startswith('local:'): continue
        keys = [k for k in FIELDS if due(row, k, mode, now)]
        if thumbnails and due(row, 'thumbnail', mode, now): keys.append('thumbnail')
        if not keys: continue
        items.append(dict(avatar_id=ref, name=row.get('name') or ref, state='Pending',
            fields=keys, expected={k:field_digest(row, k) for k in keys},
            updated=[], conflicts=[], unavailable=[], message=''))
    if not items: raise ValueError('No selected online avatar needs the requested fields.')
    data = dict(schema=1, id=str(uuid.uuid4()), account=account, mode=mode,
                thumbnails=thumbnails, state='Prepared', items=items, created_at=stamp(library.clock),
                started_at='', finished_at='', boot_id=library.boot_id)
    # Validate before review so an oversized plan never starts a partial batch.
    from avatar_creator_store import json_copy
    json_copy(data)
    return Plan(account, canonical(data), time.monotonic()+300)


def summary(plan):
    data = plan.data
    lines = [f"Account: {plan.scope}", f"Mode: {data['mode']}",
             f"{len(data['items'])} avatar(s); existing API pacing is shared with friend sync.",
             'Each request can wait at least a minute for the shared budget. Cancel is available.',
             'Only reviewed fields are saved. Notes, favorites and local files are preserved.',
             'Actual available metadata may be incomplete; no avatar assets are downloaded.',
             'Pictures: '+('allow supported thumbnails for reviewed entries' if data['thumbnails'] else 'off'), '']
    lines += [item['name']+' · '+item['avatar_id']+'\n  '+', '.join(item['fields']) for item in data['items']]
    return '\n'.join(lines)


def _write(library, db, data):
    library._put(db, data['account'], 'backfill', data['id'], data['items'][0]['avatar_id'], data)


def jobs(library, account):
    result = library.records(account, 'backfill', limit=100)
    for data in result:
        if data['state'] == 'Running' and data.get('boot_id') != library.boot_id:
            data['state'] = 'Interrupted'
            for item in data['items']:
                if item['state'] == 'Reading': item['state'] = 'Interrupted'
    return result


def remaining(data):
    return tuple(item['avatar_id'] for item in data['items']
                 if item['state'] != 'Complete' or item.get('conflicts') or item.get('unavailable'))


def receipt_text(data):
    lines = [f"{data['state']} · {data['mode']}",
             'Started: '+(data['started_at'] or 'Not started'),
             'Finished: '+(data['finished_at'] or 'Still running / interrupted'), '']
    for item in data['items']:
        lines += [item['name']+' · '+item['avatar_id'], 'Result: '+item['state']]
        for label, key in (('Updated','updated'), ('Preserved concurrent edits','conflicts'), ('Not supplied','unavailable')):
            if item[key]: lines.append(label+': '+', '.join(item[key]))
        if item['message']: lines.append(item['message'])
        lines.append('')
    return '\n'.join(lines)


class GuardedStop:
    def __init__(self, stop, allowed): self.stop, self.allowed = stop, allowed
    def is_set(self):
        return bool(self.stop is not None and self.stop.is_set()) or not self.allowed()


def run(library, plan, client, *, stop=None, progress=None, allowed=lambda: True, fetch_image=None):
    """A new review is required for every run, including interrupted remainders."""
    if not isinstance(plan, Plan) or time.monotonic() > plan.expires:
        raise ValueError('The metadata review expired. Prepare it again.')
    expected = (client.user_id, client.session_revision)
    if expected[0] != plan.scope or not client.authenticated:
        raise ValueError('The signed-in account does not match this metadata batch.')
    guarded = GuardedStop(stop, lambda: allowed() and client.authenticated and
                          (client.user_id, client.session_revision) == expected)
    def check(): check_cancel(guarded)
    data = plan.data
    if data['account'] != plan.scope: raise ValueError('Invalid metadata batch scope.')
    check()
    with library.store._transaction() as db:
        if library._load(db, plan.scope, 'backfill', data['id']): raise ValueError('This reviewed batch has already run.')
        # Keep concurrent batches serialized across multiple windows/controllers.
        for raw in db.execute(f"SELECT data FROM {_TABLE} WHERE scope=? AND kind='backfill'", (plan.scope,)):
            old = json.loads(raw[0])
            if old.get('state') == 'Running' and old.get('boot_id') == library.boot_id:
                raise ValueError('A catalog metadata batch is already running.')
        data.update(state='Running', started_at=stamp(library.clock))
        _write(library, db, data)
    library.revision += 1
    if fetch_image is None:
        from profile_images import fetch_preview
        fetch_image = fetch_preview
    try:
        for index, item in enumerate(data['items']):
            check()
            item['state'] = 'Reading'
            with library.store._transaction() as db: _write(library, db, data)
            if progress: progress(f"Catalog metadata {index+1}/{len(data['items'])}: {item['name']}")
            try:
                result = client.lookup('avatar', item['avatar_id'], stop=guarded, progress=progress)
                check()
                document = {k:v for k,v in document_from_item(avatar_search_item(result)).items() if v is not None}
                # The provider's unavailable placeholders are not metadata values.
                for key, placeholders in (('name', ('Unknown name',)), ('authorName', ('Unknown creator',))):
                    if document.get(key) in placeholders: document.pop(key, None)
                for key in ('created_at', 'updated_at'):
                    if not document.get(key): document.pop(key, None)
                if document.get('releaseStatus') == 'unknown': document.pop('releaseStatus', None)
                observation = normalize_observation(document, 'VRChat API')
                if observation['metadata']['id'] != item['avatar_id']:
                    raise ValueError('The provider returned a different avatar ID.')
                thumbnail = None
                if 'thumbnail' in item['fields'] and observation['preview_url']:
                    try:
                        check()
                        picture = fetch_image(client, observation['preview_url'], stop=guarded)
                        check()
                        thumbnail = base64.b64encode(image_preview(picture, (220,140))).decode('ascii')
                    except (APIError, ValueError, OSError):
                        check(); item['message'] = 'Metadata read; thumbnail unavailable.'
                check()
                with library.store._transaction() as db:
                    current = library._load(db, plan.scope, 'avatar', item['avatar_id'])
                    if current is None:
                        # Native favorites can be projected without an AvatarLibrary row.
                        current = library.get(plan.scope, item['avatar_id'])
                    if current is None:
                        item.update(state='Skipped', message='Catalog entry was removed; no replacement created.')
                    else:
                        metadata = {'id': item['avatar_id']}
                        for key in item['fields']:
                            if field_digest(current, key) != item['expected'][key]:
                                item['conflicts'].append(key); continue
                            if key == 'thumbnail':
                                if thumbnail is None: item['unavailable'].append(key)
                                else: item['updated'].append(key)
                            elif key in observation['metadata']:
                                metadata[key] = observation['metadata'][key]; item['updated'].append(key)
                            else: item['unavailable'].append(key)
                        builds = observation['builds'] if 'current_builds' in metadata else []
                        # Materialize only the original projected catalog entry.
                        if library._load(db, plan.scope, 'avatar', item['avatar_id']) is None:
                            library._put(db, plan.scope, 'avatar', item['avatar_id'], item['avatar_id'], current)
                        saved = library._observe_into(db, plan.scope, dict(metadata=metadata, builds=builds), 'VRChat API', stamp(library.clock))
                        if 'thumbnail' in item['updated']:
                            saved['thumbnail'] = thumbnail
                            saved['field_evidence']['thumbnail'] = dict(source='VRChat API', observed_at=stamp(library.clock))
                            library._put(db, plan.scope, 'avatar', item['avatar_id'], item['avatar_id'], saved)
                        item['state'] = 'Complete' if item['updated'] else 'Skipped'
                    check()
                    # Catalog changes and completion receipt commit together.
                    _write(library, db, data)
                library.revision += 1
            except InspectionCancelled: raise
            except (APIError, ValueError, OSError) as error:
                check()
                code = getattr(error, 'status_code', None)
                item.update(state='Failed', updated=[], message=f'Provider request failed ({code or "unavailable"}); review before retrying.')
                if code in (401,403,429) or code is None or code >= 500:
                    data['state'] = 'Stopped'
                with library.store._transaction() as db: _write(library, db, data)
                if data['state'] == 'Stopped': break
        check()
        if data['state'] == 'Running':
            data['state'] = 'Complete' if all(i['state']=='Complete' and not i['conflicts'] and not i['unavailable'] for i in data['items']) else 'Complete with issues'
    except InspectionCancelled:
        data['state'] = 'Cancelled'
        for item in data['items']:
            if item['state'] == 'Reading': item.update(state='Pending', updated=[], conflicts=[], unavailable=[])
    except Exception:
        data['state'] = 'Stopped'
        for item in data['items']:
            if item['state'] == 'Reading': item.update(state='Pending', updated=[])
        raise
    finally:
        data['finished_at'] = stamp(library.clock)
        with library.store._transaction() as db: _write(library, db, data)
        library.revision += 1
    return data
