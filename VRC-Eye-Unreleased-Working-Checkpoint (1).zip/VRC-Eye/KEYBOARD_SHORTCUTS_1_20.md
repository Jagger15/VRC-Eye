# Navigation keyboard shortcuts — Development 5

Open **VRC Eye → Accessibility → Keyboard**, or use **Find a tool… → Keyboard
shortcuts**. The same settings are available before sign-in, offline, and in every
presentation mode. This adds main-window navigation keys, not OS-global hotkeys,
VRChat input remapping, macro automation or arbitrary command execution.

## Assignments and defaults

Ten named actions are available: Find a tool, Settings, Home, Accessibility,
Photos, Social, Accounts, Avatar Library, SDK downloads, and VCC downloads. Only
**Ctrl+K → Find a tool** and **Ctrl+Comma → Settings** are assigned initially.
The remaining actions start disabled rather than taking over additional keys.

Select an action, enter a supported chord or use **Capture key chord…**, then
**Review and apply assignment**. The review shows changed actions and their old
and proposed bindings. Duplicate assignments are rejected. Disabling an existing
assignment before reusing its chord is a deliberate choice, not a silent override.
**Disable selected shortcut**, **Undo last shortcut change** and **Restore default
shortcuts…** are separate controls. The Find a tool button always remains available
and shows its current binding or that its shortcut is off.

Supported chord families are Ctrl+K, Ctrl+Comma, Ctrl+Shift+letter (with exclusions),
and F2–F12 with optional Ctrl/Shift; Ctrl+Shift+Comma/Period are also accepted.
F10 alone is reserved for native menu navigation. Ordinary typing, editing chords,
Enter, keypad Enter, Tab, Escape, Alt/AltGr/Super and arbitrary key sequences are
not accepted. This protects common native input behavior rather than promising
unrestricted mappings for every keyboard layout. CapsLock/NumLock are ignored
for matching; other modifier bits are not treated as navigation chords.

## Capture and focus

The capture dialog listens only while it is open. It does not install an OS hook.
Capturing a supported chord fills the draft; it neither executes the action nor
applies the assignment. Escape/Cancel closes without changes. Navigation dispatch
is suspended during capture and while a modal grab is active. There is no timed
response requirement. Closing capture restores the prior control's focus where
it still exists.

A private Tk bind tag places recognized main-window navigation ahead of native
text-class behavior. In particular, Ctrl+K opens Find a tool without first deleting
text in a Text widget. Unmatched keys continue through native processing. When a
shortcut is disabled, its former chord is no longer consumed by VRC Eye navigation;
the control's own behavior can therefore apply. Toplevel dialogs keep their own
bindings. Scoped sign-in Enter and keypad Enter behavior are unchanged.

Newly mapped main-window widgets receive the same navigation tag. Repeated matching
key events are briefly debounced, without introducing a user deadline. Changing a
view does not arm OSC, send a request, choose an avatar, or gain account privileges.
Opening SDK/VCC pages by a key reads only local cached metadata, just as clicking
the same navigation control does.

Control rows stack when they no longer fit the new pages. Shared scroll panes now
use the same focus-to-visible behavior as the prior account workspace so reaching
a lower control scrolls it into view without activating it. New keyboard flows
were exercised at 100% and 200% scale. Complete app-wide reflow, native assistive
technology exposure, screen-reader interoperability, switch/voice/gamepad input,
XR controls and every international keyboard/IME configuration remain unfinished
or unverified. The header and all historical custom widgets are not certified by
these task-specific tests.

## Profiles and storage

**Import shortcut profile…** reads a reviewed JSON file up to 64 KiB. It accepts
only schema version 1, the navigation-profile kind, and known action bindings.
Unknown commands/fields, duplicate JSON fields, malformed chords, conflicts,
linked paths, non-regular files and oversized inputs are refused. Partial imports
merge with current assignments; the combined result is reviewed before applying.
A shortcut-settings change during the review invalidates that review.

**Export shortcut profile…** writes a new JSON file without overwriting existing
files. It contains bindings only: no scripts, account identity, credentials,
filesystem locations or display settings. Display/accessibility profiles remain
separate and do not silently import keyboard changes.

Normal-mode assignments are stored in the existing companion database under
`ui.shortcuts.v1`. Storage completes before the active mapping changes; a failed
save therefore leaves the active mapping intact. Demo/Safe Mode changes are
session-only and explicitly labeled. Undo is session history, not a permanent
version archive. Profiles apply to the local OS-user workspace, not to a selected
VRChat account.

If a saved shortcut record is invalid or cannot be read, defaults are used for
that session with a visible notice. The invalid stored record is not silently
overwritten. The always-available Find a tool and sidebar buttons provide a
recovery route. No network dependency is needed to repair keyboard settings.

## Validation boundary

The chord parser, reserved-key handling, profile validation/storage and real Tk
Text/Entry/dialog/capture workflows have automated tests. Native Linux tests
verify that typing is preserved for handled navigation chords and dialog Enter
remains local. This is not a native Windows or screen-reader certification, nor
proof that an operating system or another focused application will deliver every
hardware key combination. These keys never work as global/background controls.
