"""Deterministic, in-memory protocol demonstrations. No app data or sockets."""
from copy import deepcopy
import math

SCENARIOS = ('normal', 'delay', 'duplicate', 'stale', 'denied', 'revoked', 'reconnect', 'rate_limit')


def simulate(scenario='normal', *, delay=1.0):
    """Exercise real schema, replay and permission gates using synthetic data only."""
    if scenario not in SCENARIOS:
        raise ValueError('Choose a supported simulation scenario.')
    if type(delay) not in (int, float) or not math.isfinite(delay) or not 0 <= delay <= 3600:
        raise ValueError('Simulation delay must be 0–3600 seconds.')
    from peer_protocol import envelope, validate_envelope, PermissionEngine, ReplayWindow, RateLimiter
    at = 1000.; clock = lambda: at
    permissions = PermissionEngine(clock=clock); replay = ReplayWindow(clock=clock)
    limiter = RateLimiter(clock=clock)
    peer, session, context = 'simulated-peer', 'simulated-session-1', 'simulated-context'
    family = 'notice'
    payload = {'title': 'Simulation notice', 'body': 'Synthetic content only', 'duration': 5}
    message = envelope('notice.show', payload, sender=peer, recipient='simulated-local',
                       session=session, context=context, now=at)
    message['message_id'] = '00000000-0000-4000-8000-000000000001'
    permissions.set(peer, family, 'allow', scope='session', session=session, context=context)
    rows = [dict(at=0., event='created', outcome='synthetic', reason='Separate in-memory simulation; no live peers or storage.')]
    if scenario == 'denied':
        permissions.set(peer, family, 'deny', scope='persistent')
    if scenario == 'revoked':
        permissions.revoke(peer)
        rows.append(dict(at=0., event='permission_revoked', outcome='review_required', reason='Existing session permission removed.'))
    if scenario == 'reconnect':
        permissions.end_session(session)
        message['session'] = 'simulated-session-2'
        rows.append(dict(at=0., event='new_session', outcome='review_required', reason='Previous consent session ended.'))
    deliveries = 2 if scenario == 'duplicate' else 5 if scenario == 'rate_limit' else 1
    at += 61. if scenario == 'stale' else delay if scenario == 'delay' else 1.
    for index in range(deliveries):
        candidate = deepcopy(message)
        if scenario == 'rate_limit':
            candidate['message_id'] = f'00000000-0000-4000-8000-{index+1:012d}'
        try:
            clean = validate_envelope(candidate, now=at)
        except ValueError:
            outcome, reason = 'expired', 'Transient message expired before delivery; no action replayed.'
        else:
            if not replay.accept(clean, now=at):
                outcome, reason = 'duplicate_rejected', 'Message ID was already handled.'
            elif not limiter.allow(peer, family, now=at):
                outcome, reason = 'rate_limited', 'Receiver notification budget exhausted.'
            else:
                decision = permissions.decide(peer, family, session=candidate['session'], context=context,
                                               message_id=candidate['message_id'], now=at)
                outcome = {'allow': 'accepted', 'deny': 'denied', 'ask': 'review_required'}[decision['decision']]
                reason = decision['reason']
        rows.append(dict(at=at-1000., event='delivery', outcome=outcome, reason=reason))
    counts = {}
    for row in rows:
        if row['event'] == 'delivery':
            counts[row['outcome']] = counts.get(row['outcome'], 0) + 1
    return dict(scenario=scenario, isolated=True, rows=rows, counts=counts,
                summary='Simulation only: ' + ', '.join(f'{n} {name.replace("_", " ")}' for name, n in counts.items()))
