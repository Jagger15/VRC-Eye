# 1.21.0 Development checkpoint 4 — validation

The clean-extracted **portable regression passed 4,346 tests and 1,059 subtests**
in 100.22 seconds, with no failures or errors. Two warnings cover the existing
TestListener collection name and a deliberately duplicated ZIP fixture member.
The offline guard recorded **zero external socket attempts**.

**This is not a completed full GUI/IPC acceptance gate.** Of 5,030 collected
tests, 473 GUI tests skipped because no display was available. Another 210 tests
in 13 modules associated with local transports were omitted, and one Unix bridge
test was deselected. The excluded modules also contain some portable unit cases;
those are not counted as passed. Exact exclusions and the command are in
BUILD_VALIDATION.json.

The environment denied local socket creation. Xvfb could not open its display
sockets, and the approval policy rejected an escalated display check. The first
full attempt was stopped after observing that environment failure. Application
socket behavior was not changed to accommodate the restriction.

## Verified in this build

- All **548 manifest-covered files** matched the tested extracted tree before
  final packaging. All **499 Python files** parse with Python 3.10 grammar;
  execution used Python 3.12.14.
- Native collections/membership, migration reviews and rollback, checksummed
  backups, account scopes, data suppression, event/inbox contracts, remote action
  reviews, image preparation, photo context/organization and desktop services.
- Controller tests for image tiles, selected identity, late-response cancellation,
  account changes, per-collection removal, new sidebar routes and appearance fields.
- Pipeline auth-token handshake and bounded reconnect/backoff with deterministic
  fixtures. Review-expiration checks use the current five-minute window.
- Retained creator, archive, media, performance, configuration and local workflows
  included in the portable selection. These are synthetic/controlled tests.
- Current-platform dependency installation and `pip check`; Linux launcher shell
  syntax and `Start.sh --version`. Existing Windows/Linux launcher bytes remain
  unchanged. The package retains every one of the 593 Development 3 archive paths.

The first completed portable run had 36 failures. One was the blocked native
Unix bridge test; the rest were obsolete widget, navigation, feed, photo-format
and preference expectations. The fixtures were updated for the intended new
behavior, and the final selected run above passed. Favorites removal wording was
also clarified to name the selected collection and explain that other memberships
are retained. No assertion was removed to hide an observed application failure.

Earlier source-stage Xvfb gates passed 181 tests / 37 subtests and then 92 tests /
24 subtests on focused, overlapping selections, including privacy clearing,
image attachment review, dialog lifetime, migration and layout. Those are prior
source-stage evidence, not a fresh GUI pass on this final package. Development 3
validation is preserved in VALIDATION_1_21_DEV3.md and nested in BUILD_VALIDATION.json.

## Acceptance still needed

A full GUI and local-transport run in an environment that allows Tk/Xvfb and
local sockets; native Windows credentials, tray and startup; real SteamVR and
audio hardware; Unity compilation; live VRChat APIs; installed VRCX databases;
Discord IPC; and pairing with a physical phone remain unverified here.

Full VRCX parity is still in progress: 30 packages are source-implemented and
52 partial. The larger roadmap retains 160 packages / 849 future acceptance
checks. Those future checks are not counted as executed tests.

This is a runnable source ZIP with Windows/Linux launchers. It contains no
compiled executable, signed installer, automatic updater, user database, saved
secret, runtime log or Python environment. Existing bundled Unity source and
the EditorCore source-package ZIP are retained.

See [development notes](DEVELOPMENT_1_21.md) and
[implementation status](IMPLEMENTATION_STATUS_1_21.md).
