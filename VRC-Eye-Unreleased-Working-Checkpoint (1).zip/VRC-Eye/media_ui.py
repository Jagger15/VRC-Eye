"""Native metadata, transport, bookmarks and DJ controller workspace.

No provider starts on construction. Audio implementation mounts into audio_host;
this page never invents PCM meters or relays peer cues to player controls.
"""
from dataclasses import asdict
import json
import sqlite3
import time
import webbrowser

from account_actions import local_writable
from account_workspace_ui import WorkspacePane
from avatar_library import active_scope, context_token
from avatar_library_ui import StableTable
from companion_ui import Page, line, button, entry, choice
from media_history import MediaHistory, safe_url
from media_model import publication
from media_service import MediaService

SECTIONS = ('Now Playing','Sources','Mixer','Library & History','DJ','Settings & Diagnostics')


def duration(value):
    if value is None: return 'Unknown'
    return '%d:%02d' % (int(value)//60,int(value)%60)


class MediaPage(Page):
    def __init__(self, shell, parent, key=None, store=None, *, service=None):
        self.viewport = WorkspacePane(shell.app,parent)
        super().__init__(shell,self.viewport.body,'Media & Audio',task_controls=False)
        self.key = key; self.store = store or shell.store
        self.history = MediaHistory(self.store); self.scope = active_scope(self.app)
        self.service = service or getattr(self.app,'media_service',None) or MediaService(context_probe=lambda:context_token(self.app))
        self.app.media_service = self.service
        self.audio_extension = None
        self.private = self.tk.BooleanVar(value=False)
        self.include_artist = self.tk.BooleanVar(value=True)
        self.keep_history = self.tk.BooleanVar(value=False)
        self.days = self.tk.StringVar(value='30'); self.query = self.tk.StringVar()
        self.tags_draft=self.tk.StringVar();self.favorite_draft=self.tk.BooleanVar(value=False)
        self.seek_seconds = self.tk.StringVar(value='0'); self.cue_label = self.tk.StringVar()
        self.now = self.tk.StringVar(value='Discover players, then pin one in Sources.')
        self.source_caption = self.tk.StringVar(value='No selected player.')
        self.timeline = self.tk.StringVar(value='Position unavailable')
        self.control_result = self.tk.StringVar(value='No control submitted.')
        self.publish_preview = self.tk.StringVar(value='Nothing shared. Preview current metadata explicitly.')
        self.diagnostics = self.tk.StringVar(value='Metadata control only. No audio capture starts here.')
        self.pending = []; self.last_revision = -1; self.last_history = None
        self.prepared_publication = None; self.last_tick = 0; self.log_records = {}
        row=line(self); button(self,row,'Discover / refresh players',self.discover); button(self,row,'Stop Media',self.stop)
        self.ttk.Checkbutton(row,text='Private listening / hide metadata',variable=self.private,command=lambda:self.guard(self.privacy_changed)).pack(side='left',padx=5)
        self.tabs=self.ttk.Notebook(self.parent);self.tabs.pack(fill='both',expand=True)
        self.frames={name:self.ttk.Frame(self.tabs,padding=8) for name in SECTIONS}
        for name,frame in self.frames.items():self.tabs.add(frame,text=name)
        self.audio_host=self.frames['Mixer']
        self.build_now(); self.build_sources(); self.build_library(); self.build_dj(); self.build_settings()
        self.load_preferences(); self.refresh_history()

    def context(self): return context_token(self.app)

    def guard(self, action):
        try:
            if self.closed:return
            if self.context()!=self.account:self.account_changed();raise ValueError('Account context changed; review the media workspace again.')
            return action()
        except (ValueError,OSError,RuntimeError,sqlite3.Error) as error:
            self.status.set('Media action unavailable.' if self.private.get() else str(error))

    def active(self):
        local_writable(self.app)
        if self.closed:raise ValueError('Media workspace is closed.')
        if self.private.get():raise ValueError('Turn off private listening before selecting or publishing metadata.')
        if self.context()!=self.account:raise ValueError('The account changed.')

    def label(self,parent,variable=None,text=None):
        widget=self.ttk.Label(parent,textvariable=variable,text=text,wraplength=1000,justify='left')
        widget.pack(anchor='w',fill='x',pady=5);return widget

    def build_now(self):
        pane=self.frames['Now Playing'];self.label(pane,self.source_caption);self.label(pane,self.now);self.label(pane,self.timeline)
        row=line(self,pane);self.controls={}
        for operation in ('previous','play','pause','stop','next'):
            self.controls[operation]=button(self,row,operation.title(),lambda op=operation:self.control(op))
        row=line(self,pane);self.ttk.Label(row,text='Seek to seconds').pack(side='left');entry(self,row,self.seek_seconds,10)
        self.controls['seek']=button(self,row,'Seek selected track',self.seek)
        self.label(pane,self.control_result)
        row=line(self,pane);button(self,row,'Bookmark this observation',self.bookmark)
        self.ttk.Checkbutton(row,text='Include artist in chat preview',variable=self.include_artist,command=self.clear_publication).pack(side='left',padx=5)
        row=line(self,pane);button(self,row,'Preview Now Playing',self.preview_publication);button(self,row,'Review & publish to chatbox',self.publish)
        button(self,row,'Cancel pending media text',self.cancel_publication)
        self.label(pane,self.publish_preview)
        self.label(pane,text='Player metadata and command acceptance do not establish audible playback. Chatbox publication uses the existing OSC permission and scheduler. No artwork or metadata URL is fetched.')

    def build_sources(self):
        pane=self.frames['Sources']
        self.sources_table=StableTable(self,pane,(('label','Application / session',260),('provider','Provider',150),('state','State',110),('caps','Advertised controls',420)),height=9)
        row=line(self,pane);button(self,row,'Pin selected source',self.pin)
        self.label(pane,text='Pinned selection never follows another player automatically. Windows app IDs are not process IDs. MPRIS/Windows metadata does not select or capture audio. Missing optional providers leave the rest of VRC Eye usable.')

    def build_library(self):
        pane=self.frames['Library & History'];row=line(self,pane);entry(self,row,self.query,38);button(self,row,'Filter',self.refresh_history)
        self.library_table=StableTable(self,pane,(('title','Title',300),('source','Source / evidence',300),('position','Bookmark',90),('kind','Kind',100),('tags','Tags',180)),height=7,select=self.library_selection)
        row=line(self,pane);self.ttk.Label(row,text='Tags (comma-separated)').pack(side='left');entry(self,row,self.tags_draft,30)
        self.ttk.Checkbutton(row,text='Favorite',variable=self.favorite_draft).pack(side='left',padx=4)
        button(self,row,'Apply to selected…',self.organize)
        row=line(self,pane);button(self,row,'Open saved URL…',self.open_saved);button(self,row,'Add selected to DJ set list',self.add_saved_cue)
        button(self,row,'Forget selected…',self.forget);button(self,row,'Review export…',self.export)
        self.label(pane,text='Saved observations belong to this VRC Eye workspace. They do not establish who heard a track. Automatic history is opt-in in Settings; bookmarks survive retention pruning.')
        row=line(self,pane);button(self,row,'Show retained log media links',self.show_log_media);button(self,row,'Bookmark selected log URL…',self.bookmark_log)
        self.log_table=StableTable(self,pane,(('stamp','Recorded',150),('url','Recorded URL',570),('evidence','Evidence',200)),height=5)

    def build_dj(self):
        pane=self.frames['DJ'];self.label(pane,text='Controller workspace: ordered local cue notes and position bookmarks. A cue never starts a player, loads a URL, captures audio or changes a mix automatically.')
        row=line(self,pane);entry(self,row,self.cue_label,40);button(self,row,'Add current cue',self.add_cue)
        self.cue_table=StableTable(self,pane,(('label','Cue label / track',350),('source','Observed source',300),('position','Position',100)),height=8)
        row=line(self,pane)
        for label,direction in (('Move up',-1),('Move down',1)):button(self,row,label,lambda d=direction:self.move_cue(d))
        button(self,row,'Seek pinned player to cue…',self.seek_cue);button(self,row,'Remove cue…',self.remove_cue)
        row=line(self,pane)
        for operation in ('play','pause','previous','next'):button(self,row,operation.title()+' pinned player',lambda op=operation:self.control(op))
        self.label(pane,text='Seek reviews show both the saved cue and the currently pinned track. Peer media cues remain planning markers. Independent PCM decks/crossfade require the separate audio engine.')

    def build_settings(self):
        pane=self.frames['Settings & Diagnostics'];row=line(self,pane)
        self.ttk.Checkbutton(row,text='Retain selected-player track observations',variable=self.keep_history).pack(side='left')
        choice(self,row,self.days,('7','30','90'),width=5);self.ttk.Label(row,text='days').pack(side='left');button(self,row,'Apply retention…',self.save_preferences)
        self.label(pane,self.diagnostics)
        row=line(self,pane);button(self,row,'Export metadata diagnostics…',self.export_diagnostics)
        button(self,row,'Retry provider cleanup',self.retry_cleanup)
        button(self,row,'Image / video error reports…',self.open_error_reports)
        button(self,row,'Inspect retained log errors…',lambda:self.open_error_reports().inspect_log_errors())
        self.label(pane,text='Providers: Windows GSMTC (optional WinRT packages) or Linux MPRIS (optional dbus-next / current user session bus). Native behavior depends on the player. Stop Media ends Eye observation, pending commands and Eye-owned extensions; it sends no automatic pause to unrelated players.')

    def open_error_reports(self):
        from inspection_reports_ui import show
        token=self.context()
        def guard():
            if self.closed or self.context()!=token or self.private.get():raise ValueError('Media context changed. Reopen error reports.')
        guard();return show(self.shell,'Media errors',owner_guard=guard)

    def show_section(self,name=None):
        if name in self.frames:self.tabs.select(self.frames[name]);self.viewport.top()

    def discover(self):self.active();self.service.start();self.status.set('Discovering supported desktop media sessions…');self.show_section('Sources')

    def pin(self):
        self.active();row=self.sources_table.selected()
        if not row:raise ValueError('Select an observed player in Sources.')
        self.cancel_publication();self.service.select(row['id']);self.prepared_publication=None;self.last_history=None;self.last_revision=-1
        self.show_section('Now Playing');self.render()

    def selected_player(self):
        self.active();row=self.service.snapshot()['current']
        if row is None:raise ValueError('Pin a fresh player observation in Sources.')
        return row

    def queue(self,plan):
        self.pending.append(self.service.submit(plan));self.control_result.set('Queued for selected session; checked again before dispatch.')

    def control(self,operation):self.selected_player();self.queue(self.service.prepare(operation))
    def seek(self):self.selected_player();self.queue(self.service.prepare('seek',float(self.seek_seconds.get())))

    def view_guard(self):
        snap=self.service.snapshot();row=snap['current']
        return self.context(),self.private.get(),snap['generation'],row.id if row else '',row.track_key if row else ''

    def clear_publication(self):self.prepared_publication=None;self.publish_preview.set('Nothing shared. Preview current metadata explicitly.')

    def preview_publication(self):
        row=self.selected_player();value=publication(row,self.include_artist.get())
        self.prepared_publication=(self.view_guard(),self.include_artist.get(),value)
        self.publish_preview.set(value+'\nPreview only — not published.')

    def publish(self):
        self.active()
        if not self.prepared_publication:raise ValueError('Preview the current title first.')
        guard,artist,value=self.prepared_publication
        if guard!=self.view_guard() or artist!=self.include_artist.get():self.clear_publication();raise ValueError('Media selection or template changed; preview again.')
        controller=getattr(self.app,'osc_controller',None)
        if controller is None:raise ValueError('Shared OSC controller is unavailable.')
        review=controller.review_control('chat.publish',text=value,producer='media-now-playing',kind='background',ttl=15,
            privacy='user_approved',immediate=True,notification=False)
        if not self.confirm('Publish Now Playing',value+'\n\nPublish this selected title to your VRChat chatbox audience through the shared OSC service?'):return
        self.active()
        if guard!=self.view_guard() or artist!=self.include_artist.get():raise ValueError('Track, player or context changed; nothing was queued.')
        queued=controller.execute_control(review)
        try:
            controller.controls.guard_chat_publication(queued['id'],lambda:
                not self.closed and guard==self.view_guard() and artist==self.include_artist.get())
        except Exception:
            controller.controls.cancel_chat_producer('media-now-playing');raise
        self.clear_publication();self.status.set('Media text queued through shared OSC; audience receipt is unverified.')

    def cancel_publication(self):
        controller=getattr(self.app,'osc_controller',None)
        controls=getattr(controller,'controls',None)
        if controls is not None:
            controls.cancel_chat_producer('media-now-playing')
        self.clear_publication()

    def observation(self,row):
        return dict(title=row.title or 'Untitled media observation',artist=row.artist,source=row.provider+' · '+row.label,
            evidence='Selected desktop player metadata; audibility unknown',position=row.position,origin='desktop')

    def bookmark(self):
        row=self.selected_player();guard=self.view_guard();data=self.observation(row)
        if self.confirm('Save media bookmark',data['title']+'\n'+data['source']+'\n\nRetain this title/artist and position in this local workspace? URLs are omitted.'):
            self.active()
            if guard!=self.view_guard():raise ValueError('Media context changed; bookmark canceled.')
            self.history.save(self.scope,data);self.refresh_history();self.status.set('Media observation bookmarked.')

    def refresh_history(self):
        if self.private.get():self.library_table.set([],lambda r:());self.cue_table.set([],lambda r:());return
        rows=[r for r in self.history.rows(self.scope,query=self.query.get()) if r['kind']!='cue']
        self.library_table.set(rows,lambda r:(('★ ' if r['favorite'] else '')+r['title'],r['source']+' · '+r['evidence'],duration(r['position']),r['kind'],', '.join(r['tags'])))
        cues=self.history.rows(self.scope,kind='cue')
        self.cue_table.set(cues,lambda r:(r['note'] or r['title'],r['source'],duration(r['position'])))

    def library_selection(self):
        row=self.library_table.selected()
        self.tags_draft.set(', '.join(row['tags']) if row else '')
        self.favorite_draft.set(bool(row and row['favorite']))

    def organize(self):
        row=self.library_selected();guard=self.context();draft=self.tags_draft.get();favorite=self.favorite_draft.get()
        from media_history import tags
        labels=tags([item.strip() for item in draft.split(',') if item.strip()])
        if not self.confirm('Organize media record',row['title']+'\nTags: '+', '.join(labels)+'\nFavorite: '+str(favorite)+'\n\nA favorite history observation becomes a bookmark and survives retention.'):return
        self.active()
        if guard!=self.context() or self.library_table.selected() is not row or draft!=self.tags_draft.get() or favorite!=self.favorite_draft.get():raise ValueError('Workspace, selection or organization draft changed.')
        self.history.organize(self.scope,row['id'],favorite=favorite,labels=labels);self.refresh_history()

    def library_selected(self):
        self.active();row=self.library_table.selected()
        if not row:raise ValueError('Select a saved record.')
        return row

    def open_saved(self):
        row=self.library_selected();url=safe_url(row['url']);guard=self.context()
        if not url:raise ValueError('This record has no retained actionable HTTP(S) URL.')
        if self.confirm('Open saved media URL',url+'\n\nOpen this externally supplied URL in your browser?'):
            self.active()
            if guard!=self.context() or self.library_table.selected() is not row:raise ValueError('Selection changed.')
            webbrowser.open(url)

    def forget(self):
        row=self.library_selected();guard=self.context()
        if self.confirm('Forget media record',row['title']+'\n\nDelete this saved record? Matching imported source keys will remain forgotten.'):
            self.active()
            if guard!=self.context() or self.library_table.selected() is not row:raise ValueError('Workspace or selection changed.')
            self.history.forget(self.scope,row['id']);self.refresh_history()

    def export(self):
        self.active();guard=self.context()
        if not self.confirm('Export media summary','Export up to 500 visible-workspace records with title, artist, evidence, position and time? URLs, source labels, notes and account IDs are omitted.'):return
        from tkinter import filedialog
        path=filedialog.asksaveasfilename(parent=self.app.root,defaultextension='.json',initialfile='VRC-Eye-media.json')
        self.active()
        if guard!=self.context():raise ValueError('Workspace changed.')
        if path:self.history.export(self.scope,path);self.status.set('Media summary exported without overwriting existing files.')

    def show_log_media(self):
        self.active();rows=[];self.log_records={}
        for item in reversed(getattr(self.shell.log,'items',())):
            if item.category!='Videos':continue
            for index,url in enumerate(item.urls):
                if not safe_url(url):continue
                identifier='%s:%s:%s'%(item.source,item.serial,index)
                rows.append(dict(id=identifier,stamp=item.stamp,url=url,evidence=item.playback or 'URL observed'))
                if len(rows)>=100:break
            if len(rows)>=100:break
        self.log_records={r['id']:r for r in rows}
        self.log_table.set(rows,lambda r:(r['stamp'],r['url'],r['evidence']))

    def bookmark_log(self):
        self.active();row=self.log_table.selected();guard=self.context()
        if not row:raise ValueError('Select a retained log media URL.')
        if not self.confirm('Retain recorded URL',row['url']+'\n\nSave this complete URL privately as a bookmark? It may contain private information. No lookup or playback occurs.'):return
        self.active()
        if guard!=self.context() or self.log_table.selected() is not row:raise ValueError('Context changed.')
        import hashlib
        key=hashlib.sha256(row['id'].encode()).hexdigest()
        self.history.save(self.scope,dict(title='Recorded media URL',source='Game Log',evidence=row['evidence'],url=row['url'],origin='game-log'),source_key=key)
        self.refresh_history()

    def add_cue(self):
        row=self.selected_player();data=self.observation(row);data['note']=self.cue_label.get()
        self.history.save(self.scope,data,kind='cue');self.cue_label.set('');self.refresh_history()

    def add_saved_cue(self):self.history.save(self.scope,self.library_selected(),kind='cue');self.refresh_history();self.show_section('DJ')

    def move_cue(self,direction):
        self.active();row=self.cue_table.selected()
        if not row:raise ValueError('Select a cue.')
        self.history.move_cue(self.scope,row['id'],direction);self.refresh_history()

    def remove_cue(self):
        self.active();row=self.cue_table.selected();guard=self.context()
        if row and self.confirm('Remove cue',row['title']+'\n\nRemove this set-list cue?'):
            self.active()
            if guard!=self.context() or self.cue_table.selected() is not row:raise ValueError('Workspace or selection changed.')
            self.history.forget(self.scope,row['id']);self.refresh_history()

    def seek_cue(self):
        current=self.selected_player();cue=self.cue_table.selected()
        if not cue or cue['position'] is None:raise ValueError('Select a cue with an observed position.')
        plan=self.service.prepare('seek',cue['position']);guard=self.view_guard()
        if self.confirm('Seek pinned player to cue',f"Saved cue: {cue['title']}\nPinned player: {current.label}\nCurrent track: {current.title}\nSeek to {duration(cue['position'])}?\n\nThe saved cue is not proof this is the same track."):
            self.active()
            if guard!=self.view_guard() or self.cue_table.selected() is not cue:raise ValueError('Player, track or cue changed.')
            self.queue(plan)

    def load_preferences(self):
        raw=self.store.option('media.retention.'+self.scope,{})
        if not isinstance(raw,dict):raw={}
        days=raw.get('days',30);self.days.set(str(days if days in (7,30,90) else 30))
        # Remember a preference; observation itself remains an explicit start.
        self.history_enabled=raw.get('enabled') is True;self.retention_days=int(self.days.get())
        self.keep_history.set(self.history_enabled)

    def save_preferences(self):
        self.active();guard=self.context();days=int(self.days.get());enabled=self.keep_history.get()
        if days not in (7,30,90):raise ValueError('Choose 7, 30 or 90 days.')
        if not self.confirm('Media retention','Retain selected-player titles/artists for '+str(days)+' days?' if enabled else 'Stop automatic history and remove unpinned history records? Bookmarks and cues remain.'):return
        self.active()
        if guard!=self.context() or days!=int(self.days.get()) or enabled!=self.keep_history.get():raise ValueError('Workspace or retention draft changed.')
        self.history.prune(self.scope,days if enabled else 0)
        self.store.set_option('media.retention.'+self.scope,dict(enabled=enabled,days=days))
        self.history_enabled=enabled;self.retention_days=days;self.last_history=None;self.refresh_history()

    def export_diagnostics(self):
        self.active();guard=self.context();report=self.service.diagnostics()
        if not self.confirm('Export metadata diagnostics','Export provider state, supported control names and request counts? Titles, URLs, player IDs, account IDs, device names, paths and audio samples are omitted. This report covers metadata controls only.'):return
        from tkinter import filedialog
        from photo_files import save_new
        destination=filedialog.asksaveasfilename(parent=self.app.root,defaultextension='.json',initialfile='VRC-Eye-media-diagnostics.json')
        self.active()
        if guard!=self.context():raise ValueError('Workspace changed.')
        if destination:
            save_new(destination,json.dumps(report,indent=2).encode());self.status.set('Metadata diagnostics exported without overwriting existing files.')

    def render(self):
        snap=self.service.snapshot();row=snap['current'];private=self.private.get()
        if self.last_revision!=snap['revision']:
            rows=[] if private else [asdict(r) for r in snap['sources']]
            self.sources_table.set(rows,lambda r:(r['label'],r['provider'],r['state'],', '.join(r['capabilities'])))
            self.last_revision=snap['revision']
        self.source_caption.set('Metadata hidden — private listening' if private else 'Pinned: '+row.label+' · '+row.provider if row else 'No fresh pinned source. Open Sources to select one.')
        self.now.set('Private listening' if private else '\n'.join((row.title or 'Title unavailable',row.artist,row.state.title())) if row else 'Playback metadata unavailable')
        position=row.estimated_position(self.service.clock()) if row else None
        remaining=max(0,row.duration-position) if row and row.duration is not None and position is not None else None
        self.timeline.set('Hidden' if private else duration(position)+' / '+duration(row.duration if row else None)+' · '+duration(remaining)+' remaining · estimated between observations')
        for operation,widget in self.controls.items():widget.configure(state='normal' if row and not private and not self.app.demo and not getattr(self.app,'safe_mode',False) and operation in row.capabilities else 'disabled')
        self.diagnostics.set(snap['status']+'\nProvider worker: '+('stopping' if snap['stopping'] else 'active' if snap['connected'] else 'inactive')+'\nRequests in queue: '+str(snap['pending'])+'\nAudio capture is a separate extension; metadata is not PCM.')
        if self.prepared_publication and self.prepared_publication[0]!=self.view_guard():self.cancel_publication()

    def tick(self):
        if self.closed:return
        if self.context()!=self.account:self.account_changed()
        for future in list(self.pending):
            if future.done():
                self.pending.remove(future)
                try:result=future.result();self.control_result.set(result['status']+' · '+result.get('detail','')+(' Later state change observed.' if result.get('observed') else ''))
                except Exception:self.control_result.set('Media request failed; no automatic retry.')
        if self.audio_extension is not None:self.audio_extension.tick()
        now=time.monotonic()
        if now-self.last_tick<.25:return
        self.last_tick=now;self.render()
        row=self.service.snapshot()['current']
        if row and not self.private.get() and self.history_enabled and not self.app.demo and not getattr(self.app,'safe_mode',False):
            key=row.id+':'+row.track_key
            if key!=self.last_history:
                self.last_history=key
                try:
                    self.history.save(self.scope,self.observation(row),kind='history',source_key=key)
                    self.history.prune(self.scope,self.retention_days);self.refresh_history()
                except (ValueError,OSError,sqlite3.Error):self.status.set('Media history unavailable; live controls remain available.')

    def stop(self):
        self.cancel_publication();self.service.stop();self.prepared_publication=None;self.last_revision=-1
        if self.audio_extension is not None:self.audio_extension.stop()
        self.status.set('Metadata stop requested; pending media chat canceled; owned audio extension asked to stop. Already submitted player controls may have taken effect. External playback was not automatically paused.');self.render()

    def retry_cleanup(self):
        self.service.retry_cleanup();self.status.set(self.service.status)

    def prepare_close(self):
        """Nonblocking gate; the shell retries while owned workers finish."""
        self.stop()
        engine=getattr(self.audio_extension,'engine',None)
        job=getattr(self.audio_extension,'job',None)
        failed=self.service.cleanup_failed or bool(getattr(engine,'unreleased_streams',()))
        busy=self.service.active or bool(getattr(engine,'running',False)) or bool(job and job.is_alive())
        if failed:
            remedies=[]
            if self.service.cleanup_failed:remedies.append('Settings & Diagnostics → Retry provider cleanup')
            if getattr(engine,'unreleased_streams',()):remedies.append('Mixer → Retry device release')
            self.status.set('Application close paused: cleanup is unconfirmed. Use '+'; '.join(remedies)+' before exiting.')
        elif busy:self.status.set('Application close is waiting for owned media/audio workers to finish cleanup.')
        return not failed and not busy

    def privacy_changed(self):
        self.stop();self.query.set('');self.tags_draft.set('');self.favorite_draft.set(False);self.cue_label.set('');self.log_table.set([],lambda r:());self.log_records={};self.refresh_history()

    def account_changed(self):
        self.stop();self.service.invalidate();self.account=self.context();self.scope=active_scope(self.app)
        self.query.set('');self.tags_draft.set('');self.favorite_draft.set(False);self.cue_label.set('');self.log_table.set([],lambda r:());self.log_records={};self.last_history=None
        self.load_preferences();self.refresh_history()

    def close(self):
        if self.closed:return True
        if not self.prepare_close():return False
        if self.audio_extension is not None:self.audio_extension.close()
        self.closed=True;return True
