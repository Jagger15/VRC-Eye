# World Creator — VRC Eye 1.19.2

Open **Primary → World**. Players and Map remain available, followed by Creator,
Metadata, Builds, Live Test, Diagnostics, Tasks, History and Controls. This is a
local creator workspace: it does not require a relay, peer connection, SteamVR,
Unity installation, or a signed-in VRChat account for its local tools.

## Start with a local project

Create a local workspace or select a published world ID. Pin a workspace to keep
working after leaving the world; follow the observed world to change workspaces
with the selected client log. Each world owns its records. Private notes, drafts,
recipes and reports do not upload when networking is enabled.

For an unpublished Build & Test project, copy the generated `local:<UUID>` into
its helper manifest. **Associate local test session** explicitly binds the current
unpublished log to that project by your declaration. It does not verify a loaded
build or start capture. Changing the log/session clears this association.

An authenticated read can recognize the world's author by stable account ID.
Opening a creator tab enables automatic recognition reads through the existing
account connection. The identity strip distinguishes a current author match, cached recognition,
local project work and unresolved identity. Recognition grants no publishing,
helper-control, instance-owner or world-master permission. A reconnect, account
switch, world change or changed log session invalidates pending reviews.

## Metadata and builds

The Metadata tab edits a local name, description, creator tags, recommended
capacity and maximum capacity draft. Description sections cover controls,
accessibility, limitations, credits, changes and test instructions. The saved
base, local draft and refreshed remote metadata support a three-way comparison;
conflicting changes require resolution. Failed lookups do not erase drafts.

Export/copy the reviewed draft and apply it through the official VRChat website
or Unity SDK. This release makes **no direct world metadata or publication API
writes**. A local export is not a successful publication. The SDK/website remains
responsible for current field limits, account permissions, upload and publication.
Publishing to Community Labs and updating an existing public world are distinct.

Build records keep release labels, creator build IDs, project revisions, platform,
artifact evidence, upload evidence and client/interaction/parity test coverage
separate. Windows, Android and iOS results can differ. A latest API package or
upload timestamp does not prove which build is loaded in the client. History is
the evidence recorded locally, not a reconstructed remote upload archive.

## Reproducible tests

Install a checklist/profile template, select the actual test environment and
start a run. Runs preserve their profile and checklist snapshots; later template
edits affect future runs. The runner records preparation, expected results,
evidence, stop conditions and manual branches. Displaying an instruction does not
execute it. Passed and Failed require recorded evidence; Blocked, Not applicable
and Needs verification are separate states.

Templates cover smoke tests, late joining, ownership changes and suspension,
persistence, accessibility, spawn/collision/locomotion, visual comparisons, media,
cross-platform behavior, localization/onboarding, network budgets, resilience and
soak tests. Structured worksheets also support recipes, named zones and routes,
assets/dependencies/credits, tester feedback, health assertions and release criteria.

Record requested conditions separately from manually confirmed or source-verified
conditions. ClientSim, local Build & Test and a real uploaded-world client are
different environments, especially for networking and persistence. Sensitive save
values need not be recorded to test presence, type, restoration or migration.

Baseline comparisons explain configuration differences and missing coverage.
Capacity guidance uses recorded samples and a chosen frame budget; it does not
increase published capacity or establish safety for untested populations.
Release gates are creator-selected, advisory requirements. They never publish a
world or represent a VRChat moderation decision.

## Diagnostics and bookmarks

Capture is **off initially**. Enable it for the current observed world after the
log reaches its live position. It records new local log observations and aggregate
roster samples, and reuses measurements from already enabled Performance & Security
or Unity Player providers. It does not start those providers. Unknown measurements
remain unavailable; process memory is not world-only memory.

Capture pauses at world/account/log/session boundaries. Mixed-world batches and
historical backlog are omitted rather than attached to the wrong test. Logging
verbosity remains unknown unless separately established; ordinary logs do not
guarantee detailed Udon coverage. Reported helper events remain untrusted evidence.

The timeline preserves source, scope, build/run, event and receipt times, a local
monotonic ordering and known clock uncertainty. Error grouping preserves build,
source and object distinctions. Population is observed coverage, not an analytics
claim or a guessed count at session start. Correlation does not establish cause.

Bookmarks preserve a selected evidence window with copied observations, optional
notes and manual zones. They remain portable after the observation ring expires.
Capture has a 2,000-event recent ring and a bounded arrival rate. Protected evidence
can outlive that ring; the entire store remains bounded at 20,000 records / 64 MiB
of JSON payload. Storage/rate limits are surfaced; protected evidence is not silently
discarded. These are payload limits, not a promise about exact SQLite disk size.

## Reports, collaboration and presentation

Select records, choose Private, Collaborator or Public and inspect the exact
report preview before exporting HTML, Markdown, JSON or CSV. Reports carry a schema
version and omissions. Text disclosure is explicit; Public defaults withhold free
text and identifiers. Secret fields are redacted even in private exports. Arbitrary
attachment paths are never read or silently packaged. A selected bookmark carries
its included evidence; no account or relay is needed to read the report.

Peer coordination reuses **VRC Eye → Networking** and the existing permissions
service. Select fields and recipients, inspect the exact card, then share. Accepted
matching peer submissions may be imported as reported feedback; they do not become
locally verified test results. A connection does not share prior records, and
reconnection does not replay sends. Local playtest roles confer no VRChat authority.

The optional SteamVR creator card uses the existing Wellness runtime owner. It is
a static, read-only current-step/error card with placement, size, opacity and a
bounded lifetime. Desktop controls perform bookmarks and test results. Interactive
VR buttons/controller input are not implemented in this release. No SteamVR means
the desktop workflow remains available. Capture records whether the card was active
so its overhead is visible in the test context.

## Optional project/helper integration

See **CREATOR_HELPER_SETUP.md** for the project exporter, UdonSharp sample, manifest
schema and explicitly routed local MIDI controls. Import a creator-supplied manifest
to review build declarations, assets/dependencies, semantic differences and debug
exposure. It does not scan or extract another creator's running world.

Control reviews require the matching world/build and an explicitly selected MIDI
output. Confirm the loaded test build as a local operator declaration. A request
is single-use; Sent is not Applied. Context changes cancel pending requests and
close the local output. No ambiguous send is retried automatically. Shared and
persistent-data actions are displayed as unsupported rather than receiving generic
execution buttons. Creator Mode cannot bypass those restrictions.

Failure drills are bounded local test tools: they can exercise a creator adapter
or a manual test recipe, not interfere with other players' network traffic.

## Runtime verification still required

Automated checks exercise model, storage, API cancellation, UI callbacks and
optional-adapter contracts. This build environment cannot validate native Windows
Tk layout, compile a VRChat Unity project, route a physical/virtual MIDI device,
or test a real SteamVR headset and uploaded multiplayer world. Verify those paths
in your own test project before relying on them during a release playtest.

## Reference documentation

- [Creating and uploading a world](https://creators.vrchat.com/worlds/creating-your-first-world/)
- [Community Labs and public world updates](https://creators.vrchat.com/worlds/submitting-a-world-to-be-made-public/)
- [ClientSim limitations](https://creators.vrchat.com/worlds/clientsim/)
- [Build & Test](https://creators.vrchat.com/worlds/udon/using-build-test/)
- [Persistence environments](https://creators.vrchat.com/worlds/udon/persistence/)

The supplied 44-feature design and implementation coverage map are preserved in
**WORLD_CREATOR_DESIGN_INPUT.md**. Unsupported runtime inspection, interactive
overlay input and remote publication are called out explicitly rather than
presented as working controls.
