"""Resumable owned-world and public SDK/VCC files; no installers or key storage.

The avatar engine owns byte/range/publication semantics. This adapter supplies
separate scoped receipts, strict provider policies and persistent host cooldowns.
"""
from contextlib import contextmanager
import json
from pathlib import Path
import re
import threading
import time
from types import SimpleNamespace
import uuid

from avatar_transfer_jobs import Transfers,source_key,canonical,summary
from companion_data import entity_id
from native_library import scope
from release_catalog import artifact_url
from release_downloads import destination_stamp

TABLE='file_transfers_dev16'
BOOT=str(uuid.uuid4())
SOURCES=('world','sdk','vcc','vcc-stable')


class PersistentBudget:
    """Wall-clock deadline survives restarts, bounded to one day per host.

    Engine monotonic timestamps are intentionally ignored; the persisted clock
    is checked on every request. No credential, path or account is stored here.
    """
    def __init__(self,store,*,wall=time.time):
        self.store,self.wall=store,wall
        with store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS transfer_cooldowns_dev16(host TEXT PRIMARY KEY,until REAL NOT NULL)')

    def defer(self,host,now,seconds):
        if not isinstance(host,str) or not re.fullmatch(r'[a-z0-9.-]{1,253}',host):raise ValueError('Invalid transfer host.')
        until=self.wall()+max(0,min(float(seconds),86400))
        with self.store.connect() as db:
            db.execute('INSERT INTO transfer_cooldowns_dev16 VALUES(?,?) ON CONFLICT(host) DO UPDATE SET until=max(until,excluded.until)',(host,until))

    def remaining(self,host,now=None):
        with self.store.connect() as db:
            row=db.execute('SELECT until FROM transfer_cooldowns_dev16 WHERE host=?',(host,)).fetchone()
        return max(0,min(86400,row[0]-self.wall())) if row else 0


class Catalog:
    def __init__(self,companion):
        self.companion=companion;self.store=self;self.clock=time.time;self.boot_id=BOOT;self.revision=0
        with companion.connect() as db:
            db.execute(f'CREATE TABLE IF NOT EXISTS {TABLE}(scope TEXT NOT NULL,kind TEXT NOT NULL,id TEXT NOT NULL,avatar_id TEXT NOT NULL,data TEXT NOT NULL,updated TEXT NOT NULL,PRIMARY KEY(scope,kind,id))')

    @contextmanager
    def _transaction(self):
        with self.companion.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            yield db

    @staticmethod
    def _load(db,account,kind,ref):
        row=db.execute(f'SELECT data FROM {TABLE} WHERE scope=? AND kind=? AND id=?',(scope(account),kind,ref)).fetchone()
        return json.loads(row[0]) if row else None

    def _put(self,db,account,kind,ref,subject,data):
        if kind!='transfer' or len(canonical(data).encode())>16384:raise ValueError('Invalid transfer receipt.')
        if not self._load(db,account,kind,ref) and db.execute(f'SELECT count(*) FROM {TABLE}').fetchone()[0]>=2000:
            raise ValueError('The file transfer journal has reached its 2,000-receipt limit.')
        db.execute(f'INSERT INTO {TABLE} VALUES(?,?,?,?,?,?) ON CONFLICT(scope,kind,id) DO UPDATE SET data=excluded.data,updated=excluded.updated',
                   (scope(account),kind,ref,subject,canonical(data),data.get('updated_at') or data['created_at']))

    def record(self,account,kind,ref):
        with self.companion.connect() as db:return self._load(db,account,kind,ref)

    def records(self,account,kind='transfer',*,limit=100):
        with self.companion.connect() as db:
            return [json.loads(r[0]) for r in db.execute(f'SELECT data FROM {TABLE} WHERE scope=? AND kind=? ORDER BY updated DESC LIMIT ?', (scope(account),kind,min(2000,max(1,limit))))]


class FileTransfers(Transfers):
    table=TABLE
    account_scope=staticmethod(scope)

    def __init__(self,catalog,source,*,release=None,suffix=None,**kwargs):
        if source not in SOURCES:raise ValueError('Choose an owned world or supported public SDK/VCC download.')
        self.source,self.release=source,release
        extension=('.vrcw' if source=='world' else Path(release.filename).suffix.lower() if release else suffix)
        allowed=('.vrcw',) if source=='world' else ('.zip',) if source=='sdk' else ('.exe','.msi','.dmg','.pkg','.zip','.gz','.xz')
        if extension not in allowed:raise ValueError('The saved artifact extension is not supported by this provider.')
        self.suffixes=(extension,)
        kwargs.setdefault('budget',PersistentBudget(catalog.companion))
        super().__init__(catalog,**kwargs)

    def subject(self,account,ref):
        if self.source=='world':
            if account=='shared':raise ValueError('Sign in before preparing a world backup.')
            if not ref.startswith('world:'):raise ValueError('Choose a world transfer.')
            entity_id('world',ref[6:])
        elif not re.fullmatch(re.escape(self.source)+r':[a-f0-9]{32}',ref):raise ValueError('Choose a matching public release.')
        return ref

    def validate_url(self,url):
        if self.source=='world':return super().validate_url(url)
        return artifact_url(self.source,url)

    def key(self,url):return source_key(url,self.validate_url)

    def response_key(self,url):
        validator=self.validate_url if self.source=='world' else lambda u:artifact_url(self.source,u,redirected=True)
        return source_key(url,validator)

    def new_destination(self,value):
        path=Path(value).expanduser().absolute()
        return destination_stamp(path,self.release or SimpleNamespace(filename='backup'+self.suffixes[0]))[0]

    def prepare(self,account,subject,url,destination=None,**kwargs):
        if kwargs.get('resume'):
            row=self.library.record(account,'transfer',kwargs['resume'])
            if row:self.new_destination(row['destination'])
        return super().prepare(account,subject,url,destination,**kwargs)

    def _response(self,opener,request):
        response=super()._response(opener,request)
        if self.release and self.release.expected_size and response.status==200 and response.headers.get('Content-Length')!=str(self.release.expected_size):
            response.close()
            raise ValueError('The response length does not match the reviewed publisher size.')
        return response

    def prepare_release(self,account,release,checked,destination=None,*,resume='',retry=False):
        if release!=self.release or release.source!=self.source or not release.downloadable:
            raise ValueError('Select a supported SDK/VCC artifact up to 2 GiB.')
        if not 0<=self.wall()-checked<=300:raise ValueError('Refresh this provider page before reviewing a resumable download.')
        if resume:
            row=self.library.record(account,'transfer',resume)
            if not row or row['expected_sha256']!=release.expected_sha256.lower():raise ValueError('Publisher checksum changed. Start a new download.')
        return self.prepare(account,self.source+':'+release.id,release.url,destination,expected_hash=release.expected_sha256,resume=resume,retry=retry)

    def prepare_world(self,account,client,result,choice,destination=None,*,resume='',retry=False):
        from world_backup import validate_world_backup
        if not getattr(client,'authenticated',False) or client.user_id!=scope(account):raise ValueError('The world account changed.')
        if not result.owned:raise ValueError('Resumable backups require a world owned by the signed-in account.')
        client.validate_world_lookup(result,choice,starting=True)
        validate_world_backup(result,choice,decrypt=False,key=None,permission=False)
        return self.prepare(account,'world:'+result.world_id,choice.url,destination,resume=resume,retry=retry)


def catalog_for(shell):
    if not hasattr(shell,'file_transfer_catalog'):shell.file_transfer_catalog=Catalog(shell.store)
    return shell.file_transfer_catalog


def engine_for(shell,row):
    source=row['avatar_id'].split(':',1)[0]
    return FileTransfers(catalog_for(shell),source,suffix=Path(row['destination']).suffix.lower())


def review_text(plan):
    return summary(plan).replace('Avatar:','File identity:').replace('this catalog','this journal')+'\n\nDownload only. No installer, archive extraction, decryption, or Unity import runs. Public provider requests never use the VRChat account transport.'
