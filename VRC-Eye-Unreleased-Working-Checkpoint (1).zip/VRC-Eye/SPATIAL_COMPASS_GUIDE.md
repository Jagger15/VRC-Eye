# SteamVR wrist compass — Development checkpoint 2

Open **Settings → SteamVR overlay & wrist compass**, search for **SteamVR wrist
compass** with Ctrl+K, or use its Home shortcut. Start SteamVR, then choose
**Start compass**. Opening the page alone does not start tracking. The compass
does not need a VRChat account, OSC connection or avatar prefab. Demo and Safe
mode keep live providers disabled.

The compass uses the same OpenVR connection as the existing Wellness, creator
and peer overlays. Its pose updates run on the shared native owner thread.
For recovery controls, open SteamVR's dashboard and select **VRC Eye Compass**.
This remains the recovery route when the selected controller is missing.
The wrist display hides until that controller has valid tracking;
it does not jump to the other hand.

## Choose a wrist and reference

Select **Left wrist**, **Right wrist**, or **Switch wrist** on the desktop.
The VR surface also has **Swap wrist**, **Reset N**, and **Details / Compact**
buttons. Swapping the attachment does not change your pointer hand or recenter
SteamVR. Left and right placements are stored separately.

Heading can follow the headset or the selected controller. **Set reference
direction** makes the current direction your zero. This is a room reference,
not magnetic or geographic north. Switching wrist or heading source preserves
that reference while the tracking frame remains valid. Unknown tracking never
appears as a zero-degree reading.

Placement fields are controller-local metres and pitch/yaw/roll degrees. Use
**Reset this wrist placement** if the panel becomes difficult to see. The wrist
panel has a fixed physical width of 0.38 m; shared text scale and contrast
preferences affect its contents. SteamVR hardware comfort and readability have
not been validated in this build environment.

## Set a temporary room waypoint

Enter a label and choose your **Current tracked position**, or enter explicit
**Room coordinates**, then select **Set room waypoint**. This replaces the one
active waypoint. Use Details to show its label, relative direction and distance
on the VR surface. The arrow requires a valid bearing; distance requires a
fresh headset position. Controller-only heading does not substitute a controller
position for your head.

Coordinates use the current SteamVR tracking frame: +X right, +Y up, −Z forward.
They are not VRChat world coordinates. A tracking-origin reset, reconnect,
account/privacy boundary, stop or application exit clears the active target.
Targets also expire; none are written to disk. Saved preferences never restart
the compass automatically.

## Tracking and shutdown

The Settings page reports tracking availability and action results. When a
provider stops responding, stale headings and target guidance become unavailable.
Stopping the compass clears its display and target; other opted-in services
retain their own controls.

If native cleanup fails, a new OpenVR owner cannot start over the old one.
**Retry provider cleanup** attempts cleanup while the owning thread is retained.
Failed initialization cleanup can leave no retryable owner; explicitly quit
and restart the app in that case. Application shutdown waits briefly without
blocking the desktop interface, then offers an
explicit choice if cleanup remains unconfirmed. Quitting anyway ends the process
but is not a report that native cleanup succeeded.

## Remaining player guidance

General player ESP/nameplates, Eye-to-Eye position streaming, creator pose
sharing, live world-to-tracking alignment, scene occlusion and avatar compass
prefabs remain pending. Instance membership and display names do not provide
player coordinates. This checkpoint connects only local SteamVR poses and your
temporary room waypoint to the compass.
