"""Private caption subprocess: local Vosk and optional selected output loopback.

JSON-line protocol, no shell, network client, audio file, or automatic model download.
The parent can terminate a blocked native recorder without blocking Tk shutdown.
"""
import base64
import json
import sys
import time
from pathlib import Path
from caption_model import pcm16,result_text

RATE=48000


def emit(kind,**values):
    print(json.dumps(dict(kind=kind,**values),ensure_ascii=True),flush=True)


def loopbacks(backend):
    return [dict(id=str(m.id),name=str(m.name),kind='loopback') for m in backend.all_microphones(include_loopback=True) if m.isloopback]


def recognizer(path):
    try:from vosk import Model,KaldiRecognizer,SetLogLevel
    except (ImportError,OSError):raise ValueError('provider') from None
    folder=Path(path).expanduser().resolve(strict=True)
    if not folder.is_dir():raise ValueError('model')
    SetLogLevel(-1)
    return KaldiRecognizer(Model(model_path=str(folder)),RATE)


class Decoder:
    def __init__(self,engine,send=emit,clock=time.monotonic):
        self.engine=engine;self.send=send;self.clock=clock;self.origin=clock();self.begin=0.;self.last_partial='';self.partial_at=-1.
    def feed(self,data,channels):
        now=self.clock()-self.origin
        final=bool(self.engine.AcceptWaveform(pcm16(data,channels)))
        if not final and now-self.begin>=15:
            text=result_text(self.engine.FinalResult(),True);self.engine.Reset();final=True
        else:text=result_text(self.engine.Result() if final else self.engine.PartialResult(),final)
        if final:
            self.send('final',text=text,start=self.begin,end=now);self.begin=now;self.last_partial=''
        elif text!=self.last_partial and now-self.partial_at>=.15:
            self.send('partial',text=text,start=self.begin,end=now);self.last_partial=text;self.partial_at=now


def run(config,stream,*,recognizer_factory=recognizer,soundcard=None,send=emit):
    if config.get('mode')=='discover':
        if soundcard is None:
            try:import soundcard
            except (ImportError,OSError):raise ValueError('loopback') from None
        send('devices',devices=loopbacks(soundcard));return
    decoder=Decoder(recognizer_factory(config['model']),send)
    source=config['source']
    if source['kind']=='input':
        send('ready')
        for line in stream:
            if len(line)>65536:raise ValueError('protocol')
            value=json.loads(line)
            if value.get('kind')=='stop':return
            data=base64.b64decode(value['data'],validate=True)
            decoder.feed(data,value['channels'])
    elif source['kind']=='loopback':
        if soundcard is None:
            try:import soundcard
            except (ImportError,OSError):raise ValueError('loopback') from None
        # Exact endpoint match; never substring/default-device fallback.
        device=next((m for m in soundcard.all_microphones(include_loopback=True) if m.isloopback and str(m.id)==source['id'] and str(m.name)==source['name']),None)
        if device is None:raise ValueError('device')
        with device.recorder(samplerate=RATE,blocksize=4800) as recorder:
            send('ready')
            while True:
                data=recorder.record(numframes=2400)
                if len(data.shape)!=2 or not 0<len(data)<=48000 or not 1<=data.shape[1]<=64:raise ValueError('format')
                decoder.feed(data.astype('float32').tobytes(),data.shape[1])
    else:raise ValueError('source')


def main():
    try:
        line=sys.stdin.buffer.readline(16385)
        if len(line)>16384:raise ValueError('protocol')
        run(json.loads(line),iter(lambda:sys.stdin.buffer.readline(65537),b''))
    except Exception as exc:
        code=str(exc) if isinstance(exc,ValueError) and str(exc) in ('provider','loopback','model','device','format','protocol','source') else 'recognition'
        emit('error',code=code)
        return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
