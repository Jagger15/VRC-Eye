"""Local player details, privacy settings, history and reviewed bridge controls."""

from text_viewport import window_body
from copy import deepcopy
import json
import queue
import threading
import tkinter as tk
from tkinter import ttk,messagebox,filedialog,simpledialog
import webbrowser

from player_session_model import Source,Confidence,seconds_label
from player_session_settings import HISTORY,COLUMNS


def text_area(parent,height=12):
    frame=ttk.Frame(parent);frame.pack(fill="both",expand=True,pady=6)
    box=tk.Text(frame,wrap="word",height=height,padx=12,pady=12)
    box.pack(side="left",fill="both",expand=True)
    scroll=ttk.Scrollbar(frame,orient="vertical",command=box.yview);scroll.pack(side="right",fill="y");box.configure(yscrollcommand=scroll.set)
    return box
def set_text(box,value):
    box.configure(state="normal");box.delete("1.0","end");box.insert("1.0",value);box.configure(state="disabled")
def text_window(app,title,value):
    window=tk.Toplevel(app.root);window.title(title);window.geometry("850x600");set_text(text_area(window_body(window)),value)
    windows=getattr(app,"player_private_windows",[]);windows.append(window);app.player_private_windows=windows[-20:]
    return window
def buttons(parent,items):
    bar=ttk.Frame(parent);bar.pack(fill="x",pady=5)
    for label,action in items:ttk.Button(bar,text=label,command=action).pack(side="left",padx=(0,8))
    return bar
def observation(value):
    if value.value is None:return "Unknown / unavailable"
    return f"{value.value}  [{value.source.value}, {value.confidence.value.lower()} confidence]"


class PlayerDetails:
    def __init__(self,panel,key,tree_key):
        self.panel,self.service,self.app=panel,panel.service,panel.app;self.key=key;self.tree_key=tree_key
        self.row=self.service.rows[key];self.instance=self.row.instance_key;self.user=self.row.user_id
        self.closed=False;self.job=None;self.actions=[];self.stop=threading.Event();self.output=queue.Queue(maxsize=1);self.last_render=None
        self.window=tk.Toplevel(self.app.root);self.window.title("Player details");self.window.geometry("1010x760");self.window.minsize(780,580);self.window.protocol("WM_DELETE_WINDOW",self.close)
        outer=ttk.Frame(window_body(self.window),padding=14);outer.pack(fill="both",expand=True)
        self.title=tk.StringVar();self.status=tk.StringVar(value="Local observations are not a judgment about a player.")
        ttk.Label(outer,textvariable=self.title,style="Accent.TLabel").pack(anchor="w")
        buttons(outer,(("Full profile…",self.profile),("Open on VRChat",self.website),("Pin / unpin",lambda:self.guard(lambda:self.service.pin(key))),("Toggle VRC Eye favorite",self.favorite)))
        self.tabs=ttk.Notebook(outer);self.tabs.pack(fill="both",expand=True)
        names=("Overview","History","Notes") if self.service.settings["mode"]=="Casual" else ("Overview","Session","Avatar","History","Safety","Notes","Advanced")
        self.pages={};self.texts={}
        for name in names:
            page=ttk.Frame(self.tabs,padding=10);self.tabs.add(page,text=name);self.pages[name]=page
            if name in ("Overview","Session","Avatar","Advanced"):self.texts[name]=text_area(page)
        self.build_history(self.pages["History"]);self.build_notes(self.pages["Notes"])
        if "Safety" in self.pages:self.build_safety(self.pages["Safety"])
        buttons(self.pages["Overview"],(("Refresh roles from API",self.roles),("Refresh relationship",lambda:self.roles(relationship=True)),("Refresh platform / trust…",self.platform),("Friends / mute / block…",self.social)))
        buttons(self.pages["Overview"],(("VRC Eye link…",self.peer_link),))
        ttk.Label(outer,textvariable=self.status,wraplength=950,style="Muted.TLabel").pack(anchor="w",pady=(8,0))
        self.tick()
    def guard(self,action):
        try:return action()
        except (ValueError,KeyError,OSError) as error:self.status.set(str(error));return None
    def current(self):
        row=self.service.rows.get(self.key)
        return row if row and row.instance_key==self.instance else None
    def private(self):return self.service.settings["presentation"]
    def require_user(self):
        if self.private():raise ValueError("Disable presentation mode to access private player data.")
        if not self.user:raise ValueError("This observation has no confirmed user ID.")
        if self.app.demo:raise ValueError("This action is unavailable in simulation.")
        return self.user
    def profile(self):
        def action():
            self.require_user()
            from player_profile_dialog import show_profile
            from world_players import PlayerRow,PlayerVisit
            row=PlayerRow(self.key,self.row.name,PlayerVisit(0,self.row.name,self.user),None,None,self.row.local,())
            show_profile(self.app.world_view,row)
        self.guard(action)
    def website(self):
        self.guard(lambda:webbrowser.open("https://vrchat.com/home/user/"+self.require_user()))
    def platform(self):
        if self.private():self.status.set("Disable presentation mode to refresh player metadata.");return
        if self.tree_key in self.app.world_view.player_rows:
            self.app.world_view.selected_row=self.tree_key;self.app.world_view.refresh_selected_player()
        else:self.status.set("Select this player in the current roster to refresh platform / trust.")
    def favorite(self):
        self.guard(lambda:self.service.update_local(self.require_user(),favorite=not self.service.local.get(self.user,{}).get("favorite",False)))
    def social(self):
        def action():
            user=self.require_user();self.app.sidebar.show("Social")
            page=self.app.sidebar.pages.get("Social")
            if page:page.target.set(user)
        self.guard(action)
    def peer_link(self):
        def action():
            from peer_player import open_peer_player
            open_peer_player(self.app, self.require_user(), self.row.name)
        self.guard(action)
    def build_notes(self,page):
        ttk.Label(page,text="Private notes and tags are shared with profiles, Favorites and local filters in this account. Earlier roster tags are preserved. Saving does not send anything to VRChat.",wraplength=900).pack(anchor="w")
        self.notes=text_area(page,10);self.tags=tk.StringVar();self.keep=tk.BooleanVar(value=True);self.loaded_note=None;self.loaded_tags=None
        bar=ttk.Frame(page);bar.pack(fill="x",pady=5)
        self.notes_workspace=self.service.workspace;self.note_revision=None
        ttk.Label(bar,text="Shared private tags (comma separated)").pack(side="left");ttk.Entry(bar,textvariable=self.tags,width=55).pack(side="left",fill="x",expand=True,padx=8)
        ttk.Checkbutton(page,text="Allow encounter / avatar history for this player",variable=self.keep).pack(anchor="w")
        buttons(page,(("Save notes and tags",self.save_notes),("Delete all local data for this player…",self.delete_all)))
        buttons(page,(("Shared notes / tags…",self.shared_notes),("Reload saved notes",self.reload_notes)))
    def load_notes(self):
        if not self.service.local_ready:
            self.notes.configure(state="disabled");return
        if self.loaded_note is not None:return
        local=self.service.local.get(self.user,{})
        import shared_notes
        self.note_revision=local.get('note_revision') or (shared_notes.empty_player_revision(self.service.workspace,self.user) if self.user else None)
        self.notes_workspace=self.service.workspace
        note=local.get("note","");tags=", ".join(local.get("tags",()))
        self.notes.configure(state="normal");self.notes.delete("1.0","end");self.notes.insert("1.0",note);self.tags.set(tags);self.keep.set(local.get("save_history",True))
        self.loaded_note,self.loaded_tags=note,tags
    def save_notes(self):
        def action():
            user=self.require_user()
            if not self.service.local_ready:raise ValueError("Local notes have not loaded. Wait for storage before editing.")
            if self.notes_workspace!=self.service.workspace:raise ValueError('Workspace changed. Reload notes before saving.')
            body=self.notes.get("1.0","end-1c");tags=[t.strip() for t in self.tags.get().split(",") if t.strip()]
            future=self.service.update_local(user,note=body,tags=tags,save_history=self.keep.get(),note_revision=self.note_revision)
            self.notes_future=future;self.actions.append((future,"Local notes and tags saved."))
        self.guard(action)
    def reload_notes(self):
        def action():
            self.require_user()
            if self.notes.get('1.0','end-1c')!=self.loaded_note and not messagebox.askyesno('Reload notes','Discard this unsaved note draft and reload saved notes?',parent=self.window):return
            self.loaded_note=None;self.service.local_ready=False;self.service.refresh_local()
        self.guard(action)
    def shared_notes(self):
        def action():
            user=self.require_user()
            from shared_notes_ui import show
            def saved():
                self.service.refresh_local()
                if not self.closed:self.loaded_note=None;self.service.local_ready=False
            show(self.app.sidebar,'friend',user,account=self.service.workspace,on_saved=saved)
        self.guard(action)
    def build_history(self,page):
        self.history_kind=tk.StringVar(value="encounters");self.history_offset=0;self.history_rows={};self.history_revision=0
        bar=ttk.Frame(page);bar.pack(fill="x")
        box=ttk.Combobox(bar,textvariable=self.history_kind,values=("encounters","avatars","incidents"),state="readonly",width=18);box.pack(side="left");box.bind("<<ComboboxSelected>>",lambda _:self.load_history(reset=True))
        for label,action in (("Load",lambda:self.load_history(reset=True)),("Previous",lambda:self.history_page(-1)),("Next",lambda:self.history_page(1)),("Export category…",self.export), ("Delete selected…",self.delete_selected)):
            ttk.Button(bar,text=label,command=action).pack(side="left",padx=5)
        self.history=ttk.Treeview(page,columns=("time","end","duration","detail"),show="headings",height=9,selectmode="browse")
        for name,title,width in (("time","FIRST OBSERVED / TIME",180),("end","LAST OBSERVED",180),("duration","SHARED TIME",100),("detail","OBSERVATION",330)):
            self.history.heading(name,text=title);self.history.column(name,width=width,minwidth=60,stretch=name=="detail")
        self.history.pack(fill="both",expand=True,pady=8)
        scroll=ttk.Scrollbar(page,orient="vertical",command=self.history.yview);scroll.pack(fill="x");self.history.configure(yscrollcommand=scroll.set)
        self.history_info=tk.StringVar(value="Load a history category. Pages contain up to 100 records; exports include the whole selected category.")
        ttk.Label(page,textvariable=self.history_info,wraplength=900).pack(anchor="w")
        buttons(page,(("Open selected record…",self.inspect_history),("Clear encounter history…",self.clear_encounters)))
    def history_page(self,delta):self.history_offset=max(0,self.history_offset+100*delta);self.load_history()
    def load_history(self,reset=False):
        def action():
            self.require_user()
            if reset:self.history_offset=0
            self.history_revision+=1;revision=self.history_revision
            def done(records):
                if self.closed or self.private() or revision!=self.history_revision:return
                self.history.delete(*self.history.get_children());self.history_rows={}
                for record in records:
                    key=record["id"];self.history_rows[key]=record
                    detail=record.get("reason") or record.get("name") or "Local incident bookmark"
                    if record.get("reconstructed"):detail+=" · reconstructed"
                    values=(record.get("first_observed",record.get("stamp","")),record.get("closed_at","") or "Unknown",seconds_label(record.get("duration")),detail)
                    self.history.insert("","end",iid=key,values=values)
                self.history_info.set(f"Page {self.history_offset//100+1}: {len(records)} records. Shared time is approximate and excludes unobserved gaps.")
            self.service.job("history",self.user,self.history_kind.get(),self.history_offset,done=done)
        self.guard(action)
    def chosen(self):
        selected=self.history.selection()
        if not selected or selected[0] not in self.history_rows:raise ValueError("Select a stored history record first.")
        return self.history_rows[selected[0]]
    def inspect_history(self):
        def action():
            self.require_user();record=self.chosen()
            text_window(self.app,"Local history record","\n".join(f"{k.replace('_',' ').title()}: {v}" for k,v in record.items()))
        self.guard(action)
    def export(self):
        def action():
            self.require_user();kind=self.history_kind.get()
            path=filedialog.asksaveasfilename(parent=self.window,title="Export this player's "+kind,defaultextension=".json",initialfile="VRC-Eye-player-"+kind+".json",filetypes=(("JSON","*.json"),))
            if path:
                future=self.service.job("export_history",self.user,kind,path);self.actions.append((future,"Selected history category exported."))
        self.guard(action)
    def delete_selected(self):
        def action():
            self.require_user();record=self.chosen()
            if messagebox.askyesno("Delete history record","Delete this exact local record? Notes, tags and favorites are kept.",parent=self.window):
                future=self.service.forget(self.user,(self.history_kind.get(),),record["id"]);self.actions.append((future,"Record deleted. Reload history to update the page."))
        self.guard(action)
    def clear_encounters(self):
        def action():
            self.require_user()
            if messagebox.askyesno("Clear encounters","Delete this player's stored encounters? Notes, tags, favorites, avatar history and incident bookmarks are kept.",parent=self.window):
                self.actions.append((self.service.forget(self.user,("encounters",)),"Encounters cleared. Reload history to update the page."))
        self.guard(action)
    def delete_all(self):
        def action():
            self.require_user()
            if messagebox.askyesno("Delete all player data","Delete this player's local encounters, avatar history, incident bookmarks, notes, tags, favorite and observed names? This cannot be undone.",parent=self.window):
                self.actions.append((self.service.forget(self.user,("encounters","avatars","incidents","notes","tags","favorite","names")),"Player data deleted."));self.loaded_note=None
        self.guard(action)
    def build_safety(self,page):
        ttk.Label(page,text="Your local controls only. Availability depends on the connected client's approved capabilities and a matching instance. Each action is reviewed before sending.",wraplength=900).pack(anchor="w")
        self.safety_text=text_area(page,7)
        self.control=tk.StringVar(value="Mute voice");self.preset=tk.StringVar(value="reduced")
        ttk.Combobox(page,textvariable=self.control,values=tuple(CONTROLS),state="readonly",width=35).pack(anchor="w")
        ttk.Label(page,text="Client preset (when using Apply preset)").pack(anchor="w",pady=(8,0))
        self.preset_box=ttk.Combobox(page,textvariable=self.preset,values=(),state="readonly",width=35);self.preset_box.pack(anchor="w")
        buttons(page,(("Review local action…",self.apply_control),("Client bridge / permissions…",self.bridge),("Local incident bookmark…",self.incident)))
    def bridge(self):
        from bridge_dialog import show_bridge
        show_bridge(self.app)
    def apply_control(self):
        def action():
            self.require_user();row=self.current()
            if not row or not row.active:raise ValueError("Choose a currently observed player.")
            from player_bridge import poll_bridge,request_action
            poll_bridge(self.service,self.app.bridge)
            cap,field,value=CONTROLS[self.control.get()];params={"user_id":row.user_id,field:self.preset.get() if field=="preset" else value}
            if not self.service.bridge_bound or not self.app.bridge.available(cap):raise ValueError("This control needs a fresh matching instance and permission from the connected bridge.")
            state=self.app.bridge.state.snapshot();client=state.get("client") or {};label=client.get("name","Connected client")
            expected=(self.service.meta.get("id"),self.service.bridge_token,row.user_id)
            review=f"{self.control.get()} for {row.name} ({row.user_id}) through {label}.\n\nThis changes your local game controls."
            if field=="preset":review+="\nClient preset: "+state["capabilities"][cap].get("presets",{}).get(self.preset.get(),"Not supplied")
            if messagebox.askyesno("Review local control",review,parent=self.window):
                future=request_action(self.service,self.app.bridge,self.key,cap,params,expected=expected);self.actions.append((future,"Client confirmed the local action."))
        self.guard(action)
    def incident(self):
        def action():
            self.require_user();note=simpledialog.askstring("Local incident bookmark","Describe what you observed. This stays local and is not a report or accusation:",parent=self.window)
            if note is not None:self.service.bookmark(self.key,note);self.status.set("Local incident bookmark queued for saving.")
        self.guard(action)
    def roles(self,relationship=False):
        def action():
            self.require_user()
            if self.job:raise ValueError("A role lookup is already in progress.")
            client=self.app.api
            if not client or not client.authenticated:
                from online_dialog import show_connection_dialog
                show_connection_dialog(self.app,self.roles);return
            row=self.current();meta=self.service.meta
            if not relationship and (not row or not row.active or not meta.get("instance_id")):raise ValueError("A currently observed full instance is required for roles.")
            self.stop.clear();self.job=(client,client.session_revision,meta["id"]);world,instance=meta.get("world_id"),meta["instance_id"]
            self.status.set("Role lookup queued with the shared API rate limit. Close this window to cancel.")
            def run():
                from player_roles import read_roles,read_relationship
                try:
                    result=read_relationship(client,self.user,stop=self.stop) if relationship else read_roles(client,world,instance,self.user,stop=self.stop)
                    self.output.put((result,None))
                except Exception as error:self.output.put((None,error))
            threading.Thread(target=run,daemon=True,name="VRC-Eye-Player-Roles").start()
        self.guard(action)
    def poll_roles(self):
        if not self.job:return
        try:result,error=self.output.get_nowait()
        except queue.Empty:return
        client,revision,instance=self.job;self.job=None
        if self.stop.is_set() or self.app.api is not client or not client.authenticated or client.session_revision!=revision or self.service.meta.get("id")!=instance:return
        if error:self.status.set("Role lookup unavailable. Existing fresh fields remain; unknown roles were not guessed.");return
        try:
            if result.get("kind")=="relationship":self.service.accept_relationship(result);self.status.set("Relationship snapshot loaded.");return
            self.service.apply_roles(result)
        except ValueError as error:self.status.set(str(error));return
        self.status.set(result["incomplete"] or "Role snapshots loaded. Network master is a separate client-reported role.")
    def tick(self):
        if self.closed:return
        current=self.current()
        if current and current.user_id!=self.user:self.user=current.user_id;self.loaded_note=None
        self.poll_roles()
        pending=self.actions;self.actions=[]
        for future,message in pending:
            if not future.done():self.actions.append((future,message));continue
            try:
                result=future.result();self.status.set(message)
                if future is getattr(self,'notes_future',None) and isinstance(result,dict):
                    self.note_revision=result.get('note_revision');self.loaded_note=result.get('note','')
            except ValueError as error:self.status.set(str(error))
            except Exception:self.status.set("The action was not confirmed. Check storage or the bridge; it was not retried.")
        if self.notes_workspace!=self.service.workspace:
            self.notes.configure(state='normal');self.notes.delete('1.0','end');self.tags.set('');self.loaded_note=None;self.note_revision=None
            self.notes_workspace=self.service.workspace;self.presentation_draft=None
        private=self.private()
        if private:
            self.status.set("Presentation mode: private details and history actions are hidden.")
            if getattr(self,"was_private",False) is not True:
                self.presentation_draft=(self.notes.get("1.0","end-1c"),self.tags.get(),self.keep.get(),self.loaded_note) if self.loaded_note is not None else None
                self.notes.configure(state="normal");self.notes.delete("1.0","end");self.notes.configure(state="disabled");self.tags.set("")
                self.history.delete(*self.history.get_children());self.history_rows={};self.history_revision+=1;self.loaded_note=None
                self.history_info.set("Private history hidden in presentation mode.")
            self.was_private=True
        else:
            draft=getattr(self,"presentation_draft",None)
            if getattr(self,"was_private",False):
                if draft:
                    self.notes.configure(state="normal");self.notes.delete("1.0","end");self.notes.insert("1.0",draft[0]);self.tags.set(draft[1]);self.keep.set(draft[2]);self.loaded_note=draft[3]
                self.presentation_draft=None
            self.was_private=False;self.load_notes()
        row=self.current()
        if row is None:
            self.title.set("Observation ended — player belongs to a previous instance")
            for box in self.texts.values():set_text(box,"This session is no longer current. Load stored History for previous encounters.")
            return
        card=self.service.card(row)
        signature=(card,int(self.service.clock()),private)
        if signature==self.last_render:return
        self.last_render=signature;self.title.set(card.name+" · "+card.primary_status)
        overview=f"Relationship: {observation(card.relationship)}\nRoles: {', '.join(card.roles) or 'Unknown / not yet retrieved'}\n\nTime observed present: {seconds_label(card.duration_seconds)}\nJoined: {card.joined_at or 'Unknown'}\nLeft: {card.left_at or 'Not observed'}\nObservation ended: {card.closed_at or 'Still observing'}\n\nAvatar: {observation(card.avatar_name)}\nAvatar state: {observation(card.load_state)}\n\nStored encounters: {card.encounters}\nApproximate closed shared time: {seconds_label(card.shared_seconds)}\nFirst seen: {card.first_seen or 'Not stored'}\nLast seen: {card.last_seen or 'Not stored'}\n\nFlags: {', '.join(card.secondary_flags) or 'None'}"
        if private:overview="Presentation mode: private history, notes, IDs and tags are hidden.\n\n"+overview
        else:
            from peer_player import summary
            overview += '\n\nVRC Eye\n' + summary(self.app, self.user)
        set_text(self.texts["Overview"],overview)
        if "Session" in self.texts:
            set_text(self.texts["Session"],"Presence: "+card.presence.value+"\nEnd reason: "+(card.end_reason or "None")+"\n\n"+("Timeline hidden in presentation mode." if private else "\n".join(" · ".join(item) for item in row.timeline)))
            set_text(self.texts["Avatar"],f"Current observed avatar: {observation(card.avatar_name)}\nAvatar ID: {observation(card.avatar_id)}\nChanges observed: {card.avatar_changes}\nLoad state: {observation(card.load_state)}\nPerformance rank: {observation(card.performance)}\nTexture memory: {card.texture_memory.value/1024**2:.1f} MiB" if card.texture_memory.value is not None else f"Current observed avatar: {observation(card.avatar_name)}\nAvatar ID: {observation(card.avatar_id)}\nChanges observed: {card.avatar_changes}\nLoad state: {observation(card.load_state)}\nPerformance rank: {observation(card.performance)}\nTexture memory: Unknown")
            self.texts["Avatar"].configure(state="normal");self.texts["Avatar"].insert("end","\n\nTexture memory is an estimate, not total VRAM. Missing data remains unknown.\n\n"+observation(card.resource));self.texts["Avatar"].configure(state="disabled")
            set_text(self.texts["Advanced"],"Private diagnostics hidden." if private else json.dumps(dict(user_id=card.user_id,instance_session=card.instance_key,fields={k:dict(v) for k,v in card.diagnostics},health=self.service.health,history_queue=self.service.worker.queue.qsize(),history_error=bool(self.service.worker.failed)),indent=2,ensure_ascii=False))
        if hasattr(self,"safety_text"):
            state=self.app.bridge.state.snapshot();presets=(state.get("capabilities",{}).get("safety.player_preset") or {}).get("presets",{})
            self.preset_box.configure(values=tuple(presets))
            set_text(self.safety_text,"Bridge instance: "+("matched" if self.service.bridge_bound else "not available / not matched")+"\nSpeaking: "+observation(card.speaking)+"\nDistance (feet): "+observation(card.distance)+"\nYour local moderation: "+(str(dict(card.moderation)) if card.moderation else "Unknown")+"\n\nWho blocked or muted you is unavailable. Local incident bookmarks do not establish cause or wrongdoing.")
    def close(self):
        if self.closed:return
        self.closed=True;self.stop.set();self.panel.dialogs.pop(self.key,None);self.window.destroy()


CONTROLS={"Mute voice":("safety.voice_mute","muted",True),"Unmute voice":("safety.voice_mute","muted",False),"Hide avatar":("safety.avatar_visibility","visible",False),"Show avatar":("safety.avatar_visibility","visible",True),"Disable avatar audio":("safety.avatar_audio","enabled",False),"Enable avatar audio":("safety.avatar_audio","enabled",True),"Disable particles":("safety.avatar_particles","enabled",False),"Enable particles":("safety.avatar_particles","enabled",True),"Disable lights":("safety.avatar_lights","enabled",False),"Enable lights":("safety.avatar_lights","enabled",True),"Disable interactions":("safety.interactions","enabled",False),"Enable interactions":("safety.interactions","enabled",True),"Apply preset":("safety.player_preset","preset",None)}


class PlayerSettings:
    def __init__(self,panel):
        self.panel,self.service=panel,panel.service;self.value=deepcopy(self.service.settings);self.vars={};self.columns={}
        self.window=tk.Toplevel(panel.app.root);self.window.title("Player list settings");self.window.geometry("920x730")
        outer=ttk.Frame(window_body(self.window),padding=14);outer.pack(fill="both",expand=True)
        notebook=ttk.Notebook(outer);notebook.pack(fill="both",expand=True);pages={}
        for name in ("Display","History & privacy","Bridge & observations","Notifications"):
            page=ttk.Frame(notebook,padding=12);notebook.add(page,text=name);pages[name]=page
        self.check(pages["Display"],"presentation","Presentation mode: hide private details, IDs, notes, tags and timeline")
        self.check(pages["Display"],"anonymize","Use stable Player 1, Player 2 aliases (also enables presentation mode)")
        self.check(pages["Display"],"search_notes","Include local notes in search (disabled by presentation mode)")
        self.check(pages["Display"],"large_rows","Larger rows")
        ttk.Label(pages["Display"],text="Columns for the currently selected layout; Name is always shown. Casual mode hides technical fields.",wraplength=840).pack(anchor="w",pady=8)
        grid=ttk.Frame(pages["Display"]);grid.pack(fill="x")
        for index,name in enumerate(COLUMNS):
            var=tk.BooleanVar(value=name in self.value["columns"][self.value["layout"]]);self.columns[name]=var
            ttk.Checkbutton(grid,text=name.replace("_"," ").title(),variable=var,state="disabled" if name=="name" else "normal").grid(row=index//4,column=index%4,sticky="w",padx=15,pady=5)
        self.number(pages["Display"],"recent_left","Show recently left players (seconds)")
        self.number(pages["Display"],"recent_join","Recently joined highlight (seconds)")
        privacy=pages["History & privacy"]
        ttk.Label(privacy,text="Encounter = one observed visit, merging rejoin gaps within the configured window. Shared time excludes gaps and unknown joins. Preferences apply to future encounters; existing saved records remain until deleted or expired.",wraplength=840).pack(anchor="w",pady=(0,12))
        self.choice(privacy,"history","Encounter retention",HISTORY)
        for key,label in (("incognito","Incognito: discard current-session encounters, avatars and incidents; keep notes / favorites"),("world_history","Store world name and world ID with future encounters"),("avatar_history","Store observed avatar changes (off by default)")):self.check(privacy,key,label)
        self.number(privacy,"rejoin_window","Merge same-instance rejoins within (seconds)")
        ttk.Label(privacy,text="No voice or distance samples are stored. Notes and VRC Eye favorites are explicit local saves. Deleting encounter history keeps notes, tags and favorites. Per-player storage and deletion are in Player details.",wraplength=840).pack(anchor="w",pady=12)
        bridge=pages["Bridge & observations"]
        for key,label in (("speaking","Show speaking indicators when fresh client data exists"),("follow_selection","Follow the connected client's selected player"),("open_selected","Open player details when following client selection"),("resource_monitor","Observe local process RAM changes near avatar changes")):self.check(bridge,key,label)
        self.choice(bridge,"distance","Distance sampling display",("Off","Selected / pinned","Visible rows"))
        for key,label in (("loading_timeout","Avatar loading timeout (seconds)"),("resource_window","Resource correlation window (seconds)"),("resource_ram_mb","RAM change threshold (MiB)")):self.number(bridge,key,label)
        ttk.Label(bridge,text="Bridge features require a connected, approved adapter and fresh instance.context telemetry. The optional RAM monitor uses psutil to read OS process statistics. Correlations never identify a cause.",wraplength=840).pack(anchor="w",pady=12)
        for key,label in (("notify_friends","Friend join / leave banners"),("notify_pinned","Pinned-player join / leave banners"),("notifications_muted","Mute all player-list notifications")):self.check(pages["Notifications"],key,label)
        ttk.Label(pages["Notifications"],text="Reconstructed events do not notify. Unknown friendship is never treated as non-friend. Presentation mode suppresses banners. VRCX notification ownership is configured under Advanced → VRCX Companion.",wraplength=840).pack(anchor="w",pady=15)
        self.status=tk.StringVar();ttk.Label(outer,textvariable=self.status,wraplength=850).pack(anchor="w",pady=6)
        buttons(outer,(("Save settings",self.save),("Cancel",self.window.destroy)))
    def check(self,page,key,label):
        var=tk.BooleanVar(value=self.value[key]);self.vars[key]=var;ttk.Checkbutton(page,text=label,variable=var).pack(anchor="w",pady=6)
    def number(self,page,key,label):
        bar=ttk.Frame(page);bar.pack(fill="x",pady=5);ttk.Label(bar,text=label).pack(side="left")
        var=tk.StringVar(value=str(self.value[key]));self.vars[key]=var;ttk.Entry(bar,textvariable=var,width=10).pack(side="right")
    def choice(self,page,key,label,values):
        bar=ttk.Frame(page);bar.pack(fill="x",pady=6);ttk.Label(bar,text=label).pack(side="left")
        var=tk.StringVar(value=self.value[key]);self.vars[key]=var;ttk.Combobox(bar,textvariable=var,values=values,state="readonly",width=25).pack(side="right")
    def save(self):
        try:
            value=deepcopy(self.value)
            value["companion_notifications"]=self.service.settings["companion_notifications"]
            for key,var in self.vars.items():value[key]=float(var.get()) if type(value[key]) in (int,float) else var.get()
            value["columns"][value["layout"]]=[key for key,var in self.columns.items() if var.get()]
            self.service.configure(value)
            ttk.Style(self.panel.app.root).configure("PlayerRoster.Treeview",rowheight=38 if value["large_rows"] else 27)
            self.panel.view.roster.configure(style="PlayerRoster.Treeview")
            self.panel.view.draw();self.window.destroy()
        except ValueError as error:self.status.set(str(error))


class PlayerDiagnostics:
    def __init__(self,panel):
        self.panel=panel;self.app=panel.app;self.closed=False;self.stop=threading.Event();self.output=queue.Queue(maxsize=1);self.running=False
        self.window=tk.Toplevel(self.app.root);self.window.title("Player diagnostics / isolated replay");self.window.geometry("900x650");self.window.protocol("WM_DELETE_WINDOW",self.close)
        outer=ttk.Frame(window_body(self.window),padding=14);outer.pack(fill="both",expand=True)
        ttk.Label(outer,text="Aggregate diagnostics only. Replay and synthetic data use a separate in-memory service with no API, bridge, notifications or history writes.",wraplength=850).pack(anchor="w")
        buttons(outer,(("Current service",self.current),("Simulate 128 players",lambda:self.start(None)),("Replay local log…",self.choose),("Cancel replay",self.stop.set)))
        self.text=text_area(outer);self.current();self.tick()
    def current(self):
        service=self.panel.service
        value=dict(players=len(service.rows),active=sum(r.active for r in service.rows.values()),unresolved=sum(not r.user_id for r in service.rows.values()),health=service.health,
                   normalized_events=len(service.seen),timeline_events=len(service.timeline),history_jobs=service.worker.queue.qsize(),history_failed=bool(service.worker.failed),instance_bridge_bound=service.bridge_bound)
        set_text(self.text,json.dumps(value,indent=2))
    def choose(self):
        path=filedialog.askopenfilename(parent=self.window,title="Replay a local VRChat log in isolation",filetypes=(("Log files","*.txt"),))
        if path:self.start(path)
    def start(self,path):
        if self.running:return
        self.running=True;self.stop.clear();set_text(self.text,"Running isolated replay…")
        def run():
            from player_replay import replay,synthetic,report
            try:result=json.dumps(report(replay(path,self.stop) if path else synthetic()),indent=2)
            except (ValueError,OSError):result="Replay unavailable or canceled. Check the file and its size (maximum 256 MiB)."
            self.output.put(result)
        threading.Thread(target=run,daemon=True,name="VRC-Eye-Isolated-Replay").start()
    def tick(self):
        if self.closed:return
        try:result=self.output.get_nowait();self.running=False;set_text(self.text,result)
        except queue.Empty:pass
        self.timer=self.app.root.after(200,self.tick)
    def close(self):
        if self.closed:return
        self.closed=True;self.stop.set();self.app.root.after_cancel(self.timer);self.window.destroy()
