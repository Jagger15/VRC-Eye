"""Avatar Library embedded in Primary → Avatars; no alternate account/provider.

All local work is explicit and bounded. Worker results stay bound to the account
and page generation that started them. Cancelling does not release a worker slot
until the worker has actually stopped. Copy receipts retain their original scope.
"""
from __future__ import annotations

from text_viewport import window_body

import base64
import json
from pathlib import Path
import queue
import re
import sqlite3
import threading
import time

from avatar_library import (AvatarLibrary, SOURCES, active_scope, context_token, decode_document,
                           document_from_item, normalize_observation, build_identity)
from avatar_library_files import (inspect_file, inspect_package, verify_file, copy_record,
                                 local_preview, image_preview, InspectionCancelled, check_cancel,
                                 checked_stream, IMAGE_LIMIT, fingerprint)
from avatar_library_display import readable_details
from avatar_details import format_download_size
from companion_ui import Page, Table, button, choice, entry, line
from creator_projects import ProjectStore
from creator_projects_ui import review_document, text_area, set_text
from vrchat_api import APIError, avatar_search_item

SECTIONS = ("Library", "Details & Builds", "Local Files", "Transfers", "File health & matches", "Metadata updates", "3D preview", "Folder discovery",
            "Import & export", "Shader Packages", "Recovery", "Activity")


class StableTable(Table):
    """Keep identity and focus across refreshes, even with duplicate display names."""
    def set(self, records, values):
        old = self.tree.selection()
        focus = self.tree.focus()
        self.records = {r["id"]: r for r in records}
        for key in self.tree.get_children():
            if key not in self.records: self.tree.delete(key)
        for index, (key, record) in enumerate(self.records.items()):
            if self.tree.exists(key):
                self.tree.item(key, values=values(record)); self.tree.move(key, "", index)
            else: self.tree.insert("", "end", iid=key, values=values(record))
        if old and old[0] in self.records: self.tree.selection_set(old[0])
        if focus in self.records: self.tree.focus(focus)


class AvatarLibraryPage(Page):
    def __init__(self, controller, parent):
        self.controller = controller
        super().__init__(controller.app.sidebar, parent, "Avatar Library")
        self.library = controller.library
        self.library.native = self.shell.store.native
        self.projects = ProjectStore(self.shell.store)
        self.scope = active_scope(self.app)
        self.account = self.context()
        self.selected_id = ""
        self.selected_build = ""
        self.comparison = None
        self.offset = 0
        self.visible = []
        self.images = []
        self.preview_windows = []
        self.remote_previews = {}
        self.notes_avatar = ""
        self.notes_view = None
        self.rendered_revision = -1
        self._last_refresh = 0.
        self.section = self.tk.StringVar(value="Library")
        self.privacy = self.tk.BooleanVar(value=False)
        self.show_paths = self.tk.BooleanVar(value=False)
        self.raw_details = self.tk.BooleanVar(value=False)
        self.show_thumbnails = self.tk.BooleanVar(value=False)
        self.view = self.tk.StringVar(value="List")
        self.scope_label = self.tk.StringVar()
        self.selection_label = self.tk.StringVar(value="Select an avatar. Viewing does not change the worn avatar.")
        self.ttk.Label(parent, textvariable=self.scope_label, style="Accent.TLabel", wraplength=930).pack(anchor="w", pady=4)
        self.ttk.Label(parent, textvariable=self.selection_label, wraplength=930).pack(anchor="w", pady=4)
        row = line(self)
        choice(self, row, self.section, SECTIONS, self.show_section, width=23)
        self.ttk.Checkbutton(row, text="Privacy view (this workspace)", variable=self.privacy, command=self.privacy_changed).pack(side="left", padx=8)
        self.ttk.Checkbutton(row, text="Show local paths", variable=self.show_paths, command=self.privacy_changed).pack(side="left", padx=8)
        self.ttk.Checkbutton(row, text="Raw details", variable=self.raw_details, command=self.refresh_sections).pack(side="left", padx=8)
        self.frames = {name: self.ttk.Frame(parent) for name in SECTIONS}
        self.build_library(self.frames["Library"])
        self.build_details(self.frames["Details & Builds"])
        self.build_files(self.frames["Local Files"])
        self.build_packages(self.frames["Shader Packages"])
        self.build_activity(self.frames["Activity"])
        from avatar_model_preview_ui import ModelPreviewPanel
        from avatar_folder_discovery_ui import FolderDiscoveryPanel
        from avatar_catalog_bulk_ui import ImportExportPanel
        from avatar_recovery_ui import RecoveryPanel
        self.model_preview = ModelPreviewPanel(self, self.frames["3D preview"])
        self.folder_discovery = FolderDiscoveryPanel(self, self.frames["Folder discovery"])
        self.bulk_panel = ImportExportPanel(self, self.frames["Import & export"])
        self.recovery_panel = RecoveryPanel(self, self.frames["Recovery"])
        from avatar_catalog_tools_ui import FileHealthPanel, MetadataPanel
        self.file_health = FileHealthPanel(self, self.frames['File health & matches'])
        self.metadata_updates = MetadataPanel(self, self.frames['Metadata updates'])
        from avatar_transfers_ui import TransfersPanel
        self.transfers = TransfersPanel(self, self.frames['Transfers'])
        self.feature_panels = (self.model_preview, self.folder_discovery, self.bulk_panel, self.recovery_panel,
                               self.file_health, self.metadata_updates, self.transfers)
        self.show_section()
        self.refresh()
        self.status.set("Local-first catalog. Nothing is scanned, downloaded, worn or launched by opening this page.")

    def context(self):
        return context_token(self.app)

    def guard(self, action):
        try:
            if hasattr(self, "library") and self.context() != self.account:
                self.account_changed()
                return
            return action()
        except (ValueError, OSError, RuntimeError, APIError, sqlite3.Error) as error:
            self.status.set(self.safe_error(error))

    def safe_error(self, error):
        if hasattr(self, "privacy") and self.privacy.get():
            return "Action did not complete. Private details are hidden; turn off Privacy view deliberately to inspect them."
        from avatar_creator_store import sanitize_export
        value = str(error)
        return value if hasattr(self, "show_paths") and self.show_paths.get() else sanitize_export(value)

    def writable(self):
        if self.closed: raise ValueError("The avatar library is closed.")
        if self.app.demo or getattr(self.app, "safe_mode", False):
            raise ValueError("Demo and Safe Mode allow browsing only. Leave them before saving or starting avatar tasks.")
        if self.privacy.get():
            raise ValueError("Detailed actions are disabled while Privacy view is enabled.")
        if self.context() != self.account:
            self.account_changed()
            raise ValueError("The account or session changed. Review the current workspace again.")

    def check_context(self, token):
        if self.closed or token != self.context():
            raise ValueError("The account or session changed. Nothing was assigned to the new account.")

    def selected(self):
        if self.context() != self.account:
            self.account_changed()
            raise ValueError("The account or session changed. Select an avatar again in the current workspace.")
        row = self.library.get(self.scope, self.selected_id) if self.selected_id else None
        if not row: raise ValueError("Select an avatar from the current catalog first.")
        return row

    def private_text(self, value, placeholder="Hidden in privacy view"):
        return placeholder if self.privacy.get() else str(value or "Unknown")

    def display(self, value):
        if self.privacy.get(): return "Private details are hidden. Turn off Privacy view deliberately to inspect this selection."
        def clean(item):
            if isinstance(item, dict):
                return {k: ("[local path hidden]" if k in ("path", "destination") and isinstance(v, str)
                            and (v.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", v)) and not self.show_paths.get() else clean(v))
                        for k, v in item.items() if k not in ("thumbnail", "boot_id")}
            if isinstance(item, list): return [clean(x) for x in item]
            return item
        value = clean(value)
        return json.dumps(value, indent=2, ensure_ascii=False) if self.raw_details.get() else readable_details(value)

    def privacy_changed(self):
        __import__('text_translation_ui').close_for(self)
        self.cancel()
        self.clear_feature_panels()
        for window in tuple(self.preview_windows):
            try: window.destroy()
            except Exception: pass
        self.preview_windows.clear()
        self.remote_previews.clear()
        self.images.clear()
        self.notes_avatar = ""
        if self.privacy.get():
            self.show_paths.set(False); self.show_thumbnails.set(False)
            self.query.set(""); self.notes.delete("1.0", "end"); self.notes_avatar = ""
        self.refresh()

    def show_section(self, name=None):
        if name is not None: self.section.set(name)
        target = self.section.get()
        if target not in self.frames: return
        for key, frame in self.frames.items():
            if key == target: frame.pack(fill="both", expand=True)
            else: frame.pack_forget()
        if hasattr(self, "activity_table"): self.refresh_sections()

    def build_library(self, parent):
        self.query = self.tk.StringVar()
        self.platform = self.tk.StringVar(value="All")
        self.visibility = self.tk.StringVar(value="All")
        self.source = self.tk.StringVar(value="All")
        self.sort = self.tk.StringVar(value="Name")
        self.favorites_only = self.tk.BooleanVar(value=False)
        self.files_only = self.tk.BooleanVar(value=False)
        self.after = self.tk.StringVar(); self.before = self.tk.StringVar()
        self.count_label = self.tk.StringVar()
        self.ttk.Label(parent, text="Saved observations, not a global avatar search or proof of ownership. Imported metadata and old builds may be incomplete or outdated.", style="Muted.TLabel", wraplength=920).pack(anchor="w", pady=6)
        row = line(self, parent)
        self.ttk.Label(row, text="Find").pack(side="left", padx=(0, 6))
        entry(self, row, self.query, 36).bind("<Return>", lambda event: self.guard(self.search))
        button(self, row, "Filter", self.search)
        button(self, row, "Reset filters", self.reset_filters)
        choice(self, row, self.view, ("List", "Cards"), self.search, width=10)
        row = line(self, parent)
        self.ttk.Label(row, text="Platform / visibility / source").pack(side="left", padx=(0, 6))
        choice(self, row, self.platform, ("All", "PC", "Android", "iOS", "Unknown"), width=10)
        choice(self, row, self.visibility, ("All", "Public", "Private", "Hidden", "Unavailable", "Unknown"), width=12)
        choice(self, row, self.source, ("All",) + SOURCES, width=19)
        row = line(self, parent)
        self.ttk.Checkbutton(row, text="Favorites", variable=self.favorites_only, command=self.search).pack(side="left", padx=5)
        self.ttk.Checkbutton(row, text="Has file records", variable=self.files_only, command=self.search).pack(side="left", padx=5)
        self.ttk.Checkbutton(row, text="Show saved thumbnails", variable=self.show_thumbnails, command=self.render).pack(side="left", padx=5)
        choice(self, row, self.sort, ("Name", "Last observed", "Updated"), self.search, width=16)
        row = line(self, parent)
        self.ttk.Label(row, text="Updated date, from / to (YYYY-MM-DD)").pack(side="left", padx=5)
        entry(self, row, self.after, 12); entry(self, row, self.before, 12)
        self.list_container = self.ttk.Frame(parent)
        self.list_container.pack(fill="both", expand=True)
        self.catalog = StableTable(self, self.list_container, (("name", "Avatar", 200), ("author", "Creator", 150),
                    ("platform", "Reported platforms", 130), ("state", "Visibility", 100), ("favorite", "Saved", 70)), height=8, select=self.table_select)
        self.card_container = self.ttk.Frame(parent)
        row = self.pager = line(self, parent)
        button(self, row, "Previous", lambda: self.page(-1)); button(self, row, "Next", lambda: self.page(1))
        self.ttk.Label(row, textvariable=self.count_label).pack(side="left", padx=8)
        row = line(self, parent)
        button(self, row, "Add avatar ID…", self.add_id)
        button(self, row, "Import avatar JSON…", self.import_json)
        button(self, row, "Browse online…", self.browse_online)
        row = line(self, parent)
        button(self, row, "Save creator workspace", self.save_workspace)
        button(self, row, "Favorite / unfavorite", self.favorite)
        button(self, row, "Details & builds", lambda: self.show_section("Details & Builds"))
        button(self, row, "Translate name / text…", lambda:__import__('text_translation_ui').show_avatar(self))
        row = line(self, parent)
        button(self, row, "Export selected report…", self.export_selected)
        button(self, row, "Forget selected avatar…", self.forget_avatar)

    def build_details(self, parent):
        self.ttk.Label(parent, text="Build history contains only descriptors you imported or explicitly observed. A file revision is distinct from an avatar version, Unity version and source-project version.", wraplength=920, style="Muted.TLabel").pack(anchor="w", pady=6)
        row = line(self, parent)
        button(self, row, "Refresh from VRChat…", self.refresh_online)
        button(self, row, "Open creator tools", self.open_creator)
        button(self, row, "Download / save VRCA…", self.download)
        button(self, row, "Resumable transfers…", lambda: self.show_section('Transfers'))
        row = line(self, parent)
        button(self, row, "Attach local preview…", self.attach_preview)
        button(self, row, "Open attached preview", self.open_preview)
        button(self, row, "Load remote thumbnail…", self.remote_preview)
        self.build_table = StableTable(self, parent, (("platform", "Platform", 90), ("unity", "Unity", 130),
                ("version", "Asset / file revision", 160), ("variant", "Variant", 90), ("observed", "Last observed", 170)), height=6, select=self.build_select)
        row = line(self, parent)
        button(self, row, "Use as comparison A", self.pin_comparison)
        button(self, row, "Compare A with selected", self.compare_builds)
        button(self, row, "Performance reports…", self.open_performance_reports)
        self.details = text_area(self, parent, height=9)
        self.ttk.Label(parent, text="Private local notes (never sent to VRChat or included in standard exports)").pack(anchor="w", pady=(8, 2))
        self.notes = self.tk.Text(parent, height=3, width=70, wrap="word")
        self.notes.pack(fill="x", pady=4)
        button(self, line(self, parent), "Save local notes", self.save_notes)
        row = line(self, parent)
        self.project_choice = self.tk.StringVar(value="Choose a catalogued project")
        self.project_picker = choice(self, row, self.project_choice, ("Choose a catalogued project",), width=36)
        button(self, row, "Link project", self.link_project)
        button(self, row, "Creator Projects (VCC)", self.open_projects)
        self.project_label = self.tk.StringVar()
        self.ttk.Label(parent, textvariable=self.project_label, wraplength=920, style="Muted.TLabel").pack(anchor="w", pady=5)

    def open_performance_reports(self):
        from inspection_reports_ui import show
        row=self.selected();avatar_id=row['id'];token=self.context()
        def guard():
            self.check_context(token)
            if self.privacy.get() or self.selected_id!=avatar_id:raise ValueError('Avatar selection or privacy changed. Reopen performance reports.')
        guard();return show(self.shell,'Avatar performance',avatar_id=avatar_id,owner_guard=guard)

    def build_files(self, parent):
        self.ttk.Label(parent, text="File references do not grant editing or redistribution rights. Identical bytes remain separate references. An unavailable path may be a disconnected drive, not a deleted file.", wraplength=920, style="Muted.TLabel").pack(anchor="w", pady=6)
        self.attach_build = self.tk.BooleanVar(value=False)
        self.build_link_label = self.tk.StringVar(value="New file association: avatar only")
        row = line(self, parent)
        self.ttk.Checkbutton(row, text="Associate new file with selected build", variable=self.attach_build, command=self.update_build_label).pack(side="left")
        self.ttk.Label(parent, textvariable=self.build_link_label, wraplength=920).pack(anchor="w", pady=4)
        row = line(self, parent)
        button(self, row, "Register local file…", self.register_local)
        button(self, row, "Recheck selected file", self.recheck)
        button(self, row, "Copy selected file…", self.copy_file)
        self.file_table = StableTable(self, parent, (("name", "File", 220), ("role", "Role", 90), ("size", "Recorded size", 100),
                        ("state", "Last check", 170), ("date", "Checked at", 150)), height=8, select=self.file_select)
        row = line(self, parent)
        button(self, row, "Find duplicate bytes", self.file_duplicates)
        button(self, row, "Forget reference only…", self.forget_file)
        self.file_details = text_area(self, parent, height=9)

    def build_packages(self, parent):
        self.ttk.Label(parent, text="Read-only shader/package inventory. No extraction, import, script execution or shader replacement. Material references outside the selected package are unresolved here—not confirmed missing.", wraplength=920, style="Muted.TLabel").pack(anchor="w", pady=6)
        row = line(self, parent)
        button(self, row, "Inspect shader / package…", self.inspect_shader_package)
        button(self, row, "Find duplicate packages", self.package_duplicates)
        button(self, row, "Forget report only…", self.forget_package)
        self.package_table = StableTable(self, parent, (("name", "Package / source", 250), ("format", "Format", 140),
                            ("shaders", "Shader entries", 100), ("materials", "Materials", 100), ("date", "Inspected at", 170)), height=6, select=self.package_select)
        self.package_details = text_area(self, parent, height=16)

    def build_activity(self, parent):
        self.ttk.Label(parent, text="Local task receipts are bound to the initiating account. Interrupted tasks require inspection of their destination; they are never automatically retried. Transfers opened in the existing VRCA dialog retain that dialog's cancellation controls.", wraplength=920, style="Muted.TLabel").pack(anchor="w", pady=6)
        self.activity_table = StableTable(self, parent, (("operation", "Task", 220), ("state", "Outcome", 190), ("date", "Started at", 170)), height=8, select=self.job_select)
        self.activity_details = text_area(self, parent, height=9)

    def search(self):
        self.offset = 0
        self.render()

    def reset_filters(self):
        self.query.set(""); self.after.set(""); self.before.set("")
        for var in (self.platform, self.visibility, self.source): var.set("All")
        self.favorites_only.set(False); self.files_only.set(False); self.sort.set("Name")
        self.search()

    def page(self, step):
        size = 12 if self.view.get() == "Cards" else 48
        if step > 0 and not getattr(self, "has_more", False): return
        self.offset = max(0, self.offset + step * size)
        self.render()

    def render(self):
        if self.context() != self.account:
            self.account_changed()
            return
        size = 12 if self.view.get() == "Cards" else 48
        result = self.library.list(self.scope, query=self.query.get(), platform=self.platform.get(),
                   visibility=self.visibility.get(), source=self.source.get(), favorite=self.favorites_only.get(),
                   local_files=self.files_only.get(), after=self.after.get(), before=self.before.get(),
                   sort=self.sort.get(), offset=self.offset, limit=size)
        self.visible, self.has_more = result["items"], result["has_more"]
        self.catalog.set(self.visible, lambda r: (self.private_text(r.get("name") or r["id"], "Hidden avatar"),
                         self.private_text(r.get("author"), "Hidden creator"), " / ".join(r.get("platforms", [])) or "Unknown",
                         r.get("visibility", "unknown"), "Favorite" if r.get("favorite") else "—"))
        self.count_label.set(f"{result['total']} match(es) · {self.offset + 1 if self.visible else 0}–{self.offset + len(self.visible)} shown")
        self.images.clear()
        for child in self.card_container.winfo_children(): child.destroy()
        if self.view.get() == "Cards":
            self.list_container.pack_forget()
            self.card_container.pack(fill="both", expand=True, before=self.pager)
            buttons = []
            for index, row in enumerate(self.visible):
                label = self.private_text(row.get("name") or row["id"], "Hidden avatar") + "\n" + self.private_text(row.get("author"), "Hidden creator")
                label += "\n" + (" / ".join(row.get("platforms", [])) or "Unknown platform") + (" · Favorite" if row.get("favorite") else "")
                options = {"text": label, "compound": "top", "width": 26}
                if self.show_thumbnails.get() and not self.privacy.get() and row.get("thumbnail"):
                    try:
                        photo = self.tk.PhotoImage(master=self.app.root, data=row["thumbnail"])
                        self.images.append(photo); options["image"] = photo
                    except Exception: pass
                card = self.ttk.Button(self.card_container, command=lambda r=row: self.guard(lambda: self.select_avatar(r["id"])), **options)
                card._eye_focus_identity = ('avatar', row['id'])
                card.grid(row=index//3, column=index%3, sticky="nsew", padx=5, pady=5)
                buttons.append(card)
            for column in range(3): self.card_container.columnconfigure(column, weight=1)
            for index, widget in enumerate(buttons):
                for key, step in (("<Right>", 1), ("<Left>", -1), ("<Down>", 3), ("<Up>", -3)):
                    def move(event, i=index, delta=step):
                        buttons[max(0, min(len(buttons)-1, i+delta))].focus_set()
                        return "break"
                    widget.bind(key, move)
        else:
            self.card_container.pack_forget()
            self.list_container.pack(fill="both", expand=True, before=self.pager)
        self.rendered_revision = self.library.revision

    def refresh(self):
        self.scope_label.set("Workspace: " + ("Local / signed out" if self.scope == "local" else
                            "Signed-in account (identity hidden)" if self.privacy.get() else self.scope) +
                             " · Local catalog state; no online write permissions")
        self.render()
        self.refresh_sections()

    def table_select(self):
        row = self.catalog.selected()
        if row: self.select_avatar(row["id"])

    def select_avatar(self, identifier):
        if self.context() != self.account:
            self.account_changed()
            return
        if identifier != self.selected_id:
            if self.job:
                self.cancel()
            self.selected_id = identifier
            self.clear_feature_panels()
            self.selected_build = ""; self.comparison = None; self.attach_build.set(False)
        self.refresh_sections()

    def refresh_sections(self):
        if self.context() != self.account:
            self.account_changed()
            return
        row = self.library.get(self.scope, self.selected_id) if self.selected_id else None
        if row is None:
            self.selected_id = ""
            self.selection_label.set("Select an avatar. Viewing does not change the worn avatar.")
        else:
            self.selection_label.set(self.private_text(row.get("name") or row["id"]) + " · " + self.private_text(row["id"]))
        builds = self.library.records(self.scope, "build", self.selected_id) if row else []
        self.build_table.set(builds, lambda b: (b["platform"], b["unity"] or "Unknown", (b["asset_version"] or "?") + " / " + (b["file_version"] or "?"), b["variant"], b["last_seen"]))
        files = self.library.records(self.scope, "file", self.selected_id) if row else []
        self.file_table.set(files, lambda f: (self.private_text(f["name"], "Hidden file"), f["role"], format_download_size(f["size"]), f["availability"], f["checked_at"]))
        packages = self.library.records(self.scope, "package", self.selected_id) if row else []
        self.package_table.set(packages, lambda p: (self.private_text(p["name"], "Hidden package"), p["format"], p["shader_count"], p["material_count"], p["inspected_at"]))
        self.activity_table.set(self.library.jobs(self.scope), lambda j: (j["operation"], j["state"], j["started_at"]))
        if row:
            details = {k: v for k, v in row.items() if k not in ("notes", "thumbnail", "current_builds")}
            author_evidence = row.get("field_evidence", {}).get("author_id", {}).get("source")
            details["author_check"] = ("Author ID matches current account in an API snapshot; this is not a permission grant." if
                 self.scope != "local" and row.get("author_id") == self.scope and author_evidence == "VRChat API" else
                 "Authorship / modification permission not established by this catalog.")
            set_text(self.details, self.display(details))
        else: set_text(self.details, "No avatar selected.")
        if self.notes_avatar != self.selected_id or self.privacy.get():
            self.notes.delete("1.0", "end")
            self.notes_view=None
            if row and not self.privacy.get():
                if not row['id'].startswith('local:'):
                    self.notes_view,_=self.library.note_view(self.scope,row['id'])
                self.notes.insert("1.0", self.notes_view.text if self.notes_view else row.get("notes", ""))
            self.notes_avatar = self.selected_id
        for table, widget in ((self.file_table, self.file_details),
                              (self.package_table, self.package_details),
                              (self.activity_table, self.activity_details)):
            selected_record = table.selected()
            set_text(widget, "Details hidden." if self.privacy.get() else
                     self.display(selected_record) if selected_record else "Select a record.")
        self.update_build_label()
        self.project_rows = {f"{p['label']} · {p['id'][:8]}": p for p in self.projects.list(limit=256)} if not self.privacy.get() else {}
        self.project_picker.configure(values=tuple(self.project_rows) or ("Choose a catalogued project",))
        if self.project_choice.get() not in self.project_rows: self.project_choice.set("Choose a catalogued project")
        linked = self.projects.for_entity("" if self.scope == "local" else self.scope, "avatar", self.selected_id) if row and not self.selected_id.startswith("local:") else []
        self.project_label.set("Project associations hidden." if self.privacy.get() else
                               "Linked projects: " + (", ".join(p["label"] for p in linked) or "None") + ". Links do not establish ownership or modify the project.")

    def build_select(self):
        row = self.build_table.selected()
        if row:
            self.selected_build = row["id"]
            set_text(self.details, self.display(row))
            self.update_build_label()

    def update_build_label(self):
        row = self.library.record(self.scope, "build", self.selected_build) if self.selected_build else None
        self.build_link_label.set("New file association: " + (f"{row['platform']} · asset {row['asset_version'] or '?'} · file {row['file_version'] or '?'}" if self.attach_build.get() and row else "avatar only"))

    def build_for_attachment(self):
        if not self.attach_build.get(): return ""
        row = self.library.record(self.scope, "build", self.selected_build) if self.selected_build else None
        if not row or row["avatar_id"] != self.selected_id:
            raise ValueError("Select a build in Details & Builds first, or turn off the build association.")
        return row["id"]

    def file_select(self):
        row = self.file_table.selected()
        if row: set_text(self.file_details, self.display(row))

    def package_select(self):
        row = self.package_table.selected()
        if row: set_text(self.package_details, self.display(row))

    def job_select(self):
        row = self.activity_table.selected()
        if row: set_text(self.activity_details, self.display(row))

    def pin_comparison(self):
        row = self.build_table.selected()
        if not row: raise ValueError("Select comparison build A first.")
        self.comparison = row
        self.status.set("Comparison A retained. Select another observed build, then Compare.")

    def compare_builds(self):
        row = self.build_table.selected()
        if not self.comparison or not row: raise ValueError("Choose comparison A and a second build.")
        if row["avatar_id"] != self.comparison["avatar_id"]: raise ValueError("Compare builds of the same avatar.")
        keys = ("platform", "unity", "asset_version", "file_id", "file_version", "variant", "created_at", "identity_evidence", "first_seen", "last_seen")
        report = {k: {"A": self.comparison.get(k) or "Unknown", "B": row.get(k) or "Unknown", "different": self.comparison.get(k) != row.get(k)} for k in keys}
        set_text(self.details, self.display(report))

    def start_task(self, work, done, *, avatar="", operation="Inspect", destination="", persist=None):
        self.writable()
        if self.job: raise ValueError("A task is still active or stopping. Wait for its outcome before starting another.")
        token, scope = self.context(), self.scope
        receipt = self.library.begin_job(scope, avatar, operation, destination=destination) if avatar else ""
        stop, output = threading.Event(), queue.Queue(maxsize=1)
        job = {"stop": stop, "output": output, "context": token, "done": done, "progress": "Starting…", "receipt": receipt}
        self.job = job
        self.app.transfer_stops.append(stop)
        def report(*values):
            if len(values) == 2 and isinstance(values[0], int):
                job["progress"] = f"{operation}: {format_download_size(values[0])}" + (" / " + format_download_size(values[1]) if values[1] is not None else "")
            else: job["progress"] = str(values[0])[:800] if values else operation
        def run():
            state, result = "Complete", None
            try:
                check_cancel(stop)
                result = work(stop, report)
                # A copy's completed destination remains recorded in the initiating
                # scope even if cancellation arrives after atomic publication.
                if persist is not None:
                    persist(result, scope)
                else:
                    check_cancel(stop)
            except InspectionCancelled:
                state = "Cancelled"
            except (ValueError, OSError, APIError, sqlite3.Error) as error:
                state, result = "Failed", str(error)[:900]
            except Exception:
                state, result = "Failed", "The bounded task could not process this input. No automatic retry."
            try:
                if receipt:
                    self.library.finish_job(scope, receipt, state, "Inspect the destination before retrying." if state != "Complete" and destination else "")
            except (ValueError, RuntimeError, sqlite3.Error):
                # The application may have closed. The prewritten destination and
                # Running receipt remain for interrupted-outcome review on restart.
                pass
            finally:
                if stop in self.app.transfer_stops: self.app.transfer_stops.remove(stop)
                output.put((state, result))
        thread = threading.Thread(target=run, name="VRC-Eye-Avatar-Library", daemon=False)
        job["thread"] = thread
        thread.start()
        self.status.set(operation + " started. Cancel is available; originals are preserved.")

    def tick(self):
        if self.closed: return
        if self.context() != self.account: self.account_changed()
        job = self.job
        if job:
            try:
                if job["thread"].is_alive():
                    raise queue.Empty
                state, result = job["output"].get_nowait()
            except queue.Empty:
                if not job["stop"].is_set() and job["context"] == self.context(): self.status.set(job["progress"])
            else:
                self.job = None
                if job["context"] == self.context():
                    if state == "Complete" and not job["stop"].is_set():
                        self.status.set("Task complete.")
                        self.guard(lambda: job["done"](result))
                    elif state == "Complete":
                        self.status.set("The task completed before cancellation took effect. Review its receipt and destination.")
                    else: self.status.set("Task cancelled." if state == "Cancelled" else self.safe_error(result))
                    self.refresh_sections()
                else: self.status.set("An earlier account's task ended. Its receipt remains in that account's scope.")
        if self.library.revision != self.rendered_revision and time.monotonic() - self._last_refresh > 1:
            self._last_refresh = time.monotonic()
            self.guard(self.render)
        for panel in getattr(self, "feature_panels", ()):
            tick = getattr(panel, "tick", None)
            if tick:
                self.guard(tick)

    def cancel(self):
        if self.job:
            self.job["stop"].set()
            self.status.set("Cancellation requested. Waiting for the worker to release its files; completed copies are not deleted.")
        self.revision += 1

    def account_changed(self):
        __import__('text_translation_ui').close_for(self)
        self.cancel()
        self.scope, self.account = active_scope(self.app), self.context()
        self.remote_previews.clear(); self.images.clear()
        self.selected_id = self.selected_build = self.notes_avatar = ""
        self.clear_feature_panels()
        self.comparison = None
        self.query.set(""); self.offset = 0
        for window in tuple(self.preview_windows):
            try: window.destroy()
            except Exception: pass
        self.preview_windows.clear()
        self.refresh()
        self.status.set("Account context changed. Old selections, previews and pending reviews were cleared.")

    def close(self):
        __import__('text_translation_ui').close_for(self)
        self.cancel(); self.closed = True
        for panel in getattr(self, "feature_panels", ()):
            close = getattr(panel, "close", None)
            if close:
                close()
            else:
                panel.clear()
        for window in tuple(self.preview_windows):
            try: window.destroy()
            except Exception: pass
        self.preview_windows.clear(); self.images.clear(); self.remote_previews.clear()
        return True

    def clear_feature_panels(self):
        for panel in getattr(self, "feature_panels", ()):
            panel.clear()

    def review(self, title, details, accept="Save record"):
        token = self.context()
        approved = review_document(self.app, title, details, accept)
        self.check_context(token)
        return approved

    def accept_observation(self, document, source):
        self.writable()
        observation = normalize_observation(document, source)
        summary = {"workspace": self.scope, "metadata": observation["metadata"],
                   "build_descriptors": len(observation["builds"]), "source": source,
                   "effect": "Save a local observation. No avatar selection, online edit, download or permission grant."}
        if not self.review("Save avatar observation", json.dumps(summary, indent=2, ensure_ascii=False)):
            self.status.set("Observation not saved."); return
        row = self.library.observe(self.scope, document, source)
        if observation["preview_url"]:
            self.remote_previews[row["id"]] = observation["preview_url"]
        # Existing download selection service remains the only source of URLs.
        try:
            from vrca_files import parse_avatar_assets, VRCAError
            export = parse_avatar_assets(json.dumps(document), row["id"])
        except (ValueError, VRCAError):
            pass
        else:
            self.app.remember_avatar_export(export, generation=self.app.data_generation)
        self.selected_id = row["id"]; self.selected_build = ""; self.comparison = None
        self.offset = 0; self.refresh()
        self.status.set("Avatar observation saved in this workspace. No online state was changed.")

    def add_id(self):
        self.writable()
        from tkinter import simpledialog
        token = self.context()
        value = simpledialog.askstring("Add avatar", "Avatar ID, VRChat avatar page link, or a local creator UUID:", parent=self.app.root)
        self.check_context(token)
        if value is None: return
        name = simpledialog.askstring("Local display name", "Optional display name for this local record:", parent=self.app.root)
        self.check_context(token)
        if name is None: return
        self.accept_observation({"id": value.strip(), "name": name}, "Manual entry")

    def import_json(self):
        self.writable()
        from tkinter import filedialog
        token = self.context()
        path = filedialog.askopenfilename(parent=self.app.root, title="Import one avatar JSON object", filetypes=(("Avatar metadata", "*.json"),))
        self.check_context(token)
        if not path: return
        def work(stop, progress):
            check_cancel(stop)
            # Use the same nonblocking regular-file guard as inventory reads.
            # Opening a FIFO through a plain metadata reader could stall shutdown.
            with checked_stream(path, limit=2 * 1024 * 1024) as (_, stream, _):
                document = decode_document(stream.read(2 * 1024 * 1024 + 1))
            normalize_observation(document)
            return document
        self.start_task(work, lambda doc: self.accept_observation(doc, "Imported JSON"), operation="Inspect avatar JSON")

    def browse_online(self):
        if self.privacy.get(): raise ValueError("Turn off Privacy view before opening the separate online browser.")
        self.app.search_avatars()

    def save_workspace(self):
        self.writable()
        avatar = self.controller.current_avatar()
        records = self.controller.store.list("workspace", avatar, limit=1)
        self.accept_observation({"id": avatar, "name": records[0]["data"].get("name", avatar) if records else avatar}, "Creator workspace")

    def favorite(self):
        self.writable(); row = self.selected()
        self.library.edit_local(self.scope, row["id"], favorite=not row.get("favorite", False))
        self.refresh()
        self.status.set("Local favorite changed. VRChat favorites were not changed.")

    def save_notes(self):
        self.writable(); row = self.selected()
        if self.privacy.get(): raise ValueError("Notes cannot be edited while Privacy view hides them.")
        value=self.notes.get('1.0','end-1c');token=self.context()
        from avatar_catalog_tools_ui import hidden
        if hidden(self):raise ValueError('Reveal private information before saving notes.')
        view=getattr(self,'notes_view',None)
        if view and view.pending:
            from shared_notes import review_text
            if not self.review('Review earlier avatar notes',review_text(view,value),'Save this shared note'):return
        def guard():
            self.writable();self.check_context(token)
            if hidden(self):raise ValueError('Privacy changed. Review notes again.')
        guard()
        self.library.edit_local(self.scope, row["id"], notes=value,notes_view=view,reconcile=True,guard=guard)
        if view:self.notes_view,_=self.library.note_view(self.scope,row['id'])
        self.status.set("Private local notes saved. Standard reports omit these notes.")

    def refresh_online(self):
        self.writable(); row = self.selected()
        if row["id"].startswith("local:"): raise ValueError("A local creator UUID has no online avatar record.")
        client = self.connected()
        if not self.review("Read VRChat avatar metadata", f"Account: {self.scope}\nAvatar: {row['id']}\n\nRead through the existing VRC Eye API transport and request budget. Results are a snapshot, not proof of access to the underlying files. You will review the local save separately.", "Read metadata"):
            return
        self.start_task(lambda stop, progress: client.lookup("avatar", row["id"], stop=stop, progress=progress),
                        lambda result: self.accept_observation(document_from_item(avatar_search_item(result)), "VRChat API"),
                        avatar=row["id"], operation="Read avatar metadata")

    def open_creator(self):
        row = self.selected()
        if self.privacy.get(): raise ValueError("Turn off Privacy view before opening creator details.")
        self.writable()
        self.controller.set_workspace(row["id"], row.get("name", ""))
        self.app.experience.open_tool("avatar:Creator")

    def download(self):
        self.writable(); row = self.selected()
        if row["id"].startswith("local:"): raise ValueError("Use Register local file for a local creator workspace.")
        if self.privacy.get(): raise ValueError("Turn off Privacy view before opening the separate file-transfer dialog.")
        token, scope, avatar = self.context(), self.scope, row["id"]
        if not self.review("Open reviewed file transfer", f"Account workspace: {scope}\nAvatar: {avatar}\n\nThe existing VRCA dialog handles file access and cancellation. Only copies you own or are authorized to preserve should be saved. A successful transfer can be recorded here after an explicit file-association review. Other transfer dialogs are not automatically inventoried.", "Open file transfer"):
            return
        def saved(result, export, selected_choice):
            self.check_context(token)
            if export is None or export.avatar_id != avatar or selected_choice is None:
                self.status.set("File saved, but no exact avatar/build association was supplied. Register it manually after checking the file.")
                return
            build = build_identity({"platform": selected_choice.platform, "unityVersion": selected_choice.unity_version,
                                    "assetVersion": selected_choice.asset_version, "variant": selected_choice.variant, "assetUrl": selected_choice.url})
            found = next((b for b in self.library.records(scope, "build", avatar) if b["descriptor_id"] == build["id"]), None)
            if not self.review("Record completed transfer", f"Avatar: {avatar}\nFile: {result.path}\nSize: {result.size}\nSHA-256: {result.sha256}\nBuild association: {'matching observed build' if found else 'avatar only'}\n\nThis records the completed file, not ownership, source-project recovery or successful avatar loading.", "Inspect and record"):
                return
            # Re-read saved bytes in the normal bounded job, not on the Tk thread.
            def work(stop, progress):
                evidence = inspect_file(result.path, stop=stop, progress=progress)
                if evidence["sha256"] != result.sha256 or evidence["size"] != result.size:
                    raise ValueError("The saved file changed before it could be inventoried.")
                return evidence
            self.start_task(work, lambda evidence: self.complete_file(scope, avatar, evidence,
                              build_id=found["id"] if found else "", provenance="Completed VRC Eye transfer; user-confirmed association"),
                            avatar=avatar, operation="Record completed transfer")
        from vrca_dialog import show_vrca_dialog
        show_vrca_dialog(self.app, avatar, on_saved=saved)

    def complete_file(self, scope, avatar, evidence, *, build_id="", role="asset", provenance="User-authorized local file"):
        self.library.register_file(scope, avatar, evidence, build_id=build_id, role=role, provenance=provenance)
        self.refresh()
        self.status.set("File reference saved. The original was not moved, modified or deleted.")

    def register_local(self):
        self.writable(); row = self.selected()
        from tkinter import filedialog
        token, scope, avatar, build = self.context(), self.scope, row["id"], self.build_for_attachment()
        path = filedialog.askopenfilename(parent=self.app.root, title="Choose your authorized local avatar/source file")
        self.check_context(token)
        if not path: return
        def done(evidence):
            if not self.review("Register local file", json.dumps({"avatar": avatar, "workspace": scope, "build_id": build or "Avatar only", **evidence}, indent=2) +
                "\n\nRegister only content you own or have permission to preserve. A hash identifies bytes, not rights or a working Unity project.", "Register reference"):
                return
            self.complete_file(scope, avatar, evidence, build_id=build)
        self.start_task(lambda stop, progress: inspect_file(path, stop=stop, progress=progress), done,
                        avatar=avatar, operation="Inspect local file")

    def recheck(self):
        self.writable(); avatar = self.selected()["id"]
        row = self.file_table.selected()
        if not row: raise ValueError("Select a file record first.")
        scope = self.scope
        def done(result):
            self.library.update_file_check(scope, row["id"], result)
            self.refresh_sections(); self.file_select()
            self.status.set("File check: " + result["availability"] + ". Recorded original hash remains unchanged.")
        self.start_task(lambda stop, progress: verify_file(row, stop=stop, progress=progress), done, avatar=avatar, operation="Recheck local file")

    def copy_file(self):
        self.writable(); avatar = self.selected()["id"]
        row = self.file_table.selected()
        if not row: raise ValueError("Select a file record first.")
        from tkinter import filedialog
        token, scope = self.context(), self.scope
        original = Path(row["path"])
        destination = filedialog.asksaveasfilename(parent=self.app.root, title="Save a new byte-for-byte copy", initialfile=original.stem + "-copy" + original.suffix, confirmoverwrite=False)
        self.check_context(token)
        if not destination: return
        if not self.review("Copy authorized local file", f"Workspace: {scope}\nAvatar: {avatar}\nSource: {row['path']}\nDestination: {destination}\nSHA-256: {row['sha256']}\n\nOriginal preserved. Destination must not exist. A source change stops the copy; this is not a repair, extraction or Unity source recovery.", "Copy file"):
            return
        def persist(evidence, captured_scope):
            self.library.register_file(captured_scope, avatar, evidence, build_id=row.get("build_id", ""),
                                       role=row["role"], provenance="Verified local copy of user-authorized reference")
        self.start_task(lambda stop, progress: copy_record(row, destination, stop=stop, progress=progress),
                        lambda evidence: (self.refresh_sections(), self.status.set("Verified copy saved and recorded. Original unchanged.")),
                        avatar=avatar, operation="Copy local file", destination=destination, persist=persist)

    def file_duplicates(self):
        set_text(self.file_details, self.display({"matching_recorded_digests": self.library.duplicates(self.scope),
                 "meaning": "Records with equal saved hashes. File availability and rights are independent. No records or files were merged or deleted."}))

    def forget_file(self):
        self.writable(); row = self.file_table.selected()
        if not row: raise ValueError("Select a file reference first.")
        if not self.review("Forget file reference", self.private_text(row["name"]) + "\n\nRemove only this catalog reference. No physical file will be deleted. An attached saved thumbnail is cleared when its preview reference is removed.", "Forget reference"):
            return
        self.library.forget(self.scope, "file", row["id"])
        self.refresh_sections(); self.status.set("Reference forgotten. File preserved.")

    def attach_preview(self):
        self.writable(); row = self.selected()
        from tkinter import filedialog
        token, scope, avatar = self.context(), self.scope, row["id"]
        path = filedialog.askopenfilename(parent=self.app.root, title="Attach your authorized 2D avatar preview", filetypes=(("Images", "*.png *.jpg *.jpeg *.webp *.gif"),))
        self.check_context(token)
        if not path: return
        def work(stop, progress):
            evidence = inspect_file(path, stop=stop, progress=progress, limit=IMAGE_LIMIT)
            thumbnail = local_preview(evidence, (220, 140), stop=stop)
            return evidence, base64.b64encode(thumbnail).decode("ascii")
        def done(result):
            evidence, thumbnail = result
            if not self.review("Attach 2D preview", f"Avatar: {avatar}\nSource: {evidence['path']}\n\nSave a metadata-free thumbnail and a reference to this local image. Only its first frame is used. This is an image—not a rendered avatar model.", "Attach preview"):
                return
            self.library.register_file(scope, avatar, evidence, role="preview", provenance="User-selected 2D preview")
            self.library.edit_local(scope, avatar, thumbnail=thumbnail)
            self.refresh(); self.status.set("2D preview attached. Enable Show saved thumbnails to display it in Cards.")
        self.start_task(work, done, avatar=avatar, operation="Prepare 2D preview")

    def open_preview(self):
        self.writable(); row = self.selected()
        if self.privacy.get(): raise ValueError("Previews are hidden by Privacy view.")
        previews = [r for r in self.library.records(self.scope, "file", row["id"]) if r["role"] == "preview"]
        if not previews:
            if row.get("thumbnail"):
                self.preview_window(base64.b64decode(row["thumbnail"]), row)
                return
            raise ValueError("Attach a local preview or explicitly load a remote thumbnail first.")
        self.start_task(lambda stop, progress: local_preview(previews[0], stop=stop), lambda data: self.preview_window(data, row),
                        avatar=row["id"], operation="Open bounded 2D preview")

    def preview_window(self, png, row):
        if self.privacy.get(): return
        window = self.tk.Toplevel(self.app.root)
        self.preview_windows.append(window)
        window.title("Avatar image preview — not a model renderer")
        window.geometry("960x780")
        self.ttk.Label(window_body(window), text=(row.get("name") or row["id"]) + "\nBounded 2D image / first frame. Zoom does not recover source-model detail.", wraplength=900).pack(anchor="w", padx=12, pady=10)
        actions = self.ttk.Frame(window_body(window)); actions.pack(fill="x", padx=12)
        body = self.ttk.Frame(window_body(window)); body.pack(fill="both", expand=True, padx=12, pady=12)
        canvas = self.tk.Canvas(body, highlightthickness=0)
        x = self.ttk.Scrollbar(body, orient="horizontal", command=canvas.xview)
        y = self.ttk.Scrollbar(body, orient="vertical", command=canvas.yview)
        x.pack(side="bottom", fill="x"); y.pack(side="right", fill="y"); canvas.pack(fill="both", expand=True)
        canvas.configure(xscrollcommand=x.set, yscrollcommand=y.set)
        scale = [1.]
        def draw(multiplier=None):
            from PIL import Image
            from io import BytesIO
            if multiplier is None: scale[0] = 1.
            else: scale[0] = max(.25, min(2., scale[0] * multiplier))
            with Image.open(BytesIO(png)) as source:
                dims = (max(1, int(source.width * scale[0])), max(1, int(source.height * scale[0])))
                output = BytesIO(); source.resize(dims, Image.Resampling.LANCZOS).save(output, "PNG")
            photo = self.tk.PhotoImage(master=window, data=base64.b64encode(output.getvalue()).decode("ascii"))
            window._preview_photo = photo
            canvas.delete("all"); canvas.create_image(0, 0, image=photo, anchor="nw")
            canvas.configure(scrollregion=(0, 0, *dims))
        self.ttk.Button(actions, text="Zoom out", command=lambda: draw(.8)).pack(side="left", padx=5)
        self.ttk.Button(actions, text="Reset zoom", command=lambda: draw()).pack(side="left", padx=5)
        self.ttk.Button(actions, text="Zoom in", command=lambda: draw(1.25)).pack(side="left", padx=5)
        def close():
            if window in self.preview_windows: self.preview_windows.remove(window)
            window.destroy()
        self.ttk.Button(actions, text="Close", command=close).pack(side="right")
        window.bind("<Escape>", lambda event: close()); window.protocol("WM_DELETE_WINDOW", close)
        draw()

    def remote_preview(self):
        self.writable(); row = self.selected()
        if self.privacy.get(): raise ValueError("Remote previews are hidden by Privacy view.")
        client = self.connected()
        url = self.remote_previews.get(row["id"])
        if not url: raise ValueError("Refresh this avatar's metadata or import its JSON in this session to obtain a supported image URL. URLs are not stored in the catalog.")
        scope, avatar = self.scope, row["id"]
        if not self.review("Load remote thumbnail", f"Account: {scope}\nAvatar: {avatar}\n\nExplicitly fetch through the existing restricted image provider, then save a metadata-free local thumbnail. No automatic image polling or other host login is used.", "Load thumbnail"):
            return
        from profile_images import fetch_preview
        def done(data):
            thumb = base64.b64encode(image_preview(data, (220, 140))).decode("ascii")
            self.library.edit_local(scope, avatar, thumbnail=thumb)
            self.preview_window(data, row); self.render()
            self.status.set("Remote 2D thumbnail loaded and saved to the initiating workspace.")
        self.start_task(lambda stop, progress: fetch_preview(client, url, stop=stop), done, avatar=avatar, operation="Load remote thumbnail")

    def inspect_shader_package(self):
        self.writable(); row = self.selected()
        from tkinter import filedialog
        token, scope, avatar = self.context(), self.scope, row["id"]
        path = filedialog.askopenfilename(parent=self.app.root, title="Inspect an authorized shader/package as data", filetypes=(("Packages and shaders", "*.zip *.unitypackage *.tgz *.tar *.gz *.shader *.shadergraph *.hlsl *.cginc *.compute"),))
        self.check_context(token)
        if not path: return
        def done(report):
            summary = {k: report[k] for k in ("name", "format", "size", "sha256", "entry_count", "shader_count", "material_count", "issues", "limitations")}
            if not self.review("Save read-only package inspection", json.dumps(summary, indent=2, ensure_ascii=False), "Save inspection"):
                return
            self.library.save_package(scope, avatar, report)
            self.refresh_sections(); set_text(self.package_details, self.display(report))
            self.status.set("Package report saved. No package was extracted, installed or executed.")
        self.start_task(lambda stop, progress: inspect_package(path, stop=stop, progress=progress), done, avatar=avatar, operation="Inspect shader package")

    def package_duplicates(self):
        set_text(self.package_details, self.display({"matching_recorded_package_digests": self.library.duplicates(self.scope, "package"),
                 "meaning": "Byte-identical package observations only. No automatic merging, deletion, licensing or compatibility conclusion."}))

    def forget_package(self):
        self.writable(); row = self.package_table.selected()
        if not row: raise ValueError("Select a package report first.")
        if self.review("Forget package report", "Remove only this inspection record. The package file remains untouched.", "Forget report"):
            self.library.forget(self.scope, "package", row["id"])
            self.refresh_sections(); set_text(self.package_details, "Report forgotten. Source file preserved.")

    def link_project(self):
        self.writable(); row = self.selected()
        if self.privacy.get(): raise ValueError("Project selection is hidden by Privacy view.")
        if row["id"].startswith("local:"):
            raise ValueError("The existing VCC association service accepts published avatar IDs. Local creator UUID links are not yet supported.")
        project = self.project_rows.get(self.project_choice.get())
        if not project: raise ValueError("Choose an existing Creator Projects catalog entry first.")
        if not self.review("Associate source project", f"Avatar: {row['id']}\nProject: {project['label']}\nWorkspace: {self.scope}\n\nThis is your local association, not proof that this project produced this avatar build. No project files will change.", "Save association"):
            return
        self.projects.link(project["id"], "" if self.scope == "local" else self.scope, "avatar", row["id"])
        self.refresh_sections(); self.status.set("Association saved using the existing VCC project catalog.")

    def open_projects(self):
        if self.privacy.get(): raise ValueError("Turn off Privacy view before opening the separate project workspace.")
        self.app.experience.open_tool("creator-projects")
        row = self.project_rows.get(self.project_choice.get())
        if row:
            page = self.app.sidebar.pages["Creator Projects"]
            page.selected_id = row["id"]; page.refresh()

    def export_selected(self):
        row = self.selected()
        if self.privacy.get(): raise ValueError("Turn off Privacy view to review which avatar details the export will contain.")
        document = self.library.export(self.scope, [row["id"]])
        payload = json.dumps(document, indent=2, ensure_ascii=False) + "\n"
        token = self.context()
        if not self.review("Review selected avatar report", payload, "Choose export file"):
            return
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.app.root, title="Save a new data-only report", initialfile="avatar-library-report.json", defaultextension=".json", confirmoverwrite=False)
        self.check_context(token)
        if path:
            from creator_projects import assert_no_links
            target = assert_no_links(Path(path))
            with target.open("x", encoding="utf-8") as output: output.write(payload)
            self.status.set("Selected report exported. It omits local paths, notes, thumbnails and provider URLs; names and avatar IDs remain.")

    def forget_avatar(self):
        self.writable(); row = self.selected()
        if not self.review("Forget avatar catalog records", self.private_text(row.get("name") or row["id"]) +
                           "\n\nRemove this workspace's catalog metadata, observed builds, local file references, thumbnails and package reports. Physical files and existing creator notes/projects remain. Task receipts remain reviewable. Other accounts are unchanged.", "Forget catalog records"):
            return
        self.library.forget(self.scope, "avatar", row["id"])
        self.selected_id = self.selected_build = ""; self.comparison = None
        self.remote_previews.pop(row["id"], None)
        self.refresh(); self.status.set("Catalog records forgotten. Files, other accounts and existing creator records preserved.")
