# Player-list design input — 1.18.6 implementation map

The user confirmed that both uploads are the same document. One unmodified copy
is appended below. SHA-256: `c90590f6e62fdd0c35b795dd34374dcec753b5d1783685c2cd4fa3df94f4f5ee`.

## Shipped in this release

| Blueprint areas | Implementation and practical scope |
| --- | --- |
| 1–9, 119–124, 183–194 | Central session model, normalized worker events, stable/provisional identity, explicit uncertainty, immutable cards and field precedence. The application's bounded worker/UI queue carries events; no per-row log parser. |
| 10–16, 76–94, 97–101, 109–118, 133–142 | Four layouts, mode-specific details, configurable columns, pins/search/filter/sort, recently left rows, stale/reconstructed states, source inspection, aliases and incremental 100-row pages. Provenance is available in details; hover tooltips are not implemented. |
| 17–26, 102–108, 143–149 | Serial bounded SQLite worker, encounters/rejoin segments, closed shared-time estimates, notes/tags, shared local favorites, optional world/avatar history, retention, per-user storage, incognito and category exports/deletion. No photo records or schema for future ecosystem services is fabricated. |
| 27–31, 45–54 | Reused friend snapshots and explicit relationship/role lookups with shared API throttling, account/instance checks and individual expiries. Permission-based group roles and staff-tag confirmation. Unknown and denied data stay unknown. |
| 32–44, 121–124, 141–142 | Observed avatar changes/counts, associated IDs, typed runtime load states, loading timeout, associated bridge performance and texture memory. RAM correlations have pre/post windows and multiple-candidate labels. Generic log failures are not attributed to a player; GPU/per-avatar allocation measurements are not supplied. Platform bundle availability remains in the existing Avatar tools. |
| 55–60, 65–75, 138–140 | Own moderation observations, local incident records, approved bridge voice/distance/selection/load/performance, reviewed local controls and client presets. New instance.context capability gates player attachment. Distance display prioritizes selected/pinned players; producer-side subscription scheduling is not added. No remote client/cheater/crasher detection. |
| 95–96 | Existing requested full-profile pictures retained; bounded account-scoped in-memory LRU added. Automatic row pictures are not added. |
| 125–128, 150–154, 161–172 | Optional friend/pin banners, manual VRCX companion suppression, session timeline, settings, feature health, card composition, aggregate diagnostics, isolated replay and deterministic stress/property-style tests. Current cards are a Python data interface, not a public network service. |

## Later phases from the blueprint

Sections 61–64, 127, 129–132, 155–160 and phase 180 describe cross-product or future
features: VRC Eye discovery badges/profiles, ready checks, shared bookmarks, Party,
Black Box integration, photo links, a Safety Center and dedicated player-list VR,
wrist and phone surfaces. These are not claimed as implemented. Existing paired
whispers and Wellness overlays are retained, with no automatic peer discovery.

The specification's suggested object/table names and example mature record are
reference architecture, not a promise that unavailable fields acquire values.
Rows use text labels and a maximum of three role labels plus overflow. Hover
cards, per-player anomaly heuristics and automatic avatar retry/hiding are not
implemented. Manual history exports are supported; importing other people's
encounter claims as verified observations is not implemented.

**PLAYER_LIST_SETUP.md** documents operation, current data sources and limitations.
**VALIDATION.md** records the tests and native-runtime checks that remain.

## Original specification (one byte-preserved copy)

Worked for 10s
Absolutely. Below is the “I regret asking for this much detail” edition of the VRC Eye Player List specification.

The biggest recommendation is this:

Do not implement the Player List as a UI widget that happens to parse VRChat logs.

Implement it as a persistent Player Session subsystem with a UI attached to it.

That distinction matters because eventually the same player data will feed:

desktop Player List,
SteamVR overlay,
Safety Center,
session timeline,
encounter history,
photo association,
incident reports,
VRC Eye-to-VRC Eye features,
Creator Mode,
Bridge Mode,
notifications,
Black Box,
diagnostics.
1. Overall Player List Philosophy
The Player List should answer four different questions:

Who is here right now?
Alice
Bob
Charlie
Dave
What is happening with them right now?
Alice       Avatar loading
Bob         🔊 Speaking
Charlie     Joined 30 sec ago
Dave        Avatar load failed
What does VRC Eye locally know about them?
Alice
Seen 8 times
Last seen Sep 22
Local note available
What actions can I take?
[ Profile ]
[ Note ]
[ Pin ]
[ Safety ]
[ Incident ]
Those four categories should remain separate internally.

2. Every Field Needs a Data Provenance
This should be one of the most important Player List rules.

Every piece of information should internally know where it came from.

I recommend these source types:

LOG
API
LOCAL
OSC
VRC_EYE
BRIDGE
DERIVED
UNKNOWN
Examples:

Field	Source
Player joined	LOG
Player left	LOG
Friend status	API
Encounter count	LOCAL
Local note	LOCAL
Speaking	BRIDGE
Avatar load failure	LOG
Avatar resource impact	DERIVED
VRC Eye user	VRC_EYE
Player distance	BRIDGE
Instance owner	API
World creator	API
Internally:

ObservedValue(
    value="Alice",
    source=Source.LOG,
    confidence=Confidence.HIGH,
    observed_at=timestamp
)

This will save you from accidentally presenting guesses as facts.

3. Confidence Levels
Some information will be certain.

Some won't.

Use:

AUTHORITATIVE
HIGH
MEDIUM
LOW
UNKNOWN
Example:

avatar_load_state = {
    "value": "failed",
    "source": "log",
    "confidence": "high"
}

Versus:

resource_impact = {
    "value": "high",
    "source": "derived",
    "confidence": "medium"
}

Never display:

Alice's avatar caused 620 MB VRAM usage.

when what actually happened was:

VRAM increased 620 MB shortly after Alice changed avatars.

Those are very different claims.

4. Player Identity Model
Do not use display name as the primary identity.

Ideally:

PlayerIdentity:
    user_id: str | None
    display_name: str

The stable key should be:

usr_xxxxxxxxx
when available.

Display names can change.

Your internal model should support:

PlayerIdentity(
    user_id="usr_123",
    display_name="Alice"
)

and temporarily:

PlayerIdentity(
    user_id=None,
    display_name="Alice"
)

until VRC Eye resolves the actual user ID.

5. Provisional Players
Sometimes VRC Eye may observe:

Alice joined
before it can resolve:

usr_7a8...
Create a provisional record.

TemporaryPlayer:
    provisional_id = "session-temp-17"
    display_name = "Alice"

Later:

session-temp-17
      ↓ merge
usr_7a8...
Do not create two separate players.

6. Player Session Object
This should represent one player's presence in one instance.

Something approximately like:

class PlayerSession:
    session_player_id
    user_id
    display_name

    joined_at
    left_at

    presence_state

    friend_state
    social_state

    avatar_state

    role_state

    safety_state

    bridge_state

    history_summary

    local_flags

    diagnostics

A particular person could have many PlayerSession records over time.

7. Presence State Machine
Do not just use:

online = True

Use an actual state machine.

Example:

UNKNOWN
  ↓
JOINING
  ↓
PRESENT
  ↓
LEAVING
  ↓
LEFT
Plus:

STALE
ERROR
RECONCILING
Full example:

UNKNOWN
   │ join event
   ▼
JOINING
   │ confirmed
   ▼
PRESENT
   │ leave event
   ▼
LEAVING
   │ finalized
   ▼
LEFT
If VRC Eye restarts:

PRESENT
   ↓
RECONCILING
until the roster can be reconstructed.

8. Current Instance Roster
Have a dedicated service:

PlayerRosterService
Responsibilities:

receive join events
receive leave events
track current instance
resolve players
handle duplicates
detect stale entries
publish roster changes
persist encounters
The UI should never directly modify roster state.

9. Event Bus
The Player subsystem should react to normalized events.

Example:

vrchat.instance.entered
vrchat.instance.left

player.joined
player.left
player.resolved

avatar.changed
avatar.load_started
avatar.load_finished
avatar.load_failed

friendship.updated

bridge.player_selected
bridge.voice_activity
bridge.distance_updated
Then:

VRChat Log Parser
       ↓
Normalized Event Bus
       ↓
PlayerRosterService
       ↓
UI / History / Safety / Black Box
10. Basic Player Row
The default row should stay readable.

Something like:

★ Alice                    Friend
  Joined 24m ago
  Avatar loaded
Not:

Alice | usr_128736 | FR | VRC | PC | 24m |
142MB | Very Poor | 3.83m | Muted=False |
Encounter=7 | ...
That belongs in details.

11. Compact Row
For small windows/overlay:

★ Alice              24m
Possible icons:

★ favorite
♥ friend
👑 owner
🛡 moderator
🌐 creator
⭐ staff
🔊 speaking
⚠ warning
📝 note
📌 pinned
👁 VRC Eye
Do not overload.

I would cap normal visible badges to perhaps 3–4.

12. Expanded Row
Optional:

Alice                           Friend
Joined 24m ago • Seen 8 times

Avatar: Example Avatar
● Loaded

📝 Note
Bridge Mode:

Alice                           🔊
Friend • 3.6m • Joined 24m ago

Avatar: Example Avatar
Performance: Very Poor
13. Player Detail Panel
Clicking a player opens the actual information.

Suggested tabs:

Overview
Session
Avatar
History
Safety
Notes
Advanced
Casual Mode might only show:

Overview
History
Notes
Advanced reveals everything.

14. Overview Panel
Example:

ALICE
───────────────────────────
Friend

Joined             24m ago
Seen               8 times
Last seen          Sep 24

Current avatar     Example Avatar
Avatar state       Loaded

Local note         Yes
Pinned             No

[ Profile ]
[ Note ]
[ Pin ]
[ Safety ]
15. Join Time
Store actual timestamp:

joined_at = datetime(...)

UI can present:

Joined 24m ago
Hover/detail:

Joined 8:42:17 PM
This is much better than storing only elapsed duration.

16. Time in Instance
Compute dynamically:

now - joined_at
Don't update the database every second.

UI timer:

24m
Internally:

joined_at
When leaving:

duration = left_at - joined_at

Persist then.

17. Encounter Count
Definition needs to be precise.

An encounter should mean:

VRC Eye confirmed this user shared an instance with the local user during a distinct session.

Avoid increasing encounter count because someone:

left
joined
left
joined
within 20 seconds due to log weirdness.

Use a debounce/merge window.

Example:

same user
same instance
rejoin within 60 sec
→ same encounter
Configurable internally.

18. First Encounter
Store:

first_seen_at
first_seen_world_id
Optional UI:

First seen
Jun 13, 2026
Maybe world name:

First encountered in:
Midnight Rooftop
But keep privacy retention configurable.

19. Last Encounter
Last seen:
Sep 24, 2026
Could optionally include:

Midnight Rooftop
Again, local-only.

20. Shared Time
Accumulated time:

total_shared_seconds

Update only when encounter closes.

Example:

Approx. time together
7h 42m
Use Approx. because logs/restarts can create gaps.

21. Shared Worlds
Optional history:

World A       6 encounters
World B       3 encounters
World C       1 encounter
This should probably be behind History rather than in the main row.

22. Encounter History
Example:

ENCOUNTERS

Sep 30
Midnight Rooftop
8:42 PM – 10:13 PM
1h 31m

Sep 22
The Great Pug
11:04 PM – 11:52 PM
48m
Allow:

Delete encounter
Delete all history for user
Disable future encounter storage
23. Local Notes
Simple but extremely useful.

Notes for Alice

Met during world testing.
Knows shader stuff.
Store locally.

Never sync unless explicitly requested.

Actions:

Edit
Delete
Export
24. Local Tags
User-defined:

Photographer
World Creator
Friend of Bob
Met at Convention
Tester
DJ
These should be entirely local.

Do not auto-assign potentially harmful labels like:

Annoying
Dangerous
Cheater
Users can write private notes themselves, but VRC Eye shouldn't algorithmically classify people socially.

25. Local Favorite
Independent of VRChat friendship/favorites.

Useful:

★
Could mean:

Keep this user easy to find in VRC Eye.

This is especially useful for:

creator
photographer
tester
event host
without requiring friendship.

26. Pinning
Different from favorite.

Favorite: persistent.

Pin: current-session only.

Example:

📌 Alice
Pinned users always appear at top.

Pin disappears when session ends unless user converts it to favorite.

27. Friend State
Possible internal states:

UNKNOWN
NOT_FRIEND
FRIEND
REQUEST_SENT
REQUEST_RECEIVED
Do not collapse all states into Boolean.

28. Relationship Badge
UI:

Alice             Friend
Bob               Request Pending
Charlie
Avoid cluttering non-friends with:

NOT FRIEND
Empty means normal.

29. VRChat User Profile Shortcut
Player menu:

View Profile
Could open the VRC Eye profile view populated from legitimate API data.

Do not require the Player List to constantly fetch every player's complete profile.

Use lazy loading.

30. Lazy Profile Fetching
Very important for API safety.

When 80 people join:

Bad:

80 users
→ 80 API profile requests immediately
Better:

Player List needs:
name + user_id + basic state
Then detailed API fetch only:

when row expanded
when role verification needed
when explicit user action occurs
Cache results.

31. API Cache
Example TTLs conceptually:

static-ish profile data        longer TTL
friend state                   shorter TTL
group roles                    medium TTL
world metadata                 medium TTL
instance metadata              short TTL
Centralize this in an API cache service.

Player List should request:

get_user_profile(user_id)

not call VRChat directly.

32. Avatar State
Use a dedicated object.

AvatarState:
    avatar_id
    avatar_name
    changed_at

    load_state

    error_type
    error_message

    observed_resource_effect

    bridge_metrics

33. Avatar Load State Machine
Example:

UNKNOWN
↓
CHANGED
↓
LOADING
↓
READY
Failure branches:

LOADING
├─ DOWNLOAD_FAILED
├─ BUNDLE_FAILED
├─ SECURITY_FAILED
├─ LOAD_FAILED
└─ UNKNOWN_FAILURE
Do not simply use:

CORRUPT
for every error.

34. Avatar Change Indicator
If recently changed:

Alice
↻ Avatar changed 8 sec ago
Fade the indicator after perhaps:

30–60 sec
but keep change count in Session details.

35. Avatar Change Count
Per player per session:

Avatar changes: 3
Potentially useful for:

troubleshooting,
resource correlation,
session timeline.
36. Avatar Name
Only display if VRC Eye legitimately knows it.

Otherwise:

Avatar
Loaded
rather than:

Avatar: Unknown_Extracted_Value
37. Avatar ID
Advanced details only:

avtr_xxxxx
Actions:

Copy avatar ID
Only if legitimately observed/resolved.

38. Avatar Platform Availability
If legitimate metadata exists:

PC           ✓
Android      ✓
iOS          —
Keep it out of compact Player List.

39. Avatar Performance Rank
If authoritative:

Excellent
Good
Medium
Poor
Very Poor
Add source internally:

source=BRIDGE
or other legitimate source.

If unavailable:

Unavailable
Do not estimate rank purely from local VRAM change.

40. Texture Memory
If legitimately provided:

Texture Memory
146 MB
Label specifically Texture Memory.

Do not label:

VRAM = 146 MB
because that isn't necessarily total GPU allocation.

41. Observed Resource Impact
Stock VRC Eye can still derive something useful.

Possible levels:

Unknown
Low
Moderate
High
Severe
Inputs could include:

VRAM change
RAM change
frame degradation
avatar load timing
number of simultaneous avatar loads
world loading state
42. Resource Correlation Window
Example:

avatar load observed at T
measure:

T - 2 sec
to
T + 10 sec
But if:

5 avatars load simultaneously
confidence becomes LOW.

If:

only Alice changed avatar
world otherwise stable
VRAM jumps +700 MB
confidence becomes higher.

43. Resource Observation Object
Something like:

ResourceObservation:
    start_time
    end_time

    ram_delta
    vram_delta

    cpu_delta
    gpu_delta

    simultaneous_avatar_loads

    confidence

    attribution_user_id | None

UI:

Observed resource increase
VRAM +620 MB
Confidence: Medium
44. Avatar Warning Icon
Only use when there is meaningful local impact:

⚠
Hover:

High resource impact observed after this avatar loaded.
Not:

Dangerous avatar.
45. Roles System
Create a dedicated:

PlayerRoles

Possible flags:

WORLD_CREATOR
INSTANCE_OWNER
INSTANCE_MASTER
GROUP_OWNER
GROUP_ADMIN
GROUP_MODERATOR
VRCHAT_STAFF
VRC_EYE_USER
These are independent.

A player can have multiple.

46. World Creator
Compare:

world.authorId
against:

player.user_id
Display:

🌐 World Creator
This means:

This account is the creator/author associated with the world metadata.

Not:

This person currently moderates this instance.

47. Instance Owner
Separate badge:

👑 Instance Owner
This means:

Owner/creator of this instance where VRChat exposes it.

Important distinction from World Creator.

48. Networking Master
If ever exposed by a trusted source:

Network Master
Do not use moderator icon.

They are not equivalent.

Possible advanced-only badge:

⚙ Network Master
49. Group Moderator
For group instances:

Determine:

instance group
player group membership
player role IDs
role permissions
Do not infer moderator status from role name.

Bad:

role name = "Ultimate Admin"
→ moderator
Good:

role permissions contain moderation capability
→ Group Moderator
50. Group Owner
Separate:

👑 Group Owner
Maybe visually distinguish from instance owner:

👑 Group Owner
🏠 Instance Owner
Avoid icon ambiguity.

51. VRChat Staff
Only display when VRChat-provided/account data explicitly identifies the account appropriately.

⭐ VRChat Staff
No badge if unknown.

Never infer from:

username
trust color
behavior
group membership
52. Staff Badge Security
Do not let users assign a local tag using the official Staff visual style.

Custom local tag:

[STAFF]
should look different from official:

⭐ VRChat Staff
Otherwise people could confuse a local note with actual authority.

53. Instance Authority Panel
Separate summary above/beside Player List:

INSTANCE AUTHORITY
────────────────────────
World Creator      Alice
Instance Owner     Bob
Group              Example Group

Moderators Present
Charlie
Dave
This is especially useful for safety.

54. Role Sorting
Optional sort:

Authority first
Ordering perhaps:

VRChat Staff
Instance Owner
Group Staff
World Creator
Friends
Others
But do not use that as default unless user asks.

Default should probably remain:

Friends / recent / alphabetical
55. Your Moderation State Toward Player
Useful and legitimate.

Object:

LocalModerationState:
    blocked
    muted
    chat_muted
    avatar_hidden
    interactions_disabled

Display:

YOUR SAFETY SETTINGS

Voice          Muted
Avatar         Hidden
Chatbox        Allowed
Interaction    Disabled
56. “They Muted/Blocked You”
Default behavior:

do not claim it
Unless you someday receive an authoritative and appropriate source.

Do not infer from disappearance.

If weird state occurs:

Player no longer locally visible.
Cause not confirmed.
57. Safety Status
Each player can have a local safety status object:

PlayerSafetyState:
    avatar_warning
    audio_warning
    resource_warning
    incident_count_current_session
    local_moderation

Main row should not show every field.

Maybe:

⚠
when something currently needs attention.

58. Incident Bookmark
Action:

[ Save Incident ]
Creates:

timestamp
player user_id
world
instance
recent player events
recent avatar events
recent resource metrics
recent audio events
user note
This is not:

Report player automatically.
It is a local timestamped record.

59. Incident History
Player detail:

Local incidents
2
Click:

Sep 30 — Audio/resource event
Sep 18 — User-created note
Do not create an automatic “danger score.”

60. Activity Anomaly Indicator
If VRC Eye sees something strange:

⚠ Unusual activity observed
Possible reasons:

unusual movement telemetry
repeated avatar failures
unexpected resource spike
runtime anomalies
Never:

CHEATER
unless you have an actual authoritative moderation result, which VRC Eye generally won't.

61. VRC Eye User Badge
If another user has explicitly opted into VRC Eye discoverability:

👁 VRC Eye
Clicking might show:

VRC Eye profile
VRC Eye version compatibility
shared capabilities
DND status
Only data they chose to share.

62. VRC Eye Profile Information
Optional:

Pronouns
Profile status
Favorite color
Creator badge
Streamer status
Sensitive profile fields should:

never be inferred
never be mandatory
have visibility controls
63. VRC Eye Link Status
For another VRC Eye user:

Connected
Same instance
Capabilities available
Example:

VRC EYE LINK

Connection       Online
Same instance    Yes
Ready checks     Supported
Shared bookmark  Supported
Diagnostics      Allowed
64. VRC Eye-to-VRC Eye Actions
Possible player menu:

Whisper
Send world
Send bookmark
Ready check
Photo countdown
Share diagnostic card
Only show enabled actions based on mutual capability/permission.

65. Bridge Mode Player Enhancements
This should be an additive layer.

Normal:

Alice
Friend • Joined 15m
Bridge:

Alice                         🔊
Friend • 3.4m • Joined 15m
66. Bridge Capability Object
Per bridge:

BridgeCapabilities:
    player_selection
    voice_activity
    distance
    avatar_load_state
    avatar_performance
    avatar_safety_controls
    interaction_state
    runtime_summary

UI checks capability.

Not client name.

Bad:

if client_name == "FooClient":

Good:

if bridge.supports("player.voice_activity"):

67. Speaking Indicator
Bridge-only unless an authoritative external source appears.

State:

SILENT
SPEAKING
UNKNOWN
Potential visual:

🔊 Alice
Use timeout smoothing.

Example:

voice event true
→ speaking

voice false
→ wait 200 ms
→ silent
This prevents flickering.

68. Voice Activity History
Probably do not persist long term.

Current-session only at most.

No need to store:

Alice spoke for 3h17m
unless a very specific user request exists.

That's unnecessarily invasive.

69. Player Distance
Bridge:

3.7 m
Update frequency should be controlled.

Do not request/update at headset frame rate.

Maybe:

2–5 updates/sec
for selected/pinned users.

Slower:

1 update/sec
for everybody else.

70. Distance Categories
For compact UI:

Nearby
Mid
Far
instead of exact meter count.

Could be better for performance.

71. Selected-Player Synchronization
Bridge event:

player.selected usr_123
VRC Eye:

highlight Alice
optionally open detail panel
Settings:

☑ Follow VRChat selection
☐ Automatically open details
☑ Scroll selected player into view
72. Safety Controls via Bridge
Only if explicitly supported.

Example:

[ Mute Locally ]
[ Hide Avatar ]
[ Disable Avatar Audio ]
[ Reduce Effects ]
[ Pause Interaction ]
VRC Eye sends structured command to bridge.

Not arbitrary:

execute_memory_function(...)
73. Bridge Safety Presets
Example:

Normal
Reduced
Minimal
Hidden
Bridge defines exact mapping.

VRC Eye UI should show capability details if Advanced Mode:

Reduced:
✓ Disable avatar audio
✓ Reduce effects
✗ Hide avatar
74. Bridge Disconnect Behavior
If bridge disappears:

voice indicators → unknown
distance → unavailable
bridge controls → hidden/disabled
Do not keep stale values pretending they are live.

Maybe row tooltip:

Bridge disconnected 12 sec ago.
75. Stale Data Handling
Every transient field needs a TTL.

Example:

voice activity       1 sec
distance             3 sec
load state           event-driven
friend status        minutes
profile metadata     hours
roles                instance lifetime
When stale:

unknown
not old value forever.

76. Player Sorting
Support:

Alphabetical
Join order
Recently joined
Longest present
Friends first
Pinned first
Authority
Encounter count
Recent avatar issue
Resource warning
Custom sort stack could eventually be:

1. Pinned
2. Friends
3. Join time
4. Alphabetical
77. Default Sort
I would probably use:

Pinned
Friends
Everyone else alphabetically
or simply:

Join order
Let user choose.

78. Filtering
Useful filters:

Everyone
Friends
Non-friends
Pinned
Has notes
VRC Eye users
Recently joined
Avatar issue
Resource warning
World/instance authority
Group staff
VRChat staff
Bridge telemetry available
79. Search
Search should match:

display name
previous locally known names
local tags
local notes optionally
user ID
Advanced search:

id:usr_
tag:photographer
friend:true
note:true
role:moderator
Maybe later.

80. Search Privacy
Searching notes can reveal note text in autocomplete.

Setting:

Search local notes
On / Off
In Presentation Mode:

notes excluded automatically
81. Recently Joined Highlight
When player joins:

Alice
NEW
Fade:

30 sec
Configurable.

82. Recently Left Section
Very useful.

Instead of instantly disappearing:

Recently Left
────────────
Alice        20 sec ago
Bob          1m ago
Retention maybe:

2–5 minutes
Then remove from active UI.

History persists separately.

83. Leave Reason
Usually:

Left instance
Do not guess:

blocked you
crashed
kicked
banned
unless actually known.

84. World Change
When the local user changes worlds:

close all current PlayerSession records
archive them
clear current roster
start new InstanceSession
Do not let previous-world players leak into the new list.

85. Log Rotation
VRChat logs can rotate/start a new file.

Your log watcher should handle:

old file ends
new file appears
without resetting VRC Eye session unnecessarily.

86. VRC Eye Restart Mid-Session
Important.

If VRC Eye closes/reopens while VRChat remains active:

VRC Eye starts
↓
detect VRChat running
↓
find current log
↓
reconstruct current instance
↓
replay relevant join/leave events
↓
rebuild roster
Mark:

reconstructed = True
in diagnostics.

87. Duplicate Join Events
Create event deduplication.

Key:

event type
user
timestamp window
instance
Example:

Alice joined
Alice joined
within 500 ms:

one event
88. Missing Leave Events
Could happen.

When world changes:

everyone remaining
→ force-close session with reason INSTANCE_ENDED
Do not leave them marked PRESENT forever.

89. Connection Drop / Log Gap
If VRC Eye misses log data:

Roster confidence degraded.
Could internally set:

roster_state = DEGRADED
Advanced UI:

⚠ Player list may be incomplete.
Casual:

small warning icon.

90. Player List Health Indicator
Top of panel:

Players 42
● Live
Other states:

◐ Rebuilding
⚠ Partial
○ Offline
Very useful for debugging.

91. Source Inspector
Advanced mode/debug:

Right-click field:

Avatar load state
Source: VRChat Log
Observed: 8:42:17 PM
Confidence: High
Developer Mode:

Raw event:
avatar.load_failed(...)
This would be amazing for debugging.

92. Provenance Tooltip
For derived features:

High observed resource impact

Based on:
• +720 MB VRAM
• +1.1 GB process RAM
• one avatar load observed
• stable world state

Confidence: Medium
This greatly increases trust.

93. Player Row Context Menu
Suggested:

View Profile
Open Details
────────────────
Pin
Favorite in VRC Eye
Add Note
Add Tag
────────────────
Safety
Save Incident
────────────────
Copy User ID
Copy Display Name
────────────────
VRC Eye
Whisper
Share World
Only show actions actually available.

94. Copy User ID
Simple:

Copy usr_...
Useful for developers/creators.

If user ID unresolved:

disabled
with tooltip:

User ID not yet resolved.
95. Profile Picture
Potentially show avatar/user image in detail panel.

Avoid loading 80 full-resolution images at once.

Use:

thumbnail lazy load
image cache
memory cap
96. Thumbnail Cache
Need LRU cache.

Example:

max thumbnails: 200
max memory: configurable
Decode thumbnails off UI thread.

97. UI Virtualization
Very important for 80-player instances.

Do not render 80 complex row trees continuously if UI framework struggles.

Use:

virtualized list
Only render rows currently visible.

98. Update Coalescing
Bridge distance + voice events could be frequent.

Don't redraw whole list every event.

Instead:

incoming events
↓
state updates
↓
UI refresh batch every 100–250 ms
Specific live indicators can update separately.

99. Thread Safety
Likely services:

Log Reader Thread
API Worker
Bridge Listener
Resource Monitor
Database Worker
UI Thread
Never mutate UI from worker threads.

Use event queue:

worker
→ event bus
→ state store
→ UI notification
100. Central Player Store
I strongly recommend:

PlayerStore
which is the source of truth.

PlayerStore:
    current_instance
    current_players
    recently_left
    cached_profiles

UI reads snapshots.

No UI component owns player state.

101. Immutable Snapshots
For fewer bugs:

PlayerViewModel

could be an immutable snapshot generated from PlayerStore.

Example:

@dataclass(frozen=True)
class PlayerRowView:
    user_id: str
    name: str
    friend: bool
    joined_seconds: int
    badges: tuple
    warning: Optional[str]

UI gets updated snapshots.

102. Database Separation
Separate:

live state
from:

persistent history
Live:

in memory
Persistent:

SQLite
Don't write every speaking/distance update to DB.

103. Suggested Database Tables
Something like:

users
encounters
user_notes
user_tags
user_favorites
avatar_observations
incidents
worlds
instance_sessions
Potential schema:

users
-----
user_id PRIMARY KEY
last_display_name
first_seen_at
last_seen_at
encounter_count
total_shared_seconds
104. Encounter Table
encounters
----------
id
user_id
instance_session_id
joined_at
left_at
duration_seconds
world_id
105. Display Name History
Optional:

user_name_history
-----------------
user_id
display_name
first_observed
last_observed
Useful:

Alice
Previously observed as AliciaVR
This should be local-history functionality, not identity accusations.

106. Avatar Observation History
Privacy-sensitive.

Optional:

avatar_observations
-------------------
user_id
avatar_id
avatar_name
observed_at
Retention control.

Could be completely disabled by default depending desired privacy stance.

107. History Retention
Settings:

Encounter history
○ Session only
○ 7 days
● 30 days
○ 90 days
○ Forever
Potential separate setting:

Avatar history
Off
Give users control.

108. Delete User History
Player detail:

Privacy & Data

[ Delete encounter history ]
[ Delete avatar history ]
[ Delete local notes ]
[ Delete all local data for this user ]
Confirmation.

109. Presentation Mode
When streaming/screensharing:

Player List can automatically hide:

user IDs
notes
private tags
instance IDs
incident notes
VRC Eye private statuses
Names can optionally be:

Alice → Player 1
Bob   → Player 2
for maximum privacy.

110. Streamer Safe Player List
Preset:

Streamer Mode

Display names           Optional
User IDs                Hidden
Notes                   Hidden
Tags                    Hidden
Whispers                Hidden
Private instance info   Hidden
111. Accessibility
Player List needs:

keyboard navigation,
scalable row height,
screen-reader labels,
high contrast,
no color-only roles/status,
reduced animation,
readable focus state.
Example screen reader:

Alice, friend, joined 24 minutes ago,
avatar loaded, local note available.
Not:

star icon, green dot, triangle.
112. Color Rules
Never:

green = friend
red = warning
without accompanying icons/text.

Use:

♥ Friend
⚠ Warning
with colors as supplementary.

113. Player List Layout Modes
Could have:

Compact
Alice                 24m
Bob                    5m
Standard
Alice        Friend
Joined 24m ago
Detailed
Alice        Friend        🌐 Creator
Joined 24m • Seen 8 times
Avatar loaded • Note
Overlay
Minimal.

114. Columns Mode
Advanced users might prefer table:

Name | Relation | Joined | Avatar | Role | Status
Good for desktop.

Not great for VR.

115. Custom Columns
Eventually:

☑ Name
☑ Friend
☑ Joined
☐ Seen count
☑ Avatar status
☐ Resource impact
☑ Role
Persist per UI profile.

116. Casual Mode
Only show:

Name
Friend
Join time
Basic avatar state
Important role
Important warning
Details on click.

117. Advanced Mode
May show:

IDs
history
resource observations
source/confidence
bridge data
API fields
role breakdown
118. Developer Mode
Adds:

raw event state
timestamps
source provenance
cache age
resolver status
bridge payload summary
database record IDs
This will be extremely useful while developing.

119. Player Resolver
Dedicated service:

PlayerIdentityResolver
Input:

display name
user ID if known
session event
API hints
Output:

stable identity
Avoid resolver calls scattered across UI.

120. Resolver Conflict
If two users somehow share conflicting observed information:

DO NOT merge automatically
Create conflict:

identity_conflict=True
Advanced diagnostics:

Could not safely resolve player identity.
121. Current Avatar Resolver
Same idea:

AvatarResolver
Can combine:

log event
API data
bridge data
local avatar config
Higher-authority source wins.

122. Field Precedence
Define it centrally.

Example:

For avatar load state:

BRIDGE authoritative runtime state
> explicit LOG failure
> derived timing
For friend status:

fresh API
> cached API
> unknown
Do not make precedence ad hoc.

123. Role Precedence
Roles aren't exclusive.

Keep list:

roles = {
    world_creator=True,
    instance_owner=True,
    group_moderator=False
}
Do not store:

role = "world_creator"
because a person might be several things.

124. Badge Priority
Display max 3.

Example priority:

VRChat Staff
Instance Owner
Group Moderator
World Creator
VRC Eye User
Friend
But Friend may be text rather than badge.

Overflow:

+2
click opens all roles.

125. Notification Integration
Player events can produce notifications.

Examples:

Friend joined
Pinned user joined
Instance owner joined
VRC Eye user connected
But don't automatically notify on every stranger.

126. Notification Rules
Potential:

Notify when:
☑ Friend joins instance
☐ Any user joins
☑ Pinned VRC Eye user joins
☐ Avatar changes
Keep separate from Player List itself.

127. Black Box Integration
Player events should automatically enter Black Box timeline:

22:14:11 Alice joined
22:14:18 Bob avatar changed
22:14:21 VRAM +900 MB
No need to store full profiles.

128. Session Timeline Integration
Player List generates timeline events:

Alice joined
Alice changed avatar
Alice left
Click timeline event:

open Alice's session detail
129. Photo Integration
When screenshot created:

Store:

timestamp
world
current session ID
current player IDs
Then later:

Players present when photo was taken:
Alice
Bob
Charlie
Important wording:

Present when photo was taken

not:

Appears in photo.

130. Creator Mode Integration
World creator testing could add:

late joiner
joined during test
avatar load issue
Creator Player List might include debugging views:

Join order
Time since instance start
Known playtest tag
Still don't expose arbitrary private runtime info.

131. Group Instance View
Could group players:

Instance Staff
Friends
Others
or:

Group members
Non-members
only where that data is legitimately available.

132. Safety Center Integration
Click:

Safety
opens:

YOUR SETTINGS FOR ALICE
Voice
Avatar
Interactions
Incidents
Observed resource warnings
Bridge adds additional local controls.

133. “Status” Column
This is one of the best compact abstractions.

Possible:

Normal
Recently joined
Avatar loading
Avatar error
Resource warning
Speaking
Left recently
Only one primary status visible.

Detailed state remains underneath.

134. Status Priority
Example:

CRITICAL SAFETY
>
AVATAR ERROR
>
RESOURCE WARNING
>
LOADING
>
SPEAKING
>
RECENTLY JOINED
>
NORMAL
This avoids contradictory badges.

135. Primary vs Secondary Status
Internal:

primary_status
secondary_flags
Example:

primary = AVATAR_ERROR
secondary = {FRIEND, NOTE, SPEAKING}
136. Tooltips
Every unusual badge should explain itself.

Example:

⚠ Resource warning
Tooltip:

VRC Eye observed a large resource increase shortly after this avatar loaded. This does not prove the avatar caused it.

This wording is important.

137. No Hidden Accusations
Never use labels like:

Crasher
Client User
Cheater
Dangerous
Troll
based on inference.

If user manually creates a private note, that's their own data.

VRC Eye itself stays descriptive.

138. Modified Client Detection — Local Only
If VRC Eye detects a local user's own compatible client:

Bridge connected
That should not imply remote users' client status.

Never:

Alice is using a client
unless there is a legitimate explicit VRC Eye/bridge signal from Alice herself, and even then label it appropriately.

139. Player List Performance Budget
Target:

80 users
multiple events/sec
minimal UI lag
Do not fetch/update everything at high frequency.

Recommended tiers:

Tier 1: Always live
presence
join time
critical warning
Tier 2: Low-frequency
friend state
role state
Tier 3: On demand
profile
history
full avatar metadata
Tier 4: Selected/pinned only
bridge distance
detailed runtime metrics
140. Prioritized Bridge Updates
For 80 players:

Bad:

distance 60 FPS × 80
Good:

selected player       5 Hz
pinned players         2 Hz
visible rows           1 Hz
others                 optional/no updates
Voice events should be event-driven.

141. Debounce Avatar Changes
A client may generate noisy transitions.

Use:

avatar_changed
↓
wait brief stabilization window
↓
publish stable state
But immediate UI:

Changing avatar...
then:

Loaded
142. Loading Timeout
If state remains:

LOADING
too long:

LOAD_STALLED
But don't immediately call it failure.

Example:

Avatar taking unusually long to load.
143. Database Write Queue
Never write every event synchronously from UI.

Use:

event
↓
persistent write queue
↓
SQLite worker
Batch:

encounter updates
history updates
avatar observations
144. Database Crash Recovery
Transactions.

If PC crashes:

open encounter with left_at=NULL
Next startup:

mark ended unexpectedly
Do not invent exact leave time.

Maybe:

left_at = last_blackbox_sample
leave_reason = CRASH_RECOVERY
with flag:

estimated=True
145. User Deletion Cascade
If:

Delete all local data for Alice
decide explicitly whether to delete:

encounters
notes
tags
favorites
avatar history
incidents
photo associations
Maybe show checklist.

146. Favorite Should Survive History Deletion
Potential UX question:

If user says:

Clear encounter history
don't necessarily delete:

favorite
note
tag
Different data categories.

147. Import/Export
Potential export:

{
  "user_id": "usr_...",
  "note": "...",
  "tags": ["Photographer"],
  "favorite": true
}

Do not include detailed encounter history unless explicitly selected.

148. Player List Privacy Modes
Maybe:

Standard
Local-history off
Streamer
Guest
Local-history off:

current roster works
no encounters persisted
149. Incognito Session
Useful:

Do not save this session.
Player List still works live.

At session end:

discard encounter history
except maybe critical diagnostic data if Black Box separate.

150. Player List Settings Page
Potential layout:

PLAYER LIST

Display
[ Compact / Standard / Detailed ]

Sorting
Friends first                  ✓
Pinned first                   ✓

Show
Join time                      ✓
Encounter count                ✓
Avatar state                   ✓
Roles                          ✓
Local notes icon               ✓

History
Store encounters               ✓
Retention                      30 days
Store avatar history           Off

Recently Left
Keep visible                   3 min

Bridge
Speaking indicators            ✓
Distance                       Selected only
Follow VRChat selection        ✓
151. Casual Settings
Simplify:

Player List
☑ Show friends first
☑ Show join times
☑ Remember people I've encountered
Everything else under:

Advanced
152. Advanced Settings
Expose:

reconciliation
retention
provenance
resource correlation
bridge update rate
history categories
153. Diagnostic Settings
Developer only perhaps:

Show unresolved identities
Show raw user IDs
Show event timestamps
Show source/confidence
Log roster transitions
154. Player Card API
Architecturally, define one view object:

PlayerCardData:
    identity
    relationship
    presence
    roles
    avatar
    history
    safety
    bridge

Desktop, overlay, phone UI all consume same structure.

155. Overlay Player List
Do not simply shrink desktop table.

Overlay should have:

Players 42

★ Alice       🔊
♥ Bob
  Charlie     ⚠
Selecting opens:

Alice
Friend
Joined 24m

[ Safety ]
[ Pin ]
[ Note ]
Large targets.

156. Wrist Player List
Even simpler:

Friends
3 nearby

Alice 🔊
Bob
Charlie
Maybe pages of 5.

Avoid scrolling 80-person list on wrist.

157. Phone Remote
Same Player Store can serve local web UI.

Potential:

current roster
notes
pins
history
Sensitive actions require device authorization.

158. Player List Notifications in Overlay
Example:

Alice joined
Friend
Click opens Alice card.

Could disappear after:

5 sec
159. User Presence Across World Change
If Alice leaves old world then is present in new world:

Create:

new encounter
unless you're intentionally modeling travel party continuity separately.

160. Party Concept
Optional local grouping:

My Session Group
Alice
Bob
Charlie
Could power:

pin group
photo group
ready checks
Not necessarily VRChat party data.

161. Friend Join Notification Deduplication with VRCX
If Companion Mode:

VRCX owns social notifications
Player List still updates.

VRC Eye does not duplicate popup.

This is separate from roster state.

162. API Failure
If VRChat API unavailable:

Player List continues from logs/local state.

Fields dependent on API become:

Unavailable
Do not kill the whole Player List.

163. Bridge Failure
Same philosophy.

Bridge unavailable
Stock fields continue.

164. Database Failure
Worst case:

Live Player List works
History disabled
Display:

⚠ Local history database unavailable.
Do not crash the list.

165. Log Failure
If output log unavailable:

Player list cannot update reliably.
But existing roster remains with:

STALE
Do not pretend current.

166. Feature Health
Player subsystem health:

Roster         Live
Identity       Healthy
History        Healthy
API enrichment Partial
Bridge         Disconnected
Feed into overall VRC Eye Feature Health Matrix.

167. Testing Strategy
You should build a fake roster simulator before advanced features.

Commands:

join Alice
join Bob
leave Alice
avatar Bob loading
avatar Bob failed
bridge Bob speaking
role Alice moderator
This lets you test Player List without launching VRChat.

168. Replay Testing
Feed recorded event sequence:

00:00 world join
00:02 Alice join
00:03 Bob join
00:08 Alice avatar change
00:10 VRAM spike
00:20 Bob leave
Verify final roster automatically.

169. Unit Tests
Examples:

duplicate join does not duplicate player
leave closes encounter
world change closes all players
rejoin after short gap follows policy
bridge disconnect clears speaking
API failure does not remove roster
history disabled performs no encounter writes
170. Property Tests
For event sequence:

join
leave
join
world_change
crash
restart
Ensure invariant:

a user cannot have two active sessions
in the same instance unless explicitly supported
171. Stress Test
Generate:

80 players
200 avatar events
1000 bridge voice events
constant resource telemetry
Target:

UI remains responsive
no duplicate rows
memory stable
database queue bounded
172. Player List Debug Console
Developer Mode:

PLAYER STORE DEBUG

Active      42
Provisional 2
RecentlyLeft 4

Events/s    8.3
UI updates  4/s
DB queue    3

[ Dump state ]
[ Simulate join ]
[ Simulate leave ]
[ Reconcile ]
This will be incredibly useful.

173. Recommended Implementation Order
Since you're doing one feature at a time, I would implement Player List in this exact progression.

Phase 1 — Core roster
Detect current instance.
Parse player joins.
Parse player leaves.
Build in-memory PlayerStore.
Basic UI rows.
Join time.
Recently left.
World-change cleanup.
At this point:

Players
Alice
Bob
Charlie
works reliably.

174. Phase 2 — Identity
Resolve stable user IDs.
Add provisional-player merge.
Copy user ID.
Basic profile lookup.
Friend state.
175. Phase 3 — Local history
SQLite database.
Encounter records.
Seen count.
Last seen.
Shared duration.
Notes.
Tags.
Favorites.
Pins.
176. Phase 4 — Avatar state
Avatar-change detection.
Avatar load state.
Avatar error classification.
Avatar change count.
Avatar detail panel.
Optional avatar history.
177. Phase 5 — Roles
World Creator.
Instance Owner.
Group membership.
Group moderator/admin detection.
VRChat Staff where explicitly exposed.
Instance Authority panel.
178. Phase 6 — Safety
My moderation state.
Avatar warning.
Resource correlation.
Incident bookmark.
Incident history.
Safety detail tab.
179. Phase 7 — UX
Search.
Filters.
Sorting.
Compact/Standard/Detailed.
Custom columns.
Accessibility.
Presentation Mode.
180. Phase 8 — VRC Eye ecosystem
VRC Eye user badge.
VRC Eye profile.
Link capability display.
Whispers.
Shared bookmarks.
Ready checks.
181. Phase 9 — Bridge
Bridge connection status.
Capability negotiation.
Selected-player synchronization.
Speaking indicators.
Distance.
Avatar performance.
Precise avatar load state.
Bridge safety actions.
Safety presets.
This ordering means Bridge Mode never becomes a prerequisite for the normal Player List.

182. Phase 10 — Advanced diagnostics
Source/confidence display.
Raw event inspector.
PlayerStore debugger.
Event replay.
Stress testing.
Black Box correlation.
183. Minimum Player Record
At the very beginning:

Player:
    user_id
    display_name
    joined_at

Do not start by creating a 100-field monster.

184. Mature Player Record
Eventually conceptually:

PlayerRecord:
    identity

    current_session
    social

    roles

    avatar

    local_history

    local_metadata

    safety

    vrc_eye_peer

    bridge

    diagnostics

Composition is better than one gigantic class.

185. Recommended Object Breakdown
Something like:

Player
├── Identity
├── Presence
├── Relationship
├── Roles
├── AvatarState
├── HistorySummary
├── LocalMetadata
├── SafetyState
├── PeerState
├── BridgeState
└── DiagnosticsState
This is much easier to maintain.

186. Example Mature State
Conceptually:

PlayerState(
    identity=Identity(
        user_id="usr_123",
        display_name="Alice"
    ),

    presence=Presence(
        state="present",
        joined_at="20:42:17"
    ),

    relationship=Relationship(
        friend=True
    ),

    roles=Roles(
        world_creator=False,
        instance_owner=False,
        group_moderator=True
    ),

    avatar=AvatarState(
        name="Example Avatar",
        state="ready",
        resource_warning="moderate"
    ),

    history=History(
        encounters=8,
        total_time=27840
    ),

    local=LocalMetadata(
        pinned=True,
        favorite=False,
        note_exists=True
    ),

    bridge=BridgeState(
        available=True,
        speaking=True,
        distance=3.7
    )
)

187. Example Final Row Generation
The UI layer converts that into:

📌 Alice                         🔊
Friend • Group Moderator
Joined 24m • Seen 8 times
Avatar loaded • ⚠ Moderate resource impact
📝 Note
Casual Mode converts same state into:

Alice                  Friend
Joined 24m ago
Overlay:

📌 Alice 🔊
Same data.

Different presentation.

188. Golden Rule: Never Let UI Infer Facts
Bad:

if player.row_is_red:
    dangerous = True

Good:

if player.safety.resource_warning == HIGH:
    row.show_warning()

The model determines facts.

UI only displays them.

189. Golden Rule: Never Let One Source Own Everything
Logs may fail.

API may fail.

Bridge may disappear.

Local DB may corrupt.

Therefore:

Player List
must degrade gracefully.

Example:

Logs working
API offline
Bridge disconnected

→ roster still works
→ history still works
→ friend enrichment temporarily unavailable
190. Golden Rule: Treat Unknown as Unknown
Do not convert:

unknown
into:

false
Examples:

is_friend = UNKNOWN
is_staff = UNKNOWN
avatar_loaded = UNKNOWN
bridge_speaking = UNKNOWN
This prevents a huge number of misleading UI states.

191. Golden Rule: Temporary Data vs Persistent Data
Temporary:

speaking
distance
loading
selected
Persistent:

notes
tags
favorite
encounter history
Do not mix them.

192. Golden Rule: Stock First, Bridge Second
Every Player List feature should answer:

What happens when Bridge Mode is absent?

If answer is:

Player List breaks.

architecture is wrong.

Instead:

Stock:
Alice
Friend
Joined 24m
Avatar loaded

Bridge:
+ speaking
+ distance
+ performance
+ precise safety controls
193. Golden Rule: Local Safety, Not Judgment
The list can say:

Avatar caused local load warning? → uncertain
better:

High resource increase observed after avatar load.
It can say:

Voice currently active.
not:

Mic spammer.
It can say:

Unusual movement observed.
not:

Cheater.
That philosophy should be baked into the data model, not just wording.

194. What the Finished Player List Eventually Becomes
At full maturity, it is effectively:

                    PLAYER STORE
                         │
       ┌─────────────────┼──────────────────┐
       │                 │                  │
   Live Roster       Local History      Enrichment
       │                 │                  │
 Logs / Bridge       SQLite           API / VRC Eye
       │                 │                  │
       └─────────────────┼──────────────────┘
                         │
                    Player State
                         │
        ┌────────────────┼────────────────┐
        │                │                │
     Desktop          VR HUD           Safety
    Player List       Overlay          Center
        │                │                │
        └─────── Session / Black Box ────┘
Which is why I would build the Player subsystem before a lot of the fancy features.

Once this foundation is solid, things like:

encounter history,
world roles,
avatar diagnostics,
safety controls,
bridge telemetry,
VRC Eye user interactions,
photos,
Black Box,
Creator Mode
mostly become additional fields/events plugged into an already-working system rather than separate hacks.