"""Fixed API operations for Search, Favorites and Social, on the existing login."""
from dataclasses import dataclass, field
from urllib.parse import urlencode
import re

from companion_data import entity_id, reference, entity, sanitize, stamp
from player_api import context, check_context, lock
from vrchat_api import APIError

PAGE=100


@dataclass(frozen=True)
class Result:
    kind: str
    data: object
    account: tuple
    checked: float
    checked_at: str
    offset: int = 0
    more: bool = False
    raw_count: int = 0
    source_client: object = field(default=None, repr=False, compare=False)


def offset_value(offset):
    if type(offset) is not int or not 0<=offset<=2_000_000_000 or offset%PAGE: raise ValueError("Invalid page offset.")
    return offset


def request(client,path,*,many=False,method=None,payload=None,stop=None,progress=None):
    expected=context(client)
    lock(client,stop)
    try:
        check_context(client,expected,stop)
        client._wait_metadata(stop,progress)
        check_context(client,expected,stop)
        result=client._request(path,expect_list=many,method=method,payload=payload)
        check_context(client,expected,stop)
        cleaned=sanitize(result)
        if path=='auth/user' and isinstance(cleaned,dict):
            # Only this own-account route may retain these additional fields.
            from account_header import name
            from vrchat_api import friend_ids
            username=name(result.get('username'))
            if username:cleaned['username']=username
            friends=friend_ids(result)
            if friends is not None:cleaned['friends']=sorted(friends)
        return cleaned,expected,client.clock()
    finally: client.lock.release()


def read(client,kind,*,offset=0,query="",scope="public",group=None,stop=None,progress=None):
    offset_value(offset)
    if not isinstance(query,str) or len(query)>512 or any(ord(c)<32 for c in query): raise ValueError("Use search text up to 512 characters without control characters.")
    own=context(client)[0]
    params=dict(n=PAGE,offset=offset)
    many,paged=True,True
    if kind in ("user-search","world-search","group-search"):
        item_kind=kind.split('-')[0]
        if query.strip().startswith(("usr_","wrld_","grp_","https://vrchat.com/")):
            ref=entity_id(item_kind,query)
            path={"user":"users/","world":"worlds/","group":"groups/"}[item_kind]+ref
            many,paged=False,False
        else:
            if item_kind=="user" and not query.strip(): raise ValueError("Enter a user name or exact ID.")
            params["query" if item_kind=="group" else "search"]=query.strip()
            if item_kind=="world":
                params.update(sort="relevance" if query.strip() else "popularity",order="descending",releaseStatus="public")
                if scope=="mine": params.update(user="me",releaseStatus="all")
            path={"user":"users","world":"worlds","group":"groups"}[item_kind]+"?"+urlencode(params)
    elif kind in ("friends-online","friends-offline"):
        params["offline"]="true" if kind.endswith("offline") else "false"
        path="auth/user/friends?"+urlencode(params)
    elif kind in ("friend-requests", "notifications"):
        params["hidden"]="false"
        path="auth/user/notifications?"+urlencode(params)
    elif kind=="self-profile":
        path="auth/user"; many=paged=False
    elif kind=="my-groups":
        path=f"users/{own}/groups"; paged=False
    elif kind=="group-invites":
        path=f"users/{own}/groups/invited"; paged=False
    elif kind in ("mutes","blocks"):
        path="auth/user/playermoderations?"+urlencode(dict(type="mute" if kind=="mutes" else "block")); paged=False
    elif kind=="favorite-limits":
        path="auth/user/favoritelimits"; many=paged=False
    elif kind=="favorite-groups":
        params["ownerId"]=own
        path="favorite/groups?"+urlencode(params)
    elif kind=="favorite-items":
        if not isinstance(group,dict) or group.get("ownerId")!=own or group.get("type") not in ("friend","avatar","world","vrcPlusWorld") or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}",str(group.get("name",""))):
            raise ValueError("Select one of your returned favorite groups first.")
        params.update(type=group["type"],tag=group["name"])
        path="favorites?"+urlencode(params)
    else: raise ValueError("Unsupported companion query.")
    data,account,checked=request(client,path,many=many,stop=stop,progress=progress)
    count=len(data) if isinstance(data,list) else 0
    if many and (not isinstance(data,list) or any(not isinstance(row,dict) for row in data)):
        raise APIError("VRChat returned an unsupported record list.")
    if many and count>(PAGE if paged else 5000): raise APIError("Response exceeds the supported page size.")
    if kind.endswith("-search"):
        data=[entity(item_kind,item) for item in (data if many else [data])]
        if not many and data[0].id!=ref: raise APIError("The returned ID does not match the requested ID.")
    elif kind.startswith("friends-"):
        for row in data: entity_id("user",row.get("id"))
    elif kind=="friend-requests":
        data=[row for row in data if isinstance(row,dict) and row.get("type")=="friendRequest"]
        for row in data:
            reference(row.get("id"),("frq","not")); entity_id("user",row.get("senderUserId"))
            if row.get("receiverUserId",own)!=own: raise APIError("A request belongs to a different recipient.")
    elif kind=="notifications":
        from social_records import notification
        data=[notification(row, own) for row in data]
        if len({row["id"] for row in data}) != len(data): raise APIError("The notification page contains duplicate identifiers. Refresh before acting.")
    elif kind=="self-profile":
        if not isinstance(data,dict) or data.get("id")!=own: raise APIError("Your profile response belongs to another account.")
    elif kind in ("group-invites", "my-groups"):
        for row in data: entity_id("group",row.get("id") or row.get("groupId"))
    elif kind in ("mutes","blocks"):
        wanted="mute" if kind=="mutes" else "block"
        for row in data:
            if row.get("sourceUserId")!=own or row.get("type")!=wanted: raise APIError("Moderation response does not belong to this account/type.")
            entity_id("user",row.get("targetUserId"))
    elif kind=="favorite-groups":
        if any(row.get("ownerId")!=own for row in data): raise APIError("Favorite groups belong to another account.")
    elif kind=="favorite-items":
        for row in data:
            reference(row.get("id"),("fvrt",))
            entity_id("world" if group["type"]=="vrcPlusWorld" else group["type"],row.get("favoriteId"))
            if row.get("type")!=group["type"] or group["name"] not in row.get("tags",[]): raise APIError("Favorite response does not match this collection.")
    return Result(kind,data,account,checked,stamp(),offset,bool(paged and count==PAGE),count,client)


def selected_record(client,result,row,kind):
    expected=context(client)
    if (not isinstance(result,Result) or result.kind!=kind or result.account!=expected or
            (result.source_client is not None and result.source_client is not client) or
            not 0<=client.clock()-result.checked<300 or not isinstance(result.data,list) or
            not any(item is row for item in result.data)):
        raise ValueError("Refresh this list and select a current record before acting.")
    return expected


def mutate(client,action,*,target="",result=None,row=None,group=None,group_result=None,stop=None,progress=None,
           before_dispatch=None,on_confirmed=None):
    expected=context(client)
    method,payload="POST",{}
    fresh=None
    if action in ("add-friend","remove-friend","mute","unmute","block","unblock"):
        target=entity_id("user",target)
        if target==expected[0]: raise ValueError("Choose someone other than your own account.")
        if action=="add-friend": path=f"user/{target}/friendRequest"
        elif action=="remove-friend": path=f"auth/user/friends/{target}"; method="DELETE"; payload=None
        else:
            original="mute" if action in ("mute","unmute") else "block"
            path="auth/user/unplayermoderate" if action in ("unmute","unblock") else "auth/user/playermoderations"
            method="PUT" if action in ("unmute","unblock") else "POST"
            payload={"moderated":target,"type":original}
    elif action in ("accept-friend","decline-friend"):
        selected_record(client,result,row,"friend-requests"); fresh=(result,row,"friend-requests")
        ref=reference(row.get("id"),("frq","not"))
        path=f"auth/user/notifications/{ref}/"+("accept" if action=="accept-friend" else "hide")
        method="PUT"
    elif action in ("accept-group","decline-group"):
        selected_record(client,result,row,"group-invites"); fresh=(result,row,"group-invites")
        target=entity_id("group",row.get("id") or row.get("groupId"))
        path=f"groups/{target}/"+("join" if action=="accept-group" else "invites")
        method="POST" if action=="accept-group" else "PUT"
    elif action in ("see-notification","hide-notification"):
        selected_record(client,result,row,"notifications"); fresh=(result,row,"notifications")
        ref=reference(row.get("id"),("frq","not"))
        if row.get("receiverUserId",expected[0])!=expected[0]: raise ValueError("Notification recipient mismatch.")
        path=f"auth/user/notifications/{ref}/"+("see" if action=="see-notification" else "hide")
        method="PUT"
    elif action=="remove-favorite":
        selected_record(client,result,row,"favorite-items"); fresh=(result,row,"favorite-items")
        path="favorites/"+reference(row.get("id"),("fvrt",)); method="DELETE"; payload=None
    elif action=="add-favorite":
        selected_record(client,group_result,group,"favorite-groups"); fresh=(group_result,group,"favorite-groups")
        if group.get("ownerId")!=expected[0] or group.get("type") not in ("friend","avatar","world","vrcPlusWorld") or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}",str(group.get("name",""))): raise ValueError("Invalid owned favorite group.")
        target=entity_id("world" if group["type"]=="vrcPlusWorld" else group["type"],target)
        path="favorites"; payload={"type":group["type"],"favoriteId":target,"tags":[group["name"]]}
    else: raise ValueError("Unsupported social/favorite action.")
    lock(client,stop)
    try:
        client._wait_metadata(stop,progress)
        check_context(client,expected,stop)
        if fresh: selected_record(client,*fresh)
        if before_dispatch: before_dispatch()
        check_context(client,expected,stop)
        reply=client._request(path,method=method,payload=payload)
        # Mutation results are never automatically retried, even if acknowledgement is lost.
        client.cache.clear()
        if action in ("remove-friend","accept-friend"):
            client.friends=None; client.friends_checked_at=""
        success=isinstance(reply.get("success"),dict) and reply["success"].get("status_code")==200
        if action=="add-friend": success=reply.get("type")=="friendRequest" and bool(reference(reply.get("id"),("frq","not")))
        elif action in ("mute","block"):
            success=(reply.get("sourceUserId")==expected[0] and reply.get("targetUserId")==target and reply.get("type")==action)
        elif action=="accept-group": success=reply.get("groupId")==target and reply.get("userId")==expected[0] and reply.get("membershipStatus") in ("member","admin","owner")
        elif action=="add-favorite": success=reply.get("favoriteId")==target and reply.get("type")==group["type"] and bool(reference(reply.get("id"),("fvrt",)))
        elif action=="see-notification": success=(reply.get("id")==ref and reply.get("type")==row.get("type") and reply.get("seen") is True)
        if not success: raise APIError("VRChat did not return the expected confirmation. Refresh to check whether the action took effect.")
        if on_confirmed: on_confirmed()
        check_context(client,expected,stop)
        return "VRChat confirmed: "+action.replace('-',' ')+". Refresh the list for current state."
    finally: client.lock.release()


def limit_text(data):
    groups,per=data.get("maxFavoriteGroups"),data.get("maxFavoritesPerGroup")
    if not isinstance(groups,dict) or not isinstance(per,dict): return "Game limits unavailable; VRChat still enforces its account limits."
    parts=[]
    for kind in ("avatar","friend","world","vrcPlusWorld"):
        a,b=groups.get(kind),per.get(kind)
        if type(a) is int and type(b) is int and 0<=a<=10000 and 0<=b<=100000:
            parts.append(f"{kind}: {a} lists × {b} per list = {a*b} slots")
    return " · ".join(parts) or "No supported favorite limits returned."
