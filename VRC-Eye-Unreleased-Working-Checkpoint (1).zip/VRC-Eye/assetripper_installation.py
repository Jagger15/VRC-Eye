"""Bounded local installation evidence; never publisher/release attestation."""
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import stat

from avatar_library_files import inspect_file,fingerprint,check_cancel
from creator_projects import assert_no_links

MAX_ENTRIES=4096
MAX_BYTES=2*1024**3


@dataclass(frozen=True)
class Entry:
    path:str
    size:int
    sha256:str
    identity:tuple

    def public(self):return dict(path=self.path,size=self.size,sha256=self.sha256)


def inspect(executable,*,stop=None,progress=None):
    """Snapshot the dedicated installation tree, including licenses/dependencies.

    Each regular file is hashed, then all file/directory identities are checked.
    This observes unchanged bytes; it neither discovers system dependencies nor
    excludes an external writer changing files after the final observation.
    """
    root=assert_no_links(Path(executable).parent)
    pending=[root];directories=[];files=[];entries=total=0
    while pending:
        check_cancel(stop)
        folder=pending.pop();assert_no_links(folder)
        directories.append((folder,fingerprint(folder.stat())))
        with os.scandir(folder) as iterator:
            for item in iterator:
                check_cancel(stop);entries+=1
                if entries>MAX_ENTRIES:
                    raise ValueError('The tool installation exceeds 4,096 entries. Select AssetRipper from a dedicated installation folder.')
                path=assert_no_links(Path(item.path));info=item.stat(follow_symlinks=False)
                if stat.S_ISDIR(info.st_mode):pending.append(path)
                elif stat.S_ISREG(info.st_mode):
                    total+=info.st_size
                    if total>MAX_BYTES:raise ValueError('The tool installation exceeds 2 GiB. Select AssetRipper from a dedicated installation folder.')
                    evidence=inspect_file(path,stop=stop,progress=progress,limit=MAX_BYTES)
                    if fingerprint(info)!=evidence['fingerprint']:
                        raise ValueError('Tool installation changed during inspection. Inspect again.')
                    files.append(Entry(path.relative_to(root).as_posix(),evidence['size'],evidence['sha256'],tuple(sorted(evidence['fingerprint'].items()))))
                else:raise ValueError('Tool installation must contain only regular files and directories; links and special files are unsupported.')
    for entry in files:
        check_cancel(stop);path=assert_no_links(root/entry.path)
        if tuple(sorted(fingerprint(path.stat()).items()))!=entry.identity:
            raise ValueError('Tool dependency changed during inspection. Inspect again.')
    for path,before in directories:
        check_cancel(stop);assert_no_links(path)
        if fingerprint(path.stat())!=before:
            raise ValueError('Tool installation entries changed during inspection. Inspect again.')
    return tuple(sorted(files,key=lambda entry:entry.path))


def evidence(entries):
    files=[entry.public() for entry in entries]
    digest=sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    notices=[entry.path for entry in entries if Path(entry.path).name.casefold().startswith(('license','licence','copying','notice','credits'))]
    return dict(schema=1,files=files,sha256=digest,license_notice_files=notices,
        publisher_verified=False,release_version_verified=False,system_dependencies_verified=False,
        limitation='Local installation snapshot only. License filenames and unchanged hashes do not authenticate a publisher, release or license entitlement; system-loaded dependencies and post-check races remain unverified.')


def environment(folder):
    """No inherited app credentials, proxies, preload hooks or user config."""
    folder=assert_no_links(Path(folder));state=folder/'ProviderState'
    state.mkdir(mode=0o700)
    env={key:value for key,value in os.environ.items() if key in ('SystemRoot','WINDIR','LANG','LC_ALL','TZ')}
    # Provider-generated state and bundle extraction stay in the reviewed job.
    # This changes defaults, not OS access rights; exporter containment is open.
    env.update(HOME=str(state),USERPROFILE=str(state),APPDATA=str(state/'config'),LOCALAPPDATA=str(state/'data'),
        XDG_CONFIG_HOME=str(state/'config'),XDG_CACHE_HOME=str(state/'cache'),XDG_DATA_HOME=str(state/'data'),
        TMPDIR=str(state),TEMP=str(state),TMP=str(state),DOTNET_BUNDLE_EXTRACT_BASE_DIR=str(state/'bundles'),
        DOTNET_CLI_TELEMETRY_OPTOUT='1',DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1')
    return env
