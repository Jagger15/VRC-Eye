"""Read-only material, texture and primitive diagnostics in the existing viewer."""
import base64
from companion_ui import Table,button,choice
from friendly_ui import flow_line as line
from avatar_scene_appearance import Material,describe,transform_uv
import avatar_mesh_health as health


def texture_image(scene, material, *, zoom=1, channel='Composite', uv_overlay=False):
    """Use validated RGBA thumbnails only. Zoom never decodes the source again."""
    from PIL import Image,ImageDraw
    if zoom not in (1,2,4) or channel not in ('Composite','RGB','Alpha'):raise ValueError('Choose an inspection zoom/channel.')
    m=scene.materials[material] if material>=0 else Material()
    if m.texture<0:return None,'This material has no decoded embedded base-color texture.'
    t=scene.textures[m.texture]
    image=Image.frombytes('RGBA',(t.width,t.height),base64.b64decode(t.rgba,validate=True))
    image=image.resize((t.width*zoom,t.height*zoom),Image.Resampling.NEAREST)
    if channel=='Alpha':out=image.getchannel('A').convert('RGB')
    elif channel=='RGB':out=image.convert('RGB')
    else:
        out=Image.new('RGB',image.size,(205,205,205));draw=ImageDraw.Draw(out)
        for y in range(0,out.height,16):
            for x in range(0,out.width,16):
                if (x//16+y//16)%2:draw.rectangle((x,y,x+15,y+15),fill=(140,140,140))
        out.paste(image,mask=image.getchannel('A'))
    notice=f'{t.source_width} × {t.source_height} source; {t.width} × {t.height} retained pixels. {zoom}x nearest zoom; no additional source detail.'
    if uv_overlay:
        draw=ImageDraw.Draw(out);count=0;total=0
        for p in scene.parts:
            if p.material!=material or not p.uvs:continue
            for tri in p.triangles:
                total+=1
                if count>=2048:continue
                coords=[transform_uv(m,p.uvs[i]) for i in tri]
                # Clip display coordinates to bounded surroundings of the unit tile.
                coords=[(max(-4,min(5,u))*out.width,max(-4,min(5,v))*out.height) for u,v in coords]
                draw.line(coords+[coords[0]],fill=(255,50,150),width=1);count+=1
        notice+=f' UV{m.uv_set} overlay: {count}/{total} triangles, transformed unit tile before wrapping.'
    return out,notice


class Inspection:
    def __init__(self,controls):
        self.controls=controls;self.page=page=controls.page;self.image=None;self.material=None
        self.box=page.ttk.Frame(controls.box)
        self.materials=Table(page,self.box,(('name','Material',230),('parts','Primitives',80),('uv','Selected UV / colors',155),('texture','Embedded texture',240)),height=4,select=self.select_material)
        row=line(page,self.box)
        button(page,row,'Isolate material',self.isolate)
        button(page,row,'Show all materials',self.restore)
        self.zoom=page.tk.StringVar(value='1x');self.channel=page.tk.StringVar(value='Composite');self.uv=page.tk.BooleanVar(value=False)
        for label,var,values in (('Texture zoom',self.zoom,('1x','2x','4x')),('Channel',self.channel,('Composite','RGB','Alpha'))):
            page.ttk.Label(row,text=label).pack(side='left');choice(page,row,var,values,width=12)
        page.ttk.Checkbutton(row,text='UV overlay',variable=self.uv).pack(side='left')
        button(page,row,'Refresh texture',self.refresh_texture)
        self.texture_info=page.tk.StringVar(value='Select a material to inspect its texture.')
        page.ttk.Label(self.box,textvariable=self.texture_info,wraplength=1000).pack(anchor='w')
        canvas_box=page.ttk.Frame(self.box);canvas_box.pack(fill='both',expand=True)
        self.canvas=page.tk.Canvas(canvas_box,height=260,width=520,highlightthickness=2,takefocus=True,
                                  background=page.app.PANEL,highlightbackground=page.app.MUTED,highlightcolor=page.app.ACCENT)
        from screen_reader_model import annotate
        annotate(self.canvas,name='Selected material texture',value=self.texture_info.get,description='Texture dimensions and channels come from the selected material. UV and mesh-health details are in the adjoining tables.')
        ys=page.ttk.Scrollbar(canvas_box,orient='vertical',command=self.canvas.yview);xs=page.ttk.Scrollbar(canvas_box,orient='horizontal',command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        ys.pack(side='right',fill='y');xs.pack(side='bottom',fill='x');self.canvas.pack(fill='both',expand=True)
        for key,axis,amount in (('Left','x',-1),('Right','x',1),('Up','y',-1),('Down','y',1)):
            self.canvas.bind('<'+key+'>',lambda event,a=axis,n=amount:(getattr(self.canvas,a+'view_scroll')(n,'units'),'break')[-1])
        page.ttk.Label(self.box,text='Texture canvas: arrow keys scroll. Zoom enlarges retained pixels; Alpha displays coverage as grayscale.',wraplength=1000).pack(anchor='w')
        self.detail=page.tk.StringVar(value='')
        page.ttk.Label(self.box,textvariable=self.detail,wraplength=1000,justify='left').pack(anchor='w',pady=4)
        page.ttk.Label(self.box,text='Mesh health · select a primitive to highlight its node',style='Heading.TLabel').pack(anchor='w')
        self.meshes=Table(page,self.box,(('node','Node / primitive',230),('counts','Vertices / triangles',150),('issues','Geometry / UV findings',330),('streams','Normal / tangent streams',230)),height=5,select=self.select_mesh)
        self.mesh_detail=page.tk.StringVar(value='Diagnostics describe source indices; boundary edges may be intentional seams or openings.')
        page.ttk.Label(self.box,textvariable=self.mesh_detail,wraplength=1000,justify='left').pack(anchor='w')
        button(page,line(page,self.box),'Close inspector',self.hide)

    def show(self):
        self.controls.require();scene=self.controls.scene;self.clear()
        rows=[]
        for ref in sorted({p.material for p in scene.parts}):
            m=scene.materials[ref] if ref>=0 else Material();parts=[p for p in scene.parts if p.material==ref]
            t=scene.textures[m.texture] if m.texture>=0 else None
            rows.append(dict(ref=ref,name=m.name,parts=len(parts),uv=f'UV{m.uv_set}: {sum(bool(p.uvs) for p in parts)} / {sum(bool(p.colors) for p in parts)}',texture=f'{t.name} · {t.source_width}×{t.source_height}' if t else 'Factor / vertex colors only'))
        self.materials.set(rows,lambda r:(r['name'],r['parts'],r['uv'],r['texture']),identity=lambda r:str(r['ref']))
        names={n.index:n.name for n in scene.nodes};rows=[]
        for i,p in enumerate(scene.parts):
            h=dict(p.health);problems=sum(h.get(k,0) for k in ('degenerate_triangles','duplicate_triangles','nonmanifold_edges','nonmanifold_vertices','winding_edges'))
            rows.append(dict(index=i,node=p.node,label=f'{names[p.node]} · primitive {i+1}',counts=f"{h.get('source_vertices',len(p.vertices))} / {h.get('source_triangles',len(p.triangles))}",issues=f"{problems} findings · {h.get('boundary_edges',0)} boundary edges · {h.get('degenerate_uv_triangles',0)} UV degeneracies",streams=f"Normals {'present' if h.get('normals_present') else 'absent'} / tangents {'present' if h.get('tangents_present') else 'absent'}"))
        self.meshes.set(rows,lambda r:(r['label'],r['counts'],r['issues'],r['streams']),identity=lambda r:str(r['index']))
        self.box.pack(fill='both',expand=True,pady=8)

    def clear(self):
        self.image=None;self.material=None;self.canvas.delete('all')
        self.materials.set([],lambda r:());self.meshes.set([],lambda r:())
        self.detail.set('');self.mesh_detail.set('');self.texture_info.set('Select a material to inspect its texture.')

    def hide(self):self.clear();self.box.pack_forget()

    def select_material(self):
        self.controls.require();row=self.materials.selected()
        if not row:return
        self.material=row['ref'];scene=self.controls.scene
        from dataclasses import replace
        self.detail.set(describe(replace(scene,parts=tuple(p for p in scene.parts if p.material==self.material))))
        self.refresh_texture()

    def refresh_texture(self):
        self.controls.require();self.canvas.delete('all');self.image=None
        if self.material is None:return
        result,notice=texture_image(self.controls.scene,self.material,zoom={'1x':1,'2x':2,'4x':4}[self.zoom.get()],channel=self.channel.get(),uv_overlay=self.uv.get())
        self.texture_info.set(notice)
        if result is not None:
            from PIL import ImageTk
            self.image=ImageTk.PhotoImage(result,master=self.canvas)
            self.canvas.create_image(0,0,anchor='nw',image=self.image)
            self.canvas.configure(scrollregion=(0,0,result.width,result.height))

    def isolate(self):
        self.controls.require()
        if self.material is None:raise ValueError('Select a material first.')
        self.controls.material_focus=self.material;self.controls.rebuild()

    def restore(self):
        self.controls.require();self.controls.material_focus=None;self.controls.rebuild()

    def select_mesh(self):
        self.controls.require();row=self.meshes.selected()
        if not row:return
        self.controls.tree.selection_set('n'+str(row['node']));self.controls.select()
        self.mesh_detail.set(health.describe(self.controls.scene.parts[row['index']]))
