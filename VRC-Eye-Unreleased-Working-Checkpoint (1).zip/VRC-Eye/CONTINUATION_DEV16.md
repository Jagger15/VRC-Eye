# VRC Eye 1.21.0 — Development 16

This build continues the saved Development 15 source archive. It adds the agreed
next batch: managed AssetRipper jobs, contextual Home actions, and resumable owned
world / SDK / VCC transfers. Existing avatar transfers, manual recovery preparation,
shared notes, ordinary downloads and supplied-key world recovery are retained.

## Start and update

Close the old copy. Extract **VRC-Eye-v1.21.0-Development-16.zip** into a separate
folder and run **Start.cmd** on Windows or **bash Start.sh** on Linux. Launchers
and dependency requirements are unchanged. Extraction folders share the existing
per-user data locations. This is runnable source, not a compiled EXE or installer.

## Managed recovery

Open **Avatars → Library → Recovery**. Choose and inspect an authorized local
bundle, confirm ownership/permission, and choose a NEW staging folder. In
**Managed AssetRipper export**, select and inspect the native executable from
your separately installed AssetRipper, then choose **Review managed export…**.

The review identifies the executable, platform format, SHA-256, source and
destination. VRC Eye rechecks executable/input identity, stages a verified copy,
and launches that selected executable with an owned loopback service. It probes
the declared API before sending the load and export commands. A missing or
incompatible contract stops without submitting either command. There is no
automatic download, installation, attachment to an existing tool, or startup run.

The Avatar Library worker shows phases and supports cancellation. The job table
retains phases, outcomes, input/tool hashes and a bounded provider-log tail; the
log tail and local paths display only when **Show local paths** is enabled. The
process budget is ten minutes, startup discovery 30 seconds, API responses 2 MiB,
the retained in-memory tail 64 KiB (16,000 characters in the receipt), and the
provider log check 8 MiB. Cancellation stops identified processes and retains the
staged input and any partial export. Do not treat interrupted output as complete.
These are lifecycle limits, not OS-level memory/disk containment of the tool.

Completed command sequences are followed by output inspection: required project
entries, extension-based asset counts, missing metadata sidecars, declared
packages and project issues. `output-inventory.json` records relative file names,
sizes and hashes; `recovery-run.json` records the observed run. The inspection
limit is 20,000 entries / 8 GiB of declared output bytes; individual file hashing
uses the existing 2 GiB inspection cap. A successful command/receipt does not
prove original-source completeness, missing-reference resolution or Unity import.

Select the job and choose **Review Unity project handoff…** to use the existing
Creator Projects add/inspect review. Its separate **Open Unity** review remains
required; recovered scripts may execute during an editor import. The earlier
manual AssetRipper handoff and output inspector remain available.

No exact installed AssetRipper release was run or qualified in this environment.
Executable identity and runtime API compatibility do not authenticate publisher,
license, dependencies or release version. See [provider contract and acceptance
limits](ASSETRIPPER_PROVIDER_DEV16.md).

## Home row actions

Select an individual row and use **Open selected…**, Enter, double-click or the
context menu. Current player rows open profiles; offline user rows and retained
world rows open saved details. Photo/project/download rows select their exact
records. Notification identities include their v1/v2 family and select the exact
existing Inbox row. Any accept/decline/invite/mutation still uses that page's
fresh evidence and existing review.

Entity rows also offer shared notes/tags. Account, privacy and connection-mode
changes invalidate old actions; projections from a different workspace are hidden.
The header shows display-snapshot age and labels offline/stale snapshots. A new
**freshness** column describes retained source evidence; snapshot recency never
claims that historical data or saved files were just rechecked.

## Expanded transfers

- **World → World VRCW backups → Resumable backup / activity…**: look up a world
  owned by the signed-in account, select its build, Download from VRChat, and
  Unchanged backup. The common window can review a new download or matching resume.
- **SDK Downloads / VCC Downloads → Resumable download / activity…**: refresh
  the provider page, select a supported artifact, and open the common window.
  The reviewed metadata must be no more than five minutes old. Reopen this action
  after refreshing/changing the selected source.
- **Avatar Library → Transfers → All transfer activity…**, or a Home Downloads
  row: inspect avatar, world and public jobs for the current workspace. Avatar
  resume routes to the existing Avatar Library source/build controls.

The common view supports local outcome rehashing and separately reviewed discard
of verified owned partials. New/resumed world and public transfers retain existing
exclusive publication, exact range/strong ETag checks, prefix rehashing, optional
publisher SHA-256, account/source guards and cancellation. Each transfer is at
most 2 GiB. The avatar catalog and the separate world/public journal each allow
at most 16 retained partials; the latter has a 2,000-receipt cap. No credentials,
signed URLs, world keys or decrypted partials are journaled. Public provider
downloads use a separate no-cookie/no-auth transport.

Provider host cooldown deadlines persist across restart and are shared with
standard SDK/VCC requests. Opt-in resumable retries remain capped at three retries
within the reviewed ten-minute request lease. A long provider delay requires a
later manual review. No transfer resumes automatically at startup. Installer
execution, archive extraction and Unity import never follow a download automatically.

Supplied-key/decrypted world flows and browser-only Unity downloads keep their
existing workflows; resumable decryption and arbitrary download sources are not
part of this batch. Real CDN range support and native Windows filesystem behavior
remain acceptance gates.

## Validation and remaining work

[Validation](VALIDATION_1_21.md) and BUILD_VALIDATION.json contain exact final
results and exclusions. New fixture/headless cases exercise transfer persistence,
provider URL/length/hash/range checks, cooldowns, source/account/privacy changes,
recovery contract rejection, cancellation, retained failures, output manifests,
Home navigation and reviewed Unity handoff. They are not installed-provider tests.

The [ARC/VRCX report](ARC_VRCX_REMAINING_DEV16.md) records 38 partial and 9 missing
areas, plus separate prerequisites and source limits. Native GUI, installed
AssetRipper, live VRChat/CDN, Unity and other external-provider acceptance remain
open. Later roadmap items were not silently folded into this batch.
