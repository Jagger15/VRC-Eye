> **1.19.8 additive Client Bridge Lab contracts:** See
> [CLIENT_BRIDGE_LAB_GUIDE.md](CLIENT_BRIDGE_LAB_GUIDE.md) and
> [client_bridge_lab_contracts.json](client_bridge_lab_contracts.json).
> They reuse this connection; capability version 1 is negotiated individually.
> Lab actions require exact context/target preconditions and provider-owned
> lifetime enforcement. This release supplies no VRChat-specific provider.

# VRC Eye Bridge protocol 1.0

Implemented by VRC Eye 1.18.5. This document and `bridge_protocol.py` define the
portable wire contract. `bridge_sdk.py` is the Python reference adapter. Neither
side may enable an unrecognized capability or run code supplied by the peer.

## Transport and framing

VRC Eye creates one listener only after the user enables it:

- Windows: `\\.\pipe\VRC-Eye-` followed by 32 lowercase hexadecimal characters.
  Duplex, overlapped, message-mode, first-instance, one peer and remote-client
  rejection. Explicit protected DACL grants access to the current token's user
  SID, with no inherited handles. Client handles use overlapped I/O and message
  read mode. Close cancels pending overlapped I/O.
- Linux: an absolute `bridge.sock` inside a fresh `vrceye-bridge-*` directory,
  normally in the system temporary directory. Directory mode 0700, socket mode
  0600, both owned by the OS user. Validate `SO_PEERCRED` UID on both sides.
  Socket paths are limited to 100 encoded bytes. No network fallback exists.

Each frame is a **4-byte unsigned big-endian byte length** followed by that many
UTF-8 JSON bytes. Length must be 1–65,536. A Windows pipe **message** contains
exactly one complete frame (one write); do not send the prefix in a separate
pipe write. Unix sockets are a byte stream and may split/coalesce frames. An
incomplete Unix frame expires after two seconds.

JSON top levels are objects. Duplicate keys, nonfinite numbers, unsupported
fields, excessive nesting (>8), lists >128, objects >256 fields, keys >100
characters and strings >2,048 characters are rejected. Individual fields often
have tighter constraints below. Numbers must have their specified type; booleans
do not count as integers. IDs are lowercase UUIDs, with `usr_` / `avtr_` prefixes
where specified. Text identity/description fields cannot contain ASCII control
characters. Unknown message kinds disconnect the peer.

The copied connection code is UTF-8 JSON, at most 4,096 characters, containing
exactly `bridge:1`, `transport:"pipe"|"unix"`, `endpoint`, and `secret` (64
lowercase hexadecimal characters). Treat it as a temporary local credential.
It changes each time the host listener is enabled and is not sent in frames.

## Authentication and negotiation

The host sends:

```json
{"type":"challenge","protocol":{"major":1,"minor":0},"nonce":"64 lowercase random hex characters"}
```

The adapter replies with exactly `type:"hello"`, `hello` and `proof`:

```json
{
  "protocol": {"major":1,"minor":0},
  "client": {
    "id":"44444444-4444-4444-4444-444444444444",
    "name":"Example adapter",
    "version":"1.0.0",
    "kind":"vrchat"
  },
  "context": {
    "attached":true,
    "runtime_session":"66666666-6666-6666-6666-666666666666",
    "local_user_id":"usr_11111111-1111-1111-1111-111111111111"
  },
  "capabilities": {
    "player.selection":{"version":1},
    "safety.avatar_visibility":{"version":1}
  }
}
```

This object is the **hello member**, not the complete envelope. Client names
are 1–80 characters, client versions 1–40. Kind is `vrchat` or `diagnostic`.
A detached context has `attached:false` and both identity fields `null`.
Diagnostic adapters cannot claim an attached context. Client ID identifies the
adapter, not a VRChat account; its name and attachment are self-reported.

Capability names use lowercase dotted identifiers with 2–4 components.
Each definition has `version` (integer 1–1000), and optionally `presets`.
There may be at most 48 capabilities. Unknown IDs/schema versions may be
advertised for negotiation; they will not be accepted or granted by this host.
Known capabilities currently have schema version 1. Major protocol versions
must match. The host negotiates the smaller minor version, currently 0.

`safety.player_preset` and `safety.focus_group` must include a nonempty `presets`
object mapping supported `normal`, `reduced`, `minimal`, `hidden` names to plain
descriptions (1–300 characters). The adapter defines their concrete local
effects. VRC Eye displays those descriptions before they can be requested.

Compute proof as lowercase hexadecimal HMAC-SHA256 with the secret's **decoded
32 bytes** as the HMAC key. Authenticate these bytes:

```text
VRC-Eye-Bridge/1 <role>\n<challenge-nonce>\n<canonical-object-json>
```

The two `\n` separators represent actual LF bytes. Role is `hello` for the hello
object or `welcome` for the welcome object. Canonical JSON uses recursively
sorted keys, no spacing outside strings, ASCII escaping for non-ASCII text,
lowercase `\u` hex escapes, and surrogate pairs for non-BMP characters. This is
Python `json.dumps(value, sort_keys=True, separators=(",",":"),
ensure_ascii=True, allow_nan=False).encode("ascii")`. The authenticated hello
and welcome schemas contain no floating-point fields. Compare proofs in
constant time.

Interoperability vector: key = `a1` repeated 32 times, nonce = `b2` repeated 32
times, role = `hello`, object = `{"test":"Bridge"}`. Expected proof:

```text
298640201e6c1cb2fb30984db27b9b588e339afc181d61332b960a1647c1be05
```

After validating the hello and proof, the host replies with exactly
`type:"welcome"`, `welcome` and `proof`. The welcome object contains:

```json
{
  "protocol":{"major":1,"minor":0},
  "session":"55555555-5555-5555-5555-555555555555",
  "accepted":{"player.selection":{"version":1}},
  "heartbeat_ms":1000,
  "lease_ms":5000,
  "app_version":"1.18.5"
}
```

The shown IDs and accepted set are illustrative. The host creates a fresh
session UUID on every connection; accepted definitions must be an exact subset
of the adapter's recognized offer. Verify the host's proof before accepting
welcome or any permissions. Handshake waits have five-second timeouts. Pairing
does not grant any capability. Reconnect is always explicit and starts empty.

## Session frames, consent and heartbeats

All later frames contain exactly:

```json
{"session":"55555555-5555-5555-5555-555555555555","seq":1,"kind":"heartbeat","data":{}}
```

`seq` starts at 1 independently in each direction and must increase by exactly
1 (maximum 2^53−1). Wrong sessions, duplicate/out-of-order frames and unknown
kinds disconnect. Each side limits the peer to 100 frames per one-second
window. All elapsed-time/deadline checks use a local monotonic clock.

Both sides send a heartbeat every second. Host heartbeat data is `{}`; adapter
heartbeat data is `{"context":<the same attached/detached context>}`. A lease
expires after five seconds without a valid heartbeat. Other messages do not
renew it. The host and reference SDK supervise stalled I/O and close the
connection on lease loss. A changed runtime context requires disconnect and a
new handshake/consent; it cannot inherit the previous connection's permissions.

The host sends `kind:"permissions"` with:

```json
{
  "revision":1,
  "grants":{"player.selection":null,"safety.avatar_visibility":600000},
  "controls_enabled":false,
  "requests_paused":false
}
```

Revision starts at 0 and changes whenever permissions/control gates change.
Grant values are remaining milliseconds (0–3,600,000) or `null` for this
connection's lifetime. Omitted capabilities are revoked. Recalculate expiry on
receipt using the local monotonic clock. Do not carry approval across sessions.
Clear queued actions/samples on each new permission record; the host also fails
its outstanding requests. Respond with `kind:"permissions_ack"` and
`data:{"revision":1}`. The host exposes capabilities only after that exact
revision is acknowledged. Older acknowledgements cannot re-enable anything.

Telemetry requires an accepted, unexpired, acknowledged grant. Game telemetry
also requires an attached `vrchat` adapter and matching signed-in API account
if VRC Eye has one. Actions additionally require `requests_paused:false`; game
actions require `controls_enabled:true`. Diagnostic ping does not require game
attachment or the game-control switch. The API account is never sent to the
adapter as credentials. The host invalidates the session on its own account
identity or Demo-mode change.

## Telemetry schemas

Adapter sends `kind:"telemetry"`:

```json
{
  "capability":"player.selection",
  "permission_revision":1,
  "sample_age_ms":0,
  "value":{"user_id":"usr_22222222-2222-2222-2222-222222222222"}
}
```

`sample_age_ms` is an integer 0–60,000, measured from observation, not from an
old cached record being resent. The host subtracts it from the three-second
freshness window and discards samples with no remaining life. Samples from an
unapproved/old permission revision are discarded. Maximum 128 distinct user
IDs per `players` batch; fields are exact, without arbitrary extra metadata.

| Capability | Value schema |
| --- | --- |
| `bridge.diagnostics` | `uptime_seconds`: finite number, 0–1e9 |
| `player.selection` | `user_id`: `usr_…` or null; optional `display_name`: 1–128 characters |
| `player.voice_activity` | `players` rows: `user_id`, `voice_active` boolean; optional `avatar_audio_active` boolean |
| `player.distance` | `players` rows: `user_id`, `distance_m` finite number 0–100,000 |
| `avatar.load_state` | `players` rows: `user_id`, `state`; optional `avatar_id`: `avtr_…` or null |
| `avatar.performance` | `players` rows: `user_id`; optional `avatar_id`, `rank`, `texture_memory_bytes`, `renderer_count`, `physbone_count`, `contact_count` |
| `unity.runtime_health` | At least one optional field: `frame_ms`, `fps`, `working_set_bytes`, `tracking`, `foreground` |
| `local.microphone_state` | `muted` boolean |
| `local.moderation_state` | `players` rows: `user_id`; optional booleans `voice_muted`, `avatar_hidden`, `interactions_disabled`, `avatar_audio_enabled` |

Load states are `loading`, `ready`, `failed`, `security_failure`,
`bundle_failure`, `unknown`. Ranks are `Excellent`, `Good`, `Medium`, `Poor`,
`Very Poor`, `Unknown`. Performance `avatar_id` may be null. Texture bytes are
integers 0–2^40; component counts are integers 0–10,000,000. These are reported
texture/component metrics, not a total per-avatar VRAM measurement.

Runtime `frame_ms` and `fps` are finite numbers 0–100,000. Working-set bytes are
integers 0–2^44. Tracking is `normal`, `lost` or `unknown`; foreground is a
boolean. Omit unavailable fields. Do not fill missing information with zero or
an inference about another user's device/health/intent.

The SDK coalesces unsent telemetry per capability and drops stale samples;
adapter authors should publish modestly (for example 2–5 samples/second per
active capability) and remain below the total frame limit including heartbeat
and action messages. Voice telemetry contains activity booleans, not recordings.

## Requests and results

Only VRC Eye sends `kind:"request"`:

```json
{
  "id":"77777777-7777-7777-7777-777777777777",
  "capability":"safety.avatar_visibility",
  "params":{"user_id":"usr_22222222-2222-2222-2222-222222222222","visible":false},
  "permission_revision":2,
  "runtime_session":"66666666-6666-6666-6666-666666666666",
  "ttl_ms":1900
}
```

Request ID is a fresh UUID. `runtime_session` must match the connection's
context (null for detached diagnostics). `ttl_ms` is 1–2,000, the remaining
host timeout at preparation; the adapter starts its own short deadline on
receipt. The host deadline starts when queued and is two seconds total. IPC
delay may make confirmation uncertain; neither side automatically retries.
The host permits at most eight pending requests and spaces new requests by at
least 200 ms. Adapter queues are also bounded to eight local actions. Do not
dispatch from the I/O worker.

Recheck session generation, runtime, permission revision, consent expiry,
control switches and action deadline immediately before dispatch. Each adapter
must additionally check target presence/current instance and its normal local
permissions at application time. A revocation/disconnect cannot reverse an
already entered callback. Never interpret client-supplied strings as code.

| Capability | Exact parameters |
| --- | --- |
| `bridge.ping` | `nonce`: UUID |
| `safety.microphone_mute` | `muted`: boolean, local user's microphone |
| `safety.voice_mute` | `user_id`, `muted`: boolean, local incoming voice for target |
| `safety.avatar_visibility` | `user_id`, `visible`: boolean |
| `safety.avatar_audio` | `user_id`, `enabled`: boolean |
| `safety.avatar_particles` | `user_id`, `enabled`: boolean |
| `safety.avatar_lights` | `user_id`, `enabled`: boolean |
| `safety.avatar_effects` | `user_id`, `mode`: `normal`, `reduced`, `minimal` |
| `safety.interactions` | `user_id`, `enabled`: boolean |
| `safety.player_preset` | `user_id`, `preset`: one of the adapter's declared presets |
| `safety.focus_group` | `user_ids`: 1–128 unique exact IDs to retain; `outside_preset`: declared `reduced`, `minimal` or `hidden` preset for others locally |

All `user_id` values are exact `usr_…` IDs. The local rendering, audio and
interaction changes must affect only the requesting local user's experience.
Preset descriptions must accurately state their effect. Unsupported operations
must not be advertised. No operation grants authority over another client.

Adapter replies `kind:"result"`:

```json
{"id":"77777777-7777-7777-7777-777777777777","ok":true,"value":{"applied":true}}
```

Ping's successful value is `{"pong":<the exact requested nonce>}`. All other
successes require exactly `{"applied":true}`. Failure uses `ok:false` and may
include a short non-sensitive `error` code such as `not_allowed`, `not_applied`
or `queue_full`. VRC Eye displays a generic failure, not raw adapter exceptions.
The host ignores results for recently completed/expired requests and rejects
unsolicited IDs or responses to unsent requests. Duplicate request IDs are
rejected by the SDK. Unknown outcomes are never claimed as successful actions.

## Isolation and release scope

Invalid frames terminate the session; a host with three failures inside 60
seconds disables its listener and requires a fresh user enable. No approval,
telemetry or queued action survives disconnect. The last 200 host request and
permission outcomes remain in memory without payloads or secrets. The protocol
does not expose VRC Eye API mutation, shell execution, file extraction, Unity
object invocation or arbitrary client-to-host commands.

This is a client integration contract, not evidence that a particular client
supports it. A connected adapter may still be buggy or dishonest. Native OS
permission checks and HMAC establish local pairing, not data accuracy. GUI,
native Windows/Linux IPC and real-client compatibility need their own runtime
verification, as recorded in **VALIDATION.md**.

## Implementation references

Transport behavior was checked against Microsoft's named-pipe documentation,
Python socket documentation and the installed CPython multiprocessing connection
source. The protocol and reference implementation are included in this ZIP.

- [Named Pipe Security and Access Rights](https://learn.microsoft.com/en-us/windows/win32/ipc/named-pipe-security-and-access-rights)
- [ConnectNamedPipe](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-connectnamedpipe)
- [Named Pipe Server Using Overlapped I/O](https://learn.microsoft.com/en-us/windows/win32/ipc/named-pipe-server-using-overlapped-i-o)
- [GetTokenInformation](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-gettokeninformation)
- [Python 3.10 socket documentation](https://docs.python.org/3.10/library/socket.html)

## Player-list extension in 1.18.6

The backward-compatible optional telemetry capability `instance.context` version 1
is required before the new Player List attaches bridge samples to people:

```json
{"world_id":"wrld_11111111-2222-3333-4444-555555555555","instance_id":"1234","network_master":"usr_11111111-1111-1111-1111-111111111111"}
```

`world_id` is an exact lowercase world ID. `instance_id` is the complete instance
string after the colon, including its modifiers, at most 1024 characters without
control characters. `network_master` is optional and may be null. The adapter must
report its actual current context, with ordinary sample age and permission revision.
Do not copy the supplied example IDs. Context and player telemetry need separate
approvals and a fresh matching local log context. Old adapters need not advertise
this optional capability; their existing protocol 1.0 features continue working.

Voice indicators expire after one second of source age; distance and other player
telemetry use at most the existing three-second lease. The host retains both receive
and sample-observation times internally. No new game command or injection method
is introduced. See PLAYER_LIST_SETUP.md for reviewed per-player controls and
limitations. Missing capabilities remain unavailable.

## 1.18.9 additive runtime telemetry capabilities

These capability-version-1 schemas use the existing Bridge 1.0 consent/lease and
telemetry envelope. They do not change the wire protocol or grant any capability
automatically. Unknown capabilities remain safely ignored by older applications.

`runtime.summary` example value:

```json
{"process_id":1234,"process_started_at":1790838000.25,"scene":"ready","avatars":"ready","render":"degraded","local_player":"ready","vr_mode":"desktop","frame_ms":16.7,"fps":60}
```

The two process fields are required. State fields accept `unknown`, `initializing`,
`ready`, `degraded`, `failed`; `vr_mode` accepts `unknown`, `desktop`, `vr`. Timing
and FPS are finite, nonnegative bounded values. The receiving Unity Player model
checks the process ID and creation time against its independently observed target.

`runtime.errors` example value:

```json
{"process_id":1234,"process_started_at":1790838000.25,"events":[{"category":"graphics","severity":"warning","code":"device_reset","count":1}]}
```

Maximum 64 entries. Category: `runtime`, `graphics`, `assets`, `avatar`, `network`,
`media`, `steamvr`, `osc`, `authentication`, `unknown`. Severity: `warning`, `error`,
`fatal`. Code: `unknown`, `device_reset`, `shader_compile`, `asset_load`, `network`.
Count is an integer 1–10,000. Unknown fields/free text are rejected. A producer
should send each error batch once; receiver deduplication covers repeated reads of
the same received sample, not a producer retransmitting an event as a new sample.

Process IDs/creation times are routing context, excluded from runtime exports and
Black Box runtime events. These fields establish matching claims by an authenticated
adapter; they are not cryptographic proof that an adapter's measurements are true.
