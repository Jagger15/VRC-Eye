"""App-owned peer lifecycle and narrow privacy/diagnostic integration."""
import sqlite3
import time


def player_privacy(service, settings):
    """Apply inherited restrictions before receiving or sending peer content."""
    service.set_inherited_privacy('players', incognito=bool(settings.get('incognito')),
                        streamer=bool(settings.get('presentation') or settings.get('anonymize')),
                        notifications_muted=bool(settings.get('notifications_muted')),
                        history_inhibited=settings.get('history', 'Session only') == 'Session only')


class PeerApp:
    def __init__(self, app, store):
        from peer_service import PeerService
        self.app = app
        self.store = store
        self.last_context = None
        self.last_privacy = None
        self.last_event = 0
        self.error = ''
        self.overlay_target = None
        try:
            self.service = PeerService(store.path.with_name(store.path.stem + '-peers.sqlite3'))
        except (OSError, ValueError, sqlite3.Error):
            self.service = PeerService(':memory:')
            self.error = 'Peer storage is unavailable. This workspace is temporary for this app session.'
        app.peer_service = self.service
        presentation = store.option('peer.presentation', {})
        app.peer_overlay_enabled = isinstance(presentation, dict) and presentation.get('overlay') is True
        self.service.set_environment(bool(app.demo or getattr(app, 'safe_mode', False)), 'Demo or startup Safe Mode')

    def tick(self):
        app = self.app
        self.service.set_environment(bool(app.demo or getattr(app, 'safe_mode', False)), 'Demo or startup Safe Mode')
        players = getattr(app, 'player_sessions', None)
        prefs = getattr(players, 'settings', {})
        wellness = app.sidebar.pages.get('Wellness')
        try:
            wellness_settings = wellness.engine.settings if wellness else self.store.option('wellness.settings', {})
            if not isinstance(wellness_settings, dict):
                raise ValueError('Invalid local Wellness preferences.')
            player_privacy(self.service, prefs)
            self.service.set_inherited_privacy('wellness', streamer=bool(wellness_settings.get('streamer')),
                                               reduced_motion=bool(wellness_settings.get('reduced_motion')))
            self.service.set_inherited_privacy('accessibility', reduced_motion=bool(getattr(getattr(app, 'presentation', None), 'reduced_motion', False)))
            context = getattr(players, 'meta', {}).get('id') if players else None
            if context != self.last_context:
                self.service.context_boundary(context)
                self.last_context = context
            self.service.tick()
            snapshot = self.service.snapshot()
        except (OSError, ValueError, sqlite3.Error):
            self.service.private_mode()
            self.error = 'Peer Services paused after a storage or validation error. Local runtime tools remain available.'
            if self.overlay_target:
                self.overlay_target.display_peer({})
            app.sidebar.peer_banner.set(self.error)
            return
        self._diagnostics(snapshot)
        self._presentation(snapshot, wellness)

    def _diagnostics(self, snapshot):
        page = self.app.sidebar.pages.get('Crash & Diagnostics')
        for event in snapshot.get('events', []):
            seq = event.get('sequence', 0)
            if type(seq) is not int or seq <= self.last_event:
                continue
            self.last_event = seq
            if page and not self.app.demo:
                # No arbitrary strings, peer identifiers, addresses or payload bodies.
                kind = event.get('type', '')
                category = ('connection' if 'connect' in kind or 'private' in kind else
                            'permission' if 'permission' in kind or 'revoke' in kind else
                            'delivery' if 'send' in kind or 'receive' in kind else 'state')
                page.service.offer('peer.activity', 'vrc_eye', {'peer_event': category,
                    'count': len(snapshot.get('peers', [])), 'sequence_to': seq})

    def _presentation(self, snapshot, wellness):
        text = self.error
        expires = 0
        notices = snapshot.get('notifications', [])
        if notices:
            notice = notices[-1]
            if isinstance(notice, dict):
                expires = notice.get('expires_at', 0)
                if type(expires) in (int, float) and expires > time.time():
                    text = str(notice.get('text', ''))[:1200]
        self.app.sidebar.peer_banner.set(text)
        target = getattr(wellness, 'runtime', None) if wellness else None
        if target is not self.overlay_target:
            if self.overlay_target:
                self.overlay_target.display_peer({})
            self.overlay_target = target
        if target:
            target.display_peer({'enabled': bool(self.app.peer_overlay_enabled and text and expires > time.time() and not self.app.demo),
                                 'text': text, 'expires_at': expires})

    def account_changed(self):
        self.service.private_mode()
        if self.overlay_target:
            self.overlay_target.display_peer({})

    def close(self):
        if self.overlay_target:
            self.overlay_target.display_peer({})
        self.service.close()


def apply_live_preferences(app, store):
    """Refresh already-open editors after an explicitly reviewed preset import.

    Validation precedes mutation. No providers are started and the existing
    Wellness session remains owned by its current engine. The caller owns the
    durable checkpoint and restores it if a UI refresh fails.
    """
    from wellness import defaults, validate
    from resource_core import validate_settings
    pages = app.sidebar.pages
    wellness = pages.get('Wellness')
    resources = pages.get('Performance & Security')
    wellness_settings = validate(store.option('wellness.settings', defaults())) if wellness else None
    resource_settings = validate_settings(store.option('resources.settings', None)) if resources else None
    if wellness:
        wellness.engine.configure(wellness_settings)
        wellness.notification.close()
        wellness.notification.seen = None
        wellness.seen_pending = None
        wellness.runtime.display({})
        wellness.sync_settings()
        wellness.view_mode.set(wellness_settings['view'])
        wellness.change_view(save=False)
    if resources:
        # The peer preset allowlist contains only this Resource Guard preference.
        resources.settings['view'] = resource_settings['view']
        resources.view.set(resource_settings['view'])
        resources.render()
