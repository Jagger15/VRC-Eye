"""Opt-in PNG metadata interpretation; candidates only, no URLs or file writes.

Independent format adapter informed by VRCX 2026.09.16 ScreenshotHelper.cs and
src/stores/vrcx.js. Sensitive fields are transient and excluded from summaries.
"""
import json
import re
import struct
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime

TEXT_LIMIT = 65536
TOTAL_LIMIT = 262144
ROSTER_LIMIT = 256
ID = re.compile(r'(usr|wrld)_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z')
PNG = b'\x89PNG\r\n\x1a\n'


def _unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out: raise ValueError('Duplicate metadata fields.')
        out[key] = value
    return out


def _bounded(value, depth=0):
    if depth > 12: raise ValueError('Metadata nesting limit exceeded.')
    if isinstance(value, dict):
        if len(value) > 512: raise ValueError('Metadata field limit exceeded.')
        for key, item in value.items(): _bounded(item, depth + 1)
    elif isinstance(value, list):
        if len(value) > ROSTER_LIMIT: raise ValueError('Metadata list limit exceeded.')
        for item in value: _bounded(item, depth + 1)
    elif isinstance(value, str) and len(value) > 4096: raise ValueError('Metadata string limit exceeded.')


def _inflate(raw):
    decoder = zlib.decompressobj()
    output = decoder.decompress(raw, TEXT_LIMIT + 1)
    if len(output) > TEXT_LIMIT or decoder.unconsumed_tail or not decoder.eof or decoder.unused_data:
        raise ValueError('Compressed metadata exceeds the limit or is malformed.')
    return output


def png_text(data):
    if not isinstance(data, bytes) or len(data) > 64 * 1024 * 1024 or not data.startswith(PNG):
        raise ValueError('Select a bounded PNG for structured metadata inspection.')
    at = 8; count = total = 0; result = {}; ended = False
    while at < len(data):
        count += 1
        if count > 4096 or at + 12 > len(data): raise ValueError('Malformed or excessive PNG chunks.')
        length = struct.unpack_from('>I', data, at)[0]; kind = data[at + 4:at + 8]; end = at + 12 + length
        if end > len(data): raise ValueError('Truncated PNG metadata.')
        if kind in (b'tEXt', b'zTXt', b'iTXt'):
            raw = data[at + 8:end - 4]
            if len(raw) > TEXT_LIMIT: raise ValueError('PNG text chunk exceeds 64 KiB.')
            if zlib.crc32(kind + raw) & 0xffffffff != struct.unpack_from('>I', data, end - 4)[0]:
                raise ValueError('PNG metadata checksum mismatch.')
            key, separator, value = raw.partition(b'\0')
            if not separator or not 1 <= len(key) <= 79: raise ValueError('Invalid PNG text keyword.')
            key = key.decode('latin1')
            if kind == b'zTXt':
                if not value or value[0] != 0: raise ValueError('Unsupported PNG text compression.')
                value = _inflate(value[1:])
            elif kind == b'iTXt':
                if len(value) < 2 or value[0] not in (0, 1) or value[1] != 0: raise ValueError('Unsupported international PNG text.')
                compressed = value[0]; remainder = value[2:].split(b'\0', 2)
                if len(remainder) != 3: raise ValueError('Malformed international PNG text.')
                value = _inflate(remainder[2]) if compressed else remainder[2]
            total += len(value)
            if len(value) > TEXT_LIMIT or total > TOTAL_LIMIT: raise ValueError('Expanded metadata budget exceeded.')
            if key in ('Description', 'XML:com.adobe.xmp'):
                if key in result: raise ValueError('Duplicate structured PNG text chunks.')
                # VRCX writes UTF-8 even in a tEXt chunk. Accept it first while
                # retaining standard Latin-1 compatibility for older PNG text.
                try: result[key] = value.decode('utf-8')
                except UnicodeError:
                    if kind == b'iTXt': raise ValueError('Invalid UTF-8 international PNG text.') from None
                    result[key] = value.decode('latin1')
        at = end
        if kind == b'IEND': ended = True; break
    if not ended: raise ValueError('PNG is missing its end marker.')
    # Legacy out-of-spec trailing Description records are deliberately not read.
    return result


def _string(value, limit=512):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError('Invalid metadata text field.')
    return value


def _id(value, kind):
    value = _string(value, 64)
    if not ID.fullmatch(value) or not value.startswith(kind + '_'): raise ValueError('Invalid declared identity.')
    return value.lower()


def _timestamp(value):
    value = _string(value, 100)
    try: stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        try: stamp = datetime.strptime(value, '%Y:%m:%d %H:%M:%S')
        except ValueError: raise ValueError('Unsupported timestamp declaration.') from None
    return stamp.isoformat(), 'Offset declared' if stamp.tzinfo else 'Timezone unknown'


def _candidate(rows, field, value, source, sensitive=False, **extra):
    if value not in (None, ''): rows.append(dict(field=field, value=value, source=source, sensitive=sensitive, **extra))


def _description(text):
    data = json.loads(text, object_pairs_hook=_unique); _bounded(data)
    if not isinstance(data, dict) or data.get('application') != 'VRCX' or type(data.get('version')) is not int or data['version'] != 1:
        raise ValueError('Unsupported Description application/schema; only VRCX version 1 is supported.')
    source = 'PNG Description · VRCX schema 1'; rows = []
    for key in ('author', 'world'):
        obj = data.get(key, {})
        if not isinstance(obj, dict): raise ValueError('Invalid metadata identity record.')
        if obj.get('id'): _candidate(rows, key + '_id', _id(obj['id'], 'usr' if key == 'author' else 'wrld'), source, key == 'author')
        name = obj.get('displayName' if key == 'author' else 'name')
        if name: _candidate(rows, key + '_name', _string(name), source, True)
        if key == 'world' and obj.get('instanceId'): _candidate(rows, 'instance', _string(obj['instanceId'], 1024), source, True)
    players = data.get('players', [])
    if not isinstance(players, list) or len(players) > ROSTER_LIMIT: raise ValueError('Participant declaration exceeds the limit.')
    roster = []
    for row in players:
        if not isinstance(row, dict): raise ValueError('Invalid participant declaration.')
        roster.append({'id': _id(row.get('id'), 'usr'), 'displayName': _string(row.get('displayName', ''))})
    if roster: _candidate(rows, 'participants', roster, source, True, meaning='Declared roster; not people verified visible in the photo')
    if data.get('timestamp'):
        value, zone = _timestamp(data['timestamp']); _candidate(rows, 'timestamp', value, source, timezone=zone)
    if data.get('note'): _candidate(rows, 'note', _string(data['note'], 4096), source, True)
    return rows


def _xmp(text):
    if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper(): raise ValueError('XML declarations/entities are not supported.')
    root = ET.fromstring(text)
    if root.tag != '{adobe:ns:meta/}xmpmeta': raise ValueError('Unsupported XMP root.')
    stack = [(root, 0)]; nodes = 0
    while stack:
        element, depth = stack.pop(); nodes += 1
        if nodes > 2048 or depth > 12: raise ValueError('XMP structure exceeds inspection limits.')
        stack.extend((child, depth + 1) for child in element)
    ns = {'xmp': 'http://ns.adobe.com/xap/1.0/', 'tiff': 'http://ns.adobe.com/tiff/1.0/', 'dc': 'http://purl.org/dc/elements/1.1/', 'rdf': 'http://www.w3.org/1999/02/22-rdf-syntax-ns#', 'vrc': 'http://ns.vrchat.com/vrc/1.0/'}
    def get(name):
        prefix, local = name.split(':'); tag = '{' + ns[prefix] + '}' + local
        values = [e.text or '' for e in root.iter(tag)]
        values += [e.attrib[tag] for e in root.iter() if tag in e.attrib]
        if len(values) > 1: raise ValueError('Duplicate XMP field declarations.')
        return values[0] if values else ''
    source = 'PNG XMP · VRChat namespace 1.0'; rows = []
    modern, legacy = get('vrc:WorldID'), get('vrc:World')
    for value, field_source in ((modern, source), (legacy, source + ' legacy World')):
        if value: _candidate(rows, 'world_id', _id(value, 'wrld'), field_source)
    author = get('vrc:AuthorID'); name = get('xmp:Author')
    if author: _candidate(rows, 'author_id', _id(author, 'usr'), source, True)
    if name:
        if not author: _candidate(rows, 'author_id', _id(name, 'usr'), source + ' legacy Author', True)
        else: _candidate(rows, 'author_name', _string(name), source, True)
    world_name = get('vrc:WorldDisplayName')
    if world_name: _candidate(rows, 'world_name', _string(world_name), source, True)
    value = get('tiff:DateTime')
    if value:
        value, zone = _timestamp(value); _candidate(rows, 'timestamp', value, source, timezone=zone)
    notes = root.findall('.//dc:title/rdf:Alt/rdf:li', ns)
    if len(notes) > 1: raise ValueError('Multiple XMP note alternatives are unsupported.')
    if notes: _candidate(rows, 'note', _string(notes[0].text or '', 4096), source, True)
    if not modern and not legacy and not author and not name: raise ValueError('No recognized VRChat XMP identity fields.')
    return rows


def inspect_metadata(data):
    chunks = png_text(data); rows = []; formats = []
    for key, parse in (('Description', _description), ('XML:com.adobe.xmp', _xmp)):
        if key not in chunks: continue
        try:
            if key=='Description' and chunks[key].startswith(('lfs|','screenshotmanager|')):parse=_legacy_description
            found = parse(chunks[key]); rows.extend(found)
            formats.append({'format': key, 'state': 'Supported declaration', 'fields': len(found)})
        except (ValueError, TypeError, KeyError, RecursionError, ET.ParseError):
            formats.append({'format': key, 'state': 'Malformed or unsupported declaration', 'fields': 0})
    for text in _trailing_descriptions(data):
        try:
            found=_legacy_description(text) if text.startswith(('lfs|','screenshotmanager|')) else _description(text)
            for row in found:row['source']='Legacy trailing chunk · '+row['source']
            rows.extend(found);formats.append({'format':'Legacy trailing Description','state':'Supported declaration','fields':len(found)})
        except (ValueError,TypeError,KeyError,RecursionError):formats.append({'format':'Legacy trailing Description','state':'Malformed or unsupported declaration','fields':0})
    conflicts = []
    for field in sorted({r['field'] for r in rows}):
        values = {json.dumps(r['value'], sort_keys=True) for r in rows if r['field'] == field}
        if len(values) > 1: conflicts.append(field)
    return {'formats': formats, 'candidates': rows, 'conflicts': conflicts,
            'note': 'Embedded declarations are unverified. No identities, locations or capture times were assigned. No participant is proven visible.'}


def _trailing_descriptions(data):
    """Known legacy chunks after IEND, at most 8 KiB and four declarations."""
    at=8
    while at+12<=len(data):
        size=struct.unpack_from('>I',data,at)[0];end=at+size+12;kind=data[at+4:at+8]
        if end>len(data):return []
        at=end
        if kind==b'IEND':break
    tail=data[at:]
    if len(tail)>8192:return []
    result=[];at=0
    while at+12<=len(tail) and len(result)<4:
        size=struct.unpack_from('>I',tail,at)[0];end=at+size+12;kind=tail[at+4:at+8]
        if size>8192 or end>len(tail):break
        payload=tail[at+8:end-4]
        if kind==b'tEXt' and zlib.crc32(kind+payload)&0xffffffff==struct.unpack_from('>I',tail,end-4)[0]:
            key,_,value=payload.partition(b'\0')
            if key==b'Description':
                try:result.append(value.decode('utf-8'))
                except UnicodeError:result.append(value.decode('latin1'))
        at=end
    return result


def _legacy_description(value):
    _string(value,8192);parts=value.split('|');rows=[]
    if parts[:2] not in (['lfs','1'],['lfs','2'],['screenshotmanager','0']):raise ValueError('Unsupported legacy screenshot schema.')
    source='Legacy '+parts[0]+' schema '+parts[1];fields={}
    for part in parts[2:]:
        key,separator,text=part.partition(':')
        if separator:
            if key in fields:raise ValueError('Duplicate legacy declaration.')
            fields[key]=text
        elif parts[0]=='screenshotmanager' and part.startswith('wrld_'):fields['world']=part
    if fields.get('author'):
        ref,_,name=fields['author'].partition(',');_candidate(rows,'author_id',_id(ref,'usr'),source,True);_candidate(rows,'author_name',_string(name),source,True)
    if fields.get('world'):
        world=fields['world'].split(',',2)
        if parts[:2]==['lfs','1']:
            location,_,name=fields['world'].partition(',');ref,_,instance=location.partition(':')
        else:
            if len(world)!=3:raise ValueError('Invalid legacy world declaration.')
            ref,instance,name=world
        _candidate(rows,'world_id',_id(ref,'wrld'),source);_candidate(rows,'world_name',_string(name),source,True)
        _candidate(rows,'instance',_string(instance,1024),source,True)
    roster=[]
    if fields.get('players'):
        records=fields['players'].split(';')
        if len(records)>ROSTER_LIMIT:raise ValueError('Too many declared legacy players.')
        for item in records:
            values=item.split(',',4 if parts[1]=='2' else 1)
            if len(values)!=(5 if parts[1]=='2' else 2):raise ValueError('Invalid legacy player declaration.')
            roster.append(dict(id=_id(values[0],'usr'),displayName=_string(values[-1])))
    if roster:_candidate(rows,'participants',roster,source,True,meaning='Declared roster; not people verified visible')
    return rows


def public_report(result, include_sensitive=False):
    return {**result, 'candidates': [row if include_sensitive or not row['sensitive'] else
            {k: v for k, v in row.items() if k != 'value'} | {'value': '[sensitive declaration hidden]'} for row in result['candidates']]}
