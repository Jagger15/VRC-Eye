"""Bounded local photo I/O and metadata-free renders; never network or edit originals.

File identity primitives are shared with the Avatar Library. Metadata observations
are suggestions, not identity/ownership evidence. Formats are deliberately limited.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
from pathlib import Path, PureWindowsPath
import json
import os
import re
import stat
import struct
import time
import warnings

from avatar_library_files import checked_stream, fingerprint, check_cancel
from creator_projects import assert_no_links, local_path

MAX_BYTES = 64 * 1024 * 1024
MAX_PIXELS = 32 * 1024 * 1024
MAX_EDGE = 16384
MAX_ENTRIES = 20000
MAX_DEPTH = 8
MAX_SCAN_SECONDS = 120
EXTENSIONS = frozenset(('.png', '.jpg', '.jpeg', '.webp'))
FORMATS = ('PNG', 'JPEG', 'WEBP')
SKIP_DIRS = frozenset(('.git', '.vrc-eye-exports', '.vrc-eye-trash'))
WORLD = re.compile(r'(?<![A-Za-z0-9_])wrld_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}(?![A-Za-z0-9_-])')
DATE = re.compile(r'(?<!\d)(\d{4})[-:](\d{2})[-:](\d{2})[ _T](\d{2})[-:](\d{2})[-:](\d{2})(?!\d)')


@dataclass(frozen=True)
class WalkResult:
    files: tuple[str, ...]
    complete: bool
    scanned: int
    skipped: int
    reason: str


def directory_identity(path):
    path = assert_no_links(local_path(path))
    info = path.stat()
    if not stat.S_ISDIR(info.st_mode):
        raise ValueError('Select an existing real folder, not a link or file.')
    return {'device': str(info.st_dev), 'inode': str(info.st_ino)}


def check_directory(path, expected):
    if directory_identity(path) != expected:
        raise ValueError('The source folder was replaced or remounted. Review and approve its current location again.')


def walk_source(path, *, recursive=False, expected=None, stop=None, progress=None, clock=time.monotonic, seconds=MAX_SCAN_SECONDS):
    """Discover within one approved root; incomplete scans never imply deletion."""
    path = assert_no_links(local_path(path))
    if expected is not None:
        check_directory(path, expected)
    else:
        directory_identity(path)
    started = clock(); stack = [(path, 0)]; files = []; count = skipped = 0; complete = True
    while stack:
        check_cancel(stop)
        folder, depth = stack.pop()
        assert_no_links(folder)
        try:
            with os.scandir(folder) as entries:
                for item in entries:
                    check_cancel(stop); count += 1
                    if count > MAX_ENTRIES or clock() - started > seconds:
                        return WalkResult(tuple(sorted(files)), False, count - 1, skipped, 'Scan budget reached; results are partial. Choose a smaller source.')
                    try:
                        info = item.stat(follow_symlinks=False)
                        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                            skipped += 1; continue
                        if stat.S_ISDIR(info.st_mode):
                            if recursive and item.name not in SKIP_DIRS:
                                if depth < MAX_DEPTH: stack.append((Path(item.path), depth + 1))
                                else: skipped += 1; complete = False
                        elif stat.S_ISREG(info.st_mode) and Path(item.name).suffix.lower() in EXTENSIONS:
                            files.append(item.path)
                    except OSError:
                        skipped += 1; complete = False
                    if progress and count % 100 == 0:
                        progress(f'Discovered {len(files)} candidate photos; inspected {count} entries.')
        except PermissionError:
            skipped += 1; complete = False
    if expected is not None: check_directory(path, expected)
    return WalkResult(tuple(sorted(files)), complete, count, skipped,
                      'Discovery complete.' if complete else 'Some folders or entries could not be inspected; results are partial.')


def read_photo(path, *, expected=None, stop=None, minimum_age=0):
    """Stable handle read; no FIFOs, symlinks, reparse points or unbounded growth."""
    check_cancel(stop)
    with checked_stream(path, limit=MAX_BYTES, expected=expected) as (path, stream, before):
        if before.st_size == 0:
            raise ValueError('The photo is empty or still being written.')
        if minimum_age and time.time_ns() - before.st_mtime_ns < minimum_age * 1_000_000_000:
            raise ValueError('The photo is too recent to import yet. Retry after the writer finishes.')
        chunks = []; size = 0
        while True:
            check_cancel(stop); data = stream.read(1024 * 1024)
            if not data: break
            size += len(data)
            if size > MAX_BYTES: raise ValueError('The photo grew past the 64 MiB limit.')
            chunks.append(data)
        if size != before.st_size: raise ValueError('The photo changed while reading. Inspect it again.')
        payload = b''.join(chunks)
    return payload, fingerprint(before)


def _date(value):
    if not isinstance(value, str) or len(value) > 1024: return ''
    match = DATE.search(value)
    if not match: return ''
    try: return datetime(*map(int, match.groups())).isoformat(timespec='seconds')
    except ValueError: return ''


def _open(data):
    try:
        from PIL import Image
    except ImportError as error:
        raise ValueError('The existing Pillow dependency is unavailable. Restart using the normal launcher to repair setup.') from error
    if not isinstance(data, bytes) or not 0 < len(data) <= MAX_BYTES:
        raise ValueError('Photo input must be between 1 byte and 64 MiB.')
    try:
        im = Image.open(BytesIO(data), formats=FORMATS)
        w, h = im.size
        if not 0 < w <= MAX_EDGE or not 0 < h <= MAX_EDGE or w * h > MAX_PIXELS:
            im.close(); raise ValueError('Photo exceeds the 32-megapixel / 16,384-pixel edge limit.')
        if getattr(im, 'n_frames', 1) != 1:
            im.close(); raise ValueError('Animated or multilayer images need separate review; this checkpoint imports single-frame photos only.')
        return im
    except (OSError, SyntaxError, OverflowError, Image.DecompressionBombError) as error:
        raise ValueError('The image is unsupported, incomplete or exceeds decoder limits.') from error


def _metadata(im, name, fp):
    """Retain presence/suggestions only, never raw GPS, embedded text or URLs."""
    fields = sorted(str(k)[:80] for k in im.info)[:64]
    warnings_ = []; dates = []; worlds = set(); text_bytes = 0
    for key, value in list(im.info.items())[:64]:
        if isinstance(value, str):
            encoded = value.encode('utf-8', errors='replace'); text_bytes += len(encoded)
            if len(encoded) <= 65536 and text_bytes <= 262144:
                worlds.update(m.group(0).lower() for m in WORLD.finditer(value))
    has_gps = False
    try:
        exif = im.getexif()
        has_gps = bool(exif.get(34853))
        for key in (36867, 306):
            value = _date(exif.get(key))
            if value: dates.append({'value': value, 'basis': 'EXIF declaration; timezone unknown'})
    except (OSError, ValueError, TypeError, SyntaxError):
        has_gps = None
        warnings_.append('EXIF metadata could not be interpreted; GPS presence is unknown.')
    value = _date(name)
    if value: dates.append({'value': value, 'basis': 'Filename declaration; timezone unknown'})
    if len({item['value'] for item in dates}) > 1:
        warnings_.append('Date declarations disagree; no reliable capture time established.')
    if not dates:
        try: value = datetime.fromtimestamp(fp['mtime_ns'] / 1e9, timezone.utc).isoformat(timespec='seconds')
        except (ValueError, OverflowError, OSError): value = ''
        dates.append({'value': value, 'basis': 'File modified time (UTC); not capture time'})
    if len(worlds) > 8: warnings_.append('Additional world-ID candidates omitted.')
    return {'date': dates[0]['value'], 'date_basis': dates[0]['basis'], 'date_candidates': dates[:3],
            'world_candidates': sorted(worlds)[:8], 'metadata_fields': fields,
            'gps_present': has_gps, 'text_metadata_present': text_bytes > 0,
            'warnings': warnings_, 'visible_content_scan': 'Not performed',
            'privacy_note': 'Metadata checks cannot establish who or what is visible in the image. Review pixels before sharing.'}


def _rgb(im):
    from PIL import Image, ImageOps
    oriented = ImageOps.exif_transpose(im)
    rgba = oriented.convert('RGBA')
    out = Image.new('RGB', rgba.size, 'white')
    out.paste(rgba, mask=rgba.getchannel('A'))
    rgba.close()
    if oriented is not im: oriented.close()
    out.info.clear()
    return out


def inspect_photo(path, *, stop=None, expected=None, minimum_age=0):
    data, fp = read_photo(path, stop=stop, expected=expected, minimum_age=minimum_age)
    check_cancel(stop)
    try:
        with _open(data) as im:
            meta = _metadata(im, Path(path).name, fp)
            with _rgb(im) as rgb:
                size = rgb.size; rgb.thumbnail((220, 160))
                output = BytesIO(); rgb.save(output, 'PNG')
            fmt = im.format
    except (OSError, SyntaxError, TypeError, struct.error) as error:
        raise ValueError('The photo could not be completely decoded; no new record was accepted.') from error
    check_cancel(stop)
    return {'path': str(local_path(path)), 'name': Path(path).name, 'sha256': sha256(data).hexdigest(),
            'fingerprint': fp, 'size': len(data), 'width': size[0], 'height': size[1],
            'format': fmt, 'metadata': meta, 'thumbnail': output.getvalue()}


def verified_data(record, *, stop=None):
    data, fp = read_photo(record['path'], expected=record['fingerprint'], stop=stop)
    if sha256(data).hexdigest() != record['sha256']:
        raise ValueError('The photo bytes changed. Recheck and explicitly import the new version before preview/export.')
    return data


def normalize_recipe(value):
    """Data-only single-image recipe, coordinates before any resize/border."""
    if not isinstance(value, dict) or set(value) - {'crop', 'redactions', 'max_edge', 'border'}:
        raise ValueError('Unsupported photo export settings.')
    crop = value.get('crop'); boxes = value.get('redactions', [])
    edge = value.get('max_edge', 4096); border = value.get('border', 'None')
    def box(b):
        if not isinstance(b, (list, tuple)) or len(b) != 4 or any(type(n) is not int for n in b):
            raise ValueError('Use four whole-pixel coordinates for each rectangle.')
        if not (0 <= b[0] < b[2] <= MAX_EDGE and 0 <= b[1] < b[3] <= MAX_EDGE):
            raise ValueError('Rectangle coordinates are outside the supported range.')
        return list(b)
    if not isinstance(boxes, (list, tuple)) or len(boxes) > 32:
        raise ValueError('Use at most 32 opaque redaction rectangles.')
    if type(edge) is not int or not 256 <= edge <= 8192 or border not in ('None', 'White', 'Dark'):
        raise ValueError('Choose a maximum output edge of 256–8192 and a supported border.')
    return {'crop': box(crop) if crop is not None else None, 'redactions': [box(b) for b in boxes], 'max_edge': edge, 'border': border}


def render(data, recipe=None, *, preview_edge=None):
    """Opaque masks → crop → downscale → border → fresh RGB PNG, no metadata."""
    from PIL import Image, ImageDraw, ImageOps
    recipe = normalize_recipe(recipe or {})
    with _open(data) as im:
        rgb = _rgb(im)
    try:
        w, h = rgb.size
        for rectangle in recipe['redactions'] + ([recipe['crop']] if recipe['crop'] else []):
            if rectangle[2] > w or rectangle[3] > h:
                raise ValueError('A rectangle extends outside the oriented image. Review the source dimensions.')
        draw = ImageDraw.Draw(rgb)
        for x0, y0, x1, y1 in recipe['redactions']:
            draw.rectangle((x0, y0, x1 - 1, y1 - 1), fill='black')
        if recipe['crop']:
            new = rgb.crop(recipe['crop']); rgb.close(); rgb = new
        edge = recipe['max_edge']
        rgb.thumbnail((edge, edge))  # Never upscale the source.
        if recipe['border'] != 'None':
            margin = max(8, min(96, max(rgb.size) // 32))
            new = ImageOps.expand(rgb, margin, fill='white' if recipe['border'] == 'White' else '#242424')
            rgb.close(); rgb = new
        if preview_edge:
            if type(preview_edge) is not int or not 128 <= preview_edge <= 1600:
                raise ValueError('Invalid preview size.')
            rgb.thumbnail((preview_edge, preview_edge))
        rgb.info.clear(); out = BytesIO(); rgb.save(out, 'PNG')
        payload = out.getvalue()
        if len(payload) > MAX_BYTES: raise ValueError('Rendered PNG exceeds the 64 MiB output budget.')
        validate_export(payload)
        return payload
    finally:
        rgb.close()


def validate_export(payload):
    """Check final bytes, not just encoder arguments. Only structural PNG chunks."""
    if not payload.startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('The rendered export is not PNG.')
    import zlib
    at = 8; found_end = False; chunks = []
    while at + 12 <= len(payload):
        n = struct.unpack('>I', payload[at:at+4])[0]; kind = payload[at+4:at+8]
        if kind not in (b'IHDR', b'IDAT', b'IEND') or at + 12 + n > len(payload):
            raise ValueError('Unexpected metadata or malformed data in the final PNG export.')
        if zlib.crc32(payload[at+4:at+8+n]) & 0xffffffff != struct.unpack('>I',payload[at+8+n:at+12+n])[0]:
            raise ValueError('PNG checksum validation failed.')
        chunks.append(kind)
        if (kind==b'IHDR' and (len(chunks)!=1 or n!=13)) or (kind==b'IEND' and n!=0):
            raise ValueError('Invalid structural PNG export.')
        at += n + 12
        if kind == b'IEND': found_end = True; break
    if not found_end or at != len(payload) or chunks[0]!=b'IHDR' or b'IDAT' not in chunks: raise ValueError('Unexpected trailing data in the final PNG export.')


def save_new(path, payload, *, stop=None):
    """Exclusive destination. Never overwrite, and only unlink our own partial file."""
    if not isinstance(payload,bytes) or not 0<len(payload)<=MAX_BYTES:
        raise ValueError('Export payload must be nonempty bytes within the 64 MiB budget.')
    path = assert_no_links(local_path(path)); parent = directory_identity(path.parent)
    check_cancel(stop); descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0), 0o600)
    identity = None
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            identity = os.fstat(stream.fileno())
            for at in range(0, len(payload), 1024 * 1024):
                check_cancel(stop); stream.write(payload[at:at+1024*1024])
            stream.flush(); os.fsync(stream.fileno())
        check_directory(path.parent, parent)
        # Successful publication is recorded even if cancellation arrived after fsync.
        if (path.stat().st_dev, path.stat().st_ino) != (identity.st_dev, identity.st_ino):
            raise ValueError('Export destination changed during saving. Inspect the destination manually.')
    except BaseException:
        try:
            now = path.lstat()
            if identity and (now.st_dev, now.st_ino) == (identity.st_dev, identity.st_ino): path.unlink()
        except OSError: pass
        raise
    return {'sha256': sha256(payload).hexdigest(), 'size': len(payload), 'path': str(path)}


def map_proton_path(value, prefix):
    """An explicit prefix only, C: drive only; no arbitrary dosdevices symlink following."""
    if not isinstance(value, str) or '\x00' in value or len(value) > 4096:
        raise ValueError('Invalid Windows screenshot path.')
    path = PureWindowsPath(value)
    if path.drive.lower() != 'c:' or not path.is_absolute() or '..' in path.parts:
        raise ValueError('Only an absolute C: path is mapped here. Select custom drives or UNC locations manually.')
    from vrchat_paths import prefix_root, resolve_config_path
    prefix_root(prefix)
    return resolve_config_path(value, prefix)


def source_candidates(log_path=None, *, home=None, prefix=None, windows_pictures=None):
    """Suggest only. Nothing is scanned, approved, created or changed."""
    home = Path(home or Path.home()); rows = []; seen = set()
    def add(path, basis, issue=''):
        key = str(path)
        if key in seen: return
        seen.add(key); rows.append({'path': key, 'basis': basis, 'issue': issue})
    if log_path:
        from vrchat_config import read_config
        from vrchat_paths import resolve_config_path
        config = read_config(log_path); field = config['fields'].get('picture_output_folder', {})
        split = config['fields'].get('picture_output_split_by_date', {})
        split_note = ('Month folders declared/defaulted; recursion still needs approval' if split.get('value') is True else
                      'Flat output declared; runtime behavior unverified' if split.get('value') is False else 'Date-folder setting invalid or unknown')
        if field.get('state') == 'Declared':
            try: add(resolve_config_path(field['value'], prefix), 'Configured picture_output_folder · ' + split_note)
            except (OSError, ValueError) as error: add(field['value'], 'Unresolved configured folder', str(error))
        elif config['state'] not in ('Read', 'Missing') or field.get('state') == 'Invalid':
            add('', 'Configured screenshot folder', 'Config could not be interpreted; no verified default or mapping was inferred.')
    pictures = windows_pictures or home / 'Pictures'
    pictures_basis = 'Pictures/VRChat fallback (review actual location)'
    if os.name == 'nt' and windows_pictures is None:
        try:
            from photo_platform import windows_pictures as known_pictures
            pictures = known_pictures()
            pictures_basis = 'Windows current Pictures known folder (location only; not verified)'
        except (OSError, ValueError, AttributeError):
            rows.append({'path': '', 'basis': 'Windows Pictures known folder',
                         'issue': 'Known-folder lookup was unavailable; the fallback below may not match a redirected location.'})
    if os.name != 'nt':
        try:
            config = Path(os.environ.get('XDG_CONFIG_HOME', str(home / '.config'))) / 'user-dirs.dirs'
            with checked_stream(config, limit=65536) as (_, stream, before): text = stream.read(65537).decode('utf-8')
            match = re.search(r'^XDG_PICTURES_DIR="([^"\n]+)"\s*$', text, re.M)
            if match:
                value = match.group(1).replace('${HOME}', str(home)).replace('$HOME', str(home))
                if '$' not in value and '`' not in value:
                    pictures = assert_no_links(local_path(value)); pictures_basis = 'XDG Pictures directory (review actual location)'
        except (OSError, ValueError, UnicodeError): pass
    add(str(Path(pictures) / 'VRChat'), pictures_basis)
    return rows
