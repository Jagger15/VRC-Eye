"""Disposable, account-isolated PNG previews; no URLs, cookies or credentials.

SQLite transactions serialize clear/eviction against writers. Runtime access
bindings are captured on the GUI thread; workers never read Tk privacy flags.
"""
from contextlib import contextmanager
from dataclasses import dataclass
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import sqlite3
import threading
import time

from companion_data import entity_id
from vrchat_api import APIError

KEY='pictures.cache.v1'
LIMITS=(32,64,128,256)
DEFAULTS=dict(enabled=True,limit_mb=128)
MAX_IMAGE=1024*1024
MAX_ROWS=3000
FRESH_SECONDS=24*60*60
KEEP_SECONDS=30*24*60*60


def settings(value):
    if value is None:return dict(DEFAULTS)
    if not isinstance(value,dict) or set(value)!=set(DEFAULTS) or type(value['enabled']) is not bool or type(value['limit_mb']) is not int or value['limit_mb'] not in LIMITS:
        raise ValueError('Choose a picture cache limit of 32, 64, 128 or 256 MiB.')
    return dict(value)


def keys(account,url):
    from profile_images import image_url
    from urllib.parse import urlsplit
    account=entity_id('user',account);url=image_url(url);parts=urlsplit(url)
    if parts.hostname=='api.vrchat.com':url=parts._replace(netloc='api.vrchat.cloud').geturl()
    return sha256(account.encode()).hexdigest(),sha256(url.encode()).hexdigest()


def valid_png(data):
    if not isinstance(data,bytes) or not 1<=len(data)<=MAX_IMAGE:raise ValueError('Invalid cached picture size.')
    from PIL import Image
    try:
        with Image.open(BytesIO(data)) as im:
            if im.format!='PNG' or im.width>600 or im.height>260 or im.width<1 or im.height<1:raise ValueError
            im.load()
    except Exception:raise ValueError('Invalid cached picture.') from None
    return data


class PictureCache:
    def __init__(self,path,*,policy=None,clock=time.time):
        self.path=Path(path);self.policy=settings(policy);self.clock=clock
        self.lock=threading.RLock();self.epoch=0

    @contextmanager
    def connect(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.path.is_symlink():raise OSError('Picture cache must be a regular local database.')
        db=sqlite3.connect(self.path,timeout=.5)
        try:
            db.execute('PRAGMA auto_vacuum=FULL')
            db.execute('PRAGMA secure_delete=ON')
            with db:
                db.execute('CREATE TABLE IF NOT EXISTS previews(account TEXT NOT NULL,key TEXT NOT NULL,data BLOB NOT NULL,bytes INTEGER NOT NULL,saved REAL NOT NULL,used REAL NOT NULL,PRIMARY KEY(account,key))')
                yield db
        finally:db.close()

    def _prune(self,db):
        now=self.clock()
        db.execute('DELETE FROM previews WHERE saved>? OR saved<?',(now,now-KEEP_SECONDS))
        size,count=db.execute('SELECT COALESCE(SUM(bytes),0),COUNT(*) FROM previews').fetchone()
        for account,key,length in db.execute('SELECT account,key,bytes FROM previews ORDER BY used,account,key').fetchall():
            if size<=self.policy['limit_mb']*1024**2 and count<=MAX_ROWS:break
            db.execute('DELETE FROM previews WHERE account=? AND key=?',(account,key));size-=length;count-=1

    def get(self,account,url,*,offline=False,epoch=None):
        account,key=keys(account,url)
        with self.lock:
            if not self.policy['enabled'] or epoch is not None and epoch!=self.epoch or not self.path.exists():return None
            with self.connect() as db:
                row=db.execute('SELECT data,saved FROM previews WHERE account=? AND key=?',(account,key)).fetchone()
                if not row:return None
                age=self.clock()-row[1]
                if not 0<=age<=KEEP_SECONDS:
                    db.execute('DELETE FROM previews WHERE account=? AND key=?',(account,key));return None
                if not offline and age>FRESH_SECONDS:return None
                try:data=valid_png(row[0])
                except ValueError:
                    db.execute('DELETE FROM previews WHERE account=? AND key=?',(account,key));return None
                db.execute('UPDATE previews SET used=? WHERE account=? AND key=?',(self.clock(),account,key))
                return data

    def put(self,account,url,data,*,epoch=None):
        account,key=keys(account,url);valid_png(data)
        with self.lock:
            if not self.policy['enabled'] or epoch is not None and epoch!=self.epoch:return False
            with self.connect() as db:
                now=self.clock()
                db.execute('INSERT INTO previews VALUES(?,?,?,?,?,?) ON CONFLICT(account,key) DO UPDATE SET data=excluded.data,bytes=excluded.bytes,saved=excluded.saved,used=excluded.used',
                    (account,key,data,len(data),now,now))
                self._prune(db)
            return True

    def configure(self,value):
        value=settings(value)
        with self.lock:self.policy=value;self.epoch+=1

    def maintain(self):
        with self.lock:
            if self.path.exists():
                with self.connect() as db:self._prune(db)

    def clear(self,account=None):
        if account is not None:account=sha256(entity_id('user',account).encode()).hexdigest()
        with self.lock:
            self.epoch+=1
            if self.path.exists():
                with self.connect() as db:
                    if account is None:db.execute('DELETE FROM previews')
                    else:db.execute('DELETE FROM previews WHERE account=?',(account,))

    def stats(self):
        with self.lock:
            if not self.path.exists():return dict(count=0,bytes=0,disk_bytes=0)
            with self.connect() as db:count,size=db.execute('SELECT COUNT(*),COALESCE(SUM(bytes),0) FROM previews').fetchone()
            return dict(count=count,bytes=size,disk_bytes=self.path.stat().st_size)


@dataclass(frozen=True)
class Access:
    service: object
    client: object
    token: tuple
    account: str
    revision: int
    epoch: int
    offline: bool
    allowed: bool

    def check(self):
        if (not self.allowed or self.token!=self.service.token or self.epoch!=self.service.cache.epoch
            or self.client is not self.service.app.api or self.client.user_id!=self.account
            or self.client.session_revision!=self.revision or not self.client.authenticated or self.client.closed.is_set()):
            raise APIError('The picture account, privacy or cache settings changed.')


class CacheService:
    def __init__(self,app,store):
        self.app,self.store=app,store
        try:policy=settings(store.option(KEY))
        except (ValueError,TypeError):policy=dict(DEFAULTS)
        self.cache=PictureCache(store.path.with_name('picture-previews.sqlite3'),policy=policy)
        self.token=None

    def sync(self):
        from account_header import boundary,private
        from session_restore import offline
        b=boundary(self.app);hidden=private(self.app);off=offline(self.app)
        self.token=(b,hidden,off,self.cache.epoch)
        c=self.app.api
        if c is not None:
            c.picture_access=Access(self,c,self.token,c.user_id,c.session_revision,self.cache.epoch,off,
                bool(c.authenticated and not hidden and not b[4] and not b[6] and not b[7]))
        return getattr(c,'picture_access',None)

    def configure(self,value):
        value=settings(value);self.store.set_option(KEY,value);self.cache.configure(value);self.sync()
        self.clear_memory()

    def clear_memory(self):
        c=self.app.api
        if c is not None and hasattr(c,'_preview_cache'):
            from profile_images import _CACHE_LOCK
            with _CACHE_LOCK:c._preview_cache.clear()


def service_for(app):
    shell=getattr(app,'sidebar',None)
    if not shell or not hasattr(shell,'store'):return None
    service=getattr(shell,'picture_cache',None)
    if service is None or service.store is not shell.store:
        if service is not None:service.token=None
        service=CacheService(app,shell.store);shell.picture_cache=service
    service.sync();return service
