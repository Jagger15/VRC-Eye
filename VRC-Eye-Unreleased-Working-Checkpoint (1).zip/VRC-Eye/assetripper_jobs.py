"""Explicit local AssetRipper jobs over its inspected web-command contract.

No tool is downloaded, selected or launched at startup. An installed binary's
identity is evidence of unchanged local bytes, not publisher authentication.
Official interface: Source/AssetRipper.GUI.Web/{Arguments,WebApplicationLauncher}.cs
Native release qualification remains separate from fixture protocol coverage.
"""
from collections import deque
from dataclasses import dataclass,field
from hashlib import sha256
from http.client import HTTPConnection
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import threading
import time
from urllib.parse import urlencode
import uuid

from avatar_library_files import checked_stream,inspect_file,check_cancel,InspectionCancelled,fingerprint
import avatar_recovery_provider as recovery
from creator_projects import assert_no_links,local_path
from native_library import scope
import assetripper_installation as installation

BOOT=str(uuid.uuid4())
COMMANDS=('/LoadFile','/Export/UnityProject')
DOC_PATHS=('/openapi.json','/openapi/v1.json','/swagger/v1/swagger.json','/Documentation/OpenApi.json')
MAX_REPLY=2*1024**2
MAX_RSS=4*1024**3
MAX_CHILDREN=64
RESOURCE_INTERVAL=1.0


def resource_limits():
    return dict(process_seconds=600,aggregate_rss_bytes=MAX_RSS,tracked_descendants=MAX_CHILDREN,
                output_bytes=recovery.MAX_TREE_BYTES,output_entries=recovery.MAX_ENTRIES,
                provider_log_bytes=8*1024**2,output_poll_seconds=RESOURCE_INTERVAL,
                enforcement='Observed limits; not OS quotas or filesystem/network containment')


@dataclass(frozen=True)
class Tool:
    path:str=field(repr=False)
    sha256:str
    size:int
    fingerprint:dict=field(repr=False)
    platform:str
    installation:tuple=field(repr=False,default=())

    def summary(self):
        evidence=installation.evidence(self.installation)
        notices='; '.join(evidence['license_notice_files']) or 'None observed'
        return (f'Executable: {self.path}\nSHA-256: {self.sha256}\nFormat: {self.platform}\n'
            f'Installation: {len(self.installation)} pinned files · SHA-256 {evidence["sha256"]}\nLicense/notice filenames: {notices}\n'
            'Local bytes and dependencies recorded; publisher, license entitlement and installed release version are not authenticated. '
            'System dependencies are outside this snapshot. The running API must pass a compatibility probe.')


def inspect_tool(value,*,stop=None,progress=None):
    path=assert_no_links(local_path(value))
    evidence=inspect_file(path,stop=stop,progress=progress)
    with checked_stream(path) as (_,stream,info):
        magic=stream.read(4)
        if magic.startswith(b'MZ'):platform='Windows PE'
        elif magic==b'\x7fELF':platform='Linux ELF'
        else:raise ValueError('Choose the native AssetRipper executable, not a shortcut, script, DLL or archive.')
        if os.name=='nt' and platform!='Windows PE' or os.name!='nt' and platform!='Linux ELF':
            raise ValueError('Choose an AssetRipper executable for this operating system.')
        if os.name!='nt' and not info.st_mode&0o111:raise ValueError('The selected native tool is not executable.')
        if fingerprint(info)!=evidence['fingerprint']:raise ValueError('The executable changed during inspection.')
    entries=installation.inspect(path,stop=stop,progress=progress)
    selected=next((item for item in entries if item.path==path.name),None)
    if selected is None or selected.sha256!=evidence['sha256'] or dict(selected.identity)!=evidence['fingerprint']:
        raise ValueError('The executable changed while inspecting its installation. Inspect again.')
    return Tool(str(path),evidence['sha256'],evidence['size'],evidence['fingerprint'],platform,entries)


def contract(document):
    """Accept only declared single-path form commands; never infer write routes."""
    if not isinstance(document,dict) or not str(document.get('openapi','')).startswith('3.'):
        raise ValueError('This tool did not publish a supported OpenAPI 3 contract.')
    def resolved(item):
        for _ in range(8):
            if not isinstance(item,dict):raise ValueError('Invalid API schema.')
            if '$ref' not in item:return item
            ref=item['$ref']
            if not isinstance(ref,str) or not ref.startswith('#/components/'):raise ValueError('Only local API schema references are supported.')
            item=document
            for part in ref[2:].split('/'):
                item=item.get(part.replace('~1','/').replace('~0','~'),{}) if isinstance(item,dict) else {}
        raise ValueError('Recursive API schema is unsupported.')
    result={}
    for path in COMMANDS:
        operation=document.get('paths',{}).get(path,{}).get('post',{})
        if operation.get('security',document.get('security')) or '302' not in operation.get('responses',{}):
            raise ValueError('The installed command contract differs from the supported local API.')
        content=resolved(operation.get('requestBody',{})).get('content',{})
        for media in ('application/x-www-form-urlencoded','multipart/form-data'):
            if media not in content:continue
            schema=resolved(content[media].get('schema',{}));properties=schema.get('properties',{})
            fields=[key for key,value in properties.items() if key.casefold()=='path' and resolved(value).get('type')=='string']
            if len(fields)!=1 or any(key not in fields for key in schema.get('required',[])):
                continue
            result[path]=(media,fields[0]);break
        if path not in result:raise ValueError('The tool must declare a single string path form for loading and Unity export. No command was submitted.')
    return result


def command_body(media,key,path):
    path=str(path)
    if any(ord(c)<32 for c in path):raise ValueError('Control characters in a tool path are unsupported.')
    if media=='application/x-www-form-urlencoded':return media,urlencode({key:path}).encode()
    boundary='VrcEye'+uuid.uuid4().hex
    body=f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{path}\r\n--{boundary}--\r\n'.encode()
    return 'multipart/form-data; boundary='+boundary,body


class OwnedServer:
    """Only talks to the loopback listener owned by this exact child process.

    Cancellation closes the connection and stops identified child processes.
    This is lifecycle control, not an operating-system sandbox for the exporter.
    """
    def __init__(self,tool,folder,*,stop,guard,progress):
        import psutil
        self.stop,self.guard,self.progress=stop,guard,progress
        self.deadline=time.monotonic()+600;self.port=None;self.tail=bytearray();self.lock=threading.Lock();self.connection=None
        self.log=Path(folder)/'AssetRipper.log'
        self.output=Path(folder)/'RecoveredProject';self.next_resource_scan=0.0
        self.resources=dict(samples=0,peak_rss_bytes=0,peak_output_bytes=0,peak_output_entries=0)
        self.process=subprocess.Popen([tool.path,'--headless','--port','0','--log-path',str(self.log)],
            cwd=str(folder),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
            env=installation.environment(folder),close_fds=True,
            shell=False,start_new_session=os.name!='nt',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0)
        self.owner=None;self.descendants={};self.creation=None
        try:
            self.owner=psutil.Process(self.process.pid);self.creation=self.owner.create_time()
            self.reader=threading.Thread(target=self.drain,daemon=True,name='VRC-Eye-recovery-log');self.reader.start()
            end=time.monotonic()+30
            while time.monotonic()<end:
                self.check()
                ports=self.ports()
                if len(ports)==1:self.port=next(iter(ports));break
                if len(ports)>1:raise ValueError('The selected tool exposed multiple listeners; it was stopped without loading input.')
                threading.Event().wait(.1)
            if not self.port:raise ValueError('No owned loopback AssetRipper listener appeared within 30 seconds.')
        except BaseException:
            self.close();raise

    def drain(self):
        while True:
            try:block=self.process.stdout.read1(2048)
            except (OSError,ValueError):break
            if not block:break
            with self.lock:
                self.tail.extend(block)
                if len(self.tail)>65536:del self.tail[:-65536]

    def logs(self):
        with self.lock:value=bytes(self.tail).decode('utf-8','replace')
        return re.sub(r'https?://\S+','[URL omitted]',re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',value))[-16000:]

    def check(self,*,force_resources=False):
        import psutil
        check_cancel(self.stop);self.guard()
        if time.monotonic()>self.deadline:raise ValueError('Recovery exceeded its ten-minute process budget; inspect retained output before retrying.')
        if self.process.poll() is not None:raise ValueError('AssetRipper exited before the command sequence finished. Inspect its retained log.')
        if self.owner.create_time()!=self.creation:raise ValueError('The recovery process identity changed.')
        for child in self.owner.children(recursive=True):
            try:self.descendants[child.pid]=(child,child.create_time())
            except psutil.NoSuchProcess:continue
            if len(self.descendants)>MAX_CHILDREN:raise ValueError('The provider exceeded its 64 tracked-child budget; recovery stopped.')
        try:
            rss=self.owner.memory_info().rss
            for child,created in tuple(self.descendants.values()):
                try:
                    if child.create_time()!=created:raise ValueError('A tracked recovery child process changed identity.')
                    rss+=child.memory_info().rss
                except psutil.NoSuchProcess:continue
        except psutil.Error as error:raise ValueError('Recovery memory usage could not be verified; recovery stopped.') from error
        self.resources['peak_rss_bytes']=max(self.resources['peak_rss_bytes'],rss)
        if rss>MAX_RSS:raise ValueError('The provider exceeded its 4 GiB observed memory budget; recovery stopped.')
        try:
            assert_no_links(self.log);info=self.log.lstat()
            if not stat.S_ISREG(info.st_mode):raise ValueError('The provider log is not a regular file.')
            if info.st_size>8*1024**2:raise ValueError('The provider log exceeded its 8 MiB budget; recovery stopped.')
        except FileNotFoundError:pass
        if force_resources or time.monotonic()>=self.next_resource_scan:
            self.check_output();self.next_resource_scan=time.monotonic()+RESOURCE_INTERVAL

    def check_output(self):
        """Bound ongoing exports, retaining partial output when a limit is observed.

        Polling cannot prevent writes between samples or outside the output folder.
        It is deliberately not described as a sandbox or an atomic disk quota.
        """
        entries=total=0;pending=[self.output]
        assert_no_links(self.output)
        try:info=self.output.lstat()
        except FileNotFoundError:return
        if not stat.S_ISDIR(info.st_mode):raise ValueError('The provider output is not a regular directory.')
        while pending:
            folder=pending.pop();assert_no_links(folder)
            with os.scandir(folder) as iterator:
                for child in iterator:
                    check_cancel(self.stop);self.guard()
                    if time.monotonic()>self.deadline:raise ValueError('Recovery exceeded its ten-minute process budget during output inspection.')
                    entries+=1
                    self.resources['peak_output_entries']=max(self.resources['peak_output_entries'],entries)
                    if entries>recovery.MAX_ENTRIES:raise ValueError('The provider exceeded its 20,000 output-entry budget; recovery stopped.')
                    assert_no_links(Path(child.path));info=child.stat(follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):pending.append(Path(child.path))
                    elif stat.S_ISREG(info.st_mode):
                        total+=info.st_size
                        self.resources['peak_output_bytes']=max(self.resources['peak_output_bytes'],total)
                        if total>recovery.MAX_TREE_BYTES:raise ValueError('The provider exceeded its 8 GiB observed output budget; recovery stopped.')
                    else:raise ValueError('The provider created a link or special output file; recovery stopped.')
        self.resources['samples']+=1

    def resource_evidence(self):return dict(limits=resource_limits(),observed=dict(self.resources))

    def ports(self):
        import psutil
        self.check()
        listeners=[item for item in self.owner.net_connections(kind='tcp') if item.status==psutil.CONN_LISTEN]
        if any(item.laddr.ip!='127.0.0.1' for item in listeners):raise ValueError('The selected tool did not restrict its listener to IPv4 loopback.')
        return {item.laddr.port for item in listeners}

    def request(self,method,path,body=None,media=None):
        if path not in (*DOC_PATHS,*COMMANDS):raise ValueError('Unsupported recovery endpoint.')
        if self.ports()!={self.port}:raise ValueError('The local recovery listener changed ownership.')
        connection=HTTPConnection('127.0.0.1',self.port,timeout=600);self.connection=connection
        done=threading.Event();result=[]
        def send():
            try:
                headers={'Accept':'application/json','Connection':'close'}
                if media:headers['Content-Type']=media
                connection.request(method,path,body=body,headers=headers)
                response=connection.getresponse();data=response.read(MAX_REPLY+1)
                if len(data)>MAX_REPLY:raise ValueError('The local provider response exceeded 2 MiB.')
                result.append((response.status,response.getheader('Location',''),data))
            except Exception:result.append(None)
            finally:connection.close();done.set()
        worker=threading.Thread(target=send,daemon=True,name='VRC-Eye-recovery-request');worker.start()
        try:
            while not done.wait(.1):self.check()
            self.check(force_resources=True)
            if not result or result[0] is None:raise ValueError('Local recovery request failed; it will not be repeated automatically.')
            return result[0]
        finally:
            connection.close();self.connection=None

    def discover(self):
        for path in DOC_PATHS:
            status,location,raw=self.request('GET',path)
            if status!=200:continue
            try:
                document=json.loads(raw);spec=contract(document)
                info=document.get('info',{})
                self.api_evidence=dict(schema_path=path,schema_sha256=sha256(raw).hexdigest(),
                    declared_title=str(info.get('title',''))[:160],declared_api_version=str(info.get('version',''))[:80],
                    installed_release_version_verified=False)
                return spec
            except (ValueError,TypeError,KeyError):continue
        raise ValueError('This installation did not expose the supported OpenAPI path forms. No load or export command was submitted. Use the manual handoff.')

    def command(self,path,value,spec):
        media,body=command_body(*spec,str(value))
        status,location,_=self.request('POST',path,body,media)
        if status!=302 or location not in ('/',f'http://127.0.0.1:{self.port}/'):
            raise ValueError('The local command did not return its declared completion redirect. Output remains unverified; no automatic retry.')

    def close(self):
        if self.connection:self.connection.close()
        import psutil
        root_owned=False;unconfirmed=False
        if self.owner:
            try:
                if self.owner.create_time()==self.creation:
                    root_owned=True
                    for child in self.owner.children(recursive=True):self.descendants[child.pid]=(child,child.create_time())
            except psutil.NoSuchProcess:pass
            except psutil.Error:unconfirmed=True
        owned=list(self.descendants.values())+([(self.owner,self.creation)] if self.owner else [])
        if os.name!='nt' and root_owned and self.process.poll() is None:
            try:os.killpg(self.process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        survivors=[]
        for process,created in reversed(owned):
            try:
                if process.create_time()==created:process.kill();survivors.append(process)
            except psutil.NoSuchProcess:pass
            except psutil.Error:unconfirmed=True
        # Popen retains the actual process handle on Windows.
        if self.process.poll() is None:self.process.kill()
        self.process.wait(timeout=5)
        if hasattr(self,'reader'):self.reader.join(timeout=1)
        if self.process.stdout:self.process.stdout.close()
        _,alive=psutil.wait_procs(survivors,timeout=5)
        if unconfirmed or any(p.is_running() and p.status()!=psutil.STATUS_ZOMBIE for p in alive):raise ValueError('Recovery process shutdown could not be verified; do not open the output yet.')


class Jobs:
    def __init__(self,store,*,server_factory=OwnedServer):
        self.store=store;self.factory=server_factory;self.preparation=recovery.PreparationService();self.plans={};self.lock=threading.Lock()
        with store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS recovery_jobs_dev16(scope TEXT NOT NULL,id TEXT NOT NULL,updated REAL NOT NULL,data TEXT NOT NULL,PRIMARY KEY(scope,id))')

    def rows(self,account):
        with self.store.connect() as db:
            rows=[json.loads(r[0]) for r in db.execute('SELECT data FROM recovery_jobs_dev16 WHERE scope=? ORDER BY updated DESC LIMIT 100',(scope(account),))]
        for row in rows:
            if row['state']=='Running' and row['boot']!=BOOT:row['state']='Interrupted; inspect output before a new job'
        return rows

    def save(self,row):
        with self.store.connect() as db:
            db.execute('INSERT INTO recovery_jobs_dev16 VALUES(?,?,?,?) ON CONFLICT(scope,id) DO UPDATE SET updated=excluded.updated,data=excluded.data', (row['account'],row['id'],time.time(),json.dumps(row,allow_nan=False)))

    def prepare(self,tool,source,destination,avatar,account):
        if not isinstance(tool,Tool):raise ValueError('Inspect the installed native AssetRipper executable first.')
        account=scope(account)
        prepared=self.preparation.prepare(source,destination,avatar)
        with self.lock:self.plans[prepared.identity]=(prepared,tool,account)
        return prepared

    def discard(self,plan):
        self.preparation.discard(plan)
        with self.lock:self.plans.pop(plan.identity,None)

    def clear(self):
        self.preparation.clear()
        with self.lock:self.plans.clear()

    def run(self,plan,*,guard,stop=None,progress=None):
        with self.lock:value=self.plans.pop(plan.identity,None)
        if not value or value[0] is not plan:raise ValueError('Recovery review was used or cleared.')
        _,tool,account=value;check_cancel(stop);guard()
        if inspect_tool(tool.path,stop=stop)!=tool:raise ValueError('The selected executable or installation dependencies changed. Inspect and review again.')
        folder=Path(plan.destination);output=folder/'RecoveredProject'
        row=dict(id=plan.identity,account=account,boot=BOOT,state='Running',avatar=plan.avatar,
                 destination=str(folder),output=str(output),tool_sha256=tool.sha256,source_sha256=plan.source.digest,
                 log=[],provider_log='',inventory=None,resource_limits=resource_limits(),
                 installation_evidence=installation.evidence(tool.installation),
                 qualification='Native AssetRipper release not qualified by VRC Eye')
        server=None
        def phase(value):
            check_cancel(stop);guard();row['log'].append(value);self.save(row)
            if progress:progress(value)
            check_cancel(stop);guard()
        try:
            phase('Staging the reviewed input into a new folder')
            self.preparation.execute(plan,stop=stop,progress=progress,context_check=guard)
            phase('Verified input staged; starting reviewed executable')
            if inspect_tool(tool.path,stop=stop)!=tool:raise ValueError('The executable or installation dependencies changed while input was staged. Review again.')
            server=self.factory(tool,folder,stop=stop,guard=guard,progress=progress)
            phase('Checking the owned local API contract');spec=server.discover()
            row['api_evidence']=getattr(server,'api_evidence',{})
            phase('Loading the verified input bundle');server.command('/LoadFile',folder/'input.bundle',spec['/LoadFile'])
            phase('Exporting into the new RecoveredProject folder');server.command('/Export/UnityProject',output,spec['/Export/UnityProject'])
            row['provider_log']=server.logs();row['resource_evidence']=getattr(server,'resource_evidence',lambda:{})()
            server.close();server=None
            phase('Exporter stopped; inspecting output and dependencies')
            inventory=recovery.inspect_output(output,handoff=folder,stop=stop,progress=progress)
            if not inventory['files']:raise ValueError('The exporter returned without regular output files. No recovered project was confirmed.')
            files=[];evidence_rows=[];entries=0;total=0
            for path in output.rglob('*'):
                entries+=1
                if entries>recovery.MAX_ENTRIES:raise ValueError('Output grew beyond the inventory limit.')
                check_cancel(stop);guard();assert_no_links(path)
                if path.is_file():
                    evidence=inspect_file(path,stop=stop)
                    total+=evidence['size']
                    if total>recovery.MAX_TREE_BYTES:raise ValueError('Output grew beyond the byte inventory limit.')
                    evidence_rows.append((path,evidence['fingerprint']))
                    files.append(dict(path=path.relative_to(output).as_posix(),size=evidence['size'],sha256=evidence['sha256']))
            if len(files)!=inventory['files']:raise ValueError('Output changed during hashing. Inspect the retained output again.')
            for path,before in evidence_rows:
                check_cancel(stop);guard();assert_no_links(path)
                if fingerprint(path.stat())!=before:raise ValueError('Output changed after hashing. Inspect it again.')
            files.sort(key=lambda r:r['path'])
            recovery._write_new(folder/'output-inventory.json',dict(schema=1,files=files),stop=stop,before_commit=guard)
            inventory['manifest_sha256']=sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()
            inventory['derivation']='Observed command sequence from this verified input; recovery quality and original source completeness are unverified.'
            inventory['limits']='Extension-based inventory and declared dependencies only. The preceding reviewed job ran AssetRipper; this inspection did not execute scripts or Unity. Original source completeness, material/mesh quality, unresolved references and build compatibility remain unverified.'
            row.update(state='Exported; review inventory' if not inventory['missing_project_entries'] else 'Partial export; review missing project entries',inventory=inventory)
            recovery._write_new(folder/'recovery-run.json',row,stop=stop,before_commit=guard)
            self.save(row);return row
        except Exception:
            row.update(state='Stopped; inspect retained output before retrying')
            raise
        finally:
            if server:
                row['provider_log']=server.logs()
                row['resource_evidence']=getattr(server,'resource_evidence',lambda:{})()
                try:server.close()
                except Exception:row['log'].append('Process shutdown could not be confirmed. Check the launched process before handling output.')
            if not row['state'].startswith(('Exported','Partial')):row['log'].append('No completed recovery was confirmed. Staged input and any partial export were preserved.')
            self.save(row)
