"""Home cards reuse current observations; layouts never create collectors."""
import time
from customization import WIDGETS,load


class HomeDashboard:
    def __init__(self,page,parent):
        self.page,self.app=page,page.app
        self.frame=page.ttk.Frame(parent);self.frame.pack(fill='both',expand=True)
        self.cards=[];self.values={};self.layout=None;self.started=None;self.session_pause=False
        self.frame.bind('<Configure>',self.arrange)
        self.rebuild(load(self.app))

    def rebuild(self,settings=None):
        from dashboard_conditions import facts,resolve
        settings=settings or load(self.app);resolved=resolve(settings,facts(self.app),paused=self.session_pause)
        editor=getattr(getattr(self.app,'experience',None),'layout_editor',None)
        if editor:resolved=editor.resolve(settings,resolved)
        self.condition_signature=repr(resolved);self.active_name=resolved['name']
        for child in self.frame.winfo_children():child.destroy()
        self.cards=[];self.values={};self.tables={}
        self.layout=resolved['rows']
        header=self.page.ttk.Frame(self.frame);header.grid(row=0,column=0,columnspan=3,sticky='ew',pady=8)
        self.header=header
        header.columnconfigure(0,weight=1)
        self.layout_title=self.page.tk.StringVar()
        self.page.ttk.Label(header,textvariable=self.layout_title,style='Heading.TLabel',wraplength=650).grid(row=0,column=0,sticky='w')
        self.page.ttk.Button(header,text='Customize Home…',command=lambda:self.page.shell.show('Customization')).grid(row=0,column=1,sticky='e')
        self.sync_status=self.page.tk.StringVar()
        self.page.ttk.Label(header,textvariable=self.sync_status,wraplength=650).grid(row=1,column=0,columnspan=2,sticky='w',pady=5)
        self.rule_status=self.page.tk.StringVar()
        self.page.ttk.Label(header,textvariable=self.rule_status,wraplength=650).grid(row=2,column=0,columnspan=2,sticky='w',pady=5)
        from companion_ui import button,choice
        from friendly_ui import flow_line
        container=self.page.ttk.Frame(self.frame);container.grid(row=1,column=0,columnspan=3,sticky='ew')
        controls=flow_line(self.page,container)
        self.profile_controls=container;self.manual_layout=self.page.tk.StringVar(value=self.active_name)
        self.manual_choice=choice(self.page,controls,self.manual_layout,tuple(settings['layouts']),width=20)
        self.hold_button=button(self.page,controls,'Hold this layout',self.hold_layout)
        button(self.page,controls,'Clear manual override',self.resume)
        button(self.page,controls,'Resume saved selection' if self.session_pause else 'Use fallback this session',self.toggle_pause)
        button(self.page,controls,'Search all local records…',self.search_library)
        if editor:editor.toolbar(self,container)
        if not self.layout:
            self.page.ttk.Label(self.frame,text='No widgets match this view. Customize Home to adjust visibility conditions.',wraplength=650).grid(row=2,column=0,sticky='w',padx=8,pady=12)
        for row in sorted(self.layout,key=lambda r:not r['pinned']):
            box=self.page.ttk.Frame(self.frame,style='Card.TFrame',padding=16)
            self.page.ttk.Label(box,text=WIDGETS.get(row['kind'],'Unavailable widget: '+row['kind'])+(' · Pinned' if row['pinned'] else ''),style='CardTitle.TLabel').pack(anchor='w')
            self.cards.append((row,box))
            if editor:editor.handles(self,box,row)
            if row['collapsed']:continue
            from dashboard_rows import TABLE_KINDS
            if row['kind'] in TABLE_KINDS:
                from dashboard_table import DashboardTable
                self.tables[row['id']]=(row,DashboardTable(self,box,row));self.actions(row,box);continue
            var=self.page.tk.StringVar();self.values[row['id']]=(row,var)
            self.page.ttk.Label(box,textvariable=var,style='CardValue.TLabel' if row['kind'] in ('session','activity','account','timer') else 'Card.TLabel',wraplength=260,justify='left').pack(anchor='w',fill='x',pady=(8,12))
            self.actions(row,box)
        self.arrange();self.tick()

    def search_library(self):
        from native_data_ui import show
        from account_header import private
        if private(self.app):raise ValueError('Reveal private information before searching local records.')
        dialog=show(self.page.shell);dialog.ready()
        client=getattr(self.app,'api',None)
        dialog.workspace.set('Current account' if client and client.authenticated else 'Shared local library')
        dialog.record_kind.set('All records');dialog.tabs.select(dialog.history_frame);dialog.browse(0)

    def hold_layout(self):
        from customization import save
        from dashboard_conditions import defaults
        value=load(self.app);before=__import__('copy').deepcopy(value);name=self.manual_layout.get()
        if name not in value['layouts']:raise ValueError('That Home layout was removed. Refresh Home.')
        value.setdefault('conditions',defaults())['override']=name
        self.session_pause=False
        save(self.app,value,'Manual Home layout held until resumed',expected=before)

    def resume(self):
        from customization import save
        from dashboard_conditions import defaults
        value=load(self.app);before=__import__('copy').deepcopy(value);value.setdefault('conditions',defaults())['override']=''
        self.session_pause=False
        save(self.app,value,'Manual Home override cleared',expected=before)

    def toggle_pause(self):
        self.session_pause=not self.session_pause;self.rebuild()

    def actions(self,row,box):
        def action(label,fn):self.page.ttk.Button(box,text=label,command=lambda:self.page.guard(fn)).pack(anchor='w',pady=3)
        kind=row['kind'];shell=self.page.shell
        routes={'session':'Primary','activity':'Primary','account':'Accounts','performance':'Performance & Security',
                'eye':'VRC Eye Primary','media':'Media & Audio','photos':'Photos','worlds':'Favorites',
                'tasks':'Creator Projects','events':'Social','downloads':'SDK Downloads','inbox':'Social','health':'VRCX Companion',
                'history':'Feed','presence':'VRCX Companion','runtime':'Unity Player','diagnostics':'Crash & Diagnostics',
                'applications':'Performance & Security','gamelog':'Game Log'}
        if kind in routes:action('Open '+WIDGETS[kind].lower(),lambda:shell.show(routes[kind]))
        if kind=='shortcuts':
            for name,page in (('Players','Primary'),('Search','Search'),('Networking','Networking'),('Wellness','Wellness')):
                action(name,lambda p=page:shell.show(p))
        elif kind=='notes':action('Edit note…',lambda:self.edit_note(row))
        elif kind=='timer':
            action('Start / restart timer',self.start_timer);action('Stop timer',self.stop_timer)

    def start_timer(self):self.started=time.monotonic();self.tick()
    def stop_timer(self):self.started=None;self.tick()

    def note_key(self,row):
        from avatar_library import active_scope
        return 'ui.dashboard.note.'+active_scope(self.app)+'.'+row['id']

    def edit_note(self,row):
        from account_actions import local_writable
        from account_header import private
        from tkinter import simpledialog
        local_writable(self.app)
        if private(self.app):raise ValueError('Reveal private information before editing your note.')
        token=self.page.context();key=self.note_key(row)
        text=simpledialog.askstring('Quick note','Note (up to 2,000 characters)',initialvalue=self.page.shell.store.option(key,''),parent=self.app.root)
        if text is None:return
        if token!=self.page.context() or private(self.app):raise ValueError('Account or privacy changed. The note was not saved.')
        if len(text)>2000:raise ValueError('Keep the note under 2,000 characters.')
        self.page.shell.store.set_option(key,text);self.tick()

    def arrange(self,event=None):
        width=event.width if event else self.frame.winfo_width();columns=max(1,min(3,width//320))
        for old in range(2,getattr(self,'last_layout_row',2)+1):self.frame.rowconfigure(old,minsize=0)
        scale=getattr(getattr(self.app,'experience',None),'preferences',__import__('ui_preferences').Presentation()).font_percent/100
        minimums={}
        for n in range(3):self.frame.columnconfigure(n,weight=1 if n<columns else 0,minsize=0,uniform='cards' if n<columns else '')
        self.header.grid_configure(columnspan=columns)
        self.profile_controls.grid_configure(columnspan=columns)
        y=2;x=0
        for row,box in self.cards:
            span=min(columns,row.get('span',0) or (columns if row['size']=='Wide' else 1))
            if x+span>columns:y+=1;x=0
            box.grid(row=y,column=x,columnspan=span,sticky='nsew',padx=6,pady=6)
            minimums[y]=max(minimums.get(y,0),round(row.get('height',0)*scale))
            for child in box.winfo_children():
                if child.winfo_class()=='TLabel':child.configure(wraplength=max(180,(max(width,320)//columns)*span-60))
            x+=span
            if x>=columns:y+=1;x=0
        for row,height in minimums.items():self.frame.rowconfigure(row,minsize=height)
        self.last_layout_row=y

    def tick(self):
        from dashboard_conditions import facts,resolve
        settings=load(self.app);resolved=resolve(settings,facts(self.app),paused=self.session_pause)
        editor=getattr(getattr(self.app,'experience',None),'layout_editor',None)
        if editor:resolved=editor.resolve(settings,resolved)
        if repr(resolved)!=getattr(self,'condition_signature',None):
            self.rebuild(settings);return
        from account_header import private
        hidden=private(self.app)
        self.layout_title.set('Home' if hidden else resolved['name']+' · '+resolved['reason'])
        self.rule_status.set(str(len(settings['layouts'][resolved['name']])-len(resolved['rows']))+' widgets hidden by conditions or layout choices'+(' · Temporary fallback active' if self.session_pause else ''))
        self.manual_choice.configure(values=() if hidden else tuple(settings['layouts']),state='disabled' if hidden else 'readonly')
        self.hold_button.configure(state='disabled' if hidden else 'normal')
        if hidden:self.manual_layout.set('')
        elif not self.manual_layout.get():self.manual_layout.set(self.active_name)
        from automatic_sync import sync_for
        self.sync_status.set(sync_for(self.page.shell).summary())
        desktop=getattr(self.page.shell,'desktop_service',None)
        projection=desktop.snapshot() if desktop else {}
        from dashboard_actions import freshness,workspace
        from session_restore import offline
        hidden=hidden or bool(projection and projection.get('account')!=workspace(self.app))
        if not hidden:self.sync_status.set(self.sync_status.get()+' · '+freshness(projection,offline=offline(self.app)))
        for row,table in self.tables.values():
            table.update(projection.get('widgets',{}).get(row['kind'],[]),hidden=hidden,
                coverage=projection.get('coverage_by_widget',{}).get(row['kind'],'Retained observations'))
        for row,var in self.values.values():
            kind=row['kind'];value=''
            if kind=='session':value=self.page.session_value.get()
            elif kind=='activity':value=self.page.events_value.get()
            elif kind=='account':value=self.page.account_value.get()
            elif kind=='notes':value='Private note hidden' if hidden else self.page.shell.store.option(self.note_key(row),'Write a note for this account.')
            elif kind=='timer':
                elapsed=int(time.monotonic()-self.started) if self.started is not None else 0
                value=f'{elapsed//3600:02}:{elapsed//60%60:02}:{elapsed%60:02}' if self.started is not None else 'Timer stopped'
            elif kind=='performance':
                p=self.page.shell.pages.get('Performance & Security');snap=p.service.snapshot() if p else None
                if snap and not snap['stale']:
                    from resource_core import format_value
                    value='RAM available: '+format_value('ram.available',snap['sample'].get('ram.available'))+'\nCPU: '+format_value('cpu.system',snap['sample'].get('cpu.system'))
                else:value='Waiting for a current resource sample'
            elif kind=='eye':value=self.app.peer_service.snapshot().get('state','Private')
            elif kind=='shortcuts':value='Your everyday tools'
            elif kind=='health':
                state=projection.get('service',{});data=state.get('data') or {}
                value=data.get('description','Official status not requested')+(' · stale / unknown' if state.get('stale',True) else '')
            elif kind=='presence':value=projection.get('discord','Presence disabled')
            elif kind=='media':value=projection.get('media','No fresh media observation')
            elif kind=='inbox':
                from native_events import hub_for
                rows=hub_for(self.page.shell).project()['notifications'];query=row.get('filter','').casefold()
                rows=[r for r in rows if not r.get('deleted') and (not query or query in (r.get('message','')+' '+r.get('type','')+' '+r.get('senderUsername','')).casefold())]
                fields={'name':'senderUsername','type':'type','time':'reported_time','status':'seen','source':'api_family'}
                selected=row.get('columns') or ['name','type']
                value=f'{len(rows)} observed notifications\n'+'\n'.join(' · '.join(str(r.get(fields[k],'')) for k in selected) for r in rows[-3:])
            elif kind=='history':value=str(projection.get('counts',{}).get('event',0))+' retained events\n'+projection.get('coverage','No current coverage')
            elif kind=='worlds':value=str(projection.get('counts',{}).get('collection',0))+' saved local collections'
            else:value={'photos':'Your local photo library','tasks':'Creator checklists and tasks','events':'Events and social activity','downloads':'SDK, VCC and Unity downloads'}.get(kind,'Unavailable in this version. This saved widget is retained and can be removed or replaced.')
            from dashboard_rows import render
            projected=projection.get('widgets',{})
            if kind in projected:value=render(projected[kind],row)
            elif kind!='inbox' and (row.get('filter') or row.get('columns')):
                value=render([dict(name=text,type=WIDGETS.get(kind,kind),time='',status='',source='Current display') for text in value.splitlines()],row)
            if hidden and kind in ('media','inbox','history','worlds','presence'):value='Private information hidden'
            if row['size']=='Compact':value=value.split('\n')[0][:120]
            if var.get()!=value:var.set(value)
