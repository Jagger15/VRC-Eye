"""Session tools coordinate existing owners; they do not grant output permissions."""
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import queue
import time
import uuid

from account_header import boundary, private
from mod_workflows import Cards, Composer, Costs, DESKTOP_KEYS, PRESETS, preset_changes, redact_activity


def presentation_due(app, key, seconds=.25):
    owner=getattr(getattr(app,'sidebar',None),'session_tools',None)
    if owner is None:return True
    interval=max(seconds,2 if owner.efficient and app.root.state() in ('iconic','withdrawn') else 0)
    now=time.monotonic()
    if now-owner.paint_times.get(key,-1e30)<interval:return False
    owner.paint_times[key]=now;return True


class SessionTools:
    def __init__(self,shell):
        self.shell,self.app,self.store=shell,shell.app,shell.store
        self.context=None;self.epoch=0;self.blocked=True;self.closed=False
        self.costs=Costs();self.paint_times={};self.dialog=None;self.pin=None
        self.activity=deque(maxlen=200);self.activity_queue=queue.Queue(maxsize=200)
        self.health_history=deque(maxlen=100);self.health_last={};self.health_checked=0
        self.client=None;self.sink=None;self.composer=None;self.speech=None
        self.return_plan=None;self.intermission=None;self.log_cursor=None;self.log_context=None
        self.event_clip=None;self.event_enabled=False;self.last_event=-1e30
        self.efficient=bool(self.store.option('workflow.efficient',True));self.sync()

    def sync(self):
        state=(boundary(self.app),private(self.app))
        blocked=state[1] or bool(getattr(self.app,'demo',False) or getattr(self.app,'safe_mode',False))
        if state!=self.context:
            self.context=state;self.epoch+=1;self.blocked=blocked
            api=getattr(self.app,'api',None)
            self.scope=getattr(api,'user_id','') if api and getattr(api,'authenticated',False) else 'shared'
            self.cards=Cards(self.store.native,self.scope)
            self.return_plan=None;self.intermission=None;self.log_cursor=None;self.log_context=None
            self.activity.clear();self.health_history.clear();self.health_last.clear()
            if self.composer:self.composer.cancel()
            if self.speech:self.speech.stop(discard=True)
            engine=getattr(self.app,'shared_audio',None)
            if engine:engine.stop()
            self.event_clip=None;self.event_enabled=False
            while not self.activity_queue.empty():
                try:self.activity_queue.get_nowait()
                except queue.Empty:break
            if self.dialog:self.dialog.invalidate()
        self.blocked=blocked
        client=getattr(self.app,'api',None)
        if client is not self.client:
            if self.client is not None and getattr(self.client,'activity_sink',None) is self.sink:self.client.activity_sink=None
            self.client=client;self.sink=self.receive_activity
            if client is not None:client.activity_sink=self.sink

    def ready(self):
        self.sync()
        from account_actions import local_writable
        local_writable(self.app)
        if self.closed or self.blocked:raise ValueError('Reveal private information and leave Demo / Safe Mode before using session tools.')

    def token(self):return self.epoch
    def valid(self,token):return not self.closed and not self.blocked and token==self.epoch

    def record(self,name,default=None):
        value=self.store.native.get(self.scope,'profile','workflow.'+name)
        return deepcopy(value['data']) if value else deepcopy(default or {})

    def save(self,name,data):
        self.ready()
        self.store.native.put(self.scope,'profile','workflow.'+name,data,provenance={'source':'VRC Eye session tools','privacy':'local'})

    @property
    def desktop(self):
        from desktop_service import service_for
        return service_for(self.shell)

    def setting_change(self,before,after,source='Desktop controls'):
        if self.blocked:return
        changes={k:{'before':before[k],'after':after[k]} for k in DESKTOP_KEYS if before.get(k)!=after.get(k)}
        if not changes:return
        history=self.record('settings',{'rows':[]})['rows']
        history.append(dict(id=uuid.uuid4().hex,at=time.time(),source=source[:80],changes=changes))
        self.save('settings',{'rows':history[-100:]})

    def apply_preset(self,name,values=None):
        self.ready();values=preset_changes(values or self.record('presets',{'values':PRESETS})['values'][name])
        current=deepcopy(self.desktop.policy)
        if self.record('preset-active').get('changes'):raise ValueError('Restore or forget the active temporary preset before applying another.')
        changes={k:{'before':current[k],'after':v} for k,v in values.items() if current[k]!=v}
        self.desktop.configure(dict(current,**values),source='Session preset: '+name)
        self.save('preset-active',dict(name=name,changes=changes,at=time.time()))

    def restore_preview(self,entry):
        changes=entry.get('changes',{});current=self.desktop.policy
        return ({k:v['before'] for k,v in changes.items() if k in DESKTOP_KEYS and current.get(k)==v['after']},
                [k for k,v in changes.items() if k in DESKTOP_KEYS and current.get(k)!=v['after']])

    def restore(self,entry,temporary=False):
        self.ready();restore,conflicts=self.restore_preview(entry)
        if restore:self.desktop.configure(dict(self.desktop.policy,**restore),source='Restore reviewed settings')
        if temporary:self.save('preset-active',{})
        return conflicts

    def speech_service(self):
        if self.speech is None:
            from local_audio import Speech,engine_for
            self.speech=Speech(engine_for(self.app))
        return self.speech

    def compose(self,text):
        self.ready();controller=getattr(self.app,'osc_controller',None)
        if controller is None:raise ValueError('The OSC workspace is unavailable.')
        if self.composer is None:self.composer=Composer(controller.controls)
        epoch=self.epoch;self.composer.begin(text,lambda:self.valid(epoch))

    def receive_activity(self,metadata):
        if self.closed or self.blocked:return
        try:self.activity_queue.put_nowait((self.epoch,redact_activity(metadata)))
        except queue.Full:pass

    def flow(self,feature,destination,purpose,fields,state):
        self.activity.append(dict(at=time.time(),feature=feature,destination=destination,purpose=purpose,fields=fields,state=state))

    def event_sound(self,permitted):
        if self.blocked or not self.event_enabled or self.event_clip is None or time.monotonic()-self.last_event<5:return False
        engine=getattr(self.app,'shared_audio',None)
        if engine and engine.running and engine.active_outputs.get('monitor') and not engine.clips.playing:
            engine.play_clip(self.event_clip,private=True,loop=False);self.last_event=time.monotonic();return True
        return False

    def arm_return(self):
        self.ready();players=getattr(self.app,'player_sessions',None);meta=getattr(players,'meta',{})
        from companion_data import entity_id
        world=entity_id('world',meta.get('world_id',''));instance=meta.get('instance_id','')
        if meta.get('ended') or not instance:raise ValueError('A current observed instance is required.')
        from world_visits import combined
        target=combined(world,instance)
        self.return_plan=dict(target=target,expires=time.monotonic()+900,at=time.time())

    def inspect_return(self):
        self.ready()
        if not self.return_plan or time.monotonic()>self.return_plan['expires']:raise ValueError('The fifteen-minute return plan expired; review a current instance again.')
        self.shell.show('World Visits')
        page=self.shell.pages['World Visits'];page.destination.set(self.return_plan['target']);page.inspect_instance()

    def capture(self,card):
        self.ready();controller=getattr(self.app,'osc_controller',None)
        if controller is None:raise ValueError('OSC camera is unavailable.')
        review=controller.controls.review('camera.capture')
        result=controller.controls.execute(review)
        card=deepcopy(card);card['state']='Requested'
        card['attempts']=(card.get('attempts',[])+[dict(at=time.time(),state='Requested',capture_id=str(result.get('capture_id','')))])[-20:]
        return self.cards.save('shots',card)

    def photo_receipt(self,path,stop=None):
        from photo_files import read_photo,_open
        data,_=read_photo(path,stop=stop,minimum_age=2)
        with _open(data) as im:im.verify()
        return dict(path=str(Path(path).resolve()),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),checked=time.time())

    def picture_for(self,kind,reference):
        self.ready()
        for scope in dict.fromkeys((self.scope,'shared')):
            record=self.store.native.get(scope,'entity',kind+':'+reference)
            if record:
                fields=record['data'].get('fields',{})
                url=fields.get('thumbnailImageUrl') or fields.get('imageUrl')
                if url:return url
        creator=getattr(self.app,'avatar_creator',None)
        if kind=='avatar' and creator:
            from avatar_library import active_scope
            record=creator.library.get(active_scope(self.app),reference)
            if record:return record.get('thumbnail','')
        return ''

    def known_creator(self,author):
        """Bounded native metadata snapshot; no scrape or inferred full portfolio."""
        self.ready()
        from companion_data import entity_id
        author=entity_id('user',author);merged={};coverage=[]
        for scope in dict.fromkeys((self.scope,'shared')):
            result=self.store.native.rows(scope,'entity',author,limit=1000)
            records=result[0] if isinstance(result,tuple) else result['rows']
            for item in records:
                data=item['data'];raw=data.get('fields',data)
                if data.get('entity_kind')!='avatar' or raw.get('authorId')!=author:continue
                key=data['entity_id'];entry=merged.setdefault(key,dict(id=key,name=raw.get('name') or key,sources=[],updated=item.get('updated',''),image=raw.get('thumbnailImageUrl') or raw.get('imageUrl') or ''))
                entry['sources'].append(item.get('provenance',{}).get('source','Native metadata'))
            coverage.append(str(scope)+': up to 1,000 matching retained records')
        creator=getattr(self.app,'avatar_creator',None)
        if creator:
            from avatar_library import active_scope
            for item in creator.library.records(active_scope(self.app),'avatar',limit=5000):
                if item.get('author_id')!=author:continue
                entry=merged.setdefault(item['id'],dict(id=item['id'],name=item.get('name') or item['id'],sources=[],updated=item.get('last_seen',''),image=item.get('thumbnail','')))
                entry['sources']=list(dict.fromkeys(entry['sources']+item.get('sources',[])+['Avatar Library']))
            coverage.append('Avatar Library: up to 5,000 retained avatars')
        return list(merged.values()),'; '.join(coverage)+'. Saved observations only; a complete author catalogue is not implied.'

    def _observe_log(self):
        log=self.shell.log;context=(getattr(log,'source',None),getattr(log,'generation',0));items=list(log.items)
        if context!=self.log_context or self.log_cursor is None:
            self.log_context=context;self.log_cursor=max((x.serial for x in items),default=0);self.intermission=None;return
        for item in items:
            if item.serial<=self.log_cursor:continue
            self.log_cursor=item.serial
            if item.category=='Worlds':self.intermission=dict(started=time.monotonic(),world=item.world or '',reported=item.message[:300],done=False)
            elif self.intermission and item.category=='Players':self.intermission.update(done=True,done_at=time.monotonic(),reported='Player activity observed in the selected log; loading completion is not verified.')
        if self.intermission and self.intermission.get('done_at') and time.monotonic()-self.intermission['done_at']>5:self.intermission=None
        if self.return_plan and time.monotonic()>self.return_plan['expires']:self.return_plan=None

    def readiness(self):
        now=time.time();rows=[]
        api=getattr(self.app,'api',None);rows.append(dict(service='VRChat connection',state='Signed in' if api and api.authenticated else 'Not signed in',next='VRChat connection…',checked=now))
        controller=getattr(self.app,'osc_controller',None)
        if controller:
            transport=controller.service.transport.snapshot()
            rows.append(dict(service='OSC observation',state='Receiving socket open' if transport.get('running') else 'Stopped',next='Networking → OSC Transport',checked=now))
        audio=getattr(self.app,'shared_audio',None)
        rows.append(dict(service='Local audio',state=audio.state if audio else 'Not started',next='Media & Audio → selected devices',checked=now))
        if self.speech:rows.append(dict(service='Local speech',state=self.speech.state,next='Composer → model and microphone',checked=now))
        sync=getattr(self.shell,'automatic_sync',None)
        rows.append(dict(service='Automatic sync',state=str(getattr(sync,'pipe_state','Not initialized')),next='Accounts → automatic sync',checked=now))
        for name in ('Unity Player','Media & Audio','Crash & Diagnostics'):
            page=self.shell.pages.get(name);value=getattr(getattr(page,'service',None),'status',None)
            rows.append(dict(service=name,state=str(value or ('Workspace loaded; inspect provider state' if page else 'Not initialized')),next='Open '+name,checked=now))
        for value in rows:
            if self.health_last.get(value['service'])!=value['state']:
                self.health_last[value['service']]=value['state'];self.health_history.append(deepcopy(value))
        return rows

    def diagnostics(self):
        controller=getattr(self.app,'osc_controller',None)
        osc=controller.snapshot() if controller else {}
        return dict(checked=time.time(),readiness=self.readiness(),transitions=list(self.health_history),
            costs=self.costs.snapshot(),cost_scope='Elapsed time of instrumented Eye callbacks, not process CPU attribution.',
            osc_ingress=controller.service.transport.snapshot() if controller else {},
            contact_routes=osc.get('workspace',{}).get('routes',[]),activity=list(self.activity),
            current_grants={'osc':osc.get('service',{}).get('permissions',{}),'audio_capture':bool(getattr(getattr(self.app,'shared_audio',None),'active_sources',{})),'outgoing_audio_route':bool(getattr(getattr(self.app,'shared_audio',None),'active_outputs',{}).get('outgoing')),'private_notification_clip':self.event_enabled},
            data_flow_scope='Observed Eye API transport and explicit local audio/composer actions; not packet capture or other applications.')

    def tick(self):
        self.sync()
        if self.blocked:return
        for _ in range(30):
            try:epoch,value=self.activity_queue.get_nowait()
            except queue.Empty:break
            if self.valid(epoch):self.activity.append(value)
        if self.composer:
            try:self.composer.tick()
            except ValueError:pass
        self._observe_log()
        if self.dialog:self.dialog.tick_tools()

    def close(self):
        self.closed=True;self.epoch+=1
        if self.composer:self.composer.cancel()
        if self.speech:self.speech.stop(discard=True)
        if self.client and getattr(self.client,'activity_sink',None) is self.sink:self.client.activity_sink=None
        engine=getattr(self.app,'shared_audio',None)
        if engine:engine.stop()
        if self.dialog:self.dialog.close()
        if self.pin:self.pin.destroy();self.pin=None


def service_for(shell):
    if getattr(shell,'session_tools',None) is None:shell.session_tools=SessionTools(shell)
    return shell.session_tools
