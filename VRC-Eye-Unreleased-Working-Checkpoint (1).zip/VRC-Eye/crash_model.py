"""Versioned diagnostic records and evidence-only analysis; no I/O or actions."""
from collections import Counter
import hashlib
import json
import math
import re
import uuid
from resource_core import METRICS, number, GIB

KINDS = {'start','stop','heartbeat','sample','gap','checkpoint','process.started','process.exited','process.hung','process.recovered',
         'instance.entered','instance.left','player.joined','player.left','avatar.changed','avatar.load','log.warning','log.error','log.crash',
         'provider.failed','bridge.connected','bridge.disconnected','vr.state','eye.error','manual','os.evidence','action.requested'}
KINDS.update({'runtime.'+kind for kind in ('process.started','process.exited','window.created','window.offscreen','display.changed','hang.started','hang.recovered','renderer.changed','metadata.changed','log.error','log.warning','log.crash','error.burst','startup.milestone','bridge.changed','provider.failed','queue.gap','launch.requested','window.action')})
KINDS.update({'companion.'+kind for kind in ('process.changed','settings.changed','solo.changed','ownership.changed','runtime.changed','action.reserved','action.completed','action.canceled','action.expired','notification.suppressed','provider.failed')})
KINDS.add('peer.activity')
KINDS.add('osc.activity')
SOURCES = {'recorder','resource','process','log','bridge','steamvr','windows','user','vrc_eye','derived'}
CONFIDENCE = {'direct','high','medium','low','unknown'}
STATES = {'unknown','responsive','unresponsive','running','not_running','unavailable','connected','disconnected','healthy','degraded','stale'}
ID = re.compile(r'^[0-9a-f]{32}$')
WORLD = re.compile(r'^wrld_[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$')


def settings(raw=None):
    base=dict(schema=1,enabled=True,window_minutes=10,retain_days=30,max_incidents=10,view='Casual',remember_world=False,windows_evidence=True)
    if raw is None:return base
    if not isinstance(raw,dict) or set(raw)-set(base):raise ValueError('Invalid Crash & Diagnostics settings.')
    value=dict(base,**raw)
    if value['schema']!=1:raise ValueError('Unsupported diagnostics settings version.')
    for key in ('enabled','remember_world','windows_evidence'):
        if type(value[key]) is not bool:raise ValueError('Invalid diagnostics on/off preference.')
    if type(value['window_minutes']) is not int or value['window_minutes'] not in (5,10,15):raise ValueError('Rolling history must be 5, 10 or 15 minutes.')
    if type(value['retain_days']) is not int or value['retain_days'] not in (0,7,30,90):raise ValueError('Retention must be 7, 30, 90 days or 0 for no age deletion.')
    if type(value['max_incidents']) is not int or value['max_incidents'] not in (0,10,25,50):raise ValueError('Keep 10, 25, 50 incidents or 0 for no count deletion.')
    if value['view'] not in ('Casual','Advanced','Developer'):raise ValueError('Invalid diagnostics view.')
    return value


def safe_payload(kind,payload):
    """Allowlist scalar/schema data before persistence; free-form text is not retained."""
    if not isinstance(payload,dict):raise ValueError('Diagnostic payload must be structured.')
    out={}
    if kind == 'peer.activity' and payload.get('peer_event') in ('connection', 'permission', 'delivery', 'state'):
        out['peer_event'] = payload['peer_event']
    for key in ('count','dropped','duration','sample_age','errors','warnings','players','hmds','controllers','trackers','tracked','connected','sequence_from','sequence_to','incident_count','segment'):
        v=payload.get(key)
        if number(v) and 0<=v<=2**53:out[key]=v
    for key in ('state','process','steamvr','tracking','bridge','network'):
        v=payload.get(key)
        if isinstance(v,str) and v in STATES:out[key]=v
    for key in ('clean_exit','expected_exit','partial','responsive','steam_running','hmd_connected','tracking_valid','worn'):
        if type(payload.get(key)) is bool:out[key]=payload[key]
    if payload.get('severity') in ('UNKNOWN','HEALTHY','ELEVATED','WARNING','CRITICAL','EMERGENCY'):out['severity']=payload['severity']
    if payload.get('category') in ('VRChat','SteamVR','Tracking','System','VRC Eye','Bridge','Assets','Networking','Rendering'):out['category']=payload['category']
    if payload.get('reason') in ('queue_overflow','sensor_expired','sampling_gap','clock_change','storage_pressure','record_corrupt','unclean_stop','process_exit','manual','log_crash','hang','provider_error','normal_close','monitor_disabled','session_change'):
        out['reason']=payload['reason']
    if payload.get('event') in KINDS:out['event']=payload['event']
    if payload.get('provider') in SOURCES:out['provider']=payload['provider']
    if kind in ('sample','checkpoint'):
        metrics=payload.get('metrics',{})
        if isinstance(metrics,dict):
            clean={}
            for key,item in metrics.items():
                if key not in METRICS or not isinstance(item,dict):continue
                v=item.get('value');age=item.get('age');ttl=item.get('ttl')
                if v is not None and (not number(v) or v<0 or METRICS[key][1]=='fraction' and v>1):continue
                if not number(age) or not 0<=age<=86400 or not number(ttl) or not 0<ttl<=60:continue
                # Provenance is a fixed provider family, never arbitrary backend strings.
                source=item.get('source') if item.get('source') in SOURCES else 'resource'
                clean[key]=dict(value=v,age=age,ttl=ttl,source=source,confidence='direct' if v is not None else 'unknown')
            out['metrics']=clean
    if kind=='os.evidence':
        if payload.get('code') in (41,1001,4101,1000,1002,6008):out['code']=payload['code']
        if payload.get('provider') in ('Kernel-Power','WER-SystemErrorReporting','Display','Application Error','Application Hang','EventLog'):out['provider']=payload['provider']
        if payload.get('application') in ('VRChat','SteamVR','VRC Eye'):out['application']=payload['application']
        bug=payload.get('bugcheck')
        if isinstance(bug,str) and re.fullmatch(r'0x[0-9a-fA-F]{1,8}',bug):out['bugcheck']=bug
    if kind.startswith('runtime.'):
        choices={'runtime_state':('UNKNOWN','NOT_RUNNING','STARTING','INITIALIZING','RUNNING','DEGRADED','UNRESPONSIVE','EXITED_CLEANLY','CRASHED','UNKNOWN_EXIT'),
                 'runtime_milestone':('Process observed','Window observed','Responsive window observed','Fresh log activity observed','Unity initialization observed'),
                 'runtime_category':('Runtime','Graphics','Assets','Avatar','Networking','Media','SteamVR','OSC','Authentication','Application','Unknown Unity'),
                 'runtime_field':('unity_version','renderer','adapter','driver','architecture'),'runtime_action':('foreground','restore','center','primary','recover','default','known')}
        for key,allowed in choices.items():
            if payload.get(key) in allowed:out[key]=payload[key]
        version=payload.get('unity_version')
        if isinstance(version,str) and re.fullmatch(r'\d{4}\.\d{1,3}\.\d{1,4}[abfp]\d{1,4}',version):out['unity_version']=version
    if kind.startswith('companion.'):
        if payload.get('state') in ('DISABLED','RUNNING','ABSENT','UNKNOWN','AMBIGUOUS','STALE'):out['state']=payload['state']
        if payload.get('preset') in ('Balanced','VRCX Primary','VRC Eye Primary'):out['preset']=payload['preset']
        if type(payload.get('enabled')) is bool:out['enabled']=payload['enabled']
        if payload.get('action') in ('launch','restart','normal_close','safe_mode'):out['action']=payload['action']
        categories=('SOCIAL','ACCOUNT','SESSION','PRESENCE','LAUNCH','RESTART','RUNTIME','SAFETY','DIAGNOSTIC','SYSTEM','CORE')
        if payload.get('category') in categories:out['category']=payload['category']
        owners=payload.get('owners')
        if isinstance(owners,dict):out['owners']={k:v for k,v in owners.items() if k in categories and v in ('VRC_EYE','VRCX')}
    if kind=='sample':
        for key in ('disk.read_bps','disk.write_bps','network.recv_bps','network.sent_bps'):
            value=payload.get(key)
            if number(value) and value>=0:out[key]=value
    return out


def record(seq,run,at,wall,kind,source,payload=None,confidence='direct'):
    if kind not in KINDS or source not in SOURCES or confidence not in CONFIDENCE:raise ValueError('Unsupported diagnostic event.')
    if not ID.fullmatch(run) or type(seq) is not int or seq<1:raise ValueError('Invalid diagnostic identity or sequence.')
    if not number(at) or not number(wall) or at<0 or wall<0:raise ValueError('Invalid diagnostic time.')
    return dict(schema=1,seq=seq,run=run,at=at,wall=wall,kind=kind,source=source,confidence=confidence,payload=safe_payload(kind,payload or {}))


def serialize(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def checksum(value):return hashlib.sha256(serialize(value).encode()).hexdigest()


def validate_record(value):
    if not isinstance(value,dict) or value.get('schema')!=1:raise ValueError('Unsupported Black Box record schema.')
    clean=record(value['seq'],value['run'],value['at'],value['wall'],value['kind'],value['source'],value['payload'],value['confidence'])
    if clean!=value:raise ValueError('Record contains fields outside the diagnostic schema.')
    return clean


def classify(records,reason='manual'):
    end=max((r['at'] for r in records if r['kind']!='os.evidence'),default=0)
    kinds=Counter(r['kind'] for r in records if r['kind']!='os.evidence' and 0<=end-r['at']<=30)
    evidence=[r['payload'] for r in records if r['kind']=='os.evidence']
    if any(e.get('code')==1001 and e.get('provider')=='WER-SystemErrorReporting' for e in evidence):return 'Windows reported a bugcheck','high'
    if any(e.get('code') in (41,6008) and e.get('provider') in ('Kernel-Power','EventLog') for e in evidence):return 'Unexpected system shutdown reported','high'
    if kinds['log.crash']:return 'VRChat crash marker observed','high'
    if reason=='process_exit' and kinds['process.hung']:return 'VRChat unresponsive before exit','high'
    if reason=='process_exit':return 'VRChat process exited — cause unknown','direct'
    if reason=='hang':return 'VRChat window appears unresponsive','medium'
    if reason=='unclean_stop':return 'VRC Eye recording ended unexpectedly','high'
    return 'Manual diagnostic snapshot','direct'


def analyze(records,reason='manual',damaged=0):
    records=sorted(records,key=lambda r:(r['at'],r['seq']));title,confidence=classify(records,reason)
    live=[r for r in records if r['kind']!='os.evidence']
    end=live[-1]['at'] if live else 0
    tail=[r for r in live if 0<=end-r['at']<=30]
    observations=[]
    samples=[r for r in tail if r['kind']=='sample']
    def vals(key):
        return [m['value'] for r in samples if (m:=r['payload'].get('metrics',{}).get(key)) and m['value'] is not None and m['age']<=m['ttl']]
    for key,label in (('gpu.fraction','Device GPU memory'),('ram.fraction','System RAM')):
        values=vals(key)
        if values and max(values)>=.9:observations.append(f'{label} reached {max(values)*100:.0f}% in the final recorded 30 seconds.')
    commit=vals('commit.available')
    if commit and min(commit)<GIB:observations.append('Windows commit headroom fell below 1 GiB in the final recorded 30 seconds.')
    errors=sum(r['payload'].get('count',1) for r in tail if r['kind']=='log.error')
    if errors:observations.append(f'{errors:g} normalized log errors were observed in the final recorded 30 seconds.')
    loads=sum(r['payload'].get('count',1) for r in tail if r['kind'] in ('avatar.changed','avatar.load'))
    if loads:observations.append(f'{loads:g} avatar events occurred in that window; this does not identify a cause.')
    gap=sum(r['kind']=='gap' for r in records)
    if gap or damaged:observations.append(f'Evidence is incomplete: {gap} recorded gaps and {damaged} invalid records.')
    if not observations:observations.append('The available record does not establish a cause.')
    checkpoint=next((r for r in reversed(records) if r['kind']=='checkpoint' and r['at']<end-30),None)
    comparison=[]
    if checkpoint and samples:
        last=samples[-1]
        for key in ('vrchat.rss','gpu.used','ram.available','commit.available'):
            a=checkpoint['payload'].get('metrics',{}).get(key);b=last['payload'].get('metrics',{}).get(key)
            if a and b and a['value'] is not None and b['value'] is not None and a['age']<=a['ttl'] and b['age']<=b['ttl']:
                comparison.append(dict(metric=key,before=a['value'],after=b['value'],delta=b['value']-a['value']))
    signature=checksum(dict(title=title,pressure=bool(vals('gpu.fraction') and max(vals('gpu.fraction'))>=.9),errors=errors>=10,hang=any(r['kind']=='process.hung' for r in records)))[:16]
    return dict(title=title,confidence=confidence,observations=observations,comparison=comparison,signature=signature,
                start=records[0]['wall'] if records else None,end=live[-1]['wall'] if live else None,
                duration=max(0,end-records[0]['at']) if records else 0,records=len(records),gaps=gap,damaged=damaged,
                caveat='These observations do not establish a definitive cause or blame a player, avatar, world or application.')


def replay_point(records,at,max_age=10):
    """No interpolation: return only contemporaneous measurements with valid ages."""
    rows=sorted((r for r in records if r['at']<=at),key=lambda r:(r['at'],r['seq']))
    sample=next((r for r in reversed(rows) if r['kind']=='sample'),None)
    if not sample:return dict(metrics={},state='unknown',gap=True)
    elapsed=at-sample['at']; gap=elapsed>max_age or any(r['kind']=='gap' and r['at']>=sample['at'] for r in rows)
    metrics={}
    if not gap:
        for key,m in sample['payload'].get('metrics',{}).items():
            metrics[key]=m['value'] if m['age']+elapsed<=m['ttl'] else None
    return dict(metrics=metrics,state=sample['payload'].get('state','unknown') if not gap else 'unknown',gap=gap)


def bundle(incident,include_metrics=True):
    """Export a new strict allowlist, even if the on-disk incident was altered."""
    valid=[];damaged=incident.get('damaged',0)
    for r in incident.get('records',[]):
        try:clean=validate_record(r)
        except (ValueError,KeyError,TypeError):damaged+=1;continue
        # Ephemeral run IDs are local correlation keys, replaced with bundle-local IDs.
        clean=dict(clean,run='0'*32)
        if not include_metrics and clean['kind'] in ('sample','checkpoint'):continue
        valid.append(clean)
    reason=incident.get('reason') if incident.get('reason') in ('manual','hang','process_exit','unclean_stop','log_crash') else 'manual'
    summary=analyze(valid,reason,damaged)
    preview=dict(included=['Incident summary','Normalized event timeline','Source/confidence metadata']+(['Resource telemetry'] if include_metrics else []),
                 excluded=['Credentials and tokens','Player/account/avatar identifiers','Private instance codes','World recovery target','Personal paths and raw logs','Machine names and hardware serials'],records=len(valid))
    return dict(summary=summary,timeline=valid,preview=preview)
