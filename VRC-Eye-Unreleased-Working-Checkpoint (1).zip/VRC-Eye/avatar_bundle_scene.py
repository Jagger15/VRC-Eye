"""Read-only Unity bundle subset into the existing declarative Scene contract.

Called after trusted imports and kernel containment. No Unity runtime, script
execution, PPtr dereference, exports, network or filesystem discovery is used.
"""
from dataclasses import replace
from hashlib import sha256
from avatar_scene import Scene,SceneNode,ScenePart,MAX_BYTES,MAX_NODES,MAX_VERTICES,MAX_TRIANGLES,integer,vector,name,bounds,local_matrix,multiply
from avatar_scene_appearance import Material
from avatar_scene_deform import Skin,RigPart,validate_skin,influences,positions
import avatar_bundle_container as container
import avatar_bundle_serialized as serialized
import avatar_bundle_mesh as geometry
import avatar_mesh_health as health


def preload():serialized.preload()


def parse(data):
    if not isinstance(data,bytes) or not 48<=len(data)<=MAX_BYTES:raise ValueError('Select a complete Unity bundle no larger than 32 MiB.')
    engine,entries=container.unpack(data);assets={};objects={};resources={};all_count=0;ignored={};platforms=set()
    for label,raw,kind in entries:
        if kind!=4:resources[label]=raw;continue
        asset,decoded=serialized.read(raw,label,engine);assets[label]=asset;platforms.add(asset.target_platform)
        all_count+=len(asset.objects)
        if all_count>serialized.MAX_OBJECTS:raise ValueError('Unity bundle exceeds 4,096 serialized objects.')
        for oid,obj in asset.objects.items():
            if obj.class_id not in serialized.ALLOWED:ignored[obj.class_id]=ignored.get(obj.class_id,0)+1
        for oid,(cls,row) in decoded.items():objects[(label,oid)]=(cls,row)
    if not assets:raise ValueError('No supported serialized asset file exists in this bundle.')
    if len(platforms)!=1:raise ValueError('Mixed build targets within a bundle are unsupported.')
    missing=set();skipped=[]
    def embedded(path):
        if not isinstance(path,str) or len(path)>1024 or '\\' in path or any(ord(c)<32 for c in path):raise ValueError('Unsupported embedded Unity resource reference.')
        if path.startswith('archive:/'):path=path[len('archive:/'):]
        elif ':' in path or path.startswith('/'):raise ValueError('External Unity resource locations are not read.')
        bits=path.split('/')
        if any(b in ('','..','.') for b in bits):raise ValueError('Unsafe Unity resource path.')
        return bits[-1]
    def key(owner,ref):
        if not isinstance(ref,dict) or set(ref)!={'m_FileID','m_PathID'}:raise ValueError('Invalid Unity object pointer.')
        fid=integer(ref['m_FileID'],0,len(assets[owner].externals));oid=ref['m_PathID']
        if type(oid) is not int or not -(2**63)<=oid<2**63:raise ValueError('Invalid Unity object ID.')
        if not oid:return None
        if fid:
            target=embedded(assets[owner].externals[fid-1].path)
            if target not in assets:missing.add(target);return None
            owner=target
        value=(owner,oid)
        if value not in objects:missing.add('unavailable object '+str(oid));return None
        return value
    def lookup(owner,ref,cls):
        k=key(owner,ref)
        if k is None:return None,None
        if objects[k][0]!=cls:raise ValueError('Unity pointer refers to a different object type.')
        return k,objects[k][1]
    def resource(info):
        label=embedded(info['path'])
        if label not in resources:missing.add(label);raise ValueError('Mesh depends on a resource outside the selected bundle.')
        raw=resources[label];start=integer(info['offset'],0,len(raw));size=integer(info['size'],1,len(raw))
        if start+size>len(raw):raise ValueError('Unity vertex resource range exceeds the embedded bytes.')
        return raw[start:start+size]
    transforms={k:v for k,(cls,v) in objects.items() if cls==4}
    if not 1<=len(transforms)<=MAX_NODES:raise ValueError('Bundle hierarchy needs 1–512 Transform objects.')
    parents={};owners={};labels={};local={}
    for k,row in transforms.items():
        owner=k[0];go,game=lookup(owner,row['m_GameObject'],1)
        if go is None:raise ValueError('A Unity transform has a missing GameObject dependency.')
        if go in owners:raise ValueError('Multiple transforms reference one GameObject.')
        owners[go]=k;labels[k]=name(game.get('m_Name'),'Unity object')
        p=key(owner,row['m_Father'])
        if row['m_Father']['m_PathID'] and p is None or p is not None and p not in transforms:raise ValueError('A Unity parent transform is missing.')
        parents[k]=p
        t=row['m_LocalPosition'];q=row['m_LocalRotation'];s=row['m_LocalScale']
        local[k]=local_matrix(dict(translation=[-t['x'],t['y'],t['z']],rotation=[q['x'],-q['y'],-q['z'],q['w']],scale=[s[c] for c in ('x','y','z')]))
    # Parent and child lists must agree; never promote an unresolved child to root.
    for k,row in transforms.items():
        children=[key(k[0],ref) for ref in row['m_Children']]
        if len(children)>MAX_NODES or len(set(children))!=len(children) or None in children or set(children)!={c for c,p in parents.items() if p==k}:
            raise ValueError('Unity parent/child hierarchy is incomplete or inconsistent.')
    nodes=[];indices={};world={};pending=set(transforms)
    while pending:
        ready=sorted(k for k in pending if parents[k] is None or parents[k] in indices)
        if not ready:raise ValueError('Unity transform hierarchy contains a cycle.')
        for k in ready:
            parent=parents[k];idx=len(nodes);indices[k]=idx
            world[idx]=multiply(world[indices[parent]],local[k]) if parent else local[k]
            nodes.append(SceneNode(idx,indices[parent] if parent else -1,labels[k],world[idx]));pending.remove(k)
    node_parents={n.index:n.parent for n in nodes}
    filters={}
    for k,(cls,row) in objects.items():
        if cls==33:
            go=key(k[0],row['m_GameObject'])
            if go in filters:raise ValueError('Duplicate Unity MeshFilter for a GameObject.')
            filters[go]=(k[0],row['m_Mesh'])
    materials=[];material_map={};parts=[];skins=[];vertices=triangles=morph_vertices=0
    def material(owner,ref):
        k,row=lookup(owner,ref,21)
        if k is None:return -1
        if k in material_map:return material_map[k]
        if len(materials)>=128:raise ValueError('Unity scene exceeds 128 materials.')
        values=dict(row.get('m_SavedProperties',{}).get('m_Colors',[]))
        prop='_BaseColor' if '_BaseColor' in values else '_Color' if '_Color' in values else None
        color=vector([values[prop][c] for c in ('r','g','b','a')],4) if prop else (1.,1.,1.,1.)
        color=tuple(max(0.,min(1.,v)) for v in color)
        note='Unlit '+(prop+' color (clamped for display)' if prop else 'white fallback: no recognized base color')+'; Unity shaders, texture maps and transparency are not evaluated.'
        index=len(materials);material_map[k]=index;materials.append(Material(name(row.get('m_Name'),'Unity material'),color,notices=(note,)));return index
    for renderer,(cls,row) in objects.items():
        if cls not in (23,137):continue
        owner=renderer[0];go=key(owner,row['m_GameObject']);node=owners.get(go)
        if node is None:raise ValueError('Unity renderer has no complete transform.')
        if cls==137:mesh_owner=owner;mesh_ref=row['m_Mesh']
        elif go in filters:mesh_owner,mesh_ref=filters[go]
        else:skipped.append('renderer without a MeshFilter');continue
        mesh_key,mesh=lookup(mesh_owner,mesh_ref,43)
        if mesh is None:skipped.append('renderer with missing mesh');continue
        try:
            if row.get('m_StaticBatchInfo',{}).get('subMeshCount',0) or row.get('m_StaticBatchRoot',{}).get('m_PathID',0):
                raise ValueError('Static-batched renderer reconstruction is unsupported.')
            if cls==137 and mesh.get('m_BindPose') and not row.get('m_Bones'):
                raise ValueError('Skin bind poses have no renderer bones.')
            channels=geometry.streams(mesh,resource);base=channels[0];faces=geometry.submeshes(mesh,len(base));ni=indices[node]
            skin=None;js=ws=()
            if cls==137 and row.get('m_Bones'):
                bone_keys=[key(owner,ref) for ref in row['m_Bones']]
                if any(k not in indices for k in bone_keys):raise ValueError('Skin has missing bone transforms.')
                skin=Skin(name(mesh.get('m_Name'),'Unity skin'),tuple(indices[k] for k in bone_keys),tuple(geometry.matrix(v) for v in mesh['m_BindPose']))
                validate_skin(skin,node_parents)
                if 12 not in channels or 13 not in channels:raise ValueError('Skin lacks supported four-weight vertex channels.')
                js,ws=influences(channels[13],channels[12],len(base),skin)
            elif 12 in channels or 13 in channels:
                raise ValueError('Mesh skin channels have no matching renderer bones.')
            mn,md,mw=geometry.morphs(mesh,len(base),row.get('m_BlendShapeWeights',[]) if cls==137 else [])
        except ValueError as error:
            skipped.append(str(error)[:140]);continue
        if skin:
            if len(skins)>=32 or sum(len(s.joints) for s in skins)+len(skin.joints)>2048:raise ValueError('Bundle skin catalog exceeds its budget.')
            skin_index=len(skins);skins.append(skin)
        else:skin_index=-1
        rig=RigPart(base,world[ni],skin_index,js,ws,mn,md,mw)
        actual=positions(rig,skins,world)
        refs=row.get('m_Materials',[])
        if not isinstance(refs,list) or len(refs)>128:raise ValueError('Invalid Unity material slot list.')
        for slot,ff in enumerate(faces):
            if not ff:continue
            used=sorted({v for t in ff for v in t});remap={v:i for i,v in enumerate(used)}
            vertices+=len(used);triangles+=len(ff);morph_vertices+=len(used)*len(mn)
            if vertices>MAX_VERTICES or triangles>MAX_TRIANGLES or len(parts)>=512 or morph_vertices>200000:raise ValueError('Unity scene exceeds preview geometry/deformation budgets.')
            uv=channels.get(4,());colors=channels.get(3,())
            part_rig=replace(rig,base=tuple(base[i] for i in used),joints=tuple(js[i] for i in used) if js else (),weights=tuple(ws[i] for i in used) if ws else (),morph_deltas=tuple(tuple(d[i] for i in used) for d in md))
            mat=material(owner,refs[slot]) if slot<len(refs) else -1
            parts.append(ScenePart(ni,tuple(actual[i] for i in used),tuple(tuple(remap[v] for v in t) for t in ff),tuple(uv[i] for i in used) if uv else (),mat,tuple(colors[i] for i in used) if colors else (),health.analyze(base,ff,normals=channels.get(1,()),tangents=channels.get(2,()),uvs=uv),part_rig))
    if not parts:raise ValueError('No supported renderer geometry could be decoded. '+('; '.join(dict.fromkeys(skipped))[:180] or 'Keep this bundle for manual recovery.'))
    target={19:'Windows64',24:'Linux64',13:'Android'}[next(iter(platforms))]
    notes=[f'UnityFS {engine} / {target}; UnityPy {serialized.VERSION}. Experimental decoded subset; native creator fixtures remain unqualified.',
        'Original Unity units; X is reflected for the preview coordinate system. Stored transforms and supported skin/morph weights only; this is not an animation or runtime pose.',
        'Material slots and saved base colors only. Texture images, Unity shaders, constraints, PhysBones, animation/controller playback and scripts are not loaded.',
        f'{ignored.get(74,0)} AnimationClip objects present but not decoded; {ignored.get(114,0)} MonoBehaviour objects skipped. Other unsupported object types: '+','.join(str(k) for k in sorted(ignored) if k not in (74,114))[:100],
        'All stored renderer objects are considered, including disabled/inactive objects and LOD levels; runtime visibility is not evaluated.',
        'Skipped renderers: '+str(len(skipped))+('. '+('; '.join(dict.fromkeys(skipped)))[:220] if skipped else '. None.'),
        'Missing embedded dependencies: '+str(len(missing))+('. '+', '.join(sorted(name(v,'dependency') for v in missing))[:180] if missing else '. None observed.')]
    return Scene(tuple(nodes),tuple(parts),bounds(tuple(v for p in parts for v in p.vertices)),sha256(data).hexdigest(),len(data),tuple(notes),tuple(materials),(),tuple(skins))
