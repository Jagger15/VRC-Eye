# Resume VRC Eye after Development 15

Use **VRC-Eye-v1.21.0-Development-15.zip** as the current source checkpoint.
It descends from the completed Development 14 archive saved by the other chat,
SHA-256 `44a5452ba27e60576246fc3d4bc0b6fc93479ad2859a02a1d6a3271a8726e510`. That chat finished saving after
the continuation began. Parallel-Recovery-Checkpoint archives are historical
branches; their alternative transfer/notes modules are not this build's owners.

Keep avatar_transfer_jobs.py / avatar_transfers_ui.py, dashboard_table.py /
dashboard_rows.py, and shared_notes.py / shared_notes_ui.py as the established
owners. Development 15 connects player_history.py and player_session_dialog.py to
shared notes. Note text is canonical; roster filter tags remain separate. Cross-
database edits are not claimed atomic. Shared-note snapshots/revisions are bound
to the account and player; do not replace a displayed draft's revision during a
background refresh. Legacy review and intentional-clear markers must survive.

Final validation: 4,793 tests + 1,059 subtests passed, 475 GUI cases
skipped, 1 bridge case deselected, 13 transport modules excluded, zero
failures/errors and blocked external-socket attempts. See BUILD_VALIDATION.json
for the full command, limitations and precise counts. Native/live checks remain open.

CONTINUATION_DEV15.md explains setup and changed behavior. The 106-area ledger is
ARC_VRCX_GAP_LEDGER_DEV15.json and its report ARC_VRCX_REMAINING_DEV15.md: 50 source
implemented, 37 partial, 10 missing, 7 acceptance/provider prerequisites, 2 source
limitations. The broader 160-package implementation ledger remains a different
inventory. Continue from actual source and retain conservative classifications.
