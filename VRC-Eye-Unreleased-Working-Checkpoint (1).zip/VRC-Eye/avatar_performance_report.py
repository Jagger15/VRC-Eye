"""Creator-supplied performance measurements; no inferred official rating."""
from dataclasses import dataclass
from datetime import datetime, timezone
import math
import re
from avatar_links import parse_avatar_reference
from avatar_performance import normalize_rank
from developer_core import safe_text
from inspection_inputs import json_file

SCHEMA = 'vrc-eye-avatar-performance-1'
# Wire names follow the reported SDK vocabulary. Unknown is represented by None.
COUNTS = ('polyCount','skinnedMeshCount','meshCount','materialCount','animatorCount','boneCount',
          'lightCount','particleSystemCount','particleTotalCount','particleMaxMeshPolyCount',
          'trailRendererCount','lineRendererCount','clothCount','clothMaxVertices','physicsColliderCount',
          'physicsRigidbodyCount','audioSourceCount','contactCount','contactCompleteCount',
          'constraintsCount','constraintDepth','raycastCount')
PHYSBONES = ('componentCount','transformCount','colliderCount','collisionCheckCount')
BOOLEANS = ('particleTrailsEnabled','particleCollisionEnabled')
SPECS = {k:('count','integer') for k in COUNTS}
SPECS.update({k:('bytes','integer') for k in ('downloadSizeBytes','uncompressedSizeBytes')})
SPECS['textureMegabytes'] = ('reported MB','number')
SPECS.update({k:('enabled','boolean') for k in BOOLEANS})
SPECS.update({'physBone.'+k:('count','integer') for k in PHYSBONES})


def text(value, limit=160):
    if not isinstance(value,str) or not value.strip() or len(value)>limit or any(ord(c)<32 for c in value):
        raise ValueError('Report labels must contain bounded plain text.')
    return value.strip()


def timestamp(value):
    value=text(value,80)
    try: dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError as error: raise ValueError('Use an ISO observation time with a timezone.') from error
    if dt.utcoffset() is None: raise ValueError('Observation time needs a timezone.')
    return dt.astimezone(timezone.utc).isoformat(timespec='seconds')


@dataclass(frozen=True)
class PerformanceReport:
    avatar_id: str
    platform: str
    sdk_version: str
    measured_at: str
    source: str
    reported_rank: str
    values: tuple
    unknown_fields: tuple = ()
    file_sha256: str = ''
    measurement_stage: str = 'reported'
    sdk_base_version: str = ''
    unity_version: str = ''

    def rows(self):
        return [dict(metric=k,value=v,unit=SPECS[k][0],state='Unknown' if v is None else 'Reported') for k,v in self.values]

    def document(self):
        stats={};phys={}
        for key,value in self.values:
            if key.startswith('physBone.'):phys[key.split('.',1)[1]]=value
            else:stats[key]=value
        stats['physBone']=phys
        return dict(schema=SCHEMA,avatar_id=self.avatar_id,platform=self.platform,sdk_version=self.sdk_version,
                    measured_at=self.measured_at,source=safe_text(self.source,160),reported_rank=self.reported_rank,stats=stats,
                    measurement_stage=self.measurement_stage,sdk_base_version=self.sdk_base_version,unity_version=self.unity_version)


def parse(document, *, expected_id='', file_sha256=''):
    if not isinstance(document,dict) or document.get('schema')!=SCHEMA: raise ValueError('Choose a VRC Eye avatar performance report (schema 1).')
    avatar_id=parse_avatar_reference(text(document.get('avatar_id'),160))
    if not avatar_id: raise ValueError('Report needs a valid avatar ID.')
    if expected_id and avatar_id!=parse_avatar_reference(expected_id): raise ValueError('Performance report belongs to a different avatar.')
    platform=document.get('platform')
    if platform not in ('standalonewindows','android','ios'): raise ValueError('Report platform must be standalonewindows, android or ios.')
    sdk=text(document.get('sdk_version'),80)
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:[-+.][A-Za-z0-9.-]+)?',sdk): raise ValueError('Report needs an explicit SDK version.')
    measured=timestamp(document.get('measured_at'));source=text(document.get('source'))
    stage=document.get('measurement_stage','reported')
    if stage not in ('reported','source','built'): raise ValueError('Unsupported measurement stage.')
    base=document.get('sdk_base_version','');unity=document.get('unity_version','')
    if base != '' and not re.fullmatch(r'\d+\.\d+\.\d+(?:[-+.][A-Za-z0-9.-]+)?',text(base,80)):
        raise ValueError('Report needs a valid Base SDK version.')
    if unity != '': unity=text(unity,80)
    rank=document.get('reported_rank')
    normalized=normalize_rank(rank)
    if rank not in (None,'','Unknown') and normalized=='Unknown': raise ValueError('Unsupported reported performance rank.')
    stats=document.get('stats')
    if not isinstance(stats,dict) or len(stats)>80: raise ValueError('Report needs a bounded stats object.')
    phys=stats.get('physBone',{})
    if phys is None: phys={}
    if not isinstance(phys,dict) or len(phys)>16: raise ValueError('PhysBone stats must be an object or null.')
    flat={k:v for k,v in stats.items() if k!='physBone'}
    flat.update({'physBone.'+k:v for k,v in phys.items()})
    if not any(k in SPECS for k in flat): raise ValueError('Report has no recognized counters.')
    values=[]
    for key,(unit,kind) in SPECS.items():
        value=flat.get(key)
        if value is not None:
            valid=(type(value) is bool if kind=='boolean' else
                   type(value) is int and 0<=value<=2**53-1 if kind=='integer' else
                   type(value) in (int,float) and math.isfinite(value) and 0<=value<=10**9)
            if not valid: raise ValueError('Invalid value for '+key+'. Missing values must be null, not a guessed zero.')
        values.append((key,value))
    unknown=tuple(sorted(text(k,100) for k in flat if k not in SPECS))
    return PerformanceReport(avatar_id,platform,sdk,measured,source,normalized,tuple(values),unknown,file_sha256,stage,base,unity)


def read(path, *, expected_id='', stop=None):
    document,digest=json_file(path,stop=stop)
    return parse(document,expected_id=expected_id,file_sha256=digest)


def compare(baseline,current):
    if (baseline.avatar_id,baseline.platform,baseline.sdk_version)!=(current.avatar_id,current.platform,current.sdk_version):
        raise ValueError('Compare reports for the same avatar, platform and SDK version.')
    if (baseline.measurement_stage,baseline.sdk_base_version,baseline.unity_version)!=(current.measurement_stage,current.sdk_base_version,current.unity_version):
        raise ValueError('Compare matching measurement stages, Base SDK and Unity versions; unknown context does not match supplied context.')
    old=dict(baseline.values);rows=[]
    for key,after in current.values:
        before=old.get(key);kind=SPECS[key][1]
        delta=None if before is None or after is None or kind=='boolean' else after-before
        rows.append(dict(metric=key,before=before,after=after,delta=delta,unit=SPECS[key][0],
                         state='Unknown comparison' if before is None or after is None else 'Unchanged' if before==after else 'Changed'))
    return dict(schema='vrc-eye-performance-comparison-1',avatar_id=current.avatar_id,platform=current.platform,sdk_version=current.sdk_version,
                measurement_stage=current.measurement_stage,sdk_base_version=current.sdk_base_version,unity_version=current.unity_version,
                baseline_time=baseline.measured_at,current_time=current.measured_at,
                baseline_sha256=baseline.file_sha256,current_sha256=current.file_sha256,
                baseline_source=safe_text(baseline.source,160),current_source=safe_text(current.source,160),
                rows=rows,scope='Reported values only; chronological order and improvement are not inferred. No official rank is calculated.')


def template(avatar_id='avtr_00000000-0000-0000-0000-000000000001'):
    return dict(schema=SCHEMA,avatar_id=avatar_id,platform='standalonewindows',sdk_version='0.0.0',
                measured_at='2000-01-01T00:00:00Z',source='Replace with the actual SDK/exporter and observation time',
                reported_rank=None,stats=dict(polyCount=None,textureMegabytes=None,downloadSizeBytes=None,uncompressedSizeBytes=None,
                                             contactCount=None,constraintsCount=None,constraintDepth=None,raycastCount=None,
                                             physBone={key:None for key in PHYSBONES}))
