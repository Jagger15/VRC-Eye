"""Read-only creator metadata through the existing authenticated API session.

This route supplies evidence, never publishing or helper-control authority.
Drafts are exported for the official website / Unity SDK workflow.
"""
from datetime import datetime, timezone

from vrchat_api import APIError
from world_backup import parse_world_reference, world_identity
from vrca_files import VRCAError


def read_world(client, reference, *, stop=None, progress=None):
    try:
        reference = parse_world_reference(reference)
    except VRCAError as error:
        raise APIError(str(error)) from None
    while not client.lock.acquire(timeout=.1):
        client._check(stop)
    try:
        client._check(stop)
        if not client.authenticated:
            raise APIError("Connect VRChat to refresh creator metadata. Local drafts remain available.")
        account, revision = client.user_id, client.session_revision
        client._wait_metadata(stop, progress)
        document = client._request("worlds/" + reference)
        client._check(stop)
        try:
            author = world_identity(document, reference)
        except VRCAError as error:
            raise APIError(str(error)) from None
        if not client.authenticated or account != client.user_id or revision != client.session_revision:
            raise APIError("The account changed during the lookup. Refresh again.")
        result = {"id": reference, "authorId": author,
                  "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                  "source": "VRChat API", "account_id": account}
        for key, limit in (("name", 512), ("description", 16000), ("releaseStatus", 64)):
            if isinstance(document.get(key), str):
                result[key] = document[key][:limit]
        for key in ("capacity", "recommendedCapacity", "version"):
            value = document.get(key)
            if type(value) is int and 0 <= value <= 2**31 - 1:
                result[key] = value
        tags = document.get("tags", [])
        result["tags"] = [t[:128] for t in tags[:100] if isinstance(t, str)] if isinstance(tags, list) else []
        result["unityPackages"] = []
        packages = document.get("unityPackages", [])
        if isinstance(packages, list):
            for package in packages[:100]:
                if not isinstance(package, dict):
                    continue
                slim = {k: package[k] for k in ("platform", "unityVersion", "created_at")
                        if isinstance(package.get(k), str) and len(package[k]) <= 128}
                for key in ("assetVersion", "unitySortNumber"):
                    if type(package.get(key)) is int:
                        slim[key] = package[key]
                if slim.get("platform"):
                    result["unityPackages"].append(slim)
        return result
    finally:
        client.lock.release()
