"""Optional MPRIS adapter. Session bus only; never launches a player.

Protocol: https://specifications.freedesktop.org/mpris/latest/Player_Interface.html
dbus-next aio calls are bounded. Each action targets a unique bus owner and
rechecks metadata/capabilities immediately before dispatch. No shell command.
"""
import asyncio
import re
from media_model import session, validate_operation

PLAYER = 'org.mpris.MediaPlayer2.Player'
PATH = '/org/mpris/MediaPlayer2'


def unwrap(value):
    if hasattr(value, 'value'): return unwrap(value.value)
    if isinstance(value, dict): return {k: unwrap(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [unwrap(v) for v in value]
    return value


class LinuxMedia:
    def __init__(self, bus=None, message=None):
        self.bus, self.message = bus, message
        self.sources = {}

    async def connect(self):
        if self.bus is None:
            try:
                from dbus_next.aio import MessageBus
                from dbus_next import Message
            except ImportError:
                raise ValueError('Linux media needs optional dbus-next. Other VRC Eye features remain available.') from None
            self.message = Message
            self.bus = await asyncio.wait_for(MessageBus().connect(), 3)

    async def call(self, destination, interface, member, signature='', body=(), path=PATH):
        reply = await asyncio.wait_for(self.bus.call(self.message(destination=destination, path=path,
            interface=interface, member=member, signature=signature, body=list(body))), 2)
        if reply is None or getattr(reply, 'error_name', None): raise ValueError('MPRIS rejected or lost the selected request.')
        return unwrap(reply.body)

    async def owner(self, name):
        value = await self.call('org.freedesktop.DBus', 'org.freedesktop.DBus', 'GetNameOwner', 's', (name,), '/org/freedesktop/DBus')
        if not value or not isinstance(value[0], str) or not value[0].startswith(':'): raise ValueError('MPRIS owner unavailable.')
        return value[0]

    async def read(self, name, owner):
        values = await self.call(owner, 'org.freedesktop.DBus.Properties', 'GetAll', 's', (PLAYER,))
        if len(values) != 1 or not isinstance(values[0], dict): raise ValueError('Malformed MPRIS properties.')
        p = values[0]; meta = p.get('Metadata', {})
        if not isinstance(meta, dict): meta = {}
        artist = meta.get('xesam:artist', [])
        if isinstance(artist, list): artist = ', '.join(v[:512] for v in artist[:16] if isinstance(v, str))
        track = meta.get('mpris:trackid', '')
        if not isinstance(track, str) or not re.fullmatch(r'(?:/[A-Za-z0-9_]+)+', track) or track.endswith('/NoTrack'): track = ''
        caps = []
        if p.get('CanControl') is True:
            caps = [op for op, key in (('play','CanPlay'),('pause','CanPause'),('next','CanGoNext'),('previous','CanGoPrevious'),('seek','CanSeek')) if p.get(key) is True]
            caps.append('stop')
        def seconds(value):
            return value / 1_000_000 if type(value) is int and 0 <= value <= 31_536_000_000_000 else None
        return dict(id=name+'@'+owner, provider='MPRIS', label=name.removeprefix('org.mpris.MediaPlayer2.'),
            track=track, title=meta.get('xesam:title'), artist=artist, album=meta.get('xesam:album'),
            state=str(p.get('PlaybackStatus', '')).lower(), position=seconds(p.get('Position')),
            duration=seconds(meta.get('mpris:length')), rate=p.get('Rate',1.), capabilities=caps, url=meta.get('xesam:url'))

    async def poll(self):
        await self.connect()
        names = await self.call('org.freedesktop.DBus','org.freedesktop.DBus','ListNames', path='/org/freedesktop/DBus')
        if not names or not isinstance(names[0], list): raise ValueError('MPRIS source list unavailable.')
        result, sources = [], {}
        candidates = sorted(n for n in names[0] if isinstance(n, str) and n.startswith('org.mpris.MediaPlayer2.'))[:32]
        for name in candidates:
            try:
                owner = await self.owner(name); value = await self.read(name, owner)
                if await self.owner(name) != owner: continue
                result.append(value); sources[value['id']] = (name, owner)
            except (ValueError, asyncio.TimeoutError): continue
        self.sources = sources
        return result

    async def command(self, expected, operation, value, before_dispatch):
        target = self.sources.get(expected.id)
        if target is None: raise ValueError('The selected MPRIS session is gone.')
        name, owner = target
        if await self.owner(name) != owner: raise ValueError('MPRIS session changed.')
        current = session(await self.read(name, owner), expected.observed)
        if current.track_key != expected.track_key: raise ValueError('The track changed; review this control again.')
        validate_operation(current, operation, value)
        if await self.owner(name) != owner: raise ValueError('MPRIS session changed.')
        before_dispatch()
        if operation == 'seek':
            await self.call(owner, PLAYER, 'SetPosition', 'ox', (current.track, round(value * 1_000_000)))
        else:
            await self.call(owner, PLAYER, {'play':'Play','pause':'Pause','next':'Next','previous':'Previous','stop':'Stop'}[operation])
        return True  # method returned; effect must be observed independently

    async def close(self):
        self.sources.clear()
        if self.bus is not None:
            self.bus.disconnect(); self.bus = None
