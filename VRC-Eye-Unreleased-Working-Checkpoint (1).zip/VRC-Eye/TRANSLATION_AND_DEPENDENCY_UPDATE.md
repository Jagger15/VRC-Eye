> Retained continuation, now merged with [autonomous completion](AUTONOMOUS_COMPLETION_NOTES.md). See [current combined validation](AUTONOMOUS_COMPLETION_VALIDATION.md); numerical results below describe the earlier continuation.

# Translation and shader dependency continuation

This update continues the Development 30 source candidate in the existing working checkpoint. It adds the requested English name translation and fixes concrete shader-removal dependency gaps. It does not claim a qualified Windows/Linux executable release or complete ARC/VRCX parity.

## Translate names and public text

- **Search** and **Global quick search**: select a user, world, avatar or group, then choose **Translate name / text…**.
- **Search avatars** and **Search VRCX avatar cache**: select a completed search result and choose **Translate name / text…**.
- **Avatar Library**: select an avatar and choose **Translate name / text…** beside its detail actions.
- **Player profile**: choose **Translate name / bio…**. The currently loaded public biography is available; a name-only observation can translate its displayed name without fetching a profile.
- Existing **Accounts/Social service panels** retain **Translate selected text…** for supported profile/world/group fields, posts, descriptions and messages.

The dialog defaults to **EN-US**. Original text remains visible in a separate read-only area. Choose a field, optionally shorten the request, select DeepL API Free or Pro, enter your own DeepL API key, enable translation for that window, then review the exact text before submitting. Source-language detection is delegated to the provider. Results are labelled as machine translations; personal names, stylized spellings and invented avatar names may be approximate.

Only the selected draft and target language are submitted. Translation does not change original names, account identifiers, favorites, descriptions, avatar files or search indexes. It does not automatically translate an entire results page. Keys and translation results are not persisted. A replacement translation window clears the previous window's key and text. Cancellation retains the worker slot until it exits; no automatic retry occurs. A request already sent cannot be recalled.

Account, privacy, offline, Safe Mode, changed source text/selection and parent-window closure invalidate displayed work. UI/source checks stay on the main thread; workers use the existing context token and cancellation signal. Existing local-only source data can be translated without signing into VRChat, but the external translation provider requires internet access and its own API key. Limits remain 4,096 request characters and 64 KiB per response.

## Preserve shader dependencies during removal

The existing **Recovery working copies and history → Review selected shader install removal…** workflow now preserves:

- Literal HLSL includes, including `include_with_pragmas`, and their transitive includes.
- `UsePass` shader references in addition to existing GUID and exact-name references.
- All package files with an ambiguous matching include basename. This is deliberately conservative and does not claim exact compiler search-path resolution.
- Folder metadata while the directory remains, and dependencies shared with a partially written or interrupted second installation.

Computed/unsupported includes and binary/control-bearing dependency data stop the removal review before deletion. Comments and continued include lines are handled. Read budgets, file hashes, closed-project checks, source preservation and conditional journal undo remain enforced. VRC Eye does not launch Unity or compile shaders during removal; dynamic dependencies and real compiler/provider behavior still require Unity testing.

Implementation references: [Unity includes](https://docs.unity.cn/Documentation/Manual/shader-include-directives.html), [HLSL includes](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/dx-graphics-hlsl-appendix-pre-include), [Unity UsePass](https://docs.unity3d.com/6000.0/Documentation/Manual/SL-UsePass.html), [Unity asset metadata](https://docs.unity3d.com/6000.0/Documentation/Manual/AssetMetadata.html).

## Validation and remaining work

Final results and exact commands are recorded in `CONTINUATION_VALIDATION.json`, `validation/continuation-test-runs.json` and the final focused/portable JUnit reports. The first integrated run found the workspace lacked the project's declared soundfile dependency. It was installed only in the validation environment; application dependencies and launchers were not changed.

No live DeepL requests, live VRChat mutations, real Discord invitations or actual Unity execution were performed. Translation transport tests use a fake provider response; workflow tests exercise real callbacks with headless widgets. Windows/Linux rendering, assistive technology, native providers, Unity/SDK execution and distribution qualification remain open.

The broad ledger remains **24 VRCX partial areas, 16 ARC partial areas, and 6 missing ARC areas**. This update advances VX-DESK-18 and ARC-16 and integrates the preceding in-progress changes; it closes no broad area. The public footer and internal compatibility version are retained.
