"""Passive external-loader evidence, sharing the Installation worker owner."""
from datetime import datetime
import webbrowser

from companion_ui import Table, button, entry
from friendly_ui import flow_line as line
from installation_reports import write_document


HELP = {
    'eac': 'https://help.vrchat.com/hc/en-us/articles/8135250400915-I-m-having-issues-launching-VRChat-due-to-an-issue-with-Easy-Anti-Cheat-EAC',
    'recovery': 'https://help.vrchat.com/hc/en-us/articles/1500002247921-VRChat-keeps-crashing-or-has-issues-launching-properly',
}
BOUNDARY = ('VRChat uses EAC to block client modifications. This view reads selected files; it does not install, load, '
            'patch or remove software. Source and file markers do not certify compatibility, integrity or an active loader.')
KINDS = {'source-tree': 'Source archive / tree', 'installed-evidence': 'Installed-file evidence',
         'mixed-evidence': 'Mixed source and installed-file evidence', 'config': 'Selected configuration',
         'log': 'Selected historical log', 'unknown': 'No established loader classification'}
LABELS = {'source_versions': 'Declared source versions', 'source_targets': 'Declared build targets',
          'configs': 'Configuration declarations', 'logs': 'Historical log summaries',
          'installed_frameworks': 'Observed framework directories', 'source_root_count': 'Source marker sets',
          'installed_root_count': 'Distribution marker sets', 'weak_proxy_count': 'Weak version.dll filename markers',
          'file_count': 'Files inventoried', 'log_count': 'Log documents found', 'config_count': 'Configuration documents found'}


def display_rows(summary):
    """Present the backend's allowlisted observations without a raw JSON dump."""
    rows = []
    def visit(value, parts=()):
        if len(rows) >= 160:
            return
        if isinstance(value, dict):
            for key, child in value.items():
                visit(child, parts + (LABELS.get(key, str(key).replace('_', ' ').replace('.', ' / ').capitalize()),))
        elif isinstance(value, (list, tuple)):
            if not value:
                rows.append((' / '.join(parts), 'None observed'))
            elif all(isinstance(item, (str, int, bool)) for item in value):
                rows.append((' / '.join(parts), ', '.join(str(item) for item in value)))
            else:
                for index, child in enumerate(value[:32]):
                    visit(child, parts + (str(index + 1),))
        else:
            label = 'Unknown' if value is None else 'Yes' if value is True else 'No' if value is False else 'Empty' if value == '' else str(value)
            rows.append((' / '.join(parts), label))
    visit(summary)
    return rows


class LoaderInspectionPanel:
    def __init__(self, page, parent, *, owner):
        self.page, self.owner = page, owner
        self.generation = 0
        self.snapshot = None
        self.target = page.tk.StringVar()
        self.summary = page.tk.StringVar(value='Choose a source ZIP, folder, Loader.cfg or historical log. Opening this tab starts no scan.')
        self.findings = page.tk.StringVar(value='No loader evidence loaded.')
        self.detail = page.tk.StringVar(value='Select an observation to read its complete value.')
        from ui_theme import responsive_wrap
        responsive_wrap(page.ttk.Label(parent, text=BOUNDARY, style='Muted.TLabel', wraplength=900)).pack(anchor='w', pady=4)
        row = line(page, parent)
        self.path_entry = entry(page, row, self.target, 50)
        self.path_entry.pack_configure(fill='x', expand=True)
        button(page, row, 'Folder…', lambda: self.choose('folder'))
        button(page, row, 'File…', lambda: self.choose('file'))
        row = line(page, parent)
        button(page, row, 'Inspect loader evidence', self.inspect)
        button(page, row, 'Cancel', self.owner.cancel)
        button(page, row, 'Clear', self.clear)
        button(page, row, 'Export diagnostic report…', self.export)
        row = line(page, parent)
        button(page, row, 'Official EAC help', lambda: self.help('eac'))
        button(page, row, 'Official launch recovery', lambda: self.help('recovery'))
        for variable in (self.summary, self.findings):
            responsive_wrap(page.ttk.Label(parent, textvariable=variable, wraplength=900, justify='left')).pack(anchor='w', pady=4)
        self.table = Table(page, parent, (('field', 'Evidence / setting', 410), ('value', 'Observed value', 420)), height=7, select=self.selected)
        responsive_wrap(page.ttk.Label(parent, textvariable=self.detail, wraplength=900, justify='left')).pack(anchor='w', pady=4)
        self.target.trace_add('write', self.changed)

    def changed(self, *_):
        self.generation += 1
        self.owner.cancel()
        self.snapshot = None
        self.render()

    def clear(self):
        self.owner.cancel()
        self.generation += 1
        self.snapshot = None
        self.target.set('')
        self.render()

    def choose(self, kind):
        self.owner.idle()
        token = (self.generation, self.page.context())
        from tkinter import filedialog
        if kind == 'folder':
            target = filedialog.askdirectory(parent=self.page.app.root, title='Select a folder for external loader evidence')
        else:
            target = filedialog.askopenfilename(parent=self.page.app.root, title='Select a source ZIP, Loader.cfg or historical log',
                filetypes=(('Source archives, configuration and logs', '*.zip *.cfg *.log'), ('ZIP archives', '*.zip'),
                           ('Loader configuration', '*.cfg'), ('Historical logs', '*.log')))
        if token != (self.generation, self.page.context()):
            raise ValueError('The context changed while choosing loader evidence. Choose again.')
        if target:
            self.target.set(target)

    def inspect(self):
        self.owner.idle()
        target = self.target.get().strip()
        if not target:
            raise ValueError('Choose a source ZIP, folder, Loader.cfg or historical log first.')
        from loader_inspection import inspect
        self.snapshot = None
        self.render()
        token = (self.generation, self.page.context())
        def done(snapshot):
            if token != (self.generation, self.page.context()):
                return
            self.snapshot = snapshot
            self.render()
            self.page.status.set('Loader evidence captured.')
        self.owner.run(lambda stop, progress: inspect(target, stop=stop, progress=progress), done)

    def render(self):
        if self.snapshot is None:
            self.summary.set('Choose a source ZIP, folder, Loader.cfg or historical log, then Inspect loader evidence.')
            self.findings.set('No loader evidence loaded.')
            self.table.set([], lambda row:row)
            self.selected()
            return
        snapshot = self.snapshot
        self.summary.set(KINDS.get(snapshot.artifact_kind, 'Unknown evidence') +
            '\nObserved: ' + datetime.fromtimestamp(snapshot.observed_at).isoformat(timespec='seconds') +
            ' · Inventory: ' + ('complete' if snapshot.inventory_complete else 'partial') +
            ' · Parsing: ' + ('complete within declared scope' if snapshot.metadata_complete else 'partial / limited') +
            '\nConfiguration values are declarations; launch options and later changes can differ. Logs are historical observations.')
        self.findings.set('\n'.join(snapshot.findings) or 'No additional findings within this inspection scope.')
        self.table.set(display_rows(snapshot.summary), lambda row:row)
        self.selected()

    def selected(self):
        row = self.table.selected()
        self.detail.set(row[0] + '\n' + row[1] if row else 'Select an observation to read its complete value.')

    def export(self):
        self.owner.idle()
        snapshot = self.snapshot
        if snapshot is None:
            raise ValueError('Inspect loader evidence before exporting a report.')
        from loader_inspection import report_document
        document = report_document(snapshot)
        token = (self.generation, self.page.context(), self.owner.generation)
        def fresh():
            if token != (self.generation, self.page.context(), self.owner.generation) or snapshot is not self.snapshot:
                raise ValueError('The loader evidence context changed. Review the export again.')
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.page.app.root, title='Save external loader diagnostic report',
            defaultextension='.json', initialfile='vrc-eye-loader-diagnostics.json', filetypes=(('JSON report', '*.json'),))
        if not path:
            return
        fresh()
        if not self.page.confirm('Review loader diagnostic export',
            'Save this frozen diagnostic report?\n\nIncludes observation time, source kind, fixed marker categories, '
            'allowlisted settings and log summaries. Excludes local paths, arbitrary filenames, raw logs, command lines '
            'and mod preference values. It is not a compatibility or integrity certificate.\n\n'
            'Existing files are never overwritten.\nDestination: ' + path):
            return
        fresh()
        self.owner.run(lambda stop, progress: write_document(path, document, stop=stop, before_commit=fresh),
                       lambda result:self.page.status.set('Saved external loader diagnostic report: ' + result))

    def help(self, key):
        webbrowser.open(HELP[key])
        self.page.status.set('Official help requested in your browser; no repair action was run.')
