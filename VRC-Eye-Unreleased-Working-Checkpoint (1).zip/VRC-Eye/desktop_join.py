"""Reviewed native VRChat URI handoff; destinations stay in RAM."""
import os
import shutil
import subprocess
import time
import uuid
from urllib.parse import urlencode
import world_visits as visits
from player_api import check_context


def handoff(uri):
    if os.name=='nt':os.startfile(uri);return True
    executable=shutil.which('xdg-open')
    if not executable:raise ValueError('No desktop URI handler is available.')
    return subprocess.run([executable,uri],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=15,shell=False).returncode==0


def dispatch(client,*,snapshot,coordinator,review,context,stop=None,progress=None,before_dispatch=None,on_confirmed=None,opener=handoff):
    visits.validate_snapshot(client,snapshot,instance=True)
    current=visits.read_instance(client,snapshot.location,stop=stop,progress=progress)
    visits.validate_snapshot(client,current,instance=True)
    if current.kind!=snapshot.kind or current.owner!=snapshot.owner:raise ValueError('The inspected instance changed after review.')
    lease=coordinator.reserve_action(review,context,expected_kind='launch');attempted=False
    try:
        check_context(client,snapshot.account,stop)
        if before_dispatch:before_dispatch()
        check_context(client,snapshot.account,stop)
        attempted=True
        if not opener('vrchat://launch?'+urlencode({'ref':'vrceye','id':current.location})):raise OSError('The operating system did not acknowledge a VRChat URI handler.')
        if on_confirmed:on_confirmed()
        return 'The operating system accepted the VRChat destination handoff. Game launch, access and arrival remain unconfirmed.'
    finally:coordinator.finish_action(lease,completed=attempted)


class JoinQueue:
    def __init__(self,*,clock=time.monotonic):self.clock=clock;self.items=[];self.context=None
    def sync(self,context,private=False):
        if private or context!=self.context:self.items=[];self.context=context
        self.items=[r for r in self.items if self.clock()-r['created']<900]
    def add(self,snapshot,context):
        self.sync(context);visits.location(snapshot.location)
        if len(self.items)>=20:raise ValueError('Keep at most 20 destinations in the session queue.')
        if any(r['snapshot'].location==snapshot.location for r in self.items):raise ValueError('This exact destination is already queued.')
        row=dict(id=uuid.uuid4().hex,snapshot=snapshot,created=self.clock());self.items.append(row);return row
    def remove(self,ref):self.items=[r for r in self.items if r['id']!=ref]
