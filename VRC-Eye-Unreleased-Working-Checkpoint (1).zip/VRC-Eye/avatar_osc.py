"""Bounded stock-client OSC codec and explicit local transport.

Nothing binds, discovers, or fetches at import time. The optional OSCQuery
reader takes an explicit loopback HTTP URL; it does not advertise mDNS services.
OSC observations establish neither author identity nor user authorization.
"""
from collections import deque
from dataclasses import dataclass
import http.client
import json
import math
import re
import socket
import struct
import threading
import time
from urllib.parse import urlsplit

MAX_PACKET = 8192
MAX_MESSAGES = 64
MAX_DOCUMENT = 524288
PARAMETER_PREFIX = "/avatar/parameters/"
AVATAR_CHANGE = "/avatar/change"
AVATAR_ID = re.compile(r"avtr_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z")


class OSCError(ValueError):
    pass


def port(value, *, ephemeral=False):
    if isinstance(value, bool) or not re.fullmatch(r"\d{1,5}", str(value)):
        raise OSCError("Port must be an integer from 1 to 65535.")
    result = int(value)
    if not (0 if ephemeral else 1) <= result <= 65535:
        raise OSCError("Port must be an integer from 1 to 65535.")
    return result


def _address(value):
    if not isinstance(value, str) or not re.fullmatch(r"/[A-Za-z0-9_./-]{1,254}", value):
        raise OSCError("Use a literal OSC address with at most 255 characters.")
    return value


def _pack_string(value):
    if not isinstance(value, str) or "\0" in value:
        raise OSCError("Invalid OSC string.")
    raw = value.encode("utf-8") + b"\0"
    if len(raw) > 1024:
        raise OSCError("OSC string is too long.")
    return raw + b"\0" * (-len(raw) % 4)


@dataclass(frozen=True)
class OSCMessage:
    address: str
    value: object
    type: str


def encode_message(address, value):
    """Encode one Bool/Int/Float, or the avatar-change string notification."""
    _address(address)
    if type(value) is bool:
        payload = _pack_string(",T" if value else ",F")
    elif type(value) is int and -(2 ** 31) <= value < 2 ** 31:
        payload = _pack_string(",i") + struct.pack(">i", value)
    elif type(value) is float and math.isfinite(value):
        try:
            payload = _pack_string(",f") + struct.pack(">f", value)
        except (OverflowError, struct.error):
            raise OSCError("OSC float is outside the finite 32-bit range.") from None
    elif address == AVATAR_CHANGE and isinstance(value, str) and AVATAR_ID.fullmatch(value):
        payload = _pack_string(",s") + _pack_string(value)
    else:
        raise OSCError("Expected Bool, Int, finite Float, or an avatar-change ID.")
    return _pack_string(address) + payload


def decode_packet(data):
    """All-or-nothing parsing of single messages and bounded immediate bundles."""
    if not isinstance(data, bytes) or not data or len(data) > MAX_PACKET or len(data) % 4:
        raise OSCError("Invalid OSC packet size.")
    messages, count = [], [0]

    def string(block, offset):
        end = block.find(b"\0", offset)
        following = (end + 4) & ~3
        if end < 0 or end - offset > 1024 or following > len(block) or any(block[end:following]):
            raise OSCError("Invalid OSC string or padding.")
        try:
            return block[offset:end].decode("utf-8"), following
        except UnicodeError:
            raise OSCError("Invalid OSC text.") from None

    def decode(block, depth):
        count[0] += 1
        if depth > 4 or count[0] > MAX_MESSAGES:
            raise OSCError("OSC bundle limit exceeded.")
        if block.startswith(b"#bundle\0"):
            if len(block) < 16 or block[8:16] != struct.pack(">Q", 1):
                raise OSCError("Only immediate OSC bundles are accepted.")
            offset = 16
            while offset < len(block):
                if offset + 4 > len(block):
                    raise OSCError("Truncated OSC bundle.")
                size = struct.unpack_from(">i", block, offset)[0]
                offset += 4
                if size <= 0 or size % 4 or offset + size > len(block):
                    raise OSCError("Invalid OSC bundle element.")
                decode(block[offset:offset + size], depth + 1)
                offset += size
            return
        address, offset = string(block, 0)
        _address(address)
        tags, offset = string(block, offset)
        if tags in (",i", ",f") and len(block) == offset + 4:
            kind = "Int" if tags == ",i" else "Float"
            value = struct.unpack_from(">i" if tags == ",i" else ">f", block, offset)[0]
            if kind == "Float" and not math.isfinite(value):
                raise OSCError("Non-finite OSC value.")
        elif tags in (",T", ",F") and len(block) == offset:
            kind, value = "Bool", tags == ",T"
        elif tags == ",s" and address == AVATAR_CHANGE:
            value, offset = string(block, offset)
            if offset != len(block) or not AVATAR_ID.fullmatch(value):
                raise OSCError("Invalid avatar-change notification.")
            kind = "String"
        else:
            raise OSCError("Unsupported OSC arguments.")
        messages.append(OSCMessage(address, value, kind))

    decode(data, 0)
    return tuple(messages)


@dataclass(frozen=True)
class OSCPacket:
    messages: tuple
    source: tuple
    received_at: float
    generation: int


class LocalOSC:
    """Exclusive IPv4 loopback socket with a bounded receive queue.

    Source-port pinning belongs to AvatarLink because a VRChat sending port is
    not guaranteed to equal its incoming port. No port reuse or takeover.
    """
    def __init__(self, clock=time.monotonic, max_queue=128):
        self.clock = clock
        self._queue = deque(maxlen=min(max(int(max_queue), 1), 512))
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._socket = self._thread = None
        self.generation = 0
        self.receive_port = self.target_port = 0
        self.dropped = self.invalid = 0
        self.error = ""

    @property
    def connected(self):
        return self._socket is not None and not self._stop.is_set()

    def connect(self, receive_port=9001, target_port=9000):
        receive_port, target_port = port(receive_port, ephemeral=True), port(target_port)
        self.close()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            sock.bind(("127.0.0.1", receive_port))
            sock.settimeout(0.1)
        except OSError as exc:
            sock.close()
            raise OSCError("OSC listening port is unavailable; choose an unused port and configure VRChat explicitly. " + str(exc)) from None
        self.generation += 1
        self.receive_port, self.target_port = sock.getsockname()[1], target_port
        self._stop = threading.Event()
        self._socket = sock
        generation, stop = self.generation, self._stop
        self._thread = threading.Thread(target=self._receive, args=(sock, stop, generation), daemon=True, name="AvatarLink OSC")
        self._thread.start()
        return self.receive_port

    def _receive(self, sock, stop, generation):
        window, count = self.clock(), 0
        while not stop.is_set():
            try:
                data, source = sock.recvfrom(MAX_PACKET + 1)
                now = self.clock()
                if now - window >= 1:
                    window, count = now, 0
                count += 1
                if source[0] != "127.0.0.1" or count > 512:
                    self.dropped += 1
                    continue
                messages = decode_packet(data)
                with self._lock:
                    if len(self._queue) == self._queue.maxlen:
                        self.dropped += 1
                    self._queue.append(OSCPacket(messages, source, now, generation))
            except socket.timeout:
                continue
            except OSCError:
                self.invalid += 1
            except OSError as exc:
                if not stop.is_set():
                    self.error = str(exc)[:200]
                    stop.set()
                break

    def drain(self, limit=128):
        with self._lock:
            return tuple(self._queue.popleft() for _ in range(min(len(self._queue), max(0, min(limit, 512)))))

    def send(self, address, value):
        if not self.connected:
            raise OSCError("OSC is disconnected.")
        # Never permit avatar switching, chatbox messages, or generic inputs.
        if not address.startswith(PARAMETER_PREFIX):
            raise OSCError("Only declared avatar parameter messages may be sent.")
        payload = encode_message(address, value)
        try:
            self._socket.sendto(payload, ("127.0.0.1", self.target_port))
        except OSError as exc:
            raise OSCError("OSC send failed: " + str(exc)) from None

    def close(self):
        self._stop.set()
        sock, thread = self._socket, self._thread
        self._socket = self._thread = None
        if sock is not None:
            sock.close()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=0.4)
        self.generation += 1
        with self._lock:
            self._queue.clear()


def _document(source):
    if isinstance(source, dict):
        source = json.dumps(source, allow_nan=False)
    if isinstance(source, str):
        source = source.encode("utf-8")
    if not isinstance(source, bytes) or len(source) > MAX_DOCUMENT:
        raise OSCError("OSC discovery document is too large or invalid.")
    try:
        result = json.loads(source, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (ValueError, UnicodeError, RecursionError):
        raise OSCError("Invalid OSC discovery JSON.") from None
    if not isinstance(result, dict):
        raise OSCError("OSC discovery document must be an object.")
    return result


def read_config(source):
    """Inspect supplied file contents, never search for or modify VRChat files."""
    doc = _document(source)
    if not isinstance(doc.get("id"), str) or not AVATAR_ID.fullmatch(doc["id"]):
        raise OSCError("Configuration needs a published avatar ID.")
    params = doc.get("parameters")
    if not isinstance(params, list) or len(params) > 1024:
        raise OSCError("Invalid OSC configuration parameter list.")
    found, names = [], set()
    for raw in params:
        if not isinstance(raw, dict) or not isinstance(raw.get("name"), str) or not 1 <= len(raw["name"]) <= 128 or raw["name"] in names:
            raise OSCError("Invalid or duplicate configuration parameter.")
        names.add(raw["name"])
        item = {"name": raw["name"]}
        for direction in ("input", "output"):
            if direction in raw:
                route = raw[direction]
                if not isinstance(route, dict) or route.get("type") not in ("Bool", "bool", "Int", "Float"):
                    raise OSCError("Unsupported configuration parameter type.")
                item[direction] = {"address": _address(route.get("address")), "type": "Bool" if route["type"] == "bool" else route["type"]}
        found.append(item)
    return {"avatar_id": doc["id"].lower(), "parameters": found, "source": "configuration", "read_only": True,
            "notice": "Inspection only. Build & Test may have no config; configuration files may change. Names do not prove authorship or permission."}


def query_endpoint(url):
    """Read one explicitly chosen local OSCQuery tree with no redirects/mDNS."""
    try:
        parsed = urlsplit(url)
        target_port = parsed.port
    except (TypeError, ValueError):
        raise OSCError("Use http://127.0.0.1:PORT/ for explicit local OSCQuery inspection.") from None
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.username or parsed.password or parsed.fragment or parsed.query or parsed.path not in ("", "/") or target_port is None:
        raise OSCError("Use http://127.0.0.1:PORT/ for explicit local OSCQuery inspection.")
    connection = http.client.HTTPConnection("127.0.0.1", port(target_port), timeout=1.5)
    timer = None
    try:
        connection.request("GET", "/", headers={"Accept": "application/json", "Connection": "close"})
        request_socket = connection.sock
        def end_read():
            # A per-read socket timeout alone permits an endless slow stream.
            # Bound the entire response, including headers, to 1.5 seconds.
            try:
                request_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        timer = threading.Timer(1.5, end_read)
        timer.daemon = True
        timer.start()
        response = connection.getresponse()
        if response.status != 200:
            raise OSCError("OSCQuery returned a non-success response; redirects are not followed.")
        doc = _document(response.read(MAX_DOCUMENT + 1))
    except (OSError, http.client.HTTPException) as exc:
        raise OSCError("Local OSCQuery inspection failed: " + str(exc)) from None
    finally:
        if timer is not None:
            timer.cancel()
        connection.close()
    parameters, count = [], [0]

    def walk(node, depth):
        count[0] += 1
        if not isinstance(node, dict) or depth > 16 or count[0] > 2048:
            raise OSCError("OSCQuery tree exceeds limits.")
        address = node.get("FULL_PATH", "")
        if isinstance(address, str) and address.startswith(PARAMETER_PREFIX):
            _address(address)
            kind = node.get("TYPE")
            if kind in ("i", "f", "T", "F"):
                parameters.append({"address": address, "type": {"i": "Int", "f": "Float", "T": "Bool", "F": "Bool"}[kind], "access": node.get("ACCESS") if type(node.get("ACCESS")) is int else None})
        children = node.get("CONTENTS", {})
        if not isinstance(children, dict) or len(children) > 1024:
            raise OSCError("Invalid OSCQuery contents.")
        for child in children.values():
            walk(child, depth + 1)

    walk(doc, 0)
    return {"endpoint": f"http://127.0.0.1:{target_port}/", "parameters": parameters,
            "source": "OSCQuery", "read_only": True,
            "notice": "Discovered parameter declarations only; no mDNS advertisement, route changes, or authorization."}
