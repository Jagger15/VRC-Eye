"""Avatar performance and local shader report viewer."""

from text_viewport import window_body

import json
from pathlib import Path

from avatar_performance import parse_performance
from shader_watch import MAX_REPORT_BYTES, SCOPE, parse_shader_report


def show_inspection_dialog(app, event):
    from tkinter import filedialog, messagebox
    from online_dialog import lookup_online
    tk, ttk = app.tk, app.ttk
    link, generation = app.avatar_links[event], app.data_generation
    reference = link[0]
    window = tk.Toplevel(app.root)
    window.title("VRC Eye · Performance & Shader Watch")
    window.geometry("900x720")
    window.minsize(760, 580)
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Performance & Shader Watch", font='EyeTitleFont').pack(anchor="w")
    ttk.Label(frame, text=f"{event.avatar}\n{reference}\nAssociation: {link[1]} (not verified by the log)",
              wraplength=830).pack(anchor="w", pady=(8, 12))
    ttk.Label(frame, text=("Performance comes from VRChat's reported platform ratings. Multiple builds means the "
        "metadata disagrees; individual build ratings appear below. Shader names require a local Unity report. "
        "The API and ordinary logs do not provide a complete shader inventory."),
        style="Muted.TLabel", wraplength=830).pack(anchor="w", pady=(0, 12))
    area = ttk.Frame(frame)
    area.pack(fill="both", expand=True)
    text = tk.Text(area, wrap="word", bg=app.PANEL, fg=app.TEXT, insertbackground=app.TEXT)
    text.pack(side="left", fill="both", expand=True)
    scroll = ttk.Scrollbar(area, orient="vertical", command=text.yview)
    scroll.pack(side="right", fill="y")
    text.configure(yscrollcommand=scroll.set)

    def current():
        if not app.event_context_current(event, link, generation):
            raise ValueError("The row or session changed. Reopen this viewer for the current avatar.")

    def render():
        if not window.winfo_exists():
            return
        record = app.avatar_performance.get(reference)
        lines = ["PERFORMANCE", record.label if record else "PC: Unknown | iOS: Unknown | Android: Unknown"]
        if record:
            lines += [f"Source: {record.source} · checked/imported {record.checked_at}",
                      "Snapshot of the selected avatar ID; rank at the log-event time is unknown.", *record.builds]
        lines += ["", "SHADER WATCH", SCOPE]
        reports = app.shader_reports.get(reference, {})
        if not reports:
            lines += ["Unavailable — no local shader report loaded.",
                "Copy Unity/Editor/VRCEyeShaderReport.cs into your avatar project's Assets/Editor folder.",
                "Select the avatar root, then Tools > VRC Eye > Export shader report. Import that CSV here."]
        for platform, report in sorted(reports.items()):
            lines += ["", f"{platform} · user-supplied Unity report · captured {report.captured_at}",
                      f"{len(report.shaders)} named shaders / {len(report.rows)} material slots"]
            lines += [f"• {shader}" for shader in report.shaders]
            lines += ["", "Material slots:"]
            lines += [f"{renderer}  |  {material}  →  {shader}" for renderer, material, shader in report.rows]
        text.configure(state="normal")
        text.delete("1.0", "end")
        text.insert("1.0", "\n".join(lines))
        text.configure(state="disabled")

    def import_data(shaders=False):
        path = filedialog.askopenfilename(parent=window,
            title="Select Unity shader report" if shaders else "Select avatar JSON backup",
            filetypes=[("Shader CSV", "*.csv")] if shaders else [("Avatar JSON", "*.json")])
        if not path:
            return
        try:
            current()
            with Path(path).open("rb") as stream:
                content = stream.read(MAX_REPORT_BYTES + 1)
            if len(content) > MAX_REPORT_BYTES:
                raise ValueError("The file exceeds the 2 MiB limit.")
            content = content.decode("utf-8-sig")
            if shaders:
                report = parse_shader_report(content, reference)
                app.remember_shader_report(event, report, link=link, generation=generation)
            else:
                record = parse_performance(json.loads(content), reference)
                app.remember_performance(event, record, link=link, generation=generation)
            render()
        except (OSError, ValueError, UnicodeError, RecursionError) as error:
            messagebox.showerror("Could not import details", str(error), parent=window)

    def online():
        previous = app.avatar_performance.get(reference)
        def apply(result):
            current()
            if app.avatar_performance.get(reference) is not previous:
                raise ValueError("Performance data changed during the lookup. Look up again.")
            if result.performance is None:
                raise ValueError("No performance metadata was returned.")
            app.remember_performance(event, result.performance, link=link, generation=generation)
            render()
        lookup_online(app, "avatar", reference, apply, parent=window, on_fallback=import_data)

    buttons = ttk.Frame(frame)
    buttons.pack(fill="x", pady=(12, 0))
    ttk.Button(buttons, text="Look up ratings online", command=online, style="Accent.TButton").pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Import avatar JSON…", command=import_data).pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Import shader CSV…", command=lambda: import_data(True)).pack(side="left")
    ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right")
    render()
    if app.api and app.api.authenticated and reference not in app.avatar_performance:
        online()
