"""Opt-in local mixer UI. Construction never enumerates or opens audio devices."""
import queue
import threading
from audio_engine import AudioEngine
from audio_mixer import Channel, dbfs


class AudioPanel:
    def __init__(self, page, parent, *, engine=None):
        self.page, self.app = page, page.app
        self.tk, self.ttk = page.tk, page.ttk
        from local_audio import engine_for
        self.engine = engine if engine is not None else engine_for(self.app)
        self.closed, self.job = False, None
        self.revision, self.context = 0, self._context()
        self.results = queue.Queue(maxsize=1)
        self.devices, self.inputs, self.outputs, self.controls = (), {}, {}, {}
        ttk, tk = self.ttk, self.tk
        ttk.Label(parent, text="Local audio mixer", style="Heading.TLabel").pack(anchor="w", pady=(6, 4))
        ttk.Label(parent, text="Choose named capture devices and outputs. Player metadata does not provide audio samples.\nPrivate cue only enters your monitor. VRChat input selection must be configured in the game.", wraplength=950).pack(anchor="w")
        row = ttk.Frame(parent); row.pack(fill="x", pady=8)
        ttk.Button(row, text="Discover audio devices", command=self.discover).pack(side="left")
        ttk.Button(row, text="Test microphone levels", command=self.test).pack(side="left", padx=6)
        ttk.Button(row, text="Start selected mix", command=self.start).pack(side="left")
        ttk.Button(row, text="Stop audio", command=self.stop).pack(side="left", padx=6)
        ttk.Button(row, text="Retry device release", command=self.retry_cleanup).pack(side="left")
        grid = ttk.Frame(parent); grid.pack(fill="x")
        for col, text in enumerate(("Input", "Selected capture device", "Gain", "Mute", "Monitor", "Outgoing")):
            ttk.Label(grid, text=text).grid(row=0, column=col, sticky="w", padx=4)
        for i, (role, label) in enumerate((("microphone", "Microphone"), ("music", "Music input"), ("cue", "Private cue")), 1):
            ttk.Label(grid, text=label).grid(row=i, column=0, sticky="w", padx=4, pady=5)
            box = ttk.Combobox(grid, state="readonly", width=38, values=("Off",)); box.set("Off")
            box.grid(row=i, column=1, sticky="ew", padx=4); self.inputs[role] = box
            gain, mute, monitor, outgoing = tk.DoubleVar(value=.5), tk.BooleanVar(value=False), tk.BooleanVar(value=False), tk.BooleanVar(value=False)
            self.controls[role] = (gain, mute, monitor, outgoing)
            ttk.Scale(grid, from_=0, to=1, variable=gain, length=90, command=lambda *_: self.configure()).grid(row=i, column=2, padx=4)
            for j, variable in enumerate((mute, monitor, outgoing), 3):
                button = ttk.Checkbutton(grid, variable=variable, command=self.configure)
                button.grid(row=i, column=j)
                if role == "cue" and j == 5:
                    button.state(["disabled"])
        grid.columnconfigure(1, weight=1)
        for role, label in (("monitor", "Monitor / headphones"), ("outgoing", "Outgoing virtual endpoint")):
            row = ttk.Frame(parent); row.pack(fill="x", pady=4)
            ttk.Label(row, text=label, width=28).pack(side="left")
            box = ttk.Combobox(row, state="readonly", width=55, values=("Off",)); box.set("Off")
            box.pack(side="left", fill="x", expand=True); self.outputs[role] = box
        self.arm = tk.BooleanVar(value=False)
        ttk.Checkbutton(parent, text="Enable the selected outgoing endpoint for this session", variable=self.arm,
                        command=self._arm_changed).pack(anchor="w", pady=4)
        ttk.Label(parent, text="Use headphones. A loopback input may include game return audio. No driver is installed and no system default is changed.\n48 kHz float capture · stereo output · linked sample-peak limiter (−1 dBFS ceiling). Device changes require Stop and Start.", wraplength=950, style="Muted.TLabel").pack(anchor="w")
        self.status = tk.StringVar(value=self.engine.state)
        self.last_engine_state = self.engine.state
        ttk.Label(parent, textvariable=self.status, wraplength=950).pack(anchor="w", pady=6)
        self.meters = tk.StringVar(value="Digital peaks: no samples")
        ttk.Label(parent, textvariable=self.meters).pack(anchor="w")
        self.canvas = tk.Canvas(parent, height=65, highlightthickness=0, background="#15212b")
        from color_vision import canvas_ink
        canvas_ink(self.canvas)
        self.canvas.pack(fill="x", pady=6)
        self.configure()

    def _context(self):
        api = getattr(self.app, "api", None)
        private = getattr(self.page, "private", None)
        return (id(api), getattr(api, "session_revision", 0), getattr(api, "authenticated", False),
                getattr(api, "user_id", ""), getattr(self.app, "data_generation", 0),
                getattr(self.app, "demo", False), getattr(self.app, "safe_mode", False),
                private.get() if private is not None else False)

    def _allowed(self):
        if self.closed or getattr(self.app, "demo", False) or getattr(self.app, "safe_mode", False):
            raise ValueError("Live audio is off in Demo and Safe Mode.")
        context = self._context()
        if context != self.context:
            self.context = context
            self.stop()
            raise ValueError("Audio context changed; review the selected devices and start again.")

    def _launch(self, work, done):
        # A finished thread still owns its undelivered result. Do not start
        # another setup while that completion occupies the bounded mailbox.
        if self.job is not None:
            self.status.set("Wait for the current audio operation to stop."); return
        rev = self.revision
        def run():
            value, error = None, None
            try:
                if not self.closed and rev == self.revision:
                    value = work()
            except Exception as exc:
                error = str(exc)[:240]
            # Close never waits for a UI tick, and no worker can block trying
            # to deliver into a destroyed page. Cancelled jobs still retire on
            # the UI thread when their completion is consumed.
            if not self.closed:
                try:
                    self.results.put_nowait((rev, done, value, error))
                except queue.Full:
                    pass
        self.job = threading.Thread(target=run, daemon=True, name="Eye audio setup")
        self.job.start()

    def discover(self):
        try:
            self._allowed()
            if self.engine.running:
                raise ValueError("Stop audio before refreshing devices.")
            self.status.set("Discovering audio devices…")
            def done(devices):
                self.devices = devices
                for boxes, field in ((self.inputs, "inputs"), (self.outputs, "outputs")):
                    labels = [d.label for d in devices if getattr(d, field) > 0]
                    for box in boxes.values():
                        old = box.get(); box.configure(values=("Off", *labels))
                        box.set(old if old in labels else "Off")
                self.status.set(f"{len(devices)} endpoints found. Select named endpoints; default aliases are unavailable for routing.")
            self._launch(self.engine.devices, done)
        except ValueError as exc:
            self.status.set(str(exc))

    def configure(self):
        self.engine.configure({name: Channel(float(v[0].get()), bool(v[1].get()),
            bool(v[3].get()) and name != "cue", bool(v[2].get())) for name, v in self.controls.items()})

    def _arm_changed(self):
        if not self.arm.get():
            self.stop()

    def _selected(self, boxes):
        index = {d.label: d for d in self.devices}
        values = {}
        for name, box in boxes.items():
            label = box.get()
            if label != "Off":
                if label not in index:
                    raise ValueError("Refresh and select the audio device again.")
                values[name] = index[label]
        return values

    def _start(self, test):
        try:
            self._allowed(); self.configure()
            sources = self._selected(self.inputs)
            outputs = {} if test else self._selected(self.outputs)
            if test:
                sources = {k: v for k, v in sources.items() if k == "microphone"}
            if "outgoing" in outputs and not self.arm.get():
                raise ValueError("Enable the selected outgoing endpoint before starting this route.")
            generation = self.engine.generation
            self._launch(lambda: self.engine.start(sources, outputs, meter_only=test,
                                                  expected_generation=generation),
                         lambda _: self.status.set(self.engine.state))
        except ValueError as exc:
            self.status.set(str(exc))

    def test(self): self._start(True)
    def start(self): self._start(False)

    def retry_cleanup(self):
        self._launch(self.engine.retry_cleanup, lambda _: self.status.set(self.engine.state))

    def stop(self):
        self.revision += 1
        self.arm.set(False)
        self.engine.stop()
        self.status.set(self.engine.state)

    def tick(self):
        if self.closed:
            return
        context = self._context()
        if context != self.context:
            self.context = context
            self.stop()
        try:
            rev, done, value, error = self.results.get_nowait()
            self.job = None
            if rev == self.revision:
                self.status.set(error) if error else done(value)
        except queue.Empty:
            pass
        state = self.engine.state
        if state != self.last_engine_state:
            self.status.set(state)
        self.last_engine_state = state
        metrics = self.engine.metrics
        inputs = " · ".join(f"{k}: {dbfs(v)} dBFS" for k, v in metrics.get("inputs", {}).items())
        out = metrics.get("outputs", {}).get("outgoing", 0)
        reduction = metrics.get("reduction_db", {}).get("outgoing", 0)
        self.meters.set(f"{inputs or 'No samples'} · Out: {dbfs(out)} dBFS · Limiter: {reduction:.1f} dB · Dropouts: {self.engine.drops}")
        from mod_tools import presentation_due
        if not presentation_due(self.app, "audio spectrum", .1):return
        from color_vision import canvas_ink
        canvas = canvas_ink(self.canvas, self.app)
        canvas.delete("all")
        width = max(1, self.canvas.winfo_width())
        for i, value in enumerate(metrics.get("spectrum", ())):
            canvas.create_rectangle(i * width / 16 + 2, 63 - 60 * value, (i + 1) * width / 16 - 2, 63, fill='@info', outline="")

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.stop(); self.engine.close()
        try:
            self.results.get_nowait()
        except queue.Empty:
            pass
