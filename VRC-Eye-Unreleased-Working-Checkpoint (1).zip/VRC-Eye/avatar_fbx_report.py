"""Bounded, declarative FBX inspection data; filenames are labels, never paths."""
from dataclasses import dataclass
from avatar_scene import integer,vector,name


@dataclass(frozen=True)
class FbxReport:
    version:int
    ascii:bool
    unit_meters:float
    axes:tuple
    fps:float
    bones:int
    meshes:tuple
    takes:tuple
    dependencies:tuple
    warnings:tuple


def decode(raw):
    if raw is None:return None
    fields={'version','ascii','unit_meters','axes','fps','bones','meshes','takes','dependencies','warnings'}
    if not isinstance(raw,dict) or set(raw)!=fields or type(raw['ascii']) is not bool:raise ValueError('Invalid FBX inspection report.')
    version=integer(raw['version'],3000,7700);axes=raw['axes']
    if not isinstance(axes,(list,tuple)) or len(axes)!=3:raise ValueError('Invalid FBX axes.')
    axes=tuple(integer(v,0,6) for v in axes)
    unit,fps=vector([raw['unit_meters'],raw['fps']],2)
    if unit<=0 or fps<=0:raise ValueError('FBX units and frame rate must be positive.')
    result=[]
    # Mesh rows: label, source vertices/faces, skin deformers, blend channels,
    # blend targets, cache deformers. Takes: label, seconds begin/end, layers.
    for field,limit,width in (('meshes',512,7),('takes',64,4),('dependencies',144,5),('warnings',64,2)):
        rows=raw[field]
        if not isinstance(rows,(list,tuple)) or len(rows)>limit:raise ValueError('FBX inspection exceeds its catalog budget.')
        output=[]
        for row in rows:
            if not isinstance(row,(list,tuple)) or len(row)!=width:raise ValueError('Invalid FBX inspection row.')
            if field=='warnings':output.append(tuple(integer(v,0,10000000) for v in row));continue
            label=row[0]
            if not isinstance(label,str) or label!=name(label,'') or not label:raise ValueError('Invalid FBX inspection label.')
            if field=='takes':
                start,end=vector(row[1:3],2)
                if end<start:raise ValueError('Invalid FBX take range.')
                output.append((label,start,end,integer(row[3],0,16384)))
            elif field=='dependencies':
                state,size,digest,used=row[1:]
                if state not in ('embedded','selected','missing','blocked','unused') or type(used) is not bool or not isinstance(digest,str) or digest and (len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest)):
                    raise ValueError('Invalid FBX dependency evidence.')
                if state in ('missing','blocked') and (size!=0 or digest or used) or state in ('embedded','selected','unused') and (size<=0 or not digest) or state=='unused' and used:
                    raise ValueError('Inconsistent FBX dependency evidence.')
                output.append((label,state,integer(size,0,16*1024**2),digest,used))
            else:output.append((label,)+tuple(integer(v,0,10000000) for v in row[1:]))
        result.append(tuple(output))
    return FbxReport(version,raw['ascii'],unit,axes,fps,integer(raw['bones'],0,16384),*result)


def describe(report):
    if report is None:return ''
    axes=('+X','−X','+Y','−Y','+Z','−Z','unknown')
    lines=[f'FBX {report.version} / {"ASCII" if report.ascii else "binary"} · ufbx 0.23.1 / Eye adapter 2',
        f'Source units: {report.unit_meters:g} meters per unit; axes right/up/front: '+', '.join(axes[v] for v in report.axes)+' (importer defaults apply when omitted)',
        'Imported in meters, right-handed Y-up; root conversion; geometric transforms applied. Default stored deformation is baked into this read-only snapshot.',
        f'Rig availability: {report.bones} bone attributes. Skin and blendshape counts below describe source data; interactive FBX posing is not enabled.',
        f'Take availability: {len(report.takes)} stacks at {report.fps:g} fps. Prepare a bounded range in Animation timeline for sampled playback; constraints are not evaluated.']
    lines+= [f'{n}: {v} control points / {f} polygons; {s} skins, {c} blend channels / {t} targets, {cache} vertex caches.' for n,v,f,s,c,t,cache in report.meshes]
    lines+= [f'Take {n}: {a:g}–{b:g} seconds, {layers} layers.' for n,a,b,layers in report.takes]
    lines+= [f'Texture {n}: {state}, {size} bytes; '+('used for diffuse preview' if used else 'not rendered')+(f'; SHA-256 {digest}' if digest else '') for n,state,size,digest,used in report.dependencies]
    lines+= [f'Importer warning type {kind}: {count} occurrence(s).' for kind,count in report.warnings]
    return '\n'.join(lines)
