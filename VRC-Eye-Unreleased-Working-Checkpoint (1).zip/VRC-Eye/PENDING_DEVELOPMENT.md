# VRC Eye — unreleased working checkpoint

Current combined source: [autonomous changes](AUTONOMOUS_COMPLETION_NOTES.md), [verification](AUTONOMOUS_COMPLETION_VALIDATION.md), and [40-area ledger](PARTIAL_COMPLETION_STATUS.md).

Retained continuation: [English name translation and shader dependency preservation](TRANSLATION_AND_DEPENDENCY_UPDATE.md). See `CONTINUATION_VALIDATION.json` for that continuation’s validation; older figures below describe their original checkpoint.

This is retained development source, not a new numbered release. The last released
baseline remains **1.21.0 Development 21**. Its internal API/peer compatibility
constants and historical release documents are retained; the public build name
now follows the calendar scheme described below.

**Release hold:** the user requested no further versioned build packages until
Development 30. Keep developing and verifying in this working tree. Do not create
Development 22–29 release ZIPs. The cumulative candidate is documented below; a milestone label does not substitute for native qualification.
Preserve future changes by updating the same working checkpoint.

## Development 30 candidate — 5 October 2026

The cumulative source candidate adds shared Steam/VRChat status and Home conditions,
revisioned Game log cards and exact navigation, a Safe Startup-compatible setup health
view, read-only database checks, metadata bookmarks/two-pack comparison, and persistent
background/rounded-control preferences. The log cursor now consumes new world/player
events without replaying source resets. Older appearance bundles remain restorable.

See [milestone acceptance and usage](DEVELOPMENT_30_MILESTONE.md) and
[final validation](DEVELOPMENT_30_VALIDATION.md). The portable development gates are
separate from native qualification. This same checkpoint retains the existing footer
and compatibility version; no numbered release has been issued.

## Dashboard and Creator recovery continuation — 5 October 2026

Home now filters every loaded row before stable sorting and 25-row paging. Each
table identifies its retained source window; saved worlds no longer compete with
events for that window. Source ages advance without starting or polling another
provider. Account/privacy/connection changes invalidate old rows. Unity runtime
events and Crash diagnostics can be added through Customize Home.

Visible Home cards count as provider consumers. When minimized or in Low power,
unused official-status polling slows to 600 seconds and Unity metadata retries
to 120 seconds. Foreground demand restores 120/30-second timing respectively;
normal request limits and failure backoff remain. Process and window checks,
protection rules, recording and recovery automation retain their normal timing.

Creator Projects copy/package jobs now create a shared repair workspace with
`raw/`, `project/` and `history/`. The reviewed command uses `project/`. Copy only,
Restore, Set exact package version and Remove package preserve the baseline;
package changes use the existing helper checkpoints and conditional undo.
Activity opens Recovery history and account-scoped durable copy-job receipts.
Interrupted jobs remain inspectable after restart, with no automatic replay.
Template creation and arbitrary Unity/editor helpers remain separate.

Validation: **310 focused tests and 18 subtests passed**. Full portable regression:
**5,389 passed, 1,065 subtests passed, 512 skipped, 1 deselected**, zero failures.
All **646 Python files** parse with Python 3.10 grammar; **666 source/test hashes**
remained unchanged during the run. See `DASHBOARD_RECOVERY_VALIDATION.md` and
`PENDING_WORKING_VALIDATION.json` → `dashboard_recovery_update` for exclusions,
recorded evidence and native acceptance limits. Four broad areas advanced;
all 40 remain Partial. The build name and release hold remain unchanged.

## Partial-area completion pass — 5 October 2026

This pass completes specific gaps inside six existing ARC/VRCX areas: reversible
GLB joint poses, material-selected UV streams and sampler filtering, indexed
vertex topology diagnostics, and broader wellness/compass settings recovery.
The settings allowlist now has **17 sections**. Named wellness-profile saves are
atomic with their selected configuration; stale wellness edits reload current
controls. Full profile recovery includes the new preference owners with inputs
and history disabled. Source files and active provider connections are preserved.

See [current partial-area status](PARTIAL_COMPLETION_STATUS.md) for usage and all
40 remaining broad areas. Six areas advanced; none is relabeled fully complete.
The six wholly missing ARC features remain deferred. Current validation is in
`PENDING_WORKING_VALIDATION.json` → `partial_completion_update`; the older dated
sections below describe their own checkpoints and section counts.

Validation: **279 focused tests passed**. Full portable regression: **5,351 passed, 1,065 subtests passed, 512 skipped, 1 deselected**, zero failures and zero blocked external-socket attempts. All **643 Python files** parse with Python 3.10 grammar; **663 source/test hashes** stayed unchanged during verification. The 13 excluded transport modules and remaining native prerequisites are listed in the validation record.

## Backup and settings recovery continuation — 5 October 2026

The next recommended recovery batch is implemented in this same unreleased
checkpoint. Open **Native data backup / restore → Backup and recovery → Verify
profile backup…** to check a profile ZIP without restoring it. Verification checks
the manifest, archive entry types and bounds, member hashes, SQLite integrity,
table inventory and the existing recovery sanitization rules on temporary copies.
The report lists stores, byte sizes and tables, without showing saved payloads.
The original ZIP and active profile are unchanged. These checks establish the
tested recovery path, not publisher authenticity or full application coverage.

**Recover profile into new folder…** now runs that verification before asking for
a destination and rechecks the reviewed backup during recovery. Cancellation and
account/privacy changes stop acceptance of results. The incomplete-recovery
record is installed before the first database is published. The completion marker
is staged, flushed and published last; an interrupted destination remains blocked
by the existing launcher. This is process-interruption coverage, not a native
Windows/Linux power-loss or filesystem-durability qualification.

Selective settings restore and undo compare existing dictionaries leaf by leaf.
For example, changing a VR profile's battery threshold after restore no longer
prevents undoing its unchanged tracker count. Lists and added/removed objects
remain atomic. Dependent preferences still must form a valid owner document;
undo will stop rather than leave an active profile pointing to a removed one.
Old top-level receipts remain readable, and undo is checked against its original
receipt before applying. Selected export, restore and undo read only the affected
settings owners, so unrelated damaged JSON does not block healthy sections.
The existing 14-section allowlist and service-grant exclusions are unchanged.

Validation: **162 focused tests passed**, including **44 new recovery tests**,
with zero blocked external-socket attempts. All **636 Python files** parse as
Python 3.10 grammar. Tests include real temporary SQLite stores and ZIPs, later
edits, old receipts, cancellation, changed accounts, malformed inputs, valid-hash
invalid databases, publication interruption, and production dialog callbacks with
headless widgets. Native Tk could not start because this environment has no
display server; Windows/Linux visual and assistive-technology acceptance remain
open. Earlier full regression results below are historical, not rerun claims.

This advances VX-MIG-17, VX-MIG-29 and VX-DESK-16 while their wider scopes remain
partial. ARC import/recovery qualification and animation remain the next stages
after the current native acceptance prerequisites. No numbered release or build
timestamp was created or changed.

## Calendar build name and bottom placement — 5 October 2026

The user requested `Year.Day.Month.Hour.Minute.Weekday`, with Monday=1 through
Sunday=7. The public `BUILD_VERSION` uses `YYYY.DD.MM.HH.mm.D`: 24-hour time,
two-digit day/month/hour/minute, and a single weekday digit. `BUILD_TIMESTAMP`
records the matching date/time with a UTC offset. This checkpoint uses
America/New_York time. These are fixed build values, never a launch-time clock.

The main title/header now show VRC Eye. A persistent bottom-right footer shows
`VRC Eye · <build name>` on every page. The `--version` command and main diagnostic
report identify the same build. Existing theme/text-size styles apply to the footer.
Future release filenames follow the calendar name without a Development suffix;
the packager checks real dates, clock ranges, weekday consistency and timestamp
agreement. Same-minute rebuilds cannot silently overwrite a release.

The internal 1.21.0 API/peer identifiers and Development 21 baseline metadata remain
available for compatibility and provenance. Development 30 remains the release
milestone: this update changes the public naming/display, not the release hold.
Continue preserving work in this same unnumbered checkpoint.

Validation for this naming/layout change is appended in
`PENDING_WORKING_VALIDATION.json`; earlier full regression results remain historical.

## Pending implementations retained for Development 30

| Tool | Entry point | Pending behavior |
|---|---|---|
| Metadata reference browser | Developer / Black Lab → Overview → Local metadata & inspection reports | Open an extracted v31 reference folder; search by type name, assembly or enum/type; inspect paged fields, constants, properties, methods and events; follow the base type; export the selected page; optionally compare a selected DLL's exact hash. |
| Creator performance reports | Avatar Library → Details & Builds → Performance reports; also the shared reports window | Import a typed report for the selected avatar, inspect 31 supported counters/flags, preserve missing values as unknown, pin a baseline, compare matching avatar/platform/SDK reports, and export. A blank template is available. |
| Media error explanations | Media & Audio → Settings & Diagnostics → Image / video error reports; Game Log selected-entry details | Explain explicit video/image error families, import supplied events, preserve unresolved future codes, and export analysis. Numeric decoding requires the matching reference build; named log labels are explicitly build-unverified. |
| SDK source performance exporter | Unity package → VRC Eye → Avatar Performance Report | Capture installed-SDK source counters for the selected scene avatar and active platform; export after review; retain Avatars/Base SDK and Unity versions. Unity compilation and native acceptance remain pending. |
| GLB bones and blendshapes | Avatar Library → local 3D preview → Choose GLB scene → Bones & blendshapes | Inspect imported joints, inverse-bind matrices and influence counts; show the skeleton; preview bounded position morph weights and reset them without changing the source. |
| Retained media error context | Media & Audio → Settings & Diagnostics → Inspect retained log errors | Inspect nearby same-family media entries and matching saved URLs; preserve ambiguity; open the exact retained Game Log entry; export without URLs or raw text. |
| More settings backup/undo | Settings backup and undo | Four additional sections: VR checklist profiles and Performance, Crash Diagnostics and Unity Player display modes. Selective coverage now contains 14 sections. |
| Local VR setup recovery | VR Center → Profiles → Settings backup and undo | Recover deleted profiles and replaced hardware summaries from local history, preserve later edits, and reject stale editor saves. Portable backups continue to exclude hardware summaries. |

Imports stay in the window until cleared or closed. Export is explicit and creates
a new file after review. No extra account/history store, collector, login, network
request, executable loader or game-memory access is introduced. Window/account,
owner-selection and privacy changes invalidate the displayed evidence and pending
results. Cancelled jobs retain their slot until their worker exits.

## Using the metadata pack

Extract the previously supplied `1919rippedopen.7z` outside Eye. Select the folder
containing `global-metadata-v31.dat` and the nested native-map `data` directory.
The reader needs adjacent `native_types.jsonl.gz`, `report.json` and
`export-validation.json`. It also reads `il2cpp-manifest.json` when present.

The normalized metadata hash is checked against the map report; the compressed
type-map size/hash is checked against its validation manifest. The original
`output.dat` hash is not confused with the normalized metadata identity. Table
bounds, sizes, ownership, names and referenced type indices are checked. This
verifies internal input consistency, not publisher authenticity or native symbol
addresses. The original game DLL is optional: a separate read-only hash comparison
reports exact match or mismatch without loading it.

Only normalized metadata v31 and the supplied map shape are supported in this
batch. Other schemas are rejected. No archive extraction, disassembler, method-body
reconstruction, native invocation, bookmarks, persistent search index or two-pack
comparison is implemented. Interfaces are shown up to 64 per type with an explicit
truncation indicator; members are paged 200 at a time; very long argument lists are
marked as excerpts.

Input bounds include a 128 MiB metadata snapshot, 16 MiB compressed type map,
128 MiB expanded type map, 64 KiB JSON lines, 500,000 native descriptors, 32 MiB each
of cached metadata/native-name text, 100,000 metadata definitions, 500 discovered
folder entries and a 90-second import deadline. Source files must be regular files
without symbolic links. Parsing never executes any file from a reference pack.

## Performance report contract

This is an Eye-owned import format. The new local Unity package exporter produces
it from the installed SDK's public source-analysis contract. Select a scene avatar
with an existing blueprint ID; capture, review and export from **VRC Eye → Avatar
Performance Report**. No module installation is needed. Missing SDK fields stay
unknown; source measurements cannot establish final build sizes or rank. Native
Unity compilation/acceptance is still pending. The blank template contains
placeholders and unknown counters, not sample measurements.

```json
{
  "schema": "vrc-eye-avatar-performance-1",
  "avatar_id": "avtr_11111111-1111-1111-1111-111111111111",
  "platform": "standalonewindows",
  "sdk_version": "3.10.2",
  "measured_at": "2026-10-05T00:00:00Z",
  "source": "Creator SDK export",
  "reported_rank": null,
  "stats": {
    "polyCount": null,
    "textureMegabytes": null,
    "downloadSizeBytes": null,
    "uncompressedSizeBytes": null,
    "contactCount": null,
    "constraintsCount": null,
    "constraintDepth": null,
    "raycastCount": null,
    "physBone": {
      "componentCount": null,
      "transformCount": null,
      "colliderCount": null,
      "collisionCheckCount": null
    }
  }
}
```

The example above is an illustrative schema only. Accepted platforms are
`standalonewindows`, `android`, and `ios`. Counts and byte sizes require nonnegative
integers; flags require booleans. Texture memory retains the supplied MB unit
without assuming a byte conversion. Non-finite, negative and wrongly typed
measurements are rejected. Absent/null counters stay unknown; an explicit zero
remains zero. Unknown metric names are reported and omitted. Bounds/AABB and
arbitrary future SDK fields are not interpreted in this batch.

Comparisons require the same avatar, platform, Avatars SDK, measurement stage,
Base SDK and Unity versions. The optional `measurement_stage` field is `source`,
`built` or `reported` (the legacy default); `sdk_base_version` and `unity_version`
are optional but unknown values cannot match known versions. Unknown counters do
not produce numeric deltas. Baseline/current dates and source-file hashes remain
visible; chronological order and improvement are not inferred. The existing
catalog's reported rating is never overwritten, and no official rating is
calculated from partial stats or guessed thresholds.

## Media input contract

```json
{
  "schema": "vrc-eye-media-errors-1",
  "build": "2026.3.3-1919-27c41b24d2-Release",
  "events": [
    {
      "family": "VideoError",
      "code": 3,
      "observed_at": "2026-10-05T00:00:00Z"
    }
  ]
}
```

This is an illustrative event, not a recorded incident. `VideoError` and
`VRCImageDownloadError` (or their full qualified type names) are distinct families.
Code 3 maps to `PlayerError` and `DownloadError`, respectively, in the supplied
build. The exact normalized metadata SHA-256 can also identify this reference.
Unknown builds leave numeric values unresolved. A supplied named label can be
explained with a build-unverified status. Unknown future codes remain in exports.

The Game Log annotator requires an explicit family-qualified expression such as
`VideoError: RateLimited`; generic HTTP/AVPro numbers are ignored. It does not infer
the build from a filename, fetch media URLs, diagnose a root cause or retry a
request. Imported reports contain at most 200 events. Exports are analysis
documents; they omit unknown source fields such as URLs and raw log text.

The retained-log snapshot considers at most 10,000 lines, the newest 200 explicit
errors and 500 saved media records in the current workspace. It associates a URL
in the same entry, or considers up to 256 preceding same-family media entries
within 120 seconds. Source changes, world markers, explicit local room exits,
application quit, crash markers and backward timestamps separate context. A video
stop/end clears video candidates. Timestamps with unknown timezones are not mixed
with zoned timestamps. A player leaving alone is not treated as a local exit.
Ambiguous and bounded candidate searches are labeled; neither a nearby URL nor an
exact saved-URL match proves a cause, playback, ownership or the same incident.
Refreshing is explicit. Jumping back checks the exact retained object so a reused
serial after reset cannot select an unrelated entry. Exports omit all URLs,
source paths, saved titles, raw logs and private instance details.

## GLB rig inspection

Only explicitly selected GLB geometry is inspected. Four joint influences per
vertex, 256 joints per skin, 32 skins, 2048 joint references, 32 morph targets per
mesh and 200,000 target vertices are supported. Position morphs are applied before
joint world/inverse-bind matrices; node weights override mesh defaults. The
existing scene/file/output budgets still apply. Weight edits (-4 through 4) run in
the existing cancellable local job; reset restores imported defaults. Privacy,
account or selection changes cancel and discard pending results.

The viewer shows imported joint transforms, inverse-bind matrices, influenced
vertex counts and maximum influence weights. It does not provide arbitrary bone
posing, humanoid retargeting, animation playback, IK, PhysBones, FBX/VRCA ingestion
or Unity shader fidelity. Morph normal/tangent data is validated but the existing
flat preview does not render those deltas. Sparse/compressed geometry and extra
joint influence sets remain unsupported. Source geometry diagnostics still use
the imported scene; transient morph previews do not replace the source object.

## Settings scope

VR checklists export profile names, selected profile, expected tracker counts and
battery thresholds. Matching local names retain their hardware summary; new
profiles start without one. Summaries are excluded from both selective exports
and full profile backups. Local direct-edit and selective-restore histories now
retain validated summaries, so reviewed undo can recover deleted profiles and
replaced captures on the same device. Each summary is one atomic observation;
undo does not combine fields from different captures. Later edits are preserved.
Selective-restore and direct-edit undo compare existing preferences field by
field. Added or deleted profiles stay atomic, so later edits to a recreated or
new profile preserve that entire profile.

Older receipts have no missing hardware data to recover. They can restore recorded
preferences with no summary, but cannot remove or overwrite a current summary
they did not record. Existing retention limits still apply: 100 direct-edit
receipts for device preferences, plus 100 restore/undo receipts per workspace.
These histories are not a replacement for original-asset backups.

VR Center exposes the existing guarded settings recovery dialog from Profiles.
Saved profiles are compared inside the settings transaction before any direct
write. A stale editor reloads the latest saved values and rejects its pending
write; the user can also explicitly reload. Recovering a summary restores saved
observations only; it does not start diagnostics or apply SteamVR settings.
The three diagnostic sections export only display mode, preserving operational
settings on selective restore. Existing controls refresh without saving again or
starting/configuring collectors. Direct edits use the existing conditional undo
ledger and preserve later field edits. Older ten-section bundles remain readable.

Full profile backup also carries VR checklists and Crash/Unity display choices;
the copied profile omits hardware snapshots and Unity launch overrides, and starts
Crash/Unity monitoring settings disabled. Existing backup owners remain in place.

## Continuation and remaining scope

- The current pending batch refines META-01, META-02 and META-08 from the saved
  supplemental review. It does not complete all of NM1919-01/02/08/11.
- The Dev21 ARC/VRCX ledger remains a historical baseline. ARC-05 now has a partial
  GLB implementation; animation, arbitrary bone posing and Unity/FBX ingestion
  remain open. Settings coverage advances while complete tool coverage remains
  partial. Media correlation is an explicit retained-log snapshot, not a live
  producer or translation service. See the pending changeset for these deltas.
- Next creator candidates are expression-menu and PhysBone/contact/constraint
  inspection over actual exported data, plus animation preview after the current
  rig work passes native acceptance. General extension hosting remains open.
- Keep reference packs and third-party client binaries outside the application
  package. No supplied mod implementation or binary was copied into Eye.
- Retain this checkpoint and the user’s Development 30 release hold across chats.
  The hold prevents release packaging, not continued source work or verification.

## Validation

See `PENDING_WORKING_VALIDATION.json` for the final source hashes and test results.
Current merged validation: **152 focused tests** and **5,286 portable tests plus
1,065 subtests passed**; 512 tests skipped, 13 transport modules excluded and one
transport case deselected. No test failures or blocked external-socket attempts.

The current `settings_recovery_update` records recovery after restart, whole-summary
undo, later-edit conflicts, legacy receipts, transaction rollback, stale editor
reloads and both portable export boundaries. Its JUnit reports are included under
`validation/`. The native recovery workflow is supplied as a test but needs a
working display; this environment has neither a display nor Xvfb, and its package
manager could not provision one under the available permissions.
The inherited portable test exclusions remain explicit; headless UI callbacks do
not establish native Windows/Linux GUI or live VRChat acceptance. The application
keeps its existing Windows/Linux launchers and dependencies.

Binary-format references used during independent implementation:

- [Versioned IL2CPP metadata table definitions](https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Il2Cpp/MetadataClass.cs)
- [Compressed integer format](https://github.com/Perfare/Il2CppDumper/blob/master/Il2CppDumper/Extensions/BinaryReaderExtensions.cs)
- [glTF 2.0 skinning and morph-target contract](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html)
- [VRChat avatar performance reference](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/)

## Archive review — 5 October 2026

Reviewed twelve supplied archives and recorded 14 deduplicated work packages (3 newly scoped and 11 refinements). See [the review](ARCHIVE_REVIEW_2026_10_05.md) and its JSON companion for per-archive findings, source evidence, existing owners and acceptance criteria. This is planning only: no proposed feature is marked implemented and the ARC/VRCX gap classifications are unchanged. Source/test hashes and the earlier regression record remain authoritative. Continue the same unnumbered checkpoint under the Development 30 release hold.

## GitHub integration backlog — 5 October 2026

All 17 proposals from the GitHub survey are now backlogged, with all 55 assessed
project candidates and their source/license/platform evidence retained in
[VRC-Eye-GitHub-Integration-Backlog.json](VRC-Eye-GitHub-Integration-Backlog.json).
Each proposal links to the existing consolidated backlog owners and related
metadata/archive-review proposals. Optional, later and watch-list items are
retained; this does not start implementation or qualify an integration.

The survey used an earlier checkpoint. Its exporter, rig and media proposals have
been reconciled with the source already retained here: finish native exporter
acceptance and measurement extensions, continue remaining rig/animation/bounds
coverage, and extend the existing retained-log media context. Do not recreate
those foundations. Existing ARC/VRCX historical classifications, source/test
hashes, regression results and the Development 30 release hold are preserved.

## SDK backlog — 5 October 2026

All nine Avatar/World SDK opportunity areas are deferred in [SDK_BACKLOG_2026_10_05.json](SDK_BACKLOG_2026_10_05.json), linked to existing ARC/VRCX/GitHub work rather than counted as duplicate features. This update records planning only.

| ID | Scope |
|---|---|
| SDK261005-01 | Expression-menu and parameter inspector |
| SDK261005-02 | PhysBone, contact and constraint relationship reports |
| SDK261005-03 | SDK performance-exporter qualification and component attribution |
| SDK261005-04 | Avatar setup and platform checks |
| SDK261005-05 | World scene inventory and validation reports |
| SDK261005-06 | Udon behavior, variable and error inspection |
| SDK261005-07 | ClientSim test profiles and report intake |
| SDK261005-08 | Unity build/test dashboard and later reviewed upload workflow |
| SDK261005-09 | SDK identity and compatibility checks |

First prerequisites are exact SDK identity and native Unity qualification. The uploaded filenames say 3.10.5, while their Base/Avatars/Worlds package manifests say 3.5.0; no version label was silently corrected. All 22 direct count-field names used by the pending exporter were found in the supplied declarations, but this is not a compiled or executed SDK test. Keep the Development 30 release hold.

## ARC-10 bounds subset — 2026-10-06T05:15:34.816394+00:00

Desktop bounds diagnostics compare imported/displayed and explicitly sampled GLB/FBX geometry in each pose’s node-local frame, report exact requested/effective sample scope, finite margins, coverage and source snapshot hashes, and export only reviewed new JSON reports. Cancellation, budgets, negative/nonuniform transforms and stale context/pose/settings guards are tested. Unity 2022.3 source adds data-only skinned-mesh sampling in an explicit root-bone frame, mesh/stored-renderer/sample comparisons and reviewed margin or explicit-value corrections to a new prefab only. Copy source/dependency fingerprints, save/reload graph/reference checks and ARC-19 durable sample/output receipts are implemented but unqualified in native Unity.

Unity 2022.3 import/compile and all EditMode execution, broader authorized creator pose/clip and nested/variant fixtures, graphical desktop acceptance and native culling/reload qualification remain open. The correction subset requires a saved prefab, readable saved mesh and explicit internal root bone; unsupported/humanoid/object-reference/script bindings stop sampling. Finite samples do not verify procedural or between-sample motion, and no FPS improvement is claimed. Generic MeshRenderer and other Unity versions are outside this initial correction subset.

Validation: **5,996 tests + 1,078 subtests passed**, 497 skips, one deselection and zero failures; 55 new desktop tests and 251 focused tests pass. 700 Python files parse with Python 3.10 grammar; all 733 frozen source hashes remained unchanged. C# syntax parsing passes for 27 files but is not compilation. Thirteen new Unity methods remain unrun. See [ARC-10 guide](ARC10_RENDERER_BOUNDS.md).

## ARC-11 setting-transfer subset — 2026-10-06T05:45:58.608042+00:00

Unity 2022.3 editor source now separates typed, individually selected renderer settings on fresh saved-prefab copies from ModelImporter policies on fresh FBX copies with explicit reimport. Material/probe references require explicit destination mappings or null; original geometry, bones and unselected values are checked. Source/dependency byte evidence, canceled/expired plan guards, serialized/reload checks, ordered stream/submesh/material/bone/hierarchy observations and linked ARC-19 durable receipts are supplied. Desktop Recovery can validate and inspect editable v1 reports with strict allowlists, typed values, recomputed ordered differences, bounded reads and context/privacy guards; this portable reader is tested and does not authenticate or replay native operations.

Unity 2022.3 import/compile and native EditMode execution, real creator-model/prefab fixtures, nested/variant and pipeline configurations, native reimport/material/bone ordering qualification, visual/deformation acceptance and graphical desktop testing remain open. Initial correction scope is compatible saved MeshRenderer/SkinnedMeshRenderer prefabs and FBX ModelImporter assets; legacy external material generation, other model formats, unsupported importer/reference policies and other Unity versions are excluded. Unreadable mesh stream/index data remains explicitly unverified; no FPS or full deformation-equivalence claim is made.

Validation: **6,068 tests + 1,078 subtests passed**, 497 skips, one deselection and zero failures; all 72 new portable tests and 247 focused tests pass. 703 Python files parse with Python 3.10 grammar; all 740 frozen source hashes remained unchanged. C# syntax parsing passes for 31 files but is not compilation. Thirteen new Unity methods remain unrun. See [ARC-11 guide](ARC11_SETTING_TRANSFERS.md).

## ARC-12 influence-reduction subset — 2026-10-06T06:05:10.681148+00:00

Desktop source-snapshot influence trials deterministically reduce selected four-slot skin weights, sample imported and explicit decoded clip poses, and report per-pose/aggregate maximum and RMS world-space position error, influence counts, worst vertices and a user-selected tolerance. Immutable source, cancellation/budgets, account/privacy/selection guards and reviewed exclusive JSON export are tested. Unity 2022.3 source adds data-only prefab dependency gates, temporary Bone4 sampling with blendshape restoration, maximum-error-gated new mesh assets, non-skin stream/bind-pose/submesh/multi-frame blendshape preservation, stale/canceled plan checks, actual candidate/reimport comparison and ARC-19 durable receipts. No source assignment, bone removal, renderer merging or runtime speed claim.

Unity 2022.3 import/compile and all native EditMode execution, real creator fixtures, visual/deformation/shading and graphical desktop acceptance, native callbacks/domain reload/filesystem behavior and supported-target profiling remain open. Initial copy subset requires a saved data-only prefab, explicit internal root bone, readable saved mesh and at most four stored influences per vertex. Unknown/dynamic components including Animator, cloth and constraints block editing. Proven-unused bone removal, compatible renderer consolidation, higher-count skin reduction, broader dependency analysis and Unity versions are not implemented. Baked FBX frames cannot evaluate changed weights. Finite position samples do not qualify normals/tangents, unsampled/procedural/shader motion or runtime equivalence.

Validation: **6,122 tests + 1,078 subtests passed**, 497 skips, one deselection and zero failures; all 54 new portable tests and 216 focused tests pass. 707 Python files parse with Python 3.10 grammar; all 747 frozen source hashes remained unchanged. C# syntax parsing passes for 34 files but is not compilation. Thirteen new Unity methods remain unrun (111 supplied total). See [ARC-12 guide](ARC12_SKIN_OPTIMIZATION.md).
