# VRC Eye 1.21.0 — Development 15 validation

The final portable regression passed **4,793 tests and 1,059 subtests**,
with **zero failures/errors** and **zero blocked external-socket attempts**, in
130.51 seconds. All 14 new shared-roster-note tests are included.

The run has **475 skipped native-GUI cases**, **1 deselected Unix
bridge case**, and **13 excluded local-transport modules**, matching the completed
Development 14 baseline. Skips and exclusions are not passes. The two retained
warnings concern a test-listener constructor and an intentionally duplicated
archive member. BUILD_VALIDATION.json records the exact command and exclusions.

All **566 Python files** parse with the Python 3.10 grammar. The
frozen manifest covers **611 source files**;
their hashes were rechecked after the suite. No runtime or test edits followed that
run. Packaging verifies ZIP CRCs and every member byte against the source. All
**748 Development 14 paths** are retained, including unchanged launchers and
requirements. The exact baseline archive SHA-256 is
`44a5452ba27e60576246fc3d4bc0b6fc93479ad2859a02a1d6a3271a8726e510`.

The new cases cover shared profile/roster notes; batched alias and clear-marker
projection; legacy review and preservation; stale drafts after refresh; empty and
cross-account drafts; changed legacy text; deletion without removing other tags;
failed note commits; repeated inline saves; actionable conflict feedback; shared
editor routing and privacy; account changes; and reload cancellation. They use
real local files/SQLite and headless widget fixtures, not a native GUI.

An existing history fixture now waits for the real history-worker startup jobs
before capturing its source-stability snapshot. This removes a test startup race;
production source-change guards remain unchanged. Build-identity validation now
checks the channel/suffix relationship without hard-coding an older checkpoint.

Native Windows/Linux GUI rendering, accessibility, live VRChat/CDN, SteamVR,
Unity, AssetRipper, audio, protected vaults and other installed-provider acceptance
remain unverified. No native display is available; earlier Xvfb attempts could not
bind local/Unix display sockets. No live VRChat actions or provider installations
were performed. This is a **runnable source ZIP**, not a compiled executable or
signed installer; full ARC/VRCX parity remains incomplete.
