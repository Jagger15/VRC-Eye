"""Avatar transfers share the catalog worker, account session and cancellation."""
import time
from pathlib import Path
from tkinter import filedialog

from avatar_library import context_token,build_identity
from avatar_catalog_tools_ui import hidden
from avatar_transfer_jobs import Transfers,summary,source_key
from companion_ui import Table,button,choice,entry,line
from creator_projects_ui import text_area,set_text
from avatar_details import format_download_size


class TransfersPanel:
    def __init__(self,page,parent):
        from file_transfer_jobs import PersistentBudget
        store=getattr(getattr(page,'shell',None),'store',None)
        self.page=page;self.service=Transfers(page.library,budget=PersistentBudget(store) if store else None);self.generation=0;self.owned=None
        self.permitted=False;self.choices={};self.fetched=None;self.last_revision=-1;self.was_hidden=False
        self.build=page.tk.StringVar(value='Load available builds first')
        self.checksum=page.tk.StringVar();self.retry=page.tk.BooleanVar(value=False)
        self.status=page.tk.StringVar(value='Choose an avatar, then load its available builds. No transfer starts automatically.')
        page.ttk.Label(parent,text='Resume an authorized avatar download after interruption. Partial files remain beside the chosen destination until completion or reviewed discard. Resume depends on server support.',wraplength=940).pack(anchor='w',pady=5)
        row=line(page,parent);button(page,row,'Load available builds',self.fetch)
        self.picker=choice(page,row,self.build,('Load available builds first',),width=55)
        row=line(page,parent);page.ttk.Label(row,text='Expected SHA-256 (optional)').pack(side='left');entry(page,row,self.checksum,65)
        page.ttk.Checkbutton(parent,text='Allow up to 3 transient retries during this ten-minute review',variable=self.retry).pack(anchor='w')
        row=line(page,parent);button(page,row,'Review new download…',self.new)
        button(page,row,'Review resume…',self.resume);button(page,row,'Pause transfer',self.cancel)
        self.table=Table(page,parent,(('name','Destination',240),('state','State',125),('bytes','Committed',130),('time','Updated',200)),height=6,select=self.select)
        row=line(page,parent);button(page,row,'Check saved outcome',self.check)
        button(page,row,'Record verified file…',self.register);button(page,row,'Discard partial…',self.discard)
        button(page,row,'Refresh jobs',self.refresh)
        button(page,row,'All transfer activity…',self.activity)
        self.detail=text_area(page,parent,height=8)
        page.ttk.Label(parent,textvariable=self.status,wraplength=940).pack(anchor='w',pady=5)

    def activity(self):
        self.require()
        from transfer_center_ui import show
        show(self.page.shell)

    def require(self,online=False):
        from session_restore import offline
        self.page.writable()
        if hidden(self.page):raise ValueError('Reveal account information before reviewing transfers.')
        if self.page.job:raise ValueError('Wait for the current avatar task to stop.')
        if online:
            if offline(self.page.app):raise ValueError('Leave Offline mode before requesting a download.')
            return self.page.connected()

    def guard_for(self,token,generation):
        def guard():
            if (not self.permitted or self.page.closed or generation!=self.generation or context_token(self.page.app)!=token
                    or getattr(self.page.app,'_native_private',False)):
                raise ValueError('Account, privacy or transfer context changed. Review again.')
        return guard

    def fetch(self):
        client=self.require(True);avatar=self.page.selected()['id']
        if avatar.startswith('local:'):raise ValueError('Select an online avatar.')
        token=self.page.context();generation=self.generation;self.permitted=True
        guard=self.guard_for(token,generation)
        def work(stop,progress):
            from avatar_metadata_jobs import GuardedStop
            def allowed():
                try:guard();return True
                except ValueError:return False
            result=client.lookup('avatar',avatar,stop=GuardedStop(stop,allowed),progress=progress)
            guard();return result
        def done(result):
            self.owned=None;self.permitted=False
            export=getattr(result,'export',None)
            if not export or export.avatar_id!=avatar:raise ValueError('No available asset builds were returned for this avatar.')
            self.choices={f'{i+1}. {c.platform} · Unity {c.unity_version} · asset {c.asset_version} · {c.variant}':c for i,c in enumerate(export.choices)}
            self.picker.configure(values=tuple(self.choices));self.build.set(next(iter(self.choices),'No available builds'))
            self.fetched=(token,avatar,time.monotonic())
            self.status.set('Builds loaded through the shared API client. Select one and review a new download or a matching resume.')
        self.page.start_task(work,done,operation='Load transfer builds');self.owned=self.page.job

    def selected_build(self):
        client=self.require(True);row=self.page.selected();chosen=self.choices.get(self.build.get())
        if not chosen or not self.fetched or self.fetched[:2]!=(self.page.context(),row['id']) or time.monotonic()-self.fetched[2]>300:
            raise ValueError('Load this avatar’s available builds again before reviewing a transfer.')
        return client,row,chosen

    def new(self):
        _,row,chosen=self.selected_build();token=self.page.context()
        path=filedialog.asksaveasfilename(parent=self.page.app.root,title='Save a new avatar download',initialfile=row['id']+'.vrca',defaultextension='.vrca',confirmoverwrite=False,filetypes=(('Avatar bundle','*.vrca'),))
        self.page.check_context(token)
        if not path:return
        self.selected_build()
        build=build_identity(dict(platform=chosen.platform,unityVersion=chosen.unity_version,assetVersion=chosen.asset_version,variant=chosen.variant,assetUrl=chosen.url))
        recorded=next((b for b in self.page.library.records(self.page.scope,'build',row['id']) if b['descriptor_id']==build['id']),None)
        plan=self.service.prepare(self.page.scope,row['id'],chosen.url,path,expected_hash=self.checksum.get(),build_id=recorded['id'] if recorded else '',retry=self.retry.get())
        self.launch(plan)

    def resume(self):
        _,row,chosen=self.selected_build();job=self.selected_job()
        plan=self.service.prepare(self.page.scope,row['id'],chosen.url,resume=job['id'],retry=self.retry.get())
        self.launch(plan)

    def launch(self,plan):
        token=self.page.context();generation=self.generation
        try:
            if not self.page.review('Review avatar transfer',summary(plan),'Start transfer'):return
            self.page.check_context(token);client,_,_=self.selected_build()
            opener=client.asset_opener();self.permitted=True;guard=self.guard_for(token,generation)
            def done(result):
                self.owned=None;self.permitted=False;self.refresh()
                self.status.set('Verified download saved. Select its job to inspect the result and record its file association.')
            submitted=plan
            self.page.start_task(lambda stop,progress:self.service.run(submitted,opener,guard=guard,stop=stop,progress=progress),done,
                operation='Avatar transfer',persist=lambda result,scope:None)
            self.owned=self.page.job;plan=None
        finally:
            if plan:self.service.discard_plan(plan)

    def selected_job(self):
        job=self.table.selected()
        if not job:raise ValueError('Select a transfer job first.')
        return job

    def check(self):
        self.require();job=self.selected_job();token=self.page.context();generation=self.generation;account=self.page.scope
        self.permitted=True;guard=self.guard_for(token,generation)
        def done(evidence):
            self.owned=None;self.permitted=False;self.refresh()
            self.status.set('Saved destination matches its publication checkpoint. It can now be recorded as a catalog file.')
        self.page.start_task(lambda stop,progress:self.service.inspect_outcome(account,job['id'],guard=guard,stop=stop,progress=progress),done,operation='Check transfer outcome')
        self.owned=self.page.job

    def register(self):
        self.require();job=self.selected_job();account=self.page.scope;token=self.page.context();generation=self.generation
        if job['state']!='Complete':raise ValueError('Check the saved outcome first.')
        if not self.page.library.get(account,job['avatar_id']):raise ValueError('Restore this avatar to the catalog before associating its file.')
        if not self.page.review('Record verified transfer',f"Avatar: {job['avatar_id']}\nFile: {job['destination']}\nSHA-256: {job['prefix_sha256']}\n\nRecheck and register these bytes in this account’s catalog. A hash does not establish rights or a working avatar.",'Inspect and record'):return
        self.page.check_context(token);self.require();self.permitted=True;guard=self.guard_for(token,generation)
        def work(stop,progress):
            evidence=self.service.inspect_outcome(account,job['id'],guard=guard,stop=stop,progress=progress)
            guard()
            return self.page.library.register_file(account,job['avatar_id'],evidence,build_id=job.get('build_id',''),provenance='Verified resumed download; reviewed association',before_commit=guard)
        self.page.start_task(work,lambda result:(self.refresh(),self.page.refresh(),self.status.set('Verified file association saved.')),operation='Record verified transfer')
        self.owned=self.page.job

    def discard(self):
        self.require();job=self.selected_job();token=self.page.context();generation=self.generation;account=self.page.scope
        if not self.page.review('Discard retained partial',f"Transfer: {job['id']}\nPartial file: {job['partial']}\nCommitted bytes: {job['offset']:,}\n\nVerify then delete only this owned partial. Completed destinations and other files are preserved.",'Discard partial'):return
        self.page.check_context(token);self.require();self.permitted=True;guard=self.guard_for(token,generation)
        self.page.start_task(lambda stop,progress:self.service.discard(account,job['id'],guard=guard,stop=stop),lambda _:(self.refresh(),self.status.set('Owned partial discarded.')),operation='Discard partial')
        self.owned=self.page.job

    def refresh(self):
        if hidden(self.page):return self.clear()
        rows=[r for r in self.service.rows(self.page.scope) if not self.page.selected_id or r['avatar_id']==self.page.selected_id]
        self.table.set(rows,lambda r:(Path(r['destination']).name,r['state'],format_download_size(r['offset']),r['updated_at'] or r['created_at']),identity=lambda r:r['id'])
        self.last_revision=self.page.library.revision;self.select()

    def select(self):
        row=self.table.selected()
        if not row or hidden(self.page):set_text(self.detail,'');return
        destination=row['destination'] if self.page.show_paths.get() else Path(row['destination']).name
        wait=max(0,int(row.get('next_retry_at',0)-time.time()))
        set_text(self.detail,f"{row['state']} · {destination}\nAvatar: {row['avatar_id']}\nCommitted bytes: {row['offset']:,} / {row['total'] or 'Unknown'}\nAttempts: {row['attempts']}\nLast recorded retry delay remaining: {wait} seconds\nSHA-256 of committed bytes: {row['prefix_sha256']}\n\n{row['message']}\n\nStrong validator: {'available' if row['etag'] else 'unavailable; interrupted bytes cannot resume'}")

    def cancel(self):
        self.permitted=False
        if self.owned is not None and self.page.job is self.owned:self.page.cancel()

    def clear(self):
        self.cancel();self.generation+=1;self.owned=None;self.fetched=None;self.choices={};self.service.clear()
        self.build.set('Load available builds first');self.picker.configure(values=('Load available builds first',))
        self.table.set([],lambda r:());set_text(self.detail,'');self.checksum.set('');self.last_revision=-1

    def tick(self):
        from session_restore import offline
        private=hidden(self.page)
        if private:
            if not self.was_hidden:self.clear()
        else:
            if offline(self.page.app):self.cancel()
            if self.last_revision!=self.page.library.revision:self.refresh()
        self.was_hidden=private

    def close(self):self.clear()
