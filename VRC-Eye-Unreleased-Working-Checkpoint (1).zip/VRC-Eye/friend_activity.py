"""Friend-location projections, opt-in alerts and bounded reconnect comparisons.

Consumes the existing sync owner's observations; never opens a connection.
"""
from copy import deepcopy
import re
import uuid
import time

from companion_data import Entity, entity_id, stamp

KEY = 'friends.watchlists.v1.'
EVENTS = ('online', 'status', 'location', 'world-entry', 'leaving-busy', 'gathering')
EVENT_LABELS={'online':'Online','status':'Status','location':'Location','world-entry':'Enters world','leaving-busy':'Leaves Busy','gathering':'Friends gather'}
COMPARE = ('state', 'status', 'statusDescription', 'location')
LABELS = dict(state='Presence', status='Status', statusDescription='Status text', location='Shared location')


def comparison(row):
    return {k:v[:4096] if isinstance(v,str) else None for k,v in row.items() if k in COMPARE or k in ('id','displayName')}


def shared_location(row):
    """Separate missing/private presence from an explicitly shared destination."""
    from world_visits import location
    value = row.get('location')
    if row.get('state') == 'offline' or value == 'offline': return '', 'Offline'
    if value == 'private': return '', 'Private location'
    if value in ('traveling', 'traveling:traveling'): return '', 'Traveling'
    if row.get('state') in ('active', 'active on website') and not str(value or '').startswith('wrld_'):
        return '', 'Website / app active'
    try:
        # Nonces never identify a grouping or become a stored/handoff capability.
        value = re.sub(r'~nonce\([^)]*\)', '', value) if isinstance(value, str) else ''
        world, instance = location(value)
        return world + ':' + instance, 'Shared instance'
    except ValueError: return '', 'Location unavailable'


def grouped_locations(rows, worlds=(), *, priority=()):
    priority=set(priority)
    known = {r.id:r for r in worlds if r.kind == 'world'}
    groups = {}
    for row in rows:
        destination, label = shared_location(row)
        world = destination.split(':', 1)[0] if destination else ''
        key = world or label
        group = groups.setdefault(key, dict(id=key, world=world, name=label, friends=[], instances={}))
        group['friends'].append(row)
        group['instances'].setdefault(destination or label, []).append(row)
    output = []
    for group in groups.values():
        world = known.get(group['world'])
        group['name'] = world.name if world else group['world'] or group['name']
        group['friends'].sort(key=lambda r:(r['id'] not in priority,str(r.get('displayName') or r['id']).casefold()))
        for friends in group['instances'].values():friends.sort(key=lambda r:(r['id'] not in priority,str(r.get('displayName') or r['id']).casefold()))
        group['instances']=dict(sorted(group['instances'].items(),key=lambda item:(not any(r['id'] in priority for r in item[1]),item[0])))
        group['priority']=any(r['id'] in priority for r in group['friends'])
        count = len(group['friends']); instances = len(group['instances'])
        caption = f'{count} friend' + ('s' if count != 1 else '')
        if group['world']: caption += f' · {instances} shared instance' + ('s' if instances != 1 else '')
        group['card'] = Entity('world' if group['world'] else 'location', group['id'], group['name']+'\n'+caption,
                               'Observed friends; occupancy and access are not established.', world.image if world else '',
                               dict(world.data or {}) if world else {})
        output.append(group)
    return sorted(output, key=lambda g:(not g['priority'],not bool(g['world']), -len(g['friends']), g['name'].casefold()))


def validate_rules(rows, account):
    if not isinstance(rows, list) or len(rows) > 50: raise ValueError('Use up to 50 watchlist rules.')
    result = []; seen = set()
    for row in rows:
        if not isinstance(row, dict) or not {'kind','target','scope','events'}<=set(row) or set(row)-{'kind','target','scope','events','world','minimum','muted_until'}:
            raise ValueError('Unsupported watchlist rule.')
        kind, target, scope = row['kind'], row['target'], row['scope']
        if kind == 'user':
            target = entity_id('user', target)
            if scope != account: raise ValueError('Friend watchlists belong to the signed-in account.')
        elif kind == 'collection':
            from native_library import identifier
            target = identifier(target)
            if scope not in (account, 'shared'): raise ValueError('Choose a friend collection for this account or Shared.')
        else: raise ValueError('Choose a friend or local friend collection.')
        events = row['events']
        if not isinstance(events, list) or not events or any(e not in EVENTS for e in events):
            raise ValueError('Select supported watchlist events.')
        extra={}
        if row.get('world'):extra['world']=entity_id('world',row['world'])
        if 'world-entry' in events and not extra.get('world'):raise ValueError('Enter a world ID for Enters world alerts.')
        if 'gathering' in events:
            if kind!='collection':raise ValueError('Friends gather needs a local friend collection.')
            minimum=row.get('minimum',3)
            if type(minimum) is not int or not 2<=minimum<=50:raise ValueError('A gathering threshold must be 2–50 friends.')
            extra['minimum']=minimum
        if 'muted_until' in row:
            value=row['muted_until']
            if type(value) is not int or not 0<=value<=4102444800:raise ValueError('Invalid watch mute expiry.')
            if value:extra['muted_until']=value
        key = kind, scope, target
        if key in seen: raise ValueError('This friend or collection already has a rule. Replace that rule.')
        seen.add(key); result.append(dict(kind=kind, target=target, scope=scope, events=[e for e in EVENTS if e in events],**extra))
    return result


class FriendActivity:
    def __init__(self, sync):
        self.sync = sync; self.revision = 0; self.epoch = 0
        self.rules = []; self.alerts = []; self.recap = None; self.members = {}; self.members_due = 0
        self.gathered={};self.wall_clock=time.time

    def reset(self):
        self.rules = []; self.alerts = []; self.recap = None; self.members = {}; self.members_due = 0
        self.gathered={}
        self.epoch += 1; self.revision += 1
        model = self.sync.model
        if not model: return
        try: self.rules = validate_rules(self.sync.store.option(KEY+model.account, []), model.account)
        except (ValueError, TypeError): pass
        if model.friends: self.gap('Saved observations loaded. Changes while Eye was not observing are unknown.')

    def save_rules(self, rows):
        from account_actions import local_writable
        from account_header import private
        local_writable(self.sync.app)
        self.sync.sync_context()
        if not self.sync.model or private(self.sync.app): raise ValueError('Sign in and reveal account information first.')
        rows = validate_rules(rows, self.sync.model.account)
        self.sync.store.set_option(KEY+self.sync.model.account, rows)
        self.rules = rows; self.members_due = 0; self.revision += 1
        self.seed_gathering()
        self.sync.hub.social_delivery.clear()
        desktop = getattr(self.sync.shell, 'desktop_service', None)
        delivery = getattr(desktop, 'delivery', None)
        if delivery:
            delivery.pending = [(r,c) for r,c in delivery.pending if not str(r.get('type','')).startswith('watch-')]

    def collection_members(self):
        now = self.sync.clock()
        if now < self.members_due: return self.members
        wanted = {(r['scope'],r['target']) for r in self.rules if r['kind']=='collection'}
        from friend_filters import collection_members
        members=collection_members(self.sync.store,wanted)
        self.members = members; self.members_due = now+30
        return members

    def observe_live(self, kind, old, current, *, trusted=True):
        if not current:self.seed_gathering();return
        self.capture(current)
        if not self.rules or not self.sync.hub.sync(): return
        ref = current['id']; events = set(); members = self.collection_members();matched=[]
        for rule in self.rules:
            matches = rule['target'] == ref if rule['kind']=='user' else ref in members.get((rule['scope'],rule['target']), ())
            if matches and self.mute_remaining(rule)==0: events.update(rule['events']);matched.append(rule)
        changed = []
        if 'online' in events and kind == 'friend-online' and old.get('state') != 'online':
            changed.append(('online','is now reported online'))
        # A stale baseline cannot establish a live transition. Snapshot differences
        # are shown in the recap instead of replayed as desktop alerts.
        if trusted:
            if 'leaving-busy' in events and old.get('status')=='busy' and current.get('status') in ('active','join me','ask me'):
                changed.append(('leaving-busy','is no longer Busy'))
            if 'world-entry' in events:
                before,_=shared_location(old);after,_=shared_location(current)
                if after and ((before and before.split(':',1)[0]!=after.split(':',1)[0]) or
                    (not before and old.get('location') in ('offline','private','traveling','traveling:traveling'))):
                    if any('world-entry' in r['events'] and r.get('world')==after.split(':',1)[0] for r in matched):
                        changed.append(('world-entry','entered the watched world (shared observation)'))
            if 'status' in events and any(k in old and k in current and old[k]!=current[k] for k in ('status','statusDescription')):
                changed.append(('status','status changed to '+str(current.get('status') or 'Unavailable')[:100]))
            if 'location' in events and 'location' in old and 'location' in current and old['location']!=current['location']:
                destination, label = shared_location(current)
                changed.append(('location','shared location changed' if destination else label))
        for event,message in changed:self.emit(event,ref,str(current.get('displayName') or ref),message)
        for rule in self.rules:
            if 'gathering' not in rule['events']:continue
            key=self.rule_key(rule);now=self.gatherings(rule,live=current);previous=self.gathered.get(key)
            self.gathered[key]=set(now)
            if previous is None or self.mute_remaining(rule):continue
            for destination,count in now.items():
                if destination not in previous:
                    self.emit('gathering',ref,'Friend gathering',f'{count} watched friends share an observed instance.',cooldown=key)

    def emit(self,event,ref,name,message,*,cooldown=None):
        row = dict(type='watch-'+event, senderUserId=ref, senderUsername=name[:256],
                   message=message, observed_at=stamp(), delivery_id='watch:'+str(uuid.uuid4()))
        if cooldown:row['cooldown_key']=cooldown
        self.alerts = (self.alerts+[row])[-200:]
        self.sync.hub.social_delivery = (self.sync.hub.social_delivery+[dict(row)])[-200:]
        self.revision += 1

    @staticmethod
    def rule_key(rule):return rule['kind']+':'+rule['scope']+':'+rule['target']

    def mute_remaining(self,rule):return max(0,rule.get('muted_until',0)-self.wall_clock())

    def mute(self,rule,seconds):
        if rule not in self.rules or seconds not in (0,900,3600,28800):raise ValueError('Select a watch and a supported mute duration.')
        updated=dict(rule,muted_until=int(self.wall_clock()+seconds) if seconds else 0)
        self.save_rules([updated if r==rule else r for r in self.rules])

    def watched_ids(self):
        refs=set();members=self.collection_members()
        for rule in self.rules:
            if rule['kind']=='user':refs.add(rule['target'])
            else:refs.update(members.get((rule['scope'],rule['target']),()))
        return refs

    def gatherings(self,rule,*,live=None):
        members=self.collection_members().get((rule['scope'],rule['target']),set());counts={}
        if not self.sync.model:return counts
        for ref in members:
            row=self.sync.model.friends.get(ref);fresh=self.sync.fresh.get(ref)
            if live and ref==live['id']:row=live
            elif not fresh or ref in self.sync.stale or not 0<=self.sync.clock()-fresh[0]<600:continue
            if not row:continue
            location,_=shared_location(row)
            if not location or rule.get('world') and location.split(':',1)[0]!=rule['world']:continue
            counts[location]=counts.get(location,0)+1
        return {k:n for k,n in counts.items() if n>=rule.get('minimum',3)}

    def seed_gathering(self):
        self.gathered={self.rule_key(r):set(self.gatherings(r)) for r in self.rules if 'gathering' in r['events']}

    def gap(self, reason):
        self.gathered={}
        self.epoch += 1
        if not self.sync.model: return
        if not self.recap or not self.recap['pending']:
            self.recap = dict(started=stamp(), reason=str(reason)[:500], pending=True, finished='',
                              before={ref:comparison(row) for ref,row in list(self.sync.model.friends.items())[:1000]},
                              after={}, coverage={})
        else:
            self.recap['reason'] = str(reason)[:500]
            self.recap['after'].clear()
        self.revision += 1

    def capture(self, row, *, epoch=None):
        recap = self.recap
        if not recap or not recap['pending'] or epoch is not None and epoch != self.epoch: return
        if len(recap['after']) >= 1000 and row['id'] not in recap['after']: return
        recap['after'][row['id']] = comparison(row); self.revision += 1

    def finish(self):
        if self.recap and self.recap['pending']:
            self.recap.update(pending=False, finished=stamp(), coverage=deepcopy(self.sync.coverage)); self.revision += 1

    def recap_rows(self):
        if not self.recap: return []
        rows = []
        for ref, current in self.recap['after'].items():
            old = self.recap['before'].get(ref)
            name = str(current.get('displayName') or ref)
            if old is None:
                rows.append(dict(id=ref, name=name, field='Newly observed', before='No earlier observation', after='Snapshot received'))
                continue
            for field in COMPARE:
                if field in old and field in current and old[field] != current[field]:
                    # Comparing endpoints never reveals when/how often it changed.
                    rows.append(dict(id=ref, name=name, field=LABELS[field], before=str(old[field])[:1500], after=str(current[field])[:1500]))
        return rows[:4000]

    def recap_summary(self):
        recap = self.recap
        if not recap: return 'No reconnect comparison yet. Saved observations are compared after a connection gap or restart.'
        unchecked = len(set(recap['before'])-set(recap['after']))
        state = 'Catching up' if recap['pending'] else 'Comparison complete for received observations'
        partial = any(v.get('state') != 'checked' for k,v in recap['coverage'].items() if k.startswith('friends-'))
        return (f"{state} · {len(recap['after'])} friends checked · {unchecked} previous observations not rechecked.\nStarted {recap['started']} (UTC). "
                + recap['reason'] + (' Friend-list coverage is partial.' if partial else '')
                + '\nOnly differences between observations are shown. Missed events, change times and intermediate locations are unknown; an absent friend is not assumed offline.')
