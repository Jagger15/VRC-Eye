# Wellness design input and implementation map — VRC Eye 1.18.5

The original user-supplied 56-part proposal is preserved byte-for-byte after
its marker below, including its incomplete final line. This preface describes
what the source code in 1.18.5 implements. Examples and future-tense proposals
in the original are not claims that every integration is already available.
See WELLNESS_SETUP.md for operating steps and VALIDATION.md for test scope.

## Implementation map

| Proposal sections | Status in this release |
| --- | --- |
| 1, 44–46: Center, Casual/Advanced, central engine | Implemented dashboard and five Advanced pages, with scrolling and a single reminder engine |
| 2–7: Hydration, breaks, headset, eye, posture, movement | Editable first/repeat timing, messages, context and meaningful breaks; headset state is manual or optional driver-reported proximity |
| 8–9: Standing/sitting | Manual posture duration; automatic pose classification is not inferred |
| 10–12: Meals, bathroom, bedtime | Intervals, clock-based meals, per-day bedtime and private messages |
| 13: Quiet hours/wind-down | Implemented for Wellness, including quiet clock reminders and no catch-up burst; application-wide social/novelty sound coordination remains future work |
| 14–18: Session display, milestones, last break, break action, check-in | Implemented, with manual resume and no emotional response history; inactive-process/idle-as-break inference is not used |
| 19: Motion comfort | Quiet break mode opens local controls; voluntary headset-removal suggestion; no automatic game/audio changes |
| 20: Hearing comfort | Optional sampled Windows per-app digital peak/sustained notices plus reviewed lower/mute controls; no ear-loudness measurement, per-player attribution or automatic lowering |
| 21–22: Temperature and room safety | Manual self-check reminders and optional VR-start room check; no environmental sensor, recalibration or playspace inference |
| 23: Low battery | Fresh manual or SteamVR role-based battery inputs and one consolidated recharge opportunity |
| 24–28: Consolidation, cooldowns, snooze, context, VR/Desktop | Implemented central queue, first/repeat/snooze and batch/per-reminder controls, busy holds, explicit mode and observed input requirements |
| 29–30: Profiles and suggestions | Seven built-in choices plus named profiles; suggestions never apply automatically |
| 31–33: Summary/history/privacy | Optional local retention and reviewed exports; fresh default is memory-only; no diagnostic/social/cloud transmission |
| 34: VRC Eye-to-VRC Eye break status | Future work. No automatic whisper/VRChat status publication or sharing switch is added |
| 35: VR overlay | Optional external SteamVR head/wrist HUD and dashboard tile with break/snooze/dismiss; native placement/input needs hardware testing |
| 36–38: Presentation, accessibility, sound | Static Subtle/Normal/Prominent/Audio + Visual desktop presentation, large text, Windows volume-controlled chime; VR overlay uses its own size/visibility settings |
| 39: Quiet social situations | User-selected Focus/DND; no guessed conversations, movie viewing or private social context |
| 40: Other systems | Shared battery/audio reminder queue and fresh world-entry/crash-log delay; automatic Resource Guard, thermal monitoring and broad restart/social coordination remain future work |
| 41–42: Streamer and Creator | Streamer preview/overlay hiding, explicit capture limitation, and manual Creator/playtest hold; no editor/build-state snooping |
| 43, 47–49: No nagging, priority, Safety separation, personalization | Neutral messages, spacing, no score/failure/streak, oldest pending reminders with same-time comfort/break priority; no personal health model; Safety Center remains separate future work |
| 50–52: Retention, exports, shareable profiles | None/session/7/30/keep retention, explicit history export, validated configuration-only templates preserving private preferences |
| 53: Testing | Selected-notification preview and isolated simulation with due overrides; no change to the real session or hardware |
| 54: DND | Wellness prompts delayed and consolidated; no application-wide Safety/social notification router is claimed |
| 55–56: Example and philosophy | Core behaviors demonstrated by controlled tests; the full long-session narrative includes integrations not yet built |

Core logic, migration, privacy and UI callbacks are tested with controlled
clocks and local databases. OS/OpenVR/COM contract tests use substitutes.
Windows, real SteamVR sensors, overlay interaction and audio routing have not
been exercised here. The optional installer makes these integrations available
for live testing; missing hardware remains unavailable rather than simulated.

---

## Original supplied specification

Absolutely. The wellness side of VRC Eye could become a full **“long-session care system”** rather than just a collection of timers. The important philosophy we settled on is that it should help people take care of themselves during long VRChat sessions **without guilt, scoring, streaks, calorie tracking, body judgments, or forced behavior**.

The core idea is:

> VRC Eye notices how long the user has been in VR, what kind of session they are having, and whether several gentle reminders can be combined into one useful moment instead of constantly nagging them.

Below is the deeper design I’d use.

# 1. Wellness Center

Rather than scattering wellness toggles across Settings, I’d give it its own dashboard.

It could look something like:

```
VRC EYE WELLNESS
────────────────────────────────

Session                  2h 18m
Last break               54m ago
Headset worn             1h 47m continuously

Next reminders
Hydration                 12m
Eye rest                  27m
Movement                  36m

Quiet Hours               Off
Smart Reminders           On

Current Profile
Long Social Session

[ Take a Break ]
[ I'm Doing Okay ]
[ Snooze Reminders ]
```

Casual users could simply turn **Wellness Protection** on and choose a preset.

Advanced users could configure every reminder independently.

Nothing should imply:

> “You have failed because you didn't take a break.”

Instead:

> “You've been in VR for a while. This could be a good time for a short break.”

That tone matters a lot.

---

# 2. Hydration Reminder

This was one of the original wellness ideas.

VRC Eye could periodically give a gentle reminder to drink something.

Example:

```
💧 Hydration Reminder

You've been in VR for a while.

If you haven't had anything to drink recently,
this may be a good opportunity.

[ Done ]
[ Remind Me Later ]
[ Skip ]
```

The user should be able to choose the interval.

For example:

```
Hydration
Enabled              Yes
First reminder       60 min
Repeat interval      60 min

Only while VRChat running       ✓
Only while headset worn         ✓
Combine with break reminders    ✓
```

The important part is that **VRC Eye shouldn't try to prescribe an exact amount of water**.

It doesn't know:

- the person's size,
- environment,
- activity,
- food intake,
- medical circumstances,
- other drinks consumed.

So it should remind rather than prescribe.

A simple:

> “Consider having a drink.”

is much safer than:

> “You need 400 mL right now.”

---

# 3. General Break Reminder

This could probably become the central wellness reminder.

Instead of every feature firing separately, the Break system acts as a hub.

For example:

```
You've been in VR for 90 minutes.

This could be a good time to:

• take the headset off
• get a drink
• rest your eyes
• move around a little
```

Then:

```
[ Taking a Break ]
[ 15 More Minutes ]
[ Dismiss ]
```

Break reminders could be based on:

**Total session duration**

or

**Continuous headset-worn duration**

Those are different.

Someone might have had VRChat open for four hours but spent an hour away from the headset. VRC Eye shouldn't treat that the same as four uninterrupted hours of VR.

If SteamVR/device information is available, VRC Eye could track both:

```
VRChat Session       4h 12m
Headset Worn         2h 43m
Continuous VR        48m
```

That gives better context.

---

# 4. Headset-Off Break

This is slightly different from a general break.

The goal isn't:

> Stop using VRChat.

It's:

> Give your eyes/head/face a little time without the headset.

Example:

```
🥽 Headset Break

You've worn the headset continuously
for 1h 34m.

Consider taking it off for a few minutes.

[ Taking It Off ]
[ Later ]
```

VRC Eye could detect that the headset has actually been removed where the VR runtime exposes proximity/wear state.

If so, the reminder could automatically complete:

```
Headset removed.

Break timer started.
```

Then:

```
Headset break
03:42
```

Once the headset goes back on:

```
Welcome back.

Headset-off break: 6m 18s
```

No score. No “good/bad” judgment.

Just information.

---

# 5. Eye-Rest Reminder

This is particularly relevant during long VR/desktop sessions.

The reminder could simply suggest looking away from screens for a bit.

For example:

```
👁 Eye Rest

You've been looking at displays for a while.

Consider looking at something farther away
for a short moment.

[ Done ]
[ Later ]
```

It should work in both:

- VR Mode
- Desktop Mode

because desktop VRChat sessions can be just as long.

VRC Eye could optionally suppress this reminder if it detects the headset has recently been removed for a meaningful period.

That prevents:

```
Take a headset break!
```

followed two minutes later by:

```
Rest your eyes!
```

Smart consolidation should recognize that the first break probably covered the second.

---

# 6. Posture Reminder

This should be very neutral.

VRC Eye shouldn't claim to diagnose posture problems.

Instead:

```
Posture Check

You've been in the same session for a while.

If you've been sitting or standing in one
position, consider getting comfortable again.

[ Done ]
[ Later ]
```

Possible prompts:

> Relax your shoulders.

> Check whether you're leaning awkwardly.

> Make sure your chair/headset position is comfortable.

For Desktop Mode:

> Adjust your chair or monitor position if needed.

For standing VR:

> Check that you're still standing comfortably within your playspace.

The user could configure:

```
Posture Reminder
Every                60 min

VR                   ✓
Desktop              ✓
```

---

# 7. Gentle Movement / Stretch Reminder

This should explicitly **not become an exercise tracker**.

No:

- calories,
- workout targets,
- body-shape goals,
- exercise streaks,
- punishment for skipping.

Instead:

```
Movement Reminder

You've been relatively stationary for a while.

If comfortable, consider moving around
or stretching briefly.

[ Done ]
[ Later ]
```

VRC Eye doesn't need to tell the person exactly what exercise to perform.

It could optionally provide very simple choices:

```
Move around
Stretch comfortably
Change position
Take a short walk
```

but no demanding routines.

---

# 8. Standing-Duration Reminder

This is useful for full-body users.

Someone may stand in VR for several hours without really noticing.

VRC Eye could keep:

```
Standing session
1h 52m
```

and gently suggest:

```
You've been standing for a while.

If you want, this could be a good time to sit
or take a short break.

[ Sit / Break ]
[ I'm Fine ]
```

The key phrasing is **“if you want.”**

VRC Eye doesn't know whether standing is uncomfortable or problematic for that person.

Profiles could specify:

```
Standing VR Profile

Standing reminder       75 min
Break reminder          90 min
Hydration               60 min
```

---

# 9. Sitting-Duration Awareness

The inverse could also exist.

For long Desktop or seated-VR sessions:

```
You've been seated for 2 hours.

If comfortable, consider changing position
or moving around briefly.
```

Again, no workout goals.

This could feed into Smart Breaks rather than becoming yet another notification.

---

# 10. Meal / Snack Reminder

This one should be handled carefully and neutrally.

VRC Eye shouldn't:

- count calories,
- tell users how much to eat,
- label food good/bad,
- encourage restriction,
- track body weight,
- reward skipping meals.

Instead it can simply support **time-based meal reminders** configured by the user.

For example:

```
🍴 Meal Reminder

It's around the time you asked VRC Eye
to remind you about dinner.

[ Got It ]
[ 30 Minutes ]
[ Skip Today ]
```

Or:

```
You started VRChat before your usual
meal reminder.

Just a reminder in case you lost track of time.
```

Users could configure:

```
Breakfast      8:00 AM
Lunch          1:00 PM
Dinner         7:00 PM
```

or simply:

```
Remind me after 4 hours in VR.
```

But I prefer clock-based reminders for meals because they're less likely to turn food into a “session quota.”

---

# 11. Bathroom Reminder

This sounds silly until you consider long VRChat sessions.

A simple optional reminder could appear every few hours:

```
🚻 Quick Check

You've been in VR for quite a while.

Need a bathroom break before continuing?

[ I'm Good ]
[ Taking a Break ]
```

It should probably have a fairly long default interval and be disabled by default or folded into Smart Breaks.

You don't want VRC Eye constantly asking.

---

# 12. Bedtime Reminder

This could be one of the most useful options for people who lose track of time in social VR.

Users set their own preferred time:

```
Bedtime Reminder
Weekdays             11:30 PM
Friday/Saturday       1:00 AM

First reminder        At bedtime
Follow-up             30 min
```

Then:

```
🌙 Bedtime Reminder

It's 11:30 PM.

You asked VRC Eye to remind you around now.

[ Wrap Up ]
[ 30 More Minutes ]
[ Dismiss Tonight ]
```

Very important:

**VRC Eye should not automatically close VRChat because it's bedtime.**

That would be obnoxious.

The only exception would be if the user deliberately created their own automation like:

```
At 1:00 AM, offer "Close VRChat".
```

Even then, user confirmation should be required.

---

# 13. Quiet Hours / Wind-Down

This expands bedtime reminders into a gentler mode.

For example:

```
Quiet Hours
10:30 PM → 7:00 AM
```

During Quiet Hours VRC Eye could:

- reduce nonessential notification sounds,
- soften visual animations,
- suppress novelty effects,
- avoid loud join jingles,
- disable confetti,
- use calmer overlay transitions,
- prioritize important alerts only.

Maybe:

```
Wind-Down Mode

Notification volume        Low
Animations                  Reduced
Wellness reminders          Gentle
Novelty events              Off
Critical safety alerts      Always
```

That makes VRC Eye less stimulating late at night without telling the player what they must do.

---

# 14. Session-Duration Display

This sounds trivial, but it could be one of the most effective wellness tools simply because VR sessions distort time perception.

Display:

```
Session
2h 47m
```

Optional overlay:

```
VRC EYE
Session  2:47
```

Users might choose:

```
Always show
Show after 1 hour
Only show when overlay opened
Never show
```

No warning necessarily.

Just knowing:

> Oh, I've actually been in here for three hours.

can be useful.

---

# 15. Session Milestones

These are gentle time markers rather than warnings.

For example:

```
You've been in VR for 1 hour.
```

Then maybe:

```
2 hours
4 hours
6 hours
```

The user chooses.

Crucially, don't turn these into achievements:

❌ `NEW RECORD! 8 HOURS!`

That would encourage exactly the opposite behavior.

Instead:

> “Session duration: 4 hours.”

Neutral and informational.

---

# 16. Last-Break Timer

VRC Eye could track:

```
Last meaningful break
1h 14m ago
```

A meaningful break could mean:

- headset removed,
- VRChat inactive,
- user manually presses **Taking a Break**,
- perhaps several minutes of inactivity.

This can appear alongside session duration:

```
Session      3h 28m
Last break   1h 14m
```

Advanced settings could let the user define:

```
Minimum break duration:
5 min
```

so lifting the headset for 10 seconds doesn't reset everything.

---

# 17. “I'm Taking a Break” Button

This should be available everywhere:

```
[ I'm Taking a Break ]
```

Pressing it could:

- pause ordinary wellness timers,
- start break duration tracking,
- optionally enable VRC Eye DND,
- suppress noncritical desktop notifications,
- change VRC Eye-to-VRC Eye status to `Taking a break` if the user explicitly allows it,
- optionally mute VRC Eye audio.

Then:

```
BREAK MODE

Duration        07:13

[ Resume Session ]
```

If VRC Eye detects the headset being worn again, it could ask:

```
Resume session?
```

rather than assuming.

---

# 18. “Doing Okay?” Check-In

This was intended to be deliberately simple.

After a very long continuous session:

```
Doing okay?

[ Yep ]
[ I Should Take a Break ]
```

That's it.

No:

- mood diagnosis,
- mental-health scoring,
- interrogation,
- tracking emotional responses unless the user explicitly wants local notes.

Potentially:

```
I'm uncomfortable
```

could open practical options:

```
Headset off
Lower VRChat volume
Motion comfort
Take a break
Exit VRChat
```

But it shouldn't try to diagnose why the user feels bad.

---

# 19. Motion-Discomfort Mode

This could be a dedicated quick action.

The user feels uncomfortable in VR and activates:

```
MOTION COMFORT MODE
```

VRC Eye could then:

- display a calm overlay,
- suggest removing the headset,
- optionally reduce VRChat application audio,
- suppress VRC Eye animations,
- pause nonessential alerts,
- expose **Exit VRChat** prominently,
- start a break timer.

If supported through safe external controls, it could also surface relevant VRChat comfort controls without pretending VRC Eye can directly alter unsupported settings.

The emphasis should be:

> Stop and get comfortable if you need to.

Not:

> Push through it.

---

# 20. Hearing Protection

This overlaps with Safety but absolutely belongs in Wellness too.

VRC Eye monitors VRChat's **overall application audio level** externally.

It could detect:

- sudden peaks,
- sustained high output,
- long periods of unusually loud audio.

Then:

```
🔊 Hearing Comfort

VRChat has remained unusually loud
for a while.

[ Lower Volume ]
[ Mute VRChat ]
[ Ignore ]
```

Advanced users could configure:

```
Audio Guard
Peak warning              On
Sustained warning         On
Auto-lower volume         Off
```

Per-player attribution would require bridge/client telemetry, but ordinary Wellness doesn't need that.

---

# 21. Temperature / Comfort Reminder

This one is intentionally generic.

Example:

```
Comfort Check

You've been in VR for 2 hours.

Too warm, cold, or uncomfortable?
This might be a good time for a quick break.
```

Especially relevant with:

- headsets,
- full-body trackers,
- long standing sessions,
- warm rooms.

VRC Eye doesn't need a room-temperature sensor.

It's simply a reminder.

If external smart-home integration ever existed much later, that's different, but not required.

---

# 22. Room-Safety Check

Before a standing VR session:

```
Before you start:

• Playspace clear?
• Anything you could trip over?
• Cables out of the way?
• Enough room to move?

[ Ready ]
```

This could integrate with SteamVR playspace validation:

```
SteamVR Boundary        ✓
Tracking                ✓
Controllers             ✓

Room Check
[ Confirm Ready ]
```

Users could disable it permanently if they find it annoying.

Perhaps only show after:

- playspace changes,
- SteamVR recalibration,
- switching from seated → standing profile.

---

# 23. Low Battery as a Break Opportunity

Instead of:

```
Tracker battery 10%
```

only as a hardware warning, Wellness could reframe it gently:

```
Your left controller is at 10%.

If you were thinking about taking a break,
this might be a convenient time to charge it.
```

That's useful because hardware downtime naturally creates a break opportunity.

Same for:

- trackers,
- controllers,
- headset.

---

# 24. Smart Consolidated Reminders

This is probably the **most important wellness architecture feature**.

Without it, the user could receive:

```
8:00 Hydration
8:05 Eye rest
8:10 Posture
8:15 Movement
8:20 Bathroom
```

which is unbearable.

Instead VRC Eye should calculate:

```
Several reminders are due soon.
```

and combine them:

```
☕ BREAK SUGGESTION

You've been in VR for 1h 42m.

This break could also be a good time to:
• get a drink
• rest your eyes
• change position
• use the bathroom if needed

[ Taking a Break ]
[ 15 Minutes ]
```

Then those associated reminder timers reset appropriately.

This is where VRC Eye could feel much smarter than basic reminder software.

---

# 25. Reminder Cooldowns

After the user dismisses something:

```
Don't immediately remind them again.
```

For example:

```
Hydration due
User selects: Later

Cooldown: 30 minutes
```

Or:

```
Dismiss for session
```

Every reminder should support:

- Done
- Snooze
- Skip once
- Disable
- Open settings

That gives the user control.

---

# 26. Intelligent Snooze

Different reminders deserve different snooze options.

Hydration:

```
10 min
30 min
1 hour
```

Bedtime:

```
15 min
30 min
1 hour
Tonight
```

General break:

```
10 min
15 min
30 min
```

VRC Eye could remember the most commonly used one without making assumptions.

---

# 27. Reminder Context

A reminder should consider what the user is doing.

For example, don't interrupt immediately after:

```
World joining...
```

or during a critical loading/error state.

Instead:

```
Reminder became due at 8:42.
User currently changing worlds.
Wait until session stabilizes.
```

Then display it a few minutes later.

Similarly, if the user is actively in a creator/debug session, VRC Eye could wait for a quieter moment.

This would require some careful heuristics, but the result would feel much better.

---

# 28. VR vs Desktop Wellness Behavior

The system should behave differently depending on play mode.

### VR Mode

Emphasize:

- headset-off breaks,
- eye rest,
- standing duration,
- playspace safety,
- tracking/battery,
- motion comfort.

### Desktop Mode

Emphasize:

- sitting duration,
- posture,
- eye rest,
- session duration,
- breaks.

Same Wellness engine, different defaults.

---

# 29. Wellness Profiles

We discussed several predefined profiles.

### Short Session

For someone expecting to play under an hour.

Very light reminders.

### Long Social Session

More useful for 3–6 hour hangouts.

Hydration, breaks, eye rest, etc.

### Standing VR

Adds standing-duration and playspace reminders.

### Seated VR

De-emphasizes standing reminders and focuses on posture/movement.

### Desktop

Screen and sitting-oriented reminders.

### Quiet Night

Fewer sounds, wind-down emphasis.

### Custom

Everything manually configurable.

Profiles only change defaults.

They should never lock settings.

---

# 30. Automatic Profile Suggestions

VRC Eye could recognize:

```
VR mode + full-body trackers detected
```

and say:

> Standing VR profile might be useful.

But don't automatically enable it without permission.

Likewise:

```
Desktop VRChat detected
```

could suggest Desktop Wellness.

---

# 31. Session Summary

When VRChat closes:

```
SESSION SUMMARY

Session duration       3h 42m
Headset time           3h 06m
Breaks                 2
Longest continuous     1h 31m

Reminders
Hydration              2
Break                   2
Eye rest                1
```

This should remain **descriptive**, not evaluative.

Avoid:

❌ Wellness Score: 62/100\
❌ Bad session\
❌ You failed 3 reminders

Instead:

```
You dismissed 3 reminders.
```

if the user even wants that shown.

It could also show:

```
Longest break      14 min
```

but again no “excellent!” scoring.

---

# 32. Session History

If enabled locally:

```
Monday
Session       2h 08m
Breaks        1

Tuesday
Session       4h 21m
Breaks        3
```

This could help people understand patterns.

But I would **not** generate competitive streaks like:

> 7-day hydration streak!

because wellness gamification can easily become counterproductive.

---

# 33. Privacy of Wellness Data

Wellness information should be among the most private VRC Eye data.

By default:

- stored locally,
- not sent to VRChat,
- not visible to other VRC Eye users,
- not included in diagnostic bundles unless explicitly relevant/approved,
- no cloud sync unless deliberately enabled someday.

If VRC Eye-to-VRC Eye status exists, sharing:

```
Taking a break
```

could be allowed.

But things like:

```
Bathroom reminder
Meal reminder
Bedtime
```

should absolutely not become public profile information by default.

---

# 34. VRC Eye-to-VRC Eye Break Status

One small optional social feature:

```
Alice
Status: Taking a break
```

This could prevent friends from wondering where someone went.

The user explicitly enables:

```
Share break status with:
○ Nobody
● VRC Eye friends
○ Approved users only
```

No reason to share *why* they're taking a break.

---

# 35. Wellness Overlay

In VR:

```
VRC EYE
────────────
Session  2:14

💧 18m
👁 34m
☕ 46m
```

Or a much simpler mode:

```
Session 2:14
Next break ~46m
```

The overlay should never constantly occupy a huge chunk of vision.

A quick wrist view would probably work especially well.

---

# 36. Reminder Presentation Levels

Users could choose:

### Subtle

Tiny icon:

```
💧
```

### Normal

Small notification card.

### Prominent

Large VR overlay.

### Audio + Visual

For accessibility.

And critical safety alerts should be configured separately from ordinary wellness reminders.

---

# 37. Reduced Motion / Accessibility

Wellness reminders must respect accessibility settings.

If **Reduced Motion** is enabled:

- no bouncing icons,
- no screen transitions,
- no mascot jumping around,
- simple fade/static cards.

If the user has large-text mode:

```
BREAK REMINDER
```

should genuinely be readable inside VR.

Warnings should never rely only on:

```
green / yellow / red
```

They should say:

```
NORMAL
REMINDER
IMPORTANT
```

too.

---

# 38. Notification Sounds

Wellness sounds should be gentle and separately configurable.

For example:

```
Wellness Sounds
Volume            30%
Hydration          Soft chime
Break              Soft chime
Bedtime            Quiet tone
```

A user might want safety warnings loud but wellness reminders quiet.

Those categories should not share one volume setting.

---

# 39. Quiet Social Situations

Imagine someone is having an important conversation.

The user could press:

```
Snooze Wellness 30m
```

and VRC Eye delays noncritical wellness notifications.

Or:

```
Focus Mode
```

automatically suppresses them while preserving the timer.

When Focus Mode ends:

> Two wellness reminders became due while Focus Mode was active. Combine into one break suggestion?

That's much better than dumping two notifications instantly.

---

# 40. Smart Consolidation Across Other Systems

Wellness can cooperate with non-wellness events.

Examples:

### Tracker battery low

Instead of:

> Tracker battery low.

and separately:

> Take a break.

combine:

> Your tracker is getting low and your break reminder is due. This might be a convenient time to recharge.

### VRChat restarting

If Quick Mode Switch restarts VRChat:

> You're already between sessions. Want to take your scheduled break before relaunching?

### Crash

Don't immediately bombard someone with wellness reminders after a crash.

Recovery and system safety come first.

### Resource Guard

If VRChat needs to close because RAM/VRAM is critical:

> VRChat has been closed for system protection. VRC Eye can keep Break Mode active while you decide whether to restart.

---

# 41. Wellness During Streamer Mode

Streamers may spend very long sessions in VR.

VRC Eye could provide **private** wellness alerts that do not appear in captured overlays.

For example:

```
Streamer Wellness
Private overlay      ✓
Do not show on stream ✓
```

Then only the headset wearer sees:

> Hydration reminder.

OBS/desktop capture would not see it if technically possible through the chosen overlay path.

---

# 42. Creator Mode Wellness

World/avatar creators can get absorbed in testing for hours.

Creator Mode could retain the same reminders but time them around tests.

Example:

```
Playtest running
Break reminder due

Wait until playtest ends?
[ Yes ]
```

Then when the creator leaves/reloads:

> Your break reminder was due 12 minutes ago.

This prevents VRC Eye from interrupting active debugging.

---

# 43. “No Nagging” Rules

I would make these hard UX rules:

1. Never show the same wellness notification repeatedly within a short window.
2. Never punish the user for dismissing something.
3. Never use guilt language.
4. Never celebrate extremely long sessions.
5. Never shame food, sleep or activity choices.
6. Never force VRChat closed for a wellness reminder.
7. Never automatically share wellness data.
8. Never turn wellness into a leaderboard.
9. Always provide snooze/dismiss controls.
10. Critical system safety and ordinary wellness remain separate.

That could be written directly into VRC Eye's design guidelines.

---

# 44. Casual Mode

Most users probably shouldn't see 30 wellness settings.

Casual view:

```
WELLNESS

Wellness Reminders       ON

Profile
● Balanced

Hydration                ON
Breaks                   ON
Bedtime                  ON
Eye Rest                 ON

[ Customize ]
```

That's enough.

---

# 45. Advanced Mode

Advanced users get:

```
Hydration
Initial delay          60m
Repeat                 60m
Snooze                 20m
Combine window         15m

Break
Continuous VR         90m
Total session          120m
Minimum break reset     5m

Eye Rest
Interval               45m

Standing
Interval               75m

Smart Consolidation
Combine reminders      ✓
Maximum reminders      1 / 15m
Delay during loading   ✓
Delay during Focus     ✓
```

This fits perfectly with the Casual/Advanced split you wanted.

---

# 46. Smart Reminder Engine

Architecturally, I wouldn't implement each reminder as its own timer scattered throughout the program.

Instead:

```
                 Wellness Engine
                       │
      ┌────────────────┼─────────────────┐
      │                │                 │
  Session State    Device State       Time
      │                │                 │
      ▼                ▼                 ▼
 Hydration due    Headset worn      Bedtime due
 Eye rest due     Standing time
 Break due
      │
      └──────────────┬───────────────────┘
                     ▼
              Consolidation Engine
                     │
                     ▼
               One Notification
```

Every reminder provides:

```
due_time
priority
category
snooze_until
can_combine
minimum_interval
context_requirement
```

Then one engine decides what to display.

This will dramatically reduce bugs and notification spam.

---

# 47. Wellness Priority Levels

Something like:

```
Informational
Session duration

Gentle
Hydration / posture

Recommended
Long continuous session

Comfort
Motion discomfort / hearing comfort
```

But ordinary wellness should never use the same:

> CRITICAL

visual style as:

> GPU overheating / RAM exhaustion.

Users need to know the difference between:

> “You may want a drink.”

and:

> “Your system is about to run out of memory.”

---

# 48. Wellness and Safety Separation

I'd actually keep:

```
Safety Center
```

and:

```
Wellness Center
```

as separate tabs.

They can communicate internally.

Safety is:

> Something may be going wrong.

Wellness is:

> Here are gentle tools to help you take care of yourself during long sessions.

That difference prevents wellness reminders from feeling alarming.

---

# 49. Personalization Without Profiling

VRC Eye could learn **interaction preferences**, not health assumptions.

For example:

> User usually snoozes the first break reminder by 15 minutes.

VRC Eye might offer:

> Make 15 minutes your default snooze?

That's okay.

It should **not** infer:

> This user probably has insomnia.

or:

> This person needs more exercise.

No health profiling.

---

# 50. Wellness Data Retention

Users could select:

```
Wellness history

○ Don't save
● Current session only
○ 7 days
○ 30 days
○ Keep until manually deleted
```

By default I'd lean toward either:

**session only**

or a relatively short local history.

There isn't much reason to permanently archive years of bathroom/hydration reminder events.

---

# 51. Export Controls

If someone exports their VRC Eye data:

```
Include Wellness History?
[ ] Yes
```

Default unchecked.

Again, privacy first.

---

# 52. Wellness Profiles Could Be Shareable — Carefully

Users could share **configuration templates**:

```
Long Social Session.vrcwellness
```

containing:

- reminder intervals,
- notification style,
- quiet hours,
- overlay preferences.

But not personal wellness history.

That could be useful:

> Here's the reminder setup I use for long VR sessions.

---

# 53. Testing Mode

Because you're adding features individually, each reminder should have:

```
[ Test Notification ]
```

so users don't have to wait two hours to see what it looks like.

And developers could run:

```
Wellness Simulation

Session time         3h
Last break           2h
Hydration due        Yes
Bedtime due          Yes
Headset worn         Yes

[ Run ]
```

Then verify that Smart Consolidation produces one sensible reminder.

---

# 54. Do Not Disturb vs Wellness

DND shouldn't necessarily disable everything.

I'd distinguish:

```
DND

Ordinary notifications     Suppressed
Social notifications       Suppressed
Wellness reminders         Delayed
Safety warnings            Always allowed
```

Then once DND ends:

```
One wellness reminder is waiting.
```

Not five.

---

# 55. Full Example of a Long Session

Imagine this timeline:

```
7:00 PM
VRChat starts.

7:55 PM
Hydration reminder becomes due.

8:00 PM
Break reminder is nearly due.
VRC Eye waits and combines them.

8:05 PM

BREAK SUGGESTION
Session: 1h 05m

This could be a good time to:
• get a drink
• rest your eyes
• change position

User:
[ Taking a Break ]
```

Headset removed.

```
8:06 PM
Break Mode begins.
```

User returns:

```
8:14 PM
Break duration: 8m 02s
```

Timers reset.

At 10:30 PM:

```
Quiet Hours begin.
Animations reduced.
Notification sounds lowered.
```

At 11:30 PM:

```
BEDTIME REMINDER

It's around the time you asked VRC Eye
to remind you.

[ Wrap Up ]
[ 30 More Minutes ]
[ Dismiss Tonight ]
```

At midnight the user closes VRChat.

VRC Eye shows:

```
SESSION

Duration              5h 00m
Headset time           4h 03m
Breaks                 3
Longest continuous     1h 22m

[ Close ]
```

No score.

No:

> “You did poorly.”

No:

> “Congratulations, five-hour streak!”

Just useful context.

---

# 56. The Ideal Wellness Philosophy

If we reduce everything to design principles, I’d use this:

> **Inform, remind, consolidate, respect dismissal, preserve privacy, and never shame.**

VRC Eye should behave like:

> “Hey, you've been in there a while. Want a break?”

not:

> “You have violated your wellness target.”

And because VRC Eye already plans to know things like **VRChat session duration, headset state, controller batteries, tracking state, Quiet Hours, Resource Guard status and SteamVR state**, the Wellness system can be much smarter than a generic timer app without needing to collect intimate health informatio