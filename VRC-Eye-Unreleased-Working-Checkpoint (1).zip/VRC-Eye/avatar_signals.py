"""Bounded, local Avatar Creator observations; never start native providers.

Provider values are private until a separately armed Avatar Link route permits
them. Device identifiers remain in this local adapter, never in scalar signals.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import base64
import hashlib
import json
import math
from pathlib import Path
import stat
import struct
import threading
import time
import uuid
import wave


def _number(value, low=0., high=1.):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError('Use a finite value in the supported range.')
    return float(value)


def signal(value=None, *, unit='state', source='unavailable', observed_at=None,
           valid=False, quality='unavailable', stale_seconds=5., privacy='private'):
    if value is not None and type(value) not in (int, float, bool):
        raise ValueError('Avatar signals contain scalar values only.')
    if type(value) in (int, float) and not math.isfinite(value):
        raise ValueError('A signal cannot contain a nonfinite value.')
    return dict(value=value, unit=unit, source=source, observed_at=observed_at,
                valid=bool(valid and value is not None), quality=quality,
                stale_seconds=stale_seconds, privacy=privacy)


class ThresholdWarning:
    """A sustained high/low condition with a separate recovery threshold."""
    def __init__(self, threshold, recovery, *, seconds=3., below=False):
        self.threshold = _number(threshold, -1e15, 1e15)
        self.recovery = _number(recovery, -1e15, 1e15)
        self.seconds = _number(seconds, 0., 600.)
        if below and recovery <= threshold or not below and recovery >= threshold:
            raise ValueError('Recovery must be beyond the threshold toward normal.')
        self.below = below
        self.reset()

    def reset(self):
        self.active = False
        self.since = None
        self.previous = None

    def update(self, value, now):
        if value is None or type(value) not in (int, float) or not math.isfinite(value):
            self.reset()
            return None
        if self.previous is not None and (now < self.previous or now - self.previous > 10):
            self.reset()
        self.previous = now
        bad = value <= self.threshold if self.below else value >= self.threshold
        recovered = value >= self.recovery if self.below else value <= self.recovery
        if self.active:
            if recovered:
                self.active, self.since = False, None
        elif bad:
            if self.since is None:
                self.since = now
            self.active = now - self.since >= self.seconds
        else:
            self.since = None
        return self.active


class Envelope:
    def __init__(self, *, attack=.1, release=.5, gain=1., ceiling=1., gate=.01):
        self.attack, self.release = _number(attack, .001, 10), _number(release, .001, 10)
        self.gain, self.ceiling, self.gate = _number(gain, 0, 10), _number(ceiling), _number(gate)
        self.value = 0.

    def update(self, raw, seconds):
        seconds = _number(seconds, 0, 10)
        raw = _number(raw)
        target = min(self.ceiling, raw * self.gain) if raw >= self.gate else 0.
        duration = self.attack if target > self.value else self.release
        self.value += (target - self.value) * (1 - math.exp(-seconds / duration))
        return min(self.ceiling, max(0., self.value))

    def reset(self):
        self.value = 0.


class WavAnalysis:
    """User-selected PCM WAV analysis cursor. Does not play or capture audio."""
    def __init__(self, path):
        path = Path(path)
        if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode) or path.stat().st_size > 100 * 1024 * 1024:
            raise ValueError('Choose a regular local WAV file of at most 100 MiB.')
        self.reader = None
        try:
            self.reader = wave.open(str(path), 'rb')
            if (self.reader.getcomptype() != 'NONE' or self.reader.getsampwidth() not in (1, 2, 3, 4)
                    or self.reader.getnchannels() not in (1, 2)
                    or not 8000 <= self.reader.getframerate() <= 96000
                    or not 0 < self.reader.getnframes() / self.reader.getframerate() <= 3600):
                raise ValueError('Choose a PCM WAV, one or two channels, 8–96 kHz, at most one hour.')
            self.duration = self.reader.getnframes() / self.reader.getframerate()
            self.position = 0.
        except Exception:
            self.close()
            raise ValueError('The selected file is not a supported bounded PCM WAV.') from None

    def advance(self, seconds):
        seconds = _number(seconds, .001, 1.)
        reader = self.reader
        if reader is None:
            raise ValueError('WAV analysis is closed.')
        data = reader.readframes(max(1, round(seconds * reader.getframerate())))
        width = reader.getsampwidth()
        if not data:
            return dict(energy=0., progress=1., ended=True)
        if len(data) % (width * reader.getnchannels()):
            raise ValueError('The WAV sample data is truncated.')
        count = len(data) // width
        if width == 1:
            samples = ((value - 128) / 128. for value in data)
        elif width == 2:
            samples = (value[0] / 32768. for value in struct.iter_unpack('<h', data))
        elif width == 4:
            samples = (value[0] / 2147483648. for value in struct.iter_unpack('<i', data))
        else:
            samples = (int.from_bytes(data[i:i + 3], 'little', signed=True) / 8388608.
                       for i in range(0, len(data), 3))
        energy = min(1., math.sqrt(sum(value * value for value in samples) / count))
        self.position = reader.tell() / reader.getframerate()
        return dict(energy=energy, progress=min(1., self.position / self.duration),
                    ended=reader.tell() >= reader.getnframes())

    def seek(self, seconds):
        seconds = _number(seconds, 0., self.duration)
        self.reader.setpos(min(self.reader.getnframes(), round(seconds * self.reader.getframerate())))
        self.position = seconds

    def close(self):
        if self.reader is not None:
            self.reader.close()
            self.reader = None


STATUS_VALUES = {
    'availability': ('available', 'busy', 'away', 'quiet'),
    'activity': ('idle', 'recording', 'streaming', 'photography', 'testing', 'media'),
    'system': ('unavailable', 'connected', 'stale', 'degraded'),
    'message': ('none', 'wave_first', 'ask_before_joining', 'taking_break'),
}

# A reviewed preset may copy only these exact typed routes for parameters
# present in the current manifest. Validity flags are maintained by Avatar Link.
# Heartbeat, action feedback and native AFK are deliberately separate owners.
TOOLKIT_SIGNAL_MAPPINGS = {
    'EYE_In_Status': 'status.presentation',
    'EYE_In_Battery': 'battery.lowest',
    'EYE_In_Recording': 'obs.recording_state',
    'EYE_In_Audio': 'media.intensity',
    'EYE_In_Quiet': 'companion.quiet',
    'EYE_In_Hardware': 'hardware.normalized',
    'EYE_In_Resource': 'resource.pressure_state',
    'EYE_In_Media': 'media.presentation',
}


class StatusResolver:
    def __init__(self, *, clock=time.monotonic):
        self.clock = clock
        self.entries = {}

    def set(self, dimension, value, *, source='manual', seconds=3600., priority=None):
        if dimension not in STATUS_VALUES or value not in STATUS_VALUES[dimension]:
            raise ValueError('Select a supported status dimension and authored status.')
        if source not in ('manual', 'native', 'companion', 'provider', 'inferred'):
            raise ValueError('Unsupported status source.')
        seconds = _number(seconds, .1, 86400.)
        # Manual intent is always stronger than provider/inferred states.
        rank = {'manual': 100, 'native': 70, 'companion': 60, 'provider': 40, 'inferred': 10}[source]
        self.entries[(dimension, source)] = dict(value=value, source=source, priority=rank,
                                               deadline=self.clock() + seconds, observed=self.clock())

    def clear(self, dimension=None, source='manual'):
        self.entries = {key: value for key, value in self.entries.items()
                        if not (key[1] == source and (dimension is None or key[0] == dimension))}

    def resolve(self):
        now = self.clock()
        self.entries = {key: value for key, value in self.entries.items() if value['deadline'] > now}
        result = {}
        for dimension in STATUS_VALUES:
            candidates = [value for (kind, _), value in self.entries.items() if kind == dimension]
            if candidates:
                row = max(candidates, key=lambda value: (value['priority'], value['observed']))
                result[dimension] = dict(row, remaining=row['deadline'] - now,
                                         index=STATUS_VALUES[dimension].index(row['value']))
            else:
                result[dimension] = dict(value=None, source='unavailable', remaining=0., index=None)
        return result


class OBSProvider:
    """Explicit localhost obs-websocket v5 read-only status adapter.

    Network operations are synchronous and bounded; call connect/sample from a
    worker. Construction and snapshot do not connect. No credentials are saved.
    """
    REQUESTS = ('GetStreamStatus', 'GetRecordStatus', 'GetReplayBufferStatus')

    def __init__(self, *, connector=None, clock=time.monotonic, wall=time.time):
        self.connector, self.clock, self.wall = connector, clock, wall
        self.socket = None
        self.lock = threading.RLock()
        self.last = None
        self.data = {}
        self.status = 'Disconnected; recording and streaming state unknown.'

    def _read(self, op):
        raw = self.socket.recv(timeout=2.)
        if not isinstance(raw, str) or len(raw.encode('utf-8')) > 16384:
            raise ValueError('Unsupported OBS response.')
        row = json.loads(raw)
        if not isinstance(row, dict) or row.get('op') != op or not isinstance(row.get('d'), dict):
            raise ValueError('Unexpected OBS response.')
        return row['d']

    def connect_local(self, port=4455, password=''):
        if type(port) is not int or not 1024 <= port <= 65535 or not isinstance(password, str) or len(password) > 1024:
            raise ValueError('Choose a localhost port from 1024 to 65535 and a bounded password.')
        with self.lock:
            self.close()
            try:
                connect = self.connector
                if connect is None:
                    from websockets.sync.client import connect
                self.socket = connect(f'ws://127.0.0.1:{port}', open_timeout=2., close_timeout=.2,
                                      max_size=16384, max_queue=4, compression=None, proxy=None)
                hello = self._read(0)
                if type(hello.get('rpcVersion')) is not int or hello['rpcVersion'] < 1:
                    raise ValueError('Unsupported OBS protocol.')
                identify = dict(rpcVersion=1, eventSubscriptions=0)
                if 'authentication' in hello:
                    auth = hello['authentication']
                    if not isinstance(auth, dict) or any(not isinstance(auth.get(key), str) or len(auth[key]) > 1024 for key in ('salt', 'challenge')):
                        raise ValueError('Invalid authentication challenge.')
                    secret = base64.b64encode(hashlib.sha256((password + auth['salt']).encode()).digest()).decode()
                    identify['authentication'] = base64.b64encode(hashlib.sha256((secret + auth['challenge']).encode()).digest()).decode()
                self.socket.send(json.dumps(dict(op=1, d=identify)))
                if self._read(2).get('negotiatedRpcVersion') != 1:
                    raise ValueError('Unsupported OBS protocol.')
                self.status = 'Connected to local OBS; read-only status.'
                return self.sample(force=True)
            except Exception:
                self.close()
                self.status = 'OBS unavailable. Check its WebSocket settings, password and optional avatar requirements.'
                raise ValueError(self.status) from None

    def sample(self, *, force=False):
        with self.lock:
            if self.socket is None or not force and self.last is not None and self.clock() - self.last < 2.:
                return self.snapshot()
            try:
                values = {}
                for request in self.REQUESTS:
                    request_id = str(uuid.uuid4())
                    self.socket.send(json.dumps(dict(op=6, d=dict(requestType=request, requestId=request_id))))
                    response = self._read(7)
                    if response.get('requestId') != request_id or response.get('requestType') != request:
                        raise ValueError('OBS response did not match the request.')
                    status = response.get('requestStatus', {})
                    data = response.get('responseData', {})
                    if not isinstance(status, dict) or status.get('result') is not True or not isinstance(data, dict):
                        values[request] = {}
                        continue
                    values[request] = {key: value for key, value in data.items()
                                       if key in ('outputActive', 'outputPaused') and type(value) is bool}
                self.data = {'streaming': values['GetStreamStatus'].get('outputActive'),
                             'recording': values['GetRecordStatus'].get('outputActive'),
                             'recording_paused': values['GetRecordStatus'].get('outputPaused'),
                             'replay_buffer': values['GetReplayBufferStatus'].get('outputActive')}
                self.last = self.clock()
            except Exception:
                self.close()
                self.status = 'OBS disconnected; recording and streaming state unknown. Reconnect explicitly.'
            return self.snapshot()

    def snapshot(self):
        # Network work holds self.lock. Snapshot must never wait for that worker
        # on the Tk thread; sampled data is replaced as a whole, never mutated.
        socket, last, data, status = self.socket, self.last, self.data, self.status
        age = self.clock() - last if last is not None else None
        current = socket is not None and age is not None and 0 <= age <= 5.
        return dict(connected=socket is not None, status=status, signals={
            'obs.' + key: signal(value if current else None, source='OBS status',
                                 observed_at=self.wall() - age if current else None,
                                 valid=current and value is not None, quality='observed' if current else 'unavailable')
            for key, value in ((key, data.get(key)) for key in ('streaming', 'recording', 'recording_paused', 'replay_buffer'))})

    def close(self):
        with self.lock:
            socket, self.socket = self.socket, None
            self.data, self.last = {}, None
            self.status = 'Disconnected; recording and streaming state unknown.'
            if socket is not None:
                try:
                    socket.close()
                except Exception:
                    pass


class AvatarSignals:
    def __init__(self, runtime=None, resource_service=None, *, app=None, clock=time.monotonic, wall=time.time):
        self.runtime, self.resource_service, self.app = runtime, resource_service, app
        self.clock, self.wall = clock, wall
        self.resolver = StatusResolver(clock=clock)
        self.obs = OBSProvider(clock=clock, wall=wall)
        self._obs_thread = None
        self._obs_stop = threading.Event()
        self._obs_closed = False
        self.assignments, self.devices, self.warnings = {}, [], {}
        self.generation = None
        self.media_source, self.wav = 'none', None
        self.amplitude, self.media_progress, self.media_at = 0., 0., None
        self.media_ended = False
        self.envelope = Envelope()
        self.last_media_tick = clock()
        self.resource_warning = None
        self.hardware_metric = None
        self.manual_media_state = None
        self.trace = deque(maxlen=200)
        self.availability_observations = {}

    def start_obs(self, port=4455, password=''):
        """Explicit opt-in; a single bounded worker owns the OBS connection."""
        if self._obs_closed:
            raise ValueError('Avatar providers are closed.')
        if type(port) is not int or not 1024 <= port <= 65535 or not isinstance(password, str) or len(password) > 1024:
            raise ValueError('Choose a localhost port from 1024 to 65535 and a bounded password.')
        if self._obs_thread is not None and self._obs_thread.is_alive():
            raise ValueError('OBS is connected or finishing its previous request. Stop it before connecting again.')
        stop = self._obs_stop = threading.Event()
        provider = self.obs = OBSProvider(clock=self.clock, wall=self.wall)
        provider.status = 'Connecting to selected localhost OBS; read-only status.'
        secret = [password]
        def work():
            reason = None
            credential = secret.pop()
            try:
                if stop.is_set():
                    return
                try:
                    provider.connect_local(port, credential)
                finally:
                    credential = None
                while not stop.wait(2.):
                    if not provider.sample().get('connected'):
                        reason = provider.status
                        break
            except Exception:
                reason = 'OBS unavailable. Check its WebSocket settings, password and optional avatar requirements.'
            finally:
                credential = None
                provider.close()
                if reason and not stop.is_set():
                    provider.status = reason
        self._obs_thread = threading.Thread(target=work, daemon=True, name='VRC-Eye-Avatar-OBS')
        self._obs_thread.start()
        return dict(status='Connecting', endpoint='localhost', read_only=True)

    def refresh_obs(self):
        """Nonblocking cached refresh; connected workers already poll every 2s."""
        return self.obs.snapshot()

    def stop_obs(self):
        """Invalidate data now; the owner closes after its bounded request ends."""
        self._obs_stop.set()
        if self._obs_thread is None or not self._obs_thread.is_alive():
            self.obs.close()
        self.obs = OBSProvider(clock=self.clock, wall=self.wall)
        self.obs.status = 'OBS stopped; all recording and streaming states are unknown.'
        self.resolver.clear('activity', source='provider')
        return self.obs.snapshot()

    def assign_device(self, role, device_id, *, include_lowest=True):
        if role not in ('left', 'right', 'headset', 'tracker1', 'tracker2', 'tracker3', 'tracker4'):
            raise ValueError('Choose left, right, headset, or tracker1–tracker4.')
        if device_id is None:
            self.assignments.pop(role, None)
            return
        candidates = [row for row in self.devices if row['device_id'] == device_id]
        if len(candidates) != 1:
            raise ValueError('Refresh and explicitly select a currently observed device.')
        row = candidates[0]
        self.assignments[role] = dict(device_id=device_id, stable=bool(row.get('stable')),
                                     generation=self.generation, include_lowest=bool(include_lowest))
        self.warnings[role] = ThresholdWarning(.2, .25, seconds=0., below=True)

    def set_manual_status(self, dimension, value, *, seconds=3600.):
        self.resolver.set(dimension, value, source='manual', seconds=seconds)

    def clear_manual_status(self, dimension=None):
        self.resolver.clear(dimension)

    def observe_availability(self, *, native_afk=None, companion_quiet=None, seconds=5.):
        """Consume independently supported observations; never change VRChat state."""
        seconds = _number(seconds, .1, 60.)
        for key, value in (('native.afk', native_afk), ('companion.quiet', companion_quiet)):
            if value is not None and type(value) is not bool:
                raise ValueError('Availability observations must be Boolean or unknown.')
            self.availability_observations[key] = (value, self.clock(), seconds)
        self.resolver.clear('availability', source='native')
        self.resolver.clear('availability', source='companion')
        if native_afk is True:
            self.resolver.set('availability', 'away', source='native', seconds=seconds)
        if companion_quiet is True:
            self.resolver.set('availability', 'quiet', source='companion', seconds=seconds)

    def set_media_source(self, source, path=None):
        if source not in ('none', 'manual', 'wav'):
            raise ValueError('Select None, manual simulation, or a local PCM WAV. Live capture is unavailable.')
        replacement = WavAnalysis(path) if source == 'wav' else None
        if self.wav is not None:
            self.wav.close()
        self.wav, self.media_source = replacement, source
        self.amplitude, self.media_progress, self.media_at = 0., 0., None
        self.media_ended = False
        self.envelope.reset()
        self.last_media_tick = self.clock()

    def set_manual_amplitude(self, value):
        if self.media_source != 'manual':
            raise ValueError('Select manual simulation first.')
        self.amplitude, self.media_at = _number(value), self.clock()

    def set_manual_media_state(self, state, *, seconds=300.):
        """An authored user declaration; never inferred from a file or waveform."""
        if state not in ('stopped', 'playing', 'paused'):
            raise ValueError('Select stopped, playing or paused for the manual presentation.')
        self.manual_media_state = (('stopped', 'playing', 'paused').index(state) + 1,
                                   self.clock(), _number(seconds, .1, 86400.))

    def configure_hardware_metric(self, metric, minimum, maximum):
        from peer_tools import METRICS
        if metric not in METRICS:
            raise ValueError('Choose an available named measurement for normalization.')
        low = _number(minimum, 0., METRICS[metric][1])
        high = _number(maximum, 0., METRICS[metric][1])
        if high <= low:
            raise ValueError('The normalization maximum must exceed its minimum.')
        self.hardware_metric = (metric, low, high)

    def advance_media(self, seconds=.1):
        if self.media_source != 'wav' or self.wav is None:
            raise ValueError('Select a WAV analysis source first.')
        result = self.wav.advance(seconds)
        self.amplitude, self.media_progress = result['energy'], result['progress']
        self.media_ended, self.media_at = result['ended'], self.clock()
        return result

    def seek_media(self, seconds=0.):
        if self.wav is None:
            raise ValueError('Select a WAV analysis source first.')
        self.wav.seek(seconds)
        self.envelope.reset()
        self.amplitude, self.media_at, self.media_ended = 0., None, False
        self.media_progress = self.wav.position / self.wav.duration

    def configure_resource_warning(self, metric, threshold, recovery, *, seconds=3., below=False):
        from peer_tools import METRICS
        if metric not in METRICS:
            raise ValueError('Choose an available named resource measurement.')
        _number(threshold, 0., METRICS[metric][1]); _number(recovery, 0., METRICS[metric][1])
        self.resource_warning = (metric, ThresholdWarning(threshold, recovery, seconds=seconds, below=below))

    def _battery_signals(self):
        try:
            raw = self.runtime.snapshot() if self.runtime is not None else {}
        except Exception:
            raw = {}
        generation = raw.get('generation')
        if self.generation is not None and generation != self.generation:
            self.assignments = {key: value for key, value in self.assignments.items() if value['stable']}
            for warning in self.warnings.values():
                warning.reset()
        self.generation = generation
        age = self.clock() - raw['received'] if type(raw.get('received')) in (int, float) else None
        valid = raw.get('steamvr_available') is True and age is not None and math.isfinite(age) and 0 <= age <= 5.
        self.devices = []
        if valid and isinstance(raw.get('batteries'), (list, tuple)):
            seen = set()
            for row in raw['batteries'][:64]:
                if not isinstance(row, dict):
                    continue
                stable = row.get('stable_id')
                identifier = stable or row.get('device')
                if not isinstance(identifier, str) or not 1 <= len(identifier) <= 200 or identifier in seen:
                    continue
                percent = row.get('percent')
                if type(percent) not in (int, float) or not math.isfinite(percent) or not 0 <= percent <= 100:
                    continue
                seen.add(identifier)
                self.devices.append(dict(device_id=identifier, label=str(row.get('label', 'Device'))[:100],
                                         percent=percent, stable=bool(stable),
                                         charging=row.get('charging') if row.get('charging_valid') is True and type(row.get('charging')) is bool else None))
        devices = {row['device_id']: row for row in self.devices}
        result, lowest = {}, []
        roles = set(self.assignments) | {'left', 'right', 'headset'}
        for role in sorted(roles):
            assignment = self.assignments.get(role, {})
            device = devices.get(assignment.get('device_id'))
            value = device['percent'] / 100 if device else None
            observed = self.wall() - age if device else None
            result['battery.' + role] = signal(value, unit='fraction', source='OpenVR assigned role',
                observed_at=observed, valid=device is not None, quality='observed' if device else 'unavailable')
            charging = device.get('charging') if device else None
            result['charging.' + role] = signal(charging, source='OpenVR assigned role',
                observed_at=observed, valid=charging is not None, quality='observed' if charging is not None else 'unavailable')
            warning = self.warnings.get(role)
            warned = warning.update(value, self.clock()) if warning else None
            result['battery_warning.' + role] = signal(warned, source='Battery threshold 20% / recovery 25%',
                observed_at=observed, valid=warned is not None, quality='derived' if warned is not None else 'unavailable')
            if device and assignment.get('include_lowest'):
                lowest.append(value)
        result['battery.lowest'] = signal(min(lowest) if lowest else None, unit='fraction',
            source='Included assigned devices only', observed_at=self.wall() - age if lowest else None,
            valid=bool(lowest), quality='derived' if lowest else 'unavailable')
        return result

    def sample(self):
        now = self.clock()
        values = self._battery_signals()
        from peer_tools import performance_card, collect_snapshots
        snapshots = {}
        try:
            snapshots = collect_snapshots(self.app)
            if self.resource_service is not None:
                snapshots['resources'] = self.resource_service.snapshot()
            card = performance_card(snapshots, app=self.app, wall=self.wall)
            for key, row in card['metrics'].items():
                values['resource.' + key] = signal(row['value'], unit=row['unit'], source=row['source'],
                    observed_at=card['captured_at'] if row['value'] is not None else None,
                    valid=row['value'] is not None, quality=row['quality'])
        except Exception:
            card = {'metrics': {}}
        if self.resource_warning is not None:
            key, threshold = self.resource_warning
            measurement = values.get('resource.' + key, {})
            warned = threshold.update(measurement.get('value') if measurement.get('valid') else None, now)
            values['resource.warning'] = signal(warned, source='Sustained threshold: ' + key,
                observed_at=self.wall() if warned is not None else None, valid=warned is not None,
                quality='derived' if warned is not None else 'unavailable')
        resource = snapshots.get('resources', {})
        resource_age = resource.get('age')
        fresh_resource = resource.get('stale') is False and type(resource_age) in (int, float) and math.isfinite(resource_age) and 0 <= resource_age <= 5.
        severity = resource.get('summary', {}).get('severity') if fresh_resource else None
        pressure = {'HEALTHY': 1, 'ELEVATED': 2, 'WARNING': 3, 'CRITICAL': 3, 'EMERGENCY': 3}.get(severity)
        pressure_source = 'Resource Guard severity (does not identify a cause)'
        if self.resource_warning is not None:
            warning = values.get('resource.warning', {})
            pressure = (3 if warning['value'] else 1) if warning.get('valid') else None
            pressure_source = warning.get('source', 'Selected resource threshold')
        values['resource.pressure_state'] = signal(pressure, unit='authored enum', source=pressure_source,
            observed_at=self.wall() if pressure is not None else None, valid=pressure is not None,
            quality='derived' if pressure is not None else 'unavailable')
        values['hardware.normalized'] = signal(unit='fraction', source='No selected hardware metric')
        if self.hardware_metric is not None:
            metric, low, high = self.hardware_metric
            reading = values.get('resource.' + metric, {})
            present = reading.get('valid') is True
            values['hardware.normalized'] = signal(min(1., max(0., (reading['value'] - low) / (high - low))) if present else None,
                unit='fraction', source=reading.get('source', 'unavailable') + ' normalized ' + metric,
                observed_at=reading.get('observed_at'), valid=present, quality='derived' if present else 'unavailable')
        obs = self.obs.snapshot()
        values.update(obs['signals'])
        stream, record = values['obs.streaming'], values['obs.recording']
        paused = values['obs.recording_paused']
        recording_state = None
        if stream['valid'] and stream['value'] is True:
            recording_state = 4
        elif stream['valid'] and record['valid']:
            if record['value'] is False:
                recording_state = 1
            elif paused['valid']:
                recording_state = 3 if paused['value'] else 2
        values['obs.recording_state'] = signal(recording_state, unit='authored enum', source='OBS read-only status',
            observed_at=stream['observed_at'] if recording_state is not None else None,
            valid=recording_state is not None, quality='derived' if recording_state is not None else 'unavailable')
        if stream['valid'] and stream['value'] is True:
            self.resolver.set('activity', 'streaming', source='provider', seconds=2.)
        elif record['valid'] and record['value'] is True:
            self.resolver.set('activity', 'recording', source='provider', seconds=2.)
        elif stream['valid'] and record['valid']:
            self.resolver.set('activity', 'idle', source='provider', seconds=2.)
        else:
            self.resolver.clear('activity', source='provider')
        for key, (value, received, ttl) in self.availability_observations.items():
            fresh = value is not None and 0 <= now - received <= ttl
            values[key] = signal(value if fresh else None,
                source='VRChat reported AFK' if key == 'native.afk' else 'VRC Eye notification policy',
                observed_at=self.wall() - (now - received) if fresh else None,
                valid=fresh, quality='observed' if fresh else 'unavailable', stale_seconds=ttl)
        media_valid = self.media_source != 'none' and self.media_at is not None and 0 <= now - self.media_at <= 5.
        dt = min(1., max(0., now - self.last_media_tick))
        self.last_media_tick = now
        amplitude = self.envelope.update(self.amplitude if media_valid else 0., dt)
        quality = 'simulated' if self.media_source == 'manual' else 'file_analysis' if self.media_source == 'wav' else 'unavailable'
        for key, value, unit in (('media.intensity', amplitude, 'fraction'),
                                 ('media.progress', self.media_progress, 'fraction'),
                                 ('media.active', self.amplitude > 0 and not self.media_ended, 'state')):
            values[key] = signal(value if media_valid else None, unit=unit,
                source='Manual simulator' if self.media_source == 'manual' else 'WAV analysis (no playback)',
                observed_at=self.wall() - (now - self.media_at) if media_valid else None,
                valid=media_valid, quality=quality if media_valid else 'unavailable')
        statuses = self.resolver.resolve()
        for dimension, row in statuses.items():
            values['status.' + dimension] = signal(row['index'], unit='authored enum', source=row['source'],
                observed_at=self.wall() if row['index'] is not None else None, valid=row['index'] is not None,
                quality='declared' if row['source'] == 'manual' else 'observed', stale_seconds=row['remaining'])
        availability = statuses['availability']
        presentation = availability['index'] + 1 if availability['index'] is not None else None
        values['status.presentation'] = signal(presentation, unit='authored enum', source=availability['source'],
            observed_at=self.wall() if presentation is not None else None, valid=presentation is not None,
            quality='declared' if availability['source'] == 'manual' else 'observed', stale_seconds=availability['remaining'])
        media_state = self.manual_media_state
        media_fresh = media_state is not None and 0 <= now - media_state[1] <= media_state[2]
        values['media.presentation'] = signal(media_state[0] if media_fresh else None, unit='authored enum',
            source='User-declared media presentation; playback not observed',
            observed_at=self.wall() if media_fresh else None,
            valid=media_fresh, quality='declared' if media_fresh else 'unavailable',
            stale_seconds=media_state[2] if media_state else 5.)
        return dict(signals=values, devices=deepcopy(self.devices), assignments=deepcopy(self.assignments),
                    status=statuses, providers={'battery': 'Existing Wellness SteamVR connection only; assign device roles explicitly.',
                    'obs': self.obs.snapshot()['status'], 'media': self.media_source,
                    'live_audio_capture': 'Unavailable; selected WAV analysis and manual simulation are supported.'})

    def route(self, link, mappings, *, allow_public=False, allow_simulated=False):
        """Send selected scalars through Avatar Link's own manifest/privacy gates."""
        if not isinstance(mappings, dict) or len(mappings) > 64:
            raise ValueError('Choose at most 64 explicit signal-to-parameter mappings.')
        sample = self.sample()['signals']
        results = []
        for key, name in mappings.items():
            row = sample.get(key)
            if row is None or not isinstance(name, str):
                results.append(dict(signal=key, parameter=name, status='unsupported'))
                continue
            if row['quality'] in ('simulated', 'file_analysis') and not allow_simulated:
                results.append(dict(signal=key, parameter=name, status='preview_only'))
                continue
            try:
                # Link remains final authority for declared type, synchronization,
                # consent, ownership, endpoint identity and avatar context.
                declaration = getattr(link, 'manifest', {}) or {}
                declarations = declaration.get('parameters', []) if isinstance(declaration, dict) else []
                parameter = next((p for p in declarations if isinstance(p, dict) and p.get('name') == name), None)
                if parameter is None:
                    raise ValueError('A declared parameter is required.')
                if (parameter.get('synced') is True or parameter.get('privacy') == 'public') and not allow_public:
                    raise ValueError('Public/synchronized routing needs separate approval.')
                # None is invalid data, not a claimed zero. The link chooses its
                # declared neutral value and invalidates the companion validity flag.
                age = max(0., self.wall() - row['observed_at']) if row['observed_at'] is not None else 0.
                result = link.update(name, row['value'], source=row['source'], valid=row['valid'],
                                     sampled_at=self.clock() - age, owner='provider')
                results.append(dict(signal=key, parameter=name, result=result))
            except ValueError as exc:
                results.append(dict(signal=key, parameter=name, status='blocked', reason=str(exc)))
        self.trace.extend(deepcopy(results))
        return results

    def reset_context(self):
        self.resolver.entries.clear()
        self.set_media_source('none')
        self.trace.clear()
        self.availability_observations.clear()
        self.manual_media_state = None
        if self.resource_warning is not None:
            self.resource_warning[1].reset()

    def close(self):
        self.reset_context()
        self._obs_closed = True
        self.stop_obs()
