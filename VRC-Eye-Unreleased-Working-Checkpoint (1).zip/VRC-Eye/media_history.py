"""Bounded account-scoped media bookmarks, retained observations and DJ set list.

Uses the existing CompanionStore database; no raw audio, credentials or automatic
URL enrichment. Source identifiers never establish a VRChat account owner.
"""
from contextlib import contextmanager
import hashlib
import json
import re
import time
import uuid
from urllib.parse import urlsplit

from avatar_library import scope_id
from game_log import redact
from media_model import text, number
from player_profile import safe_link

TABLE = 'media_items_v121'


def safe_url(value):
    if not isinstance(value, str) or len(value) > 8192 or redact(value) != value or not safe_link(value): return ''
    try:
        parts = urlsplit(value)
        if parts.scheme not in ('http','https') or parts.username or parts.password: return ''
    except ValueError: return ''
    return value


def tags(value):
    if not isinstance(value,(tuple,list)) or len(value)>20:raise ValueError('Choose up to 20 media tags.')
    result=[]
    for item in value:
        clean=text(item,40)
        if not clean or clean!=item:raise ValueError('Each media tag must contain 1–40 plain text characters.')
        if clean.casefold() not in [tag.casefold() for tag in result]:result.append(clean)
    return result


class MediaHistory:
    def __init__(self, store, *, clock=time.time, quota=3000): self.store, self.clock, self.quota = store, clock, quota

    @contextmanager
    def connect(self):
        with self.store.connect() as db:
            db.execute(f'CREATE TABLE IF NOT EXISTS {TABLE}(scope TEXT NOT NULL,id TEXT NOT NULL,kind TEXT NOT NULL,data TEXT NOT NULL,created REAL NOT NULL,rank INTEGER NOT NULL,PRIMARY KEY(scope,id))')
            db.execute('CREATE TABLE IF NOT EXISTS media_forgotten_v121(scope TEXT NOT NULL,source_key TEXT NOT NULL,PRIMARY KEY(scope,source_key))')
            yield db

    def save(self, scope, data, *, kind='bookmark', source_key=''):
        scope = scope_id(scope)
        if kind not in ('bookmark','history','cue'): raise ValueError('Unsupported media record.')
        if not isinstance(data, dict): raise ValueError('Invalid media record.')
        if not isinstance(source_key,str) or len(source_key)>8192: raise ValueError('Invalid media source key.')
        source_key = hashlib.sha256(source_key.encode()).hexdigest() if source_key else ''
        value = {k:text(data.get(k), 512) for k in ('title','artist','source','evidence','note')}
        value.update(url=safe_url(data.get('url')), position=number(data.get('position')), source_key=text(source_key,256))
        value.update(tags=tags(data.get('tags',[])),favorite=data.get('favorite') is True,
            origin=data.get('origin') if data.get('origin') in ('desktop','game-log','manual') else 'manual')
        if not value['title']: raise ValueError('Enter a media title or cue label.')
        identity = hashlib.sha256((kind+'|'+source_key).encode()).hexdigest() if source_key else uuid.uuid4().hex
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if source_key and db.execute('SELECT 1 FROM media_forgotten_v121 WHERE scope=? AND source_key=?',(scope,source_key)).fetchone(): return None
            old = db.execute(f'SELECT data FROM {TABLE} WHERE scope=? AND id=?',(scope,identity)).fetchone()
            if old: return identity
            count = db.execute(f'SELECT count(*) FROM {TABLE} WHERE scope=?',(scope,)).fetchone()[0]
            if count >= self.quota: raise ValueError('Media library limit reached. Review and delete old records.')
            rank = db.execute(f'SELECT coalesce(max(rank),0)+1 FROM {TABLE} WHERE scope=?',(scope,)).fetchone()[0]
            db.execute(f'INSERT INTO {TABLE} VALUES(?,?,?,?,?,?)',(scope,identity,kind,json.dumps(value,ensure_ascii=False),self.clock(),rank))
        return identity

    def rows(self, scope, *, kind=None, query='', limit=200):
        scope = scope_id(scope)
        if kind is not None and kind not in ('bookmark','history','cue'): raise ValueError('Unsupported media view.')
        query = text(query,512); limit = min(500,max(1,int(limit)))
        with self.connect() as db:
            rows = db.execute(f'SELECT id,kind,data,created,rank FROM {TABLE} WHERE scope=? '+('AND kind=? ' if kind else '')+
                'ORDER BY rank '+('ASC' if kind=='cue' else 'DESC'),(scope,kind) if kind else (scope,)).fetchall()
        result = []
        for identity, category, raw, created, rank in rows:
            try: value = json.loads(raw)
            except (ValueError, TypeError): continue
            if not isinstance(value,dict): continue
            try:row_tags=tags(value.get('tags',[]))
            except ValueError:row_tags=[]
            value = dict({k:text(value.get(k),512) for k in ('title','artist','source','evidence','note')},
                url=safe_url(value.get('url')), position=number(value.get('position')), source_key=text(value.get('source_key'),256),
                favorite=value.get('favorite') is True,tags=row_tags,
                origin=value.get('origin') if value.get('origin') in ('desktop','game-log','manual') else 'manual')
            if query.casefold() not in ' '.join([value['title'],value['artist'],value['note'],value['source'],value['origin'],*row_tags]).casefold(): continue
            result.append(dict(value,id=identity,kind=category,created=created,rank=rank))
            if len(result) >= limit: break
        return result

    def organize(self,scope,identity,*,favorite=False,labels=()):
        scope=scope_id(scope);labels=tags(labels)
        if type(favorite) is not bool:raise ValueError('Invalid favorite setting.')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute(f'SELECT data FROM {TABLE} WHERE scope=? AND id=?',(scope,identity)).fetchone()
            if not row:raise ValueError('Media record no longer exists in this workspace.')
            value=json.loads(row[0])
            if not isinstance(value,dict):raise ValueError('Invalid stored media record.')
            value.update(favorite=favorite,tags=labels)
            db.execute(f'UPDATE {TABLE} SET data=?,kind=CASE WHEN kind=\'history\' AND ? THEN \'bookmark\' ELSE kind END WHERE scope=? AND id=?',
                (json.dumps(value,ensure_ascii=False),favorite,scope,identity))

    def forget(self, scope, identity):
        scope = scope_id(scope)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute(f'SELECT data FROM {TABLE} WHERE scope=? AND id=?',(scope,identity)).fetchone()
            if row:
                source_key = json.loads(row[0]).get('source_key')
                if source_key:
                    count = db.execute('SELECT count(*) FROM media_forgotten_v121 WHERE scope=?',(scope,)).fetchone()[0]
                    if count >= self.quota * 10: raise ValueError('Forgotten-media key limit reached; disable automatic retention before recording more observations.')
                    db.execute('INSERT OR IGNORE INTO media_forgotten_v121 VALUES(?,?)',(scope,source_key))
                db.execute(f'DELETE FROM {TABLE} WHERE scope=? AND id=?',(scope,identity))

    def move_cue(self, scope, identity, direction):
        rows = self.rows(scope,kind='cue',limit=500)
        index = next((i for i,r in enumerate(rows) if r['id']==identity),None)
        if index is None or direction not in (-1,1): raise ValueError('Select a cue to move.')
        other = index+direction
        if not 0 <= other < len(rows): return
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for a,b in ((rows[index],rows[other]),(rows[other],rows[index])):
                db.execute(f'UPDATE {TABLE} SET rank=? WHERE scope=? AND id=?',(b['rank'],scope_id(scope),a['id']))

    def prune(self, scope, days):
        if days not in (0,7,30,90): raise ValueError('Choose session-only, 7, 30 or 90 days.')
        with self.connect() as db:
            # Starred observations become bookmarks so they survive retention.
            db.execute(f'DELETE FROM {TABLE} WHERE scope=? AND kind=?'+(' AND created<?' if days else ''),
                (scope_id(scope),'history',self.clock()-days*86400) if days else (scope_id(scope),'history'))

    def export(self, scope, destination):
        from avatar_creator_store import sanitize_export
        from photo_files import save_new
        rows = [{k:r[k] for k in ('kind','title','artist','evidence','position','created')} for r in self.rows(scope,limit=500)]
        for row in rows:
            for key in ('title','artist','evidence'):
                row[key] = re.sub(r'(?i)https?://[^\s<>]+','[URL omitted]',redact(row[key]))
        payload = json.dumps(dict(schema='vrc-eye-media-1',items=sanitize_export(rows)),ensure_ascii=False,indent=2).encode()
        save_new(destination,payload)
        return len(rows)
