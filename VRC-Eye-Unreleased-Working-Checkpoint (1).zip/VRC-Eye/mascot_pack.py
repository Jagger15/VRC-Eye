"""Data-only local mascot packs. Changed or missing images fall back to built-ins."""
import hashlib
from io import BytesIO
from pathlib import Path


def prepare(path,phrases,stop=None):
    from avatar_library_files import checked_stream,check_cancel
    from PIL import Image
    from native_library import plain
    if not isinstance(phrases,list) or not 1<=len(phrases)<=20:raise ValueError('Use one to twenty phrases.')
    phrases=[plain(x,200,empty=False) for x in phrases]
    with checked_stream(path,limit=256*1024) as (path,stream,before):
        raw=stream.read(256*1024+1)
        if len(raw)>256*1024 or len(raw)!=before.st_size:raise ValueError('Choose a stable PNG smaller than 256 KiB.')
    check_cancel(stop)
    with Image.open(BytesIO(raw)) as im:
        if im.format!='PNG' or not 1<=im.width<=1024 or not 1<=im.height<=1024:raise ValueError('Use a PNG up to 1024 × 1024.')
        im.load();im=im.convert('RGBA');im.thumbnail((160,120));out=BytesIO();im.save(out,'PNG')
    return dict(path=str(Path(path).resolve()),sha256=hashlib.sha256(raw).hexdigest(),phrases=phrases,png=out.getvalue())


def render_home(panel):
    owner=getattr(panel.page.shell,'session_tools',None)
    if not owner or owner.blocked:return False
    revision=owner.store.native.revision();key=(owner.epoch,revision)
    if getattr(panel,'pack_key',None)!=key:
        panel.pack_key=key;panel.pack_photo=None;panel.pack_data=None
        value=owner.record('mascot')
        if value:
            try:
                prepared=prepare(value['path'],value['phrases'])
                if prepared['sha256']!=value['sha256']:return False
                import base64
                panel.pack_photo=panel.page.tk.PhotoImage(master=panel.app.root,data=base64.b64encode(prepared['png']).decode())
                panel.pack_data=value
            except (ValueError,OSError,KeyError):return False
    if panel.pack_photo is None:return False
    panel.canvas.configure(background=panel.app.PANEL);panel.canvas.delete('all');panel.canvas.create_image(90,62,image=panel.pack_photo)
    panel.message.set(panel.pack_data['phrases'][0]);return True
