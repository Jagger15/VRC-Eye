# VRC Eye — Social invitations and My avatars (Development 7)

## Send one invitation or request

1. Open **Community → Social → Send invitations** and choose Send invite or
   Request invite. Opening this tab makes no API request.
2. Enter an exact recipient user ID, or use a selected user from Browse. Select
   **Inspect recipient**. The returned user ID must match; the server still
   controls friendship, access and delivery rules.
3. For Send invite, enter an exact world:instance reference or supported launch
   link and select **Inspect invitation destination**. Its entry is masked until
   you explicitly reveal it. Do not assume inspection grants access.
4. Choose your saved message slot (0–11) and **Load message slot**. Review the
   actual returned text. Different actions use different message collections.
5. Select **Review and send one action…**. Check the active account, recipient,
   message and, where applicable, exact private destination before confirming.

For a reply, first load **Invite requests** in Browse, select a returned
requestInvite notification, then use **Use selected invite request from Browse**
in Send invitations. Load a request-response slot and review. This sends a text
response to that request; sending an instance invitation is a separate action.

Recipient/request and message evidence expire after 120 seconds; a destination
also keeps the existing instance-inspection freshness rule. Delayed or changed
context requires refresh and another review. Immediately before a POST, the
message slot is fetched again and checked against its reviewed ID/text/version.
There remains a server-side race if another application edits the slot after that
check. Only one POST is attempted; a missing or mismatched acknowledgement is
Uncertain. Confirmation does not prove delivery, permission, arrival or acceptance.

This checkpoint does not edit message slots, attach photos, send bulk invitations,
join instances or answer ordinary invitations. Ordinary-invite response documents
disagree on the sent message collection, so that operation is deferred.

## Browse and edit your uploaded avatars

1. Open **You → Accounts → My avatars**, then **Load my avatars**. Previous/Next
   page controls request up to 100 rows; filters search only the fetched page.
2. Select a row and **Refresh selected details**. An exact returned author ID must
   match the authenticated account. Purchases, licenses and local files do not
   establish upload ownership for this editor.
3. Inspect returned visibility, metadata revision and platform/build observations.
   Unknown or absent values stay unknown. These are neither a full revision
   history nor a Unity compatibility test.
4. Edit supported returned fields and choose **Review avatar changes…**. Only
   changed fields are submitted, after a fresh ownership check and exact review.
5. Reload after completion. The acknowledgement must match avatar, author and all
   changed field values; otherwise the receipt is Uncertain.

The local editor allows names up to 100 characters and descriptions up to 5,000.
Changed names/descriptions cannot be blank. Only public/private visibility can be
written. Author tags are entered one per line without `author_tag_`; returned
classification/system tags are preserved. Local bounds are 50 total tags and
100 characters per stored tag. These are editor bounds, not a claim that VRChat
will accept every value. Unsupported/missing fields remain disabled.

The detail snapshot must remain less than 120 seconds old through the request
budget wait. This is not a server-side compare-and-swap; concurrent edits elsewhere
may occur. No files, thumbnails or platform builds are uploaded, no avatar is
deleted, and the currently worn avatar is not changed.

**Save observation to Avatar Library…** stores the inspected metadata and build
observations under the acting account after review. It omits image/asset URLs and
unsent draft edits. This is a local metadata record, not an avatar-file backup.

## Privacy and recovery

Account replacement, disconnect or the page's Privacy view clears its loaded
records and drafts. No startup requests or saved drafts are added. Explicitly
saved local observations remain in their original account workspace.

The shared Action history shows Queued, Dispatching, Confirmed, Rejected, Not sent
or Uncertain. Receipt targets contain recipient/avatar/notification IDs and a
non-reversible destination fingerprint where needed; private capabilities and
message/field bodies are omitted. An unacknowledged matching uncertain action
blocks another attempt. Acknowledge only after independently checking the outcome.
Receipt saving can be retried locally without repeating a remote write.

See [SOCIAL_ACCOUNTS_1_20.md](SOCIAL_ACCOUNTS_1_20.md) for the existing account,
receipt and recovery system. One authenticated session remains active at a time.

## Contract references and verification

Community-maintained API references inspected during implementation:

- https://vrchat.community/reference/invite-user
- https://vrchat.community/reference/request-invite
- https://vrchat.community/reference/respond-invite
- https://vrchat.community/reference/get-invite-message
- https://vrchat.community/reference/search-avatars
- https://vrchat.community/reference/get-avatar
- https://vrchat.community/reference/update-avatar

Send invite uses the complete world:instance as `instanceId`, binding the reviewed
world and instance together. The generated community example is ambiguous about
that field. The choice is corroborated by the canonical VRCX implementation:
https://github.com/vrcx-team/VRCX/blob/6de8d7467ead2ad80af4d0f229ae0dcdefeffb4a/src/components/dialogs/UserDialog/UserDialog.vue
The community request schema requires instanceId and allows messageSlot:
https://github.com/vrchatapi/specification/blob/master/openapi/components/requests/InviteRequest.yaml
No extra undocumented payload fields are sent. This remains an adapter awaiting
live acceptance testing, not a guarantee of server behavior.

These are not a VRChat support/approval claim. Live acceptance was not tested.
See BUILD_VALIDATION.json for controlled-fixture and native Linux test results.
