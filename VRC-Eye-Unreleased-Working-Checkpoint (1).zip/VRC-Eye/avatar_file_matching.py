"""Bounded file health and explainable matching against recorded byte evidence."""
from collections import defaultdict

from avatar_folder_discovery import scan_folder, inspect_candidate, validate_source
from avatar_library import MAX_ROWS, scope_id
from avatar_library_files import check_cancel, checked_stream, inspect_file, FILE_LIMIT, InspectionCancelled

HASH_LIMIT = 128
BYTE_BUDGET = 4 * 1024**3


def snapshot(library, account):
    return library.records(scope_id(account), 'file', limit=MAX_ROWS)


def inspect_matches(source, records, *, stop=None, progress=None):
    """Hash only the selected folder, preserving ambiguous historical associations."""
    scan = scan_folder(source, stop=stop, progress=progress)
    known = defaultdict(list)
    for row in records:
        known[(row['sha256'], row['size'])].append(dict(row))
    results = []; used = 0; skipped = 0
    for candidate in scan['candidates']:
        check_cancel(stop)
        if len(results) >= HASH_LIMIT or used + candidate['size'] > BYTE_BUDGET:
            skipped += 1
            continue
        used += candidate['size']
        if progress: progress(f"Hashing {len(results)+1} / {min(HASH_LIMIT,len(scan['candidates']))}: {candidate['name']}")
        item = dict(id=candidate['id'], name=candidate['name'], candidate=candidate,
                    evidence=None, matches=[], duplicate_paths=[], error='')
        try:
            found = inspect_candidate(source, candidate, stop=stop)
            item.update(evidence=found, matches=known.get((found['sha256'], found['size']), []))
        except InspectionCancelled: raise
        except (ValueError, OSError): item['error'] = 'Unavailable or changed since scan; scan again.'
        results.append(item)
    duplicates = defaultdict(list)
    for item in results:
        if item['evidence']:
            found = item['evidence']; duplicates[(found['sha256'], found['size'])].append(found['path'])
    for item in results:
        found = item['evidence']
        if found:
            item['duplicate_paths'] = [p for p in duplicates[(found['sha256'], found['size'])] if p != found['path']]
    validate_source(source)
    return dict(items=results, bytes_read=used, skipped=skipped, scan=scan,
                partial=bool(skipped or scan['truncated'] or scan['depth_skipped']))


def inspect_health(records, *, stop=None, progress=None):
    rows = []; used = 0; skipped = 0
    for record in records:
        check_cancel(stop)
        if len(rows) >= HASH_LIMIT or used >= BYTE_BUDGET:
            skipped += 1; continue
        if progress: progress(f"Checking file {len(rows)+1} / {min(HASH_LIMIT,len(records))}")
        result = dict(expected_sha256=record['sha256'], observed_sha256='')
        allocation = 0
        try:
            with checked_stream(record['path'], limit=FILE_LIMIT) as (_, stream, info):
                if info.st_size > BYTE_BUDGET-used:
                    skipped += 1
                    continue
                allocation = info.st_size
                found = inspect_file(record['path'], stop=stop, limit=allocation)
            result.update(observed_sha256=found['sha256'], availability=(
                'Matches recorded bytes' if (found['sha256'],found['size'])==(record['sha256'],record['size']) else 'Changed'))
        except InspectionCancelled: raise
        except FileNotFoundError: result['availability'] = 'Unavailable'
        except (OSError, ValueError): result['availability'] = 'Unreadable'
        used += allocation
        rows.append(dict(id=record['id'], record=record, result=result))
    return dict(items=rows, skipped=skipped, partial=bool(skipped), bytes_budgeted=used)


def register_match(library, account, source, item, selected_record, *, check=lambda: None):
    """A reviewed match copies the reference's identity, never moves/deletes bytes."""
    account = scope_id(account); check(); validate_source(source)
    evidence = item.get('evidence')
    if not evidence or selected_record not in item['matches']:
        raise ValueError('Choose one of the inspected exact-byte matches.')
    if (selected_record['sha256'], selected_record['size']) != (evidence['sha256'], evidence['size']):
        raise ValueError('The byte evidence does not match this reference.')
    if selected_record['path'] == evidence['path']:
        raise ValueError('This file is already registered to that association. Use Check recorded files.')
    # Pin the reviewed candidate and folder while the database transaction runs.
    candidate = item['candidate']
    from avatar_folder_discovery import _candidate_path
    path = _candidate_path(source, candidate)
    if str(path) != evidence['path'] or candidate['fingerprint'] != evidence['fingerprint']:
        raise ValueError('The selected candidate changed; scan again.')
    def still_current():
        check(); validate_source(source)
        with checked_stream(path, expected=evidence['fingerprint']):
            if library.record(account, 'file', selected_record['id']) != selected_record:
                raise ValueError('The matching catalog reference changed. Scan again.')
    with checked_stream(path, expected=evidence['fingerprint']):
        still_current()
        return library.register_file(account, selected_record['avatar_id'], evidence,
            build_id=selected_record.get('build_id', ''), role=selected_record['role'],
            provenance='Reviewed exact SHA-256 and size match to existing catalog reference',
            before_commit=still_current)


def describe(item):
    if item.get('error'): return item['error']
    matches = item['matches']; duplicates = item['duplicate_paths']
    identities = {(r['avatar_id'], r.get('build_id', ''), r['role']) for r in matches}
    match_text = (f'{len(identities)} possible catalog associations; choose one' if len(identities)>1 else
                  'Exact recorded SHA-256 and size match' if matches else 'No recorded byte match')
    return match_text + (f" · {len(duplicates)} duplicate file(s) in scanned set" if duplicates else '')
