"""External bridge supervisor. Optional, quarantined, per-capability, session bound."""
from collections import deque
from concurrent.futures import Future
from copy import deepcopy
import json
import threading
import time

import bridge_protocol as protocol
from bridge_protocol import BridgeError, CAPABILITIES
import bridge_transport


class BridgeState:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.session=None;self.client={};self.context={};self.capabilities={};self.advertised={}
        self.grants={};self.samples={};self.pending={};self.queue=deque();self.completed=deque(maxlen=256);self.ledger=deque(maxlen=200)
        self.last_heartbeat=0.;self.sequence=0;self.permission_revision=0;self.permission_ack=-1
        self.controls_enabled=False;self.requests_paused=False;self.expected_user="";self.demo=False
        self.lab_context=None;self.lab_events=deque();self.lab_event_sequence=0;self.lab_event_bytes=0;self.lab_events_dropped=0
        self.message="Disabled. Standard VRC Eye features remain available.";self.revision=0;self.next_request=0.

    def _audit(self,capability,outcome,request_id=""):
        self.ledger.append(dict(time=time.strftime("%H:%M:%S"),capability=capability,outcome=outcome,request_id=request_id));self.revision+=1
    def _fail_requests(self,message):
        for key,item in tuple(self.pending.items()):
            if not item["future"].done():item["future"].set_exception(BridgeError(message))
            self.completed.append(key);self._audit(item["capability"],message,key)
        self.pending.clear();self.queue.clear()
    def connect(self,hello,session):
        accepted=protocol.hello(hello);protocol.ref(session)
        with self.lock:
            self.disconnect("Previous bridge session ended.")
            self.session=session;self.client=deepcopy(hello["client"]);self.context=deepcopy(hello["context"])
            self.advertised=deepcopy(hello["capabilities"]);self.capabilities=deepcopy(accepted);self.last_heartbeat=self.clock();self.sequence=0
            self.permission_revision=0;self.permission_ack=-1;self.controls_enabled=False
            self.message="Connected in quarantine. Approve individual capabilities for this connection.";self.revision+=1
    def disconnect(self,message="Bridge disconnected. Standard monitoring remains available."):
        with self.lock:
            self._fail_requests("Unconfirmed: bridge disconnected; no automatic retry.")
            self.session=None;self.client={};self.context={};self.capabilities={};self.advertised={};self.grants.clear();self.samples.clear()
            self.lab_context=None;self.lab_events.clear();self.lab_event_bytes=0;self.lab_event_sequence+=1
            self.controls_enabled=False;self.permission_ack=-1;self.message=message;self.revision+=1
    def _prune(self):
        now=self.clock()
        if self.session and not 0<=now-self.last_heartbeat<protocol.LEASE_SECONDS:
            self.disconnect("Bridge heartbeat expired. Advanced capabilities disabled.");return
        expired=[k for k,expiry in self.grants.items() if expiry is not None and now>=expiry]
        if expired:
            for key in expired:self.grants.pop(key,None);self.samples.pop(key,None)
            self._changed_permissions("Unconfirmed: capability consent expired; no automatic retry.")
        for key,sample in tuple(self.samples.items()):
            if now>=sample["expires"]:self.samples.pop(key,None);self.revision+=1
        for key,item in tuple(self.pending.items()):
            if item["future"].cancelled() or now>=item["deadline"]:
                self.pending.pop(key);self.completed.append(key)
                if not item["future"].done():item["future"].set_exception(BridgeError("Unconfirmed: bridge request expired; no automatic retry."))
                self._audit(item["capability"],"Unconfirmed: canceled or timed out; no automatic retry.",key)
    def _changed_permissions(self,reason="Unconfirmed: bridge permissions changed; no automatic retry."):
        self.permission_revision+=1;self.permission_ack=-1;self.revision+=1;self._fail_requests(reason)
    def _game_ready(self):
        return bool(not self.demo and self.client.get("kind")=="vrchat" and self.context.get("attached") and
                    (not self.expected_user or self.expected_user==self.context.get("local_user_id")))
    def _allowed(self,name):
        spec=CAPABILITIES.get(name)
        return bool(self.session and spec and name in self.capabilities and name in self.grants and self.permission_ack==self.permission_revision and
                    (not spec.game or self._game_ready()) and (spec.kind!="action" or not self.requests_paused and (not spec.game or self.controls_enabled)))
    def available(self,name):
        with self.lock:self._prune();return self._allowed(name)
    def _check_session(self,session):
        self._prune()
        if not session or session!=self.session:raise BridgeError("The bridge connection changed or expired. Review the current client again.")
    def grant(self,names,expected_session,seconds=None):
        if seconds is not None:protocol.integer(seconds,1,3600)
        if not isinstance(names,(list,tuple)) or not names:raise BridgeError("Select capabilities to approve.")
        with self.lock:
            self._check_session(expected_session)
            for name in names:
                if name not in self.capabilities:raise BridgeError("Unsupported capability cannot be approved.")
                if CAPABILITIES[name].game and not self._game_ready():raise BridgeError("Game capabilities require an attached VRChat client and matching signed-in account when present.")
            for name in names:self.grants[name]=None if seconds is None else self.clock()+seconds
            self._changed_permissions();self._audit("permissions","Approved selected capabilities for this connection.")
    def revoke(self,names=None):
        with self.lock:
            targets=list(self.grants) if names is None else names
            for name in targets:self.grants.pop(name,None);self.samples.pop(name,None)
            self._changed_permissions();self._audit("permissions","Selected permissions revoked.")
    def controls(self,enabled,expected_session):
        protocol.boolean(enabled)
        with self.lock:
            self._check_session(expected_session)
            if enabled and not self._game_ready():raise BridgeError("Local controls require an attached VRChat client with matching account context.")
            self.controls_enabled=enabled;self._changed_permissions();self._audit("controls","Local controls enabled." if enabled else "Local controls locked.")
    def pause_requests(self,paused=True):
        protocol.boolean(paused)
        with self.lock:
            self.requests_paused=paused;self._changed_permissions();self._audit("controls","Bridge requests paused." if paused else "Bridge requests resumed.")
    def environment(self,user_id="",demo=False):
        if user_id:protocol.ref(user_id,"usr")
        protocol.boolean(demo)
        with self.lock:
            if (user_id,demo)==(self.expected_user,self.demo):return
            self.expected_user,self.demo=user_id,demo;self.grants.clear();self.samples.clear();self.controls_enabled=False
            self._changed_permissions("Unconfirmed: VRC Eye account/mode changed; no automatic retry.")
            if self.session or demo:self.disconnect("Bridge disabled in Demo." if demo else "VRC Eye account changed. Reconnect the adapter and review its permissions.")
    def permission_message(self):
        with self.lock:
            self._prune();now=self.clock()
            return dict(revision=self.permission_revision,controls_enabled=self.controls_enabled,requests_paused=self.requests_paused,
                        grants={name:None if expiry is None else max(0,int((expiry-now)*1000)) for name,expiry in self.grants.items()})
    def request(self,name,params,*,expected_session):
        with self.lock:
            self._check_session(expected_session)
            if name not in CAPABILITIES or CAPABILITIES[name].kind!="action" or not self._allowed(name):raise BridgeError("This bridge action is unavailable, unapproved or locked.")
            params=deepcopy(protocol.parameters(name,params,self.capabilities[name]))
            if name.startswith("lab."):self._check_lab_action(name,params)
            if len(self.pending)>=8 or self.clock()<self.next_request:raise BridgeError("Bridge request limit reached. Wait before issuing another action.")
            self.next_request=self.clock()+.2
            key=protocol.fresh_id();future=Future();future.bridge_request_id=key;future.bridge_dispatched_at=None
            self.pending[key]=dict(id=key,session=self.session,capability=name,params=params,permission_revision=self.permission_revision,
                                   deadline=self.clock()+2.,future=future,sent=False)
            self.queue.append(key);self._audit(name,"Queued local request.",key)
            return future
    def next_command(self):
        with self.lock:
            self._prune()
            while self.queue:
                key=self.queue.popleft();item=self.pending.get(key)
                if item is None:continue
                if not self._allowed(item["capability"]) or item["permission_revision"]!=self.permission_revision:
                    self._fail_requests("Unconfirmed: action gate changed; no automatic retry.");return None
                if item["capability"].startswith("lab."):
                    try:self._check_lab_action(item["capability"],item["params"])
                    except BridgeError:
                        if not item["future"].done():item["future"].set_exception(BridgeError("Lab context changed before dispatch; not sent."))
                        self.pending.pop(key,None);self.completed.append(key);continue
                return dict(id=key,capability=item["capability"],params=deepcopy(item["params"]),permission_revision=self.permission_revision,
                            runtime_session=self.context.get("runtime_session"),ttl_ms=max(1,int((item["deadline"]-self.clock())*1000)))
            return None
    def authorize_send(self,session,command):
        with self.lock:
            self._check_session(session);item=self.pending.get(command["id"])
            if not item or item["future"].done() or not self._allowed(item["capability"]) or command["permission_revision"]!=self.permission_revision:raise BridgeError("Queued bridge action is no longer allowed.")
            if item["capability"].startswith("lab."):self._check_lab_action(item["capability"],item["params"])
            item["sent"]=True;item["future"].bridge_dispatched_at=self.clock();self._audit(item["capability"],"Sent to client; confirmation pending.",item["id"])
    def ingest(self,message):
        protocol.exact(message,("session","seq","kind","data"));protocol.integer(message["seq"],1,2**53-1)
        with self.lock:
            self._check_session(message["session"])
            if message["seq"]!=self.sequence+1:raise BridgeError("Out-of-order or replayed bridge message.")
            self.sequence=message["seq"];kind=message["kind"];data=message["data"]
            if kind=="heartbeat":
                protocol.exact(data,("context",))
                if protocol.context(data["context"])!=self.context:raise BridgeError("Runtime identity changed; a new bridge session and consent are required.")
                self.last_heartbeat=self.clock()
            elif kind=="permissions_ack":
                protocol.exact(data,("revision",));protocol.integer(data["revision"])
                if data["revision"]>self.permission_revision:raise BridgeError("Unknown permission revision.")
                if data["revision"]==self.permission_revision:self.permission_ack=data["revision"];self.revision+=1
            elif kind=="telemetry":
                protocol.exact(data,("capability","permission_revision","sample_age_ms","value"));name=data["capability"]
                if not isinstance(name,str) or name not in self.capabilities or CAPABILITIES[name].kind!="telemetry":raise BridgeError("Unsupported telemetry capability.")
                protocol.integer(data["permission_revision"]);protocol.integer(data["sample_age_ms"],0,60000)
                if data["permission_revision"]!=self.permission_revision or not self._allowed(name):return
                value=deepcopy(protocol.telemetry(name,data["value"]))
                lifetime=protocol.TELEMETRY_SECONDS-data["sample_age_ms"]/1000.
                if lifetime<=0:self.samples.pop(name,None);return
                if name.startswith("lab.") and not self._ingest_lab(name,value):return
                self.samples[name]=dict(value=value,received=self.clock(),observed=self.clock()-data["sample_age_ms"]/1000,expires=self.clock()+lifetime,source="Client reported",session=self.session)
                if name.startswith("lab."):self._record_lab(name,self.samples[name])
                self.revision+=1
            elif kind=="result":
                protocol.exact(data,("id","ok"),("value","error"));key=protocol.ref(data["id"]);protocol.boolean(data["ok"])
                item=self.pending.get(key)
                if item is None:
                    if key in self.completed:return
                    raise BridgeError("Unsolicited bridge result.")
                if not item["sent"]:raise BridgeError("Response arrived for an unsent request.")
                self.pending.pop(key);self.completed.append(key)
                if data["ok"]:
                    try:value=deepcopy(protocol.result(item["capability"],data.get("value"),item["params"]))
                    except BridgeError:
                        item["future"].set_exception(BridgeError("Client response did not confirm the requested action."));raise
                    item["future"].set_result(value);self._audit(item["capability"],"Acknowledged by provider; observation remains separate." if item["capability"].startswith("lab.") else "Confirmed by client.",key)
                else:
                    item["future"].set_exception(BridgeError("Client rejected or could not complete the local action."));self._audit(item["capability"],"Client reported failure; not retried.",key)
            else:raise BridgeError("Clients cannot invoke VRC Eye commands.")
    def _ingest_lab(self,name,value):
        """Only the attached local account; secondary telemetry cannot change context."""
        from bridge_lab_contract import same
        context=value["context"]
        if context["account_id"]!=self.context.get("local_user_id") or context["runtime_session"]!=self.context.get("runtime_session"):
            raise BridgeError("Lab telemetry does not belong to the attached local runtime/account.")
        if name=="lab.context":
            if self.lab_context is not None:
                if context["revision"]<self.lab_context["revision"]:return False
                if context["revision"]==self.lab_context["revision"] and not same(context,self.lab_context):
                    raise BridgeError("Lab context changed without a new revision.")
            if not same(context,self.lab_context):
                for key in list(self.samples):
                    if key.startswith("lab."):self.samples.pop(key,None)
                for key,item in list(self.pending.items()):
                    if item["capability"].startswith("lab."):
                        if not item["future"].done():item["future"].set_exception(BridgeError("Lab context changed; outcome unconfirmed if already sent."))
                        self.pending.pop(key,None);self.completed.append(key)
                self.lab_context=deepcopy(context)
            return True
        return bool(self._allowed("lab.context") and self.samples.get("lab.context") and
                    self.samples["lab.context"]["expires"]>self.clock() and same(context,self.lab_context))

    def _check_lab_action(self,name,params):
        from bridge_lab_contract import same
        current=self.samples.get("lab.context")
        if not self._allowed("lab.context") or not current or current["expires"]<=self.clock() or not same(params["context"],self.lab_context):
            raise BridgeError("Fresh approved lab context is required; account/avatar/world/configuration may have changed.")
        if name=="lab.restore" and not self._allowed(params["original_capability"]):
            raise BridgeError("Restoration cannot bypass the original capability permission.")
        from bridge_lab_contract import check_preconditions
        def read(capability):
            sample=self.samples.get(capability)
            if not self._allowed(capability) or not sample or sample["expires"]<=self.clock():
                raise BridgeError("Fresh approved precondition telemetry is unavailable.")
            value=deepcopy(sample["value"])
            if capability=="lab.creator":
                elapsed=max(0,(self.clock()-sample["observed"])*1000)
                value["manifest"]["authority_expires_ms"]=max(0,value["manifest"]["authority_expires_ms"]-elapsed)
            return value
        check_preconditions(name,params,read)

    def _record_lab(self,name,sample):
        self.lab_event_sequence+=1
        row=dict(sequence=self.lab_event_sequence,capability=name,sample=deepcopy(sample))
        size=len(protocol.canonical(row))
        if size>1024*1024:
            self.lab_events_dropped+=1;return
        while self.lab_events and (len(self.lab_events)>=256 or self.lab_event_bytes+size>1024*1024):
            _,previous=self.lab_events.popleft();self.lab_event_bytes-=previous;self.lab_events_dropped+=1
        self.lab_events.append((row,size));self.lab_event_bytes+=size

    def lab_events_since(self,sequence):
        with self.lock:
            self._prune()
            rows=[row for row,_ in self.lab_events if row["sequence"]>sequence]
            # Permission revocation also stops disclosure of retained observations.
            rows=[row for row in rows if self._allowed(row["capability"]) and self._allowed("lab.context")]
            return dict(sequence=self.lab_event_sequence,events=deepcopy(rows),dropped=self.lab_events_dropped,
                        bytes=self.lab_event_bytes,maximum_bytes=1024*1024)

    def get_sample(self,name):
        with self.lock:
            self._prune()
            return deepcopy(self.samples.get(name)) if self._allowed(name) else None
    def snapshot(self):
        with self.lock:
            self._prune();now=self.clock()
            return dict(session=self.session,client=deepcopy(self.client),context=deepcopy(self.context),advertised=deepcopy(self.advertised),
                        capabilities=deepcopy(self.capabilities),grants={k:None if v is None else max(0,v-now) for k,v in self.grants.items()},
                        available=[k for k in self.capabilities if self._allowed(k)],game_ready=self._game_ready() if self.session else False,
                        controls_enabled=self.controls_enabled,requests_paused=self.requests_paused,message=self.message,revision=self.revision,
                        ledger=deepcopy(list(self.ledger)),samples=[k for k in self.samples if self._allowed(k)])


class ClientBridge:
    def __init__(self,*,clock=time.monotonic,listener_factory=bridge_transport.listener):
        self.state=BridgeState(clock);self.factory=listener_factory;self.lock=threading.RLock()
        self.listener=None;self.stream=None;self.bound_stream=None;self.stop_event=threading.Event();self.thread=None;self.watchdog=None;self.secret="";self._run_id=0
    def start(self):
        with self.lock:
            if self.state.demo:raise BridgeError("Bridge is disabled in Demo.")
            if self.listener is not None:raise BridgeError("Bridge is already listening.")
            self.listener=self.factory();self.secret=protocol.fresh_secret();self.stop_event=threading.Event();self._run_id+=1
            run_id=self._run_id;stop=self.stop_event;listener=self.listener
            self.state.message="Waiting for a compatible local client. No advanced capabilities are enabled."
            self.thread=threading.Thread(target=self._run,args=(run_id,stop,listener,self.secret),daemon=True,name="VRC-Eye-Bridge")
            self.watchdog=threading.Thread(target=self._watch,args=(run_id,stop),daemon=True,name="VRC-Eye-Bridge-Watchdog")
            self.thread.start();self.watchdog.start()
    def pairing_code(self):
        with self.lock:
            if self.listener is None:raise BridgeError("Enable the bridge first.")
            return json.dumps(dict(bridge=1,transport=self.listener.transport,endpoint=self.listener.endpoint,secret=self.secret),separators=(",",":"))
    def environment(self,user_id="",demo=False):
        self.state.environment(user_id,demo)
        if demo:self.stop("Bridge disabled in Demo.")
    def stop(self,message="Bridge disabled. Standard VRC Eye features remain available."):
        with self.lock:
            self.stop_event.set();self._run_id+=1;stream,self.stream=self.stream,None;self.bound_stream=None;listener,self.listener=self.listener,None;self.secret=""
            self.state.disconnect(message)
        if stream:
            try:stream.close()
            except OSError:pass
        if listener:
            try:listener.close()
            except OSError:pass
    def disconnect_client(self):
        with self.lock:
            stream,self.stream=self.stream,None;self.bound_stream=None;self.state.disconnect("Client disconnected. Reconnection requires fresh capability approvals.")
        if stream:stream.close()
    def _watch(self,run_id,stop):
        while not stop.wait(.1):
            with self.lock:
                if run_id!=self._run_id:return
                self.state.snapshot()
                if self.bound_stream is not None and self.state.session is None:
                    stream,self.stream=self.stream,None;self.bound_stream=None
                    if stream:stream.close()
    def _run(self,run_id,stop,listener,secret):
        errors=deque(maxlen=3)
        while not stop.is_set():
            stream=None
            try:
                stream=listener.accept()
                if stream is None:continue
                with self.lock:
                    if run_id!=self._run_id:stream.close();return
                    self.stream=stream
                self._session(stream,secret,stop,run_id)
            except EOFError:pass
            except (BridgeError,OSError,ValueError,TypeError,KeyError):
                if stop.is_set():break
                errors.append(time.monotonic())
                if len(errors)==3 and errors[-1]-errors[0]<60:
                    self.stop("Bridge isolated after repeated connection/protocol failures. Enable it again to review a new pairing.");return
                self.state.disconnect("Bridge rejected or disconnected an invalid session. No advanced capabilities are enabled.")
            except Exception:
                if run_id==self._run_id and not stop.is_set():self.stop("Bridge integration stopped after an internal error. Standard VRC Eye remains available.")
                return
            finally:
                if stream:
                    try:stream.close()
                    except OSError:pass
                    with self.lock:
                        if run_id==self._run_id:
                            if self.stream is stream:self.stream=None
                            if self.bound_stream is stream:self.bound_stream=None
                            if self.state.session:self.state.disconnect()
    def _session(self,stream,secret,stop,run_id):
        nonce=protocol.fresh_secret();session=protocol.fresh_id();deadline=time.monotonic()+protocol.HANDSHAKE_SECONDS
        stream.send(dict(type="challenge",protocol=protocol.PROTOCOL,nonce=nonce))
        hello=None
        while not stop.is_set() and time.monotonic()<deadline:
            hello=stream.receive(.2)
            if hello is not None:break
        if hello is None:raise BridgeError("Bridge handshake timed out.")
        protocol.exact(hello,("type","hello","proof"))
        if hello["type"]!="hello":raise BridgeError("Expected bridge hello.")
        protocol.verify(secret,"hello",nonce,hello["hello"],hello["proof"]);accepted=protocol.hello(hello["hello"])
        welcome=dict(protocol=dict(major=1,minor=min(protocol.PROTOCOL["minor"],hello["hello"]["protocol"]["minor"])),session=session,
                     accepted=accepted,heartbeat_ms=int(protocol.HEARTBEAT_SECONDS*1000),lease_ms=int(protocol.LEASE_SECONDS*1000),app_version=protocol.APP_VERSION)
        with self.lock:
            if run_id!=self._run_id or stop.is_set() or self.stream is not stream:return
            self.state.connect(hello["hello"],session);self.bound_stream=stream
        stream.send(dict(type="welcome",welcome=welcome,proof=protocol.proof(secret,"welcome",nonce,welcome)))
        sent_revision=-1;sequence=0;heartbeat_at=0.;window=time.monotonic();messages=0
        def send(kind,data):
            nonlocal sequence
            if self.state.snapshot()["session"]!=session:raise EOFError("Bridge session ended.")
            sequence+=1;stream.send(dict(session=session,seq=sequence,kind=kind,data=data))
        while not stop.is_set() and self.state.snapshot()["session"]==session:
            now=time.monotonic()
            permissions=self.state.permission_message()
            if permissions["revision"]!=sent_revision:
                send("permissions",permissions);sent_revision=permissions["revision"]
            if now>=heartbeat_at:send("heartbeat",{});heartbeat_at=now+protocol.HEARTBEAT_SECONDS
            command=self.state.next_command()
            if command:
                self.state.authorize_send(session,command);send("request",command)
            message=stream.receive(.1)
            if message is not None:
                if now-window>=1:window=now;messages=0
                messages+=1
                if messages>100:raise BridgeError("Bridge message rate exceeded.")
                self.state.ingest(message)
    def available(self,name):return self.state.available(name)
    def get_sample(self,name):return self.state.get_sample(name)
    def request(self,name,params,*,expected_session):return self.state.request(name,params,expected_session=expected_session)
