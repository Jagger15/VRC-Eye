"""Native VRChat camera requests and observation of newly saved local PNGs."""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import socket
import struct
import threading
import time

from rangefinder import parse_port

MAX_PHOTO_BYTES = 32 * 1024 * 1024
MAX_PHOTO_PIXELS = 16 * 1024 * 1024
MAX_ENTRIES = 20000
PNG_HEADER = b"\x89PNG\r\n\x1a\n"
PREPARE = (("Mode", 1), ("Environment", True), ("GreenScreen", False),
           ("LocalPlayer", False), ("RemotePlayer", False), ("ShowUIInCamera", False))


class CameraError(ValueError):
    pass


def osc_message(endpoint: str, value) -> bytes:
    # Deliberately limited to the documented camera actions used by this UI.
    allowed = {name for name, _ in PREPARE} | {"Capture"}
    if endpoint not in allowed or type(value) not in (int, bool):
        raise CameraError("Unsupported camera request.")
    def string(value):
        raw = value.encode("ascii") + b"\0"
        return raw + bytes((-len(raw)) % 4)
    if type(value) is bool:
        return string("/usercamera/" + endpoint) + string(",T" if value else ",F")
    return string("/usercamera/" + endpoint) + string(",i") + struct.pack(">i", value)


def prepare_camera(port):
    """Legacy standalone helper. Application views use the shared OSC controller."""
    destination = ("127.0.0.1", parse_port(port))
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
        for endpoint, value in PREPARE:
            connection.sendto(osc_message(endpoint, value), destination)


def request_photo(port, stop: threading.Event):
    """Legacy standalone pulse; the application uses the shared OSC scheduler.

    Sending UDP does not acknowledge a capture.
    """
    destination = ("127.0.0.1", parse_port(port))
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
        connection.sendto(osc_message("Capture", False), destination)
        if stop.wait(.08):
            return
        try:
            connection.sendto(osc_message("Capture", True), destination)
            stop.wait(.15)
        finally:
            connection.sendto(osc_message("Capture", False), destination)


def default_photo_folder(log_path: Path) -> Path:
    fallback = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Pictures" / "VRChat"
    from vrchat_config import read_config
    from vrchat_paths import resolve_config_path
    try:
        field = read_config(log_path)['fields'].get('picture_output_folder', {})
        if field.get('state') == 'Declared': return Path(resolve_config_path(field['value']))
    except (OSError, ValueError, RecursionError):
        pass
    return fallback


@dataclass(frozen=True)
class PhotoFile:
    path: Path
    size: int
    modified_ns: int
    device: int
    inode: int

    @classmethod
    def inspect(cls, path: Path, stat=None):
        stat = path.stat() if stat is None else stat
        return cls(path, stat.st_size, stat.st_mtime_ns, stat.st_dev, stat.st_ino)


def scan_photos(folder: Path) -> dict[Path, PhotoFile]:
    """Read the selected folder and one level of date folders; never recurse links."""
    if not folder.exists():
        return {}  # VRChat may create the directory when taking the first photo.
    result = {}
    directories = [folder]
    count = 0
    for directory in directories:
        with os.scandir(directory) as entries:
            for entry in entries:
                count += 1
                if count > MAX_ENTRIES:
                    raise CameraError("Too many files to watch. Choose the current YYYY-MM photo folder instead.")
                if directory == folder and entry.is_dir(follow_symlinks=False):
                    directories.append(Path(entry.path))
                elif entry.name.lower().endswith(".png") and entry.is_file(follow_symlinks=False):
                    try:
                        path = Path(entry.path)
                        result[path] = PhotoFile.inspect(path, entry.stat(follow_symlinks=False))
                    except FileNotFoundError:
                        continue
    return result


def stable_new_photos(baseline: dict, previous: dict, current: dict) -> tuple[PhotoFile, ...]:
    return tuple(sorted((record for path, record in current.items()
                         if path not in baseline and record.size > 0 and previous.get(path) == record),
                        key=lambda record: (record.modified_ns, str(record.path)), reverse=True))


def watch_capture(folder: Path, port, trigger: bool, output, stop: threading.Event,
                  timeout: float = 45., interval: float = .5, *, shared_trigger=False):
    """Capture once or watch a manual shutter press; keep all old photos untouched."""
    try:
        baseline = scan_photos(folder)
        if stop.is_set():
            return
        if trigger:
            if shared_trigger:
                ready = threading.Event()
                output.put(("capture_ready", ready))
                # The UI thread submits the reviewed shared-service action only
                # after this baseline exists. This worker never calls OSC.
                deadline = time.monotonic() + timeout
                while not ready.wait(min(interval, .1)):
                    if stop.is_set():
                        return
                    if time.monotonic() >= deadline:
                        raise CameraError("The capture was not transmitted. Check OSC Controls before trying again.")
            else:
                request_photo(port, stop)
        if stop.is_set():
            return
        output.put(("status", "Capture request sent; waiting for a new PNG. A new file alone does not prove this request caused it." if trigger else
                              "Ready — take the photo in VRChat now. Waiting for a new PNG…"))
        previous = baseline
        deadline = time.monotonic() + timeout
        while not stop.wait(interval):
            current = scan_photos(folder)
            ready = stable_new_photos(baseline, previous, current)
            if ready:
                output.put(("photos", ready))
                return
            previous = current
            if time.monotonic() >= deadline:
                output.put(("error", "No new PNG detected. Check the photo folder, OSC, and open camera. "
                             "You can watch a manual shot or choose an existing photo."))
                return
    except (OSError, ValueError) as error:
        if not stop.is_set():
            output.put(("error", str(error)))


def watch_shared_capture(folder: Path, trigger: bool, output, stop: threading.Event,
                         timeout: float = 45., interval: float = .5):
    """Observe a photo while the UI thread owns shared-service submission."""
    watch_capture(folder, None, trigger, output, stop, timeout, interval, shared_trigger=True)


def png_dimensions(data: bytes) -> tuple[int, int]:
    if len(data) < 24 or len(data) > MAX_PHOTO_BYTES or not data.startswith(PNG_HEADER) or data[12:16] != b"IHDR":
        raise CameraError("Choose a complete PNG photo no larger than 32 MiB.")
    width, height = struct.unpack(">II", data[16:24])
    if not 1 <= width <= 8192 or not 1 <= height <= 8192 or width * height > MAX_PHOTO_PIXELS:
        raise CameraError("Photo is too large. Choose 2160p / 4K or lower in VRChat and take another photo.")
    return width, height


def read_photo(path: Path, expected: PhotoFile | None = None) -> bytes:
    with path.open("rb") as stream:
        before = PhotoFile.inspect(path, os.fstat(stream.fileno()))
        if expected is not None and before != expected:
            raise CameraError("The photo changed. Choose it again after it finishes saving.")
        data = stream.read(MAX_PHOTO_BYTES + 1)
        after = PhotoFile.inspect(path, os.fstat(stream.fileno()))
    if before != after or after != PhotoFile.inspect(path):
        raise CameraError("The photo changed while reading. Try again after it finishes saving.")
    png_dimensions(data)
    return data


def reduction_factor(width: int, height: int) -> int:
    return max(1, math.ceil(max(width, height) / 2048))


def save_png(path: Path, data: bytes):
    """Exclusive creation: even a stale file-picker result cannot overwrite a photo."""
    png_dimensions(data)
    created = False
    try:
        with path.open("xb") as stream:
            created = True
            stream.write(data)
    except OSError:
        if created:
            path.unlink(missing_ok=True)
        raise
