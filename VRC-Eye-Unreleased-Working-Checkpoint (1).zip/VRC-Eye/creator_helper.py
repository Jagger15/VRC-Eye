"""Optional creator-declared helper capabilities; imported data never grants authority.

No device, network, project, or filesystem is accessed at import time. A manifest
is a creator's declaration, not proof of the loaded world or publishing account.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
import re
import secrets
import time
import uuid


SCHEMA = 1
MAX_MANIFEST_BYTES = 256 * 1024
MAX_CONTROLS = 64
MAX_RECORDS = 256
MAX_REQUESTS = 256
REVIEW_SECONDS = 30.0
ACK_SECONDS = 10.0
LOG_PREFIX = '[VRCEyeCreator] '
_ID = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}$')
_WORLD = re.compile(r'^(?:wrld_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|local:[A-Za-z0-9][A-Za-z0-9_.-]{0,79})$')
_FORBIDDEN = re.compile(r'(?:[A-Za-z]:[\\/]|(?:^|\s)/(?:home|Users|workspace|tmp)/|(?:https?|file)://|(?:token|password|secret|authorization)\s*[:=])', re.I)
_ACTIVE = {'Requested', 'Sent'}


class HelperError(ValueError):
    """A malformed declaration, unavailable route, or stale review."""


def _obj(value, allowed, where):
    if not isinstance(value, dict) or any(not isinstance(k, str) for k in value):
        raise HelperError(where + ' must be an object.')
    unknown = set(value) - set(allowed)
    if unknown:
        raise HelperError(where + ' has unsupported fields: ' + ', '.join(sorted(unknown)))
    return value


def _text(value, where, limit=512, *, required=False, safe=False):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise HelperError(where + ' must be bounded plain text.')
    value = value.strip()
    if required and not value:
        raise HelperError(where + ' is required.')
    if safe and _FORBIDDEN.search(value):
        raise HelperError(where + ' must not contain URLs, private paths, or credentials.')
    return value


def _identifier(value, where):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise HelperError(where + ' must be a short identifier.')
    return value


def _integer(value, where, low, high):
    if type(value) is not int or not low <= value <= high:
        raise HelperError(f'{where} must be an integer from {low} to {high}.')
    return value


def _boolean(value, where):
    if type(value) is not bool:
        raise HelperError(where + ' must be true or false.')
    return value


def _array(value, where, limit=MAX_RECORDS):
    if not isinstance(value, list) or len(value) > limit:
        raise HelperError(where + ' must be a bounded list.')
    return value


def _strings(value, where, limit=32, *, identifiers=False):
    rows = _array(value, where, limit)
    out = [_identifier(v, where) if identifiers else _text(v, where, 512, required=True, safe=True) for v in rows]
    if len(set(out)) != len(out):
        raise HelperError(where + ' contains duplicates.')
    return out


def _json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise HelperError('Duplicate JSON field: ' + str(key))
        result[key] = value
    return result


def _reject_number(value):
    raise HelperError('Non-finite JSON number: ' + value)


def parse_manifest(text):
    if not isinstance(text, (str, bytes)):
        raise HelperError('Manifest must be JSON text.')
    try:
        if isinstance(text, bytes):
            text = text.decode('utf-8-sig')
        if len(text.encode('utf-8')) > MAX_MANIFEST_BYTES:
            raise HelperError('Manifest exceeds 256 KiB.')
        document = json.loads(text, object_pairs_hook=_json_object, parse_constant=_reject_number)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise HelperError('Manifest is not valid bounded JSON.') from exc
    return validate_manifest(document)


def load_manifest(path):
    """Explicit local-file import with a hard read limit."""
    with Path(path).open('rb') as source:
        data = source.read(MAX_MANIFEST_BYTES + 1)
    if len(data) > MAX_MANIFEST_BYTES:
        raise HelperError('Manifest exceeds 256 KiB.')
    return parse_manifest(data)


def validate_manifest(document):
    """Return a fresh, normalized schema-1 declaration; reject unknown fields."""
    _obj(document, ('schema', 'world_id', 'build_id', 'platform', 'project_revision',
                    'controls', 'telemetry', 'assertions', 'zones', 'dependencies',
                    'contracts', 'debug', 'notes'), 'Manifest')
    _integer(document.get('schema'), 'schema', SCHEMA, SCHEMA)
    world = document.get('world_id')
    if not isinstance(world, str) or not _WORLD.fullmatch(world):
        raise HelperError('world_id must be a wrld_ ID or local:project identifier.')
    result = dict(schema=SCHEMA, world_id=world,
                  build_id=_identifier(document.get('build_id'), 'build_id'),
                  platform=_identifier(document.get('platform'), 'platform'),
                  project_revision=_text(document.get('project_revision', ''), 'project_revision', 128, safe=True),
                  notes=_text(document.get('notes', ''), 'notes', 1024, safe=True))
    controls = []
    identifiers, routes = set(), set()
    for row in _array(document.get('controls', []), 'controls', MAX_CONTROLS):
        _obj(row, ('id', 'label', 'description', 'type', 'scope', 'options', 'min', 'max',
                   'midi', 'requirements', 'retry_safe', 'test_only', 'affected_systems',
                   'leaves_unchanged', 'state_available'), 'Control')
        control_id = _identifier(row.get('id'), 'control.id')
        if control_id in identifiers:
            raise HelperError('Duplicate control ID.')
        identifiers.add(control_id)
        kind = _identifier(row.get('type'), 'control.type')
        scope = row.get('scope')
        if scope not in ('local', 'helper', 'shared', 'persistent'):
            raise HelperError('Control scope must be explicit: local, helper, shared, or persistent.')
        c = dict(id=control_id, label=_text(row.get('label'), 'control.label', 120, required=True, safe=True),
                 description=_text(row.get('description', ''), 'control.description', 1024, safe=True),
                 type=kind, scope=scope,
                 requirements=_strings(row.get('requirements', []), 'requirements'),
                 retry_safe=_boolean(row.get('retry_safe', False), 'retry_safe'),
                 test_only=_boolean(row.get('test_only', True), 'test_only'),
                 state_available=_boolean(row.get('state_available', False), 'state_available'),
                 affected_systems=_strings(row.get('affected_systems', []), 'affected_systems'),
                 leaves_unchanged=_text(row.get('leaves_unchanged', ''), 'leaves_unchanged', 512, safe=True))
        if kind == 'selection':
            c['options'] = _strings(row.get('options', []), 'control.options', 128)
            if not c['options']:
                raise HelperError('Selection controls need at least one option.')
        elif 'options' in row:
            raise HelperError('Only selection controls may declare options.')
        if kind == 'integer':
            c['min'] = _integer(row.get('min'), 'control.min', 0, 127)
            c['max'] = _integer(row.get('max'), 'control.max', c['min'], 127)
        elif 'min' in row or 'max' in row:
            raise HelperError('Only integer controls may declare a range.')
        if 'midi' in row and row['midi'] is not None:
            route = _obj(row['midi'], ('channel', 'number'), 'midi')
            channel = _integer(route.get('channel'), 'midi.channel', 0, 15)
            number = _integer(route.get('number'), 'midi.number', 1, 127)
            if (channel, number) in routes:
                raise HelperError('Duplicate MIDI control route.')
            routes.add((channel, number))
            c['midi'] = dict(channel=channel, number=number)
        else:
            c['midi'] = None
        controls.append(c)
    result['controls'] = controls
    telemetry = []
    for row in _array(document.get('telemetry', []), 'telemetry'):
        _obj(row, ('id', 'label', 'unit', 'scope', 'description'), 'Telemetry')
        telemetry.append(dict(id=_identifier(row.get('id'), 'telemetry.id'),
                              label=_text(row.get('label', row.get('id')), 'telemetry.label', 120, safe=True),
                              unit=_text(row.get('unit', ''), 'telemetry.unit', 32, safe=True),
                              scope=_text(row.get('scope', 'local'), 'telemetry.scope', 96, required=True, safe=True),
                              description=_text(row.get('description', ''), 'telemetry.description', 512, safe=True)))
    result['telemetry'] = telemetry
    assertions = []
    for row in _array(document.get('assertions', []), 'assertions'):
        _obj(row, ('id', 'label', 'scope', 'timing', 'severity', 'grace_seconds', 'budget_ms'), 'Assertion')
        severity = row.get('severity', 'warning')
        if severity not in ('info', 'warning', 'error', 'blocking'):
            raise HelperError('Assertion severity is unsupported.')
        numbers = {}
        for key, maximum in (('grace_seconds', 300), ('budget_ms', 100)):
            value = row.get(key, 0)
            if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= maximum:
                raise HelperError('Invalid assertion ' + key)
            numbers[key] = value
        assertions.append(dict(id=_identifier(row.get('id'), 'assertion.id'),
                               label=_text(row.get('label', row.get('id')), 'assertion.label', 120, safe=True),
                               scope=_text(row.get('scope', 'local'), 'assertion.scope', 96, required=True, safe=True),
                               timing=_text(row.get('timing', 'manual'), 'assertion.timing', 120, required=True, safe=True),
                               severity=severity, **numbers))
    result['assertions'] = assertions
    result['zones'] = _strings(document.get('zones', []), 'zones', MAX_RECORDS)
    dependencies = []
    for row in _array(document.get('dependencies', []), 'dependencies'):
        _obj(row, ('id', 'version', 'owner', 'credit', 'provenance', 'documentation', 'source_available', 'tests'), 'Dependency')
        dep = dict(id=_identifier(row.get('id'), 'dependency.id'))
        for key in ('version', 'owner', 'credit', 'provenance', 'documentation'):
            dep[key] = _text(row.get(key, ''), 'dependency.' + key, 1024, safe=True)
        dep['source_available'] = _boolean(row.get('source_available', False), 'dependency.source_available')
        dep['tests'] = _strings(row.get('tests', []), 'dependency.tests', identifiers=True)
        dependencies.append(dep)
    result['dependencies'] = dependencies
    contracts = []
    for row in _array(document.get('contracts', []), 'contracts'):
        _obj(row, ('id', 'kind', 'signature', 'description', 'essential'), 'Contract')
        kind = row.get('kind')
        if kind not in ('network-object', 'persistence-schema', 'game-state', 'interaction', 'visual'):
            raise HelperError('Unsupported semantic contract kind.')
        contracts.append(dict(id=_identifier(row.get('id'), 'contract.id'), kind=kind,
                              signature=_text(row.get('signature'), 'contract.signature', 256, required=True, safe=True),
                              description=_text(row.get('description', ''), 'contract.description', 512, safe=True),
                              essential=_boolean(row.get('essential', True), 'contract.essential')))
    result['contracts'] = contracts
    debug = _obj(document.get('debug', {}), ('verbose_logging', 'test_ui', 'world_debugging', 'external_dependencies'), 'debug')
    result['debug'] = {}
    for key in ('verbose_logging', 'test_ui'):
        result['debug'][key] = _boolean(debug.get(key, False), 'debug.' + key)
    wd = debug.get('world_debugging', 'unknown')
    if wd not in ('unknown', 'enabled', 'disabled'):
        raise HelperError('world_debugging must be unknown, enabled, or disabled.')
    result['debug']['world_debugging'] = wd
    result['debug']['external_dependencies'] = _strings(debug.get('external_dependencies', []), 'external_dependencies')
    for key in ('telemetry', 'assertions', 'dependencies', 'contracts'):
        ids = [r['id'] for r in result[key]]
        if len(set(ids)) != len(ids):
            raise HelperError('Duplicate ' + key + ' identifier.')
    if len(json.dumps(result).encode('utf-8')) > MAX_MANIFEST_BYTES:
        raise HelperError('Normalized manifest exceeds 256 KiB.')
    return result


def manifest_digest(manifest):
    normalized = validate_manifest(manifest)
    return hashlib.sha256(json.dumps(normalized, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def control_support(control):
    if control['type'] not in ('toggle', 'selection', 'integer', 'button'):
        return 'Unsupported control type; no generic execution route.'
    if control['scope'] not in ('local', 'helper'):
        return 'Shared and persistent controls need independent world-side authorization; this adapter blocks them.'
    if control.get('requirements'):
        return 'Additional declared requirements are not independently verified by this adapter.'
    if not control.get('midi'):
        return 'No supported MIDI route declared.'
    return ''


def control_value(control, value):
    kind = control['type']
    if kind == 'toggle':
        return int(_boolean(value, 'Toggle value'))
    if kind == 'selection':
        if not isinstance(value, str) or value not in control['options']:
            raise HelperError('Select an explicitly declared option.')
        return control['options'].index(value)
    if kind == 'integer':
        return _integer(value, 'Control value', control['min'], control['max'])
    if kind == 'button':
        if value is not True:
            raise HelperError('A button requires an explicit true action value.')
        return 1
    raise HelperError('Unsupported control type; no generic execution route.')


def compare_manifests(left, right):
    """Declared semantic differences, not inferred runtime or upload parity."""
    left, right = validate_manifest(left), validate_manifest(right)
    if left['world_id'] != right['world_id']:
        raise HelperError('Compare manifests for the same explicitly identified world.')
    result = []
    for section in ('controls', 'assertions', 'contracts', 'dependencies'):
        lrows = {r['id']: r for r in left[section]}
        rrows = {r['id']: r for r in right[section]}
        for key in sorted(lrows.keys() | rrows.keys()):
            before, after = lrows.get(key), rrows.get(key)
            if before == after:
                continue
            state = 'added' if before is None else 'missing' if after is None else 'changed'
            row = before or after
            impacted = row.get('tests', [key]) if section == 'dependencies' else [key]
            result.append(dict(section=section, id=key, change=state, before=before, after=after,
                               affected=impacted, intentional=False, reason='',
                               scope='visual' if row.get('kind') == 'visual' else 'declared contract'))
    return result


def debug_audit(manifest):
    manifest = validate_manifest(manifest)
    results = []
    for control in manifest['controls']:
        if control['scope'] in ('shared', 'persistent') or control['test_only']:
            results.append(dict(kind='control', id=control['id'], severity='review',
                                message=f"{control['label']}: {control['scope']} scope; "
                                        + ('test-only declaration. ' if control['test_only'] else '')
                                        + 'Declared requirements: ' + (', '.join(control['requirements']) or 'none'),
                                route=control_support(control) or 'Local MIDI; explicit review required'))
    for key in ('verbose_logging', 'test_ui'):
        if manifest['debug'][key]:
            results.append(dict(kind='debug', id=key, severity='review', message=key.replace('_', ' ') + ' is declared enabled.'))
    results.append(dict(kind='debug', id='world_debugging', severity='info',
                        message='Built-in World Debugging: ' + manifest['debug']['world_debugging'] +
                                '. Creator Mode grants no VRChat debug-view permission.'))
    for dep in manifest['dependencies']:
        missing = [key for key in ('owner', 'credit', 'provenance') if not dep[key]]
        if missing:
            results.append(dict(kind='attribution', id=dep['id'], severity='review',
                                message='Missing recordkeeping: ' + ', '.join(missing) + '. This is not legal clearance.'))
    for dep in manifest['debug']['external_dependencies']:
        results.append(dict(kind='dependency', id=dep, severity='review', message='Declared external dependency: ' + dep))
    results.append(dict(kind='coverage', id='declared-only', severity='info',
                        message='This audit covers supplied declarations, not a scan of the running world or all Unity components.'))
    return results


def _context(value):
    if not isinstance(value, dict):
        raise HelperError('A current world/build/session context is required.')
    _obj(value, ('world_id', 'build_id', 'generation', 'account_id', 'client_session'), 'Context')
    if not _WORLD.fullmatch(str(value.get('world_id', ''))):
        raise HelperError('Current world is unresolved.')
    _identifier(value.get('build_id'), 'Current loaded build')
    if value.get('generation') is None or value.get('generation') == '':
        raise HelperError('Current session generation is unresolved.')
    try:
        serialized = json.dumps(value, allow_nan=False, sort_keys=True)
    except (TypeError, ValueError) as exc:
        raise HelperError('Invalid session context.') from exc
    if len(serialized) > 4096:
        raise HelperError('Session context is too large.')
    return json.loads(serialized)


class CommandLedger:
    """Single-use reviews; a changed session or ambiguous send never retries itself."""
    def __init__(self, context=None, *, clock=time.monotonic):
        self.clock = clock
        self.context = _context(context) if context is not None else None
        self._requests = {}
        self._sequence = secrets.randbelow((1 << 20) - 1) + 1
        self._manifest_digest = None

    def set_context(self, context):
        normalized = _context(context) if context is not None else None
        if normalized != self.context:
            for request in self._requests.values():
                if request['status'] in _ACTIVE:
                    request['status'] = 'Cancelled'
                    request['message'] = 'World, build, account, client, or session context changed.'
            self.context = normalized

    def set_manifest(self, manifest):
        """Call on import/replacement so an old review cannot outlive capabilities."""
        digest = manifest_digest(manifest) if manifest is not None else None
        if digest != self._manifest_digest:
            for request in self._requests.values():
                if request['status'] in _ACTIVE:
                    request['status'] = 'Cancelled'
                    request['message'] = 'The selected helper manifest changed.'
            self._manifest_digest = digest

    def review(self, manifest, control_id, value, context, now=None, *, transport_id=None):
        context = _context(context)
        if context != self.context:
            raise HelperError('Context changed; refresh the current session before reviewing.')
        manifest = validate_manifest(manifest)
        if (context['world_id'], context['build_id']) != (manifest['world_id'], manifest['build_id']):
            raise HelperError('Manifest does not match the current world and loaded build.')
        control = next((c for c in manifest['controls'] if c['id'] == control_id), None)
        if control is None:
            raise HelperError('Control is not declared by this manifest.')
        unsupported = control_support(control)
        if unsupported:
            raise HelperError(unsupported)
        encoded = control_value(control, value)
        if transport_id is not None and (not isinstance(transport_id, str) or not transport_id or len(transport_id) > 512):
            raise HelperError('A valid explicitly enabled transport identity is required.')
        self.set_manifest(manifest)
        now = self.clock() if now is None else now
        self.expire(now)
        if len(self._requests) >= MAX_REQUESTS:
            terminal = next((k for k, r in self._requests.items() if r['status'] not in _ACTIVE), None)
            if terminal is None:
                raise HelperError('Too many pending requests. Cancel or wait for expiry.')
            del self._requests[terminal]
        self._sequence += 1
        if self._sequence >= (1 << 21):
            raise HelperError('MIDI request sequence exhausted; create a new session controller.')
        request = dict(id=uuid.uuid4().hex, wire_id=self._sequence, status='Requested',
                       world_id=manifest['world_id'], build_id=manifest['build_id'],
                       control_id=control_id, label=control['label'], description=control['description'],
                       scope=control['scope'], value=copy.deepcopy(value), encoded_value=encoded,
                       midi=copy.deepcopy(control['midi']), context=context,
                       transport_id=transport_id,
                       created=now, expires=now + REVIEW_SECONDS, sent=None,
                       manifest_digest=manifest_digest(manifest), helper_report=None,
                       affected_systems=control['affected_systems'], leaves_unchanged=control['leaves_unchanged'],
                       retry_safe=control['retry_safe'], message='Review required. No command has been sent.')
        self._requests[request['id']] = request
        return copy.deepcopy(request)

    def dispatch(self, request_id, context, adapter, *, consent=False, now=None):
        now = self.clock() if now is None else now
        self.expire(now)
        request = self._requests.get(request_id)
        if request is None:
            raise HelperError('Unknown or expired request.')
        current = _context(context)
        if current != self.context or current != request['context']:
            request['status'] = 'Cancelled'
            request['message'] = 'Context changed after review.'
            raise HelperError(request['message'])
        if request['manifest_digest'] != self._manifest_digest:
            request['status'] = 'Cancelled'
            request['message'] = 'The selected helper manifest changed after review.'
            raise HelperError(request['message'])
        if request['transport_id'] is not None and request['transport_id'] != getattr(adapter, 'transport_id', None):
            request['status'] = 'Cancelled'
            request['message'] = 'The MIDI output changed or disconnected after review.'
            raise HelperError(request['message'])
        if request['status'] != 'Requested':
            raise HelperError('A reviewed request may be sent only once; never automatically retry.')
        if consent is not True:
            raise HelperError('Explicit confirmation of this reviewed command is required.')
        # Consume before entering any transport: an exception may follow a partial send.
        request['status'], request['sent'] = 'Sent', now
        request['expires'] = now + ACK_SECONDS
        request['message'] = 'Sent to the selected local MIDI output; application is not confirmed.'
        try:
            adapter.send(copy.deepcopy(request))
        except Exception as exc:
            request['status'] = 'Failed'
            request['message'] = 'Delivery may be partial. No automatic retry. ' + type(exc).__name__
        return copy.deepcopy(request)

    def expire(self, now=None):
        now = self.clock() if now is None else now
        for request in self._requests.values():
            if request['status'] in _ACTIVE and now >= request['expires']:
                sent = request['status'] == 'Sent'
                request['status'] = 'Timed out' if sent else 'Expired'
                request['message'] = ('Application was not independently confirmed; no retry.' if sent
                                      else 'Review expired before sending.')

    def record_helper_report(self, observation, context):
        """Untrusted local logs retain reported status; they never certify application."""
        if _context(context) != self.context:
            return False
        if (not isinstance(observation, dict) or observation.get('trusted') is not False or
                observation.get('event') != 'control-report' or
                observation.get('state') not in ('accepted', 'applied', 'failed')):
            return False
        for request in self._requests.values():
            if (request['wire_id'] == observation.get('request') and
                    request['control_id'] == observation.get('control') and
                    request['world_id'] == observation.get('world_id') and
                    request['build_id'] == observation.get('build_id') and
                    request['context'] == self.context and request['sent'] is not None and
                    request['status'] not in ('Cancelled', 'Failed')):
                request['helper_report'] = copy.deepcopy(observation)
                return True
        return False

    def verify(self, request_id, context, *, observed_value, consent=False):
        request = self._requests.get(request_id)
        if request is None or request['status'] not in ('Sent', 'Timed out'):
            raise HelperError('Only a sent request may be manually verified.')
        if _context(context) != self.context or request['context'] != self.context:
            raise HelperError('The observed state belongs to a different session.')
        if consent is not True or type(observed_value) is not type(request['value']) or observed_value != request['value']:
            raise HelperError('Explicitly confirm the matching observed local state.')
        request['status'] = 'Independently observed'
        request['message'] = 'User manually confirmed the matching local state; not proof of other players\' state.'
        return copy.deepcopy(request)

    def cancel(self, request_id):
        request = self._requests.get(request_id)
        if request and request['status'] in _ACTIVE:
            request['status'], request['message'] = 'Cancelled', 'Cancelled locally; an already sent effect is not undone.'

    def requests(self):
        self.expire()
        return copy.deepcopy(list(self._requests.values()))


def parse_helper_log(line):
    """Parse bounded observations only. A prefix and matching IDs provide no trust."""
    if not isinstance(line, str) or len(line) > 8192 or LOG_PREFIX not in line:
        return None
    text = line.split(LOG_PREFIX, 1)[1].strip()
    try:
        row = json.loads(text, object_pairs_hook=_json_object, parse_constant=_reject_number)
        _obj(row, ('schema', 'world_id', 'build_id', 'event', 'sequence', 'request', 'control',
                   'value', 'state', 'zone', 'assertion', 'elapsed_ms'), 'Helper observation')
        _integer(row.get('schema'), 'schema', SCHEMA, SCHEMA)
        if not _WORLD.fullmatch(str(row.get('world_id', ''))):
            return None
        _identifier(row.get('build_id'), 'build_id')
        if row.get('event') not in ('identity', 'bookmark', 'state', 'control-report', 'assertion', 'zone'):
            return None
        _integer(row.get('sequence'), 'sequence', 0, 2147483647)
        if 'request' in row:
            _integer(row['request'], 'request', 1, (1 << 21) - 1)
        for key in ('control', 'zone', 'assertion'):
            if key in row:
                _identifier(row[key], key)
        if 'state' in row and row['state'] not in ('accepted', 'applied', 'failed', 'pass', 'fail', 'unresolved'):
            return None
        if 'value' in row and not (type(row['value']) in (bool, int, float, str)):
            return None
        for key in ('value', 'elapsed_ms'):
            if key in row and type(row[key]) in (int, float) and not math.isfinite(row[key]):
                return None
        if 'elapsed_ms' in row and (type(row['elapsed_ms']) not in (int, float) or not 0 <= row['elapsed_ms'] <= 3600000):
            return None
        if isinstance(row.get('value'), str):
            _text(row['value'], 'value', 256, safe=True)
        row['trusted'] = False
        row['source'] = 'creator helper log (untrusted declaration)'
        return row
    except (ValueError, TypeError, RecursionError):
        return None


def evaluate_assertion(declaration, observed_state, age_seconds):
    """Preserve unknown and allowed settling time rather than claiming a pass."""
    if type(age_seconds) not in (int, float) or not math.isfinite(age_seconds) or age_seconds < 0:
        raise HelperError('Assertion age must be a nonnegative finite duration.')
    if observed_state not in ('pass', 'fail', 'unresolved', None):
        raise HelperError('Unsupported assertion state.')
    if observed_state is None:
        return dict(status='No observation', severity='unknown')
    if observed_state == 'pass':
        return dict(status='Reported pass', severity='info')
    if age_seconds < declaration.get('grace_seconds', 0):
        return dict(status='Settling', severity='info')
    return dict(status='Reported failure' if observed_state == 'fail' else 'Unresolved',
                severity=declaration.get('severity', 'warning'))


class FailureSimulation:
    """Explicit local adapter exercise, with no access to VRChat or peer traffic."""
    SCENARIOS = ('companion-disconnect', 'helper-timeout', 'missing-configuration',
                 'unavailable-media', 'interrupted-sharing', 'delayed-confirmation')

    def __init__(self):
        self.active = None
        self.events = []

    def start(self, scenario, expected_recovery, *, consent=False):
        if consent is not True or scenario not in self.SCENARIOS or self.active is not None:
            raise HelperError('Choose and explicitly start one local simulation at a time.')
        expected = _text(expected_recovery, 'Expected recovery', 512, required=True, safe=True)
        self.active = dict(scenario=scenario, expected_recovery=expected, scope='VRC Eye local simulation only', result='In progress')
        self.events.append(copy.deepcopy(self.active))
        self.events = self.events[-64:]
        return copy.deepcopy(self.active)

    def finish(self, result, note=''):
        if self.active is None or result not in ('Recovered automatically', 'Manual recovery', 'Invalid state', 'Not tested'):
            raise HelperError('Record an explicit recovery result for an active simulation.')
        completed = dict(self.active, result=result, note=_text(note, 'Recovery note', 1024))
        self.events.append(completed)
        self.events = self.events[-64:]
        self.active = None
        return copy.deepcopy(completed)

    def gate(self, capability, value):
        """Withhold only a caller-supplied local adapter result during an exercise.

        This is an integration hook for local simulations, not a network switch.
        The owner supplies the already-local result. No other participant's data
        or connection is changed. The withheld result is not a successful test.
        """
        routes = {'companion-disconnect': 'companion', 'helper-timeout': 'helper',
                  'missing-configuration': 'configuration', 'unavailable-media': 'media',
                  'interrupted-sharing': 'sharing', 'delayed-confirmation': 'confirmation'}
        if self.active and routes[self.active['scenario']] == capability:
            return None
        return value
