"""Reference client-side SDK for the VRC Eye local bridge.

An adapter supplies its own legitimate telemetry and narrowly scoped callbacks.
This SDK never finds/injects/loads/modifies VRChat. Game callbacks run only from
explicit dispatch_pending() calls on the adapter's own appropriate thread.
"""
from collections import deque
from copy import deepcopy
import json
import threading
import time

import bridge_protocol as p
import bridge_transport
from bridge_protocol import BridgeError, CAPABILITIES


def pairing(text):
    if not isinstance(text,str) or len(text)>4096:raise BridgeError("Invalid bridge connection code.")
    data=p.decode(text.encode("utf-8"));p.exact(data,("bridge","transport","endpoint","secret"))
    if type(data["bridge"]) is not int or data["bridge"]!=1:raise BridgeError("Unsupported connection code version.")
    p.choice(data["transport"],("unix","pipe"))
    (bridge_transport.unix_address if data["transport"]=="unix" else bridge_transport.pipe_address)(data["endpoint"])
    p.proof(data["secret"],"hello","validate",{})
    return data


class BridgeClient:
    def __init__(self,*,client_id,name,version,kind="diagnostic",context=None,capabilities=None,handlers=None,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.stream=None;self.stop_event=threading.Event();self.thread=None;self.watchdog=None;self._generation=0;self.connecting=False
        self.hello=dict(protocol=dict(p.PROTOCOL),client=dict(id=client_id,name=name,version=version,kind=kind),
                        context=context or dict(attached=False,runtime_session=None,local_user_id=None),capabilities=capabilities or {})
        self.offered=p.hello(self.hello);self.handlers=dict(handlers or {})
        for key,handler in self.handlers.items():
            if key not in self.offered or CAPABILITIES[key].kind!="action" or key=="bridge.ping" or not callable(handler):raise BridgeError("Handlers must match explicitly offered local action capabilities.")
        for key in self.offered:
            if CAPABILITIES[key].kind=="action" and key!="bridge.ping" and key not in self.handlers:raise BridgeError("Do not advertise unimplemented client actions.")
        self.hello=deepcopy(self.hello);self.offered=deepcopy(self.offered);self.session=None;self.accepted={};self.grants={};self.permission_revision=-1
        self.controls_enabled=False;self.requests_paused=False;self.last_heartbeat=0.;self.received_seq=0;self.sent_seq=0
        self.samples={};self.lab_samples={};self.actions=deque();self.replies=deque();self.seen=deque(maxlen=256)
        self.status="Disconnected."

    def connected(self):
        with self.lock:
            return bool(self.session and not self.stop_event.is_set() and 0<=self.clock()-self.last_heartbeat<p.LEASE_SECONDS)
    def _allowed(self,name):
        if not self.connected() or name not in self.accepted or name not in self.grants:return False
        expires=self.grants[name]
        if expires is not None and self.clock()>=expires:return False
        spec=CAPABILITIES[name]
        if spec.game and (self.hello["client"]["kind"]!="vrchat" or not self.hello["context"]["attached"]):return False
        return spec.kind!="action" or not self.requests_paused and (not spec.game or self.controls_enabled)
    def allowed(self,name):
        with self.lock:return self._allowed(name)
    def connect(self,code):
        data=pairing(code)
        with self.lock:
            if self.stream is not None or self.connecting:raise BridgeError("Disconnect the existing adapter session first.")
            self._generation+=1;generation=self._generation;self.connecting=True;self.stop_event=threading.Event();stop=self.stop_event
            hello=deepcopy(self.hello)
        stream=None
        try:
            stream=bridge_transport.connect(data["transport"],data["endpoint"])
            with self.lock:
                if generation!=self._generation or stop.is_set():raise BridgeError("Bridge connection canceled.")
                self.stream=stream
            def read():
                deadline=time.monotonic()+p.HANDSHAKE_SECONDS
                while not stop.is_set() and time.monotonic()<deadline:
                    message=stream.receive(.2)
                    if message is not None:return message
                raise BridgeError("Bridge handshake timed out.")
            challenge=read();p.exact(challenge,("type","protocol","nonce"))
            if challenge["type"]!="challenge" or challenge["protocol"]!=p.PROTOCOL:raise BridgeError("Unsupported bridge challenge.")
            p.text(challenge["nonce"],64)
            stream.send(dict(type="hello",hello=hello,proof=p.proof(data["secret"],"hello",challenge["nonce"],hello)))
            reply=read();p.exact(reply,("type","welcome","proof"))
            if reply["type"]!="welcome":raise BridgeError("Bridge did not accept the connection.")
            welcome=reply["welcome"];p.verify(data["secret"],"welcome",challenge["nonce"],welcome,reply["proof"])
            p.exact(welcome,("protocol","session","accepted","heartbeat_ms","lease_ms","app_version"))
            if welcome["protocol"]!=p.PROTOCOL or welcome["heartbeat_ms"]!=1000 or welcome["lease_ms"]!=5000:raise BridgeError("Unsupported negotiated bridge timing/version.")
            p.ref(welcome["session"]);p.text(welcome["app_version"],40)
            if not isinstance(welcome["accepted"],dict) or any(k not in self.offered or v!=self.offered[k] for k,v in welcome["accepted"].items()):raise BridgeError("Invalid negotiated capabilities.")
            with self.lock:
                if generation!=self._generation or stop.is_set() or self.stream is not stream:raise BridgeError("Bridge connection canceled.")
                self.connecting=False
                self.session=welcome["session"];self.accepted=deepcopy(welcome["accepted"]);self.grants={};self.permission_revision=-1
                self.controls_enabled=False;self.requests_paused=False;self.last_heartbeat=self.clock();self.received_seq=self.sent_seq=0
                self.samples.clear();self.lab_samples.clear();self.actions.clear();self.replies.clear();self.seen.clear();self.status="Connected; awaiting capability approval."
                self.thread=threading.Thread(target=self._run,args=(generation,stop,stream),daemon=True,name="VRC-Eye-Bridge-Adapter")
                self.watchdog=threading.Thread(target=self._watch,args=(generation,stop),daemon=True,name="VRC-Eye-Bridge-Adapter-Watchdog")
                self.thread.start();self.watchdog.start()
        except Exception:
            if stream:stream.close()
            with self.lock:
                if generation==self._generation:self.close()
            raise BridgeError("Could not authenticate a compatible local VRC Eye bridge.") from None
        finally:
            data["secret"]=""  # Connection code is not retained by the SDK.
    def close(self):
        with self.lock:
            self.stop_event.set();self._generation+=1;self.connecting=False;stream,self.stream=self.stream,None
            self.session=None;self.grants.clear();self.samples.clear();self.lab_samples.clear();self.actions.clear();self.replies.clear();self.controls_enabled=False;self.status="Disconnected."
        if stream:
            try:stream.close()
            except OSError:pass
    def _watch(self,generation,stop):
        while not stop.wait(.1):
            with self.lock:
                if generation!=self._generation:return
                if not self.connected():self.close();return
    def set_runtime(self,context):
        """Call on attach/detach, account/world change, or runtime reset; consent resets."""
        context=p.context(context)
        if self.hello["client"]["kind"]=="diagnostic" and context["attached"]:raise BridgeError("Diagnostic adapters cannot enable game capabilities.")
        self.close();self.hello["context"]=context
    def publish(self,name,value):
        with self.lock:
            if name not in self.accepted or CAPABILITIES[name].kind!="telemetry" or not self._allowed(name):return False
            value=deepcopy(p.telemetry(name,value))
            if name.startswith("lab."):
                from bridge_lab_contract import same
                context=value["context"]
                if context["account_id"]!=self.hello["context"]["local_user_id"] or context["runtime_session"]!=self.hello["context"]["runtime_session"]:
                    raise BridgeError("Lab telemetry must belong to the attached local runtime/account.")
                previous=self.lab_samples.get("lab.context")
                if name=="lab.context":
                    if previous and (context["revision"]<previous[0]["context"]["revision"] or context["revision"]==previous[0]["context"]["revision"] and not same(context,previous[0]["context"])):
                        raise BridgeError("Lab context revision must increase when its identity changes.")
                    if previous and not same(context,previous[0]["context"]):
                        self.lab_samples.clear()
                        for key in tuple(self.samples):
                            if key.startswith("lab."):self.samples.pop(key,None)
                elif not previous or self.clock()-previous[1]>=3 or not same(context,previous[0]["context"]):
                    raise BridgeError("Publish a fresh matching lab.context before its observations.")
                self.lab_samples[name]=(deepcopy(value),self.clock(),self.permission_revision)
            self.samples[name]=(value,self.clock(),self.permission_revision);return True
    def dispatch_pending(self,limit=1):
        """Run only on the adapter's VRChat/main thread. Never call arbitrary code from a peer."""
        p.integer(limit,1,8);count=0
        for _ in range(limit):
            with self.lock:
                if not self.actions:break
                item=self.actions.popleft()
                valid=(item["generation"]==self._generation and self._allowed(item["capability"]) and self.clock()<item["deadline"] and item["permission_revision"]==self.permission_revision)
                handler=self.handlers.get(item["capability"])
            value=None;ok=False
            if valid and handler:
                try:
                    # Adapter still owns the final atomic state/lease check on its own thread.
                    if item["capability"].startswith("lab."):
                        with self.lock:
                            from bridge_lab_contract import check_preconditions
                            def read(name):
                                sample=self.lab_samples.get(name)
                                if not self._allowed(name) or not sample or self.clock()-sample[1]>=3 or sample[2]!=self.permission_revision:
                                    raise BridgeError("Fresh approved provider precondition is absent.")
                                value=deepcopy(sample[0])
                                if name=="lab.creator":
                                    value["manifest"]["authority_expires_ms"]=max(0,value["manifest"]["authority_expires_ms"]-(self.clock()-sample[1])*1000)
                                return value
                            if item["capability"]=="lab.restore" and not self._allowed(item["params"]["original_capability"]):
                                raise BridgeError("Restoration requires the original scoped permission.")
                            check_preconditions(item["capability"],item["params"],read)
                    value=p.result(item["capability"],handler(deepcopy(item["params"])),item["params"]);ok=True
                except Exception:pass
            with self.lock:
                if self.session and item["generation"]==self._generation:
                    if len(self.replies)>=16:raise BridgeError("Adapter result queue exceeded.")
                    self.replies.append(dict(id=item["id"],ok=ok,**({"value":value} if ok else {"error":"not_applied"})))
            count+=1
        return count
    def _handle(self,message):
        p.exact(message,("session","seq","kind","data"));p.integer(message["seq"],1,2**53-1)
        with self.lock:
            if message["session"]!=self.session or message["seq"]!=self.received_seq+1:raise BridgeError("Stale or replayed server frame.")
            self.received_seq=message["seq"];kind=message["kind"];data=message["data"]
            if kind=="heartbeat":p.exact(data,());self.last_heartbeat=self.clock();return None
            if kind=="permissions":
                p.exact(data,("revision","grants","controls_enabled","requests_paused"));p.integer(data["revision"])
                if data["revision"]<=self.permission_revision:raise BridgeError("Stale or repeated capability consent.")
                p.boolean(data["controls_enabled"]);p.boolean(data["requests_paused"])
                if not isinstance(data["grants"],dict) or set(data["grants"])-set(self.accepted):raise BridgeError("Invalid capability consent.")
                grants={}
                for name,ms in data["grants"].items():
                    if ms is not None:p.integer(ms,0,3600000)
                    grants[name]=None if ms is None else self.clock()+ms/1000
                self.grants=grants;self.permission_revision=data["revision"];self.controls_enabled=data["controls_enabled"];self.requests_paused=data["requests_paused"]
                self.actions.clear();self.samples.clear();self.lab_samples.clear();self.status="Capability permissions received for this connection."
                return ("permissions_ack",dict(revision=self.permission_revision))
            if kind!="request":raise BridgeError("Unsupported server message.")
            p.exact(data,("id","capability","params","permission_revision","runtime_session","ttl_ms"))
            key=p.ref(data["id"]);p.integer(data["ttl_ms"],1,2000);p.integer(data["permission_revision"])
            if key in self.seen:raise BridgeError("Duplicate bridge action ID.")
            self.seen.append(key);name=data["capability"]
            if not isinstance(name,str) or name not in self.accepted or CAPABILITIES[name].kind!="action":raise BridgeError("Unadvertised bridge action.")
            p.parameters(name,data["params"],self.accepted[name])
            if not self._allowed(name) or data["permission_revision"]!=self.permission_revision or data["runtime_session"]!=self.hello["context"]["runtime_session"]:
                return ("result",dict(id=key,ok=False,error="not_allowed"))
            if name=="bridge.ping":return ("result",dict(id=key,ok=True,value=dict(pong=data["params"]["nonce"])))
            if len(self.actions)>=8:return ("result",dict(id=key,ok=False,error="queue_full"))
            self.actions.append(dict(data,generation=self._generation,deadline=self.clock()+data["ttl_ms"]/1000))
            return None
    def _run(self,generation,stop,stream):
        heartbeat_at=0.;window=time.monotonic();messages=0
        def send(kind,data):
            with self.lock:
                if generation!=self._generation or not self.connected():raise EOFError("Adapter disconnected.")
                self.sent_seq+=1;message=dict(session=self.session,seq=self.sent_seq,kind=kind,data=data)
            stream.send(message)
        try:
            while not stop.is_set() and self.connected():
                now=time.monotonic()
                if now>=heartbeat_at:
                    send("heartbeat",dict(context=self.hello["context"]));heartbeat_at=now+p.HEARTBEAT_SECONDS
                with self.lock:
                    replies=list(self.replies);self.replies.clear();samples=dict(self.samples);self.samples.clear()
                for reply in replies:send("result",reply)
                for name,(value,captured,revision) in samples.items():
                    if self.allowed(name) and revision==self.permission_revision:
                        age=int((self.clock()-captured)*1000)
                        if 0<=age<3000:send("telemetry",dict(capability=name,value=value,permission_revision=revision,sample_age_ms=age))
                message=stream.receive(.1)
                if message is not None:
                    if now-window>=1:window=now;messages=0
                    messages+=1
                    if messages>100:raise BridgeError("Server message rate exceeded.")
                    reply=self._handle(message)
                    if reply:send(*reply)
        except Exception:pass  # Never expose connection codes or received raw packets in errors.
        finally:
            try:stream.close()
            except OSError:pass
            with self.lock:
                if generation==self._generation:
                    stop.set()
                    self.stream=None;self.session=None;self.grants.clear();self.samples.clear();self.lab_samples.clear();self.actions.clear();self.replies.clear();self.controls_enabled=False
                    self.status="Bridge disconnected or timed out. Reconnect explicitly; previous consent has expired."
