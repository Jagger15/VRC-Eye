"""Photo context is declared or observed evidence, never visual identification."""
from datetime import datetime,timezone
from hashlib import sha256
import json
import struct
import zlib
from companion_data import entity_id
from photo_metadata import PNG,png_text,inspect_metadata
from photo_files import read_photo


def candidate(raw,session,*,now=None):
    now=now or datetime.now(timezone.utc)
    report=inspect_metadata(raw);values={}
    for row in report['candidates']:values.setdefault(row['field'],set()).add(str(row['value']))
    reasons=[];world='';stamp=''
    if len(values.get('world_id',()))==1:world=next(iter(values['world_id']))
    elif values.get('world_id'):reasons.append('Conflicting embedded world declarations')
    if len(values.get('timestamp',()))==1:stamp=next(iter(values['timestamp']))
    else:reasons.append('No unique declared capture time')
    try:
        capture=datetime.fromisoformat(stamp.replace('Z','+00:00'))
        start=datetime.fromisoformat(session.get('started','').replace('Z','+00:00'))
        if capture.tzinfo is None or start.tzinfo is None:raise ValueError()
        if not start<=capture<=now or (now-capture).total_seconds()>90:reasons.append('Capture is outside the recent observed session')
    except (ValueError,TypeError):reasons.append('Capture time or session timezone is unknown')
    if not world or world!=session.get('world_id'):reasons.append('Embedded world does not match the observed session')
    if not session.get('id') or session.get('ended'):reasons.append('No active session observation')
    return dict(world_id=world,captured_at=stamp,session_id=session.get('id','') if not reasons else '',
                confidence='Corroborated declaration' if not reasons else 'Review required',reasons=reasons,
                source='Embedded photo metadata + current Eye session',roster_inferred=False)


def record(store,scope,photo,raw,session,*,adopt=False,include_people=False):
    row=store.get(scope,photo)
    if not row or sha256(raw).hexdigest()!=row['sha256']:raise ValueError('Photo bytes changed; recheck before indexing context.')
    value=candidate(raw,session);value['digest']=row['sha256']
    if include_people:
        report=inspect_metadata(raw);authors=set();participants=set()
        for item in report['candidates']:
            if item['field']=='author_id':authors.add(entity_id('user',item['value']))
            if item['field']=='participants':
                participants.update(entity_id('user',v['id']) for v in item['value'])
        value.update(author_ids=sorted(authors),participant_ids=sorted(participants),people_basis='Embedded declarations; not verified visible people')
    with store.connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS photo_context_v1(scope TEXT,photo TEXT,digest TEXT,data TEXT,PRIMARY KEY(scope,photo))')
        previous=db.execute('SELECT digest,data FROM photo_context_v1 WHERE scope=? AND photo=?',(scope,photo)).fetchone()
        if not include_people and previous and previous['digest']==row['sha256']:
            old=json.loads(previous['data'])
            for key in ('author_ids','participant_ids','people_basis'):
                if key in old:value[key]=old[key]
        db.execute('INSERT OR REPLACE INTO photo_context_v1 VALUES(?,?,?,?)',(scope,photo,row['sha256'],json.dumps(value)))
        if adopt and value['confidence']=='Corroborated declaration':
            # Inferred context only fills both empty links. Manual edits win.
            db.execute("UPDATE photo_items_v4 SET world_id=?,session_id=? WHERE scope=? AND id=? AND world_id='' AND session_id=''",
                       (value['world_id'],value['session_id'],scope,photo))
    return value


def description(world='',name='',timestamp=''):
    result={'application':'VRCX','version':1}
    if world:result['world']={'id':entity_id('world',world),'name':str(name)[:512]}
    if timestamp:
        parsed=datetime.fromisoformat(timestamp.replace('Z','+00:00'))
        if parsed.tzinfo is None:raise ValueError('A capture timestamp needs an explicit UTC offset.')
        result['timestamp']=parsed.isoformat()
    return result


def metadata_copy(raw,fields):
    """Replaces textual metadata only; encoded image chunks stay byte-identical."""
    png_text(raw) # Validate bounded PNG chunk structure first.
    if set(fields)-{'application','version','world','timestamp'} or fields.get('application')!='VRCX' or fields.get('version')!=1:
        raise ValueError('Only the reviewed world and capture time can be exported.')
    world=fields.get('world',{})
    if not isinstance(world,dict) or set(world)-{'id','name'}:raise ValueError('Instance capabilities and roster fields are excluded.')
    expected=description(world.get('id',''),world.get('name',''),fields.get('timestamp',''))
    payload=b'Description\0'+json.dumps(expected,ensure_ascii=False,separators=(',',':')).encode()
    kind=b'tEXt';chunk=struct.pack('>I',len(payload))+kind+payload+struct.pack('>I',zlib.crc32(kind+payload)&0xffffffff)
    result=bytearray(PNG);at=8
    while at<len(raw):
        size=struct.unpack_from('>I',raw,at)[0];kind=raw[at+4:at+8];end=at+size+12
        if zlib.crc32(raw[at+4:end-4])&0xffffffff!=struct.unpack_from('>I',raw,end-4)[0]:raise ValueError('PNG chunk checksum mismatch.')
        if kind==b'IEND':result.extend(chunk);result.extend(raw[at:end]);break
        if kind not in (b'tEXt',b'zTXt',b'iTXt',b'eXIf'):result.extend(raw[at:end])
        at=end
    result=bytes(result)
    if json.loads(png_text(result)['Description'])!=expected:raise ValueError('Export metadata verification failed.')
    return result
