"""Explicit local installation tasks inside the existing Unity Player owner."""
from datetime import datetime
import json
from pathlib import PurePosixPath
import threading

from companion_ui import Table, button, entry
from friendly_ui import flow_line as line, focus_scroll_target
from installation_inspector import inspect_installation, associate_runtime
from installation_reports import baseline_document, compare_baseline, load_baseline, report_document, write_document


class InstallationPanel:
    def __init__(self, page, parent):
        self.page = page; self.snapshot = None; self.baseline = None; self.comparison = None; self.association = None
        self.parent = parent
        self.generation = 0; self.working = threading.Event(); self.worker = None; self.frames = {}
        tk, ttk = page.tk, page.ttk
        self.target = tk.StringVar(); self.summary = tk.StringVar(value='Choose a folder or ZIP, then Inspect. Opening this view starts no scan.')
        self.details = tk.StringVar(value='Select a file to inspect its recorded evidence.')
        self.environment = tk.StringVar(value='Declared installation components are separate from live hardware and runtime observations.')
        self.findings = tk.StringVar(value='No installation evidence loaded.')
        self.runtime = tk.StringVar(value='Runtime association has not been requested.')
        row = line(page, parent); entry(page, row, self.target, 65)
        button(page, row, 'Folder…', self.choose_folder); button(page, row, 'ZIP…', self.choose_zip)
        row = line(page, parent)
        button(page, row, 'Inspect selected installation', self.inspect)
        button(page, row, 'Cancel inspection', self.cancel)
        button(page, row, 'Clear evidence', self.clear)
        ttk.Label(parent, text='Read-only local evidence · no sign-in · no program launch, extraction or automatic repair', style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=4)
        self.tabs = ttk.Notebook(parent); self.tabs.pack(fill='both', expand=True)
        for name in ('Overview', 'Files & packages', 'Environment', 'Findings & reports', 'Loader diagnostics'):
            frame = ttk.Frame(self.tabs, padding=8); self.tabs.add(frame, text=name); self.frames[name] = frame
        ttk.Label(self.frames['Overview'], textvariable=self.summary, justify='left', wraplength=900).pack(anchor='w', pady=6)
        ttk.Label(self.frames['Overview'], textvariable=self.runtime, justify='left', wraplength=900).pack(anchor='w', pady=6)
        button(page, line(page, self.frames['Overview']), 'Compare with current runtime', self.associate)
        button(page, line(page, self.frames['Overview']), 'Open loader diagnostics', self.show_loader)
        files = self.frames['Files & packages']
        self.table = Table(page, files, (('name', 'Relative file', 360), ('role', 'Role', 170), ('size', 'Bytes', 100), ('arch', 'PE architecture', 100), ('state', 'Evidence', 100), ('hash', 'SHA-256', 105)), height=10, select=self.show_file)
        self.table.tree.configure(selectmode='extended')
        button(page, line(page, files), 'Hash selected files and refresh snapshot', self.hash_selected)
        ttk.Label(files, text='Select up to 32 files. Hashing reads their complete bytes within a 1 GiB task budget; it does not verify publisher authenticity.', wraplength=900, style='Muted.TLabel').pack(anchor='w')
        ttk.Label(files, textvariable=self.details, justify='left', wraplength=900).pack(anchor='w', pady=5)
        ttk.Label(self.frames['Environment'], textvariable=self.environment, justify='left', wraplength=900).pack(anchor='w', pady=5)
        reports = self.frames['Findings & reports']
        row = line(page, reports)
        button(page, row, 'Save comparison baseline…', self.save_baseline)
        button(page, row, 'Compare saved baseline…', self.choose_baseline)
        button(page, row, 'Export sanitized report…', self.export_report)
        ttk.Label(reports, textvariable=self.findings, justify='left', wraplength=900).pack(anchor='w', pady=5)
        self.changes = Table(page, reports, (('file', 'Current relative file / baseline item', 420), ('role', 'Role', 170), ('state', 'Comparison', 230)), height=7)
        from vrchat_paths_ui import VRChatEnvironmentPanel
        self.path_environment = VRChatEnvironmentPanel(page, self.frames['Environment'], owner=self)
        from loader_inspection_ui import LoaderInspectionPanel
        self.loader = LoaderInspectionPanel(page, self.frames['Loader diagnostics'], owner=self)
        self._bind_focus(parent)
        self.target.trace_add('write', self._target_changed)

    def _bind_focus(self, parent):
        for widget in parent.winfo_children():
            widget.bind('<FocusIn>', self.focus_visible, add='+')
            self._bind_focus(widget)

    def focus_visible(self, event):
        """Reveal a control in Unity Player's existing Installation canvas."""
        from tkinter import TclError
        canvas = getattr(self.parent, 'master', None)
        try:
            widget = event.widget
            if canvas is None or canvas.winfo_class() != 'Canvas' or not widget.winfo_ismapped():
                return
            box = canvas.bbox('all')
            if not box or box[3] <= 0:
                return
            position = widget.winfo_rooty() - self.parent.winfo_rooty()
            start = canvas.canvasy(0)
            target = focus_scroll_target(position, widget.winfo_height(), canvas.winfo_height(), start)
            if target != start:
                canvas.yview_moveto(min(1., target / box[3]))
        except TclError:
            pass

    def show_loader(self):
        self.tabs.select(self.frames['Loader diagnostics'])
        self.loader.path_entry.focus_set()

    def _target_changed(self, *_):
        self.generation += 1
        if self.page.job: self.page.cancel()
        self.snapshot = None; self.comparison = None; self.association = None
        self.render()

    def idle(self):
        if self.working.is_set() or (self.worker and self.worker.is_alive()) or self.page.job:
            raise ValueError('An installation or Unity Player task is still finishing. Cancel it and wait for completion before starting another.')

    def run(self, work, done):
        self.idle(); token = self.generation; self.working.set()
        def worker(client, stop, progress):
            # Page.cancel intentionally releases its UI job immediately. Keep the
            # actual thread reference until exit, including queue publication.
            self.worker = threading.current_thread()
            try: return work(stop, progress)
            finally: self.working.clear()
        def delivered(value):
            if token == self.generation: done(value)
        try: self.page.start(worker, delivered, api=False)
        except BaseException: self.working.clear(); raise

    def choose_folder(self):
        self.idle(); token = (self.generation, self.page.context())
        from tkinter import filedialog
        path = filedialog.askdirectory(parent=self.page.app.root, title='Select a VRChat installation folder')
        if token != (self.generation, self.page.context()): raise ValueError('The context changed while choosing an installation.')
        if path: self.target.set(path)

    def choose_zip(self):
        self.idle(); token = (self.generation, self.page.context())
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.page.app.root, title='Select an offline installation ZIP', filetypes=(('ZIP archives', '*.zip'),))
        if token != (self.generation, self.page.context()): raise ValueError('The context changed while choosing an installation.')
        if path: self.target.set(path)

    def inspect(self, hashes=()):
        self.idle(); target = self.target.get().strip()
        if not target: raise ValueError('Choose an installation folder or ZIP first.')
        self.snapshot = None; self.comparison = None; self.association = None; self.render()
        def done(snapshot):
            self.snapshot = snapshot
            if self.baseline: self.comparison = compare_baseline(snapshot, self.baseline)
            self.render(); self.page.status.set('Installation snapshot captured. File declarations are not active runtime capabilities.')
        self.run(lambda stop, progress: inspect_installation(target, hash_paths=hashes, stop=stop, progress=progress), done)

    def cancel(self):
        self.page.cancel()
        if self.working.is_set(): self.page.status.set('Cancellation requested. The current local worker retains ownership until it exits.')

    def clear(self):
        self.cancel(); self.generation += 1; self.snapshot = None; self.baseline = None; self.comparison = None; self.association = None
        self.path_environment.clear()
        self.loader.clear()
        self.render()

    def require_snapshot(self):
        self.idle()
        if self.snapshot is None: raise ValueError('Inspect an installation first.')
        return self.snapshot

    def hash_selected(self):
        self.require_snapshot()
        records = [self.table.records[k] for k in self.table.tree.selection() if k in self.table.records]
        if not 1 <= len(records) <= 32: raise ValueError('Select 1–32 files in the table to hash.')
        self.inspect(tuple(r.path for r in records))

    def show_file(self):
        record = self.table.selected()
        if not record: self.details.set('Select a file to inspect its recorded evidence.'); return
        metadata = record.metadata
        self.details.set(record.path+'\nRole: '+record.role+' · State: '+record.state+'\nSHA-256: '+(record.sha256 or 'Not hashed')+'\n'+json.dumps(metadata, ensure_ascii=False, indent=2)[:10000]+'\nCertificate-table presence is not signature verification. Direct imports omit dynamic and delayed loading.')

    def associate(self):
        snapshot = self.require_snapshot(); runtime = self.page.service.snapshot()
        # Uses the existing fresh runtime service. No new telemetry loop or process read.
        self.association = associate_runtime(snapshot, runtime, now=self.page.service.clock())
        self.render()

    def choose_baseline(self):
        snapshot = self.require_snapshot(); token = (self.generation, self.page.context())
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.page.app.root, title='Select a historical installation baseline', filetypes=(('JSON baseline', '*.json'),))
        if not path: return
        if token != (self.generation, self.page.context()) or snapshot is not self.snapshot: raise ValueError('The evidence context changed while choosing a baseline.')
        def done(value):
            self.baseline = value; self.comparison = compare_baseline(snapshot, value); self.render()
        self.run(lambda stop, progress: load_baseline(path), done)

    def _save(self, document, kind):
        snapshot = self.require_snapshot(); token = self.generation
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.page.app.root, title='Save '+kind, defaultextension='.json', initialfile='vrc-eye-installation-'+kind.replace(' ', '-')+'.json', filetypes=(('JSON evidence', '*.json'),))
        if not path: return
        text = ('Save this frozen '+kind+'?\n\n'+str(len(snapshot.files))+' file records. '+
            'Paths, arbitrary filenames, account data and raw file contents are excluded. Exact observation times, file sizes and selected SHA-256 digests remain. '+
            ('Opaque path hashes permit later local comparisons. ' if kind=='baseline' else 'File IDs are local to this report. ')+
            'Existing files will not be overwritten.\n\nDestination: '+path)
        if not self.page.confirm('Review installation evidence export', text): return
        if token != self.generation or snapshot is not self.snapshot: raise ValueError('Installation selection changed during review.')
        def fresh():
            if token != self.generation or snapshot is not self.snapshot: raise ValueError('Evidence selection changed before publication.')
        self.run(lambda stop, progress: write_document(path, document, stop=stop, before_commit=fresh), lambda result:self.page.status.set('Saved installation '+kind+': '+result))

    def save_baseline(self):
        self._save(baseline_document(self.require_snapshot()), 'baseline')

    def export_report(self):
        snapshot = self.require_snapshot()
        # Association is historical at export review; no stored PID/path is included.
        association = associate_runtime(snapshot, self.page.service.snapshot(), now=self.page.service.clock())
        self._save(report_document(snapshot, comparison=self.comparison, association=association), 'report')

    def render(self):
        snapshot = self.snapshot
        if snapshot is None:
            self.summary.set('Choose a folder or ZIP, then Inspect. No installation evidence is currently loaded.')
            self.environment.set('Declared installation components are separate from live hardware and runtime observations.')
            self.findings.set('No installation evidence loaded.'); self.runtime.set('Runtime association has not been requested.')
            self.table.set([], lambda r:()); self.changes.set([], lambda r:()); self.show_file(); return
        summary = snapshot.summary
        engine = '\n'.join(summary['engine_versions']) or 'Unknown'
        self.summary.set(('Offline ZIP snapshot' if snapshot.source_kind=='zip' else 'Selected folder snapshot')+'\nObserved: '+datetime.fromtimestamp(snapshot.observed_at).isoformat(timespec='seconds')+
            '\nFiles: '+str(len(snapshot.files))+' · inventory '+('complete' if snapshot.inventory_complete else 'partial')+' · metadata '+('complete within declared scope' if snapshot.metadata_complete else 'partial / limited')+
            '\nUnity engine marker: '+engine+'\nVRChat release: Unknown · Steam build ID: Unknown\nPE architectures: '+', '.join(f'{k}: {v}' for k,v in summary['architectures'].items())+
            '\nIL2CPP layout: '+('present' if summary['il2cpp_layout'] else 'not established')+
            '\nSelected hashes completed: '+str(summary['completed_hash_count'])+'/'+str(summary['selected_hash_count'])+
            '\n\nThis client runtime does not determine the supported Creator SDK editor. File presence does not prove compatibility, active devices, enabled features or official integrity.')
        self.table.set(snapshot.files, lambda r:(r.path, r.role, str(r.size), r.metadata.get('architecture', '—'), r.state+'/'+r.metadata.get('state', 'declared'), r.sha256[:12] or 'not hashed'))
        if self.association:
            self.runtime.set('Runtime association: '+self.association['state']+'\n'+self.association['reason']+'\nLogged engine: '+str(self.association.get('runtime_engine_version') or 'Unknown')+'\nAssociation is a historical observation; use the button to refresh it.')
        else: self.runtime.set('Runtime association has not been requested.')
        parts=['Shipped component roles (presence only):']+[f'{role}: {count}' for role,count in summary['role_counts'].items()]
        for name, metadata in snapshot.manifests.items():
            if 'actions' in metadata:
                parts+=['\nSteamVR declarations: '+str(len(metadata['actions']))+' actions; '+str(len(metadata['action_sets']))+' sets; '+str(len(metadata['default_bindings']))+' default bindings.',
                    'Action types: '+', '.join(sorted({a['type'] for a in metadata['actions']})),
                    'Action sets: '+', '.join(a['name'] for a in metadata['action_sets']),
                    'Controller profiles: '+', '.join(b['controller_type']+' ('+b['state']+')' for b in metadata['default_bindings'])]
            if 'boot_options' in metadata: parts+=['\nBoot file declarations: '+json.dumps(metadata['boot_options'], ensure_ascii=False), metadata['interpretation']]
            if 'assembly_count' in metadata: parts+=['Declared assembly count: '+str(metadata['assembly_count'])+' (not a loose managed DLL inventory).']
        parts+=['\nBindings are declared references, not active headset/controller or OSC address evidence. Selecting a file shows its detailed manifest.']
        self.environment.set('\n'.join(parts))
        self.findings.set('\n'.join(snapshot.findings) or 'No additional structural findings within inspected coverage. This is not an integrity or safety verdict.')
        if self.comparison:
            self.findings.set(self.findings.get()+'\n\n'+self.comparison['meaning']+('\nEngine version boundary differs between snapshots.' if self.comparison['version_boundary'] else ''))
            self.changes.set(self.comparison['rows'], lambda r:(r['name'], r['role'], r['state']))
        else: self.changes.set([], lambda r:())
