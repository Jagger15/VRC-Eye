# External tracking and loader diagnostics

Development checkpoint 3 adds read-only interoperability based on the supplied
MelonLoader 0.7.3 and OpenVR-SpaceCalibrator 1.5.1 source archives.

## Saved Space Calibrator profiles

Open **Settings → SpaceCal & tracking diagnostics**. Choose a saved profile JSON, or use
the explicit Windows profile read on Windows. Opening Settings does not read the
registry, scan files, or start SteamVR. Demo and Safe mode allow selected JSON
inspection; native tracking and registry access stay disabled.

The profile view shows saved tracking systems, calibration rotation, translation,
scale, configured flags, relative-transform availability and chaperone presence.
These are saved settings, not a measurement of current calibration quality or
proof that the driver has applied them. Unsupported fields are counted without
retaining their values. Profiles, previews and matches remain session-only.

For this source version the Windows value is `Config` (REG_SZ), under the current
user's `Software\Classes\Local Settings\Software\OpenVR-SpaceCalibrator` key.
The upstream format is a JSON array; its stock loader uses element zero. This
integration does not invent an on-disk profile location or write that registry key.

### Offline transform worksheet

Enter a point or displacement vector in metres to preview the saved transform or
its inverse. Points include translation; vectors do not. The primary calibration
uses degrees and `Rz(roll) × Ry(yaw) × Rx(pitch)`, with saved centimetres converted
to metres. Its worksheet evaluates `t + R(scale × p)`.

That worksheet assumes an identity existing driver-to-world transform. The
upstream driver scales a raw device-local position before composing its existing
driver origin and calibration. The worksheet therefore cannot reproduce arbitrary
live tracker output from an already transformed SteamVR position. **Never apply
the saved transform again to calibrated SteamVR absolute poses.**

The separate relative transform uses radians, metre translations and
`Rx(roll) × Ry(yaw) × Rz(pitch)`. Its preview requires the saved
`relative_pos_calibrated` flag. Neither preview changes SteamVR, the compass,
the play space or a VRChat world.

## Live SteamVR device diagnostics

Choose **Start diagnostics** explicitly. This reuses VRC Eye's existing OpenVR
owner alongside the wrist compass and other overlays. It reports runtime device
class, controller role, tracking system, model, connection and positional-tracking
health. A rotation-only or out-of-range result is not reported as positional
tracking. Runtime slots are connection-scoped and are not avatar body roles.

The inventory is bounded to 64 slots, sampled at most twice per second, and
expires after 0.9 seconds. No coordinates, velocities or raw device serials enter
the inventory. A local serial hash supports matching against an explicitly read
profile; it is a pseudonymous identifier, not an authentication credential.
Matches indicate observed device identity only. Incomplete identities remain
candidates, duplicates remain ambiguous, and calibration activity stays unknown.

Stop diagnostics to clear this inventory without stopping another feature's
runtime use. Privacy and account changes clear profiles, previews and matches
and require an explicit restart. Lost or stale tracking stops being usable data.
The report excludes serials, device hashes, source paths and chaperone geometry.
Review the displayed profile summary before exporting a new report file.

## MelonLoader evidence

Open **Unity Player → Installation → Loader diagnostics**. Select a folder,
source ZIP, `Loader.cfg`, or historical `.log`, then choose **Inspect loader
evidence**. The view distinguishes source code from installed-file markers and
historical observations. A proxy filename alone is weak evidence.

The source inspector reports declared source versions/targets and recognized
layout markers. The configuration reader accepts bounded, supported TOML values
from the fixed loader sections. It does not substitute README defaults or infer
effective settings after command-line overrides. The log reader retains only
validated loader/Unity/runtime/architecture fields and severity counts.

**Export diagnostic report** saves the reviewed, sanitized snapshot as a new
JSON file. Raw logs, command lines, local paths, arbitrary filenames, mod messages
and mod preferences are excluded. No loader program or supplied assembly runs,
and no game file is patched, installed, removed or repaired by this view.

## EAC boundary and remaining work

[VRChat's security guidance](https://hello.vrchat.com/blog/vrchat-security-update)
distinguishes standalone SteamVR tools/overlays from modified VRChat clients.
These additions stay outside the VRChat client: selected-file inspection and
the existing external OpenVR connection. They do not provide loader injection,
process-memory access, client hooks or an EAC bypass. This is not EAC certification
or a guarantee about every external program a user might run.

The supplied Space Calibrator driver has its own SteamVR pose hooks. VRC Eye
does not include or install that driver, issue its binary calibration commands,
write chaperone data, or claim to replace its calibration solver. No supplied
MelonLoader or Space Calibrator binaries are bundled. Real Windows registry and
SteamVR/headset acceptance remains separate from the offline build tests.

Remote-player ESP, player positions and live VRChat-world alignment remain
pending. A local tracking-device inventory does not provide those data.
