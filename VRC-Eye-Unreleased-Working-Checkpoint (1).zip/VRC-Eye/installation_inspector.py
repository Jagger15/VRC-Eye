"""Passive, bounded installation evidence. No extraction, execution or DLL loading.

A snapshot is local historical evidence, not an integrity certification. Native
code, IL2CPP metadata and large Unity assets are never semantically inspected.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path, PurePosixPath
import json
import os
import re
import stat
import struct
import time
import uuid
import zipfile

from avatar_library_files import checked_stream, check_cancel, fingerprint, InspectionCancelled
from creator_projects import assert_no_links, local_path
from installation_pe import inspect_pe

MAX_ENTRIES = 4096
MAX_DEPTH = 16
MAX_SOURCE = 2 * 1024**3
MAX_DECLARED = 8 * 1024**3
MAX_READ = 256 * 1024**2
MAX_PREFIX = 64 * 1024**2
MAX_HASH = 1024**3
MAX_SECONDS = 120
TEXT_LIMIT = 128 * 1024
REPORT_LIMIT = 4 * 1024**2
SCHEMA = 'vrc-eye-installation-1'
ENGINE = re.compile(r'(?:20\d\d|6000)\.\d{1,3}\.\d{1,4}[abfp]\d{1,3}(?:[-_ ][A-Za-z0-9_() .-]{0,80})?\Z')
HEX = re.compile('[0-9a-f]{64}\\Z')
KNOWN_ROLES = frozenset(('main executable', 'Unity engine', 'native game assembly', 'crash helper',
    'anti-cheat helper', 'installation helper', 'XR provider', 'audio provider', 'media provider',
    'platform integration', 'graphics support', 'native support', 'engine configuration',
    'declared assemblies', 'declared XR manifest', 'declared VR bindings', 'IL2CPP metadata',
    'Unity asset', 'nested archive', 'other file'))


class BudgetExceeded(ValueError):
    pass


class SourceChanged(ValueError):
    pass


@dataclass(frozen=True)
class InstallationFile:
    path: str
    size: int
    role: str
    state: str = 'observed'
    metadata_json: str = '{}'
    sha256: str = ''
    identity_json: str = '{}'

    @property
    def metadata(self):
        return json.loads(self.metadata_json)

    @property
    def key(self):
        return sha256(self.path.casefold().encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class InstallationSnapshot:
    id: str
    observed_at: float
    source: str  # Local only; never exported.
    source_kind: str
    root_prefix: str
    root_identity_json: str
    files: tuple[InstallationFile, ...]
    inventory_complete: bool
    metadata_complete: bool
    findings: tuple[str, ...]
    summary_json: str
    manifests_json: str
    read_bytes: int
    hash_bytes: int

    @property
    def summary(self): return json.loads(self.summary_json)
    @property
    def manifests(self): return json.loads(self.manifests_json)


def encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def safe_member(name):
    if not isinstance(name, str) or not name or len(name) > 1024 or '\\' in name or ':' in name or name.startswith('/') or any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise ValueError('Unsafe installation member name.')
    raw = name[:-1] if name.endswith('/') else name
    parts = raw.split('/')
    if len(parts) > MAX_DEPTH or any(not p or p in ('.', '..') or p.endswith(('.', ' ')) for p in parts):
        raise ValueError('Unsafe or excessively nested installation member.')
    for part in parts:
        stem = part.split('.', 1)[0].upper()
        if stem in ('CON', 'PRN', 'AUX', 'NUL') or re.fullmatch(r'(?:COM|LPT)[1-9]', stem):
            raise ValueError('Reserved installation member name.')
    return '/'.join(parts)


def role_for(path):
    p = path.casefold(); name = PurePosixPath(p).name
    if name == 'vrchat.exe': return 'main executable'
    if name == 'unityplayer.dll': return 'Unity engine'
    if name == 'gameassembly.dll': return 'native game assembly'
    if name.startswith('unitycrashhandler'): return 'crash helper'
    if 'easyanticheat' in p or name == 'start_protected_game.exe': return 'anti-cheat helper'
    if name in ('install.exe', 'launch.exe'): return 'installation helper'
    if name == 'global-metadata.dat': return 'IL2CPP metadata'
    if name in ('boot.config', 'app.info'): return 'engine configuration'
    if name == 'scriptingassemblies.json': return 'declared assemblies'
    if name == 'unitysubsystemsmanifest.json': return 'declared XR manifest'
    if '/steamvr/' in p and name.endswith('.json'): return 'declared VR bindings'
    if name.endswith(('.zip', '.7z', '.rar', '.tar', '.gz')): return 'nested archive'
    if name.endswith(('.assets', '.ress', '.resource', '.vrcw', '.vrca')): return 'Unity asset'
    if name.endswith('.dll'):
        if any(v in name for v in ('openvr', 'ovrplugin', 'xrsdk')): return 'XR provider'
        if any(v in name for v in ('audio', 'opus', 'phonon', 'lipsync', 'nnnoiseless', 'portmidi')): return 'audio provider'
        if any(v in name for v in ('avpro', 'mediapipe', 'spout')): return 'media provider'
        if any(v in name for v in ('steam_api', 'eossdk', 'discord')): return 'platform integration'
        if any(v in name for v in ('d3d', 'dxgi', 'gpuutilities', 'texture')): return 'graphics support'
        return 'native support'
    return 'other file'


class Budget:
    def __init__(self, stop=None, progress=None, clock=time.monotonic):
        self.stop, self.progress, self.clock = stop, progress, clock
        self.started = clock(); self.read = 0; self.hashed = 0; self.last_progress = -1e30

    def check(self):
        check_cancel(self.stop)
        if self.clock() - self.started > MAX_SECONDS:
            raise BudgetExceeded('Inspection elapsed-time limit reached; coverage is partial.')

    def consume(self, count, hashing=False):
        self.check()
        if hashing:
            if self.hashed + count > MAX_HASH: raise BudgetExceeded('Hash budget reached; remaining selected hashes are unverified.')
            self.hashed += count
        else:
            if self.read + count > MAX_READ: raise BudgetExceeded('Metadata read budget reached; coverage is partial.')
            self.read += count

    def update(self, index, total):
        self.check()
        if self.progress and self.clock() - self.last_progress >= .2:
            self.last_progress = self.clock()
            self.progress(f'Installation evidence: {index}/{total} files; {self.read//1024} KiB read; {self.hashed//1024} KiB hashed.')


def _zip_preflight(stream, size):
    if size < 22: raise ValueError('The selected ZIP is incomplete.')
    stream.seek(max(0, size - 65557)); tail = stream.read(65557)
    at = tail.rfind(b'PK\x05\x06')
    if at < 0 or at + 22 > len(tail): raise ValueError('Unsupported ZIP directory.')
    _, disk, directory_disk, count_disk, count, length, offset, comment = struct.unpack_from('<4s4H2IH', tail, at)
    if disk or directory_disk or count != count_disk or count == 65535 or offset == 0xffffffff or length == 0xffffffff:
        raise ValueError('Multi-volume and ZIP64 installation archives are not supported by this bounded inspector.')
    if at + 22 + comment != len(tail) or count > MAX_ENTRIES or length > 4 * 1024**2 or offset + length > size:
        raise ValueError('ZIP directory exceeds its bounded inspection limits.')


class InstallationSource:
    def __init__(self, target, budget):
        self.path = assert_no_links(local_path(target)); self.budget = budget
        self.kind = 'folder' if self.path.is_dir() else 'zip'
        self.entries = {}; self.directories = {}; self.complete = True; self.findings = []
        self.archive = None; self.stream_context = None; self.enumerated = 0

    def __enter__(self):
        if self.kind == 'zip':
            if self.path.suffix.casefold() != '.zip': raise ValueError('Choose an installation folder or a ZIP archive.')
            self.stream_context = checked_stream(self.path, limit=MAX_SOURCE)
            _, stream, info = self.stream_context.__enter__(); self.identity = fingerprint(info)
            try:
                _zip_preflight(stream, info.st_size); self.archive = zipfile.ZipFile(stream)
                self._zip_inventory()
            except BaseException:
                self.__exit__(*__import__('sys').exc_info()); raise
        else:
            self.identity = fingerprint(self.path.stat()); self._folder_inventory()
        return self

    def __exit__(self, typ, value, trace):
        if self.archive: self.archive.close()
        if self.stream_context: return self.stream_context.__exit__(typ, value, trace)
        return False

    def _zip_inventory(self):
        seen = {}; declared = 0
        if len(self.archive.infolist()) > MAX_ENTRIES:
            raise ValueError('ZIP actual directory count exceeds the bounded installation inventory limit.')
        for entry in self.archive.infolist():
            self.budget.check(); name = safe_member(entry.orig_filename)
            key = name.casefold()
            if key in seen: raise ValueError('ZIP contains duplicate or case-colliding member names.')
            seen[key] = entry.is_dir()
            mode = (entry.external_attr >> 16) & 0xffff
            if stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError('ZIP links and special files are not supported.')
            if entry.is_dir(): continue
            declared += entry.file_size
            if declared > MAX_DECLARED: raise ValueError('ZIP declared contents exceed the installation inventory limit.')
            state = 'encrypted' if entry.flag_bits & 1 else 'observed'
            if entry.file_size > 1024**2 and entry.file_size > max(1, entry.compress_size) * 1000: state = 'limited'
            self.entries[name] = {'size': entry.file_size, 'state': state, 'entry': entry, 'identity': {}}
        for name in seen:
            parts = name.split('/')
            if any('/'.join(parts[:i]) in seen and not seen['/'.join(parts[:i])] for i in range(1, len(parts))):
                raise ValueError('ZIP contains a file/directory path collision.')

    def _folder_inventory(self):
        pending = [(self.path, '')]; seen = set(); declared = 0
        while pending:
            self.budget.check(); directory, prefix = pending.pop()
            assert_no_links(directory)
            before = fingerprint(directory.stat()); self.directories[str(directory)] = before
            try:
                with os.scandir(directory) as scan:
                    children = []
                    for item in scan:
                        self.enumerated += 1
                        if self.enumerated > MAX_ENTRIES:
                            self.complete = False; self.findings.append('Inventory entry limit reached.'); return
                        if len(children) + len(self.entries) + len(pending) > MAX_ENTRIES:
                            self.complete = False; self.findings.append('Inventory entry limit reached.'); return
                        children.append(item)
            except OSError:
                self.complete = False; self.findings.append('A selected directory could not be enumerated.'); continue
            for item in sorted(children, key=lambda i: i.name.casefold()):
                self.budget.check()
                name = prefix + item.name
                try: name = safe_member(name)
                except ValueError:
                    self.complete = False; self.findings.append('An unsafe or excessively nested name was skipped.'); continue
                if name.casefold() in seen:
                    self.complete = False; self.findings.append('Case-colliding filesystem entries were not inspected.'); continue
                seen.add(name.casefold())
                try: info = item.stat(follow_symlinks=False)
                except OSError:
                    self.complete = False; self.findings.append('A filesystem entry became unavailable.'); continue
                if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                    self.complete = False; self.findings.append('A link or reparse point was skipped.'); continue
                if stat.S_ISDIR(info.st_mode): pending.append((Path(item.path), name + '/')); continue
                if not stat.S_ISREG(info.st_mode):
                    self.complete = False; self.findings.append('A special file was skipped.'); continue
                declared += info.st_size
                if declared > MAX_DECLARED:
                    self.complete = False; self.findings.append('Declared inventory size limit reached.'); return
                self.entries[name] = {'size': info.st_size, 'state': 'observed', 'identity': fingerprint(info)}
            if fingerprint(directory.stat()) != before: raise SourceChanged('Installation directory changed during enumeration. Inspect again.')

    @contextmanager
    def reader(self, name, hashing=False):
        record = self.entries[name]
        if record['state'] != 'observed': raise BudgetExceeded('This entry is encrypted or exceeds the bounded member policy.')
        if self.kind == 'zip':
            with self.archive.open(record['entry']) as stream: yield self._prefix_reader(stream, record['size'], hashing)
        else:
            path = self.path.joinpath(*name.split('/'))
            try:
                with checked_stream(path, limit=MAX_DECLARED, expected=record['identity']) as (_, stream, _):
                    def read_at(offset, count):
                        self.budget.check()
                        if offset < 0 or count < 0 or count > MAX_PREFIX or offset + count > record['size']: raise ValueError('Read outside the inspected file bounds.')
                        self.budget.consume(count, hashing); stream.seek(offset); data = stream.read(count)
                        if len(data) != count: raise SourceChanged('An installation file changed while reading. Inspect again.')
                        return data
                    yield read_at
            except (FileNotFoundError, PermissionError): raise

    def _prefix_reader(self, stream, size, hashing):
        cache = bytearray(); position = 0
        def read_at(offset, count):
            nonlocal position
            self.budget.check()
            if offset < 0 or count < 0 or offset + count > size: raise ValueError('Read outside the inspected archive member bounds.')
            end = offset + count
            if not hashing and end > MAX_PREFIX: raise BudgetExceeded('Member prefix exceeds the metadata read limit.')
            if hashing:
                if offset != position: raise ValueError('Hashing requires a single forward read.')
                self.budget.consume(count, True); data = stream.read(count); position += len(data)
                if len(data) != count: raise SourceChanged('An archive member changed while reading.')
                return data
            while len(cache) < end:
                chunk = min(65536, end - len(cache)); self.budget.consume(chunk)
                data = stream.read(chunk)
                if len(data) != chunk: raise SourceChanged('An archive member is truncated.')
                cache.extend(data)
            return bytes(cache[offset:end])
        return read_at

    def text(self, name):
        if self.entries[name]['size'] > TEXT_LIMIT: raise BudgetExceeded('Manifest exceeds the bounded text limit.')
        with self.reader(name) as read: return read(0, self.entries[name]['size']).decode('utf-8-sig')

    def verify(self):
        self.budget.check(); assert_no_links(self.path)
        if fingerprint(self.path.stat()) != self.identity: raise SourceChanged('Selected installation changed during inspection. Inspect again.')
        if self.kind == 'folder':
            for path, original in self.directories.items():
                self.budget.check(); assert_no_links(path)
                if fingerprint(Path(path).stat()) != original: raise SourceChanged('Installation directory changed during inspection. Inspect again.')
            for name, record in self.entries.items():
                self.budget.check(); path = assert_no_links(self.path.joinpath(*name.split('/')))
                if fingerprint(path.stat()) != record['identity']: raise SourceChanged('An inventoried installation file changed. Inspect again.')


def _root_prefix(entries):
    candidates = [n for n in entries if PurePosixPath(n).name.casefold() == 'vrchat.exe']
    if len(candidates) != 1: return '', 'No unique VRChat executable root was established.'
    name = candidates[0]; prefix = name[:-len(PurePosixPath(name).name)]
    if (prefix + 'UnityPlayer.dll').casefold() not in {n.casefold() for n in entries}:
        return prefix, 'The selected root has no observed UnityPlayer.dll.'
    return prefix, ''


def _json_text(source, name):
    text = source.text(name)
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result: raise ValueError('Duplicate manifest key.')
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs)


def _label(value, limit=128):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value): raise ValueError('Unsupported manifest label.')
    return value


def _manifest(source, name):
    lower = name.casefold(); base = PurePosixPath(lower).name
    if base == 'app.info': return {'app_info': [_label(v) for v in source.text(name).splitlines()[:2]]}
    if base == 'boot.config':
        allowed = {'gfx-enable-gfx-jobs', 'gfx-threading-mode', 'wait-for-native-debugger', 'hdr-display-enabled', 'gc-max-time-slice', 'nolog'}
        fields = {}; seen = set()
        for line in source.text(name).splitlines():
            key, sep, value = line.partition('=')
            if not sep: continue
            if key in seen: raise ValueError('Duplicate boot configuration key.')
            seen.add(key)
            if key in allowed: fields[key] = _label(value, 64)
        return {'boot_options': fields, 'interpretation': 'Declared file values; effective runtime settings are unknown.'}
    data = _json_text(source, name)
    if not isinstance(data, dict): raise ValueError('Expected a bounded manifest object.')
    if base == 'scriptingassemblies.json':
        names = data.get('names')
        if not isinstance(names, list) or len(names) > 1024: raise ValueError('Assembly declaration limit exceeded.')
        return {'assembly_count': len(names), 'assemblies': [_label(v) for v in names]}
    if base == 'unitysubsystemsmanifest.json':
        return {'name': _label(data.get('name', '')), 'version': _label(data.get('version', '')),
                'library': _label(data.get('libraryName', '')), 'state': 'declared, not observed active'}
    if base == 'actions.json':
        actions, sets, defaults = data.get('actions', []), data.get('action_sets', []), data.get('default_bindings', [])
        if not all(isinstance(v, list) for v in (actions, sets, defaults)) or len(actions) > 512 or len(sets) > 32 or len(defaults) > 64: raise ValueError('SteamVR declaration limit exceeded.')
        result = {'actions': [], 'action_sets': [], 'default_bindings': []}
        for item in actions:
            if not isinstance(item, dict): raise ValueError('Malformed action declaration.')
            result['actions'].append({'name': _label(item.get('name', ''), 256), 'type': _label(item.get('type', ''), 64)})
        for item in sets:
            if not isinstance(item, dict): raise ValueError('Malformed action-set declaration.')
            result['action_sets'].append({'name': _label(item.get('name', ''), 256), 'usage': _label(item.get('usage', ''), 64)})
        parent = str(PurePosixPath(name).parent)
        for item in defaults:
            if not isinstance(item, dict): raise ValueError('Malformed binding reference.')
            binding = _label(item.get('binding_url', ''), 512); state = 'unavailable'
            try:
                relative = safe_member(binding)
                if '/' in relative: raise ValueError('Bindings must stay in the same declared folder.')
                target = parent + '/' + relative
                if target in source.entries:
                    # Reference is validated only. The ordinary manifest pass reads each known binding once.
                    state = 'present'
            except ValueError: state = 'unsafe reference refused'
            result['default_bindings'].append({'controller_type': _label(item.get('controller_type', ''), 128), 'reference': binding, 'state': state})
        return result
    if '/steamvr/' in lower:
        bindings = data.get('bindings', {})
        if not isinstance(bindings, dict) or len(bindings) > 32: raise ValueError('Binding action-set limit exceeded.')
        return {'controller_type': _label(data.get('controller_type', '')), 'binding_sets': [_label(v, 256) for v in bindings], 'state': 'declared, not active binding evidence'}
    return {}


def inspect_installation(target, *, hash_paths=(), stop=None, progress=None, clock=time.monotonic, wall=time.time):
    budget = Budget(stop, progress, clock)
    if not isinstance(hash_paths, (list, tuple, set, frozenset)) or len(hash_paths) > 32: raise ValueError('Select at most 32 files for this hash task.')
    selected_hashes = {safe_member(p) for p in hash_paths}
    records = []; manifests = {}; findings = []; metadata_complete = True
    with InstallationSource(target, budget) as source:
        prefix, root_note = _root_prefix(source.entries)
        if root_note: findings.append(root_note)
        if any(p not in source.entries and prefix + p not in source.entries for p in selected_hashes): raise ValueError('A selected hash file is outside this installation inventory.')
        selected_hashes = {p if p in source.entries else prefix + p for p in selected_hashes}
        def priority(name):
            base = PurePosixPath(name).name.casefold()
            return (0 if base in ('vrchat.exe', 'unityplayer.dll', 'unitycrashhandler64.exe') else 1 if name.endswith(('.json', '.config', '.info')) else 2, name.casefold())
        for index, name in enumerate(sorted(source.entries, key=priority)):
            budget.update(index, len(source.entries)); item = source.entries[name]; role = role_for(name); state = item['state']; metadata = {}; digest = ''
            if state != 'observed': metadata_complete = False
            try:
                if state == 'observed' and name.casefold().endswith(('.dll', '.exe')):
                    # Large native game code is never analyzed beyond the PE file header.
                    detail = PurePosixPath(name).name.casefold() != 'gameassembly.dll' and (role in ('main executable', 'Unity engine', 'crash helper') or item['size'] <= 4 * 1024**2)
                    with source.reader(name) as read:
                        try: metadata = inspect_pe(read, item['size'], details=detail)
                        except BudgetExceeded:
                            metadata_complete = False
                            metadata = {'state': 'limited', 'errors': ['metadata_read_budget'], 'signature_trust': 'unverified'}
                    if metadata.get('state') not in ('parsed',): metadata_complete = False
                elif state == 'observed' and role in ('engine configuration', 'declared assemblies', 'declared XR manifest', 'declared VR bindings'):
                    metadata = _manifest(source, name); manifests[name] = metadata
                if name in selected_hashes:
                    hashed = sha256(); offset = 0
                    with source.reader(name, hashing=True) as read:
                        while offset < item['size']:
                            amount = min(1024**2, item['size'] - offset); hashed.update(read(offset, amount)); offset += amount
                            budget.update(index, len(source.entries))
                    digest = hashed.hexdigest()
            except InspectionCancelled: raise
            except SourceChanged: raise
            except BudgetExceeded:
                metadata_complete = False; state = 'limited'
            except (OSError, UnicodeError, ValueError, json.JSONDecodeError, zipfile.BadZipFile, RuntimeError):
                metadata_complete = False; state = 'unreadable'
            records.append(InstallationFile(name, item['size'], role, state, encoded(metadata), digest, encoded(item['identity'])))
        source.verify()
        findings.extend(source.findings)
        architectures = {}; engines = []
        for record in records:
            architecture = record.metadata.get('architecture')
            if architecture: architectures[architecture] = architectures.get(architecture, 0) + 1
            if record.role in ('main executable', 'Unity engine', 'crash helper'):
                value = record.metadata.get('version_strings', {}).get('ProductVersion')
                if isinstance(value, str) and ENGINE.fullmatch(value): engines.append(value)
        unique_engines = sorted(set(engines))
        main = [r for r in records if r.role == 'main executable']; engine_files = [r for r in records if r.role == 'Unity engine']
        if len(main) == len(engine_files) == 1:
            a, b = main[0].metadata.get('architecture'), engine_files[0].metadata.get('architecture')
            if a and b and a != b: findings.append('Main executable and Unity engine declare different architectures; verify this selected installation.')
        canonical_engines = {re.sub(r'(?:_| \()([0-9a-f]{12})\)?$', r' \1', v) for v in unique_engines}
        if len(canonical_engines) > 1: findings.append('Engine version strings differ; review each source. Formatting differences alone do not establish damage.')
        hashed_count = sum(bool(r.sha256) for r in records)
        summary = {'engine_versions': unique_engines, 'application_release': 'unknown', 'steam_build_id': 'unknown',
            'architectures': architectures, 'file_count': len(records), 'bytes': sum(r.size for r in records),
            'il2cpp_layout': any(r.role == 'native game assembly' for r in records) and any(r.role == 'IL2CPP metadata' for r in records),
            'selected_hash_count': len(selected_hashes), 'completed_hash_count': hashed_count,
            'role_counts': {role: sum(r.role == role for r in records) for role in sorted({r.role for r in records})}}
        return InstallationSnapshot(uuid.uuid4().hex, wall(), str(source.path), source.kind, prefix,
            encoded(source.identity), tuple(sorted(records, key=lambda r:r.path.casefold())), source.complete,
            metadata_complete, tuple(dict.fromkeys(findings)), encoded(summary), encoded(manifests), budget.read, budget.hashed)


def associate_runtime(snapshot, runtime, *, now=None, wall=None):
    """Fresh exact process identity only; never overwrite runtime fields."""
    result = {'state': 'unverified', 'snapshot_id': snapshot.id, 'file_engine_versions': snapshot.summary.get('engine_versions', []), 'runtime_engine_version': None}
    now = time.monotonic() if now is None else now
    wall = time.time() if wall is None else wall
    if not 0 <= wall - snapshot.observed_at <= 300: return dict(result, reason='Installation observation expired; inspect again.')
    identity, at = runtime.get('identity'), runtime.get('process_at')
    if snapshot.source_kind != 'folder': return dict(result, reason='An archive is offline evidence.')
    if not isinstance(identity, (tuple, list)) or len(identity) != 3 or not isinstance(at, (int, float)) or not 0 <= now - at <= 5 or runtime.get('state') == 'UNKNOWN':
        return dict(result, reason='No fresh exact runtime process observation.')
    mains = [r for r in snapshot.files if r.role == 'main executable']
    if len(mains) != 1: return dict(result, reason='No unique inspected executable.')
    try:
        root = assert_no_links(Path(snapshot.source)); expected = assert_no_links(root.joinpath(*mains[0].path.split('/')))
        actual = assert_no_links(local_path(identity[2]))
        if os.path.normcase(str(actual)) != os.path.normcase(str(expected)): return dict(result, reason='Runtime executable is outside the selected exact root.')
        if fingerprint(root.stat()) != json.loads(snapshot.root_identity_json): return dict(result, reason='The selected root changed; inspect again.')
        for item in snapshot.files:
            if item.role == 'Unity engine':
                engine = assert_no_links(root.joinpath(*item.path.split('/')))
                if fingerprint(engine.stat()) != json.loads(item.identity_json): return dict(result, reason='The inspected Unity engine changed; inspect again.')
        if fingerprint(expected.stat()) != json.loads(mains[0].identity_json): return dict(result, reason='The inspected executable changed; inspect again.')
        if not isinstance(identity[0], int) or identity[0] <= 0 or not isinstance(identity[1], (float, int)) or identity[1] <= 0:
            return dict(result, reason='Process start identity is unavailable.')
    except (OSError, ValueError): return dict(result, reason='Executable identity could not be rechecked.')
    field = runtime.get('fields', {}).get('unity_version', {}).get('value')
    if isinstance(field, str) and ENGINE.fullmatch(field): result['runtime_engine_version'] = field
    return dict(result, state='associated', reason='Fresh process PID/start identity and exact unchanged executable match this selected folder.', runtime_generation=runtime.get('generation'))
