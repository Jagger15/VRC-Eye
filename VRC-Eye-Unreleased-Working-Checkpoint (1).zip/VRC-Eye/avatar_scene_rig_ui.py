"""Local joint inspection with explicitly applied, reversible pose controls."""
from companion_ui import Table,button,choice
from friendly_ui import flow_line as line
from avatar_scene_deform import joint_rows
from avatar_scene_pose import DEFAULT


class RigInspection:
    def __init__(self,controls):
        self.controls=controls;self.page=page=controls.page;self.node=None;self.joint=None;self.rigs={};self.node_choices={}
        self.box=page.ttk.Frame(controls.box)
        page.ttk.Label(self.box,text='Bones and blendshapes',style='Heading.TLabel').pack(anchor='w')
        page.ttk.Label(self.box,text='Pose and shape controls affect this preview only. Apply is explicit and cancellable; Reset returns to the imported pose. Influence counts cover retained vertices. No animation, IK, PhysBones or source editing.',wraplength=1000).pack(anchor='w',pady=4)
        self.joints=Table(page,self.box,(('name','Joint',210),('skin','Skin',160),('vertices','Influenced vertices',140),('weight','Maximum weight',130)),height=6,select=self.select_joint)
        self.joint_detail=page.tk.StringVar(value='')
        page.ttk.Label(self.box,textvariable=self.joint_detail,wraplength=1000,justify='left').pack(anchor='w')
        self.pose_vars={}
        for key,label in (('translation','Local offset (meters, -10 to 10)'),('rotation','Local rotation (degrees, -180 to 180)'),('scale','Local scale multiplier (0.01 to 10)')):
            row=line(page,self.box);page.ttk.Label(row,text=label).pack(side='left')
            self.pose_vars[key]=[]
            for axis,value in zip('XYZ',DEFAULT[key]):
                page.ttk.Label(row,text=axis).pack(side='left')
                var=page.tk.StringVar(value=str(value));self.pose_vars[key].append(var)
                page.ttk.Entry(row,textvariable=var,width=8).pack(side='left')
        page.ttk.Label(self.box,text='Offsets use the imported joint’s local axes. Rotations apply X, then Y, then Z; child joints and attached meshes follow.',wraplength=1000).pack(anchor='w')
        row=line(page,self.box)
        button(page,row,'Apply selected joint',self.apply_joint)
        button(page,row,'Reset selected joint',self.reset_joint)
        button(page,row,'Reset all joint poses',lambda:controls.set_joints({}))
        row=line(page,self.box);page.ttk.Label(row,text='Morph mesh node').pack(side='left')
        self.node_value=page.tk.StringVar(value='')
        self.node_picker=choice(page,row,self.node_value,(),self.select_node,width=45)
        self.morphs=Table(page,self.box,(('name','Blendshape / position target',270),('default','Imported weight',130),('current','Preview weight',130)),height=5,select=self.select_morph)
        row=line(page,self.box);self.amount=page.tk.StringVar(value='0')
        page.ttk.Label(row,text='Selected weight (-4 to 4)').pack(side='left')
        page.ttk.Entry(row,textvariable=self.amount,width=10).pack(side='left')
        self.slider_value=page.tk.StringVar(value='0')
        self.slider=page.ttk.Scale(row,from_=-4,to=4,variable=self.slider_value,command=lambda v:self.amount.set(f'{float(v):.4f}'),takefocus=True)
        self.slider.pack(side='left',fill='x',expand=True)
        button(page,row,'Apply selected weight',self.apply)
        row=line(page,self.box)
        button(page,row,'Zero this node’s weights',self.zero)
        button(page,row,'Reset all imported weights',lambda:controls.set_morphs({}))
        button(page,row,'Close bone inspector',self.hide)

    def show(self):
        self.controls.require();scene=self.controls.scene;self.rigs={p.node:p.rig for p in scene.parts if p.rig and p.rig.morph_names}
        rows=joint_rows(scene);self.joints.set(rows,lambda r:(r['name'],r['skin_name'],r['vertices'],f"{r['maximum_weight']:.4f}"),identity=lambda r:f"{r['skin']}:{r['joint']}")
        names={n.index:n.name for n in scene.nodes}
        self.node_choices={f'{n}: {names[n]}':n for n in sorted(self.rigs)}
        self.node_picker.configure(values=tuple(self.node_choices))
        selected=self.controls.selected_or_none()
        self.node_value.set(next((label for label,n in self.node_choices.items() if n==selected),next(iter(self.node_choices),'')))
        self.joint_detail.set(f'{len(rows)} joint references; {len(self.rigs)} morph-bearing mesh nodes. Select a joint to inspect its bind matrix.')
        self.select_node();self.box.pack(fill='both',expand=True,pady=8)

    def hide(self):
        self.node=None;self.joint=None;self.rigs={};self.node_choices={};self.node_value.set('');self.amount.set('0');self.slider_value.set('0')
        self.refresh_joint()
        self.joints.set([],lambda r:());self.morphs.set([],lambda r:());self.joint_detail.set('');self.box.pack_forget()

    def select_joint(self):
        self.controls.require();row=self.joints.selected()
        if not row:return
        self.joint=row['node'];self.refresh_joint()
        self.controls.tree.selection_set('n'+str(row['node']));self.controls.select()
        self.describe_joint()

    def describe_joint(self):
        row=self.joints.selected()
        if row is None:return
        current=next(n.matrix[12:15] for n in self.controls.display_scene.nodes if n.index==row['node'])
        self.joint_detail.set(f"{row['name']} · node {row['node']} · parent {row['parent']}\nImported world position: {row['world_position']}\nPreview world position: {current}\nInverse bind matrix (column-major): {row['inverse_bind']}")

    def refresh_joint(self):
        values=self.controls.joint_overrides.get(self.joint,DEFAULT)
        for key,variables in self.pose_vars.items():
            for var,value in zip(variables,values[key]):var.set(f'{value:g}')

    def refresh_pose(self):
        self.refresh_weights();self.refresh_joint();self.describe_joint()

    def apply_joint(self):
        self.controls.require()
        if self.joint is None:raise ValueError('Select a skin joint first.')
        try:values={key:tuple(float(var.get()) for var in variables) for key,variables in self.pose_vars.items()}
        except ValueError:raise ValueError('Joint offsets must be numeric.') from None
        self.controls.set_joints(dict(self.controls.joint_overrides)|{self.joint:values})

    def reset_joint(self):
        self.controls.require()
        if self.joint is None:raise ValueError('Select a skin joint first.')
        self.controls.set_joints({key:value for key,value in self.controls.joint_overrides.items() if key!=self.joint})

    def select_node(self):
        self.controls.require();self.node=self.node_choices.get(self.node_value.get());self.refresh_weights()

    def refresh_weights(self):
        if self.node is None:self.morphs.set([],lambda r:());return
        rig=self.rigs[self.node];current=self.controls.morph_overrides.get(self.node,rig.morph_weights)
        rows=[dict(index=i,name=n,default=rig.morph_weights[i],current=current[i]) for i,n in enumerate(rig.morph_names)]
        self.morphs.set(rows,lambda r:(r['name'],f"{r['default']:.4f}",f"{r['current']:.4f}"),identity=lambda r:str(r['index']))

    def select_morph(self):
        self.controls.require();row=self.morphs.selected()
        if row:self.slider_value.set(str(row['current']));self.amount.set(str(row['current']))

    def apply(self):
        self.controls.require();row=self.morphs.selected()
        if self.node is None or row is None:raise ValueError('Select a mesh node and a blendshape first.')
        weights=list(self.controls.morph_overrides.get(self.node,self.rigs[self.node].morph_weights))
        weights[row['index']]=float(self.amount.get())
        self.controls.set_morphs(dict(self.controls.morph_overrides)|{self.node:tuple(weights)})

    def zero(self):
        self.controls.require()
        if self.node is None:raise ValueError('Select a morph mesh node first.')
        self.controls.set_morphs(dict(self.controls.morph_overrides)|{self.node:(0.,)*len(self.rigs[self.node].morph_names)})
