"""Reviewed, bounded VPM operations on NEW copies, never original projects.

A selected installed CLI is trusted executable code, not a sandbox. Hash checks
bind reviews to the chosen binary; they do not certify its publisher. No shell,
silent installs, forced removal, credentials, automatic Unity launch or publishing.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import threading
import time
import uuid

from creator_projects import (PACKAGE_NAME, SKIP_DIRECTORIES, assert_no_links, cancelled,
                              inspect_project, local_path, read_bytes)

MAX_ENTRIES = 50_000
MAX_BYTES = 8 * 1024 ** 3
EXACT_VERSION = re.compile(r'\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?\Z')
OPERATIONS = ('Copy only', 'Restore packages', 'Set package version', 'Remove package')
TEMPLATES = ('Base', 'Avatar', 'World', 'UdonSharp')


@dataclass(frozen=True)
class ToolInfo:
    path: str
    digest: str
    version: str
    capabilities: tuple[str, ...]


@dataclass(frozen=True)
class TreeEntry:
    relative: str
    directory: bool
    size: int = 0
    digest: str = ''


@dataclass(frozen=True)
class ProjectPlan:
    id: str
    source: str
    destination: str
    operation: str
    entries: tuple[TreeEntry, ...]
    source_digest: str
    total_bytes: int
    tool: ToolInfo | None
    package: str = ''
    version: str = ''
    template: str = ''

    def command(self):
        if self.operation == 'Copy only':
            return ()
        if not self.tool:
            raise ValueError('Review an installed VPM CLI before preparing this operation.')
        if self.operation == 'Restore packages':
            return (self.tool.path, 'resolve', 'project', self.destination)
        if self.operation == 'Set package version':
            return (self.tool.path, 'add', 'package', self.package + '@' + self.version, '-p', self.destination)
        if self.operation == 'Remove package':
            return (self.tool.path, 'remove', 'package', self.package, '-p', self.destination)
        if self.operation == 'Create from template':
            target = Path(self.destination)
            return (self.tool.path, 'new', target.name, self.template, '-p', str(target.parent))
        raise ValueError('Unsupported project operation.')

    def review_text(self):
        title = ('Create a NEW project from a VPM template.' if self.template else
                 'Copy the approved source, then operate ONLY on the new copy.')
        command = subprocess.list2cmdline(self.command()) if self.command() else 'No external command.'
        return (f'{title}\n\nOperation: {self.operation}\nSource: {self.source or "Installed VPM template"}\n'
                f'Destination: {self.destination}\nFiles/directories: {len(self.entries):,}\n'
                f'Source data: {self.total_bytes / 1024**2:,.1f} MiB\n\n{command}\n\n'
                'The original project is NOT changed. Close Unity and other project managers first. '
                'Library, Temp, Logs, Obj and version-control databases are excluded from copies. '
                'Other source files, including project-contained private data, remain in the local copy.\n\n'
                'VPM may download dependencies, update its own caches/settings, and remove legacy packages '
                'inside the COPY. The CLI does not supply a verified dependency dry-run here: the full '
                'dependency diff is unknown until execution. No force removal or automatic Unity launch is used.\n\n'
                'This is not an operating-system sandbox. Only approve a CLI and project you trust. '
                'A failed or canceled operation can leave a partial copy for inspection; it is not auto-deleted. '
                'Successful CLI exit is not proof of a successful Unity compile or VRChat upload.')


def _file_hash(path, stop=None, output=None):
    path = assert_no_links(path)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0))
    sha = hashlib.sha256()
    total = 0
    with os.fdopen(descriptor, 'rb') as source:
        before = os.fstat(source.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_BYTES:
            raise ValueError('Copy supports bounded regular files only.')
        while True:
            cancelled(stop)
            data = source.read(1024 * 1024)
            if not data:
                break
            total += len(data)
            if total > MAX_BYTES:
                raise ValueError('A project file exceeds the copy budget.')
            sha.update(data)
            if output:
                output.write(data)
        after = os.fstat(source.fileno())
    current = path.stat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
    if identity(before) != identity(after) or identity(after) != identity(current):
        raise ValueError('The source changed while being copied or reviewed. Prepare a fresh review.')
    return total, sha.hexdigest()


def tree_snapshot(path, *, stop=None, progress=lambda text: None):
    root = assert_no_links(local_path(path))
    if not root.is_dir():
        raise ValueError('The source project is unavailable.')
    entries, pending = [], [root]
    total = 0
    while pending:
        cancelled(stop)
        folder = pending.pop()
        assert_no_links(folder)
        with os.scandir(folder) as stream:
            children = []
            for child in stream:
                if folder == root and child.name in SKIP_DIRECTORIES:
                    continue
                if len(children) + len(entries) + len(pending) >= MAX_ENTRIES:
                    raise ValueError('Project copy exceeds 50,000 entries. Use VCC directly for this project.')
                children.append(child)
        for child in sorted(children, key=lambda x: x.name):
            cancelled(stop)
            item = assert_no_links(Path(child.path))
            relative = str(item.relative_to(root)).replace(os.sep, '/')
            info = child.stat(follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                entries.append(TreeEntry(relative, True))
                pending.append(item)
            elif stat.S_ISREG(info.st_mode):
                size, digest = _file_hash(item, stop)
                total += size
                if total > MAX_BYTES:
                    raise ValueError('Project copy exceeds the 8 GiB source budget. Use VCC directly for this project.')
                entries.append(TreeEntry(relative, False, size, digest))
            else:
                raise ValueError('Project contains a non-regular file. No special files are copied.')
            if len(entries) > MAX_ENTRIES:
                raise ValueError('Project copy entry limit exceeded.')
            if len(entries) % 100 == 0:
                progress(f'Reviewing source: {len(entries):,} entries, {total / 1024**2:,.1f} MiB')
    entries.sort(key=lambda entry: entry.relative)
    raw = json.dumps([(e.relative, e.directory, e.size, e.digest) for e in entries], separators=(',', ':')).encode()
    return tuple(entries), hashlib.sha256(raw).hexdigest(), total


def tool_digest(path):
    path = assert_no_links(local_path(path))
    if not path.is_file() or path.name.casefold() not in ('vpm', 'vpm.exe', 'unity', 'unity.exe'):
        raise ValueError('Select the installed vpm or Unity executable, not a script, installer, or arbitrary command.')
    if os.name != 'nt' and not os.access(path, os.X_OK):
        raise ValueError('The selected tool is not executable.')
    return hashlib.sha256(read_bytes(path, 256 * 1024 * 1024)).hexdigest()


def run_bounded(command, *, cwd, stop=None, timeout=600, output_limit=65536):
    """Drain bounded output; stop the subprocess/group before abandoning a run.

    Only installed, explicitly reviewed VPM/Unity tools reach this runner from the
    UI. It is not an OS sandbox. Windows descendant completion is unverified.
    """
    cancelled(stop)
    if not command or not Path(command[0]).is_absolute():
        raise ValueError('An absolute reviewed executable is required.')
    if not 0 < timeout <= 600 or type(output_limit) is not int or not 1 <= output_limit <= 65536:
        raise ValueError('Invalid external-tool execution budget.')
    options = dict(cwd=str(cwd), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                   stderr=subprocess.STDOUT, shell=False, bufsize=0)
    if os.name == 'nt':
        options['creationflags'] = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        options['start_new_session'] = True
    process = subprocess.Popen(list(command), **options)
    output = bytearray()
    overflow = threading.Event()

    def drain():
        try:
            while True:
                block = process.stdout.read(4096)
                if not block:
                    return
                if len(output) + len(block) > output_limit:
                    overflow.set()
                if len(output) < output_limit:
                    output.extend(block[:output_limit - len(output)])
        except (OSError, ValueError):
            pass

    def terminate():
        # On POSIX the group may outlive its root; do not test only root.poll().
        if os.name != 'nt':
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        elif process.poll() is None:
            process.terminate()
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            pass
        if os.name != 'nt':
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        elif process.poll() is None:
            process.kill()
        process.wait(timeout=3)

    reader = threading.Thread(target=drain, name='VRC-Eye-VPM-output', daemon=True)
    reader.start()
    deadline = time.monotonic() + timeout
    success = False
    try:
        while process.poll() is None:
            if stop is not None and stop.is_set():
                raise ValueError('Canceled; the new copy may be incomplete.')
            if time.monotonic() >= deadline:
                raise ValueError('Tool timed out; the new copy may be incomplete.')
            if overflow.is_set():
                raise ValueError('Tool output exceeded the safety limit; inspect the new copy before continuing.')
            time.sleep(.02)
        reader.join(min(1, max(.05, deadline-time.monotonic())))
        if reader.is_alive() or overflow.is_set():
            raise ValueError('Tool output did not close cleanly or exceeded the safety limit; result unverified.')
        cancelled(stop)
        success = True
        return process.returncode, bytes(output).decode('utf-8', 'replace')
    except ValueError as error:
        if os.name == 'nt':
            raise ValueError(str(error) + ' External child-process completion is unverified on Windows.') from error
        raise
    finally:
        if not success:
            terminate()
            reader.join(1)
        if process.stdout:
            process.stdout.close()


def probe_vpm(path, *, stop=None, runner=run_bounded):
    path = assert_no_links(local_path(path))
    if path.name.casefold() not in ('vpm', 'vpm.exe'):
        raise ValueError('Choose the installed VPM CLI executable, not the Creator Companion GUI.')
    fingerprint = tool_digest(path)
    code, help_text = runner((str(path), '--help'), cwd=path.parent, stop=stop, timeout=15)
    if code != 0 or not all(re.search(r'\b' + word + r'\b', help_text, re.I) for word in ('project', 'package')):
        raise ValueError('This executable did not report a recognized VPM help interface. Use VCC directly.')
    capabilities = []
    for operation, terms in (('Restore packages', ('resolve',)), ('Set package version', ('add',)),
                             ('Remove package', ('remove',)), ('Create from template', ('new',))):
        if all(re.search(r'\b' + term + r'\b', help_text, re.I) for term in terms):
            capabilities.append(operation)
    code, reported = runner((str(path), '--version'), cwd=path.parent, stop=stop, timeout=15)
    version = next((line.strip() for line in reported.splitlines() if re.fullmatch(r'[0-9][0-9A-Za-z.+-]{0,79}', line.strip())), 'Unreported') if code == 0 else 'Unreported'
    if tool_digest(path) != fingerprint:
        raise ValueError('The tool changed during inspection. Review it again.')
    return ToolInfo(str(path), fingerprint, version, tuple(capabilities))


def _destination(source, destination):
    source = local_path(source) if source else None
    target = assert_no_links(local_path(destination))
    if target.exists():
        raise ValueError('Destination already exists. A new, empty project path is required.')
    if not target.parent.is_dir():
        raise ValueError('Choose an existing destination parent folder.')
    if source and target.is_relative_to(source):
        raise ValueError('The new copy must be outside the original project.')
    return target


def _closed_project(source):
    # This is a conservative preflight, not a lock shared with Unity or VCC.
    if (source / 'Temp' / 'UnityLockfile').exists():
        raise ValueError('A Unity lock file is present. Close the editor and inspect the project before retrying.')


def make_plan(source, destination, operation, *, tool=None, package='', version='', stop=None, progress=lambda text: None):
    if operation not in OPERATIONS:
        raise ValueError('Choose a supported copy-only project operation.')
    root = assert_no_links(local_path(source))
    target = _destination(root, destination)
    _closed_project(root)
    snapshot = inspect_project(root, stop=stop)
    if snapshot['state'] == 'Unavailable':
        raise ValueError('The source project is unavailable.')
    if operation != 'Copy only':
        if tool is None or operation not in tool.capabilities or tool_digest(tool.path) != tool.digest:
            raise ValueError('The installed CLI must be reviewed and advertise this operation.')
    if operation in ('Set package version', 'Remove package'):
        if not isinstance(package, str) or not PACKAGE_NAME.fullmatch(package):
            raise ValueError('Use a package identifier, not a URL, path, or command.')
    if operation == 'Set package version' and (not isinstance(version, str) or not EXACT_VERSION.fullmatch(version)):
        raise ValueError('Select an exact semantic version; latest, ranges and shell arguments are not accepted.')
    if operation == 'Remove package' and package not in {p['name'] for p in snapshot['packages']}:
        raise ValueError('The selected package is not in the inspected project inventory.')
    if operation == 'Restore packages' and not (root / 'Packages' / 'vpm-manifest.json').is_file():
        raise ValueError('This project has no VPM manifest to restore. Legacy migration remains a VCC handoff.')
    entries, digest, total = tree_snapshot(root, stop=stop, progress=progress)
    return ProjectPlan(str(uuid.uuid4()), str(root), str(target), operation, entries, digest, total,
                       tool if operation != 'Copy only' else None, package, version)


def make_template_plan(destination, template, tool):
    target = _destination(None, destination)
    if not re.fullmatch(r'(?![-.])[\w -]{1,80}', target.name):
        raise ValueError('Use a template project name with letters, numbers, spaces, underscores or hyphens.')
    if template not in TEMPLATES or not tool or 'Create from template' not in tool.capabilities:
        raise ValueError('Review a VPM CLI with the new-project capability and choose a supported template.')
    if tool_digest(tool.path) != tool.digest:
        raise ValueError('The tool changed. Review it again.')
    return ProjectPlan(str(uuid.uuid4()), '', str(target), 'Create from template', (), '', 0, tool, template=template)


class ProjectJobs:
    """Single-use reviews and cross-instance VRC Eye reservation files."""
    def __init__(self, data_folder):
        self.folder = local_path(data_folder)
        self.plans = {}
        self.lock = threading.Lock()

    def offer(self, plan):
        if not isinstance(plan, ProjectPlan):
            raise ValueError('Invalid project review.')
        with self.lock:
            if len(self.plans) >= 32:
                self.plans.clear()
            self.plans[plan.id] = plan
        return plan

    def discard(self, plan):
        with self.lock:
            self.plans.pop(plan.id, None)

    def execute(self, plan, *, stop=None, progress=lambda text: None, runner=run_bounded):
        with self.lock:
            if self.plans.pop(plan.id, None) is not plan:
                raise ValueError('The review is no longer available. Prepare a new review; jobs are never replayed automatically.')
        cancelled(stop)
        target = _destination(plan.source, plan.destination)
        if plan.tool and tool_digest(plan.tool.path) != plan.tool.digest:
            raise ValueError('The reviewed CLI changed. No command was submitted.')
        locks = assert_no_links(self.folder / 'creator-project-locks')
        locks.mkdir(parents=True, exist_ok=True)
        key = hashlib.sha256(os.path.normcase(plan.source or plan.destination).encode()).hexdigest()
        lockfile = locks / (key + '.lock')
        try:
            descriptor = os.open(lockfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as error:
            raise ValueError('Another VRC Eye project job or an unreconciled reservation exists. No second job was started.') from error
        with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
            json.dump(dict(schema=1, operation=plan.operation, review=plan.id, started=time.time()), stream)
        receipt = dict(schema=1, operation=plan.operation, destination=plan.destination,
                       source_digest=plan.source_digest, state='Not submitted',
                       tool_version=plan.tool.version if plan.tool else '', cli_exit=None,
                       original_modified_by_vrc_eye=False, checked=time.time(), message='')
        try:
            if plan.source:
                source = assert_no_links(local_path(plan.source))
                _closed_project(source)
                _, fresh_digest, _ = tree_snapshot(source, stop=stop, progress=progress)
                if fresh_digest != plan.source_digest:
                    raise ValueError('Source changed since review. No copy or CLI operation was started.')
                if shutil.disk_usage(target.parent).free < plan.total_bytes * 2 + 256 * 1024 ** 2:
                    raise ValueError('Insufficient destination free space for the copy and conservative working allowance.')
                target.mkdir(exist_ok=False)
                receipt['state'] = 'Copying'
                for index, entry in enumerate(plan.entries):
                    cancelled(stop)
                    full = assert_no_links(target / entry.relative)
                    if entry.directory:
                        full.mkdir(parents=True, exist_ok=True)
                    else:
                        full.parent.mkdir(parents=True, exist_ok=True)
                        with full.open('xb') as output:
                            size, digest = _file_hash(source / entry.relative, stop, output)
                        if (size, digest) != (entry.size, entry.digest):
                            raise ValueError('Source changed during the copy. No CLI command was submitted.')
                        shutil.copystat(source / entry.relative, full, follow_symlinks=False)
                    if index % 100 == 0:
                        progress(f'Copying: {index + 1:,} / {len(plan.entries):,} entries')
                _, final_digest, _ = tree_snapshot(source, stop=stop, progress=progress)
                if final_digest != plan.source_digest:
                    raise ValueError('Source changed during copying. Inspect the partial copy; no CLI command was submitted.')
                receipt['state'] = 'Copied'
            cancelled(stop)
            if plan.tool:
                if tool_digest(plan.tool.path) != plan.tool.digest:
                    raise ValueError('The CLI changed after copying. No command was submitted.')
                progress('Running the reviewed VPM operation on the NEW project. The original remains untouched.')
                receipt['state'] = 'Submitted; result unverified'
                code, _ = runner(plan.command(), cwd=target.parent, stop=stop, timeout=600)
                receipt['cli_exit'] = code
                if code != 0:
                    raise ValueError('The CLI returned a nonzero exit code. No automatic retry; inspect the new project.')
            snapshot = inspect_project(target, stop=stop)
            if snapshot['state'] == 'Unavailable':
                raise ValueError('The requested destination was not produced. CLI outcome is unverified.')
            receipt['state'] = 'Copy ready' if not plan.tool else 'CLI completed; Unity validation required'
            receipt['message'] = 'Original project not modified by VRC Eye. New project manifests were inspected; Unity compilation was not tested.'
            return receipt, snapshot
        except Exception as error:
            receipt['message'] = str(error) if isinstance(error, (ValueError, OSError)) else 'Unexpected local job failure; inspect the new copy.'
            receipt['state'] = ('Failed or canceled before submission' if receipt['cli_exit'] is None and not receipt['state'].startswith('Submitted') else 'Failed or incomplete; inspect copy')
            return receipt, None
        finally:
            # Receipt path is app-owned, not placed in an untrusted source project.
            try:
                receipt_dir = assert_no_links(self.folder / 'creator-project-receipts')
                receipt_dir.mkdir(parents=True, exist_ok=True)
                with (receipt_dir / (plan.id + '.json')).open('x', encoding='utf-8') as stream:
                    json.dump(receipt, stream, ensure_ascii=False, indent=2)
            finally:
                lockfile.unlink(missing_ok=True)
