"""Start VRC Eye with an app-local, automatically prepared Python environment.

Only this launcher prepares packages. Importing application modules, starting
Safe Mode/Demo, and help/version commands never install anything. Setup failure
leaves local workspaces intact and falls back to the available core application.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import subprocess
import sys


SKIP_SETUP = frozenset(("--safe-mode", "--demo", "--help", "-h", "--version"))
ENVIRONMENT = ".recovery-env"  # Reuse environments created by earlier releases.
PROBE_TIMEOUT = 20
CREATE_TIMEOUT = 90
INSTALL_TIMEOUT = 300
PILLOW_INSTALL_TIMEOUT = 120
CHILD_READY = "VRC_EYE_BOOTSTRAP_COMPLETE"
MANAGED_MARKER = ".vrc-eye-managed"
MARKER_CONTENT = "VRC Eye local environment, created by bootstrap v1\n"

# Probe with the target interpreter: platform markers and package versions must
# refer to the environment we will launch, rather than the bootstrap interpreter.
# pip bundles packaging; this does not invoke a package operation or the network.
PROBE_CODE = r'''
import importlib.metadata, json, os, pathlib, sys, sysconfig
result = {"usable": False, "ready": False, "missing": [], "pillow_broken": False}
try:
    import tkinter
    expected = pathlib.Path(sys.argv[1]).resolve()
    result["usable"] = (sys.version_info >= (3, 10) and
        pathlib.Path(sys.prefix).resolve() == expected and sys.prefix != sys.base_prefix and
        all(pathlib.Path(sysconfig.get_path(key)).resolve().is_relative_to(expected)
            for key in ("purelib", "platlib", "scripts", "data")))
    if result["usable"]:
        try:
            from pip._vendor.packaging.requirements import Requirement
        except ImportError:
            result["missing"] = ["pip or its requirement parser"]
        else:
            raw = pathlib.Path(sys.argv[2]).read_bytes()
            if len(raw) > 32768:
                raise ValueError("Dependency list is too large")
            requirements = [Requirement(line.strip()) for line in raw.decode("utf-8").splitlines()
                            if line.strip() and not line.lstrip().startswith("#")]
            if not requirements:
                raise ValueError("Dependency list is empty")
            for requirement in requirements:
                if requirement.url or requirement.extras:
                    raise ValueError("Unsupported dependency source")
                if requirement.marker and not requirement.marker.evaluate():
                    continue
                try:
                    installed = importlib.metadata.version(requirement.name)
                except importlib.metadata.PackageNotFoundError:
                    result["missing"].append(str(requirement))
                else:
                    if not requirement.specifier.contains(installed):
                        result["missing"].append(str(requirement))
                    elif requirement.name.lower() == "pillow":
                        try:
                            from PIL import Image, ImageTk
                            if len(Image.new("RGBA", (1, 1)).tobytes()) != 4:
                                raise ImportError("Pillow pixel decoder unavailable")
                        except (ImportError, OSError):
                            result["missing"].append(str(requirement))
                            result["pillow_broken"] = True
            result["ready"] = not result["missing"]
except Exception:
    result["ready"] = False
    result["missing"] = ["environment or dependency check unavailable"]
print(json.dumps(result))
'''


class SetupBusy(Exception):
    pass


def environment_python(root):
    folder = Path(root) / ENVIRONMENT
    return folder / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def environment_path_is_local(root):
    # resolve also catches Windows junctions on Python versions without
    # Path.is_junction(). Standard venv executable links remain supported.
    root = Path(root).resolve()
    folder = root / ENVIRONMENT
    try:
        return not folder.is_symlink() and folder.resolve() == folder
    except (OSError, RuntimeError):
        return False


def setup_environment():
    """Keep subprocess setup independent of pip install-directory overrides."""
    environment = {key: value for key, value in os.environ.items()
                   if not key.upper().startswith("PIP_") and key.upper() not in ("PYTHONPATH", "PYTHONHOME")}
    environment["PIP_CONFIG_FILE"] = os.devnull
    environment["PYTHONNOUSERSITE"] = "1"
    return environment


def inspect_environment(root, *, runner=subprocess.run):
    root = Path(root)
    folder = root / ENVIRONMENT
    unavailable = {"usable": False, "ready": False, "missing": ["local environment"]}
    # A linked directory can point outside this application. Never install there.
    if not environment_path_is_local(root) or not environment_python(root).is_file():
        return unavailable
    try:
        result = runner([str(environment_python(root)), "-I", "-c", PROBE_CODE,
                         str(folder.resolve()), str(root / "requirements.txt")],
                        cwd=str(root), capture_output=True, text=True, timeout=PROBE_TIMEOUT,
                        stdin=subprocess.DEVNULL)
        if result.returncode:
            return unavailable
        value = json.loads(result.stdout)
        if (not isinstance(value, dict) or type(value.get("usable")) is not bool
                or type(value.get("ready")) is not bool or not isinstance(value.get("missing"), list)
                or not all(isinstance(item, str) for item in value['missing'])
                or type(value.get('pillow_broken', False)) is not bool):
            return unavailable
        return value
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return unavailable


@contextmanager
def setup_lock(root):
    """An OS-owned lock is released even after a crash; do not unlink live locks."""
    handle = (Path(root) / ".startup.lock").open("a+b")
    acquired = False
    try:
        if handle.seek(0, os.SEEK_END) == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise SetupBusy("Another launch is preparing VRC Eye. Let that window finish first.") from error
        acquired = True
        yield
    finally:
        if acquired:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def prepare_environment(root, *, python=None, runner=subprocess.run, report=print):
    """Return the launch interpreter; pip is restricted to our verified venv."""
    root = Path(root).resolve()
    python = str(python or sys.executable)
    folder = root / ENVIRONMENT
    requirements = root / "requirements.txt"
    # Keep the initial launch interpreter as the fallback; never run global pip.
    if not requirements.is_file():
        report("Dependency list is unavailable. Opening VRC Eye with the available core features.")
        return python
    with setup_lock(root):
        state = inspect_environment(root, runner=runner)
        if state["ready"] and state["usable"]:
            return str(environment_python(root))
        if not state["usable"]:
            owned = False
            marker = folder / MANAGED_MARKER
            try:
                owned = not marker.is_symlink() and marker.read_text() == MARKER_CONTENT
            except (OSError, ValueError):
                pass
            if not environment_path_is_local(root) or folder.exists() and not owned:
                report("The existing local environment could not be used. It was left unchanged; opening core features.")
                return python
            report("First start: preparing VRC Eye's local Python environment...")
            try:
                if not folder.exists():
                    folder.mkdir()
                    marker.write_text(MARKER_CONTENT)
                result = runner([python, "-I", "-m", "venv", str(folder)], cwd=str(root),
                                timeout=CREATE_TIMEOUT, stdin=subprocess.DEVNULL, env=setup_environment())
                if result.returncode:
                    raise OSError("Environment creation did not finish")
            except (OSError, subprocess.TimeoutExpired):
                report("Local setup could not finish. Opening core features without changing your saved data.")
                return python
            state = inspect_environment(root, runner=runner)
            if not state["usable"]:
                report("The new environment is unavailable. Opening core features with the original Python.")
                return python
        target = str(environment_python(root))
        report("Preparing missing or incompatible feature packages. This may take a few minutes and needs internet access.")
        report("Setup stays inside this app folder. Devices and connections remain under your control.")
        try:
            if "pip or its requirement parser" in state["missing"]:
                runner([target, "-I", "-m", "ensurepip", "--upgrade"], cwd=str(root),
                       timeout=CREATE_TIMEOUT, stdin=subprocess.DEVNULL, env=setup_environment())
                state = inspect_environment(root, runner=runner)
                if not state['usable']:
                    report("The local environment could not be verified after setup. Opening core features.")
                    return python
            command = [target, "-I", "-m", "pip", "--isolated", "install", "--disable-pip-version-check", "--no-input", "--no-user",
                       "--only-binary=:all:", "--timeout", "8", "--retries", "0"]
            pillow = next((item for item in state['missing'] if re.fullmatch(r'pillow(?:[<>=!~0-9.,]+)?', item, re.I)), None)
            if pillow:
                # Resolve Pillow independently: an unavailable optional driver
                # wheel must not prevent image support from being installed.
                report("Downloading and installing Pillow for wallpapers and image tools...")
                repair = ['--force-reinstall', '--no-cache-dir'] if state.get('pillow_broken', False) else []
                result = runner(command + ['--no-deps', *repair, pillow], cwd=str(root), timeout=PILLOW_INSTALL_TIMEOUT,
                                stdin=subprocess.DEVNULL, env=setup_environment())
                if result.returncode:
                    report("Pillow could not be downloaded. PNG wallpapers still work; the next normal start will retry.")
                    return target
                state = inspect_environment(root, runner=runner)
                if not state['usable']:
                    report("The local environment could not be verified after setup. Opening core features.")
                    return python
                if any(re.match(r'pillow\b', item, re.I) for item in state['missing']):
                    report("Pillow is still unavailable. PNG wallpapers still work; the next normal start will retry.")
                    return target
                report("Pillow is ready.")
            complete = state['ready']
            if not complete:
                result = runner(command + ["-r", str(requirements)], cwd=str(root), timeout=INSTALL_TIMEOUT,
                                stdin=subprocess.DEVNULL, env=setup_environment())
                complete = result.returncode == 0 and inspect_environment(root, runner=runner)["ready"]
        except (OSError, subprocess.TimeoutExpired):
            complete = False
        if complete:
            report("Setup complete. Starting VRC Eye.")
        else:
            report("Some feature packages are unavailable. Core tools will still open; Start.cmd will retry setup next time.")
        return target


def main(argv=None, *, root=None, python=None, runner=subprocess.run, report=print):
    args = list(sys.argv[1:] if argv is None else argv)
    root = Path(root or Path(__file__).resolve().parent).resolve()
    python = str(python or sys.executable)
    target = python
    try:
        if not any(flag in args for flag in SKIP_SETUP):
            try:
                target = prepare_environment(root, python=python, runner=runner, report=report)
            except SetupBusy as error:
                report(str(error))
                return 0
            except OSError:
                report("Automatic setup is unavailable in this folder. Opening VRC Eye with the available core features.")
        # Launch the application directly; do not recursively restart bootstrap.
        environment = dict(os.environ)
        environment[CHILD_READY] = "1"
        result = runner([target, str(root / "vrc_eye.py"), *args], cwd=str(root), env=environment)
        return result.returncode
    except KeyboardInterrupt:
        report("Startup cancelled.")
        return 130
    except OSError as error:
        report("VRC Eye could not start: " + str(error))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
