> Development 5 adds [navigation shortcut remapping](KEYBOARD_SHORTCUTS_1_20.md)
> and [SDK/VCC download workspaces](RELEASE_DOWNLOADS_1_20.md). The older guide below
> describes the original interface baseline; current defaults remain Ctrl+K and
> Ctrl+Comma, but those main-window shortcuts are now user-configurable.

# VRC Eye 1.19.6.1 — Interface guide

This minor update changes how existing tools are presented. It keeps the
1.19.5 application services, creator workspaces, transport configuration,
permission checks, and Start.cmd startup flow.

## Getting started

Close the previous copy of VRC Eye. Extract the release ZIP into a new folder,
open its VRC-Eye directory, and run Start.cmd. Keep all source files together.
Python 3.10 or newer with Tkinter is still required. Start.cmd retains its
existing automatic dependency preparation. Demo.cmd and Safe-mode.cmd remain
available and do not install dependencies.

Home is the default opening workspace. It summarizes local evidence without
requiring an account, a peer, a bridge or a running game. Sample data, Safe mode,
and a paused view are explicitly identified. A selected log is not proof that
VRChat is currently running. The event counter is the bounded set retained by
the current application view, not a lifetime counter or online population.

Previously stored connection settings are not reset by this update. Existing
automatic startup behavior is unchanged; the new Home screen is not a switch
that disables or enables services.

## Navigation changes

| Previous label | Current location / label |
| --- | --- |
| Primary | Primary → Players & avatars |
| Primary → Avatars | Players & avatars → Avatars |
| Primary → World | Players & avatars → World |
| Feed | Community → Friend activity |
| Search | Community → Search VRChat |
| VRC Eye Primary | VRC Eye → Eye-to-Eye |
| Shared OSC Controls | Eye-to-Eye → OSC Controls |
| OSC host / ports | Networking → OSC transport |
| Top-of-window log path | Settings → Log source |
| VRChat connection | VRChat account… in the sidebar footer or Settings |
| Optional client bridge | Settings → Show technical details → Client bridge… |
| Performance, crash, Unity, VRCX, Game Log | More tools… or Find a tool |

World and Avatar creator features still belong to their original World and
Avatars workspaces. This update does not move them into a separate application.
All old internal page identifiers remain intact for existing callbacks.

## Detail levels

Use the View selector in the top bar or Settings → Appearance.

**Casual** favors everyday navigation and a shorter set of table columns and
tabs. **Advanced** reveals more diagnostic, integration and creator tools.
**Developer** also reveals existing developer-facing pages. These are display
levels, not account roles, entitlements or permission grants.

The workspace selector shows every tab, including hidden tabs marked
“more tools” and disabled tabs marked “unavailable.” Opening a hidden tool
reveals the required level in that workspace without changing the global view.
A disabled tab stays disabled. More tools expands the sidebar without changing
control permissions.

Changing the global detail level deliberately reapplies its visibility defaults.
Changing only spacing, text size or startup page preserves the currently selected
workspace, per-workspace detail level, and expanded avatar details. Selecting
Casual again after another global mode restores the simple default avatar view.

## Find a tool

Press Ctrl+K or click Find a tool. Search matches local titles, workspace paths
and aliases; for example, “microphone,” “photos,” “ports,” “creator” or “log.”
All 57 indexed destinations are searchable regardless of the global view.

Use Down to focus results, Enter to open the selection, and Escape to close.
No matches leaves Open tool disabled. Reopening search brings the same search
window forward rather than creating duplicates. Search does not read peers,
call VRChat, run scripts, arm controls, or perform the action named by a tool.
“OSC Camera,” for example, opens its page; it does not take a photograph.

## Players, avatars and OSC

The Casual avatar table emphasizes Time, Player, Previous avatar, New avatar
and Event. Show all columns restores platform, trust, performance, visibility,
sizes and dates. Data continues to be collected by the existing services; hiding
a column does not delete it. Export behavior is unchanged.

Common avatar actions remain next to the table. Show avatar details and file tools
contains the original date/status, download-size, association, rescue/archive,
diagnostic and detailed-selection tools. Collapsing this area does not destroy
its widgets or change the selected event.

The shared View selection gives the player roster a compact presentation in
Casual without rewriting the roster's persisted preferences. Its existing
Player settings still provide the detailed layout and behavior controls.

OSC Overview uses readable summaries in Casual. Advanced views retain raw
inspection data. Unknown state stays unknown. A send result is not proof of
delivery, execution, microphone state or a rendered effect. OSC transport
settings remain in Networking, and all OSC pages continue to share the same
controller and service. Viewing controls never grants a route permission.

This is a cleanup of the main shell and selected common views. Specialized
creator editors and some dense diagnostic panels retain their established
controls; it is not a complete redesign of every editor.

## Appearance, logs and local preferences

Settings offers Comfortable or Compact spacing, Standard or Larger text, and
Home or Players & avatars as the startup page. Home and Settings are scrollable;
explanations wrap with their cards, including at the 1060 × 720 minimum window.
The sidebar scrolls while Settings and account access remain at the bottom.

Appearance is saved in the existing companion options store under
`ui.presentation`. It includes only schema version, view mode, density, text
size, and startup page. Invalid or unsupported records fall back safely; valid
individual fields survive an otherwise malformed preference record.

Demo and Safe mode apply changes only for the current session. A storage error
leaves the chosen appearance usable for the session and displays a save notice.
Reset appearance only does not reset favorites, profiles, authoring workspaces,
connection configuration, saved permissions, or the selected log source.

Choose folder or Choose file fills the log-source entry. Canceling leaves it
unchanged. Select Watch logs to begin monitoring that selection. The existing
normal-launch log monitoring and Demo behavior are unchanged.

## Versioning and verification

The runtime, peer/bridge version labels, API user agent, OSC diagnostic export
and release filename identify 1.19.6.1. The Unity Avatar Toolkit keeps its
independent package version; no new Unity package build is claimed here.

The release helper accepts X.Y.Z and X.Y.Z.N. For this release,
`python tools/package_release.py --next-minor-version` prints 1.19.6.2 and
`--next-version` prints 1.19.7. Neither command modifies files.

See VALIDATION.md for the checks performed. Native Windows appearance, Windows
DPI scaling, screen-reader behavior, live VRChat, optional hardware and Unity
compilation remain separate runtime verification tasks.


## Version 1.19.9: Remembered sign-in and keyboard login

A small update on 1.19.8. Close the old copy, extract **VRC-Eye-v1.19.9.zip**,
open **VRC-Eye**, and run **Start.cmd**. No launcher or dependency changes.

The existing VRChat connection window now has separate **Remember username** and
**Remember password** checkboxes. Either, both, or neither can be selected.
New values save only after successful sign-in, including verification. Unchecking
an option immediately forgets that stored value without deleting the other one.
**Forget saved sign-in** removes both; Disconnect only discards the current session.

**Enter and keypad Enter** submit sign-in or the requested verification code,
with duplicate-request protection and automatic focus on the code field. Mouse
buttons remain available. There is no automatic sign-in or verification bypass.

Passwords use **Windows Credential Manager**, never plaintext settings. The
username has its own per-user JSON file. Password-only mode leaves the username
blank and checks that untouched autofill belongs to the typed username. A failed
storage operation is reported without breaking an otherwise successful sign-in.
Demo/Safe mode do not read or change saved values. Non-Windows systems support
username remembering and Enter, but password remembering stays disabled.

Read **[LOGIN_GUIDE.md](LOGIN_GUIDE.md)** for the four combinations, storage,
forgetting and validation details. Native Windows storage and live VRChat sign-in
remain untested here; the release uses offline tests and real Tk keyboard checks.

