"""Live friend events and explicit snapshots, with account-scoped local history."""
import json
import time

import companion_api as api
import player_api
from companion_data import entity
from companion_ui import Page, Table, Picture, line, button, entry, choice, note
from automatic_sync import sync_for
from profile_images import fetch_preview, image_url


class FeedPage(Page):
    def context(self):
        from account_header import boundary,private
        from session_restore import offline
        return boundary(self.app),private(self.app),offline(self.app)

    def __init__(self, shell, parent):
        super().__init__(shell, parent, "Feed")
        self.sync=sync_for(shell);self.seen = -1; self.result = None; self.selected_ref = ""
        from native_events import hub_for
        self.hub=hub_for(shell)
        self.kind = self.tk.StringVar(value="Online / website friends"); self.query = self.tk.StringVar(value="")
        self.live_status = self.tk.StringVar(value=self.sync.summary())
        self.detail = self.tk.StringVar(value="Load friends or start the live connection.")
        self.auto_snapshots = self.tk.BooleanVar(value=False); self.next_snapshot = 0.; self.rotate = 0; self.history_offset = 0
        self.automatic=self.tk.BooleanVar(value=self.sync.enabled)
        row = line(self)
        self.ttk.Checkbutton(row,text='Automatic sync after sign-in',variable=self.automatic,command=lambda:self.guard(lambda:self.sync.configure(self.automatic.get()))).pack(side='left')
        button(self,row,"Resume sync",self.start_live); button(self,row,"Pause sync",self.stop_live);button(self,row,'Sync now',self.reconcile)
        row=line(self)
        choice(self,row,self.kind,("Online / website friends","Offline friends"),self.list_changed,25)
        button(self,row,"Refresh friends",lambda:self.load(0)); button(self,row,"Next friends page",self.more)
        self.ttk.Label(parent,textvariable=self.live_status,wraplength=1020).pack(anchor="w",pady=4)
        note(self,'Automatic sync keeps running across pages. Snapshot pages share the existing one-request-per-minute metadata budget; initial catch-up can take several minutes. Pause is remembered. Private, offline and locked modes suspend automatic traffic.')
        note(self,"Locations appear only as supplied by VRChat; private locations remain private. Changes are compared with previously observed snapshots. Newly visible groups are labeled that way because their actual join time is unknown. Current pictures are snapshots, not guaranteed live images.")
        tabs=self.tabs=self.ttk.Notebook(parent); tabs.pack(fill="both",expand=True)
        current=self.ttk.Frame(tabs); history=self.ttk.Frame(tabs)
        tabs.add(current,text="Friends / current snapshots"); tabs.add(history,text="Observed changes")
        self.table=Table(self,current,(("name","Friend",165),("state","Presence",140),("location","Shared location",320),("checked","Freshness",250)),height=8,select=self.selection)
        self.ttk.Label(current,textvariable=self.detail,wraplength=1000).pack(anchor="w",pady=4)
        row=line(self,current)
        button(self,row,"Refresh profile + groups",self.refresh_selected)
        button(self,row,"Player profile…",lambda:self.profile(self.selected_entity()))
        button(self,row,"Save local favorite…",lambda:self.favorite(self.selected_entity()))
        button(self,row,"Load current pictures",self.pictures)
        row=line(self,current); self.profile_picture=Picture(self,row,"Profile picture"); self.avatar_picture=Picture(self,row,"Avatar picture")
        row=line(self,current)
        self.ttk.Checkbutton(row,text="Cycle profile/group snapshots for loaded friends (opt-in; two queued requests per friend)",variable=self.auto_snapshots).pack(side="left")
        from profile_history import HISTORY_GROUPS
        self.history_group=self.tk.StringVar(value='Everything')
        row=line(self,history);choice(self,row,self.history_group,tuple(HISTORY_GROUPS),lambda:self.history(0),28)
        row=line(self,history); entry(self,row,self.query,32); button(self,row,"Filter / refresh",lambda:self.history(0))
        button(self,row,"Previous",lambda:self.history(max(0,self.history_offset-100))); button(self,row,"Next",lambda:self.history(self.history_offset+100))
        button(self,row,"Forget this account's history…",self.forget)
        button(self,row,'Imported history / retention…',lambda:__import__('native_data_ui').show(self.shell))
        button(self,line(self,history),'History & discovery…',lambda:__import__('social_history_ui').show(self.shell))
        button(self,line(self,history),'Profile changes…',lambda:__import__('social_history_ui').show(self.shell,'Profile changes'))
        self.history_table=Table(self,history,(("time","Observed (UTC)",175),("name","Friend",165),("kind","Change",165),("source","Source",135),("detail","Details",330)),height=10,select=self.history_selection)
        self.history_text=self.tk.Text(history,height=6,wrap="word");self.history_text.pack(fill="x");self.history_text.configure(state="disabled")
        from friend_activity_ui import FriendViews
        self.friend_views=FriendViews(self,tabs)
        self.ensure_model(optional=True)
        if self.model:self.render()

    @property
    def model(self):return self.sync.model

    @property
    def pipeline(self):return self.sync.pipeline

    def ensure_model(self,optional=False):
        self.sync.sync_context()
        client=self.app.api
        if not client or not client.authenticated or self.app.demo or self.model is None:
            if optional:return None
            self.connected()
            raise ValueError('Reveal account information before loading the Feed.')
        return self.model

    def account_changed(self):
        self.sync.sync_context();self.hub.sync()
        self.result=None; self.seen=-1; self.selected_ref=""; self.auto_snapshots.set(False)
        self.table.set([],lambda r:());self.history_table.set([],lambda r:()); self.detail.set("Load friends for the current account.")
        self.profile_picture.clear(); self.avatar_picture.clear(); self.history_text.configure(state="normal");self.history_text.delete("1.0","end");self.history_text.configure(state="disabled")
        self.ensure_model(optional=True)
        self.friend_views.clear()

    def list_changed(self): self.cancel(); self.result=None
    def load(self,offset):
        self.ensure_model(); kind="friends-offline" if self.kind.get()=="Offline friends" else "friends-online"
        after=self.sync.sequence
        self.start(lambda c,s,p:api.read(c,kind,offset=offset,stop=s,progress=p),lambda result:self.observe_list(result,after=after))
    def more(self):
        if not self.result or not self.result.more:raise ValueError("Refresh a friend list first; no next page was reported.")
        self.load(self.result.offset+100)
    def observe_list(self,result,after=None):
        model=self.ensure_model()
        if result.account!=(self.app.api.user_id,self.app.api.session_revision):return
        self.result=result
        self.sync.observe_friends(result,after=after)
        self.render();self.status.set(f"Observed {len(result.data)} friends on this page. {len(model.friends)} loaded in this Feed session; absence from a page does not prove offline status.")

    def start_live(self):
        from account_header import private
        if private(self.app):raise ValueError('Reveal account information before starting the live feed.')
        self.connected();self.ensure_model()
        self.sync.configure(True);self.automatic.set(True);self.live_status.set(self.sync.summary())
    def stop_live(self):
        self.sync.configure(False);self.automatic.set(False);self.live_status.set(self.sync.summary())

    def selected_entity(self):
        row=self.table.selected()
        if not row:raise ValueError("Select a loaded friend first.")
        return entity("user",row)
    def selection(self):
        row=self.table.selected()
        if not row:return
        self.selected_ref=row["id"]
        profile=next((row.get(k) for k in ("profilePicOverride","userIcon","iconUrl") if isinstance(row.get(k),str) and row[k]),"")
        avatar=row.get("currentAvatarThumbnailImageUrl") or row.get("currentAvatarImageUrl") or ""
        for preview,url in ((self.profile_picture,profile),(self.avatar_picture,avatar)):
            if preview.url!=url:preview.clear(url)
        self.detail.set(f"{row.get('displayName') or row['id']} · {row['id']}\nStatus: {row.get('status','Unavailable')} · {row.get('statusDescription','')}\nAvatar: {row.get('currentAvatarName') or row.get('currentAvatar') or 'Not supplied'}\nBio: {str(row.get('bio','Not supplied'))[:500]}")
    def render(self):
        if not self.model:return
        self.table.set(sorted(self.model.friends.values(),key=lambda r:str(r.get("displayName","")).casefold()),lambda r:(r.get("displayName") or r["id"],r.get("state","Unavailable"),r.get("location","Not shared / unavailable"),self.sync.freshness(r['id'])),identity=lambda r:r['id'])
        for key,row in self.table.records.items():
            if row["id"]==self.selected_ref:self.table.tree.selection_set(key);self.selection();break
        else:
            self.selected_ref="";self.profile_picture.clear();self.avatar_picture.clear();self.detail.set("Select a loaded friend.")
        self.seen=self.model.revision;self.history(self.history_offset)

    def refresh_selected(self):
        item=self.selected_entity();self.snapshot(item.id)
    def snapshot(self,ref):
        self.ensure_model()
        after=self.sync.sequence
        def work(c,s,p):
            expected=player_api.context(c);profile={"id":ref};groups=None;errors=[]
            for section in ("public","groups"):
                try:
                    result=player_api.read_section(c,ref,section,stop=s,progress=p)
                    if section=="public":profile=result.data
                    else:groups=result.data
                except api.APIError as error:
                    player_api.check_context(c,expected,s)
                    errors.append(section+": "+str(error))
            return profile,groups,errors
        def done(result):
            if not self.model or ref not in self.model.friends:return
            if self.sync.friend_versions.get(ref,0)>after:
                self.status.set('A newer live update arrived. The older profile snapshot was discarded.');return
            profile,groups,errors=result
            if groups is not None:profile=dict(profile,groups=groups)
            self.model.observe(profile,"VRChat profile/group snapshot");self.sync.fresh[ref]=(self.sync.clock(),'Profile snapshot');self.render()
            self.status.set("Saved available snapshot fields. "+(" · ".join(errors) if errors else "Changes compare observations; hidden groups remain unavailable."))
        self.next_snapshot=time.monotonic()+120
        self.start(work,done)

    def pictures(self):
        row=self.table.selected()
        if not row:raise ValueError("Select a friend.")
        self.selection();ref=row["id"]; urls=(self.profile_picture.url,self.avatar_picture.url)
        if not any(urls):raise ValueError("This snapshot supplied no picture URLs. Refresh its profile.")
        def work(c,s,p):
            output=[]
            for url in urls:
                if not url:output.append((None,"Unavailable"));continue
                try: output.append((fetch_preview(c,image_url(url),stop=s),""))
                except (ValueError,api.APIError) as error: output.append((None,str(error)))
            return output
        def done(output):
            current=self.table.selected()
            if not current or current["id"]!=ref or urls!=(self.profile_picture.url,self.avatar_picture.url):return
            errors=[]
            for preview,(data,error) in zip((self.profile_picture,self.avatar_picture),output):
                if data:preview.show(data)
                elif error:errors.append(preview.title+": "+error)
            self.status.set(" · ".join(errors) if errors else "Current snapshot pictures loaded.")
        self.start(work,done)

    def history(self,offset):
        if not self.model:return
        from profile_history import HISTORY_GROUPS
        self.history_offset=offset; rows=self.shell.store.feed(self.model.account,offset,self.query.get(),fields=HISTORY_GROUPS[self.history_group.get()])
        self.history_table.set(rows,lambda r:(r["checked"],r["name"],r["kind"],r["source"],r["detail"][:250]))
        self.history_text.configure(state="normal");self.history_text.delete("1.0","end");self.history_text.configure(state="disabled")
    def history_selection(self):
        row=self.history_table.selected()
        if row:
            self.history_text.configure(state="normal");self.history_text.delete("1.0","end")
            self.history_text.insert("1.0",f"{row['checked']} · {row['source']}\n{row['name']} · {row['id']}\n{row['kind']}\n{row['detail']}");self.history_text.configure(state="disabled")
    def forget(self):
        model=self.ensure_model()
        if self.confirm("Forget Feed history","Delete this account's stored change history and comparison snapshots on this computer? Future observations will establish new baselines."):
            self.sync.forget_feed();self.selected_ref="";self.render()

    def tick(self):
        from account_header import private
        self.sync.sync_context()
        self.friend_views.tick()
        self.live_status.set(self.sync.summary());self.automatic.set(self.sync.enabled)
        hidden=private(self.app)
        if hidden:
            if not getattr(self,'privacy_cleared',False):
                self.cancel();self.result=None;self.table.set([],lambda r:());self.history_table.set([],lambda r:())
                self.detail.set('Private information hidden');self.profile_picture.clear();self.avatar_picture.clear()
                self.history_text.configure(state='normal');self.history_text.delete('1.0','end');self.history_text.configure(state='disabled')
                self.privacy_cleared=True;self.seen=-1
            return
        self.privacy_cleared=False
        super().tick()
        epoch=(int(self.sync.clock()//60),self.sync.pipe_state,self.sync.blocked())
        if self.model and (self.model.revision!=self.seen or epoch!=getattr(self,'freshness_epoch',None)):
            self.render();self.freshness_epoch=epoch
        if self.auto_snapshots.get() and self.model and self.model.friends and not self.job and not self.sync.blocked() and self.sync.budget_ready() and time.monotonic()>=self.next_snapshot:
            refs=sorted(self.model.friends);ref=refs[self.rotate%len(refs)];self.rotate+=1
            self.guard(lambda:self.snapshot(ref))

    def close(self):
        # Page lifetime never owns the shared connection.
        self.friend_views.close()
        return super().close()

    def reconcile(self):
        self.ensure_model()
        queued=self.sync.request_sync()
        self.live_status.set(self.sync.summary())
        self.status.set('Catch-up queued using the shared request budget.' if queued else 'Catch-up is already queued; requests were combined.')
