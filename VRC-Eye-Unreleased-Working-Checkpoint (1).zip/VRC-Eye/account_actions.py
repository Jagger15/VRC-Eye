"""Development 3: account-bound reviews and minimal, durable action receipts.

No credentials, API response bodies, messages or destination URLs are persisted.
One active API session is retained by the existing application. Local labels are
not logins. This module does not turn legacy pages into a multi-session client.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
import json
import re
import sqlite3
import threading
import time
import uuid

from companion_data import CompanionStore, entity_id, reference, sanitize, stamp
from vrchat_api import APIError
import companion_api as api
import player_api

ROLES = ("Main", "Alt", "Creator", "Other")
STATES = ("Queued", "Dispatching", "Confirmed", "Rejected", "Not sent", "Uncertain")
DIRECT = frozenset(("add-friend", "remove-friend", "mute", "unmute", "block", "unblock"))
INVITATIONS = frozenset(("accept-friend", "decline-friend", "accept-group", "decline-group"))
NOTIFICATIONS = frozenset(("see-notification", "hide-notification"))
FAVORITES = frozenset(("add-favorite", "remove-favorite"))
VISITS = frozenset(("self-invite", "create-personal-instance"))
OUTBOUND = frozenset(("send-invite", "request-invite", "respond-request-invite",'respond-invite'))
OWNED_AVATARS = frozenset(("update-owned-avatar",))
SUPPORTED = DIRECT | INVITATIONS | NOTIFICATIONS | FAVORITES | VISITS | OUTBOUND | OWNED_AVATARS | {"update-self"}
from native_api import ACTIONS as NATIVE_ACTIONS
SUPPORTED = SUPPORTED | NATIVE_ACTIONS | {'upload-image','join-instance'}
MAX_ACCOUNTS = 64
MAX_RECEIPTS = 2000
MAX_REVIEWS = 32
REVIEW_SECONDS = 300.


def text(value, maximum=120, *, multiline=False):
    """Plain bounded UI text, never markup, a command or a path."""
    if not isinstance(value, str) or len(value) > maximum:
        raise ValueError(f"Use text of at most {maximum} characters.")
    if any((ord(c) < 32 and not (multiline and c in '\n\t')) or ord(c) == 127 or
           c in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069' for c in value):
        raise ValueError("Control and direction-override characters are not supported.")
    return value.strip()


def display(value, maximum=160):
    if not isinstance(value, str):
        return ""
    value = ''.join(c for c in value if ord(c) >= 32 and ord(c) != 127 and
                    c not in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069')
    return value[:maximum]


def account_id(app):
    client = getattr(app, "api", None)
    if not client or not getattr(client, "authenticated", False):
        return ""
    try:
        return entity_id("user", client.user_id)
    except ValueError:
        return ""


def local_writable(app):
    if getattr(app, "demo", False) or getattr(app, "safe_mode", False):
        raise ValueError("Local changes are disabled in Demo and Safe mode.")


class AccountStore:
    """Namespaced additions to CompanionStore; no changes to legacy records."""
    def __init__(self, companion):
        self.companion = companion if isinstance(companion, CompanionStore) else CompanionStore(companion)

    @contextmanager
    def connect(self):
        with self.companion.connect() as db:
            db.row_factory = sqlite3.Row
            db.execute('''CREATE TABLE IF NOT EXISTS social_accounts_v3(
                account TEXT PRIMARY KEY, label TEXT NOT NULL, role TEXT NOT NULL,
                updated TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS social_receipts_v3(
                id TEXT PRIMARY KEY, account TEXT NOT NULL, run TEXT NOT NULL,
                session INTEGER NOT NULL, operation TEXT NOT NULL, target TEXT NOT NULL,
                state TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL,
                reason TEXT NOT NULL, acknowledged INTEGER NOT NULL DEFAULT 0)''')
            db.execute('''CREATE INDEX IF NOT EXISTS social_receipts_v3_account
                ON social_receipts_v3(account, created)''')
            yield db

    def accounts(self):
        with self.connect() as db:
            return [dict(r) for r in db.execute(
                "SELECT * FROM social_accounts_v3 ORDER BY label COLLATE NOCASE,account LIMIT ?", (MAX_ACCOUNTS,))]

    def save_account(self, account, label, role):
        account, label = entity_id("user", account), text(label)
        if not label or role not in ROLES:
            raise ValueError("Choose a nonempty local label and a supported role.")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            found = db.execute("SELECT 1 FROM social_accounts_v3 WHERE account=?", (account,)).fetchone()
            if not found and db.execute("SELECT COUNT(*) FROM social_accounts_v3").fetchone()[0] >= MAX_ACCOUNTS:
                raise ValueError("The 64 local account-label limit was reached. Forget an unused label first.")
            db.execute("INSERT OR REPLACE INTO social_accounts_v3 VALUES(?,?,?,?)", (account, label, role, stamp()))

    def forget_account(self, account):
        account = entity_id("user", account)
        with self.connect() as db:
            db.execute("DELETE FROM social_accounts_v3 WHERE account=?", (account,))

    def begin(self, review, run):
        """Commit the intent before dispatch; refuse duplicate/uncertain operations."""
        now = stamp()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            for row in db.execute('''SELECT state,run,acknowledged FROM social_receipts_v3
                    WHERE account=? AND operation=? AND target=?''',
                    (review.account, review.action, review.target)):
                state, owner, acknowledged = row
                if state in ("Dispatching", "Uncertain") and not acknowledged:
                    raise ValueError("An earlier matching action may have been sent. Inspect its receipt and verify before acknowledging that uncertainty.")
                if state == "Queued" and owner == run:
                    raise ValueError("This account already has the same action queued.")
            count = db.execute("SELECT COUNT(*) FROM social_receipts_v3 WHERE account=?", (review.account,)).fetchone()[0]
            if count >= MAX_RECEIPTS:
                raise ValueError("Action history is full (2,000 records for this account). Review and explicitly clear completed history first.")
            db.execute("INSERT INTO social_receipts_v3 VALUES(?,?,?,?,?,?,?,?,?,?,0)",
                (review.id, review.account, run, review.session, review.action, review.target,
                 "Queued", now, now, "Reviewed locally; not dispatched."))

    def finish(self, identity, state, reason):
        if state not in STATES:
            raise ValueError("Unsupported receipt state.")
        with self.connect() as db:
            changed = db.execute("UPDATE social_receipts_v3 SET state=?,reason=?,updated=? WHERE id=?",
                (state, text(reason, 500), stamp(), identity)).rowcount
            if changed != 1:
                raise ValueError("The action receipt no longer exists. No further action is permitted.")

    def receipts(self, account, run="", *, offset=0, limit=100):
        account = entity_id("user", account)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 200:
            raise ValueError("Invalid action-history page.")
        with self.connect() as db:
            rows = [dict(row) for row in db.execute('''SELECT * FROM social_receipts_v3
                WHERE account=? ORDER BY created DESC,rowid DESC LIMIT ? OFFSET ?''', (account, limit, offset))]
            total = db.execute("SELECT COUNT(*) FROM social_receipts_v3 WHERE account=?", (account,)).fetchone()[0]
        for row in rows:
            row["display_state"] = row["state"]
            if row["run"] != run and row["state"] == "Queued":
                row["display_state"] = "Interrupted / not sent"
            if row["run"] != run and row["state"] == "Dispatching":
                row["display_state"] = "Interrupted / uncertain"
        return rows, total

    def acknowledge(self, account, identity, run, active_ids=()):
        account = entity_id("user", account)
        if identity in active_ids:
            raise ValueError("This action is still running. Its outcome cannot be acknowledged yet.")
        with self.connect() as db:
            row = db.execute("SELECT state,run FROM social_receipts_v3 WHERE account=? AND id=?", (account, identity)).fetchone()
            if not row or not (row[0] == "Uncertain" or row[0] == "Dispatching" and row[1] != run):
                raise ValueError("Select an uncertain or interrupted-dispatch receipt.")
            db.execute("UPDATE social_receipts_v3 SET acknowledged=1,updated=? WHERE account=? AND id=?", (stamp(), account, identity))

    def clear_completed(self, account, run):
        account = entity_id("user", account)
        with self.connect() as db:
            return db.execute('''DELETE FROM social_receipts_v3 WHERE account=? AND
                (state IN ('Confirmed','Rejected','Not sent') OR (state='Queued' AND run!=?))''', (account, run)).rowcount

    def export_receipt(self, account, identity, run):
        """Selected, identity-free report. No alias, target, session, freeform text."""
        account = entity_id("user", account)
        with self.connect() as db:
            row = db.execute("SELECT * FROM social_receipts_v3 WHERE account=? AND id=?", (account, identity)).fetchone()
        if not row:
            raise ValueError("Select an existing receipt belonging to this account.")
        state = row["state"]
        if row["run"] != run and state in ("Queued", "Dispatching"):
            state = "Interrupted / " + ("not sent" if state == "Queued" else "uncertain")
        return {"schema": "vrc-eye.action-receipt.v1", "operation": row["operation"],
                "state": state, "uncertainty_acknowledged": bool(row["acknowledged"]),
                "created": row["created"], "updated": row["updated"],
                "scope": "Selected receipt; identifiers and payload omitted. Not proof of current remote state."}


@dataclass(frozen=True)
class Review:
    id: str
    account: str
    session: int
    action: str
    target: str
    description: str
    expires: float
    fields: tuple = ()

    def summary(self):
        effect = {
            "add-friend": "Sends a friend request; it does not establish a friendship by itself.",
            "remove-friend": "Removes this friendship from your signed-in account.",
            "mute": "Adds this user's mute on your signed-in account.",
            "unmute": "Removes this user's mute on your signed-in account.",
            "block": "Blocks this user on your signed-in account.",
            "unblock": "Removes this user's block on your signed-in account.",
            "see-notification": "Marks this notification as read on VRChat. Viewing it alone does not.",
            "hide-notification": "Hides this notification on VRChat. It is not an invite response or a join action.",
            "accept-friend": "Accepts this returned friend request.",
            "decline-friend": "Hides this returned friend request; it does not block its sender.",
            "accept-group": "Accepts the invitation by joining this group.",
            "decline-group": "Declines this group invitation.",
            "add-favorite": "Changes your game favorites; this is not a local VRC Eye favorite.",
            "remove-favorite": "Removes this game favorite from every list attached to its record; local favorites remain separate.",
            "update-self": "Updates only the explicitly changed fields shown below on your own profile.",
            "self-invite": "Sends this account one self-invitation to the exact inspected instance. It does not join, launch VRChat, change accounts or bypass permissions.",
            "create-personal-instance": "Creates ONE personal instance under this account. Creation does not send an invitation or join the world. A second separately reviewed action is required.",
            "send-invite": "Sends this exact recipient one invitation to the inspected destination using the reviewed message slot. It does not join the instance or guarantee access.",
            "request-invite": "Sends this exact recipient one invitation request using the reviewed message slot. It does not reveal their location or guarantee a response.",
            "respond-request-invite": "Sends one reviewed message-slot response to this returned invitation request. It does not send an instance invitation or join a world.",
            "update-owned-avatar": "Updates only the explicitly changed metadata fields on this freshly inspected avatar owned by the active account. It does not upload files or change the avatar you are wearing.",
            'respond-invite':'Sends the reviewed response message for this invitation with RSVP enabled. It does not join the instance.',
            'upload-image':'Uploads the exact previewed PNG to the selected VRChat media destination. Your original file is preserved.',
            'inventory-consume':'Consumes this selected inventory bundle. Review its contents first; this action may be irreversible.',
            'reward-redeem':'Redeems this code on the active account. The code is excluded from the saved receipt; redemption may be irreversible.',
            'favorite-group-clear':'Clears the contents of this game favorite list. Other local collections are unchanged.',
            'group-delete':'Requests deletion of this group as its current owner. Do not assume it can be recovered.',
            'group-transfer':'Transfers ownership of this group to the reviewed eligible recipient.',
            'media-delete':'Deletes this selected account media file from VRChat.',
            'print-delete':'Deletes this selected print from VRChat.',
        }.get(self.action,'Submits the reviewed '+self.action.replace('-',' ')+' operation to VRChat for the exact target and fields below.')
        extra = '\n'.join(f"{key}: {before!r} → {after!r}" for key, before, after in self.fields)
        return (f"Acting account: {self.account}\nSession revision: {self.session}\n\n"
                f"Action: {self.action.replace('-', ' ').title()}\n{self.description}\nTarget: {self.target}\n\n"
                f"{effect}\n{extra}\n\nAuthentication: this exact active session is required.\n"
                "API risk: remote write, community-documented / not live-verified here.\n"
                "Privacy impact: VRChat receives this action and its target; a local receipt retains IDs, not message bodies or credentials.\n"
                "No automatic retry. A lost acknowledgement may leave an uncertain outcome.\n\nSubmit this one action?")


@dataclass(frozen=True)
class Outcome:
    receipt: str
    state: str
    message: str
    value: object = None


class ActionService:
    def __init__(self, app, store, *, clock=time.monotonic):
        self.app, self.store, self.clock = app, store, clock
        self.run = str(uuid.uuid4())
        self._lock = threading.RLock()
        self._plans = {}
        self._active = set()
        self._volatile = {}  # Last-resort outcomes when disk saving fails; session-only.

    def token(self):
        local_writable(self.app)
        client = getattr(self.app, "api", None)
        if not client:
            raise ValueError("Connect to VRChat first. Local account labels do not sign you in.")
        own, session = player_api.context(client)
        return client, entity_id("user", own), session, getattr(self.app, "data_generation", 0)

    def check(self, token, stop=None):
        if stop is not None and stop.is_set():
            raise ValueError("The pending action was canceled.")
        try:
            current = self.token()
        except (ValueError, APIError):
            raise ValueError("The account, session or operating mode changed. Review again.") from None
        if current != token:
            raise ValueError("The account or session changed. Review again.")
        token[0]._check(stop)

    @property
    def active_ids(self):
        with self._lock:
            return tuple(self._active)

    def volatile_outcomes(self, account):
        account = entity_id("user", account)
        with self._lock:
            return [outcome for owner, outcome in self._volatile.values() if owner == account]

    def retry_receipt_save(self, account, identity):
        """Retry only the local receipt write; never rerun the remote operation."""
        local_writable(self.app)
        account = entity_id("user", account)
        with self._lock:
            entry = self._volatile.get(identity)
            if not entry or entry[0] != account or identity in self._active:
                raise ValueError("No completed in-memory outcome is available for this receipt and account.")
            outcome = entry[1]
            reason = outcome.message.split(" WARNING:", 1)[0]
            self.store.finish(identity, outcome.state, reason)
            self._volatile.pop(identity, None)
        return outcome

    def invalidate(self):
        """Revoke unsubmitted reviews, never erase an in-flight receipt."""
        with self._lock:
            self._plans.clear()

    def discard(self, review):
        with self._lock:
            self._plans.pop(review.id, None)

    def prepare(self, action, *, target="", description="", result=None, row=None,
                group=None, group_result=None, values=None):
        if action not in SUPPORTED:
            raise ValueError("This action is not implemented by the reviewed account service.")
        token = self.token()
        client, own, session, generation = token
        args = {}; fields = ()
        if action=='join-instance':
            import world_visits
            selected=world_visits.validate_snapshot(client,result,instance=True)
            coordinator=getattr(getattr(self.app,'sidebar',None),'companion',None)
            if coordinator is None:raise ValueError('The shared desktop launch coordinator is unavailable.')
            target=world_visits.receipt_target(selected.world,selected.instance)
            context=(own,session,generation,target)
            reservation=coordinator.review_action('launch',context)
            args=dict(snapshot=selected,coordinator=coordinator,review=reservation,context=context)
            fields=(('World',None,selected.name or selected.world),('Instance access',None,selected.kind),
                ('Desktop action',None,'Hand this exact destination to the installed VRChat URI handler. Arrival is not confirmed.'),
                ('Observed game account',None,getattr(getattr(self.app,'player_sessions',None),'local_user_id','') or 'Unknown; the game may use a different login'))
        elif action=='upload-image':
            from native_images import prepare
            plan=prepare(client,result=result,values=values);target,fields=plan.target,plan.fields;args['plan']=plan
        elif action in NATIVE_ACTIONS:
            from native_api import prepare
            plan=prepare(client,action,result=result,row=row,values=values,target=target,group_result=group_result)
            target,fields=plan.target,plan.fields;args['plan']=plan
        elif action in DIRECT:
            target = entity_id("user", target)
            if target == own:
                raise ValueError("Choose someone other than your own account.")
            args["target"] = target
        elif action in INVITATIONS | NOTIFICATIONS | {"remove-favorite"}:
            kind = "group-invites" if action.endswith("group") else "friend-requests" if action.endswith("friend") else "favorite-items" if action == "remove-favorite" else "notifications"
            api.selected_record(client, result, row, kind)
            if result.source_client is not client:
                raise ValueError("Refresh this list using the current connection.")
            frozen = json.loads(json.dumps(sanitize(row), allow_nan=False))
            if kind == "group-invites":
                target = entity_id("group", frozen.get("id") or frozen.get("groupId"))
            elif kind in ("friend-requests", "notifications"):
                target = reference(frozen.get("id"), ("frq", "not"))
                if frozen.get("receiverUserId", own) != own:
                    raise ValueError("This notification belongs to a different account.")
                if kind == "friend-requests" and frozen.get("type") != "friendRequest":
                    raise ValueError("Select an actual friend request.")
            else:
                target = reference(frozen.get("id"), ("fvrt",))
            args.update(result=replace(result, data=[frozen]), row=frozen)
        elif action in VISITS:
            from world_visits import validate_snapshot, create_values, receipt_target
            validate_snapshot(client,result,instance=action=="self-invite")
            args["snapshot_value"]=result
            if action=="self-invite":
                target=receipt_target(result.world,result.instance)
                fields=(("Exact private destination (not retained in receipt)",None,result.location),)
            else:
                validated=create_values(own,values)
                args["values"]={key:validated[key] for key in ("type","region")}
                target=result.world+" · "+validated['type']+" · "+validated['region']
                fields=tuple((key,None,validated[key]) for key in ('ownerId','type','region'))
        elif action in OUTBOUND:
            from social_outbound import prepare_action
            plan = prepare_action(client, action, result, values)
            target, fields = plan.target, plan.fields
            args["plan"] = plan
        elif action in OWNED_AVATARS:
            from owned_avatars import prepare
            plan = prepare(client, result=result, values=values)
            target, fields = plan.avatar, plan.fields
            args["plan"] = plan
        elif action == "add-favorite":
            api.selected_record(client, group_result, group, "favorite-groups")
            if group_result.source_client is not client:
                raise ValueError("Refresh game lists using the current connection.")
            frozen = json.loads(json.dumps(sanitize(group), allow_nan=False))
            if frozen.get("ownerId") != own:
                raise ValueError("Select your own favorite group.")
            kind = "world" if frozen.get("type") == "vrcPlusWorld" else frozen.get("type")
            target = entity_id(kind, target)
            # target records both the resource and exact collection for duplicate prevention.
            args.update(target=target, group=frozen, group_result=replace(group_result, data=[frozen]))
            target += " @ " + text(frozen.get("name"), 100)
        else:
            if (not isinstance(result, api.Result) or result.kind != "self-profile" or result.account != (own, session) or result.source_client is not client
                    or not 0 <= client.clock() - result.checked < REVIEW_SECONDS or not isinstance(result.data, dict)
                    or result.data.get("id") != own):
                raise ValueError("Refresh your own profile before reviewing changes.")
            patch = __import__('player_profile').self_patch(values)
            patch = {k: v for k, v in patch.items() if result.data.get(k) != v}
            if not patch:
                raise ValueError("No changed profile fields to submit.")
            fields = tuple((k, result.data.get(k), v) for k, v in sorted(patch.items()))
            args.update(values=patch, checked=result.checked)
            target = own
        review = Review(str(uuid.uuid4()), own, session, action, target,
                        display(description, 240), self.clock() + REVIEW_SECONDS, fields)
        with self._lock:
            self._plans = {key: item for key, item in self._plans.items() if item[0].expires > self.clock()}
            if len(self._plans) >= MAX_REVIEWS:
                raise ValueError("Too many open reviews. Close an unused review first.")
            self._plans[review.id] = (review, token, args)
        return review

    def validate_review(self, review):
        with self._lock:
            item = self._plans.get(getattr(review, "id", None))
        if not item or item[0] is not review:
            raise ValueError("This review was used, canceled or revoked. Review again.")
        self.check(item[1])
        if not self.clock() < review.expires:
            self.discard(review)
            raise ValueError("The review expired. Refresh and review again.")

    def execute(self, review, *, stop=None, progress=None, dispatch_guard=None):
        """Claim once, durably journal, then use the original transport and budget."""
        with self._lock:
            self.validate_review(review)
            item = self._plans.pop(review.id)
            self.check(item[1], stop)
            self.store.begin(review, self.run)  # Failure here prevents dispatch.
            self._active.add(review.id)
        token, args = item[1], item[2]
        client = token[0]
        entered_transport = False
        observed_confirmation = False
        value = None

        def before_dispatch():
            nonlocal entered_transport
            self.check(token, stop)
            if dispatch_guard is not None:dispatch_guard()
            if self.clock() >= review.expires:
                raise ValueError("The review expired while waiting for the connection.")
            if review.action == "update-self" and not 0 <= client.clock() - args["checked"] < REVIEW_SECONDS:
                raise ValueError("The profile snapshot expired while waiting for the connection.")
            self.store.finish(review.id, "Dispatching", "The transport boundary was entered; receipt confirmation is pending.")
            self.check(token, stop)
            entered_transport = True

        def confirmed():
            nonlocal observed_confirmation
            observed_confirmation = True

        try:
            self.check(token, stop)
            if review.action=='join-instance':
                from desktop_join import dispatch
                value=dispatch(client,**args,stop=stop,progress=progress,before_dispatch=before_dispatch,on_confirmed=confirmed)
            elif review.action=='upload-image':
                from native_images import dispatch
                value=dispatch(client,args['plan'],stop=stop,progress=progress,before_dispatch=before_dispatch,on_confirmed=confirmed)
            elif review.action in NATIVE_ACTIONS:
                from native_api import dispatch
                value=dispatch(client,**args,stop=stop,progress=progress,before_dispatch=before_dispatch,on_confirmed=confirmed)
            elif review.action == "update-self":
                if not 0 <= client.clock() - args["checked"] < REVIEW_SECONDS:
                    raise ValueError("The profile snapshot expired while queued.")
                value = player_api.update_self(client, review.account, args["values"], stop=stop,
                    progress=progress, before_dispatch=before_dispatch, on_confirmed=confirmed)
            elif review.action in VISITS:
                from world_visits import dispatch
                value=dispatch(client,review.action,**args,stop=stop,progress=progress,
                               before_dispatch=before_dispatch,on_confirmed=confirmed)
            elif review.action in OUTBOUND:
                from social_outbound import dispatch
                value = dispatch(client, review.action, **args, stop=stop, progress=progress,
                                 before_dispatch=before_dispatch, on_confirmed=confirmed)
            elif review.action in OWNED_AVATARS:
                from owned_avatars import dispatch
                value = dispatch(client, **args, stop=stop, progress=progress,
                                 before_dispatch=before_dispatch, on_confirmed=confirmed)
            else:
                value = api.mutate(client, review.action, **args, stop=stop, progress=progress,
                                   before_dispatch=before_dispatch, on_confirmed=confirmed)
            state, reason = "Confirmed", "The expected acknowledgement was received. Refresh to inspect current remote state."
        except Exception as error:
            code = getattr(error, "status_code", None)
            if observed_confirmation:
                state, reason = "Confirmed", "The expected acknowledgement was received; the view or account changed afterward."
            elif code in (400, 401, 403, 404, 405, 409, 410, 413, 415, 422, 429):
                state, reason = "Rejected", f"VRChat returned HTTP {code}. No automatic retry was made."
            elif entered_transport:
                state, reason = "Uncertain", "The request may have reached VRChat, but no expected acknowledgement was recorded. Verify before repeating."
            else:
                state, reason = "Not sent", "The context, review, cancellation or local receipt check prevented dispatch."
        outcome = Outcome(review.id, state, f"{state}: {reason}", value if state == "Confirmed" else None)
        try:
            self.store.finish(review.id, state, reason)
        except (OSError, sqlite3.Error, ValueError):
            outcome = replace(outcome, message=outcome.message + " WARNING: final receipt could not be saved; this outcome is available only in memory until exit.")
            with self._lock:
                self._volatile[review.id] = (review.account, outcome)
        finally:
            with self._lock:
                self._active.discard(review.id)
        return outcome


def service_for(shell):
    service = getattr(shell, "account_actions", None)
    if service is None:
        service = ActionService(shell.app, AccountStore(shell.store))
        shell.account_actions = service
    return service
