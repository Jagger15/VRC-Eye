# VRC Eye — remaining ARC and VRCX functions after Development 20

106 tracked areas: 82 VRCX and 24 ARC. The original review was completed before this implementation. These are source implementation dispositions; native/live acceptance is a separate gate.

| Disposition | Areas |
|---|---:|
| Source implemented; native/live acceptance open | 50 |
| Acceptance / provider prerequisite | 7 |
| Partial | 40 |
| Source-data limitation | 2 |
| Missing | 7 |

**47 areas remain partial/missing: 40 partial and 7 missing.** ARC-04 moves from Missing to Partial because the static GLB base-color subset is implemented. No full ARC/VRCX parity claim.

## Development 20 scope

- Eight typed settings sections; sidebar and photo grouping now participate in selective restore and the existing direct-edit undo journal. Backup coverage is explicit.
- Source ages for Home media/status/performance; demand-aware cadence for existing optional GPU/disk workers, with guard/recording priority.
- Static GLB base-color/UV0 texture rendering and material inspector. No Unity shader, rig, animation, FBX or VRCA decoding milestone is claimed.
- Automatic checkpoints for reviewed VPM helpers in recovery workspaces. Unity edits and other helper paths remain manual.
- Derived session-day photo grouping, frozen block-based chat drafts and a read-only OSC endpoint inventory. These are native Eye enhancements, not newly missing parity reclassified as complete.

## Next work

1. Native Windows/Linux acceptance for the new viewer, controls, large text, high contrast and keyboard flows.
2. Qualification with installed VPM/Unity/AssetRipper and real authorized assets/origins; stronger helper process containment.
3. Richer scene/material/rig/animation contracts and approved provider integration.
4. Remaining direct settings stores and provider subscriptions/throttling.
5. The reviewed later ideas: local caption refinements, carefully scoped MIDI input, optional OSC legacy bridging and other utility proposals. None is silently enabled by Dev20.

## All missing and partial areas

| ID | Feature | State | Remaining implementation or qualification |
|---|---|---|---|
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Partial | All other profile fields/producers, every historical source schema and unobserved changes remain outside coverage. Actual change times and hidden data cannot be reconstructed from snapshots. |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | Partial | General creator duplicate detection across asset/model content, complete historical asset-version acquisition and actual rollback remain missing. Exact local hashes do not establish equivalent avatars. |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Partial | Image approval has no verified endpoint in the pinned source. Ordering is limited to one complete unfiltered page of fewer than 100 images. |
| VX-MIG-01 | Versioned source contract inventory | Partial | Additional historical source-version adapters are not exhaustive. |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Partial | Requires rollback-journal stores. This does not erase physical logs/photos, original VRCX files, all creator/media stores or minimal action receipts. |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Partial | Independent live stores are not universally one atomic database. Profile snapshots can represent slightly different instants. |
| VX-MIG-14 | User, world and avatar memos plus account notes | Partial | Historical producer/export schemas and bidirectional external-app note synchronization remain incomplete. Creator notebooks, quick notes and photo notes retain their distinct purposes. Private annotations do not update API profile tags or account notes. |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Partial | Persistent custom-user-tag VRCX producer/export contracts remain conditional. Tags are local entity annotations; unobserved external labels cannot be reconstructed. |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Partial | Other tool/display stores and unverified external VRCX settings mappings remain incomplete. New photo grouping and sidebar sections require a Dev20 reader; older readers should receive bundles without those sections. |
| VX-MIG-20 | Video, resource and auxiliary game-log history | Partial | All version-specific auxiliary payloads remain conditional. |
| VX-MIG-23 | Notification archives and invite message details | Partial | Exhaustive nested payloads across historical versions are not supported. |
| VX-MIG-25 | Print favorite references and conditional print metadata | Partial | Complete historical print metadata/export schemas remain conditional. |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Partial | Exhaustive legacy/cross-application formats are not claimed. |
| VX-MIG-28 | Saved searches, filters and portable views | Partial | No verified persisted VRCX saved-search producer was found; such external migration remains conditional. These are native VRC Eye tag views. |
| VX-MIG-29 | Native selective backup and complete restore | Partial | Original photos, Unity/recovery workspaces, protected sessions, approvals and unrecognized stores remain outside portable settings. The private direct-edit ledger is not part of the portable settings bundle. |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Partial | Complete bidirectional VRCX roundtrip is not claimed; ID/CSV exports lose richer native relationships/history. |
| VX-DESK-01 | Shared dashboard projections | Partial | Other runtime/log views still lack one revisioned subscription/paging contract. Universal source freshness and Smart Start remain incomplete. |
| VX-DESK-02 | Configurable dashboards and widget layouts | Partial | Interactive VR dashboard rendering, broader runtime-specific conditions and native Windows/Linux accessibility/layout acceptance remain open. |
| VX-DESK-06 | Discord content, join controls and coexistence | Partial | Interactive Discord join-request acceptance is not implemented. Native Discord IPC and application registration remain user/environment prerequisites. |
| VX-DESK-08 | Opt-in crash recovery controller | Partial | Unattended private-instance rejoin and installed native crash/launch acceptance remain incomplete. |
| VX-DESK-15 | Tray/background and low-power operation | Partial | Native tray/startup/shutdown acceptance and adaptive demand policies for remaining providers remain. Default enabled GPU/disk warning rules intentionally retain normal collection cadence. |
| VX-DESK-16 | Settings profiles, backup and rollback UX | Partial | Direct edits in all other stores, physical asset recovery and native active-control/accessibility acceptance remain open. Credentials, service grants, executable approvals and paths are excluded. History is bounded and does not retrospectively reconstruct earlier edits. |
| VX-DESK-17 | Optional update channels and recoverable installation | Partial | Publisher endpoint, trusted signing keys, installer/update-channel implementation and native rollback acceptance remain missing. |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Partial | Live provider acceptance, broader providers and generalized playback-error correlation remain incomplete. |
| ARC-01 | Isolated avatar provider contract and lifecycle | Partial | Rich-avatar/Unity-bundle/FBX provider coverage, formal OS sandbox containment and native Windows/Linux process/render qualification remain open. The bundled static GLB parser is process fault separation, not an OS security boundary. |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing | Decode authorized VRCA/Unity bundles into actual mesh/material/rig/animation scene data; supported-version and missing-dependency reporting. |
| ARC-03 | Authorized FBX import and scene inspection | Missing | FBX import/scene inspection including axes, units, importer settings, takes and external dependency handling. |
| ARC-04 | Actual material and texture viewer | Partial | PBR/Unity shader appearance, arbitrary material extensions, vertex colors, multiple UV sets, texture transforms, full-resolution filtering, normal/occlusion/emissive/metallic maps and native render acceptance remain. Blend sorting is approximate. External and data URI images are never read. |
| ARC-05 | Rig, skinning and blendshape viewer | Missing | Bone/bind-pose/influence inspection, skinned preview, reversible poses and blendshape controls. |
| ARC-06 | Clip, take and safe controller animation preview | Missing | Actual clip/take playback and scrubbing, speed/loop/root-motion controls and safe Animator/controller-subset preview. |
| ARC-07 | AssetRipper provider selection, version and provenance | Partial | Exact installed-release/version qualification, publisher/license verification, dependency pinning and a qualified provider registry remain. A local executable hash and compatible API do not authenticate its publisher. |
| ARC-08 | Integrated user-owned recovery orchestration | Partial | Native Windows/Linux installed-release acceptance, complete descendant containment, exporter memory/disk containment and version-specific quality/failure qualification remain. This process lifecycle is not an OS sandbox. |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial | Original-source completeness, semantic object/fileID/material/rig validation, OS-enforced immutability and successful Unity import are not established. Raw data is protected by application behavior and hash checks, not an OS sandbox. |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing | Compare real mesh/renderer/pose bounds and apply reviewed bounds corrections or margins to clones. |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing | Compatible mesh/renderer/importer setting transfer with typed diffs, fresh copies and controlled reimport policy. |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing | Dependency-checked influence reduction, proven-unused bone removal and renderer consolidation with measured deformation comparisons. |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial | Full topology/stream/index/tangent diagnostics and narrowly reviewed tangent repairs. |
| ARC-14 | Shader and material compatibility diagnostics | Partial | Actual shader compilation, render-pipeline/platform compatibility and complete typed material-property/keyword/texture analysis still require richer parser/editor evidence. GUID presence alone does not validate the target object. |
| ARC-15 | Typed material property mapping on copies | Partial | Exact-shader-version mapping profiles and reviewed texture, offset/scale, color, number/vector, queue and keyword transfer. |
| ARC-16 | Reviewed shader package install and removal | Partial | Shader-specific install/remove planning with dependency review, post-operation compilation/diffs and change-aware removal journal. |
| ARC-17 | Animation and controller dependency repair copies | Partial | Object-reference curve repairs, clip swaps and cloned Animator/override-controller dependency closure repair. |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial | Binary Unity component and object-level dependency graphs, validated Unity fileIDs, component copying and reference remapping remain incomplete. Static GLB hierarchy does not establish Unity semantic equivalence. |
| ARC-19 | General repair-copy journal and conditional rollback | Partial | Automatic wrapping of arbitrary Unity/editor helpers and the separate Creator Projects copy jobs, native installed VPM/Unity execution, Windows descendant handling and power-loss acceptance remain. Rollback is per-file, not atomic across the tree; modes and empty directories remain outside the content journal. |
| ARC-21 | Evidence-based automated local-file association | Partial | Separately enabled deterministic automatic association rules, scope-wide rule revocation and mass-association undo remain open. Matches reuse recorded associations and never prove ownership or semantic avatar identity. |
| ARC-22 | Opt-in resumable authorized transfers | Partial | Other asset owners, supplied-key/decrypted resumable streams, real-origin range support and native Windows filesystem acceptance remain. Unsupported validators require a new reviewed complete download; modified or uncertain partials remain for inspection. |
| ARC-23 | Explicit bounded transient retry policy | Partial | Qualification of actual provider rate-limit/redirect behavior and broader nontransfer task policies remain. External extraction, imports and repairs are never automatically replayed. |
| ARC-24 | Durable job and publication crash reconciliation | Partial | OS-proven external-process containment, atomic cross-owner catalog publication and native power-loss/filesystem qualification remain incomplete. Releasing a stale reservation does not reconcile or replay uncertain file operations. |

## Acceptance prerequisites and source limits

| ID | Feature | State | Remaining evidence |
|---|---|---|---|
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite | Native window, idle-event and Windows/Linux protected-vault acceptance remain. The lock is a UI privacy boundary, not disk encryption. |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite | Provider availability/access/terms and live metadata/image results need acceptance; no VRCX-only entitlement is assumed. |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation | Source groups absent from the selected database cannot be reconstructed. |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation | The source has no file fingerprint, so historical byte identity cannot be proven. No implicit path scans or roster matching. |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite | Installed protocol registration/focus/delivery requires native OS acceptance. |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite | The full prepared acceptance matrix, native Windows and release gates remain open. |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite | Native Discord application registration and Windows/Linux IPC acceptance remain required. |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite | Native launch/cleanup acceptance remains. No process-name killing, force-kill fallback or application-readiness claim. |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite | Installed zero-VRCX and coexistence acceptance remains; all parity gaps remain visible in this ledger. |

The complete 106-area evidence inventory is ARC_VRCX_GAP_LEDGER_DEV20.json. Prior ledgers and review artifacts are retained.
