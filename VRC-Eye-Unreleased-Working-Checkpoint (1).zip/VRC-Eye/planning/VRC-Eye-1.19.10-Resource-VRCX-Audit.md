# VRC Eye 1.19.9 — Resource Monitor and VRCX Companion Audit

**Date:** October 2, 2026  
**Purpose:** Investigation for the planned 1.19.10 update. No implementation, release build, or modifications to the supplied project.

## Audit boundary

The inspected baseline is `VRC-Eye-v1.19.9.zip`, SHA-256 `dbdd0ed01a0d4e8aac42edc12bc4debc2f4f61007037d367ab5f7846e5adac07`. All 371 file members were compared byte-for-byte by SHA-256 with the extracted audit copy after testing; none changed. Test scripts, temporary settings, and reports were created separately.

This audit used source inspection, 203 selected existing tests, a short native Tk GUI run under Linux/Xvfb with real psutil 7.2.2, and three controlled edge-case reproductions. The native GUI run used a fresh temporary local configuration, no account, no running VRChat or VRCX instance, and blocked outbound socket connections. Process-control and account-action buttons were not invoked.

**The cause on the user's Windows installation remains unconfirmed.** Successful Linux tests do not establish Windows compatibility, driver support, VRCX login state, or correctness of the user's installed configuration. The following findings distinguish reproduced behavior from source-confirmed limitations and planned changes.

## R1 — Core initialization failure has no independent recovery

**Classification:** Reproduced recovery defect; high repair priority.

`ResourceService._core` constructs its backend once. Any exception records an unavailable status and returns, ending the core thread. `ResourceService.start` returns immediately when *any* collector thread is alive. GPU and disk threads can therefore keep the service nominally started while the dead core collector is never recreated. The page's ordinary tick does not recover this condition either: its restart condition requires a set stop event and all threads stopped.

A synthetic core factory was configured to fail once and succeed on subsequent calls. After startup and three explicit `start()` attempts, the factory had still been called only once, the core thread was dead, both auxiliary threads remained alive, and there was no sample.

The error message also incorrectly attributes every backend-initialization exception to psutil setup, even when a dependency is installed and the failure is a different exception.

**Source:** `resource_service.py:27–35,65–69`; `resource_ui.py:268–282`.

**Planned correction, not implemented:** Per-collector lifecycle and bounded retry, a manual retry operation, and differentiated sanitized failure reasons. A failed optional sensor must not block healthy sensors, and recovery must not create duplicate collectors. Test dependency failure separately from transient initialization failure.

## R2 — GPU provider health can claim availability without usable data

**Classification:** Reproduced status-reporting defect.

The NVIDIA parser preserves metric entries when counters are `N/A`, correctly setting their values to unavailable. The service, however, tests whether the metric dictionary is nonempty rather than whether any contained measurement is valid. Four unavailable metric entries therefore set the provider health to `Available` and reset its failure counter.

Controlled reproduction: input `0, Test GPU, N/A, N/A, N/A, N/A` produced four metric entries, zero valid numeric measurements, and an `Available` result from the current health expression. The individual table values remain unavailable; the inconsistency is between overall provider health and the readings.

**Source:** `resource_backend.py:163–175`; `resource_service.py:119–131`.

**Planned correction, not implemented:** Distinguish provider present, sampling, usable measurements, partial data, unsupported counters, stale values, and failed collection. Determine health and retry behavior from valid measurements and failure causes, not container truthiness. The combined Disk / CPU thermal label also needs separation because disk availability does not establish temperature availability.

## V1 — An unreadable process name can obscure a detected VRCX process

**Classification:** Reproduced conservative-detection / presentation limitation; not proof of the user's specific failure.

The detector marks the complete enumeration incomplete when any process name is unavailable. That flag takes precedence over already-found VRCX matches. In a controlled input, one valid `VRCX.exe` record alone returned `RUNNING`; adding one record whose name was unavailable changed the result to `UNKNOWN`, even though the match count remained one.

The unknown-name record could represent an additional VRCX process, so this audit does **not** recommend pretending that uniqueness is established. The problem is that visible process presence, full-enumeration confidence, and authorization to coordinate consequential actions are currently conflated.

**Source:** `vrcx_companion_service.py:36–82`; existing detector tests already cover some incomplete-enumeration cases.

**Planned correction, not implemented:** Show that a VRCX process was observed while separately stating that enumeration/uniqueness is incomplete. Preserve conservative ownership and recovery-action checks. Add tests for a valid matching process combined with denied/unreadable unrelated observations, disappearance, multiple roots, and recovery after a provider gap. Native Windows testing is still required.

## R3 — Several displayed resource metrics lack a Windows implementation

**Classification:** Source-confirmed capability gaps, not failures of every resource counter.

The current GPU backend uses NVIDIA's installed `nvidia-smi`, then a Linux AMD sysfs fallback. It contains no Windows AMD or Intel GPU collector. On Windows without a usable NVIDIA path, these GPU readings have no working provider in this build. The selected device index is also a manual setting, so an unavailable index is a separate possible cause.

CPU temperature uses `psutil.sensors_temperatures` with Linux sensor names. The psutil 7.2.2 reference lists this function for Linux and FreeBSD, not Windows. No alternate Windows CPU-temperature provider exists in the inspected backend.

`gpu.process` (VRChat-specific GPU memory) is present in the metric catalog, but neither resource backend supplies it. The Resource Guard diagnostic text explicitly calls it unavailable. Device-wide GPU memory should not be relabeled as VRChat-only memory.

**Sources:** `resource_backend.py:124–206`; `resource_core.py:36`; `resource_ui.py:310`; psutil 7.2.2 documentation, Sensors section, reviewed October 2, 2026.

**Planned correction, not implemented:** A hardware/platform capability inventory, honest unsupported/disabled/error states, automatic supported-device discovery where feasible, and separate provider work for additional hardware. Any new provider must feed the existing shared resource service rather than create a second monitoring system. Do not promise universal temperature or per-process GPU coverage before testing the provider.

## V2 — Companion scope and legacy settings are easy to misinterpret

**Classification:** Source-confirmed implementation scope and UI clarification work.

Companion Mode defaults off. When enabled, it observes process presence and coordinates **VRC Eye's own behavior**. It is not an authenticated or negotiated connection to VRCX. Changing an ownership preference does not send a setting change to VRCX.

The included guide says that Discord publication, automatic restart, and account/session popup publication do not have active VRC Eye publishers in this baseline. The application coordinator explicitly reports the corresponding own-app capabilities as off. Those rows must not imply that selecting an owner implements the feature.

Social suppression is real but narrow: it affects eligible local player banners, not every future social notification surface. The planned 1.19.10 inbox and notifications therefore need integration with this existing coordinator, not another independent ownership system.

The legacy avatar-cache toggle/path is separate from Companion Mode. Enabling one does not enable or validate the other. The reader expects an accessible local `VRCX.sqlite3` with a `cache_avatar` table and expected columns. This audit did not inspect the user's actual database and did not establish a current schema mismatch. The older cache reader is also a legacy dependency to label and review against the project's preference for documented handoffs and explicit exchange.

**Sources:** `VRCX_COMPANION_SETUP.md:10–56`; `companion_ui.py:402–418`; `vrcx_companion_model.py`; `vrcx_integration.py:45–82,99–144`.

**Planned correction, not implemented:** Separate process detection, coordination enablement, declared external settings, legacy cache health, and handoff readiness. Label preference-only/unimplemented capability rows clearly. Reuse the same coordinator across Social, notifications, runtime, and recovery.

## V3 — VRCX handoffs need installation-specific checks

**Classification:** Verification pending on the user's machine; not a reproduced handoff defect.

The local handoff module constructs allowlisted `vrcx://` detail requests and submits them to the OS handler. Its return status deliberately does not claim that VRCX focused a page or completed a login. VRCX's published Windows installer registers the URI protocol. Registration on the user's actual installation and successful delivery were not tested here.

**Sources:** `vrcx_handoff.py:1–52`; VRCX upstream `Installer/installer.nsi:179–185`, reviewed October 2, 2026.

**Planned checks, not implemented:** Inspect handler availability without changing the registry, distinguish submitted from confirmed, and test installed/portable configurations deliberately. Do not treat OS request acceptance as a VRCX receipt.

## T1 — Existing test results and native UI check

203 existing tests selected from:

- `test_resource_guard`
- `test_resource_workflow`
- `test_vrcx_companion`
- `test_vrcx_companion_workflow`
- `test_vrcx_routing`
- `test_vrcx_handoff`
- `test_vrcx_exchange`
- `test_vrcx_integration`

**Result:** 203 run, 0 failures, 0 errors, 0 skipped.

The native Linux UI check constructed the real application, opened Resource Guard and VRCX Companion, allowed actual local collection, and captured Tk callback errors. RAM/CPU/basic process collection produced fresh readings; the Resource Guard page displayed a fresh sample. The companion detector correctly reported no VRCX process in the test environment. GPU unavailability was expected for this environment. No Tk callback errors were captured during the short run.

These tests establish only the exercised behaviors. Several existing workflow tests substitute widgets and replace collector startup; passing them does not test real Windows sensors, process permissions, URI registration, or a signed-in VRCX application. The three additional reproductions expose gaps beyond the existing passing tests.

## Repair planning for 1.19.10

Treat these as a repair track alongside Social / Accounts, not a duplicate feature expansion. First repair collector lifecycle and health reporting; clarify process detection and capability state; then connect the expanded social notification routes to the existing Companion coordinator. Add regression tests before enabling new code in a release.

Keep missing dependencies, monitoring disabled, Safe Mode/Demo suspension, no running game, denied process access, unsupported hardware, and stale results visibly distinct. Both the core resource collector and VRCX process detector depend on psutil, making its load status a useful shared diagnostic. This is an investigation lead, not a confirmed explanation of the user's current symptoms.

The exact Windows issue remains open pending local evidence. No user credentials, game logs, database, hardware inventory, or VRCX installation was available in this audit.

## Evidence excerpts

The following excerpts are from the unchanged 1.19.9 archive. Numbers are original source line numbers.

### `resource_service.py:27–35`

```text
27:     def start(self):
28:         with self.lock:
29:             if any(t.is_alive() for t in self.threads):
30:                 if self.stop.is_set(): raise ValueError("A resource collector is still stopping. It cannot be duplicated.")
31:                 return
32:             self.stop=threading.Event(); self.generation+=1; self.status="Collecting"; self.sample=None; self.aux={}
33:             self.engine=RuleEngine(parse_rules(self.settings["rules"])); self.health={}; self.simulated=False
34:             self.threads=[threading.Thread(target=fn,daemon=True,name="VRC-Eye-Resource-"+name) for fn,name in ((self._recover,"JournalCheck"),(self._core,"Core"),(self._gpu,"GPU"),(self._disk,"Disk"))]
35:             for t in self.threads:t.start()
```

### `resource_service.py:65–69`

```text
65:     def _core(self):
66:         try: backend=self.core_factory()
67:         except Exception:
68:             with self.lock:self.status="Core unavailable — reopen Start.cmd online to finish automatic psutil setup"; self.health["Core"]="Unavailable"
69:             return
```

### `resource_service.py:119–131`

```text
119:         failures=0
120:         while not self.stop.is_set():
121:             with self.lock:enabled=self.settings["gpu"]; index=self.settings["gpu_index"]; generation=self.generation
122:             if enabled:
123:                 try: values,name=backend.sample(index,at=self.clock())
124:                 except Exception:values,name={},"GPU collector failed"
125:                 with self.lock:
126:                     if generation==self.generation and not self.stop.is_set():
127:                         self.aux["gpu"]=values;self.gpu_name=name;self.health["GPU"]="Available" if values else "Unavailable"
128:                 failures=0 if values else min(failures+1,5)
129:             else:
130:                 with self.lock:self.aux.pop("gpu",None);self.health["GPU"]="Disabled"
131:             self.stop.wait(min(30,3*2**failures))
```

### `vrcx_companion_service.py:45–72`

```text
45:         try:
46:             iterator = self.psutil.process_iter(['pid', 'name', 'create_time', 'ppid'], ad_value=None)
47:             for index, process in enumerate(iterator):
48:                 if index >= 8192 or self.clock() - started > 2.:
49:                     return observation(at=self.clock(), reason='incomplete')
50:                 info = process.info
51:                 name = info.get('name')
52:                 if not isinstance(name, str):
53:                     incomplete = True
54:                     continue
55:                 if name.casefold() not in ('vrcx.exe', 'vrcx'):
56:                     continue
57:                 pid, created, parent = info.get('pid'), info.get('create_time'), info.get('ppid')
58:                 if (type(pid) is not int or not 0 < pid < 2**32 or not number(created) or
59:                         created <= 0 or type(parent) is not int or not 0 <= parent < 2**32):
60:                     incomplete = True
61:                     continue
62:                 matches[pid] = (created, parent)
63:         except Exception:
64:             return observation(at=self.clock(), reason='permission')
65:         at = self.clock()
66:         if incomplete:
67:             return observation(at=at, count=len(matches), reason='incomplete')
68:         if not matches:
69:             return observation('ABSENT', at=at, reason='absent')
70:         roots = [(pid, values[0]) for pid, values in matches.items() if values[1] not in matches]
71:         if len(roots) != 1:
72:             return observation('AMBIGUOUS', at=at, count=len(matches), reason='ambiguous')
```

### `resource_backend.py:139–147`

```text
139:                 values[f"disk.{kind}.free"] = metric(info.free, "psutil.disk_usage ("+kind+")", at, 15)
140:                 if kind == "data": values["disk.data.fraction"] = metric(info.free/info.total, "psutil.disk_usage", at, 15, 1)
141:             except Exception: values[f"disk.{kind}.free"] = Metric(source="Disk collector", at=at, reason="Path missing or drive inaccessible")
142:         try:
143:             sensors = self.ps.sensors_temperatures()
144:             temps = [s.current for name, rows in sensors.items() if name in ("coretemp", "k10temp", "cpu_thermal", "zenpower") for s in rows if number(s.current) and 0 <= s.current <= 150]
145:             if temps: values["cpu.temperature"] = metric(max(temps), "psutil CPU thermal sensors", at, 15, 150)
146:         except Exception: pass
147:         return values
```

### `resource_backend.py:163–175`

```text
163:     @staticmethod
164:     def parse_nvidia(text, index, at):
165:         if len(text) > 65536: raise ValueError("GPU response too large")
166:         rows = list(csv.reader(io.StringIO(text)))
167:         row = next((r for r in rows if len(r)==6 and r[0].strip()==str(index)), None)
168:         if row is None: return {}, "Selected NVIDIA GPU unavailable"
169:         values = {}
170:         for key, raw, multiplier, maximum in zip(("gpu.total","gpu.used","gpu.load","gpu.temperature"), row[2:], (1024**2,1024**2,.01,1), (None,None,1,150)):
171:             try: value = float(raw.strip())*multiplier
172:             except ValueError: value = None
173:             values[key] = metric(value, f"NVIDIA device {index}", at, 10, maximum)
174:         GpuBackend.derive(values, at)
175:         return values, f"NVIDIA GPU {index} (device-wide)"
```

### `resource_backend.py:185–197`

```text
185:     def sample(self, index=0, at=None):
186:         at = time.monotonic() if at is None else at
187:         if self.smi:
188:             try:
189:                 result = self.run([self.smi,"--query-gpu=index,name,memory.total,memory.used,utilization.gpu,temperature.gpu","--format=csv,noheader,nounits"],
190:                     capture_output=True, text=True, timeout=2, check=True,
191:                     creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0) if os.name=="nt" else 0)
192:                 return self.parse_nvidia(result.stdout, index, at)
193:             except (OSError, ValueError, subprocess.SubprocessError): pass
194:         # AMD sysfs is read-only and isolated in its own worker.
195:         cards = sorted((p for p in self.sysfs.glob("card[0-9]*") if p.name[4:].isdigit()), key=lambda p:int(p.name[4:]))
196:         amd = [p for p in cards if (p/"device/mem_info_vram_total").is_file()]
197:         if index >= len(amd): return {}, "GPU backend unavailable; device index or driver unsupported"
```

### `resource_core.py:30–38`

```text
30:     "gpu.used": ("GPU device VRAM used", "bytes"),
31:     "gpu.total": ("GPU device VRAM total", "bytes"),
32:     "gpu.available": ("GPU device VRAM available", "bytes"),
33:     "gpu.fraction": ("GPU device VRAM usage", "fraction"),
34:     "gpu.load": ("GPU device utilization", "fraction"),
35:     "gpu.temperature": ("GPU temperature", "celsius"),
36:     "gpu.process": ("VRChat GPU memory", "bytes"),
37:     "disk.data.free": ("VRC Eye data drive free", "bytes"),
38:     "disk.data.fraction": ("VRC Eye data drive free fraction", "fraction"),
```

### `companion_ui.py:372–384`

```text
372:     def tick(self):
373:         if self.closed: return
374:         if getattr(self, "developer", None): self.developer.account_changed()
375:         blocked = bool(self.app.demo or getattr(self.app, "safe_mode", False))
376:         self.companion.set_environment(blocked)
377:         if not blocked: self.companion.start()
378:         if not getattr(self, "auto_resource_checked", False):
379:             self.auto_resource_checked = True
380:             self.ensure_page("Performance & Security")
381:         if not getattr(self, "auto_crash_checked", False):
382:             self.auto_crash_checked = True
383:             self.ensure_page("Crash & Diagnostics")
384:         if not getattr(self, "auto_unity_checked", False):
```

### `companion_ui.py:405–412`

```text
405:         if unity:
406:             snap = unity.service.snapshot()
407:             self.companion.runtime_boundary((snap['generation'], snap['identity']))
408:         players = getattr(self.app, 'player_sessions', None)
409:         prefs = players.settings if players else {}
410:         social = (prefs.get('notify_friends') or prefs.get('notify_pinned')) and not any(prefs.get(k) for k in ('notifications_muted', 'companion_notifications', 'presentation'))
411:         self.companion.set_eye_features({'SOCIAL': 'on' if social else 'off', 'ACCOUNT': 'off', 'SESSION': 'off',
412:             'PRESENCE': 'off', 'LAUNCH': 'on' if unity and unity.settings['enabled'] else 'off', 'RESTART': 'off'})
```

### `VRCX_COMPANION_SETUP.md:10–24`

```text
10: ## First use
11: 
12: Companion Mode defaults **off**. Enable it and choose Balanced, VRCX Primary, or
13: VRC Eye Primary. The page observes process presence and applies VRC Eye's own
14: preferences. It does not establish a negotiated connection to VRCX. Process
15: presence does not prove responsiveness, account login, notification delivery,
16: Discord publication or restart activity.
17: 
18: Casual shows Overview and Tools. Advanced adds Ownership and Diagnostics.
19: Developer adds decision reasons, process generation/PID, normalized event history
20: and an isolated simulation. Tabs and sidebar navigation scroll vertically.
21: 
22: The old optional read-only avatar-cache setting remains independent of Companion
23: Mode. Existing enabled/path preferences are preserved. Its location and records
24: are not copied into Companion diagnostics.
```

### `VRCX_COMPANION_SETUP.md:38–56`

```text
38: These are preferences while a unique VRCX process has been observed, not commands
39: sent to VRCX. Core responsibility cannot be transferred. Each shared category can
40: use its preset or an explicit override. VRCX feature settings are **user declared**:
41: Unknown, Enabled or Disabled. A declared Disabled feature releases its preference
42: to VRC Eye. Unknown remains unverified rather than being inferred from the process.
43: Changing a preset retains explicit category overrides; Reset overrides removes them.
44: 
45: VRC Eye currently has no Discord Rich Presence publisher, automatic restart engine,
46: or account/session popup publisher. Their ownership rows prepare arbitration and
47: show availability; selecting an owner does not create those features. Existing
48: runtime monitoring, Black Box and Resource Guard keep their own settings. No
49: unimplemented Safety protection is claimed by the companion page.
50: 
51: When VRCX owns SOCIAL, VRC Eye suppresses eligible Player List friend/pinned-player
52: banners. The event still updates the roster, session timeline and configured local
53: history. Runtime/resource alerts are not routed through this social suppression.
54: The former Player Settings switch is now **Always suppress VRC Eye player banners
55: (legacy)** in Companion Tools. Its existing value is preserved, including in Solo
56: Mode; uncheck it explicitly when testing banners.
```

### `vrcx_integration.py:62–76`

```text
62: def load_vrcx_settings(path: Path) -> dict:
63:     if path == settings_path() and not path.exists():
64:         legacy = path.parent.parent / "AvatarWatch/settings.json"
65:         if legacy.is_file():
66:             path = legacy
67:     defaults = {"vrcx_enabled": True, "vrcx_database": str(default_vrcx_database())}
68:     try:
69:         if path.stat().st_size > 65536:
70:             return defaults
71:         value = json.loads(path.read_text(encoding="utf-8"))
72:         if not isinstance(value, dict):
73:             return defaults
74:         if isinstance(value.get("vrcx_enabled"), bool):
75:             defaults["vrcx_enabled"] = value["vrcx_enabled"]
76:         database = value.get("vrcx_database")
```

### `vrcx_integration.py:99–127`

```text
99: def _database_path(location: Path) -> Path:
100:     path = location.expanduser()
101:     if path.is_dir():
102:         path = path / "VRCX.sqlite3"
103:     if not path.is_file():
104:         raise VRCXError("VRCX database not found. Open Advanced → VRCX Companion → Avatar cache settings… and select VRCX.sqlite3.")
105:     return path
106: 
107: 
108: @contextmanager
109: def open_vrcx_readonly(location: Path):
110:     connection = None
111:     try:
112:         path = _database_path(location)
113:         connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True,
114:                                      timeout=0.75, isolation_level=None)
115:         connection.execute("PRAGMA query_only=ON")
116:         connection.execute("PRAGMA trusted_schema=OFF")
117:         deadline = time.monotonic() + 2.0
118:         connection.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
119:         connection.row_factory = sqlite3.Row
120:         # Read this one known table; a view or an unrelated database is not used.
121:         table = connection.execute("SELECT type FROM sqlite_master WHERE name = ?", ("cache_avatar",)).fetchone()
122:         if not table or table[0] != "table":
123:             raise VRCXError("This database has no supported VRCX avatar cache (cache_avatar). Check the selected file and VRCX version.")
124:         columns = {row[1] for row in connection.execute('PRAGMA table_info("cache_avatar")')}
125:         if not {"id", "name"}.issubset(columns):
126:             raise VRCXError("The VRCX avatar-cache format is not supported: id/name columns are missing.")
127:         yield connection, columns, path
```

## Recorded native GUI output

```text
GUI constructed
Resource page: True
Resource state: {'status': 'Monitoring', 'age': 0.0908816700000159, 'stale': False, 'health': {'Disk / CPU thermal': 'Available', 'GPU': 'Unavailable', 'Core': 'Available'}}
Resource UI: Resource Guard • Healthy VRChat not running • Updated 0.1s ago
Companion: {'state': 'ABSENT', 'health': 'Not running; VRC Eye remains independent', 'provider': 'Process observations only', 'reason': 'absent'}
Errors: 0
```

## Recorded edge-case output

```text
CASE 1: Resource core initialization fails once; other collectors stay alive
Before retry: Core unavailable — reopen Start.cmd online to finish automatic psutil setup factory_calls= 1
After start retries: Core unavailable — reopen Start.cmd online to finish automatic psutil setup factory_calls= 1 sample= None
Threads: [('VRC-Eye-Resource-JournalCheck', False), ('VRC-Eye-Resource-Core', False), ('VRC-Eye-Resource-GPU', True), ('VRC-Eye-Resource-Disk', True)]

CASE 2: One valid VRCX process plus one process whose name is unavailable
Valid VRCX alone: {'state': 'RUNNING', 'at': 304.063060882, 'identity': (42, 1000.0), 'count': 1, 'reason': 'observed'}
With unreadable-name process: {'state': 'UNKNOWN', 'at': 304.063102905, 'identity': None, 'count': 1, 'reason': 'incomplete'}

CASE 3: GPU returns entries, but every numeric counter is unavailable
Parsed metric entries: 4 Valid numeric metrics: 0
Current service health expression: Available
```

## External primary references

Reviewed only for provider/platform and handoff context, not as evidence of the user's local installation:

- psutil 7.2.2 documentation, Sensors: `https://psutil.readthedocs.io/stable/#sensors`
- VRCX Windows installer source: `https://github.com/vrcx-team/VRCX/blob/master/Installer/installer.nsi`

The attempt to locate the current upstream database implementation at the older `src/services/database.js` path was unsuccessful; no conclusion about the current VRCX database schema is based on that attempt.
