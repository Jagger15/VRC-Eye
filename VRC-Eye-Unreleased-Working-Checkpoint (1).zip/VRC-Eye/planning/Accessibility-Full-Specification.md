# VRC Eye Accessibility System — Expanded Planning Specification

Accessibility should be a **core part of how VRC Eye works**, not a collection of appearance settings added after everything else is finished.

The goal is broader than “make the text bigger.” A user should be able to launch VRC Eye, configure it, sign in, understand its current state, operate its features, recover from mistakes, and exit safely **without depending on any one particular ability, input device, sensory channel, or physical posture**.

That also means accessibility has to reach the less glamorous parts of the application: login errors, confirmation dialogs, notification history, file pickers, developer tools, disconnected-device warnings, profile imports, and startup recovery.

This is an expanded **planning specification**, not a claim that these features are already implemented or verified. It preserves our earlier direction: build accessibility-friendly foundations early, introduce features in manageable stages, and keep Casual, Advanced, and Developer experiences within the same application rather than creating a separate, limited “accessible edition.”

For reference, I would use WCAG 2.2 as a baseline for applicable desktop-interface requirements, with WCAG2ICT guidance for interpreting those requirements in non-web software. XR needs additional evaluation: W3C’s XR Accessibility User Requirements is useful guidance, but it explicitly is not a formal baseline or certification checklist. [W3C](https://www.w3.org/TR/WCAG22/?utm_source=chatgpt.com)

---

# Part I — The foundation

## 1. What accessibility must mean in VRC Eye

### Accessibility is available before authentication

A person who needs larger text, keyboard navigation, or screen-reader support must not have to complete an inaccessible login screen to enable those features.

The initial launcher, first-run setup, login window, account selector, error messages, and update/recovery interface should all load the applicable accessibility preferences before displaying their normal content.

There should be a clearly named **Accessibility** entry on the first screen. It should work offline and without a VRChat account.

Accessibility should also remain available when authentication fails, a session expires, the network is unavailable, or the user chooses to use local-only features.

### Accessibility does not depend on Developer Mode

Basic accessibility must not require Advanced Mode, Developer Mode, a custom client, a Client Bridge, an API experiment, or a separate plugin.

A future bridge might expose additional information useful to an accessibility feature, but it must not become a prerequisite for operating VRC Eye itself.

Likewise, switching from Casual to Advanced Mode should not disable enlarged controls, reduce contrast, restore animations, or make previously accessible controls inaccessible.

**Interface complexity and accessibility are separate settings.**

### Equivalent access does not require identical presentation

A sighted user might inspect a performance graph. A screen-reader user might inspect its current value, range, trend, and underlying table.

A VR user might activate an overlay button. A desktop user might activate the same command from a toolbar or command search.

These are different presentations of the same capability, not different feature tiers.

The important requirement is that users receive equivalent information, authority, and task outcomes. An alternative should not omit critical details or require an unreasonable number of additional steps.

### Accessibility must preserve agency

VRC Eye should not infer that someone needs a particular mode because of their behavior, avatar, age, voice, or presumed disability.

It can offer useful controls and optional presets. It should not diagnose the user, assign them a disability category, or silently decide that they need a simplified experience.

A user should be able to combine preferences freely: large text with a dense layout, screen narration with visual notifications, reduced motion with Advanced Mode, or one-handed controls with Developer Mode.

### Accessibility must include recovery

Every accessibility setting that can make interaction harder must have a recovery path.

That includes a theme with unreadable colors, an oversized interface, an off-screen window, a remapped shortcut that conflicts with another application, an overlay placed out of view, or narration routed to a disconnected device.

A system that can be configured accessibly but cannot be recovered accessibly is unfinished.

---

## 2. Where accessibility belongs in the interface

I would give it a permanent location:

**Settings → Accessibility**

The main Accessibility page should begin with a small set of commonly needed adjustments: text size, interface size, contrast, reduced motion, larger controls, narration, and notification persistence.

More specialized settings can sit underneath clearly named sections such as **Reading and display**, **Keyboard and controls**, **Audio and captions**, **Notifications**, **VR overlay**, and **Profiles and recovery**.

The categories should describe what the setting changes rather than asking the user to identify with a medical label.

### Make settings discoverable in more than one place

A setting should have one underlying value but may be discoverable from several relevant screens.

For example, notification duration belongs in Notifications and should also be reachable from Accessibility. Overlay scale belongs in Overlay Settings and should also appear in Accessibility.

These should be links or shared controls bound to the same setting—not separate copies that drift out of sync.

Settings search should recognize practical phrases such as “text too small,” “stop animation,” “make alerts stay,” “use one controller,” and “read buttons aloud.” The result should show the setting’s location and current value.

### Provide an accessible setup assistant

An optional first-run assistant could offer a few independent steps:

**Reading**, **controls**, **alerts**, and **VR comfort**.

Each step should include a preview, a plain-language explanation, and a visible way to skip or return. It should not become a lengthy questionnaire or require the user to disclose why they need a feature.

The assistant itself must already support keyboard navigation, readable defaults, and assistive technology. It cannot depend on completing its own configuration to become usable.

### Include a harmless preview environment

Users should be able to test a notification, a focused button, a warning message, a table, and a small overlay without affecting VRChat.

A test should never send a real invite, activate a real safety action, change account state, or publish a message.

The preview should explicitly say **Test notification** or **Preview only** so that its contents cannot be mistaken for a live event.

---

# Part II — Visual accessibility

## 3. High contrast

High contrast should be a complete rendering mode, not a dark background with brighter text.

It must cover panels, controls, borders, focus indicators, selected rows, disabled states, charts, tooltips, dialogs, notifications, and overlay backgrounds.

### Offer several contrast approaches

I would support **Follow operating system**, **High-contrast dark**, **High-contrast light**, and **Custom**.

Following the operating system should mean using the applicable platform accessibility preferences where the toolkit supports them—not guessing from whether the operating system uses an ordinary dark theme.

Dark mode and high-contrast mode should remain separate concepts.

### Define measurable contrast targets

As a baseline, ordinary text should meet a contrast ratio of at least **4.5:1**, with **3:1** permitted for text that qualifies as large under WCAG’s definition. Important non-text interface boundaries and state indicators have their own **3:1** contrast requirement against adjacent colors. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html?utm_source=chatgpt.com)

For VRC Eye, I would additionally offer an enhanced-contrast preset targeting **7:1 for ordinary body text** wherever practical. That would be a product choice beyond the baseline, not a reason to make all users use extreme contrast.

### Test every state, not just the default screenshot

A button might be readable normally but fail when hovered. A selected row might obscure its text. A warning banner might become unreadable when disabled.

The theme system should therefore define and test normal, hover, focused, pressed, selected, checked, loading, unavailable, warning, and error states.

Unavailable controls should remain understandable. VRC Eye should avoid reducing their opacity so aggressively that users cannot read what the unavailable action is.

### Remove decorative dependencies

In high-contrast mode, controls should not rely on soft shadows, translucent glass, background blur, or subtle gradients to indicate their boundaries.

Important sections should have visible structure. A text field should still look like a text field when shadows disappear.

Icons should use theme-aware rendering rather than fixed colors baked into image files.

### Treat VR overlays separately

Text over an unpredictable VR scene cannot be evaluated as though it always sits on a fixed desktop background.

The overlay should offer an opaque or strongly backed reading panel. Increasing background opacity should not require increasing the brightness of the text.

A high-contrast overlay should preserve contrast even when the world behind it is bright, dark, or visually busy.

### Custom-color validation

When someone chooses custom colors, VRC Eye should show a live preview and indicate which combinations are difficult to distinguish.

It should offer a repair suggestion, such as adjusting the foreground or panel color, without silently replacing the user’s choices.

The accessibility recovery controls must remain available even when the custom theme is unusable.

---

## 4. Scalable text and interface

Text size, overall interface scale, and control size should be related but independently adjustable.

Someone may need larger text without enormous spacing. Another person may read small text comfortably but need larger buttons.

### Separate the major scale controls

**Text scale** should affect labels, descriptions, values, menus, notifications, and tooltips.

**Interface scale** should affect the overall geometry of panels and controls.

**Control size** should affect clickable or touchable targets.

**VR overlay scale** should control the overlay’s apparent size independently of the desktop window.

These settings should not blindly multiply until the interface becomes enormous. The settings page should show the effective result and explain when one setting is already being incorporated into another.

### Require real reflow

When text becomes larger, the layout should reorganize.

Labels should wrap when appropriate. Toolbars should move less-used actions into an accessible overflow menu. Sidebars should be collapsible. Two-column settings pages should become one column when needed.

A larger font should not merely be painted over a fixed-height button.

As a baseline, text enlargement to **200%** should not cause loss of content or functionality. For suitable web-like content, WCAG’s reflow criterion uses a width equivalent to **320 CSS pixels**, commonly corresponding to a 1280-pixel-wide viewport at 400% zoom; native interfaces need an appropriate equivalent evaluation rather than a blind pixel substitution. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/resize-text.html)

### Avoid automatic shrinking

An especially important rule:

**VRC Eye should not secretly shrink text to make it fit after the user has enlarged it.**

If content no longer fits, the application should wrap it, restructure it, or provide a clearly accessible expanded view.

Long account names, world names, paths, and localized labels need particular attention.

### Preserve the complete value

Some dense tables may still need truncation. In that case, the full value should be available through focus, an expanded detail view, and copying—not only a mouse-hover tooltip.

A screen reader should receive the complete meaningful value rather than an ellipsis.

### Handle multiple displays

Moving VRC Eye between monitors with different display scaling should not lose the window, shrink its controls unexpectedly, or separate hit targets from their visible buttons.

Window position should be validated at startup. A saved location on a disconnected monitor should be recoverable without editing a configuration file.

### Keep the controls for changing scale accessible

The scale setting should have visible increase, decrease, and reset controls, plus direct value entry where appropriate.

A tiny slider cannot be the only way to make the interface larger.

---

## 5. Readable typography and density controls

Typography should be configurable without turning the application into a font-management project.

### Default typography

The default should favor clear letterforms, distinguishable numbers, and readable punctuation.

Long explanatory text should not use all capitals, thin decorative lettering, or condensed display fonts.

Technical identifiers can use a monospaced font, but the entire Developer interface should not become a wall of small monospaced text.

Users should be able to change the interface font from a supported selection or use the system default.

Alternative fonts should be presented as preferences—not as treatments or guaranteed solutions for particular conditions.

### Spacing controls

Reading settings should include line spacing and, where supported, paragraph, letter, and word spacing.

A useful compatibility test comes from WCAG text-spacing guidance: supported markup content should tolerate line spacing of 1.5 times the font size, paragraph spacing of twice the font size, letter spacing of 0.12 times, and word spacing of 0.16 times without losing information or functionality. These are override-tolerance tests, not mandatory default styling. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/text-spacing.html)

For VRC Eye, the same principle should apply to its native layouts: increasing spacing must not cut off the lower half of a label or hide the final line of an explanation.

### Density is not the same as text size

I would provide **Comfortable**, **Balanced**, and **Compact** density.

Comfortable density would create more separation between controls and sections. Compact density would reduce unnecessary spacing while retaining readable labels and usable targets.

Large text plus Compact density should remain a valid combination.

### Reading aids

A detail panel could offer a focused reading view with a narrower line length and fewer surrounding distractions.

Long help text should have headings, meaningful links, and a clear reading order. Copying it should preserve the text rather than produce a screenshot.

Technical abbreviations should have discoverable explanations, especially in Casual Mode.

---

## 6. Color-independent status indicators

No important status should be communicated only through color.

This applies to connection state, account state, friend status, permissions, warnings, API risk, synchronization, pending operations, and safety features.

### Use a redundant status vocabulary

Each important state should have a text label and, where useful, a distinct icon or shape.

For example:

| State           | Proposed presentation                            |
| --------------- | ------------------------------------------------ |
| Connected       | Connection icon and “Connected”                  |
| Connecting      | Progress indicator and “Connecting…”             |
| Disconnected    | Broken-link icon and “Disconnected”              |
| Warning         | Warning icon and a specific explanation          |
| Action required | Action symbol and an explicit next step          |
| Unknown         | Question-mark icon and “Status unavailable”      |
| Stale           | Clock symbol and the last successful update time |

The icons should supplement the words, not replace them.

### Distinguish “unknown” from “bad”

An unavailable status must not automatically become a warning or failure.

If VRC Eye cannot determine whether an action succeeded, it should say **Outcome unknown**, not show a green success indicator or a red definitive failure.

Similarly, old information should be labeled as old. “Last updated 12 minutes ago” is more useful than a colored dot that still looks current.

### Apply the same rule to graphs

Multiple graph series should differ by labels, line styles, markers, or patterns—not only hue.

A selected graph series should remain distinguishable in a monochrome view.

Warnings on a timeline should have meaningful labels and accessible event details.

---

## 7. Colorblind palettes

Alternative palettes are useful, but they should be an additional layer rather than the foundation of status communication.

### Palette selection

I would offer a small set of carefully tested palettes with a preview of actual interface states: success, warning, error, selection, focus, graph lines, and badges.

The labels can explain which color distinctions the palette emphasizes. Users should also be able to adjust individual semantic colors.

Avoid presenting a palette as universally correct for everyone associated with a particular color-vision category.

### Palette changes must preserve meaning

Changing the palette should not change which icon means warning or which line style represents a particular graph series.

The semantic meaning stays stable while the colors change.

### Separate interface recoloring from content editing

Changing the accessibility palette should recolor VRC Eye’s own interface.

It should not recolor photos, avatar thumbnails, or world images unless the user explicitly enables a separate viewing filter.

A viewing filter must not modify the original file.

### Include a monochrome evaluation mode

For testing, VRC Eye should offer an internal monochrome preview.

If a status panel becomes incomprehensible without color, that reveals a design problem that an alternative palette alone would not solve.

---

## 8. Reduced motion, reduced flashing, and reduced visual noise

These should be related settings, but not one single switch.

A person may be comfortable with a short fade but not sliding panels. Another may want animation removed entirely.

### Reduced motion behavior

When enabled, reduced motion should suppress nonessential panel slides, bouncing buttons, animated backgrounds, confetti, parallax, smooth camera-like transitions, and decorative pulsing.

Loading still needs to be understandable. A static “Loading…” label, a progress value, or occasional textual updates can replace an endlessly moving effect.

WCAG addresses disabling nonessential interaction-triggered animation, while Microsoft’s gaming guidance also treats visual distractions and motion settings as their own accessibility area. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html)

### No flashing alert design

I would make flashing warnings unnecessary by design.

Urgency should come from clear text, stable placement, appropriate contrast, and the user’s chosen sound or narration—not a rapidly flashing border.

WCAG includes a specific flashing threshold criterion, but VRC Eye should not treat that threshold as a target to approach. Its own interface can generally avoid flashing effects entirely. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/three-flashes-or-below-threshold.html)

### Control animated user content

Avatar images, world previews, shared media cards, or other supported animated content should have a static-preview option.

Autoplay should be independently configurable. A paused preview should remain paused after navigating away and back unless the user changes that preference.

### Reduce motion caused by live data

Rows that continually reorder, counters that resize their containers, and graphs that constantly shift can be disruptive even without decorative animation.

A **Stable live view** setting should keep the current layout stationary while showing a clear indicator that updates are available.

This should pause presentation changes—not silently stop underlying monitoring.

---

## 9. Magnification, pointer visibility, and text-caret visibility

These are important additions to the original list.

### Work with system magnification

The desktop interface should expose meaningful focus and control locations so that compatible assistive technology can track the active element.

VRC Eye should avoid custom rendering that leaves the operating system unaware of where the user is working.

Windows provides UI Automation for programmatic access to interface elements; on Linux, AT-SPI is the relevant accessibility infrastructure used by tools such as Orca. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/winauto/entry-uiauto-win32?utm_source=chatgpt.com)

### Optional local magnification

An in-app magnified detail view could be useful for photos, graphs, or dense diagnostic values.

It should have direct zoom controls, keyboard panning, a visible current zoom value, and **Fit**, **Actual size**, and **Reset view** actions.

It should not become a replacement for making ordinary controls readable.

### Pointer and caret controls

Within VRC Eye-controlled surfaces, offer a larger pointer or reticle, stronger pointer contrast, a clearer text caret, and a way to locate the current focus.

A locate-focus action should use a stable highlight rather than a flashing or rapidly expanding animation.

For VR, pointer size and selection feedback should be independent of the physical size of the controller model.

---

# Part III — Interaction and assistive technology

## 10. Keyboard navigation

Keyboard navigation should be a complete operating method, not a partial convenience.

Every essential task should be possible without a mouse.

### Follow familiar patterns

Tab should move between controls or control groups. Shift+Tab should move backward. Arrow keys should navigate inside appropriate composite controls such as lists, menus, tabs, and grids.

Enter and Space should behave according to the control’s role rather than triggering an arbitrary global action.

These conventions are reflected in W3C’s keyboard-interface guidance, which also distinguishes moving between components from moving within a component. [W3C](https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/)

### Define navigation regions

The main window should have recognizable regions: navigation, page content, contextual details, and notifications.

There should be a keyboard-accessible way to move directly between these regions rather than tabbing through every item each time.

A command search should also provide direct access to major destinations and actions.

### Avoid hundreds of Tab stops

A player list with hundreds of rows should not require hundreds of Tab presses to leave it.

The list itself can be a navigation region. Arrow keys move between rows; another command opens the selected row’s actions; Tab moves out to the next appropriate control.

The interaction model should be documented in the control’s accessible help.

### No hover-only features

Anything available through hovering should also be reachable through keyboard focus or a visible action.

A row’s action buttons should not disappear when the pointer leaves while keyboard focus is inside that row.

### Preserve normal text editing

Text fields should support familiar selection, copying, pasting, and cursor movement.

A global shortcut should not intercept ordinary typing, screen-reader navigation, or input-method composition.

In particular, pressing Enter to finish an input-method composition must not accidentally submit a login form or send a message.

### No keyboard traps

A user must be able to enter and leave every panel, popup, menu, and embedded control.

A modal dialog can intentionally contain focus while open, but it needs an accessible close or cancel path. Closing it should restore focus sensibly. These are established modal-dialog interaction principles. [W3C](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/)

---

## 11. Visible focus states

Focus tells the user where the next keyboard or controller action will apply.

It must be visually obvious and programmatically exposed.

### Distinguish focus from selection

A selected player and the currently focused control are not necessarily the same thing.

Selection might identify the player being inspected. Focus might be on the **Open profile** button.

Those states should look different.

A checked setting, hovered button, active tab, and focused tab also need distinct treatment.

### Use a robust focus indicator

I would use a clearly visible outline or border treatment that survives light themes, dark themes, high contrast, custom colors, and busy thumbnails.

Its thickness should scale with the interface.

It should not rely solely on a faint glow.

WCAG 2.2’s minimum requirement is that a focused component not be entirely hidden by author-created content. For VRC Eye, I would aim higher: keep the entire focused control and its label visible whenever the layout allows it. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html?utm_source=chatgpt.com)

### Manage focus after changes

Opening a dialog should move focus into it.

Closing a detail panel should return focus to its originating item when that item still exists.

Deleting a row should move focus to a logical neighboring item or the containing list—not nowhere.

Changing accounts should never restore focus to a control belonging to the previous account’s stale content.

### Do not steal focus for ordinary notifications

A new friend event, diagnostic update, or completed background task should not move the user away from what they are typing.

The notification can be announced or added to history without taking control.

Focus changes should generally correspond to the user’s own navigation or an explicit blocking interaction.

### Keep focus stable during live updates

If the user is inspecting a player row, a new event should not move another player into that row’s position and cause the next click to affect the wrong person.

The interface should retain item identity, not just row number.

---

## 12. Screen-reader support

This is much more than adding labels to buttons.

The screen reader needs a meaningful representation of the interface: what each element is, what it does, its current state, its value, and how it relates to other elements.

### Expose complete control information

A setting might need to expose:

> “Notification duration, combo box, Persistent selected.”

A button might need:

> “Invite Me, button. Sends a self-invite using the selected account.”

An unavailable control might need:

> “Edit world metadata, unavailable. The active account is not the world author.”

The visible explanation and accessible explanation should agree.

### Use meaningful names

Avoid labels such as “Button 12,” “Image,” “More,” or a raw icon filename.

A repeated action needs enough context to distinguish it from neighboring actions.

For example, **Open profile for Alex** is more useful than ten identical **Open profile** controls with no associated row information.

Where practical, the accessible name should include the visible label so that speech-control users can activate what they see. WCAG’s Label in Name criterion addresses this connection. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/label-in-name.html?utm_source=chatgpt.com)

### Preserve structure

Pages should expose headings, sections, lists, tables, tabs, and dialogs with appropriate semantics.

A settings page should not be announced as one enormous block of text.

Tables should expose column headers and meaningful row relationships. Sort order should be announced. A selected row should be distinguishable from an unselected row.

### Handle live updates carefully

A notification or search result update can be announced without moving keyboard focus.

Ordinary status changes should use a noninterrupting announcement approach. Truly urgent messages can have a separately controlled interrupting channel.

WCAG’s status-message guidance is specifically concerned with making relevant updates available to assistive technology without requiring focus to move to them. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html)

For VRC Eye, a performance counter should not announce every sample. A player list should not read every join and leave indefinitely unless the user chooses that level of detail.

Provide announcement frequency, batching, and verbosity controls.

### Make charts accessible

A graph should expose its title, time range, units, current value, minimum, maximum, and any notable labeled events.

It should provide an accessible data table or event list.

A useful summary could be:

> “Memory usage over the last ten minutes. Current value 3.2 gigabytes. Highest value 3.8 gigabytes. Two warning events.”

That summary should come from the same data as the graph.

### Make photos accessible without inventing facts

The Photos system should expose filename, capture date, dimensions, favorite state, user notes, and any reliably available world or session metadata.

Users should be able to add their own descriptions.

Optional generated descriptions could be considered later, but they should be clearly labeled as generated, editable, and potentially inaccurate. They should not infer real identities or sensitive personal attributes from an avatar or image.

### Avoid duplicate narration

Native screen-reader support and VRC Eye’s own optional text-to-speech should not both read the same control by default.

The user should be able to choose which system narrates navigation, notifications, and long-form content.

### Define platform support honestly

On Windows, accessibility work should be tested against the actual UI Automation behavior of the chosen toolkit. On Linux, it should be tested against the actual AT-SPI behavior and supported desktop environment. These are platform interfaces, not proof that VRC Eye automatically works with every assistive tool. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-uiautomationoverview?utm_source=chatgpt.com)

Native Linux operation and running a Windows build through a compatibility layer should be separate test configurations.

A functioning Windows screen-reader path should not be presented as proof of Linux support, or vice versa.

---

## 13. Large-control mode

Large-control mode should increase the usable target area and separation between actions.

It should not simply enlarge the icon inside the same tiny clickable rectangle.

### Proposed target sizing

For VRC Eye’s own desktop components, I would start with a preferred interactive target around **44–48 logical pixels**, with a large-control preset around **56–64 logical pixels**, then validate those choices through testing.

Those are proposed product dimensions, not universal accessibility thresholds.

For comparison, WCAG 2.2’s AA target-size criterion uses a minimum of **24 by 24 CSS pixels**, with specified exceptions and spacing provisions. That is a baseline, not an ideal size for every interaction. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html?utm_source=chatgpt.com)

### Increase separation where mistakes are costly

**Open**, **Invite**, **Remove**, and **Delete** should not become adjacent tiny targets in a crowded row.

Destructive actions should have appropriate spacing and, where useful, sit in a secondary menu rather than next to a routine action.

A larger invisible target must not overlap another target.

### Enlarge secondary controls too

Checkboxes, disclosure arrows, slider handles, scrollbar interaction areas, close buttons, and small overflow menus need attention.

It is not enough to enlarge the main toolbar while leaving every supporting control tiny.

### Avoid required precision gestures

Dragging should have a non-dragging alternative: move up/down buttons, destination selection, numeric position controls, or a **Move to folder** action.

WCAG’s dragging guidance specifically calls for an alternative single-pointer method where dragging is not essential. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/dragging-movements.html?utm_source=chatgpt.com)

---

## 14. Remappable hotkeys

Hotkeys should be built around named actions, not hard-coded key combinations scattered through the application.

### Create an action registry

Every remappable action should have a stable identifier, display name, description, scope, current binding, and availability state.

Examples include **Open Accessibility**, **Read current status**, **Repeat last notification**, **Open notification history**, **Show overlay**, and **Release active VRC Eye controls**.

The same action should be callable from a button, keyboard shortcut, controller binding, or approved alternative input.

### Separate shortcut scopes

**Application shortcuts** work only while VRC Eye is active.

**Panel shortcuts** work only in a particular interface region.

**Global shortcuts** work while another application is active and therefore require more careful conflict handling.

**VR bindings** apply to supported overlay interactions.

The settings page should show these distinctions clearly.

### Avoid accidental character shortcuts

Single-letter shortcuts should not trigger while typing or using assistive-technology navigation.

WCAG addresses this risk by requiring character-key shortcuts to be switchable, remappable, or active only when the relevant component has focus. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/character-key-shortcuts.html)

For VRC Eye, single-character global shortcuts should generally not be the default.

### Support alternatives to simultaneous chords

Users should be able to bind a simple key, a supported controller button, or a sequential shortcut where appropriate.

A sequential shortcut should have adjustable timing and a visible cancel path.

Core actions should never require holding three or four keys together.

### Make remapping itself accessible

The binding editor should be keyboard navigable and screen-reader labeled.

Recording a shortcut should clearly indicate when it begins and ends. The user must be able to cancel recording without the cancellation key accidentally becoming the new binding.

It should detect conflicts and explain them before applying changes.

### Handle unsupported global shortcuts honestly

If the operating system or current environment refuses a global shortcut, VRC Eye should report **Unavailable in this environment** and retain an in-app alternative.

It should not silently claim the shortcut is active.

It should not require broad keylogging behavior or elevated privileges merely to make ordinary accessibility controls work.

---

## 15. Alternative input and one-handed operation

This is another major addition.

Keyboard accessibility helps many input methods, but VRC Eye should also deliberately support low-precision, one-handed, and nontraditional interaction patterns.

### One-handed layouts

Offer left- and right-oriented control arrangements where relevant.

Important overlay actions should be reachable using one controller. A wrist interface should not require the other hand to activate every essential control.

Desktop operations should avoid mandatory two-handed key chords.

The user should be able to select their preferred side without changing unrelated display settings.

### Toggle alternatives to holding

Actions that normally require holding a control should have an appropriate toggle alternative when that can be implemented safely.

The active state must remain visible and accessible.

Toggling should not quietly create an indefinite game-input state. Actions that affect VRChat need their own explicit release and state handling.

### Switch-access compatibility

A user operating a keyboard-emulating switch should be able to reach essential controls using predictable navigation.

A later built-in scanning interface could offer automatic scanning and manual next/select modes, adjustable speed, group scanning, and a pause control.

Automatic scanning should remain optional. Manual scanning avoids forcing the user to respond within a moving time window.

### Dwell activation

For supported pointing or gaze-controlled interaction, optional dwell activation could activate a control after the pointer remains on it.

Dwell duration should be adjustable. Progress should be perceivable without requiring color or animation alone.

Looking at or resting on a destructive action should not immediately execute it. Such actions should require a separate deliberate confirmation.

### Pointer stabilization

An optional stabilized pointer mode could reduce small unintended movement in VRC Eye-controlled surfaces.

It should include a preview and a sensitivity setting.

It should not silently modify VRChat’s aiming, locomotion, or global pointer behavior.

### Speech control

The interface should work well with platform speech-control tools through meaningful control names.

A future built-in voice-command layer should be optional, visibly indicate listening state, distinguish dictation from commands, and require confirmation for sensitive actions.

Speech must never become the only accessible alternative.

---

## 16. No unnecessarily timed interactions

The principle should be:

**The user should not lose access to information or an action merely because they did not react quickly enough.**

### Remove artificial deadlines

Settings dialogs should not auto-close. Help text should not vanish while being read. A confirmation should not require a rapid response unless the underlying operation genuinely demands it.

A short toast should not be the only place an action exists.

WCAG’s timing guidance distinguishes adjustable application-controlled deadlines from genuinely essential or real-time limits, and it recognizes persistent alternative access as relevant to temporary notifications. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/timing-adjustable.html)

### Distinguish display time from validity

An invite may expire on the server even if its notification remains visible.

VRC Eye should preserve the information but update the action to **Expired** or **No longer available**.

Keeping a notification on screen must not imply that the underlying server action remains valid.

### Do not weaken authentication

Accessibility should make sign-in easier to operate, not bypass security or pretend a verification code is still valid.

When a code expires, explain what happened and preserve appropriate nonsecret context.

Avoid unnecessary re-entry, but do not retain sensitive values indiscriminately.

### Make Undo durable where possible

When an operation genuinely supports Undo, provide it in a persistent activity or history view rather than only in a five-second toast.

Do not show Undo for a server action that cannot reliably be reversed.

### Avoid reaction-based setup

Overlay calibration, audio testing, shortcut testing, and theme selection should not require users to click within a short countdown.

A deliberate **Continue** or **Keep these settings** interaction is preferable when technically feasible.

---

# Part IV — Alerts, communication, and comprehension

## 17. Visual equivalents for sounds

Every meaningful sound produced by VRC Eye should have a visual equivalent.

A sound that merely decorates an action can be disabled. A sound that conveys information needs another channel.

### Represent the meaning, not the waveform

A connection sound should correspond to **Connected**.

A warning sound should correspond to a specific warning.

A message sound should correspond to a visible message entry.

A generic flash saying “Sound occurred” is not equivalent information.

### Provide persistent discovery

The user should be able to discover missed events through notification history, a status panel, or an activity view.

The visual equivalent should not disappear before the user notices it.

### Avoid visually overwhelming substitutions

Replacing every sound with a large animated popup would create a different accessibility problem.

Users should be able to choose compact badges, text banners, persistent cards, or a grouped notification indicator.

### Respect scope

VRC Eye can provide reliable visual equivalents for events it generates or reliably observes.

It should not imply that it can identify every sound inside VRChat or automatically explain environmental audio it does not understand.

Any future audio-recognition feature would need its own capability limits, privacy controls, and uncertainty labeling.

---

## 18. Audio equivalents for visual alerts

Visual information should have optional spoken or audible equivalents where useful.

This requires an audio system designed around information priority and privacy.

### Separate audio channels

I would provide independent controls for interface sounds, notification sounds, spoken notifications, navigation narration, and optional novelty sounds.

Each should have its own volume or mute setting.

Microsoft’s audio-accessibility guidance includes configurable audio presentation and a mono option; these are useful reference points for VRC Eye’s own audio design. [Microsoft Learn](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/105)

### Make speech understandable

Spoken alerts should identify the event and the next useful action.

Instead of:

> “Warning.”

Use:

> “The VRC Eye connection is unavailable. Local tools are still running.”

Instead of reading a long technical error immediately, speak a summary and offer **Read details**.

### Control verbosity

A user should be able to select brief, normal, or detailed announcements.

Brief narration might say:

> “Photo saved.”

Detailed narration might include the folder and capture time, subject to privacy settings.

Identifiers, file paths, and diagnostic codes should be read on request rather than included in every routine announcement.

### Control the speech queue

Provide **Pause speech**, **Stop speech**, **Repeat last message**, **Read next message**, and **Open notification history**.

Low-priority announcements should not create an endless backlog.

New urgent information should not repeatedly interrupt itself because the underlying status is updating frequently.

### Mono and nonspatial options

VRC Eye-generated information should not depend on hearing which side an alert came from.

Offer mono output and a nonspatial narration mode.

Spatial cues can remain optional enhancements.

### Protect privacy when audio devices change

A disconnected headset should not automatically cause private messages to be read aloud through room speakers.

The user should choose the fallback behavior: pause speech, use the system default, or switch to another approved device.

A visible warning should explain when speech output is paused because the selected device is unavailable.

### Keep volume changes bounded

A “critical” alert should not override the user’s volume choice by suddenly playing at maximum volume.

Urgency is not permission to disregard accessibility preferences.

---

## 19. Adjustable and persistent notifications

Notifications should be one shared subsystem with accessibility built into its delivery rules.

Individual modules should not create their own incompatible popup behavior.

### Separate an event from its presentation

The underlying event should be recorded independently of whether a toast, sound, spoken message, or overlay card is shown.

Suppressing a notification must not suppress the event itself or prevent relevant state from updating.

That fits the notification-coordination direction we already discussed for VRC Eye and VRCX.

### Distinguish notification states

A notification should be able to represent:

**New**, **presented**, **read**, **acknowledged**, **dismissed**, **resolved**, and **expired**.

These are not interchangeable.

Reading a warning does not resolve the underlying problem. Closing a popup does not necessarily acknowledge it. A server action expiring does not mean the user dismissed it.

### Configurable persistence

Users should be able to choose a duration or **Remain until dismissed**.

Duration should be configurable by category, because a social event and an operational warning may need different treatment.

When focus enters a notification, it should not disappear underneath the user.

### Persistent history

The notification center should support filtering, searching, category labels, timestamps, read state, and accessible actions.

Users should be able to reopen the details of an event after its popup disappears.

Account-specific history must remain account-specific.

### Avoid notification storms

Repeated events should be grouped where appropriate.

For example:

> “Connection interrupted four times in the last ten minutes.”

The details can expose individual occurrences.

Grouping should not conceal a materially different error or pretend that all events had the same outcome.

### Reserve attention deliberately

A notification should have a severity, but severity alone should not dictate every delivery channel.

The user’s preferences, DND state, current presentation surface, privacy mode, and category ownership should also matter.

A sensible delivery decision might preserve a warning in history, show a quiet status indicator, and avoid interrupting active narration.

### Do not silently override DND

Critical-alert exceptions should be explicitly configurable.

“Critical” should not become a loophole that allows any subsystem to play sounds despite the user’s settings.

At the same time, suppressing sound should not erase important information. It can remain available through the user’s chosen nonaudio channel.

### Keep focus and actions stable

A notification should not jump to a different screen position just as the user tries to activate it.

When multiple notifications arrive, the card currently being read or focused should remain stable.

Buttons should be labeled with the action, not only “Yes” and “No.”

### Handle stale actions

Before executing an action from history, VRC Eye should revalidate relevant state.

An old notification for another account, a vanished instance, or a completed operation should not execute as though it were current.

---

## 20. Captions, transcription, and communication assistance

This is a substantial missing feature area, but it needs clear boundaries.

### Caption VRC Eye’s own spoken content

Every built-in spoken instruction or tutorial should have corresponding readable text.

Narrated setup should not require hearing.

Video help, if added, should have captions and a text alternative for important instructions.

### Optional speech-to-text

A future speech-to-text feature could help compose messages or provide local captions from an explicitly selected audio source.

It should show which source is being processed, whether processing is local or remote, whether anything is retained, and how to stop it.

It must not start capturing microphone or system audio simply because the user enabled “Accessibility.”

### Separate drafting from sending

Recognized speech should normally enter a draft.

Sending it to VRChat’s chatbox, a VRC Eye peer conversation, or another destination should be a separate action unless the user deliberately enables a narrowly defined automatic-send mode.

The current destination should be continuously visible and accessible.

### Label uncertainty

Transcripts can be wrong.

VRC Eye should support editing, correction, and uncertainty indicators where the recognition system provides them.

It should not confidently assign a speaker identity that the source does not reliably provide.

### Preserve communication preferences

A phrase board could provide user-authored messages such as:

> “Please give me a moment to respond.”

> “I’m using text right now.”

> “Could you repeat that?”

These should be editable and optional. They should not automatically disclose a disability or medical explanation.

### Avoid turning captions into a data archive

Retention should be a separate choice.

A transient captioning feature should not quietly become a permanent searchable transcript of other people’s speech.

Cloud processing, export, and sharing should require clear user action and appropriate consent considerations.

Microsoft’s gaming accessibility guidance treats speech-to-text and text-to-speech communication as a dedicated area; VRC Eye should similarly treat this as a real subsystem, not a checkbox attached to notifications. [Microsoft Learn](https://learn.microsoft.com/en-us/xbox/accessibility/xbox-accessibility-guidelines/119)

---

## 21. Simplified layout and cognitive accessibility

Simplification should reduce unnecessary complexity without removing authority or hiding important consequences.

W3C’s cognitive-accessibility guidance emphasizes understandable content and usable interaction patterns beyond basic technical conformance. That is an appropriate direction for VRC Eye’s Casual experience. [W3C](https://www.w3.org/TR/coga-usable/)

### Keep navigation stable

Major sections should remain in predictable locations.

Menus should not continually reorder themselves based on recent use.

A user may pin favorites, but the application should not unexpectedly rearrange the rest of the interface.

### Use progressive disclosure

A routine task should show the information needed to complete it.

Additional technical details can be placed behind **Details**, **Advanced options**, or a clearly named secondary panel.

However, the consequences of an action must remain visible. Simplifying a screen should not hide that an action changes a VRChat account or shares information.

### Give each screen a clear purpose

The user should be able to answer:

**Where am I? What is this showing? What can I do here? What happens next?**

A page title, concise description, and a clear primary action often provide more value than adding another row of icons.

### Preserve unfinished work

Drafts, filter selections, expanded sections, and the current reading position should survive reasonable navigation.

Returning from a detail view should not reset the user to the top of a long list.

After a recoverable error, the user should not have to reconstruct the entire task from memory.

### Provide a “What changed?” summary

After reconnecting, returning from an interruption, or resuming a paused live view, VRC Eye could show a short summary of meaningful changes.

This should be optional and based on actual recorded differences.

It should not announce every background update.

### Plain-language errors

An error should explain what failed, whether the application knows the outcome, what remains usable, and what the user can do next.

Technical details can remain available for troubleshooting.

“Transport exception” is not a complete user-facing explanation.

---

## 22. Accessible forms, authentication, and destructive actions

These are often where otherwise accessible applications fail.

### Persistent field labels

Text fields should have labels that remain visible after the user types.

Placeholder text is not a substitute for a label.

Required fields should be identified in words or semantics, not only with a colored asterisk.

### Accessible validation

An invalid field should have a specific explanation associated with it.

The interface should provide an error summary when several fields need attention, with a way to move to each affected field.

It should not clear valid information because another field failed.

### Login behavior

The previously requested separate **Remember username** and **Remember password** controls should have separate descriptions and states.

Pressing Enter should submit the login form when appropriate, while avoiding accidental submission during text composition.

Username, password, and verification-code fields should support pasting and compatible password-manager behavior. W3C’s accessible-authentication guidance specifically identifies password-manager support and copy/paste as mechanisms that reduce memory and transcription demands. [W3C](https://www.w3.org/WAI/WCAG22/Understanding/accessible-authentication-minimum.html)

Accessibility does not justify plaintext credential storage or bypassing account verification.

### Password visibility

A show-password control should be keyboard accessible and announce whether the password is shown or hidden.

Sensitive values should remain protected from ordinary narration and accidental logging.

Any deliberate reveal behavior should be explicit and reversible.

### Clear account identity

Before an account-changing operation, the interface should identify the acting account.

If a running-game account mismatch is relevant, the explanation should be readable and available to assistive technology—not just indicated by a colored account badge.

### Destructive confirmations

A confirmation should name the object and the consequence.

For example:

> “Move 12 selected photos to Trash?”

is better than:

> “Are you sure?”

The less destructive action should receive appropriate initial focus. Do not require users to type a long arbitrary phrase for every routine operation.

### Prevent accidental repeat execution

Repeated Enter presses, switch bounce, or a held controller button must not send the same invite or account operation multiple times.

The operation should become visibly pending, prevent duplicate submission, and report its actual outcome.

An unknown outcome should remain unknown until reconciled. Accessibility input repetition must not trigger blind retries.

---

# Part V — VR-overlay accessibility

## 23. Comfortable overlay placement

The overlay should be adjustable around the user’s preferred posture and interaction method.

It should not assume standing, symmetrical controller use, a particular eye position, or comfort with sustained upward or sideways looking.

W3C’s XR guidance identifies customization, alternatives to required physical movement, magnification, and orientation as important user needs. The specific controls below are proposed VRC Eye design choices that would need device and user testing. [W3C](https://www.w3.org/TR/xaur/)

### Independent placement controls

The user should be able to adjust horizontal position, vertical position, distance, width, height, tilt, and anchoring behavior.

Each spatial adjustment should have a non-drag alternative, such as directional buttons and numeric controls.

A visible **Reset placement** command is essential.

### Separate distance from apparent size

Moving an overlay farther away should not necessarily make the text too small.

Provide an option to preserve its apparent size while changing distance.

Conversely, a user should be able to make a panel occupy less of the view without being forced to place it at an uncomfortable depth.

These are related geometric controls, but they should be presented in understandable language.

### Avoid one universal “comfortable” distance

I would not hard-code one distance and label it universally safe or comfortable.

Offer sensible initial presets and an interactive adjustment process.

Comfort depends on the user, headset, rendering, and task; the feature should support personalization rather than promise a medical outcome.

### Anchoring modes

Potential modes include dashboard-attached, controller-attached, wrist-attached, room/world-fixed, and view-relative presentation where supported.

Each mode needs its own behavior explanation.

For example, a controller-attached panel may be easy to find but unsuitable for someone who does not want to hold a controller in view.

### Reading placement and alert placement should differ

A large reading panel and a compact notification should not be forced to share identical positioning.

Users may prefer notifications near the center but long-form content slightly lower or to one side.

A caption area should also have its own placement controls.

### Respect the visible scene

The overlay should support a compact state and a quick hide action.

It should avoid covering large portions of the view without deliberate user action.

VRC Eye should not claim that an overlay layout can guarantee awareness of the physical environment.

---

## 24. Overlay interaction and focus

A readable overlay is not automatically an accessible interface.

Its controls, navigation, semantics, and recovery behavior must also work.

### Offer multiple interaction paths

Where supported, overlay actions should be operable through controller pointing, discrete controller navigation, keyboard commands, and the equivalent desktop interface.

No essential operation should require touching a precise point in 3D space.

A user should not need both controllers merely to open, read, and close the panel.

### Provide discrete navigation

A controller-based focus mode could move through controls using directional inputs and activate them with a single button.

This should use the same logical focus order as the equivalent desktop interface where practical.

Selected and focused states need clear visual and optional audio feedback.

### Prevent accidental click-through

While the user is interacting with VRC Eye, the application should use the platform’s supported focus and input mechanisms to avoid sending the same interaction to the underlying game.

Where complete isolation cannot be guaranteed, the limitation should be clearly documented and tested.

The interface should not assume that drawing a panel automatically gives it exclusive control of the input.

### Support stable reading

A **Lock while reading** option could temporarily stabilize the panel’s position.

A **Recenter VRC Eye panel** action should reposition only VRC Eye’s interface.

It should not silently recenter the entire VR world, change player orientation, or alter locomotion.

### Tracking loss

If an attached controller disappears or tracking becomes invalid, the overlay should follow a configured fallback: hide, return to the dashboard, or move to a known neutral position.

It should not become permanently lost because its saved anchor no longer exists.

### Desktop equivalence

Every essential overlay-only status should have an equivalent accessible desktop representation.

Every essential overlay command should have a desktop or keyboard alternative.

Native screen-reader access to an overlay must be verified; an image rendered into a VR texture should not be advertised as screen-reader accessible merely because its desktop source window is accessible.

---

## 25. VR sensory comfort and quick simplification

I would add a **Quiet VRC Eye** action distinct from broader Safety Mode.

Its purpose would be to reduce the companion application’s own sensory and interaction load.

### What it could do

It could hide nonessential panels, stop novelty effects, pause nonessential spoken announcements, simplify the visible overlay, and preserve a small accessible status indicator.

The exact changes should be configurable and previewable.

### What it must not claim

It should not claim to mute VRChat, suppress every world effect, stop all uncomfortable content, or protect the user from every sensory trigger.

It should state exactly what it changed.

For example:

> “VRC Eye animations paused. Nonessential VRC Eye sounds muted.”

That is much more trustworthy than a broad “Everything is safe now.”

### No mandatory depth-only cues

Within VRC Eye panels, buttons and selected items should have labels, borders, or other flat cues rather than depending only on stereoscopic depth.

The interface should remain understandable when one eye is not providing the same visual information as the other.

### Avoid brightness surprises

Opening a panel should not produce an unnecessarily bright full-screen transition.

Offer panel brightness or theme choices independently from size.

### Quick access must remain available

Quiet mode should not hide the control needed to leave quiet mode.

Likewise, hiding all overlays should preserve a discoverable keyboard, controller, or desktop command to show them again.

---

# Part VI — Profiles, persistence, and recovery

## 26. Accessibility profiles

Profiles should save useful combinations of settings, but they should remain understandable collections of preferences.

### Use task-oriented presets

Possible starting presets include **Larger text**, **High contrast**, **Low motion**, **Quiet interface**, **Keyboard-first**, **Screen-reader-first**, **One-handed controls**, and **Large VR controls**.

These names describe behavior rather than assigning a diagnosis.

The user should be able to rename and modify them.

### Avoid mutually exclusive categories

A user may need several adjustments at once.

Instead of forcing a choice between “Low vision” and “Motor,” VRC Eye should support combining compatible preference groups or saving a combined custom profile.

Conflicts should be explained before application.

### Profiles should show their contents

Selecting a profile should display what it will change.

For example:

> “Increases text to 150%, enables persistent notifications, disables decorative animation, and enlarges pointer targets.”

It should not be a mysterious switch that changes dozens of unrelated values.

### Support temporary use

A profile could be applied for the current session without replacing the user’s usual preferences.

The interface should clearly distinguish **Apply temporarily** from **Save as default**.

### Prevent unexpected automatic switching

Connecting a headset or controller may offer to apply a preferred profile.

Automatic switching should be opt-in and should not change the interface in the middle of a focused interaction.

A context rule must not silently undo a preference the user has explicitly locked.

---

## 27. Settings scope and precedence

This needs a formal design because VRC Eye supports multiple accounts, devices, modes, and surfaces.

### Accessibility belongs primarily to the local user

Core accessibility preferences should normally belong to the current operating-system user’s VRC Eye configuration.

They should not disappear when the user logs out of VRChat or switches to an alternate account.

“Global” here should mean global within that local user’s VRC Eye environment—not shared across unrelated operating-system users.

### Separate account content from presentation

The active account controls which friends, notifications, permissions, and operations are available.

Accessibility preferences control how that information is presented and operated.

Switching accounts must isolate content without resetting the person’s ability to use the application.

### A proposed precedence model

From lowest to highest priority, I would use:

**Application defaults → followed operating-system preferences → local-user preferences → selected accessibility profile → device/surface adjustments → explicit temporary adjustments.**

Explicitly locked accessibility preferences would then prevent automatic context rules from replacing those values.

This should be visible in the settings interface. A setting might show:

> “150% — supplied by your Reading profile.”

or:

> “Animation disabled — locked in your accessibility preferences.”

### Privacy rules are separate constraints

A privacy rule may prevent private message content from being spoken aloud.

That should not be implemented by randomly resetting narration preferences. It should change what information is eligible for delivery.

The user should see the reason:

> “Message details are hidden by Streamer Privacy Mode.”

### Handle unavailable capabilities transparently

A device profile might request haptics when no haptic device is connected.

VRC Eye should preserve the requested setting, mark the capability unavailable, and use only the user’s approved alternatives.

It should not silently delete the preference.

---

## 28. Import and export of accessibility settings

Accessibility transfer should be treated as a carefully scoped configuration operation.

It should not be a general-purpose settings bundle with hidden side effects.

### Export only the intended settings

An accessibility export should contain relevant display, input, narration, notification, and profile preferences.

It should not contain passwords, session tokens, private messages, friend lists, world history, or unrelated API configuration.

Custom hotkey action identifiers can be included, but not executable scripts disguised as accessibility preferences.

### Include a versioned schema

The export should identify the configuration format version, the relevant feature versions, and any device-specific sections.

That allows a later VRC Eye version to migrate supported values or explain why a setting cannot be imported.

### Preview before applying

The import screen should show current values and proposed values, grouped by category.

It should identify unknown settings, unsupported capabilities, conflicting shortcuts, unavailable fonts, and device-specific overlay geometry.

### Allow selective import

Users should be able to import text and contrast settings without importing hotkeys.

They should be able to import desktop preferences without replacing their VR placement.

A single **Apply everything** button is not enough.

### Validate rather than guess

Invalid numbers, impossible dimensions, malformed files, and unsupported values should be rejected or presented for correction.

An unknown setting should not be interpreted as an instruction to reset the whole accessibility system.

### Treat device geometry carefully

A profile created on another headset should not automatically place the overlay at an extreme or invisible position.

Device-specific geometry should be separately reviewed, adapted, or excluded.

### Preserve a rollback point

Before applying an import, save the current known-good accessibility configuration.

Applying a partially invalid file should not leave half the interface using new values and half using old values without an explanation.

### No automatic network effects

Importing a profile should not connect to a relay, change permissions, send messages, enable microphone capture, or upload data.

Any optional sharing of the profile itself should remain a separate, explicit operation.

---

## 29. Accessibility recovery and safe startup

This should be one of the first foundational pieces, not a late polish feature.

### Maintain a last-known-good configuration

VRC Eye should keep a recoverable copy of accessibility settings that successfully loaded.

A malformed profile should not prevent the application from opening.

A failed import should not overwrite the only usable configuration.

### Provide a recovery interface

A small recovery interface should allow the user to restore a previous accessibility profile, restore readable defaults, reset window placement, reset overlay placement, and disable a conflicting shortcut set.

It should use a minimal, well-tested interface rather than the same potentially broken custom theme.

### Do not rely on one secret shortcut

Recovery should be accessible through more than one supported route: a visible startup entry, an in-app command, and a documented keyboard path.

A shortcut alone is insufficient because the keyboard mapping may be the thing that broke.

### Preview high-risk presentation changes

Theme and scale changes should be previewable before replacing the main interface.

A preview should have clear **Keep** and **Revert** actions.

A short mandatory countdown is not ideal. Where an automatic fallback is necessary, its behavior should be adjustable and accessible, with a non-timed recovery path available.

### Recover off-screen content

Desktop windows should be checked against connected displays.

Overlays should be checked against valid anchors and reasonable visible placement.

A missing monitor or controller should not make the settings interface unreachable.

### Preserve accessibility during update failures

The updater, migration process, and error recovery screen should retain essential accessibility behavior.

An update should not temporarily force the user through tiny text and mouse-only dialogs before restoring their preferences.

### Do not silently disable the last usable channel

If the user attempts to turn off all enabled presentation or control alternatives, explain the consequence and preserve an accessible recovery route.

The system should not assume that visual, audio, or pointer interaction is available merely because the hardware exists.

---

# Part VII — Integration with the rest of VRC Eye

## 30. Accessibility across existing and planned modules

This system should be applied to every feature family, not just Settings.

### Social and account features

Account identity, permission state, pending operations, and account mismatch warnings need textual and accessible representations.

Friend lists should support stable navigation, meaningful row labels, and non-color status information.

Invites and invite requests should remain actionable from persistent views when still valid.

Screen narration should follow account isolation and privacy rules.

### Photos

The gallery needs keyboard navigation, adjustable thumbnail sizes, an accessible list alternative, meaningful metadata, and a clear selected state.

Favoriting, moving, renaming, organizing, and deleting should have non-drag alternatives.

A photo detail panel should expose descriptions and metadata without requiring visual inspection of the image.

Deletion confirmation should distinguish removing a catalog entry from deleting or moving an actual file.

### Player list

Live updates should preserve row identity and focus.

The user should be able to pause visible reordering, inspect a stable snapshot, and then apply accumulated updates.

Unknown, stale, and observed states should be explicit.

Actions must remain tied to the intended player even if the list changes.

### Black Box and crash diagnostics

Diagnostic timelines need searchable event lists and readable summaries.

A graph-only crash report is insufficient.

Error codes should be copyable, and the application should distinguish observed facts from inferred explanations.

Accessibility failures—such as an unavailable narration device or a broken UI accessibility provider—could appear in local diagnostics without exposing private content.

### Safety

Safety controls need large, distinct targets, remappable access, readable state, and confirmation of what actually happened.

A command being issued is not proof that VRChat performed it.

The interface should distinguish **Requested**, **Confirmed**, **Unavailable**, and **Outcome unknown**.

Accessibility must not turn safety actions into unexplained automation.

### OSC controls

The same command framework should be used for keyboard, switch, controller, and other supported input.

Held controls need explicit release handling.

VRChat’s OSC documentation states that axes need to return to zero and button inputs need press/release state transitions. That makes release handling a functional requirement, not merely a visual concern. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

VRC Eye should release its active controls during normal cancellation, focus changes where appropriate, device disconnection, and orderly shutdown when transport remains usable.

However, it should not claim guaranteed release after a total process or transport failure. The interface and design should account for that limitation rather than implying a software watchdog can solve every failure.

### VRC Eye-to-VRC Eye features

The receiver should remain in control of notification size, placement, duration, sound, narration, and motion.

A peer should not be able to force a flashing overlay, override DND, or activate a louder alert by attaching a “critical” label.

Shared countdowns and ready checks should preserve accessible summaries and explain when the underlying shared event has ended.

### VRCX Companion Mode

Notification ownership and accessibility presentation need to coordinate.

If VRCX owns a social notification, VRC Eye should avoid duplicating the toast and narration unless the user explicitly chooses a complementary presentation.

Suppressing duplicate presentation must not erase the event from the relevant state model.

### Creator and Developer tools

Advanced tools need accessible controls too.

Risk labels should be words, not just red badges. API operation descriptions should identify their scope and consequences.

Raw JSON, logs, and parameter tables should be navigable and copyable.

Custom visual editors should provide structured alternatives for essential operations.

---

## 31. Privacy and accessibility

Accessibility can unintentionally expose information through speech, captions, secondary displays, or shared profiles.

Privacy must therefore be designed into each channel.

### Accessibility settings are not public identity

Using large text, captions, switch input, or narration should not automatically create a public badge.

VRC Eye should not tell peers which accessibility tools the user employs unless the user chooses to share that information.

### Sanitize before delivery

Private content should be filtered before it enters the speech queue, overlay notification, transcript, export, or diagnostic log.

It is too late to redact a private message after it has already been spoken.

### Give private content an explicit reveal action

A privacy-preserving notification might say:

> “New private message. Open to read.”

The user can then deliberately reveal the content through their preferred accessible channel.

This should not make private content permanently inaccessible; it should make the disclosure intentional.

### Do not log sensitive narration

Logs can record that an announcement occurred without storing its complete private text.

Credentials, session tokens, and private message contents should not be included in ordinary accessibility diagnostics.

### Optional cloud features need separate permission

Cloud speech recognition, generated image descriptions, or other remote services should clearly identify what data leaves the device.

Enabling one accessibility feature should not grant blanket permission for unrelated processing.

### Second-screen support needs pairing

A future phone or tablet companion could be valuable for larger controls or caption viewing.

It should require explicit pairing, access control, and a visible connection state.

A QR code should not be the only pairing method; an accessible textual alternative should exist.

This should remain a later feature, not a dependency for basic accessibility.

---

## 32. Performance and failure behavior

Accessibility features must remain usable when the application is busy or partially failing.

### Protect interaction responsiveness

A heavy photo scan, graph update, or diagnostic import should not freeze keyboard navigation or delay a confirmation button indefinitely.

Accessibility events should not depend on a long-running task finishing on the interface thread.

### Preserve essential accessibility in low-overhead mode

Low-overhead mode may reduce decorative rendering, animation, update frequency, and optional analysis.

It should not silently disable screen-reader semantics, focus indicators, readable text, or the user’s required notification channel.

Accessibility is not an optional visual effect to discard first.

### Bound queues

Speech, notifications, captions, and accessibility events need bounded queues and coalescing rules.

A burst of thousands of diagnostic events should not create hours of narration.

The user should receive a meaningful summary and retain access to details.

### Make degraded states clear

If narration stops working, show the reason through another configured channel.

If captions fail, indicate that they are no longer updating.

If the overlay disconnects, the desktop interface should remain usable.

Do not leave a stale accessibility feature appearing active.

### Preserve offline functionality

Text scaling, keyboard navigation, local profiles, high contrast, focus, and basic recovery should remain functional without internet access.

Optional online services should fail independently rather than taking the accessibility system down with them.

---

# Part VIII — Technical structure and implementation

## 33. Shared accessibility architecture

I would implement the system through shared infrastructure rather than adding special cases to every page.

The exact toolkit integration needs to be verified against the actual codebase, but the architectural responsibilities can be defined now.

### Shared design values

A central design system should define typography, spacing, target sizes, colors, borders, focus styling, motion behavior, and notification geometry.

Individual pages should not hard-code their own versions.

Changing text scale should update all compliant components.

### Shared semantic components

Buttons, switches, fields, tables, trees, dialogs, and notifications should have reusable accessible implementations.

Each component should expose its name, role, state, value, help text, and relationships.

A custom-drawn control should not be accepted merely because it looks right.

### Shared action registry

Every important operation should be represented by one command with multiple invocation methods.

The button, hotkey, controller binding, and command-search result should call the same underlying operation.

Authorization, duplicate prevention, account binding, and outcome reporting should live with the operation—not be reimplemented differently for each input method.

### Shared focus manager

The application needs a consistent mechanism for tracking focus, restoring it, handling modal dialogs, navigating regions, and preserving item identity during updates.

Focus handling should not be improvised independently on every screen.

### Shared notification router

The router should determine category, ownership, privacy treatment, persistence, channels, narration priority, and deduplication.

Feature modules should submit structured events rather than directly playing sounds or drawing popups.

### Shared accessibility profile service

This service should validate settings, resolve precedence, apply changes, create checkpoints, migrate versions, and expose the effective value of each preference.

It should load early enough to support login and recovery.

### Platform adapters

Windows, Linux, desktop, and VR surfaces may require different platform integrations.

Those differences should sit behind explicit adapters.

The common feature model should not assume every platform supports identical global shortcuts, narration engines, haptics, or overlay semantics.

### Capability reporting

Each feature should distinguish **Available**, **Configured**, **Active**, **Unavailable**, **Degraded**, and **Not yet tested** where appropriate.

For example, selecting a speech voice is not the same as successfully producing audio through the intended device.

---

## 34. Proposed starting defaults

These are starting design choices for testing, not universal prescriptions.

| Area                 | Proposed initial behavior                                                     |
| -------------------- | ----------------------------------------------------------------------------- |
| Accessibility access | Available before login and offline                                            |
| Contrast             | Readable default theme; follow system accessibility preferences when selected |
| Text scaling         | Support at least 200% without losing essential functionality                  |
| Focus                | Clear, persistent when navigating by keyboard/controller                      |
| Motion               | No flashing; decorative motion can be disabled                                |
| Status               | Important states always include text                                          |
| Notifications        | All meaningful events remain discoverable after popups disappear              |
| Speech               | Off unless chosen; easy access to platform screen-reader support              |
| Private narration    | No automatic reading through an unapproved fallback device                    |
| Large controls       | Separate from font scaling                                                    |
| Hotkeys              | Application-scoped by default where practical                                 |
| Capturing audio      | Never enabled merely by selecting an accessibility preset                     |
| Profile changes      | Previewable and reversible                                                    |
| Account switching    | Preserve local-user accessibility preferences                                 |
| VR placement         | Adjustable, recoverable, and independent of desktop scale                     |
| Import               | Validated, previewed, and limited to selected categories                      |
| Low-overhead mode    | Preserve essential accessibility                                              |
| Recovery             | Accessible without editing files manually                                     |

The defaults should be conservative, but they should not prevent experienced users from making the interface more compact or less verbose.

---

## 35. Example end-to-end workflows

Accessibility should be designed around completed tasks, not isolated controls.

### Workflow A: First launch without a mouse

The user launches VRC Eye, reaches Accessibility through keyboard navigation, increases text size, enables persistent notifications, returns to login, pastes credentials, submits with Enter, and reaches the main dashboard.

The task fails if any required step demands a pointer, loses focus, or hides the current control.

### Workflow B: Screen-reader user reviews an invite

The user hears a concise notification, continues their current task without interruption, opens notification history, reads the inviting account and destination, checks the invite’s validity, and chooses an action.

The application reports whether the action succeeded, failed, or has an unknown outcome.

The task fails if the invite is only represented by a thumbnail or disappears before it can be reviewed.

### Workflow C: One-controller VR use

The user opens a dashboard-attached VRC Eye panel, navigates through discrete focus controls, reads a status, activates a harmless command, and closes the panel without raising the other hand.

If the controller disconnects, the panel follows its configured fallback.

The task fails if closing or recovering the panel requires the missing controller.

### Workflow D: User enables very large text

The dashboard reflows into fewer columns. Labels wrap. Important actions remain visible. A table offers a detail view rather than hiding values.

The user can still return to the scale controls.

The task fails if the enlarged interface makes its own settings unreachable.

### Workflow E: Accessibility import contains bad values

VRC Eye detects unsupported overlay geometry and a conflicting hotkey, explains the issues, imports only the chosen valid categories, and retains a rollback point.

The task fails if the import silently replaces everything or leaves the application unusable.

### Workflow F: Busy live player list

The user focuses a player while several other players join and leave. The focused identity remains stable. New events are indicated without shifting the intended action to another person.

The task fails if pressing Enter acts on a different player because the row moved.

---

## 36. Implementation order

We should keep the earlier preference for incremental changes, but accessibility foundations should not be postponed until every feature is already custom-built.

### Phase 1: Structural prerequisites

Introduce shared design values, accessible component patterns, a command registry, focus rules, early-loading preferences, and recovery checkpoints.

Audit the current interface to identify custom controls and inconsistent notification paths.

This phase makes later accessibility work possible without repeatedly rebuilding the same foundations.

### Phase 2: Essential desktop operation

Make login, navigation, settings, dialogs, forms, and core lists fully keyboard operable.

Add visible focus, meaningful labels, text scaling, high contrast, and color-independent states.

Complete a small number of end-to-end workflows before expanding coverage.

### Phase 3: Notifications and readable live data

Implement persistent history, configurable durations, structured announcements, stable list updates, accessible tables, and chart alternatives.

Coordinate notification ownership with companion-mode plans.

### Phase 4: Profiles and recovery

Add profile composition, scope resolution, locked preferences, import/export validation, and accessible startup recovery.

Test account switching and device changes extensively.

### Phase 5: VR overlay accessibility

Add independent scaling, placement, anchoring, discrete navigation, one-controller workflows, tracking-loss behavior, and desktop equivalence.

Verify actual platform behavior before advertising support.

### Phase 6: Extended input and communication

Add selected features such as switch scanning, dwell input, phrase boards, optional transcription, or second-screen interaction.

Each should be a separate capability with its own privacy and failure model.

### Phase 7: Broad usability testing and maintenance

Expand real-user testing, publish known limitations, and add regression coverage.

Accessibility should then become a release requirement for new features, not a cleanup task scheduled after them.

---

## 37. Testing and release gates

A screenshot review and an automated checker are not enough.

The system needs component tests, integration tests, assistive-technology testing, and completed-task testing.

### Component-level tests

Every shared control should be tested for keyboard operation, accessible name and role, state announcements, text enlargement, theme changes, focus visibility, and pointer-target behavior.

A component should not pass simply because it exists in an accessibility tree. Its information and interaction must also be correct.

### Real assistive-technology testing

Test the actual packaged application with supported screen readers and platform accessibility tools.

Record operating-system version, application version, toolkit version where relevant, assistive-technology version, and any limitations.

“Works with screen readers” should not be a blanket claim based on one successful button announcement.

### Combination testing

The difficult failures often involve combinations.

Test large text with high contrast. Test keyboard navigation while notifications arrive. Test screen narration during account switching. Test one-controller navigation with reduced motion. Test profile import while a custom theme is active.

A setting working alone does not prove that the profile works.

### Failure testing

Deliberately test missing displays, disconnected audio devices, lost controller tracking, malformed settings, unavailable speech voices, expired authentication, failed network operations, and corrupted profile imports.

Recovery must be part of the test, not merely the appearance of an error message.

### Live-data testing

Use large player lists, rapid updates, many notifications, and long diagnostic logs.

Verify that focus stays attached to the intended object, narration does not flood, and the user can pause presentation without losing underlying event history.

### Manual user testing

Include people who actually use the relevant interaction methods.

A color filter simulation cannot substitute for evaluating whether the interface is understandable. A developer navigating once with Tab cannot substitute for sustained keyboard-only use.

Testing participation should not require unnecessary medical disclosure.

### Suggested release blockers

I would treat the following as release-blocking defects in supported core workflows: an unreachable essential action, missing focus, inaccessible login, loss of essential content at supported text sizes, color-only critical states, an unrecoverable accessibility setting, or a notification action that executes against the wrong account or item.

A broken optional experimental feature can be labeled and withheld. A broken foundation should not be disguised as a minor cosmetic issue.

### Publish support accurately

The release notes should distinguish **implemented**, **tested**, **partially supported**, and **experimental**.

They should name known limitations and available alternatives.

Using WCAG and XR guidance during development is valuable, but it does not by itself establish complete conformance or prove that every user can complete every task. WCAG2ICT is guidance for applying WCAG outside the web, and XR guidance requires additional interpretation and testing. [W3C](https://www.w3.org/TR/wcag2ict/)

---

# The intended end result

Your original list already covers many of the visible features. The most important additions are the systems underneath them:

**Accessible startup and recovery; stable focus and live data; alternative input; accessible authentication and errors; captioning and communication controls; privacy-aware narration; account-independent preferences; device-aware profiles; accessible charts and photos; and real end-to-end testing.**

Those additions are what prevent accessibility from becoming a settings page that looks impressive while the rest of the application still assumes a mouse, good vision, fast reactions, two controllers, and uninterrupted attention.

The standard I would set for VRC Eye is:

> **A user should not need to temporarily stop using their accessibility preferences to sign in, perform an important task, understand a warning, fix a mistake, or recover the application.**

That should apply equally to Casual Mode, Advanced Mode, Developer Mode, desktop use, and every supported VR-overlay workflow