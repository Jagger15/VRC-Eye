# VRC Eye — Expanded Photos System Specification

The photo system should become **a local-first photo library connected to VRC Eye’s session history, organization tools, creator workflows, and privacy controls**—not merely a folder viewer with a favorite button.

The important distinction is that it should understand both **the image itself** and **the context that can legitimately be associated with it**, without pretending that missing information is known.

A photo might have a reliable world identifier embedded in it. Another might only have a filename containing a timestamp. Another might be an edited copy received from a friend. The system needs to handle all three without confidently assigning incorrect worlds, sessions, accounts, or people.

This specification expands the features you listed and adds the supporting systems they need. It is a plan, not a claim that these features are already implemented.

The architecture should continue following our existing direction: **one photo library, one shared session-history system, one privacy-policy system, one notification system, and optional integrations rather than duplicated subsystems.**

---

# Part I — The photo library and its underlying structure

## 1. VRChat Photos tab

### 1.1 What this tab actually represents

The **VRChat Photos** tab should be VRC Eye’s primary workspace for locally available VRChat-related images.

It should not imply that every image shown has been uploaded to VRChat, exists in the user’s VRChat inventory, or is visible to friends. The distinction between **local VRC Eye photos** and **VRChat’s own online photo features** needs to remain obvious.

The normal landing view should answer three questions immediately:

**What photos do I have? Where did they come from? What can I do with them?**

The interface should favor the images themselves. Filesystem paths, metadata schemas, import diagnostics, and association evidence should remain accessible without occupying the whole screen.

### 1.2 Recommended internal layout

I would organize the workspace around **Library, Sessions, Albums, Photo Booth, and Review**.

**Library** is the complete image browser for the currently selected library scope.

**Sessions** presents photos through the existing session-history system. It should not maintain a competing definition of what a session is.

**Albums** contains manually organized collections and saved automatic collections.

**Photo Booth** contains borders, strips, layouts, and capture-session coordination.

**Review** collects unfinished tasks: ambiguous session matches, missing files, duplicate candidates, failed imports, and photos awaiting privacy review.

Review is a work queue, not another notification inbox. A notification can point into it, but the underlying task should exist only once.

### 1.3 The main screen

The center should be a resizable image grid. A narrow internal navigation area can expose sources, albums, and filters. A collapsible detail panel should appear on the right when an image is selected.

The toolbar should contain search, sorting, filtering, selection controls, and the primary action appropriate to the current view.

A small status area should show meaningful information such as:

> 428 photos · 2 folders offline · Importing 16 new files

That is more useful than a permanent technical status dump.

Following your planned interface change, **section headings should be slightly larger and bolder than the clickable category buttons, with visible separators between sections—not between individual categories.**

### 1.4 Casual and Advanced presentation

Casual mode should expose ordinary actions: open, favorite, add to album, edit a copy, export, and delete.

Advanced mode should reveal source selection, metadata provenance, session-match evidence, file relationships, organization rules, and processing status.

These should remain presentations of the same underlying system. A photo must not acquire different favorites, albums, or privacy settings because the user changes interface mode.

### 1.5 Empty, loading, and error states

An empty library must distinguish between:

**No folders configured**, **configured folders contain no supported images**, **folders are unavailable**, and **photos exist but filters hide them**.

Those situations need different remedies.

A disconnected drive should not produce “No photos found.” A malformed configuration file should not produce “Your photo library is empty.” A privacy filter should not make the application appear to have lost files.

### 1.6 Selection behavior

Selection should remain stable while new photos arrive. Importing a screenshot must not move the currently selected tile under the mouse.

Bulk actions should state whether they affect selected images, the current page, or all matching results.

“Select all” should not silently expand from the visible grid to an entire library containing tens of thousands of files.

---

## 2. Separate photos, files, captures, and versions

This is one of the most important missing architectural pieces.

A **photo** is not always equivalent to **one file**.

One capture can produce several layers. One original can have several edited versions. The same exact file can exist on two drives. One photo can belong to ten albums without needing ten copies.

### 2.1 Proposed conceptual objects

| Object                | What it represents                                                                                    |
| --------------------- | ----------------------------------------------------------------------------------------------------- |
| Capture               | One photograph-taking event, where that relationship is known or explicitly established.              |
| Photo                 | The logical image the user browses, favorites, annotates, and organizes.                              |
| Representation        | A composite image, transparent layer, edited rendition, thumbnail, or export associated with a photo. |
| File location         | A physical path containing a particular representation.                                               |
| Version               | A particular state of an image or its editing instructions.                                           |
| Collection membership | A relationship between a photo and an album, saved search, or project.                                |
| Context association   | A link to a session, world, event, or manually identified person.                                     |

These are conceptual requirements, not a claim that the current database already contains these tables.

### 2.2 Why this distinction matters

Moving an original should not erase its favorite status.

Adding a border should not create an unrelated photo that loses its session association.

Finding a backup copy should not automatically double the visible photo count.

Deleting one transparent layer should not silently remove the composite image.

A session cover should point to a specific photo and rendition, not an arbitrary filename that becomes invalid after organization.

### 2.3 Stable internal identity

Every logical photo should receive a stable internal identifier.

Its identity should not be derived solely from its current path, filename, world name, or account display name.

File hashes can help detect identical content, but **identical bytes are not permission to merge private library scopes or account ownership automatically**.

A hash is also not proof of who took a photograph.

### 2.4 Original-preservation policy

The default policy should be:

> Browsing and organizing do not modify the original image.

Favorites, album membership, notes, manual tags, session corrections, and editing recipes should initially live in VRC Eye’s own storage.

Writing metadata into originals should be a separate, explicitly enabled capability—not a side effect of opening the Photos tab.

---

# Part II — Finding and importing photos reliably

## 3. Configured screenshot-folder discovery

### 3.1 Discovery must respect VRChat’s actual configuration

VRChat documents `picture_output_folder` for camera output and `picture_output_split_by_date` for whether photos are placed into `YYYY-MM` subfolders. Its configuration file is named `config.json`, and it is not necessarily created by default. VRC Eye should read these documented settings rather than assume that every installation uses one fixed folder. [VRChat](https://docs.vrchat.com/docs/configuration-file)

The discovery process should distinguish between **finding a likely folder** and **receiving permission to monitor it**.

It should propose sources, explain why they were found, and allow the user to approve them.

### 3.2 Discovery order

An explicitly selected VRC Eye source should take precedence over guesses.

After that, the application can inspect the configuration associated with the relevant VRChat installation or runtime, then consider the operating system’s Pictures location, previously approved sources, and separately enabled screenshot sources.

A discovered source should have an explanation such as:

> Found through VRChat’s configured picture output folder.

or:

> Suggested because this is the system Pictures folder’s VRChat subfolder.

Those labels help diagnose incorrect discovery.

### 3.3 Windows Pictures handling

Windows provides known-folder APIs for retrieving folder locations, and known folders can be redirected. Consequently, VRC Eye should resolve the actual Pictures location rather than construct it by inserting a username into a hard-coded path. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/nf-shlobj_core-shgetknownfolderpath?utm_source=chatgpt.com)

The path shown in the interface can be friendly and shortened, while Advanced mode exposes the exact resolved path.

### 3.4 Multiple sources

A user should be able to monitor several sources simultaneously: the current camera output folder, older photo archives, a manually selected import folder, and optionally Steam screenshots.

Steam screenshots should be treated as a separate source type rather than assumed to be the same thing as VRChat camera photos; VRChat’s camera documentation distinguishes the two storage locations. [wiki.vrchat.com](https://wiki.vrchat.com/wiki/Camera)

Each source needs its own settings for recursive scanning, inclusion rules, read-only behavior, notifications, and permitted organization actions.

### 3.5 Changing the camera output folder

When the configured output location changes, VRC Eye should detect the change and ask whether to add the new location.

It should not automatically remove the old source, because old photos may still be there.

It should not automatically migrate the old photos, because changing where new images arrive is a different operation from moving existing files.

The source panel should make that distinction explicit:

> New captures are being saved elsewhere. Your existing library remains available.

### 3.6 Invalid configuration

Malformed JSON, an inaccessible path, an unsupported path format, and a missing configuration file should produce different messages.

Discovery should be read-only. It must not “repair” VRChat’s configuration just because VRC Eye cannot parse it.

A future configuration editor could offer a reviewed change with a backup and a clear before-and-after comparison, but that should be a separate action.

### 3.7 Overlapping folders

If the user adds both a parent folder and one of its children, the same physical image should not be imported twice.

The application should detect overlapping roots, explain the overlap, and avoid redundant watching.

Symbolic links and alternate path spellings also need to be considered, without allowing a link to expand monitoring into unrelated locations silently.

---

## 4. Linux and Proton path handling

Linux support needs more than replacing backslashes with forward slashes.

### 4.1 Understand the runtime’s filesystem view

Proton uses a compatibility-data location and a Wine-style prefix. Valve’s implementation also establishes Windows drive mappings within that prefix. A Windows path seen by VRChat therefore needs to be resolved through the relevant prefix rather than interpreted directly as a Linux host path. [GitHub](https://raw.githubusercontent.com/ValveSoftware/Proton/proton_10.0/proton)

VRC Eye should retain both the path as VRChat sees it and the resolved path accessible to VRC Eye.

For example:

> VRChat path: `C:\users\steamuser\Pictures\VRChat`\
> Host path: resolved through the selected Proton prefix

The host path should be derived, not fabricated from a universal template.

### 4.2 Prefix selection

The application should support automatic suggestions and manual prefix selection.

A machine may have more than one relevant installation, more than one Steam library, or an older prefix that still contains valuable screenshots.

The system needs to distinguish **the prefix used by the current runtime** from **an archive prefix that merely contains photos**.

### 4.3 Custom drive mappings

A configured output path might use a drive other than `C:`.

VRC Eye should resolve mappings from the selected environment and validate that the resulting host path is accessible and within an approved source.

It should not assume that a mapped drive grants permission to scan the entire host filesystem.

### 4.4 Sandboxed and restricted installations

The source-management interface should account for installations where VRC Eye cannot access a folder even though VRChat can.

The remedy should be narrowly scoped folder access or a user-selected source—not blanket permission changes across the home directory.

An error should explain the difference:

> VRChat’s output folder was identified, but VRC Eye does not currently have access to it.

### 4.5 Symlinks and duplicate detection

The scanner should detect link loops, avoid recursively revisiting the same directory, and recognize when two approved source paths lead to the same files.

It should preserve the user-friendly source name even when the underlying canonical path is more complicated.

### 4.6 Case and filename handling

Tests should cover filenames that differ only by case, non-English names, emoji, combining characters, spaces, and long paths.

A cross-platform organization rule should preview names that are not portable to the selected destination.

The application should never silently turn two distinct files into one destination filename.

### 4.7 Unavailable mounts

When an external drive or network location disappears, the library should mark its photos **temporarily unavailable**.

That must not remove favorites, session links, or album membership.

When the source returns, the library should reconcile it without treating every photo as newly captured.

---

## 5. The screenshot ingestion pipeline

### 5.1 A file event is not a completed screenshot

Filesystem notifications should be treated as signals to investigate, not as proof that an image is ready. Microsoft’s watcher documentation explicitly notes that ordinary operations can generate multiple events and that event buffers can overflow. The design therefore needs deduplication and reconciliation, not a one-event-equals-one-photo assumption. [Microsoft Learn](https://learn.microsoft.com/en-us/dotnet/api/system.io.filesystemwatcher.error?view=net-10.0\&utm_source=chatgpt.com)

### 5.2 Proposed import states

A newly discovered image should move through recognizable internal states:

`Discovered → Waiting for completion → Validating → Indexed → Preview ready`

Failures should produce a recoverable state such as **Waiting for access**, **Unsupported format**, **Invalid image**, or **Retry required**.

An interrupted write should not immediately become a permanently broken photo.

### 5.3 Completion checks

The importer should look for a sufficiently stable file, attempt a bounded decode, and retry with controlled delays when the producer is still writing.

A file that stops changing is only a candidate for completion; successful validation still matters.

Retries should have limits so one inaccessible file cannot occupy a worker indefinitely.

### 5.4 Initial import versus live capture

The first scan of an archive should not produce thousands of “New photo saved” notifications.

Historical imports and newly observed captures need distinct event types.

The user should see one import summary for an archive and ordinary photo notifications only for appropriately identified live additions.

### 5.5 Recovery scans

Watching should be supplemented by incremental reconciliation after startup, watcher failure, source reconnection, or an explicit refresh.

The application should remember enough scan progress to avoid restarting huge imports unnecessarily.

A source being rescanned should remain browsable while reconciliation continues.

### 5.6 Processing priorities

A photo the user opens should receive higher preview priority than an old photo being indexed in the background.

Basic indexing should not wait for expensive privacy analysis, duplicate analysis, or optional visual classification.

The grid can show a photo while clearly indicating that secondary processing is still pending.

### 5.7 No recursive export loop

VRC Eye-generated exports must not continually re-enter the capture pipeline, receive another border, and produce another export.

Managed outputs need identifiable provenance and explicit inclusion rules.

“Watch this folder” should not automatically mean “apply capture automation to every image written there.”

---

## 6. Manual import and device imports — additional feature

The photo system should support images that do not arrive through a watched folder.

### 6.1 Import choices

Dragging a file or folder into VRC Eye should offer **reference in place** or **copy into a managed library location**.

Reference-in-place should explain that the photo remains dependent on the original location.

Managed import should show the destination and expected storage use before copying.

### 6.2 Photos received from friends

An imported photo should retain its source description and any supplied attribution, but it should not automatically become “taken by the currently logged-in account.”

The system should distinguish:

**File owner**, **importing account**, **claimed photographer**, and **verified local capture context**.

These can be different.

### 6.3 Headset and phone imports

A user-selected folder containing exported device photos should work even without direct device integration.

Direct device browsing or synchronization can be a later adapter, but basic import must not depend on it.

The application should not promise access to a headset’s or phone’s photo library merely because it recognizes the device type.

### 6.4 Import receipts

A completed import should summarize how many files were added, already known, unsupported, skipped, or unsuccessful.

The receipt should make partial failure visible without treating the entire import as failed.

---

# Part III — Browsing, previews, and everyday organization

## 7. Thumbnails

### 7.1 Multiple thumbnail sizes

The application should generate a small number of standard preview sizes rather than one unique image for every possible tile dimension.

The original remains authoritative. Thumbnails are disposable derivatives.

A cache reset should not affect favorites, edits, albums, or session associations.

### 7.2 Progressive presentation

The grid can first show a lightweight placeholder, then a small preview, then a sharper preview when the tile remains visible.

It should avoid decoding every full-resolution image merely to draw a wall of thumbnails.

For scale, one 7,680 × 4,320 image decoded into four bytes per pixel occupies about **127 MiB for that pixel buffer alone**. Loading dozens that way would be an unnecessary resource burden.

### 7.3 Correct appearance

Thumbnail generation should preserve aspect ratio and apply the same orientation interpretation as the full preview.

Transparent images need a selectable neutral background or checkerboard.

An image should not appear stretched in the library and correct only when opened.

### 7.4 Cache identity

The cache key should include the underlying representation version and the rendering settings that affect appearance.

If the image changes externally, its old thumbnail must be invalidated.

If a privacy-safe preview differs from the original, those must be separate cached representations.

### 7.5 Privacy-aware thumbnails

A photo marked private should not leak through session covers, search suggestions, recent-file cards, or notification previews.

Privacy handling should happen before a thumbnail is presented—not as a late overlay that briefly exposes the original.

### 7.6 Cache controls

Advanced settings should expose cache size, current use, rebuild actions, and storage location.

The interface should explain that clearing cached previews will temporarily slow browsing but will not delete source photos.

---

## 8. Preview and full-screen viewing

### 8.1 Standard viewing controls

The preview should support fit-to-window, actual-size viewing, zoom, panning, previous/next navigation, and full-screen mode.

Actual-size viewing should have an unambiguous meaning: one image pixel mapped to the intended display scale, rather than an arbitrary enlarged preview.

### 8.2 Navigation stability

Opening a photo should preserve the current search and sort order.

Closing the preview should return to the same grid position.

Changing a favorite should not unexpectedly jump the user to another image unless the current filter genuinely excludes the changed item—and even then, the transition should be understandable.

### 8.3 Original versus edited view

The viewer should clearly identify whether it displays the original, an edited version, a redacted export, or a layer.

A comparison toggle can show original and edited versions, but only within a context where displaying the original is permitted.

Guest or presentation mode should not expose a one-click original reveal by accident.

### 8.4 Side-by-side comparison

A comparison workspace would help with selecting the best photograph from a burst.

It should support synchronized zoom and panning, separate favorite or reject flags, and a clear indication of which file is selected.

Comparing images should not alter them.

### 8.5 Missing originals

When only a cached preview remains available, the viewer should say so prominently.

It must not imply that a thumbnail can be exported at original quality.

Actions requiring the full source should be disabled with an explanation rather than failing after the user completes an export dialog.

### 8.6 Safe keyboard behavior

Arrow keys can navigate, Escape can close, and a favorite shortcut can toggle the current item.

Destructive shortcuts must not activate while the user is typing in a caption or search field.

The Enter key should activate the intended dialog action, not a hidden destructive default.

---

## 9. Favorites

### 9.1 Favorites are a local photo property

Favoriting a photo should not copy it, move it, upload it, or change its VRChat metadata.

It should also remain distinct from VRChat world, avatar, or user favorites.

### 9.2 Immediate and persistent behavior

The favorite indicator should update immediately and survive rescans, renames, source moves, and application restarts.

Where the same logical photo has multiple file locations, the favorite should ordinarily belong to the photo rather than only one path.

Account-scoped libraries can still maintain separate favorite state where appropriate.

### 9.3 Batch favorites

Bulk favorite and unfavorite actions should operate on an explicit selection.

The confirmation or undo message should state the number affected.

### 9.4 Favorites versus protection

A favorite flag and a **protect from cleanup** flag should be separate.

A user may favorite a photo without wanting permanent protection from every storage-management tool. Another photo may need protection for archival reasons without being a favorite.

Cleanup rules should explain whether they respect either flag.

### 9.5 Rating without complexity

A simple favorite system should come first.

Optional star ratings, color labels, and pick/reject flags can be added for creator workflows, but Casual mode should not force users to manage several overlapping ranking systems.

---

## 10. Folder organization

### 10.1 Virtual organization should be the default

The safest first-level organization is virtual: grouping photos inside VRC Eye while leaving physical files where they are.

That gives users organization without unexpected filesystem changes.

Actual file moves should be an explicit, separately reviewed operation.

### 10.2 Folder browser

The source browser should reflect real folders and make clear when a displayed grouping is virtual.

A virtual album called “October screenshots” should not be visually indistinguishable from a physical folder with the same name.

### 10.3 Creating and moving folders

Users should be able to create folders within approved writable roots and move selected photos into them.

The move dialog should show the original location, destination, number of physical files, naming conflicts, and affected relationships.

It should also show whether associated layers or sidecars are included.

### 10.4 Naming templates

A naming-template editor could support fields such as capture date, world name, session label, and a short uniqueness suffix.

Unknown fields need explicit fallbacks.

A missing world name should produce something like `Unknown world`, not a guess based on whichever world is currently open.

### 10.5 Collision handling

The system should never overwrite an existing file silently.

It can offer skip, keep both with a suffix, or compare.

“Replace” should require an explicit decision and should explain whether the replaced file is also indexed elsewhere.

### 10.6 Safe physical moves

A move that requires copying data should verify the destination before removing the source.

The operation should be journaled so an interruption can be reconciled.

Database changes and filesystem changes must be treated as a coordinated workflow with recovery—not assumed to form one magically atomic operation.

### 10.7 Manual organization locks

Users should be able to mark a photo or folder as manually organized.

Automatic rules must not continually rearrange something the user has deliberately placed.

---

## 11. Albums and smart albums — additional feature

### 11.1 Manual albums

An album should contain references to photos, not duplicate image files.

One photo can therefore appear in “Favorites,” “World exploration,” and “October meetup” without consuming three copies’ worth of storage.

Removing a photo from an album should not delete the file.

### 11.2 Album properties

Albums should support a name, description, cover image, ordering preference, privacy setting, and optional association with a session or creator project.

The cover is a presentation choice, not a declaration that the photo was captured at the beginning of the event.

### 11.3 Smart albums

A smart album is a saved query that updates automatically.

Examples include favorite photos without a backup, images from a selected world, photos awaiting review, and recent imported images lacking session context.

The interface should say that membership is rule-driven.

Dragging a photo into a smart album should either explain that it cannot be added directly or offer to modify a relevant tag—not silently fail.

### 11.4 Album privacy

An album may be more restrictive than its individual photos.

Exporting the album should evaluate every selected item and the album’s own policy.

A public-looking album name must not automatically make its contents public.

---

## 12. Delete with confirmation

Deletion needs particularly careful design because “remove” can mean several different things.

### 12.1 Distinct actions

| Action                      | Intended effect                                                       |
| --------------------------- | --------------------------------------------------------------------- |
| Remove from album           | Removes only that album relationship.                                 |
| Hide from library           | Stops ordinary presentation without deleting the source.              |
| Stop indexing               | Excludes an item or source according to an explicit rule.             |
| Move to Trash / Recycle Bin | Requests recoverable physical removal where supported.                |
| Permanently delete          | Removes selected files through a separate, strongly confirmed action. |

The interface should not call all five actions “Delete.”

### 12.2 The confirmation dialog

The dialog should show a preview, the number of logical photos, the number of actual files, and whether any are favorites, protected items, covers, or members of multiple albums.

For a multilayer capture, it should state whether the action includes the composite, layers, and edited exports.

The default action should be recoverable removal where available.

### 12.3 Cross-platform trash handling

Linux desktop trash behavior should be implemented through the relevant platform facilities rather than inventing a universal trash directory. The freedesktop specification defines a trash system with associated information, but the application still needs to handle the actual capabilities of the selected location. [Freedesktop Specifications](https://specifications.freedesktop.org/trash/latest/)

If recoverable removal is unavailable, VRC Eye must not silently fall back to permanent deletion.

### 12.4 Undo and restoration

Undo should restore both the available physical files and their library relationships.

A filename collision during restoration should prompt a safe resolution rather than overwrite a new file.

The application should not promise indefinite recovery after an external trash system or another application has removed the data.

### 12.5 Shared physical files

A photo visible in two local account scopes may still point to one physical file.

Deleting that file from one scope can affect the other.

The confirmation must disclose that shared dependency, or the system should require an appropriate shared-library action rather than treating it as a private account-only deletion.

### 12.6 Partial failure

When 18 files are removed and two fail, the result should say exactly that.

The two failures must remain visible and retryable.

The application should not display a blanket success message and leave the database inconsistent.

### 12.7 Prevent unwanted re-import

A photo deliberately excluded from indexing should not immediately return during the next scan.

The exclusion mechanism should be explicit and should distinguish “I no longer want this file shown” from “this file is temporarily missing.”

---

# Part IV — Context, metadata, sessions, and automatic organization

## 13. Metadata-based organization

### 13.1 The actual VRChat metadata baseline

VRChat’s 2025.3.2 release documents a camera toggle controlling local XMP world/author metadata. It records the capturing user’s name and ID, not other players’ information, and omits the world name and ID when the world itself is private. VRC Eye should support that documented metadata without assuming that every file contains it. [VRChat](https://docs.vrchat.com/docs/vrchat-202532)

That immediately rules out a bad design assumption:

> A VRChat photo does not inherently contain a verified list of everyone visible in it.

### 13.2 Separate metadata categories

The detail model should distinguish **file properties**, **embedded claims**, **observed capture context**, **inferred associations**, and **manual annotations**.

A file’s dimensions are not the same kind of information as a user-entered world name.

An embedded photographer ID is not the same as a verified capture performed by the currently observed local runtime.

### 13.3 Provenance for every important field

Each important contextual field should carry its source.

Useful labels include:

> Embedded in image\
> Matched to local session history\
> Imported from a sidecar\
> Added manually\
> Suggested from timestamp

Advanced mode should expose why a match was made.

Casual mode can show a simpler “Confirmed,” “Suggested,” or “Unknown” state.

### 13.4 Confidence without fake precision

I would avoid percentage confidence unless the model has actually been calibrated.

“87% certain this was World A” sounds scientific but may only conceal a few arbitrary rules.

Readable states such as **Directly recorded**, **Strong match**, **Ambiguous**, and **Manually confirmed** are more honest.

### 13.5 Conflicting metadata

Suppose the embedded world says one thing while the local session timeline suggests another.

VRC Eye should retain both pieces of evidence, present the conflict, and let the user choose the preferred association.

It should not rewrite the original metadata to make the disagreement disappear.

### 13.6 Privacy of local annotations

Private notes, inferred session context, and people tags should stay in VRC Eye’s storage by default.

They should not be embedded into image files merely because they are useful for local search.

A portable metadata export should show exactly which fields will leave the local library.

### 13.7 Untrusted metadata parsing

Metadata parsers should enforce size limits, reject unsafe structures, and avoid following external references.

A photo’s metadata should never execute code, open arbitrary local paths, or initiate network requests.

Unknown metadata fields can be preserved as opaque information where safe, but they should not acquire application behavior automatically.

---

## 14. World, session, and date grouping

### 14.1 Date grouping

The library should distinguish capture time, import time, and file modification time.

A photo copied today should not automatically become a photo taken today.

Sorting needs clear labels such as **Date taken**, **Date added**, and **File modified**.

### 14.2 Missing time zones

A timestamp without a time zone should remain an uncertain local timestamp until there is sufficient information to interpret it.

The system should not invent an offset and then confidently associate it with a session.

A user can correct a batch of imported timestamps with a reviewed offset adjustment.

### 14.3 Calendar date versus session date

An evening session that crosses midnight should remain one session.

The same photos can still appear under two calendar dates in a date-based view.

The application should not force one grouping model to serve both purposes.

### 14.4 World grouping

World grouping should prefer stable identifiers where available, while retaining the world name recorded at capture time.

A later world rename should not erase historical labels.

The interface can show:

> Captured as “Old World Name” · Currently known as “New World Name”

But current-name enrichment should be optional and should reuse the shared world-information service.

### 14.5 Unknown and ambiguous groups

Unknown world and unassigned session groups should be first-class views.

They are not errors.

A library containing old photos should still be useful even when most of them cannot be associated with a world.

### 14.6 Group covers and counts

Group covers should use eligible images under the current privacy policy.

Counts should distinguish logical photos from additional layers or duplicate file locations.

A capture with four associated files should not necessarily appear as four unrelated photographs in every summary.

---

## 15. Photo/session relationships

This should connect directly to the Session Timeline and Journal we already planned.

### 15.1 Different relationship types

The system should distinguish:

**Captured during this session**, **manually attached to this session**, and **included in a recap of this session**.

Those are not interchangeable.

A friend might send a photo after the event. It can belong in the session’s album without pretending it was captured by the local user or imported while the session was active.

### 15.2 Matching procedure

A proposed automatic match should consider the best available capture-time evidence, the relevant runtime, the observed account, and the session’s world intervals.

It should not simply attach a new file to whichever session is currently on screen.

### 15.3 Delayed file writes

For example, a screenshot might indicate capture at 21:14:58, the user changes worlds at 21:15:02, and the file becomes visible to VRC Eye at 21:15:05.

The import time alone would point to the wrong world.

The matching logic should preserve the distinction between capture evidence and filesystem arrival.

### 15.4 World transitions

Photos near a transition boundary should receive extra scrutiny.

A configurable tolerance can help account for timing uncertainty, but it should not indiscriminately attach every nearby image to the nearest session.

When two candidates remain plausible, the correct output is an ambiguous match.

### 15.5 Incomplete sessions

A session missing its final exit event should not stretch indefinitely into the future.

The shared session service should expose whether an interval is open, completed, interrupted, or uncertain.

Photo matching should respect that state.

### 15.6 Manual correction

The user should be able to detach a photo, assign it to another session, or lock a manually confirmed relationship.

Future rescans should not override that decision.

The original evidence should remain inspectable so a correction does not rewrite history invisibly.

### 15.7 Account boundaries

VRC Eye’s currently selected login may not be the account associated with the running VRChat process.

Photo attribution must use the relevant observed runtime context where available.

Switching the application’s account should not reassign all subsequently discovered historical images to the new account.

### 15.8 Bidirectional navigation

From a photo, the user should be able to open the associated session.

From a session, the user should be able to open its photos.

Both views should refer to the same relationship records, so corrections appear consistently.

---

## 16. People relationships without pretending to know who is pictured

This deserves its own section because it is very easy to build incorrectly.

### 16.1 Presence is not appearance

A session roster can suggest who was present in the instance.

It cannot prove that each person appeared in a specific photo.

Therefore, the detail panel should separate **People tagged in this photo** from **People recorded in the associated session**.

### 16.2 Manual people tags

Users should be able to add a person tag manually, optionally linked to an already known profile.

The system can suggest names from the authorized local session context, but the user should confirm the relationship.

A text-only tag should remain possible when no profile is available.

### 16.3 No automatic identity claims from avatars

The system should not identify a player solely because an avatar resembles another photo.

The same avatar can appear in different contexts, and a person’s appearance can change.

Visual similarity is not a reliable account identity mechanism.

### 16.4 Consent and sharing notes

An optional local note could record that someone asked not to be included in public exports.

That should be treated as a practical sharing reminder, not as a comprehensive legal consent system.

The application should not infer permission to publish because someone was a friend, joined a group photo, or appeared in a public instance.

### 16.5 Removal requests

A user should be able to find photos manually tagged with a person and review them.

The system should not promise that removing a local copy also removes files already received by other people.

---

## 17. Auto-organization

### 17.1 Separate suggestion from execution

Auto-organization should begin with low-risk actions: adding virtual album membership, applying tags, and suggesting session relationships.

Physical moves and renames should require a more explicit policy.

Automatic organization must not be synonymous with automatic file manipulation.

### 17.2 Rule structure

A rule needs a name, scope, conditions, actions, priority, and explanation.

Conditions can use source folder, date range, confirmed world, session, existing tags, privacy state, and file properties.

Actions can add an album relationship, apply a label, suggest a cover, create an approved copy, or queue a reviewed physical move.

### 17.3 Example rule

A rule could read:

> For newly imported photos with a confirmed session relationship, add them to that session’s album. Do not move the original files. Do not change privacy settings.

That is a useful default because its behavior is understandable and reversible.

### 17.4 Rule preview

Before enabling a rule on existing photos, the user should see how many items match and a sample of the proposed results.

A physical organization preview should show exact before-and-after paths.

### 17.5 Rule conflicts

Conflicts need a deterministic policy.

Manual locks should take precedence over automatic organization.

Privacy rules should not be weakened by an album rule.

Two competing move destinations should produce a review task rather than whichever rule happens to execute last.

### 17.6 Repeat safety

Running a rule twice should not create duplicate albums, duplicate tags, or another copy of the same export.

Rules should record the version of the action that was applied and detect when the result already exists.

### 17.7 Historical scope

Applying a rule to future captures should be separate from applying it to the entire archive.

The default should not suddenly reorganize years of photos.

### 17.8 Explainability

A photo’s history should be able to say:

> Added to “World exploration” by rule “Favorite public-world photos.”

The user should be able to open, disable, or revise that rule from the explanation.

### 17.9 Undo

Reversible rule actions should support batch undo.

Where external changes make a full undo impossible, the application should explain the remaining differences rather than claim complete restoration.

---

## 18. Photo detail panel

The detail panel should be comprehensive without becoming a permanent wall of technical fields.

### 18.1 Overview

The first section should show title, favorite state, capture date, dimensions, source, and the preferred world/session association.

Unavailable or uncertain fields should remain visibly uncertain.

### 18.2 Context

The context section should contain linked sessions, world information, manual people tags, event notes, and relevant creator-project associations.

Session roster information should remain separately labeled.

### 18.3 Files and versions

This section should show the original, associated layers, edited versions, exports, and known file locations.

Each entry should state whether it is available, missing, modified, or located on an offline source.

### 18.4 Privacy

The privacy section should show the local visibility classification, the most recent scan status, unresolved findings, and whether the displayed rendition is approved for a particular export profile.

It must not reduce all of that to one misleading green shield.

### 18.5 Provenance

Advanced mode should expose timestamp sources, embedded metadata, matching evidence, manual overrides, and conflicts.

A “Why is this linked?” action should explain associations in ordinary language.

### 18.6 Activity history

The panel should record meaningful actions such as importing, moving, editing, correcting a session link, exporting, and restoring.

This history should avoid storing unnecessary sensitive content.

A diagnostic record needs to know that a privacy scan failed; it does not need to copy the sensitive text the scanner found.

---

# Part V — Creative tools, photo booths, and session presentation

## 19. Non-destructive editing — additional feature

### 19.1 Initial editing scope

A practical first editor should support crop, rotation, straightening, basic exposure and contrast adjustments, borders, text, and redaction.

The goal should be preparing and presenting photos, not rebuilding a full professional image editor.

### 19.2 Editing recipes

Edits should be stored as instructions associated with the original.

The user should be able to return to the original, revise a crop, remove a border, or create an alternate version without degrading the source through repeated saves.

### 19.3 Named versions

Useful versions might include **Original**, **Album edit**, **Public export**, and **Photo-booth strip**.

A version should preserve the relationship to its source.

It should not silently inherit an outdated privacy approval after the user changes its caption or visible contents.

### 19.4 External editors

“Open in external editor” should be an explicit handoff.

The user should choose whether to open the original or a working copy.

When the edited result returns, VRC Eye should validate it, create or update the appropriate version, regenerate previews, and invalidate privacy review where necessary.

### 19.5 Color and transparency

The editor should preserve intended appearance through the preview and export pipeline.

Transparent outputs need explicit background choices when exported to a format or destination that does not preserve transparency.

The preview should show the result the user will actually receive.

---

## 20. Multilayer capture support — important missing feature

VRChat’s camera documentation describes a Multi Layer mode that can save a regular photo plus environment, users, and UI images, with transparency in the users and UI masks. That makes capture bundles an important design consideration rather than an exotic future edge case. [wiki.vrchat.com](https://wiki.vrchat.com/wiki/Camera)

### 20.1 Bundle presentation

Related outputs should appear as one expandable capture where the relationship is sufficiently supported.

The default tile can show the composite image with a layer badge.

Expanding it reveals the available representations.

### 20.2 Conservative grouping

Grouping should use recognized producer naming or metadata conventions and appropriate timing evidence.

Files with similar names should not automatically become one capture when the relationship is uncertain.

The user should be able to join or separate a bundle manually.

### 20.3 Incomplete bundles

A capture missing one layer should remain usable.

The interface should distinguish **layer not produced**, **layer missing**, and **layer still arriving** where that distinction can be established.

### 20.4 Layer-aware actions

Export, backup, move, and delete dialogs should make their layer scope explicit.

“Export photo” should normally export the selected composite or rendition, not silently include every source layer.

### 20.5 Creative uses

Supported layers could enable alternate backgrounds, different booth layouts, and creator comparison sheets.

These should remain edits of a copy.

### 20.6 Privacy consequences

A clean composite does not automatically make every underlying layer safe to share.

Each exported layer needs its own review.

A bundle export must not accidentally include a UI layer that contains information absent from the composite.

---

## 21. Photo booth borders

### 21.1 Borders should be reusable templates

A border should be a template with assets, layout rules, optional text fields, and export behavior.

It should not be burned into the original as soon as the user selects it.

### 21.2 Template properties

A template needs an identifier, version, display name, supported aspect ratios, image-safe region, text regions, default colors, and asset references.

The version matters: changing a template later should not silently alter every previously exported image.

### 21.3 Layout handling

The user should be able to choose between expanding the canvas around the photo and placing decoration over the photo.

Those are different operations.

The preview should clearly show when an overlay covers image content.

### 21.4 Dynamic text

Templates could include an event name, custom caption, date, photographer label, or world name.

Every dynamic field should respect the photo’s export privacy policy.

A public export should not regain a private world name because a border template automatically inserts it.

### 21.5 Missing fields

A template should have explicit behavior for missing information: omit the field, use a neutral replacement, or ask the user.

It should never invent a world, photographer, or session title.

### 21.6 Custom border imports

The initial format should favor static assets and declarative settings rather than executable templates.

Imported packs need bounds checking, supported file-type validation, and safe asset paths.

A downloaded border should not be able to access arbitrary files or perform network requests.

### 21.7 Text quality

Text handling should cover wrapping, maximum length, font fallback, non-English characters, and contrast against the selected frame.

A caption that does not fit should produce a visible warning or controlled truncation, not disappear outside the canvas.

### 21.8 Batch application

Users should be able to apply a border to selected photos while previewing portrait and landscape examples.

Batch export should preserve individual originals and use collision-safe output names.

---

## 22. Photo strips, contact sheets, and collages — additional feature

### 22.1 Photo strips

A photo strip should support a fixed number of slots, configurable spacing, orientation, background, and optional captions.

The user should choose the order of images explicitly.

A missing capture should leave an editable slot rather than silently duplicate another photograph.

### 22.2 Contact sheets

Contact sheets would be useful for creator reviews and selecting photos with friends.

They should support thumbnail labels, optional filenames, sequence numbers, and configurable page or canvas sizes.

Sensitive filenames and world names must remain opt-in for public output.

### 22.3 Collages

Collage tools can support simple grids, unequal panels, and a highlighted main image.

The interface should show crop boundaries per image.

The system should not crop away important content merely to satisfy a layout without making that crop visible.

### 22.4 Reusable projects

A strip or collage should remain an editable project referencing source photos.

Deleting a source should warn that the project depends on it.

An exported collage is a separate rendered representation, not a replacement for the project.

---

## 23. Photo booth sessions and coordinated countdowns — additional feature

This should reuse the Eye-to-Eye photo coordination and countdown concepts already planned.

### 23.1 Booth session state

A booth session can define an event title, selected border, shot count, optional countdown, participating peers, and an output album.

It should remain useful with one person and no network connection.

### 23.2 Countdown is not shutter control

A countdown should be described as coordination unless an explicitly supported capture adapter can actually trigger and verify the photograph.

VRC Eye must not display “Photo taken” merely because a timer reached zero.

The state should distinguish **countdown completed**, **capture requested**, and **new image detected**.

### 23.3 Associating incoming images

During an active booth session, new candidate captures can be suggested for the next slot.

The user should be able to reject a candidate, replace a slot, or mark it as unrelated.

Ordinary screenshots taken during the event should not be absorbed into the strip unquestioningly.

### 23.4 Peer permissions

Permission to receive a countdown should not imply permission to receive the resulting photo.

Permission to send a photo should not imply permission to browse the sender’s library.

These capabilities should remain separate in the existing per-user permission system.

### 23.5 Failure handling

Disconnects, late countdown messages, canceled shots, and missing files should produce understandable states.

A canceled countdown must not suddenly execute after a connection recovers.

### 23.6 Notification behavior

Countdown sounds and overlays should respect the existing notification and do-not-disturb settings.

Photo coordination should not introduce a second independent audio-notification system.

---

## 24. Session cover photo

### 24.1 Manual selection first

Every session should be able to use a manually selected cover.

The cover should reference a specific rendition, so a redacted or cropped version can be used without altering the original.

### 24.2 Suggested covers

Automatic suggestions can prioritize user favorites, suitable aspect ratios, and complete available images.

The application should not claim to know which photograph is emotionally most important.

A suggested cover remains a suggestion until the chosen policy accepts it.

### 24.3 Crop and focal point

Cover selection should include a preview of the actual session-card dimensions.

The user should be able to choose a focal point so a wide card does not crop the subject out unexpectedly.

### 24.4 Different presentation contexts

A private journal cover and a shareable session-card cover can be different renditions.

The system must not reuse a private cover automatically in a public recap.

### 24.5 Deleted or unavailable covers

If a cover becomes unavailable, the session should show a neutral placeholder or another explicitly eligible choice.

It should not silently substitute an arbitrary private photo.

### 24.6 Privacy-mode behavior

Guest, presentation, and streamer modes should reevaluate cover eligibility.

Hiding sensitive photo tiles while leaving them visible as giant session banners would defeat the entire privacy design.

---

# Part VI — Privacy scanning, redaction, and sharing

## 25. Screenshot privacy scanner

This should be one of the defining features of the photo system, but its purpose must be stated honestly:

**It is a local review assistant that helps detect possible disclosures. It is not a guarantee that an image is safe to publish.**

### 25.1 Two different kinds of disclosure

The scanner should inspect both **visible image content** and **non-visible accompanying information**.

Removing metadata does not remove a username printed in the picture.

Covering a username does not remove identifiers embedded in the file.

Both paths matter.

### 25.2 Metadata inspection

The scanner should examine supported embedded metadata, including author information, world identifiers, comments, timestamps, and other potentially identifying fields.

PNG itself supports Exif information, and the specification warns that metadata and embedded thumbnails may no longer correspond to an edited main image. That is another reason to inspect the actual export rather than assume an editor cleaned everything correctly. [W3C](https://www.w3.org/TR/png-3/)

The public-export pipeline should use a deliberate metadata allowlist rather than copy every source field by default.

### 25.3 Visible text inspection

An optional local text-recognition stage could look for possible usernames, account identifiers, invite or instance information, chat overlays, email addresses, filesystem paths, and credential-like text.

It should report **possible sensitive text**, not claim that every detected string is confidential.

A public world name and a private session join detail should not receive identical treatment.

### 25.4 Overlay and interface regions

The scanner can help flag likely chat panels, player lists, diagnostic windows, notification banners, and interface overlays for review.

It should also allow user-defined regions or masks for recurring overlays.

A preset is only a starting point; the user must still be able to move or resize it.

### 25.5 Codes and links

A supported code-recognition stage could flag QR codes or similar machine-readable content.

It should never automatically open a decoded destination.

The purpose is to alert the user that the image may contain an actionable link or identifier.

### 25.6 Private-world and private-session context

The privacy model should keep world publication state, instance access, and local session privacy separate.

A world identifier being present must not be treated as proof that publishing the surrounding session context is appropriate.

Local privacy preferences should remain authoritative even when embedded metadata is technically readable.

### 25.7 No identity recognition requirement

The scanner does not need face recognition, avatar-to-account matching, or guesses about personal characteristics.

Its job is to identify possible disclosure regions and fields—not to identify strangers.

### 25.8 Local processing by default

The design should keep image analysis local by default.

A future optional external analysis provider would require a separate, explicit disclosure of what leaves the device and for what purpose.

“Scan for privacy” must not quietly upload the potentially private image elsewhere.

### 25.9 Minimal retained scanner data

By default, the application should retain the finding category, region, review decision, and relevant processing version.

It should avoid retaining a searchable archive of every recognized private message or credential-like string.

Raw recognized text can be transient unless the user deliberately enables a text-search feature with a clear retention policy.

### 25.10 Clear scan states

The user should see states such as **Not scanned**, **Scanning**, **Possible disclosures found**, **Reviewed**, **Scan failed**, and **Needs rescanning**.

“Reviewed” means the user or configured workflow reviewed that specific output.

It should not mean “guaranteed private.”

### 25.11 Explainable findings

Each finding should show its location, category, and reason.

For example:

> Possible account identifier detected in the upper-right overlay.

The interface should support reviewing the region at a useful zoom level.

### 25.12 False positives

Users should be able to dismiss a finding for the current export or create a narrowly scoped exception.

A dismissal should not automatically trust the same text in every future image and every account.

### 25.13 False negatives

The interface should explain that stylized text, small text, reflections, unusual languages, or contextual clues may be missed.

A lack of findings should lead to **No findings detected**, not **Nothing private exists**.

### 25.14 Scan the final rendition

A scan result should be associated with the actual representation and processing settings.

Changing the crop, caption, border, image layer, or export metadata should invalidate the relevant review.

A previously approved source cannot automatically approve a newly rendered image.

---

## 26. Redaction tools — additional feature

### 26.1 Manual redaction must always be available

The user should be able to select a rectangular or freeform region even when automatic scanning is disabled or finds nothing.

Automatic detection should assist the user, not become a prerequisite for protecting an image.

### 26.2 Real redaction versus decorative blur

For genuinely sensitive information, the export tool should favor an opaque replacement or removal from the output.

A blur effect can remain available as an aesthetic choice, but the application should not present it as equivalent to reliably removing the underlying content.

The requirement is that the sensitive pixels are absent from the delivered representation—not merely hidden by an editable overlay.

### 26.3 Coordinate correctness

Redaction regions must remain correctly aligned after cropping, rotation, resizing, and layout placement.

The internal editing system should transform masks with the image rather than reuse stale screen coordinates.

This needs explicit tests because a misaligned mask can look almost correct while leaving part of an identifier visible.

### 26.4 Flattened output

A redacted export should not include the unredacted original as a hidden layer, embedded preview, project attachment, or accidental sidecar.

For transparency-sensitive cases, the export process should ensure that hidden pixel data does not preserve the removed content.

### 26.5 Before-and-after review

The user should be able to inspect the finished output at full resolution before sharing.

In privacy-restricted presentation modes, original comparison should remain deliberately gated so the review interface does not expose what the export is trying to protect.

### 26.6 Batch redaction

Reusable masks can help with recurring overlays, but batch application should include a sample review and individual exceptions.

One fixed rectangle should not be assumed to cover a moving interface element in every photo.

---

## 27. Export and share preparation — essential additional feature

### 27.1 One central export workflow

Borders, edits, session covers, social handoffs, clipboard copies, and peer transfers should all use the same export-policy system.

Otherwise, a photo might be safely redacted through one button and leaked through another.

### 27.2 Export profiles

Useful profiles could include **Original archive**, **Edited local copy**, **Public image**, **Trusted-recipient image**, and **Creator review package**.

Profiles should define dimensions, quality, format, metadata handling, filename policy, and review requirements.

The names should not imply guarantees. “Public image” is a preparation policy, not proof of consent.

### 27.3 Exact output preview

The export screen should show the actual crop, border, redaction, background, and metadata policy.

A user should not preview a PNG with transparency and receive a JPEG with an unexpected background.

### 27.4 Filename privacy

Export filenames should be treated as part of the disclosure surface.

A sanitized image should not be delivered as:

`Private-event_full-account-name_exact-session-details.png`

A neutral filename option should be easy to select.

### 27.5 Sidecars and project files

Public image exports should exclude private sidecars, editing projects, session manifests, and source-layer bundles unless explicitly selected.

An archive package and a public share package must have different defaults.

### 27.6 Clipboard behavior

“Copy share-ready image” should copy the prepared rendition, not the original file behind it.

“Copy original file” should be a separate action.

The application should make clear that another application receiving a copy is outside VRC Eye’s later control.

### 27.7 Drag-and-drop exports

Dragging a photo from a share-preparation view should deliver the prepared export.

Dragging from a raw library view should have clearly defined behavior and should not silently bypass the active privacy policy.

### 27.8 Final verification

Before reporting export success, VRC Eye should confirm that the file exists, can be decoded as expected, has the intended dimensions, and follows the selected metadata policy.

A saved path alone is not enough.

### 27.9 Review bypasses

The user can have a workflow that allows manual export without automated scanning.

That output should be labeled **Not automatically scanned**, rather than falsely inheriting a passed status.

A user-enabled stricter profile can require review before its own sharing action proceeds.

---

## 28. Sharing through existing VRC Eye systems

### 28.1 Reuse the social and networking architecture

Photo sharing should integrate with the existing account system, reviewed account-bound actions, peer permissions, and networking transports.

Photos should not implement a second login store, separate friend list, independent message inbox, or new unreviewed sending mechanism.

### 28.2 Separate permissions

Permission to coordinate a photograph, receive a thumbnail, receive a full-resolution image, and receive a source-layer package should be separate.

A successful Eye-to-Eye handshake should not expose the library.

### 28.3 Recipient review

A send action should show the recipient, active sending identity, selected rendition, file size, and whether source metadata or additional files are included.

An account change after preparation should require revalidation before sending.

### 28.4 Transfer integrity

Transfers should verify that the received bytes correspond to the intended export.

That verifies transfer integrity; it does not prove the scene is authentic or the claimed photographer is genuine.

### 28.5 Incoming photos

Received images should enter an explicit incoming-photo workflow.

They should be validated and indexed as imported material, not assigned local capture provenance.

### 28.6 Revocation expectations

A future hosted link may support disabling access to that hosted copy.

It cannot guarantee removal of copies another person has already saved.

The interface should not use “revoke everywhere” language.

### 28.7 VRChat-specific online actions

Any future connection to VRChat’s own inventory, gallery, or image-bearing social features should be capability-checked and routed through the existing account-action layer.

The local Photos tab should remain fully functional without those capabilities.

---

# Part VII — Features missing from the original list

## 29. Search and filtering

### 29.1 Searchable fields

Search should cover filenames, titles, notes, manual tags, albums, world labels, session labels, and supported file properties.

The result should indicate why a photo matched.

### 29.2 Combined filters

Users should be able to combine date ranges, favorites, source folders, orientations, dimensions, privacy states, review states, and association confidence.

A creator might search for landscape favorites from a particular world that have not yet been exported.

### 29.3 Text inside images

Searching recognized image text should be optional and separate from basic privacy scanning.

Enabling it changes what information the application retains.

The user should be told that it can create a local searchable index of visible text.

### 29.4 Saved searches

A useful search should be saveable as a smart album.

The underlying query should remain inspectable and editable.

### 29.5 No silent broadening

When a filter finds nothing, the application should not quietly remove the restrictive filter and show unrelated private images.

It can suggest broadening the query, but the user should make that choice.

---

## 30. Duplicate detection and burst grouping

### 30.1 Exact duplicates

Exact duplicate detection should compare content, not just filenames.

The system can present multiple file locations for the same bytes without immediately merging their privacy scopes or deleting anything.

### 30.2 Visually equivalent images

Two images can appear identical while differing in metadata, encoding, or hidden information.

Visual equivalence should not imply identical privacy properties.

Their export reviews may still differ.

### 30.3 Similar-photo suggestions

A similarity tool can help identify near-duplicate poses or repeated shots.

Its result should be a suggestion for comparison, not an automatic deletion decision.

### 30.4 Burst groups

Photos captured close together can be presented as a collapsible sequence where appropriate.

The user should be able to split or merge a burst manually.

### 30.5 Picking the best shot

The comparison workflow should allow pick, reject, favorite, and protect states.

Automatic quality estimates can be a later optional aid, but they should not decide which photographs have personal value.

### 30.6 Cleanup safety

Duplicate cleanup must show exact files, locations, protected states, and retained copies.

It should never delete the last available original merely because an edited or lower-resolution image looks similar.

---

## 31. Backup, portability, and library recovery

### 31.1 Back up more than the images

A complete library backup needs the relevant originals or file references, catalog data, album membership, notes, manual associations, editing recipes, and necessary template assets.

Backing up only thumbnails is not a photo backup.

Backing up only originals loses the organization work.

### 31.2 Backup modes

A **catalog-only backup** should clearly say that it does not contain the image collection.

A **complete managed backup** should report which referenced files were included and which were unavailable.

### 31.3 Consistency

The catalog backup should use a consistent snapshot.

It should not blindly copy a database file while related updates are partially committed.

### 31.4 Verification

Backup jobs should verify copied files and record incomplete items.

“Backup completed with 12 unavailable originals” is much more useful than “Success.”

### 31.5 Restore previews

Restoration should show the target location, collisions, account scopes, and whether the operation will merge or create a separate library.

It should not automatically overwrite a newer catalog.

### 31.6 Portability

Users should be able to export their organization data in a documented form.

The system should not trap favorites, tags, and session associations in an opaque database with no migration route.

### 31.7 Privacy and backup destinations

Private catalog data should not be copied into an externally synchronized destination without the user choosing that destination knowingly.

A local privacy setting should not be represented as protection over every independent backup or synchronization service.

---

## 32. Library repair and missing-file recovery

### 32.1 Relinking moved folders

When a folder moves, the user should be able to locate its new root and preview the proposed relinks.

The system can compare file evidence, but it should not blindly connect unrelated files with matching names.

### 32.2 Externally modified files

External changes should create a new observed version state or a reviewed update, depending on policy.

Thumbnails, metadata parsing, duplicate analysis, and privacy review should be invalidated where affected.

### 32.3 Rebuild options

Separate actions should exist for rebuilding thumbnails, rebuilding search indexes, rescanning metadata, and reconciling file locations.

A user should not have to delete the entire library to fix one damaged cache.

### 32.4 Health report

A library health view should show missing originals, invalid files, unavailable sources, stale derivatives, unfinished moves, and backup gaps.

It should prioritize actionable problems.

### 32.5 Recovery after interruption

An interrupted move, export, or import should be resumed or reconciled from a job record.

Temporary files should not be treated as completed photos.

Cleanup should avoid deleting a temporary file that still belongs to an active operation.

---

## 33. Multi-account photo organization

### 33.1 Three different scopes

The system should distinguish **device-wide sources**, **account-scoped organization**, and **explicitly shared local collections**.

A physical folder may be available to the machine while its notes and session associations belong to one VRC Eye account scope.

### 33.2 Capture identity versus active interface account

The account currently selected in VRC Eye should not automatically determine the photographer of every imported image.

Observed runtime identity, embedded claims, and manual attribution should remain separate.

### 33.3 Switching accounts

Switching accounts should clear or replace private search results, details, thumbnails, recent-item lists, and queued share destinations appropriately.

It should not leave the previous account’s private cover photo visible while the rest of the interface changes.

### 33.4 Queued actions

Exports and transfers should capture their intended scope when created and revalidate it before execution.

A queued “send to friend” action should not silently continue under another account.

### 33.5 Shared collections

Cross-account album access should be explicit.

Sharing an album locally should not merge all historical session data or expose private notes automatically.

### 33.6 Security boundaries

A privacy label inside VRC Eye is not the same as filesystem encryption.

An optional encrypted-library feature would need to cover the catalog, previews, temporary outputs, backups, and key handling—not merely encrypt one database field.

That should be treated as a separately designed capability, not a cosmetic “locked album” promise.

---

## 34. Privacy-mode integration

### 34.1 History Off

History Off should prevent photo features from quietly rebuilding session history through imported metadata and correlations.

Basic file browsing can remain available, but contextual retention needs to follow the chosen privacy policy.

### 34.2 Incognito sessions

Incognito should have explicit photo behavior.

Possible controls include stopping contextual association, stopping new photo indexing, and disabling photo notifications.

The interface must make clear that these controls govern VRC Eye; they do not themselves stop VRChat or another application from saving image files.

### 34.3 Preventing later re-import

A future rescan must not silently undo an explicit exclusion.

Where persistent exclusion tracking is required, the application should disclose what marker is retained. Source separation can be an alternative for users who do not want such tracking.

### 34.4 Streamer and presentation modes

These modes should apply to thumbnails, previews, titles, account names, source paths, covers, search suggestions, and notifications.

A privacy mode that hides only the detail panel is incomplete.

### 34.5 Guest mode

Guest mode should disable access to private collections and sensitive operations according to policy.

It should not expose hidden photos through keyboard navigation, slideshow transitions, or recent-item history.

### 34.6 Policy changes during processing

If a photo becomes private while its export is queued, the queued action should re-evaluate the policy.

Privacy decisions should not be captured once and then ignored during long-running work.

---

## 35. VRCX Companion Mode integration

VRCX already advertises storing world data in in-game pictures. That is a concrete reason to design coexistence carefully rather than have both applications rewrite the same images independently. [GitHub](https://github.com/vrcx-team/VRCX)

### 35.1 Single ownership of side effects

For each source, there should be a clear owner for metadata writing, automatic renaming, physical organization, and save notifications.

VRC Eye can index an image without claiming ownership of all operations around it.

### 35.2 Read without competing writes

Where VRCX supplies supported photo metadata, VRC Eye can read it as an external source with provenance.

It should not need to modify VRCX’s database or undocumented private storage.

### 35.3 Avoid duplicate notifications

If one application is configured to announce new screenshots, the other can suppress equivalent presentation while still updating its internal library.

Suppression must not prevent indexing.

### 35.4 Independent operation

VRC Eye’s photo library should remain useful when VRCX is absent, closed, or incompatible.

The integration should enrich the workflow, not become a dependency.

### 35.5 Visible integration status

Advanced mode should explain which application owns which actions and whether a conflict exists.

Casual mode can show a simpler message:

> VRCX handles photo metadata. VRC Eye manages browsing and albums.

Only supported, actually configured behavior should be presented that way.

---

## 36. Creator workflows

### 36.1 World playtest albums

A world creator should be able to attach selected photos to an existing playtest session, checklist item, or issue.

This should reuse the Creator workspace rather than create a second issue tracker inside Photos.

### 36.2 Before-and-after comparisons

Photos can be paired across world revisions or lighting changes.

The user should explicitly label the comparison context.

The system should not infer that visually different screenshots necessarily represent a performance or correctness improvement.

### 36.3 Avatar reference sets

An avatar creator can organize front, side, back, expression, and outfit reference shots into a project album.

Manual shot labels should be available.

The photo system should not claim it can identify the exact underlying avatar asset merely from pixels.

### 36.4 Annotated feedback

Simple arrows, callouts, and numbered markers would help explain visual issues.

Exports should distinguish annotations from original capture content.

### 36.5 Diagnostic attachments

A photo can be attached to an existing Black Box or runtime diagnostic event manually.

The attachment should mean “relevant visual context,” not proof that the visible avatar or world caused the event.

---

## 37. Slideshows, memories, and session recaps

### 37.1 Slideshows

Slideshows should support selected albums, timing, manual navigation, and presentation-safe filtering.

Private photos should not appear because the user reached the end of an approved subset.

### 37.2 Session recap builder

A recap can combine selected photos, a cover, a user-written description, and permitted session details.

The existing session service should supply context; the recap builder should not reconstruct a competing history.

### 37.3 Memory resurfacing

An optional “On this date” view could surface past photos.

It should be disabled for excluded or private collections according to policy and should not generate surprise notifications by default.

### 37.4 Manual storytelling

Users should be able to arrange photos into a deliberate sequence.

Automatic chronological sorting is useful, but it should not override a user-created narrative order.

---

# Part VIII — Performance, reliability, and implementation boundaries

## 38. Resource management

### 38.1 Protect the running game

Indexing, thumbnail generation, similarity analysis, and optional text recognition should run under resource budgets.

Opening one image should not trigger full-resolution processing of the entire folder.

### 38.2 Separate queues

The system should distinguish interactive preview work, live capture indexing, archive import, privacy analysis, and maintenance.

Interactive actions should receive priority without starving all maintenance permanently.

### 38.3 Pause expensive work

Users should be able to pause heavy processing while keeping basic browsing and file detection active.

A low-overhead profile should reduce worker concurrency and defer nonessential analysis.

### 38.4 Bounded decoding

Every decoder should have limits for dimensions, memory use, processing time, and metadata size.

Unsupported or malformed files should produce controlled failures, not crash the whole application.

### 38.5 Honest progress

Progress should distinguish files discovered, files indexed, previews generated, and secondary analyses completed.

A scan that has indexed everything but still has thumbnails pending should not sit at an unexplained 99%.

### 38.6 Performance testing

Large-library support should be tested against documented sample sizes and hardware.

The interface can be designed for very large collections, but we should not advertise specific speed or capacity claims before measurement.

---

## 39. Accessibility and everyday usability

### 39.1 Keyboard access

All major actions should be accessible without a mouse.

Focus order should remain predictable across the grid, toolbar, detail panel, and dialogs.

### 39.2 Screen-reader descriptions

Photo tiles should expose useful labels such as title, date, favorite state, and availability.

Private metadata should not leak through accessibility text when it is hidden visually.

### 39.3 Visual clarity

Selection, focus, favorites, privacy state, and processing errors should not depend solely on color.

Thumbnail density and text size should be adjustable.

### 39.4 Motion settings

Grid transitions, preview animations, and slideshow effects should respect reduced-motion preferences.

### 39.5 Localization

Dates, sorting, filename display, and text layout should accommodate different languages and writing directions.

The underlying stored identity should remain stable when the interface language changes.

### 39.6 Error language

Errors should explain what happened and what action is available.

> The source drive is disconnected. Reconnect it to open the original.

is better than:

> Resource resolution failure.

Technical detail can remain expandable.

---

## 40. API, authentication, and risk labels

Most of this system should require **no VRChat API access at all**.

The proposed labeling should distinguish network risk, filesystem effects, and privacy impact instead of squeezing them into one vague warning.

| Operation                          | Proposed authentication/API treatment                      | Important non-API impact                       |
| ---------------------------------- | ---------------------------------------------------------- | ---------------------------------------------- |
| Browse approved local folders      | No VRChat login required                                   | Reads local images and metadata.               |
| Favorite or add to local album     | No VRChat API required                                     | Writes local catalog state.                    |
| Generate thumbnails                | No VRChat API required                                     | Creates cached image derivatives.              |
| Move or delete files               | No VRChat API required                                     | Potentially destructive filesystem action.     |
| Match to existing local sessions   | No new API request required                                | Uses retained session context.                 |
| Fetch missing world details        | Optional shared API service, subject to its requirements   | Discloses a lookup and enriches local context. |
| Export a local edited image        | No VRChat API required                                     | Creates a potentially shareable copy.          |
| Send through an online integration | Explicit recipient/account review and supported capability | Transfers image data outside the device.       |

The core library should work offline.

Browsing 500 photos should not cause 500 repeated world requests.

Any optional enrichment should use the existing cache, request scheduler, authentication handling, and privacy policy.

---

## 41. Developer diagnostics and test tooling

### 41.1 Photo pipeline inspector

Developer Mode can expose source health, watcher state, import queues, decoder results, association evidence, and export-job history.

This should be an inspection tool, not an excuse to bypass ordinary file safety.

### 41.2 Synthetic test library

A dedicated test library should include missing metadata, conflicting metadata, unusual filenames, large images, corrupt files, incomplete writes, multilayer bundles, and intentionally placed mock privacy findings.

Tests should use synthetic sensitive-looking strings rather than real credentials or private conversations.

### 41.3 Reproducible association tests

The session matcher should be testable against fixed timelines and known expected outcomes.

Examples should cover world transitions, clock changes, delayed writes, interrupted sessions, and multiple runtimes.

### 41.4 Export audit

A diagnostic export should be able to report the transformations applied, metadata policy, output dimensions, and validation status without including the private original.

### 41.5 Sanitized diagnostics

Bug reports should avoid full personal paths, raw recognized text, private session details, and image contents unless the user explicitly chooses to attach them.

The photo system should not become the application’s largest accidental source of sensitive diagnostic data.

---

# Part IX — Delivery order and definition of done

## 42. Recommended implementation sequence

I would build this in capability layers, with each layer useful on its own.

### Layer A — Reliable local library

This establishes approved source discovery, Windows and Linux/Proton path handling, robust indexing, thumbnails, preview, favorites, source health, and confirmed recoverable deletion.

The success criterion is simple: **the user can browse and manage photos without losing files or requiring a VRChat login**.

### Layer B — Trustworthy context

This adds metadata provenance, date/world/session grouping, manual corrections, session relationships, detail panels, and session covers.

The success criterion is **useful context with visible uncertainty**, not maximum automatic tagging.

### Layer C — Safe editing and export

This adds non-destructive editing, manual redaction, metadata inspection, export profiles, final-output validation, and optional automated visible-content scanning.

The success criterion is **a clearly identified share-ready rendition that does not silently include the original or private sidecars**.

### Layer D — Organization and creative workflows

This adds smart albums, rule previews, reviewed physical organization, multilayer bundles, photo-booth borders, strips, collages, duplicate comparison, and creator-project attachments.

The success criterion is **less repetitive work without unpredictable automation**.

### Layer E — Optional integrations

This adds peer photo coordination, approved transfers, supported online publishing adapters, advanced backup destinations, and deeper companion integrations.

The success criterion is **additional capability without making the local photo system dependent on another application or service**.

---

## 43. Acceptance criteria that should be tested explicitly

| Test case                                             | Required outcome                                                                                |
| ----------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| A screenshot is still being written                   | It waits or retries; it is not immediately treated as a completed or permanently corrupt photo. |
| The watcher reports the same file several times       | One logical import occurs.                                                                      |
| A watcher loses events                                | Reconciliation finds the missed files.                                                          |
| An archive is imported                                | It does not generate thousands of live-capture notifications.                                   |
| A Proton path resolves through a custom drive mapping | The correct approved host location is used.                                                     |
| An external drive disconnects                         | Photos become unavailable, not deleted from the catalog.                                        |
| A photo has no metadata                               | Browsing still works; unknown context stays unknown.                                            |
| Embedded world data conflicts with session history    | Both sources remain visible and the conflict is reviewable.                                     |
| A screenshot arrives after a world transition         | Capture evidence is considered separately from arrival time.                                    |
| A user was present in the session                     | They are not automatically labeled as visible in every photo.                                   |
| A photo is moved outside VRC Eye                      | Relinking preserves organization when the file is correctly identified.                         |
| A border adds a world name after a scan               | The final rendition requires renewed review.                                                    |
| A redacted image is exported                          | The delivered file does not contain the unredacted original as a hidden attachment or layer.    |
| A multilayer capture is deleted                       | The confirmation clearly identifies which files are affected.                                   |
| Recoverable deletion is unavailable                   | There is no silent fallback to permanent deletion.                                              |
| An account changes during a queued send               | The action is revalidated rather than sent under the wrong identity.                            |
| Guest or streamer mode is activated                   | Covers, previews, search results, and notifications follow the same privacy policy.             |
| VRCX is closed                                        | The local library continues functioning.                                                        |
| An organization rule runs twice                       | It does not duplicate actions or keep renaming the same files.                                  |
| A job fails halfway through                           | Completed and incomplete work are reported accurately and can be reconciled.                    |

---

## The central design decision

The photo system should preserve five distinctions everywhere:

**An original is not an export. A file is not an album entry. Session presence is not proof of appearing in a photograph. A metadata claim is not verified identity. A successful scan is not a guarantee of privacy.**

Keeping those distinctions intact lets VRC Eye offer a much richer system: a useful gallery for Casual users, an organized archive for long-term users, a production tool for creators, and a privacy-aware preparation workflow for sharing.

**That is the version worth building: a photo system that remembers useful context, admits what it does not know, and never makes destructive or public-facing decisions invisibly.**