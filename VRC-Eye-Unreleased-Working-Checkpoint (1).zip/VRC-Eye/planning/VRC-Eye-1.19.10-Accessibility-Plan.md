# VRC Eye 1.19.10 — Accessibility planning and integration map

Status: planning only. No application changes, dependency installation, runtime tests, or release build authorized or performed for this review.

Prepared: October 2, 2026.

## 1. Scope and evidence

Accessibility is a shared requirement across the application, not a separate reduced-capability edition or a cosmetic theme. The user's earlier accessibility list is the baseline. The proposed navigation, implementation details, recovery workflow, and acceptance criteria below expand that list; they are planning recommendations rather than an implemented specification recovered from another conversation.

The already supplied Social / Account specification, section 36, requires keyboard access, color-independent states, stable focus, safe Enter behavior, readable names, larger-text tolerance, and reduced motion. Its section 45 includes large-text and translated-interface tests. The supplied Photos specification, section 39, requires keyboard access, privacy-safe screen-reader descriptions, density/text controls, color-independent states, reduced motion, localization, and understandable errors. These requirements should be consolidated, not duplicated.

## 2. Read-only source inspection

Baseline inspected directly inside `/mnt/data/files/VRC-Eye-v1.19.9.zip`. The ZIP contains 371 non-directory entries. SHA-256 before inspection:

`dbdd0ed01a0d4e8aac42edc12bc4debc2f4f61007037d367ab5f7846e5adac07`

The review read source text with Python's standard-library ZIP reader. It did not import or execute project code, extract a modified project, install dependencies, open the app, or exercise assistive technology.

### Existing controls to extend

| Source | Observed baseline | Planning implication |
| --- | --- | --- |
| `VRC-Eye/ui_preferences.py`, lines 6–18, 21–39 | Casual/Advanced/Developer modes, Comfortable/Compact density, Standard/Larger text, and a versioned `ui.presentation` record. | Extend and migrate the existing presentation settings rather than add a competing preference file. |
| `VRC-Eye/ui_theme.py`, lines 7–24 | Shared Tk/ttk theme, `clam`, named fonts, and 10-point or 12-point base text according to the existing text preset. | Introduce a scalable typography and theme model here; existing presets are not evidence of full-interface scaling support. |
| `VRC-Eye/ui_theme.py`, lines 38–48, 62–78 | Heading styles, button focus styling, focus borders, and density-dependent tree row heights. | Extend shared tokens and control states instead of drawing different focus indicators separately on every page. |
| `VRC-Eye/ui_theme.py`, lines 98–107 | Responsive label wrapping helper. | Reuse and expand reflow support; labels alone do not establish full-page reflow. |
| `VRC-Eye/friendly_ui.py`, lines 17–37 | Button-based Show/Hide disclosure controls. | Preserve discoverable keyboard activation; verify programmatic expanded state rather than assume the visible label is sufficient. |
| `VRC-Eye/friendly_ui.py`, lines 40–68 | Canvas-backed scroll area with a minimum content width. | Include narrow-window, magnification, focus-scrolling, and accessibility-tree tests. This observation alone is not a confirmed runtime failure. |
| `VRC-Eye/friendly_ui.py`, lines 275–303 | Existing Appearance settings and Reset appearance only. | Accessibility and Settings should edit the same values. Extend appearance-only recovery rather than reset account or library data. |
| `VRC-Eye/friendly_ui.py`, lines 490–494 | Existing Ctrl+K and Ctrl+comma shortcuts. | Extend existing navigation/shortcut handling; do not add duplicate global key bindings. |
| `VRC-Eye/wellness_ui.py`, lines 137–140 | Existing large reminder text, reduced motion, and sound controls. | Preserve explicit choices and map component-specific preferences into the shared policy carefully. |
| `VRC-Eye/peer_app.py`, line 46 | Peer setup reads reduced motion from wellness settings. | Replace fragmented policy sources deliberately, with migration and consumer testing; do not merely add a new unused checkbox. |

A targeted search of non-test Python source did not find explicit application-level UI Automation, IAccessible, AT-SPI, screen-reader, or accessible-name implementation references. This does NOT establish that native controls expose no accessibility information. Exact platform behavior remains untested. An accessibility-tree and assistive-technology assessment is required before promising support.

## 3. Navigation and availability

Proposed primary destination: **VRC Eye → Accessibility**, visible in Casual, Advanced, and Developer views. Settings, the existing command palette, the initial screen, and sign-in should provide links to that same destination or its relevant controls.

Proposed internal sections: Display & Text; Input & Navigation; Alerts & Audio; Motion & VR; Profiles & Recovery. These are internal groupings, not five new sidebar categories.

Preserve the requested sidebar hierarchy: section headings slightly larger (approximately 1–2 points at the base size) and bolder than category buttons; visible divider lines between sections only. Scale the hierarchy consistently with text settings. Dividers are not focusable actions. No lines between individual clickable categories.

Accessibility settings must be usable before VRChat sign-in, offline, and without VRCX, a client bridge, or a VR headset. Merely opening settings must not start a network listener, arm camera/game controls, or change the selected VRChat account.

## 4. Baseline feature mapping

All 19 previously requested items remain in scope.

| Requested item | Planned behavior |
| --- | --- |
| High contrast | Light/dark high-contrast themes, system-follow mode where supported, explicit override, readable controls and state differences. |
| Scalable text/UI | Independent text and control scaling, responsive layout, font fallback, preserved labels, tested operating-system display scaling. |
| Keyboard navigation | Logical region/tab order, standard activation, list navigation, keyboard context actions, predictable dialog focus. |
| Visible focus states | Distinct focus versus selection; sufficiently visible outlines; focused controls scroll into view. |
| Screen-reader labels | Names, roles, values, state, relationships, and change events through the actual platform accessibility interface. |
| Reduced motion | Suppress decorative animations and animated reorderings without suppressing underlying data updates. |
| Color-independent status indicators | Text and distinct icons/patterns; no red/green-only warnings or account identity. |
| Colorblind palettes | Optional palettes tested for contrast; never the only way states can be distinguished. |
| Visual equivalents for sounds | Every meaningful VRC Eye sound has a persistent or reviewable visual equivalent. |
| Audio equivalents for visual alerts | Optional private spoken/tonal equivalents for meaningful VRC Eye events; scoped, rate-limited, and user-controlled. |
| Adjustable/persistent notifications | User-controlled duration and routes, reviewable outcomes, batching, no focus theft, quiet-mode coordination. |
| Simplified layout | Reduce density and competing information while preserving authority, account, target, consequences, and recovery. |
| Large-control mode | Larger hit areas and spacing, separate from font size; clear non-destructive alternatives to precision gestures. |
| Readable typography/density controls | Font size/weight, spacing, row height, wrap, readable long names and text fallback. |
| Remappable hotkeys | Shared registry, conflict detection, scope labels, reset, keyboard-only remapping, no capture-time action dispatch. |
| No unnecessarily timed interactions | Persistent review controls; no short response requirement for local actions; actual service expiry remains unchanged. |
| Comfortable VR-overlay placement | Adjustable anchor, size, distance, angle, opacity/background; seated/one-handed use and recentering. |
| Accessibility profiles | Composable task-oriented presets with reviewed changes; not diagnoses or permission bundles. |
| Import/export accessibility settings | Versioned data-only profiles, preview/merge, bounds validation, rollback, no secrets or social data. |

## 5. Display and layout requirements

Propose scale presets of 100%, 125%, 150%, 175%, and 200%, with the final supported range subject to layout testing. The goal is at least 200% text enlargement without loss of essential functionality, not merely a zoomed screenshot of the interface. Operating-system scale and app scale must be handled deliberately, including mixed-scale displays.

Reflow account strips, toolbars, confirmation buttons, warnings, navigation, lists, and dialogs. Long names must remain recoverable without hover-only disclosure. Preserve exact SDK/Unity version suffixes and target identities. Dense tables can offer an alternate detail/list view; unavoidable horizontal data scrolling is not a substitute for reflowing ordinary forms.

Use measured contrast targets as design inputs: 4.5:1 ordinary text, 3:1 qualifying large text, and 3:1 for relevant control/state graphics against adjacent colors, with the cited standards' scope and exceptions. High contrast is not synonymous with maximum brightness. Offer a strong text preset and a readable lower-glare theme without making medical claims or promising one palette fits everyone.

Test normal, hover, selected, focused, disabled, error, warning, stale, and unavailable states. Keep disabled-control explanations accessible through nearby readable text or an accessible explanation action.

## 6. Input, focus, and action safety

Every essential task needs a non-pointer path. No essential action may require double-clicking, dragging, hovering, a long press, precise slider placement, or simultaneous multi-key/button input without a practical alternative.

Use standard Tab/Shift+Tab traversal between controls and arrow-key traversal inside appropriate lists. Provide discoverable region navigation through the existing shortcut system. Keep focused rows and selected identities stable as social data arrives. Closing a dialog returns focus to its initiating control or a clear safe substitute if that control no longer exists.

Distinguish focus, selection, and the default action. Enter in captions/search must not send an invitation or delete a photo. Preserve scoped Enter/keypad Enter behavior in sign-in and verification; respect text composition. Repeated activation must not duplicate commands.

Provide numeric inputs, increment/decrement controls, and reset alongside sliders. Photo crop/redaction controls need keyboard-adjustable regions and explicit coordinate/size controls rather than pointer-only editing. Shared command guards, not input timing, enforce action safety.

Hotkey remapping must expose local/global scope, collisions, unavailable bindings, and an accessible reset path. Recording a shortcut must never execute it. Global bindings are opt-in and must not silently override the game, operating-system accessibility shortcuts, or text entry. Use existing action dispatch; do not create a second mechanism for sending game commands.

## 7. Screen readers and accessible semantics

Test real controls in the exact shipped Tk/runtime combination before declaring support. A tooltip, a string called 'accessible_name', or a text-to-speech button does not establish operating-system accessibility-tree integration.

Early assessment targets: sign-in, top-level navigation, tabs, lists, the account strip, disabled-action explanations, modal dialogs, resource metrics, and photo tiles. Verify names, roles, values, expanded/selected/disabled state, row/column relationships, focus events, validation messages, and status changes.

Prefer existing controls that expose usable native semantics. For an opaque custom control, consider a verified provider adapter or a targeted replacement while reusing the same application services. Do not authorize a wholesale UI rewrite implicitly, and do not claim the current framework is either fully accessible or categorically incapable without testing.

Offer photo grid/list views over the same records. A useful label may describe a title, date, favorite state, source availability, and selected rendition. It must not invent who appears in the scene. Resource graphs need an equivalent metric table/text summary with units, time, freshness, and unavailable states.

Live information must not flood speech. Announce relevant state changes, support read-on-demand summaries, and batch nonurgent updates. Do not read CPU percentages every collection interval or speak every friend refresh.

Privacy policy is applied before accessibility text or application-generated speech is produced. Hidden account aliases, private photos, private destinations, secret notes, credentials, and verification codes must not leak through a secondary presentation path. Password controls retain protected semantics; optional application narration is not permission to read secret values. Purge or invalidate queued private announcements when their context becomes ineligible.

## 8. Alerts, sounds, and notification ownership

Extend the shared notification router and VRCX ownership coordinator. One event can have several user-selected presentations, but they must share an identity and dismissal/review state. Accessibility does not create a new incoming inbox, resource alarm service, or VRCX detector.

Provide visual equivalents for meaningful VRC Eye sounds and optional spoken/tonal equivalents for meaningful visual alerts. Include routing, volume, repetition limits, output selection where supported, and a clearly labeled synthetic test. Never generate a fake live invitation or change game state to test an alert.

Persistent means important information remains reviewable, not that a popup remains on screen forever. Allow dismissal without focus theft; retain a policy-appropriate outcome in the existing activity/inbox workflow. Quiet modes and VRCX ownership are evaluated before producing extra output. A suppressed social event must not be recreated by a separate speech engine.

Application narration should be optional and coordinate with screen-reader use to avoid double speech. A screen-reader option must not suppress a user's only output automatically. Device disconnection should use an explicitly permitted alternative and a visible degraded state, not silently route private speech to speakers.

This scope concerns VRC Eye's own interface and event outputs. It does not promise to caption arbitrary in-game voice, interpret every game sound, or make third-party websites accessible.

## 9. Motion, sensory load, and VR

Provide reduced-motion and reduced-distraction controls for page transitions, animated sorting, thumbnail movement, slideshow effects, confetti, notification motion, and progress decoration. Prefer static progress text and deliberate manual advancement. Do not introduce flashing alerts as the only warning route; disable decorative flashing by default.

Freezing or slowing the visual presentation of live metrics must not stop collection, recovery processing, or meaningful warning state. Show a 'display paused' or snapshot timestamp when appropriate. Resource budgets may defer decorative work, but not remove keyboard navigation, accessible labels, or readable status from the interface.

VR overlay controls should offer left/right/center positioning, supported anchor modes, size, depth/distance, angle, background contrast, opacity, and easy recenter/hide actions. No essential control should require turning far behind the head, reaching above the shoulder, holding both controllers, or standing up. This is a design goal requiring actual hardware/user tests, not a comfort guarantee.

Keep a usable desktop equivalent for every essential overlay action. Haptics, gaze/dwell, controller remapping, and other runtime-specific options remain capability-checked enhancements. They must not become prerequisites or silently arm OSC, request capture, or grant bridge permissions. Do not force users into head-locked motion or a single fixed distance.

## 10. Profiles, persistence, and recovery

Base accessibility preferences should belong to the local operating-system user/installation rather than depend on the selected VRChat account. Apply them before sign-in. The app must not shrink text, remove speech support, or change essential input mappings just because Main changes to Alt.

Account-specific social notification/content policies still belong to their account. Explicit account-specific accessibility overrides may be considered, but must be reviewed and must not unexpectedly remove a needed global control. Privacy rules and supported-capability limits are constraints, not settings a presentation preset can override.

For overlapping presentation choices, use an explainable precedence: explicit user override, selected profile, followed system preference, application default. Platform limitations remain visible. Show where a setting comes from and let the user revert an individual override. Preserve an explicit reduced-motion requirement across component presets rather than silently restoring animation.

Suggested presets: Larger Text, High Contrast, Keyboard-Focused, Large Controls, Reduced Distraction, Quiet Visual Alerts, and Seated/One-Handed VR. These describe behaviors; they are not diagnoses. Presets compose through a previewed set of setting changes and may coexist with Casual/Advanced/Developer views. Developer access remains unrestricted as previously planned; accessibility itself never authorizes sensitive actions.

Add a preview containing a label, button, field, warning, focus example, table row, and synthetic notification. Applying a preset must not require a short timed response. Keep the previous usable presentation and a reachable 'Revert last accessibility change' action. Reset only selected presentation/input settings, not credentials, account records, photo files, or permission grants.

Provide a documented startup recovery entry for an inaccessible configuration, with restored on-screen window bounds and no sign-in requirement. Account database failures should not block recovering basic UI accessibility. Migrate necessary presentation preferences without copying account content into a recovery file. Validate imported settings field by field and retain valid existing values when an import fails.

Imports/exports must be bounded, versioned, data-only, and reviewed. Exclude credentials, tokens, account aliases by default, local file paths where unnecessary, notes, peer identities, queued commands, and permission grants. An imported profile may not enable listeners, install software, launch websites, send invites, or weaken privacy. Hardware-dependent mappings become unassigned or disabled until resolved, not silently mapped to unrelated actions.

## 11. Accessible sign-in and error recovery

Preserve independent remember choices and the existing login/verification command guards. Allow pasting credentials and complete verification codes. Use persistent field labels, accessible password-reveal controls where appropriate, announced validation, and retained nonsecret drafts.

Do not turn accessible authentication into automatic sign-in, token copying, CAPTCHA bypass, extended server expiry, or lower authorization checks. A service-controlled timeout remains a real timeout; show its meaning clearly and permit a new deliberate attempt without discarding unrelated work.

Errors should say what happened, what still works, and the next available action. Distinguish failed resource measurement, unavailable sensor, stale reading, and a real zero. Distinguish unknown invite outcome from rejection. Essential recovery, cancellation, stop controls, and action context remain visible in simplified views.

## 12. Cross-feature integration

| Workspace | Accessibility requirement and reuse boundary |
| --- | --- |
| Social / Accounts | Stable rows, semantic account/recipient labels, readable differences, one shared command pipeline. |
| Invite Me | Account and destination announced before the deliberate action; no automatic join or repeat from an input adaptation. |
| Photos | Keyboard grid/list alternatives, selection state, accessible edit controls, privacy-aware labels/exports; one catalog. |
| Resource Monitor | Equivalent text/table output, units and stale/unavailable states, rate-limited presentation; one telemetry backend. |
| VRCX Companion | Readable detection, ownership, and partial-availability states; one detector/coordinator. |
| SDK/VCC Download | Exact versions and compatibility meanings accessible as text; progress/cancel reachable; one downloader. |
| Useful Links | Preserve the requested visible labels; expose destination and external-browser meaning without hover-only discovery. |
| Wellness / Safety | Reuse event routing and existing reviewed actions; accessibility presets never toggle monitoring or remote actions implicitly. |
| Creator / Developer | Same accessible primitives and settings; advanced complexity does not excuse inaccessible controls. |

## 13. Acceptance tests and evidence

These are required future tests, NOT passing results from this review.

| Scenario | Required outcome |
| --- | --- |
| First launch without mouse | Accessibility and local navigation usable before connection. |
| Text enlarged to 200% | Account, target, warnings, and dialog actions remain available; ordinary forms reflow. |
| Mixed-scale displays or removed monitor | Window remains reachable and focus remains visible; supported scaling behaves consistently. |
| High-contrast light/dark/system theme | Interactive and meaningful non-text states remain distinguishable; no color-only status. |
| Keyboard-only sign-in and verification | Paste and scoped Enter work; focus and errors are exposed; duplicate submissions prevented. |
| Live friend update while navigating | Focus and intended recipient are preserved. |
| Photo arrival while selecting | Selection and grid/list focus are stable. |
| Screen-reader navigation | Actual platform tree provides the required control semantics and task completion. |
| Screen reader with live telemetry | Meaningful summaries; no continuous announcement flood; unknown never read as zero. |
| Streamer/guest/account switch | Visual, accessible, queued speech, and notification content follow the same privacy scope. |
| VRCX owns a notification | No duplicate VRC Eye spoken/toast event; internal state still updates. |
| Audio device or VR controller lost | A permitted usable alternative remains available; no unapproved private-output reroute. |
| Reduced motion and low-overhead mode | Essential data, navigation, accessible states, and warnings remain functional. |
| Hotkey conflict or malformed import | No unwanted action, no silent overwrite, no permission/network changes. |
| Excessive scale or unusable layout | Recovery restores a usable presentation without deleting app data. |
| Profile changed during an action review | Account/target/operation bindings remain intact; no new command dispatched. |

Proposed platform matrix: Windows with keyboard, Narrator, NVDA, contrast themes, text/display scaling and voice-control interactions; supported Linux environments with keyboard, Orca/AT-SPI as an explicit verification target; supported VR runtime/headset/controller combinations with desktop fallback. These are test targets, not compatibility claims. Record app, OS, Tk/toolkit, assistive-technology, and runtime versions for results. Invite task-based testing with people who use the relevant assistive technologies; a settings screenshot is not task completion evidence.

## 14. Delivery order

First, assess real accessibility-tree support and critical sign-in/navigation tasks. Second, extend shared preferences, typography, layout, focus, recovery, and privacy-aware semantics. Third, retrofit essential existing tasks and ensure new Social/Photos/download controls use those components from their first implementation. Fourth, add coordinated audio/visual outputs and validated profiles/imports. Fifth, verify supported VR adaptations and run cross-platform task-based acceptance tests.

This order does not remove anything from the plan. It makes accessibility a dependency of interface expansion rather than a final cosmetic pass.

## 15. External guidance consulted

External references were consulted for design and verification criteria; they are not evidence that VRC Eye already complies. WCAG2ICT is informative guidance for non-web software, not a product certificate or a substitute for platform testing. Numeric web targets need deliberate interpretation for desktop and VR controls.

- W3C WCAG2ICT: https://www.w3.org/TR/wcag2ict-22/
- W3C Contrast (Minimum): https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html
- W3C Non-text Contrast: https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html
- W3C Resize Text: https://www.w3.org/WAI/WCAG22/Understanding/resize-text.html
- W3C Accessible Authentication (Minimum): https://www.w3.org/WAI/WCAG22/Understanding/accessible-authentication-minimum.html
- W3C XR Accessibility User Requirements: https://www.w3.org/TR/xaur/
- Microsoft UI Automation Providers Overview: https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-providersoverview
- Microsoft Accessibility Testing: https://learn.microsoft.com/en-us/windows/apps/design/accessibility/accessibility-testing

## 16. Review boundary

The only artifact produced for this review is this Markdown planning document. No application source, saved preferences, credentials, database, installed dependency, or runtime state was changed. No screen-reader, UI, VR, or application test was run. The source archive hash was checked again after writing this document and matched the baseline.
