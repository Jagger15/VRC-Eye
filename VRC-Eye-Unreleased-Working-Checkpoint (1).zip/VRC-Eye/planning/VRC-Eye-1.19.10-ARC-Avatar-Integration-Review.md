# VRC Eye 1.19.10 — ARC avatar feature integration review

**Date:** October 2, 2026  
**Status:** Inspected and added to next-build planning. No application implementation or release build performed. Existing build hold remains in effect.

## Decision

Bring the useful avatar-management and authorized creator-workflow capabilities into VRC Eye's existing avatar workspace. Prefer VRC Eye-native implementations for catalog, filtering, records, queues, and accessible presentation. Treat Unity-side repair, recovery, and actual-model rendering as separately reviewed capabilities, not as permission to copy the uploaded application or promise every feature works.

The user requested feature integration, including stronger avatar tooling. This review establishes a concrete integration direction; it is not a completed integration, a security certification, or a promise of complete ARC feature parity in 1.19.10.

## 1. Inspection boundary and identity

The supplied `Release.zip` was inspected as data. The review read ZIP inventories, selected nested archives and text files, readable executable strings/symbol names, and selected VRC Eye source files. No uploaded executable, DLL, Unity project, or asset was run or imported. No third-party analysis dependencies were installed. No ARC or VRChat authentication was performed; no avatar, cache record, or credential was sent to an external service. Public documentation was consulted separately.

| Item | Static observation |
| --- | --- |
| Uploaded archive | `Release.zip`, 142,761,540 bytes; 66 outer entries, including directory entries. |
| Archive SHA-256 | `201e3a64597c0c5b5b0032e61699c9292abdaa706b4a0f386f2f0e076e40d199` |
| Main application | `ARC.exe`; readable application-title strings identify Avatar Recovery Client (A.R.C). Embedded version fields read `1.41.3.112`. This is an embedded version, not a verified release provenance. |
| Main library | `CoreSystem.dll`, embedded version `1.0.4.0`. |
| Declared runtime | Both application configuration files target `.NETFramework,Version=v4.8.1`. |
| Main application source | No ARC solution/project source appears in the outer release. Debug symbol files are present, but they are not a complete source project. |
| Nested Unity project | `Assets/ARC2026.zip`: 2,030 entries, including Unity editor source and package files. |
| Nested recovery tool | `Assets/AssetRipper.zip`: 31 entries, including `AssetRipper.exe` and dependency notices. |
| Nested viewer | `Assets/NewestViewer.zip`: 20 entries, including `AssetViewer.exe`, Unity runtime files, and `AssetViewer_Data`. |

The nested Unity project declares editor `2022.3.22f1`, FACS Utilities `25.5.27` with `OSL-3.0`, and VRChat Base/Avatars package version `3.10.2`. These are archive declarations, not verification of package integrity, an unmodified official SDK, or a complete compatible dependency set.

The editor declaration matches the currently retrieved VRChat editor guidance, but that does not establish that the bundled standalone viewer is patched, safe, or compatible. The official guidance explicitly distinguishes creating VRChat content from shipping standalone Unity applications. [R5]

### Evidence levels

**Observed file/configuration:** a member or declared value is present. **Source-inspected:** selected source text contains a relevant implementation or editor control. **Symbol/UI evidence:** a compiled binary contains a named operation, field, or interface string. The last category does not establish that the operation is reachable, enabled, permitted, or working today. This review did not reconstruct complete compiled control flow.

## 2. Existing VRC Eye foundations to retain

Baseline: `VRC-Eye-v1.19.9.zip`, SHA-256 `dbdd0ed01a0d4e8aac42edc12bc4debc2f4f61007037d367ab5f7846e5adac07`. It was materialized for read-only archive inspection, not changed.

| Existing component | Source observation | Integration consequence |
| --- | --- | --- |
| Avatar search | `avatar_search.py:6–53` provides bounded results, upload/favorite/featured/VRCX scopes, source and checked-time fields, literal filtering, and ID-based merging. | Extend the shared search model rather than add an unrelated ARC browser. Do not describe local filtering as unrestricted remote search. |
| Creator workspace | `AVATAR_CREATOR_SETUP.md:3–21` describes nine existing tabs: Creator, Modules, Avatar Link, Parameters, Preview, Tests, Diagnostics, Profiles, History. | Add library/build/shader views through this workspace and planned My Avatars entry points; preserve one underlying record system. |
| Creator records | `avatar_creator_store.py:212–300` includes bounded records, filtered listing, local search, and run snapshots. | Extend with explicit record kinds and reviewed migrations where needed. Existing storage alone does not prove the new multi-account model is complete. |
| Build metadata and transfer | `vrca_files.py:35–58,90–130,145–180,216–281` includes platform/build choices, bounded transfers, digests, cancellation, and no-overwrite copying. | Build an inventory/history around these existing primitives rather than import ARC's downloader or lower transfer safeguards. Access permission remains separate from URL validity. |
| Cache matching | `vrca_cache.py:64–268` contains source resolution, target matching, scanning, save operations, and guards. | Reuse reviewed local-file evidence where applicable; a cache match is neither ownership proof nor authorization to publish or export an asset. |
| Desktop preview | `avatar_creator_ui.py:516–528` explicitly uses a generic mannequin and creator-manifest hierarchy. | A real-model viewer is additional work. Do not relabel the mannequin or a thumbnail as an actual avatar rendering. |
| Source preview/export | `Unity/AvatarToolkit/README.md:54–64` describes sanitized source manifests and separately reviewed static source-preview exports. | Preserve static/mannequin fallbacks and extend the optional existing Unity package, not a second toolkit. |
| Existing journals | `Unity/AvatarToolkit/README.md:44–52` documents original-reference preservation and change-aware installation removal. | Use this recovery approach for reviewed creator edits; ordinary Undo is not a substitute for asset-file backups. |

These are source/document observations. No baseline runtime tests were run in this review.

## 3. Feature-by-feature integration map

The rows below are planned VRC Eye behavior. Added details such as stronger privacy, cancellation, and accessibility are VRC Eye requirements, not claims that ARC implements them.

| Feature area | Evidence in the supplied package | VRC Eye integration decision |
| --- | --- | --- |
| Rich avatar catalog | Main executable search controls; `AvatarSearch`, avatar-grid, database-count, and favorite-related symbols. | **Native priority:** one searchable library with grid/list views, stable avatar IDs, source and freshness, explicit account scope, thumbnails, and links to existing creator records. |
| More useful filtering | Name/ID/description and platform fields; public/private and PC/Quest search-model symbols. | **Native priority:** combine name, avatar ID, author/author ID where supplied, platform, date, local-file availability, ownership evidence, and favorites. Missing data stays unknown; local filters never imply the server supports the same search. |
| Detailed avatar information | `Avatar_Info` resources and avatar description, PC/Quest asset, and Unity-version labels. | **Native priority:** unify details with creator notes and selected-account context; distinguish avatar identity from file/build identity and source project identity. Hide private endpoints from ordinary exports. |
| Build/version browser | Version-picker resources and a version/Unity/date display format. | **Native priority:** compare available builds by platform, revision, Unity version, date, and local status. Historical entries may be incomplete; do not promise a complete server archive or unlimited retention. |
| Local download/build inventory | `DownloadHistoryManager`, `DownloadRecord`, download-grid columns, missing-entry cleanup and open-folder controls. | **Native priority:** persistent per-account records for authorized acquisitions and local imports; record digest, size, outcome, source, and current file availability. Removing an inventory entry must be separate from deleting its file. |
| Managed jobs | Progress, cancellation-related components, and download completion/error strings. | **Native priority:** shared bounded job handling, accurate progress, deliberate retry, cancellation, destination checks, and partial-failure results. Resume is supported only where the source and integrity checks permit it. |
| Image browsing | `Preview Image`, avatar-preview resources, and image-location helpers. | **Native priority:** lazy, bounded thumbnails and full-image previews with readable descriptions, zoom/reset controls, and privacy-scoped caches. |
| Actual-model preview | `PreviewVRCA`/viewer-launch symbols and the nested standalone viewer. | **Conditional:** creator-authorized actual-model review through a reviewed Unity export or separately isolated viewer. Validate file/runtime compatibility and supply a static fallback. Do not load arbitrary avatar scripts in VRC Eye. |
| Shader-package inventory | Shader import/remove controls; shader installation/hash/count symbols. | **Native catalog priority:** selected package inventory, source/version/hash, duplicate detection, and read-only package inspection. Selecting a package for inspection must not import its scripts into Unity. |
| Material/shader inspection | Source files `MaterialList.cs` and `EasyShaderReassign.cs` with editor menu entries. | **Conditional Unity capability:** material usage and missing/incompatible shader reports; explicit per-material remapping with preview, backup, and recheck. No blanket replacement of every shader. |
| Bounds and mesh diagnostics | Source files `BetterBounds.cs`, `CopyMeshSettings.cs`, and `SkinnedMeshOptimizer.cs`. | **Conditional Unity capability:** inspect selected owned/authorized source objects and offer reviewed bounds/mesh operations. Record what changed and compare results; do not promise better frame rate from an edit alone. |
| Animation and component diagnostics | Source files `FixAnimations.cs`, `AnimationSwap.cs`, `ComponentDependencies.cs`, `ComponentHierarchy.cs`, `CopyComponents.cs`, and missing-script utilities. | **Conditional Unity capability:** read-only findings first, then narrowly reviewed repairs in an authorized project copy. Never remove missing components indiscriminately or fabricate unavailable animation data. |
| Project/editor handoff | Unity-location controls and the nested project/template. | **Native orchestration priority:** associate a source project with the avatar record, report exact versions, and offer an explicit open-in-editor action. Reuse shared SDK/VCC dependency planning; do not silently import the bundled project. |
| Recoverable package/export workflow | Extraction, compression, package-related symbols and the nested recovery tool. | **Conditional creator recovery:** user-authorized local backup/conversion into a new destination, with known-loss and unsupported-state reporting. A recovered bundle is not guaranteed to reproduce its original editable project. |
| Local gallery/report export | HTML viewer filename resources; the public ARC README also describes an HTML browser. | **Native extension:** selected data-only reports and optional offline gallery output, with HTML escaping, reviewed images, no hidden remote fetches, and account/privacy filtering. |
| Avatar selection | A change-avatar context action and selection symbols. | **Capability-dependent:** reuse VRC Eye's shared reviewed account-action mechanism where available and appropriate. Viewing an avatar never changes the worn avatar automatically. |
| External tool state | Bundled utilities and corresponding location/progress controls. | **Conditional adapter work:** explicit provider selection, verified identity/version, finite operations, honest missing/unsupported/failure states, and controlled child-process lifetime. No generic execute-any-DLL feature. |

### Features not carried over wholesale

The binaries include named cache-reporting/upload operations and external-service references. That is enough to require a data-flow review before reuse; it is **not** evidence that the supplied program always uploads the cache or is malicious. VRC Eye will not inherit those behaviors simply by enabling avatar tools.

Do not copy ARC authentication, transfer VRChat credentials/cookies into ARC, make an ARC server/API key a core dependency, automatically publish local avatar records, or treat access to a cached/private asset as permission to redistribute it. Do not introduce hotswap-based upload substitution, unauthorized private-asset retrieval, decryption/access-control bypasses, or content/safety-filter bypasses. Creator recovery remains limited to content the user owns or is authorized to work with.

The main executable also contains a message indicating that an API-download path is disabled. Without executing or tracing that path, this does not establish which controls are disabled now. It does establish why visible controls and method names must not be presented as verified working functionality.

## 4. Licensing, provenance, and platform findings

### ARC itself

A public ARC/SARS repository was found. Its README permits reading/learning/debugging but restricts redistribution, including modified variants, without developer permission. The repository is archived and has not been established as the exact source of this uploaded build. No independent redistribution grant for this exact ARC release was established. [R1]

**Decision:** do not copy ARC executable/library code into VRC Eye or redistribute its binaries under an assumed open-source license. Independently implement generic workflows and behavior, without copying proprietary implementation or branding. Permission and exact-version provenance would be prerequisites for direct reuse. This review is not a legal opinion that a particular combined distribution is compliant.

### FACS Utilities

The nested package includes editor source, a package manifest declaring `OSL-3.0`, and an Open Software License 3.0 text. The upstream repository also identifies that license and supports VPM distribution. [R2]

**Decision:** this is a possible reviewed integration target, not an automatic permission to strip license notices or merge code under unrelated terms. A user-selected existing installation, a documented integration point, or an independent implementation of selected operations should be evaluated before redistributing a derived package. Exact component terms and compatibility remain release-review items.

### AssetRipper and the viewer

Current upstream AssetRipper identifies GPL-3.0 licensing, but the exact revision/provenance of the bundled executable was not established. Its nested archive contains dependency notices; those alone do not settle all redistribution requirements. [R3] The standalone viewer likewise remains unverified for provenance, security, protocol, and runtime behavior.

**Decision:** neither executable is bundled or launched by this change. Any eventual adapter requires an exact-version review and explicit user initiation. Running a helper in a separate process does not by itself settle licensing or sandbox security.

### Windows and Linux

ARC's configuration targets .NET Framework 4.8.1; Microsoft describes .NET Framework as Windows-only. [R4] That is a real packaging mismatch with VRC Eye's cross-platform Python/Tk foundations, not proof that every generic feature is unportable.

**Decision:** native catalog and records should remain independent of ARC. A Windows-only helper must show a clear unavailable state elsewhere; Wine/Proton operation would be unverified rather than promised. Missing Unity/viewer support must not block local browsing.

### VRChat actions

VRChat's currently published Creator Guidelines describe unsupported/public-API limitations, credential handling restrictions, and restrictions on third-party content uploading on users' behalf. A working endpoint or an owned avatar does not independently establish platform approval. [R6]

**Decision:** retain the project's separate authentication/distribution review. This avatar enhancement does not introduce another login system or an automatic third-party uploader. Source editing, preparation, and diagnostics remain distinct from user-controlled publishing through the appropriate SDK workflow.

## 5. Navigation and service integration

Use **Primary → Avatars** as the existing working area. The planned My Avatars account workspace should provide another view of the same authorized records, not a second catalog. Candidate internal views are Library, Details/Builds, Local Files, Preview, and Creator Tools. Place material/shader and repair controls inside the existing creator structure; final tab grouping can be resolved during implementation without removing existing tools.

The shared Social/Accounts identity rules bind every operation to its acting account and selected avatar/build. A queued job must not switch accounts because the visible dashboard changes. Creator-project edits use a separate approved source-project context.

Reuse existing avatar records and extend their schema deliberately. Reuse resource monitoring for heavy preview/scan budgets, existing notifications for job results, the VRCX coordinator for allowed exchange/handoff, and existing creator history/journals for changes. Do not add duplicate telemetry collectors, notification publishers, private VRCX database writers, or an ARC-specific background scanner.

Store provider capability and freshness separately from content availability. An installed viewer does not prove it can open a selected build. A file path does not prove the file still exists or is unchanged. A public avatar listing does not guarantee file-download or editing rights.

## 6. Accessibility requirements

The newly approved 37-section accessibility specification applies to these additions from their first implementation. Provide keyboard grid/list navigation, stable focus when results update, names and roles through the actual accessibility interface, non-color-only file/build state, and large-text reflow.

Preview must have a keyboard-operable alternative and a meaningful textual summary. Busy jobs require reachable Cancel and reviewable outcomes without focus theft. Shader mapping needs searchable lists and explicit buttons rather than drag-and-drop only. Confirmation must retain the exact avatar, build, account, source, and destination.

Live scan/progress information must not flood speech. Hidden thumbnails, private file paths, avatar notes, and account aliases must remain hidden in accessible labels and queued announcements as well as on screen. Reduced-motion settings must not stop essential jobs or erase their results.

## 7. Delivery and release checks

**First: native catalog work.** Extend search/details, platform/build records, local-file inventory, existing transfer history, and accessible browsing. These are the most direct additions because they reuse VRC Eye's current services and do not require ARC binaries.

**Second: read-only creator inspection.** Add selected package/material/dependency reports and project association. Preserve source-versus-build identity and do not run imported code merely to catalog a package.

**Third: conditional advanced tools.** Actual-model preview, Unity repair operations, and authorized recovery need exact provider/version/licensing decisions, protected originals, explicit action review, and native Unity/Windows/Linux testing where claimed. They remain qualified scope rather than guaranteed complete 1.19.10 parity.

Acceptance cases must cover duplicate names with different IDs; identical files linked to different records; sparse historical build data; account changes during jobs; cancelled/retried transfers; destination collisions; malformed or oversized packages; directory traversal/link entries; disconnected drives; unsupported viewer inputs; shader-license/dependency failures; edits made since a repair preview; rollback after partial failure; and privacy filtering in exports and accessibility output.

Test that local catalog use makes no unrequested ARC-service calls. Test that opening a view does not launch Unity, run a helper, select an avatar, send OSC, or upload data. Treat each provider's consent, output validation, resource limit, and failure behavior as a separate acceptance requirement.

Release notes must separate **implemented**, **tested**, **conditional**, and **deferred**. No Windows, Unity, screen-reader, model-preview, or live VRChat success is claimed by this review.

## References

External pages were retrieved on October 2, 2026. Their claims do not establish the provenance of the uploaded binaries.

- **R1:** [ARC/SARS project README, feature description and redistribution terms](https://github.com/Dean2k/SARS).
- **R2:** [FACS Utilities project, OSL-3.0 identification and VPM support](https://github.com/FACS01-01/FACS_Utilities).
- **R3:** [AssetRipper project and GPL-3.0 identification](https://github.com/AssetRipper/AssetRipper).
- **R4:** [Microsoft .NET Framework overview/downloads, Windows-only platform description](https://dotnet.microsoft.com/en-us/download/dotnet-framework).
- **R5:** [VRChat current Unity editor guidance and standalone-application distinction](https://creators.vrchat.com/sdk/upgrade/current-unity-version/).
- **R6:** [VRChat Creator Guidelines, API Usage / Bots](https://hello.vrchat.com/creator-guidelines).

## Final state

Only this review and temporary inspection records were created. The supplied archive and VRC Eye 1.19.9 baseline remained unchanged. No ARC binaries or utility source were copied into the application. No application build, runtime test, dependency installation, SDK import, account action, or avatar transfer was performed.
