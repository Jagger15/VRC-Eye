# VRC Eye — Expanded Social / Account Features Specification

I would turn this into a complete **Social & Accounts workspace**, rather than a collection of unrelated buttons. It should handle everyday social activity, creator-owned content, multiple account contexts, privacy, and the less obvious situations where an action succeeds but the interface cannot yet prove what happened.

Two details from the existing project matter here. Your **1.19.9 guide documents independent “Remember username” and “Remember password” settings, but only one remembered pair—not a multi-account system**. It also documents Enter/keypad Enter support without automatic sign-in merely from opening the connection window. Those behaviors should survive this expansion rather than being accidentally replaced.    VRC-Eye-1.19.9-Login-Guide

There is also a distribution issue to keep separate from feature design: VRChat’s published guidelines restrict collecting credentials/session information, identify the web API as unsupported for public use, require responsible request handling, and prohibit third-party software uploading avatars/worlds on users’ behalf. Therefore, neither encrypted credential storage nor a working endpoint should be presented as platform approval. The public-release authentication path remains a review dependency. [VRChat](https://hello.vrchat.com/creator-guidelines)

Everything below is a **proposed specification and acceptance standard**, not a claim that these changes are already implemented.

---

# Part I — The structure everything else depends on

## 1. Organize the workspace around what the user is doing

I would use four primary areas, with deeper tools appearing according to your existing Casual, Advanced, and Developer views.

| Area           | Main pages                                                                      | Purpose                                                                           |
| -------------- | ------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| **Social**     | Dashboard, Friends, Inbox, Invites, Groups, Recently Met                        | Everyday interaction.                                                             |
| **My Account** | Profile, Status, Favorites, Privacy, Security                                   | Managing the selected account’s own information and preferences.                  |
| **My Avatars** | Library, Details, Metadata Drafts, Build Overview, Change History               | Organizing avatars and editing records the account is actually permitted to edit. |
| **Accounts**   | Account Switcher, Active VRC Eye Logins, Account Settings, Storage, Diagnostics | Managing identities, sessions, isolation, and account-specific behavior.          |

The same underlying services should power every view. Advanced mode should reveal additional information; it should not create a second account implementation with different behavior.

**Casual view** should prioritize understandable actions: “Invite,” “Open profile,” “Edit my avatar,” “Switch account,” and “Pause notifications.”

**Advanced view** should expose account ownership, freshness, source information, pending actions, privacy details, and troubleshooting.

**Developer view** should expose normalized records, supported operation definitions, account/environment context, request lifecycle information, and sanitized diagnostics. It should remain accessible under your current development approach, but entering Developer view should not silently activate writes or weaken account isolation.

### The permanent account strip

A small account strip should remain visible throughout all four areas.

It should show the selected account’s local label, current display name, connection state, and whether the running VRChat client appears to use the same account.

For example:

> **Viewing: Main — ExampleName**\
> VRC Eye connection: Available\
> Running VRChat account: Creator — Different account

This strip is not decoration. It is part of the action-safety system.

A user should not have to remember which account they selected several minutes ago before clicking a button with an external effect.

---

## 2. Establish four identities instead of one ambiguous “current account”

The application needs to distinguish four concepts.

**Viewing account** means the account whose dashboard, inbox, avatars, and settings the user is currently examining.

**Acting account** means the authenticated identity that will perform a particular operation.

**Running-game account** means the account VRC Eye has evidence is currently being used by the local VRChat client.

**Local workspace identity** means VRC Eye’s own account record, containing local labels, settings, saved layouts, and other organization.

These often match. They must not be assumed to match.

An avatar-editing draft might belong to the Creator account while the user is playing VRChat on Main. A notification might arrive for Alt while Main is visible. A browser opened from VRC Eye might already be signed into yet another account.

The application should handle those situations deliberately.

### Bind actions when they are created

An action must record its acting account when the user begins it.

It must not resolve “whatever account is currently selected” at the last moment.

For example, opening an invitation composer under Main should create a Main-owned draft. Switching the dashboard to Alt must not convert that draft into an invitation from Alt.

The composer should either remain explicitly attached to Main or become paused until the user returns to Main.

### Treat identity evidence as evidence

The running-game account indicator should include a source and observation time.

“Detected from the current local session, 20 seconds ago” is more useful than a permanently green “Matched” icon.

When identity cannot be established, the state should be **Unknown**, not a guessed match based on a similar display name.

---

# Part II — Friends and everyday social activity

## 3. Friends/social dashboard

The dashboard should answer three practical questions:

**Who is available? What needs my attention? What can I do from this account?**

It should not try to answer those questions with one giant unsorted friend list.

### Dashboard sections

The main page should have compact sections for available friends, pending social requests, recent invitations, pinned people, and relevant group activity.

Each section should be independently collapsible and remember its arrangement per account.

A creator account could prioritize group activity and playtest contacts. A casual account could prioritize pinned friends and invitations. That is a layout preference, not an automatic assumption about how the account should behave.

### Friend rows need separate kinds of state

A friend row should distinguish:

| Dimension               | Example values                                                       |
| ----------------------- | -------------------------------------------------------------------- |
| **Relationship**        | Friend, Incoming request, Outgoing request, Not friends, Unknown     |
| **Presence**            | In VRChat, On website, Offline, Unknown                              |
| **Social preference**   | Join Me, Online, Ask Me, Do Not Disturb                              |
| **Location visibility** | Visible, Private, Unavailable, Previously observed                   |
| **Action availability** | Join available, Request invite available, Unavailable, Needs refresh |

VRChat itself distinguishes social status from presence and uses status to influence location visibility, joining, and notifications. VRC Eye should preserve those distinctions rather than compressing everything into “online/offline.” [VRChat Wiki](https://wiki.vrchat.com/wiki/Social)

A person can be online without their location being visible. A location can be visible without a successful join being guaranteed. A cached online observation is not proof that the person is still online.

### The minimum useful friend card

Each card should include the current display name, profile image when permitted, local nickname when configured, relationship state, status text, permitted location summary, and observation age.

The local nickname should not replace the real display name entirely. A layout such as:

> **Painting Friend**\
> Current VRChat name: ExampleName

avoids turning a personal nickname into an identity claim.

Advanced view can reveal the stable user identifier, source account, source provider, and freshness information.

### Sorting without accidental clicks

Useful sorts include alphabetical, pinned first, available to join, recently interacted with locally, and recently updated.

However, the list should not continuously rearrange beneath the pointer.

When a user is hovering over an Invite button, a presence update must not move a different friend into that button’s position.

A stable interaction window should temporarily preserve row positions while the user is navigating, selecting, or opening a context menu.

### Filters and saved views

Filters should cover relationship, presence, social preference, local labels, shared groups where available, and whether an action can currently be attempted.

Saved views could include “Playtest contacts,” “Pinned friends,” and “People I met recently.”

These should be **local filters**, not additional server-side categories unless the user explicitly chooses a synchronization feature.

### Honest counts

The dashboard should distinguish:

> 47 friends currently loaded.

from:

> 47 total friends.

A partially fetched list must not produce an authoritative total. A filtered view should say how many matching records are visible and whether the underlying dataset is complete.

### Loading, failure, and empty states

An empty list can mean no friends, no matching filters, no authenticated connection, an incomplete refresh, or an error.

Those require different messages.

VRChat’s own support guidance notes that an apparently missing friends list can result from service issues, account mix-ups, or connection problems. Therefore, VRC Eye should not respond to a failed refresh by declaring that everybody has been removed. [VRChat](https://help.vrchat.com/hc/en-us/articles/46059121284755-Friends-list-disappeared-Causes-and-troubleshooting?utm_source=chatgpt.com)

A failed refresh should preserve the last permitted snapshot, visibly mark it as stale, and offer a controlled refresh—not repeatedly hammer the service.

---

## 4. Friend requests

Friend requests deserve a real workflow, not merely “Accept” and “Decline” buttons attached to notifications.

### Separate incoming and outgoing requests

Incoming requests should show who sent the request, which of your accounts received it, when VRC Eye observed it, and any relevant context that is legitimately available.

Outgoing requests should show the originating account, target identity, submission state, and last confirmed relationship state.

The community-maintained API reference describes separate friend-status and request operations. Those are useful integration references, but the user-facing model should remain independent of the exact endpoint arrangement. [VRChat Community](https://vrchat.community/reference/get-friend-status)

### The request state model

I would use local states such as:

`Unknown → Incoming / Outgoing → Action pending → Relationship verified`

with additional states for rejected operations, stale observations, and uncertain outcomes.

“Action pending” should not instantly turn into “Friend.”

A request submission succeeding only establishes that the submission was accepted at that stage. It does not establish that the other person accepted the relationship.

### Accepting an incoming request

Opening the acceptance control should resolve the exact target user and receiving account.

Before dispatch, the application should check whether the request still appears actionable. Another device may already have accepted or dismissed it.

After dispatch, the application should verify the relationship when the provider supports a suitable read.

Until verification, the interface should say:

> Acceptance submitted. Updating relationship status.

It should not play an unconditional “new friend” animation and silently leave a stale row behind.

### Decline versus hide

These are different actions.

**Hide from this inbox** should be local organization.

**Decline request** should be a remote operation where supported.

The labels must not imply that dismissing a card also changes the service-side request.

Likewise, declining a request should not automatically block the person, erase local notes, or remove them from a local collection.

### Canceling an outgoing request

The application should distinguish “Cancel request” from “Unfriend.”

If the relationship changed while the dialog was open, the original request-cancellation intent should not be silently translated into an unfriend operation.

Instead:

> This request has already become a friendship. Nothing was removed.

That prevents an old dialog from acquiring a stronger meaning.

### Batch handling

Batch local organization is straightforward: label, archive, or hide selected cards.

Batch remote acceptance or rejection should be more deliberate. Any future implementation should operate under one explicitly selected account, show the exact recipients, explain partial completion, and stop on identity or permission changes.

There should be no automatic friend-request campaign, repeated resend loop, or “accept everybody forever” background behavior.

### Useful quality-of-life additions

A request card could offer a private reminder such as “Review later,” a local note, and an “Open full profile” action.

These should help the user decide, not generate a numerical “trustworthiness score” from profile appearance, account age, or shared contacts.

---

## 5. Invites

An invitation is both a social action and a disclosure of a destination. The interface should make both aspects visible.

### Create an invitation composer

The composer should show:

| Field               | Required behavior                                                 |
| ------------------- | ----------------------------------------------------------------- |
| **From**            | The exact acting account.                                         |
| **To**              | The resolved recipient identity.                                  |
| **Destination**     | The selected world and instance, where available.                 |
| **Access context**  | What VRC Eye currently knows about whether inviting is permitted. |
| **Message options** | Only options supported by the current integration.                |
| **Media**           | Optional, supported, and separately reviewed.                     |
| **Result tracking** | Submission and later verification states.                         |

The recipient name should remain visible while choosing a destination. The account label should remain visible while choosing a message.

### Do not assume “my current world”

The phrase “Invite to my world” becomes ambiguous in a multi-account application.

The composer should instead identify the destination source:

> Destination observed from the running VRChat session.

or:

> Destination manually selected from a permitted instance record.

When the running game belongs to a different account, VRC Eye should warn before preparing an invitation based on that session.

### Invitation permission is not inferred from familiarity

Being friends with a person or belonging to the same group does not mean every destination is suitable for every invitation.

VRChat distinguishes multiple instance access models, and its client release notes explicitly describe rejecting invite-request acceptance when the requester cannot be invited to the instance. VRC Eye should use supported permission information and still treat the service as authoritative. [VRChat](https://help.vrchat.com/hc/en-us/articles/28526267258515-Getting-Started-with-VRChat?utm_source=chatgpt.com)

The application should not invent access by manipulating an instance string or assuming that a copied destination bypasses access rules.

### Outgoing result states

The invitation history should distinguish:

**Prepared**, **Not sent**, **Sending**, **Submission acknowledged**, **Rejected**, and **Outcome unknown**.

It should not automatically show **Delivered**, **Read**, or **Joined** without a source that actually establishes those outcomes.

The community invitation reference describes creating an invitation notification; that should not be reinterpreted as a guaranteed read receipt. [VRChat Community](https://vrchat.community/reference/invite-user)

### Incoming invite cards

An incoming card should prominently show the recipient account.

The card should also contain the sender, destination details available to that account, any supported message, observation time, and the status of the invitation.

Media previews should respect platform restrictions and the user’s applicable filtering. Unknown or restricted media should not be displayed merely because a different interface received its URL.

### Joining should be a separate action

Clicking an incoming invite should open its details, not immediately launch or redirect VRChat.

“Join” should be an explicit action after the user can see the destination and account context.

When the local game is using a different account, the application should explain that accepting an invitation for Main does not necessarily authorize Alt to use it.

### Expiry handling

Use a service-provided expiry when one exists.

When expiry is not available, display the age of the invitation and explain that validity is not confirmed.

Do not fabricate a countdown from an old assumption and present it as a server guarantee.

### Duplicate prevention

Repeated clicks should create one local command, not several independent submissions.

A timed-out request should not immediately enable a shiny “Try again” button that blindly repeats the operation. The preferred action should be:

> Check whether the invitation was created.

Only when verification cannot resolve the outcome should the user be asked whether to attempt a new invitation.

---

## 6. Invite requests

An invite request is not an invitation and not a generic private message.

The basic meaning is:

> I am asking this person to invite me.

The community reference exposes invite-request behavior separately from sending invitations, reinforcing the need for a distinct workflow. [VRChat Community](https://vrchat.community/reference/request-invite)

### Outgoing invite requests

The request composer should show the requesting account and the target person.

It should not require the application to discover a hidden destination. The point of the request is that the recipient decides whether and where to invite the requester.

The interface should display supported message choices without implying that the system is a replacement for unrestricted messaging.

### Pending-request visibility

The account’s Social page should show recent outgoing requests with a clear distinction between:

> Request submitted.

and:

> Invitation received in response.

No response should remain no response. It should not be labeled “Ignored,” “Rejected,” or “They do not want you there.”

Those interpretations are not established by silence.

### Handling an incoming request

The recipient should see which account received it, who is requesting, and which destination would be used if an invitation is sent.

The destination must be reviewed at response time.

A request received while in one instance should not later be accepted using that old instance simply because the user moved elsewhere.

### Respecting social preferences

VRC Eye should not use a separate notification channel to undermine the user’s chosen quiet mode.

The official social documentation describes Do Not Disturb as suppressing or changing several kinds of social notifications. VRC Eye’s own notification policy should be explicitly coordinated with that preference rather than treating API access as permission to bypass it. [VRChat Wiki](https://wiki.vrchat.com/wiki/Social)

### Anti-nag behavior

A person’s lack of response should not start a retry schedule.

The app can remind the requesting user locally that a request is pending, but should not repeatedly contact the recipient.

A useful optional control would be:

> Do not offer another request to this person until I dismiss the previous one locally.

This is interface friction against accidental repetition, not a claim about an official service cooldown.

---

## 7. Group invites

Group membership invitations and invitations to group instances should be separate throughout the UI.

**Join this group** changes membership.

**Join this group’s instance** concerns a particular session.

A user should never discover after clicking a generic “Accept” button that they joined an organization rather than a world instance.

### Incoming group-membership invitations

The card should show the group name, stable group identity, inviter where available, receiving account, group description, and membership implications available from the platform.

Opening the group’s details should not automatically accept the invitation.

The acceptance button should say:

> Join group as Creator.

rather than simply:

> Accept.

### Permission-aware outgoing invitations

VRChat groups have role-based permissions, including a permission governing group invites and join-request handling. Membership alone is not the same as management permission. [VRChat Wiki](https://wiki.vrchat.com/wiki/Groups)

VRC Eye should resolve the acting account’s effective permissions before displaying an enabled invitation control.

A local label such as “My moderator account” must never be used as proof of an actual group role.

### Permission changes during a workflow

Suppose a group manager opens an invite dialog, then loses the relevant role.

The final submission must be evaluated under the current account context and current supported permission information.

A cached permission should never become an indefinite authorization token inside VRC Eye.

If the server rejects the action, the app should show the rejection and refresh the permission summary instead of retrying under another account.

### Membership visibility

Joining a group, representing it, and choosing whether affiliation is displayed are separate concepts. VRChat exposes membership-visibility and representation controls with different meanings. [VRChat Wiki](https://wiki.vrchat.com/wiki/Groups)

The invitation flow should therefore avoid automatically representing the group or changing visibility after acceptance.

A post-join panel may explain available choices, but those should remain separate actions.

### Join requests and approvals

For accounts with appropriate authority, a group request inbox could provide review, profile opening, acceptance, rejection, and local notes.

The review screen should identify the account and group at all times.

A bulk review mode should clearly report per-request outcomes. It should never pretend that a set of independent operations completed atomically.

### Additional useful group features

Add a “My roles here” panel, a membership status inspector, a record of invitations sent through VRC Eye, and a permission-change indicator.

These belong in Social/Groups. Deep moderation and creator operations can link to their dedicated workspaces instead of being duplicated here.

---

## 8. User profiles

Profiles should combine permitted VRChat information with clearly labeled local organization.

They should never blend the two so thoroughly that a private nickname or note looks like something the other person published.

### Profile layout

I would divide the profile into **Overview**, **Relationship**, **Shared Context**, **Local Notes**, and **Actions**.

Overview should display the current profile fields actually available to the selected account.

Relationship should show the friendship state and pending requests.

Shared Context should contain permitted shared groups, mutual information when supported, and locally observed encounters that the user chose to retain.

Local Notes should remain unmistakably local.

### Profile fields

VRChat’s profile documentation includes fields such as status, bio, pronouns, languages, social links, badges, and groups. VRC Eye should display only fields it receives legitimately, preserve their source, and avoid guessing missing information. [VRChat Wiki](https://wiki.vrchat.com/wiki/Social)

A missing language field should not become “English.”

A missing pronoun field should not trigger a guess from the avatar.

A hidden group list should not be reconstructed from another account’s view.

### Stable identity versus display identity

The stable user identifier should be the internal key.

Display names and local nicknames should be attributes.

Changing a display name should not create a second local profile, sever notes, or transfer notes to another person with the old name.

### Profile links

Links should be displayed as external destinations, not silently opened or fetched.

The application should preview the destination host and warn before leaving VRC Eye where appropriate.

Profile text must be treated as untrusted text. It should not become executable markup, shell commands, or embedded application instructions.

### “What am I seeing?” explanation

Advanced view should explain why some fields are absent.

Useful states include:

> Not supplied by this provider.

> Not visible to this account.

> Not fetched yet.

> Previously observed; currently unconfirmed.

Those explanations are more useful than one generic “N/A.”

### Avoid a surveillance profile

Do not add hidden-location reconstruction, inferred alternate accounts, “who blocked me,” speculative relationship analysis, or a timeline of a person’s activity collected from every account.

A profile should help the user interact with someone, not turn uncertain observations into a dossier.

---

# Part III — My Avatars and creator-owned records

## 9. My Avatars manager

The first requirement is to stop treating every avatar associated with an account as the same kind of possession.

### Separate the library into meaningful collections

I would distinguish:

| Collection                    | Meaning                                                               |
| ----------------------------- | --------------------------------------------------------------------- |
| **My uploads**                | Avatar records uploaded under the selected account.                   |
| **Licensed/purchased access** | Avatars the account may use through a license or product entitlement. |
| **Favorites**                 | Avatars saved through supported favorite mechanisms.                  |
| **Local bookmarks**           | VRC Eye-only references.                                              |
| **Local projects**            | User-linked source projects, without implying remote ownership.       |

VRChat’s creator documentation distinguishes uploaded avatars from avatar products that grant buyers access. Those are different relationships to an avatar record. [VRChat Creators](https://creators.vrchat.com/economy/products/avatar/)

**Being able to use an avatar must not enable its creator metadata editor.**

Owning a source-model license is also not automatically the same as owning every uploaded avatar record derived from that model.

### Library cards

Each card should show the avatar name, thumbnail, relationship to the account, visibility where available, platform availability, and update observation.

A local label such as “Convention version” should be presented separately from the remote name.

Cards should have an unmistakable ownership badge:

> Uploaded by this account.

> Licensed for use.

> Favorited.

> Local bookmark only.

### Search and filtering

Useful filters include uploaded versus licensed, public versus private where applicable, platform availability, local collections, incomplete metadata, pending local drafts, and unavailable records.

“Missing Android build” should be based on known build information, not on a missing field from a partial response.

### Selection and launch behavior

Opening avatar details should be read-only.

Selecting an avatar for the account, when supported, should be a separate command.

A successful account-side selection should not be labeled “Loaded in VRChat” without client-side evidence. Your existing developer guide already makes this distinction, and the normal avatar manager should preserve it.    VRC-Eye-1.19.7-Developer-Guide

### Unavailable avatars

An avatar becoming unavailable should not immediately destroy local notes or project links.

The card can become a tombstone record:

> This avatar is not currently available through the selected account.

The app should preserve useful local organization according to retention settings while avoiding claims about why access changed.

### Large libraries

The manager should support incremental loading, virtualized grids, lazy thumbnails, and search over already indexed permitted metadata.

Scrolling through a library should not trigger a fresh full profile request for every visible card.

---

## 10. Owned-avatar metadata editing

This should be a structured editor with drafts, previews, validation, conflict detection, and explicit save results.

It should not be a raw JSON textbox in the normal interface.

### Ownership verification

Before enabling remote editing, VRC Eye should verify that the selected authenticated account is permitted to edit that avatar record.

The local project owner, folder name, avatar nickname, and remembered author name are not sufficient.

Where ownership cannot be established, the editor should remain local-draft-only.

### A field allowlist

The adapter should explicitly define which fields are editable.

The community reference documents an avatar-update operation, but a response containing a field does not establish that the field can safely be written. [VRChat Community](https://vrchat.community/reference/update-avatar)

For example, an API response may contain server-computed information, identifiers, review state, platform information, or other values that should not be exposed as editable metadata.

The application must never implement:

> Fetch the object, let the user edit anything, then send the whole object back.

### Draft behavior

Typing should save a local draft, not continuously update VRChat.

The draft should record its owning account, target avatar, baseline values, proposed values, and creation/update times.

Closing the editor should offer to keep or discard the local draft. It should not silently publish it.

Changing accounts should preserve the draft under its original owner.

### Review before save

The review screen should show only actual changes.

For example:

| Field       | Previous value       | Proposed value         |
| ----------- | -------------------- | ---------------------- |
| Name        | Example Avatar       | Example Avatar — Event |
| Description | Previous description | Revised description    |
| Visibility  | Private              | Public                 |

A visibility change should stand out more strongly than a spelling correction.

The user should not need to inspect a full metadata document to discover that a public/private setting changed.

### Conflict detection

Before sending, compare the draft’s baseline with a newly observed record where supported.

If the remote description changed after the draft began, the user should see the baseline, current remote value, and their proposed value.

Offer “Keep remote,” “Keep mine,” or a manual merge as appropriate.

Do not silently overwrite someone’s changes made through the website or SDK.

### Be honest about race conditions

A final read followed by a write is not automatically a server-side transaction.

Another update may occur between them.

Your developer guide already notes that its last-moment comparison is not an atomic server transaction. The expanded editor should preserve that honesty unless an integration genuinely supports conditional updates.    VRC-Eye-1.19.7-Developer-Guide

### Save results

The editor should distinguish:

> Saved and verified.

> Submission acknowledged; verification pending.

> Rejected; draft retained.

> Outcome unknown; draft retained.

A timeout must not delete the draft.

### Undo

“Undo remote change” should mean preparing a new reviewed change that attempts to restore earlier values.

It must not imply that the original operation can be erased from the service’s history or that all side effects can be reversed.

---

## 11. Avatar description, image, tags, and platform builds

These belong together visually, but they require different validation and authority rules.

### 11.1 Name and description

The editor should have a live character counter, clear validation, preserved line breaks where supported, and an explicit distinction between local notes and remotely published description text.

Do not silently truncate text to make a save succeed.

When text exceeds a verified limit, explain the limit and keep the user’s complete draft.

Validation should be based on the actual editing surface. VRChat’s current avatar-product documentation provides specific limits, but those should not automatically be treated as universal limits for every older or different endpoint. [VRChat Creators](https://creators.vrchat.com/economy/products/avatar/)

For the documented avatar-product surface, the reference currently specifies:

| Field            | Documented limit                                             |
| ---------------- | ------------------------------------------------------------ |
| Name             | Up to 64 characters.                                         |
| Description      | Up to 256 characters.                                        |
| Tags             | Up to 10 tags, each up to 64 characters.                     |
| Acknowledgements | Up to 300 characters.                                        |
| Thumbnail        | Square, between 64×64 and 2048×2048 pixels, up to 10 MB.     |
| Gallery          | Up to six images, up to 1 MB each; 1920×1080 is recommended. |

These are validation inputs for that particular documented surface, not permission to assume that every field has a working VRC Eye write adapter. [VRChat Creators](https://creators.vrchat.com/economy/products/avatar/)

### 11.2 Thumbnail and image tools

Add a local image-preparation panel.

It should allow cropping, previewing, checking dimensions, estimating final file size, and comparing the proposed thumbnail against the existing one.

The source file should remain unchanged unless the user explicitly chooses to overwrite it.

The preview should show how the image looks at both full size and small card size.

A technically valid image can still become unreadable when reduced to a thumbnail. The user should be able to see that before publishing.

### Separate preparation from upload

Preparing an image locally should not imply that VRC Eye has uploaded it.

Selecting an already supported hosted image and uploading a new image are also distinct capabilities.

When the approved integration path does not support a particular media operation, the application should provide an explicit official-site handoff rather than pretending that changing an image URL is a complete upload workflow.

### Media validation

The application should inspect the decoded image, not just the filename extension.

It should apply bounds to dimensions and decoded size, handle corrupted files, and avoid forwarding credentials to arbitrary image hosts.

Remote redirects should remain subject to the same destination checks as the original request.

### 11.3 Tags

There should be three visibly separate tag categories:

**Remote descriptive tags** are published through supported avatar metadata.

**Required content-warning labels** represent platform content classification.

**Local organization labels** exist only inside VRC Eye.

These must not share one ambiguous tag box.

A local label such as “Needs fixing” should not accidentally be published.

A descriptive tag editor should not remove required content warnings.

VRChat’s upload documentation treats content warnings, visibility, thumbnail selection, and other avatar details as distinct parts of the publishing workflow. [VRChat Creators](https://creators.vrchat.com/avatars/creating-your-first-avatar/?utm_source=chatgpt.com)

### Reserved and unknown tags

Unknown or server-managed tags should remain visible to a diagnostic view without automatically becoming editable.

If an integration only supports replacing an entire tag collection and VRC Eye cannot safely preserve its required semantics, the write should be unavailable until the adapter is reviewed.

“Preserve unknown data” must not mean “blindly send every server field back.”

### 11.4 Visibility and publication

Visibility should be its own clearly labeled section.

Changing a local collection from “Private projects” to “Public projects” must not change the avatar’s remote visibility.

The user should see an explicit remote action:

> Change this avatar’s VRChat visibility.

For creator-owned uploads, VRChat documents different behavior for public and private avatars. That change deserves a higher-impact review than ordinary text editing. [VRChat Creators](https://creators.vrchat.com/avatars/creating-your-first-avatar/?utm_source=chatgpt.com)

### 11.5 Platform build overview

Do not reduce this to two icons labeled PC and Quest.

VRChat’s creator documentation currently describes Windows, Android, and iOS targets. The data model should accommodate those targets and preserve unknown future targets without mislabeling them. [VRChat Creators](https://creators.vrchat.com/platforms/)

The build view should show, when legitimately available:

| Build attribute                  | Meaning                                                       |
| -------------------------------- | ------------------------------------------------------------- |
| Platform target                  | The actual build target reported by the source.               |
| Availability                     | Whether a build record is known for that target.              |
| Version information              | The version data the source actually provides.                |
| Upload/update observation        | When the build information was observed.                      |
| Reported performance information | Clearly identified as reported metadata.                      |
| Validation status                | Whether VRC Eye has enough information to assess consistency. |

An absent field is **Unknown**. A verified absent build is **Missing**.

Those must be different states.

### Build consistency

Useful warnings include “Only Windows build observed,” “Platform records have different reported versions,” and “Build data is incomplete.”

The wording should avoid implying that a version difference always means a broken upload.

Some differences may be intentional. The user should be able to mark a local explanation without altering remote metadata.

### Metadata editing is not rebuilding

Changing a platform label cannot convert an avatar to another platform.

Changing a displayed performance value cannot optimize an avatar.

Actual build work belongs to the creator’s source project and supported SDK workflow. VRChat documents SDK interfaces for enhancing creator workflows, which should remain separate from a generic social-account editor. [VRChat Creators](https://creators.vrchat.com/sdk/public-sdk-api/?utm_source=chatgpt.com)

### 11.6 History and restoration

Retain optional local metadata snapshots so users can compare changes.

Call this **Metadata history**, not **Full avatar backup**.

A snapshot of name, description, tags, and build records does not contain the original Unity project or guarantee restoration of an uploaded asset.

---

# Part IV — Multi-account behavior

## 12. Multi-account VRC Eye support

Multi-account support is an application-wide architecture change.

It affects every cache, notification, worker, draft, permission check, and UI callback.

### Add an account without creating a session accidentally

“Add account” should initially create a local workspace record.

The user can assign a label and choose whether to connect it through an available, reviewed authentication path.

Creating the local record should not attempt sign-in, query a profile, or copy credentials from another application.

### Account records

A local account record should contain a random internal identifier, optional verified service-user identifier, local alias, current display-name snapshot, settings namespace, connection-provider reference, and session generation.

It should not use the display name as its primary key.

### Multiple connected accounts

The design can support multiple account contexts at once, but background activity should be configurable per account.

Useful modes would be:

**Disconnected** retains local organization only.

**Manual refresh** allows user-initiated reads.

**Background social updates** permits a limited set of explicitly enabled refresh activities.

**Paused** keeps the workspace available but stops scheduled work.

The application should not assume that connecting an alt means the user wants it polled indefinitely.

### Authentication separation

Each account must have its own authentication state and verification flow.

A verification response for Main must not complete an Alt login attempt because the user switched tabs.

An expired session should affect that account’s work, not produce a confusing global logout unless the failure truly applies globally.

### Aggregate views

“All Accounts” should be an explicitly chosen view.

Its rows should carry account badges. An unread count should indicate which accounts contributed to it.

Actions launched from an aggregate view must still resolve to one acting account.

A combined dashboard must not become a combined identity.

### No quota multiplication

Multiple accounts must not be used to bypass throttling.

A request rejected or delayed for one context should not be silently rerouted through another account.

The global scheduler should also consider aggregate application traffic, rather than treating every account as an excuse to create another uncontrolled request loop.

---

## 13. Main/alt account organization

“Main,” “Alt,” “Creator,” and “Testing” should be **private VRC Eye labels**.

They should not imply that VRChat has merged the accounts or publicly identified them as belonging to the same person.

### Local labels and appearance

Each account can have a local name, icon, accent, ordering preference, and default workspace.

Color should be supplementary. The label must remain readable without color perception.

A creator account might open My Avatars by default. An alt might open a quiet dashboard.

Those defaults should be user-selected.

### Keep account links private

The relationship between the user’s own accounts should not be exported to peers, included in diagnostic bundles, exposed in notifications, or inserted into public profile text.

A screenshot mode should optionally replace account aliases with neutral labels.

“Main” and “Secret Alt” can themselves be sensitive information.

### No automatic cross-account copying

Adding an alt should not copy Main’s friends, notes, favorites, groups, blocked-user settings, or profile text.

A future “Copy selected local settings” tool should clearly identify source, destination, and the exact categories being copied.

Cosmetic application settings are different from social records.

### Do not confuse organization with account linking

VRC Eye’s account organization should not present itself as the platform’s account-linking or upgrade process.

Those are separate operations with separate consequences.

The UI should use “Organize account” or “Add account workspace,” not “Merge accounts.”

### Compare without leaking

An optional comparison page could compare the user’s own local settings across accounts.

It should default to non-sensitive settings such as layout, notification preferences, and enabled modules.

Comparing private social information should require an explicit choice and retain the account source for every value.

---

## 14. Account-isolated state

This is the most important engineering section.

An account dropdown is not account isolation.

### Everything that must be scoped

At minimum, the following must be associated with an account context:

| State category       | Examples                                                           |
| -------------------- | ------------------------------------------------------------------ |
| Authentication       | In-memory session state, verification progress, connection status. |
| Social data          | Friends, requests, invitations, group memberships.                 |
| Private organization | Notes, nicknames, labels, saved views.                             |
| Creator records      | Editable-avatar lists, drafts, ownership observations.             |
| Notifications        | Inbox items, read state, routing preferences.                      |
| Background work      | Queued reads, pending writes, retry state.                         |
| Diagnostics          | Account-scoped events and sanitized action records.                |
| Permissions          | Group capabilities, ownership checks, operation availability.      |

Environment must be part of the scope too.

Main in Live and Main in Replay are not interchangeable contexts.

### Cache keys

A private cache key should include account context, environment, provider, resource identity, query parameters, and relevant representation scope.

Caching a user profile only under the target user ID is insufficient when different viewing accounts may receive different permitted fields.

The same applies to missing or forbidden results.

A “not available to Alt” result must not poison Main’s view, and a richer Main response must not leak into Alt’s view.

### Asynchronous responses

Every request should carry the context under which it started.

When its response arrives, the application should verify that it still belongs to the correct account session generation.

A response can be stored in its original account’s cache where appropriate without being rendered into whichever account is now visible.

The rendering layer should reject mismatched context, not merely hope that the worker was canceled.

### Session generations

Each successful connection or replacement should create a new session generation.

Work started under an older generation should not be allowed to mutate the newer session’s state.

This handles late verification responses, delayed network results, reconnects, and sign-out/sign-in races.

### Shared images and blobs

The application may eventually deduplicate identical image bytes for storage efficiency.

However, possessing the bytes is not proof that a particular account should display them.

Authorization and visibility checks must happen before rendering, even when the file is already present locally.

### Search isolation

Global application search should default to the selected account.

“All Accounts” search should be explicit.

Search results, autocomplete suggestions, recent searches, and command-palette history all need the same account isolation as the main database.

A carefully isolated database can still leak through a carelessly global autocomplete list.

### Isolation is not an operating-system security boundary

This design should prevent accidental cross-account mixing inside VRC Eye.

It should not be advertised as protection against a compromised operating-system account or arbitrary software running with the same privileges.

The product should distinguish application-level separation from stronger device-security guarantees.

---

## 15. Active VRC Eye Logins

This page should answer:

> Which account connections is this VRC Eye installation managing, and what is each one doing?

It should **not** claim to show every VRChat login on every device.

### Session cards

Each card should contain the account alias, display name, connection state, authentication-provider identity, session start observation, last successful authenticated operation, enabled background work, and queued actions.

It should also show whether notifications are enabled and whether this account matches the currently observed game session.

### Use precise connection states

I would separate authentication state from network state.

An account may still have an authenticated local context while the network is temporarily unavailable.

Useful display combinations include:

> Connected; network unavailable.

> Verification required.

> Session expired.

> Paused by you.

> Disconnected; local data retained.

Do not translate every timeout into “Logged out.”

### Distinct controls

The page should provide separate controls for:

| Control                            | Intended effect                                            |
| ---------------------------------- | ---------------------------------------------------------- |
| **Pause updates**                  | Stop future background work for this account.              |
| **Disconnect VRC Eye**             | Stop this app’s use of its current local connection.       |
| **Forget remembered sign-in**      | Remove deliberately stored sign-in values.                 |
| **Clear cached account data**      | Remove selected local cached information.                  |
| **Remove account workspace**       | Remove the local account record and selected local data.   |
| **Open official account security** | Hand off to the platform’s own account-management surface. |

Your 1.19.9 guide already distinguishes forgetting saved values from disconnecting the in-memory session and explicitly avoids claiming that disconnecting revokes other applications’ sessions. Preserve that distinction.    VRC-Eye-1.19.9-Login-Guide

### Activity inspector

A session card should expand into a readable activity summary.

Examples:

> Friends refresh waiting in the shared queue.

> One avatar metadata draft exists.

> No outgoing social actions are pending.

> Notifications are paused for this account.

It should not expose cookies, passwords, verification codes, or a “Copy authentication token” button.

### Multiple VRC Eye devices

A future paired-device system should be a separate concept.

Pairing two VRC Eye installations should exchange VRC Eye-specific permissions and device identity—not VRChat credentials.

“Revoke this paired device” should mean revoking its VRC Eye access. It should not imply that all platform sessions on that device have been invalidated.

---

## 16. Expand remembered sign-in without breaking 1.19.9

The existing behavior has several valuable details that a multi-account rewrite could easily lose.

The guide describes successful-authentication-only saving, independent forgetting, no automatic login when the dialog opens, and duplicate-submission prevention. It also documents Windows Credential Manager storage without a plaintext fallback.&#x20;

### Preserve independent choices per account

Each account should retain separate “Remember username” and “Remember password” choices.

Turning off one should not silently turn off the other.

Neither choice should automatically imply session persistence or automatic login.

These are distinct behaviors.

### Password-only mode requires identity binding

A stored password must not be automatically submitted with an unrelated username just because the password field is populated.

The remembered record must remain associated with its intended account identity.

The UI should explain a mismatch and require deliberate user input rather than trying the stored password against several possible accounts.

### Migration from the current single pair

The migration should not guess which new account workspace owns the legacy record.

A controlled migration could occur after a successful sign-in establishes the actual account identity.

The application should then explain which existing remembered values will be associated with that workspace.

A failed or canceled migration should leave the previous usable state intact.

### Storage failures must be visible

“Forgotten” should not appear until the storage layer confirms removal.

A failed credential save should not be reported as a failed VRChat sign-in when authentication itself succeeded.

Those are different outcomes and need different messages.

Operating-system credential persistence has its own defined behavior; it should remain behind a dedicated storage abstraction rather than being mixed into general settings serialization. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/wincred/ns-wincred-credentialw)

### Keyboard behavior

Enter and keypad Enter should operate only on the relevant login or verification form.

Repeated presses during an active attempt should not create duplicates.

Enter during text composition should not prematurely submit an unfinished value.

Opening another account’s connection dialog should not cause a global Enter handler to submit a hidden form.

---

# Part V — Labels, warnings, and understandable consequences

## 17. API risk labels

One red/yellow/green badge cannot describe everything important about an operation.

I would separate **integration support**, **side effects**, **privacy**, and **recovery**.

### Integration-support label

Examples:

| Label                    | Meaning                                                                                        |
| ------------------------ | ---------------------------------------------------------------------------------------------- |
| **Local only**           | No external service operation is required.                                                     |
| **Official handoff**     | VRC Eye opens an official surface for the user to continue.                                    |
| **Reviewed API adapter** | VRC Eye has a defined integration for this operation, subject to platform support limitations. |
| **Experimental adapter** | The integration is still under development or insufficiently verified.                         |
| **Unavailable**          | No supported implementation is currently available.                                            |

“Reviewed API adapter” must not look like “Officially approved by VRChat.”

Those are different claims.

### Side-effect label

Use plain language:

**Reads account data.**

**Changes your account.**

**Contacts another user.**

**Changes visibility.**

**Removes a relationship or resource.**

The user should not need to know HTTP methods to understand what a button does.

### Operational-risk explanation

The expanded panel should describe likely failure modes.

For an invitation, the risks include contacting the wrong person, disclosing a destination, or creating a duplicate after an uncertain result.

For avatar metadata editing, the risks include overwriting newer data or changing public-facing content.

For a local nickname, the risks are primarily local data handling and export exposure.

### No fake ban percentages

Do not display “2% ban risk,” “100% safe,” or similar invented precision.

The application does not have evidence for those numbers.

API compatibility, platform permission, account consequences, and privacy impact should be described separately.

### Label changes invalidate old reviews

If an adapter’s risk classification or availability changes, existing prepared actions should require a new review.

An action prepared under one capability definition should not silently execute under a materially different one.

---

## 18. Authentication requirement labels

Authentication labels should explain what is needed **and why**.

### User-facing examples

Useful labels include:

> No sign-in needed — local organization.

> Cached account data only.

> Connection required for this account.

> Additional verification required.

> Avatar owner access required.

> Group permission required.

> Continue on the official website.

Do not flatten all of these into a padlock icon.

### Authentication is not authorization

A connected account may still lack permission to edit an avatar or invite users to a group.

The button’s explanation should distinguish:

> You are not connected.

from:

> You are connected, but this account does not have the required permission.

That distinction prevents pointless reauthentication loops.

### Read-only mode

Read-only mode should disable VRC Eye’s remote mutation commands.

It must not claim that the underlying authentication mechanism has cryptographically read-only permissions unless that is actually true.

The explanation should be:

> VRC Eye will not send account-changing actions in this mode.

not:

> This session cannot change anything anywhere.

### Verification flow

When additional verification is needed, pause the relevant action and explain why.

Do not quietly repeat the original password step.

A canceled verification should leave the action unsent and retain any non-sensitive draft.

### Unavailable authentication path

The feature should remain capable of showing local drafts, cached data according to the user’s settings, and official handoff options.

A missing connection should degrade the feature gracefully, not turn the entire workspace into an empty error panel.

---

## 19. Privacy-impact labels

Privacy labels should explain **where information goes**.

“Private” is too vague on its own.

### Privacy dimensions

For each feature, describe whether data is stored locally, sent to VRChat, shared with another VRC Eye user, included in notifications, exposed in an overlay, or eligible for export.

A local note might be private to this installation but still appear in an unredacted backup.

An invitation necessarily reveals selected information to another person.

A diagnostic report can be sanitized without becoming anonymous in every possible context.

### Example labels

| Feature               | Example privacy explanation                                         |
| --------------------- | ------------------------------------------------------------------- |
| Local nickname        | Stored in this account’s VRC Eye workspace.                         |
| Remote profile edit   | Sent to VRChat and potentially visible according to platform rules. |
| Invitation            | Shares the selected invitation details with the recipient.          |
| Main/alt organization | Local account relationship; excluded from ordinary peer sharing.    |
| Diagnostic export     | Previewed and redacted before export.                               |
| Full local backup     | Contains private account data; not a shareable support report.      |

### Retention should be visible

Advanced view should show whether a record is temporary, retained until manually deleted, or subject to a configured retention period.

The application should explain what deletion affects.

Deleting an inbox card locally does not retract something already sent to another user.

Deleting local history does not delete a file the user previously exported.

### Notification privacy

The privacy system should cover desktop notifications, tray tooltips, overlays, task-switcher previews, and screenshots—not just the main window.

A masked main interface is not sufficient if a toast still says:

> Secret Alt received an invitation from ExampleName.

### Privacy presets

Useful presets could be **Normal**, **Streaming**, **Shared computer**, and **Minimal retention**.

Each should show a reviewable list of settings it changes.

A preset should not silently alter remote VRChat status or profile visibility unless the user explicitly chooses those separate actions.

---

## 20. Account-change warnings

Warnings should appear where a context change creates a real risk, not every time the user navigates.

### Switching with an unsaved draft

The app should offer:

> Keep draft under Creator and switch.

> Discard draft and switch.

> Stay here.

It should not offer “Save” without clarifying whether that means save locally or publish remotely.

### Switching with queued work

Before switching, identify any queued remote writes.

The default should be to pause or cancel unsent writes that require active user context.

Read-only background work can continue under its original account when enabled, but it must not populate the new account’s UI.

### Switching after dispatch

Once an operation has been sent, changing accounts cannot reliably unsend it.

The activity record should remain attached to the original account.

The new account should not inherit the operation or its success message.

### Confirmation dialogs

A confirmation must include the acting account, target, operation, and meaningful consequences.

Bad:

> Are you sure?

Better:

> Remove ExampleName from Main’s friends? This does not affect Alt’s separate relationship with this person.

### Browser handoffs

Opening a browser page should not imply that the browser uses the selected VRC Eye account.

The handoff should remind the user to verify the website’s account before performing a consequential operation.

VRC Eye should not attempt to solve this by copying authentication state into the browser.

### Game-account mismatch

For actions involving the local game—joining an instance, responding using its observed location, or assessing avatar loading—the mismatch warning should be explicit.

For purely account-side organization, the mismatch can be informational rather than blocking.

Warnings should reflect the operation, not produce blanket alarm.

---

# Part VI — Additional features worth adding

## 21. A unified social inbox

The inbox should combine friend requests, invitations, invite requests, group invitations, relevant account notices, and local action outcomes.

Each item needs a type, source account, target identity, event identifier where available, observation time, local read state, and remote-state summary.

**Reading**, **archiving**, **dismissing**, and **performing a remote action** should remain distinct.

The inbox should deduplicate repeated observations without merging different events.

Two invitations from the same person to different instances are not duplicates.

An item already handled on another device should update to:

> Already handled elsewhere.

It should not continue offering an action known to be stale.

A useful feature would be a “Needs attention” view that prioritizes actionable items without implying that every notification is urgent.

---

## 22. Friend circles, local labels, and private notes

Add local circles such as “Creator friends,” “Regular group,” and “People to invite to the next playtest.”

A person may belong to several circles.

Circles should not automatically send anything, publish membership, or create remote friend categories.

### Notes need storage labels

If VRC Eye supports both local notes and a platform-hosted note mechanism, the editor should clearly distinguish them.

“Private note” should not obscure whether the text is being transmitted to a service.

Local notes should support search, timestamps, simple formatting, and explicit export inclusion.

They should not be inserted into invitation messages automatically.

### Local nicknames

Nickname edits should never modify the target person’s public profile.

Search should match both nickname and current display name while keeping the stable identity attached.

### Circle actions

Safe initial actions include filter, pin, create a local event roster, and prepare an invitation review.

“Invite this circle” should open a recipient review, not immediately contact everybody.

---

## 23. My profile and status editor

Your list includes user profiles, but a dedicated **My Profile** editor deserves its own page.

It should show current remote values alongside local drafts for supported fields.

Status presets could include “Available,” “Working on an avatar,” and “Quiet session,” with user-authored text and explicit social-status choices.

Because VRChat’s status setting influences more than cosmetic text, a preset should preview those effects before applying it. [VRChat Wiki](https://wiki.vrchat.com/wiki/Social)

### Temporary presets

A temporary preset should record the exact values it changed and the previous values.

Restoration should not blindly overwrite a later manual change.

For example, if VRC Eye applies one status and the user subsequently changes it inside VRChat, an expiry timer should not replace the newer choice without review.

### Separate local and remote quiet modes

“Mute VRC Eye notifications” should affect VRC Eye.

“Change my VRChat social status” should affect the account.

A combined preset may offer both, but each effect must be visible.

---

## 24. Favorites and bookmarks manager

Create one place to manage supported remote favorites and VRC Eye-only bookmarks.

The distinction should be visible in every collection.

A local folder called “Favorites” should not be mistaken for a synchronized VRChat favorite list.

### Conflict-aware synchronization

For supported remote favorite operations, the app should compare current state before applying changes and clearly identify additions and removals.

Deleting a local bookmark should not remove a remote favorite unless the user explicitly requests that operation.

### Limits

The UI should use verified current limits where available.

It should not hardcode one universal capacity and then tell the user that their account is broken when the platform exposes a different limit.

### Missing resources

A removed or inaccessible resource should remain as a labeled placeholder when useful.

Do not repeatedly fetch it on every render.

Offer local removal separately from any remote cleanup.

---

## 25. Recently met and encounter bookmarks

A local “Recently Met” feature would be useful, especially for finding someone after a busy session.

It should rely on information actually observed through an enabled, appropriate source.

### Record useful context, not everything

A minimal encounter record could contain the user identity, local encounter time, source session, and an optional user-written note.

World or instance details should be retained only under the selected privacy settings.

The user should be able to bookmark a particular encounter rather than automatically keeping an indefinite history.

### No activity reconstruction

The feature should not query multiple accounts to track a person’s movements.

It should not estimate where someone went after leaving or infer private destinations.

A record should say:

> Seen in your session.

not:

> Tracked online for four hours.

### Recovery after a crash

A small optional local encounter journal could help recover recently seen names after VRC Eye or VRChat closes unexpectedly.

Retention and export behavior should be explicit.

---

## 26. Social action journal and recovery center

This should collect the outcomes of actions VRC Eye attempted.

It is different from the inbox: the inbox contains incoming events; the journal contains the application’s own commands and outcomes.

### Journal entries

Each entry should show the acting account, operation, target, preparation time, dispatch state, result, verification state, and available recovery action.

Sensitive message content and private destinations should be redacted by default.

### Recovery actions

Examples include:

> Verify without sending again.

> Reopen retained draft.

> Review current remote values.

> Discard unsent action.

> Open the official management page.

A generic “Retry everything” button would be inappropriate.

### Uncertain outcomes

The recovery center should make uncertain outcomes visible without encouraging duplicate submissions.

HTTP standards distinguish operations for which automatic retry is appropriate from those requiring greater care. VRC Eye should base retry behavior on the operation’s actual semantics, not merely on whether the network request failed. [RFC Editor](https://www.rfc-editor.org/rfc/rfc9110.html)

---

## 27. A real notification-control center

Notifications need their own policy system.

Controls should exist per account, event type, destination, and quiet-mode profile.

### Routing

An event could appear in the inbox only, as a desktop toast, in an overlay, or through a sound.

Those routes should be individually selectable.

A hidden Alt account should not become visible through a global tray tooltip.

### Deduplication and batching

A burst of presence updates should produce a summary rather than dozens of toasts.

Repeated observations of the same event should not repeatedly notify.

Batching should not erase important distinctions between accounts or between different recipients.

### Quiet hours

Quiet hours should use the user’s selected timezone and handle daylight-saving transitions.

They should control notifications, not silently send account-status changes.

### Notification clicks

Clicking a toast should open the event in its original account context.

The app must not process an Alt invitation under Main merely because Main is currently selected.

---

## 28. Social session planner and small event rosters

Add a lightweight planner for meetups, creator tests, photography sessions, and group activities.

A plan should contain a title, selected account, proposed time, optional world bookmark, participants, and local checklist.

### Planning is not sending

Adding somebody to a roster should not contact them.

Preparing invitations should be a separate reviewed step.

### Readiness and attendance

Local checkboxes and optional Eye-to-Eye responses should be labeled by source.

A “Ready” response from an opt-in VRC Eye peer is not a VRChat presence confirmation.

An invitation submission is not attendance.

### Calendar integration

Calendar export can be useful, but private instance links should be excluded by default.

An event shared outside VRC Eye should preview exactly which account names, participant names, and destinations are included.

Group calendar management, where supported, should require the relevant group permission rather than being treated as a normal personal-calendar operation. VRChat’s group permission model distinguishes calendar management from other group capabilities. [VRChat Wiki](https://wiki.vrchat.com/wiki/Groups)

---

## 29. Eye-to-Eye social actions

Reuse the planned Eye-to-Eye system instead of pretending that VRChat invitations are a general messaging API.

A profile could expose optional actions such as sending a world card, sharing a bookmark, requesting a ready check, coordinating a photo countdown, or exchanging a reviewed diagnostic card.

### Capability-driven controls

Only display an enabled action when the peer has advertised the necessary capability and granted the relevant permission.

An unavailable peer feature should not silently fall back to a more privacy-invasive channel.

### Distinguish identities

A verified VRC Eye peer identity, a claimed VRChat account, and an authenticated local VRChat account are separate concepts.

The interface should not overstate the strength of a linkage.

### Per-account permissions

Main may permit a peer interaction that Alt does not.

Permissions should not automatically transfer across the user’s local account collection.

The peer system should never receive VRChat passwords, cookies, or raw authentication state.

---

## 30. Account security and recovery dashboard

This should be a status and handoff center, not a replacement password manager or identity-verification service.

It can show connection problems, repeated local authentication failures, outdated local app versions, pending credential-removal failures, and links to official recovery surfaces.

### Keep sensitive recovery material out

Do not retain verification codes, recovery codes, identity documents, or screenshots of sensitive account-recovery pages.

The app can explain that an action must continue through the platform’s own process.

### Clear recovery scope

“Fix VRC Eye connection” is different from “Recover my VRChat account.”

VRChat provides official account sign-in, verification, and recovery guidance. VRC Eye should direct genuine account-recovery problems there rather than improvising recovery mechanisms. [VRChat](https://help.vrchat.com/hc/en-us/articles/1500002379302-I-m-having-issues-logging-signing-in-2FA-or-need-help-with-Account-Recovery)

### Security notices without false certainty

A suspicious local event should be described as an observation.

For example:

> Several sign-in attempts failed in this VRC Eye installation.

not:

> Someone is hacking your account.

The app should avoid turning incomplete telemetry into an accusation.

---

## 31. Block, mute, and interaction-preference manager

This belongs near Social but should remain clearly separated from friendship management.

A local notification mute, a VRChat account preference, and a group moderation action are not interchangeable.

### Show the scope

Each setting should say whether it affects VRC Eye notifications, the selected VRChat account, or a specific group context.

Unfriending should not automatically block.

Blocking should not silently erase private notes unless the user’s cleanup settings request it.

### No reverse inference

Do not add a feature that claims to identify who blocked the user based on missing profiles, unavailable locations, or failed requests.

Those observations are not sufficient evidence.

### Safety actions remain accessible

Quiet or simplified views should not bury ordinary protective controls.

Any remote action should still use the account-bound command system and show whether its effect has been confirmed.

---

## 32. Privacy dashboard, exports, and deletion

Every account should have a page explaining what VRC Eye has retained.

Show categories rather than an intimidating list of database tables.

Examples include profile cache, friend records, local notes, encounter history, drafts, action journal, and downloaded thumbnails.

### Storage inspection

The page should show approximate size, retention policy, last update, and whether the category is included in backups or reports.

### Export types

Provide distinct export types:

**Settings export** contains selected configuration.

**Personal data export** contains the user’s chosen account records.

**Diagnostic report** contains reviewed, sanitized troubleshooting information.

**Full backup** contains private data and should be labeled accordingly.

The existing developer guide already distinguishes private database backups from sanitized reports. That distinction should become visible in the normal account-management UI.    VRC-Eye-1.19.7-Developer-Guide

### Deletion behavior

Clearing cached profiles should not delete local notes unless explicitly selected.

Removing an account workspace should explain whether remembered sign-in data will also be removed.

The application should not claim that local deletion erases previously exported files or remote service records.

### Import safety

Imported files should be treated as data, not executable instructions.

Imports should not automatically authenticate accounts, submit queued actions, or merge private account identities.

A preview should show the destination account and collision-handling behavior before applying anything.

---

## 33. Avatar collections, variants, and release notes

Add local variant relationships between avatars.

Examples include “Standard,” “Event,” “Performance-focused,” and “Testing.”

These should be local organization unless the platform exposes a matching concept through a supported interface.

### Variant links

A variant relationship should record the linked avatar IDs, account ownership context, local description, and source-project reference where supplied.

It should not imply that one avatar can be converted into another by copying metadata.

### Local release notes

Allow the creator to record what changed and which source project produced the update.

These notes can remain local or be copied manually into an appropriate public description.

They should not be published automatically.

### Metadata templates

Templates could help with acknowledgements, naming conventions, and description structure.

Applying a template should produce a draft diff.

It must not replace content warnings, visibility, ownership, or platform build data.

---

## 34. Purchased-avatar and entitlement clarity

The manager should explain why an avatar appears in the library.

“Purchased,” “licensed,” “favorited,” and “uploaded by you” should not be collapsed into “owned.”

### Read-only entitlement panel

Where supported, show the entitlement relationship and observation time.

Avoid collecting unnecessary purchase or financial details merely to explain access.

### Expired or unavailable access

When an entitlement can no longer be confirmed, retain local organization but mark access as unconfirmed.

Do not promise that a cached record guarantees continued use.

### Creator editing boundaries

An account with licensed use should be able to create local notes and collections.

It should not receive creator metadata controls simply because the avatar is present in its library.

This separation follows the distinction between uploaded avatar records and product-granted access in VRChat’s creator documentation. [VRChat Creators](https://creators.vrchat.com/economy/products/avatar/)

---

## 35. Search and a command palette

A command palette could make the expanded system manageable.

Examples:

> Open Main’s pending requests.

> Find my avatar with an unreviewed draft.

> Show people in my Playtest circle.

> Open Active VRC Eye Logins.

### Search first, act second

Selecting a search result should open a detail view.

Consequential commands should show a preview before execution.

Typing a command must not turn fuzzy text matching into a remote action against the wrong person.

### Account-qualified results

Every result should carry its account context.

Identical display names should remain distinguishable through profile images, local context, and stable identifiers in the detail view.

### Search privacy

Search suggestions should obey account isolation, streaming mode, and retention settings.

Recently searched private accounts should not appear in an unrelated account’s autocomplete.

---

## 36. Accessibility and reduced-complexity views

The expanded feature set should not require perfect vision, precise mouse control, or memorization of icon meanings.

### Interaction requirements

All important controls should be keyboard reachable.

Status must not rely on color alone.

Dialogs should have stable focus, readable descriptions, and predictable Escape behavior.

Destructive actions should not become the default merely because the user pressed Enter while a list was refreshing.

### Text handling

Long names should wrap or reveal a full accessible label.

Truncation should not make two different users appear identical.

Interface layouts should tolerate translated text and increased font size without hiding the acting account.

### Reduced motion

Presence changes and inbox updates should not require animated reshuffling.

A reduced-motion preference should preserve all functionality.

### Casual mode

Casual mode should hide raw identifiers and request details by default, but preserve the account name, action consequence, privacy destination, and result state.

Simplicity should remove clutter—not remove the information that prevents mistakes.

---

# Part VII — The shared machinery

## 37. One command system for every remote action

Friends, invites, profile edits, avatar edits, and group actions should not each invent their own networking logic.

They should use one command pipeline.

### Command record

A proposed internal command envelope would contain:

```
Local command ID
Owning account workspace
Verified acting user identity
Environment
Session generation
Operation type
Target resource identity
Validated proposed fields
Baseline observation
Required permissions
Privacy classification
Review state
Review expiry
Dispatch state
Verification strategy
Result and recovery state
```

This is an internal model, not a VRChat request body.

### Lifecycle

A useful lifecycle is:

```
Draft
→ Validating
→ Ready for review
→ Approved
→ Waiting to send
→ Sending
→ Acknowledged
→ Verified
```

Additional outcomes include:

```
Canceled before sending
Review invalidated
Rejected
Verification unavailable
Acknowledged; verification pending
Outcome unknown
```

The interface should not collapse all terminal states into either a green checkmark or a red cross.

### Review invalidation

A prepared action should become invalid when its account, target, payload, environment, relevant permissions, or capability definition changes.

The user should never approve one operation and have another operation substituted beneath that approval.

### Local validation is useful but limited

Local validation can check structure, required fields, known ownership information, and obvious conflicts.

It does not replace server authorization.

A syntactically valid operation may still be rejected for reasons VRC Eye cannot know in advance.

---

## 38. A shared scheduler and cache

The application needs a scheduler that balances responsiveness with responsible service use.

Your existing developer guide documents a shared 60-second metadata pacing policy and explicitly identifies it as a VRC Eye policy, not an advertised VRChat quota. That should not be silently replaced with aggressive per-panel polling during this expansion.    VRC-Eye-1.19.7-Developer-Guide

### Coalesce equivalent reads

When three panels need the same permitted profile snapshot, they should share one read.

Opening the dashboard, profile window, and invite composer should not triple the requests.

### Separate cache freshness from refresh scheduling

A cache entry becoming stale does not mean it must immediately trigger a network request.

The scheduler should consider whether the data is visible, whether the user requested a refresh, whether another equivalent request exists, and whether the account is paused.

### Prioritize deliberately

A user-requested verification after an uncertain write may deserve higher priority than an off-screen thumbnail refresh.

However, one account should not monopolize the queue indefinitely.

### Throttling and errors

Use backoff, application identification, caching, and unsynchronized scheduling. These align with VRChat’s published API-usage guidance. [VRChat](https://hello.vrchat.com/creator-guidelines)

The UI should show “Waiting because requests are paused” rather than appearing frozen.

If the scope of a throttle is uncertain, the scheduler should behave conservatively instead of immediately retrying through another account.

### Reconnection

Reconnecting should not automatically flush every old social write.

Reads can be rescheduled under policy.

Unsent invitations, profile publications, and destructive actions should require review when their original context is stale.

---

## 39. Provenance: every important value needs an explanation

For meaningful account and social values, retain:

**Where it came from.**

**Which account could see it.**

**When it was observed.**

**Whether it is complete.**

**Whether it has since become stale.**

This supports both privacy and troubleshooting.

### Distinguish server facts from local observations

Examples:

> Server response reports this account as a friend.

> Local session observation indicates this user was present.

> VRC Eye nickname entered by you.

> Account match is unconfirmed.

These are not interchangeable types of evidence.

### Avoid false precision

A presence event observed at 8:03 does not necessarily mean the person came online at exactly 8:03.

A profile change first observed today does not prove it was made today.

Use “Observed” language when that is what the application actually knows.

### Partial responses

A partial response should update only the fields it meaningfully supplies.

Missing fields should not automatically erase existing data unless the adapter knows that omission represents removal.

Unknown formats should produce a compatibility warning, not destructive normalization.

---

## 40. Capability registry

Every feature should ask a shared capability service what is currently possible.

The answer should include availability, reason, authentication requirement, permission requirement, supported fields, side effects, verification method, and integration status.

### Why this matters

Without a registry, one page will enable an action that another page considers unavailable.

A profile window might offer an invitation while the inbox considers the account disconnected.

A metadata editor might expose a field the underlying adapter does not support.

### Availability states

Useful states include:

> Available.

> Available after connection.

> Available after verification.

> Requires ownership.

> Requires a group permission.

> Temporarily paused.

> Unsupported by this provider.

> Disabled after a compatibility failure.

The explanation should be accessible from the disabled control.

### Fail closed for unknown writes

A new response field should not automatically become editable.

A changed endpoint shape should not trigger a fallback to arbitrary request construction.

Read-only inspection can continue where safe, while the affected write remains unavailable pending review.

---

## 41. Cross-feature integration rules

The Social workspace should reuse your existing modules without creating hidden coupling.

### Safety

Safety-related controls should retain their own authority and scope.

A social label such as “Trusted friend” must not disable unrelated protections.

### Networking

Eye-to-Eye sharing should use its existing permission model.

Opening a profile should not start a listener or grant peer access.

### Creator tools

Avatar project links and creator dashboards should remain optional enhancements.

Basic Social and Accounts functionality should not depend on the back-burner Unity toolkit.

### Optional client bridge

The bridge should remain secondary and capability-driven.

Its presence may provide additional evidence or supported controls, but friends, account organization, metadata drafts, and the normal account workspace should not require a modified client.

### Diagnostics

Diagnostics should observe VRC Eye’s own activity and use sanitized records.

A troubleshooting session should not become a remote VRChat API relay operating through somebody else’s credentials.

---

# Part VIII — Failure cases that must be designed before release

## 42. Account-isolation acceptance tests

**Switch during a profile read.** Main starts loading a profile, the user switches to Alt, and Main’s response arrives. The response must not appear in Alt’s profile pane.

**Switch during verification.** A verification result must attach only to the login attempt that created it. It must not sign another workspace into the wrong account.

**Same person, different visibility.** Main and Alt receive different permitted profile fields. Each view must retain its own representation.

**Same event identifiers in different contexts.** Deduplication must include account and provider context rather than assuming that one identifier is globally sufficient.

**Account removal during queued work.** Unsent work must be canceled or invalidated. Late responses must not recreate the removed workspace.

**Live versus Replay.** Replayed events must never use Live authentication or dispatch real commands.

**Global search.** Private notes from Main must not appear in Alt’s suggestions unless an explicit All Accounts search is active.

**Image cache reuse.** An image already stored for one account must not bypass another account’s visibility checks.

---

## 43. Social-action acceptance tests

**Double-click Invite.** Only one command should be created.

**Timeout after submission.** The result should become uncertain, not automatically retry.

**Request accepted elsewhere.** The stale local card should reconcile without creating a second relationship operation.

**Friendship changes while a dialog is open.** Canceling an old request must not silently become unfriending.

**Destination changes.** An invitation prepared from a previous game session should require review before using that destination.

**Recipient disappears from the fetched page.** Pagination changes must not be interpreted as a confirmed removal.

**Permission revoked.** Group actions should fail cleanly and refresh capability information.

**Quiet mode.** Suppressed notifications must not leak through sounds, overlays, tray text, or a different account’s summary.

**Account mismatch.** An invitation received by Main must not be treated as an invitation for the game’s Alt account.

---

## 44. Avatar-editor acceptance tests

**Wrong author.** Creator metadata editing must remain disabled even if the user owns a source-model license or has runtime access.

**Unknown fields.** Newly returned server fields must not become writable automatically.

**Remote edit conflict.** A changed baseline must produce a conflict review instead of overwriting the newer value.

**Partial save result.** A retained draft must identify which operation is acknowledged, rejected, or uncertain.

**Visibility change.** The review must clearly show the change and its target account.

**Local tags.** A local organizational label must never enter the remote tag payload accidentally.

**Required warnings.** Editing descriptive metadata must not remove required content classification.

**Missing build information.** Unknown platform data must not be reported as a verified missing build.

**Image failure.** A corrupt file should leave the remote thumbnail unchanged and preserve the rest of the draft.

**History restoration.** Restoring metadata should be a new reviewed action, not an unqualified promise of full-avatar rollback.

---

## 45. Storage, interface, and recovery acceptance tests

**Credential deletion fails.** The app must not claim the value was forgotten.

**Migration is canceled.** The legacy remembered pair must not be rebound to the wrong account.

**Login succeeds but storage fails.** The account should remain connected while the storage warning remains visible.

**Application restarts with old queued writes.** It must not publish them automatically.

**Large text and translated UI.** The acting account and target must remain visible.

**Long or visually similar names.** Confirmation screens must provide enough identity context to distinguish targets.

**Malformed profile text.** It must render as data, not execute.

**Exported spreadsheet-like text.** Export formatting should keep user-controlled values inert rather than creating active formulas.

**Disk full.** Local draft-save failures must be reported without implying a successful backup.

**Crash during a command.** On restart, the journal should preserve uncertainty rather than invent success or automatically repeat the action.

**Synthetic scale tests.** Large test datasets should verify scrolling, searching, memory bounds, and queue fairness without generating unnecessary live API traffic.

These are acceptance criteria. Passing a handful of happy-path tests would not establish that the multi-account system is safe from cross-context mistakes.

---

# Part IX — Recommended implementation sequence

## 46. Build the foundations before multiplying features

I would stage this by dependency, not by whichever button is most appealing.

### Stage 1 — Account context and command infrastructure

Introduce account-scoped storage, session generations, a capability registry, action envelopes, safe cancellation, and explicit source/freshness information.

At this stage, even a single connected account benefits because the architecture is no longer built around mutable global identity.

### Stage 2 — Read-only Social workspace

Build the dashboard, profiles, account-aware inbox, group membership views, My Avatars organization, and accurate empty/error states.

This exposes normalization and isolation problems before remote writes make them consequential.

### Stage 3 — Reviewed social actions

Add friend-request handling, invitations, invite requests, supported group invitations, action history, and verification/recovery workflows.

Every action should use the same command system.

### Stage 4 — Creator metadata drafts

Add owned-avatar verification, local editing, field validation, diffs, conflict handling, image preparation, and metadata history.

Enable remote fields individually through reviewed adapters rather than exposing everything at once.

### Stage 5 — Multiple active account contexts

Add the account switcher, Active VRC Eye Logins, account-specific background policies, aggregate views, and controlled migration of existing remembered sign-in behavior.

This stage should be blocked on the isolation tests—not merely on whether two accounts can successfully authenticate.

### Stage 6 — Quality-of-life expansion

Add circles, notes, event rosters, privacy presets, advanced notification routing, account comparison, optional peer features, and creator variant organization.

These should reuse the established account and permission model.

---

## The central design rule

Every consequential Social / Account action should make six things answerable:

**Which account is acting? Which person or resource is affected? What information leaves the device? What permission is required? What has actually been confirmed? What happens when the result is uncertain?**

That is the difference between a companion app with many buttons and a Social / Accounts system that remains understandable when the user has several accounts, several windows open, stale data, delayed responses, and a running VRChat session that does not match the dashboard.

The highest-priority additions are therefore **the unified inbox, account-bound action system, genuinely isolated storage, Active VRC Eye Logins inspector, metadata draft/conflict system, and privacy-aware notification router**. Once those exist, the rest of the feature set can grow without turning every new social button into another opportunity to act as the wrong account.