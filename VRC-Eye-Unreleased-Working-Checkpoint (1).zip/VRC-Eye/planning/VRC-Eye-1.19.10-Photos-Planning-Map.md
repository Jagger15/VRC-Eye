# VRC Eye 1.19.10 — Photos planning and reuse map

**Status: planning and read-only source inspection. No application changes, build, runtime test, or live integration test performed in this review.**

## Basis and scope

The attached **VRC Eye — Expanded Photos System Specification** supplies the requested feature design, its 43 numbered sections, delivery layers, and acceptance criteria. Its optional and future capabilities remain optional/future; including the document does not establish that every integration exists or is verified.

This note maps that document to the existing 1.19.9 archive and the already planned 1.19.10 Social/Accounts, sidebar, resource-monitor, VRCX Companion, downloads, links, and self-invite work. It does not replace either supplied specification or independently verify external product documentation cited by those specifications.

Proposed navigation: **You → VRChat Photos**, available in Casual view as well as Advanced/Developer views. Internal destinations remain **Library, Sessions, Albums, Photo Booth, Review**. This placement is a proposal, not a user-confirmed reorganization. The enlarged/bold section headings and between-section dividers remain the shared sidebar design; there are no dividers between individual category buttons.

## What the source inspection found

### P1 — No dedicated local photo-library workspace found

The inspected navigation and page factory do not contain a VRChat Photos library destination (`ui_navigation.py:7–17,37–94`; `companion_ui.py:275–287`). Project-wide photo/screenshot searches primarily lead to camera/map capture, OSC controls, peer coordination, resource-path settings, and remote profile-image presentation. No implementation of the supplied persistent photo catalog, albums, rendition-aware exports, or privacy-review workspace was found.

This is therefore more than adding controls to an existing gallery. New photo-library capabilities are needed, but the application foundations around them should be reused.

### P2 — There is a reusable, deliberately limited source/capture helper

`camera_capture.py:66–82` reads `picture_output_folder` from a config next to the selected log location and otherwise constructs a Pictures/VRChat fallback. It does not resolve a redirected Windows Pictures known folder or a Proton drive mapping, and it silently falls back for several configuration failures. Those shortcomings matter for the new source-management design.

`camera_capture.py:99–126` scans PNGs in the selected root and immediate child directories, does not recurse directory links, and caps the scan at 20,000 entries. `watch_capture` (`129–175`) waits for newly observed stable files during one capture workflow and then returns. It is not a persistent multi-source ingestion service with reconciliation or durable identity. Preserve its safeguards while consolidating appropriate file-evidence logic into the library service; do not run multiple overlapping watchers for the same approved source.

### P3 — A map preview must not become the authoritative photo original

`camera_capture.py:16–18,178–215` imposes a 32 MiB input limit and a 16 × 1024 × 1024 pixel limit, checks for changed files, and saves with exclusive creation. `camera_dialog.py:16–35` intentionally generates a reduced map image, and `camera_dialog.py:260–304` loads/saves that map workflow.

Keep the map conversion and its safety limits as a specialized consumer. The photo library needs its own bounded original/thumbnail/preview/export representations, and must not import a reduced map copy as the full-quality original. Larger images need a separately tested decode budget rather than globally removing limits. Do not run the map camera preparation preset when merely opening Photos: it is explicitly configured to hide players/UI for map capture (`osc_app.py:397–401`).

### P4 — Preserve the shared OSC controller and bounded capture evidence

`osc_app.py:392–401` already routes camera capture/preset actions through the shared reviewed control service. `osc_controls.py:623–632` records an observed nearby file without claiming the request caused it. A new Photo Booth page should call that existing controller when a supported, explicitly authorized capture action is selected. Timer completion, command transmission, observed file, and confirmed association must remain separate states.

### P5 — Photo coordination exists; full-image transfer is not established by it

`peer_protocol.py:32–62,184–190` defines ready checks, countdowns and `photo.plan`. The photo-plan payload consists of a title and optional shot labels, notes and photographer identifier. It is not a full-resolution image transfer contract.

Reuse coordination and permissions. Any actual image transfer remains a separately implemented capability over the existing networking architecture, with explicit image size/format limits, consent, integrity checks and recipient review. Do not place large image payloads into text-plan, configuration, or diagnostic messages as an improvised workaround.

### P6 — Session history is an existing authority

`player_sessions.py` and `player_history.py` already manage player/session observations, retained encounter sessions, history settings and incognito behavior. Photo links should refer to those session identities, with explicit relationship types and evidence. The photo catalog must not create a second session tracker or rebuild deliberately unretained history.

Account-aware photo associations are dependent on the planned account-context and privacy work; current single-account/global structures should not be described as already satisfying the new specification.

### P7 — Remote profile previews are not a local library service

`profile_images.py:20–34` has an account/revision-scoped in-memory preview cache; `69–85` contains bounded rendering, and later functions perform authenticated remote retrieval. Shared image validation/rendering primitives may be factored carefully, but their remote authentication and host restrictions must not be relaxed, nor imposed on offline local photos. A local folder browser must not require a VRChat login because it reused the wrong class.

### P8 — Photo-specific VRCX ownership needs an extension

`vrcx_companion_model.py:1–18,26–54` explicitly controls VRC Eye's decisions, not VRCX configuration, and has fixed shared ownership categories. It has no per-source photo metadata/rename/move ownership model. Extend this coordinator for the specification's distinct side effects instead of adding a second VRCX detector or claiming that selecting an owner changes VRCX itself.

Resolve the previously audited detection/status issues in the existing repair work. Photo browsing/indexing must continue without VRCX. Suppressing a duplicate save notification must not suppress ingestion.

### P9 — Resource budgets should use the existing monitor work

`resource_core.py` already defines a configured screenshot-drive free-space metric and a `photos_path` setting; this is not a source registry or image scanner. Link approved photo sources to the existing resource service where appropriate without creating another CPU/GPU polling service. Maintain bounded queues and conservative limits even when resource telemetry is unavailable or stale. Sharing jobs and large archive scans must not depend on the disputed health indicator being accurate.

## Consolidation rules across 1.19.10

One logical photo catalog; one approved-source registry; one ingestion owner per physical source; one export/privacy policy for all outgoing renditions. Multiple screens may open these same records and workflows.

Local file operations do not need live VRChat authentication. Reuse journaling, cancellation, progress, and recovery conventions while keeping local file jobs distinct from account-changing remote commands. Online actions go through the planned account-bound command layer; peer transfers use the existing peer transport and permissions, not VRChat credentials.

Photo favorites are photo-catalog state, not remote world/avatar favorites. Session albums and covers are views/references, not copied photos or duplicated session records. Creator attachments reuse existing project/task/diagnostic records. Review is a task queue, not another social inbox.

**Additional integration proposal:** a photo with an established world reference can open the existing world-details page and its planned **Invite Me** workflow. Historical image metadata never becomes proof of current instance access, and opening a photo cannot automatically send an invitation. This proposal is additional to, not a claim quoted from, the supplied photo specification.

## Migration and preservation requirements

Existing map profiles/copies, camera folder choices, OSC routes/grants, peer plans/countdowns, resource settings, and session-history preferences must remain usable. Do not infer missing original photo paths from an embedded map image. An initial import must not rename or move an archive, generate a flood of capture alerts, or grant permission to scan new roots.

Use stable photo identity and independent file/rendition records. Hash equality must not merge private account scopes. Keep file owner, importing workspace, photographer claim, and observed capture context distinct. Moves preserve favorite/album links; shared physical deletion discloses its other dependencies. Missing drives retain catalog entries and are not mistaken for confirmed deletion.

## Complete specification coverage map

The table follows the attachment's numbered headings. “New” means not found as a dedicated photo-library capability in this static review, not that every low-level primitive must be written again. “Extend/reuse” is a design direction, not a verified implementation result.

| Section | Integration plan |
|---|---|
| 1. VRChat Photos tab | New photo workspace; reuse navigation, theme, command palette and accessibility patterns. Five internal destinations, not five competing libraries. |
| 2. Separate photos, files, captures, and versions | New stable capture/photo/representation/location/version relationships within a single photo catalog; originals unchanged by browsing. |
| 3. Configured screenshot-folder discovery | Extend source discovery from the limited camera helper; approved multi-source registry, actual Pictures resolution, explicit config errors. |
| 4. Linux and Proton path handling | New prefix-aware path adapter and approved-root resolution; unavailable mounts retain records; no blanket filesystem permission changes. |
| 5. The screenshot ingestion pipeline | New durable ingestion/reconciliation lifecycle; reuse file-stability evidence; coalesce watchers and exclude managed export loops. |
| 6. Manual import and device imports — additional feature | New reviewed reference-in-place or managed-copy import; device-folder import first; direct device adapters remain later capabilities. |
| 7. Thumbnails | New bounded, disposable, privacy-scoped thumbnail cache; carefully reuse generic image validation rather than authenticated profile retrieval. |
| 8. Preview and full-screen viewing | New viewer with fit/zoom/pan/full-screen/compare; preserve filtered navigation and distinguish originals from derivatives. |
| 9. Favorites | New stable logical-photo favorites; separate from remote favorites and cleanup protection; no copies or moves. |
| 10. Folder organization | New virtual organization and reviewed physical move/rename jobs; collision review, recovery journal and manual locks. |
| 11. Albums and smart albums — additional feature | New manual/smart album references, album covers and saved-query membership; no duplicated physical files. |
| 12. Delete with confirmation | New distinct remove/hide/exclude/trash/permanent actions; layer-aware confirmation, shared-file warnings and partial-failure recovery. |
| 13. Metadata-based organization | New bounded metadata adapters and provenance/conflict storage; external formats require verification; metadata is not verified identity. |
| 14. World, session, and date grouping | New grouping queries over known dates/worlds/sessions; use shared world cache and retain unknown/ambiguous groups. |
| 15. Photo/session relationships | Extend shared session history with photo relationship records and corrections; delayed capture arrival must not select the current world blindly. |
| 16. People relationships without pretending to know who is pictured | New manual people relationships; roster presence never proves who is pictured; reuse known profile links without visual identity matching. |
| 17. Auto-organization | New explainable previewable rules with idempotent actions; virtual changes first; manual locks and privacy override automation. |
| 18. Photo detail panel | New detail panel backed by the same catalog and jobs: overview, context, versions, privacy, evidence and activity. |
| 19. Non-destructive editing — additional feature | New bounded non-destructive editor; shared rendition/export engine; external-editor handoff remains explicit. |
| 20. Multilayer capture support — important missing feature | New conservative multilayer/bundle relationships; explicit layer scope for move/delete/export and independent review of shared layers. |
| 21. Photo booth borders | New static/declarative border templates; originals preserved, safe paths, bounded assets, privacy-aware text and versioned renders. |
| 22. Photo strips, contact sheets, and collages — additional feature | New strips/contact sheets/collage projects referencing catalog images; output rendered via the same export policy. |
| 23. Photo booth sessions and coordinated countdowns — additional feature | Extend existing peer plans, ready checks, countdowns and reviewed OSC capture; no automatic photo or sharing from timer permission. |
| 24. Session cover photo | Extend session presentation with a specific eligible photo/rendition and focal crop; private and public covers can differ. |
| 25. Screenshot privacy scanner | New local review assistant for metadata and optional visible-content/code scanning; explicit unknown/failure/stale states, no privacy guarantee. |
| 26. Redaction tools — additional feature | New manual opaque redaction/removal and transform-aware masks; flattened output excludes original/layers/embedded previews. |
| 27. Export and share preparation — essential additional feature | New single export-policy workflow for edits, borders, clipboard, drag-out and sharing; neutral filenames and final-byte validation. |
| 28. Sharing through existing VRC Eye systems | Extend Social/account command and peer permission architecture; full-image transfer and online publishing remain capability-dependent adapters. |
| 29. Search and filtering | New account/privacy-scoped library search and combined filters; saved queries are smart albums; retained recognized-text search separately opt-in. |
| 30. Duplicate detection and burst grouping | New exact-duplicate and burst/near-duplicate review; visual similarity does not imply identical privacy or authorize deletion. |
| 31. Backup, portability, and library recovery | Extend backup/recovery with catalog/original/template/recipe manifests; distinguish catalog-only from complete backup and verify partial results. |
| 32. Library repair and missing-file recovery | New relink/cache-rebuild/source-health tools; reconcile unfinished jobs, preserve relationships and avoid blanket library resets. |
| 33. Multi-account photo organization | Integrate device sources, account-scoped organization and explicitly shared collections with planned account isolation; encryption stays separately designed. |
| 34. Privacy-mode integration | Extend existing privacy modes across thumbnails, covers, search, queues and notifications; no hidden reconstruction of excluded history. |
| 35. VRCX Companion Mode integration | Extend the one VRCX Companion coordinator with per-source photo side-effect ownership; no private VRCX database edits or dependency. |
| 36. Creator workflows | Extend existing creator playtests, tasks and diagnostics using catalog attachments; no second issue tracker or causality claims from screenshots. |
| 37. Slideshows, memories, and session recaps | New filtered slideshows and recaps using the existing session service; memory resurfacing optional, no surprise notifications. |
| 38. Resource management | Extend shared resource policies; bounded priority queues, pausable heavy work, conservative limits without valid telemetry, measured scale tests. |
| 39. Accessibility and everyday usability | Reuse and extend UI accessibility: keyboard focus, readable states, adjustable density, reduced motion and privacy-safe accessible labels. |
| 40. API, authentication, and risk labels | Use planned capability/risk labels while preserving offline browsing; keep API, filesystem and disclosure impacts distinct. |
| 41. Developer diagnostics and test tooling | Extend Developer diagnostics with a photo pipeline inspector and synthetic fixtures; reports exclude private images/text unless deliberately attached. |
| 42. Recommended implementation sequence | Retain all five delivery layers A–E from the attachment; sequence by dependencies, not permission to start a build. |
| 43. Acceptance criteria that should be tested explicitly | Retain the complete acceptance table; add regressions for existing map capture, shared OSC, peer coordination and authentication separation. |

## Definition of done and dependency order

Preserve the specification's layers: A reliable offline library; B trustworthy context; C non-destructive editing and safe export; D organization/creative workflows; E optional integrations. Account scope, shared privacy rules, reliable source identity and journaled jobs precede cross-account sharing or automatic physical organization. Photo-specific VRCX ownership follows the Companion repair work. Basic library use is never gated on VRCX or on working GPU sensors.

All 43 sections remain in planning coverage. Direct headset/phone browsing, external/cloud analysis, encrypted-library design, optional automatic quality ranking, hosted sharing, online publishing and advanced backup destinations retain their qualified status from the attachment; none are silently promised as implemented 1.19.10 capabilities.

High-priority acceptance cases include duplicate watcher events, partially written files, missed-event recovery, offline drives, Proton custom mappings, metadata conflicts, world transitions, cross-account thumbnail/send isolation, private session covers, transformed redaction masks, hidden-layer/sidecar exclusion, unavailable trash, interrupted file jobs, repeat-safe rules and no dependency on VRCX. Existing map photo behavior must keep its original-preservation, safe cancellation and no-overwrite guarantees.

No tests were run in this planning review. Existing test source files were located; passing behavior on either Windows or Linux is not claimed here.

## Inspection record

- Inspected archive: `VRC-Eye-v1.19.9.zip`
- Regular archive entries: 371.
- SHA-256 before inspection: `dbdd0ed01a0d4e8aac42edc12bc4debc2f4f61007037d367ab5f7846e5adac07`.
- Method: read archive members directly; no extraction, application imports, application execution, network requests, database migration or source edit.

## Selected source evidence

### `ui_navigation.py:7–17`

```text
7: NAV_GROUPS = (
8:     ("Primary", (("Home", "Home"), ("Primary", "Players & avatars"))),
9:     ("Community", (("Feed", "Friend activity"), ("Search", "Search VRChat"),
10:                    ("Favorites", "Favorites"), ("Social", "Social"))),
11:     ("You", (("Wellness", "Wellness"),)),
12:     ("VRC Eye", (("VRC Eye Primary", "Eye-to-Eye"), ("Networking", "Networking"))),
13:     ("Advanced", (("Performance & Security", "Performance & security"),
14:                   ("Crash & Diagnostics", "Crash diagnostics"), ("Unity Player", "Unity Player"),
15:                   ("VRCX Companion", "VRCX Companion"), ("Game Log", "Game log"),
16:                   ("Developer", "Developer / Black Lab"))),
17: )
```

### `companion_ui.py:275–287`

```text
275:     def ensure_page(self, name):
276:         if name not in self.frames:
277:             from companion_pages import FeedPage, GameLogPage, SearchPage, FavoritesPage, SocialPage
278:             from wellness_ui import WellnessPage
279:             from resource_ui import ResourcePage
280:             from crash_ui import CrashPage
281:             from unity_ui import UnityPage
282:             from vrcx_companion_ui import VrcxCompanionPage
283:             from peer_ui import VrcEyePrimaryPage
284:             from peer_network_ui import NetworkingPage
285:             from friendly_ui import HomePage, SettingsPage
286:             from developer_ui import DeveloperPage
287:             classes = {"Developer": DeveloperPage, "Home": HomePage, "Settings": SettingsPage, "Feed": FeedPage, "Game Log": GameLogPage, "Search": SearchPage, "Favorites": FavoritesPage, "Social": SocialPage, "Wellness": WellnessPage, "Performance & Security": ResourcePage, "Crash & Diagnostics": CrashPage, "Unity Player": UnityPage, "VRCX Companion": VrcxCompanionPage, "VRC Eye Primary": VrcEyePrimaryPage, "Networking": NetworkingPage}
```

### `camera_capture.py:66–82`

```text
66: def default_photo_folder(log_path: Path) -> Path:
67:     fallback = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Pictures" / "VRChat"
68:     directory = log_path.parent if log_path.is_file() else log_path
69:     try:
70:         with (directory / "config.json").open("rb") as stream:
71:             raw = stream.read(1024 * 1024 + 1)
72:         if len(raw) > 1024 * 1024:
73:             return fallback
74:         data = json.loads(raw)
75:         value = data.get("picture_output_folder") if isinstance(data, dict) else None
76:         if isinstance(value, str) and value.strip() and "\0" not in value:
77:             candidate = Path(os.path.expandvars(value)).expanduser()
78:             if candidate.is_absolute():
79:                 return candidate
80:     except (OSError, ValueError, RecursionError):
81:         pass
82:     return fallback
```

### `camera_capture.py:99–126`

```text
99: def scan_photos(folder: Path) -> dict[Path, PhotoFile]:
100:     """Read the selected folder and one level of date folders; never recurse links."""
101:     if not folder.exists():
102:         return {}  # VRChat may create the directory when taking the first photo.
103:     result = {}
104:     directories = [folder]
105:     count = 0
106:     for directory in directories:
107:         with os.scandir(directory) as entries:
108:             for entry in entries:
109:                 count += 1
110:                 if count > MAX_ENTRIES:
111:                     raise CameraError("Too many files to watch. Choose the current YYYY-MM photo folder instead.")
112:                 if directory == folder and entry.is_dir(follow_symlinks=False):
113:                     directories.append(Path(entry.path))
114:                 elif entry.name.lower().endswith(".png") and entry.is_file(follow_symlinks=False):
115:                     try:
116:                         path = Path(entry.path)
117:                         result[path] = PhotoFile.inspect(path, entry.stat(follow_symlinks=False))
118:                     except FileNotFoundError:
119:                         continue
120:     return result
121: 
122: 
123: def stable_new_photos(baseline: dict, previous: dict, current: dict) -> tuple[PhotoFile, ...]:
124:     return tuple(sorted((record for path, record in current.items()
125:                          if path not in baseline and record.size > 0 and previous.get(path) == record),
126:                         key=lambda record: (record.modified_ns, str(record.path)), reverse=True))
```

### `camera_capture.py:172–183`

```text
172: def watch_shared_capture(folder: Path, trigger: bool, output, stop: threading.Event,
173:                          timeout: float = 45., interval: float = .5):
174:     """Observe a photo while the UI thread owns shared-service submission."""
175:     watch_capture(folder, None, trigger, output, stop, timeout, interval, shared_trigger=True)
176: 
177: 
178: def png_dimensions(data: bytes) -> tuple[int, int]:
179:     if len(data) < 24 or len(data) > MAX_PHOTO_BYTES or not data.startswith(PNG_HEADER) or data[12:16] != b"IHDR":
180:         raise CameraError("Choose a complete PNG photo no larger than 32 MiB.")
181:     width, height = struct.unpack(">II", data[16:24])
182:     if not 1 <= width <= 8192 or not 1 <= height <= 8192 or width * height > MAX_PHOTO_PIXELS:
183:         raise CameraError("Photo is too large. Choose 2160p / 4K or lower in VRChat and take another photo.")
```

### `camera_dialog.py:16–35`

```text
16: def make_map_png(data, tk, parent):
17:     """Decode using the same native Tk engine as the map; downsample large photos.
18: 
19:     This changes image resolution only. It does not rectify perspective or
20:     remove roofs/occluders, and never modifies the original camera file.
21:     """
22:     width, height = png_dimensions(data)
23:     photo = tk.PhotoImage(data=base64.b64encode(data).decode("ascii"), master=parent)
24:     if (photo.width(), photo.height()) != (width, height):
25:         raise CameraError("Decoded image dimensions do not match the PNG header.")
26:     factor = reduction_factor(width, height)
27:     reduced = photo.subsample(factor) if factor > 1 else photo
28:     if factor > 1 or len(data) > MAX_IMAGE:
29:         with tempfile.TemporaryDirectory(prefix="vrc-eye-photo-") as folder:
30:             file = Path(folder) / "map.png"
31:             reduced.write(str(file), format="png")
32:             with file.open("rb") as stream:
33:                 data = stream.read(MAX_IMAGE + 1)
34:     image_dimensions(data)
35:     return data, reduced
```

### `osc_app.py:392–401`

```text
392:     def camera_capture(self, owner="manual-camera", delay=0):
393:         self.ensure_active()
394:         result = self.controls.execute(self.controls.review("camera.capture", owner=owner, countdown=delay))
395:         return dict(result, id=result["action_id"])
396: 
397:     def camera_prepare(self, owner="world-map"):
398:         self.ensure_active()
399:         values = {"Mode": 1, "Environment": True, "GreenScreen": False,
400:                   "LocalPlayer": False, "RemotePlayer": False, "ShowUIInCamera": False}
401:         return self.controls.execute(self.controls.review("camera.preset", owner=owner, settings=values))
```

### `osc_controls.py:623–632`

```text
623:     def observe_capture_file(self, path, *, capture_id=None):
624:         """Record selected-folder evidence without claiming causal attribution."""
625:         name = str(path).replace("\\", "/").rsplit("/", 1)[-1]
626:         _text(name, 255, "capture filename")
627:         choices = [row for row in self._captures if row.get("sent_at") is not None and (capture_id is None or row["id"] == capture_id)]
628:         if not choices:
629:             return None
630:         row = choices[-1]
631:         row.update(file=name, status="file_observed", detail="A nearby photo file was observed; it may have been triggered by another control")
632:         return deepcopy(row)
```

### `peer_protocol.py:184–190`

```text
184:     "party.snapshot": ({"party_id": _id, "revision": _revision, "title": _title},
185:                        {"members": _list(_id, 32), "roles": _roles, "current_destination": _world,
186:                         "next_destination": _world, "notes": _body, "host": _id}),
187:     "ready.request": ({"request_id": _id, "prompt": _title, "deadline": _number}, {"recipients": _list(_id, 32)}),
188:     "ready.response": ({"request_id": _id, "state": _enum("READY", "NOT_READY", "DECLINED")}, {}),
189:     "countdown.start": ({"countdown_id": _id, "target_at": _number}, {"title": _title}),
190:     "photo.plan": ({"title": _title}, {"shots": _list(_title, 40), "notes": _body, "photographer": _id}),
```

### `vrcx_companion_model.py:1–18`

```text
1: """Local, process-aware VRCX ownership decisions; no VRCX protocol is implied.
2: 
3: The resolver controls VRC Eye's presentation and actions only. Observing a
4: process is not evidence that a VRCX feature is enabled or functioning.
5: """
6: from collections import deque
7: from copy import deepcopy
8: import math
9: 
10: 
11: SHARED = ('SOCIAL', 'ACCOUNT', 'SESSION', 'PRESENCE', 'LAUNCH', 'RESTART')
12: PROTECTED = ('RUNTIME', 'SAFETY', 'DIAGNOSTIC', 'SYSTEM', 'CORE')
13: CATEGORIES = SHARED + PROTECTED
14: OWNERS = ('VRC_EYE', 'VRCX')
15: PRESETS = ('Balanced', 'VRCX Primary', 'VRC Eye Primary')
16: VIEWS = ('Casual', 'Advanced', 'Developer')
17: DECLARATIONS = ('on', 'off', 'unknown')
18: STATES = ('DISABLED', 'RUNNING', 'ABSENT', 'UNKNOWN', 'AMBIGUOUS', 'STALE')
```

### `profile_images.py:20–34`

```text
20: def cached_preview(client,url,data=None):
21:     """Account/revision-scoped LRU: at most 32 decoded previews and 8 MiB, memory only."""
22:     scope=(client.user_id,client.session_revision)
23:     with _CACHE_LOCK:
24:         if getattr(client,"_preview_scope",None)!=scope:
25:             client._preview_scope=scope;client._preview_cache=OrderedDict()
26:         cache=client._preview_cache;now=client.clock()
27:         for key,(at,_) in tuple(cache.items()):
28:             if not 0<=now-at<300:cache.pop(key,None)
29:         if data is not None:
30:             if len(data)<=LIMIT:cache[url]=(now,data);cache.move_to_end(url)
31:             while len(cache)>32 or sum(len(value[1]) for value in cache.values())>LIMIT:cache.popitem(last=False)
32:             return data
33:         if url in cache:cache.move_to_end(url);return cache[url][1]
34:         return None
```
