# VRC Eye: optional VRCX replacement

Recorded October 3, 2026, after the 1.21.0 Development 1 source checkpoint.

## Product requirement

The user wants VRC Eye to serve as a standalone VRCX replacement for people who choose it, as well as remain an optional companion for people who use both. Core workflows must not require VRCX to be installed, running or logged in. Optional import and coexistence tools remain useful, but are not substitutes for native features.

This records the direction and current gaps. It does not change the released ZIP or claim that the gaps have been implemented.

## Comparison boundary

This review compares the delivered VRC Eye 1.21.0 Development 1 code and its feature documents with the supplied VRCX 2026.09.16 source, including its README feature list. It is not an exhaustive audit of every VRCX control or a live-service compatibility certification. Existing implementation and native/live acceptance are separate statuses.

## Standalone capabilities already implemented

| Area | Current VRC Eye capability | Remaining qualification |
| --- | --- | --- |
| VRChat connection | Own authentication, two-factor flow, remembered username and optional protected Windows password, confirmed account header | One active authenticated session; no retained multi-account session vault; non-Windows password storage remains unavailable |
| Friends and activity | Friends lists, explicit live friend WebSocket feed, stored observed changes, optional cycling profile/group snapshots | Friend packets only; missed events are not replayed; reconnect and snapshot reconciliation require user action |
| Profile changes | Observed name, bio, status, shared location and available avatar/picture changes; newly visible groups | Observation history is not complete historical data or proof of an exact group-join date |
| Social actions | Friend requests/removal, accept/decline, own mute/block actions, group-invite actions, reviewed notification read/hide | Legacy notification inbox refresh is manual; NotificationV2 and a complete live notification service remain absent |
| Invitations | Send invite, request invite, respond to returned invite requests, inspect destinations, create supported instances and self-invite | Ordinary-invite response, message-slot editing, photo attachments and direct automatic joins remain incomplete |
| Search | Users/worlds/groups API search, exact IDs, scoped avatar collections, saved/recent searches | No unified VRCX-style fuzzy index across all local entity types; avatar-name filters apply to loaded collections |
| Favorites | Native local collections, local backup/import, actual VRChat favorite-list reads and reviewed add/remove | Legacy local collections are shared on the computer; imported VRCX groups use separate tables; full unified local management and remote favorite-group create/rename/reorder/visibility controls remain incomplete |
| Logs and current session | Local roster and game-log views; world/player/avatar events, video URLs, images, errors and explicit crash markers | Not a migration of VRCX history and not proof of complete historical/session analytics |
| Player/session history | Observed encounters, time together, local notes and retained history | Existing observations are not complete retrospective friendship history; some older encounter stores are shared locally |
| Photos | Library, thumbnails, previews, favorites/albums, opt-in folder polling, manual world/session links, edits and metadata-free exports | Reading screenshot metadata does not automatically adopt it or write world/session metadata into new screenshots |
| Status/profile tools | Own status/status-description/pronoun editing and local status presets | Presets fill a reviewed draft; they are not imported VRCX presets |
| Owned avatars | Uploaded-avatar browsing and reviewed name/description/visibility/author-tag changes; native Avatar Library | Avatar/world image uploads and a complete ordinary-user content-management workflow remain unfinished; separate Developer API tools are not a replacement UI |
| Launch and diagnostics | Reviewed launch/recovery requests, runtime/crash diagnostics | No automatic companion-app launcher or crash-restart-and-rejoin engine |

These native capabilities do not require VRCX. API-dependent features require Eye's own VRChat session. Live VRChat/VRCX acceptance and native Windows testing were not established by this build's fixture tests.

## Optional VRCX interoperability already implemented

| Integration | Actual scope |
| --- | --- |
| Process observation/coexistence | Optional process presence, Eye-side ownership preferences, banner suppression and diagnostics. It is not authenticated coordination with VRCX. |
| Avatar-cache browsing | Explicit selected read-only VRCX database access and cached observations. A saved database can be inspected without VRCX running. |
| CSV import | Known avatar/world/friend export shapes plus custom-column preview and mapping; reviewed imports into local Eye records. |
| Favorite-group import | Local favorite folders/groups and their avatar/world/friend memberships, with deduplication and selected shared/account scope. These are not VRChat community-group memberships. |
| Avatar/tag observations | Selected cached avatar metadata and local VRCX tags preserved separately from current API authority and author tags. These are not automatically merged into Avatar Library. |
| Screenshot metadata | Explicit PNG VRCX JSON schema-1 and VRChat XMP inspection, provenance/conflicts and hidden sensitive fields. |
| Detail handoff | Reviewed exact user/world/avatar/group detail request through a registered VRCX URI handler. This action does require an installed handler and VRCX's own login; delivery is not acknowledged. |
| Export | ID-only favorites export for manual interchange. It does not round-trip imported group structures, names, notes or tags. |

## Significant replacement gaps

1. **Reliable live social notifications:** NotificationV2, full notification-event handling, reconnect/backoff and explicit reconciliation, durable notification history and configurable delivery. Preserve the already implemented live friend feed rather than replace it with a second unrelated connection.
2. **Complete migration and unified native data:** Friend memos/notes, user/world/avatar notes, avatar-use observations, social/game/session/video history, VRCX status presets/settings and photo index/metadata-cache migration. Integrate imported group/tag observations with native favorites/catalog management. Empty favorite groups and VRCX print favorites are not currently migrated.
3. **Discord Rich Presence:** No Eye publisher exists. The companion ownership row is only a preference.
4. **Social VR overlay:** Existing creator OpenVR integration does not provide VRCX's configurable live social/event feed overlay. The replacement overlay remains work.
5. **Automation:** Optional startup-app launching, crash restart and last-instance recovery with explicit controls and observed outcome handling.
6. **Dashboard and activity analysis:** Configurable multi-widget dashboards, a unified fuzzy quick search, activity heatmaps and broader friendship/session analytics. Existing encounters, time-together records, notes and feed/history/log views remain useful foundations.
7. **Broader content/group management:** Avatar/world image uploads, complete normal-user world management, group roles/member/moderation workflows and reviewed moderation-ban import. Low-level Developer operations should not be counted as finished everyday workflows.
8. **Accounts:** Retained account sessions, convenient switching and consistent account isolation across older stores as well as new integrations.
9. **Photo context automation:** Automatically correlate new screenshots with observed world/session context and optionally embed compatible metadata while preserving originals and privacy choices.
10. **Service health and desktop acceptance:** VRChat service-status integration and task-based Windows/Linux validation of the replacement workflows.

## Proposed delivery order

This order is a recommendation, not a claim that the user selected every subfeature or that implementation has begun.

1. Strengthen the live friend/notification lifecycle and native account/data boundaries.
2. Unify native favorite groups, notes and avatar records; provide a reviewed migration wizard that remains useful after VRCX is removed.
3. Complete everyday invite/join/profile/content workflows and service-health feedback.
4. Add Discord presence, the social VR overlay and opt-in launch/recovery automation.
5. Expand dashboards, activity analysis, photo automation and advanced group tools.

Acceptance should include a clean machine with VRCX absent, then a separate coexistence test with both apps. A read-only import or Open in VRCX button does not satisfy native replacement acceptance.

## Code and document evidence

- `friend_feed.py`, `feed_ui.py`: native live friend connection, snapshots and change history.
- `companion_pages.py`, `favorites_ui.py`, `account_local_121.py`: search, favorites, status presets and saved searches.
- `social_workspace_ui.py`, `social_outbound.py`, `SOCIAL_ACCOUNTS_1_20.md`, `SOCIAL_AVATARS_1_20_DEV7.md`: implemented social/account workflows and limits.
- `game_log.py`, `photo_ui.py`, `photo_metadata.py`, `photo_watch.py`: native logs/photos and metadata-reading boundary.
- `player_sessions.py`, `player_history.py`: existing encounters, time-together observations and history.
- `vrcx_exchange.py`, `vrcx_csv.py`, `vrcx_sources.py`, `vrcx_local.py`, `vrcx_local_ui.py`, `vrcx_handoff.py`: migration, imported records and handoff boundaries.
- `vrcx_companion_ui.py`, `VRCX_COMPANION_SETUP.md`: coexistence and absent publisher/automatic-recovery capabilities. Historical setup instructions are not current version instructions.
- `creator_integrations.py`: existing creator-focused OpenVR provider; not the planned general social overlay.
- `IMPLEMENTATION_STATUS_1_21.md`, `BUILD_VALIDATION.json`: current checkpoint scope and validation limits.
- Supplied `VRCX-2026.09.16/README.md`: comparison feature list.
