# VRC Eye 1.19.10 — World self-invite source check

Inspection date: October 2, 2026.

## Scope and result

Inspected the mounted `VRC-Eye-v1.19.9.zip` read-only. No application code was changed, no release was built, and no live account request or invitation was sent. This was source inspection, not an execution or compatibility test.

No dedicated world-browser self-invite control or executable self-invite API operation was found. The world-search UI currently offers website opening and local favorites, among other non-self-invite controls. The Social page invitation handler is for incoming friend requests and group membership invitations. The developer catalog contains executable instance inspection and personal instance creation operations, but its ordinary instance-invitation entry is explicitly reference-only.

## Evidence from the baseline

### World search controls

`VRC-Eye/companion_pages.py`, lines 25–38.

```text

25:         choice(self, row, self.kind, ("Users", "Worlds", "Groups", "Avatars"), self.reset)

26:         entry(self, row, self.query, 35); button(self, row, "Search / load", lambda: self.search(0))

27:         row = line(self)

28:         choice(self, row, self.scope, ("Public / featured", "My uploads", "My avatar favorites"), self.reset)

29:         button(self, row, "Previous", lambda: self.page(-1)); button(self, row, "Next", lambda: self.page(1))

30:         button(self, row, "Search avatars…", self.app.search_avatars)

31:         note(self, "Users, worlds and groups support API name search or exact IDs. Avatar names filter the current collection page; use Next for later pages. Avatar scopes are your uploads, favorites or featured. Exact avtr_ IDs are also supported.")

32:         self.table = Table(self, parent, (("name", "Name", 210), ("detail", "Details", 260), ("id", "ID", 360)), select=self.selection)

33:         self.ttk.Label(parent, textvariable=self.detail, wraplength=1020).pack(anchor="w", pady=5)

34:         row = line(self)

35:         button(self, row, "Open VRChat page", lambda: self.open_item(self.table.selected()))

36:         button(self, row, "Player profile…", lambda: self.profile(self.table.selected()))

37:         button(self, row, "Save VRC Eye favorite…", lambda: self.favorite(self.table.selected()))

38:         button(self, row, "Avatar VRCA…", self.download)

```


### Existing invitation control is not a world self-invite

`VRC-Eye/companion_pages.py`, lines 157–166.

```text

157:     def invite(self, accept):

158:         client = self.connected(); result, row = self.result, self.table.selected()

159:         if not result or result.kind not in ("friend-requests", "group-invites"): raise ValueError("Load Friend requests or Group invites and select an invite.")

160:         api.selected_record(client, result, row, result.kind)

161:         if self.job: raise ValueError("Wait for or cancel the current task first.")

162:         target = self.row_entity(row); action = ("accept" if accept else "decline") + ("-friend" if result.kind == "friend-requests" else "-group")

163:         expected = self.context()

164:         if not self.confirm("Review invitation", f"{action.replace('-', ' ').title()} invitation\n\n{target.name}\n{target.id}\n\nSubmit to VRChat?"): return

165:         if expected != self.context(): raise ValueError("Account changed. Review again.")

166:         self.start(lambda c,s,p: api.mutate(c, action, result=result, row=row, stop=s, progress=p), self.status.set, mutation=True)

```


### Existing browser handoff

`VRC-Eye/companion_ui.py`, lines 157–159.

```text

157:     def open_item(self, record):

158:         if not record: raise ValueError("Select an item first.")

159:         webbrowser.open(page_url(record.kind, record.id))

```


### Reusable instance operations

`VRC-Eye/developer_catalog.py`, lines 203–209.

```text

203:     read('instance.get', 'Inspect an explicit instance', 'Instances', 'instances/{worldId}:{instanceId}',

204:          {'worldId': W, 'instanceId': INSTANCE}, slug='get-instance', notes='Only a supplied instance reference. No hidden-location discovery.')

205:     write('instance.create', 'Create a personal test instance', 'Instances', 'POST', 'instances', body={

206:           'worldId': W, 'type': enum('private', 'friends', 'hidden', 'public', required=True, example='private'),

207:           'region': enum('us', 'use', 'eu', 'jp', required=True), 'ownerId': ident('usr', 'userId', required=False)},

208:           risk='instance creation', preflight='world.get', slug='create-instance',

209:           notes='Personal instances only in this adapter. Creation is not a join request or proof of arrival.')

```


### Ordinary instance invitation is reference-only

`VRC-Eye/developer_catalog.py`, lines 279–285.

```text

279:     # Registration metadata is visible without providing an unsafe generic live executor.

280:     for key, title, route, method, family, slug in (

281:         ('reference.group-role', 'Group role assignment (roadmap)', 'groups/{groupId}/members/{userId}/roles/{roleId}', 'PUT', 'Groups', 'add-group-member-role'),

282:         ('reference.invite', 'Send an instance invitation (roadmap)', 'invite/{userId}', 'POST', 'Social', 'invite-user'),

283:         ('reference.world-tags', 'Creator tag editing (roadmap)', 'worlds/{worldId}/tags', 'POST', 'Worlds', 'add-world-tags')):

284:         ops.append(Operation(key, title, family, method, route, risk='reference only', source_slug=slug, live=False,

285:                              notes='Not executable. Kept visible so documentation coverage is not confused with implemented support.'))

```


### Catalog documentation explicitly excludes execution

`VRC-Eye/DEVELOPER_CAPABILITIES.md`, lines 94–102.

```text

94: ## Reference-only entries

95: 

96: These definitions do not dispatch in Live or Sandbox. A reference listing is not an implemented action.

97: 

98: | Key | Proposed operation | Reference |

99: |---|---|---|

100: | `reference.group-role` | Group role assignment (roadmap) | [Reference](https://vrchat.community/reference/add-group-member-role) |

101: | `reference.invite` | Send an instance invitation (roadmap) | [Reference](https://vrchat.community/reference/invite-user) |

102: | `reference.world-tags` | Creator tag editing (roadmap) | [Reference](https://vrchat.community/reference/add-world-tags) |

```


### Personal instance ownership constraints

`VRC-Eye/developer_service.py`, lines 192–196.

```text

192:         if op.key == 'instance.create':

193:             if req['body'].get('ownerId', account) != account:

194:                 raise ValueError('A personal test instance cannot be created under another account’s ownership.')

195:             if req['body']['type'] != 'public' and 'ownerId' not in req['body']:

196:                 raise ValueError('A non-public personal instance requires ownerId set to your connected account.')

```


## Search cross-check

Scanned 342 Python, Markdown, JSON, and text files for common self-invite names and the dedicated self-invite route fragment. Matching files: none. Also inspected ordinary invite references, world-search controls, and developer operation dispatch definitions. A text search alone is not a live-functionality test.

## Planned addition — not implemented

Add an “Invite Me” action to world-search results and shared world details, with the same action available from world favorites/bookmarks and appropriate history views. Resolve a permitted existing instance, or explicitly create a permitted personal instance before self-inviting. Reuse instance inspection/creation and the existing shared transport while adding the missing dedicated self-invite operation to the account-bound Social command system. Keep instance creation and invitation outcomes separate, prevent duplicate submissions, and never silently join, launch, bypass access restrictions, or switch accounts.

## Archive integrity

Archive SHA-256: `dbdd0ed01a0d4e8aac42edc12bc4debc2f4f61007037d367ab5f7846e5adac07`.

The archive hash was unchanged after this source check.
