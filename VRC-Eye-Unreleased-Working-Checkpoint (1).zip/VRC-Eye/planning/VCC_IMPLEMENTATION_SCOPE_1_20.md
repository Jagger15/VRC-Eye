# Selective VCC scope carried into 1.20

The user explicitly authorized implementation on October 2, 2026. Preserve the
previous proposals as requirements, not as claims that they are all now delivered.

Approved direction includes project discovery/catalog and avatar/world associations;
exact editor/dependency evidence; reviewed restore/update/migration with recovery
and concurrency controls; templates; modular VRC Eye Unity packages; optional
local-only Unity helper/pairing/reporting with per-project grants; and optional
capability-based external tool adapters, including a separately reviewed vrc-get
path. VRC Eye does not replace VCC or the existing standalone creator tools.

Discovery stays read-only and approved-root scoped. No silent installs, global
configuration rewrites, automatic script execution or publishing follows from
linking a project. Restore and update remain distinct. Missing drives are retained;
platform capabilities and unavailable integrations are explicit. App dependency
maintenance and project package maintenance are separate systems.

Development checkpoint 1 implements the subset and qualifications listed in
`../IMPLEMENTATION_STATUS_1_20.md` and `../VCC_INTEGRATION_1_20.md`. In particular,
copy-only CLI jobs, manual Editor Core report exchange and a source package are
not the complete reviewed in-place workflow or live Unity bridge.
