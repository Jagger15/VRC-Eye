"""Shared local reference/report workspace, reachable from existing feature pages."""
import json
from companion_ui import Table, button, choice, entry
from friendly_ui import flow_line as line, ScrollPane
from vrcx_ui_jobs import LocalPage
import metadata_reference as metadata
import avatar_performance_report as performance
import media_error_reference as media

TABS=('Metadata reference','Avatar performance','Media errors')


def show(shell, tab=TABS[0], *, avatar_id='', owner_guard=None):
    from vrcx_exchange import active
    from account_header import private
    active(shell.app)
    if private(shell.app):raise ValueError('Reveal private information before inspecting reports.')
    if owner_guard:owner_guard()
    old=getattr(shell.app,'inspection_reports_window',None)
    if old is not None and not old.closed:old.close()
    window=ReportsDialog(shell,tab,avatar_id=avatar_id,owner_guard=owner_guard)
    shell.app.inspection_reports_window=window
    return window


class ReportsDialog(LocalPage):
    def __init__(self,shell,tab=TABS[0],*,avatar_id='',owner_guard=None):
        self.expected_avatar=avatar_id;self.owner_guard=owner_guard;self.invalid_context=False
        self.reference=None;self.performance=None;self.baseline=None;self.media_report=None;self.preview=None
        self.metadata_comparison=None;self.metadata_bookmarks={}
        self.type_offset=0;self.member_offset=0;self.selected_type=None;self.comparison=None;self._log_entries={}
        app=shell.app;self.window=app.tk.Toplevel(app.root);self.window.title('VRC Eye — local inspection reports')
        self.window.geometry('1100x800');self.window.minsize(720,540)
        self.viewport=ScrollPane(app,self.window,min_width=670)
        super().__init__(shell,self.viewport.body,'Local inspection reports',task_controls=False)
        self.setup_privacy()
        row=line(self);button(self,row,'Cancel current task',self.cancel);button(self,row,'Clear loaded reports',self.clear)
        button(self,row,'Close',self.close)
        self.note(self.parent,'Open a local reference pack or report. Loaded content stays in this window. Declaration bookmarks save locally for this account and exact pack; export reports deliberately to keep a copy.')
        self.tabs=self.ttk.Notebook(self.parent);self.tabs.pack(fill='both',expand=True)
        self.frames={}
        for title in TABS:
            frame=self.ttk.Frame(self.tabs,padding=8);self.tabs.add(frame,text=title);self.frames[title]=frame
        self.build_metadata();self.build_performance();self.build_media()
        self.tabs.select(self.frames[tab if tab in TABS else TABS[0]])
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(200,self.tick)

    def note(self,parent,value):
        from ui_theme import responsive_wrap
        kw={'textvariable':value} if hasattr(value,'get') else {'text':value}
        responsive_wrap(self.ttk.Label(parent,wraplength=980,justify='left',**kw)).pack(anchor='w',fill='x',pady=5)

    def text_box(self,parent,height=10):
        frame=self.ttk.Frame(parent);frame.pack(fill='both',expand=True)
        box=self.tk.Text(frame,height=height,width=45,wrap='word',state='disabled')
        scrollbar=self.ttk.Scrollbar(frame,orient='vertical',command=box.yview)
        box.configure(yscrollcommand=scrollbar.set);scrollbar.pack(side='right',fill='y');box.pack(fill='both',expand=True)
        return box

    @staticmethod
    def put(box,value):
        box.configure(state='normal');box.delete('1.0','end')
        box.insert('1.0',value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False))
        box.configure(state='disabled')

    def require(self):
        self.ready()
        if self.invalid_context or self.context()!=self.account:raise ValueError('Context changed. Reopen the reports window.')
        if self.owner_guard:self.owner_guard()

    def checked(self,token):self.require();self.verify(token)

    def start(self,work,done,**kwargs):
        self.require()
        def publish(value):
            # Owner selection/privacy is a UI concern; recheck it on the main
            # thread after the worker slot has been cleared by Page.tick.
            self.require();done(value)
        return super().start(work,publish,**kwargs)

    def clear(self):self.invalidate()

    def clear_preview(self):
        self.reference=None;self.performance=None;self.baseline=None;self.media_report=None;self.preview=None
        self.metadata_comparison=None;self.metadata_bookmarks={}
        self.selected_type=None;self.comparison=None;self.member_offset=0;self.type_offset=0;self._log_entries={}
        if hasattr(self,'types'):
            for table in (self.types,self.members,self.performance_table,self.error_table):table.set([],lambda r:())
            for value in (self.metadata_status,self.performance_status,self.media_status):value.set('No report loaded.')
            for box in (self.type_detail,self.performance_detail,self.error_detail):self.put(box,'')
            self.assembly.set('All');self.assembly_choice.configure(values=('All',))
            self.query.set('');self.code.set('');self.build.set('Unknown')
            if hasattr(self,'bookmark_choice'):self.bookmark_choice.configure(values=());self.bookmark.set('');self.metadata_changes.set([],lambda r:())

    def account_changed(self):self.invalid_context=True

    def tick(self):
        if self.closed:return
        if self.owner_guard:
            try:self.owner_guard()
            except (ValueError,OSError):
                if not self.invalid_context:self.invalid_context=True;self.invalidate()
        self.tick_job()
        if not self.closed:self.timer=self.app.root.after(200,self.tick)

    def close(self):
        if self.closed:return
        if hasattr(self,'timer'):self.app.root.after_cancel(self.timer)
        super().close();self.clear_preview();self.window.destroy()

    def choose_file(self,title):
        self.require();token=self.token()
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.window,title=title,filetypes=[('JSON report','*.json')])
        self.checked(token);return path

    def save(self,document,name):
        self.require();token=self.token()
        from creator_projects_ui import review_document
        from tkinter import filedialog
        from photo_organize import publish
        from pathlib import Path
        payload=json.dumps(document,ensure_ascii=False,indent=2,allow_nan=False)
        if not review_document(self.app,'Review local report export',payload,accept='Choose destination'):return
        self.checked(token)
        path=filedialog.asksaveasfilename(parent=self.window,title='Save a new report',initialfile=name,defaultextension='.json',confirmoverwrite=False)
        self.checked(token)
        if path:
            publish(Path(path),payload.encode('utf-8'),lambda:self.checked(token))
            self.status.set('Reviewed report exported. Existing files were not replaced.')

    def build_metadata(self):
        frame=self.frames[TABS[0]];row=line(self,frame)
        button(self,row,'Open extracted reference folder…',self.choose_metadata)
        button(self,row,'Check selected game DLL…',self.check_dll)
        self.metadata_status=self.tk.StringVar(value='Choose the extracted 1919-style pack containing global-metadata-v31.dat and its native-type map.')
        self.note(frame,self.metadata_status)
        row=line(self,frame);self.query=self.tk.StringVar();self.assembly=self.tk.StringVar(value='All');self.kind=self.tk.StringVar(value='All')
        self.ttk.Label(row,text='Type name').pack(side='left');entry(self,row,self.query,28)
        self.assembly_choice=choice(self,row,self.assembly,('All',),width=30)
        choice(self,row,self.kind,('All','Enum','Type'),width=10);button(self,row,'Search',lambda:self.search(0))
        self.types=Table(self,frame,(('assembly','Assembly',240),('name','Type',460),('kind','Kind',80)),height=8,select=self.select_type)
        row=line(self,frame);button(self,row,'Previous types',lambda:self.search(max(0,self.type_offset-100)))
        button(self,row,'Next types',lambda:self.search(self.type_offset+100));button(self,row,'Inspect base type',self.follow_parent)
        self.type_detail=self.text_box(frame,5)
        self.members=Table(self,frame,(('kind','Member',90),('name','Name / arguments',420),('type','Type / result',280),('value','Constant / accessor',160)),height=9)
        row=line(self,frame);button(self,row,'Previous members',lambda:self.member_page(-1));button(self,row,'Next members',lambda:self.member_page(1))
        button(self,row,'Export selected declaration page…',self.export_type)
        row=line(self,frame);button(self,row,'Bookmark declaration',self.bookmark_type);button(self,row,'Remove bookmark',self.remove_bookmark)
        self.bookmark=self.tk.StringVar();self.bookmark_choice=choice(self,row,self.bookmark,(),self.open_bookmark,width=35)
        row=line(self,frame);button(self,row,'Compare with another pack…',self.compare_metadata);button(self,row,'Export pack comparison…',self.export_metadata_comparison)
        self.metadata_changes=Table(self,frame,(('state','Change',130),('assembly','Assembly',200),('name','Declaration',430)),height=5)
        self.note(frame,'Declarations only. Following a base type shows inherited declarations separately. Private/public access and runtime compatibility are not established by accessor presence. ZIP/7z extraction is performed outside Eye; no supplied scripts or DLLs are launched.')

    def choose_metadata(self):
        self.require();token=self.token()
        from tkinter import filedialog
        path=filedialog.askdirectory(parent=self.window,title='Select the extracted metadata reference folder')
        self.checked(token)
        if not path:return
        self.reference=None;self.selected_type=None;self.types.set([],lambda r:());self.members.set([],lambda r:());self.put(self.type_detail,'')
        self.metadata_status.set('Loading selected reference…')
        def done(value):
            self.reference=value;self.preview=value
            self.assembly.set('All');self.assembly_choice.configure(values=('All',)+tuple(sorted(set(value.owners))))
            self.query.set('');self.kind.set('All');self.search(0)
            self.refresh_bookmarks();self.metadata_comparison=None;self.metadata_changes.set([],lambda r:())
        self.start(lambda client,stop,progress:metadata.load(path,stop=stop,progress=progress),done)

    def bookmark_owner(self):
        self.require()
        if self.reference is None:raise ValueError('Load a metadata reference first.')
        from metadata_workspace import Bookmarks
        from dashboard_actions import workspace
        return Bookmarks(self.shell.store),workspace(self.app)

    def refresh_bookmarks(self):
        owner,account=self.bookmark_owner();rows=owner.rows(account,self.reference)
        self.metadata_bookmarks={str(n+1)+'. '+row['label']:row for n,row in enumerate(rows)}
        self.bookmark_choice.configure(values=tuple(self.metadata_bookmarks));self.bookmark.set('')

    def bookmark_type(self):
        owner,account=self.bookmark_owner()
        if self.selected_type is None:raise ValueError('Select a declaration first.')
        owner.save(account,self.reference,self.selected_type);self.refresh_bookmarks();self.status.set('Declaration bookmarked for this account and exact reference pack.')

    def remove_bookmark(self):
        owner,account=self.bookmark_owner()
        if self.selected_type is None:raise ValueError('Select a declaration first.')
        owner.remove(account,self.reference,self.selected_type);self.refresh_bookmarks()

    def open_bookmark(self):
        owner,_=self.bookmark_owner();row=self.metadata_bookmarks.get(self.bookmark.get())
        if not row:raise ValueError('Select a saved bookmark.')
        self.selected_type=owner.resolve(self.reference,row);self.member_offset=0;self.render_members()

    def compare_metadata(self):
        self.require();token=self.token();current=self.reference
        if current is None:raise ValueError('Load the current reference pack first.')
        from tkinter import filedialog
        path=filedialog.askdirectory(parent=self.window,title='Select the baseline reference pack to compare with the loaded pack')
        self.checked(token)
        if not path:return
        from metadata_workspace import compare
        def work(client,stop,progress):return compare(metadata.load(path,stop=stop,progress=progress),current,stop=stop,progress=progress)
        def done(report):
            if self.reference is not current:raise ValueError('Reference selection changed. Compare again.')
            self.metadata_comparison=report;self.metadata_changes.set(report['rows'],lambda r:(r['state'],r['assembly'],r['name']))
            self.status.set(('Complete declaration comparison' if report['complete'] else 'Partial declaration comparison')+' · '+str(report['counts'])+f" · {report['rows_omitted']} rows omitted from display/export")
        self.start(work,done)

    def export_metadata_comparison(self):
        self.require()
        if self.metadata_comparison is None:raise ValueError('Compare two reference packs first.')
        self.save(self.metadata_comparison,'VRC-Eye-Metadata-Comparison.json')

    def search(self,offset=0):
        self.require()
        if self.reference is None:raise ValueError('Load a metadata reference first.')
        rows,total=self.reference.search(self.query.get(),self.assembly.get(),self.kind.get(),offset)
        if offset and not rows:offset=max(0,((total-1)//100)*100);rows,total=self.reference.search(self.query.get(),self.assembly.get(),self.kind.get(),offset)
        self.type_offset=offset;self.selected_type=None;self.members.set([],lambda r:());self.put(self.type_detail,'')
        self.types.set(rows,lambda r:(r['assembly'],r['name'],r['kind']))
        identity=self.reference.identity
        self.metadata_status.set(f"{identity['game_build']} · Unity {identity['unity_version']}\n{total:,} matches · {offset+1 if rows else 0}–{offset+len(rows)}. Metadata and type-map hashes checked.\nNative DLL: {identity['native_match']}\nPublisher and address mapping unverified.")

    def select_type(self):
        self.require();row=self.types.selected()
        if row:self.selected_type=row['index'];self.member_offset=0;self.render_members()

    def render_members(self):
        if self.reference is None or self.selected_type is None:return
        data=self.reference.detail(self.selected_type,offset=self.member_offset)
        self.put(self.type_detail,dict(name=data['name'],assembly=data['assembly'],parent=data['parent'],interfaces=data['interfaces'],
                                      interface_count=data['interface_count'],interfaces_truncated=data['interfaces_truncated'],
                                      members=f"{data['offset']+1 if data['members'] else 0}–{data['offset']+len(data['members'])} of {data['total_members']}"))
        self.members.set(data['members'],lambda r:(r['kind'],r['name'],r.get('type') or 'Unknown',
                         str(r['constant']) if r.get('constant') is not None else r.get('access','')))

    def member_page(self,direction):
        self.require()
        if self.selected_type is None:raise ValueError('Select a type first.')
        total=self.reference.detail(self.selected_type,limit=1)['total_members']
        self.member_offset=max(0,min(max(0,((total-1)//200)*200),self.member_offset+200*direction));self.render_members()

    def follow_parent(self):
        self.require()
        if self.reference is None or self.selected_type is None:raise ValueError('Select a type first.')
        parent=self.reference.parent(self.selected_type)
        if parent is None:raise ValueError('No inspectable base definition is present in this pack.')
        self.selected_type=parent;self.member_offset=0;self.render_members()

    def export_type(self):
        self.require()
        if self.reference is None or self.selected_type is None:raise ValueError('Select a type first.')
        self.save(self.reference.selected_report(self.selected_type,self.member_offset),'VRC-Eye-Metadata-Selection.json')

    def check_dll(self):
        self.require();reference=self.reference
        if reference is None:raise ValueError('Load a reference first.')
        token=self.token()
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.window,title='Choose GameAssembly.dll for byte-hash comparison',filetypes=[('DLL','*.dll')])
        self.checked(token)
        if not path:return
        def done(result):
            reference.identity['native_match']=result['state'];reference.identity['checked_binary']=result
            self.search(self.type_offset)
        self.start(lambda client,stop,progress:metadata.check_binary(reference,path,stop=stop),done)

    def build_performance(self):
        frame=self.frames[TABS[1]];row=line(self,frame)
        button(self,row,'Import creator performance report…',self.choose_performance)
        button(self,row,'Save blank report template…',lambda:self.save(performance.template(self.expected_avatar) if self.expected_avatar else performance.template(),'VRC-Eye-Performance-Template.json'))
        self.performance_status=self.tk.StringVar(value=('Selected avatar: '+self.expected_avatar) if self.expected_avatar else 'Choose a report containing an avatar ID, platform, SDK version, observation time and stats.')
        self.note(frame,self.performance_status)
        self.performance_table=Table(self,frame,(('metric','Metric',290),('value','Reported value',150),('unit','Unit',130),('state','Evidence',160)),height=14)
        row=line(self,frame);button(self,row,'Use current report as baseline',self.pin_performance)
        button(self,row,'Compare baseline with current',self.compare_performance)
        button(self,row,'Export current report…',self.export_performance)
        button(self,row,'Export comparison…',self.export_comparison)
        self.performance_detail=self.text_box(frame,10)
        self.note(frame,'In Unity, install the bundled AvatarToolkit package and open VRC Eye → Avatar Performance Report. Capture SDK source measurements, export JSON, then import here. Missing counters remain unknown; source and built reports cannot be compared. No rank is inferred or written over the catalog rating.')

    def choose_performance(self):
        path=self.choose_file('Choose creator performance JSON')
        if not path:return
        self.performance=None;self.comparison=None;self.performance_table.set([],lambda r:());self.put(self.performance_detail,'')
        self.performance_status.set('Reading selected report…')
        self.start(lambda client,stop,progress:performance.read(path,expected_id=self.expected_avatar,stop=stop),self.accept_performance)

    def accept_performance(self,report):
        self.performance=report;self.preview=report;self.comparison=None
        self.performance_table.set(report.rows(),lambda r:(r['metric'],'Unknown' if r['value'] is None else str(r['value']),r['unit'],r['state']))
        self.performance_status.set(f'{report.avatar_id} · {report.platform} · SDK {report.sdk_version}\nStage: {report.measurement_stage} · Base SDK: {report.sdk_base_version or "Unknown"} · Unity: {report.unity_version or "Unknown"}\nObserved: {report.measured_at} · Source claim: {report.source}\nReported rank: {report.reported_rank} · Unknown fields omitted: '+(', '.join(report.unknown_fields) or 'none'))
        self.put(self.performance_detail,dict(input_sha256=report.file_sha256,baseline=('Loaded: '+self.baseline.measured_at) if self.baseline else 'None',scope='No rating calculation or catalog mutation.'))

    def pin_performance(self):
        self.require()
        if self.performance is None:raise ValueError('Import a performance report first.')
        self.baseline=self.performance;self.comparison=None;self.put(self.performance_detail,'Baseline pinned. Import another report, then compare.')

    def compare_performance(self):
        self.require()
        if self.baseline is None or self.performance is None:raise ValueError('Pin a baseline and import a current report.')
        self.comparison=performance.compare(self.baseline,self.performance);self.put(self.performance_detail,self.comparison)

    def export_performance(self):
        self.require()
        if self.performance is None:raise ValueError('Import a performance report first.')
        self.save(self.performance.document(),'VRC-Eye-Avatar-Performance.json')

    def export_comparison(self):
        self.require()
        if self.comparison is None:raise ValueError('Compare two reports first.')
        self.save(self.comparison,'VRC-Eye-Performance-Comparison.json')

    def build_media(self):
        frame=self.frames[TABS[2]];row=line(self,frame)
        button(self,row,'Import media error report…',self.choose_media)
        button(self,row,'Export current analysis…',self.export_media)
        row=line(self,frame);button(self,row,'Inspect retained log errors',self.inspect_log_errors)
        button(self,row,'Open selected error in Game Log',self.open_log_error)
        self.note(frame,'Reference: VRChat '+media.BUILD+'. Choose a matching build only when supplied by your evidence; unknown builds keep numeric codes unresolved.')
        row=line(self,frame);self.family=self.tk.StringVar(value='VideoError');self.code=self.tk.StringVar(value='3');self.build=self.tk.StringVar(value='Unknown')
        choice(self,row,self.family,tuple(media.FAMILIES),width=25)
        self.ttk.Label(row,text='Code / label').pack(side='left');entry(self,row,self.code,18)
        choice(self,row,self.build,('Unknown',media.BUILD),width=40);button(self,row,'Explain supplied code',self.lookup_media)
        self.media_status=self.tk.StringVar(value='No media observations imported. A reference lookup does not claim an event occurred.')
        self.note(frame,self.media_status)
        self.error_table=Table(self,frame,(('time','Supplied time',170),('family','Family',240),('code','Code',100),('label','Label',170),('state','Mapping evidence',240)),height=12,select=self.select_error)
        self.error_detail=self.text_box(frame,11)
        self.note(frame,'Game Log also explains explicit VideoError and VRCImageDownloadError labels in selected entries. Generic HTTP/player numbers are not interpreted as SDK codes. No playback action or automatic retry is performed.')

    def choose_media(self):
        path=self.choose_file('Choose media error JSON')
        if not path:return
        self.media_report=None;self._log_entries={};self.error_table.set([],lambda r:());self.put(self.error_detail,'');self.media_status.set('Reading selected report…')
        self.start(lambda client,stop,progress:media.read(path,stop=stop),self.accept_media)

    def accept_media(self,report):
        self.media_report=report;self.preview=report;self._log_entries={};self.put(self.error_detail,'')
        self.error_table.set(report['events'],lambda r:(r.get('observed_at','Not an observation'),r['family'].rsplit('.',1)[-1],str(r['raw_code']),r['label'] or 'Unknown',r['state']))
        self.media_status.set(report['provenance']+' · '+str(len(report['events']))+' entries.')

    def lookup_media(self):
        self.require();raw=self.code.get().strip()
        import re
        code=int(raw) if re.fullmatch(r'-?\d{1,10}',raw) else raw
        row=media.explain(self.family.get(),code,build='' if self.build.get()=='Unknown' else self.build.get())
        self.accept_media(dict(schema='vrc-eye-media-error-analysis-1',events=[row],provenance='Manual reference lookup; no event observed'))
        self.put(self.error_detail,row)

    def select_error(self):
        self.require();row=self.error_table.selected()
        if row:self.put(self.error_detail,row)

    def export_media(self):
        self.require()
        if self.media_report is None:raise ValueError('Import errors or explain a supplied code first.')
        from media_error_context import export_document
        self.save(export_document(self.media_report),'VRC-Eye-Media-Error-Analysis.json')

    def inspect_log_errors(self):
        self.require()
        from media_error_context import correlate
        from media_history import MediaHistory
        from avatar_library import active_scope
        items=tuple(self.shell.log.items)
        saved=MediaHistory(self.shell.store).rows(active_scope(self.app),limit=500)
        self.media_report=None;self._log_entries={};self.error_table.set([],lambda r:());self.put(self.error_detail,'')
        self.media_status.set('Inspecting retained log snapshot…')
        def done(report):
            self.accept_media(report)
            wanted={r['log_serial'] for r in report['events']}
            self._log_entries={r.serial:r for r in items if r.serial in wanted}
        self.start(lambda client,stop,progress:correlate(items,saved,stop=stop),done)

    def open_log_error(self):
        self.require();row=self.error_table.selected()
        item=self._log_entries.get(row.get('log_serial')) if row else None
        retained=list(reversed(self.shell.log.items))
        index=next((i for i,r in enumerate(retained) if r is item),None)
        if index is None:raise ValueError('This entry is no longer retained. Inspect the current log again.')
        self.shell.show('Game Log');page=self.shell.pages['Game Log']
        page.category.set('All');page.query.set('');page.refresh((index//200)*200)
        for key,value in page.table.records.items():
            if value is item:page.table.tree.selection_set(key);page.table.tree.see(key);page.selection();break
