# Developer capabilities — VRC Eye 1.19.7

Catalog revision: `eye-api-2026-10-02.1`. Source-review date: 2026-10-02.

**55 implemented executable adapters: 37 reads and 18 writes. Three additional entries are reference only. No live VRChat service validation was performed.**

Local field limits are VRC Eye validation bounds, not claims about current server quotas or complete endpoint schemas. An executable adapter can still encounter changed fields, permissions or behavior on the real service.

## Executable catalog

| Key | Operation | Method and route | Scope | Preflight / verification | Reference |
|---|---|---|---|---|---|
| `account.get` | Connected account | `GET /auth/user` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-current-user) |
| `user.get` | User record | `GET /users/{userId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-user) |
| `user.profile` | Public profile | `GET /profile/{userId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-public-profile) |
| `user.groups` | Visible user groups | `GET /users/{userId}/groups` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-user-groups) |
| `user.group-invites` | Own group invitations | `GET /users/{userId}/groups/invited` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-user-group-invited) |
| `account.update` | Edit own profile | `PUT /users/{userId}` | Own account only | account.get / account.get | [Community reference](https://vrchat.community/reference/update-user) |
| `world.get` | World record and packages | `GET /worlds/{worldId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-world) |
| `world.metadata` | World custom metadata | `GET /worlds/{worldId}/metadata` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-world-metadata) |
| `world.publication` | World publication eligibility | `GET /worlds/{worldId}/publish` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-world-publish-status) |
| `world.search` | Search accessible worlds | `GET /worlds` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/search-worlds) |
| `world.active` | Active worlds | `GET /worlds/active` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-active-worlds) |
| `world.recent` | Recently visited worlds | `GET /worlds/recent` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-recent-worlds) |
| `world.favorites` | Favorited worlds | `GET /worlds/favorites` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-favorited-worlds) |
| `world.update` | Edit owned world metadata | `PUT /worlds/{worldId}` | Owned world only | world.get / world.get | [Community reference](https://vrchat.community/reference/update-world) |
| `world.publish` | Request owned-world publication | `PUT /worlds/{worldId}/publish` | Owned world only | world.get / world.get | [Community reference](https://vrchat.community/reference/publish-world) |
| `world.unpublish` | Unpublish owned world | `DELETE /worlds/{worldId}/publish` | Owned world only | world.get / world.get | [Community reference](https://vrchat.community/reference/unpublish-world) |
| `avatar.get` | Avatar metadata | `GET /avatars/{avatarId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-avatar) |
| `avatar.list` | Own or featured avatars | `GET /avatars` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/search-avatars) |
| `avatar.favorites` | Favorite avatars | `GET /avatars/favorites` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-favorited-avatars) |
| `avatar.update` | Edit owned avatar metadata | `PUT /avatars/{avatarId}` | Owned avatar only | avatar.get / avatar.get | [Community reference](https://vrchat.community/reference/update-avatar) |
| `avatar.select` | Select an accessible avatar | `PUT /avatars/{avatarId}/select` | Signed-in account | avatar.get / account.get | [Community reference](https://vrchat.community/reference/select-avatar) |
| `instance.get` | Inspect an explicit instance | `GET /instances/{worldId}:{instanceId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-instance) |
| `instance.create` | Create a personal test instance | `POST /instances` | Signed-in account | world.get / None | [Community reference](https://vrchat.community/reference/create-instance) |
| `friends.list` | Friends, one page at a time | `GET /auth/user/friends` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-friends) |
| `friends.status` | Friend relationship | `GET /user/{userId}/friendStatus` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-friend-status) |
| `friends.request` | Send one friend request | `POST /user/{userId}/friendRequest` | Signed-in account | None / friends.status | [Community reference](https://vrchat.community/reference/friend) |
| `friends.cancel-request` | Cancel an outgoing friend request | `DELETE /user/{userId}/friendRequest` | Signed-in account | None / friends.status | [Community reference](https://vrchat.community/reference/delete-friend-request) |
| `friends.remove` | Remove one friendship | `DELETE /auth/user/friends/{userId}` | Signed-in account | None / friends.status | [Community reference](https://vrchat.community/reference/unfriend) |
| `notifications.list` | Own notifications | `GET /auth/user/notifications` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-notifications) |
| `notifications.get` | Own notification record | `GET /auth/user/notifications/{notificationId}` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-notification) |
| `notifications.read` | Mark a notification as read | `PUT /auth/user/notifications/{notificationId}/see` | Signed-in account | notifications.get / None | [Community reference](https://vrchat.community/reference/mark-notification-as-read) |
| `notifications.hide` | Hide a notification | `PUT /auth/user/notifications/{notificationId}/hide` | Signed-in account | notifications.get / None | [Community reference](https://vrchat.community/reference/delete-notification) |
| `notifications.accept` | Accept a friend request | `PUT /auth/user/notifications/{notificationId}/accept` | Signed-in account | notifications.get / None | [Community reference](https://vrchat.community/reference/accept-friend-request) |
| `favorites.limits` | Own favorite limits | `GET /auth/user/favoritelimits` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-favorite-limits) |
| `favorites.groups` | Own favorite collections | `GET /favorite/groups` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-favorite-groups) |
| `favorites.list` | Favorite entries | `GET /favorites` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-favorites) |
| `favorites.add` | Add one favorite | `POST /favorites` | Signed-in account | None / None | [Community reference](https://vrchat.community/reference/add-favorite) |
| `favorites.remove` | Remove one favorite entry | `DELETE /favorites/{favoriteId}` | Signed-in account | None / None | [Community reference](https://vrchat.community/reference/remove-favorite) |
| `group.get` | Group record and own membership | `GET /groups/{groupId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group) |
| `group.search` | Search visible groups | `GET /groups` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/search-groups) |
| `group.roles` | Group role definitions | `GET /groups/{groupId}/roles` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-roles) |
| `group.permissions` | Possible group permissions (not grants) | `GET /groups/{groupId}/permissions` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-permissions) |
| `group.members` | Other group members | `GET /groups/{groupId}/members` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-members) |
| `group.bans` | Authorized group ban list | `GET /groups/{groupId}/bans` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-bans) |
| `group.instances` | Accessible group instances | `GET /groups/{groupId}/instances` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-instances) |
| `group.invites` | Authorized group invitations | `GET /groups/{groupId}/invites` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-invites) |
| `group.requests` | Authorized group join requests | `GET /groups/{groupId}/requests` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-requests) |
| `group.member` | Group member record | `GET /groups/{groupId}/members/{userId}` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-member) |
| `group.audit` | Group audit log with continuation | `GET /groups/{groupId}/auditLogs` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-audit-logs) |
| `group.announcement` | Group announcement | `GET /groups/{groupId}/announcement` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-group-announcement) |
| `group.update` | Edit an owned group’s description | `PUT /groups/{groupId}` | Group owner only in this adapter | group.get / group.get | [Community reference](https://vrchat.community/reference/update-group) |
| `moderation.list` | Own personal moderation preferences | `GET /auth/user/playermoderations` | Own account only | None / None | [Community reference](https://vrchat.community/reference/get-player-moderations) |
| `moderation.apply` | Apply one personal moderation preference | `POST /auth/user/playermoderations` | Signed-in account | None / None | [Community reference](https://vrchat.community/reference/moderate-user) |
| `moderation.reset` | Reset one personal moderation preference | `PUT /auth/user/unplayermoderate` | Signed-in account | None / None | [Community reference](https://vrchat.community/reference/unmoderate-user) |
| `service.config` | Service configuration snapshot | `GET /config` | Accessible records; server authorization applies | None / None | [Community reference](https://vrchat.community/reference/get-config) |

## Write field boundary

Only the following fields are writable through these adapters; arbitrary response fields and account-security/settings changes are not accepted.

| Operation | Accepted body fields | Behavior |
|---|---|---|
| `account.update` | `bio`, `statusDescription`, `status` | Profile text/status only; no security, age, entitlement or filtering settings. |
| `world.update` | `name`, `description`, `capacity`, `recommendedCapacity` | No build upload. Capacity limits here are local validation bounds; the server may reject a value. |
| `world.publish` | No body fields | Separate from saving metadata. Service eligibility and publication rules remain authoritative. |
| `world.unpublish` | No body fields |  |
| `avatar.update` | `name`, `description` |  |
| `avatar.select` | No body fields | HTTP acknowledgement and service selection do not confirm client loading or avatar readiness. |
| `instance.create` | `worldId`, `type`, `region`, `ownerId` | Personal instances only in this adapter. Creation is not a join request or proof of arrival. |
| `friends.request` | No body fields |  |
| `friends.cancel-request` | No body fields |  |
| `friends.remove` | No body fields |  |
| `notifications.read` | No body fields |  |
| `notifications.hide` | No body fields |  |
| `notifications.accept` | No body fields |  |
| `favorites.add` | `type`, `favoriteId`, `tags` | Local bookmarks are separate; the service enforces favorite limits. |
| `favorites.remove` | No body fields |  |
| `group.update` | `description` | Role-based management expansion is not inferred from the permission-definition list. |
| `moderation.apply` | `moderated`, `type` | Account preference only. Immediate in-client protection is not confirmed by HTTP success. |
| `moderation.reset` | `moderated`, `type` | Reset is distinct from setting the opposite explicit preference. |

## Reference-only entries

These definitions do not dispatch in Live or Sandbox. A reference listing is not an implemented action.

| Key | Proposed operation | Reference |
|---|---|---|
| `reference.group-role` | Group role assignment (roadmap) | [Reference](https://vrchat.community/reference/add-group-member-role) |
| `reference.invite` | Send an instance invitation (roadmap) | [Reference](https://vrchat.community/reference/invite-user) |
| `reference.world-tags` | Creator tag editing (roadmap) | [Reference](https://vrchat.community/reference/add-world-tags) |

## Delivery boundaries relative to the full design

| Area | Implemented in 1.19.7 | Not yet delivered by this update |
|---|---|---|
| Shared foundation | Existing transport/lock/pacing integration, context-bound actions, redaction and bounded recorder | Full provider-wide action model and end-to-end provenance on every old feature |
| API requests | Catalog, guided/JSON composer, precise reviews, selected verification, account/resource checks | Arbitrary endpoint registration, request scripting, bulk social workflows |
| Scheduling | Existing shared lock and interval, cache use, cancellation, HTTP-429 cooldown | New cross-feature duplicate-read coalescing, full circuit breaker, priority scheduler |
| Responses | Sanitized response pin/compare, type/field diffs, bounded page inspection | Automatic response → normalized store → rendered UI divergence analysis |
| Events/state | Shared API traffic and existing pipeline observation, player provenance, cache and provider views | A complete unified event bus for every subsystem, server event gap recovery |
| Offline testing | Synthetic API executor/failures, real-player-model deterministic replay, parser/fuzz tools | Replay checkpoints/speed/seek, automatic scenario reduction, cross-build replay runner |
| Data/recovery | Read-only schema/count/integrity diagnostics and new consistent private backups | Active-data repair/replacement, new migration or rollback orchestration |
| Integrations | Initialized-provider snapshots and navigation to existing tools | New SDK/helper orchestration, extension host or unrestricted runtime command channel |
| Reports/performance | Reviewable redacted report export and recorder counters | Full Black Box causal graph, per-provider CPU/memory profiler, compatibility fleet comparisons |

The complete user-supplied roadmap is DEVELOPER_DESIGN_INPUT.md. Its 67 design sections are not 67 completed features. Existing creator/OSC/peer/runtime facilities are preserved, not counted again as newly implemented SDK integrations.
