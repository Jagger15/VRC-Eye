"""Immutable animation data and bounded sampling. No executable/event channels.

glTF TRS/weight tracks use STEP, LINEAR/slerp and CUBICSPLINE. FBX takes
use explicitly prepared discrete snapshots; no interpolation is invented.
"""
from bisect import bisect_right
from dataclasses import dataclass,replace
import math
import time
from avatar_scene import vector,integer,name,local_matrix,multiply,transform,bounds
from avatar_scene_deform import affine,positions,morph_weights
from avatar_scene_pose import inverse
from avatar_library_files import check_cancel

MAX_COMPONENTS=250000
MAX_FRAME_VERTICES=300000
MAX_FRAME_NODES=20000


@dataclass(frozen=True)
class Base:
    node:int
    matrix:tuple
    translation:tuple=(0.,0.,0.)
    rotation:tuple=(0.,0.,0.,1.)
    scale:tuple=(1.,1.,1.)


@dataclass(frozen=True)
class Track:
    node:int
    path:str
    interpolation:str
    times:tuple
    values:tuple


@dataclass(frozen=True)
class Frame:
    time:float
    matrices:tuple
    vertices:tuple
    colors:tuple


@dataclass(frozen=True)
class Clip:
    name:str
    start:float
    end:float
    tracks:tuple=()
    frames:tuple=()
    reason:str=''
    notes:tuple=()


@dataclass(frozen=True)
class Animation:
    bases:tuple
    clips:tuple


def quaternion(value):
    value=vector(value,4);length=math.sqrt(sum(v*v for v in value))
    if length<1e-8:raise ValueError('Animation produced a zero quaternion; this clip cannot be previewed at that time.')
    return tuple(v/length for v in value)


def interpolate(track,at):
    times=track.times;stride=3 if track.interpolation=='CUBICSPLINE' else 1
    def value(i):return track.values[i*stride+(1 if stride==3 else 0)]
    if at<=times[0]:return value(0)
    if at>=times[-1]:return value(len(times)-1)
    lo=bisect_right(times,at)-1;dt=times[lo+1]-times[lo];t=(at-times[lo])/dt;a=value(lo);b=value(lo+1)
    if track.interpolation=='STEP':return a
    if stride==3:
        outgoing=track.values[lo*3+2];incoming=track.values[(lo+1)*3]
        result=tuple((2*t**3-3*t*t+1)*x+dt*(t**3-2*t*t+t)*u+(-2*t**3+3*t*t)*y+dt*(t**3-t*t)*v for x,y,u,v in zip(a,b,outgoing,incoming))
        return quaternion(result) if track.path=='rotation' else result
    if track.path=='rotation':
        dot=sum(x*y for x,y in zip(a,b))
        if dot<0:b=tuple(-v for v in b);dot=-dot
        if dot<.9995:
            angle=math.acos(max(-1.,min(1.,dot)));s=math.sin(angle)
            return quaternion(tuple((math.sin((1-t)*angle)*x+math.sin(t*angle)*y)/s for x,y in zip(a,b)))
    result=tuple(x+(y-x)*t for x,y in zip(a,b))
    return quaternion(result) if track.path=='rotation' else result


def world_at(scene,clip,at):
    overrides={};weights={}
    for tr in clip.tracks:
        value=interpolate(tr,at)
        if tr.path=='weights':weights[tr.node]=morph_weights(value,len(value))
        else:overrides.setdefault(tr.node,{})[tr.path]=value
    bases={b.node:b for b in scene.animations.bases};world={}
    for n in scene.nodes:
        b=bases[n.index];values=overrides.get(n.index)
        local=local_matrix(dict(translation=values.get('translation',b.translation),rotation=values.get('rotation',b.rotation),scale=values.get('scale',b.scale))) if values else b.matrix
        world[n.index]=multiply(world[n.parent],local) if n.parent>=0 else local
    return world,weights


def mirrored(m):
    return m[0]*(m[5]*m[10]-m[9]*m[6])-m[4]*(m[1]*m[10]-m[9]*m[2])+m[8]*(m[1]*m[6]-m[5]*m[2])<0


def sample(scene,index,at,*,anchor=-1,stop=None):
    check_cancel(stop)
    if scene.animations is None:raise ValueError('This scene has no playable animation data.')
    clip=scene.animations.clips[integer(index,0,len(scene.animations.clips)-1)]
    if clip.reason:raise ValueError(clip.reason)
    at=vector([at],1)[0];at=max(clip.start,min(clip.end,at));deadline=time.monotonic()+4
    ids={n.index for n in scene.nodes}
    if type(anchor) is not int or anchor!=-1 and anchor not in ids:raise ValueError('Choose an existing scene node to hold in place.')
    if clip.frames:
        frame=clip.frames[max(0,bisect_right(tuple(f.time for f in clip.frames),at)-1)]
        world={n.index:m for n,m in zip(scene.nodes,frame.matrices)}
        reference={n.index:m for n,m in zip(scene.nodes,clip.frames[0].matrices)}
        parts=[replace(p,vertices=v) for p,v in zip(scene.parts,frame.vertices)]
        materials=tuple(replace(m,base_color=c) for m,c in zip(scene.materials,frame.colors))
    else:
        world,weights=world_at(scene,clip,at);reference=world_at(scene,clip,clip.start)[0] if anchor>=0 else {}
        original={n.index:n.matrix for n in scene.nodes};parts=[];materials=scene.materials
        for p in scene.parts:
            check_cancel(stop)
            if p.rig:vertices=positions(replace(p.rig,matrix=world[p.node]),scene.skins,world,weights.get(p.node),stop=stop,deadline=deadline)
            else:
                delta=multiply(world[p.node],inverse(original[p.node]));vertices=[]
                for i,v in enumerate(p.vertices):
                    if i%256==0:
                        check_cancel(stop)
                        if time.monotonic()>deadline:raise ValueError('Animation sampling exceeded four seconds; use a smaller scene.')
                    vertices.append(transform(delta,v))
                vertices=tuple(vertices)
            flip=(p.rig is None or p.rig.skin<0) and mirrored(world[p.node])!=mirrored(original[p.node])
            parts.append(replace(p,vertices=vertices,triangles=tuple(t[::-1] for t in p.triangles) if flip else p.triangles))
    if anchor>=0:
        offset=tuple(world[anchor][12+k]-reference[anchor][12+k] for k in range(3))
        world={i:m[:12]+tuple(m[12+k]-offset[k] for k in range(3))+(1.,) for i,m in world.items()}
        moved=[]
        for p in parts:
            vertices=[]
            for i,v in enumerate(p.vertices):
                if i%256==0:check_cancel(stop)
                vertices.append(vector(tuple(v[k]-offset[k] for k in range(3)),3))
            moved.append(replace(p,vertices=tuple(vertices)))
        parts=moved
    check_cancel(stop)
    box=bounds(tuple(v for p in parts for v in p.vertices))
    return replace(scene,nodes=tuple(replace(n,matrix=world[n.index]) for n in scene.nodes),parts=tuple(parts),bounds=box,materials=materials)


def decode(raw,scene):
    """Validate every child-supplied curve/frame before retaining it in the UI."""
    if raw is None:return None
    if not isinstance(raw,dict) or set(raw)!={'bases','clips'}:raise ValueError('Invalid animation result.')
    if not isinstance(raw['bases'],(list,tuple)) or len(raw['bases']) not in (0,len(scene.nodes)) or not isinstance(raw['clips'],(list,tuple)) or len(raw['clips'])>32:raise ValueError('Animation catalog exceeds its limits.')
    def label(v):
        if not isinstance(v,str) or not v or v!=name(v,''):raise ValueError('Invalid animation label.')
        return v
    bases=[];known={n.index for n in scene.nodes};morphs={p.node:len(p.rig.morph_names) for p in scene.parts if p.rig}
    for row,n in zip(raw['bases'],scene.nodes):
        if set(row)!={'node','matrix','translation','rotation','scale'} or type(row['node']) is not int or row['node']!=n.index:raise ValueError('Invalid animation base node.')
        rotation=vector(row['rotation'],4)
        if abs(sum(v*v for v in rotation)-1)>1e-4:raise ValueError('Animation base rotation is not normalized.')
        bases.append(Base(n.index,affine(row['matrix']),vector(row['translation'],3),rotation,vector(row['scale'],3)))
    if bases:
        world={}
        for n,b in zip(scene.nodes,bases):
            world[n.index]=multiply(world[n.parent],b.matrix) if n.parent>=0 else b.matrix
            if any(abs(a-b)>1e-6*max(1,abs(a),abs(b)) for a,b in zip(world[n.index],n.matrix)):raise ValueError('Animation bases disagree with the imported hierarchy.')
    clips=[];components=frame_vertices=frame_nodes=track_count=0
    for row in raw['clips']:
        if not isinstance(row,dict) or set(row)!={'name','start','end','tracks','frames','reason','notes'}:raise ValueError('Invalid animation clip fields.')
        start,end=vector([row['start'],row['end']],2)
        if not -86400<=start<=end<=86400 or end-start>3600:raise ValueError('Animation range exceeds one hour.')
        reason=row['reason'];notes=row['notes']
        if not isinstance(reason,str) or len(reason)>300 or not isinstance(notes,(list,tuple)) or len(notes)>8 or any(not isinstance(v,str) or len(v)>300 for v in notes):raise ValueError('Invalid animation diagnostics.')
        tracks=[];frames=[];seen=set()
        if not isinstance(row['tracks'],(list,tuple)) or len(row['tracks'])>256 or not isinstance(row['frames'],(list,tuple)) or len(row['frames'])>121:raise ValueError('Animation track/frame count exceeds its limit.')
        if row['tracks'] and row['frames'] or reason and (row['tracks'] or row['frames']) or not reason and not (row['tracks'] or row['frames']):raise ValueError('Ambiguous animation clip representation.')
        for tr in row['tracks']:
            if set(tr)!={'node','path','interpolation','times','values'}:raise ValueError('Invalid animation track.')
            node=integer(tr['node'],0,511);path=tr['path'];mode=tr['interpolation'];width={'translation':3,'rotation':4,'scale':3,'weights':morphs.get(node,0)}.get(path,0)
            if not bases or node not in known or not width or mode not in ('STEP','LINEAR','CUBICSPLINE') or (node,path) in seen:raise ValueError('Unsupported or duplicate animation binding.')
            if path!='weights':
                b=next(b for b in bases if b.node==node);matrix=local_matrix(dict(translation=b.translation,rotation=b.rotation,scale=b.scale))
                if any(abs(a-c)>1e-6*max(1,abs(a),abs(c)) for a,c in zip(b.matrix,matrix)):raise ValueError('Animated node defaults must agree with its local TRS transform.')
            seen.add((node,path));track_count+=1
            if track_count>1024:raise ValueError('Animation exceeds 1,024 tracks.')
            if not isinstance(tr['times'],(list,tuple)) or not 1<=len(tr['times'])<=4096:raise ValueError('Animation key count exceeds 4,096.')
            times=vector(tr['times'],len(tr['times']));stride=3 if mode=='CUBICSPLINE' else 1
            if times[0]<start or times[-1]>end or any(a>=b for a,b in zip(times,times[1:])) or stride==3 and len(times)<2:raise ValueError('Animation keys must have strictly increasing in-range times.')
            values=tr['values']
            if not isinstance(values,(list,tuple)) or len(values)!=len(times)*stride:raise ValueError('Animation value count mismatch.')
            components+=len(times)+len(values)*width
            if components>MAX_COMPONENTS:raise ValueError('Animation exceeds 250,000 numeric components.')
            values=tuple(vector(v,width) for v in values)
            actual=values[1::3] if stride==3 else values
            if path=='rotation' and any(abs(sum(x*x for x in v)-1)>1e-4 for v in actual):raise ValueError('Animation quaternion keys must be normalized.')
            if path=='weights':
                for v in actual:morph_weights(v,width)
            tracks.append(Track(node,path,mode,times,values))
        for fr in row['frames']:
            if set(fr)!={'time','matrices','vertices','colors'}:raise ValueError('Invalid baked frame.')
            at=vector([fr['time']],1)[0]
            if not start<=at<=end or frames and at<=frames[-1].time:raise ValueError('Baked frame times must increase within the clip.')
            if len(fr['matrices'])!=len(scene.nodes) or len(fr['vertices'])!=len(scene.parts) or len(fr['colors'])!=len(scene.materials):raise ValueError('Baked frame catalog differs from its scene.')
            frame_nodes+=len(scene.nodes);frame_vertices+=sum(len(p.vertices) for p in scene.parts)
            if frame_nodes>MAX_FRAME_NODES or frame_vertices>MAX_FRAME_VERTICES:raise ValueError('Baked animation exceeds its retained geometry budget.')
            vertices=[]
            for source,p in zip(fr['vertices'],scene.parts):
                if len(source)!=len(p.vertices):raise ValueError('Baked frame vertex count differs from its scene.')
                vertices.append(tuple(vector(v,3) for v in source))
            from avatar_scene_appearance import factor
            colors=tuple(tuple(factor(v) for v in vector(c,4)) for c in fr['colors'])
            frames.append(Frame(at,tuple(affine(m) for m in fr['matrices']),tuple(vertices),colors))
        if frames and (frames[0].time!=start or frames[-1].time!=end):raise ValueError('Baked frames must include both range endpoints.')
        clips.append(Clip(label(row['name']),start,end,tuple(tracks),tuple(frames),reason,tuple(notes)))
    return Animation(tuple(bases),tuple(clips))


class Clock:
    """Explicit playback; no autostart and no large catch-up after a stalled UI."""
    def __init__(self,start=0.,end=0.):self.start,self.end,self.position=start,end,start;self.playing=False;self.speed=1.;self.loop=False;self.last=None
    def seek(self,value):
        value=vector([value],1)[0];self.position=max(self.start,min(self.end,value));return self.position
    def update(self,now):
        if self.last is not None and self.playing:
            value=self.position+min(.25,max(0.,now-self.last))*self.speed
            if value>=self.end:
                if self.loop and self.end>self.start:value=self.start+(value-self.start)%(self.end-self.start)
                else:value=self.end;self.playing=False
            self.position=value
        self.last=now;return self.position


def describe(clip):
    lines=[f'{clip.name}: {clip.start:g}–{clip.end:g} seconds.']
    if clip.reason:lines.append('Unavailable: '+clip.reason)
    lines.extend(clip.notes)
    lines += [f'Node {t.node} / {t.path}: {t.interpolation}, {len(t.times)} keys, {len(t.values[0])} components; key span {t.times[0]:g}–{t.times[-1]:g} s.' for t in clip.tracks]
    if clip.frames:lines.append(f'{len(clip.frames)} exact sampled poses; holds the preceding sample when scrubbing between frames.')
    return '\n'.join(lines)
