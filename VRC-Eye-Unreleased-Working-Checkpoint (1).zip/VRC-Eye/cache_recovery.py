"""Local, supplied-key recovery of one observed UnityFS/AES-GCM cache layout.

This does not find keys, contact VRChat, repair damaged ciphertext, or change
cache files. Unknown layouts and failed authentication produce no output.
Layout reference: VRC1337/VRChatStudio, AnimeStudio/BundleFile.cs (2026-09-28).
"""

import base64
import binascii
import io
import os
import re
import stat
import struct
from pathlib import Path

from vrca_cache import cache_entry_guard
from vrca_files import MAX_DOWNLOAD_BYTES, VRCAError, _check_cancel, _save_stream


MAX_INFO_BYTES = 8 * 1024 * 1024
MAX_BLOCKS = 100_000
MAX_NODES = 10_000
CHUNK_DATA = 65_536
CHUNK_OVERHEAD = 32
CHUNK_SIZE = CHUNK_DATA + CHUNK_OVERHEAD


def parse_recovery_key(text):
    """A supplied 256-bit key, not a password, account token, or avatar ID."""
    if not isinstance(text, str) or len(text) > 256:
        raise VRCAError("Enter a 256-bit key as 64 hexadecimal characters or Base64.")
    text = text.strip()
    try:
        key = bytes.fromhex(text) if re.fullmatch(r"[0-9a-fA-F]{64}", text) else base64.b64decode(text, validate=True)
    except (ValueError, binascii.Error):
        key = b""
    if len(key) != 32:
        raise VRCAError("The key must decode to exactly 32 bytes. A password or avatar ID is not a decryption key.")
    return key


def recovery_dependencies():
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.exceptions import InvalidTag
        import lz4.block
    except ImportError:
        raise VRCAError("Recovery packages are missing. Start.cmd prepares them automatically; close VRC Eye and reopen Start.cmd online to retry.") from None
    return AESGCM, InvalidTag, lz4.block


def _read(stream, count):
    data = stream.read(count)
    if len(data) != count:
        raise VRCAError("The cache file is truncated or its layout is unsupported. No recovered file was saved.")
    return data


def _cstring(stream, maximum=128):
    value = bytearray()
    for _ in range(maximum):
        char = _read(stream, 1)
        value += char
        if char == b"\0":
            return bytes(value)
    raise VRCAError("A bundle header or directory string exceeds the supported limit.")


def _align(value):
    return (value + 15) & ~15


def _plain_size(encrypted_size):
    full, tail = divmod(encrypted_size, CHUNK_SIZE)
    if not encrypted_size or (tail and tail <= CHUNK_OVERHEAD):
        raise VRCAError("This block does not match the supported encrypted layout. It may already be readable.")
    return full * CHUNK_DATA + (tail - CHUNK_OVERHEAD if tail else 0)


def _layout(stream, source_size, lz4):
    if _read(stream, 8) != b"UnityFS\0":
        raise VRCAError("Recovery supports UnityFS cache bundles only. This file has an unknown or damaged header.")
    version_bytes = _read(stream, 4)
    version = struct.unpack(">I", version_bytes)[0]
    if version not in (6, 7, 8):
        raise VRCAError("This UnityFS format version is not supported for recovery.")
    prefix = b"UnityFS\0" + version_bytes + _cstring(stream) + _cstring(stream)
    declared_size, packed_size, info_size, flags = struct.unpack(">QIII", _read(stream, 20))
    if declared_size != source_size:
        raise VRCAError("The bundle length does not match its header. It may be truncated or use an unsupported layout.")
    if flags & ~0x3FF or not flags & 0x40:
        raise VRCAError("The bundle uses unsupported header flags.")
    if not 24 <= info_size <= MAX_INFO_BYTES or not 1 <= packed_size <= MAX_INFO_BYTES:
        raise VRCAError("Bundle metadata is missing or exceeds the 8 MiB recovery limit.")
    header_end = _align(stream.tell()) if version >= 7 else stream.tell()
    info_start = source_size - packed_size if flags & 0x80 else header_end
    if info_start < header_end or info_start + packed_size > source_size:
        raise VRCAError("Bundle metadata lies outside the file.")
    stream.seek(info_start)
    packed = _read(stream, packed_size)
    compression = flags & 0x3F
    if compression == 0:
        info = packed
    elif compression in (2, 3):
        try:
            info = lz4.decompress(packed, uncompressed_size=info_size)
        except (ValueError, lz4.LZ4BlockError):
            raise VRCAError("Bundle metadata could not be decompressed. The file may be damaged.") from None
    else:
        raise VRCAError("This metadata compression is unsupported. Recovery supports uncompressed and LZ4 metadata.")
    if len(info) != info_size:
        raise VRCAError("The decompressed metadata length does not match the header.")
    info = bytearray(info)
    reader = io.BytesIO(info)
    _read(reader, 16)  # Retain the original uncompressed-data hash.
    count = struct.unpack(">I", _read(reader, 4))[0]
    if not 1 <= count <= MAX_BLOCKS:
        raise VRCAError("The bundle has an invalid or unsupported block count.")
    blocks, total_plain, total_expanded, total_encrypted = [], 0, 0, 0
    for _ in range(count):
        position = reader.tell()
        expanded, encrypted, block_flags = struct.unpack(">IIH", _read(reader, 10))
        if block_flags & ~0x7F or (block_flags & 0x3F) not in (0, 1, 2, 3):
            raise VRCAError("The bundle uses unsupported data-block flags.")
        plain = _plain_size(encrypted)
        if not expanded or ((block_flags & 0x3F) == 0 and expanded != plain):
            raise VRCAError("The block sizes do not describe the supported encrypted layout. The file may already be readable.")
        total_plain += plain
        total_expanded += expanded
        total_encrypted += encrypted
        if max(total_plain, total_expanded, total_encrypted) > MAX_DOWNLOAD_BYTES:
            raise VRCAError("The bundle exceeds the 2 GiB recovery limit.")
        struct.pack_into(">I", info, position + 4, plain)
        blocks.append(encrypted)
    nodes = struct.unpack(">I", _read(reader, 4))[0]
    if not 1 <= nodes <= MAX_NODES:
        raise VRCAError("The bundle has an invalid or unsupported directory count.")
    for _ in range(nodes):
        offset, size, _flags = struct.unpack(">QQI", _read(reader, 20))
        if offset + size > total_expanded:
            raise VRCAError("The bundle directory points outside its expanded data.")
        _cstring(reader, 4096)
    if reader.tell() != len(info):
        raise VRCAError("Extra bundle metadata was found; this layout is unsupported.")
    data_start = header_end if flags & 0x80 else info_start + packed_size
    if flags & 0x200:
        data_start = _align(data_start)
    data_end = info_start if flags & 0x80 else source_size
    if data_start + total_encrypted != data_end:
        raise VRCAError("The block table does not cover the file exactly. No recovery was attempted.")
    # Write plain metadata at the front, preserving compressed asset bytes.
    output_header_size = len(prefix) + 20
    aligned = _align(output_header_size) if version >= 7 else output_header_size
    output_size = aligned + len(info) + total_plain
    if output_size > MAX_DOWNLOAD_BYTES:
        raise VRCAError("The recovered bundle would exceed the 2 GiB limit.")
    output_header = prefix + struct.pack(">QIII", output_size, len(info), len(info), flags & 0x140)
    output_header += b"\0" * (aligned - len(output_header))
    stream.seek(data_start)
    return output_header + info, tuple(blocks), output_size


class _RecoveredStream:
    def __init__(self, stream, header, blocks, cipher, invalid_tag, stop):
        self.stream, self.header, self.blocks = stream, header, blocks
        self.cipher, self.invalid_tag, self.stop = cipher, invalid_tag, stop
        self.iterator = self._chunks()
        self.buffer = b""

    def _chunks(self):
        yield self.header
        for size in self.blocks:
            remaining = size
            while remaining:
                _check_cancel(self.stop)
                count = min(remaining, CHUNK_SIZE)
                record = _read(self.stream, count)
                length = struct.unpack_from("<I", record, 12)[0]
                if not 1 <= length <= CHUNK_DATA or length + CHUNK_OVERHEAD != count:
                    raise VRCAError("Encrypted chunk lengths are invalid. The file may be readable already, damaged, or unsupported.")
                try:
                    plaintext = self.cipher.decrypt(record[:12], record[16:], None)
                except self.invalid_tag:
                    raise VRCAError("Authentication failed: the key does not match, the bytes are damaged, or the format differs. No recovered file was saved.") from None
                remaining -= count
                yield plaintext

    def read(self, size):
        while len(self.buffer) < size:
            _check_cancel(self.stop)
            try:
                self.buffer += next(self.iterator)
            except StopIteration:
                break
        result, self.buffer = self.buffer[:size], self.buffer[size:]
        return result


def recover_cache_entry(entry, destination, key, *, avatar_known=False, stop=None, progress=None):
    destination = Path(destination).expanduser()
    suffix = ".vrca" if avatar_known and entry.matched else ".bundle"
    if destination.suffix.lower() != suffix:
        raise VRCAError(f"Save the recovered file as {suffix}.")
    verify = cache_entry_guard(entry, destination)
    return recover_bundle(entry.path, destination, key, suffixes=(suffix,), source_check=verify,
                          stop=stop, progress=progress)


def recover_bundle(source, destination, key, *, suffixes=(".bundle",), source_check=None,
                   before_commit=None, stop=None, progress=None):
    """Recover supplied bytes using the same authenticated framing for any bundle.

    A caller must establish the file's identity/permission; this only verifies
    the supplied key against every encrypted chunk. It never obtains keys.
    """
    if not isinstance(key, bytes) or len(key) != 32:
        raise VRCAError("A valid 256-bit key is required.")
    AESGCM, invalid_tag, lz4 = recovery_dependencies()
    _check_cancel(stop)
    source = Path(source).expanduser()
    try:
        with source.open("rb") as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or not 1 <= before.st_size <= MAX_DOWNLOAD_BYTES:
                raise VRCAError("Choose a regular bundle file between 1 byte and 2 GiB.")
            if source_check:
                source_check(before)

            def unchanged():
                fingerprint = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
                after = os.fstat(stream.fileno())
                if fingerprint(before) != fingerprint(after) or fingerprint(before) != fingerprint(source.stat()):
                    raise VRCAError("The source file changed during recovery. No recovered file was saved.")
                if source_check:
                    source_check(after)
                if before_commit:
                    before_commit()

            header, blocks, size = _layout(stream, before.st_size, lz4)
            recovered = _RecoveredStream(stream, header, blocks, AESGCM(key), invalid_tag, stop)
            return _save_stream(recovered, destination, size, "", stop, progress, network=False,
                                suffixes=suffixes, before_commit=unchanged)
    except OSError:
        raise VRCAError("Could not read the source or write the recovered copy. Check permissions and available disk space.") from None
