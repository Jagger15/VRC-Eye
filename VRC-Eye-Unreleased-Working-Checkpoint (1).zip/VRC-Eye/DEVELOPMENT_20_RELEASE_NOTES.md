# VRC Eye 1.21.0 — Development 20

This build implements the first scoped batch from the completed utility and ARC/VRCX review. It extends the complete Development 19 baseline. Supplied utilities informed behavior and priorities; their implementations and binaries were not copied into Eye or run.

## Start

Extract this ZIP into a separate folder. Use **Start.cmd** on Windows or **bash Start.sh** on Linux. The existing launchers manage the local Python environment. The new `tzdata` dependency supplies IANA time-zone data where the operating system does not provide it. This is runnable source, not a compiled executable or signed installer.

## Changes and where to find them

| Feature | Entry point | Behavior |
|---|---|---|
| Settings coverage | Settings backup and undo | Sidebar section choices and photo grouping join the six existing typed sections. Selective export/restore, direct edit history, conditional undo and full sanitized profile backup retain them. A coverage dialog distinguishes settings, catalog records and original assets. |
| Source freshness | Home tables | Media, official status and performance rows show observation age. Default columns expose freshness. A repaint does not refresh provider evidence. |
| Optional sensor cadence | Existing Desktop power preference / minimize window | GPU and disk workers slow to 30 seconds only without an active display, enabled warning rule or recording. Existing collectors wake when demand returns. Core monitoring and protective rules keep their cadence. |
| GLB appearance | Avatar Library → 3D preview | Choose a static GLB, then Base color or Textured. Existing hierarchy selection, hide/show, frame and bounds remain. Inspect materials explains each assignment, UV coverage and fallback. |
| Automatic recovery checkpoints | Avatar Library → Recovery → Working copies / repair history | Review an installed VPM CLI in Creator Projects → Templates & tools first. On a selected recovery working copy, review Restore packages, Set package version or Remove package. Pending edits and resulting changes use the existing journal. |
| Night-session photos | Photos → Library grouping controls | Enable grouping, set a cutoff such as 04:00 and choose Local, UTC or an IANA zone. List/cards and an exact session-day filter show derived days. Naive dates need an explicit assumption. Source dates and files are unchanged. |
| Dated compatible copies | Photo context → Enable watched compatible exports | Newly reviewed export rules freeze the current grouping policy into session-day folders. Missing/conflicting capture metadata stops that export for review. Existing flat-output rules retain their behavior. |
| Draft blocks | Session tools → Composer | Add, reorder, enable, save and load Text, Clock and Selected media blocks. Build produces a private snapshot. Review segments and Confirm send still use the existing UTF-16/grapheme-aware OSC queue, permissions, cancellation and pacing. |
| OSC connection diagnostics | Networking → OSC Transport; OSC Controls → Inspector | Configured send/receive, actual receive, local query, selected remote query and advertised remote UDP roles are separate. Reports flag stale/context-mismatched metadata, fallback ports and possible loops. Default exports omit endpoint identities. |

## Exact limits

- Static GLB only: 32 MiB source, 100,000 used vertices, 30,000 triangles and 512 nodes/primitive instances. Existing rejection of required extensions, skinning and morph geometry remains.
- Appearance supports unlit base-color factors and UV0 embedded PNG/JPEG. At most 16 decoded textures; each at most 4 megapixels and 8 megapixels total, downsampled to at most 256 pixels per edge. Frames use at most 480 × 320 pixels, four million bounding-box pixel visits and four seconds, on one cancellable latest-frame worker. Larger scenes can use Solid/Wireframe or a framed subtree.
- Opaque/mask alpha uses a depth buffer. Blend uses depth-sorted approximate compositing. PBR/Unity shaders, normal/occlusion/emissive/metallic maps, vertex colors, other UV sets, texture transforms, skinning and animation remain unrendered. URI images are never opened. OBJ remains flat geometry. GLB interpretation follows the [Khronos glTF 2.0 specification](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html).
- The parser subprocess is fault separation, not an OS sandbox. A reviewed VPM executable is trusted local code and may affect its own caches/settings. No supplied mod DLL runs in Eye or VRChat.
- Checkpointed VPM applies only to journal-owned working copies. Original/raw data is protected by application behavior and hashes. Unity/editor helpers and ordinary Creator Projects jobs are not automatically wrapped. Canceled/failed capture retains an intent for inspection; no auto replay. Rollback checks individual files and preserves later changes; it is not an atomic filesystem transaction.
- Photo session days group labeled date evidence; they do not establish actual capture time, session attendance or a person in an image. Date from/to filters still use the original calendar-date evidence. Existing watched export rules change only when reviewed and re-enabled.
- Composer blocks are data only: no expressions, scripts, arbitrary variables or automatic publication. At most 12 blocks and 6,000 typed characters; final segmentation still enforces the existing chat limits. Saved blocks contain typed text, not live provider values or send authority, and currently stay outside selective/profile backups.
- OSC diagnostics read existing owners; they do not scan ports/processes, seize sockets, start discovery, enable routes or send traffic. Duplicate discovery advertisements alone do not prove a conflict. A send is not proof of delivery.

## Remaining work

See ARC_VRCX_REMAINING_DEV20.md and the complete JSON ledger. There are 40 partial and 7 missing areas; material/texture viewing moves to Partial. Native Windows/Linux GUI/accessibility, installed VPM/Unity/AssetRipper, live VRChat/CDN and SteamVR acceptance remain open. Later utility ideas were not silently enabled.

## Validation

See DEVELOPMENT_20_VALIDATION.md and BUILD_VALIDATION.json for final test counts, exclusions, source hashes and environment limits. All previous baseline files are retained. Development 19 remains a separate unchanged archive.
