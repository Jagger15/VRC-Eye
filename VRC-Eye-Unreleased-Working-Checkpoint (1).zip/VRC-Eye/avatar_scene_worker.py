"""Bundled static-scene parser process. Input and output are bounded data only."""
import json
from pathlib import Path
import sys


def main():
    if sys.platform!='win32':
        # Unix resource ceilings are additional budgets, not filesystem/network
        # containment. Windows uses the parent's resident-memory observation.
        import resource
        for kind,soft,hard in ((resource.RLIMIT_AS,1024**3,1024**3),(resource.RLIMIT_CPU,30,31),(resource.RLIMIT_CORE,0,0)):
            _,existing=resource.getrlimit(kind)
            if existing!=resource.RLIM_INFINITY:soft=min(soft,existing);hard=min(hard,existing)
            resource.setrlimit(kind,(soft,hard))
    # -I ignores ambient PYTHONPATH; import only this installation's modules.
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    from dataclasses import asdict
    from avatar_scene import parse,MAX_BYTES,MAX_OUTPUT
    try:
        from avatar_scene_sandbox import preload,install
        preload()
        bundle=sys.argv[1:]==['--bundle']
        take=len(sys.argv)==3 and sys.argv[1]=='--fbx-take'
        take_request=None
        if take:
            from avatar_animation_fbx import request,prepare
            if len(sys.argv[2])>256:raise ValueError('FBX take request exceeds its budget.')
            take_request=request(json.loads(sys.argv[2]))
        fbx=sys.argv[1:]==['--fbx'] or take
        if sys.argv[1:] and not (bundle or fbx):raise ValueError('Unsupported scene worker mode.')
        if bundle:
            if not sys.platform.startswith('linux'):raise ValueError('Unity bundle parsing requires kernel containment on this platform.')
            from avatar_bundle_scene import preload as preload_bundle,parse as parse_bundle
            preload_bundle()
        if fbx:
            if not sys.platform.startswith('linux'):raise ValueError('FBX parsing requires kernel containment on this platform.')
            from avatar_fbx_scene import preload as preload_fbx,parse as parse_fbx
            from avatar_fbx_input import MAX_INPUT,unpack
            preload_fbx()
        containment=install()
        data=sys.stdin.buffer.read((MAX_INPUT if fbx else MAX_BYTES)+1)
        if fbx:
            try:scene=prepare(*unpack(data),take_request) if take else parse_fbx(*unpack(data))
            except ValueError:raise
            except Exception:raise ValueError('FBX data is damaged or outside the supported importer subset.') from None
        elif bundle:
            try:scene=parse_bundle(data)
            except ValueError:raise
            except Exception:raise ValueError('Unity bundle data is damaged or outside the supported decoder subset.') from None
        else:scene=parse(data)
        raw=json.dumps(dict(protocol=1,containment=containment,scene=asdict(scene)),separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
        if len(raw)>MAX_OUTPUT:raise ValueError('The parsed scene exceeds the renderer transfer budget.')
    except (ValueError,TypeError,KeyError,IndexError,RecursionError,OverflowError,MemoryError,OSError,AssertionError,ImportError):
        # Only parser diagnostics are user-facing; never a source document or traceback.
        error=sys.exc_info()[1]
        message=str(error) if isinstance(error,ValueError) else 'The scene is malformed, unsupported or exceeds its parsing limits.'
        raw=json.dumps(dict(protocol=1,error=message[:300]),ensure_ascii=True).encode()
    sys.stdout.buffer.write(raw)


if __name__=='__main__':main()
