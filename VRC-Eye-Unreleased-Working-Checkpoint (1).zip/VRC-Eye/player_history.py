"""Transactional local player history and a bounded serial database worker.

Live voice, distance, API profiles and raw logs are never stored here.
"""
from concurrent.futures import Future
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import json
import queue
import sqlite3
import threading
import time

from player_store import PlayerStore
from player_session_model import exact_id,clean
from player_session_settings import defaults,validate
from world_players import log_epoch


def user_hash(user):return hashlib.sha256(exact_id(user,"usr").encode()).hexdigest()


class PlayerHistory(PlayerStore):
    def __init__(self,path=None,companion_path=None,*,account_scope='shared'):
        super().__init__(path,account_scope=account_scope)
        from companion_data import CompanionStore
        self.companion=CompanionStore(companion_path)
        self.native=self.companion.native

    @contextmanager
    def connect(self):
        with super().connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS roster_settings (id INTEGER PRIMARY KEY CHECK(id=1),value TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS player_local (user_id TEXT PRIMARY KEY,tags TEXT NOT NULL DEFAULT '[]',favorite INTEGER NOT NULL DEFAULT 0,save_history INTEGER NOT NULL DEFAULT 1)")
            db.execute("CREATE TABLE IF NOT EXISTS encounter_sessions (id TEXT PRIMARY KEY,world_id TEXT NOT NULL,world_name TEXT NOT NULL,started TEXT NOT NULL,ended TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL DEFAULT '')")
            db.execute("CREATE TABLE IF NOT EXISTS encounters (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,session_id TEXT NOT NULL,display_name TEXT NOT NULL,joined TEXT NOT NULL,first_observed TEXT NOT NULL,left_at TEXT NOT NULL,closed_at TEXT NOT NULL,duration INTEGER,reason TEXT NOT NULL,reconstructed INTEGER NOT NULL,segments TEXT NOT NULL)")
            db.execute("CREATE INDEX IF NOT EXISTS encounter_user ON encounters(user_id,first_observed)")
            db.execute("CREATE TABLE IF NOT EXISTS avatar_observations (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,session_id TEXT NOT NULL,stamp TEXT NOT NULL,avatar_id TEXT NOT NULL,name TEXT NOT NULL,state TEXT NOT NULL,source TEXT NOT NULL)")
            db.execute("CREATE INDEX IF NOT EXISTS avatar_observation_user ON avatar_observations(user_id,stamp)")
            db.execute("CREATE TABLE IF NOT EXISTS player_incidents (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,session_id TEXT NOT NULL,stamp TEXT NOT NULL,body TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS encounter_suppression (user_hash TEXT PRIMARY KEY,before_epoch REAL NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS deleted_player_records (id TEXT PRIMARY KEY)")
            db.execute("CREATE TABLE IF NOT EXISTS player_category_suppression (user_hash TEXT NOT NULL,category TEXT NOT NULL,before_epoch REAL NOT NULL,PRIMARY KEY(user_hash,category))")
            db.execute("CREATE TABLE IF NOT EXISTS private_player_sessions (id TEXT PRIMARY KEY)")
            yield db

    def settings(self):
        with self.connect() as db:row=db.execute("SELECT value FROM roster_settings WHERE id=1").fetchone()
        return validate(json.loads(row[0])) if row else defaults()

    def save_settings(self,value):
        value=validate(value)
        with self.connect() as db:db.execute("INSERT OR REPLACE INTO roster_settings VALUES(1,?)",(json.dumps(value,allow_nan=False),))
        return value

    def local_snapshot(self):
        """One batched read; callers do not fetch a note for every draw."""
        result={}
        with self.connect() as db:
            for user,body in db.execute("SELECT user_id,body FROM notes LIMIT 20000"):result.setdefault(user,{})["note"]=body
            for user,tags,favorite,keep in db.execute("SELECT user_id,tags,favorite,save_history FROM player_local LIMIT 20000"):
                result.setdefault(user,{}).update(tags=tuple(json.loads(tags)),favorite=False,save_history=bool(keep))
            for user,name in db.execute("SELECT user_id,name FROM names ORDER BY last_seen DESC LIMIT 40000"):
                result.setdefault(user,{}).setdefault("names",[]).append(name)
            for user,count,total,first,last in db.execute("SELECT user_id,count(*),coalesce(sum(duration),0),min(first_observed),max(CASE WHEN closed_at<>'' THEN closed_at ELSE first_observed END) FROM encounters GROUP BY user_id LIMIT 20000"):
                result.setdefault(user,{}).update(encounters=count,shared_seconds=total,first_seen=first,last_seen=last)
        import shared_notes
        from shared_tags import migrate_roster
        migrate_roster(self.native,self.account_scope,{user:value.get('tags',()) for user,value in result.items()})
        views=shared_notes.read_players(self.native,self.account_scope,{user:value.get('note','') for user,value in result.items()})
        for user,view in views.items():
            result.setdefault(user,{}).update(note=view.text,tags=tuple(view.tags),note_revision=shared_notes.revision(view))
        self._note_views=views
        for user in self.companion.native.favorite_ids(self.account_scope,'friend',limit=20000):result.setdefault(user,{})['favorite']=True
        return result

    def set_local(self,user,*,note=None,tags=None,favorite=None,save_history=None,display_name=None,note_revision=None):
        exact_id(user,"usr")
        if note is not None and (not isinstance(note,str) or len(note)>20000):raise ValueError("Use at most 20,000 characters for a local note.")
        if tags is not None:
            from shared_tags import tags as clean_tags
            tags=clean_tags(tags)
        for flag in (favorite,save_history):
            if flag is not None and type(flag) is not bool:raise ValueError("Local flags must be true or false.")
        if note is not None:
            import shared_notes
            if note_revision is not None:
                self.note(user);view=self._note_views[user]
                if shared_notes.revision(view)!=note_revision:
                    raise ValueError('Notes changed in another editor or workspace. Reload notes and review your draft before saving.')
            if self._note_views.get(user) is None:self.note(user)
            if self._note_views[user].pending:
                raise ValueError('Review earlier notes in the shared notes editor before saving.')
            view=self._note_views[user]
            self._note_views[user]=shared_notes.save(self.native,view,note,tags=tags,legacy_now=lambda:{'Earlier player note':self.legacy_note(user)})
        elif tags is not None:
            import shared_tags
            self.sync_tags(user)
            # A tag-only update preserves any unreconciled earlier note text.
            current=shared_tags.values(shared_notes_rows(self.native,self.account_scope,user))
            if current!=tags:
                shared_tags.commit(self.native,shared_tags.prepare(self.native,self.account_scope,['friend:'+user],'Replace',tags))
        if favorite is not None:
            if favorite:self.companion.save_favorite("friend",user,clean(display_name or user),scope=self.account_scope)
            else:self.companion.remove_favorite("friend",user,scope=self.account_scope)
        with self.connect() as db:
            old=db.execute("SELECT tags,favorite,save_history FROM player_local WHERE user_id=?",(user,)).fetchone() or ("[]",0,1)
            db.execute("INSERT OR REPLACE INTO player_local VALUES(?,?,?,?)",(user,old[0],int(favorite) if favorite is not None else old[1],int(save_history) if save_history is not None else old[2]))
        return self.user_local(user)

    def user_local(self,user):
        exact_id(user,"usr");result={"note":"","tags":(),"favorite":False,"save_history":True,"names":()}
        with self.connect() as db:
            row=db.execute("SELECT body FROM notes WHERE user_id=?",(user,)).fetchone()
            if row:result["note"]=row[0]
            row=db.execute("SELECT tags,favorite,save_history FROM player_local WHERE user_id=?",(user,)).fetchone()
            if row:result.update(tags=tuple(json.loads(row[0])),favorite=bool(row[1]),save_history=bool(row[2]))
            result["names"]=tuple(r[0] for r in db.execute("SELECT name FROM names WHERE user_id=? ORDER BY last_seen DESC LIMIT 100",(user,)))
            row=db.execute("SELECT count(*),coalesce(sum(duration),0),min(first_observed),max(CASE WHEN closed_at<>'' THEN closed_at ELSE first_observed END) FROM encounters WHERE user_id=?",(user,)).fetchone()
            result.update(encounters=row[0],shared_seconds=row[1],first_seen=row[2] or "",last_seen=row[3] or "")
        with self.companion.native.connect() as db:
            result['favorite']=db.execute("SELECT 1 FROM eye_native_records WHERE scope=? AND kind='membership' AND json_extract(data,'$.entity')=?",(self.account_scope,'friend:'+user)).fetchone() is not None
        import shared_notes
        result['note']=self.note(user);result['note_revision']=shared_notes.revision(self._note_views[user])
        result['tags']=tuple(self._note_views[user].tags)
        return result

    def persist(self,session,encounters,avatars=(),*,world_history=False):
        if len(encounters)>2000 or len(avatars)>2000:raise ValueError("History batch exceeds its limit.")
        with self.connect() as db:
            if db.execute("SELECT 1 FROM private_player_sessions WHERE id=?",(session["id"],)).fetchone():return False
            db.execute("INSERT INTO encounter_sessions VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET world_id=excluded.world_id,world_name=excluded.world_name,ended=excluded.ended,reason=excluded.reason",
                       (session["id"],session.get("world_id","") if world_history else "",session.get("world_name","") if world_history else "",session["started"],session.get("ended",""),session.get("reason","")))
            for item in encounters:
                if db.execute("SELECT 1 FROM deleted_player_records WHERE id=?",(item["id"],)).fetchone():continue
                user=exact_id(item["user_id"],"usr");flag=db.execute("SELECT save_history FROM player_local WHERE user_id=?",(user,)).fetchone()
                cutoff=db.execute("SELECT before_epoch FROM encounter_suppression WHERE user_hash=?",(user_hash(user),)).fetchone()
                start=log_epoch(item["joined"] or item["first_observed"])
                if flag and not flag[0] or cutoff and (start is None or start<=cutoff[0]):continue
                db.execute("INSERT INTO encounters VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET user_id=excluded.user_id,display_name=excluded.display_name,joined=excluded.joined,left_at=excluded.left_at,closed_at=excluded.closed_at,duration=excluded.duration,reason=excluded.reason,reconstructed=excluded.reconstructed,segments=excluded.segments",
                           (item["id"],user,session["id"],clean(item["name"]),item["joined"],item["first_observed"],item["left_at"],item["closed_at"],item["duration"],item["reason"],int(item["reconstructed"]),json.dumps(item.get("segments",[]),allow_nan=False)))
                stamp=item["closed_at"] or item["first_observed"]
                names_cutoff=db.execute("SELECT before_epoch FROM player_category_suppression WHERE user_hash=? AND category='names'",(user_hash(user),)).fetchone()
                if not names_cutoff or (log_epoch(stamp) or 0)>names_cutoff[0]:
                    db.execute("INSERT INTO names VALUES(?,?,?,?) ON CONFLICT(user_id,name) DO UPDATE SET first_seen=min(first_seen,excluded.first_seen),last_seen=max(last_seen,excluded.last_seen)",(user,clean(item["name"]),stamp if names_cutoff else item["first_observed"],stamp))
                db.execute("DELETE FROM names WHERE user_id=? AND name NOT IN (SELECT name FROM names WHERE user_id=? ORDER BY last_seen DESC LIMIT 100)",(user,user))
            for item in avatars:
                if db.execute("SELECT 1 FROM deleted_player_records WHERE id=?",(item["id"],)).fetchone():continue
                user=exact_id(item["user_id"],"usr");flag=db.execute("SELECT save_history FROM player_local WHERE user_id=?",(user,)).fetchone()
                cutoff=db.execute("SELECT before_epoch FROM encounter_suppression WHERE user_hash=?",(user_hash(user),)).fetchone()
                if flag and not flag[0] or cutoff and (log_epoch(item["stamp"]) or 0)<=cutoff[0]:continue
                avatar_cutoff=db.execute("SELECT before_epoch FROM player_category_suppression WHERE user_hash=? AND category='avatars'",(user_hash(user),)).fetchone()
                if avatar_cutoff and (log_epoch(item["stamp"]) or 0)<=avatar_cutoff[0]:continue
                if item.get("avatar_id"):exact_id(item["avatar_id"],"avtr")
                db.execute("INSERT OR IGNORE INTO avatar_observations VALUES(?,?,?,?,?,?,?,?)",(item["id"],user,session["id"],item["stamp"],item.get("avatar_id",""),clean(item.get("name","")),clean(item.get("state",""),50),clean(item["source"],30)))
            db.execute("DELETE FROM encounter_sessions WHERE id NOT IN (SELECT session_id FROM encounters) AND id NOT IN (SELECT session_id FROM avatar_observations) AND id NOT IN (SELECT session_id FROM player_incidents)")
        return True

    def recover(self):
        """An interrupted observation never becomes an invented player departure."""
        with self.connect() as db:
            db.execute("UPDATE encounters SET reason='RECONCILING',duration=NULL WHERE left_at='' AND closed_at='' AND reason=''")
            return db.execute("SELECT count(*) FROM encounters WHERE reason='RECONCILING'").fetchone()[0]

    def history(self,user,kind="encounters",offset=0):
        exact_id(user,"usr")
        if type(offset) is not int or not 0<=offset<=1000000 or offset%100:raise ValueError("Invalid history page.")
        with self.connect() as db:
            db.row_factory=sqlite3.Row
            if kind=="encounters":rows=db.execute("SELECT e.*,s.world_id,s.world_name FROM encounters e LEFT JOIN encounter_sessions s ON s.id=e.session_id WHERE e.user_id=? ORDER BY e.first_observed DESC LIMIT 100 OFFSET ?",(user,offset)).fetchall()
            elif kind=="avatars":rows=db.execute("SELECT * FROM avatar_observations WHERE user_id=? ORDER BY stamp DESC LIMIT 100 OFFSET ?",(user,offset)).fetchall()
            elif kind=="incidents":rows=db.execute("SELECT * FROM player_incidents WHERE user_id=? ORDER BY stamp DESC LIMIT 100 OFFSET ?",(user,offset)).fetchall()
            else:raise ValueError("Unknown player history category.")
        return [dict(r) for r in rows]

    def incident(self,record):
        exact_id(record["user_id"],"usr");raw=json.dumps(record,ensure_ascii=False,allow_nan=False)
        if len(raw.encode())>65536:raise ValueError("Incident bookmark exceeds 64 KiB.")
        with self.connect() as db:db.execute("INSERT INTO player_incidents VALUES(?,?,?,?,?)",(record["id"],record["user_id"],record["session_id"],record["stamp"],raw))
        return record

    def delete(self,user,categories,*,record_id=None,cutoff=None):
        exact_id(user,"usr")
        categories=set(categories)
        if not categories or categories-{"encounters","avatars","incidents","notes","tags","favorite","names"}:raise ValueError("Choose known local data categories.")
        if record_id is not None and (not isinstance(record_id,str) or not 1<=len(record_id)<=128):raise ValueError("Select an exact history record.")
        with self.connect() as db:
            if record_id:db.execute("INSERT OR IGNORE INTO deleted_player_records VALUES(?)",(record_id,))
            if cutoff is not None and record_id is None:
                for category in categories & {"names","avatars"}:
                    db.execute("INSERT INTO player_category_suppression VALUES(?,?,?) ON CONFLICT(user_hash,category) DO UPDATE SET before_epoch=max(before_epoch,excluded.before_epoch)",(user_hash(user),category,float(cutoff)))
            for category,table in (("encounters","encounters"),("avatars","avatar_observations"),("incidents","player_incidents")):
                if category in categories:db.execute("DELETE FROM "+table+" WHERE user_id=?"+(" AND id=?" if record_id else ""),(user,record_id) if record_id else (user,))
            if "notes" in categories:db.execute("DELETE FROM notes WHERE user_id=?",(user,))
            if "names" in categories:db.execute("DELETE FROM names WHERE user_id=?",(user,))
            if "tags" in categories:db.execute("UPDATE player_local SET tags='[]' WHERE user_id=?",(user,))
            if "favorite" in categories:db.execute("UPDATE player_local SET favorite=0 WHERE user_id=?",(user,))
            if {"encounters","avatars","incidents","notes","tags","favorite","names"}<=categories:db.execute("DELETE FROM player_local WHERE user_id=?",(user,))
            if cutoff is not None and "encounters" in categories and record_id is None:
                db.execute("INSERT INTO encounter_suppression VALUES(?,?) ON CONFLICT(user_hash) DO UPDATE SET before_epoch=max(before_epoch,excluded.before_epoch)",(user_hash(user),float(cutoff)))
            db.execute("DELETE FROM encounter_sessions WHERE id NOT IN (SELECT session_id FROM encounters) AND id NOT IN (SELECT session_id FROM avatar_observations) AND id NOT IN (SELECT session_id FROM player_incidents)")
        if "notes" in categories:
            import shared_notes
            reader=lambda:{'Earlier player note':self.legacy_note(user)}
            view=shared_notes.read(self.native,self.account_scope,'friend',user,legacy=reader())
            self._note_views[user]=shared_notes.save(self.native,view,'',reconcile=True,legacy_now=reader)
        if "favorite" in categories:self.companion.remove_favorite("friend",user,scope=self.account_scope)
        if 'tags' in categories:
            import shared_tags
            if shared_notes_rows(self.native,self.account_scope,user):
                shared_tags.commit(self.native,shared_tags.prepare(self.native,self.account_scope,['friend:'+user],'Replace',[]))
            shared_tags.migrate_roster(self.native,self.account_scope,{user:[]})
        return True

    def delete_session(self,session_id):
        with self.connect() as db:
            db.execute("INSERT OR IGNORE INTO private_player_sessions VALUES(?)",(session_id,))
            session=db.execute("SELECT started FROM encounter_sessions WHERE id=?",(session_id,)).fetchone()
            names=db.execute("SELECT DISTINCT user_id,display_name FROM encounters WHERE session_id=?",(session_id,)).fetchall()
            for table in ("encounters","avatar_observations","player_incidents"):db.execute("DELETE FROM "+table+" WHERE session_id=?",(session_id,))
            db.execute("DELETE FROM encounter_sessions WHERE id=?",(session_id,))
            if session:
                for user,name in names:
                    db.execute("DELETE FROM names WHERE user_id=? AND name=? AND first_seen>=?",(user,name,session[0]))
                    previous=db.execute("SELECT max(CASE WHEN closed_at<>'' THEN closed_at ELSE first_observed END) FROM encounters WHERE user_id=? AND display_name=?",(user,name)).fetchone()[0]
                    db.execute("UPDATE names SET last_seen=coalesce(?,first_seen) WHERE user_id=? AND name=? AND last_seen>=?",(previous,user,name,session[0]))
        return True

    def prune(self,before,*,preview=False):
        count=0
        with self.connect() as db:
            for table,column in (("encounters","first_observed"),("avatar_observations","stamp"),("player_incidents","stamp")):
                cursor=db.execute("SELECT id,"+column+" FROM "+table)
                while True:
                    rows=cursor.fetchmany(200)
                    if not rows:break
                    ids=[(r[0],) for r in rows if (log_epoch(r[1]) is not None and log_epoch(r[1])<before)]
                    count+=len(ids)
                    if not preview:db.executemany("DELETE FROM "+table+" WHERE id=?",ids)
            if not preview:db.execute("DELETE FROM encounter_sessions WHERE id NOT IN (SELECT session_id FROM encounters) AND id NOT IN (SELECT session_id FROM avatar_observations) AND id NOT IN (SELECT session_id FROM player_incidents)")
        return count

    def export_history(self,user,kind,path):
        """Stream only the category explicitly selected; atomically replace the chosen file."""
        from pathlib import Path
        import os,tempfile
        exact_id(user,"usr")
        table={"encounters":"encounters","avatars":"avatar_observations","incidents":"player_incidents"}.get(kind)
        if table is None:raise ValueError("Choose a history category to export.")
        path=Path(path);temporary=None;count=0
        try:
            with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=path.parent,prefix=".vrc-eye-export-",delete=False) as out:
                temporary=out.name;out.write('{"format":"VRC Eye player history 1","category":'+json.dumps(kind)+',"records":[')
                with self.connect() as db:
                    db.row_factory=sqlite3.Row
                    for row in db.execute("SELECT * FROM "+table+" WHERE user_id=?",(user,)):
                        if count:out.write(",\n")
                        json.dump(dict(row),out,ensure_ascii=False,allow_nan=False);count+=1
                out.write("]}\n")
            os.replace(temporary,path);temporary=None
        finally:
            if temporary:
                try:os.unlink(temporary)
                except OSError:pass
        return count


def shared_notes_rows(library,account,user):
    from shared_tags import rows
    with library.connect() as db:return rows(library,db,account,'friend:'+user)


class HistoryWorker:
    """One serial worker, bounded jobs, explicit failure, no writes on every UI tick."""
    def __init__(self,store,*,thread_factory=threading.Thread):
        self.store=store;self.factory=thread_factory;self.queue=queue.Queue(maxsize=256);self.thread=None;self.lock=threading.RLock();self.closed=False
        self.policy_revision=0;self.failed="";self.completed=0
    def submit(self,operation,*args,policy_revision=None,**kwargs):
        if operation not in ("settings","save_settings","local_snapshot","set_local","user_local","persist","recover","history","incident","delete","delete_session","prune","note","save_note","names","forget_names","export_history"):raise ValueError("Unsupported player database operation.")
        future=Future()
        with self.lock:
            if self.closed:future.set_exception(ValueError("Player history worker is closed."));return future
            try:self.queue.put_nowait((operation,deepcopy(args),deepcopy(kwargs),future,policy_revision))
            except queue.Full:future.set_exception(ValueError("Player history queue is full; live roster remains available."));return future
            if self.thread is None:
                self.thread=self.factory(target=self._run,daemon=True,name="VRC-Eye-Player-History");self.thread.start()
        return future
    def _run(self):
        while True:
            job=self.queue.get()
            try:
                if job is None:return
                operation,args,kwargs,future,revision=job
                if not future.set_running_or_notify_cancel():continue
                with self.lock:
                    allowed=revision is None or revision==self.policy_revision
                if not allowed:future.set_result(None);continue
                try:result=getattr(self.store,operation)(*args,**kwargs);future.set_result(result);self.completed+=1
                except Exception as error:
                    self.failed="Local player history unavailable; live roster continues."
                    future.set_exception(error)
            finally:self.queue.task_done()
            if self.closed and not getattr(self,"sentinel_sent",False) and self.queue.empty():return
    def change_policy(self):
        with self.lock:self.policy_revision+=1;return self.policy_revision
    def close(self,timeout=1.):
        with self.lock:
            self.closed=True
            if not getattr(self,"sentinel_sent",False):
                try:self.queue.put_nowait(None)
                except queue.Full:return False
                self.sentinel_sent=True
        if self.thread:
            self.thread.join(timeout)
            return not self.thread.is_alive()
        return True
