# Development 20 validation

Final portable regression on frozen source: **5,115 passed, 1,059 subtests passed, zero failures or errors** in 118.41 seconds. There were 475 native-display skips, one deselected case and two inherited warnings. The external-socket guard blocked zero attempted external connections. All 55 new cases ran in this suite.

## What was exercised

| Area | Evidence |
|---|---|
| Settings and providers | Typed sidebar/photo sections, older bundle compatibility, profile coverage, conditional history/undo, source ages, demand cadence and wake-up behavior. |
| GLB appearance | Real bounded parser subprocess fixtures; material/UV/embedded-image validation; alpha, wrapping, negative-scale winding, decoding limits, malformed structured output, raster color/depth and worker cancellation. A generated UV triangle image was visually inspected. |
| Recovery helper | Real local working-copy files and journal records with a simulated VPM runner; reviewed scope/tool binding, before/after checkpoints, failure/cancellation, changed-input refusal and conditional undo. No installed VPM or Unity execution. |
| Photos and composer | Time-zone/cutoff and naive-date handling, full-catalog filtering, compatible-copy folder rules, strict data-only blocks, saved account scope, private frozen output and existing chat segmentation. |
| OSC diagnostics | Distinct endpoint roles and context/age findings, possible loops, fallback ports and redacted exports, through existing fake/controller snapshots. |
| Headless workflows | Composer form/build/review invalidation; photo controls and account context; real texture raster through an adapted canvas; recovery form requiring a reviewed CLI. |

## Reproducibility and package

- Python runtime: 3.12.14. All 612 Python source files parse with Python 3.10 grammar; this is syntax compatibility, not an executed Python 3.10 matrix.
- SOURCE_CHECKPOINT_MANIFEST.json records SHA-256 for 657 runtime, test, launcher and source files. All hashes matched after the final run; runtime/test/launcher files were not edited afterward.
- The complete 809-file Development 19 baseline remains independently byte-verified against its original ZIP. Every prior path is retained in Development 20; files implementing this release and current metadata are intentionally updated.
- Baseline SHA-256: `82c60be6114cb6bf3e5510bb0ec5525cb2f0c9f34a32dc575bc8312b0f6670bd`.
- The exclusive-create package tool checks ZIP CRC and every archived member against the final source. The separate build report records the resulting ZIP hash and size.
- This is source with the existing Windows/Linux launchers, not a compiled executable or signed installer. No credentials, runtime profile, test caches, uploaded utilities or supplied mod binaries are included.

## Environment limits

No native display or Xvfb is available. All 475 skipped tests require a Tk display. Windows/Linux native layout, keyboard, high contrast, large text, tray, renderer performance, installed VPM/Unity/AssetRipper, live VRChat/CDN, SteamVR and power-loss acceptance remain open. Headless callbacks and simulated helper results do not substitute for these gates.

The inherited exclusions are retained without expansion:

- `tests/test_media_mpris_bus_121.py`
- `tests/test_session_secret_service_protocol.py`
- `tests/test_peer_transport.py`
- `tests/test_networking_integration.py`
- `tests/test_osc_transport.py`
- `tests/test_osc_discovery.py`
- `tests/test_osc_simulator.py`
- `tests/test_avatar_link.py`
- `tests/test_avatar_osc.py`
- `tests/test_avatar_creator_app.py`
- `tests/test_rangefinder.py`
- `tests/test_camera_capture.py`
- `tests/test_osc_avatar.py`

One individual deselection: `tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore`.

The two warnings are the inherited pytest TestListener constructor collection warning and the deliberate duplicate `VRChat.exe` ZIP fixture.

## Exact final command

```sh
PYTHONPATH=.:tests python3 -m pytest -q --tb=short -rf -p tools.offline_test_guard --durations=10 -o faulthandler_timeout=60 --ignore=tests/test_media_mpris_bus_121.py --ignore=tests/test_session_secret_service_protocol.py --ignore=tests/test_peer_transport.py --ignore=tests/test_networking_integration.py --ignore=tests/test_osc_transport.py --ignore=tests/test_osc_discovery.py --ignore=tests/test_osc_simulator.py --ignore=tests/test_avatar_link.py --ignore=tests/test_avatar_osc.py --ignore=tests/test_avatar_creator_app.py --ignore=tests/test_rangefinder.py --ignore=tests/test_camera_capture.py --ignore=tests/test_osc_avatar.py --deselect=tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore --junitxml=../release-dev20-final-tests.xml
```

BUILD_VALIDATION.json is the machine-readable record. BASELINE_1_21_DEV19_VALIDATION.json retains the prior release record unchanged.
