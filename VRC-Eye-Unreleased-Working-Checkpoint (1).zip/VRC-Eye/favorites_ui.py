"""Distinct server favorites and unrestricted local collections."""

from text_viewport import window_body
from companion_data import Entity, entity_id
from companion_ui import Page, Table, line, button, entry, choice, note
import companion_api as api


class FavoritesPage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, "Favorites")
        tabs = self.ttk.Notebook(parent); tabs.pack(fill="both", expand=True)
        local = self.ttk.Frame(tabs); game = self.ttk.Frame(tabs)
        tabs.add(local, text="VRC Eye Favorites"); tabs.add(game, text="Game Favorites")
        self.local = LocalFavorites(shell, local); self.game = GameFavorites(shell, game)
    def tick(self):
        super().tick(); self.local.guard(self.local.tick); self.game.guard(self.game.tick)
    def account_changed(self):
        for page in (self.local, self.game):
            page.cancel(); page.account = page.context(); page.account_changed()
    def close(self):
        self.local.close(); self.game.close(); return super().close()


class LocalFavorites(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, "VRC Eye Favorites")
        self.kind = self.tk.StringVar(value="avatar"); self.query = self.tk.StringVar(value="")
        self.filter_group = self.tk.StringVar(value=""); self.name = self.tk.StringVar(value="")
        self.ref = self.tk.StringVar(value=""); self.collection = self.tk.StringVar(value="General")
        self.workspace = self.tk.StringVar(value='Shared local library')
        self.offset = 0; self.total = 0; self.loaded = None
        note(self, "Collections are stored in VRC Eye and work without VRCX or VRC+. Each item can belong to multiple collections. Choose a shared library or the current account’s local workspace.")
        row=line(self);choice(self,row,self.workspace,('Shared local library','Current account'),lambda:self.load(0),24)
        button(self,row,'Collections…',self.manage_collections)
        button(self,row,'VRCX migration / native backup…',lambda:__import__('native_data_ui').show(self.shell))
        row = line(self); choice(self, row, self.kind, ("avatar", "friend", "world"), lambda: self.load(0), 12)
        entry(self, row, self.query, 23); entry(self, row, self.filter_group, 18)
        button(self, row, "Filter / refresh", lambda: self.load(0)); button(self, row, "Previous", lambda: self.load(max(0,self.offset-100)))
        button(self, row, "Next", self.next)
        note(self, "Filter fields: text, then exact collection name (blank means all collections).")
        self.table = Table(self, parent, (("name", "Name", 200), ("group", "Local collection", 150), ("id", "ID", 350), ("updated", "Saved", 175)), height=9, select=self.selection)
        row = line(self); self.ttk.Label(row, text="ID / page:").pack(side="left"); entry(self, row, self.ref, 51)
        self.ttk.Label(row, text="Name:").pack(side="left"); entry(self, row, self.name, 23)
        row = line(self); self.ttk.Label(row, text="Collection:").pack(side="left"); entry(self, row, self.collection, 23)
        button(self, row, "Save / update local entry", self.save); button(self, row, "Remove selected…", self.remove)
        button(self,row,'Notes / tags…',self.annotate);button(self,row,'Set order…',self.order)
        row = line(self); button(self, row, "Open VRChat page", lambda: self.open_item(self.selected_entity()))
        button(self, row, "Player profile…", lambda: self.profile(self.selected_entity()))
        button(self, row, "Invite Me to world…", lambda: __import__("world_visits_ui").open_for_world(self.shell,self.selected_entity()))
        button(self, row, "Export all local favorites…", self.export); button(self, row, "Import local backup…", self.import_backup)
        self.load(0)

    def target_scope(self):
        if self.workspace.get()=='Shared local library':return 'shared'
        client=self.app.api
        if not client or not client.authenticated:raise ValueError('Connect an account or choose the shared library.')
        return entity_id('user',client.user_id)

    def account_changed(self):
        self.table.set([],lambda r:());self.loaded=None;self.ref.set('');self.name.set('')
        self.status.set('Account changed. Refresh the selected workspace.')

    def manage_collections(self):
        from tkinter import simpledialog
        library=self.shell.store.native;target=self.target_scope();kind=self.kind.get()
        window=self.tk.Toplevel(self.app.root);window.title('Local collections');window.transient(self.app.root)
        box=self.tk.Listbox(window_body(window),width=60,height=12,exportselection=False);box.pack(fill='both',expand=True,padx=12,pady=8)
        records=[]
        def refresh():
            records[:]=library.collections(target,kind);box.delete(0,'end')
            for r in records:box.insert('end',r['data']['name'])
            self.load(0)
        def change(action):
            if target!=self.target_scope():raise ValueError('The workspace changed. Reopen collections.')
            selected=box.curselection();row=records[selected[0]] if selected else None
            if action!='create' and row is None:raise ValueError('Choose a collection.')
            if action=='delete':
                if self.confirm('Delete collection',f"Remove {row['data']['name']} and its memberships? Items and their other collections are kept."):library.forget(target,'collection',row['id'])
            else:
                name=simpledialog.askstring('Collection name','Name',parent=window,initialvalue=row['data']['name'] if row else '')
                if name:library.collection(target,kind,name,ref=row['id'] if row else None)
            refresh()
        bar=self.ttk.Frame(window_body(window));bar.pack(fill='x',padx=12,pady=8)
        for title,action in (('New empty collection','create'),('Rename','rename'),('Delete…','delete')):button(self,bar,title,lambda a=action:change(a))
        refresh()

    def annotate(self):
        item=self.selected_entity();target=self.target_scope()
        from shared_notes_ui import show
        return show(self.shell,item.kind,item.id,account=target,on_saved=lambda:self.load(self.offset))

    def order(self):
        from tkinter import simpledialog
        row=self.table.selected()
        if not row:raise ValueError('Select a collection item.')
        rank=simpledialog.askinteger('Collection order','Smaller numbers appear first.',parent=self.app.root,minvalue=-1000000000,maxvalue=1000000000)
        if rank is not None:self.shell.store.native.move_membership(self.target_scope(),row['membership_id'],rank=rank);self.load(self.offset)

    def load(self, offset):
        kind, query, group = self.kind.get(), self.query.get(), self.filter_group.get().strip()
        records, total = self.shell.store.favorites(kind, query, group, offset,scope=self.target_scope())
        self.loaded = (kind, query, group); self.total, self.offset = total, offset
        self.table.set(records, lambda r: (r["name"], r["collection"], r["id"], r["updated"]))
        self.ref.set(""); self.name.set("")
        self.status.set(f"{total:,} matching local favorites · page {offset//100+1} · {len(records)} displayed. No storage count cap.")

    def next(self):
        if self.offset+100 < self.total: self.load(self.offset+100)
    def selection(self):
        row = self.table.selected()
        if row: self.ref.set(row["id"]); self.name.set(row["name"]); self.collection.set(row["collection"])
    def selected_entity(self):
        row = self.table.selected()
        if not row or not self.loaded: raise ValueError("Select a local favorite.")
        return Entity(self.loaded[0], row["id"], row["name"], row["collection"], data=row["data"])
    def save(self):
        if self.app.demo: raise ValueError("Leave Demo before saving favorites.")
        self.shell.store.save_favorite(self.kind.get(), self.ref.get(), self.name.get(), self.collection.get(),scope=self.target_scope())
        self.load(0)
    def remove(self):
        item = self.selected_entity()
        collection = self.table.selected()['collection']
        if self.confirm("Remove collection membership", f"Remove {item.name}\n{item.id}\nfrom the {collection} collection? Other collection memberships are kept."):
            self.shell.store.remove_favorite(item.kind, item.id,scope=self.target_scope(),membership=self.table.selected()['membership_id']); self.load(self.offset)
    def export(self):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.app.root, initialfile="VRC-Eye-favorites.csv", defaultextension=".csv", filetypes=[("Favorites backup", "*.csv")])
        if path: self.status.set(f"Exported {self.shell.store.export_favorites(path,scope=self.target_scope()):,} collection memberships. CSV excludes notes, tags and empty collections; use Native backup to preserve those.")
    def import_backup(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.app.root, filetypes=[("Favorites backup", "*.csv")])
        target=self.target_scope()
        if path and self.confirm("Import local favorites", "Merge these collection memberships into the selected workspace? Existing names and metadata are preserved; missing data is filled."):
            self.start(lambda c,s,p: self.shell.store.import_favorites(path,stop=s,scope=target), lambda count: (self.load(0), self.status.set(f"Imported {count:,} local entries.")), api=False)


class GameFavorites(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, "Game Favorites")
        self.groups = None; self.items = None; self.mapping = {}; self.loaded_group = None; self.names = {}
        self.group_name = self.tk.StringVar(value=""); self.target = self.tk.StringVar(value="")
        self.limits = self.tk.StringVar(value="Account limits not loaded. VRChat enforces the game's list and slot limits.")
        self.detail = self.tk.StringVar(value="Load your game lists, choose one, then load its items.")
        row = line(self); button(self, row, "Load / refresh game lists", lambda: self.load_groups(0)); button(self, row, "Next lists page", self.more_groups)
        button(self, row, "Refresh account limits", self.load_limits)
        self.ttk.Label(parent, textvariable=self.limits, wraplength=1030).pack(anchor="w", pady=6)
        row = line(self); self.group_box = choice(self, row, self.group_name, (), self.changed_group, 43)
        button(self, row, "Load list items", lambda: self.load_items(0)); button(self, row, "Previous", lambda: self.items_page(-1)); button(self, row, "Next", lambda: self.items_page(1))
        note(self, "These are your actual VRChat favorite lists. IDs remain visible when the favorite endpoint omits names; Look up selected resolves one item. Writes use a recently refreshed list and VRChat's own permissions and limits.")
        self.table = Table(self, parent, (("name", "Name / ID", 250), ("kind", "Type", 95), ("id", "Item ID", 340), ("tags", "Game lists", 140)), height=9, select=self.selection)
        self.ttk.Label(parent, textvariable=self.detail, wraplength=1020).pack(anchor="w", pady=5)
        row = line(self); self.ttk.Label(row, text="Add ID / page:").pack(side="left"); entry(self, row, self.target, 54)
        button(self, row, "Add to game list…", self.add); button(self, row, "Remove selected…", self.remove)
        row = line(self); button(self, row, "Look up selected", self.lookup); button(self, row, "Open VRChat page", lambda: self.open_item(self.selected_entity()))
        button(self, row, "Save VRC Eye favorite…", lambda: self.favorite(self.selected_entity()))
        button(self, row, "Invite Me to world…", lambda: __import__("world_visits_ui").open_for_world(self.shell,self.selected_entity()))
        row=line(self);button(self,row,'Rename / visibility…',self.edit_group);button(self,row,'Clear game list…',self.clear_group)

    def edit_group(self):
        from tkinter import simpledialog
        from native_api import bridge_favorite_group
        from account_workspace_ui import submit_review
        group=self.current_group();snapshot=bridge_favorite_group(self.connected(),self.groups,group)
        name=simpledialog.askstring('Game list name','Display name',parent=self.app.root,initialvalue=group.get('displayName') or group['name'])
        if name is None:return
        visibility=simpledialog.askstring('Game list visibility','private, friends or public',parent=self.app.root,initialvalue=group.get('visibility','private'))
        if visibility is None:return
        submit_review(self,'favorite-group-edit',result=snapshot,values={'displayName':name,'visibility':visibility},view_guard=self.review_guard)

    def clear_group(self):
        from native_api import bridge_favorite_group
        from account_workspace_ui import submit_review
        snapshot=bridge_favorite_group(self.connected(),self.groups,self.current_group())
        submit_review(self,'favorite-group-clear',result=snapshot,view_guard=self.review_guard)

    def account_changed(self):
        self.groups = self.items = None; self.mapping.clear(); self.names.clear(); self.loaded_group = None
        self.group_box.configure(values=()); self.group_name.set(""); self.target.set("")
        self.table.set([], lambda r: ()); self.limits.set("Account limits not loaded."); self.detail.set("Load lists for the current account.")
    def changed_group(self):
        self.cancel(); self.items = None; self.loaded_group = None; self.table.set([], lambda r: ()); self.detail.set("Load items for this list.")
    def load_limits(self):
        self.start(lambda c,s,p: api.read(c,"favorite-limits",stop=s,progress=p), lambda result: self.limits.set(api.limit_text(result.data)+" · "+result.checked_at))
    def load_groups(self, offset):
        def done(result):
            self.groups = result; self.items = None; self.loaded_group = None
            self.mapping = {f"{row.get('type')} · {row.get('displayName') or row.get('name')} [{row.get('name')}]": row for row in result.data}
            self.group_box.configure(values=tuple(self.mapping)); self.group_name.set(next(iter(self.mapping),""))
            self.table.set([], lambda r: ()); self.status.set(f"Loaded {len(self.mapping)} game lists at offset {offset}. Refresh lists before acting if older than five minutes.")
        self.start(lambda c,s,p: api.read(c,"favorite-groups",offset=offset,stop=s,progress=p), done)
    def more_groups(self):
        if not self.groups or not self.groups.more: raise ValueError("No next list page reported.")
        self.load_groups(self.groups.offset+100)
    def current_group(self):
        group = self.mapping.get(self.group_name.get())
        if not group: raise ValueError("Load and choose a game list.")
        return group
    def load_items(self, offset):
        group = self.current_group()
        client, generation = self.app.api, getattr(self.app, "data_generation", 0)
        def done(result):
            if self.current_group() is not group: raise ValueError("List selection changed; load it again.")
            self.items = result; self.loaded_group = group; self.render()
            osc = getattr(self.app, "osc_controller", None)
            if osc is not None and group.get("type") == "avatar":
                try:
                    osc.remember_eligible_avatars({row["favoriteId"]: "favorites" for row in result.data if row.get("type") == "avatar"},
                        client=client, generation=generation)
                except ValueError:
                    pass
            self.status.set(f"{len(result.data)} game favorites · offset {offset} · checked {result.checked_at}")
        self.start(lambda c,s,p: api.read(c,"favorite-items",group=group,offset=offset,stop=s,progress=p), done)
    def items_page(self, direction):
        if not self.items: raise ValueError("Load items first.")
        if direction > 0 and not self.items.more: raise ValueError("No next page reported.")
        self.load_items(max(0,self.items.offset+direction*100))
    def render(self):
        self.table.set(self.items.data if self.items else [], lambda r: (self.names.get(r["favoriteId"],r["favoriteId"]),r["type"],r["favoriteId"],", ".join(r.get("tags",[]))))
    def selected_entity(self):
        row = self.table.selected()
        if not row: raise ValueError("Select a game favorite.")
        kind = "world" if row["type"] == "vrcPlusWorld" else row["type"]
        return Entity(kind,row["favoriteId"],self.names.get(row["favoriteId"],row["favoriteId"]))
    def selection(self):
        if not self.table.selected(): self.detail.set("Select an item."); return
        item = self.selected_entity(); self.detail.set(f"{item.name}\n{item.id}")
    def lookup(self):
        item = self.selected_entity()
        def work(c,s,p):
            if item.kind == "avatar": return c.lookup("avatar",item.id,stop=s,progress=p).name
            kind = "user" if item.kind == "friend" else item.kind
            return api.read(c,kind+"-search",query=item.id,stop=s,progress=p).data[0].name
        def done(name): self.names[item.id] = name or item.id; self.render(); self.selection()
        self.start(work,done)
    def review_guard(self):
        return (self.context(), self.group_name.get(), self.target.get(),
                id(self.groups), id(self.items), id(self.table.selected()))

    def add(self):
        from account_workspace_ui import submit_review
        client = self.connected(); group = self.current_group(); result = self.groups
        api.selected_record(client, result, group, "favorite-groups")
        ref = entity_id("world" if group["type"] == "vrcPlusWorld" else group["type"], self.target.get())
        submit_review(self, "add-favorite", target=ref, group=group, group_result=result,
                      description=f"Game list: {group.get('displayName') or group['name']} ({group['type']}). VRChat enforces available slots.",
                      view_guard=self.review_guard)

    def remove(self):
        from account_workspace_ui import submit_review
        client = self.connected(); result, row = self.items, self.table.selected()
        api.selected_record(client, result, row, "favorite-items")
        item = self.selected_entity()
        submit_review(self, "remove-favorite", result=result, row=row,
                      description=f"{item.name} — {item.id}. Lists: {', '.join(row.get('tags', []))}",
                      view_guard=self.review_guard)
