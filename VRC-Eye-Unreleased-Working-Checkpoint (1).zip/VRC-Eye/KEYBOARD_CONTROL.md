# Keyboard control

Keyboard control is enabled automatically, including before sign-in, offline,
in Demo/Safe Mode, and with the screen reader off. Press **F1** for an in-app
guide. Accessibility → Keyboard contains the guide and navigation remapping.

| Keys | Action |
| --- | --- |
| Tab / Shift+Tab | Next / previous visible, enabled control in the current window |
| F6 / Shift+F6 | Next / previous region: header, navigation, page, notices |
| Ctrl+Page Down / Ctrl+Page Up | Next / previous available tab in the nearest workspace |
| Enter / keypad Enter | Activate the focused button or its existing scoped action |
| Space | Native button, checkbox and radio activation; press/release for hold controls |
| Arrow keys | Lists, trees, tab strips, sidebar buttons, sliders and supported previews |
| Home / End in sidebar | First / last visible navigation button |
| Shift+F10 / Menu | Feature row actions, or generic table details and sorting |
| Ctrl+Shift+F10 on a table | Generic details/sorting, even when the table has a feature menu |
| Enter on an ordinary table | Full selected-row text, unless the feature supplies its own Enter action |
| Shift+Left / Shift+Right on a table | Horizontal column scrolling |
| Ctrl+Tab / Ctrl+Shift+Tab in an editor | Leave the editor without inserting a tab |
| Escape in a dialog | Existing close/cancel action, including cleanup and confirmation rules |
| F1 | Keyboard help |
| Ctrl+K | Find a tool, including workspaces hidden by the current display mode |
| Ctrl+Shift+K | Quick search |
| Ctrl+Comma | Settings |

Main-window navigation shortcuts can be remapped, disabled, reviewed, imported,
exported, and undone using the existing shortcut editor. Existing profiles keep
their assignments: if an old profile already uses F6, the newly added region
default is disabled instead of replacing that assignment. In dialogs, F6 and
Shift+F6 use their standard control-group navigation. A remapped main-window
navigation chord takes precedence over a shared keyboard binding on that chord.
F1 and the visible Accessibility controls remain available.

Tab leaves read-only text. Editable multiline text retains normal Tab, Enter,
selection, copy/paste and cursor behavior; Ctrl+Tab is its explicit exit path.
Enter on Cancel activates Cancel, even when the dialog also defines a default
Enter action. Keypad Enter follows an existing widget-specific Return action.
The existing sign-in bindings and password paste behavior remain in place.
Alt/AltGr/Super and Ctrl+Alt screen-reader commands are not intercepted.

Continuous sliders use 1% of their range per arrow press, 10% with Shift or Page
Up/Down, and Home/End for endpoints. Reversed ranges and endpoint clamping are
supported. This makes 0–1 sliders usable between their endpoints.

## Lists, cards and dialogs

Lists are one Tab stop rather than one stop per row. Native arrow selection,
tree expansion, multi-selection, scrolling and text editing remain available.
The generic table menu exposes existing sort commands; it does not introduce
new account or network operations. Full row details support ordinary text
selection and copying, redact protected columns, and clear when the source or
privacy context changes. Up to 100 selected rows are shown per details view.

Shared table refreshes preserve the selected entity and focused row across
reordering. Removed entities and account changes clear selection. Avatar cards
and search tiles explicitly identify themselves so rebuilt cards can regain
focus on the same entity. New notifications do not move focus.

Moving through the World player roster now updates selection and its inline
details. Press Enter, double-click, or use Open to open the selected profile.
Single selection no longer opens a profile window and interrupts arrow browsing.

Dialogs receive initial focus unless they already chose it. Tab traversal stays
inside their window. The keyboard layer respects grabs, nested dialogs, existing
Escape handlers, and close protocols. Closing restores the originating control
when its account context and visibility still match; otherwise it uses the
current page. Shortcut capture suspends navigation and reader commands.

Focused controls are revealed inside scrollable canvas workspaces. Existing
theme focus outlines remain active; enable Stronger keyboard focus outlines in
Accessibility → Display for additional emphasis.

## Custom views

* **World map:** Tab onto the map. Arrows pan; Shift+arrows pan farther; plus/minus
  zoom; Home fits. Enter or keypad Enter adds a waypoint at the center crosshair.
  The visible Add center waypoint button does the same. Pan moves the chosen map
  position under the crosshair. Naming and saving retain the existing review and
  map workflow; a changed map invalidates a pending waypoint name.
* **Social mutual graph:** the paged member table and Focus selected graph member
  button provide the same filtering action as clicking a graph label.
* **Images and models:** existing arrow panning/orbit controls and visible
  zoom/fit/reset buttons remain available. The keyboard layer does not synthesize
  mouse drags or infer scene content.
* **Plots:** existing data tables and the screen reader's factual text/data
  alternatives remain available. Noninteractive plots gain no arbitrary actions.
* **Hold controls:** Space press/release and focus-loss release are retained.
  Enter does not start a momentary OSC hold. Existing permissions, arm/review
  steps, timeouts, service ownership and transport cleanup remain authoritative.

## Qualification and scope

Implementation and verification are recorded in `KEYBOARD_QUALIFICATION.json`
and `PENDING_WORKING_VALIDATION.json`. Portable tests exercise dispatch, focus,
modal/context guards, text editing, table identity, details/privacy, menus,
slider steps, map controls, profile migration and cleanup. Twelve additional
real-Tk acceptance tests cover actual bindings, login paste, dialogs, large-scale
routes, tables, native controls and previews. They require a Windows or Linux
graphical desktop and are not executed in the current headless environment.
The environment also rejects AF_UNIX sockets, preventing Xvfb startup.

This is application-local desktop keyboard control. It does not register
OS-global/gameplay hotkeys or implement VR controller/overlay input. Native
Windows/Linux end-to-end acceptance, native file dialogs and assistive-technology
interoperability remain unqualified. See `SCREEN_READER.md` for reader scope.
No numbered release, installer or executable is created by this checkpoint.

Implementation follows Tk's native [focus traversal](https://www.tcl-lang.org/man/tcl9.1/TkCmd/focusNext.html)
and [takefocus](https://www.tcl-lang.org/man/tcl8.6.13/TkCmd/options.htm)
contracts. Existing [Treeview heading commands](https://www.tcl-lang.org/man/tcl8.6.14/TkCmd/ttk_treeview.htm)
are reused for keyboard sorting.
The table-inspection chord has a narrow leading binding because Tk
[modifier patterns also match additional modifiers](https://www.tcl-lang.org/man/tcl8.6/TkCmd/bind.htm).
Keypad/cursor handling accepts Tk's Windows Extended flag while retaining the
Alt/AltGr/Super exclusions. Final qualification separates the full regression
snapshot from the focused verification of these final binding corrections.
