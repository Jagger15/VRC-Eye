"""Historical cached fields and annotations alongside existing live profiles."""

from text_viewport import window_body
import json
from companion_data import entity_id
from native_library import identity
from companion_ui import button,line
from vrcx_ui_jobs import LocalPage


def project(library,account,kind,ref,*,shared=False):
    entity_id(kind,ref);kinds=('friend','user') if kind in ('friend','user') else (kind,)
    output=[]
    for workspace in dict.fromkeys((account,'shared') if shared else (account,)):
        for item_kind in kinds:
            key=item_kind+':'+ref;row=library.get(workspace,'entity',key)
            if row:output.append(dict(scope=workspace,record=row,annotations=library.annotations(workspace,key)))
    return output


def legacy_plan(library,source,target,user):
    entity_id('friend',user);body=source.note(user)
    if not body:raise ValueError('No note is stored for this user in the selected legacy workspace.')
    key='friend:'+user
    row=dict(scope=target,kind='entity',id=key,data=dict(entity_kind='friend',entity_id=user,name=user),provenance=dict(source='Earlier VRC Eye notes'))
    annotation=dict(scope=target,kind='annotation',id=identity('earlier-player-note',source.account_scope,user),
        data=dict(entity=key,type='note',value=body,color=''),provenance=dict(source='Earlier VRC Eye notes',source_account=source.account_scope))
    return library.prepare([row,annotation],source='Reviewed earlier player note',policy='keep'),body


def show(shell,kind,ref):
    if kind not in ('user','friend','world','avatar','group'):raise ValueError('Select a supported saved item.')
    entity_id(kind,ref);return SavedDetails(shell,kind,ref)


class SavedDetails(LocalPage):
    def __init__(self,shell,kind,ref):
        self.kind,self.ref=kind,ref;self.window=shell.app.tk.Toplevel(shell.app.root)
        self.window.title('Saved details · '+ref);self.window.geometry('920x700')
        frame=shell.app.ttk.Frame(window_body(self.window),padding=14);frame.pack(fill='both',expand=True)
        super().__init__(shell,frame,'Saved fields and local annotations')
        self.shared=self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(frame,text='Include shared imports and earlier shared notes',variable=self.shared,command=lambda:self.guard(self.reload)).pack(anchor='w')
        self.ttk.Label(frame,text='Historical saved values with provenance. These do not establish current profile values, friendships or permissions.',wraplength=880).pack(anchor='w',pady=8)
        self.text=self.tk.Text(frame,wrap='word');self.text.pack(fill='both',expand=True)
        row=line(self);button(self,row,'Reload saved details',self.reload)
        button(self,row,'Edit shared notes / tags…',lambda:__import__('shared_notes_ui').show(self.shell,self.kind,self.ref,account=self.workspace(),on_saved=self.reload))
        if kind in ('user','friend'):button(self,row,'Review earlier note into native annotations…',self.import_note)
        button(self,row,'Close',self.close)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=self.app.root.after(200,self.tick)
        self.reload()

    def workspace(self):return getattr(self.app.api,'user_id','') or 'shared'

    def source(self):
        from player_store import PlayerStore
        return PlayerStore(getattr(self.app,'player_store_path',None),account_scope='shared' if self.shared.get() else self.workspace())

    def reload(self):
        self.ready();rows=project(self.shell.store.native,self.workspace(),self.kind,self.ref,shared=self.shared.get())
        value=json.dumps(rows,ensure_ascii=False,indent=2) if rows else 'No saved native details in the selected workspace.'
        if self.kind in ('friend','user'):
            source=self.source();note=source.note(self.ref) if source.path.is_file() else ''
            value+='\n\nEarlier notes · '+source.account_scope+'\n'+(note or 'No earlier note.')
        self.text.configure(state='normal');self.text.delete('1.0','end');self.text.insert('1.0',value);self.text.configure(state='disabled')

    def import_note(self):
        self.ready();token=self.token();source=self.source();target=self.workspace();library=self.shell.store.native
        plan,body=legacy_plan(library,source,target,self.ref)
        try:
            from creator_projects_ui import review_document
            if not review_document(self.app,'Review earlier local note',f'Source workspace: {source.account_scope}\nDestination workspace: {target}\nUser: {self.ref}\n\n{body}\n\nExisting native annotations and the original earlier note are preserved.',accept='Import this note'):return
            self.verify(token)
            if source.note(self.ref)!=body:raise ValueError('The earlier note changed. Review it again.')
            submitted=plan
            self.start(lambda c,s,p:library.commit(submitted,stop=s,check=lambda:self.verify(token)),lambda result:(self.reload(),self.status.set('Earlier note imported into native annotations.')),mutation=True)
            plan=None
        finally:
            if plan:library.discard(plan)

    def clear_preview(self):
        self.text.configure(state='normal');self.text.delete('1.0','end');self.text.configure(state='disabled');self.shared.set(False)

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(200,self.tick)

    def close(self):
        if self.closed:return
        self.app.root.after_cancel(self.timer);self.clear_preview();super().close();self.window.destroy()
