"""Application-local keyboard access, using existing widget commands only.

Owned hotkeys run before widget bindings, followed by this layer and native Tk
class bindings. Unmapped keys keep feature-specific widget behavior. The generic table-menu chord has a narrow leading tag because
Tk also matches it against existing Shift+F10 bindings. No synthesized mouse
clicks, OS hooks, or background actions.
"""
from __future__ import annotations

from text_viewport import window_body

import uuid
import weakref
import math
from tkinter import TclError
from screen_reader_model import annotate


HELP = '''VRC Eye keyboard controls

Tab / Shift+Tab: next / previous control in the current window.
F6 / Shift+F6: next / previous region (header, navigation, page, notices).
Ctrl+Page Down / Ctrl+Page Up: next / previous tab in the nearest workspace.
Enter / keypad Enter: activate the focused button. Space: native button,
checkbox or radio control. Arrow keys: lists, trees, sliders and tab strips.
Shift+F10 / Menu: selected row's actions. Ctrl+Shift+F10: table details and
sorting, including tables with their own row menu. Enter on an ordinary
table opens the full selected row; feature-specific Enter actions stay active.
Shift+Left / Shift+Right on a table: scroll columns horizontally.
Ctrl+Tab / Ctrl+Shift+Tab: leave a multiline editor without inserting a tab.
Readonly text uses Tab to leave; editable text retains normal Tab and Enter.
Escape: close a dialog through its existing close/cancel action. Tab stays
inside its window. Closing returns to the originating control when available.
F1: this help. Ctrl+K: Find a tool. Ctrl+Comma: Settings.
Ctrl+0: restore desktop text to 100%, including from an enlarged dialog.
Text-size slider: arrows change by 1 percentage point; Page Up/Down by 10.

World map: arrows pan, Shift+arrows pan farther, + / - zoom, Home fits.
Enter on the map adds a waypoint at its center. A visible button does the same.
Image and model previews have focused arrow controls and visible zoom/reset.
Graph member actions are also available in the paged member table.

Tool destinations and local commands can be mapped in Accessibility > Keyboard.
Search by action, category or assigned chord; review reassignment and use Undo.
F6 region bindings and screen-reader commands can be remapped there too.
In dialogs, F6 cycles visible control groups using its standard binding.
Hold controls still use Space press/release and release when focus leaves.
Text selection, copy/paste, AltGr and system keys remain native.
Screen reader defaults are Ctrl+Alt+F5 through Ctrl+Alt+F12.
F1 help, Ctrl+0 text recovery, native editing and dialog navigation stay available.

Alternate input: the header button opens switch scanning and pointer dwell.
Default switch keys are F8 next, F9 select and F7 pause/resume; Escape stops it.
The layout lock enables Home tile Move, Resize and Hide controls. Hidden tiles
can be restored. Dragging also has ordinary button alternatives; Escape cancels.
'''


def within(widget, parent):
    while widget is not None:
        if widget is parent:
            return True
        widget = getattr(widget, 'master', None)
    return False


def available(widget):
    try:
        if not widget.winfo_exists() or not widget.winfo_viewable():
            return False
        # A readonly Text can still be selected/copied and scrolled.
        if widget.winfo_class() == 'Text':
            return True
        if hasattr(widget, 'state'):
            return 'disabled' not in widget.state()
        try:
            return str(widget.cget('state')) != 'disabled'
        except TclError:
            return True  # Toplevels and structural controls have no state option.
    except Exception:
        return False


def focusable(widget):
    try:
        return available(widget) and bool(int(widget.tk.call('tk::FocusOK', widget)))
    except Exception:
        return False


def controls(parent):
    """Visible controls only; do not cross into a child toplevel."""
    top = parent.winfo_toplevel()
    result = []
    def visit(widget):
        if widget.winfo_toplevel() is not top or not widget.winfo_viewable():
            return
        if focusable(widget):
            result.append(widget)
        for child in widget.winfo_children():
            visit(child)
    visit(parent)
    return result


def displayed_columns(tree):
    columns = tuple(tree['columns'])
    display = tree['displaycolumns']
    if display == '#all' or tuple(display) == ('#all',):
        return columns
    return tuple(columns[int(c)] if str(c).isdigit() else c for c in display)


class KeyboardManager:
    def __init__(self, experience):
        self.experience, self.app, self.root = experience, experience.app, experience.app.root
        self.closed = False
        self.suspended = 0
        self.tag = 'VRCEyeKeyboard' + uuid.uuid4().hex
        self.table_tag = self.tag + 'Table'
        self.attached = weakref.WeakSet()
        self.windows = weakref.WeakKeyDictionary()
        self.remembered = weakref.WeakKeyDictionary()
        self.last_focus = self.root.focus_get()
        self.context = self.boundary()
        self.jobs = set()
        self.menu = None
        self.help_window = None
        self.owned_windows = {}
        self.app.keyboard = self
        self.root.bind_class(self.table_tag, '<Control-Shift-F10>', self.table_chord)
        for sequence, callback in (('<KeyPress>', self.dispatch), ('<FocusIn>', self.focused),
                                   ('<Destroy>', self.destroyed), ('<Unmap>', self.unmapped)):
            self.root.bind_class(self.tag, sequence, callback)
        self.map_id = self.root.bind_all('<Map>', self.mapped, add='+')
        self.attach_tree(self.root)

    def boundary(self):
        from account_header import boundary, private
        return boundary(self.app), private(self.app), bool(getattr(self.app, '_native_private', False))

    def sync(self):
        current = self.boundary()
        if current != self.context:
            self.context = current
            self.remembered.clear()
            if self.menu:
                try:self.menu.unpost()
                except TclError:pass
        return current

    def idle(self, callback):
        token = None
        def run():
            self.jobs.discard(token)
            if not self.closed:
                callback()
        token = self.root.after_idle(run)
        self.jobs.add(token)

    def attach(self, widget):
        try:
            if widget in self.attached:
                return
            tags = list(widget.bindtags())
            # Keep widget-specific and remapped navigation commands first.
            widget_index = tags.index(str(widget)) + 1 if str(widget) in tags else 1
            index = widget_index
            shortcuts = getattr(self.experience, 'shortcuts', None)
            if shortcuts and shortcuts.tag in tags:
                index = max(tags.index(shortcuts.tag) + 1, widget_index)
            else:
                reader = getattr(self.app, 'screen_reader', None)
                if reader and reader.tag in tags:index = max(tags.index(reader.tag) + 1, widget_index)
            tags.insert(index, self.tag)
            tags.insert(0, self.table_tag)
            widget.bindtags(tuple(tags))
            widget._eye_keyboard_top = widget.winfo_toplevel()
            self.attached.add(widget)
            if widget.winfo_class() == 'Text' and str(widget.cget('takefocus')) == '':
                widget.configure(takefocus=True)
            if widget.winfo_toplevel() is widget and widget is not self.root:
                self.windows[widget] = (self.last_focus, self.boundary())
                self.idle(lambda: self.enter_window(widget))
        except (AttributeError, TclError):
            pass

    def attach_tree(self, widget):
        self.attach(widget)
        for child in widget.winfo_children():
            self.attach_tree(child)

    def mapped(self, event):
        if not self.closed and hasattr(event.widget, 'winfo_children'):
            self.attach_tree(event.widget)

    def allowed(self, widget):
        if self.closed or self.suspended or not available(widget):
            return False
        try:
            grab = self.root.grab_current()
        except (TclError, KeyError):
            return False  # Tcl-owned native popup, outside Python's widget tree.
        # Menus and native combo popdowns own their own keyboard interaction.
        if grab is not None and (grab.winfo_class() == 'Menu' or not within(widget, grab.winfo_toplevel())):
            return False
        return widget.winfo_class() != 'Menu'

    def focus(self, widget):
        if widget is not None and self.allowed(widget) and focusable(widget):
            widget.focus_set()
            return True
        return False

    def first(self, parent):
        return next(iter(controls(parent)), None)

    def enter_window(self, window):
        if self.closed or not window.winfo_exists() or not window.winfo_viewable():
            return
        focused = self.root.focus_get()
        # Respect explicit initial focus, including password and confirmation defaults.
        if focused is not None and within(focused, window) and focusable(focused):
            return
        opener, _ = self.windows.get(window, (None, None))
        if focused is None or focused is opener or focused is window:
            self.focus(self.first(window))

    def regions(self, window):
        if window is self.root:
            shell = self.app.sidebar
            candidates = [('Header', getattr(self.app, 'header', None)),
                          ('Navigation', getattr(shell, 'nav_canvas', None)),
                          ('Page', getattr(shell, 'frames', {}).get(shell.current)),
                          ('Notices', getattr(shell, 'alert_host', None))]
        else:
            # Frames containing a list/editor/buttons form dialog regions.
            candidates = []
            for control in controls(window):
                parent = control.master
                if parent not in [p for _, p in candidates]:
                    candidates.append(('Dialog controls', parent))
        return [(name, parent) for name, parent in candidates if parent is not None and controls(parent)]

    def cycle_region(self, direction=1):
        self.sync()
        focused = self.root.focus_get()
        window = focused.winfo_toplevel() if focused is not None else self.root
        regions = self.regions(window)
        if not regions:
            return 'break'
        # Prefer the deepest matching group in dialogs.
        matches = [i for i, (_, parent) in enumerate(regions) if within(focused, parent)]
        index = matches[-1] if matches else (-1 if direction > 0 else 0)
        name, parent = regions[(index + direction) % len(regions)]
        target = self.remembered.get(parent)
        if target is None or not within(target, parent) or not self.focus(target):
            self.focus(self.first(parent))
        return 'break'

    def focused(self, event):
        if self.closed or not hasattr(event.widget, 'winfo_toplevel'):
            return
        self.sync()
        self.last_focus = event.widget
        self.reveal(event.widget)
        for _, parent in self.regions(event.widget.winfo_toplevel()):
            if within(event.widget, parent):
                self.remembered[parent] = event.widget

    def reveal(self, widget):
        from friendly_ui import focus_scroll_target
        parent = getattr(widget, 'master', None)
        while parent is not None:
            if parent.winfo_class() == 'Canvas':
                try:
                    box = parent.bbox('all')
                    if box:
                        for axis, index, root_pos, size in (('x',0,'winfo_rootx','winfo_width'),('y',1,'winfo_rooty','winfo_height')):
                            start = getattr(parent, 'canvas' + axis)(0)
                            position = start + getattr(widget, root_pos)() - getattr(parent, root_pos)()
                            target = focus_scroll_target(position, getattr(widget, size)(), getattr(parent, size)(), start)
                            extent = box[index+2]-box[index]
                            if extent > 0 and target != start:
                                getattr(parent, axis+'view_moveto')(max(0, (target-box[index])/extent))
                except TclError:
                    pass
            parent = getattr(parent, 'master', None)

    def focus_content(self):
        parent = getattr(self.app.sidebar, 'frames', {}).get(self.app.sidebar.current)
        if parent is not None:
            self.focus(self.first(parent))

    def page_changed(self):
        self.sync()
        focused = self.root.focus_get()
        if focused is not None and focused.winfo_toplevel() is self.root and not available(focused):
            self.idle(self.focus_content)

    def unmapped(self, event):
        focused = self.root.focus_get()
        if focused is not None and hasattr(event.widget, 'winfo_toplevel') and within(focused, event.widget):
            top = focused.winfo_toplevel()
            if top is self.root:
                self.idle(self.page_changed)

    def destroyed(self, event):
        widget = event.widget
        if widget not in self.windows:
            if within(self.last_focus, widget):
                top = getattr(widget, '_eye_keyboard_top', self.root)
                parent = getattr(widget, 'master', None)
                identity = getattr(widget, '_eye_focus_identity', None)
                context = self.boundary()
                def repair():
                    if not top.winfo_exists() or not top.winfo_viewable():return
                    focused = self.root.focus_get()
                    if focused is not None and focusable(focused):return
                    if identity is not None and context == self.boundary() and parent is not None and parent.winfo_exists():
                        for child in parent.winfo_children():
                            if getattr(child, '_eye_focus_identity', None) == identity and self.focus(child):return
                    if top is self.root:self.focus_content()
                    else:self.focus(self.first(top))
                self.idle(repair)
            return
        opener, context = self.windows.pop(widget)
        for parent in tuple(self.remembered):
            if within(parent, widget):self.remembered.pop(parent, None)
        def restore():
            focused = self.root.focus_get()
            if focused is not None and focusable(focused):
                return  # Another dialog or explicit close callback already chose focus.
            if context == self.boundary() and self.focus(opener):
                return
            if self.root.grab_current() is None:
                self.focus_content()
        self.idle(restore)

    def traverse(self, widget, direction):
        cursor, visited = widget, set()
        while str(cursor) not in visited:
            visited.add(str(cursor))
            target = cursor.tk_focusPrev() if direction < 0 else cursor.tk_focusNext()
            if target.winfo_toplevel() is not widget.winfo_toplevel():break
            if self.focus(target):break
            cursor = target
        return 'break'

    def change_tab(self, widget, direction):
        node = widget
        notebook = None
        while node is not None:
            if node.winfo_class() == 'TNotebook':
                notebook = node
                break
            # Friendly tab strips are siblings of the notebook.
            notebook = getattr(node, '_eye_notebook', None)
            if notebook is not None:
                break
            node = getattr(node, 'master', None)
        if notebook is None:
            return None
        tabs = [tab for tab in notebook.tabs() if str(notebook.tab(tab, 'state')) == 'normal']
        if not tabs:
            return 'break'
        selected = str(notebook.select())
        index = tabs.index(selected) if selected in tabs else 0
        notebook.select(tabs[(index + direction) % len(tabs)])
        # Newly selected contents have not necessarily mapped yet.
        def finish():
            if notebook.winfo_exists():
                self.focus(self.first(notebook.nametowidget(notebook.select())))
        self.idle(finish)
        return 'break'

    def dispatch(self, event):
        widget = event.widget
        if not hasattr(widget, 'winfo_class') or not self.allowed(widget):
            return None
        self.sync()
        state = int(event.state)
        # Tk's Windows Extended flag (AnyModifier << 3) marks keypad Enter
        # and cursor-cluster keys, not a user-held command modifier.
        if state & ~(1 | 2 | 4 | 16 | 0x40000):
            return None  # Alt, AltGr, Super and screen-reader chords.
        shift, ctrl = bool(state & 1), bool(state & 4)
        key, kind = event.keysym, widget.winfo_class()
        if ctrl and not shift and key in ('0', 'KP_0'):
            page = self.app.sidebar.pages.get('Accessibility')
            if page:page.change(dict(font_scale=100))
            else:self.experience.change(font_scale=100)
            return 'break'
        if key == 'F1' and not ctrl and not shift:
            self.show_help()
            return 'break'
        if key == 'F6' and not ctrl:
            if widget.winfo_toplevel() is self.root:
                return None  # Main-window F6 belongs to the remappable registry.
            return self.cycle_region(-1 if shift else 1)
        navigation = getattr(self.app.sidebar, 'nav_canvas', None)
        if not ctrl and not shift and navigation is not None and within(widget, navigation):
            if key in ('Up', 'Down', 'Home', 'End'):
                buttons = [w for w in controls(navigation) if w.winfo_class() in ('TButton', 'Button')]
                if buttons:
                    index = buttons.index(widget) if widget in buttons else 0
                    target = 0 if key == 'Home' else len(buttons)-1 if key == 'End' else (index + (-1 if key == 'Up' else 1)) % len(buttons)
                    self.focus(buttons[target])
                return 'break'
        if ctrl and not shift and key in ('Prior', 'Next'):
            return self.change_tab(widget, -1 if key == 'Prior' else 1)
        if kind == 'TScale' and not ctrl and key in ('Left','Right','Up','Down','Prior','Next','Home','End'):
            lower, upper, current = float(widget.cget('from')), float(widget.cget('to')), float(widget.get())
            if all(math.isfinite(n) for n in (lower, upper, current)):
                step = (upper-lower) * (.1 if shift or key in ('Prior','Next') else .01)
                if hasattr(widget, '_eye_keyboard_step'):
                    step = widget._eye_keyboard_step * (10 if shift or key in ('Prior','Next') else 1)
                value = lower if key == 'Home' else upper if key == 'End' else current + step * (-1 if key in ('Left','Up','Prior') else 1)
                widget.set(max(min(lower,upper), min(max(lower,upper), value)))
            return 'break'
        if key in ('Tab', 'ISO_Left_Tab'):
            if kind == 'Text' and str(widget.cget('state')) != 'disabled' and not ctrl:
                return None
            if ctrl and kind != 'Text':
                return None  # Native notebook traversal.
            return self.traverse(widget, -1 if shift or key == 'ISO_Left_Tab' else 1)
        if kind == 'Treeview' and (key == 'Menu' and not ctrl or key == 'F10' and shift):
            # Feature menus retain their actions; Ctrl+Shift+F10 always offers details/sort.
            if not ctrl and widget.bind('<Shift-F10>'):
                if key == 'Menu' and not widget.bind('<KeyPress-Menu>'):
                    widget.event_generate('<Shift-F10>')
                return 'break'
            self.table_menu(widget)
            return 'break'
        if kind == 'Treeview' and shift and not ctrl and key in ('Left', 'Right'):
            widget.xview_scroll(-1 if key == 'Left' else 1, 'units')
            return 'break'
        if key in ('Return', 'KP_Enter') and not ctrl and not shift:
            # Don't dispatch a widget-specific handler twice when it returns None.
            sequence = '<' + key + '>'
            if widget.bind(sequence):
                return 'break'
            if key == 'KP_Enter' and widget.bind('<Return>'):
                widget.event_generate('<Return>')
                return 'break'
            if kind in ('TButton', 'Button', 'TCheckbutton', 'Checkbutton', 'TRadiobutton', 'Radiobutton'):
                if not getattr(widget, '_eye_hold_control', False):
                    widget.invoke()
                return 'break'
            if kind == 'Treeview':
                self.table_details(widget)
                return 'break'
        if key == 'Escape' and not ctrl and not shift:
            editor=getattr(self.experience,'layout_editor',None)
            if editor is not None and editor.drag is not None:return editor.cancel_drag()
            window = widget.winfo_toplevel()
            if window is not self.root and not window.bind('<Escape>') and not widget.bind('<Escape>'):
                command = window.protocol('WM_DELETE_WINDOW')
                if command:
                    window.tk.call('eval', command)
                else:
                    window.destroy()
                return 'break'
        return None

    def table_chord(self, event):
        widget = event.widget
        if not hasattr(widget, 'winfo_class') or widget.winfo_class() != 'Treeview' or not self.allowed(widget):return None
        if int(event.state) & ~(1 | 2 | 4 | 16 | 0x40000):return None
        shortcuts = getattr(self.experience, 'shortcuts', None)
        dispatch = getattr(shortcuts, 'dispatch', None)
        if callable(dispatch) and dispatch(event) == 'break':return 'break'
        self.sync()
        self.table_menu(widget)
        return 'break'

    def table_menu(self, tree):
        if self.menu:
            self.menu.destroy()
        menu = self.app.tk.Menu(tree, tearoff=False)
        self.menu = menu
        context = self.boundary()
        revision = getattr(tree, '_eye_content_revision', 0)
        def valid():
            return context == self.boundary() and available(tree) and revision == getattr(tree, '_eye_content_revision', 0)
        menu.add_command(label='Read full selected row…', command=lambda: self.table_details(tree) if valid() else None,
                         state='normal' if tree.selection() else 'disabled')
        for column in displayed_columns(tree):
            command = tree.heading(column, 'command')
            if command:
                label = tree.heading(column, 'text') or str(column)
                def sort(c=column, original=command):
                    if valid() and tree.heading(c, 'command') == original:
                        tree.tk.call('eval', original)
                menu.add_command(label='Sort by ' + str(label), command=sort)
        selection = tree.selection()
        box = tree.bbox(selection[0]) if selection else ()
        x = tree.winfo_rootx() + 16
        y = tree.winfo_rooty() + (box[1] + box[3] if box else 24)
        menu.tk_popup(x, y)
        menu.focus_set()
        menu.activate(0)

    def table_details(self, tree):
        from screen_reader_tk import SECRET, protected, label_for
        selection = tree.selection()
        if not selection:
            return
        context = self.boundary()
        if context[1] or context[2] or protected(tree,label_for(tree)):
            text = 'Row details are hidden by the active privacy mode.'
        else:
            sections = []
            for row in selection[:100]:
                data = tree.item(row)
                values = tuple(data.get('values', ()))
                columns = tuple(tree['columns'])
                lines = [str(data.get('text', ''))] if data.get('text') else []
                for column in displayed_columns(tree):
                    name = str(tree.heading(column, 'text') or column)
                    value = values[columns.index(column)] if column in columns and columns.index(column) < len(values) else ''
                    lines.append(name + ': ' + ('Protected' if SECRET.search(name) else str(value)))
                sections.append('\n'.join(lines))
            text = '\n\n'.join(sections)
            if len(selection) > 100:
                text += '\n\nFirst 100 selected rows shown. Select fewer rows to read the others.'
        stamp = (selection, repr([tree.item(row) for row in selection]), getattr(tree, '_eye_content_revision', 0))
        def valid():
            if context != self.boundary() or not available(tree):
                return False
            try:
                return stamp == (tree.selection(), repr([tree.item(row) for row in selection]), getattr(tree, '_eye_content_revision', 0))
            except TclError:
                return False
        self.text_window('Table row details', text, source=tree, valid=valid)

    def text_window(self, title, text, *, source=None, valid=None):
        app = self.app
        parent = source.winfo_toplevel() if source is not None else (self.root.focus_get() or self.root).winfo_toplevel()
        window = app.tk.Toplevel(parent)
        window.title(title)
        window.transient(parent)
        window.geometry('780x540')
        window.minsize(480, 320)
        body = app.ttk.Frame(window_body(window), padding=14)
        body.pack(fill='both', expand=True)
        content = annotate(app.tk.Text(body, wrap='word', takefocus=True), name=title)
        scroll = app.ttk.Scrollbar(body, orient='vertical', command=content.yview)
        content.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        content.pack(fill='both', expand=True)
        content.insert('1.0', text)
        content.configure(state='disabled')
        jobs = []
        old_grab = self.root.grab_current()
        context = self.boundary()
        def close():
            for job in jobs:
                window.after_cancel(job)
            jobs.clear()
            self.owned_windows.pop(window, None)
            window.destroy()
            if context == self.boundary() and old_grab is not None and old_grab.winfo_exists() and self.root.grab_current() is None:
                old_grab.grab_set()
            if context == self.boundary():self.focus(source)
        self.owned_windows[window] = close
        app.ttk.Button(body, text='Close', command=close).pack(anchor='w', pady=(8, 0))
        window.protocol('WM_DELETE_WINDOW', close)
        window.bind('<Escape>', lambda _: (close(), 'break')[-1])
        def check():
            jobs.clear()
            if not window.winfo_exists() or self.closed:
                return
            if not valid():
                content.configure(state='normal')
                content.delete('1.0', 'end')
                content.insert('1.0', 'The source or privacy context changed. Close this view and select the row again.')
                content.configure(state='disabled')
                return
            jobs.append(window.after(100, check))
        if valid:
            check()
        # Keep an existing confirmation's grab; the child temporarily owns it.
        if old_grab is not None:
            window.grab_set()
        content.focus_set()
        return window

    def show_help(self):
        if self.help_window is not None and self.help_window.winfo_exists():
            self.help_window.lift()
            self.focus(self.first(self.help_window))
            return
        self.help_window = self.text_window('Keyboard help', HELP, source=self.root.focus_get())

    def close(self):
        if self.closed:
            return
        self.closed = True
        for close in tuple(self.owned_windows.values()):
            close()
        for job in self.jobs:
            self.root.after_cancel(job)
        self.jobs.clear()
        if self.menu:
            self.menu.destroy()
        for widget in tuple(self.attached):
            try:
                if widget.winfo_exists():
                    widget.bindtags(tuple(tag for tag in widget.bindtags() if tag not in (self.tag, self.table_tag)))
            except TclError:
                pass
        for sequence in ('<KeyPress>', '<FocusIn>', '<Destroy>', '<Unmap>'):
            self.root.unbind_class(self.tag, sequence)
        self.root.unbind_class(self.table_tag, '<Control-Shift-F10>')
        if self.map_id:
            self.root._unbind(('bind', 'all', '<Map>'), self.map_id)
        self.windows.clear()
        self.remembered.clear()
