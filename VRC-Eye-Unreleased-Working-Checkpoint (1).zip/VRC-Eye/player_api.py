"""Player profile reads and explicit self/owned-avatar actions on the existing session."""
from datetime import datetime, timezone
import re
from urllib.parse import quote, urlencode

from avatar_links import parse_avatar_reference
from avatar_search import check_offset
from player_platforms import parse_user_id
from player_profile import section_snapshot, self_patch, avatar_patch, clean
from vrchat_api import APIError, METADATA_INTERVAL

PAGE = 100


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def context(client):
    client._check()
    if not client.authenticated:
        raise APIError("Connect to VRChat first.")
    return client.user_id, client.session_revision


def check_context(client, expected, stop):
    client._check(stop)
    if not client.authenticated or (client.user_id, client.session_revision) != expected:
        raise APIError("The signed-in account changed. Reopen the action.")


def lock(client, stop):
    while not client.lock.acquire(timeout=.1):
        client._check(stop)


def read_section(client, user_id, section, *, offset=0, group=None, stop=None, progress=None):
    user_id = parse_user_id(user_id)
    check_offset(offset)
    expected = context(client)
    own = expected[0] == user_id
    many = False
    page = False
    identity = section in ("public", "account", "activity")
    if section == "public":
        path = f"profile/{user_id}?withGroupsAndWorlds=true" + ("&asSelf=true" if own else "")
    elif section == "account":
        path = "auth/user" if own else "users/" + user_id
    elif section == "activity":
        path = f"profile/{user_id}/private"
    elif section == "groups":
        path, many = f"users/{user_id}/groups", True
    elif section == "mutuals":
        path, many, page = f"users/{user_id}/mutuals/friends?" + urlencode(dict(n=PAGE, offset=offset)), True, True
    elif section == "favorite-lists":
        path, many, page = "favorite/groups?" + urlencode(dict(ownerId=user_id, n=PAGE, offset=offset)), True, True
    elif section == "favorite-items":
        if (not isinstance(group, dict) or group.get("ownerId") != user_id or
                group.get("type") not in ("world", "vrcPlusWorld", "avatar") or
                not isinstance(group.get("name"), str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", group["name"])):
            raise ValueError("Select a returned world/avatar favorite list belonging to this player.")
        path = f"favorites/groups/{group['type']}/{quote(group['name'], safe='')}?" + urlencode(dict(ownerId=user_id))
    elif section == "credits":
        if not own: raise ValueError("Credit balance is available only for your signed-in account.")
        path = f"user/{user_id}/balance"
    elif section == "avatars":
        if not own: raise ValueError("Other players' complete avatar libraries are unavailable. See their reported current avatar and observed changes.")
        path, many, page = "avatars?" + urlencode(dict(user="me", releaseStatus="all", n=PAGE, offset=offset, sort="name", order="ascending")), True, True
    else:
        raise ValueError("Unknown player profile section.")
    key = ("player-section", user_id, path)
    lock(client, stop)
    try:
        check_context(client, expected, stop)
        cached = client.cache.get(key)
        if cached and client.clock() - cached[0] < METADATA_INTERVAL:
            return cached[1]
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        document = client._request(path, expect_list=many)
        check_context(client, expected, stop)
        if many and len(document) > (PAGE if page else 2000):
            raise ValueError("VRChat returned more entries than the supported limit.")
        more = bool(page and len(document) == PAGE)
        if section == "favorite-lists":
            # A response for a different owner must not silently substitute their collection.
            for item in document:
                if not isinstance(item, dict) or item.get("ownerId") != user_id:
                    raise ValueError("A favorite list did not match the requested owner.")
        if section == "favorite-items":
            if not isinstance(document.get("favorites"), list) or len(document["favorites"]) > 2000:
                raise ValueError("VRChat did not return a supported favorite list.")
        if section == "avatars" and any(not isinstance(item, dict) or item.get("authorId") != user_id for item in document):
            raise ValueError("An avatar in My uploads did not belong to the signed-in account.")
        if section == "credits" and (type(document.get("balance")) is not int or document["balance"] < 0):
            raise ValueError("VRChat did not return a supported credit balance.")
        result = section_snapshot(document, user_id, section, stamp(), offset=offset, more=more, identity=identity)
        client.cache[key] = (client.clock(), result)
        if len(client.cache) > 200:
            client.cache.pop(next(iter(client.cache)))
        return result
    finally:
        client.lock.release()


def invalidate(client, user_id="", avatar_id=""):
    for key in tuple(client.cache):
        if ((user_id and key[0] in ("player-section", "user") and user_id in key) or
                (avatar_id and (avatar_id in key or key[0] == "avatar-search" or
                               key[0] == "player-section"))):
            client.cache.pop(key, None)


def update_self(client, user_id, values, *, stop=None, progress=None, before_dispatch=None, on_confirmed=None):
    user_id, values = parse_user_id(user_id), self_patch(values)
    expected = context(client)
    if user_id != expected[0]:
        raise ValueError("You can edit only your signed-in account.")
    lock(client, stop)
    try:
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        if before_dispatch: before_dispatch()
        check_context(client, expected, stop)
        document = client._request("users/" + user_id, payload=values, method="PUT")
        # The write may have reached VRChat even if a disconnect/cancellation occurs afterwards.
        invalidate(client, user_id=user_id)
        result = section_snapshot(document, user_id, "account", stamp())
        if on_confirmed:
            if any(document.get(key) != value for key, value in values.items()):
                raise APIError("The returned profile did not confirm every changed field.")
            on_confirmed()
        check_context(client, expected, stop)
        return result
    finally:
        client.lock.release()


def send_boop(client, user_id, *, stop=None, progress=None):
    user_id = parse_user_id(user_id)
    expected = context(client)
    if user_id == expected[0]:
        raise ValueError("Choose another player to boop.")
    lock(client, stop)
    try:
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        document = client._request(f"users/{user_id}/boop", payload={})
        check_context(client, expected, stop)
        success = document.get("success")
        if not isinstance(success, dict) or success.get("status_code") != 200:
            raise APIError("VRChat did not confirm the boop. It was not retried.")
        return "VRChat confirmed the boop."
    finally:
        client.lock.release()


def owned_avatar(client, reference, *, stop=None, progress=None):
    reference = parse_avatar_reference(reference)
    expected = context(client)
    lock(client, stop)
    try:
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        data = client._request("avatars/" + reference)
        check_context(client, expected, stop)
        if data.get("id") != reference or data.get("authorId") != expected[0]:
            raise ValueError("This avatar does not belong to your signed-in account.")
        return {"account": expected, "checked": client.clock(), "data": clean(data)}
    finally:
        client.lock.release()


def update_owned_avatar(client, snapshot, values, *, stop=None, progress=None):
    values = avatar_patch(values)
    expected = context(client)
    if (not isinstance(snapshot, dict) or snapshot.get("account") != expected or
            not isinstance(snapshot.get("data"), dict) or snapshot["data"].get("authorId") != expected[0] or
            not 0 <= client.clock() - snapshot.get("checked", -99999) < 300):
        raise ValueError("Load this owned avatar again before saving; the ownership check is stale or belongs to another account.")
    reference = parse_avatar_reference(snapshot["data"].get("id"))
    lock(client, stop)
    try:
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        if not 0 <= client.clock() - snapshot["checked"] < 300:
            raise ValueError("Ownership check expired while queued. Load the avatar again.")
        result = client._request("avatars/" + reference, payload=values, method="PUT")
        invalidate(client, avatar_id=reference)
        check_context(client, expected, stop)
        if result.get("id") != reference or result.get("authorId") != expected[0]:
            raise ValueError("The returned avatar identity/owner changed. Refresh to check whether the write took effect.")
        return {"account": expected, "checked": client.clock(), "data": clean(result)}
    finally:
        client.lock.release()
