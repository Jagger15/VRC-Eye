"""Reviewed, bounded OSC routes, transformations, presets, and local rules.

Configuration is data, never authority. All output passes through OSCService's
registry, source permission, ownership and context checks. No socket is opened
by this module. Managed-route policy covers only traffic routed through Eye.
"""
from __future__ import annotations

from copy import deepcopy
from collections import deque
import json
import ipaddress
import math
import re
import time
import uuid

from osc_registry import same_arguments


class RouteError(ValueError):
    pass


MAX_IMPORT_BYTES = 262144
MAX_ROUTES, MAX_PRESETS, MAX_RULES = 64, 32, 32
AUDIENCES = ("local", "avatar", "peer", "diagnostic")
IDENTITIES = ("configured-label", "local-adapter", "authenticated-peer")
TYPES = ("bool", "int", "float", "vector2", "vector3", "vector4", "vector6")
EYE_ENDPOINTS = {"center-pitch-yaw": ("CenterPitchYaw", "vector2"),
                 "center-pitch-yaw-distance": ("CenterPitchYawDist", "vector3"),
                 "left-right-pitch-yaw": ("LeftRightPitchYaw", "vector4"),
                 "left-right-vec": ("LeftRightVec", "vector6"),
                 "center-vec": ("CenterVec", "vector3"),
                 "center-vec-full": ("CenterVecFull", "vector3")}
EYE_REPRESENTATIONS = tuple(EYE_ENDPOINTS)
SAFE_PRESET_PERMISSIONS = frozenset(("avatar.parameters", "camera"))
EXCLUDED_PRESET_ADDRESSES = frozenset(("/usercamera/Streaming", "/usercamera/AudioFromCamera"))


def _number(value, name, minimum=-1e9, maximum=1e9):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise RouteError(f"{name} must be a finite number from {minimum} to {maximum}.")
    return float(value)


def _text(value, name, maximum=160, identifier=False):
    if not isinstance(value, str) or not value or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise RouteError(f"Invalid {name}.")
    if identifier and not re.fullmatch(r"[A-Za-z0-9_.-]+", value):
        raise RouteError(f"{name} accepts letters, digits, dots, underscores and hyphens.")
    return value


def _fields(value, allowed, required=()):
    if not isinstance(value, dict) or set(value) - set(allowed) or set(required) - set(value):
        raise RouteError("Configuration has unknown or missing fields.")


def _typed(value, kind):
    if kind == "bool" and type(value) is bool:
        return value
    if kind == "int" and type(value) is int and -(2 ** 31) <= value < 2 ** 31:
        return value
    if kind == "float" and type(value) in (int, float):
        return _number(value, "sample", -3.4e38, 3.4e38)
    if kind.startswith("vector") and isinstance(value, (list, tuple)) and len(value) == int(kind[-1]):
        return tuple(_number(v, "coordinate", -100000, 100000) for v in value)
    raise RouteError(f"Value is not a valid {kind}.")


def _args(value, kind):
    return tuple(value) if kind.startswith("vector") else (value,)


def _pipeline(steps, kind, command="state"):
    if not isinstance(steps, list) or len(steps) > 12:
        raise RouteError("A transform pipeline permits at most 12 steps.")
    result = []
    scalar = kind in ("int", "float")
    for step in steps:
        if not isinstance(step, dict):
            raise RouteError("Transform must be an object.")
        op = step.get("op")
        if op in ("scale", "offset"):
            _fields(step, ("op", "value"), ("value",))
            if kind.startswith("vector") and op == "offset":
                _typed(step["value"], kind)
            else: _number(step["value"], op, -100000, 100000)
            if not scalar and not kind.startswith("vector"):
                raise RouteError("Numeric transforms require numeric source data.")
        elif op == "axis_map":
            _fields(step, ("op", "axes", "signs"), ("axes", "signs"))
            count = int(kind[-1]) if kind.startswith("vector") else 0
            if not count or not isinstance(step["axes"], list) or any(type(i) is not int for i in step["axes"]) or sorted(step["axes"]) != list(range(count)):
                raise RouteError("Axis mapping must be a permutation of the vector axes.")
            if not isinstance(step["signs"], list) or len(step["signs"]) != count or any(type(v) not in (int, float) or v not in (-1, 1) for v in step["signs"]):
                raise RouteError("Each mapped axis requires a sign of 1 or -1.")
        elif op in ("clamp", "hysteresis"):
            _fields(step, ("op", "min", "max", "below"), ("min", "max"))
            if not scalar or _number(step["min"], "min") >= _number(step["max"], "max"):
                raise RouteError("Transform requires ascending numeric limits.")
            if "below" in step and type(step["below"]) is not bool:
                raise RouteError("below must be a boolean.")
            if op == "hysteresis":
                kind, scalar = "bool", False
        elif op in ("deadzone", "threshold", "smooth", "debounce"):
            _fields(step, ("op", "value"), ("value",))
            bounds = (0, 1) if op == "smooth" else (0, 10) if op == "debounce" else (0, 1e6)
            _number(step["value"], op, *bounds)
            if op == "debounce":
                if kind != "bool":
                    raise RouteError("Debounce requires boolean state.")
            elif not scalar and not (op == "smooth" and kind.startswith("vector")):
                raise RouteError("Transform requires numeric state.")
            if op == "smooth" and command not in ("state", "continuous", "tracking"):
                raise RouteError("Smoothing is allowed only for continuous state.")
            if op == "threshold":
                kind, scalar = "bool", False
        elif op == "invert":
            _fields(step, ("op",))
            if kind not in ("bool", "int", "float"):
                raise RouteError("Invert requires a scalar.")
        elif op == "boolean":
            _fields(step, ("op",))
            if not scalar and kind != "bool":
                raise RouteError("Boolean conversion requires a scalar.")
            kind, scalar = "bool", False
        elif op == "enum":
            _fields(step, ("op", "mapping"), ("mapping",))
            mapping = step["mapping"]
            if kind not in ("int", "bool") or not isinstance(mapping, dict) or not 1 <= len(mapping) <= 64:
                raise RouteError("Enum mapping requires integer/boolean input and at most 64 entries.")
            values = list(mapping.values())
            if any(type(v) not in (bool, int, float) for v in values):
                raise RouteError("Enum outputs must be typed scalar data.")
            kinds = {"bool" if type(v) is bool else "int" if type(v) is int else "float" for v in values}
            if len(kinds) != 1:
                raise RouteError("Enum outputs must have one exact type.")
            kind = kinds.pop()
            scalar = kind in ("int", "float")
            for key, value in mapping.items():
                if not isinstance(key, str) or not re.fullmatch(r"true|false|-?\d{1,11}", key):
                    raise RouteError("Invalid enum key.")
                _typed(value, kind)
        elif op == "edge":
            _fields(step, ("op", "direction"))
            if kind != "bool" or step.get("direction", "rising") not in ("rising", "falling", "either"):
                raise RouteError("Edge transform requires boolean state and a known direction.")
        else:
            raise RouteError("Unknown transform; scripts and expressions are not supported.")
        result.append(deepcopy(step))
    return result, kind


class TransformPipeline:
    """Small stateful typed pipeline. None means suppressed, not a zero value."""
    def __init__(self, steps=(), input_type="float", output_type="float", command="state"):
        if input_type not in TYPES or output_type not in TYPES:
            raise RouteError("Unsupported source or destination type.")
        self.steps, final_type = _pipeline(list(steps), input_type, command)
        if final_type != output_type and not (final_type == "int" and output_type == "float"):
            raise RouteError("Pipeline result type does not match its declared destination.")
        self.input_type, self.output_type = input_type, output_type
        self.state = {}
        self.last_preview = []

    def reset(self):
        self.state.clear()

    def apply(self, raw, now):
        value = _typed(raw, self.input_type)
        self.last_preview = [{"stage": "source", "value": value}]
        for index, step in enumerate(self.steps):
            op = step["op"]
            previous = self.state.get(index)
            if op == "scale": value = tuple(v * step["value"] for v in value) if isinstance(value, tuple) else value * step["value"]
            elif op == "offset": value = tuple(v + shift for v, shift in zip(value, step["value"])) if isinstance(value, tuple) else value + step["value"]
            elif op == "axis_map": value = tuple(value[axis] * sign for axis, sign in zip(step["axes"], step["signs"]))
            elif op == "clamp": value = min(step["max"], max(step["min"], value))
            elif op == "invert": value = not value if type(value) is bool else -value
            elif op == "deadzone": value = 0 if abs(value) <= step["value"] else value
            elif op == "threshold": value = value >= step["value"]
            elif op == "boolean": value = bool(value)
            elif op == "enum":
                key = str(value).lower()
                if key not in step["mapping"]:
                    raise RouteError("Enum value has no declared mapping.")
                value = step["mapping"][key]
            elif op == "hysteresis":
                below = step.get("below", True)
                active = previous if previous is not None else False
                if value <= step["min"]: active = below
                elif value >= step["max"]: active = not below
                self.state[index], value = active, active
            elif op == "smooth":
                if previous is not None:
                    value = tuple(old + step["value"] * (new - old) for old, new in zip(previous, value)) if isinstance(value, tuple) else previous + step["value"] * (value - previous)
                self.state[index] = value
            elif op == "debounce":
                candidate, since, accepted = previous if previous is not None else (value, now, None)
                if value != candidate: candidate, since = value, now
                if now - since >= step["value"]: accepted = candidate
                self.state[index] = (candidate, since, accepted)
                if accepted is None: return None
                value = accepted
            elif op == "edge":
                self.state[index] = value
                # An initially held signal is not an event. Observe a baseline first.
                if previous is None or previous == value: return None
                direction = step.get("direction", "rising")
                if direction == "rising" and not value or direction == "falling" and value: return None
            self.last_preview.append({"stage": op, "value": value})
        return _typed(value, self.output_type)


def validate_configuration(source):
    if isinstance(source, (str, bytes)):
        raw = source.encode("utf-8") if isinstance(source, str) else source
        if len(raw) > MAX_IMPORT_BYTES:
            raise RouteError("OSC configuration is limited to 256 KiB.")
        try:
            source = json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(RouteError("Non-finite JSON value.")))
        except (ValueError, UnicodeError, RecursionError) as exc:
            raise RouteError("Invalid bounded JSON configuration.") from exc
    try:
        encoded = json.dumps(source, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError, RecursionError) as exc:
        raise RouteError("Configuration must contain finite JSON data.") from exc
    if len(encoded) > MAX_IMPORT_BYTES:
        raise RouteError("OSC configuration is limited to 256 KiB.")
    _fields(source, ("schema", "routes", "presets", "rules"), ("schema",))
    if type(source["schema"]) is not int or source["schema"] != 1:
        raise RouteError("Unsupported configuration schema.")
    result = {"schema": 1, "routes": [], "presets": [], "rules": []}
    for name, maximum in (("routes", MAX_ROUTES), ("presets", MAX_PRESETS), ("rules", MAX_RULES)):
        rows = source.get(name, [])
        if not isinstance(rows, list) or len(rows) > maximum:
            raise RouteError(f"Too many {name}; maximum {maximum}.")
        seen = set()
        for raw in rows:
            item = deepcopy(raw)
            if not isinstance(item, dict): raise RouteError("Each configuration record must be an object.")
            key = _text(item.get("id"), "id", 64, True)
            if key in seen: raise RouteError("Duplicate configuration id.")
            seen.add(key)
            _text(item.get("label", key), "label")
            if name == "routes": _validate_route(item)
            elif name == "presets": _validate_preset(item)
            else: _validate_rule(item)
            result[name].append(item)
    return result


def _address(value):
    _text(value, "address", 240)
    if not value.startswith("/") or any(c in value for c in " *?[]{},#\\"):
        raise RouteError("Only a single exact OSC address is supported.")
    return value


def _validate_route(item):
    _fields(item, ("id", "label", "source_id", "source_identity", "source_endpoint", "source_address", "capabilities", "audience", "address", "input_type", "output_type", "transforms", "rate_hz", "max_age", "kind", "tracking", "deduplicate"), ("id", "source_id", "capabilities", "audience", "address", "input_type", "output_type"))
    _text(item["source_id"], "source_id", 64, True)
    if item.get("source_identity", "configured-label") not in IDENTITIES: raise RouteError("Unknown source identity classification.")
    if "source_endpoint" in item or "source_address" in item:
        _fields(item.get("source_endpoint"), ("host", "port"), ("host", "port"))
        source = item["source_endpoint"]
        try:
            host = ipaddress.IPv4Address(source["host"])
        except (ValueError, TypeError): raise RouteError("Managed UDP routes need an exact literal IPv4 source host.") from None
        if type(source["host"]) is not str or host.is_unspecified or host.is_multicast or str(host) == "255.255.255.255": raise RouteError("Managed UDP source must be one explicit unicast host.")
        if type(source["port"]) is not int or not 1 <= source["port"] <= 65535: raise RouteError("Managed UDP source port must be 1 to 65535.")
        _address(item.get("source_address"))
        if item.get("source_identity", "configured-label") != "configured-label": raise RouteError("Raw UDP endpoint labels cannot claim authenticated or verified application identity.")
    if item["audience"] not in AUDIENCES: raise RouteError("Unknown route audience.")
    if not isinstance(item["capabilities"], list) or not 1 <= len(item["capabilities"]) <= 8: raise RouteError("Declare one to eight narrow capabilities.")
    for scope in item["capabilities"]: _text(scope, "capability", 64, True)
    _address(item["address"])
    kind = item.get("kind", "state")
    if kind not in ("state", "eye", "body"): raise RouteError("Unknown route kind.")
    if item["address"].startswith("/tracking/eye/") and kind != "eye": raise RouteError("Eye endpoints require an explicit eye route and representation.")
    if item["address"].startswith("/tracking/trackers/") and kind != "body": raise RouteError("Tracker endpoints require explicit body coordinates and units.")
    TransformPipeline(item.get("transforms", []), item["input_type"], item["output_type"], "tracking" if kind != "state" else "state")
    _number(item.get("rate_hz", 10), "rate_hz", .1, 120)
    _number(item.get("max_age", .5), "max_age", .02, 30)
    if "deduplicate" in item and type(item["deduplicate"]) is not bool: raise RouteError("deduplicate must be boolean.")
    tracking = item.get("tracking", {})
    if kind == "eye":
        _fields(tracking, ("representation", "channel"), ("representation",))
        if tracking["representation"] not in EYE_REPRESENTATIONS: raise RouteError("Declare one supported eye representation.")
        if tracking.get("channel", "look") not in ("look", "eyelids"): raise RouteError("Unknown eye tracking channel.")
        endpoint, output_type = ("EyesClosedAmount", "float") if tracking.get("channel", "look") == "eyelids" else EYE_ENDPOINTS[tracking["representation"]]
        if item["address"] != "/tracking/eye/" + endpoint or item["output_type"] != output_type:
            raise RouteError("Eye endpoint and output type must match the declared representation.")
    elif kind == "body":
        _fields(tracking, ("tracker", "units", "coordinates", "rotation", "purpose"), ("tracker", "units", "coordinates", "rotation"))
        if not (type(tracking["tracker"]) is int and 1 <= tracking["tracker"] <= 8 or tracking["tracker"] == "head"): raise RouteError("Body tracker must be 1 through 8 or an explicit head alignment reference.")
        if tracking["tracker"] == "head" and tracking.get("purpose") != "alignment": raise RouteError("Head reference messages are alignment data; declare purpose as alignment.")
        if "purpose" in tracking and tracking["purpose"] not in ("tracker", "alignment"): raise RouteError("Unknown body route purpose.")
        if (tracking["units"], tracking["coordinates"], tracking["rotation"]) != ("meters", "Unity", "Euler-degrees"):
            raise RouteError("Body tracking requires real meters, Unity coordinates and Euler degrees.")
        if item["output_type"] != "vector3" or item["address"] not in (f'/tracking/trackers/{tracking["tracker"]}/position', f'/tracking/trackers/{tracking["tracker"]}/rotation'):
            raise RouteError("Body route must match its exact tracker position or rotation endpoint.")
    elif tracking: raise RouteError("Tracking metadata belongs only to tracking routes.")


def _assignments(rows):
    if not isinstance(rows, list) or not 1 <= len(rows) <= 32: raise RouteError("Select one to 32 state assignments.")
    seen = set()
    for row in rows:
        _fields(row, ("address", "args"), ("address", "args"))
        address = _address(row["address"])
        if address in seen: raise RouteError("Duplicate assignment address.")
        seen.add(address)
        if not isinstance(row["args"], list) or not 1 <= len(row["args"]) <= 3: raise RouteError("State assignments need one to three typed values.")
        if any(type(v) not in (bool, int, float) for v in row["args"]): raise RouteError("Presets and rules cannot publish arbitrary text.")
        for value in row["args"]:
            if type(value) is not bool: _number(value, "assignment", -3.4e38, 3.4e38)


def _validate_preset(item):
    _fields(item, ("id", "label", "avatar_id", "schema_revision", "platform", "assignments", "duration"), ("id", "avatar_id", "assignments"))
    _text(item["avatar_id"], "avatar_id", 80)
    for key in ("schema_revision", "platform"):
        if key in item: _text(item[key], key, 100)
    _assignments(item["assignments"])
    _number(item.get("duration", 30), "duration", 1, 30)


def _validate_rule(item):
    _fields(item, ("id", "label", "trigger", "edge", "equals", "cooldown", "max_duration", "ttl", "assignments", "capabilities", "audience"), ("id", "trigger", "assignments", "capabilities", "audience"))
    _text(item["trigger"], "trigger", 100, True)
    if item.get("edge", "entered") not in ("entered", "changed", "explicit"): raise RouteError("Rules require an edge or an explicit action.")
    if "equals" in item and type(item["equals"]) not in (bool, int, float): raise RouteError("Rule condition must be a typed scalar.")
    _number(item.get("cooldown", 1), "cooldown", .1, 3600)
    _number(item.get("max_duration", 60), "max_duration", .1, 3600)
    _number(item.get("ttl", 2), "ttl", .02, 30)
    if item["audience"] not in AUDIENCES: raise RouteError("Unknown rule audience.")
    if not isinstance(item["capabilities"], list) or not 1 <= len(item["capabilities"]) <= 8: raise RouteError("Rule requires narrow declared capabilities.")
    for scope in item["capabilities"]: _text(scope, "capability", 64, True)
    _assignments(item["assignments"])


class OSCWorkspace:
    """Local workflow layer. Reviews expire and bind to the exact service context."""
    def __init__(self, service, clock=time.monotonic):
        self.service, self.clock = service, clock
        self.configuration = {"schema": 1, "routes": [], "presets": [], "rules": []}
        self.routes, self.rules, self.applications = {}, {}, {}
        self.reviews, self.events = {}, deque(maxlen=256)
        self.guard = self._guard()
        self.context_guard = tuple(getattr(self.service, "context_guard", self.guard))

    def _guard(self): return tuple(self.service.state_guard)

    def _record(self, kind, record_id, outcome, reason=""):
        self.events.append({"time": self.clock(), "kind": kind, "id": record_id, "outcome": outcome, "reason": str(reason)[:300]})

    def _source(self, kind, key): return f"{kind}:{key}"

    def _route_source(self, row):
        if row.get("kind") == "body":
            return f'route:{row["source_id"]}:body:{row["tracking"]["tracker"]}'
        return self._source("route", row["id"])

    def _cancel_source(self, source, reason):
        cancel = getattr(self.service, "cancel_source", None)
        if callable(cancel): cancel(source, reason=reason)
        else: self.service.revoke(source=source)

    def _refresh(self):
        guard = self._guard()
        context_guard = tuple(getattr(self.service, "context_guard", guard))
        if context_guard != self.context_guard:
            for key in list(self.routes): self.stop_route(key, "OSC context changed")
            self.cancel_rules("OSC context changed")
            self.reviews.clear()
        elif guard != self.guard:
            # A new grant for another source is not a new avatar/session. Revocation
            # still stops every affected source, while all prior reviews expire.
            self.reviews.clear()
            granted = getattr(self.service, "is_granted", None)
            if callable(granted):
                for key, state in self.routes.items():
                    row = self._find("routes", key)
                    if state["active"] and not granted(self._route_source(row), row["address"]):
                        self.stop_route(key, "Route permission revoked")
                for key, state in self.rules.items():
                    row = self._find("rules", key)
                    if state["active"] and any(not granted(self._source("rule", key), assignment["address"]) for assignment in row["assignments"]):
                        self.cancel_rule(key, "Rule permission revoked")
        self.guard, self.context_guard = guard, context_guard

    def _new_review(self, kind, key, details):
        self._refresh()
        now = self.clock()
        self.reviews = {k: v for k, v in self.reviews.items() if v["expires_at"] > now}
        if len(self.reviews) >= 128: raise RouteError("Too many pending reviews.")
        review = {"token": uuid.uuid4().hex, "kind": kind, "id": key, "guard": self.guard, "expires_at": now + 30, "details": deepcopy(details)}
        self.reviews[review["token"]] = deepcopy(review)
        return review

    def _consume(self, review, kind):
        self._refresh()
        original = self.reviews.pop(review.get("token"), None) if isinstance(review, dict) else None
        if original is None or original != review or original["kind"] != kind or original["guard"] != self.guard or original["expires_at"] <= self.clock():
            raise RouteError("Review is expired, changed, already used, or belongs to another OSC context.")
        return original

    def _find(self, kind, key):
        for row in self.configuration[kind]:
            if row["id"] == key: return row
        raise RouteError(f"Unknown {kind} id.")

    def import_configuration(self, source):
        config = validate_configuration(source)
        old = self.configuration
        changes = []
        for category in ("routes", "presets", "rules"):
            known = {r["id"]: r for r in old[category]}
            for row in config[category]:
                previous = known.get(row["id"])
                changes.append({"kind": category, "id": row["id"], "change": "new" if previous is None else "changed" if previous != row else "unchanged", "fields": sorted(k for k in row if previous is None or previous.get(k) != row[k])})
        for key in list(self.routes): self.stop_route(key, "Configuration replaced")
        self.cancel_rules("Configuration replaced")
        self.reviews.clear()
        self.configuration = config
        self.routes = {row["id"]: self._route_state(row) for row in config["routes"]}
        self.rules = {row["id"]: {"active": False, "status": "Imported; review required", "previous": None, "last_fired": None, "count": 0} for row in config["rules"]}
        self._record("import", "configuration", "inert")
        return {"status": "Imported, inactive", "changes": changes, "network_destinations": [],
                "managed_sources": [{"route": row["id"], "endpoint": deepcopy(row["source_endpoint"]), "address": row["source_address"], "identity": "Unverified configured UDP endpoint"} for row in config["routes"] if "source_endpoint" in row],
                "authority_granted": False, "configuration": deepcopy(config)}

    def export_configuration(self): return deepcopy(self.configuration)

    def _route_state(self, row):
        return {"active": False, "status": "Imported; review required", "pipeline": TransformPipeline(row.get("transforms", []), row["input_type"], row["output_type"], "tracking" if row.get("kind", "state") != "state" else "state"), "latest": None, "last_sent": None, "last_value": None, "last_sample": None, "started_at": None, "received": 0, "scheduled": 0, "sent": 0, "pending_actions": [], "dropped": 0, "rejected": 0, "queue_delay": None, "owner": None, "source_health": "unknown"}

    def _endpoint(self, address):
        endpoint = self.service.registry.get(address)
        if endpoint is None: raise RouteError("Destination is not a registered compatible endpoint.")
        if endpoint.read_only: raise RouteError("Destination is read-only.")
        return endpoint

    def review_route(self, key):
        row = self._find("routes", key)
        endpoint = self._endpoint(row["address"])
        if endpoint.permission not in row["capabilities"]: raise RouteError("Route does not declare its destination capability.")
        if endpoint.behavior not in ("state", "assignment", "continuous"): raise RouteError("Managed routes accept state endpoints, not pulses, toggles or publications.")
        if endpoint.permission in ("avatar.parameters", "avatar.scale", "tracking.eye", "tracking.body") and row["audience"] != "avatar": raise RouteError("Avatar and tracking output requires an explicit avatar audience; local computation does not imply private output.")
        if row["address"] in EXCLUDED_PRESET_ADDRESSES: raise RouteError("Streaming and audio changes require a deliberate camera workflow.")
        if endpoint.permission in ("input", "microphone", "safety") and any(step["op"] in ("smooth", "debounce", "edge", "hysteresis") for step in row.get("transforms", [])):
            raise RouteError("Stateful transforms must not delay an input release or urgent cleanup.")
        return self._new_review("route", key, {"route": row, "permission": endpoint.permission, "source": self._route_source(row), "identity_note": "Configured labels and UDP endpoint matches are not authenticated identity", "coverage": "Only traffic passed through this managed route", "fallback": "Stop forwarding; native tracking fallback is not instantaneous"})

    def activate_route(self, review, *, approved_audiences=()):
        checked = self._consume(review, "route")
        key, row = checked["id"], self._find("routes", checked["id"])
        if row["audience"] != "local" and row["audience"] not in approved_audiences: raise RouteError("Explicit consent for this output audience is required.")
        if row.get("kind") == "eye" and row.get("tracking", {}).get("channel", "look") == "look":
            representation = row["tracking"]["representation"]
            for other_id, state in self.routes.items():
                other = self._find("routes", other_id)
                if other_id != key and state["active"] and other.get("kind") == "eye" and other.get("tracking", {}).get("channel", "look") == "look" and other["tracking"]["representation"] != representation:
                    raise RouteError("Only one eye-look representation may be active.")
        # Activation does not grant OSC permissions; OSCService enforces explicit grants.
        self.routes[key] = self._route_state(row)
        self.routes[key].update(active=True, status="Waiting for a fresh valid source sample", started_at=self.clock(), owner=self._route_source(row))
        if hasattr(self.service, "mode"): self.service.mode = "managed"
        self._record("route", key, "armed")
        return self.snapshot()

    def stop_route(self, key, reason="Stopped by user"):
        state = self.routes.get(key)
        if state:
            if state["active"]: self._cancel_source(self._route_source(self._find("routes", key)), reason)
            state.update(active=False, latest=None, status=reason, source_health="stopped", owner=None)
            state["pipeline"].reset()
            self._record("route", key, "stopped", reason)
            if hasattr(self.service, "mode") and self.service.mode == "managed" and not any(route["active"] for route in self.routes.values()):
                self.service.mode = "coexistence" if getattr(self.service, "armed", False) else "observation"

    def sample(self, key, value, *, source_id, valid=True, sampled_at=None, context=None):
        self._refresh()
        row, state = self._find("routes", key), self.routes[key]
        if not state["active"]: return False
        now = self.clock()
        when = now if sampled_at is None else _number(sampled_at, "sample time", 0, 1e15)
        if source_id != row["source_id"] or context is not None and tuple(context) != self.guard:
            state["rejected"] += 1
            state["status"] = "Source or context does not match the reviewed route"
            return False
        if valid is not True or when > now + .01 or now - when > row.get("max_age", .5) or state["last_sample"] is not None and when < state["last_sample"]:
            state["rejected"] += 1
            state["latest"] = None
            state["source_health"] = "unavailable" if valid is not True else "stale"
            state["status"] = "No valid current sample; forwarding stopped without a zero pose"
            state["last_value"] = None
            state["pipeline"].reset()
            self._cancel_source(self._route_source(row), state["status"])
            return False
        try: _typed(value, row["input_type"])
        except RouteError:
            state["rejected"] += 1
            state.update(latest=None, last_value=None, source_health="invalid", status="Rejected typed sample; forwarding stopped")
            state["pipeline"].reset()
            self._cancel_source(self._route_source(row), state["status"])
            raise
        if state["latest"] is not None: state["dropped"] += 1
        state["latest"] = (deepcopy(value), when)
        state["last_sample"], state["source_health"] = when, "healthy"
        state["received"] += 1
        return True

    def receive(self, address, args, observation):
        """Route explicitly reviewed UDP ingress, independently from VRChat telemetry.

        Exact source endpoint matching is routing configuration, not identity proof.
        This callback receives parsed data only; it never creates network listeners.
        """
        self._refresh()
        if not isinstance(observation, dict) or not isinstance(args, (tuple, list)):
            return 0
        source = observation.get("source")
        if not isinstance(source, (tuple, list)) or len(source) != 2: return 0
        selected = getattr(self.service, "trusted_source", None)
        transport = getattr(self.service, "transport", None)
        destination = (getattr(transport, "target_host", None), getattr(transport, "target_port", None))
        if tuple(source) == selected or tuple(source) == destination:
            # Native feedback is an observation, never a newly authorized command.
            return 0
        expected_generation = getattr(self.service, "generation", None)
        if expected_generation is not None and observation.get("generation") != expected_generation: return 0
        received = observation.get("received_at")
        if type(received) not in (int, float) or not math.isfinite(received): return 0
        count = 0
        for row in self.configuration["routes"]:
            endpoint = row.get("source_endpoint")
            if not endpoint or not self.routes[row["id"]]["active"] or row.get("source_address") != address or tuple(source) != (endpoint["host"], endpoint["port"]): continue
            vector = row["input_type"].startswith("vector")
            if not vector and len(args) != 1:
                self.routes[row["id"]]["rejected"] += 1
                continue
            value = tuple(args) if vector else args[0]
            try:
                accepted = self.sample(row["id"], value, source_id=row["source_id"], sampled_at=received, context=self.guard)
                count += int(accepted)
            except (ValueError, RuntimeError, PermissionError):
                continue
        return count

    def preview_transform(self, key, value):
        row = self._find("routes", key)
        pipeline = TransformPipeline(row.get("transforms", []), row["input_type"], row["output_type"], "tracking" if row.get("kind", "state") != "state" else "state")
        result = pipeline.apply(value, self.clock())
        return {"raw": deepcopy(value), "steps": pipeline.last_preview, "value": result, "suppressed": result is None, "sent": False}

    def _submit(self, address, args, source, *, duration=None, ttl=2, owner=None):
        review = self.service.review(address, tuple(args), source=source, owner=owner or source, duration=duration, ttl=ttl)
        return self.service.submit(review)

    def tick(self):
        self._refresh()
        now = self.clock()
        for key, state in self.routes.items():
            action_lookup = getattr(self.service, "action", None)
            if callable(action_lookup):
                pending = []
                for action_id in state["pending_actions"]:
                    action = action_lookup(action_id)
                    if action and action.get("status") == "scheduled": pending.append(action_id)
                    elif action and action.get("sent_at") is not None:
                        state["sent"] += 1
                    elif action:
                        state["rejected"] += 1
                        state["last_value"] = None
                        if state["active"]: state["status"] = action.get("detail", "Output did not transmit")
                state["pending_actions"] = pending
            if not state["active"]: continue
            row = self._find("routes", key)
            age = row.get("max_age", .5)
            if state["last_sample"] is not None and now - state["last_sample"] > age:
                if state["source_health"] != "stale": self._cancel_source(self._route_source(row), "Source sample expired")
                state.update(latest=None, last_value=None, source_health="stale", status="Source lost; stopped forwarding. No stale replay or zero reset.")
                state["pipeline"].reset()
                continue
            pending = state["latest"]
            if pending is None or state["last_sent"] is not None and now - state["last_sent"] < 1 / row.get("rate_hz", 10): continue
            state["latest"] = None
            raw, when = pending
            try:
                value = state["pipeline"].apply(raw, now)
                previous=state.get("diagnostic_value")
                edge=("rising" if value is True and previous is not True else "falling" if value is False and previous is True else "changed" if value!=previous else "unchanged")
                state["diagnostic_value"]=deepcopy(value)
                state["feedback"]={"raw":deepcopy(raw),"transformed":deepcopy(value),"edge":edge,"at":now,"steps":deepcopy(state["pipeline"].last_preview),"reason":"Transform suppressed this sample" if value is None else "Transform accepted; route and permission guards still apply"}
                if value is None: continue
                if row.get("deduplicate", row.get("kind", "state") == "state") and value == state["last_value"] and state["last_sent"] is not None: continue
                source = self._route_source(row)
                result = self._submit(row["address"], _args(value, row["output_type"]), source, duration=age, ttl=max(.02, age - (now - when)))
                state.update(last_sent=now, last_value=value, queue_delay=max(0, now - when), status="Scheduled; delivery and visual effect are unconfirmed")
                state["scheduled"] += 1
                action_id = result.get("id", result.get("action_id"))
                if action_id:
                    state["pending_actions"].append(action_id)
                    if len(state["pending_actions"]) > 128: state["pending_actions"].pop(0)
                self._record("route", key, result.get("status", "scheduled"))
            except (ValueError, RuntimeError, PermissionError) as exc:
                state["rejected"] += 1
                state["status"] = str(exc)[:300]
                self._record("route", key, "blocked", exc)
        for key, state in self.rules.items():
            if state["active"] and now >= state["expires_at"]: self.cancel_rule(key, "Maximum duration elapsed")
        return self.snapshot()

    def _preset_rows(self, record):
        rows = []
        snapshot = self.service.snapshot()
        observed_avatar = snapshot.get("avatar_id", snapshot.get("observed_avatar_id", ""))
        avatar_ok = observed_avatar == record["avatar_id"]
        for assignment in record["assignments"]:
            row = deepcopy(assignment)
            row.update(compatible=False, reason="", before=None)
            try:
                if not avatar_ok: raise RouteError("Preset avatar does not match the observed avatar.")
                for key in ("schema_revision", "platform"):
                    current = snapshot.get(key, snapshot.get("profile_revision") if key == "schema_revision" else None)
                    if key in record and current != record[key]: raise RouteError(f"Preset {key} does not match the current compatibility context.")
                endpoint = self._endpoint(row["address"])
                if endpoint.behavior not in ("state", "assignment") or endpoint.permission not in SAFE_PRESET_PERMISSIONS or row["address"] in EXCLUDED_PRESET_ADDRESSES or row["address"].startswith(("/tracking/", "/input/", "/chatbox/")):
                    raise RouteError("Presets exclude pulses, tracking, inputs, publications and sensitive state.")
                self.service.registry.validate(row["address"], tuple(row["args"]), write=True)
                observed = self.service.observation(row["address"])
                row["before"] = deepcopy(observed.get("args")) if observed else None
                row["compatible"] = True
                row["owner"] = next((deepcopy(owner) for owner in snapshot.get("owners", []) if owner.get("address") == row["address"]), None)
            except (ValueError, RuntimeError, PermissionError) as exc: row["reason"] = str(exc)[:300]
            rows.append(row)
        return rows

    def preview_preset(self, key):
        record = self._find("presets", key)
        return self._new_review("preset", key, {"rows": self._preset_rows(record), "duration": record.get("duration", 30), "source": self._source("preset", key), "note": "Only compatible selected state assignments are applied; conflicts remain subject to shared ownership policy."})

    def apply_preset(self, review, *, skip_conflicts=True):
        checked = self._consume(review, "preset")
        key, source = checked["id"], self._source("preset", checked["id"])
        current = self._preset_rows(self._find("presets", key))
        if current != checked["details"]["rows"]: raise RouteError("Observed state or ownership changed; preview the preset again.")
        results = []
        for row in current:
            outcome = deepcopy(row)
            if not row["compatible"]: outcome["status"] = "skipped"
            elif skip_conflicts and row.get("owner") and row["owner"].get("source") != source:
                outcome.update(status="skipped", reason="Another source owns this control")
            else:
                try:
                    action = self._submit(row["address"], row["args"], source, duration=checked["details"]["duration"])
                    outcome.update(status="scheduled", action_id=action.get("id", action.get("action_id")), source=source)
                except (ValueError, RuntimeError, PermissionError) as exc: outcome.update(status="failed", reason=str(exc)[:300])
            results.append(outcome)
        application_id = uuid.uuid4().hex
        application = {"id": application_id, "preset_id": key, "guard": self.guard, "rows": results, "created_at": self.clock()}
        self.applications[application_id] = application
        while len(self.applications) > 64: self.applications.pop(next(iter(self.applications)))
        self._record("preset", key, "reviewed application", "Scheduled values remain unverified until observed")
        return deepcopy(application)

    def _restore_rows(self, application):
        snapshot = self.service.snapshot()
        rows = []
        for applied in application["rows"]:
            row = {"address": applied["address"], "args": applied.get("before"), "compatible": False, "reason": ""}
            owners = [o for o in snapshot.get("owners", []) if o.get("address") == row["address"]]
            observation = self.service.observation(row["address"])
            if tuple(application["guard"]) != self.guard: row["reason"] = "Context changed"
            elif applied.get("status") != "scheduled" or row["args"] is None: row["reason"] = "No previous observed state to restore"
            elif not any(o.get("source") == applied.get("source") and o.get("action_id") == applied.get("action_id") and o.get("expires_at", float("inf")) > self.clock() for o in owners): row["reason"] = "A newer writer or expired ownership prevents restoration"
            elif not observation or observation.get("live") is False or not same_arguments(tuple(observation.get("args", ())), tuple(applied["args"])): row["reason"] = "Current observed state does not match the applied state or its source is stale"
            else: row["compatible"] = True
            rows.append(row)
        return rows

    def preview_restore(self, application_id):
        self._refresh()
        if application_id not in self.applications: raise RouteError("Unknown preset application.")
        return self._new_review("restore", application_id, {"rows": self._restore_rows(self.applications[application_id]), "note": "Best-effort scoped restore; external concurrent writers cannot be locked."})

    def restore(self, review):
        checked = self._consume(review, "restore")
        application = self.applications[checked["id"]]
        rows = self._restore_rows(application)
        if rows != checked["details"]["rows"]: raise RouteError("Restoration conditions changed; preview again.")
        for row in rows:
            if row["compatible"]:
                try:
                    row["action"] = self._submit(row["address"], row["args"], self._source("preset", application["preset_id"]))
                    row["status"] = "scheduled"
                except (ValueError, RuntimeError, PermissionError) as exc: row.update(status="failed", reason=str(exc)[:300])
            else: row["status"] = "skipped"
        self._record("restore", application["preset_id"], "reviewed restore")
        return rows

    def review_rule(self, key):
        row = self._find("rules", key)
        for assignment in row["assignments"]:
            endpoint = self._endpoint(assignment["address"])
            if endpoint.permission not in row["capabilities"] or endpoint.behavior not in ("state", "assignment"):
                raise RouteError("Rule permits only declared state capabilities; use the action service for sensitive workflows.")
            if endpoint.permission not in SAFE_PRESET_PERMISSIONS or assignment["address"] in EXCLUDED_PRESET_ADDRESSES or assignment["address"].startswith(("/input/", "/chatbox/", "/tracking/")): raise RouteError("Rules permit selected non-sensitive avatar and camera state only.")
            self.service.registry.validate(assignment["address"], tuple(assignment["args"]), write=True)
        return self._new_review("rule", key, {"rule": row, "source": self._source("rule", key), "cancellation": ["user", "context change", "permission revoked", "duration elapsed", "source unavailable"]})

    def arm_rule(self, review, *, approved_audiences=()):
        checked = self._consume(review, "rule")
        row = self._find("rules", checked["id"])
        if row["audience"] != "local" and row["audience"] not in approved_audiences: raise RouteError("Explicit audience consent is required.")
        self.rules[row["id"]].update(active=True, status="Armed; waiting for a new event", previous=None, last_fired=None, expires_at=self.clock() + row.get("max_duration", 60), guard=self.guard)
        self._record("rule", row["id"], "armed")
        return self.snapshot()

    def cancel_rule(self, key, reason="Cancelled by user"):
        state = self.rules.get(key)
        if state:
            if state["active"]: self._cancel_source(self._source("rule", key), reason)
            state.update(active=False, status=reason, previous=None)
            self._record("rule", key, "cancelled", reason)

    def cancel_rules(self, reason="Cancelled by user"):
        for key in self.rules: self.cancel_rule(key, reason)

    def event(self, trigger, value, *, kind="explicit", valid=True, sampled_at=None, origin="local", propagation=0):
        self._refresh()
        now = self.clock()
        if type(value) not in (bool, int, float) or type(value) is float and not math.isfinite(value): raise RouteError("Events carry typed scalar state.")
        if kind not in ("explicit", "state") or origin != "local" or propagation != 0:
            # Observations, echoes and raw peer packets are not fresh local requests.
            return []
        results = []
        for key, state in self.rules.items():
            row = self._find("rules", key)
            if not state["active"] or row["trigger"] != trigger: continue
            when = now if sampled_at is None else _number(sampled_at, "event time", 0, 1e15)
            if valid is not True or when > now + .01 or now - when > row.get("ttl", 2):
                self.cancel_rule(key, "Trigger source unavailable or expired")
                continue
            if now >= state["expires_at"]:
                self.cancel_rule(key, "Maximum duration elapsed")
                continue
            previous = state["previous"]
            state["previous"] = deepcopy(value)
            equal = "equals" not in row or type(row["equals"]) is type(value) and row["equals"] == value
            edge = row.get("edge", "entered")
            fires = (kind == "explicit") if edge == "explicit" else (previous is not None and (type(previous) is not type(value) or previous != value))
            if edge == "entered": fires = fires and equal
            elif not equal: fires = False
            if not fires or state["last_fired"] is not None and now - state["last_fired"] < row.get("cooldown", 1): continue
            state["last_fired"] = now
            state["count"] += 1
            for assignment in row["assignments"]:
                try:
                    action = self._submit(assignment["address"], assignment["args"], self._source("rule", key), duration=min(30, row.get("max_duration", 60), state["expires_at"] - now), ttl=max(.02, row.get("ttl", 2) - (now - when)))
                    results.append(action)
                    state["status"] = "State assignment scheduled; effect unverified"
                except (ValueError, RuntimeError, PermissionError) as exc:
                    state["status"] = str(exc)[:300]
                    self.cancel_rule(key, "Action blocked: " + str(exc)[:240])
                    break
            self._record("rule", key, "triggered", state["status"])
        return results

    def snapshot(self):
        now = self.clock()
        routes = []
        for row in self.configuration["routes"]:
            state = self.routes.get(row["id"], {})
            public = {key: deepcopy(value) for key, value in state.items() if key not in ("pipeline", "latest", "last_value", "pending_actions", "diagnostic_value")}
            elapsed = max(.001, now - (state.get("started_at") or now))
            public.update(id=row["id"], label=row.get("label", row["id"]), definition=deepcopy(row), sample_age=None if state.get("last_sample") is None else max(0, now - state["last_sample"]), incoming_hz=state.get("received", 0) / elapsed, outgoing_hz=state.get("sent", 0) / elapsed, queue_delay_scope="Local route sample age at scheduling, not VRChat or network latency")
            routes.append(public)
        applications = deepcopy(list(self.applications.values()))
        action_lookup = getattr(self.service, "action", None)
        for application in applications:
            summary = {"scheduled": 0, "sent_unverified": 0, "matching_state_observed": 0, "skipped": 0, "failed": 0}
            for row in application["rows"]:
                action = action_lookup(row.get("action_id")) if callable(action_lookup) and row.get("action_id") else None
                delivery = action.get("status") if action else row["status"]
                row["delivery_status"] = delivery
                classification = "sent_unverified" if delivery == "sent" else delivery if delivery in summary else "failed"
                summary[classification] += 1
            application["summary"] = summary
        return {"routes": routes, "presets": deepcopy(self.configuration["presets"]), "rules": [{**deepcopy(row), **deepcopy(self.rules.get(row["id"], {}))} for row in self.configuration["rules"]], "applications": applications, "events": deepcopy(list(self.events)), "guard": self.guard, "coverage": "Managed routes only; direct application traffic is outside this policy engine", "configuration": self.export_configuration()}

    def close(self):
        for key in list(self.routes): self.stop_route(key, "Workspace closed")
        self.cancel_rules("Workspace closed")
        self.reviews.clear()


EXAMPLE_CONFIGURATION = {
    "schema": 1,
    "routes": [{"id": "battery", "label": "Reviewed battery level", "source_id": "local-battery", "source_identity": "local-adapter", "capabilities": ["avatar.parameters"], "audience": "avatar", "address": "/avatar/parameters/Eye_Battery01", "input_type": "float", "output_type": "float", "transforms": [{"op": "scale", "value": .01}, {"op": "clamp", "min": 0, "max": 1}], "rate_hz": 1, "max_age": 10}],
    "presets": [], "rules": [],
}
