"""Ephemeral, approved bridge observations bound to the exact logged instance."""
from player_session_model import Source,Confidence,PlayerEvent
from player_sessions import utc

FIELDS=("speaking","avatar_audio","distance","load","performance","texture_memory","moderation","roles","avatar_id")


def poll_bridge(service,bridge):
    now=service.clock();snapshot=bridge.state.snapshot();sample=bridge.get_sample("instance.context")
    context=sample["value"] if sample else {}
    bound=bool(not service.demo and not service.meta.get("ended") and sample and service.meta.get("instance_id") and
               context.get("world_id")==service.meta.get("world_id") and context.get("instance_id")==service.meta.get("instance_id"))
    token=(snapshot.get("session"),snapshot.get("context",{}).get("runtime_session"),service.meta.get("id")) if bound else None
    if token!=getattr(service,"bridge_token",None):
        service.bridge_token=token;service.bridge_since=sample["received"] if bound else now;service.bridge_selection=""
        service.revision+=1
        for row in service.rows.values():
            row.bridge_loading=None
            for field in FIELDS:row.fields.get(field,{}).pop(Source.BRIDGE,None)
    service.bridge_bound=bound
    if not bound:return
    rows={r.user_id:r for r in service.rows.values() if r.active and r.user_id}
    master=context.get("network_master")
    for row in rows.values():
        row.put("roles",("Network Master",) if row.user_id==master else (),Source.BRIDGE,Confidence.MEDIUM,utc(service.wall()),sample["received"],ttl=sample["expires"]-sample["received"],detail="Client-reported network role",scope=service.meta["id"])
    fields={"player.voice_activity":("speaking",),"player.distance":("distance",),"avatar.load_state":("load",),"avatar.performance":("performance","texture_memory"),"local.moderation_state":("moderation",)}
    for cap,names in fields.items():
        item=bridge.get_sample(cap)
        valid=item and item["received"]>=service.bridge_since
        players={r["user_id"]:r for r in item["value"]["players"]} if valid else {}
        for user,row in rows.items():
            values=players.get(user)
            if not values:
                for name in names:row.fields.get(name,{}).pop(Source.BRIDGE,None)
                continue
            received=item.get("observed",item["received"]);ttl=min(item["expires"]-received,1. if cap=="player.voice_activity" else 3.)
            if now>=received+ttl:
                for name in names:row.fields.get(name,{}).pop(Source.BRIDGE,None)
                continue
            def put(field,value,detail=""):
                row.put(field,value,Source.BRIDGE,Confidence.MEDIUM,utc(service.wall()-(now-received)),received,ttl=ttl,detail=detail,scope=service.meta["id"])
            if cap=="player.voice_activity":
                previous=row.get("speaking",now)
                # Do not extend freshness; a 200ms release hold only smooths an active signal.
                if not values["voice_active"] and previous.value is True and now-previous.received<.2:continue
                put("speaking",values["voice_active"],"Client-reported voice activity; not persisted")
            elif cap=="player.distance":put("distance",round(values["distance_m"]*3.280839895,1),"Straight-line feet, client reported; not persisted")
            elif cap=="avatar.load_state":
                state={"loading":"LOADING","ready":"READY","failed":"LOAD_FAILED","security_failure":"SECURITY_FAILED","bundle_failure":"BUNDLE_FAILED","unknown":"UNKNOWN"}[values["state"]]
                avatar=values.get("avatar_id")
                previous=row.get("avatar_id",now).value
                if avatar and previous and avatar!=previous:
                    service.accept(PlayerEvent.make("avatar.changed",utc(service.wall()),user_id=row.user_id,name=row.name,data={"avatar_id":avatar},source=Source.BRIDGE,confidence=Confidence.MEDIUM))
                if avatar:put("avatar_id",avatar)
                if state=="LOADING":
                    token=(avatar,state)
                    if getattr(row,"bridge_loading",None)!=token:row.bridge_loading=token;row.bridge_loading_at=now
                    if now-row.bridge_loading_at>=service.settings["loading_timeout"]:state="LOAD_STALLED"
                else:row.bridge_loading=None
                put("load",state,"Client reported")
            elif cap=="avatar.performance":
                # Require explicit matching avatar IDs. A user-level statistic must not follow a swap.
                if not values.get("avatar_id") or values.get("avatar_id")!=row.get("avatar_id",now).value:
                    for name in names:row.fields.get(name,{}).pop(Source.BRIDGE,None)
                    continue
                if "rank" in values:put("performance",values["rank"],"Client-reported platform performance rank")
                if "texture_memory_bytes" in values:put("texture_memory",values["texture_memory_bytes"],"Texture memory estimate; not total VRAM usage")
            elif cap=="local.moderation_state":put("moderation",tuple((k,v) for k,v in sorted(values.items()) if k!="user_id"),"Your local controls only")
    selection=bridge.get_sample("player.selection")
    user=selection["value"].get("user_id") if selection and selection["received"]>=service.bridge_since else None
    service.bridge_selection=rows[user].key if user in rows else ""
    runtime=bridge.get_sample("unity.runtime_health")
    if runtime and runtime["received"]>=service.bridge_since and runtime["received"]!=getattr(service,"resource_received",None):
        service.resource_received=runtime["received"]
        service.resource_sample(runtime["value"],utc(service.wall()))


def request_action(service,bridge,key,cap,params,*,expected):
    """Recheck after the review dialog; never silently retarget a modal action."""
    poll_bridge(service,bridge)
    row=service.rows.get(key)
    token=(service.meta.get("id"),getattr(service,"bridge_token",None),row.user_id if row else None)
    if token!=expected or not row or not row.active or not row.user_id or not service.bridge_bound:raise ValueError("The player, instance, or bridge changed. Review this action again.")
    if params.get("user_id")!=row.user_id:raise ValueError("Bridge action target mismatch.")
    if not bridge.available(cap):raise ValueError("This control is unavailable or not approved for the connected client.")
    return bridge.request(cap,params,expected_session=service.bridge_token[0])
