"""Player platform snapshots from explicit user JSON, matched by VRChat user ID."""

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone

from player_trust import trust_from_tags


MAX_USER_JSON_BYTES = 2 * 1024 * 1024
USER_ID_PATTERN = r"usr_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
PLATFORM_NAMES = {"standalonewindows": "PC", "android": "Android", "ios": "iOS"}


def parse_user_id(value):
    if not isinstance(value, str) or not re.fullmatch(USER_ID_PATTERN, value.strip()):
        raise ValueError("A complete usr_ user ID is required.")
    return value.strip().lower()


@dataclass(frozen=True)
class PlayerPlatform:
    user_id: str
    platform: str
    field: str
    imported_at: str
    origin: str = "Imported user JSON"
    trust_rank: str = "Unknown"
    trust_note: str = ""

    @property
    def label(self):
        if self.platform == "Unknown":
            return "Unknown"
        qualifier = "last known" if self.field == "last_platform" else "snapshot"
        return f"{self.platform} ({qualifier})"

    @property
    def source(self):
        return self.origin + ": " + self.field


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("User JSON contains duplicate fields.")
        result[key] = value
    return result


def parse_user_platform(text, expected_user_id, *, allow_missing=False):
    """Read only identity/platform fields; never infer from avatar packages.

    The import time is ours, not the time the source observed the device. Even
    presence.platform is presented as a snapshot, never as live/historical proof.
    """
    expected = parse_user_id(expected_user_id)
    if not isinstance(text, str) or len(text) > MAX_USER_JSON_BYTES or len(text.encode("utf-8")) > MAX_USER_JSON_BYTES:
        raise ValueError("User JSON is too large (maximum 2 MiB).")
    try:
        document = json.loads(text.lstrip("\ufeff"), object_pairs_hook=_unique_keys)
    except (json.JSONDecodeError, RecursionError):
        raise ValueError("Choose a valid user JSON object.") from None
    if not isinstance(document, dict):
        raise ValueError("Choose one user JSON object containing id and platform information.")
    reference = parse_user_id(document.get("id"))
    if reference != expected:
        raise ValueError("The JSON user ID does not match this player's ID in the log.")
    rank, rank_note = trust_from_tags(document.get("tags"))
    presence = document.get("presence")
    candidates = (("presence.platform", presence.get("platform") if isinstance(presence, dict) else None),
                  ("platform", document.get("platform")), ("last_platform", document.get("last_platform")))
    for field, raw in candidates:
        if raw is None or raw == "":
            continue
        if not isinstance(raw, str):
            raise ValueError(f"The {field} field must be a string.")
        if not raw.strip():
            continue
        # An unrecognized current field stays Unknown; do not hide it behind an
        # older last_platform value or interpret arbitrary Unity version strings.
        label = PLATFORM_NAMES.get(raw.strip().casefold(), "Unknown")
        return PlayerPlatform(reference, label, field, datetime.now(timezone.utc).isoformat(timespec="seconds"),
                              trust_rank=rank, trust_note=rank_note)
    if allow_missing:
        return PlayerPlatform(reference, "Unknown", "not supplied", datetime.now(timezone.utc).isoformat(timespec="seconds"),
                              trust_rank=rank, trust_note=rank_note)
    raise ValueError("This user JSON has no platform, presence.platform, or last_platform value. Avatar build platforms cannot identify a player's device.")


def platform_for_event(event, records):
    record = records.get(event.user_id) if event.user_id else None
    return record if record and record.user_id == event.user_id else None


def platform_label(event, records):
    record = platform_for_event(event, records)
    return record.label if record else "Unknown"


def platform_details(event, records):
    record = platform_for_event(event, records)
    if record:
        action = "checked" if record.origin == "VRChat API" else "imported"
        return (f"Player platform: {record.label} · {record.source} · {action} {record.imported_at}\n"
                f"Trust rank (tags): {record.trust_rank} · {record.trust_note}\n"
                "Latest available data for this user; source age is unknown, including at the avatar-event time.")
    if not event.user_id:
        return "Player platform: Unknown · no unambiguous user ID in the observed join log."
    return "Player platform: Unknown · use Player details… to look up this user or import JSON."
