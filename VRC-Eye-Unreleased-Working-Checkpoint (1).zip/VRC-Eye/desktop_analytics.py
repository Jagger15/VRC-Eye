"""Local observed activity; imported totals never become invented sessions."""
from collections import defaultdict
from datetime import datetime,timezone,timedelta
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
import csv


def instant(value):
    if not isinstance(value,str):raise ValueError('An explicit timestamp is required.')
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    if dt.tzinfo is None:raise ValueError('Timezone-free observations cannot establish a duration.')
    return dt.astimezone(timezone.utc)


def summarize(records, zone='UTC', *, after='', before='', stop=None):
    from vrcx_sources import stopped
    try:tz=ZoneInfo(zone)
    except (ValueError,ZoneInfoNotFoundError):raise ValueError('Choose an installed IANA time zone, such as UTC or America/New_York.') from None
    def boundary(value,end=False):
        if not value:return None
        from photo_store import date_filter
        date_filter(value);moment=datetime.fromisoformat(value)+(timedelta(days=1) if end else timedelta())
        return moment.replace(tzinfo=tz).astimezone(timezone.utc)
    lower,upper=boundary(after),boundary(before,True)
    if lower and upper and lower>=upper:raise ValueError('The end date must be on or after the start date.')
    days=defaultdict(lambda:dict(events=0,derived_sessions=0,seconds=0.,derived_seconds=0.,hours=defaultdict(float),derived_hours=defaultdict(float),event_hours=defaultdict(int)));seen=set();intervals=defaultdict(list)
    ignored=0;aggregates=0;gaps=0
    for row in records:
        stopped(stop)
        ident=(row['scope'],row['kind'],row['id'])
        if ident in seen:continue
        seen.add(ident);data=row['data']
        if row['kind']=='coverage':gaps+=1;continue
        derived=row['kind']=='aggregate' and data.get('category')=='derived-activity' and not data.get('open_tail')
        if row['kind']=='aggregate' and not derived:aggregates+=1;continue
        if row['kind']!='event' and not derived:continue
        if derived:
            try:
                data=dict(data,reported_time=datetime.fromtimestamp(data['start_ms']/1000,timezone.utc).isoformat(),
                    started_at=datetime.fromtimestamp(data['start_ms']/1000,timezone.utc).isoformat(),ended_at=datetime.fromtimestamp(data['end_ms']/1000,timezone.utc).isoformat())
            except (KeyError,ValueError,TypeError,OverflowError):ignored+=1;continue
        when=data.get('reported_time') or data.get('created_at') or data.get('timestamp')
        try:dt=instant(when)
        except (ValueError,TypeError,OverflowError):ignored+=1;continue
        if (lower is None or dt>=lower) and (upper is None or dt<upper):
            local=dt.astimezone(tz);days[local.date().isoformat()]['derived_sessions' if derived else 'events']+=1
            if not derived:days[local.date().isoformat()]['event_hours'][local.strftime('%H:00 %z')+(' (fold 2)' if local.fold else '')]+=1
        start=data.get('started_at') or data.get('start');end=data.get('ended_at') or data.get('end')
        if start and end:
            try:a,b=instant(start),instant(end)
            except (ValueError,TypeError,OverflowError):ignored+=1;continue
            if not 0<(b-a).total_seconds()<=7*86400:ignored+=1;continue
            # Union repeated or overlapping intervals per subject, independent
            # of import provenance. Different people remain separate subjects.
            a=max(a,lower) if lower else a;b=min(b,upper) if upper else b
            subject=(bool(derived),row['scope'],data.get('user_id') or data.get('subject_id') or 'self')
            if b>a:intervals[subject].append((a,b))
    buckets=0
    for (derived,*_),values in intervals.items():
        merged=[]
        for a,b in sorted(values):
            if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],b))
            else:merged.append((a,b))
        for a,b in merged:
            # UTC minute boundaries handle DST folds, gaps and half-hour shifts.
            while a<b:
                buckets+=1
                if buckets%1000==0:stopped(stop)
                if buckets>2000000:raise ValueError('Analysis exceeds its interval budget. Choose a narrower date range.')
                limit=min(b,a.replace(second=0,microsecond=0)+timedelta(minutes=1))
                local=a.astimezone(tz);day=days[local.date().isoformat()]
                seconds=(limit-a).total_seconds();day['derived_seconds' if derived else 'seconds']+=seconds
                label=local.strftime('%H:00 %z')+(' (fold 2)' if local.fold else '')
                day['derived_hours' if derived else 'hours'][label]+=seconds;a=limit
    rows=[]
    for date,value in sorted(days.items()):
        rows.append(dict(date=date,events=value['events'],observed_seconds=round(value['seconds'],3),hours=dict(value['hours']),
                         derived_sessions=value['derived_sessions'],derived_seconds=round(value['derived_seconds'],3),derived_hours=dict(value['derived_hours'])))
        rows[-1]['event_hours']=dict(value['event_hours'])
    return dict(zone=zone,days=rows,gaps=gaps,undated_or_invalid=ignored,aggregate_snapshots=aggregates,
                coverage='Partial local observations. Durations count subject-time, not guaranteed game uptime. Imported derived intervals are separate estimates and never added to observed time. Missing observations do not mean offline.')


def export(path,report):
    from pathlib import Path
    from creator_projects import assert_no_links,local_path
    path=assert_no_links(local_path(path));assert_no_links(path.parent)
    # Never replace an existing export without another file choice.
    with path.open('x',encoding='utf-8',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(('Date','Timezone','Observed events','Observed subject-seconds','Derived subject-seconds','Coverage'))
        for row in report['days']:writer.writerow((row['date'],report['zone'],row['events'],row['observed_seconds'],row['derived_seconds'],report['coverage']))
