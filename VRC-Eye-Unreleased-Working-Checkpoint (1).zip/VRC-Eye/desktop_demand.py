"""Presentation demand for existing owners; never enables or starts a provider."""


def demand(shell, *, hidden=False, minimized=False, power='Balanced'):
    current=getattr(shell,'current','')
    visible=not hidden and not minimized
    home=shell.pages.get('Home');dashboard=getattr(home,'dashboard',None)
    widgets={row['kind'] for row in getattr(dashboard,'layout',()) if not row.get('collapsed')} if current=='Home' else set()
    def wants(page,kind):return visible and (current==page or kind in widgets)
    return dict(economy=minimized or power=='Low power',
        performance=wants('Performance & Security','performance') or wants('Performance & Security','applications'),
        health=wants('VRCX Companion','health'),runtime=wants('Unity Player','runtime'))


def apply(shell,health,request):
    economy=request['economy']
    for title,key in (('Performance & Security','performance'),('Unity Player','runtime')):
        page=shell.pages.get(title)
        if page:page.service.set_display_demand(request[key],economy)
    health.set_display_demand(request['health'],economy)
