"""Application-local switch scanning and dwell; no global hooks or device access."""
from dataclasses import asdict, dataclass
import time
import uuid
import weakref
from tkinter import TclError

from keyboard_ui import available, controls, within

KEY = 'ui.alternate_input.v1'
MODES = ('Two switches', 'One switch auto scan')
SWITCH_KEYS = ('F2', 'F3', 'F4', 'F5', 'F7', 'F8', 'F9', 'F11', 'F12')


@dataclass(frozen=True)
class Preferences:
    schema: int = 1
    mode: str = 'Two switches'
    next_key: str = 'F8'
    select_key: str = 'F9'
    pause_key: str = 'F7'
    scan_ms: int = 1500
    dwell: bool = False
    dwell_ms: int = 1500
    tolerance: int = 8

    @classmethod
    def parse(cls, raw):
        if not isinstance(raw, dict) or set(raw)-set(cls.__dataclass_fields__):
            raise ValueError('Use a data-only alternate-input profile.')
        value=asdict(cls());value.update(raw)
        if type(value['schema']) is not int or value['schema'] != 1:
            raise ValueError('Unsupported alternate-input profile version.')
        if value['mode'] not in MODES or type(value['dwell']) is not bool:
            raise ValueError('Choose a listed input mode and a boolean dwell setting.')
        keys=[value[k] for k in ('next_key','select_key','pause_key')]
        if any(k not in SWITCH_KEYS for k in keys) or len(set(keys))!=3:
            raise ValueError('Choose three different listed switch keys.')
        for key,lo,hi in (('scan_ms',500,10000),('dwell_ms',500,10000),('tolerance',0,40)):
            if type(value[key]) is not int or not lo<=value[key]<=hi:
                raise ValueError('Use whole numbers: timing 500–10000 ms; pointer tolerance 0–40 pixels.')
        return cls(**value)

    def to_dict(self):return asdict(self)


def conflicting(preferences, bindings):
    return sorted(set((preferences.next_key,preferences.select_key,preferences.pause_key)) & set(bindings.values()))


class Dwell:
    """A target fires once until departure; movement or context change restarts it."""
    def __init__(self):self.clear()
    def clear(self):self.target=None;self.origin=None;self.started=0;self.fired=False
    def sample(self, target, position, now, delay, tolerance):
        if target is None:self.clear();return False,0
        moved=self.origin is not None and max(abs(a-b) for a,b in zip(position,self.origin))>tolerance
        if target!=self.target or moved:
            self.target=target;self.origin=position;self.started=now
            # Movement inside an already activated control must not repeat it.
            if target!=getattr(self,'activated',None):self.fired=False
        fraction=min(1,max(0,(now-self.started)/delay))
        if fraction>=1 and not self.fired:
            self.fired=True;self.activated=target;return True,1
        return False,fraction

    def leave(self):self.clear();self.activated=None


def fingerprint(widget):
    """No field contents or credentials retained in queued input state."""
    kind=widget.winfo_class()
    options=[]
    for key in ('command','text'):
        try:options.append(str(widget.cget(key)))
        except (TclError, KeyError):options.append('')
    selection=tuple(widget.selection()) if kind=='Treeview' else ()
    return kind,tuple(options),selection,getattr(widget,'_eye_content_revision',0)


class AlternateInput:
    def __init__(self, experience):
        self.experience=experience;self.app=experience.app;self.root=self.app.root
        self.keyboard=experience.keyboard;self.closed=False;self.running=False
        self.paused=True;self.target=None;self.target_stamp=None;self.context=None
        self.pressed={};self.releases={};self.attached=weakref.WeakSet()
        self.dwell=Dwell();self.next_at=0;self.job=None;self.undo_preferences=None
        self.dialog=None;self.pointer_down=False;self.preferences=Preferences()
        self.dwell_paused=False;self.dwell_gate=None
        self.dwell_latched_widget=None
        self.status=self.app.tk.StringVar(value='Alternate input stopped. Start when you are ready.')
        try:
            raw=experience.shell.store.option(KEY,None)
            if raw is not None:self.preferences=Preferences.parse(raw)
        except (ValueError,OSError,__import__('sqlite3').Error):
            self.status.set('Saved input settings could not be read. Defaults are available; the saved record was not overwritten.')
        self.tag='VRCEyeAlternate'+uuid.uuid4().hex
        for sequence,fn in (('<KeyPress>',self.press),('<KeyRelease>',self.release),
                            ('<ButtonPress>',self.pointer_press),('<ButtonRelease>',self.pointer_release)):
            self.root.bind_class(self.tag,sequence,fn)
        self.map_id=self.root.bind_all('<Map>',self.mapped,add='+')
        self.attach_tree(self.root)
        footer=getattr(self.app,'build_footer',None)
        if footer is not None:
            from screen_reader_model import annotate
            annotate(self.app.ttk.Label(footer,textvariable=self.status,wraplength=680,style='Small.TLabel'),public=True,name='Alternate input status').pack(side='left',fill='x')
        self.schedule()

    def attach_tree(self, widget):
        try:
            if widget not in self.attached:
                widget.bindtags((self.tag,*widget.bindtags()));self.attached.add(widget)
            for child in widget.winfo_children():self.attach_tree(child)
        except (TclError,AttributeError):pass

    def mapped(self,event):
        if not self.closed and hasattr(event.widget,'winfo_children'):self.attach_tree(event.widget)

    def scope(self):
        if self.closed or self.keyboard.suspended or getattr(self.experience.shortcuts,'suspended',0):return None
        focused=self.root.focus_get()
        if focused is None or not self.keyboard.allowed(focused):return None
        top=focused.winfo_toplevel()
        # focus_get() is application-local: unfocused applications return None.
        return top

    def boundary(self):
        return self.keyboard.boundary(),getattr(self.app.sidebar,'current','')

    def stamp(self,widget):return self.boundary(),fingerprint(widget)

    def valid(self,widget,stamp):
        try:return widget is not None and available(widget) and self.stamp(widget)==stamp
        except (TclError,AttributeError):return False

    def check_conflicts(self, preferences=None):
        keys=conflicting(preferences or self.preferences,getattr(self.experience.shortcuts,'bindings',{}))
        if keys:raise ValueError('These switch keys are navigation shortcuts: '+', '.join(keys)+'. Choose different switch keys or remap those shortcuts.')

    def apply(self,raw):
        prefs=Preferences.parse(raw);self.check_conflicts(prefs)
        session=self.app.demo or getattr(self.app,'safe_mode',False)
        if not session:self.experience.shell.store.set_option(KEY,prefs.to_dict())
        self.stop();self.undo_preferences=self.preferences;self.preferences=prefs
        self.status.set('Input settings applied'+(' for this session' if session else ' and saved')+'. Select Start to use them.')

    def undo(self):
        if self.undo_preferences is None:raise ValueError('No alternate-input change to undo.')
        self.apply(self.undo_preferences.to_dict())

    def start(self):
        self.check_conflicts();self.running=True;self.paused=False
        self.dwell_paused=False;self.dwell_gate=self.root.winfo_pointerxy()
        self.reset_pending();self.context=(self.boundary(),self.scope())
        self.next_at=time.monotonic()+self.preferences.scan_ms/1000
        self.status.set('Input active. '+self.preferences.next_key+': next; '+self.preferences.select_key+': select; '+self.preferences.pause_key+': pause. Escape stops input.')
        self.sync_button()
        self.schedule()

    def reset_pending(self):
        self.target=None;self.target_stamp=None;self.pressed.clear();self.dwell.leave()
        self.dwell_latched_widget=None
        for job in self.releases.values():self.root.after_cancel(job)
        self.releases.clear()

    def stop(self):
        self.running=False;self.paused=True;self.reset_pending()
        if self.job:self.root.after_cancel(self.job);self.job=None
        self.status.set('Alternate input stopped. Start when you are ready.')
        self.sync_button()

    def sync_button(self):
        button=getattr(self.experience,'input_button',None)
        if button is not None:button.configure(text='Stop alternate input' if self.running else 'Alternate input')

    def pause(self):
        self.paused=not self.paused;self.reset_pending()
        self.dwell_paused=self.paused
        self.next_at=time.monotonic()+self.preferences.scan_ms/1000
        self.status.set('Scanning paused. Select or press the pause key to resume.' if self.paused else 'Scanning resumed.')

    def key(self,event):
        if not self.running or self.scope() is None:return None
        if int(event.state)&~(2|16):return None
        return event.keysym if event.keysym in (self.preferences.next_key,self.preferences.select_key,self.preferences.pause_key,'Escape') else None

    def press(self,event):
        key=self.key(event)
        if key is None:
            if self.running:
                self.target=None;self.target_stamp=None;self.paused=True;self.dwell.leave()
                self.dwell_gate=self.root.winfo_pointerxy()
            return None
        if key=='Escape':
            editor=getattr(self.experience,'layout_editor',None)
            if editor is not None:editor.cancel_drag()
            self.stop();return 'break'
        self.dwell.leave();self.dwell_gate=self.root.winfo_pointerxy()
        if key in self.releases:self.root.after_cancel(self.releases.pop(key))
        if key not in self.pressed:
            self.pressed[key]=(self.boundary(),self.scope(),self.target,self.target_stamp)
        return 'break'

    def release(self,event):
        key=self.key(event)
        if key is None:return None
        if key in self.releases:self.root.after_cancel(self.releases.pop(key))
        # X11 auto-repeat emits release/press pairs. Only a real release acts.
        self.releases[key]=self.root.after(40,lambda:self.finish_key(key))
        return 'break'

    def finish_key(self,key):
        self.releases.pop(key,None);before=self.pressed.pop(key,None)
        if not before or not self.running or self.scope() is None:return
        if before[:2]!=(self.boundary(),self.scope()):self.reset_pending();return
        if key==self.preferences.pause_key:self.pause()
        elif key==self.preferences.next_key:self.paused=False;self.step()
        elif self.paused:self.paused=False;self.dwell_paused=False;self.step()
        elif key==self.preferences.select_key:
            if before[2] is self.target and before[3]==self.target_stamp:self.activate(self.target,self.target_stamp)

    def step(self,direction=1):
        top=self.scope()
        if top is None:return
        candidates=[w for w in controls(top) if not getattr(w,'_eye_hold_control',False)]
        if not candidates:return
        current=self.target or self.root.focus_get()
        index=candidates.index(current) if current in candidates else (-1 if direction>0 else 0)
        target=candidates[(index+direction)%len(candidates)]
        if self.keyboard.focus(target):
            self.target=target;self.target_stamp=self.stamp(target)
            self.next_at=time.monotonic()+self.preferences.scan_ms/1000

    def activate(self,widget,stamp):
        if not self.valid(widget,stamp) or widget.winfo_toplevel() is not self.scope() or not self.keyboard.allowed(widget) or getattr(widget,'_eye_hold_control',False):return
        self.dwell.leave();self.next_at=time.monotonic()+self.preferences.scan_ms/1000
        kind=widget.winfo_class()
        if kind in ('TButton','Button','TCheckbutton','Checkbutton','TRadiobutton','Radiobutton'):
            widget.invoke()
        else:
            from alternate_input_ui import ControlActions
            if self.dialog is None:self.dialog=ControlActions(self,widget,stamp)
        # Every invocation starts a new selection; queued releases cannot repeat it.
        self.target=None;self.target_stamp=None

    def pointer_press(self,event):
        self.pointer_down=True;self.dwell.leave();self.target=None;self.target_stamp=None;self.paused=True
    def pointer_release(self,event):
        self.pointer_down=False;self.dwell.leave()
        self.dwell_latched_widget=getattr(event,'widget',None)

    def tick(self, now=None):
        if not self.running:return
        now=time.monotonic() if now is None else now
        top=self.scope();context=(self.boundary(),top)
        if top is None or context!=self.context:
            self.context=context;self.reset_pending();self.paused=True;self.pointer_down=False
            self.dwell_gate=self.root.winfo_pointerxy()
            self.status.set('Input paused after focus or workspace changed. Select to resume scanning; dwell restarts on pointer movement.')
            return
        try:self.check_conflicts()
        except ValueError as error:self.stop();self.status.set(str(error));return
        if self.preferences.mode=='One switch auto scan' and not self.paused and now>=self.next_at and not self.pressed:
            self.step()
        if not self.preferences.dwell or self.pointer_down or self.dwell_paused or self.pressed:return
        try:
            position=self.root.winfo_pointerxy();widget=self.root.winfo_containing(*position)
            if self.dwell_gate is not None:
                if max(abs(a-b) for a,b in zip(position,self.dwell_gate))<=self.preferences.tolerance:return
                self.dwell_gate=None
            if self.dwell_latched_widget is not None and widget is self.dwell_latched_widget:return
            self.dwell_latched_widget=None
            if (widget is None or widget.winfo_toplevel() is not top or not self.keyboard.allowed(widget)
                or getattr(widget,'_eye_hold_control',False) or widget.winfo_class() not in
                ('TButton','Button','TCheckbutton','Checkbutton','TRadiobutton','Radiobutton')):
                self.dwell.leave();return
            stamp=self.stamp(widget);key=(widget,stamp)
            fire,fraction=self.dwell.sample(key,position,now,self.preferences.dwell_ms/1000,self.preferences.tolerance)
            self.status.set('Dwell '+str(round(fraction*100))+'% · move away to cancel. Escape stops input.')
            if fire:
                self.dwell_latched_widget=widget
                widget.invoke()
                # Commands may restart input, change labels or rebuild the page.
                # A physical departure is required before another activation.
                if self.running:self.dwell_latched_widget=widget
        except (TclError,KeyError):self.dwell.leave()

    def schedule(self):
        if self.closed or not self.running or self.job is not None:return
        self.job=self.root.after(80,self.poll)

    def poll(self):
        self.job=None
        try:self.tick()
        finally:self.schedule()

    def close(self):
        if self.closed:return
        self.stop();self.closed=True
        if self.job:self.root.after_cancel(self.job)
        if self.dialog:self.dialog.close()
        for widget in tuple(self.attached):
            try:widget.bindtags(tuple(t for t in widget.bindtags() if t!=self.tag))
            except TclError:pass
        for sequence in ('<KeyPress>','<KeyRelease>','<ButtonPress>','<ButtonRelease>'):self.root.unbind_class(self.tag,sequence)
        if self.map_id:self.root._unbind(('bind','all','<Map>'),self.map_id)
