# ARC continuation: shader evidence and verified repair copies

This unreleased source checkpoint advances ARC-13, ARC-14, ARC-15, ARC-16 and
ARC-19. All 16 inherited ARC partial areas retain end-to-end gates: 13 have
implemented source awaiting native/provider acceptance, and 3 retain platform
or provider implementation/qualification blockers. The six separately missing
ARC capabilities are unchanged. No item is marked complete merely because its
portable tests pass.

## Shader observations attached to installations

The Unity material tool now exports schema-2 observations containing selected
material pass results, shader support/error flags, the editor target and graphics
API, project context, and bounded file hashes for the saved material, shader,
dependencies, metadata, package manifests and render settings. It checks source
and dependency freshness around capture. Unresolved package or built-in file
dependencies are explicitly recorded as unverified.

The desktop Recovery history adds **Import shader compiler observation…** for a
completed shader installation receipt. Review and commit check account/context,
raw baseline, report bytes, current project bytes, package contents and the
selected installation receipt. A separate history record preserves the imported
outcome, unverified dependencies and other untested shaders in the package.
The original installation-time `not_run` compilation result remains unchanged.

To use this workflow:

1. Open the journal's working `project` in a qualified Unity editor and save the
   material, shader and pipeline assets. Select a material using the installed
   shader under `Assets`.
2. In the typed material mapping tool, compile the selected material's passes
   and export a new JSON shader observation outside the project.
3. Close Unity. In desktop Recovery history, select the completed shader
   installation and choose **Import shader compiler observation…**.
4. Review the exact editor, material, dependency and package evidence, then
   record the observation. Changed evidence requires a fresh capture.

Schema-1 diagnostic exports remain local records but need recapture before this
new import workflow can accept them. Built-in shaders, unsaved materials and
shaders outside the selected installation cannot qualify that installation.

These JSON files are editable local reports. Matching hashes establish that the
report applies to the selected files; they do not authenticate compiler execution
or publisher identity. A compiled selected-material pass is not certification of
the whole package, another platform/quality level, final rendering or runtime
variant stripping. Exported reports contain the local project path and diagnostic
text; explicit absolute source/project fields are omitted from the desktop receipt.

## Verify published repair copies

Material mapping snapshots the expected output before publication. After a
synchronous forced import it reloads the material and checks the shader, queue,
flags, keywords and every declared typed property, including texture references,
offsets and scales. Exact color/vector comparisons detect changes smaller than
Unity's approximate equality operators would detect.

Mesh repair copies additionally verify vertex colors and all eight UV channels,
then compare the reloaded output's geometry, submeshes, bones, blendshapes,
normals and tangents against the expected copy. Existing source freshness,
ownership, output ancestry and journal checks remain active. A callback-altered
output interrupts the operation and retains partial output for inspection.

Six new Unity EditMode test methods cover precise material value/transform/queue
comparison, saved shader file evidence, path rejection, changed bytes, structured
observations, unsaved sources and an actual material import callback. They are
**unrun** here: this environment has no Unity editor or C# compiler. Across the
recent continuation passes, 35 added Unity test methods remain unrun.

## Remaining acceptance

The gates in [the previous containment pass](ARC_CONTINUATION.md) remain open:
Windows parser containment; exporter filesystem/network containment; an exact
qualified AssetRipper release; native viewer/accessibility behavior; Unity
import, rendering and repair-copy semantics; actual provider transfers/retries;
installed VPM, host process recovery and power-loss behavior. This environment
also has no graphical desktop or Windows runtime. Portable failures are fixed
here; unavailable native results are never counted as passed.

Current machine-readable evidence is in `PENDING_WORKING_VALIDATION.json` under
`arc_repair_update`, `ARC_QUALIFICATION_STATUS.json`, and
`PARTIAL_COMPLETION_STATUS.json`. Prior evidence is retained. The source identity
remains `2026.05.10.02.47.1`, compatibility `1.21.0`. No numbered release,
compiled executable or installer was produced.

API references used during source review:
[Unity ShaderUtil](https://docs.unity3d.com/cn/2022.3/ScriptReference/ShaderUtil.html),
[CompilePass](https://docs.unity3d.com/cn/current/ScriptReference/ShaderUtil.CompilePass.html),
[AssetDatabase](https://docs.unity3d.com/cn/2022.3/ScriptReference/AssetDatabase.html).
