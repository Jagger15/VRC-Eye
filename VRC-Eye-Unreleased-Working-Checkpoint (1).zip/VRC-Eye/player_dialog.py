"""Explicit user-platform import; works without a VRCX connection."""

from text_viewport import window_body

from pathlib import Path

from player_trust import BLOCK_STATUS, TRUST_LIMITS

from player_platforms import MAX_USER_JSON_BYTES, parse_user_platform, platform_details


def show_player_dialog(app, event):
    from tkinter import filedialog, messagebox
    tk, ttk = app.tk, app.ttk
    generation = app.data_generation
    window = tk.Toplevel(app.root)
    window.title("Player details")
    window.geometry("850x750")
    window.minsize(780, 700)
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Player details", font='EyeTitleFont').pack(anchor="w")
    ttk.Label(frame, text=f"{event.player}\nUser ID from log: {event.user_id or 'Unavailable'}",
              wraplength=740).pack(anchor="w", pady=(8, 12))
    status = tk.StringVar(value=platform_details(event, app.player_platforms))
    ttk.Label(frame, textvariable=status, style="Muted.TLabel", wraplength=740).pack(anchor="w", pady=(0, 12))
    ttk.Label(frame, text=("Look up this user directly through your VRChat connection. JSON import or paste is a backup. "
        "The user ID must match the log. PC, Android, and iOS come from user platform fields; avatar build lists do not identify the player. "
        "Android can mean a standalone headset or an Android phone. PC does not distinguish VR from desktop mode.\n\n"
        "Each lookup is a snapshot; last_platform is labeled last known. This cannot prove the device at an older avatar-event time. "
        "Look up again for newer data. Only the user ID, platform, derived trust rank/note, source and time are retained for this session.\n\n"
        + TRUST_LIMITS + "\nBlocked me: " + BLOCK_STATUS),
        style="Muted.TLabel", wraplength=740).pack(anchor="w", pady=(0, 10))
    online_row = ttk.Frame(frame)
    online_row.pack(fill="x", pady=(0, 10))

    def online():
        from online_dialog import lookup_online
        previous = app.player_platforms.get(event.user_id)

        def apply(record):
            if app.player_platforms.get(event.user_id) is not previous:
                raise ValueError("Player data changed while the lookup was running. Look up again to replace it.")
            app.remember_player_platform(event, record, generation=generation)
            if window.winfo_exists():
                status.set(platform_details(event, app.player_platforms))

        lookup_online(app, "user", event.user_id, apply, parent=window, on_fallback=import_file)

    ttk.Button(online_row, text="Look up online", command=online, style="Accent.TButton",
               state="normal" if event.user_id and not app.demo else "disabled").pack(side="left")
    if not event.user_id:
        ttk.Label(frame, text="This row has no unambiguous user ID. Open a log containing that player's OnPlayerJoined entry with a usr_ ID, then select a later avatar event.",
                  style="Accent.TLabel", wraplength=740).pack(anchor="w", pady=(0, 10))
    editor = tk.Text(frame, height=7, wrap="word", bg=app.PANEL, fg=app.TEXT,
                     insertbackground=app.TEXT, undo=False)
    editor.pack(fill="both", expand=True, pady=(0, 12))

    def apply_text(text):
        try:
            record = parse_user_platform(text, event.user_id, allow_missing=True)
            app.remember_player_platform(event, record, generation=generation)
        except (ValueError, UnicodeError) as error:
            messagebox.showerror("Could not import player details", str(error), parent=window)
            return
        editor.delete("1.0", "end")
        status.set(platform_details(event, app.player_platforms))

    def import_file():
        path = filedialog.askopenfilename(parent=window, title="Select user JSON export",
            filetypes=[("JSON", "*.json"), ("All files", "*")])
        if not path:
            return
        try:
            with Path(path).open("rb") as stream:
                content = stream.read(MAX_USER_JSON_BYTES + 1)
            if len(content) > MAX_USER_JSON_BYTES:
                raise ValueError("User JSON is too large (maximum 2 MiB).")
            text = content.decode("utf-8-sig")
        except (OSError, ValueError, UnicodeError) as error:
            messagebox.showerror("Could not read user JSON", str(error), parent=window)
            return
        apply_text(text)

    def clear():
        try:
            app.remember_player_platform(event, None, generation=generation)
        except ValueError as error:
            messagebox.showerror("Could not clear platform", str(error), parent=window)
            return
        status.set(platform_details(event, app.player_platforms))

    buttons = ttk.Frame(frame)
    buttons.pack(fill="x")
    enabled = "normal" if event.user_id and not app.demo else "disabled"
    ttk.Button(buttons, text="Import user JSON…", command=import_file, state=enabled).pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Use pasted JSON", command=lambda: apply_text(editor.get("1.0", "end-1c")), state=enabled).pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Clear for this user", command=clear, state=enabled).pack(side="left", padx=(0, 8))
    ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right")
    editor.focus_set()
    if event.user_id and not app.demo and app.api and app.api.authenticated:
        online()
