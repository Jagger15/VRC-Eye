"""Additional explicit conditions for the existing Home and widget editors."""
from companion_ui import choice
from friendly_ui import flow_line
from dashboard_conditions import CONDITIONS, terms


class ConditionPicker:
    def __init__(self, page, parent, primary):
        self.variables = [primary]
        page.ttk.Label(parent, text='All chosen conditions must match. Leave unused conditions on Always.', wraplength=800).pack(anchor='w', pady=4)
        for index in range(3):
            row = flow_line(page, parent)
            page.ttk.Label(row, text=f'Also require ({index + 2})').pack(side='left')
            var = page.tk.StringVar(value='Always'); self.variables.append(var)
            choice(page, row, var, CONDITIONS, width=24)

    def get(self):
        selected = [var.get() for var in self.variables if var.get() != 'Always']
        value = selected if len(selected) > 1 else selected[0] if selected else 'Always'
        terms(value)
        return value

    def set(self, value):
        selected = terms(value)
        for index, var in enumerate(self.variables): var.set(selected[index] if index < len(selected) else 'Always')
