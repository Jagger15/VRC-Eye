"""Bounded native catalog batch import and standalone, inert HTML export.

No network calls, global scans, alternate catalog or new account state. Plans
hold frozen reviewed data in RAM; the existing AvatarLibrary owns persistence.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import base64
from hashlib import sha256
from html import escape
from io import BytesIO
import json
import math
from pathlib import Path
import re

from avatar_library import normalize_observation, scope_id, SCHEMA, text
from avatar_library_files import check_cancel, checked_stream, image_preview
from creator_projects import assert_no_links, local_path
from avatar_creator_store import sanitize_export

MAX_INPUT = 8 * 1024**2
MAX_AVATARS = 500
MAX_BUILDS = 2048
MAX_NODES = 100000
MAX_DEPTH = 12
MAX_GALLERY = 96
MAX_HTML = 24 * 1024**2


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON field names are not supported.')
        result[key] = value
    return result


def _bounded(value):
    stack = [(value, 0)]
    count = 0
    while stack:
        item, depth = stack.pop()
        count += 1
        if count > MAX_NODES or depth > MAX_DEPTH:
            raise ValueError('Metadata exceeds the supported nesting or value-count limit.')
        if isinstance(item, dict):
            if any(not isinstance(key, str) or len(key) > 256 for key in item):
                raise ValueError('Unsupported metadata field name.')
            stack.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            stack.extend((v, depth + 1) for v in item)
        elif isinstance(item, str):
            item.encode('utf-8')
        elif type(item) is float and not math.isfinite(item):
            raise ValueError('Non-finite JSON values are unsupported.')
        elif type(item) is int and abs(item) > 2**63 - 1:
            raise ValueError('Integer metadata exceeds the supported range.')
        elif type(item) not in (int, bool, float, type(None)):
            raise ValueError('Metadata must contain JSON data only.')


def _report_avatar(row):
    """Selected report roundtrip imports observations, never files/private data."""
    if not isinstance(row, dict):
        raise ValueError('Every report avatar must be an object.')
    document = {key: row[key] for key in ('id', 'name') if key in row}
    for before, after in (('author', 'authorName'), ('visibility', 'releaseStatus')):
        if before in row:
            document[after] = row[before]
    if 'builds' in row:
        builds = row['builds']
        if not isinstance(builds, list):
            raise ValueError('Report builds must be a list.')
        document['unityPackages'] = []
        for build in builds:
            if not isinstance(build, dict):
                raise ValueError('Report builds must contain objects.')
            document['unityPackages'].append({after: build[before] for before, after in (
                ('platform', 'platform'), ('unity', 'unityVersion'), ('asset_version', 'assetVersion'),
                ('variant', 'variant')) if before in build and build[before] is not None})
    return document


def _clean_document(document):
    if not isinstance(document, dict):
        raise ValueError('Each imported avatar must be a metadata object.')
    clean = {key: document[key] for key in ('id', 'name', 'authorName', 'authorId', 'description',
             'releaseStatus', 'created_at', 'updated_at', 'tags', 'version') if key in document}
    if 'unityPackages' in document:
        packages = document['unityPackages']
        if packages is None:
            packages = []
        if not isinstance(packages, list) or len(packages) > 1000 or any(not isinstance(p, dict) for p in packages):
            raise ValueError('Use at most 1,000 build objects per avatar.')
        clean['unityPackages'] = [{key: p[key] for key in ('platform', 'unityVersion', 'assetVersion', 'variant',
                                  'created_at', 'fileId', 'fileVersion', 'assetUrl') if key in p} for p in packages]
    normalize_observation(clean)
    return clean


def decode_batch(data):
    if not isinstance(data, (bytes, str)):
        raise ValueError('Choose a UTF-8 JSON metadata file.')
    try:
        raw = data.encode('utf-8') if isinstance(data, str) else data
        if len(raw) > MAX_INPUT:
            raise ValueError('Bulk metadata imports are limited to 8 MiB.')
        document = json.loads(raw.decode('utf-8-sig'), object_pairs_hook=_pairs,
            parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Non-finite JSON values are unsupported.')))
        _bounded(document)
    except (UnicodeError, RecursionError, OverflowError) as error:
        raise ValueError('Use bounded UTF-8 JSON metadata.') from error
    report = False
    if isinstance(document, dict) and 'avatars' in document:
        schema = document.get('schema')
        if schema is not None and schema != SCHEMA:
            raise ValueError('Unsupported avatar report schema.')
        report = schema == SCHEMA
        rows = document['avatars']
    elif isinstance(document, dict):
        rows = [document]
    else:
        rows = document
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_AVATARS:
        raise ValueError('Import 1–500 avatar objects in one batch.')
    clean, identities, builds = [], set(), 0
    for row in rows:
        item = _clean_document(_report_avatar(row) if report else row)
        observation = normalize_observation(item)
        identity = observation['metadata']['id']
        if identity in identities:
            raise ValueError('The batch contains duplicate avatar IDs; resolve them before importing.')
        identities.add(identity)
        builds += len(item.get('unityPackages', []))
        if builds > MAX_BUILDS:
            raise ValueError('One batch supports at most 2,048 build descriptors in total.')
        clean.append(item)
    return tuple(clean)


def read_batch(path, *, stop=None, progress=None):
    check_cancel(stop)
    with checked_stream(path, limit=MAX_INPUT) as (_, stream, info):
        data = stream.read(MAX_INPUT + 1)
    check_cancel(stop)
    if progress:
        progress('Validating selected metadata…')
    result = decode_batch(data)
    check_cancel(stop)
    return result


@dataclass(frozen=True)
class ImportPlan:
    scope: str
    documents: tuple = field(repr=False)
    expected: tuple = field(repr=False)
    summary: str
    source_library: object = field(repr=False, compare=False)


def prepare_import(library, scope, documents, *, stop=None):
    scope = scope_id(scope)
    if not isinstance(documents, (tuple, list)):
        raise ValueError('Inspect an avatar batch first.')
    # Revalidate callers as well as file readers; canonical copy rejects mutation.
    documents = decode_batch(canonical(list(documents)))
    expected, frozen, lines = [], [], [f'Workspace: {scope}', f'Avatar observations: {len(documents)}',
        'One transaction: either all observations save or none do. Existing local notes, favorites, thumbnails and file references remain.',
        'Incoming metadata updates matching IDs; omitted fields are retained. Names are not identities.',
        'Imported data is an observation, not proof of ownership, available assets or complete build history.',
        'No online lookup, download, worn-avatar change or local-file import.\n']
    for document in documents:
        check_cancel(stop)
        observation = normalize_observation(document)
        meta = observation['metadata']
        identity = meta['id']
        old = library.get(scope, identity)
        expected.append((identity, canonical(old) if old is not None else None))
        frozen.append(canonical(document))
        lines.append(f'{identity} — {"Update existing observation" if old else "Add new observation"}')
        changed = False
        for key, value in sorted(meta.items()):
            if key in ('id', 'current_builds'):
                continue
            before = old.get(key) if old else None
            if before != value:
                lines.append(f'  {key}: {before!r} → {value!r}')
                changed = True
        lines.append(f'  Build descriptors in import: {len(observation["builds"])}')
        if not changed:
            lines.append('  Metadata unchanged; source/observation times will refresh.')
    return ImportPlan(scope, tuple(frozen), tuple(expected), '\n'.join(lines), library)


def commit_import(library, plan, *, stop=None):
    if not isinstance(plan, ImportPlan) or plan.source_library is not library:
        raise ValueError('Use the reviewed plan belonging to this catalog.')
    check_cancel(stop)
    documents = [json.loads(raw) for raw in plan.documents]
    return library.observe_batch(plan.scope, documents, expected=dict(plan.expected), stop=stop)


@dataclass(frozen=True)
class GalleryPlan:
    scope: str
    identifiers: tuple
    expected: tuple = field(repr=False)
    html: bytes = field(repr=False)
    summary: str
    thumbnails: bool
    source_library: object = field(repr=False, compare=False)


def export_text(value, limit):
    value = sanitize_export(text(value, limit))
    value = re.sub(r'https?://[^\s<>"\x27]+', '[URL omitted]', value, flags=re.I)
    return re.sub(r'usr_[a-fA-F0-9-]{36}', '[account ID omitted]', value)


def prepare_gallery(library, scope, identifiers, *, thumbnails=False, title='Avatar gallery', stop=None):
    scope = scope_id(scope)
    title = export_text(title, 120)
    if not title:
        raise ValueError('Give the gallery a title.')
    if type(thumbnails) is not bool or not isinstance(identifiers, (tuple, list)) or not 1 <= len(identifiers) <= MAX_GALLERY:
        raise ValueError('Choose 1–96 explicitly selected catalog avatars.')
    if len(set(identifiers)) != len(identifiers):
        raise ValueError('Choose each avatar only once.')
    expected, cards, names, embedded = [], [], [], 0
    for identity in identifiers:
        check_cancel(stop)
        row = library.get(scope, identity)
        if row is None:
            raise ValueError('A selected avatar is no longer in this workspace.')
        expected.append((row['id'], canonical(row)))
        name = export_text(row.get('name'), 512) or row['id']
        author = export_text(row.get('author'), 512) or 'Unknown creator'
        visibility = export_text(row.get('visibility'), 80) or 'Unknown'
        platforms = ', '.join(export_text(p, 80) for p in row.get('platforms', [])) or 'Unknown'
        names.append(name + ' · ' + row['id'] + '\n  Creator: ' + author + '\n  Visibility: ' + visibility + '\n  Observed platforms: ' + platforms)
        picture = '<div class="placeholder" aria-label="No image included">No image included</div>'
        if thumbnails and row.get('thumbnail'):
            try:
                raw = base64.b64decode(row['thumbnail'], validate=True)
                if len(raw) > 180000:
                    raise ValueError('Saved thumbnail exceeds the supported limit.')
                cleaned = image_preview(raw, (220, 140))
            except (ValueError, OSError, TypeError) as error:
                raise ValueError('A saved thumbnail could not be validated; turn off images or replace it before exporting.') from error
            picture = '<img alt="Saved avatar thumbnail" width="220" height="140" src="data:image/png;base64,' + base64.b64encode(cleaned).decode('ascii') + '">'
            embedded += 1
        cards.append('<article>' + picture + '<h2>' + escape(name) + '</h2><p class="creator">' + escape(author) +
                     '</p><p><strong>Visibility:</strong> ' + escape(visibility) + '</p><p><strong>Observed platforms:</strong> ' +
                     escape(platforms) + '</p><p class="identifier">' + escape(row['id']) + '</p></article>')
    # Literal CSS only. No links, scripting, imports, event handlers or user HTML.
    header = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
              '<meta name="viewport" content="width=device-width,initial-scale=1">'
              '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
              '<meta name="referrer" content="no-referrer"><title>' + escape(title) + '</title><style>'
              'body{font:16px system-ui,sans-serif;background:#101722;color:#f3f6fa;margin:0;padding:28px;line-height:1.5}'
              'main{max-width:1300px;margin:auto}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}'
              'article{background:#1b2637;border:1px solid #71829c;border-radius:14px;padding:18px;overflow-wrap:anywhere}'
              'img,.placeholder{display:block;max-width:100%;height:140px;object-fit:contain;margin:auto;background:#101722;border-radius:8px}'
              '.placeholder{display:flex;align-items:center;justify-content:center;color:#c1cad8}h2{font-size:1.15rem;margin-bottom:4px}'
              '.creator{color:#d2dfef;margin-top:0}.identifier{font:12px monospace}footer{margin-top:28px;color:#c1cad8}'
              '@media print{body{background:white;color:black}article{background:white;color:black;break-inside:avoid}.creator,footer{color:#333}}'
              '</style></head><body><main><h1>' + escape(title) + '</h1><p>' + str(len(cards)) +
              ' saved avatar observations. Metadata may be incomplete or outdated; this gallery does not grant access or establish ownership.</p><section class="grid">')
    html = (header + ''.join(cards) + '</section><footer>Exported by VRC Eye. Static local gallery; no scripts or remote resources.</footer></main></body></html>').encode('utf-8')
    if len(html) > MAX_HTML:
        raise ValueError('This gallery exceeds the 24 MiB export limit.')
    summary = (f'Workspace: {scope}\nTitle: {title}\nAvatars: {len(cards)}\nEmbedded saved thumbnails: {embedded}\nOutput size: {len(html):,} bytes\n\n'
        'Included: avatar names/IDs, creator names, observed visibility/platforms, and images only if enabled.\n'
        'Excluded: descriptions, private notes, account IDs, source paths, provider endpoints, file inventories and remote image references.\n'
        'Human-entered names and images can still identify people or contain sensitive content. Review this selection before sharing.\n'
        'No browser opens automatically. This is a standalone local HTML document, not a published website.\n\n' + '\n'.join(names))
    return GalleryPlan(scope, tuple(identifiers), tuple(expected), html, summary, thumbnails, library)


def validate_gallery(library, plan):
    if not isinstance(plan, GalleryPlan) or plan.source_library is not library:
        raise ValueError('Use the reviewed gallery from this catalog.')
    for identity, expected in plan.expected:
        row = library.get(plan.scope, identity)
        if row is None or canonical(row) != expected:
            raise ValueError('A selected catalog record changed after review. Prepare the gallery again.')


def save_gallery(library, plan, destination, *, stop=None, progress=None, before_commit=None):
    validate_gallery(library, plan)
    check_cancel(stop)
    path = assert_no_links(local_path(destination))
    if path.suffix.lower() != '.html' or not path.parent.is_dir() or path.exists() or path.is_symlink():
        raise ValueError('Choose a new .html filename in an existing folder; nothing is overwritten.')
    parent_stat = path.parent.stat()
    identity = (parent_stat.st_dev, parent_stat.st_ino)
    def check():
        check_cancel(stop)
        assert_no_links(path.parent)
        now = path.parent.stat()
        if (now.st_dev, now.st_ino) != identity:
            raise ValueError('The export folder changed during saving.')
        validate_gallery(library, plan)
        if before_commit:
            before_commit()
    from vrca_files import _save_stream
    return _save_stream(BytesIO(plan.html), path, len(plan.html), sha256(plan.html).hexdigest(), stop, progress,
                        network=False, before_commit=check, suffixes=('.html',))
