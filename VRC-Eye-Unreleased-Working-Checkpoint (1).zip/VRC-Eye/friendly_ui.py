"""Friendly shell for VRC Eye. This module changes presentation, not authority.

Existing page/controller instances retain their state, job cancellation, guards
and transport ownership. No UI preference can arm OSC, pair a peer, sign in,
start a provider or grant a bridge capability.
"""
from __future__ import annotations

from text_viewport import window_body

import sqlite3
from typing import Callable

from companion_ui import Page
from ui_preferences import Presentation, MODES, DENSITIES, TEXT_SIZES, PREFERENCE_KEY
from ui_navigation import LABELS, ADVANCED_PAGES, TOOL_BY_KEY, search_tools


class Disclosure:
    """A keyboard-focusable expander; collapsing never destroys its contents."""
    def __init__(self, app, parent, title, *, opened=False):
        self.app, self.title, self.opened = app, title, bool(opened)
        self.frame = app.ttk.Frame(parent)
        self.frame.pack(fill="x", pady=(4, 4))
        self.button = app.ttk.Button(self.frame, style="Quiet.TButton", command=self.toggle)
        self.button.pack(anchor="w")
        self.body = app.ttk.Frame(self.frame, padding=(8, 4, 0, 4))
        self.set_open(opened)

    def set_open(self, opened):
        self.opened = bool(opened)
        self.button.configure(text=("Hide " if self.opened else "Show ") + self.title.lower())
        if self.opened:
            self.body.pack(fill="x")
        else:
            self.body.pack_forget()

    def toggle(self):
        self.set_open(not self.opened)


def focus_scroll_target(position, extent, viewport, start):
    """Reveal a fitting control; align an oversized control's leading edge."""
    # A trailing margin cannot displace the start of an oversized control off
    # screen. Fit the margin in the actual spare room on both sides instead.
    margin = min(8, max(0, (viewport - extent) // 2))
    if position < start:
        return max(0, position - margin)
    if position + extent > start + viewport:
        return max(0, position + min(extent, viewport) - viewport + margin)
    return start


class ScrollPane:
    """Scrollable content for settings and Home, including narrow windows."""
    def __init__(self, app, parent, *, min_width=700):
        parent = window_body(parent)
        self.app = app
        self._focus_idle = None
        self._content_size = None
        self.frame = app.ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True)
        self.canvas = app.tk.Canvas(self.frame, background=app.BG, highlightthickness=0)
        self.y = app.ttk.Scrollbar(self.frame, orient="vertical", command=self.canvas.yview)
        self.x = app.ttk.Scrollbar(self.frame, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=self.y.set, xscrollcommand=self.set_xscroll)
        self.x.pack(side="bottom", fill="x")
        self.y.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.body = app.ttk.Frame(self.canvas, padding=(0, 2, 14, 10))
        self.body._eye_scroll_canvas = self.canvas
        self.canvas._eye_scroll_canvas = self.canvas
        self.item = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.min_width = min_width
        self.body.bind("<Configure>", self.content_changed)
        self.canvas.bind("<Configure>", self.resize)

    def content_changed(self, event=None):
        if getattr(getattr(getattr(self, 'app', None), 'presentation', None), 'font_percent', 100) > 200:
            width = max(self.min_width, self.canvas.winfo_width(), self.body.winfo_reqwidth())
            if self.body.winfo_width() != width:self.canvas.itemconfigure(self.item, width=width)
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))
        self._bind_focus(self.body)
        size = (self.body.winfo_width(), self.body.winfo_height())
        if size != self._content_size:
            self._content_size = size
            self._reveal_after_layout()

    def _reveal_after_layout(self):
        # Scaling can move an already-focused control without another FocusIn.
        if self._focus_idle is not None:return
        def reveal():
            self._focus_idle = None
            from tkinter import TclError
            from types import SimpleNamespace
            try:
                focused = self.canvas.focus_get()
                node = focused
                while node is not None and node is not self.body:
                    node = getattr(node, 'master', None)
                if node is self.body:self.focus_visible(SimpleNamespace(widget=focused))
            except TclError:pass
        self._focus_idle = self.canvas.after_idle(reveal)

    def _bind_focus(self, parent):
        for widget in parent.winfo_children():
            if not getattr(widget, "_eye_workspace_focus", False):
                widget._eye_workspace_focus = True
                widget.bind("<FocusIn>", self.focus_visible, add="+")
                widget._eye_workspace_geometry = None
                widget.bind("<Configure>", self._focused_geometry_changed, add="+")
            self._bind_focus(widget)

    def _focused_geometry_changed(self, event):
        # Nested rows can move a retained focused control without resizing the
        # outer body. Track parent-relative geometry: a manual canvas scroll
        # changes screen coordinates only and must not snap back to old focus.
        widget = event.widget
        geometry = (event.x, event.y, event.width, event.height)
        if geometry == widget._eye_workspace_geometry:
            return
        widget._eye_workspace_geometry = geometry
        focused = self.canvas.focus_get()
        while focused is not None and focused is not widget:
            focused = getattr(focused, 'master', None)
        if focused is widget:
            self._reveal_after_layout()

    def focus_visible(self, event):
        from tkinter import TclError
        try:
            widget = event.widget
            box = self.canvas.bbox("all")
            if not box or not widget.winfo_ismapped():
                return
            for axis, root_pos, size in (("x", "winfo_rootx", "winfo_width"), ("y", "winfo_rooty", "winfo_height")):
                position = getattr(widget, root_pos)() - getattr(self.body, root_pos)()
                extent = getattr(widget, size)()
                viewport = getattr(self.canvas, size)()
                visible_start = getattr(self.canvas, "canvas" + axis)(0)
                target = focus_scroll_target(position, extent, viewport, visible_start)
                total = box[2 if axis == "x" else 3]
                if total > 0 and target != visible_start:
                    getattr(self.canvas, axis + "view_moveto")(min(1., target / total))
        except TclError:
            pass  # The window may have closed during a focus transition.


    def set_xscroll(self, first, last):
        self.x.set(first, last)
        if float(first) <= 0 and float(last) >= 1:
            self.x.pack_forget()
        else:
            self.x.pack(side="bottom", fill="x", before=self.canvas)

    def resize(self, event):
        natural = self.body.winfo_reqwidth() if getattr(getattr(getattr(self, 'app', None), 'presentation', None), 'font_percent', 100) > 200 else 0
        self.canvas.itemconfigure(self.item, width=max(self.min_width, event.width, natural))
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.wrap_labels(self.body)
        self._reveal_after_layout()

    def wrap_labels(self, parent):
        # Bind once per label; each nested card uses its own available width.
        from ui_theme import responsive_wrap
        for child in parent.winfo_children():
            if child.winfo_class() in ("Label", "TLabel") and not getattr(child, "_eye_wrapped", False):
                maximum = int(float(child.cget("wraplength") or 0))
                if maximum:
                    responsive_wrap(child, maximum=maximum, inset=38)
            self.wrap_labels(child)

    def top(self):
        self.canvas.yview_moveto(0)


def flow_line(page, parent=None):
    """New-workspace control row: stack rather than clip at large UI scales."""
    frame = page.ttk.Frame(parent or page.parent)
    frame.pack(fill='x', pady=4)
    frame._eye_vertical = None
    def layout(event=None):
        children = frame.winfo_children()
        if not children: return
        needed = sum(child.winfo_reqwidth() + 6 for child in children)
        vertical = needed > max(1, frame.winfo_width())
        if vertical == frame._eye_vertical: return
        frame._eye_vertical = vertical
        for child in children:
            child.pack_configure(side='top' if vertical else 'left',
                                 fill='x' if vertical else 'none',
                                 anchor='w', padx=(0, 0 if vertical else 6), pady=3 if vertical else 0)
    frame.bind('<Configure>', layout, add='+')
    frame.after_idle(layout)
    return frame


class NotebookNavigator:
    """A compact switcher over the *same* Notebook pages, not a second UI.

    All pages remain discoverable in the drop-down. Selecting an advanced page
    reveals that page's display level only. Disabled capability tabs stay disabled.
    """
    def __init__(self, app, notebook, pages, *, levels=None, mode="Casual", view=None, show=None):
        self.app, self.notebook, self.pages = app, notebook, dict(pages)
        self.levels = dict(levels or {})
        self.view, self.show_callback = view, show
        self.mode, self.closed = mode, False
        self.trace = None
        self.layout_job = None
        self.quick_names = ()
        self.quick_candidates = ()
        self.quick_gap = None
        self.bar = app.ttk.Frame(notebook.master)
        self.bar._eye_notebook = notebook
        self.bar.pack(fill="x", before=notebook, pady=(3, 7))
        self.quick = app.ttk.Frame(self.bar)
        self.choice = app.tk.StringVar()
        self.picker = app.ttk.Combobox(self.bar, textvariable=self.choice, state="readonly", width=26,
                                     style="Navigation.TCombobox")
        # Allocate the all-pages picker first: quick links yield to overflow at
        # narrow widths. Their request must not push the picker off the window.
        self.picker.pack(side="right", padx=(8, 0))
        self.quick.pack(side="left", fill="x", expand=True)
        self.quick.pack_propagate(False)
        self.picker.bind("<<ComboboxSelected>>", lambda _: self.open_choice())
        self.buttons = {name: app.ttk.Button(self.quick, text=name, style="TabLink.TButton",
                       command=lambda n=name: self.open(n)) for name in self.pages}
        for button in self.buttons.values():
            from screen_reader_model import annotate
            annotate(button,public=True,role='tab')
            for sequence, step in (("<Left>", -1), ("<Right>", 1), ("<Home>", "first"), ("<End>", "last")):
                button.bind(sequence, lambda event, s=step: self.move_focus(event.widget, s))
            button.bind("<Return>", lambda event: self.activate_focused(event.widget))
        self.quick.bind("<Configure>", self.queue_layout, add="+")
        self.bar.bind("<<ThemeChanged>>", self.queue_layout, add="+")
        self.bar.bind("<Destroy>", self._destroyed, add="+")
        self.labels = {}
        notebook.configure(style="Friendly.TNotebook")
        self.tab_binding = notebook.bind("<<NotebookTabChanged>>", lambda _: self.sync(), add="+")
        if view is not None:
            self.trace = view.trace_add("write", lambda *_: self.apply_mode(view.get()))
        self.apply_mode(mode)

    def selected_name(self):
        selected = self.notebook.select()
        return next((name for name, frame in self.pages.items()
                     if selected is frame or str(selected) == str(frame)), next(iter(self.pages), ""))

    def tab_state(self, name):
        state = self.notebook.tab(self.pages[name], "state")
        return str(state)

    def apply_mode(self, mode):
        if self.closed:
            return
        self.mode = mode if mode in MODES else "Casual"
        rank = MODES.index(self.mode)
        for name, frame in self.pages.items():
            # A disabled tab can represent a capability restriction. Never clear it.
            if self.tab_state(name) == "disabled":
                continue
            level = self.levels.get(name, "Casual")
            self.notebook.tab(frame, state="normal" if MODES.index(level) <= rank else "hidden")
        self.sync()

    def queue_layout(self, event=None):
        if not self.closed and self.layout_job is None:
            self.layout_job = self.bar.after_idle(self.layout_quick)

    def layout_quick(self):
        self.layout_job = None
        if self.closed:
            return
        # Only window/font/page-set changes change the visible quick slots.
        # Selection never substitutes a label or repacks this row.
        gap = max(4, round(4 * getattr(self.app, "presentation", Presentation()).scale / 100))
        height = max((button.winfo_reqheight() for button in self.buttons.values()), default=1)
        if self.quick.winfo_reqheight() != height:
            self.quick.configure(height=height)
        available = self.quick.winfo_width()
        names = []
        for name in self.quick_candidates[:3]:
            required = self.buttons[name].winfo_reqwidth() + gap
            if required > available:
                break
            names.append(name)
            available -= required
        names = tuple(names)
        if names == self.quick_names and gap == self.quick_gap:
            return
        # A frame that shrinks to zero can unmap its focused child before the
        # idle layout runs. Tk retains that toplevel's intended focus target.
        focused = self.bar.focus_get() or self.bar.focus_lastfor()
        if focused in [self.buttons[name] for name in self.quick_names if name not in names]:
            # Transfer before unmapping; never force application focus from
            # another window just because this strip reflows.
            self.picker.focus_set()
        for name in self.quick_names:
            self.buttons[name].pack_forget()
        for name in names:
            self.buttons[name].pack(side="left", padx=(0, gap))
        self.quick_names = names
        self.quick_gap = gap

    def sync(self):
        if self.closed:
            return
        selected = self.selected_name()
        states = {name: self.tab_state(name) for name in self.pages}
        rank = MODES.index(self.mode)
        candidates = tuple(name for name in self.pages if states[name] == "normal" or
                           (states[name] == "disabled" and MODES.index(self.levels.get(name, "Casual")) <= rank))
        for name, button in self.buttons.items():
            button.configure(style="Selected.TabLink.TButton" if name == selected else "TabLink.TButton")
            button.state(["selected" if name == selected else "!selected",
                          "disabled" if states[name] == "disabled" else "!disabled"])
        if candidates != self.quick_candidates:
            self.quick_candidates = candidates
            self.queue_layout()
        self.labels = {}
        for name in self.pages:
            state = states[name]
            suffix = " · unavailable" if state == "disabled" else " · more tools" if state == "hidden" else ""
            self.labels[name + suffix] = name
        self.picker.configure(values=tuple(self.labels))
        label = next((label for label, name in self.labels.items() if name == selected), "All workspace tabs")
        self.choice.set(label)

    def move_focus(self, widget, step):
        if self.closed:
            return "break"
        buttons = [self.buttons[name] for name in self.quick_names if not self.buttons[name].instate(["disabled"])]
        if buttons:
            index = buttons.index(widget) if widget in buttons else 0
            target = 0 if step == "first" else len(buttons) - 1 if step == "last" else (index + step) % len(buttons)
            buttons[target].focus_set()
        return "break"

    def activate_focused(self, widget):
        if not self.closed:
            widget.invoke()
        return "break"

    def open_choice(self):
        name = self.labels.get(self.choice.get())
        if name:
            self.open(name)

    def open(self, name):
        if self.closed or name not in self.pages or self.tab_state(name) == "disabled":
            self.sync()
            return False
        needed = self.levels.get(name, "Casual")
        if MODES.index(needed) > MODES.index(self.mode):
            if self.view is not None:
                self.view.set(needed)  # A display variable, never a service permission.
            self.apply_mode(needed)
        if self.tab_state(name) == "hidden":
            self.notebook.tab(self.pages[name], state="normal")
        self.notebook.select(self.pages[name])
        if self.show_callback:
            self.show_callback(name)
        self.sync()
        return True

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.layout_job is not None:
            self.bar.after_cancel(self.layout_job)
            self.layout_job = None
        try:
            self.notebook.unbind("<<NotebookTabChanged>>", self.tab_binding)
        except self.app.tk.TclError:
            pass
        if self.trace is not None and self.view is not None:
            try:
                self.view.trace_remove("write", self.trace)
            except (AttributeError, self.app.tk.TclError):
                pass

    def _destroyed(self, event):
        if event.widget is self.bar:
            self.close()


def card(app, parent, title, *, row=None, column=0, columns=1):
    frame = app.ttk.Frame(parent, style="Card.TFrame", padding=16)
    if row is None:
        frame.pack(fill="x", pady=(0, 12))
    else:
        frame.grid(row=row, column=column, columnspan=columns, sticky="nsew", padx=(0, 10), pady=(0, 10))
    app.ttk.Label(frame, text=title, style="CardTitle.TLabel").pack(anchor="w", pady=(0, 5))
    return frame


class HomePage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, "Home", task_controls=False)
        self.status.set("Your session and your everyday tools, in one place.")
        self.scroll = ScrollPane(self.app, parent)
        body = self.scroll.body
        self.intro = self.tk.StringVar(value="Ready when you are.")
        self.ttk.Label(body, textvariable=self.intro, style="Muted.TLabel", wraplength=900).pack(anchor="w", fill="x", pady=8)
        self.session_value, self.events_value, self.account_value = (self.tk.StringVar() for _ in range(3))
        from novelty_ui import NoveltyPanel
        self.novelty=NoveltyPanel(self,body)
        from home_dashboard import HomeDashboard
        self.dashboard = HomeDashboard(self, body)
        from spatial_ui import attach_home
        attach_home(self)
        self.last_snapshot = None
        self.tick()

    def tick(self):
        super().tick()
        if self.closed:
            return
        self.novelty.engine.tick();self.novelty.render()
        self.dashboard.tick()
        app = self.app
        demo, safe = bool(app.demo), bool(getattr(app, "safe_mode", False))
        signed = bool(app.api and app.api.authenticated)
        source = bool(app.source)
        snapshot = (demo, safe, signed, source, len(app.events), bool(app.paused))
        if snapshot == self.last_snapshot:
            return
        self.last_snapshot = snapshot
        self.session_value.set("Sample data" if demo else "Log selected" if source else "Waiting for log")
        self.events_value.set(f"{len(app.events):,} events")
        self.account_value.set("Signed in" if signed else "Not signed in")
        if demo:
            text = "You're exploring sample data. No live VRChat session is shown. Choose your own log in Settings when you're ready."
        elif source:
            text = "Your selected log is available. Open Players or Avatar activity to explore what VRC Eye has observed. A log alone does not confirm that VRChat is running."
        else:
            text = "VRC Eye is waiting for a VRChat log. Local favorites, notes and creator workspaces are still available. Choose a log source in Settings."
        if safe:
            text += " Safe mode is on; optional integrations stay restricted."
        if app.paused:
            text += " The avatar view is paused; collection may continue."
        from novelty import owned
        self.intro.set(owned(app,text))


class SettingsPage(Page):
    def __init__(self, shell, parent):
        # Keep the title/status in the same scroll surface as the controls. At
        # large text sizes a wrapped status must not consume the whole viewport.
        self.scroll = ScrollPane(shell.app, parent,min_width=600)
        super().__init__(shell, self.scroll.body, "Settings", task_controls=False)
        self.experience = self.app.experience
        self.status.set("Make VRC Eye comfortable to use. Connection permissions are managed separately.")
        body = self.scroll.body
        self.sections = {}
        appearance = card(self.app, body, "Appearance")
        self.sections["appearance"] = appearance
        for label, variable, values in (("Detail level", self.experience.mode, MODES),
                                       ("Spacing", self.experience.density, DENSITIES)):
            row = self.ttk.Frame(appearance, style="Card.TFrame")
            row.pack(fill="x", pady=4)
            self.ttk.Label(row, text=label, style="Card.TLabel", width=16).pack(side="left")
            picker = self.ttk.Combobox(row, textvariable=variable, values=values, state="readonly", width=22)
            picker.pack(side="left")
            picker.bind("<<ComboboxSelected>>", lambda _: self.save_appearance())
        from text_scaling import FontScaleControl
        self.font_control = FontScaleControl(self.app, appearance, self.experience.preferences.font_percent)
        self.ttk.Button(appearance, text='Apply text size', command=lambda:self.guard(
            lambda:self.experience.change(font_scale=self.font_control.get()))).pack(anchor='w', pady=5)
        self.ttk.Label(appearance, text="Casual keeps the essentials visible. Advanced and Developer reveal more tools; they do not grant extra access.",
                       style="CardMuted.TLabel", wraplength=850).pack(anchor="w", pady=(8, 4))
        row = self.ttk.Frame(appearance, style="Card.TFrame")
        row.pack(fill="x", pady=4)
        self.ttk.Label(row, text="Start page", style="Card.TLabel", width=16).pack(side="left")
        self.start_page = self.tk.StringVar(value="Home" if self.experience.preferences.start_page == "Home" else "Players & avatars")
        picker = self.ttk.Combobox(row, textvariable=self.start_page, values=("Home", "Players & avatars"), state="readonly", width=22)
        picker.pack(side="left")
        picker.bind("<<ComboboxSelected>>", lambda _: self.save_appearance())
        self.ttk.Button(appearance, text="Reset appearance only", command=self.reset_appearance).pack(anchor="w", pady=(10, 0))

        self.ttk.Button(appearance, text="Accessibility settings…", command=lambda:self.shell.show("Accessibility")).pack(anchor="w", pady=(8,0))
        self.ttk.Button(appearance, text="Colors, themes & Home layout…", command=lambda:self.shell.show("Customization")).pack(anchor="w", pady=(8,0))
        self.ttk.Button(appearance, text="Setup health and dependencies…", command=lambda:__import__('desktop_health_ui').show(self.shell)).pack(anchor='w',pady=(8,0))

        logs = card(self.app, body, "Log source")
        self.sections["logs"] = logs
        self.ttk.Label(logs, text="Choose the VRChat log folder or a specific output log. Changing the text below does not start monitoring until you select Watch logs.",
                       style="CardMuted.TLabel", wraplength=850).pack(anchor="w", pady=(0, 8))
        self.log_entry = self.ttk.Entry(logs, textvariable=self.app.folder)
        self.log_entry.pack(fill="x", pady=(0, 8))
        row = self.ttk.Frame(logs, style="Card.TFrame")
        row.pack(fill="x")
        self.ttk.Button(row, text="Choose folder…", command=lambda: self.pick_log(False)).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Choose file…", command=lambda: self.pick_log(True)).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Watch logs", style="Accent.TButton", command=self.app.start_monitor).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Try sample data", command=self.app.load_demo).pack(side="left")
        self.ttk.Label(logs, textvariable=self.app.state, style="CardMuted.TLabel", wraplength=850).pack(anchor="w", pady=(8, 0))

        connections = card(self.app, body, "Account & integrations")
        self.sections["connections"] = connections
        self.ttk.Label(connections, text="Local logs, notes and creator tools do not require a VRChat account. Open a connection's settings to review its options; these shortcuts do not connect anything.",
                       style="CardMuted.TLabel", wraplength=850).pack(anchor="w", pady=(0, 10))
        row = self.ttk.Frame(connections, style="Card.TFrame")
        row.pack(fill="x")
        from online_dialog import show_connection_dialog
        self.ttk.Button(row, text="VRChat account…", command=lambda: show_connection_dialog(self.app)).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Networking", command=lambda: self.shell.show("Networking")).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="VRCX Companion", command=lambda: self.shell.show("VRCX Companion")).pack(side="left")
        self.ttk.Label(connections, text="Network addresses and ports remain under VRC Eye → Networking, including OSC transport settings.",
                       style="CardMuted.TLabel", wraplength=850).pack(anchor="w", pady=(10, 0))
        self.details = Disclosure(self.app, body, "technical details")
        from bridge_dialog import show_bridge
        row = self.ttk.Frame(self.details.body)
        row.pack(fill="x", pady=4)
        self.ttk.Button(row, text="Client bridge…", command=lambda: show_bridge(self.app)).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Log diagnostics…", command=self.app.diagnostics).pack(side="left", padx=(0, 8))
        self.ttk.Button(row, text="Crash diagnostics", command=lambda: self.shell.show("Crash & Diagnostics")).pack(side="left")
        self.ttk.Label(self.details.body, textvariable=self.shell.bridge_status, style="Muted.TLabel").pack(anchor="w", pady=4)
        self.ttk.Label(self.details.body, textvariable=self.app.activity, style="Muted.TLabel", wraplength=850).pack(anchor="w", pady=4)
        self.ttk.Label(body, text="Start.cmd still prepares dependencies automatically. Appearance changes do not reset favorites, creator workspaces, connection profiles or permissions.",
                       style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=(12, 0))
        from spatial_ui import attach_settings
        attach_settings(self)
        from tracking_ui import attach_settings as attach_tracking
        attach_tracking(self)

    def pick_log(self, file):
        from tkinter import filedialog
        selected = (filedialog.askopenfilename(title="Choose a VRChat log", parent=self.app.root,
                    filetypes=[("VRChat logs", "output_log_*.txt"), ("Text logs", "*.txt")]) if file else
                    filedialog.askdirectory(title="Choose the VRChat log folder", parent=self.app.root, mustexist=True))
        if selected:
            self.app.folder.set(selected)
            self.status.set("Log source selected. Choose Watch logs to start monitoring it.")

    def save_appearance(self):
        start = "Home" if self.start_page.get() == "Home" else "Primary"
        self.experience.change(mode=self.experience.mode.get(), density=self.experience.density.get(),
                               start_page=start)
        self.status.set(self.experience.notice.get())

    def reset_appearance(self):
        self.experience.change(**{k: v for k, v in Presentation().to_dict().items() if k != "schema"})
        self.start_page.set("Home")
        self.status.set(self.experience.notice.get())

    def focus_section(self, name):
        if name not in self.sections:
            return
        self.app.root.update_idletasks()
        target = self.sections[name]
        total = max(1, self.scroll.body.winfo_height())
        self.scroll.canvas.yview_moveto(max(0, target.winfo_y()) / total)
        if name == "logs":
            self.log_entry.focus_set()
        elif name == "overlay":
            self.spatial_panel.buttons['Start compass'].focus_set()
        elif name == "tracking":
            self.tracking_panel.buttons['Read profile JSON…'].focus_set()


class ToolPalette:
    """Search navigation only: no network lookup, arbitrary evaluation or actions."""
    def __init__(self, experience):
        self.experience, self.app = experience, experience.app
        app = self.app
        self.window = app.tk.Toplevel(app.root)
        self.window.title("Find a tool · VRC Eye")
        self.window.geometry("840x570")
        self.window.minsize(640, 420)
        self.window.transient(app.root)
        self.window.configure(background=app.BG)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        body = app.ttk.Frame(window_body(self.window), padding=20)
        body.pack(fill="both", expand=True)
        app.ttk.Label(body, text="Find a tool", style="Title.TLabel").pack(anchor="w")
        app.ttk.Label(body, text="Search every workspace, including tools hidden in your current view.", style="Muted.TLabel").pack(anchor="w", pady=(4, 12))
        self.query = app.tk.StringVar()
        self.input = app.ttk.Entry(body, textvariable=self.query)
        self.input.pack(fill="x", pady=(0, 10))
        table_frame = app.ttk.Frame(body)
        table_frame.pack(fill="both", expand=True)
        self.table = app.ttk.Treeview(table_frame, columns=("tool", "workspace", "level"), show="headings", selectmode="browse", height=8)
        for key, title, width in (("tool", "Tool", 280), ("workspace", "Workspace", 340), ("level", "Detail level", 100)):
            self.table.heading(key, text=title)
            self.table.column(key, width=width, minwidth=80, stretch=key != "level")
        y = app.ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        x = app.ttk.Scrollbar(table_frame, orient="horizontal", command=self.table.xview)
        self.table.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        x.pack(side="bottom", fill="x")
        y.pack(side="right", fill="y")
        self.table.pack(fill="both", expand=True)
        self.description = app.tk.StringVar()
        from ui_theme import responsive_wrap
        responsive_wrap(app.ttk.Label(body, textvariable=self.description, wraplength=770, style="Muted.TLabel"), maximum=770).pack(anchor="w", pady=(10, 8))
        row = app.ttk.Frame(body)
        row.pack(fill="x")
        self.count = app.tk.StringVar()
        app.ttk.Label(row, textvariable=self.count, style="Muted.TLabel").pack(side="left")
        app.ttk.Button(row, text="Close", command=self.close).pack(side="right")
        self.open_button = app.ttk.Button(row, text="Open tool", style="Accent.TButton", command=self.open_selected)
        self.open_button.pack(side="right", padx=8)
        self.results = {}
        self.trace = self.query.trace_add("write", lambda *_: self.refresh())
        self.table.bind("<<TreeviewSelect>>", lambda _: self.selection())
        self.table.bind("<Double-1>", lambda _: self.open_selected())
        self.table.bind('<Return>', lambda _: (self.open_selected(), 'break')[-1])
        self.window.bind("<Escape>", lambda _: self.close())
        self.window.bind("<Return>", lambda _: self.open_selected())
        self.input.bind("<Down>", self.focus_results)
        self.input.bind('<Return>', lambda _: (self.open_selected(), 'break')[-1])
        self.refresh()
        self.input.focus_set()

    def focus_results(self, _event=None):
        self.table.focus_set()
        if self.results:
            key = next(iter(self.results))
            self.table.selection_set(key)
            self.table.focus(key)
        return "break"

    def refresh(self):
        old = next(iter(self.table.selection()), None)
        children = self.table.get_children()
        if children:
            self.table.delete(*children)
        self.results = {tool.key: tool for tool in search_tools(self.query.get())}
        for key, tool in self.results.items():
            self.table.insert("", "end", iid=key, values=(tool.title, tool.location, tool.level))
        if self.results:
            key = old if old in self.results else next(iter(self.results))
            self.table.selection_set(key)
            self.table.focus(key)
            self.open_button.configure(state="normal")
        else:
            self.open_button.configure(state="disabled")
        self.count.set(f"{len(self.results)} tools · Enter to open · Esc to close")
        self.selection()

    def selection(self):
        tool = next((self.results[key] for key in self.table.selection() if key in self.results), None)
        self.description.set(tool.description if tool else "No matching tools. Try a shorter name, such as voice, creator, or log.")

    def open_selected(self):
        key = next((key for key in self.table.selection() if key in self.results), None)
        if key:
            self.close()
            self.experience.open_tool(key)
            keyboard=getattr(self.experience,'keyboard',None)
            if keyboard:keyboard.idle(keyboard.focus_content)

    def close(self):
        if self.experience.palette is not self:
            return
        self.query.trace_remove("write", self.trace)
        self.experience.palette = None
        self.window.destroy()
        self.app.root.focus_set()


class FriendlyExperience:
    """Coordinates the shared shell while leaving feature services untouched."""
    def __init__(self, app):
        self.app, self.shell = app, app.sidebar
        app.experience = self
        self.preferences = self.shell.presentation
        self.mode = app.tk.StringVar(value=self.preferences.mode)
        self.density = app.tk.StringVar(value=self.preferences.density)
        self.text_size = app.tk.StringVar(value=self.preferences.text_size)
        self.notice = app.tk.StringVar(value="")
        self.session_badge = app.tk.StringVar(value="Local companion")
        self.palette, self.closed = None, False
        self.navigators = {}
        self.decorated = set()
        self.last_header = None
        self.avatar_columns = app.tk.BooleanVar(value=False)
        self._build_header()
        self._register_primary()
        from screen_reader import Reader
        self.reader = Reader(app)
        from ui_shortcuts import ShortcutManager
        self.shortcuts = ShortcutManager(self)
        from keyboard_ui import KeyboardManager
        self.keyboard = KeyboardManager(self)
        from alternate_input import AlternateInput
        self.alternate = AlternateInput(self)
        from layout_edit import LayoutEditor
        self.layout_editor = LayoutEditor(self)
        from live_captions import LiveCaptions
        self.captions = LiveCaptions(self)
        self.zoom = app.text_zoom
        self.apply(initial=True)
        self.shell.show(self.preferences.start_page)
        self.bindings = []
        for sequence, callback in (("<MouseWheel>", self._wheel), ("<Button-4>", self._wheel), ("<Button-5>", self._wheel)):
            self.bindings.append((sequence, app.root.bind(sequence, callback, add="+")))
        from screen_reader_model import annotate
        self.reader_button=annotate(app.ttk.Button(app.header_actions,text='Screen reader',command=self.reader.open_settings),public=True,
                                   description='Open Accessibility, then Screen reader. Keyboard settings lists the current speech and Reading view shortcuts.')
        self.reader_button.pack(side='left',padx=6)
        self.input_button=annotate(app.ttk.Button(app.header_actions,text='Alternate input',command=self.open_input),public=True,
                                   description='Open switch scanning and dwell controls. Escape stops alternate input.')
        self.input_button.pack(side='left',padx=6)
        self.tick()

    def open_input(self):
        if self.alternate.running:self.alternate.stop();return
        self.shell.show('Accessibility')
        page=self.shell.pages['Accessibility'];page.tabs.select(page.frames['Alternate input'])

    def _build_header(self):
        app, ttk = self.app, self.app.ttk
        actions = app.header_actions
        self.find_tool_button = ttk.Button(actions, text="Find a tool…  Ctrl+K", command=self.open_palette)
        self.find_tool_button.pack(side="left", padx=(0, 12))
        from screen_reader_model import annotate
        annotate(self.find_tool_button,public=True)
        ttk.Label(actions, text="View", style="Muted.TLabel").pack(side="left", padx=(0, 6))
        self.mode_picker = ttk.Combobox(actions, textvariable=self.mode, values=MODES, state="readonly", width=11)
        self.mode_picker.pack(side="left", padx=(0, 10))
        self.mode_picker.bind("<<ComboboxSelected>>", lambda _: self.change(mode=self.mode.get()))
        ttk.Button(actions, text="Settings", style="Quiet.TButton", command=lambda: self.shell.show("Settings")).pack(side="left")
        ttk.Label(app.header, textvariable=self.session_badge, style="Accent.TLabel").pack(side="left", padx=12)

    def _register_primary(self):
        app = self.app
        world = app.world_view
        avatar_creator = getattr(app.avatar_creator, "panel", None)
        world_creator = getattr(world.creator, "panel", None)
        avatars = {"Activity": app.avatar_activity}
        worlds = {"Players": world.players_page, "Map": world.map_page}
        if avatar_creator:
            avatars.update(avatar_creator.pages)
        if world_creator:
            worlds.update(world_creator.pages)
        self.navigators["avatars"] = NotebookNavigator(app, app.avatar_sections, avatars,
            levels={name: "Advanced" for name in avatars if name not in ("Activity", "Library")},
            mode=self.preferences.mode, show=lambda name: avatar_creator.show(name) if avatar_creator and name in avatar_creator.pages else None)
        self.navigators["world"] = NotebookNavigator(app, world.sections, worlds,
            levels={name: "Advanced" for name in worlds if name not in ("Players", "Map")},
            mode=self.preferences.mode, show=lambda name: world_creator.show(name) if world_creator and name in world_creator.pages else None)
        app.ttk.Checkbutton(app.avatar_filter_row, text="Show all columns", variable=self.avatar_columns,
                           command=self.update_avatar_columns).pack(side="left", padx=(12, 0))

    def decorate_page(self, name, page):
        if name in self.decorated or name in ("Home", "Settings"):
            return
        self.decorated.add(name)
        if name == "Wellness":
            page.view_mode.set("Casual" if self.preferences.mode == "Casual" else "Advanced")
            page.change_view(save=False)
            return
        maps = {"Performance & Security": ("tab_frames", {"Rules & settings": "Advanced", "Diagnostics": "Advanced"}),
                "Crash & Diagnostics": ("frames", {"Replay": "Advanced", "Error Center": "Advanced", "Developer": "Developer"}),
                "Unity Player": ("frames", {"Installation": "Advanced", "Runtime & graphics": "Advanced", "Logs": "Advanced", "Compatibility": "Advanced", "Developer": "Developer"}),
                "Media & Audio": ("frames", {"Mixer": "Advanced", "DJ": "Advanced", "Settings & Diagnostics": "Advanced"}),
                "VRCX Companion": ("frames", {"Ownership": "Advanced", "Diagnostics": "Advanced", "Developer": "Developer"}),
                "VRC Eye Primary": ("frames", {"Creator": "Advanced", "Diagnostics & presets": "Advanced", "Developer": "Developer"}),
                "Networking": ("frames", {"Profiles & adapters": "Advanced", "OSC transport": "Advanced", "Developer API": "Developer", "Client Bridge": "Developer"}),
                "Developer": ("frames", {}), "Creator Projects": ("frames", {}), "Customization": ("frames", {}), "VR Center": ("frames", {}),
                "Accessibility": ("frames", {}), "SDK Downloads": ("frames", {}), "Unity Downloads": ("frames", {}), "VCC Downloads": ("frames", {}), "World Visits": ("frames", {}), "Photos": ("frames", {}), "Social": ("frames", {}), "Accounts": ("frames", {})}
        if name in maps:
            field, levels = maps[name]
            # Photos.view is Cards/List, not Casual/Advanced/Developer. Only
            # controllers that expose a detail-level selector share this value.
            view = getattr(page, "view", None) if name in ('Performance & Security', 'Crash & Diagnostics', 'Unity Player', 'VRC Eye Primary', 'VRCX Companion') else None
            if view is not None:
                view.set(self.preferences.mode)
            self.navigators[name] = NotebookNavigator(self.app, page.tabs, getattr(page, field),
                                                     levels=levels, mode=self.preferences.mode, view=view)
        if name == "VRC Eye Primary":
            osc = page.osc_controls
            osc.view.set(self.preferences.mode)
            self.navigators["osc"] = NotebookNavigator(self.app, osc.notebook, osc.pages,
                levels={name: "Advanced" for name in ("Tracking", "Presets & Rules", "Routes & Permissions", "Inspector")},
                mode=self.preferences.mode, view=osc.view, show=osc.show)

    def change(self, **values):
        try:
            previous = self.preferences
            self.preferences = self.preferences.changed(**values)
            self.apply(mode_changed=previous.mode != self.preferences.mode)
            if self.app.demo or getattr(self.app, "safe_mode", False):
                self.notice.set("Appearance updated for this session. Demo and Safe mode do not save display preferences.")
            else:
                self.shell.store.set_option(PREFERENCE_KEY, self.preferences.to_dict())
                self.notice.set("Appearance saved. Existing connections, permissions and workspaces were not changed.")
        except (ValueError, OSError, sqlite3.Error) as error:
            self.notice.set("Appearance is usable for this session, but could not be saved: " + str(error))
        self.shell.ui_notice.set(self.notice.get())

    def apply(self, *, initial=False, mode_changed=True):
        prefs = self.preferences
        self.shell.presentation = prefs
        self.app.presentation = prefs
        self.mode.set(prefs.mode)
        self.density.set(prefs.density)
        self.text_size.set(prefs.text_size)
        self.app.make_styles()
        if hasattr(self,'layout_editor'):self.layout_editor.paint_icon()
        if hasattr(self, 'zoom'):self.zoom.apply()
        self.shell.refresh_navigation()
        if initial or mode_changed:
            self.shell.set_navigation_mode(prefs.mode)
            self.avatar_columns.set(prefs.mode != "Casual")
            self.update_avatar_columns()
            for name, navigator in self.navigators.items():
                if navigator.view is not None:
                    navigator.view.set(prefs.mode)
                navigator.apply_mode(prefs.mode)
            wellness = self.shell.pages.get("Wellness")
            if wellness:
                wellness.view_mode.set("Casual" if prefs.mode == "Casual" else "Advanced")
                wellness.change_view(save=False)
            panel = getattr(self.app.world_view, "player_panel", None)
            if panel:
                panel.presentation_mode = prefs.mode
            if prefs.mode == "Casual":
                self.app.avatar_more.set_open(False)
        accessibility = self.shell.pages.get("Accessibility")
        if accessibility:
            accessibility.sync()
        settings = self.shell.pages.get('Settings')
        if settings and hasattr(settings, 'font_control'):settings.font_control.set(prefs.font_percent)
        customization = self.shell.pages.get('Customization')
        if customization and hasattr(customization, 'font_control'):customization.font_control.set(prefs.font_percent)
        self.tick()

    def update_avatar_columns(self):
        columns = "#all" if self.avatar_columns.get() else ("time", "player", "before", "after", "kind")
        self.app.table.configure(displaycolumns=columns)

    def page_changed(self, name):
        if name in ADVANCED_PAGES:
            self.shell.reveal_advanced()
        self.tick()
        if hasattr(self, 'keyboard'): self.keyboard.page_changed()

    def open_tool(self, key):
        tool = TOOL_BY_KEY.get(key)
        if not tool or self.closed:
            return False
        route = tool.route
        self.shell.show(route[0])
        if self.shell.current != route[0]:
            return False
        if route[0] == "Primary":
            if route[1] == "World":
                self.app.pages.select(self.app.world_page)
                return self.navigators["world"].open(route[2])
            self.app.pages.select(self.app.avatar_page)
            opened = self.navigators["avatars"].open(route[2])
            if opened and route[2] == "Library" and len(route) > 3:
                page = getattr(self.app.avatar_creator.panel, "library_page", None)
                if page is None: return False
                page.show_section(route[3])
            return opened
        if route[0] == "Settings" and len(route) > 1:
            self.shell.pages["Settings"].focus_section(route[1])
        elif len(route) > 1:
            navigator = self.navigators.get(route[0])
            if not navigator or not navigator.open(route[1]):
                return False
            if len(route) > 2:
                if route[0] == "Developer":return self.shell.pages["Developer"].bridge_lab_panel.show(route[2])
                return self.navigators["osc"].open(route[2])
        return True

    def open_palette(self):
        if self.closed:
            return
        if self.palette:
            self.palette.window.lift()
            self.palette.input.focus_set()
            return
        self.palette = ToolPalette(self)

    def _open_palette_event(self, _event=None):
        self.open_palette()
        return "break"

    def _open_settings_event(self, _event=None):
        self.shell.show("Settings")
        return "break"

    def _wheel(self, event):
        widget = event.widget
        # Keep list, text and table scrolling with their native bindings.
        if widget.winfo_class() in ("Text", "Listbox", "Treeview", "TCombobox", "TScrollbar"):
            return
        while widget is not None:
            canvas = getattr(widget, "_eye_scroll_canvas", None)
            if canvas is not None:
                delta = getattr(event, "delta", 0)
                steps = (-max(1, abs(int(delta)) // 120) if delta > 0 else max(1, abs(int(delta)) // 120)) if delta else (-1 if getattr(event, "num", 0) == 4 else 1)
                axis = 'x' if int(getattr(event, 'state', 0)) & 1 else 'y'
                getattr(canvas, axis + 'view_scroll')(steps, "units")
                return "break"
            widget = getattr(widget, "master", None)

    def tick(self):
        if self.closed:
            return
        app = self.app
        if hasattr(self,'layout_editor'):self.layout_editor.tick()
        if getattr(app,'backdrop',None):app.backdrop.tick()
        state = "Sample data" if app.demo else "Safe mode" if getattr(app, "safe_mode", False) else "View paused" if app.paused else "Local log selected" if app.source else "Waiting for log"
        signed = bool(app.api and app.api.authenticated)
        snapshot = state, signed
        if snapshot != self.last_header:
            self.last_header = snapshot
            self.session_badge.set(state)
            self.shell.account_label.set("VRChat: signed in" if signed else "VRChat: not signed in")

    def close(self):
        if self.closed:
            return
        if hasattr(self, 'captions'):self.captions.close()
        if hasattr(self, 'alternate'):self.alternate.close()
        if hasattr(self, 'layout_editor'):self.layout_editor.close()
        if hasattr(self,'reader'):self.reader.close()
        if hasattr(self,'keyboard'):self.keyboard.close()
        if hasattr(self,'zoom'):self.zoom.close()
        if self.palette:
            self.palette.close()
        if getattr(self.app,'backdrop',None):self.app.backdrop.close()
        self.closed = True
        if hasattr(self, "shortcuts"): self.shortcuts.close()
        for navigator in self.navigators.values():
            navigator.close()
        for sequence, identifier in self.bindings:
            if identifier:
                self.app.root.unbind(sequence, identifier)
