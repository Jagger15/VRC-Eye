# VRC Eye 1.21.0 — Development 10 validation

The final portable regression passed **4,599 tests and 1,059 subtests**,
with zero failures/errors and zero blocked external-socket attempts in 113.46s.
There are **473 skipped native-GUI cases**, **1 deselected Unix bridge case**,
and the same **13 excluded local-transport modules** as Development 9. Skips and
exclusions are not passes. The inherited environment limitation is the unavailable
native display/local-listening support. The two warnings remain the pre-existing
TestListener constructor and deliberately duplicated ZIP-member cases.

The 35 new focused cases cover grouping and hidden locations, nonce removal,
account-scoped watch settings, fresh/stale transitions, collections, quiet hours,
cooldowns and notification ownership, reconnect endpoint comparisons, pre-gap
response exclusion, shared worker ownership, real headless Feed callbacks,
instance handoff without remote writes, image fallback/decoding, legacy cache
compatibility, picture retries and privacy/offline cancellation.

A temporary VRCX SQLite cache reproduced picture URLs being discarded by search
before the fix. Regression tests now assert those URLs reach the tile loader
without inventing a downloadable/avatar API lookup. Tests also exercise ordinary
API avatar search, full-image fallback and queued image publication. Headless
widget checks do not establish native Tk rendering or live image availability.

All **536 Python files** parse with Python 3.10 grammar. Execution used
Python 3.12.14. The source manifest covers **585 files**.
Seven launchers and requirements.txt are byte-identical to Development 9. Shell
syntax and CLI version checks passed. Packaging checks CRC, all baseline paths,
manifest hashes and exact archive/source bytes. No second full clean-extraction
test run is claimed. Runtime code was unchanged after the final regression.

Native Windows/Linux GUI, credential vaults, tray/speech, Discord and SteamVR,
real VRChat authentication/events and actual status writes remain unverified.
This is runnable source, not a compiled executable or signed installer. The
updater is preparation-only and still needs an Eye release feed and packages.

See [Development 10 guide](FRIEND_ACTIVITY_DEV10.md),
[previous validation](VALIDATION_1_21_DEV9.md), and BUILD_VALIDATION.json for
the exact command and exclusions. Full VRCX parity remains incomplete.
