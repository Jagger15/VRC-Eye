# Resume VRC Eye from Development 19

Use **VRC-Eye-v1.21.0-Development-19.zip** as the current unified source baseline.
It uses the completed concurrent Development 18 archive (SHA-256
3c8dd442c3aaab77c0f477c2e2b9025aa070314e8e1664fb176566a53679cb5b), retains its
static GLB viewer and shared direct-settings history, and adds combined Home
conditions, power preference rules and temporary fallback pause in existing owners.
The interim Home-only Development 18 produced during this chat was superseded
before delivery; do not branch future work from it.

Final portable regression: 5,060 passed, 1,059 subtests passed, 475 native-GUI
skips, one deselection, 13 retained module exclusions, two warnings, zero blocked
external sockets. See DEVELOPMENT_19_VALIDATION.md and BUILD_VALIDATION.json.

See ARC_VRCX_REMAINING_DEV19.md and ARC_VRCX_GAP_LEDGER_DEV19.json for current
remaining work. The static viewer still lacks materials/textures, rig/blendshape,
animation and direct FBX/VRCA/Unity-bundle decoding. Native/live acceptance is open.
Run Start.cmd on Windows or bash Start.sh on Linux after extracting separately.
