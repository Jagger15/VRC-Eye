# VRC Eye — archive review and backlog additions

Reviewed 5 October 2026. **14 concrete work packages: 3 newly scoped packages and 11 refinements of existing backlog items.** All are proposals; no application feature was implemented by this review. No new numbered build was created. The Development 30 release hold remains active.

“Newly scoped” means no dedicated equivalent was found in the reviewed candidate lists; it does not mean the underlying idea is novel. The ARC/VRCX historical ledger remains unchanged. Current pending changes still live in `PENDING_CHANGESET.json`.

The most useful additions are the VCC project/package workflows and per-component creator reports. Plugin design is one part of the findings, alongside preview tools, panels, notifications, world reports and presentation.

## Prioritized additions

| ID | Work package | Order | Existing backlog |
|---|---|---|---|
| AR261005-01 | VPM repository catalog and package provenance | Next creator batch | C09 |
| AR261005-02 | Explain package dependency and version changes | Next creator batch | C09, ARC-16, ARC-19 |
| AR261005-03 | Unity editor compatibility and handoff matrix | Next creator batch | C09, ARC-09 |
| AR261005-04 | Project backup browser, restore copies and migration preflight | Next creator batch | ARC-19, ARC-24, C23 |
| AR261005-05 | Template catalog and local package preflight | After project provenance | C09 |
| AR261005-06 | Per-component avatar budget breakdown | Next creator batch | NM1919-08, ARC-13, ARC-18 |
| AR261005-07 | Preview turntable, view bookmarks and deformation comparison | Small viewer follow-on | NM1919-09, ARC-05 |
| AR261005-08 | Extension dependency checks, typed settings and lifecycle health | Separate extension milestone | NM1919-07, NM1919-06 |
| AR261005-09 | Compact detachable roster and diagnostic panels | After shared presentation model | C15, VX-DESK-01, VX-DESK-02 |
| AR261005-10 | Contextual notification profiles and presentation preview | Small notification follow-on | VX-DESK-03, C15 |
| AR261005-11 | Local text readability and flood diagnostics | Small diagnostic follow-on | C23, VX-DESK-03 |
| AR261005-12 | Creator-owned Udon behavior and event report browser | After avatar creator reports | NM1919-13, C23 |
| AR261005-13 | Reviewable appearance packs and panel-level accessibility | Later polish | C24, NM1919-07 |
| AR261005-14 | Pinned controls for selected media applications | Later control-deck refinement | C13, C21 |

## Concrete scope and acceptance

### AR261005-01 — VPM repository catalog and package provenance

**Already in Eye:** Eye inventories project packages and imports the VCC project-path list. It deliberately does not import repository credentials or headers.

**Add:** Preview a selected repository name, URL, package IDs and versions; show each package origin, last successful inspection and enabled state. Detect duplicate package IDs across repositories. Add explicit source selection to project-copy jobs only after provider support is verified.

**Prerequisites:** Portable catalog/model; changes to VCC/VPM configuration need a supported, version-checked adapter. Do not directly edit VCC caches.

Acceptance:

- A repository listing is untrusted data and never executes scripts during preview.
- Private repository credentials remain local secrets and are excluded from portable exports.
- Ambiguous origins, stale data and prereleases remain visible; changing a source never silently changes an installed project.

Existing owners: `creator_projects.py`, `creator_projects_ui.py`, `creator_project_jobs.py`.
Evidence: E02. Newly scoped work package; extends C09.

### AR261005-02 — Explain package dependency and version changes

**Already in Eye:** Requested/locked/embedded inventories and reviewed Restore, Set exact version and Remove operations already exist on copies. There is no verified complete resolver preview.

**Add:** Show why a package is present, requested versus resolved versions, missing requirements, origin conflicts and the expected transitive changes. Highlight prerelease, downgrade, major-version and legacy-folder effects. Compare the actual post-operation manifest with the preview.

**Prerequisites:** Portable static analysis first; a genuine dry run requires a verified VPM/provider capability, not invented CLI flags.

Acceptance:

- Label declared dependency analysis separately from an authoritative resolver result.
- Unknown or conflicting ranges stay unresolved rather than being guessed.
- Review is tied to exact project/tool/package inputs; unexpected changes remain in the existing receipt and rollback workflow.

Existing owners: `creator_projects.py`, `creator_project_jobs.py`, `recovery_journal.py`, `recovery_helper.py`.
Evidence: E03, E20. Refinement; extends C09, ARC-16, ARC-19.

### AR261005-03 — Unity editor compatibility and handoff matrix

**Already in Eye:** Eye records project versions and supports a manually selected exact editor handoff.

**Add:** Provide one view of selected installed editor candidates, the project version, package-declared minimums, and supported/recommended evidence with dates. Explain missing editor/platform modules and offer a precise reviewed handoff.

**Prerequisites:** Read-only version discovery plus native Windows/Linux acceptance; current supported-editor data needs an explicit authoritative source.

Acceptance:

- A matching executable name alone does not establish editor version or required platform modules.
- Archive-era versions are examples, never a hard-coded current recommendation.
- An upgrade remains a separate reviewed copy/migration operation; absent evidence is unknown.

Existing owners: `creator_projects.py`, `creator_projects_ui.py`, `creator_project_jobs.py`.
Evidence: E04, E01. Newly scoped work package; extends C09, ARC-09.

### AR261005-04 — Project backup browser, restore copies and migration preflight

**Already in Eye:** Eye already has project copies, durable jobs and repair checkpoints; arbitrary VCC ZIP backup intake and a full migration preflight are not established.

**Add:** Inspect a selected backup for project/editor/package identity; compare it with a working copy and restore into a fresh destination. Before migration, show copy exclusions, scenes or references in excluded folders, path-length issues and disk-space estimates.

**Prerequisites:** Portable bounded archive inspection; installed Unity/VPM operations and filesystem recovery need native qualification.

Acceptance:

- Archive paths, links, member counts, sizes and destination conflicts are checked before extraction.
- Do not overwrite the current project or silently delete older backups.
- Capture exact backup identity and per-file outcomes; a post-failure project is not described as successfully migrated.

Existing owners: `creator_project_jobs.py`, `recovery_journal.py`, `recovery_journal_ui.py`, `creator_projects_ui.py`.
Evidence: E05. Refinement; extends ARC-19, ARC-24, C23.

### AR261005-05 — Template catalog and local package preflight

**Already in Eye:** The existing new-project path supports a fixed set of reviewed VPM template names.

**Add:** Inspect selected official, user and local templates: identity, template/package version, declared Unity version, dependency list, intended Avatar/World use and provenance. Validate a local package manifest before offering it to a verified provider.

**Prerequisites:** Portable manifest inspector first; template creation requires an installed supported CLI/editor.

Acceptance:

- Preview does not import Unity assets or run editor scripts.
- Template and package versions are distinct; missing declarations remain unknown.
- Creation uses a new destination and the existing job journal; arbitrary template invocation requires verified provider support.

Existing owners: `creator_projects.py`, `creator_project_jobs.py`, `creator_projects_ui.py`.
Evidence: E06, E02. Newly scoped work package; extends C09.

### AR261005-06 — Per-component avatar budget breakdown

**Already in Eye:** The pending exporter/importer already supports 31 aggregate counters/flags; native Unity acceptance is still open.

**Add:** Attribute supported costs to renderers, meshes, textures, materials, particle systems and dynamics components. Sort large contributors and compare matching source reports; jump to the component in a creator-owned Unity project.

**Prerequisites:** Requires an extended creator-selected Unity exporter and native SDK validation; standalone Eye displays supplied evidence.

Acceptance:

- Keep platform, SDK, Unity and measurement-stage context attached to every comparison.
- Separate shared resources, per-component counts and estimates; do not double-count shared assets as measured totals.
- Do not copy historical client thresholds, invent official performance ranks or claim crash prevention from static counts.

Existing owners: `Unity/AvatarToolkit/Editor/EyePerformanceReport.cs`, `avatar_performance_report.py`, `inspection_reports_ui.py`, `avatar_mesh_health.py`.
Evidence: E10. Refinement; extends NM1919-08, ARC-13, ARC-18.

### AR261005-07 — Preview turntable, view bookmarks and deformation comparison

**Already in Eye:** Orbit, pan, zoom, framing, scene hierarchy, imported-pose skinning, skeleton and reversible morph controls already exist.

**Add:** Add optional auto-turntable speed/direction, front/side/back presets, bounded view bookmarks and a same-camera comparison between imported defaults and a transient morph preview.

**Prerequisites:** Existing portable renderer; native rendering and responsiveness remain acceptance gates.

Acceptance:

- Manual orbit is existing functionality, not counted as new.
- Pause motion while hidden, private, unfocused as appropriate, or under reduced motion; cancel stale renders.
- Bind bookmarks to the selected source identity and clear stale overrides. No animation, IK or physics capability is implied.

Existing owners: `avatar_model_preview_ui.py`, `avatar_scene_ui.py`, `avatar_scene_rig_ui.py`.
Evidence: E07. Refinement; extends NM1919-09, ARC-05.

### AR261005-08 — Extension dependency checks, typed settings and lifecycle health

**Already in Eye:** Eye has particular provider workers and a bridge contract. General plugin installation and hosting remain planned.

**Add:** Refine the Eye-owned extension manifest with required/optional dependency ranges, incompatibilities and host/platform requirements. Generate accessible settings from typed schemas, stage changes with reset/undo, and display states such as disabled, blocked, starting, ready, stopping and failed with reasons. Add bounded error history, startup/shutdown deadlines and explicit recovery after repeated failure.

**Prerequisites:** Start with data-only packs and schema previews, then versioned supported workers with Windows/Linux qualification.

Acceptance:

- No MelonLoader/BepInEx DLL compatibility is promised; new extensions target the Eye SDK.
- Dependency cycles, absent optional capabilities, schema migrations and contradictory requirements produce understandable results.
- Action ownership, account/privacy changes and shutdown cancel extension work; caught exceptions alone do not establish isolation.
- Executable workers need their own trust/resource contract; an out-of-process host is not an OS sandbox.

Existing owners: `bridge_protocol.py`, `bridge_sdk.py`, `avatar_scene_provider.py`, `avatar_recovery_provider.py`, `developer_ui.py`, `settings_bundle.py`.
Evidence: E19, E20, E15, E23. Refinement; extends NM1919-07, NM1919-06.

### AR261005-09 — Compact detachable roster and diagnostic panels

**Already in Eye:** Home cards, roster views and overlay infrastructure already exist. A shared compact external panel workflow is still broader work.

**Add:** Expose selected roster, session, media and diagnostic cards in a small draggable/resizable desktop window, with density/opacity controls, remembered placement and clear interactive versus display-only behavior.

**Prerequisites:** Native OS window support is separate from SteamVR overlays. Uploaded Unity GUI code is design evidence only; click-through support must be capability-driven.

Acceptance:

- Reuse existing snapshots and selected accounts; do not create another event collector or history database.
- Recover windows from disconnected monitors and changed DPI; provide a keyboard way to restore interaction.
- Privacy clears names/private fields immediately and freshness is visible. World positions or private client states are not inferred.

Existing owners: `player_roster_ui.py`, `desktop_service.py`, `dashboard_rows.py`, `creator_integrations.py`, `spatial_overlay.py`.
Evidence: E14, E22, E11. Refinement; extends C15, VX-DESK-01, VX-DESK-02.

### AR261005-10 — Contextual notification profiles and presentation preview

**Already in Eye:** Eye already has DND/quiet hours, category muting, priority types, batches, sender/type cooldowns, VR delivery and a session-selected sound clip.

**Add:** Add a reviewable rule matrix for supported join/leave and social event contexts, per-rule name visibility and presentation/sound choices, and a preview with an explanation of which rule matched. Include an explicit unknown-context outcome.

**Prerequisites:** Portable policy; audio, speech and overlay choices are limited to available native providers.

Acceptance:

- Use only context supplied by existing event owners; private location and relationship states are never guessed.
- All destinations obey the same existing quiet/privacy/cooldown rules and do not duplicate delivery.
- Pendulum instance-filter settings are a stub in this archive; Eye needs an independently implemented and tested rule evaluator.

Existing owners: `desktop_notifications.py`, `desktop_service.py`, `desktop_ui.py`, `mod_tools.py`, `settings_bundle.py`.
Evidence: E08, E18, E12. Refinement; extends VX-DESK-03, C15.

### AR261005-11 — Local text readability and flood diagnostics

**Already in Eye:** Retained logs and bounded notification queues/cooldowns already exist; this proposal is a display/refinement layer.

**Add:** Fold repetitive retained lines, visibly escape disruptive control characters, cap rendering work, and show suppressed-display counts with reasons. Add a sanitized inspection view so users can understand an unreadable or noisy event without replaying it.

**Prerequisites:** Portable local-data view; access to actual incoming VRChat chatboxes is not assumed.

Acceptance:

- Unicode handling preserves valid international text and grapheme boundaries; no copied ASCII-only rules or word blacklist.
- Display filtering does not silently rewrite source history or claim to block VRChat traffic.
- Long text, repeated input and unknown encodings have bounded rendering/export behavior and explicit truncation.

Existing owners: `game_log.py`, `game_log_ui.py`, `desktop_notifications.py`, `media_error_context.py`.
Evidence: E16, E12. Refinement; extends C23, VX-DESK-03.

### AR261005-12 — Creator-owned Udon behavior and event report browser

**Already in Eye:** Eye already retains Unity/Udon-related log evidence and creator report foundations; it does not inspect arbitrary live world programs.

**Add:** Browse a creator-selected export by hierarchy path, behavior, declared event and exposed symbol, and link exact matching log evidence to it. Show unresolved references and report/build identity.

**Prerequisites:** Needs a documented exporter/report contract and native Unity acceptance; the native client hook is not a reusable provider.

Acceptance:

- An event declaration is not proof that it executed or caused a log error.
- Only matching creator-provided report/build evidence receives exact links; others remain possible associations.
- The browser is read-only and does not invoke events or alter other users' worlds.

Existing owners: `Unity/Editor/VrcEyeCreatorManifest.cs`, `unity_model.py`, `unity_history.py`, `unity_ui.py`, `inspection_reports_ui.py`.
Evidence: E21. Refinement; extends NM1919-13, C23.

### AR261005-13 — Reviewable appearance packs and panel-level accessibility

**Already in Eye:** Themes, accents, scaling, contrast and reduced motion already exist and are included in typed settings backup.

**Add:** Define an optional data-only appearance preset with identity, author text, compatible schema and an exact changed-token preview. Permit bounded named overrides, reset/undo and explicit ordering, while preserving meaningful On/Off text and keyboard focus. Check tooltip placement and new panel animations against existing accessibility preferences.

**Prerequisites:** Portable schema/UI work; apply through existing appearance and settings owners, not a second theme engine.

Acceptance:

- Do not recreate Unity hierarchy selectors, downloaded sprites, brand marks or client assets.
- A cosmetic preset cannot change accounts, collectors, hotkeys or provider permissions.
- Unknown tokens are rejected/reported and protected accessibility choices remain explicit during preview.

Existing owners: `ui_preferences.py`, `ui_theme.py`, `appearance_colors.py`, `accessibility_ui.py`, `settings_bundle.py`.
Evidence: E09, E13, E23. Refinement; extends C24, NM1919-07.

### AR261005-14 — Pinned controls for selected media applications

**Already in Eye:** Eye already has native Windows/Linux media providers and transport controls; play/pause/next are not new features.

**Add:** Pin selected provider-supported application controls into a compact deck, keep the target application visible, and distinguish last known state, requested action and confirmed outcome. Communication-app shortcuts may be a separate optional adapter only when their capability can be verified.

**Prerequisites:** GSMTC/MPRIS/native-provider dependent. Any communication-app integration requires independent current documentation and acceptance.

Acceptance:

- Do not steal foreground focus or silently send a global shortcut to the wrong application.
- Never infer Discord mute/deafen state from a keypress; show unconfirmed or unavailable when no supported state source exists.
- Retain existing action, privacy and provider ownership; stale sessions cannot receive actions.

Existing owners: `media_service.py`, `media_windows.py`, `media_linux.py`, `media_ui.py`, `desktop_service.py`.
Evidence: E17. Refinement; extends C13, C21.

## What each archive contributed

| Archive | Finding and disposition |
|---|---|
| VRChat Creator Companion.zip | Installed VCC distribution, templates and minified web UI. Highest-value creator inspiration: repositories, package changes, editor selection, backup/migration and templates. Bundled build declares 2.4.5, not current-version authority. Executable/backend behavior was not tested; vendor notices do not establish a blanket reuse license. |
| Hexed-Reversed-main.zip | Obfuscated/decompiled C# plus runtime/interoperability code. Categorized events, diagnostic panels and presentation clues refine existing UI work. String decoders/loaders were not run. Many ClassN files and bundled dependencies are not independent features. |
| PendulumClient-Private-master.zip | Readable older client source. Preview rotation, theme metadata and notification settings are useful design clues. README describes an old/nonworking client. Notification registration is commented out and its instance filter is a stub. |
| babyfurPASTE.rar | Odium-derived decompiled source. Reinforces the lifecycle/text/UI ideas also found in A11; counted once. 109 of 143 corresponding C# files match A11 after newline normalization. No independent compatibility is established. |
| Mint v2.rar | Native C++ source with vendors and large development/build artifacts. Creator-owned Udon report browsing and basic tabbed/control presentation are transferable ideas. About 2.29 GB declared expansion is mostly development artifacts. Large generated files were skipped; hooks/authentication/runtime modifications were not adopted. |
| FuneralClient-master.zip | Older C# client source plus substantial vendor code. Component budget attribution and diagnostic presentation are useful. Historical mesh/particle thresholds and live disabling are not current SDK rules or proof of crash protection. |
| akdhax-vrchat.zip | Internal loader-dependent C# project plus generated assemblies. Tooltip/view-tween choices reinforce accessibility acceptance for future Eye panels. README dependency/compatibility claims were not tested. Game-object modifications provide no standalone provider. |
| Bepinex-EAC-MSI-6.7.25.zip | Prepackaged runtime, plugins, generated interop assemblies, configs and API XML. Typed configuration/dependency contracts support the planned Eye extension SDK; panel/browser ideas reinforce existing reference tools. 500 DLLs are not 500 installable Eye plugins. Selected CLI metadata only: DeepCore 0.0.0.0; UnityExplorer 4.12.7.0. Method behavior and EAC claims were not verified. |
| NebulaWare-master.zip | C# in-client UI and modules. Compact readable roster presentation belongs in the shared desktop panel backlog. Its StandaloneUI is a Unity Canvas, not a native external panel; private client states are not a supported Eye data source. |
| odium-build-796.zip | Resources and authentication-related files, no client source/DLL implementation. Resource names identify bottom notification, notification and input-dialog presentation. No separate functional feature is proved. Authentication data was not read or used. Bundles/images were not loaded or copied into Eye. |
| Odium-VRC-main.zip | Decompiled Odium source plus Original/Patched source ZIPs. Lifecycle handling, notification placement, local text handling and app-control deck refinements. Nested source archives were inventoried and byte-compared only. Authentication patches and runtime hooks were not adopted; overlapping A04 ideas are deduplicated. |
| StellarV3External-master.zip | MelonLoader C# project and many bundled assemblies. Draggable/resizable panels and consistent button/toggle/slider design. Main inherits MelonMod despite External in the filename. README reuse conditions are not treated as permission to copy assets/code. |

The babyfurPASTE/Odium overlap is **109 of 143 corresponding C# files after newline normalization**. Shared concepts are counted once. The Odium resource pack establishes asset names, not functional notification or plugin implementations.

## Existing functionality and lower-priority ideas

Basic media transport, manual model orbit, notification batches/cooldowns, theme/accessibility controls, roster views, project manifests/copy jobs and the pending metadata/aggregate-report/GLB inspection tools are not counted again.

- Automatic loading-screen music and cosmetic client mimicry have lower value than finishing current creator and native acceptance work.
- General reference bookmarks, pack comparison, expression-menu/parameter inspection, dynamics graphs and animation remain on the previous backlog; these archives do not implement them.

No uploaded code, icons, themes, assets or runtime loaders were incorporated. The proposals use original Eye designs and existing data/action owners. Direct code reuse or a blanket license was not assumed. Game injection, authentication patching, private-state inference and disruptive features were not added to the roadmap.

## Suggested sequence

1. Complete native Unity/Windows/Linux acceptance for the pending exporter, rig viewer, media context and settings work.
2. Continue the previously recommended creator expression/parameter and dynamics report work; add AR261005-06 component attribution to the same report family.
3. Implement AR261005-01/02/03/04 in stages over existing Creator Projects and recovery owners; then AR261005-05 templates.
4. Take bounded UI follow-ons AR261005-07/10/11 as capacity allows; general extension hosting AR261005-08 remains its own milestone.
5. Defer multi-surface panels, Udon reporting, appearance packs and optional app-control adapters until their prerequisites are concrete.

## Review method and evidence

Complete outer archive inventories, bounded text extraction, selected source/config/API-document reads, nested source inventory/byte comparisons and byte-only CLI metadata for two DLLs. No installer, client, string decoder or assembly was executed.

- This is feature discovery, not a line-by-line code audit or compatibility/security certification.
- Text selection was bounded to 2 MiB per member and 180 MiB per archive; large generated files and binary internals were not comprehensively inspected.
- Resource bundles/images were inventoried; no rendering, Unity loading or runtime behavior is claimed.
- Method/type names and UI strings establish declarations or design intent, not a working provider.

Evidence below identifies selected source locations, not executed behavior. For the minified VCC bundle, offsets are zero-based UTF-8 byte offsets in decoded text. Full archive hashes, selected-file hashes, owners, constraints and machine-readable proposals are in `ARCHIVE_REVIEW_2026_10_05.json`.

| Evidence | Archive/member | Location | Observation |
|---|---|---|---|
| E01 | A01: `VRChat Creator Companion/WebApp/Dist/buildInfo.json` | line 1 (2.4.5) | The bundled distribution declares VCC 2.4.5; this is not a claim that it is the current release. |
| E02 | A01: `VRChat Creator Companion/WebApp/Dist/assets/index-066158fc.js` | byte 1285921 (Community Repositories); byte 1260413 (Local User Packages); byte 1010975 (settings/showPreReleasePackages) | UI strings identify repository lists, community sources and prerelease display. Minified frontend evidence does not verify backend operations. |
| E03 | A01: `VRChat Creator Companion/WebApp/Dist/assets/index-066158fc.js` | byte 1289740 (Packages with potential conflicts); byte 1290321 (Downgrading a package); byte 1290650 (packageChangesDetailedView) | UI strings expose potential package conflicts, major upgrades, downgrades and detailed change presentation. |
| E04 | A01: `VRChat Creator Companion/WebApp/Dist/assets/index-066158fc.js` | byte 1025707 (unityEditors/supportedInfo); byte 1116026 (Change Unity Version); byte 1026033 (hasRecommendedEditor) | Frontend references supported/recommended editors and changing Unity version; no installer or backend was run. |
| E05 | A01: `VRChat Creator Companion/WebApp/Dist/assets/index-066158fc.js` | byte 1031751 (backupProject); byte 1110415 (Create Backup); byte 1319030 (Make Backup) | Frontend contains project backup and migration affordances. |
| E06 | A01: `VRChat Creator Companion/Templates/Avatar/package.json` | Selected declarations | Template metadata supplies an identity and declared template version; project settings separately declare the editor version. |
| E07 | A03: `PendulumClient-Private-master/UI/AvatarPreviewScroller.cs` | line 15 (AutoRotate) | Manual drag and automatic rotation toggles inspire optional local preview presentation. |
| E08 | A03: `PendulumClient-Private-master/JoinNotifacations/JoinNotifierSettings.cs` | line 26 (RegisterSettings); line 49 (ShouldNotifyInCurrentInstance) | Join/leave presentation and instance-filter settings are design clues. Registration is commented out and ShouldNotifyInCurrentInstance returns true; the filter is not proven functional. |
| E09 | A03: `PendulumClient-Private-master/ColorModuleV2/CMV2_StyleMetadata.cs` | line 21 (MixinPriority); line 23 (DisabledByDefault) | Theme metadata includes name, description, author, target build, mixin priority and disabled-by-default state. |
| E10 | A06: `FuneralClient-master/FuneralClient/Utils/Other/AntiCrash.cs` | line 94 (maxParticles); line 151 (subMeshCount) | Component inspection includes particle, mesh and material checks. Its live mutations and historical thresholds are not proposed for reuse. |
| E11 | A02: `Hexed-Reversed-main/Client/Hexed/Class118.cs` | Selected declarations | Obfuscated/decompiled code contains Quick Menu panel and text-color references. Only visible declarations/literals were inspected. |
| E12 | A02: `Hexed-Reversed-main/Client/Hexed/Class53.cs` | Selected declarations | Event categories and colored presentation can inform local diagnostic views; availability of private game events is not assumed. |
| E13 | A07: `akdhax-vrchat/HexedBase/Visuals/QMMenus/QMMenuQOL.cs` | line 53 (Disable ViewTween); line 69 (Top Tooltip) | Camera-tween and tooltip-position toggles are presentation hints; most game-object modifications are outside Eye. |
| E14 | A09: `NebulaWare-master/UI/PlayerListUI.cs` | line 17 (Canvas); line 107 (blocksRaycasts) | A Unity Canvas roster suggests a compact view. Its StandaloneUI name does not establish an external OS panel. |
| E15 | A11: `Odium-VRC-main/Client/Original/Odium/OdiumModuleLoader.cs` | line 16 (OnApplicationStart); line 118 (OnSceneWasLoaded); line 283 (SetModuleEnabled) | Enabled modules receive lifecycle callbacks with exception logging. Catching exceptions is not process isolation. |
| E16 | A11: `Odium-VRC-main/Client/Original/Odium/ChatboxAntis.cs` | Selected declarations | Repeated text, sender cooldown and Unicode checks inspire bounded local display filters, not game traffic interception. |
| E17 | A11: `Odium-VRC-main/Client/Original/Odium/MediaControls.cs` | Selected declarations | Media and communication shortcuts suggest a selected-app control deck. The supplied focus/keystroke approach does not verify resulting application state. |
| E18 | A11: `Odium-VRC-main/Client/Original/Odium/Odium/Modules/OdiumBottomNotification.cs` | line 210 (ShowNotification) | A separate bottom notification presentation is visible in source; this does not demonstrate a bounded notification queue. |
| E19 | A08: `BepInEx/core/BepInEx.Core.xml` | line 225 (T:BepInEx.Configuration.AcceptableValueRange); line 308 (T:BepInEx.Configuration.ConfigDescription) | Supplied API documentation defines typed settings, acceptable ranges/lists, and setting-change events. |
| E20 | A08: `BepInEx/core/BepInEx.Core.xml` | line 822 (F:BepInEx.BepInDependency.DependencyFlags.HardDependency); line 867 (T:BepInEx.BepInIncompatibility) | Supplied API documentation defines required/optional dependencies, version ranges and incompatibilities. |
| E21 | A05: `Mint/Mint/Entrypoint.cpp` | line 1446 (UdonBehaviours: %d); line 1472 (Udon Events:) | A tabbed object/event listing suggests a creator-owned world report browser. Runtime event invocation and hooks are not adopted. |
| E22 | A12: `StellarV3External-master/StellarV3/Main.cs` | line 16 (class Main : MelonMod); line 151 (GUI.DragWindow); line 190 (resizeArea) | Main inherits MelonMod and draws a draggable/resizable Unity GUI. The archive is not an external desktop app. |
| E23 | A12: `StellarV3External-master/StellarV3/GUIButtonAPI/GUIButtonAPI.cs` | Selected declarations | Button, toggle and slider helpers suggest consistent declarative extension controls; no implementation is copied. |

Official VCC documentation was also checked to separate supported workflows from archive-era UI clues:

- [https://vcc.docs.vrchat.com/guides/community-repositories/](https://vcc.docs.vrchat.com/guides/community-repositories/): Repository preview and source selection; credentials must not be treated as portable catalog metadata.
- [https://vcc.docs.vrchat.com/vpm/packages/](https://vcc.docs.vrchat.com/vpm/packages/): VPM package dependencies, local packages, prerelease handling and legacy-folder implications.
- [https://vcc.docs.vrchat.com/guides/faq/](https://vcc.docs.vrchat.com/guides/faq/): Backup ZIP restoration and migration/path considerations.
- [https://vcc.docs.vrchat.com/vpm/migrating/](https://vcc.docs.vrchat.com/vpm/migrating/): Copy migration, exclusions and failure evidence.
- [https://vcc.docs.vrchat.com/guides/using-project-template-repos/](https://vcc.docs.vrchat.com/guides/using-project-template-repos/): Official/user template workflows.

## Verification and release hold

This review changes planning documents only. All 653 files in the pending source/test manifest must remain byte-identical. The prior 5,296 passing tests and 1,059 passing subtests are retained historical validation, not a newly executed run. Native Unity and Windows/Linux acceptance remain open. Archive integrity and review references are checked separately.

Keep this review inside the same unnumbered working checkpoint. Do not publish Development 22–29 packages or label these proposals Development 30.
