# VRC Eye Whispers

## Current release: 1.19.1

Open **VRC Eye → VRC Eye Primary → Whispers & sharing** for messaging.
The player profile's Whisper tab opens this same workspace. Pair and manage
connections in **VRC Eye → Networking**; see **NETWORKING_SETUP.md** and
**PEER_SERVICES_SETUP.md**. **Start.cmd** automatically prepares connection
packages; an offline setup failure leaves available local tools usable and a
later normal launch retries missing packages. LAN, supported VPN adapters and the
`peer_relay.py` tunnel are
available. Each installation has an authenticated device identity; local
player associations do not verify VRChat account identity.

The previous pairing secrets and relay protocol are not imported. Create fresh
invitations for the new service. Old relay modules remain in the source for
compatibility and historical tests; the current UI does not run them.

## Archived setup for 1.18.5

The instructions below describe the old release only.

Whispers are text conversations between paired copies of VRC Eye. They appear in
the selected player's **Whisper** tab, separate from VRChat voice/chat and avatar
functions. They do not change the VRChat client, use VRChat's notification API,
or provide an in-game overlay. No public VRC Eye relay or account directory is
provided. A complete relay server is included in `whisper_relay.py`.

## Pair and send

1. Both people extract the current release and run **Start.cmd**. Dependencies,
   including `cryptography`, are prepared automatically in `.recovery-env`.
   If setup cannot complete offline, local profiles and notes remain available;
   retry **Start.cmd** online before using encrypted connections.
2. Connect your own VRChat account in VRC Eye, then open the other person's player
   window using their exact logged account ID. Both people need each other's
   account window. The World player list works without a custom world helper.
3. One person enters a shared **HTTPS relay URL** and the relay operator's access
   token. Click **Create invitation**, then **Copy invitation**. Share this private
   invitation with the intended person through a channel you already trust.
   Do not post it in public chat: it contains the relay access token and a shared
   encryption secret. Clipboard contents are not automatically erased.
4. Both people paste that invitation in the matching player's Whisper tab and
   click **Connect / accept invitation**. The creator can use the invitation
   already in their field. Review the relay address before confirming.
5. Type text and click **Send whisper**. Only this explicit action queues a
   message. A relay acceptance is not a read receipt or guaranteed delivery.
   Polling starts only after connection; an idle pair polls about every two seconds.

Invitations are bound to two exact account IDs and are rejected in a different
player/account window. This guards against accidental pairing mistakes; the
shared invitation does **not independently authenticate the remote person's
VRChat identity**. Anyone holding it can impersonate either participant. Verify
the intended person through your existing trusted contact before sharing it.

After connecting, token/invitation entry boxes clear. The active pair remains in
memory. An errored active connection can reconnect explicitly using that in-memory
pair. After **Disconnect / block pair**, window close, account/log reset, or app
exit, paste a retained invitation to reconnect, or create/share a new one.
Disconnect blocks this pair locally by stopping its worker; it does not create a
VRChat block or revoke copies of the old secret. Use a new invitation to replace
a compromised pairing. There is no automatic discovery or unsolicited incoming
contact. Keep the relevant window open to receive messages.

## Run the included relay

The relay uses only Python's standard library and can run separately from VRC Eye.
For a **local two-client test on one computer**:

```text
python whisper_relay.py --create-key relay-access.txt
python whisper_relay.py --access-key-file relay-access.txt --host 127.0.0.1 --port 8766
```

The first command creates a new token file without overwriting an existing one.
Read the token file privately and supply its contents to your two local clients.
Use `http://127.0.0.1:8766` in the Whisper tab. Loopback is reachable only from that
computer. It does not connect friends on different computers over the internet.

For friends on different computers, host the relay on a machine reachable by
both, with a DNS name and valid TLS certificate for that name:

```text
python whisper_relay.py --access-key-file relay-access.txt --host 0.0.0.0 --port 8766 --cert fullchain.pem --key privkey.pem
```

Use `https://your-relay-host:8766` in both clients. Configure your own hosting,
firewall and DNS to reach that port. `fullchain.pem` and `privkey.pem` must be
real certificate files you supply; the command does not issue a certificate.
Clients validate certificates using Python's trust store. There is no
certificate-verification bypass or silent insecure fallback. A non-loopback
listener requires TLS certificate/key arguments; remote cleartext HTTP is refused.
Relay URLs must be an origin, with no path, credentials, query, or fragment.

Share the relay access token only with intended users. Each invitation includes
it, so everyone with an invitation can use that relay and create their own pairs.
To revoke operator access, stop the relay, generate a token at a new filename,
restart with that file, and create new invitations with the new token. Protect the
access-token and TLS-key files. On Windows, their access follows the folder ACLs.
Stop the server with Ctrl+C. It is a standalone process, not an automatically
installed/background system service.

## Behavior and limits

| Item | Implemented behavior |
| --- | --- |
| Message contents | AES-256-GCM encryption with a random 12-byte nonce per message. Direction, channel and message ID are authenticated. Tampered/wrong-key/wrong-identity/expired messages are rejected. |
| Key distribution | A private invitation supplies a random 32-byte shared secret. Encryption and relay authentication use separate derived values. The encryption secret is not sent to the relay. |
| Transport | HTTPS with certificate validation; HTTP allowed only for loopback testing. Redirects are refused, so relay credentials are not forwarded. No VRChat cookies or passwords go to the relay. |
| Identity and metadata | User IDs and message text are inside ciphertext. The relay sees opaque channel/side IDs, IP addresses, times and message sizes. The shared-secret protocol has not been independently audited and does not provide forward secrecy. |
| Retention | Relay RAM only, up to the latest 100 messages per pair for 24 hours, removed on subsequent activity; restart clears everything. No durable offline-delivery guarantee. |
| Local history | Last 500 transcript entries in the open window's memory, not saved to notes, settings or profile JSON. Account/log reset and closing clear it. |
| Bounds | 2,000 characters/message; server allows at most one send/second per side, 256 active pairs, and 20 concurrent request handlers. Oversized/invalid requests are rejected. |
| Replay handling | Message IDs/cursor suppress repeats during a connection, with a 10,000-ID session bound. Explicit reconnect may replay still-retained messages. |
| Presence | A peer poll in the last 30 seconds. It means this paired client contacted the relay, not that the person is in VRChat, nearby, or reading the window. |
| Send failure | No automatic resend. The server might already have accepted a timed-out send; decide whether to retry. Failed sends retain the typed draft. |
| Cancellation | Closing/disconnecting/account changes cancel queued work; a request already transmitted may finish at the relay. Late UI results from old connections are discarded. |

Synthetic tests exercise two real local HTTP clients and a local TLS relay,
including rejection of an untrusted certificate. Other checks cover encryption,
tampering, wrong keys/identities, redirects, bounds, operator access, presence,
retention, failed acknowledgements and the actual UI worker callbacks. No public
relay was deployed and no real friend received a development message. These
checks do not replace a live test of your hosting setup.

Cryptography API reference:
https://cryptography.io/en/latest/hazmat/primitives/aead/
