"""File health, reviewed byte matches and catalog metadata batch workflows."""
import json
from tkinter import filedialog

from companion_ui import Table, button, choice, line
from creator_projects_ui import text_area, set_text
from avatar_details import format_download_size
from avatar_folder_discovery import select_source
from avatar_library import context_token
import avatar_file_matching as files
import avatar_metadata_jobs as metadata


def hidden(page):
    from account_header import private
    return bool(page.privacy.get() or private(page.app))


class FileHealthPanel:
    def __init__(self, page, parent):
        self.page = page; self.source = None; self.results = []; self.matches = {}
        self.generation = 0; self.owned = None; self.was_hidden = False
        self.folder = page.tk.StringVar(value='No folder selected.')
        self.status = page.tk.StringVar(value='Choose a folder for matches, or check recorded files.')
        self.match = page.tk.StringVar(value='Choose a recorded association')
        page.ttk.Label(parent, text='Find byte-identical files and inspect recorded-file health. '
            'Matches use SHA-256 and size; filenames and avatar names do not establish identity.', wraplength=940).pack(anchor='w', pady=5)
        row = line(page, parent)
        button(page, row, 'Choose folder…', self.choose)
        button(page, row, 'Find exact matches', self.scan)
        button(page, row, 'Check recorded files…', self.health)
        button(page, row, 'Cancel task', page.cancel)
        page.ttk.Label(parent, textvariable=self.folder, wraplength=940).pack(anchor='w')
        self.table = Table(page, parent, (('file','File',230), ('result','Result',430), ('bytes','Size',120)), height=8, select=self.select)
        row = line(page, parent)
        self.picker = choice(page, row, self.match, ('Choose a recorded association',), width=55)
        button(page, row, 'Review matching association…', self.register)
        self.detail = text_area(page, parent, height=8)
        from avatar_association_rules_ui import Controls
        self.rule_controls=Controls(self,parent)
        page.ttk.Label(parent, textvariable=self.status, wraplength=940).pack(anchor='w', pady=5)
        page.ttk.Label(parent, text='Each run hashes up to 128 files / 4 GiB. Folder discovery is also bounded; '
            'partial coverage is reported. Duplicate bytes may have several recorded avatar/build associations. '
            'Review one explicitly or enable an exact-byte rule for later scans. Matching never moves or deletes files.',
            wraplength=940, style='Muted.TLabel').pack(anchor='w')

    def require(self):
        self.page.writable()
        if hidden(self.page): raise ValueError('Reveal account information before inspecting files.')
        if self.page.job: raise ValueError('Wait for the active avatar task to finish or stop.')

    def clear(self):
        if self.owned is not None and self.page.job is self.owned: self.page.cancel()
        self.owned = None; self.generation += 1; self.source = None; self.results = []; self.matches = {}
        self.folder.set('No folder selected.'); self.match.set('Choose a recorded association')
        self.picker.configure(values=('Choose a recorded association',))
        self.table.set([], lambda r: ()); set_text(self.detail, '')
        self.rule_controls.clear();self.status.set('File results cleared.')

    def choose(self):
        self.require(); token = self.page.context(); generation = self.generation
        path = filedialog.askdirectory(parent=self.page.app.root, title='Choose folder for exact file matching', mustexist=True)
        self.page.check_context(token); self.require()
        if not path: return
        source = select_source(path)
        if not self.page.review('Review file matching folder',
                f'{source.path}\n\nRead supported candidates under this folder, up to 128 files / 4 GiB per run. '
                'Compare against this account’s recorded hashes. Previously enabled exact-byte rules for this same folder can create references on a matching scan.', 'Use folder'): return
        self.require(); self.page.check_context(token)
        if generation != self.generation: raise ValueError('Folder selection changed. Choose again.')
        self.clear(); self.source = source
        self.folder.set(source.path if self.page.show_paths.get() else 'Selected folder · path hidden')

    def scan(self):
        self.require()
        if self.source is None: raise ValueError('Choose a folder first.')
        source, generation, scope = self.source, self.generation, self.page.scope
        token=self.page.context()
        records = files.snapshot(self.page.library, scope)
        def done(result):
            self.owned = None
            if generation != self.generation or hidden(self.page): return
            self.results = result['items']; self.matches = {}
            self.table.set(self.results, lambda r:(r['candidate']['relative_path'] if self.page.show_paths.get() else r['name'],
                                                  files.describe(r), format_download_size(r['candidate']['size'])))
            self.status.set(f"{len(self.results)} files examined. "+('Partial scan: limits reached.' if result['partial'] else 'Selected-folder scan complete.')+
                            ' Matches describe recorded associations, not ownership or current build versions.')
            message=self.rule_controls.apply_result(source,scope,generation,token,self.results)
            self.status.set(self.status.get()+message)
            self.page.refresh()
        self.page.start_task(lambda stop, progress:files.inspect_matches(source, records, stop=stop, progress=progress),
                             done, operation='Compare local file hashes')
        self.owned = self.page.job

    def select(self):
        row = self.table.selected(); self.matches = {}; self.match.set('Choose a recorded association')
        if not row: return
        if 'result' in row:
            set_text(self.detail, self.page.display(dict(file=row['record']['name'], avatar_id=row['record']['avatar_id'], **row['result'])))
        else:
            for index, match in enumerate(row['matches']):
                label = f"{index+1}: {match['avatar_id']} · {match.get('build_id') or 'avatar only'} · {match['role']}"
                self.matches[label] = match
            if len(self.matches) == 1: self.match.set(next(iter(self.matches)))
            details = dict(reason=files.describe(row), file=row['name'],
                           sha256=(row.get('evidence') or {}).get('sha256'),
                           recorded_associations=[dict(avatar_id=r['avatar_id'], build_id=r.get('build_id',''), role=r['role']) for r in row['matches']],
                           duplicate_files=[path if self.page.show_paths.get() else __import__('pathlib').Path(path).name for path in row['duplicate_paths']])
            set_text(self.detail, self.page.display(details))
        self.picker.configure(values=tuple(self.matches) or ('Choose a recorded association',))

    def register(self):
        self.require(); row = self.table.selected(); match = self.matches.get(self.match.get())
        if not row or not match: raise ValueError('Select a file and one of its exact recorded associations.')
        token, generation, scope, source = self.page.context(), self.generation, self.page.scope, self.source
        details = dict(file=row['name'], avatar_id=match['avatar_id'], build_id=match.get('build_id',''),
                       role=match['role'], sha256=row['evidence']['sha256'], bytes=row['evidence']['size'])
        if not self.page.review('Review exact-byte association', json.dumps(details,indent=2)+
                '\n\nSave a reference using this existing association? Exact bytes do not establish ownership. '
                'Other possible matches are not merged. The previous reference stays available for review.', 'Save matching reference'): return
        def check():
            self.require(); self.page.check_context(token)
            if generation != self.generation or source is not self.source: raise ValueError('File evidence was cleared. Scan again.')
        check(); files.register_match(self.page.library, scope, source, row, match, check=check)
        self.page.refresh(); self.status.set('Matching reference saved. Original files and previous references remain.')

    def health(self):
        self.require(); records = files.snapshot(self.page.library, self.page.scope)
        if not records: raise ValueError('No recorded files in this account’s Avatar Library.')
        token, scope, generation = self.page.context(), self.page.scope, self.generation
        if not self.page.review('Check recorded file health', f'Check up to 128 of {len(records)} recorded references, '
                'within a 4 GiB read budget. This reads only previously registered paths and saves their current availability. '
                'Missing or changed originals are not replaced.', 'Check files'): return
        self.require(); self.page.check_context(token)
        if generation != self.generation: raise ValueError('The file workspace changed.')
        def done(result):
            self.owned = None
            if generation != self.generation or hidden(self.page): return
            for row in result['items']:
                if self.page.library.record(scope,'file',row['id']) == row['record']:
                    self.page.library.update_file_check(scope,row['id'],row['result'])
            self.results = result['items']; self.matches = {}
            self.table.set(self.results,lambda r:(r['record']['name'],r['result']['availability'],format_download_size(r['record']['size'])))
            self.status.set(f"Checked {len(self.results)} references; {result['skipped']} outside this run’s budget. Results are observations at check time.")
        self.page.start_task(lambda stop,progress:files.inspect_health(records,stop=stop,progress=progress),done,operation='Check recorded file health')
        self.owned = self.page.job

    def tick(self):
        current = hidden(self.page)
        if current and not self.was_hidden: self.clear()
        self.was_hidden = current

    def close(self): self.clear()


class MetadataPanel:
    def __init__(self, page, parent):
        self.page = page; self.generation = 0; self.permitted = False; self.owned = None
        self.last_revision = -1; self.was_hidden = False
        self.selection = page.tk.StringVar(value='Selected avatar')
        self.mode = page.tk.StringVar(value='Fill missing')
        self.images = page.tk.BooleanVar(value=False)
        self.status = page.tk.StringVar(value='Choose catalog entries and review one background batch.')
        page.ttk.Label(parent,text='Update selected catalog metadata through your existing VRChat login. '
            'Fill missing fields, refresh observations older than seven days, or refresh the selected fields. '
            'Existing notes, favorites and local-file references stay intact.',wraplength=940).pack(anchor='w',pady=5)
        row = line(page,parent)
        choice(page,row,self.selection,('Selected avatar','Current filtered page'),width=24)
        choice(page,row,self.mode,metadata.MODES,width=23)
        page.ttk.Checkbutton(row,text='Include thumbnails',variable=self.images).pack(side='left',padx=5)
        row=line(page,parent)
        button(page,row,'Review & start batch…',self.start)
        button(page,row,'Cancel batch',self.cancel)
        button(page,row,'Refresh job history',self.refresh)
        self.table=Table(page,parent,(('time','Started',175),('mode','Mode',180),('state','Result',200),('progress','Items completed',130)),height=6,select=self.select)
        button(page,line(page,parent),'Review remaining items…',self.continue_remaining)
        self.detail=text_area(page,parent,height=10)
        page.ttk.Label(parent,textvariable=self.status,wraplength=940).pack(anchor='w',pady=5)
        page.ttk.Label(parent,text='The filtered page is only the currently displayed rows. API calls share the existing '
            'one-request-per-minute budget and may wait behind other features. No periodic scan or startup retry is enabled. '
            'Completed entries and per-item outcomes are retained; continuing a stopped batch creates a new review.',
            wraplength=940,style='Muted.TLabel').pack(anchor='w')

    def require(self):
        self.page.writable()
        from session_restore import offline
        if hidden(self.page) or offline(self.page.app): raise ValueError('Catalog provider updates are suspended in private/offline mode.')
        if self.page.job: raise ValueError('Wait for the active avatar task to finish or stop.')
        return self.page.connected()

    def start(self):
        self.require()
        ids = ((self.page.selected()['id'],) if self.selection.get()=='Selected avatar' else
               tuple(row['id'] for row in self.page.visible))
        plan=metadata.prepare(self.page.library,self.page.scope,ids,mode=self.mode.get(),thumbnails=self.images.get())
        self.launch(plan)

    def launch(self,plan):
        client=self.require(); token=self.page.context(); generation=self.generation
        if not self.page.review('Review catalog metadata updates',metadata.summary(plan),'Start background batch'): return
        if self.require() is not client or token!=self.page.context() or generation!=self.generation:
            raise ValueError('The reviewed account or workspace changed.')
        self.permitted=True
        # This worker guard uses plain state only; Tk variables stay on the UI thread.
        def allowed():
            return (self.permitted and generation==self.generation and not self.page.closed and
                    context_token(self.page.app)==token and not getattr(self.page.app,'_native_private',False))
        def done(data):
            self.owned=None; self.permitted=False; self.refresh()
            self.status.set('Metadata batch: '+data['state']+'. Select its receipt for per-item results.')
            set_text(self.detail,metadata.receipt_text(data)); self.page.refresh()
        self.page.start_task(lambda stop,progress:metadata.run(self.page.library,plan,client,stop=stop,progress=progress,allowed=allowed),
                             done,operation='Update catalog metadata',persist=lambda result,scope:None)
        self.owned=self.page.job

    def continue_remaining(self):
        self.require(); data=self.table.selected()
        if not data: raise ValueError('Select a saved metadata job.')
        ids=metadata.remaining(data)
        if not ids: raise ValueError('This batch has no remaining items.')
        ids=tuple(ref for ref in ids if self.page.library.get(self.page.scope,ref))
        plan=metadata.prepare(self.page.library,self.page.scope,ids,mode=data['mode'],thumbnails=data['thumbnails'])
        self.launch(plan)

    def refresh(self):
        if hidden(self.page): self.clear(); return
        data=metadata.jobs(self.page.library,self.page.scope)
        self.table.set(data,lambda r:(r['started_at'],r['mode'],r['state'],
                                     f"{sum(i['state']=='Complete' for i in r['items'])}/{len(r['items'])}"),identity=lambda r:r['id'])
        self.last_revision=self.page.library.revision

    def select(self):
        data=self.table.selected()
        if data and not hidden(self.page): set_text(self.detail,metadata.receipt_text(data))

    def cancel(self):
        self.permitted=False
        if self.owned is not None and self.page.job is self.owned: self.page.cancel()
        self.status.set('Cancellation requested; committed entries remain in job history.')

    def clear(self):
        self.cancel(); self.generation+=1; self.owned=None; self.table.set([],lambda r:())
        set_text(self.detail,''); self.last_revision=-1

    def tick(self):
        from session_restore import offline
        current=hidden(self.page)
        if current:
            if not self.was_hidden:self.clear()
        else:
            if offline(self.page.app):self.cancel()
            if self.last_revision!=self.page.library.revision:self.refresh()
        self.was_hidden=current

    def close(self): self.clear()
