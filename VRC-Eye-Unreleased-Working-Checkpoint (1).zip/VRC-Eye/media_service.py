"""One optional metadata worker. No auto-connect, audio capture or OSC socket."""
import asyncio
from collections import deque
from concurrent.futures import Future
import queue
import sys
import threading
import time
import uuid

from media_model import Intent, session, validate_operation


def native_provider():
    if sys.platform == 'win32':
        from media_windows import WindowsMedia
        return WindowsMedia()
    if sys.platform.startswith('linux'):
        from media_linux import LinuxMedia
        return LinuxMedia()
    raise ValueError('Desktop media providers support Windows and Linux only.')


class MediaService:
    def __init__(self, *, provider_factory=native_provider, clock=time.monotonic, context_probe=None):
        self.factory, self.clock = provider_factory, clock
        self.lock = threading.RLock(); self.stop_event = threading.Event()
        self.thread = None; self.provider = None; self.sources = {}; self.selected = ''
        self.generation = 0; self.revision = 0; self.status = 'Disconnected. Discover players explicitly.'
        self.intents = {}; self.commands = queue.Queue(8); self.receipts = deque(maxlen=100)
        self.refresh_event = threading.Event(); self.dispatched = 0
        self.context_probe = context_probe
        self.context = context_probe() if context_probe else None
        self.loop = None; self.worker_task = None; self.cleaning = False
        self.cleanup_failed = False

    @property
    def active(self): return bool(self.thread and self.thread.is_alive())

    @property
    def quiescent(self): return not self.active and not self.cleanup_failed and not self.cleaning

    def start(self):
        with self.lock:
            if self.cleanup_failed: raise ValueError('Provider cleanup is unconfirmed. Retry provider cleanup before starting observation.')
            if self.active:
                if self.stop_event.is_set(): raise ValueError('Media observation is still stopping.')
                self.refresh_event.set(); return
            self.stop_event = threading.Event(); self.generation += 1
            self.context = self.context_probe() if self.context_probe else None
            self.status = 'Discovering desktop players…'; self.sources = {}; self.selected = ''; self.intents.clear(); self.revision += 1
            self.thread = threading.Thread(target=self._run, daemon=False, name='VRC-Eye-Media')
            self.thread.start()

    def select(self, identifier):
        with self.lock:
            if identifier not in self.sources: raise ValueError('Select a currently observed player.')
            if self.selected != identifier:
                self.selected = identifier; self.generation += 1; self.intents.clear()
            return self.sources[identifier]

    def invalidate(self):
        with self.lock:
            self.generation += 1; self.intents.clear()
            self.context = self.context_probe() if self.context_probe else None

    def current(self):
        row = self.sources.get(self.selected)
        return row if row and 0 <= self.clock()-row.observed <= 6 else None

    def snapshot(self):
        with self.lock:
            return dict(sources=tuple(self.sources.values()), selected=self.selected, current=self.current(),
                generation=self.generation, revision=self.revision, status=self.status,
                connected=self.active and not self.stop_event.is_set(), stopping=self.active and self.stop_event.is_set(),
                cleanup_failed=self.cleanup_failed,
                receipts=tuple(dict(r) for r in self.receipts), pending=self.commands.qsize())

    def diagnostics(self):
        with self.lock:
            current=self.current()
            return dict(schema='vrc-eye-media-diagnostics-1',worker='cleanup unconfirmed' if self.cleanup_failed else 'stopping' if self.active and self.stop_event.is_set() else 'observing' if self.active else 'inactive',
                provider_types=sorted({r.provider for r in self.sources.values()}),source_count=len(self.sources),
                selected_fresh=current is not None,capabilities=list(current.capabilities) if current else [],
                queued_requests=self.commands.qsize(),dispatched_requests=self.dispatched,
                outcomes={status:sum(r['status']==status for r in self.receipts) for status in ('accepted','rejected','not_sent','outcome_unknown')},
                audibility_verified=False,audio_capture='Separate audio service; not assessed by metadata diagnostics')

    def prepare(self, operation, value=None):
        with self.lock:
            row = self.current()
            if not row or self.stop_event.is_set(): raise ValueError('Select a fresh player observation.')
            value = validate_operation(row, operation, value)
            plan = Intent(uuid.uuid4().hex, self.generation, row.id, row.track_key, operation, value, self.clock()+15)
            if len(self.intents) >= 64: self.intents.pop(next(iter(self.intents)))
            self.intents[plan.nonce] = plan
            return plan

    def submit(self, plan):
        future = Future()
        with self.lock:
            if self.intents.pop(getattr(plan,'nonce',None), None) != plan:
                raise ValueError('Media control review is missing or already used.')
            self._check(plan)
            try: self.commands.put_nowait((plan, future))
            except queue.Full: raise ValueError('Media control queue is full.') from None
        return future

    def _check(self, plan):
        row = self.current()
        if (self.context_probe and self.context_probe() != self.context or
                self.stop_event.is_set() or self.clock() > plan.expires or self.generation != plan.generation
                or not row or row.id != plan.source or row.track_key != plan.track_key):
            raise ValueError('Player, track or context changed. Review the control again.')
        validate_operation(row, plan.operation, plan.value)
        return row

    def accept(self, rows):
        clean = [session(row, self.clock()) for row in rows[:32]]
        if len({r.id for r in clean}) != len(clean): raise ValueError('Duplicate media session identities.')
        with self.lock:
            if self.stop_event.is_set(): return
            old = self.sources.get(self.selected); self.sources = {r.id:r for r in clean}; new = self.current()
            if old and (not new or old.track_key != new.track_key): self.intents.clear(); self.generation += 1
            self.revision += 1
            self.status = 'Observing %s player(s). Pin a source to control it.' % len(clean)

    async def poll(self):
        rows = await asyncio.wait_for(self.provider.poll(), 12)
        self.accept(rows)

    async def execute(self, plan, future):
        dispatched = False; cancelled = False
        if not future.set_running_or_notify_cancel(): return
        receipt = dict(id=plan.nonce, operation=plan.operation, status='not_sent', observed=False)
        def boundary():
            nonlocal dispatched
            with self.lock:
                self._check(plan)
                dispatched = True; self.dispatched += 1
        try:
            await self.poll()
            with self.lock: row = self._check(plan)
            accepted = await asyncio.wait_for(self.provider.command(row, plan.operation, plan.value, boundary), 8)
            if not dispatched: raise ValueError('Provider did not validate the dispatch boundary.')
            if type(accepted) is not bool: raise ValueError('Unsupported player acknowledgement.')
            receipt.update(status='accepted' if accepted else 'rejected', detail='Player accepted the request; audible playback is unverified.' if accepted else 'Player rejected the request.')
            try:
                await self.poll()
                with self.lock: observed = self.current()
                if accepted and observed and observed.id == row.id:
                    matched = ((plan.operation in ('play','pause','stop') and observed.state == {'play':'playing','pause':'paused','stop':'stopped'}[plan.operation])
                        or (plan.operation in ('next','previous') and observed.track_key != row.track_key)
                        or (plan.operation == 'seek' and observed.track_key == row.track_key and observed.position is not None and abs(observed.position-plan.value) <= 2))
                    receipt['observed'] = bool(matched)
            except Exception: pass  # acceptance is not changed by unavailable follow-up
        except asyncio.CancelledError:
            cancelled = True
            if receipt['status'] in ('accepted','rejected'):
                receipt.update(observed=False,detail='Player '+receipt['status']+' the request. Observation stopped before later state verification; audible playback remains unverified.')
            else:
                receipt.update(status='outcome_unknown' if dispatched else 'not_sent', observed=False,
                    detail='Media stopped after dispatch; the request may have reached the player. No automatic retry.' if dispatched else 'Media stopped before dispatch.')
        except Exception as error:
            receipt.update(status='outcome_unknown' if dispatched else 'not_sent',
                detail=('Request may have reached the player; no automatic retry.' if dispatched else
                        str(error) if isinstance(error, ValueError) else 'Player is unavailable or the request expired.'))
        with self.lock: self.receipts.append(dict(receipt))
        future.set_result(receipt)
        if cancelled: raise asyncio.CancelledError
        return receipt

    async def _worker(self, cleanup_only=False):
        with self.lock:
            self.loop = asyncio.get_running_loop(); self.worker_task = asyncio.current_task()
        try:
            if cleanup_only or self.stop_event.is_set(): return
            self.provider = self.factory()
            next_poll = -1.
            while not self.stop_event.is_set():
                try: plan, future = self.commands.get_nowait()
                except queue.Empty: plan = None
                if plan is not None:
                    await self.execute(plan, future); next_poll = self.clock()+2
                elif self.clock() >= next_poll or self.refresh_event.is_set():
                    self.refresh_event.clear()
                    try: await self.poll()
                    except Exception as error:
                        with self.lock:
                            self.sources = {}; self.intents.clear(); self.revision += 1; self.generation += 1
                            self.status = str(error) if isinstance(error, ValueError) else 'Media provider unavailable. Check its optional dependency and desktop session.'
                    next_poll = self.clock()+2
                await asyncio.sleep(.05)
        except asyncio.CancelledError:
            pass  # First-stop cancellation always proceeds through owned cleanup.
        except Exception:
            with self.lock: self.status = 'Media provider could not start.'
        finally:
            # The scheduled cancellation callback checks this under the same lock.
            # A second Stop/Close can never interrupt event unsubscription.
            with self.lock: self.cleaning = True
            cleanup_failed=False
            if self.provider is not None:
                try: await asyncio.wait_for(self.provider.close(), 3)
                except (Exception, asyncio.CancelledError): cleanup_failed=True
            with self.lock:
                self.sources = {}; self.intents.clear(); self.cleanup_failed = cleanup_failed
                if not cleanup_failed: self.provider = None
                if self.stop_event.is_set() or cleanup_failed:self.status='Observation stopped. Provider cleanup '+('could not be confirmed. Retry provider cleanup; observation and application exit remain blocked.' if cleanup_failed else 'completed. No external pause was sent.')
                while not self.commands.empty():
                    _, future = self.commands.get_nowait()
                    if not future.done(): future.set_result(dict(status='not_sent', observed=False, detail='Media stopped before dispatch.'))

    def _run(self, cleanup_only=False):
        try: asyncio.run(self._worker(cleanup_only))
        finally:
            with self.lock: self.loop = None; self.worker_task = None; self.cleaning = False

    def _cancel_before_cleanup(self, task):
        with self.lock:
            if self.worker_task is task and not self.cleaning and not task.done(): task.cancel()

    def stop(self):
        with self.lock:
            first_stop = not self.stop_event.is_set()
            self.stop_event.set(); self.generation += 1; self.intents.clear(); self.sources = {}; self.selected = ''
            self.revision += 1
            while not self.commands.empty():
                _, future = self.commands.get_nowait()
                if not future.done(): future.set_result(dict(status='not_sent', observed=False, detail='Media stopped before dispatch.'))
            if not self.cleanup_failed:
                self.status = ('Observation stopping.' if self.active else 'Observation stopped.')+' Queued commands canceled; no external pause was sent.'
            if first_stop and self.loop is not None and self.worker_task is not None and not self.cleaning:
                try: self.loop.call_soon_threadsafe(self._cancel_before_cleanup, self.worker_task)
                except RuntimeError: pass  # Owner loop already finished its cleanup.

    def retry_cleanup(self):
        """Explicit recovery only; retained native handles are never replaced."""
        with self.lock:
            if self.active: raise ValueError('Provider cleanup is still running.')
            if not self.cleanup_failed: return
            self.status = 'Retrying retained provider cleanup; observation remains disabled.'
            self.thread = threading.Thread(target=self._run, args=(True,), daemon=False, name='VRC-Eye-Media-Cleanup')
            self.thread.start()

    def close(self):
        self.stop()
        return self.quiescent
