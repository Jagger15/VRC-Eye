"""Reported performance ranks; never estimate a rank from partial avatar stats."""

from dataclasses import dataclass
from datetime import datetime, timezone

from avatar_details import PLATFORMS, normalize_avatar_timestamp
from avatar_links import parse_avatar_reference


RANKS = {name.replace(" ", "").casefold(): name for name in
         ("Excellent", "Good", "Medium", "Poor", "Very Poor")}


def normalize_rank(value):
    return RANKS.get(value.strip().replace(" ", "").casefold(), "Unknown") if isinstance(value, str) else "Unknown"


@dataclass(frozen=True)
class AvatarPerformance:
    avatar_id: str
    ranks: tuple[str, str, str]
    source: str
    checked_at: str
    updated_at: str = ""
    builds: tuple[str, ...] = ()

    @property
    def label(self):
        return " | ".join(f"{title}: {rank}" for (_, title, _), rank in zip(PLATFORMS, self.ranks))


def parse_performance(document, expected_id, *, source="Imported avatar JSON", checked_at=None):
    reference = parse_avatar_reference(expected_id)
    if (not isinstance(document, dict) or not isinstance(document.get("id"), str)
            or parse_avatar_reference(document["id"]) != reference):
        raise ValueError("Performance metadata must match the selected avatar ID.")
    summary = document.get("performance")
    summary = summary if isinstance(summary, dict) else {}
    packages = document.get("unityPackages")
    packages = packages if isinstance(packages, list) else []
    if len(packages) > 2000:
        raise ValueError("Too many avatar builds in the metadata.")
    ranks, builds = [], []
    for _key, title, native in PLATFORMS:
        matching = [p for p in packages if isinstance(p, dict) and p.get("platform") == native
                    and (p.get("variant") or "standard") in ("standard", "security")]
        reported = [normalize_rank(p.get("performanceRating")) for p in matching]
        rank = normalize_rank(summary.get(native))
        if rank == "Unknown" and reported:
            distinct = set(reported)
            rank = reported[0] if len(distinct) == 1 else "Multiple builds"
        ranks.append(rank)
        for package, rating in zip(matching, reported):
            unity = str(package.get("unityVersion", "Unknown"))[:80]
            version = str(package.get("assetVersion", "Unknown"))[:80]
            builds.append(f"{title} · Unity {unity} · asset {version} · {package.get('variant') or 'standard'}: {rating}")
    return AvatarPerformance(reference, tuple(ranks), source,
        checked_at or datetime.now(timezone.utc).isoformat(timespec="seconds"),
        normalize_avatar_timestamp(document.get("updated_at")), tuple(builds))


def performance_label(event, links, records):
    link = links.get(event)
    record = records.get(link[0]) if link else None
    return record.label + " *" if record else "Unknown"
