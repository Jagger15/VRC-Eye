"""Readable catalog summaries. Raw evidence stays available as an explicit view.

The caller applies privacy/path policy before formatting. No HTML or remote
content is rendered here, and no value is treated as an executable link.
"""
from __future__ import annotations
import json


def readable_details(value):
    if not isinstance(value, dict):
        return json.dumps(value, indent=2, ensure_ascii=False)
    def field(label, key, default="Unknown"):
        data = value.get(key)
        return f"{label}: {data if data not in (None, '', []) else default}"
    def joined(items):
        return ", ".join(str(item) for item in items) or "None recorded"
    if value.get("schema") == "vrc-eye-package-inspection-1":
        lines = [field("Package", "name"), field("Format", "format"),
                 f"Shader entries: {value.get('shader_count', 0)}    Materials: {value.get('material_count', 0)}",
                 field("Inspected at", "inspected_at"), field("Source location", "path"),
                 field("SHA-256", "sha256"), "", "PACKAGE DECLARATIONS"]
        for item in value.get("manifests", []):
            lines.append(f"{item.get('name') or 'Unnamed package'} · {item.get('version') or 'Version unknown'}")
            lines.append("License declaration: " + (item.get('license_declaration') or 'Unknown; not permission to reuse'))
            for name, version in item.get("dependencies", {}).items():
                lines.append(f"  Dependency: {name} · {version or 'Unknown'}")
        if not value.get("manifests"): lines.append("No readable package manifest found.")
        lines.extend(["", "SHADERS / SHADER SOURCE"])
        for item in value.get("shaders", []):
            lines.append((item.get("declared_name") or "No declaration determined") + "\n  " + item["path"])
        if not value.get("shaders"): lines.append("No recognized shader entries.")
        lines.extend(["", "MATERIAL REFERENCES"])
        for item in value.get("materials", []):
            lines.append(item["path"] + "\n  " + item["reference_state"])
            if item.get("referenced_asset"): lines.append("  Asset: " + item["referenced_asset"])
        if not value.get("materials"): lines.append("No recognized material entries.")
        if value.get("duplicate_shader_bytes"):
            lines.extend(["", "BYTE-IDENTICAL SHADER ENTRIES"])
            for names in value["duplicate_shader_bytes"].values(): lines.append(joined(names))
        lines.extend(["", "LICENSE FILES", joined(value.get("license_files", [])), "", "INSPECTION NOTES"])
        lines.extend(value.get("issues", []) or ["No bounded-parser warnings recorded. This is not a compatibility or security certificate."])
        lines.extend(["", value.get("limitations", "")])
        return "\n".join(lines)
    if "availability" in value and "sha256" in value:
        return "\n".join([field("File", "name"), field("Role", "role"), field("Location", "path"),
            f"Recorded bytes: {value.get('size', 'Unknown'):,}" if isinstance(value.get('size'),int) else 'Recorded bytes: Unknown',
            field("Last check", "availability"), field("Checked at", "checked_at"),
            field("Recorded SHA-256", "sha256"), field("Last observed SHA-256", "observed_sha256"),
            field("Association", "build_id", "Avatar only; not a specific observed build"),
            field("Source note", "provenance"), "", "A recorded hash identifies bytes, not ownership, rights or a functioning avatar. Recheck before relying on an old observation."])
    if "descriptor_id" in value:
        return "\n".join([field("Avatar", "avatar_id"), field("Platform", "platform"),
            field("Unity declaration", "unity"), field("Asset version", "asset_version"),
            field("File revision", "file_version"), field("File ID", "file_id"), field("Variant", "variant"),
            field("Identity evidence", "identity_evidence"), field("First recorded", "first_seen"),
            field("Last recorded", "last_seen"), field("Observation source", "source"),
            "", "Only saved observations are shown. This is not a complete server-side version archive."])
    if "field_evidence" in value:
        lines = [field("Avatar", "name"), field("Avatar ID", "id"), field("Creator", "author"),
            field("Creator ID", "author_id"), field("Visibility snapshot", "visibility"),
            "Reported platforms: " + joined(value.get("platforms", [])), "Tags: " + joined(value.get("tags", [])),
            field("Avatar record version", "version"), field("Record creation date", "created_at"),
            field("Record update date", "updated_at"), field("First saved here", "first_seen"),
            field("Last saved here", "last_seen"), "Sources: " + joined(value.get("sources", [])),
            "", "DESCRIPTION", value.get("description") or "No description recorded.",
            "", value.get("author_check", "Authorship and modification rights are not established by this catalog.")]
        if value.get("history"):
            lines.extend(["", "RECENT LOCAL OBSERVATION CHANGES"])
            for item in value["history"][-12:]:
                lines.append(item["at"] + " · " + joined(item["fields"]) + " · " + item["source"])
            if len(value["history"]) > 12: lines.append("Raw details contains up to 50 retained change events.")
        return "\n".join(lines)
    if "operation" in value and "started_at" in value:
        return "\n".join([field("Task", "operation"), field("Outcome", "state"),
            field("Avatar", "avatar_id"), field("Started", "started_at"), field("Finished", "finished_at"),
            field("Destination", "destination", "No copy destination"), field("Outcome note", "message", "None"),
            "", "An inspection may complete before you choose whether to save its results. Interrupted or failed copies need destination review; no automatic retry."])
    return json.dumps(value, indent=2, ensure_ascii=False)
