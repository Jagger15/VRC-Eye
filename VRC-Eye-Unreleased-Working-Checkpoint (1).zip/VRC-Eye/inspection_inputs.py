"""Bounded local snapshots for explicit diagnostic imports; no code loading."""
import hashlib
import os
from pathlib import Path
import stat
import time
from developer_core import bounded_json


def checkpoint(stop=None, deadline=None):
    if stop is not None and stop.is_set(): raise ValueError('Inspection canceled.')
    if deadline is not None and time.monotonic() > deadline: raise ValueError('Inspection time limit exceeded.')


def snapshot(path, limit, *, stop=None, deadline=None, digest_only=False):
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink(): raise ValueError('Choose a regular local file without symbolic links.')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0) | getattr(os, 'O_BINARY', 0))
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= limit:
            raise ValueError('Input is not a regular file within the inspection limit.')
        size = 0; chunks = []; digest = hashlib.sha256()
        while True:
            checkpoint(stop, deadline)
            chunk = stream.read(min(1024*1024, limit-size+1))
            if not chunk: break
            size += len(chunk)
            if size > limit: raise ValueError('Input exceeds the inspection limit.')
            digest.update(chunk)
            if not digest_only: chunks.append(chunk)
        after = os.fstat(stream.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    if identity(before) != identity(after) or identity(after) != identity(path.stat()) or size != before.st_size:
        raise ValueError('Input changed while it was being read. Choose it again.')
    checkpoint(stop, deadline)
    return (b'' if digest_only else b''.join(chunks)), digest.hexdigest()


def json_file(path, *, stop=None, limit=256*1024):
    raw, digest = snapshot(path, limit, stop=stop, deadline=time.monotonic()+30)
    return bounded_json(raw, limit=limit), digest
