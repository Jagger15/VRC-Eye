"""Receiver-controlled static peer notice in the existing SteamVR connection."""
import ctypes
import os
import textwrap


def pixels(text):
    from PIL import Image, ImageDraw, ImageFont
    image = Image.new('RGBA', (768, 256), (19, 27, 40, 240))
    draw = ImageDraw.Draw(image)
    font = None
    for name in ('segoeui.ttf', 'DejaVuSans.ttf'):
        try:
            font = ImageFont.truetype(name, 26)
            break
        except OSError:
            pass
    if font is None:
        font = ImageFont.load_default(size=26)
    lines = []
    for value in str(text)[:1200].splitlines():
        lines.extend(textwrap.wrap(value, width=46) or [''])
    draw.multiline_text((24, 18), '\n'.join(lines[:7]), font=font, fill='white', spacing=5)
    return image.tobytes()


class PeerOverlay:
    """Uses its owner's OpenVR runtime; never opens or closes another context."""
    def __init__(self, vr, *, channel='peer', title='VRC Eye peer notice', vertical=-.05):
        self.vr = vr
        self.channel,self.title,self.vertical=channel,title,vertical
        self.overlay = None
        self.handle = None
        self.text = None

    def draw(self, payload):
        text = str(payload.get('text', ''))[:1200]
        if not payload.get('enabled') or not text:
            if self.handle is not None:
                self.overlay.hideOverlay(self.handle)
            return
        if self.handle is None:
            self.overlay = self.vr.VROverlay()
            self.handle = self.overlay.createOverlay('vrceye.'+self.channel+'.' + str(os.getpid()), self.title)
            self.overlay.setOverlayWidthInMeters(self.handle, .55)
            matrix = self.vr.HmdMatrix34_t()
            for i in range(3):
                matrix.m[i][i] = 1.
            matrix.m[1][3] = self.vertical
            matrix.m[2][3] = -1.3
            self.overlay.setOverlayTransformTrackedDeviceRelative(self.handle, self.vr.k_unTrackedDeviceIndex_Hmd, matrix)
        if text != self.text:
            buffer = ctypes.create_string_buffer(pixels(text))
            self.overlay.setOverlayRaw(self.handle, buffer, 768, 256, 4)
            self.text = text
        self.overlay.showOverlay(self.handle)

    def close(self):
        if self.handle is not None:
            try:
                self.overlay.destroyOverlay(self.handle)
            finally:
                self.handle = None
