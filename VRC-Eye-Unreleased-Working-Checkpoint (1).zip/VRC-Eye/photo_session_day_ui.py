"""Keyboard-accessible night grouping controls on the existing photo catalog."""
from companion_ui import button,entry
from friendly_ui import flow_line
import photo_session_day as days


class Controls:
    def __init__(self,page,parent):
        self.page=page;self.account=None
        self.enabled=page.tk.BooleanVar();self.naive=page.tk.BooleanVar();self.cutoff=page.tk.StringVar();self.zone=page.tk.StringVar();self.filter=page.tk.StringVar()
        row=flow_line(page,parent)
        page.ttk.Checkbutton(row,text='Group late-night photos',variable=self.enabled).pack(side='left')
        page.ttk.Label(row,text='New day at HH:MM').pack(side='left');entry(page,row,self.cutoff,7)
        page.ttk.Label(row,text='Time zone').pack(side='left');entry(page,row,self.zone,23)
        button(page,row,'Save grouping',self.save)
        row=flow_line(page,parent);page.ttk.Checkbutton(row,text='Assume selected zone for dates without an offset',variable=self.naive).pack(side='left')
        page.ttk.Label(row,text='Session day filter (YYYY-MM-DD)').pack(side='left');entry(page,row,self.filter,12)
        page.ttk.Label(parent,text='Local, UTC or an installed IANA zone, such as America/New_York. Grouping is derived from the labeled date evidence; it is not proof of a play session. Date from/to filters still use the original date. Originals and metadata stay unchanged.',wraplength=1000).pack(anchor='w')
        self.reload()

    def reload(self):
        page=self.page;value=days.load(page.shell.store,page.scope);self.account=page.scope
        self.enabled.set(value['enabled']);self.naive.set(value['assume_naive']);self.zone.set(value['timezone'])
        self.cutoff.set(f"{value['cutoff']//60:02d}:{value['cutoff']%60:02d}");self.filter.set('')

    def save(self):
        page=self.page;page.writable()
        if self.account!=page.scope:self.reload();raise ValueError('Photo workspace changed. Review grouping again.')
        import re
        raw=self.cutoff.get()
        if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',raw):raise ValueError('Use a cutoff such as 04:00.')
        hour,minute=map(int,raw.split(':'))
        value=days.settings(dict(schema=1,enabled=self.enabled.get(),assume_naive=self.naive.get(),timezone=self.zone.get().strip(),cutoff=hour*60+minute))
        page.shell.store.set_option(days.key(page.scope),value)
        if not value['enabled']:self.filter.set('')
        page.search();page.status.set('Session-day grouping saved for this workspace. Original dates and files are unchanged.')
