"""Avatar Library Recovery panel for manual extraction preparation and review."""
from pathlib import Path
import json

from companion_ui import button, line
from creator_projects_ui import review_document, text_area, set_text
from ui_theme import responsive_wrap
import avatar_recovery_provider as recovery


class RecoveryPanel:
    """Uses the parent Avatar Library worker, receipts and account/privacy scope."""
    def __init__(self, page, parent):
        self.page, self.parent = page, parent
        self.service = recovery.PreparationService()
        self.generation = 0
        self.source = None
        self.handoff = ''
        self.last = self.context()
        self.path = page.tk.StringVar()
        self.destination = page.tk.StringVar()
        self.output = page.tk.StringVar()
        self.authorized = page.tk.BooleanVar(value=False)
        self.info = page.tk.StringVar(value='Choose a local bundle you own or are authorized to recover, then inspect it.')
        self.label('Prepare an avatar recovery handoff', title=True)
        self.label('Prepare a verified input handoff, or explicitly review a managed AssetRipper export with your installed tool. Recovered output does not establish a complete original Unity project.')
        row = line(page, parent)
        button(page, row, 'Choose bundle…', self.choose_source)
        button(page, row, 'Inspect selected bundle', self.inspect_source)
        button(page, row, 'Clear recovery details', self.clear)
        self.source_label = page.tk.StringVar(value='No source selected.')
        responsive_wrap(page.ttk.Label(parent, textvariable=self.source_label)).pack(anchor='w', pady=3)
        responsive_wrap(page.ttk.Label(parent, textvariable=self.info)).pack(anchor='w', pady=4)
        page.ttk.Checkbutton(parent, text='I own this avatar or have permission to preserve and recover these files.',
                             variable=self.authorized).pack(anchor='w', pady=4)
        row = line(page, parent)
        button(page, row, 'Choose NEW staging folder…', self.choose_destination)
        button(page, row, 'Review and prepare handoff…', self.prepare)
        self.destination_label = page.tk.StringVar(value='No staging folder selected.')
        responsive_wrap(page.ttk.Label(parent, textvariable=self.destination_label)).pack(anchor='w', pady=3)
        from assetripper_ui import ManagedRecovery
        self.managed=ManagedRecovery(self,parent)
        self.label('Manual extraction steps')
        self.label('1. Install an official AssetRipper release appropriate for your system separately. Its published builds include Windows and Linux; VRC Eye has not tested a native installed tool here.\n'
                   '2. Open AssetRipper yourself. Load the prepared input.bundle using its GUI. If the bundle requires a key, use the separate supported key-recovery workflow first.\n'
                   '3. In AssetRipper, review export settings and choose the handoff’s empty RecoveredProject folder. Do not overwrite an existing Unity project.\n'
                   '4. Wait for export to finish, close the export task, then select that output below. Inspect before opening Unity: exported scripts can execute when imported. '
                   'Missing shaders, editor-only assets, source textures, original scripts and authoring history may be unrecoverable.')
        self.label('Inspect an exported source folder', title=True)
        row = line(page, parent)
        button(page, row, 'Choose exported source folder…', self.choose_output)
        button(page, row, 'Use a saved handoff folder…', self.choose_handoff)
        button(page, row, 'Inspect output', self.inspect_output)
        button(page, line(page,parent), 'Working copies / repair history…', lambda:__import__('recovery_journal_ui').show(page.shell,account=page.scope,source=self.output.get()))
        button(page, line(page,parent), 'Inspect Unity setting-transfer report…', self.inspect_setting_transfer)
        self.output_label = page.tk.StringVar(value='No output selected. Nothing is scanned on opening this panel.')
        responsive_wrap(page.ttk.Label(parent, textvariable=self.output_label)).pack(anchor='w', pady=3)
        self.report = text_area(page, parent, height=12)
        set_text(self.report, 'Output inventory is read-only. A chosen handoff, matching hash, or matching Unity version does not establish that an output was derived from the selected bundle.')
        self.path.trace_add('write', lambda *_: self.source_changed())

    def label(self, text, title=False):
        responsive_wrap(self.page.ttk.Label(self.parent, text=text,
            style='Subtitle.TLabel' if title else 'Muted.TLabel')).pack(anchor='w', pady=(7, 4))

    def context(self):
        return (self.page.context(), self.page.privacy.get(), self.page.show_paths.get())

    def require(self):
        self.page.writable()
        if self.page.job:
            raise ValueError('Wait for or cancel the pending Avatar Library task first.')

    def signature(self):
        return (self.context(), self.generation, self.page.selected_id, self.path.get(), self.destination.get(),
                self.output.get(), self.handoff, id(self.source), self.authorized.get())

    def source_changed(self):
        self.source = None; self.service.clear(); self.authorized.set(False)
        if hasattr(self,'managed'):self.managed.clear()
        self.info.set('Source changed. Inspect the new bundle and confirm your permission before preparing it.')
        self.labels()

    def labels(self):
        def caption(value, empty):
            return value if value and self.page.show_paths.get() else 'Selected locally (path hidden)' if value else empty
        self.source_label.set(caption(self.path.get(), 'No source selected.'))
        self.destination_label.set(caption(self.destination.get(), 'No staging folder selected.'))
        self.output_label.set(caption(self.output.get(), 'No exported source folder selected.') +
                              (' · Handoff selected; derivation unverified.' if self.handoff else ' · No handoff comparison.'))

    def clear(self):
        self.generation += 1
        if self.page.job:
            self.page.cancel()
        self.service.clear(); self.source = None; self.handoff = ''
        if hasattr(self,'managed'):self.managed.clear()
        self.path.set(''); self.destination.set(''); self.output.set(''); self.authorized.set(False)
        self.info.set('Recovery source, destination and report cleared. Existing files and completed handoffs remain.')
        set_text(self.report, 'No output report retained. Choose and inspect explicitly.')
        self.last = self.context(); self.labels()

    def tick(self):
        if self.context() != self.last:
            self.clear()
        if hasattr(self,'managed'):self.managed.tick()

    def choose_source(self):
        self.require()
        token = self.signature()
        from tkinter import filedialog
        value = filedialog.askopenfilename(parent=self.page.app.root, title='Choose your authorized local Unity bundle',
            filetypes=[('Unity bundles', '*.vrca *.bundle *.unity3d'), ('All files', '*')])
        if value:
            self.after_dialog(token)
            self.path.set(value)

    def choose_destination(self):
        self.require()
        token = self.signature()
        from tkinter import filedialog
        value = filedialog.asksaveasfilename(parent=self.page.app.root, title='Choose the name of a NEW staging folder',
                                           initialfile='Avatar-Recovery-Handoff')
        if value:
            self.after_dialog(token)
            self.destination.set(value); self.service.clear(); self.labels()

    def choose_output(self):
        self.require()
        token = self.signature()
        from tkinter import filedialog
        value = filedialog.askdirectory(parent=self.page.app.root, title='Choose completed exported Unity source folder')
        if value:
            self.after_dialog(token)
            self.output.set(value); self.labels(); set_text(self.report, 'Output changed. Inspect explicitly.')

    def choose_handoff(self):
        self.require()
        token = self.signature()
        from tkinter import filedialog
        value = filedialog.askdirectory(parent=self.page.app.root, title='Choose a saved VRC Eye recovery handoff folder')
        if value:
            self.after_dialog(token)
            self.handoff = value; self.labels(); set_text(self.report, 'Handoff selected but not verified yet. Inspect output to compare.')

    def after_dialog(self, token):
        self.require()
        if token != self.signature():
            raise ValueError('The account, privacy setting or recovery draft changed while choosing a path. Choose again.')

    def inspect_setting_transfer(self):
        self.require();token=self.signature()
        from tkinter import filedialog
        from avatar_setting_reports import load,describe
        path=filedialog.askopenfilename(parent=self.page.app.root,title='Inspect completed Unity setting-transfer observation',filetypes=[('JSON observation','*.json')])
        self.after_dialog(token)
        if not path:return
        set_text(self.report,'Reading the selected setting-transfer observation…')
        def done(value):
            if self.page.closed or token!=self.signature():return
            set_text(self.report,describe(value,details=self.page.show_paths.get()))
            self.info.set('Setting-transfer report inspected. No importer, renderer or source was changed; native execution is not authenticated by an editable report.')
        self.page.start_task(lambda stop,progress:load(path,stop=stop),done,operation='Inspect setting-transfer report')

    def inspect_source(self):
        self.require()
        path = self.path.get(); token = self.signature()
        def done(value):
            if token != self.signature():
                raise ValueError('Recovery selection changed. Inspect the selected bundle again.')
            self.source = value; self.info.set(value.summary())
        self.page.start_task(lambda stop, progress: recovery.inspect_source(path, stop=stop, progress=progress), done,
                             operation='Inspect recovery source')

    def prepare(self):
        self.require()
        avatar = self.page.selected()['id']
        if not self.authorized.get():
            raise ValueError('Confirm that you own this avatar or have permission to recover its files.')
        review = self.service.prepare(self.source, self.destination.get(), avatar)
        token, context = self.signature(), self.page.context()
        try:
            if not review_document(self.page.app, 'Review recovery preparation', review.summary(), accept='Prepare verified handoff'):
                return
            self.require()
            if token != self.signature():
                raise ValueError('The account, avatar, source or destination changed. Review again.')
            def work(stop, progress, prepared=review):
                return self.service.execute(prepared, stop=stop, progress=progress,
                                            context_check=lambda: self.page.check_context(context))
            def done(value):
                if token != self.signature():
                    raise ValueError('The handoff was prepared but this recovery draft changed. Inspect the original account’s receipt and recorded destination.')
                self.handoff = value['destination']; self.output.set(str(Path(value['destination']) / 'RecoveredProject'))
                self.info.set('Verified handoff prepared. Open input.bundle in AssetRipper manually; no source extraction has run.')
                self.labels()
            # persist marks a completed staging operation complete even if a late
            # UI cancellation arrives; the initiating account keeps its receipt.
            self.page.start_task(work, done, avatar=avatar, operation='Prepare manual source recovery',
                                 destination=review.destination, persist=lambda result, scope: None)
            review = None
        finally:
            if review is not None:
                self.service.discard(review)

    def inspect_output(self):
        self.require()
        path, handoff, token = self.output.get(), self.handoff or None, self.signature()
        def done(value):
            if token != self.signature():
                raise ValueError('Recovery selection changed. Inspect the current output again.')
            set_text(self.report, json.dumps(value, indent=2, ensure_ascii=False))
        self.page.start_task(lambda stop, progress: recovery.inspect_output(path, handoff=handoff, stop=stop, progress=progress),
                             done, operation='Inspect manual recovery output')
