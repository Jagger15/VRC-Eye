"""Immutable media observations and command intents; no platform I/O."""
from dataclasses import dataclass
import hashlib
import json
import math
import re

OPERATIONS = ('play', 'pause', 'next', 'previous', 'stop', 'seek')
STATES = ('playing', 'paused', 'stopped', 'unknown')


def text(value, limit=512):
    if not isinstance(value, str): return ''
    value = ''.join(c for c in value[:limit * 4] if ord(c) >= 32 and ord(c) != 127 and not 0xD800 <= ord(c) <= 0xDFFF)
    return value[:limit].strip()


def number(value, maximum=31_536_000):
    return float(value) if type(value) in (float, int) and 0 <= value <= maximum and math.isfinite(value) else None


@dataclass(frozen=True)
class Session:
    id: str
    provider: str
    label: str
    track: str = ''
    title: str = ''
    artist: str = ''
    album: str = ''
    state: str = 'unknown'
    position: float | None = None
    duration: float | None = None
    rate: float = 1.
    capabilities: tuple = ()
    observed: float = 0.
    url: str = ''
    seek_start: float = 0.
    seek_end: float | None = None

    @property
    def track_key(self):
        return hashlib.sha256(json.dumps((self.track, self.title, self.artist, self.album, self.duration), ensure_ascii=False).encode()).hexdigest()

    def estimated_position(self, now):
        if self.position is None or not 0 <= now - self.observed <= 6: return None
        value = self.position + ((now - self.observed) * self.rate if self.state == 'playing' else 0)
        return max(0., min(value, self.duration)) if self.duration is not None else max(0., value)


def session(raw, now):
    if not isinstance(raw, dict): raise ValueError('Invalid media observation.')
    identifier, provider = text(raw.get('id')), text(raw.get('provider'), 32)
    if not identifier or identifier != raw.get('id') or provider not in ('MPRIS', 'Windows GSMTC', 'Fixture'): raise ValueError('Unsupported media source identity.')
    duration, position = number(raw.get('duration')), number(raw.get('position'))
    if duration == 0: duration = None
    advertised = raw.get('capabilities', ())
    if not isinstance(advertised, (list, tuple)): raise ValueError('Invalid media capabilities.')
    capabilities = tuple(op for op in OPERATIONS if op in advertised)
    seek_start = number(raw.get('seek_start', 0))
    seek_end = number(raw.get('seek_end', duration))
    track = text(raw.get('track'), 1024)
    if track != (raw.get('track') or ''): raise ValueError('Invalid media track identity.')
    if duration is None or not track or seek_start is None or seek_end is None or not seek_start < seek_end <= duration:
        capabilities = tuple(op for op in capabilities if op != 'seek')
    rate = number(raw.get('rate'), 16)
    return Session(identifier, provider, text(raw.get('label')) or provider, track,
        text(raw.get('title')), text(raw.get('artist')), text(raw.get('album')),
        raw.get('state') if raw.get('state') in STATES else 'unknown', position, duration,
        rate if rate is not None and rate > 0 else 1., capabilities, now, text(raw.get('url'), 8192), seek_start or 0., seek_end)


@dataclass(frozen=True)
class Intent:
    nonce: str
    generation: int
    source: str
    track_key: str
    operation: str
    value: float | None
    expires: float


def validate_operation(row, operation, value=None):
    if operation not in OPERATIONS or operation not in row.capabilities:
        raise ValueError('The selected player does not currently advertise this control.')
    if operation == 'seek':
        value = number(value)
        if value is None or row.duration is None or row.seek_end is None or not row.seek_start <= value <= row.seek_end:
            raise ValueError('Seek within the player’s advertised position range.')
    elif value is not None: raise ValueError('This control does not accept a position.')
    return value


def publication(row, include_artist=True):
    """Titles are deliberately previewed; URLs/paths are never template fields."""
    from osc_controls import preview_chat
    from game_log import redact
    title = row.title
    if not title: raise ValueError('The player has not supplied a title.')
    metadata = title + ' ' + row.artist
    if redact(metadata) != metadata or re.search(r'(?i)(?:https?://|file:|[A-Z]:[\\/]|/(?:home|users|tmp)/)', metadata):
        raise ValueError('Metadata contains a URL or local path; use the manual chatbox composer instead.')
    value = 'Now playing: ' + title + (' — ' + row.artist if include_artist and row.artist else '')
    # Keep UTF-16 code point boundaries intact; reserve one unit for ellipsis.
    while len(value.encode('utf-16-le')) // 2 > 144:
        value = value.rstrip('…')[:-1] + '…'
    return preview_chat(value)['text']
