"""Selected-photo context, compatible copies and journaled organization."""
import json
import time
from pathlib import Path
from tkinter import filedialog,simpledialog
from companion_ui import Table,line,button
from vrcx_ui_jobs import LocalPage
from photo_files import read_photo
from photo_organize import Organizer,publish
from photo_context import record,description,metadata_copy


def show(page):
    page.writable();photo=page.selected()
    return PhotoActions(page,photo['id'])


class PhotoActions(LocalPage):
    def __init__(self,page,photo):
        self.owner,self.photo=page,photo;self.service=page.service;self.store=page.store
        self.scope=page.scope;self.organizer=Organizer(self.store);self.preview=None
        app=page.app;self.window=app.tk.Toplevel(app.root);self.window.title('Photo context and organization');self.window.geometry('1020x700')
        from friendly_ui import ScrollPane
        self.viewport=ScrollPane(app,self.window,min_width=650)
        super().__init__(page.shell,self.viewport.body,'Selected photo · context and organization');self.setup_privacy()
        row=line(self);button(self,row,'Inspect / rebuild context index',self.index)
        button(self,row,'Index declared author / roster…',self.index_people)
        button(self,row,'Export compatible metadata copy…',lambda:self.export(False));button(self,row,'Export metadata sidecar…',lambda:self.export(True))
        row=line(self);button(self,row,'Move / rename selected file…',self.move);button(self,row,'Move to recovery folder…',self.recovery)
        button(self,row,'Move to OS trash…',self.trash)
        row=line(self);button(self,row,'Enable watched compatible exports…',self.enable_exports);button(self,row,'Disable compatible exports for source',self.disable_exports)
        self.detail=self.tk.StringVar(value='Originals are preserved during metadata export. File organization is explicit and records every publication / removal step.')
        self.ttk.Label(self.parent,textvariable=self.detail,wraplength=920).pack(anchor='w',pady=8)
        self.table=Table(self,self.parent,(('time','Time',170),('state','State',430),('id','Action',280)),height=10)
        row=line(self);button(self,row,'Refresh move history',self.history);button(self,row,'Undo selected completed move…',self.undo);button(self,row,'Inspect recovery paths',self.inspect_receipt)
        button(self,row,'Recover selected interrupted move…',self.recover_move)
        button(self,line(self),'Close',self.close);self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.timer=app.root.after(200,self.tick);self.history()
        page.windows.append(self)
    def current(self):
        self.ready();self.owner.revealed()
        if self.scope!=self.owner.scope:raise ValueError('The photo workspace changed.')
        row=self.store.get(self.scope,self.photo)
        if not row:raise ValueError('The selected photo was removed.')
        return row
    def index_people(self):
        row=self.current();token=self.token()
        if not self.confirm('Index declared photo identities','Store author and participant IDs declared in this photo’s metadata for local search? Metadata does not prove who is visible in the image.'):return
        self.verify(token);session=dict(getattr(getattr(self.app,'player_sessions',None),'meta',{}))
        def work(scope,context,stop,progress):
            raw,_=read_photo(row['path'],expected=row['fingerprint'],stop=stop);self.service.check(context,stop)
            result=record(self.store,scope,self.photo,raw,session,include_people=True)
            return result,'Complete','Declared author / roster IDs indexed locally.'
        self.task('Index declared photo identities',work,lambda result:self.detail.set(json.dumps(result,indent=2)))
    def task(self,operation,work,done=None):
        token=self.service.token()
        def completed(result):
            self.status.set(result['state']+': '+result['detail'])
            if result['state']=='Complete' and done:done(result['result'])
            self.history()
        self.start(lambda c,s,p:self.service.execute(operation,work,token=token,stop=s,progress=p),completed,mutation=True)
    def index(self):
        row=self.current();session=dict(getattr(self.app,'player_sessions',None).meta) if getattr(self.app,'player_sessions',None) else {}
        def work(scope,token,stop,progress):
            raw,_=read_photo(row['path'],expected=row['fingerprint'],stop=stop);self.service.check(token,stop)
            result=record(self.store,scope,self.photo,raw,session,adopt=False)
            return result,'Complete','Context indexed as evidence; manual links unchanged.'
        self.task('Photo context index',work,lambda r:self.detail.set(json.dumps(r,ensure_ascii=False,indent=2)))
    def export(self,sidecar):
        row=self.current();token=self.token()
        world=simpledialog.askstring('Export world','Exact world ID to include (blank excludes world):',initialvalue=row['world_id'],parent=self.window);self.verify(token)
        if world is None:return
        captured=simpledialog.askstring('Export capture time','Capture timestamp with UTC offset (blank excludes time):',initialvalue='',parent=self.window);self.verify(token)
        if captured is None:return
        fields=description(world.strip(),'',captured.strip())
        if not self.confirm('Review metadata to share',json.dumps(fields,ensure_ascii=False,indent=2)+'\n\nExport these exact fields? Other text, EXIF, roster and instance capabilities are excluded. Original encoded pixels are preserved in PNG copies.'):return
        self.verify(token)
        path=filedialog.asksaveasfilename(parent=self.window,defaultextension='.json' if sidecar else '.png',initialfile=Path(row['path']).stem+('-metadata.json' if sidecar else '-context.png'));self.verify(token)
        if not path:return
        def work(scope,context,stop,progress):
            raw,_=read_photo(row['path'],expected=row['fingerprint'],stop=stop)
            data=(json.dumps(fields,ensure_ascii=False,indent=2)+'\n').encode() if sidecar else metadata_copy(raw,fields)
            publish(path,data,lambda:self.service.check(context,stop))
            return str(path),'Complete','Metadata '+('sidecar' if sidecar else 'copy')+' published; original unchanged.'
        self.task('Compatible photo metadata export',work)
    def move(self):
        row=self.current();token=self.token();path=filedialog.asksaveasfilename(parent=self.window,title='Move selected original photo',initialfile=Path(row['path']).name);self.verify(token)
        if path:self.review_move(self.organizer.prepare(self.scope,self.photo,path))
    def enable_exports(self):
        row=self.current();token=self.token()
        if not row['source_id']:raise ValueError('Associate this photo with an approved source first.')
        folder=filedialog.askdirectory(parent=self.window,title='Choose compatible-copy output folder outside photo sources');self.verify(token)
        if not folder:return
        sidecar=self.confirm('Export format','Use JSON sidecars? Choose No for PNG copies. Both preserve originals.')
        self.verify(token)
        from photo_session_day import load
        grouping=load(self.owner.shell.store,self.scope)
        note=(f"\nSession-day folders: {grouping['timezone']}, day starts {grouping['cutoff']//60:02d}:{grouping['cutoff']%60:02d}. Capture time must be declared. This rule keeps these settings until explicitly re-enabled." if grouping['enabled'] else '\nFlat output folder; session-day grouping is off.')
        if not self.confirm('Enable watched compatible exports','For NEW imports from this source, export '+('JSON sidecars' if sidecar else 'PNG copies')+' to:\n'+folder+note+'\n\nOnly unambiguous declared world and capture time are included. Originals are preserved; unknown/conflicting metadata needs review. Enable this source rule?'):return
        self.verify(token)
        __import__('photo_compatible').configure(self.store,self.scope,row['source_id'],folder,sidecar=sidecar,grouping=grouping)
        self.status.set('Compatible export rule enabled. Enable the source watcher in Photos to process new imports.')
    def disable_exports(self):
        row=self.current();__import__('photo_compatible').disable(self.store,self.scope,row['source_id']);self.status.set('Compatible exports disabled for this source.')
    def trash(self):
        row=self.current();token=self.token()
        if not self.confirm('Move original to OS trash',row['path']+'\n\nSend this original to the operating-system trash? Restore it using your desktop trash and then relink the same bytes. Albums and notes remain in Eye.'):return
        self.verify(token)
        def work(scope,context,stop,progress):
            result=self.organizer.trash(scope,self.photo,expected=row['fingerprint'],check=lambda:self.service.check(context,stop))
            return result,'Complete','OS trash accepted the file; catalog reference retained.'
        self.task('Move photo to OS trash',work)
    def recover_move(self):
        self.current();row=self.table.selected();token=self.token()
        if not row:raise ValueError('Select an interrupted move receipt.')
        if not self.confirm('Recover interrupted move','Verify both recorded paths, then adopt the identical destination when present, or the identical source otherwise? This action never deletes either file.'):return
        self.verify(token)
        def work(scope,context,stop,progress):
            result=self.organizer.recover(scope,row,check=lambda:self.service.check(context,stop))
            return result,'Complete','Recovery adopted verified bytes; no physical file was deleted.'
        self.task('Recover interrupted photo move',work)
    def recovery(self):
        row=self.current();token=self.token();folder=Path(row['path']).parent/'VRC-Eye-Recovery'
        if not self.confirm('Move photo to recovery folder',str(folder)+'\n\nMove this original into an Eye recovery folder? This is reversible through the move journal; it is not permanent deletion or OS trash.'):return
        self.verify(token)
        from creator_projects import assert_no_links
        assert_no_links(folder);folder.mkdir(exist_ok=True)
        self.review_move(self.organizer.prepare(self.scope,self.photo,folder/Path(row['path']).name))
    def review_move(self,plan):
        token=self.token()
        if not self.confirm('Review physical photo move',plan['source']+'\n→ '+plan['destination']+'\n\nCopy, verify exact bytes, then remove the source? Collisions stop the operation. Albums and notes retain their identity.'):return
        self.verify(token)
        def work(scope,context,stop,progress):
            result=self.organizer.execute(plan,lambda:self.service.check(context,stop))
            return result,'Complete','Photo moved; catalog updated. Undo is available from move history.'
        self.task('Physical photo move',work)
    def history(self):
        if self.private_value or getattr(self.app,'_native_private',False):self.table.set([],lambda r:());return
        self.table.set(self.organizer.history(self.scope),lambda r:(r['updated'],r['state'],r['id']))
    def undo(self):
        self.current();row=self.table.selected()
        if not row:raise ValueError('Select a completed move.')
        self.review_move(self.organizer.prepare_undo(self.scope,row))
    def inspect_receipt(self):
        self.current();row=self.table.selected()
        if not row:raise ValueError('Select a receipt.')
        value=json.loads(row['payload']);self.detail.set('State: '+row['state']+'\nSource: '+value['source']+'\nDestination: '+value['destination']+'\nSHA-256: '+value['sha256']+'\nFor interrupted moves, inspect both files and use Photos → Relink identical file. No automatic deletion is attempted.')
    def clear_preview(self):
        self.preview=None
        if hasattr(self,'detail'):self.detail.set('Details cleared.')
        if hasattr(self,'table'):self.table.set([],lambda r:())
    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(200,self.tick)
    def close(self):
        if self.closed:return True
        super().close()
        if self in self.owner.windows:self.owner.windows.remove(self)
        self.app.root.after_cancel(self.timer);self.window.destroy();return True
