# ARC-10: bounds observations and reviewed prefab copies

Status: **partial, unreleased**. The desktop observation workflow has executable
Python coverage. The Unity correction workflow is supplied as source and has
not been compiled or executed in Unity here. No release, installer or desktop
executable was built. Existing ARC-02/03/06 work is retained.

## Desktop workflow

Open an imported GLB or authorized FBX in the existing avatar preview, then
choose **Bounds diagnostics…**. Select a mesh-owning node. Inspect imported and
currently displayed geometry, or explicitly select one prepared clip/take and
an endpoint-inclusive range. FBX ranges must first be prepared in the Animation
timeline. Sampling pauses playback and leaves the displayed pose unchanged.

The report compares imported, displayed and sampled bounds, checks whether the
imported reference covers the observations, and proposes their union plus finite
per-axis margins. Margins apply to both sides. Each pose's vertices are measured
using that pose's node inverse, including negative/nonuniform transforms. The
world AABB is never inverse-transformed to approximate these observations.
Zero/near-singular transforms stop the operation.

Review and export produces a new JSON file with the imported-byte SHA-256,
selected node, coordinate space, requested and effective sample times, every
sample box, margins, proposed box and limitations. Existing files and symlink
targets are refused. Changed account, avatar, privacy, safe/demo context, pose,
settings or source cancels/invalidates the review. This records an in-memory
import snapshot; it does not certify that an external source file is still
unchanged after import.

Limits: one node and one clip per desktop observation, at most 128 samples and
four million vertex visits, with cancellation and a 15-second cooperative
sampling budget. FBX frame playback holds the preceding prepared sample; both
requested and effective times appear in the report. GLB coordinates use exported
units; this FBX importer normalizes units to meters. The desktop GLB/FBX payload
does **not** provide Unity renderer culling bounds or its root-bone frame. It
does not apply any correction to an avatar, mesh or renderer.

## Unity correction workflow

In Unity **2022.3**, install the Toolkit source and run its EditMode gate first.
Open **VRC Eye → Renderer Bounds Copies**. Choose an authorized, saved `.prefab`
root under `Assets` and one `SkinnedMeshRenderer` inside it. A readable saved
mesh and explicit root bone inside the prefab are required. Source scene/model
assets, missing or repeated component types, ambiguous names, unsaved sources,
external/missing bones and unsupported dependency paths are rejected.

1. Choose zero to eight saved local-transform/blendshape clip ranges and press
   **Observe imported pose and selected samples**. Each range has up to 128
   endpoint-inclusive samples over at most 60 seconds; the total is bounded to
   257 poses and eight million baked vertices, with a 20-second cooperative
   sampling budget and cancelable progress.
2. Compare mesh-local bounds, the mesh box transformed into the imported
   root-bone frame, stored renderer bounds and the union of sampled vertices.
   Each listed pose has a box, clip label and exact seconds. The report includes
   skin quality, the offscreen update setting and a source/dependency fingerprint.
3. Choose per-side XYZ margins over the union with existing bounds, or explicit
   root-bone-local center and size. Finite explicit values must contain the
   sampled geometry and imported mesh box. Inspect the exact proposal.
4. Review and create a separate prefab under `Assets/VRC Eye Repairs`. The copy
   is unpacked from nested/variant links. Only the selected renderer's serialized
   bounds and dirty-bounds flag are changed; a new root asset name is permitted.
   Reloaded values and internal bone/component references are checked against the
   original graph. External asset references remain shared. No scene assignment
   or original renderer is changed by this operation.
5. Inspect `bounds-review.txt` and **Repair Copy History** before manually using
   the copy. ARC-19 records durable intent, sample scope, source fingerprint and
   output/meta hashes. Interrupted operations retain their outputs for inspection.

Sampling builds an inactive, data-only hierarchy of transforms and one skinned
renderer. It does not clone user behaviours, run an Animator, dispatch events or
evaluate controllers. Supported curves are local position/scale, quaternion or
raw Euler rotation, and the selected renderer's blendshape weights. Other-renderer
blendshape channels are counted but ignored. Events are counted but not executed.
Object-reference swaps, missing targets, humanoid/muscle clips, mixed Euler and
quaternion targets, script/constraint bindings and other unsupported channels
stop sampling. No retargeting is inferred.

Unity's skinned bounds inspector uses the actual root bone's frame. This workflow
requires an explicit root bone because the native implicit fallback is not a
public API. `BakeMesh(..., false)` supplies renderer-transform-local vertices;
each vertex is mapped through that sample's renderer-to-root-bone matrix. Mesh
box comparisons transform all eight corners. Corrections use the 2022.3 skinned
renderer's serialized `m_AABB` and `m_DirtyAABB`, and verify exact save/reload;
generic runtime `Renderer.localBounds` overrides are not a prefab persistence
mechanism. MeshRenderer corrections and other Unity versions are outside this
initial scope. `updateWhenOffscreen` is retained and reported because Unity can
recompute bounds when it is enabled.

The observation expires after five minutes. Source objects, mesh data, clips,
dependency bytes and project/quality context are checked again at review and
copy boundaries. Existing project import/editor callbacks can run during prefab
copy/load/save; unexpected source or copy changes fail verification and interrupt
the receipt. This is an editor workflow, not a sandbox for untrusted Unity projects.

## Qualification and limits

Finite observations do not establish complete bounds for between-sample motion,
unselected clips, runtime controllers, retargeting, IK, PhysBones, cloth,
constraints, custom scripts or shader deformation. No claimed FPS improvement
follows solely from a bounds change.

`tests/test_bounds_arc10.py` covers numeric spaces, real GLB skin/morph sampling,
prepared native FBX held-frame scope, margins, invalid/singular data, budgets,
cancellation, immutable sources and exclusive exports. `test_bounds_ui_arc10.py`
exercises real UI callbacks with headless widgets, stale jobs, context/pose/settings
changes, modal export reviews and timeline integration. These are not graphical
desktop acceptance tests.

Thirteen new `EyeBoundsTests.cs` methods cover native skin/root-bone space,
negative/nonuniform transforms, moving bones and blendshapes, exact copy/reload,
source byte preservation, remapped bones, explicit bounds validation, changed
mesh/clip evidence, singular transforms, ignored events, unsupported bindings,
margins/ranges and source mutation during import. **They are unrun here.** C#
syntax parsing is recorded separately and does not establish compilation or API
compatibility. Run the entire existing Toolkit EditMode suite plus these tests
in a disposable authorized Unity 2022.3 project; then qualify real creator
prefabs, nested/variant prefabs, intended platforms and visual culling behavior.

Remaining ARC-10 gates: actual Unity import/compile/EditMode execution, broader
creator pose/clip fixtures, graphical desktop acceptance, native culling and
reload checks under supported project configurations. The area stays partial.

## Primary implementation references

- [Unity 2022.3 BakeMesh](https://docs.unity.cn/2022.3/Documentation/ScriptReference/SkinnedMeshRenderer.BakeMesh.html)
- [Unity Renderer.localBounds](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Renderer-localBounds.html)
- [Unity 2022.3 skinned renderer inspector source](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Editor/Mono/Inspector/SkinnedMeshRendererEditor.cs)
- [Unity 2022.3 renderer bindings](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Runtime/Export/Graphics/GraphicsRenderers.bindings.cs)

These references informed coordinate-space and persistence choices. They do not
replace executing the qualification gate on the target Unity version.
