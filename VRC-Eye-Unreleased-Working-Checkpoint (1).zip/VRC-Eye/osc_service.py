"""One bounded, reviewed action scheduler for all VRC Eye OSC clients.

Only this service owns the UDP transport. Metadata, observations, discovery and
source labels never confer write permission. No action is replayed on reconnect.
"""
from collections import OrderedDict, deque
import copy
import ipaddress
import math
import time
import uuid

from osc_registry import EndpointRegistry, SCOPES, same_arguments, typed_args, valid_address

MAX_ACTIONS = 256
MAX_QUEUE = 128
MAX_REVIEWS = 128
MAX_OBSERVATIONS = 2048
MAX_TRACE = 512
HEALTH_SECONDS = 15.0


def _finite(value, minimum, maximum, label):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(label + " is outside its finite supported range.")
    return float(value)


def _label(value, label):
    if not isinstance(value, str) or not 1 <= len(value) <= 128 or any(ord(c) < 32 for c in value):
        raise ValueError(label + " must be a short local identifier.")
    return value


class OSCService:
    def __init__(self, transport=None, clock=time.monotonic, registry=None):
        if transport is None:
            from osc_transport import SharedOSC
            transport = SharedOSC(clock=clock)
        self.transport = transport
        self.clock = clock
        self.registry = registry or EndpointRegistry()
        self.generation = 0
        self.avatar_generation = 0
        self.profile_revision = ""
        self.permission_revision = 0
        self.instance_id = ""
        self.account_id = ""
        self.session = ""
        self.avatar_id = ""
        self.connected = False
        self.mode = "observation"
        self.message = "Observation only. No control permissions granted."
        self.trusted_source = None
        self._source_port = None
        self._target_host = "127.0.0.1"
        self._transport_generation = None
        self._health_at = None
        self._grants = {}
        self._reviews = OrderedDict()
        self._actions = OrderedDict()
        self._queue = OrderedDict()
        self._dispatch_guards = {}
        self._owners = {}
        self._observations = OrderedDict()
        self._trace = deque(maxlen=MAX_TRACE)
        self._subscribers = []
        self._ingress_subscribers = []
        self._sequence = 0
        self._stopped = False
        self.invalid = 0
        self.dropped = 0
        self.cleanup_unverified = False

    @property
    def state_guard(self):
        return (self.instance_id, self.generation, self.avatar_generation, self.profile_revision,
                self.permission_revision, self.registry.revision, self.account_id, self.session)

    @property
    def context_guard(self):
        """Active controllers check permissions separately from session identity."""
        return (self.instance_id, self.generation, self.avatar_generation, self.profile_revision,
                self.registry.revision, self.account_id, self.session)

    @property
    def armed(self):
        return self.connected and not self._stopped and bool(self._grants)

    @property
    def permissions(self):
        return {source: tuple(sorted(scopes)) for source, scopes in self._grants.items()}

    def _event(self, category, detail, **fields):
        # Payloads (chat, poses, avatar IDs and paths) are intentionally absent.
        row = {"time": self.clock(), "category": category, "detail": str(detail)[:240],
               "generation": self.generation, "avatar_generation": self.avatar_generation}
        row.update(fields)
        self._trace.append(row)

    def connect(self, receive_port=9001, target_port=9000, target_host="127.0.0.1",
                allow_lan=False, source_port=None, instance_id="", **config):
        if self.connected:
            self.disconnect()
        if source_port is not None and (type(source_port) is not int or not 1 <= source_port <= 65535):
            raise ValueError("Observed source port must be a valid UDP port.")
        self.generation += 1
        self._grants.clear()
        self._reviews.clear()
        self._observations.clear()
        self.avatar_id = ""
        self.trusted_source = None
        self._source_port = source_port
        self._target_host = str(target_host)
        self.instance_id = str(instance_id)[:128]
        self._health_at = None
        self._stopped = False
        self.mode = "observation"
        self.transport.start(receive_port=receive_port, target_port=target_port,
                             target_host=target_host, allow_lan=allow_lan, **config)
        self._transport_generation = getattr(self.transport, "generation", None)
        self.connected = True
        self.message = "Send configured; awaiting passive observations. Controls are read-only."
        self._event("connection", "Receiving endpoint opened; no actions transmitted")
        return self.snapshot()

    def disconnect(self):
        self.stop_controls("OSC disconnected")
        try:
            self.transport.stop()
        finally:
            self.connected = False
            self._health_at = None
            self.trusted_source = None
            self.generation += 1
            self._observations.clear()
            self.avatar_id = ""
            self.message = "Disconnected. No actions will replay on reconnect."
            self._event("connection", "Disconnected")

    close = disconnect

    def set_context(self, instance_id=None, avatar_id=None, profile_revision=None,
                    account_id=None, session=None, force_avatar=False, **unused):
        if instance_id is None and "instance" in unused:
            instance_id = unused["instance"]
        changes = {key: value for key, value in (("instance_id", instance_id), ("avatar_id", avatar_id),
            ("profile_revision", profile_revision), ("account_id", account_id), ("session", session))
            if value is not None and getattr(self, key) != str(value)}
        if force_avatar and avatar_id is not None:
            changes["avatar_id"] = avatar_id
        if not changes:
            return False
        # An observed avatar transition has already happened remotely. Never
        # neutralize an old custom parameter on the newly loaded avatar.
        if "avatar_id" in changes or set(changes) & {"instance_id", "account_id", "session"}:
            for address, owner in list(self._owners.items()):
                if owner.get("custom"):
                    self._owners.pop(address, None)
        self.stop_controls("Session, avatar or profile changed")
        if "avatar_id" in changes:
            self.avatar_generation += 1
            self.registry.clear_parameters()
        if set(changes) & {"instance_id", "account_id", "session"}:
            self.generation += 1
            self.avatar_id = ""
            self.trusted_source = None
            self.registry.clear_parameters()
        self._health_at = None
        self._observations.clear()
        for key, value in changes.items():
            setattr(self, key, str(value))
        self.message = "Context changed. Review compatibility and rearm controls."
        self._event("context", "Pending controls invalidated")
        return True

    def mark_health(self, alive=True):
        """A selected service's successful health check can refresh stable values."""
        self._health_at = self.clock() if alive and self.connected else None

    def arm(self, scopes, source="manual", reviewed=False, public=False):
        if not reviewed:
            raise ValueError("Control permission requires explicit local review.")
        if not self.connected:
            raise ValueError("Connect the shared OSC receiver before granting controls.")
        source = _label(source, "Source")
        if isinstance(scopes, str):
            scopes = (scopes,)
        if not isinstance(scopes, (list, tuple, set, frozenset)) or len(scopes) > 512:
            raise ValueError("Select a bounded list of permission scopes.")
        selected = set(scopes)
        if public:
            selected.add("avatar.public")
        if not selected or any(scope not in SCOPES and not (valid_address(scope) and self.registry.get(scope)) for scope in selected):
            raise ValueError("Permissions must be known scopes or exact described addresses.")
        if len(self._grants) >= 128 and source not in self._grants:
            raise ValueError("Too many active source permissions.")
        if selected.issubset(self._grants.get(source, set())) and not self._stopped:
            return self.permissions[source]
        self._grants.setdefault(source, set()).update(selected)
        self.permission_revision += 1
        self._reviews.clear()
        self._stopped = False
        self.mode = "coexistence" if self.mode == "observation" else self.mode
        self.message = "Reviewed controls armed. Direct external traffic remains outside this policy."
        self._event("permission", "Selected control scopes granted", source=source)
        return self.permissions[source]

    def is_granted(self, source, address):
        item = self.registry.get(address)
        scopes = self._grants.get(source, set())
        return bool(item and not self._stopped and (address in scopes or item.permission in scopes)
                    and (not item.public or "avatar.public" in scopes))

    def revoke(self, source=None, scopes=None):
        sources = list(self._grants) if source is None else [source]
        changed = False
        for name in sources:
            if scopes is None:
                changed = self._grants.pop(name, None) is not None or changed
                self.cancel_source(name, "Permission revoked")
            elif name in self._grants:
                before = set(self._grants[name])
                self._grants[name].difference_update((scopes,) if isinstance(scopes, str) else scopes)
                changed = self._grants[name] != before or changed
                if not self._grants[name]:
                    self._grants.pop(name)
                for action_id, action in list(self._queue.items()):
                    if action["source"] == name and not self.is_granted(name, action["address"]):
                        self.cancel(action_id, "Permission revoked")
                for address, owner in list(self._owners.items()):
                    if owner["source"] == name and not self.is_granted(name, address):
                        self._cleanup(address, "Permission revoked")
        if not changed:
            return
        self.permission_revision += 1
        self._reviews.clear()
        self._event("permission", "Control permission revoked", source=source or "all")

    def _priority(self, source, requested):
        priority = 80 if source in ("manual", "desktop", "avatar-link") else 60 if source.startswith("preset:") else 40 if source.startswith("rule:") else 20
        if source.startswith("protective:") and "protective" in self._grants.get(source, ()):
            priority = 100
        if requested is not None:
            requested = _finite(requested, 0, 100, "Priority")
            priority = min(priority, requested)
        return priority

    def _check(self, address, args, source):
        self._check_transport()
        if not self.connected or self._stopped:
            raise ValueError("OSC controls are stopped or disconnected.")
        item = self.registry.validate(address, args)
        if not self.is_granted(source, address):
            raise PermissionError("This source has no reviewed permission for the requested control.")
        if item.custom and not self.avatar_id:
            raise ValueError("Observe the current avatar before writing custom parameters.")
        if item.custom and (self._health_at is None or self.clock() - self._health_at > HEALTH_SECONDS):
            raise ValueError("Current avatar service health is unknown. Recheck the selected OSCQuery service or receive fresh data.")
        return item

    def review(self, address, args, source="manual", owner=None, duration=None,
               delay=0.0, ttl=5.0, priority=None, **options):
        source = _label(source, "Source")
        owner = _label(owner or source, "Owner")
        args = typed_args(args)
        try:
            item = self._check(address, args, source)
        except (ValueError, PermissionError) as exc:
            self._event("blocked", str(exc), source=source, address=str(address)[:256])
            raise
        delay = _finite(delay, 0, 60, "Delay")
        ttl = _finite(ttl, .02, 120, "Expiration")
        if delay >= ttl:
            raise ValueError("Action expiration must exceed its delay.")
        if duration is not None:
            duration = _finite(duration, .02, 30, "Hold duration")
        elif item.behavior == "pulse":
            duration = .15
        elif item.behavior == "continuous":
            duration = .3 if item.cleanup is not None else 1.0
        else:
            duration = 30.0
        now = self.clock()
        token = uuid.uuid4().hex
        review = {"token": token, "address": address, "args": args, "source": source, "owner": owner,
            "duration": duration, "delay": delay, "expires_at": now + ttl, "reviewed_at": now,
            "guard": self.state_guard, "priority": self._priority(source, priority),
            "permission": item.permission, "behavior": item.behavior,
            "evidence": item.evidence, "confirmation": item.confirmation}
        self._reviews[token] = copy.deepcopy(review)
        while len(self._reviews) > MAX_REVIEWS:
            self._reviews.popitem(last=False)
        return review

    def submit(self, review):
        if not isinstance(review, dict):
            raise ValueError("A current review is required.")
        saved = self._reviews.pop(review.get("token"), None)
        if saved is None or saved != review:
            raise ValueError("Review is missing, changed or already used.")
        if saved["guard"] != self.state_guard or self.clock() >= saved["expires_at"]:
            raise ValueError("Review expired after a session, metadata or permission change.")
        item = self._check(saved["address"], saved["args"], saved["source"])
        if item.behavior == "continuous":
            for action_id, queued in list(self._queue.items()):
                if queued["address"] == saved["address"] and queued["source"] == saved["source"]:
                    self.cancel(action_id, "Superseded by the latest value")
        if len(self._queue) >= MAX_QUEUE:
            self.dropped += 1
            raise ValueError("OSC action queue is full; nothing was sent.")
        self._sequence += 1
        action = {key: copy.deepcopy(value) for key, value in saved.items() if key != "token"}
        action.update(id=uuid.uuid4().hex, status="scheduled", requested_at=saved["reviewed_at"],
                      scheduled_at=self.clock() + saved["delay"], sequence=self._sequence,
                      context_guard=self.context_guard,
                      sent_at=None, observed_at=None, detail="Validated and scheduled; not yet sent")
        self._actions[action["id"]] = action
        self._queue[action["id"]] = action
        self._trim_actions()
        self._event("scheduled", "Reviewed action scheduled", action_id=action["id"],
                    address=action["address"], source=action["source"])
        return copy.deepcopy(action)

    def send_now(self, review):
        action = self.submit(review)
        return self.flush_action(action["id"])

    def flush_action(self, action_id):
        action = self._queue.get(action_id)
        self._expire_owners()
        if action is None:
            result = self.action(action_id)
            if result and result["status"] in ("sent", "matching_state_observed"):
                return result
            raise ValueError("The requested action is no longer scheduled.")
        if action["scheduled_at"] > self.clock():
            raise ValueError("Delayed actions cannot be transmitted before their reviewed time.")
        self._send_action(action)
        result = self.action(action_id)
        if result["status"] != "sent":
            raise ValueError(result["detail"])
        return result

    def _trim_actions(self):
        for key in list(self._actions):
            if len(self._actions) <= MAX_ACTIONS:
                break
            if key not in self._queue and not any(o["action_id"] == key for o in self._owners.values()):
                del self._actions[key]

    def action(self, action_id):
        row = self._actions.get(action_id)
        return copy.deepcopy(row) if row else None

    def cancel(self, action_id, reason="Cancelled by user"):
        self._dispatch_guards.pop(action_id, None)
        action = self._queue.pop(action_id, None)
        if action:
            action.update(status="cancelled", detail=str(reason)[:240])
            self._event("cancelled", reason, action_id=action_id)
        # Never discard an owed release when cancellation follows a send.
        for address, owner in list(self._owners.items()):
            if owner["action_id"] == action_id:
                self._cleanup(address, reason)
        return self.action(action_id)

    def guard_dispatch(self, action_id, predicate):
        """Bind a local, nonblocking predicate to one pending action only.

        This is an in-process producer hook, never a serialized rule or grant.
        A failing predicate can only prevent transmission, never authorize it.
        """
        if action_id not in self._queue or not callable(predicate):
            raise ValueError("A pending action and local dispatch predicate are required.")
        self._dispatch_guards[action_id] = predicate

    def cancel_source(self, source, reason="Source stopped"):
        for action_id, action in list(self._queue.items()):
            if action["source"] == source:
                self.cancel(action_id, reason)
        for address, owner in list(self._owners.items()):
            if owner["source"] == source:
                self._cleanup(address, reason)

    def release_owner(self, owner, reason="Owner released control"):
        for action_id, action in list(self._queue.items()):
            if action["owner"] == owner:
                self.cancel(action_id, reason)
        for address, row in list(self._owners.items()):
            if row["owner"] == owner:
                self._cleanup(address, reason)

    def release_address(self, address, owner=None, source=None, reason="Control released"):
        """Release one matching ownership record without disturbing siblings."""
        for action_id, action in list(self._queue.items()):
            if action["address"] == address and (owner is None or action["owner"] == owner) and (source is None or action["source"] == source):
                self.cancel(action_id, reason)
        row = self._owners.get(address)
        if row and (owner is None or row["owner"] == owner) and (source is None or row["source"] == source):
            self._cleanup(address, reason)
            return True
        return False

    def release_all(self, reason="Owned controls released"):
        """Cancel pending assertions and clean owned controls, preserving grants.

        Intended for an already reviewed local protective sequence. It does not
        resume sources or restore values, and never manufactures permissions.
        """
        for action in self._queue.values():
            action.update(status="cancelled", detail=str(reason)[:240])
        self._queue.clear()
        self._dispatch_guards.clear()
        self._reviews.clear()
        for address in list(self._owners):
            self._cleanup(address, reason)

    def stop_controls(self, reason="Stop Controls selected"):
        self._stopped = True
        # First block producers and cancel every queued assertion, then release.
        for action in self._queue.values():
            action.update(status="cancelled", detail=str(reason)[:240])
        self._queue.clear()
        self._dispatch_guards.clear()
        self._reviews.clear()
        self._grants.clear()
        self.permission_revision += 1
        for address in list(self._owners):
            self._cleanup(address, reason)
        self.mode = "observation"
        self.message = "Controls stopped. Owned releases requested; delivery is unverified."
        self._event("stopped", reason)

    suspend = stop_controls

    def _cleanup(self, address, reason):
        owner = self._owners.pop(address, None)
        if owner is None:
            return
        cleanup = owner.get("cleanup")
        cleanup_address = address
        if address == "/dolly/PlayDelayed":
            cleanup, cleanup_address = (False,), "/dolly/Play"
        if cleanup is None or owner["args"] == cleanup:
            return
        if owner.get("custom"):
            try:
                self.registry.validate(address, cleanup)
            except ValueError:
                self._event("cleanup_unavailable", "Custom cleanup omitted because its compatible contract is no longer available", address=address)
                return
        self.cleanup_unverified = True
        try:
            if not self.connected:
                raise OSError("Transport unavailable")
            self.transport.send(cleanup_address, cleanup)
            self._event("cleanup", "Owned release sent; delivery unverified", address=cleanup_address,
                        owner=owner["owner"], action_id=owner["action_id"])
        except Exception:
            self._event("cleanup_failed", "Owned release could not be sent; use VRChat controls to recover",
                        address=cleanup_address, owner=owner["owner"], action_id=owner["action_id"])

    def _expire_owners(self):
        now = self.clock()
        for address, owner in list(self._owners.items()):
            if now >= owner["expires_at"]:
                self._cleanup(address, "Bounded ownership expired")

    def _send_action(self, action):
        self._queue.pop(action["id"], None)
        predicate = self._dispatch_guards.pop(action["id"], None)
        if predicate is not None:
            try:
                valid = predicate() is True
            except Exception:
                valid = False
            if not valid:
                action.update(status="cancelled", detail="Producer context changed before transmission")
                return
        now = self.clock()
        if now >= action["expires_at"]:
            action.update(status="expired", detail="Action expired before transmission")
            return
        if action["context_guard"] != self.context_guard:
            action.update(status="cancelled", detail="Context or metadata changed before transmission")
            return
        try:
            item = self._check(action["address"], action["args"], action["source"])
            group = item.conflict_group or item.address
            conflicts = [(address, row) for address, row in self._owners.items()
                         if row["group"] == group and (row["owner"], row["source"]) !=
                         (action["owner"], action["source"])]
            if any(row["priority"] >= action["priority"] for _, row in conflicts):
                raise ValueError("Another controller owns this control group with equal or higher priority.")
            for address, _ in conflicts:
                self._cleanup(address, "Ownership transferred after reviewed override")
            previous = self._owners.get(item.address)
            if previous and item.behavior == "pulse" and action["args"] != item.cleanup:
                self._cleanup(item.address, "Release before a new press")
            self.transport.send(item.address, action["args"])
            action.update(status="sent", sent_at=now, detail="Sent locally; remote execution is not confirmed")
            if item.cleanup is not None and action["args"] == item.cleanup:
                self._owners.pop(item.address, None)
            else:
                self._owners[item.address] = {"group": group, "address": item.address,
                    "owner": action["owner"], "source": action["source"], "action_id": action["id"],
                    "args": action["args"], "value": action["args"][0] if len(action["args"]) == 1 else action["args"],
                    "cleanup": item.cleanup, "custom": item.custom,
                    "priority": action["priority"], "started_at": now, "expires_at": now + action["duration"]}
            self._event("sent", "Local send completed; outcome unconfirmed", address=item.address,
                        source=action["source"], action_id=action["id"])
        except Exception as exc:
            action.update(status="failed", detail=str(exc)[:240])
            self._event("failed", action["detail"], address=action["address"], action_id=action["id"])

    def subscribe(self, callback):
        if not callable(callback) or len(self._subscribers) >= 64:
            raise ValueError("A bounded observation callback is required.")
        self._subscribers.append(callback)
        def unsubscribe():
            if callback in self._subscribers:
                self._subscribers.remove(callback)
        return unsubscribe

    def subscribe_ingress(self, callback):
        """Subscribe to untrusted ingress, before selected-VRChat source filtering.

        This callback grants no authority. Managed routes must check the exact
        reviewed network endpoint and use ordinary reviewed outgoing actions.
        """
        if not callable(callback) or len(self._ingress_subscribers) >= 64:
            raise ValueError("A bounded ingress callback is required.")
        self._ingress_subscribers.append(callback)
        def unsubscribe():
            if callback in self._ingress_subscribers:
                self._ingress_subscribers.remove(callback)
        return unsubscribe

    def _source_matches(self, source):
        if source is None:
            return self.trusted_source is None
        if not isinstance(source, (tuple, list)) or len(source) != 2:
            return False
        try:
            ip = ipaddress.ip_address(source[0])
            target = ipaddress.ip_address(self._target_host)
        except (ValueError, TypeError):
            return False
        if not (ip == target or ip.is_loopback and target.is_loopback):
            return False
        if self._source_port is not None and source[1] != self._source_port:
            return False
        return self.trusted_source is None or tuple(source) == self.trusted_source

    def observe(self, address, args, source=None, generation=None, received_at=None):
        if not self.connected or generation is not None and generation != self._transport_generation:
            self.dropped += 1
            return False
        if not valid_address(address) or not self._source_matches(source):
            self.dropped += 1
            return False
        try:
            args = typed_args(args)
            if self.registry.get(address):
                self.registry.validate(address, args, write=False)
        except ValueError:
            self.invalid += 1
            return False
        if address == "/avatar/change":
            if source is not None and self.trusted_source is None:
                self.trusted_source = tuple(source)
            # Same-ID reloads can contain a newly built parameter schema. An
            # avatar initialization event is a boundary even if its ID repeats.
            self.set_context(avatar_id=args[0], force_avatar=True)
        if self.trusted_source is None and source is not None and self._source_port is not None:
            self.trusted_source = tuple(source)
        now = self.clock()
        # A packet cannot claim a future freshness time supplied by a route.
        received = now if received_at is None else min(now, float(received_at))
        if not math.isfinite(received) or received < now - 120:
            self.dropped += 1
            return False
        trusted = source is None or self.trusted_source is not None and tuple(source) == self.trusted_source
        if trusted:
            self._health_at = now
        old = self._observations.get(address)
        changed = not old or not same_arguments(old["args"], args)
        row = {"address": address, "args": args, "value": args[0] if len(args) == 1 else args,
               "received_at": received, "last_changed_at": received if changed else old["last_changed_at"],
               "source": tuple(source) if source is not None else None, "trusted": trusted,
               "generation": self.generation, "avatar_generation": self.avatar_generation,
               "live": trusted, "changed": changed}
        self._observations[address] = row
        self._observations.move_to_end(address)
        while len(self._observations) > MAX_OBSERVATIONS:
            self._observations.popitem(last=False)
        item = self.registry.get(address)
        if trusted and item and item.behavior not in ("pulse", "publication"):
            for action in reversed(tuple(self._actions.values())):
                same_context = (action["guard"][:4] == self.state_guard[:4]
                                and action["guard"][5:] == self.state_guard[5:])
                if same_context and action["address"] == address and action["status"] == "sent" and same_arguments(action["args"], args) and received >= action["sent_at"]:
                    action.update(status="matching_state_observed", observed_at=received,
                                  detail="Requested state observed; causation and lasting outcome are unproven")
                    break
        for callback in tuple(self._subscribers):
            try:
                callback(address, args, copy.deepcopy(row))
            except Exception:
                self._event("subscriber", "Observation subscriber failed")
        return True

    def observation(self, address):
        row = self._observations.get(address)
        if not row:
            return None
        result = copy.deepcopy(row)
        result["live"] = bool(self.connected and row["trusted"] and self._health_at is not None
                              and self.clock() - self._health_at <= HEALTH_SECONDS)
        result["value_age"] = max(0., self.clock() - row["last_changed_at"])
        result["service_health_age"] = None if self._health_at is None else max(0., self.clock() - self._health_at)
        return result

    def _check_transport(self):
        """A stopped receive worker invalidates the selected live session."""
        if self.connected and getattr(self.transport, "running", True) is False:
            self.disconnect()
            self.message = "OSC receive transport stopped unexpectedly. Reconnect and review controls."
            self._event("connection_lost", "Receive transport stopped; queued work and permissions revoked")
            return False
        return self.connected

    def tick(self):
        self._check_transport()
        if self.connected:
            try:
                packets = self.transport.drain(limit=128)
            except TypeError:
                packets = self.transport.drain()
            message_budget = 256
            for packet in tuple(packets)[:128]:
                for message in packet.messages[:64]:
                    if message_budget <= 0:
                        self.dropped += 1
                        continue
                    message_budget -= 1
                    if packet.generation == self._transport_generation and valid_address(message.address):
                        try:
                            args = typed_args(message.args)
                            ingress = {"address": message.address, "args": args, "source": packet.source,
                                "received_at": packet.received_at, "generation": self.generation,
                                "avatar_generation": self.avatar_generation, "live": True, "trusted": False}
                            for callback in tuple(self._ingress_subscribers):
                                try:
                                    callback(message.address, args, copy.deepcopy(ingress))
                                except Exception:
                                    self._event("subscriber", "Managed ingress subscriber failed")
                        except ValueError:
                            self.invalid += 1
                    self.observe(message.address, message.args, source=packet.source,
                        generation=packet.generation, received_at=packet.received_at)
        self._expire_owners()
        now = self.clock()
        for key, review in list(self._reviews.items()):
            if review["expires_at"] <= now:
                self._reviews.pop(key, None)
        # Urgent release path above is outside this ordinary output budget.
        ready = sorted((row for row in self._queue.values() if row["scheduled_at"] <= now),
                       key=lambda row: (-row["priority"], row["sequence"]))
        for action in ready[:32]:
            if action["id"] in self._queue:
                self._send_action(action)
        self._trim_actions()
        return self.snapshot()

    @staticmethod
    def _redact_action(row):
        row = copy.deepcopy(row)
        if row.get("address", "").startswith(("/chatbox/", "/tracking/", "/dolly/Import", "/avatar/change")):
            row["args"] = ("[redacted]",)
        return row

    def snapshot(self):
        return {"connected": self.connected, "armed": self.armed, "mode": self.mode,
            "state": "Controls armed" if self.armed else "Read-only ready" if self.connected else "Disconnected",
            "message": self.message, "generation": self.generation, "avatar_generation": self.avatar_generation,
            "avatar_id": self.avatar_id, "profile_revision": self.profile_revision,
            "permission_revision": self.permission_revision, "instance_id": self.instance_id,
            "receive_port": getattr(self.transport, "receive_port", 0),
            "target_port": getattr(self.transport, "target_port", 0), "source": self.trusted_source,
            "permissions": self.permissions, "owners": copy.deepcopy(list(self._owners.values())),
            "observations": {address: self.observation(address) for address in self._observations},
            "actions": [self._redact_action(row) for row in self._actions.values()],
            "traces": copy.deepcopy(list(self._trace)), "queue_size": len(self._queue),
            "invalid": self.invalid + getattr(self.transport, "invalid", 0),
            "dropped": self.dropped + getattr(self.transport, "dropped", 0),
            "cleanup_unverified": self.cleanup_unverified,
            "firewall_coverage": "Only traffic routed through VRC Eye; direct application traffic is outside coverage"}
