"""Explicit optional MIDI output for the finite VRC Eye creator helper protocol.

MIDI is transport, not authorization. No ports are enumerated or opened until
the user asks. Requires mido + python-rtmidi and a user-configured MIDI route.
"""
from __future__ import annotations

import importlib
import threading
import uuid

from creator_helper import HelperError


def encode_request(request):
    """Seven control-change messages; one request ID and an atomic commit marker.

    CC16=protocol header(95), 17/18/19=request ID low/mid/high 7 bits,
    CC20=declared logical control number, CC21=value, CC22=commit(85).
    Interrupted or out-of-order frames are discarded by the supplied helper.
    """
    if not isinstance(request, dict) or request.get('scope') not in ('local', 'helper'):
        raise HelperError('MIDI adapter permits declared local/helper actions only.')
    route = request.get('midi')
    if not isinstance(route, dict) or set(route) != {'channel', 'number'}:
        raise HelperError('A finite declared MIDI route is required.')
    channel, number = route.get('channel'), route.get('number')
    wire, value = request.get('wire_id'), request.get('encoded_value')
    for key, datum, low, high in (('channel', channel, 0, 15), ('number', number, 1, 127),
                                  ('wire ID', wire, 1, (1 << 21) - 1), ('value', value, 0, 127)):
        if type(datum) is not int or not low <= datum <= high:
            raise HelperError('Invalid MIDI ' + key + '.')
    values = (95, wire & 127, (wire >> 7) & 127, (wire >> 14) & 127, number, value, 85)
    return [dict(type='control_change', channel=channel, control=16 + index, value=datum)
            for index, datum in enumerate(values)]


class MIDIAdapter:
    def __init__(self, *, backend=None):
        self._backend = backend
        self._port = None
        self.port_name = ''
        self._lock = threading.RLock()
        self._used = set()
        self._transport_id = None

    @property
    def connected(self):
        return self._port is not None

    @property
    def transport_id(self):
        """Opaque identity for this particular opening, invalidated on every close."""
        with self._lock:
            return self._transport_id

    def _load(self):
        if self._backend is None:
            try:
                self._backend = importlib.import_module('mido')
            except ImportError as exc:
                raise HelperError('MIDI support is unavailable. Start.cmd prepares its packages automatically; reopen it online to retry missing dependencies.') from exc
        return self._backend

    def list_ports(self):
        """Explicit device enumeration. Never selects a default device."""
        try:
            names = self._load().get_output_names()
        except HelperError:
            raise
        except Exception as exc:
            raise HelperError('MIDI output enumeration is unavailable: ' + type(exc).__name__) from exc
        if not isinstance(names, (list, tuple)) or len(names) > 256:
            raise HelperError('MIDI device list is invalid or too large.')
        return [name for name in names if isinstance(name, str) and 0 < len(name) <= 512]

    def open(self, port, *, consent=False):
        if consent is not True or not isinstance(port, str) or not port:
            raise HelperError('Explicitly select and enable a MIDI output.')
        with self._lock:
            if port not in self.list_ports():
                raise HelperError('Selected MIDI output is no longer available.')
            self.close()
            try:
                self._port = self._load().open_output(port)
                self.port_name = port
                self._transport_id = 'midi:' + uuid.uuid4().hex
            except Exception as exc:
                self._port, self.port_name = None, ''
                self._transport_id = None
                raise HelperError('Could not open the selected MIDI output: ' + type(exc).__name__) from exc

    def send(self, request):
        frames = encode_request(request)
        request_id = request.get('id')
        if not isinstance(request_id, str) or len(request_id) != 32:
            raise HelperError('A reviewed command ID is required.')
        with self._lock:
            if self._port is None:
                raise HelperError('No MIDI output is explicitly enabled.')
            if request.get('transport_id') is not None and request['transport_id'] != self._transport_id:
                raise HelperError('The reviewed MIDI output has changed or disconnected.')
            if request_id in self._used:
                raise HelperError('This command was already attempted. Automatic replay is blocked.')
            if len(self._used) >= 4096:
                raise HelperError('MIDI adapter request limit reached; restart the creator workspace explicitly.')
            self._used.add(request_id)
            # Mark consumed before the first write; partial sends must not replay.
            for frame in frames:
                message_type = frame['type']
                args = {k: v for k, v in frame.items() if k != 'type'}
                self._port.send(self._load().Message(message_type, **args))

    def close(self):
        with self._lock:
            port, self._port = self._port, None
            self.port_name = ''
            self._transport_id = None
            if port is not None:
                try:
                    port.close()
                except Exception:
                    pass
            # Keep consumed IDs across close/open to prevent stale UI replays.
