# VRC Eye Development 6 — VRCX expansion

This build extends the existing desktop application. VRCX supplies optional
migration data; daily use does not require VRCX. The source ZIP retains the
Windows/Linux launchers and the earlier bug fixes, search tiles, SDK/VCC
downloads, mobile pairing, creator tools, media and diagnostics.

## Features and entry points

| Area | Where to find it | Added behavior |
|---|---|---|
| History and discovery | Desktop controls → History & discovery; enable Analytics first | One timeline across retained native/imported events, notifications, friend feed and account roster. Explicit shared-legacy inclusion; date/timezone/user filtering; friend activity, Hot Worlds, observed co-presence, mutual graph/hide/compare and CSV export. |
| Home widgets | Home → Customize | Recent history, worlds, events, photos, creator tasks and downloads populate configured filters/columns. |
| Owned appearance | Accounts → Biography / appearance | Choose owned inventory-template cosmetics, completed profile/banner images and background textures. Theme CRUD and color pickers use the existing reviewed profile action. |
| Groups and creator batches | Social / Accounts native panels → Reviewed batch queue | Persist up to 1,000 exact targets and common changed fields. Review remaining operations, pause and renew explicitly; uncertain/completed/rejected items do not repeat. |
| Groups and media | Social → Groups; Accounts → My media | Create group instances; upload/attach/remove gallery images; inspect pending images; order a complete small gallery. Emoji motion, masks and loop styles extend the existing upload preview. Inventory adds flags, ordering and item/template detail. |
| Visits | World Visits → Join queue | Queue inspected destinations in memory, reinspect the last observed instance and review native-client joins through the shared launch coordinator. OS acceptance does not confirm arrival. |
| Notifications | Desktop controls → Notifications | Category mutes/priorities, Windows SAPI or installed Linux espeak, and a read-only social feed on the existing SteamVR runtime. Explicitly start the shared VR connection. |
| Discord and companion apps | Desktop controls → Presence & health / Automation | Inspect the observed world for art/template/session/public-link previews. Owned child applications gain exit results and optional cleanup when the same game session ends. |
| Local lock | Desktop controls → Setup | Local passphrase and idle lock hide open windows, cancel work and disconnect the active account. Unlocking requires the passphrase; reconnect explicitly. This does not encrypt files on disk. |
| Migration | Favorites/VRCX → Data manager | Capture a live DB/WAL into a verified standalone snapshot; import with three-way lineage merges; retain history across the native/feed/roster stores. |
| Saved profile details | Search → Saved fields; Player profile → Notes; World Visits | Read historical fields/annotations with explicit shared scope. Review earlier local player notes into native annotations without overwriting existing notes. |
| Photos | Photos → Sources / context & organization controls | Verify a moved source by relative path and exact bytes; recover interrupted moves; use OS trash; index declared author/participants; enable per-source compatible PNG-copy or JSON-sidecar output. |
| Recovery | Data manager → Back up desktop profile / Recover profile | Bundle supported local stores with checksums. Restore into a new folder and launch with `python vrc_eye.py --profile-dir "path"`. Automatic services, executable/network approvals and sign-ins require fresh setup. |

## Behavioral boundaries

All new automatic services are opt-in. The existing account client, action
receipts, photo watcher, launch coordinator and SteamVR connection remain their
respective owners. New joins are one-use reviews; private destinations are
session-only and expire after 15 minutes. Uncertain remote/OS outcomes do not
trigger automatic retry. A batch review lasts five minutes and checks every
target immediately before its operation.

Legacy shared player history is not silently assigned to a selected account.
Account history requires the observed game identity to match that account.
Historical values, metadata-declared people and observed co-presence are not
current profile, visibility or friendship claims. Graph dates use a matching
source snapshot fetch time only; relationship age remains unknown.

Profile bundles include supported companion, player, creator and photo-catalog
data. They exclude protected sessions, execution/network grants, original photos,
Unity project files and unrecognized component stores. Each SQLite store is a
committed snapshot, but different stores may represent different instants.
Recovery never overwrites a running profile. A folder without its completion
marker is blocked from startup. Checksums detect changed bytes; they are not
publisher signatures.

Photo recovery preserves notes, albums and originals; conflicting bytes stop
reconciliation. Source reapproval disables its automatic grants. OS trash has
no permanent-delete fallback. Compatible PNG output requires a PNG source;
sidecars can carry supported world/time declarations for other imported formats.
Declared author/participant indexing is explicit, not image recognition.

## Still missing or awaiting verification

- **Creator workflows:** general duplicate detection and complete historical
  asset-version rollback; exhaustive profile-field change capture.
- **Group galleries:** approval needs a verified service contract. Reordering
  currently requires a complete unfiltered page of fewer than 100 images.
- **Older migration:** custom-user-tag, saved-search, print and some nested log/
  notification/screenshot producers remain unsupported where no contract is
  known. Missing empty groups and historical photo fingerprints cannot be
  reconstructed. Rich bidirectional VRCX roundtrip is not implemented.
- **Whole-application data:** legacy note editors are not bidirectionally synced;
  every arbitrary component store is not included in backup or retention.
  Coordinated history deletion requires SQLite rollback journals and preserves
  personal notes, favorites, photos and minimal action receipts.
- **Desktop extensions:** interactive Discord join-request handling, interactive
  VR inbox actions, broader optional providers and comprehensive adaptive sensor
  throttling remain outside this build.
- **Signed automatic updates:** a real publisher endpoint, trusted signing keys,
  installer/update channel and native rollback acceptance are still needed.
- **Native/live acceptance:** Windows/Linux window locking, credential vaults,
  launch/URI handlers, trash, tray, Discord IPC, installed speech, SteamVR,
  physical mobile pairing, actual VRChat permissions/entitlements and provider
  availability cannot be established by offline tests. No live VRChat writes
  were performed for this build.

Bounds are shown in the workflows: 200,000 projected history records, 300
subjects for pairwise overlap, 2,000 owned items per appearance category,
20 queued joins, and 2,000 references/512 MiB per moved-root recovery review.
Larger inputs require smaller explicit selections.

The detailed [implementation ledger](IMPLEMENTATION_STATUS_1_21.md) records all
82 VRCX work packages and the wider roadmap. [Validation](VALIDATION_1_21.md)
distinguishes executed tests from native/live checks still open. This package
is runnable source, not a compiled executable or signed installer.

## Contract sources

- User-supplied VRCX 2026.09.16: API/types, profile/inventory/gallery controls,
  native launch routes and database producers. No VRCX implementation was copied.
- [Discord primary documentation](https://discord.com/developers/docs/rich-presence/using-with-the-discord-social-sdk).
- [Send2Trash primary project](https://github.com/arsenetar/send2trash).
- Existing pinned VRChat API schemas and offline transport fixtures; current
  service behavior still requires live acceptance.
