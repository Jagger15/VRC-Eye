# Development 7 — continuation on the complete Development 6 build

Development 6 from the preceding chat became available during this continuation.
This package uses that complete build as its baseline, preserving its appearance,
batch queues, group media/instances, profile recovery, photo tools, lock, speech,
join queue and other VRCX additions. The history work is integrated into the
existing **Desktop controls → History & discovery** page. There is no separate
replacement history window or duplicate live-service owner.

You can also open that same page from **Feed → Observed changes → History &
discovery…**, or the native data manager's **Local history and records** tab.
Enable the existing local Analytics setting before loading history. Opening a
page does not start a live feed or send online requests.

## Changes in this continuation

- **Timeline categories and undated rows.** Select a category from those retained
  in the loaded sources. Choose whether undated rows should remain visible in a
  date-filtered timeline. These two controls affect the Timeline view; the other
  history/discovery views retain their existing filters.
- **Time evidence and display.** Display dates use the selected IANA timezone and
  show the UTC offset, including repeated daylight-saving hours. Friend-feed
  receipt times are labelled observed times. Derived intervals use their known
  start. Missing or timezone-free timestamps remain unknown; a normalized import
  value no longer silently supplies a timezone for an original naive timestamp.
- **Account and source identity.** Native, friend-feed, player and game-log rows
  have distinct source-origin identities even when their local IDs collide.
  Selecting shared legacy data cannot admit a player database belonging to a
  different account. Reads use read-only SQLite connections, cancellation,
  query deadlines and a 200,000-record / 64 MiB budget.
- **Current snapshots.** Source changes invalidate the retained display and require
  a reload. Account changes, privacy mode and changed filter drafts clear the
  affected data. Source and account checks also run during export. Personal
  names/IDs left in filter fields clear at privacy/account boundaries.
- **Correct encounter time.** Retained leave/rejoin segments determine observed
  duration and same-session overlap. Gaps between segments are excluded. An open,
  malformed or unknown-duration encounter is not converted into continuous
  presence simply because first/last timestamps exist. Observed and derived
  durations remain separate.
- **Reviewed CSV export.** The selected view's full filtered rows are exported,
  not just the displayed page. The review identifies the count and possible
  private content. Formula prefixes behind whitespace are escaped. Export checks
  cancellation/account/source state throughout and before publication, removes
  incomplete temporary output, and never overwrites an existing destination.

The previous graph, Hot Worlds tiles, friend activity, co-presence, date filtering,
hide/compare tools and analytics opt-in remain available. Source-change checks
are conservative: another write to a selected local database can require reloading
the view. CSV publication requires filesystem hard-link support; unsupported
destinations fail rather than falling back to an overwrite.

## Running and remaining work

Close the earlier copy, extract into a new folder, open `VRC-Eye`, then use
**Start.cmd** on Windows or **bash Start.sh** on Linux. This is a runnable Python
3.10+ source build with Tkinter, not a compiled executable. Existing launcher
and dependency files are unchanged from the complete Development 6 build.

The retained [Development 6 feature guide](VRCX_COMPLETION_DEV6.md) describes its
larger additions and remaining VRCX gaps. This continuation does not claim full
parity or native/live acceptance. [Validation](VALIDATION_1_21.md) records the
executed tests and display/transport limitations.
