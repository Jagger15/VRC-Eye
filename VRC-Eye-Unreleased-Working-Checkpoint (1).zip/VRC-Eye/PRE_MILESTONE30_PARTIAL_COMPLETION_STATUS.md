# Partial ARC/VRCX work — current checkpoint

Dashboard, optional provider demand and Creator copy-job recovery continuation. Earlier GLB, topology and settings work remains retained. All 40 broad areas remain Partial.

This pass advances four areas and leaves 36 unchanged. The six wholly missing ARC areas remain deferred. No numbered release was created; the Development 30 hold and calendar build name remain unchanged.

## Completed in this pass

| Area | Completed subfeatures |
| --- | --- |
| VX-DESK-01 | Home tables filter every loaded row before stable sorting and 25-row paging. Saved worlds have a separate source window; coverage labels expose retained limits. Desktop-owned revisions share one snapshot per producer, source ages advance without polling, context changes clear old rows, and Unity runtime/events plus Crash diagnostics use the same cards. |
| VX-DESK-15 | Shared display demand recognizes visible, uncollapsed Home cards and full pages. Minimized/low-power operation uses a 600-second unused public-status cadence and 120-second unused Unity metadata retries; foreground demand returns them to 120/30 seconds. Normal health request limits and failure backoff remain enforced. Core/window/recording/protection/recovery timing is unchanged. |
| ARC-19 | Creator Projects Copy only, Restore packages, Set exact package version and Remove package now create shared journal workspaces with raw/project/history. The frozen review identifies the actual project/ command; shared helper receipts and post-run checkpoints provide conditional undo while preserving later edits. Creator Activity links to Recovery history. |
| ARC-24 | Creator copy jobs persist account-scoped intent before file writes and link workspace/helper/checkpoint IDs through each phase. Interrupted copies and tools remain inspectable. Earlier-process unfinished receipts show their saved phase as outcome-unverified; restart never executes, retries or deletes them. |

## How to try the changes

On **Home**, use Previous/Next beneath tables. Filters and sorting apply across the loaded window; each table identifies that window. Add **Unity runtime** or **Crash diagnostics** through **Customize Home**. Provider freshness is separate from Home repaint time; historical events keep their event timestamps.

In **Desktop controls → Setup**, choose **Low power**. Visible Home cards count as active consumers. Optional public-status polling and Unity metadata retries slow while unused; protection rules, process/window checks, recording and crash-recovery automation keep normal timing.

Open **Creator Projects → Reviewed changes**. The chosen destination is now a recovery workspace; the editable Unity copy is in **project/**, alongside **raw/** and **history/**. Prepare the review, check the actual working path and command, then execute it. **Activity → Recovery history…** opens the shared checkpoints and reviewed undo. **Show durable copy-job receipts** includes interrupted jobs. Template creation remains a separate workflow.

## Earlier completed subfeatures retained

Open **Avatar Library → 3D preview → Bones & blendshapes…**, select a joint, enter local offsets and choose **Apply selected joint**. Joint rotations use X, then Y, then Z; scale multiplies the imported local transform. Translation is bounded to ±10 meters, rotation to ±180 degrees and scale to 0.01–10. Use the separate joint and blendshape resets to keep the other edits. Preview changes never write the source file. Clearing the scene or changing account/privacy context clears the overrides.

Use **Materials, textures & mesh health…** to see each material’s selected UV set and vertex topology counts. Sampling follows the declared nearest or linear filter. Unspecified filtering retains nearest; mipmap filters use the corresponding non-mipmap fallback on the retained preview image. Images remain capped at 256 pixels. Missing selected UV streams are reported and fall back to color factors.

Open **Settings backup and undo…** and select the new wellness or compass sections. Exports include selected reminder text. Live input connections, session history choices, the wellness master switch and compass Start/Stop state are preserved during selective restore. Isolated profile recovery starts those integrations disabled. Existing-session reminder timing can change when restored preferences change, just as with a normal reminder edit.

## All remaining partial areas

| ID | Area | Advanced this pass | Remaining work |
| --- | --- | --- | --- |
| ARC-04 | Actual material and texture viewer | No | PBR/Unity shaders, additional material extensions and normal/occlusion/emissive/metallic maps, full-resolution images/mipmaps, exact blend ordering, non-GLB appearance and native renderer acceptance remain. |
| ARC-05 | Rig, skinning and blendshape viewer | No | Animation/IK/PhysBones, non-GLB ingestion and native renderer acceptance remain. Near-singular imported parent transforms cannot be safely reconstructed for relative poses. The six missing ARC areas, including animation and other importers, remain deferred. |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | No | Self-intersection, cross-primitive/welded topology, deformation analysis, reviewed tangent repairs, semantic/runtime performance judgments and native acceptance remain. Findings are observations, not proof of a broken avatar. |
| VX-DESK-16 | Settings profiles, backup and rollback UX | No | Remaining settings owners, physical asset recovery, native controls/accessibility and power-loss acceptance remain open. Bounded history cannot reconstruct unrecorded edits. |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | No | Other tool/display stores and verified historical VRCX settings mappings remain. New sections must be omitted when sharing with an older reader. Composer and reminder messages may be private. |
| VX-MIG-29 | Native selective backup and complete restore | No | Original assets, Unity/recovery workspaces, unrecognized stores and cross-store instant consistency remain outside complete backup coverage. Credentials, service grants, local undo histories and executable approvals remain intentionally excluded. |
| ARC-01 | Isolated avatar provider contract and lifecycle | No | Rich-avatar/Unity-bundle/FBX provider coverage, formal OS sandbox containment and native Windows/Linux process/render qualification remain open. The bundled static GLB parser is process fault separation, not an OS security boundary. |
| ARC-07 | AssetRipper provider selection, version and provenance | No | Exact installed-release/version qualification, publisher/license verification, dependency pinning and a qualified provider registry remain. A local executable hash and compatible API do not authenticate its publisher. |
| ARC-08 | Integrated user-owned recovery orchestration | No | Native Windows/Linux installed-release acceptance, complete descendant containment, exporter memory/disk containment and version-specific quality/failure qualification remain. This process lifecycle is not an OS sandbox. |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | No | Original-source completeness, semantic object/fileID/material/rig validation, OS-enforced immutability and successful Unity import are not established. Raw data is protected by application behavior and hash checks, not an OS sandbox. |
| ARC-14 | Shader and material compatibility diagnostics | No | Actual shader compilation, render-pipeline/platform compatibility and complete typed material-property/keyword/texture analysis still require richer parser/editor evidence. GUID presence alone does not validate the target object. |
| ARC-15 | Typed material property mapping on copies | No | Exact-shader-version mapping profiles and reviewed texture, offset/scale, color, number/vector, queue and keyword transfer. |
| ARC-16 | Reviewed shader package install and removal | No | Shader-specific install/remove planning with dependency review, post-operation compilation/diffs and change-aware removal journal. |
| ARC-17 | Animation and controller dependency repair copies | No | Object-reference curve repairs, clip swaps and cloned Animator/override-controller dependency closure repair. |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | No | Binary Unity component and object-level dependency graphs, validated Unity fileIDs, component copying and reference remapping remain incomplete. Static GLB hierarchy does not establish Unity semantic equivalence. |
| ARC-19 | General repair-copy journal and conditional rollback | Yes | VPM template creation and arbitrary Unity/editor helpers are outside this journal workflow. Native installed VPM/Unity execution, Windows descendant handling and power-loss acceptance remain. Rollback is per-file, not atomic across the tree; modes and empty directories are outside content undo. |
| ARC-22 | Opt-in resumable authorized transfers | No | Other asset owners, supplied-key/decrypted resumable streams, real-origin range support and native Windows filesystem acceptance remain. Unsupported validators require a new reviewed complete download; modified or uncertain partials remain for inspection. |
| ARC-23 | Explicit bounded transient retry policy | No | Qualification of actual provider rate-limit/redirect behavior and broader nontransfer task policies remain. External extraction, imports and repairs are never automatically replayed. |
| ARC-24 | Durable job and publication crash reconciliation | Yes | Template jobs, OS-proven process containment, atomic cross-owner catalog publication and native power-loss/filesystem qualification remain incomplete. Inspectable phase receipts do not establish automatic file/catalog reconciliation or safe replay. |
| VX-DESK-01 | Shared dashboard projections | Yes | Other log views and providers still lack the common projection/subscription contract. Universal source freshness, Smart Start and database-wide search beyond the explicitly retained Home windows remain incomplete; native UI acceptance is open. |
| VX-DESK-02 | Configurable dashboards and widget layouts | No | Interactive VR dashboard rendering, broader runtime-specific conditions and native Windows/Linux accessibility/layout acceptance remain open. |
| VX-DESK-06 | Discord content, join controls and coexistence | No | Interactive Discord join-request acceptance is not implemented. Native Discord IPC and application registration remain user/environment prerequisites. |
| VX-DESK-08 | Opt-in crash recovery controller | No | Unattended private-instance rejoin and installed native crash/launch acceptance remain incomplete. |
| VX-DESK-15 | Tray/background and low-power operation | Yes | Native tray/startup/shutdown acceptance and adaptive policies for additional optional providers remain. Enabled GPU/disk warning rules intentionally retain normal collection cadence. Real desktop resource savings and long-run behavior are unmeasured. |
| VX-DESK-17 | Optional update channels and recoverable installation | No | Publisher endpoint, trusted signing keys, installer/update-channel implementation and native rollback acceptance remain missing. |
| VX-DESK-18 | Optional media-link enrichment and translation providers | No | Live/native producer and translation coverage. |
| VX-MIG-01 | Versioned source contract inventory | No | Additional historical source-version adapters are not exhaustive. |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | No | Requires rollback-journal stores. This does not erase physical logs/photos, original VRCX files, all creator/media stores or minimal action receipts. |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | No | Independent live stores are not universally one atomic database. Profile snapshots can represent slightly different instants. |
| VX-MIG-14 | User, world and avatar memos plus account notes | No | Historical producer/export schemas and bidirectional external-app note synchronization remain incomplete. Creator notebooks, quick notes and photo notes retain their distinct purposes. Private annotations do not update API profile tags or account notes. |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | No | Persistent custom-user-tag VRCX producer/export contracts remain conditional. Tags are local entity annotations; unobserved external labels cannot be reconstructed. |
| VX-MIG-20 | Video, resource and auxiliary game-log history | No | All version-specific auxiliary payloads remain conditional. |
| VX-MIG-23 | Notification archives and invite message details | No | Exhaustive nested payloads across historical versions are not supported. |
| VX-MIG-25 | Print favorite references and conditional print metadata | No | Complete historical print metadata/export schemas remain conditional. |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | No | Exhaustive legacy/cross-application formats are not claimed. |
| VX-MIG-28 | Saved searches, filters and portable views | No | No verified persisted VRCX saved-search producer was found; such external migration remains conditional. These are native VRC Eye tag views. |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | No | Complete bidirectional VRCX roundtrip is not claimed; ID/CSV exports lose richer native relationships/history. |
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | No | Other profile fields/producers and historical schemas remain outside coverage. Actual change times, missed intermediate changes and hidden data cannot be reconstructed from snapshots. Live-provider and native history-view acceptance remain open. |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | No | General creator duplicate detection across asset/model content, complete historical asset-version acquisition and actual rollback remain missing. Exact local hashes do not establish equivalent avatars. |
| VX-NATIVE-17 | Group posts, announcements and gallery access | No | Image approval has no verified endpoint in the pinned source. Ordering is limited to one complete unfiltered page of fewer than 100 images. |

## Evidence and release hold

See `PENDING_WORKING_VALIDATION.json` → `dashboard_recovery_update` for current evidence and exclusions. Native Windows/Linux UI, installed Unity/VPM, long-run tray operation and power-loss behavior still need acceptance. Source hashes, earlier changes and the calendar build name `2026.05.10.02.47.1` are preserved; internal compatibility remains `1.21.0`.
