# VRC Eye 1.18.8 — Crash & Diagnostics implementation map

The uploaded design follows byte-for-byte after this preface. User-requested
placement is **Advanced → Crash & Diagnostics**, alongside Performance & Security.

| Design area | Implementation / limits |
| --- | --- |
| External stock-client operation | Core requires no bridge, login, injection or modified client |
| Crash-resilient recorder, heartbeat, rotation and sequence/checksum validation | Independent writer, SQLite WAL/FULL transactions, wall + monotonic time, bounded ring and incident payload budgets |
| Recovery after whole-app/system interruption | Preserve unfinished committed records before starting a new ring; optional Windows provider/event correlation; no cause invented from Event 41 |
| Adaptive sampling | 5s normal / 1s pressure metrics plus 1s heartbeat; no fabricated 250ms precision |
| Resource and process telemetry | Existing Resource Guard metrics plus independent core fallback, process transitions, Windows responsiveness, I/O rates and interface-link status |
| SteamVR/tracking/bridge | SteamVR process presence; already-connected Wellness proximity/device-count observations; bridge connectivity; detailed tracking/pose/driver and per-avatar attribution unavailable |
| Session/avatar/error timeline | Fresh normalized event types and counts; historical log reconstruction excluded; raw logs and personal IDs excluded |
| Incident categories | Manual, crash marker, sustained unresponsiveness, unexplained exit, unfinished recorder; same-episode automatic trigger cooldown |
| Incident overview and analysis | Last-window observations, healthy-checkpoint comparison, bounded broad-feature similarity; correlation is never player blame |
| Replay and Error Center | Scrubber, selectable metric graph, timestamps/provenance, visible expired/unknown intervals and normalized error history |
| Retention / export | Independent age/count pruning, reviewed per-incident deletion, strict allowlist ZIP preview/export with checksums |
| Recovery | Reviewed Steam launch and optional previous-world webpage; no guaranteed user-Home launch or private-instance rejoin capability |
| VRC Eye startup failure handling | Three interrupted starts prompt Safe Mode; optional integrations disabled at startup, recorder stays available |
| Casual / Advanced / Developer | Simple overview/history/settings; replay/errors; sanitized stored-record inspector and provider diagnostics |
| Later extensions | Dumps/hardware fault decoding, comprehensive tracking, per-avatar attribution, learned/predictive similarity and automatic remediation remain unimplemented |

Implementation: crash_model.py, crash_store.py, crash_service.py,
crash_platform.py, crash_export.py, crash_boot.py, crash_ui.py, and existing
sidebar/app integration. Operating details: CRASH_DIAGNOSTICS_SETUP.md.
Validation and platform limitations: VALIDATION.md.

---

The important design constraint was that this should work as part of the **stock external VRC Eye application**. It should **not require a custom VRChat client, client bridge, or modded client** for its core functionality. A bridge can enhance attribution when available, but the Black Box has to remain useful entirely on its own.&#x20;

## 1. The core idea: a real “flight recorder,” not just a log viewer

The Black Box is not merely a folder full of logs.

Its purpose is:

> **Reconstruct the state of the computer, VRChat, SteamVR, the current session, and VRC Eye itself during the several minutes leading up to a failure.**

That distinction mattered a lot.

Traditional logs often tell you:

- an exception occurred,
- the process terminated,
- SteamVR disconnected,
- Windows rebooted,
- or a driver fault appeared.

But they frequently don't answer the more useful question:

> **“What changed immediately before everything went wrong?”**

So VRC Eye would maintain a rolling timeline containing system telemetry, VRChat observations, session changes, avatar/player events, tracking state, and error activity.

When something fails, VRC Eye freezes that history instead of overwriting it.

After restart, you could hit something like:

**Analyze Black Box**

and get a reconstructed incident timeline.

---

# 2. The Black Box must survive crashes

One of the biggest requirements we established was that it cannot exist only in RAM.

If the whole PC freezes, blue-screens, loses power, or resets, RAM contents cannot be trusted.

So the Black Box should use a **disk-backed circular buffer**.

Conceptually:

```
Normal operation

Newest
  ↓

[ T-00:00 ]
[ T-00:01 ]
[ T-00:02 ]
[ T-00:03 ]
...
[ T-09:58 ]
[ T-09:59 ]
[ T-10:00 ]

Oldest
```

As new samples are written, old samples roll off.

The working target we discussed was roughly:

**5–15 minutes of history**

with something around **10 minutes** being a very reasonable default.

That means VRC Eye isn't indefinitely recording everything someone does. It retains a small diagnostic window.

When a crash is detected, that rolling buffer becomes a preserved incident record.

---

# 3. Why disk-backed matters

There are several failure categories.

### VRChat-only crash

VRC Eye survives.

This is the easiest case.

VRC Eye can immediately detect:

```
VRChat process disappeared
```

and finalize the recording.

### VRChat hang

VRC Eye survives while VRChat becomes nonresponsive.

The recorder continues collecting system telemetry and can document the degradation.

### SteamVR crash

VRChat may remain alive or destabilize.

VRC Eye can continue recording the surrounding system state.

### GPU driver reset

VRChat may freeze, crash, recover, or render incorrectly.

The recorder may catch the resource pressure or driver-level symptoms leading into it.

### Windows freeze

VRC Eye can't continue operating once Windows itself stops scheduling processes.

Therefore the last successfully persisted sample is effectively the end of the recording.

### BSOD

Same limitation.

You can't record *after* the kernel crashes.

Instead VRC Eye reconstructs the event after reboot using the samples already written to disk plus Windows evidence.

### Hard power loss

Again, nothing can record during the outage.

The Black Box therefore needs frequent small writes so the last persisted state is as close to the outage as practical.

That was an important philosophical point:

**VRC Eye should never pretend it witnessed something that physically could not have been recorded.**

For a BSOD or power loss it may know:

> “The last Black Box sample was recorded 1.2 seconds before the system stopped.”

It should not invent the missing 1.2 seconds.

---

# 4. Crash-safe storage design

We discussed making the recorder resilient against the crash corrupting the recorder itself.

A reasonable design was an append-oriented journal rather than continuously rewriting one giant file.

Something conceptually like:

```
BlackBox/
    active/
        journal_A.bb
        journal_B.bb
        session.meta
        commit.state

    incidents/
        2026-10-01_00-42-16/
            timeline.bb
            metadata.json
            system-events.json
            logs/
```

The precise filenames are implementation detail, but the architecture matters.

Potential mechanisms included:

- append-only records,
- sequence numbers,
- timestamps,
- lightweight checksums,
- periodic commit markers,
- alternating journal files,
- atomic metadata replacement.

The idea behind **two journals** is extra resilience.

For example:

```
Journal A
Sequence 1000–1499
VALID

Journal B
Sequence 1500–1972
VALID

Sequence 1973
partial write due to power loss
```

On startup VRC Eye scans for the last valid record.

It ignores the incomplete tail.

Therefore a power failure shouldn't destroy the entire diagnostic history.

---

# 5. Adaptive sampling

We also discussed not treating every moment of a session equally.

During healthy operation, aggressive high-frequency logging wastes disk writes and CPU.

So the recorder could use **adaptive sampling**.

For example:

### Normal

Every \~5 seconds:

```
RAM
VRAM
CPU
GPU
temperatures
disk activity
network
VRChat memory
tracking health
SteamVR state
```

### Elevated

If instability begins appearing:

```
every ~1 second
```

### Critical

During a severe anomaly:

```
250–500 ms
```

for metrics where that resolution is useful.

For example:

```
21:31:42.000 VRAM 71%
21:31:42.500 VRAM 76%
21:31:43.000 VRAM 82%
21:31:43.500 VRAM 89%
21:31:44.000 VRAM 95%
21:31:44.500 VRChat responsiveness degraded
21:31:45.000 VRChat stopped responding
```

That tells you significantly more than:

```
VRChat crashed.
```

---

# 6. What the Black Box records

The design had several telemetry families.

## System memory

Record things such as:

- physical RAM total,
- RAM used,
- RAM available,
- commit usage,
- commit limit,
- paging activity,
- memory pressure,
- VRC Eye memory use,
- VRChat memory use,
- possibly SteamVR-related process memory.

The distinction between **physical RAM** and **commit** is particularly valuable.

For example:

```
RAM:
25.8 / 32 GB

Commit:
47.2 / 48.0 GB
```

may indicate a very different failure mode than simply seeing “80% RAM.”

---

# 7. GPU and VRAM

VRChat is often extremely sensitive to GPU memory pressure, so this is one of the most important Black Box categories.

Capture:

- GPU utilization,
- VRAM allocated,
- VRAM available,
- dedicated memory,
- shared GPU memory where available,
- GPU temperature,
- GPU clocks if safely accessible,
- driver reset indications when observable,
- GPU engine activity.

Timeline example:

```
22:14:03 VRAM 68%
22:14:22 Avatar load began
22:14:27 VRAM 74%
22:14:31 VRAM 81%
22:14:34 VRAM 88%
22:14:37 VRAM 94%
22:14:40 frame responsiveness degraded
22:14:43 Unity errors rapidly increasing
22:14:45 VRChat stopped responding
22:14:48 VRChat process exited
```

That would be an extremely useful diagnostic chain.

But critically, VRC Eye should say:

> **VRAM pressure increased immediately before the crash.**

Not:

> **VRAM caused the crash.**

More on that distinction later.

---

# 8. CPU information

The recorder should track:

- total CPU usage,
- VRChat CPU usage,
- VRC Eye CPU usage,
- SteamVR CPU usage where practical,
- CPU temperature,
- potentially frequency/throttling state.

The aim is not to become a hardware benchmark.

It's to answer questions such as:

```
Was the system CPU-starved?

Did one process suddenly consume everything?

Did thermal throttling occur?

Did CPU utilization collapse because the process hung?
```

---

# 9. Temperature and hardware-health data

Where safely available:

- CPU temperature,
- GPU temperature,
- maybe hotspot temperature,
- thermal throttle indications.

These are observations rather than diagnoses.

Example:

```
GPU:
82°C

GPU utilization:
98%

VRAM:
93%

Thermal throttling:
observed
```

VRC Eye could highlight the combination.

It still shouldn't conclude:

> GPU overheating caused VRChat to crash.

unless there were exceptionally definitive external indicators.

---

# 10. Storage activity

Disk behavior is important because VRChat may be loading:

- worlds,
- avatars,
- shaders,
- cache assets,
- textures,
- logs.

Useful observations include:

- read throughput,
- write throughput,
- disk queue/load,
- free disk space,
- possible disk stalls,
- cache-related activity where observable.

Example:

```
World joined
↓
Heavy disk reads
↓
Avatar loading surge
↓
Disk utilization 100%
↓
VRChat responsiveness degraded
```

Again, correlation—not automatic causation.

---

# 11. Network

The Black Box should also retain short diagnostic observations like:

- network availability,
- latency when meaningfully measurable,
- packet instability if available,
- interface disconnect/reconnect,
- Steam networking state where observable.

It does **not** need to become a packet sniffer.

The goal is operational state, not surveillance.

---

# 12. VRChat process health

The external VRC Eye process can monitor VRChat itself.

That includes things like:

```
Process running
Process responsive
Process memory
Process CPU
Process lifetime
Exit status when available
```

An important state machine could be:

```
Healthy
   ↓
Slow response
   ↓
Unresponsive
   ↓
Recovered
```

or:

```
Healthy
   ↓
Unresponsive
   ↓
Process terminated
```

That distinction is valuable because:

> “VRChat instantly closed”

and

> “VRChat hung for 22 seconds and then terminated”

are very different incidents.

---

# 13. SteamVR and tracking state

Because VRC Eye is VR-focused, Black Box data shouldn't stop at VRChat.exe.

The recorder should retain the surrounding VR environment.

Possible observations:

- SteamVR active/inactive,
- compositor state,
- headset connected,
- headset tracking available,
- tracking loss,
- controller connectivity,
- tracker connectivity,
- base station status when available,
- repeated device reconnects.

Example:

```
18:05:11 Tracker 3 disconnected
18:05:13 Tracker 3 reconnected
18:05:21 HMD tracking degraded
18:05:23 SteamVR compositor error observed
18:05:26 VRChat frame response degraded
```

That can help differentiate a VR runtime problem from a purely VRChat-side problem.

---

# 14. Session context

One of the more powerful pieces was tying diagnostics to **what was happening in the VRChat session**.

The recorder can retain things like:

- world join,
- world leave,
- instance transition,
- session start,
- session duration,
- player joins,
- player leaves,
- avatar changes,
- your avatar changing,
- major avatar-load events,
- resource spikes following particular events.

That turns this:

```
21:17:51 VRAM spike
```

into:

```
21:17:44 Player joined
21:17:46 Avatar loading observed
21:17:51 VRAM +1.8 GB
21:17:54 Unity error burst
```

Much more diagnostically useful.

---

# 15. Player events can participate in diagnostics

This tied directly into the expanded **Player List / Player Store** system we discussed.

Player records can have a diagnostics component.

For example:

```
Player joined
    ↓
Avatar resolved
    ↓
Resource observation recorded
    ↓
GPU memory increased
```

This does **not** mean VRC Eye labels the person:

> “This player crashed you.”

Instead it can show:

> “A significant resource increase occurred shortly after this player's avatar loaded.”

That distinction is extremely important.

---

# 16. Avatar events

Avatar transitions are especially useful timeline markers.

Possible events:

```
Local avatar changed

Remote avatar changed

Avatar loading began

Avatar load completed

Avatar unavailable

Avatar fallback occurred
```

If VRC Eye has resource observations from its normal avatar safety functionality, Black Box can correlate them.

Example:

```
00:12:04 Remote avatar change detected

00:12:06
VRAM: 6.2 → 7.9 GB

00:12:07
GPU utilization: 71 → 99%

00:12:09
VRChat response latency increased

00:12:11
VRChat became unresponsive
```

VRC Eye can display that chain while maintaining an explicit confidence boundary.

---

# 17. Unity / VRChat log correlation

VRC Eye can watch VRChat's logs and ingest diagnostically useful events into the timeline.

Not necessarily every single line.

It can normalize useful classes such as:

```
Unity warning
Unity exception
Shader failure
Asset error
Networking warning
Avatar load error
SteamVR-related message
```

A sudden burst matters.

For example:

```
Unity errors/min:

T-5 min     1
T-4 min     0
T-3 min     3
T-2 min     2
T-1 min    17
T-10 sec   84
CRASH
```

That should be visible immediately in the incident view.

---

# 18. VRC Eye records itself too

A diagnostic system that only watches other software is incomplete.

VRC Eye should also record its own important events:

- subsystem startup,
- data provider failures,
- plugin failures,
- bridge connection/disconnection,
- polling failures,
- database failures,
- permission errors,
- telemetry source failures,
- internal exceptions,
- watchdog warnings.

That makes it possible to distinguish:

> “VRChat failed”

from

> “VRC Eye stopped receiving information.”

Those must never be treated as equivalent.

---

# 19. Provenance: where did each fact come from?

This connected directly to the architecture we talked about for the Player Store.

Diagnostic information should retain its **source**.

Something like:

```
Value:
Avatar changed

Source:
VRChat log parser

Confidence:
High

Observed:
00:42:17.315
```

or:

```
VRAM:
7.63 GB

Source:
Windows GPU performance counters

Observed:
00:42:18.004
```

If a custom client bridge provides something:

```
Avatar complexity event

Source:
Client Bridge

Capability:
avatar.telemetry.v2

Observed:
00:42:18.221
```

This is especially useful in Developer Mode.

---

# 20. Never confuse observation with causation

This was one of the strongest design rules.

VRC Eye should be conservative when explaining crashes.

Suppose it sees:

```
Avatar loaded
↓
VRAM rose dramatically
↓
Unity errors began
↓
VRChat froze
```

It may say:

> **A large VRAM increase and Unity error burst occurred immediately before VRChat became unresponsive.**

It should not automatically say:

> **That avatar crashed VRChat.**

Likewise:

```
System memory reached 98%
↓
PC rebooted
```

should produce something like:

> **Severe memory pressure was observed shortly before the unexpected system shutdown.**

Not:

> **VRChat crashed Windows due to RAM usage.**

That evidence threshold matters enormously.

---

# 21. Windows crash correlation

After reboot, VRC Eye can examine Windows evidence.

We specifically discussed correlating things like Windows event information.

For example:

### Event ID 41

Kernel-Power Event 41 broadly indicates that Windows restarted without a clean shutdown.

It does **not** by itself explain why.

Therefore:

```
Unexpected system shutdown detected
```

is appropriate.

```
Power supply failure detected
```

is not.

### Event 1001 / bugcheck evidence

If Windows logged bugcheck information or a dump, VRC Eye can recognize:

```
Windows reported a bugcheck
```

and potentially expose:

- bugcheck code,
- dump existence,
- timestamp.

But again, unless evidence genuinely supports it, VRC Eye should not claim VRChat caused the BSOD.

---

# 22. Next-boot crash detection

This leads into one of the really important mechanisms.

Imagine VRC Eye records:

```
Session active
VRChat active
VRC Eye active
```

and then everything suddenly stops.

There was no orderly:

```
session closed
application shutdown
recorder finalized
```

The next time VRC Eye launches, it finds an unfinished Black Box journal.

That is evidence of an **unexpected termination**.

It can then ask Windows:

```
Was there an unexpected OS shutdown?

Was there a bugcheck?

Was VRChat terminated?

Are there crash artifacts?
```

The resulting incident might be classified as:

```
Unexpected PC shutdown

Black Box recovered
Last valid sample:
00:31:52.481

Windows restart event:
00:31:53
```

That is powerful because VRC Eye itself did not need to survive the crash.

---

# 23. Incident preservation

Under normal circumstances, the circular buffer keeps rotating.

Once an incident is detected:

```
ACTIVE BLACK BOX
      ↓
FREEZE
      ↓
COPY/PROMOTE
      ↓
INCIDENT RECORD
```

So it does not get overwritten when the user relaunches VRChat.

Possible incident metadata:

```
Incident ID

Time

Session duration

World

Instance type

VRChat version

VRC Eye version

Windows version

GPU driver version

VR runtime

Crash classification

Last valid sample

Evidence sources
```

Privacy rules would determine exactly which world/player identifiers are retained or sanitized.

---

# 24. Diagnostics Replay

One of the main UI ideas was effectively a **flight-recorder replay**.

Think of a horizontal timeline.

```
21:33                     21:34                     21:35
│──────────────────────────│─────────────────────────│

World Join
   ▲

Player A Joined
           ▲

Avatar Loading
              ▲

VRAM Warning
                         ▲

Tracking Drop
                              ▲

Unity Errors
                                      ▲▲▲▲▲

VRChat Hang
                                               ▲

Process Exit
                                                   ▲
```

You could scrub backward and forward.

At any point VRC Eye could show what the system looked like.

For example:

```
T - 38 seconds

CPU            71%
GPU            98%
RAM            24.2 GB
Commit          31.7 GB
VRAM            7.6 / 8 GB
GPU temp        79°C

VRChat
Responsive

SteamVR
Healthy

Players
31

Recent event
Avatar load completed
```

Move forward:

```
T - 7 seconds

CPU            82%
GPU            100%
RAM            26.1 GB
Commit          35.8 GB
VRAM            7.95 / 8 GB

VRChat
Response degraded

Unity Errors
41 / 10 sec

Tracking
Healthy
```

Then:

```
T - 2 seconds

VRChat
Not responding
```

Then:

```
T = 0

VRChat process exited
```

That was the envisioned power of the feature.

---

# 25. Safety Checkpoints

Another concept was **healthy checkpoints**.

VRC Eye periodically knows:

> “Everything appears healthy here.”

It can save a lightweight reference snapshot.

For example:

```
Healthy Checkpoint
21:31:00

RAM:
18.4 GB

VRAM:
4.6 GB

Players:
21

Unity errors:
0

SteamVR:
Healthy
```

Then compare that against the crash period:

```
Crash window
21:38:22

RAM:
27.1 GB
+8.7 GB

VRAM:
7.9 GB
+3.3 GB

Players:
36
+15

Unity errors:
73

SteamVR:
Healthy
```

That comparison makes troubleshooting much more understandable for normal users.

---

# 26. Crash classification

The diagnostics engine can categorize incidents without overclaiming causality.

Potential high-level classifications:

```
VRChat Process Crash

VRChat Hang

SteamVR Failure

Tracking Failure

GPU/Driver Instability

Unexpected System Restart

Windows Bugcheck

Power/Hard Reset Suspected

VRC Eye Failure

Unknown
```

The word **suspected** is useful where evidence is indirect.

---

# 27. Confidence system

We also had the broader provenance/confidence philosophy.

So a diagnostic conclusion could look like:

### High confidence

> VRChat stopped responding for 14 seconds and then its process terminated.

That's directly observable.

### Medium confidence

> GPU memory pressure may have contributed to instability.

There is strong correlation but not necessarily proof.

### Low confidence

> A player avatar load occurred shortly before the failure.

It is relevant but weak as causal evidence.

This keeps the program from turning coincidences into accusations.

---

# 28. Error Center

Crash Diagnostics was also connected with a broader **Error Center**.

Instead of scattering failures around the UI, VRC Eye can normalize them into categories.

Example:

```
Errors

VRChat
  3

SteamVR
  1

Tracking
  2

System
  1

VRC Eye
  0
```

Opening one could show:

```
VRChat

00:41:18
Unity asset loading exception

00:41:24
Rendering warning burst

00:41:29
Process stopped responding
```

Black Box incidents can link directly into these events.

---

# 29. Crash recovery

The feature wasn't supposed to stop at diagnostics.

Once VRC Eye knows VRChat crashed, it can also help you recover.

We discussed options along the lines of:

```
VRChat closed unexpectedly.

[ Restart VRChat ]

[ Launch Home ]

[ Rejoin Previous World ]

[ Analyze Black Box ]
```

The exact availability depends on what information VRC Eye legitimately has.

---

# 30. Previous-world recovery

Because VRC Eye maintains session context, it can remember the last world/session.

A recovery view might say:

```
Previous session

World:
Example World

Session duration:
1h 42m

Crash occurred:
12 seconds after avatar loading spike
```

Then offer a safe return path where feasible.

---

# 31. Safe Rejoin Guard

A very useful companion concept was the **Safe Rejoin Guard**.

Suppose the Black Box saw:

```
VRAM critical
many avatars
repeated Unity errors
VRChat crash
```

Instead of blindly encouraging:

> Rejoin Previous Instance

VRC Eye can warn:

```
Previous session showed signs of instability.

Observed before crash:

• VRAM reached critical level
• Multiple avatars were loading
• Unity errors increased rapidly
```

Then offer safer choices.

For example:

```
Launch Home
Rejoin Anyway
View Diagnostics
```

The goal is to avoid crash loops.

---

# 32. Repeated crash detection

This becomes even more useful if the same pattern happens repeatedly.

Example:

```
Incident 1
World A
VRAM 96%
Crash

Incident 2
World A
VRAM 97%
Crash

Incident 3
World A
VRAM 94%
Crash
```

VRC Eye might say:

> **Similar resource pressure was present in three recent incidents involving this session environment.**

Still not:

> **World A is broken.**

---

# 33. Circuit-breaker integration

This tied into the broader Safety system.

The Black Box is primarily diagnostic.

But the Safety subsystem can use repeated reliable observations to activate **circuit breakers**.

The conceptual split was:

```
Black Box
OBSERVES

Diagnostics
ANALYZES

Safety Rules
DECIDE

Circuit Breakers
ACT
```

That separation is important.

The telemetry collector itself should not start taking actions just because it sees one high number.

---

# 34. Threshold design

The safety thresholds shouldn't simply be:

```
IF VRAM > 90%
THEN PANIC
```

We discussed more mature rule behavior involving:

- threshold,
- duration,
- hysteresis,
- recovery threshold,
- cooldown,
- recurrence.

Example:

```
Warning threshold:
VRAM > 90%

Required duration:
5 seconds

Critical:
VRAM > 96%

Recovery:
VRAM < 85% for 15 seconds

Cooldown:
30 seconds
```

This avoids alert spam when a metric briefly crosses a boundary.

---

# 35. Architecture separation

The crash system fits the larger VRC Eye architecture we had been outlining.

A clean pipeline would be:

```
COLLECTION
    ↓
STATE
    ↓
ANALYSIS
    ↓
RULES
    ↓
ACTIONS
```

### Collection

Gets raw information.

```
Windows
VRChat logs
SteamVR
GPU counters
Bridge
VRC Eye
```

### State

Normalizes it.

```
current VRAM
current world
current players
tracking status
process health
```

### Analysis

Looks for patterns.

```
resource spike
error burst
responsiveness degradation
```

### Rules

Determines whether something warrants attention.

### Actions

Things like:

```
warning
incident preservation
safe rejoin recommendation
circuit breaker
```

That modularity prevents one giant crash-monitoring class from becoming impossible to maintain.

---

# 36. The custom-client bridge is an enhancement, not a dependency

This was another major boundary.

The normal Black Box works externally.

If a compatible custom-client bridge is present, it may provide additional internal signals.

Conceptually:

```
External Black Box
    +
Optional Bridge Telemetry
```

The bridge could make some attribution more precise.

But:

> **No bridge = Black Box still works.**

This is consistent with the broader VRC Eye principle that custom-client support is optional and secondary.

---

# 37. Bridge safety model

The bridge was never supposed to become:

```
VRC Eye injects arbitrary instructions into VRChat.
```

Instead, the architecture we discussed was closer to a structured protocol.

```
VRC Eye
 ↕
Versioned Bridge API
 ↕
Compatible Client
```

The bridge advertises capabilities.

For example:

```
player.telemetry
avatar.telemetry
world.state
runtime.errors
```

VRC Eye then knows exactly which functions are supported.

No arbitrary memory execution.

No assumption that the bridge is always present.

---

# 38. Bridge disconnect behavior

This matters especially for diagnostics.

If the bridge disconnects:

```
Bridge telemetry
≠
zero
```

It becomes:

```
unavailable
```

For example, this is bad:

```
Avatar metric:
0
```

if the bridge disappeared.

The correct representation is:

```
Avatar metric:
Unavailable

Last update:
7 seconds ago

Reason:
Bridge disconnected
```

Stale bridge information should be marked stale or cleared appropriately.

---

# 39. Developer Mode

Developer Mode gets considerably more detail than Casual Mode.

It could show:

```
Raw event name
Timestamp
Provider
Sequence number
Database ID
Resolver state
Cache age
Confidence
Bridge capability
Bridge payload summary
Polling latency
Journal offset
```

Potential example:

```
Event
avatar.resource.update

Timestamp
00:42:17.337

Provider
bridge.avatar.telemetry.v2

Player DB ID
18432

Resolver
resolved

Payload age
41 ms

Confidence
direct
```

That is fantastic for debugging VRC Eye itself but would be useless clutter for most users.

---

# 40. Casual Mode

The normal user should see an understandable incident explanation.

Something like:

```
VRChat closed unexpectedly.

In the 30 seconds before the crash:

GPU memory became nearly full.

Several avatars were loading.

VRChat began responding slowly.

A large number of Unity errors occurred.

The program stopped responding and then exited.
```

Buttons:

```
Restart VRChat
View Details
Launch Home
```

That's enough for most people.

---

# 41. Advanced Mode

Advanced users could see more detailed correlations.

For example:

```
VRAM
7.92 / 8.00 GB

System RAM
27.3 / 32 GB

Commit
39.8 / 48 GB

Unity errors
87 / 30 sec

Players
38

Avatar loads
6 / 20 sec

VRChat nonresponsive
11.4 sec

Process exit
0x....
```

alongside graphs and the replay timeline.

---

# 42. Developer Mode

Developer Mode can expose nearly everything safe to expose.

For example:

```
00:42:17.102
PROC_HEALTH
vrchat.exe
response_ms=412

00:42:17.337
GPU_SAMPLE
dedicated_used=7.91GB

00:42:17.552
PLAYER_EVENT
avatar_change
entity=PlayerStore:18432

00:42:17.912
LOG_EVENT
UnityErrorBurst
count=14
window=1000ms
```

That would make VRC Eye itself dramatically easier to troubleshoot.

---

# 43. Diagnostic Bundle Generator

Another major part was being able to export a diagnostic bundle.

Something like:

```
VRC-Eye-Diagnostics-2026-10-01.zip
```

containing sanitized versions of:

```
Black Box timeline

VRC Eye logs

VRChat relevant log section

system information

hardware information

Windows crash evidence

SteamVR information

incident metadata
```

This could be extremely useful for:

- bug reports,
- GitHub issues,
- Discord support,
- developer debugging.

---

# 44. Sanitization is mandatory

The diagnostic exporter should not blindly dump private data.

We explicitly had redaction in the concept.

Potentially sensitive fields include:

- authentication tokens,
- API tokens,
- account identifiers,
- private instance information,
- filesystem usernames,
- personal file paths,
- session secrets,
- bridge credentials.

For example:

```
C:\Users\Igor\AppData\...
```

might become:

```
C:\Users\<USER>\AppData\...
```

A private instance identifier might become:

```
wrld_xxxx:PRIVATE_INSTANCE_REDACTED
```

And tokens should simply be removed.

---

# 45. Export preview

A particularly good safety feature would be:

```
Diagnostic Bundle Preview

Included:
✓ hardware summary
✓ crash timeline
✓ performance telemetry
✓ sanitized VRChat log
✓ VRC Eye log

Removed:
✓ authentication tokens
✓ private instance identifiers
✓ user filesystem name
```

Then:

```
[ Export Bundle ]
```

That gives the user confidence about what they're sharing.

---

# 46. Player privacy

Because the Black Box can contain player-related events, it shouldn't turn into permanent behavioral surveillance.

The rolling buffer is temporary by design.

Long-term player records and crash telemetry should be treated separately.

For example, Black Box might retain:

```
Player joined
Avatar changed
Resource spike observed
```

for incident reconstruction.

That does not necessarily mean every raw diagnostic event needs to become permanent player-history data.

---

# 47. Incident retention

A sensible model would be:

```
Active recorder
~10 minutes rolling

No incident:
overwritten automatically

Incident:
preserved

Old preserved incidents:
subject to retention limits/user settings
```

Potential settings later could include:

```
Keep last 10 incidents
Keep incidents for 30 days
Manual deletion
Never automatically delete
```

Those exact retention options weren't the essential part; the important idea was that normal telemetry rolls away while crashes can be preserved.

---

# 48. Crash timeline example

Putting all of the pieces together, imagine this session:

```
22:14:00
Black Box healthy checkpoint

22:14:12
Player joined

22:14:14
Avatar loading observed

22:14:18
VRAM
5.9 → 6.7 GB

22:14:22
Two additional avatar loads

22:14:27
VRAM
7.3 GB

22:14:31
VRAM warning threshold reached

22:14:34
Unity warnings increasing

22:14:36
VRChat responsiveness degraded

22:14:38
VRAM
7.93 / 8 GB

22:14:39
GPU utilization
100%

22:14:40
Unity error burst

22:14:41
VRChat unresponsive

22:14:53
VRChat process terminated
```

The summary should read something like:

> **VRChat became unresponsive and terminated. GPU memory was near capacity and Unity errors increased significantly during the final seconds of the session. Several avatar-loading events occurred shortly beforehand. These observations are correlated with the crash but do not establish a definitive cause.**

That is exactly the tone I think VRC Eye should maintain.

---

# 49. Whole-PC crash example

The harder case:

```
01:04:31.000
RAM 82%
Commit 88%
VRAM 91%

01:04:31.500
Unity error burst

01:04:32.000
RAM 87%
Commit 93%

01:04:32.500
VRChat responsiveness degraded

01:04:33.000
Commit 97%

01:04:33.500
Last valid Black Box record
```

Then no orderly shutdown.

Next boot:

```
VRC Eye startup
↓
unfinished Black Box discovered
↓
Windows unexpected-shutdown evidence discovered
↓
incident reconstructed
```

Report:

```
Unexpected System Shutdown

Last Black Box sample:
01:04:33.500

Windows indicates the previous session ended unexpectedly.

Immediately beforehand:

• System commit was near its configured limit.
• VRChat responsiveness had degraded.
• Unity errors were increasing.
```

Again:

**not**

> VRChat ran Windows out of memory and crashed the computer.

Unless actual evidence proved that.

---

# 50. Why Black Box should be independent of the normal logger

I would keep these conceptually separate.

### Logs

Human-readable detailed events.

### Black Box

Structured time-series evidence.

Example log:

```
[01:23:44] Avatar change detected for player...
```

Black Box record:

```
type = avatar_change
timestamp = 01:23:44.312
entity = player:1842
source = log_parser
confidence = high
```

Structured data is much easier to:

- graph,
- replay,
- correlate,
- compare,
- classify.

---

# 51. Schema versioning

Since this feature is intended to evolve, every Black Box file should probably have a schema version.

For example:

```
BlackBox Schema
3

VRC Eye
1.18.7
```

Then future versions can migrate or interpret older incidents.

Otherwise one future telemetry change could make old crash recordings unreadable.

---

# 52. Session IDs and incident IDs

Every VRChat run should have a unique session identifier.

Conceptually:

```
Session
S-20261001-00123

Incident
I-20261001-00018
```

Then every Black Box event can associate with:

```
session_id
timestamp
sequence
source
event_type
payload
```

This makes correlation deterministic.

---

# 53. Monotonic timestamps

For a serious crash recorder, wall-clock time alone isn't ideal.

Windows time can change.

So internally VRC Eye should preferably retain both:

```
Wall clock:
2026-10-01 01:14:22.337

Monotonic:
session + 01:42:17.583
```

That makes event ordering reliable even if system time jumps.

---

# 54. Event sequencing

Similarly, events can receive increasing sequence numbers.

```
#881203 GPU sample
#881204 avatar event
#881205 Unity warning
#881206 process heartbeat
```

If a crash truncates the journal halfway through:

```
#881207 corrupt/incomplete
```

the reader knows exactly where valid data ends.

---

# 55. Health heartbeat

Another useful concept for reconstructing system failure is a periodic heartbeat.

VRC Eye writes something lightweight such as:

```
BLACKBOX_HEARTBEAT
```

When the next boot sees:

```
heartbeat
heartbeat
heartbeat
nothing
```

followed by an unclean system shutdown, that's useful evidence about when execution stopped.

---

# 56. Diagnostic correlation engine

Eventually the replay system could automatically identify interesting windows.

Instead of forcing the user to inspect ten minutes manually:

```
Potentially Relevant Events

T-43 sec
VRAM increased sharply

T-29 sec
Avatar load burst

T-17 sec
Unity errors increased

T-11 sec
VRChat responsiveness degraded

T=0
Process exited
```

That's basically the system saying:

> “These are the events that changed unusually close to the failure.”

Not:

> “These caused it.”

---

# 57. Baseline comparison

The analyzer could compare the crash period against that session's normal state.

For example:

```
                         Normal       Before Crash

VRAM                     61%          98%
RAM                      64%          84%
Unity errors/min          2           112
Avatar loads/min          3            19
VRChat response           normal       degraded
SteamVR                   healthy      healthy
```

This can immediately reveal what was unusual.

---

# 58. Incident similarity

A future version could group incidents according to similar signatures.

Example:

```
Crash Pattern A
4 incidents

Common observations:
• VRAM >95%
• rapid avatar loading
• Unity error burst
• VRChat hangs before exit
```

Another:

```
Crash Pattern B
2 incidents

Common observations:
• SteamVR compositor disconnect
• HMD tracking loss
• VRChat remains running
```

That could be incredibly useful for diagnosing recurring issues.

---

# 59. Don't create false player blame

I think this deserves its own explicit design rule.

Suppose the Black Box sees:

```
Player X joins
6 seconds later
crash
```

That is nowhere near sufficient.

Even if:

```
Player X joins
avatar loads
VRAM jumps
VRChat freezes
```

the UI should frame it carefully.

Something like:

```
Avatar Event

A remote avatar finished loading 4.1 seconds before GPU memory reached the critical range.
```

Not:

```
Player X crashed you.
```

That would be technically irresponsible and could encourage harassment.

---

# 60. Future bridge-assisted attribution

With an optional client bridge, VRC Eye could potentially gain stronger observations.

For example:

```
avatar object instantiated
shader count changed
texture allocation changed
render load changed
```

But even then the wording should remain evidence-based.

Bridge telemetry increases **observability**, not magical certainty.

---

# 61. VRC Eye crash protection itself

The Safety architecture also included the idea that if **VRC Eye itself repeatedly fails on startup**, it should protect itself.

That leads into a Safe Mode concept.

Example:

```
VRC Eye failed during startup 3 times.

Start in Safe Mode?
```

Safe Mode could disable:

- integrations,
- plugins,
- overlays,
- experimental modules,
- bridge extensions.

while retaining core functionality.

This prevents one malfunctioning add-on from making VRC Eye unusable.

---

# 62. Black Box should remain active in Safe Mode

Ideally the core diagnostic recorder is sufficiently isolated and lightweight that it can remain functional in Safe Mode.

That's especially useful because:

> the thing you're using to diagnose VRC Eye should not depend on all the components that might be causing VRC Eye to fail.

Architecturally that means the recorder should be close to the core.

---

# 63. UI placement

Given the newer sidebar architecture we were discussing, I'd treat Black Box as part of the broader:

```
Safety
```

or possibly:

```
Safety
 ├─ Overview
 ├─ Crash Diagnostics
 ├─ Black Box
 ├─ Error Center
 ├─ Recovery
 └─ Safety Settings
```

The user-facing distinction could be:

**Crash Diagnostics** = analysis and incident history.

**Black Box** = recorder configuration and raw recordings.

That is cleaner than treating them as exactly the same thing.

---

# 64. Black Box live status

The Safety overview could show something simple:

```
BLACK BOX

● Recording

Buffer
09:42 / 10:00

Disk use
42 MB

Last sample
0.4 sec ago

Health
Normal
```

If something is wrong:

```
BLACK BOX

⚠ Degraded

GPU telemetry unavailable
Last valid GPU sample 14 sec ago
```

Again, missing telemetry should be visibly missing rather than silently replaced with zero.

---

# 65. Incident history

A dedicated page could show something like:

```
Crash Diagnostics

Today

12:41 AM
VRChat Crash
Black Box available

Yesterday

11:18 PM
Unexpected PC Restart
Black Box recovered

9:02 PM
SteamVR Failure
No VRChat crash
```

Clicking one enters the replay.

---

# 66. Incident overview

An incident page might have:

```
VRChat Crash
12:41:27 AM

Session
1h 28m

Black Box
Recovered

Primary observations

⚠ VRAM reached critical range
⚠ Unity errors increased rapidly
⚠ VRChat became unresponsive

✓ SteamVR remained responsive
✓ Tracking remained available
✓ Network remained connected
```

Then:

```
[ Replay Timeline ]
[ View Raw Data ]
[ Export Diagnostic Bundle ]
```

That would be a really strong UI.

---

# 67. Casual / Advanced / Developer split

This fits the profile system we already established for VRC Eye.

### Casual

Explain what happened.

Hide implementation detail.

### Advanced

Show metrics, graphs, source information, and deeper correlation.

### Developer

Expose raw recorder data, bridge payload summaries, timestamps, resolver state, cache age, IDs, sequence numbers, and internal diagnostic states.

That means we don't need separate applications or builds.

Same engine.

Different visibility.

---

# 68. Performance requirements

A crash recorder that causes performance problems would be self-defeating.

So the design philosophy should be:

```
small samples
structured binary data where appropriate
bounded memory
bounded disk
asynchronous writes
adaptive frequency
no heavy analysis in the sampling loop
```

Collection should remain cheap.

Expensive analysis happens:

```
after incident
```

or in lower-priority worker tasks.

---

# 69. Crash-safe write philosophy

The recorder should prefer many tiny valid records over infrequent giant snapshots.

For example:

```
record header
timestamp
event type
payload size
payload
checksum
```

If the system dies halfway through a record:

```
previous records remain readable.
```

That's precisely what you want from a flight recorder.

---

# 70. A possible internal record structure

Something conceptually like:

```
BlackBoxRecord
{
    schemaVersion
    sequence
    monotonicTimestamp
    wallClockTimestamp
    eventType
    sourceId
    flags
    payloadLength
    payload
    checksum
}
```

Events might include:

```
SYSTEM_SAMPLE

GPU_SAMPLE

PROCESS_SAMPLE

VRCHAT_EVENT

PLAYER_EVENT

AVATAR_EVENT

STEAMVR_EVENT

TRACKING_EVENT

LOG_EVENT

VRC_EYE_EVENT

BRIDGE_EVENT

HEALTH_CHECKPOINT
```

That leaves the system highly extensible.

---

# 71. One more important rule: gaps must be visible

Suppose GPU telemetry stops for 14 seconds.

The chart should show:

```
──────────────     ──────────────
              GAP
```

not interpolate a fake line.

Likewise:

```
Bridge unavailable
```

should not turn into:

```
0 players
```

Missing information is itself diagnostic information.

---

# 72. Why I think the Black Box belongs fairly deep in development

Our broader implementation sequencing had Black Box correlation relatively late—around the point where the roster, identity system, avatar model, roles, safety system, UX, ecosystem, and optional Bridge foundation already exist.

That makes sense because the Black Box benefits enormously from all those normalized systems.

Rather than teaching Black Box independently how to understand:

```
players
avatars
worlds
bridge state
tracking
```

it can subscribe to the already established VRC Eye state model.

So conceptually:

```
Player Store
Avatar Store
Session Store
System Telemetry
SteamVR
Safety
Bridge
          ↓
      Event Bus
          ↓
      Black Box
```

That gives you one source of truth.

---

# 73. Where this ultimately leads

If implemented fully, a VRC Eye crash could become something like this:

```
VRChat stopped responding at 12:41:22 AM
and terminated 11.4 seconds later.

VRC Eye recovered 10 minutes of pre-crash telemetry.

Notable changes before the incident:

• GPU memory increased from 68% to 98%.
• Six avatar-loading events occurred within 24 seconds.
• Unity errors rose from 2/min to 87/min.
• System memory remained below its critical threshold.
• SteamVR and tracking remained responsive.
• Network connectivity remained available.

These events are correlated with the failure but do not establish a definitive cause.

Suggested recovery:
Launch VRChat Home before returning to the previous session.
```

Then you can hit:

```
Replay
```

and literally scrub backward through the incident.

**That is what makes the feature a Black Box instead of just “crash logs.”**

And one aspect I especially want to preserve from what we'd discussed: the Black Box is meant to reconstruct **pre-crash state**, including in the really nasty cases where the **entire PC freezes, BSODs, resets, or loses power**. In those cases VRC Eye obviously cannot observe anything after Windows itself dies; the design instead makes sure the last several minutes have already been safely committed so they can be recovered and correlated on the next boot.