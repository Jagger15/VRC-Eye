"""Bounded relative joint poses for an immutable imported GLB scene.

Offsets are applied after the imported local matrix: T * Rz * Ry * Rx * S.
They are a preview convention, not glTF animation channels or a rig repair.
"""
import math
from avatar_scene import IDENTITY, multiply, vector
from avatar_library_files import check_cancel

DEFAULT = {'translation': (0., 0., 0.), 'rotation': (0., 0., 0.), 'scale': (1., 1., 1.)}


def offsets(scene, values):
    if not isinstance(values, dict):
        raise ValueError('Joint offsets must be a node-to-pose object.')
    joints = {n for skin in scene.skins for n in skin.joints}
    if any(type(n) is not int or n not in joints for n in values):
        raise ValueError('Select a skin joint from this scene.')
    result = {}
    for node, raw in values.items():
        if not isinstance(raw, dict) or set(raw) != set(DEFAULT):
            raise ValueError('Joint offsets require translation, rotation and scale.')
        value = {key: vector(raw[key], 3) for key in DEFAULT}
        if any(abs(v) > 10 for v in value['translation']):
            raise ValueError('Joint translation offsets must be between -10 and 10 meters.')
        if any(abs(v) > 180 for v in value['rotation']):
            raise ValueError('Joint rotation offsets must be between -180 and 180 degrees.')
        if any(not .01 <= v <= 10 for v in value['scale']):
            raise ValueError('Joint scale multipliers must be between 0.01 and 10.')
        if value != DEFAULT:
            result[node] = value
    return result


def inverse(matrix):
    """Inverse of an affine column-major matrix; singular poses stay inspectable."""
    a, b, c = matrix[0:3], matrix[4:7], matrix[8:11]
    def cross(x, y):
        return (x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0])
    rows = (cross(b, c), cross(c, a), cross(a, b))
    det = sum(a[k]*rows[0][k] for k in range(3))
    size = math.prod(math.sqrt(sum(x*x for x in v)) for v in (a, b, c))
    if not size or abs(det) <= size*1e-12:
        raise ValueError('This pose crosses a singular imported transform; reset the joint offsets or use a nonsingular source.')
    rows = tuple(tuple(v/det for v in row) for row in rows)
    shift = tuple(-sum(row[k]*matrix[12+k] for k in range(3)) for row in rows)
    return vector((
        rows[0][0], rows[1][0], rows[2][0], 0.,
        rows[0][1], rows[1][1], rows[2][1], 0.,
        rows[0][2], rows[1][2], rows[2][2], 0., *shift, 1.), 16)


def delta(value):
    x, y, z = (math.radians(v) for v in value['rotation'])
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    rx = (1, 0, 0, 0, 0, cx, sx, 0, 0, -sx, cx, 0, 0, 0, 0, 1)
    ry = (cy, 0, -sy, 0, 0, 1, 0, 0, sy, 0, cy, 0, 0, 0, 0, 1)
    rz = (cz, sz, 0, 0, -sz, cz, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
    tx = list(IDENTITY); tx[12:15] = value['translation']
    scale = list(IDENTITY); scale[0], scale[5], scale[10] = value['scale']
    return multiply(multiply(multiply(multiply(tuple(tx), rz), ry), rx), tuple(scale))


def world_matrices(scene, values, *, stop=None):
    original = {n.index: n.matrix for n in scene.nodes}
    world = {}; changed = set(); inverses = {}
    for node in scene.nodes:
        check_cancel(stop)
        if node.index not in values and node.parent not in changed:
            world[node.index] = node.matrix
            continue
        local = node.matrix
        if node.parent >= 0:
            if node.parent not in inverses:
                inverses[node.parent] = inverse(original[node.parent])
            local = multiply(inverses[node.parent], node.matrix)
        if node.index in values:
            local = multiply(local, delta(values[node.index]))
        world[node.index] = multiply(world[node.parent], local) if node.parent >= 0 else local
        changed.add(node.index)
    return world, changed
