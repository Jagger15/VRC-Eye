# VRC Eye updater preparation

The intended route is to adapt suitable VRCX updater code and behavior into an
Eye-owned updater. VRCX's repository currently declares the MIT license, which
permits reuse with its copyright and permission notice retained in substantial
copies. Any actual port should pin a source revision and preserve applicable
file-level and third-party notices.

Primary references checked October 4, 2026:

- https://github.com/vrcx-team/VRCX/blob/master/LICENSE
- https://github.com/vrcx-team/VRCX
- https://github.com/vrcx-team/VRCX/releases

VRCX publishes its own application installers/releases, including separate
desktop platform packaging. Eye is a Python/Tk source application with its own
launchers. Installing a VRCX release does not install an Eye update or merge
new VRCX features into Eye. Upstream feature changes still need an intentional
port and regression checks. No updater implementation was copied in this
checkpoint; detailed source-port selection remains to be done.

## Proposed first implementation

1. Check an explicitly configured Eye release repository/feed for the selected
   stable or development channel, with a bounded interval and manual check.
2. Show Eye version, channel, release notes and compatible platform package.
   Use Eye's full version plus development checkpoint for ordering; the current
   `1.21.0` alone cannot distinguish Development 9 from Development 10.
3. Download only an Eye package into a staging directory. Verify a signed
   manifest against a pinned publisher key, then package length and digest.
   A checksum delivered alongside an untrusted package is not publisher proof.
4. Prepare installation, then offer restart-to-install. Preserve the previous
   working version for rollback and keep account data outside the replaced
   application tree. Never replace files in a running process.
5. Disable self-install for externally managed packages. Keep check-only and
   manual-install fallbacks available when a platform cannot install safely.

## Release inputs still needed

- An Eye-owned release repository or HTTPS feed and its publishing workflow.
- Publisher signing key custody and the public verification key shipped in Eye.
- Windows/Linux package contracts and native restart, failure and rollback tests.

No public repository, release upload, signing identity, update feed, remote
installer or background update task has been created by Development 10.
Existing UI continues to report automatic installation unavailable.
