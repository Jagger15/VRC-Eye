"""Validated Unity 2022.3 uncompressed vertex streams into preview geometry."""
import struct
from avatar_scene import integer,vector,MAX_VERTICES,MAX_TRIANGLES

FORMATS={0:('f',4,None),1:('e',2,None),2:('B',1,255),3:('b',1,127),4:('H',2,65535),5:('h',2,32767),6:('B',1,None),7:('b',1,None),8:('H',2,None),9:('h',2,None),10:('I',4,None),11:('i',4,None)}


def blob(value,limit=64*1024**2):
    if not isinstance(value,(bytes,bytearray,list,tuple)) or len(value)>limit:raise ValueError('Unity binary stream exceeds its byte budget.')
    try:return bytes(value)
    except (ValueError,TypeError):raise ValueError('Invalid Unity binary stream.') from None


def reflect(v):
    x,y,z=vector(v,3);return (-x,y,z)


def matrix(value):
    # Unity stores serialized Matrix4x4 e[row][column]; preview is column-major.
    result=vector([value['e'+str(r)+str(c)] for c in range(4) for r in range(4)],16)
    from avatar_scene_deform import affine
    return affine([v*(-1 if (i%4==0)!=(i//4==0) else 1) for i,v in enumerate(result)])


def streams(mesh,resource):
    if mesh.get('m_MeshCompression',0)!=0:raise ValueError('Compressed mesh vertex data remains unsupported.')
    compressed=mesh.get('m_CompressedMesh',{})
    if any(isinstance(v,dict) and v.get('m_NumItems',0) for v in compressed.values()):raise ValueError('Packed/compressed mesh streams remain unsupported.')
    data=mesh['m_VertexData'];count=integer(data['m_VertexCount'],1,MAX_VERTICES)
    channels=data['m_Channels']
    if not isinstance(channels,list) or not 1<=len(channels)<=14:raise ValueError('Unsupported Unity vertex channel count.')
    raw=blob(data['m_DataSize']);stream=mesh.get('m_StreamData',{})
    if stream.get('path'):
        if raw:raise ValueError('Ambiguous inline and streamed Unity vertices.')
        raw=resource(stream)
    elif stream.get('size',0):raise ValueError('Unity streamed vertices have no resource path.')
    used={};strides={};ranges={}
    for idx,ch in enumerate(channels):
        dim=integer(ch['dimension'],0,4)
        if dim==0:continue
        fmt=integer(ch['format'],0,11);part=integer(ch['stream'],0,3);offset=integer(ch['offset'],0,255)
        width=FORMATS[fmt][1]*dim
        ranges.setdefault(part,[]).append((offset,offset+width))
        strides[part]=max(strides.get(part,0),offset+width);used[idx]=(part,offset,dim,fmt)
    if 0 not in used or used[0][2]!=3:raise ValueError('Unity mesh lacks three-component positions.')
    starts={};end=0
    for part in sorted(strides):
        rr=sorted(ranges[part])
        if rr[0][0]!=0 or any(a[1]!=b[0] for a,b in zip(rr,rr[1:])):raise ValueError('Gapped or overlapping Unity vertex channels are unsupported.')
        starts[part]=end;end+=count*strides[part]
        if end>len(raw):raise ValueError('Unity vertex channels exceed their embedded resource.')
        end=(end+15)&~15
    result={}
    for idx,(part,offset,dim,fmt) in used.items():
        code,width,divisor=FORMATS[fmt];rows=[]
        for i in range(count):
            values=struct.unpack_from('<'+str(dim)+code,raw,starts[part]+offset+i*strides[part])
            if divisor:values=tuple(max(-1.,v/divisor) for v in values)
            if idx==13:
                if fmt not in (6,8,10) or dim!=4:raise ValueError('Bone indices require four unsigned integer components.')
                rows.append(values)
            else:rows.append(vector(values,dim))
        result[idx]=tuple(rows)
    for idx,dim in ((1,3),(2,4),(3,4),(4,2),(12,4)):
        if idx in result and used[idx][2]!=dim:raise ValueError('Unsupported Unity normal/tangent/color/UV/weight channel dimensions.')
    result[0]=tuple(reflect(v) for v in result[0])
    if 1 in result:result[1]=tuple(reflect(v) for v in result[1])
    if 2 in result:result[2]=tuple((*reflect(v[:3]),-v[3]) for v in result[2])
    return result


def submeshes(mesh,count):
    size={0:2,1:4}.get(mesh.get('m_IndexFormat'))
    if size is None:raise ValueError('Unsupported Unity index format.')
    raw=blob(mesh['m_IndexBuffer']);rows=mesh['m_SubMeshes'];result=[];total=0
    if not isinstance(rows,list) or not 1<=len(rows)<=128 or len(raw)%size:raise ValueError('Invalid Unity submesh/index buffer.')
    for row in rows:
        if row['topology']!=0:raise ValueError('Only Unity triangle submeshes are supported.')
        start=integer(row['firstByte'],0,len(raw));n=integer(row['indexCount'],0,MAX_TRIANGLES*3);base=integer(row.get('baseVertex',0),0,count-1)
        first=integer(row['firstVertex'],0,count);number=integer(row['vertexCount'],0,count)
        if start%size or n%3 or start+n*size>len(raw) or first+number>count:raise ValueError('Unity submesh exceeds its declared streams.')
        total+=n//3
        if total>MAX_TRIANGLES:raise ValueError('Unity mesh exceeds 30,000 triangles.')
        indices=struct.unpack_from('<'+str(n)+('H' if size==2 else 'I'),raw,start)
        values=tuple(integer(v+base,first,first+number-1) for v in indices)
        faces=tuple((values[i+2],values[i+1],values[i]) for i in range(0,n,3))
        if any(len(set(t))!=3 for t in faces):raise ValueError('Unity submesh contains repeated-index triangles; inspect it in the source editor.')
        result.append(faces)
    return tuple(result)


def morphs(mesh,count,weights):
    shapes=mesh.get('m_Shapes',{});channels=shapes.get('channels',[]);frames=shapes.get('shapes',[]);vertices=shapes.get('vertices',[]);full=shapes.get('fullWeights',[])
    if not channels:
        if weights:raise ValueError('Renderer blendshape weights lack mesh channels.')
        return (),(),()
    if len(channels)>32 or count*len(channels)>200000 or len(weights)!=len(channels):raise ValueError('Unity blendshapes exceed preview limits or have missing weights.')
    from avatar_scene import name
    from avatar_scene_deform import morph_weights
    names=[];deltas=[];values=[]
    for i,ch in enumerate(channels):
        if ch['frameCount']!=1:raise ValueError('Multi-frame Unity blendshapes are not supported in this preview.')
        frame=integer(ch['frameIndex'],0,len(frames)-1)
        if frame>=len(full) or not 0<full[frame]<=1e9:raise ValueError('Invalid Unity blendshape full weight.')
        row=frames[frame];start=integer(row['firstVertex'],0,len(vertices));size=integer(row['vertexCount'],0,count)
        if start+size>len(vertices):raise ValueError('Unity blendshape exceeds its delta stream.')
        delta=[(0.,0.,0.)]*count;seen=set()
        for v in vertices[start:start+size]:
            idx=integer(v['index'],0,count-1)
            if idx in seen:raise ValueError('Repeated Unity blendshape vertex delta.')
            seen.add(idx);delta[idx]=reflect([v['vertex'][k] for k in ('x','y','z')])
        names.append(name(ch['name'],f'Blendshape {i+1}'));deltas.append(tuple(delta));values.append(weights[i]/full[frame])
    return tuple(names),tuple(deltas),morph_weights(values,len(names))
