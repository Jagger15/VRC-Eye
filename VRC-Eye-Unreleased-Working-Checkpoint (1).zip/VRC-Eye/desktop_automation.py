"""Opt-in executable entries and recovery driven by the existing runtime owner."""
from collections import deque
from hashlib import sha256
import os
from pathlib import Path
import subprocess
import time
import uuid
from avatar_library_files import checked_stream,fingerprint
from creator_projects import assert_no_links,local_path

KEY='desktop.automation.entries.v1'


def approve_executable(path,arguments,*,name='',delay=0,mode='Both',close_with_game=False):
    path=assert_no_links(local_path(path))
    if not isinstance(arguments,list) or len(arguments)>64 or any(not isinstance(v,str) or len(v)>4096 or '\0' in v for v in arguments):
        raise ValueError('Supply up to 64 literal arguments, one per line. Shell recipes are not supported.')
    if type(delay) is not int or not 0<=delay<=600 or mode not in ('Both','Desktop','VR'):raise ValueError('Choose a delay of 0–600 seconds and a supported mode.')
    if type(close_with_game) is not bool:raise ValueError('Child cleanup must be explicitly selected.')
    with checked_stream(path,limit=512*1024*1024) as (_,stream,info):
        header=stream.read(4);digest=sha256(header)
        if not ((os.name=='nt' and path.suffix.lower()=='.exe' and header.startswith(b'MZ')) or
                (os.name!='nt' and header==b'\x7fELF' and os.access(path,os.X_OK))):
            raise ValueError('Select a native executable, not a shortcut, script, installer recipe or desktop file.')
        for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
    return dict(id=uuid.uuid4().hex,name=(name.strip() or path.name)[:100],path=str(path),arguments=list(arguments),
                fingerprint=fingerprint(info),sha256=digest.hexdigest(),delay=delay,mode=mode,enabled=False,close_with_game=close_with_game)


class Automation:
    def __init__(self,store,*,clock=time.monotonic,wall=time.time,popen=subprocess.Popen):
        self.store,self.clock,self.wall,self.popen=store,clock,wall,popen
        self.runtime=None;self.pending={};self.history=deque(maxlen=100);self.stopped=False;self.children={};self.child_info={}
        self.recovery=None;self.recovery_future=None;self.handled_crashes=set();self.paused=False
        self.status='Automatic launch and crash recovery are disabled until explicitly enabled.'

    def record(self,operation,state,entry=''):
        row=dict(at=self.wall(),operation=operation,state=state,entry=entry)
        self.history.append(row)
        self.store.set_option('desktop.automation.history.v1',list(self.history))

    def cancel(self):
        self.pending.clear();self.recovery=None;self.paused=True
        self.status='Unstarted launches and crash recovery canceled. Explicitly resume to rearm.'

    def resume(self):self.paused=False;self.runtime=None;self.status='Armed for a new confirmed game start.'

    def observe_children(self,runtime,*,cleanup=False):
        for key,child in list(self.children.items()):
            info=self.child_info[key];result=child.poll()
            if result is not None:
                self.record('Child exit','Observed exit code '+str(result),info['name'])
                del self.children[key];del self.child_info[key];continue
            if cleanup and runtime.get('state') in ('EXITED_CLEANLY','CRASHED') and runtime.get('session')==info['session'] and info['cleanup'] and not info['requested']:
                info['requested']=True
                self.record('Child cleanup','Termination requested for this owned child',info['name'])
                try:child.terminate()
                except OSError:self.record('Child cleanup','Not confirmed; no force-kill attempted',info['name'])

    def tick(self,runtime,policy,service,companion,*,blocked=False):
        now=self.clock()
        self.observe_children(runtime,cleanup=not (self.stopped or blocked or self.paused) and policy.get('launch_apps',False))
        if self.stopped or blocked or self.paused:
            self.pending.clear();self.recovery=None;return
        token=(runtime.get('session'),tuple(runtime.get('identity') or ()))
        running=bool(runtime.get('identity')) and runtime.get('state') in ('RUNNING','DEGRADED','STARTING','INITIALIZING','UNRESPONSIVE')
        if running and token!=self.runtime:
            self.runtime=token;self.pending.clear();self.recovery=None
            mode='Unknown'
            for entry in runtime.get('bridge',{}).values():
                declared=entry.get('value',{}).get('vr_mode')
                if declared in ('vr','desktop'):mode='VR' if declared=='vr' else 'Desktop'
            for entry in self.store.option(KEY,[])[:32]:
                if entry.get('enabled') and entry.get('mode') in ('Both',mode):self.pending[entry['id']]=(now+entry['delay'],entry,token)
        elif not running:self.pending.clear()
        for key,(due,entry,expected) in list(self.pending.items()):
            if now<due:continue
            del self.pending[key]
            if not policy.get('launch_apps') or expected!=token:continue
            current=next((r for r in self.store.option(KEY,[]) if r.get('id')==key),None)
            if current!=entry:continue
            seen_key=sha256(repr((entry['id'],token[1])).encode()).hexdigest()
            attempts=self.store.option('desktop.automation.attempted.v1',[])
            if seen_key in attempts:continue
            # Persist before dispatch. A crash after this point never causes a
            # replay, even if the OS acknowledgement was lost.
            self.store.set_option('desktop.automation.attempted.v1',(attempts+[seen_key])[-256:])
            try:
                assert_no_links(local_path(entry['path']))
                with checked_stream(entry['path'],limit=512*1024*1024,expected=entry['fingerprint']) as (_,stream,_):
                    digest=sha256()
                    for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
                if digest.hexdigest()!=entry.get('sha256'):raise ValueError('The approved executable bytes changed or have no hash approval.')
                self.record('Launch','Dispatching; no outcome yet',entry['name'])
                process=self.popen([entry['path'],*entry['arguments']],shell=False,close_fds=True,cwd=str(Path(entry['path']).parent))
                child_key=uuid.uuid4().hex;self.children[child_key]=process
                self.child_info[child_key]=dict(name=entry['name'],session=runtime.get('session'),cleanup=entry.get('close_with_game',False),requested=False)
                self.record('Launch','Submitted; application readiness unconfirmed',entry['name'])
            except (ValueError,OSError):self.record('Launch','Not confirmed; inspect executable approval before retrying',entry['name'])
        if self.recovery_future and self.recovery_future.done():
            try:self.status=self.recovery_future.result();self.record('Recovery','Submitted; arrival unconfirmed')
            except Exception:self.status='Recovery was not confirmed. Review Unity Player and the action history.';self.record('Recovery','Not confirmed; automatic retry disabled')
            self.recovery_future=None
        if not policy.get('recover_crashes'):self.recovery=None;return
        # RuntimeModel requires a recent, process-bound explicit crash marker
        # plus repeated positive absence before it classifies CRASHED.
        incident=runtime.get('session')
        if runtime.get('state')=='CRASHED' and incident and incident not in self.handled_crashes and not self.recovery_future:
            self.handled_crashes.add(incident)
            attempts=[v for v in self.store.option('desktop.recovery.attempts.v1',[]) if 0<=self.wall()-v<3600]
            if len(attempts)>=policy.get('recovery_limit',2):
                self.paused=True;self.status='Crash-loop breaker paused recovery. Inspect diagnostics and resume explicitly.';return
            self.recovery=(now+policy.get('recovery_delay',30),incident)
        if self.recovery:
            due,incident=self.recovery
            if runtime.get('session')!=incident or runtime.get('state')!='CRASHED':self.recovery=None;return
            self.status=f'Observed crash: recovery in {max(0,int(due-now))} seconds. Cancel from Desktop controls.'
            if now>=due:
                self.recovery=None
                try:
                    context=(runtime['generation'],runtime['identity'])
                    review=companion.review_action('restart',context,automatic=True)
                    attempts=[v for v in self.store.option('desktop.recovery.attempts.v1',[]) if 0<=self.wall()-v<3600]
                    if attempts and self.wall()-attempts[-1]<300:raise ValueError('Recovery cooldown remains active.')
                    self.store.set_option('desktop.recovery.attempts.v1',attempts+[self.wall()])
                    self.recovery_future=service.submit('launch',policy.get('recovery_profile','Normal'),{},now+15,review,'restart')
                except ValueError as error:self.status=str(error);self.record('Recovery','Blocked before dispatch')

    def close(self):self.stopped=True;self.cancel()
