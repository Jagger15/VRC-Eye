"""Read-only setup checks over current owners; checks never start integrations."""
from functools import lru_cache
import importlib.util
from pathlib import Path
import platform
import sqlite3
import time
from urllib.parse import quote

DEPENDENCIES=(('psutil','Resource and process monitoring','Performance & Security'),
    ('PIL','Extended image formats and rounded controls','Customization'),('openvr','SteamVR input and overlays','VR Center'),
    ('cryptography','Optional encrypted recovery','Avatar Creator'),('lz4','Optional bundle inspection','Avatar Creator'),
    ('qrcode','QR quick links','Useful Links'),('vosk','Offline speech recognition','Accessibility'),('soundcard','Desktop caption loopback','Accessibility'))


@lru_cache(maxsize=16)
def available(module):
    try:return importlib.util.find_spec(module) is not None
    except (ImportError,ValueError):return False


def snapshot(shell,*,samples=None,dependency_check=available):
    app=shell.app;pages=getattr(shell,'pages',{});rows=[]
    def add(name,state,detail,route):rows.append(dict(id=name,name=name,state=state,detail=detail,route=route))
    if samples is None:
        samples={key:page.service.snapshot() if (page:=pages.get(title)) else {} for key,title in
            (('performance','Performance & Security'),('runtime','Unity Player'),('diagnostics','Crash & Diagnostics'),('media','Media & Audio'))}
    from session_restore import offline
    client=getattr(app,'api',None)
    add('VRChat connection','Offline' if offline(app) else 'Connected' if getattr(client,'authenticated',False) else 'Signed out',
        'Account-backed features use the active connection; local tools remain available.','Accounts')
    resource=samples.get('performance',{})
    add('Process and resource observations','Current' if resource and not resource.get('stale',True) else 'Unavailable / stale',
        'Steam/VRChat cards reuse this owner. A stale sample does not mean an application stopped.','Performance & Security')
    log=getattr(shell,'log',None)
    add('Game log','Observed' if log and log.items else 'No retained lines',
        f"{len(log.items) if log else 0} retained lines; {getattr(log,'dropped',0)} rolled out. Log silence does not establish a crash.",'Game Log')
    for key,title in (('runtime','Unity Player'),('diagnostics','Crash & Diagnostics'),('media','Media & Audio')):
        value=samples.get(key,{})
        if key=='media':state='Connected' if value.get('connected') else 'Not connected'
        elif key=='runtime':state='Enabled' if value.get('enabled') else 'Disabled / not started'
        else:state='Observed' if value.get('process_at') is not None else 'Not observed'
        add(title,state,'Open the existing workspace for provider details and controls.',title)
    for module,title,route in DEPENDENCIES:
        add(title+' dependency','Installed' if dependency_check(module) else 'Package unavailable',
            ('PNG wallpapers, resizing and opacity work without Pillow. JPEG/WebP and rounded decorations use Pillow.' if module=='PIL' else
             module+' availability only; native hardware/provider operation still requires its own check.'),route)
    creator=pages.get('Creator Projects')
    add('Creator VPM CLI','Reviewed this session' if getattr(creator,'cli',None) else 'Not reviewed',
        'Project inventory and copy-only jobs work without VPM. Running VPM requires a reviewed executable.','Creator Projects')
    add('Platform',platform.system() or 'Unknown','This report does not certify native integration or driver compatibility.','Settings')
    return dict(schema='vrc-eye-setup-health-1',checked=time.time(),rows=rows,
        scope='Local availability and existing-owner observations. No network request, executable launch, scan or automatic repair.')


def integrity(shell,*,stop=None,progress=lambda value:None,seconds=15):
    """Explicit bounded SQLite quick checks; output omits paths and record data."""
    from inspection_inputs import checkpoint
    deadline=time.monotonic()+seconds;results=[];seen=set()
    # NativeLibrary shares CompanionStore's database. Do not initialize it here:
    # constructing that owner can create tables or migrate older records.
    for title,store in (('Companion and native library',shell.store),):
        path=Path(store.path).absolute()
        if path in seen:continue
        seen.add(path);checkpoint(stop,deadline);progress('Checking '+title)
        if path.is_symlink() or not path.is_file():
            results.append(dict(store=title,state='Unavailable',detail='Database is missing or is a symbolic link.'));continue
        db=None
        try:
            db=sqlite3.connect('file:'+quote(str(path),safe='/')+'?mode=ro',uri=True,timeout=1)
            db.set_progress_handler(lambda:int(bool(stop and stop.is_set()) or time.monotonic()>deadline),1000)
            rows=db.execute('PRAGMA quick_check').fetchmany(101)
            checkpoint(stop,deadline)
            ok=rows==[('ok',)]
            results.append(dict(store=title,state='Passed' if ok else 'Needs attention',
                detail='SQLite quick_check completed.' if ok else 'SQLite reported integrity findings; no repair was attempted.'))
        except sqlite3.Error:
            checkpoint(stop,deadline)
            results.append(dict(store=title,state='Unavailable',detail='Database could not be checked; it may be busy, inaccessible or damaged.'))
        finally:
            if db is not None:db.close()
    return dict(schema='vrc-eye-local-store-check-1',checked=time.time(),results=results,
        scope='Read-only SQLite quick_check of the current companion stores. Asset files and cross-store consistency are not verified.')
