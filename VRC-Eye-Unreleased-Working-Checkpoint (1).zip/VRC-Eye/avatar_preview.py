"""Generic geometric preview and explicitly selected bounded static references.

No model loader, custom shader, asset download or live-avatar command is used.
The mannequin is deliberately isolated from Avatar Link and action providers.
"""
import base64
import math
from pathlib import Path
import struct

MAX_IMAGE_BYTES = 8 * 1024 * 1024
MAX_DIMENSION = 2048
MAX_PIXELS = 4 * 1024 * 1024
VIEWS = ('Front', 'Side', 'Back', 'Three-quarter')
POSES = ('T-pose', 'Relaxed', 'Seated')
HANDS = ('Left', 'Right', 'Both')
MODULES = ('Wrist controller', 'Battery display', 'Status badge', 'Contact button', 'Raycast marker')
PROVENANCE = 'Generic geometric mannequin. Demonstration only; actual avatar proportions, rig and runtime behavior are unknown.'


def _dimensions(width, height):
    if not 1 <= width <= MAX_DIMENSION or not 1 <= height <= MAX_DIMENSION or width * height > MAX_PIXELS:
        raise ValueError('Reference images must be at most 2048 × 2048 pixels.')


def inspect_reference(content):
    """Read dimensions without a decoder; reject animation and oversized data."""
    if not isinstance(content, bytes) or not 10 <= len(content) <= MAX_IMAGE_BYTES:
        raise ValueError('Select a PNG or single-frame GIF no larger than 8 MiB.')
    if content.startswith(b'\x89PNG\r\n\x1a\n'):
        if len(content) < 33 or content[12:16] != b'IHDR' or struct.unpack('>I', content[8:12])[0] != 13:
            raise ValueError('Invalid PNG header.')
        width, height = struct.unpack('>II', content[16:24])
        _dimensions(width, height)
        offset, chunks, ended = 8, 0, False
        while offset + 12 <= len(content):
            size = struct.unpack('>I', content[offset:offset + 4])[0]
            name = content[offset + 4:offset + 8]
            if size > MAX_IMAGE_BYTES or offset + 12 + size > len(content):
                raise ValueError('Invalid PNG chunk length.')
            if name in (b'acTL', b'fcTL', b'fdAT'):
                raise ValueError('Use a static reference; animated PNG is not supported.')
            chunks += 1
            if chunks > 4096:
                raise ValueError('The PNG contains too many chunks.')
            offset += 12 + size
            if name == b'IEND':
                ended = size == 0 and offset == len(content)
                break
        if not ended:
            raise ValueError('The PNG is incomplete or contains trailing data.')
        return dict(format='png', width=width, height=height, frames=1,
                    fidelity='Static creator-selected reference; not a runtime rendering.')
    if content.startswith((b'GIF87a', b'GIF89a')):
        if len(content) < 14:
            raise ValueError('Invalid GIF header.')
        width, height = struct.unpack('<HH', content[6:10])
        _dimensions(width, height)
        packed = content[10]
        offset = 13 + (3 * 2 ** ((packed & 7) + 1) if packed & 128 else 0)
        frames, blocks = 0, 0
        while offset < len(content):
            block = content[offset]
            offset += 1
            blocks += 1
            if blocks > 4096:
                raise ValueError('The GIF contains too many blocks.')
            if block == 0x3B:
                if frames != 1 or offset != len(content):
                    raise ValueError('Use a complete single-frame GIF without trailing data.')
                return dict(format='gif', width=width, height=height, frames=1,
                            fidelity='Static creator-selected reference; not a runtime rendering.')
            if block == 0x2C:
                if offset + 9 > len(content):
                    raise ValueError('Invalid GIF frame.')
                left, top, frame_width, frame_height = struct.unpack('<HHHH', content[offset:offset + 8])
                _dimensions(frame_width, frame_height)
                if left + frame_width > width or top + frame_height > height:
                    raise ValueError('The GIF frame exceeds its declared canvas.')
                frame_packed = content[offset + 8]
                offset += 9 + (3 * 2 ** ((frame_packed & 7) + 1) if frame_packed & 128 else 0)
                frames += 1
                if frames != 1:
                    raise ValueError('Use a static reference; animated GIF is not supported.')
                offset += 1  # LZW minimum code size; bounded decoding is left to Tk.
            elif block == 0x21:
                if offset >= len(content):
                    raise ValueError('Invalid GIF extension.')
                offset += 1  # Extension label.
            else:
                raise ValueError('Unknown GIF block.')
            while True:
                if offset >= len(content):
                    raise ValueError('Incomplete GIF sub-block.')
                size = content[offset]
                offset += 1
                if not size:
                    break
                offset += size
                if offset > len(content):
                    raise ValueError('Incomplete GIF sub-block.')
        raise ValueError('The GIF is incomplete.')
    raise ValueError('Only explicit PNG or single-frame GIF references are supported.')


def load_reference(path, *, authorized=False):
    if authorized is not True:
        raise ValueError('Confirm permission to use this particular reference image.')
    source = Path(path)
    if source.suffix.casefold() not in ('.png', '.gif'):
        raise ValueError('Choose a PNG or single-frame GIF reference.')
    if not source.is_file() or source.stat().st_size > MAX_IMAGE_BYTES:
        raise ValueError('Choose a reference file no larger than 8 MiB.')
    with source.open('rb') as stream:
        content = stream.read(MAX_IMAGE_BYTES + 1)
    info = inspect_reference(content)
    return dict(info, content=content, filename=source.name,
                provenance='Explicitly supplied local reference; permission declared by user. No source model loaded.')


def mannequin_scene(view='Front', pose='T-pose', hand='Left', module='Wrist controller',
                     offset=(0., 0., 0.), visual_scale=1., touch_scale=1., sample=.65):
    if view not in VIEWS or pose not in POSES or hand not in HANDS or module not in MODULES:
        raise ValueError('Choose supported mannequin options.')
    values = (*offset, visual_scale, touch_scale, sample)
    if len(offset) != 3 or any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise ValueError('Preview coordinates and sample values must be finite.')
    if any(abs(v) > .5 for v in offset) or not .2 <= visual_scale <= 3 or not .2 <= touch_scale <= 3 or not 0 <= sample <= 1:
        raise ValueError('Preview adjustments are outside demonstration limits.')
    nodes = {'head': (0., 1.65, 0.), 'neck': (0., 1.45, 0.), 'chest': (0., 1.28, 0.),
             'hip': (0., .9, 0.), 'shoulderL': (.25, 1.4, 0.), 'shoulderR': (-.25, 1.4, 0.),
             'hipL': (.15, .85, 0.), 'hipR': (-.15, .85, 0.)}
    for suffix, sign in (('L', 1), ('R', -1)):
        if pose == 'T-pose':
            nodes['elbow' + suffix] = (sign * .55, 1.4, 0.)
            nodes['wrist' + suffix] = (sign * .85, 1.4, 0.)
        else:
            nodes['elbow' + suffix] = (sign * .35, 1.08, .08)
            nodes['wrist' + suffix] = (sign * .32, .85, .18 if pose == 'Relaxed' else .5)
        nodes['knee' + suffix] = (sign * .15, .5 if pose != 'Seated' else .8, 0. if pose != 'Seated' else .4)
        nodes['foot' + suffix] = (sign * .15, .08 if pose != 'Seated' else .35, .08 if pose != 'Seated' else .45)
    bones = [('head', 'neck'), ('neck', 'chest'), ('chest', 'hip')]
    for suffix in ('L', 'R'):
        bones.extend([('neck', 'shoulder' + suffix), ('shoulder' + suffix, 'elbow' + suffix),
            ('elbow' + suffix, 'wrist' + suffix), ('hip', 'hip' + suffix),
            ('hip' + suffix, 'knee' + suffix), ('knee' + suffix, 'foot' + suffix)])
    angle = {'Front': 0, 'Side': 90, 'Back': 180, 'Three-quarter': 35}[view] * math.pi / 180
    def project(point):
        x, y, z = point
        return (x * math.cos(angle) + z * math.sin(angle), y)
    attachments = []
    for suffix in (('L', 'R') if hand == 'Both' else ('L',) if hand == 'Left' else ('R',)):
        origin = nodes['chest'] if module == 'Status badge' else nodes['wrist' + suffix]
        point = tuple(origin[i] + offset[i] for i in range(3))
        attachments.append(dict(anchor='chest' if module == 'Status badge' else 'wrist' + suffix,
            position=project(point), visual_scale=visual_scale, touch_scale=touch_scale,
            sample=sample, module=module, simulated=True))
        if module == 'Status badge':
            break
    return dict(nodes={name: project(point) for name, point in nodes.items()}, bones=bones,
                attachments=attachments, provenance=PROVENANCE, simulated=True,
                live_commands_sent=0, pose=pose, view=view)


class MannequinPreview:
    """A self-contained Tk pane; draws on user changes with no rendering worker."""
    def __init__(self, parent, tk, ttk):
        self.tk, self.ttk = tk, ttk
        self.closed, self.image, self.reference = False, None, None
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill='both', expand=True)
        self.message = tk.StringVar(value=PROVENANCE)
        ttk.Label(self.frame, textvariable=self.message, wraplength=820).pack(fill='x', padx=8, pady=6)
        controls = ttk.Frame(self.frame)
        controls.pack(fill='x', padx=8)
        self.view, self.pose, self.hand, self.module = (tk.StringVar(value=value) for value in ('Front', 'T-pose', 'Left', 'Wrist controller'))
        for label, variable, choices in (('View', self.view, VIEWS), ('Pose', self.pose, POSES),
                                        ('Hand', self.hand, HANDS), ('Module', self.module, MODULES)):
            ttk.Label(controls, text=label).pack(side='left', padx=(3, 1))
            choice = ttk.Combobox(controls, textvariable=variable, values=choices, state='readonly', width=16)
            choice.pack(side='left', padx=3)
            choice.bind('<<ComboboxSelected>>', lambda event: self.show_mannequin())
        adjustments = ttk.Frame(self.frame)
        adjustments.pack(fill='x', padx=8, pady=4)
        self.x, self.y, self.z, self.scale, self.touch, self.sample = (tk.DoubleVar(value=value) for value in (0, 0, 0, 1, 1, .65))
        for label, variable, low, high in (('X', self.x, -.5, .5), ('Y', self.y, -.5, .5),
                ('Depth', self.z, -.5, .5), ('Visual size', self.scale, .2, 3),
                ('Touch size', self.touch, .2, 3), ('Synthetic value', self.sample, 0, 1)):
            pane = ttk.Frame(adjustments)
            pane.pack(side='left', fill='x', expand=True)
            ttk.Label(pane, text=label).pack()
            ttk.Scale(pane, from_=low, to=high, variable=variable,
                      command=lambda value: self.show_mannequin()).pack(fill='x')
        self.canvas = tk.Canvas(self.frame, background='#111c2a', height=440, highlightthickness=0)
        from color_vision import canvas_ink
        canvas_ink(self.canvas)
        self.canvas.pack(fill='both', expand=True, padx=8, pady=6)
        self.canvas.bind('<Configure>', lambda event: self.draw())
        self.canvas.bind('<Map>', lambda event: self.draw())
        footer = ttk.Frame(self.frame)
        footer.pack(fill='x', padx=8, pady=6)
        ttk.Button(footer, text='Simulate button', command=self.simulate_button).pack(side='left')
        ttk.Button(footer, text='Generic mannequin', command=self.show_mannequin).pack(side='left', padx=4)
        self.permission = tk.BooleanVar(value=False)
        ttk.Checkbutton(footer, text='I have permission to use the selected reference', variable=self.permission).pack(side='left', padx=8)
        ttk.Button(footer, text='Open static reference…', command=self.choose_reference).pack(side='left')
        self.draw()

    def show_mannequin(self):
        self.reference, self.image = None, None
        self.message.set(PROVENANCE)
        self.draw()

    def simulate_button(self):
        self.show_mannequin()
        self.message.set('SIMULATION: input → accepted → demonstration result → released. No photograph, parameter write or live action was requested.')

    def choose_reference(self):
        from tkinter import filedialog, messagebox
        if not self.permission.get():
            messagebox.showinfo('Reference permission', 'Confirm that you have permission to use this selected reference image.', parent=self.frame)
            return
        path = filedialog.askopenfilename(parent=self.frame, filetypes=[('Static reference', '*.png *.gif')])
        if not path:
            return
        try:
            selected = load_reference(path, authorized=True)
            image = self.tk.PhotoImage(data=base64.b64encode(selected['content']).decode('ascii'), format=selected['format'])
            ratio = max(1, math.ceil(max(selected['width'] / 800, selected['height'] / 500)))
            self.image = image.subsample(ratio, ratio) if ratio > 1 else image
            self.reference = selected
            self.message.set(selected['provenance'] + ' Static reference only; pose and attachment simulation apply to the generic mannequin.')
            self.draw()
        except (OSError, ValueError, self.tk.TclError) as exc:
            messagebox.showerror('Reference unavailable', str(exc), parent=self.frame)

    def draw(self):
        if self.closed or not self.canvas.winfo_ismapped():
            return
        from color_vision import canvas_ink
        canvas = canvas_ink(self.canvas)
        canvas.delete('all')
        width, height = max(320, canvas.winfo_width()), max(260, canvas.winfo_height())
        if self.reference and self.image:
            canvas.create_image(width / 2, height / 2, image=self.image)
            canvas.backed_text(10, 10, anchor='nw', text='AUTHORIZED STATIC REFERENCE — runtime fidelity unverified', fill='@text')
            return
        scene = mannequin_scene(self.view.get(), self.pose.get(), self.hand.get(), self.module.get(),
            offset=(self.x.get(), self.y.get(), self.z.get()), visual_scale=self.scale.get(),
            touch_scale=self.touch.get(), sample=self.sample.get())
        scale = min(width / 2.5, height / 2.05)
        def pixel(point):
            return width / 2 + point[0] * scale, height - 35 - point[1] * scale
        for start, end in scene['bones']:
            canvas.create_line(*pixel(scene['nodes'][start]), *pixel(scene['nodes'][end]), fill='@muted', width=7)
        for name, position in scene['nodes'].items():
            x, y = pixel(position)
            radius = 15 if name == 'head' else 5
            canvas.create_oval(x-radius, y-radius, x+radius, y+radius, fill='@text', outline='')
            if name.startswith('wrist'):
                canvas.create_text(x, y-19, text='Left' if name.endswith('L') else 'Right', fill='@text')
        for attachment in scene['attachments']:
            x, y = pixel(attachment['position'])
            half = 12 * attachment['visual_scale']
            touch = 18 * attachment['touch_scale']
            canvas.create_oval(x-touch, y-touch, x+touch, y+touch, outline='@warning', dash=(3, 3))
            canvas.create_rectangle(x-half, y-half/2, x+half, y+half/2, fill='@success', outline='@text')
            canvas.create_text(x, y+touch+12, text=f'Simulated {attachment["sample"]:.0%}', fill='@text')
            if attachment['module'] == 'Raycast marker':
                canvas.create_line(x, y, x+80, y-50, fill='@warning', dash=(5, 3), arrow='last')
        canvas.create_text(12, 12, anchor='nw', text='GENERIC DEMONSTRATION • no live commands', fill='@text')
        canvas.create_text(12, height-12, anchor='sw', text='Dashed outline = separate illustrative touch volume', fill='@warning')

    def close(self):
        self.closed = True
        self.reference, self.image = None, None


def createpreview(parent, tk, ttk):
    return MannequinPreview(parent, tk, ttk)
