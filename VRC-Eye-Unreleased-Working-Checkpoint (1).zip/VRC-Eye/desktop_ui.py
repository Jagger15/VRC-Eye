"""Desktop controls in the existing Customization and VRCX workspaces."""
from copy import deepcopy
import json
from pathlib import Path
from tkinter import filedialog,simpledialog
from companion_ui import Table,line,button,entry,choice
from vrcx_ui_jobs import LocalPage
from desktop_service import service_for,settings,DEFAULTS


def show(shell):
    dialog=getattr(shell,'desktop_dialog',None)
    if dialog and not dialog.closed:dialog.window.lift();return dialog
    shell.desktop_dialog=DesktopDialog(shell);return shell.desktop_dialog


class DesktopDialog(LocalPage):
    def __init__(self,shell):
        app=shell.app;self.window=app.tk.Toplevel(app.root);self.window.title('Desktop controls')
        self.window.geometry('1120x850');self.window.minsize(700,500)
        from friendly_ui import ScrollPane
        self.viewport=ScrollPane(app,self.window,min_width=680)
        super().__init__(shell,self.viewport.body,'Desktop controls')
        self.service=service_for(shell);self.preview=None;self.report=None;self.config_receipt=None
        self.loaded_policy=deepcopy(self.service.policy)
        self.setup_privacy();self.vars={};tabs=self.ttk.Notebook(self.parent);self.tabs=tabs;tabs.pack(fill='both',expand=True)
        self.tabs=tabs
        self.frames={name:self.ttk.Frame(tabs,padding=10) for name in ('Setup','Notifications','Presence & health','Automation','Analytics','History & discovery','VRChat config','Profiles')}
        for name,frame in self.frames.items():tabs.add(frame,text=name)
        self.build_setup();self.build_notifications();self.build_presence();self.build_automation();self.build_analytics();self.build_config();self.build_profiles()
        from social_history_ui import HistoryPane
        self.history=HistoryPane(self,self.frames['History & discovery'])
        row=line(self);button(self,row,'Apply desktop settings…',self.apply);button(self,row,'Dismiss current banner',self.service.delivery.clear);button(self,row,'Close',self.close)
        self.live=self.tk.StringVar();self.ttk.Label(self.parent,textvariable=self.live,wraplength=980).pack(anchor='w',pady=8)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(300,self.tick)

    def explain(self,pane,text):self.ttk.Label(pane,text=text,wraplength=960,justify='left').pack(anchor='w',fill='x',pady=6)
    def boolean(self,pane,key,label):
        value=self.tk.BooleanVar(value=self.service.policy[key]);self.vars[key]=value
        self.ttk.Checkbutton(pane,text=label,variable=value).pack(anchor='w',pady=3)
    def field(self,pane,key,label,values=None):
        row=line(self,pane);self.ttk.Label(row,text=label,width=32).pack(side='left')
        current=self.service.policy[key]
        value=self.tk.StringVar(value=','.join(current) if isinstance(current,list) else str(current));self.vars[key]=value
        return choice(self,row,value,values,width=38) if values else entry(self,row,value,52)
    def form(self):
        value=deepcopy(self.service.policy)
        for key,var in self.vars.items():
            item=var.get()
            if type(DEFAULTS[key]) is int:
                try:item=int(item)
                except ValueError:raise ValueError(key+' needs a whole number.') from None
            elif isinstance(DEFAULTS[key],list):item=list(dict.fromkeys(v.strip() for v in item.split(',') if v.strip()))
            value[key]=item
        return settings(value)
    def apply(self):
        self.ready();token=self.token();value=self.form()
        if getattr(self,'loaded_policy',self.service.policy)!=self.service.policy:raise ValueError('Desktop settings changed in another editor. Reopen Desktop controls before applying this draft.')
        differences={k:v for k,v in value.items() if v!=self.service.policy[k]}
        if not differences:self.status.set('No settings changed.');return
        if not self.confirm('Review desktop settings',json.dumps(differences,indent=2,ensure_ascii=False)+'\n\nEnable only the services you want on this device?'):return
        self.verify(token)
        if value!=self.form():raise ValueError('Settings changed during review.')
        self.service.configure(value);self.loaded_policy=deepcopy(value);self.status.set('Desktop settings applied.')

    def build_setup(self):
        pane=self.frames['Setup']
        self.explain(pane,'Use VRC Eye by itself, migrate selected VRCX data, or keep both applications with explicit ownership preferences. Existing accounts, favorites, feeds, photos and diagnostics remain the daily workspaces.')
        row=line(self,pane);button(self,row,'Use VRC Eye standalone',self.standalone)
        button(self,row,'Migrate from VRCX…',lambda:__import__('native_data_ui').show(self.shell))
        button(self,row,'Use both: ownership settings',lambda:self.shell.show('VRCX Companion'))
        self.explain(pane,'Available here: native collections and history, reviewed account/social actions, media uploads, status, presence, notifications, local analytics, launch entries and crash recovery. Native Windows/Linux and live-account acceptance remain part of the next build validation.')
        self.explain(pane,'External setup still needed: Discord requires your registered public application ID. Signed app updates need a publisher endpoint and signing key. Steam/Discord/tray behavior depends on the installed desktop applications.')
        self.field(pane,'power','Desktop refresh budget',('Balanced','Low power'))
        self.explain(pane,'Low power or a minimized window slows unused optional sensors, public status polling and Unity metadata retries. Visible Home cards keep their providers responsive. Process monitoring, protection rules, recording and recovery checks keep their normal timing.')
        button(self,line(self,pane),'Picture cache…',lambda:__import__('picture_cache_ui').show(self.shell))
        self.field(pane,'autolock_minutes','Auto-lock after idle minutes (0 = off)')
        row=line(self,pane);button(self,row,'Set local lock passphrase…',self.setup_lock);button(self,row,'Lock now',self.service.app_lock.lock);button(self,row,'Unlock…',self.unlock);button(self,row,'Remove local lock…',self.remove_lock)
        self.explain(pane,'Locking hides private workspaces, cancels pending work and disconnects the active login. Unlock with your local passphrase, then sign in or restore a saved session. Files continue to use operating-system permissions.')
        self.boolean(pane,'background_photos','Allow approved photo watchers while the window is minimized')
        self.boolean(pane,'background_feed','Allow the enabled feed while the window is minimized')
        self.boolean(pane,'photo_context','Associate new photos only when embedded world / capture time corroborate the observed session')
        self.boolean(pane,'close_to_tray','Closing the window keeps Eye in the tray when a supported tray is available')
        button(self,line(self,pane),'Minimize window',self.app.root.iconify)
        row=line(self,pane);button(self,row,'Enable start with OS…',lambda:self.startup(True));button(self,row,'Disable start with OS',lambda:self.startup(False))
        button(self,line(self,pane),'Quit VRC Eye',self.app.close)
        self.explain(pane,'Tray support uses optional pystray and the desktop’s tray menu. If unavailable, the window stays reachable through normal minimize. Start with OS requires an installed executable and cannot be enabled from a source checkout.')
    def startup(self,enabled):
        self.ready();token=self.token()
        if enabled and not self.confirm('Start VRC Eye with the operating system','Register this installed executable for your user account at login?'):return
        self.verify(token);self.status.set(__import__('desktop_tray').startup(enabled))
    def setup_lock(self):
        self.ready();token=self.token()
        secret=simpledialog.askstring('Local lock','New local passphrase (8–256 characters):',show='*',parent=self.window);self.verify(token)
        if secret is None:return
        repeated=simpledialog.askstring('Local lock','Repeat the passphrase:',show='*',parent=self.window);self.verify(token)
        if secret!=repeated:raise ValueError('The passphrases did not match.')
        self.service.app_lock.setup(secret);self.status.set('Local lock configured.')
    def unlock(self):
        secret=simpledialog.askstring('Unlock VRC Eye','Local lock passphrase:',show='*',parent=self.window)
        if secret is not None:self.status.set(self.service.app_lock.unlock(secret))
    def remove_lock(self):
        self.ready();token=self.token();secret=simpledialog.askstring('Remove local lock','Current passphrase:',show='*',parent=self.window);self.verify(token)
        if secret is not None:self.service.app_lock.remove(secret);self.vars['autolock_minutes'].set('0');self.status.set('Local lock removed. Apply 0 idle minutes to disable auto-lock.')
    def standalone(self):
        self.ready();value=self.shell.companion.snapshot()['config'];value['enabled']=False
        self.shell.companion.configure(value);self.shell.store.set_option('vrcx.companion',value)
        self.status.set('Standalone mode selected. Optional VRCX imports remain available.')

    def build_notifications(self):
        pane=self.frames['Notifications']
        for key,label in (('banners','Show one shared desktop banner'),('sound','Play a single system sound for new events'),('dnd','Do not disturb'),('quiet_hours','Use local quiet hours'),('history_private_text','Retain private notification names / message text in local history')):
            self.boolean(pane,key,label)
        self.field(pane,'quiet_start','Quiet start: minute after midnight')
        self.field(pane,'quiet_end','Quiet end: minute after midnight')
        self.field(pane,'banner_seconds','Banner duration in seconds')
        self.field(pane,'notification_batch_seconds','Group arrivals within seconds (0–10)')
        self.field(pane,'notification_cooldown_seconds','Same sender/type alert cooldown (0–300)')
        self.explain(pane,'Grouping and cooldown affect alerts only. All observed notifications remain in the inbox. Catch-up snapshots are silent.')
        self.explain(pane,'Quiet hours use this computer’s current time zone. For example, 1320 is 22:00 and 480 is 08:00. Imported and refreshed history never produces new-event sounds. Notification history remains available when banners are muted.')
        button(self,line(self,pane),'Open Social inbox',lambda:self.shell.show('Social'))
        self.field(pane,'muted_types','Muted notification types (comma separated)')
        self.field(pane,'priority_types','Priority types (comma separated)')
        self.boolean(pane,'speech','Speak new notification summaries using local speech')
        self.boolean(pane,'speech_details','Include sender names / message text in spoken notifications')
        self.boolean(pane,'vr_notifications','Send new notifications to the shared SteamVR overlay once started')
        row=line(self,pane);button(self,row,'Start social overlay this session',self.service.start_social_overlay)
        button(self,row,'Show latest inbox in VR',self.service.show_social_feed)
        self.explain(pane,'Quiet hours, DND, category mutes and privacy apply to automatic speech and VR delivery. Speech uses Windows SAPI or installed Linux espeak. Start the shared SteamVR connection explicitly; no second VR runtime is opened.')

    def build_presence(self):
        pane=self.frames['Presence & health']
        self.boolean(pane,'health_poll','Refresh official public VRChat status every two minutes (backoff on errors)')
        button(self,line(self,pane),'Check official status once',self.check_health)
        self.boolean(pane,'discord','Publish presence to the local Discord desktop client')
        self.field(pane,'discord_application','Public Discord application ID')
        self.field(pane,'discord_details','Exact public presence text')
        self.field(pane,'discord_template','Presence template',('Custom','World name','World and session'))
        for key,label in (('discord_art','Share inspected world artwork'),('discord_join','Share a join button for the inspected public instance'),('discord_elapsed','Share observed session elapsed time')):self.boolean(pane,key,label)
        self.boolean(pane,'discord_requests','Use reviewed Discord join requests for that public instance')
        button(self,line(self,pane),'Inspect observed world / public instance for presence',self.inspect_presence)
        button(self,line(self,pane),'Preview public presence',self.preview_presence)
        self.explain(pane,'Preview the exact public presence payload. Optional artwork, elapsed time and public-instance links use an explicit inspection that expires after two minutes and must match the observed game account and session. Privacy view disables publishing. Private/group join capabilities and roster identities are excluded.')
        self.join_requests=Table(self,pane,(('name','Discord name',220),('id','Discord user ID',190),('state','Response',120)),height=3)
        row=line(self,pane);button(self,row,'Accept selected request…',lambda:self.answer_join(True));button(self,row,'Decline selected request…',lambda:self.answer_join(False))
        self.explain(pane,'Requests expire after two minutes and clear when presence changes. Accept sends a public-instance invitation to the displayed Discord ID. Discord names are unverified display text. No response is sent automatically.')
        self.discord_invites=Table(self,pane,(('world','Invited public world',380),('instance','Public instance',240)),height=2)
        button(self,line(self,pane),'Review selected invitation in World Visits',self.review_discord_invite)
    def review_discord_invite(self):
        self.ready();self.service.tick();review=self.discord_invites.selected()
        if not review:raise ValueError('Select a current public invitation.')
        row=self.service.presence.take_invitation(review)
        if not self.shell.ensure_page('World Visits'):raise ValueError('World Visits is unavailable.')
        page=self.shell.pages['World Visits'];page.set_world(row['world']);page.destination.set(row['id']);page.tabs.select(page.frames['Existing instance'])
        self.shell.show('World Visits');self.status.set('Public destination selected. Inspect and review the join in World Visits.')
    def answer_join(self,accept):
        self.ready();token=self.token();self.service.tick()
        row=self.join_requests.selected()
        if not row:raise ValueError('Select a current Discord join request.')
        if not self.confirm('Review Discord join response',('Send a public-instance invitation to ' if accept else 'Decline the request from ')+row['name']+'\nDiscord ID: '+row['id']+'?'):return
        self.verify(token);self.service.tick();self.service.presence.decide(row,accept)
        self.status.set('Response queued; see Discord status for acknowledgement.')
    def check_health(self):self.ready();self.service.health.request(explicit=True);self.status.set('Requested official public status; no account credentials are attached.')
    def preview_presence(self):
        self.ready();self.status.set(json.dumps(self.service.presence_payload(self.form()),ensure_ascii=False))

    def inspect_presence(self):
        self.ready();self.connected();meta=dict(getattr(getattr(self.app,'player_sessions',None),'meta',{}));ref=meta.get('world_id')
        from companion_data import entity_id
        entity_id('world',ref)
        def work(c,s,p):
            import native_api,world_visits
            world=native_api.read(c,'world',subject=ref,stop=s,progress=p);instance=None
            if meta.get('instance_id'):instance=world_visits.read_instance(c,meta['instance_id'],world=ref,stop=s,progress=p)
            return world,instance
        def done(result):
            if meta!=getattr(getattr(self.app,'player_sessions',None),'meta',{}):raise ValueError('The observed session changed during inspection.')
            self.service.presence_world,self.service.presence_instance=result;self.preview_presence()
        self.start(work,done,api=True)

    def build_automation(self):
        pane=self.frames['Automation'];self.boolean(pane,'launch_apps','Launch my approved executable entries on a confirmed game start')
        self.apps=Table(self,pane,(('name','Application',220),('mode','Mode',100),('delay','Delay (s)',90),('cleanup','Close with game',120),('enabled','Enabled',80)),height=5)
        row=line(self,pane);button(self,row,'Add executable…',self.add_app);button(self,row,'Enable / disable selected…',self.toggle_app);button(self,row,'Remove entry',self.remove_app)
        self.boolean(pane,'recover_crashes','Automatically request restart after an explicitly observed crash')
        self.field(pane,'recovery_delay','Cancellable delay (seconds)')
        self.field(pane,'recovery_limit','Maximum attempts per hour')
        self.field(pane,'recovery_profile','Recovery launch profile',('Normal','Desktop','Troubleshooting','Low overhead'))
        row=line(self,pane);button(self,row,'Cancel / pause automation',self.service.automation.cancel);button(self,row,'Resume for a new game start',self.service.automation.resume)
        self.explain(pane,'Recovery shares Unity Player’s process verification and Companion launch reservation. Normal exits and unknown process loss do not trigger it. A five-minute cooldown and hourly crash-loop limit apply. Restart permission does not grant private-instance rejoin permission.')
        button(self,line(self,pane),'Open Unity launch controls',lambda:self.shell.show('Unity Player'));self.refresh_apps()
    def refresh_apps(self):
        from desktop_automation import KEY
        self.apps.set(self.shell.store.option(KEY,[]),lambda r:(r['name'],r['mode'],r['delay'],'Yes' if r.get('close_with_game') else 'No','Yes' if r['enabled'] else 'No'))
    def add_app(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,title='Select a native executable')
        self.verify(token)
        if not path:return
        args=simpledialog.askstring('Literal arguments','Arguments, one per line (leave empty for none):',parent=self.window)
        self.verify(token)
        if args is None:return
        mode=simpledialog.askstring('Game mode','Both, Desktop or VR:',initialvalue='Both',parent=self.window);self.verify(token)
        if mode is None:return
        delay=simpledialog.askinteger('Start delay','Delay after observed start (0–600 seconds):',initialvalue=0,minvalue=0,maxvalue=600,parent=self.window);self.verify(token)
        if delay is None:return
        cleanup=self.confirm('Optional child cleanup','Request this application to terminate after the same observed VRChat session stops or crashes? Only the child launched by VRC Eye is affected. Choose No to leave it running.');self.verify(token)
        from desktop_automation import approve_executable,KEY
        def done(row):
            rows=self.shell.store.option(KEY,[])
            if len(rows)>=32:raise ValueError('Keep up to 32 approved executable entries.')
            self.shell.store.set_option(KEY,rows+[row]);self.refresh_apps();self.status.set('Entry saved disabled. Review it before enabling.')
        self.start(lambda c,s,p:approve_executable(path,args.splitlines(),delay=delay,mode=mode,close_with_game=cleanup),done)
    def toggle_app(self):
        self.ready();row=self.apps.selected();token=self.token()
        if not row:raise ValueError('Select an executable entry.')
        if not row['enabled'] and not self.confirm('Enable executable entry',row['path']+'\nArguments: '+json.dumps(row['arguments'])+'\nMode: '+row['mode']+f"\nDelay: {row['delay']} seconds\nClose owned child with game: {bool(row.get('close_with_game'))}\n\nAllow this exact executable to run automatically?"):return
        self.verify(token);from desktop_automation import KEY
        rows=self.shell.store.option(KEY,[])
        for current in rows:
            if current['id']==row['id']:
                if current!=row:raise ValueError('Entry changed; review again.')
                current['enabled']=not current['enabled']
        self.shell.store.set_option(KEY,rows);self.service.automation.pending.clear();self.refresh_apps()
    def remove_app(self):
        self.ready();row=self.apps.selected()
        if not row:raise ValueError('Select an entry.')
        from desktop_automation import KEY
        self.shell.store.set_option(KEY,[r for r in self.shell.store.option(KEY,[]) if r['id']!=row['id']]);self.service.automation.pending.clear();self.refresh_apps()

    def build_analytics(self):
        pane=self.frames['Analytics'];self.boolean(pane,'analytics','Allow local analysis of retained native observations')
        self.zone=self.tk.StringVar(value='UTC');row=line(self,pane);self.ttk.Label(row,text='IANA time zone').pack(side='left');entry(self,row,self.zone,35)
        self.analysis_after=self.tk.StringVar();self.analysis_before=self.tk.StringVar()
        row=line(self,pane);self.ttk.Label(row,text='Dates, inclusive (YYYY-MM-DD), from / through').pack(side='left');entry(self,row,self.analysis_after,14);entry(self,row,self.analysis_before,14)
        row=line(self,pane)
        button(self,row,'Analyze local records',self.analyze);button(self,row,'Export displayed CSV…',self.export_analytics)
        self.analytics=Table(self,pane,(('date','Date',150),('events','Observed events',160),('seconds','Observed subject-seconds',190),('derived','Derived subject-seconds',190)),height=8,select=self.analysis_selection)
        self.heat_metric=self.tk.StringVar(value='Observed events');row=line(self,pane)
        choice(self,row,self.heat_metric,('Observed events','Observed subject-seconds','Derived subject-seconds'),self.draw_heatmap,width=30)
        from screen_reader_model import annotate
        self.heatmap=self.tk.Canvas(pane,height=280,background='#15202b',highlightthickness=0,takefocus=False);self.heatmap.pack(fill='x',pady=6)
        from color_vision import canvas_ink
        canvas_ink(self.heatmap)
        self.heatmap.bind('<Configure>',lambda _:self.draw_heatmap())
        from color_vision import HEAT_LEGEND
        self.explain(pane, HEAT_LEGEND)
        self.hour_table=Table(self,pane,(('hour','Selected day / hour and UTC offset',240),('events','Events',100),('seconds','Observed seconds',160),('derived','Derived seconds',160)),height=5)
        self.analysis_note=self.tk.StringVar(value='No analysis requested. Imported aggregate snapshots remain separate from dated events.')
        self.ttk.Label(pane,textvariable=self.analysis_note,wraplength=920).pack(anchor='w')
    def analyze(self):
        self.ready()
        if not self.service.policy['analytics']:raise ValueError('Enable local analytics and apply settings first.')
        from desktop_analytics import summarize
        account=getattr(self.app.api,'user_id','') or 'shared';zone=self.zone.get();after=self.analysis_after.get();before=self.analysis_before.get()
        def work(c,s,p):
            with self.shell.store.native.connect() as db:
                total=db.execute("SELECT count(*) FROM eye_native_records WHERE scope IN (?,?) AND kind IN ('event','coverage','aggregate')",(account,'shared')).fetchone()[0]
                if total>100000:raise ValueError('This analysis is limited to 100,000 records. Narrow retained history before analyzing.')
                rows=[self.shell.store.native._row(r) for r in db.execute("SELECT * FROM eye_native_records WHERE scope IN (?,?) AND kind IN ('event','coverage','aggregate')",(account,'shared'))]
                # Project the existing friend-feed store. Do not create a second
                # history writer or copy private names/messages for analytics.
                for serial,user,kind,when in db.execute('SELECT serial,user_id,kind,checked FROM feed_events WHERE account=? ORDER BY serial DESC LIMIT 5000',(account,)):
                    rows.append(dict(scope=account,kind='event',id='feed:'+str(serial),data=dict(reported_time=when,user_id=user,category=kind)))
            return summarize(rows,zone,after=after,before=before,stop=s)
        def done(report):
            self.report=report;self.analytics.set(report['days'],lambda r:(r['date'],r['events'],r['observed_seconds'],r['derived_seconds']));self.draw_heatmap();self.analysis_selection()
            self.analysis_note.set(report['coverage']+f"\nZone: {report['zone']}; gaps: {report['gaps']}; undated: {report['undated_or_invalid']}; aggregate snapshots: {report['aggregate_snapshots']}")
        self.start(work,done)
    def analysis_selection(self):
        if not hasattr(self,'hour_table'):return
        row=self.analytics.selected()
        keys=sorted(set(row['hours'])|set(row['derived_hours'])|set(row['event_hours'])) if row else []
        self.hour_table.set(keys,lambda h:(row['date']+' '+h,row['event_hours'].get(h,0),round(row['hours'].get(h,0),3),round(row['derived_hours'].get(h,0),3)))
    def draw_heatmap(self):
        if not hasattr(self,'heatmap'):return
        from color_vision import canvas_ink, activity_band
        canvas=canvas_ink(self.heatmap, self.app);canvas.delete('all')
        from screen_reader_model import annotate
        annotate(self.heatmap,name='Activity heatmap',value=lambda:self.heat_metric.get(),description='Last 14 displayed days by local hour. Use the adjacent date/hour tables for every value, including repeated daylight-saving hours.')
        if not self.report:return
        rows=self.report['days'][-14:];metric={'Observed events':'event_hours','Observed subject-seconds':'hours','Derived subject-seconds':'derived_hours'}[self.heat_metric.get()]
        if not rows:return
        # Merge the two local DST occurrences only in this overview. The selected
        # day table keeps both offsets and the fold marker visible.
        matrix=[]
        for row in rows:
            values=[0.]*24
            for hour,value in row[metric].items():values[int(hour[:2])]+=value
            matrix.append(values)
        from ui_preferences import Presentation
        prefs=getattr(getattr(self.app,'experience',None),'preferences',Presentation())
        scale=prefs.font_percent/100;left=115*scale;row_height=24*scale
        maximum=max((v for row in matrix for v in row),default=0)
        width=max(canvas.winfo_width(),600*scale);cell=(width-left-10*scale)/24
        canvas.configure(width=600*scale,height=(35+len(rows)*24)*scale)
        for hour in range(24):canvas.create_text(left+hour*cell+cell/2,12*scale,text=str(hour),fill='@text')
        for index,(row,values) in enumerate(zip(rows,matrix)):
            y=26*scale+row_height*index;canvas.create_text(5*scale,y+8*scale,text=row['date'],anchor='w',fill='@text')
            for hour,value in enumerate(values):
                band=activity_band(value,maximum);x=left+hour*cell
                canvas.create_rectangle(x,y,x+cell-2*scale,y+18*scale,fill='@panel',outline='@line')
                for mark in range(band):
                    mx=x+(mark+1)*(cell-2*scale)/5
                    canvas.create_line(mx,y+5*scale,mx,y+13*scale,fill='@info',width=max(1,round(2*scale)))
        # All chart values are also exposed through keyboard-readable tables.
    def export_analytics(self):
        self.ready()
        if not self.report:raise ValueError('Analyze current observations first.')
        token=self.token();path=filedialog.asksaveasfilename(parent=self.window,defaultextension='.csv',initialfile='VRC-Eye-observed-activity.csv');self.verify(token)
        if path:__import__('desktop_analytics').export(path,self.report);self.status.set('Activity CSV saved.')

    def build_config(self):
        from desktop_config import ConfigEditor,FIELDS
        pane=self.frames['VRChat config'];self.editor=ConfigEditor();self.config_path=self.tk.StringVar();self.config_field=self.tk.StringVar(value=next(iter(FIELDS)));self.config_value=self.tk.StringVar();self.config_remove=self.tk.BooleanVar()
        row=line(self,pane);button(self,row,'Select VRChat config.json…',self.choose_config);entry(self,row,self.config_path,65)
        row=line(self,pane);choice(self,row,self.config_field,tuple(FIELDS),width=32);entry(self,row,self.config_value,50)
        self.ttk.Checkbutton(pane,text='Remove selected field to use VRChat’s documented default',variable=self.config_remove).pack(anchor='w')
        row=line(self,pane);button(self,row,'Review selected field change…',self.edit_config);button(self,row,'Restore previous edit…',self.restore_config)
        self.explain(pane,'Select the exact installation/account configuration. Unknown fields are preserved. A sibling backup is created before the atomic update; a concurrent change stops the operation. Restart VRChat to apply these settings. Boolean values use true or false; dimensions and limits use whole numbers.')
    def choose_config(self):
        self.ready();token=self.token();path=filedialog.asksaveasfilename(parent=self.window,title='Select the exact VRChat config.json',initialfile='config.json',defaultextension='.json');self.verify(token)
        if path:self.config_path.set(path)
    def edit_config(self):
        self.ready();from desktop_config import FIELDS
        key=self.config_field.get();rule=FIELDS[key];value=self.config_value.get()
        if self.config_remove.get():value=None
        elif rule is bool:
            if value not in ('true','false'):raise ValueError('Use true or false.')
            value=value=='true'
        elif isinstance(rule,tuple):
            try:value=int(value)
            except ValueError:raise ValueError('Use a whole number.') from None
        review=self.editor.prepare(self.config_path.get(),{key:value});self.commit_config(review)
    def commit_config(self,review):
        token=self.token()
        if not self.confirm('Review VRChat configuration',review.path+'\n\n'+json.dumps(review.diff,ensure_ascii=False,indent=2)+'\n\nSave this change and a rollback copy?'):return
        self.verify(token)
        def done(receipt):self.config_receipt=receipt;self.status.set(receipt['state']+' · Backup: '+receipt['backup'])
        self.start(lambda c,s,p:self.editor.commit(review,lambda:self.verify(token)),done,mutation=True)
    def restore_config(self):
        self.ready()
        if not self.config_receipt:raise ValueError('No config edit to restore in this session.')
        self.commit_config(self.editor.prepare_restore(self.config_receipt))

    def build_profiles(self):
        pane=self.frames['Profiles'];row=line(self,pane)
        button(self,row,'Export portable profile…',self.export_profile);button(self,row,'Review profile import…',self.import_profile)
        button(self,row,'Undo profile import…',self.undo_profile)
        button(self,line(self,pane),'Native data backup / restore…',lambda:__import__('native_data_ui').show(self.shell))
        button(self,line(self,pane),'Selective settings backup / undo…',lambda:__import__('settings_bundle_ui').show(self.shell))
        self.explain(pane,'Profiles include presentation, dashboard layouts and desktop preferences. Login sessions, executable approvals and external-service permissions are excluded. Import and undo keep publishing and automation disabled until you enable them separately.')
        self.explain(pane,'App update installation remains unavailable: no publisher endpoint or signing key has been configured. Your working source is never replaced by an unsigned update.')
    def export_profile(self):
        self.ready();token=self.token();path=filedialog.asksaveasfilename(parent=self.window,defaultextension='.json',initialfile='VRC-Eye-desktop-profile.json');self.verify(token)
        if not path:return
        from creator_projects import assert_no_links,local_path
        path=assert_no_links(local_path(path))
        with path.open('x',encoding='utf-8') as stream:json.dump(self.service.profile(),stream,ensure_ascii=False,indent=2)
        self.status.set('Portable profile exported with permissions disabled.')
    def import_profile(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,filetypes=[('Profile JSON','*.json')]);self.verify(token)
        if not path:return
        from customization import read_document
        raw=read_document(path)
        if not self.confirm('Import desktop profile',json.dumps(raw,ensure_ascii=False,indent=2)+'\n\nApply this profile with publishing, history grants and automation disabled?'):return
        self.verify(token);self.service.import_profile(raw);self.clear_preview();self.status.set('Profile imported. Reopen Desktop controls to edit the imported settings.')
    def undo_profile(self):
        self.ready();raw=self.shell.store.option('desktop.profile.undo.v1')
        if not raw:raise ValueError('No profile import to undo.')
        token=self.token()
        if self.confirm('Restore prior desktop preferences','Restore the previous profile with grants disabled?'):
            self.verify(token);self.service.import_profile(raw);self.status.set('Previous profile restored; grants remain disabled.')

    def clear_preview(self):
        self.preview=None;self.report=None
        if hasattr(self,'history'):self.history.clear()
        if hasattr(self,'analytics'):self.analytics.set([],lambda r:())
        if hasattr(self,'heatmap'):self.heatmap.delete('all')
        if hasattr(self,'hour_table'):self.hour_table.set([],lambda r:())
        if hasattr(self,'live'):self.live.set('Private details cleared.')
        if hasattr(self,'join_requests'):self.join_requests.set([],lambda r:())
        if hasattr(self,'discord_invites'):self.discord_invites.set([],lambda r:())
    def tick(self):
        if self.closed:return
        self.tick_job()
        if hasattr(self,'history'):self.history.tick()
        if not self.private_value:
            health=self.service.health.snapshot();data=health['data'];status=(data['description'] if data else 'Unknown')+(' · stale' if health['stale'] else '')
            self.live.set('VRChat status: '+status+'\nDiscord: '+self.service.presence.status+' · '+self.service.presence.join_status+'\nAutomation: '+self.service.automation.status)
            self.join_requests.set(self.service.presence.pending_requests(),lambda r:(r['name'],r['id'],r['state']),identity=lambda r:r['review'])
            self.discord_invites.set(self.service.presence.pending_invitations(),lambda r:(r['world'],r['instance']),identity=lambda r:r['review'])
        self.timer=self.app.root.after(500,self.tick)
    def close(self):
        if self.closed:return True
        super().close()
        if hasattr(self,'history'):self.history.close()
        if getattr(self,'timer',None):self.app.root.after_cancel(self.timer)
        self.window.destroy();return True
