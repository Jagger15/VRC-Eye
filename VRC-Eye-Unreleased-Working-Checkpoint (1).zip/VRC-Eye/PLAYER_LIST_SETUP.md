# Player sessions — VRC Eye 1.18.6

Open **Primary → World → Players**. The roster works from the local log without
VRCX, a map, JSON imports, a login, or a client bridge. Missing data stays unknown.
The retained **Map**, **Avatars**, account editor, profile and backup functions
remain available through their existing pages.

## Views and navigation

- **Compact**, **Standard**, **Detailed**, and **Columns** choose a saved set of
  columns. **Player settings → Display** customizes the current layout. Name is
  always included. Casual hides technical columns; Advanced and Developer expose
  them. Large rows and keyboard selection/Enter are supported.
- Sorting covers pins/friends, name, join order, recent joins, elapsed time,
  roles, stored encounters, avatar errors and resource observations. Recently
  departed players appear after active players, normally for three minutes.
- Search matches names, exact user IDs, locally observed names and tags. Notes
  are excluded unless enabled. Optional queries include `tag:photography`,
  `role:"Group Moderator"`, `friend:friend`, `pinned:true`, and `avatar:fox`.
- Lists show at most 100 rows per page. Previous/Next change pages without
  imposing a storage limit. Row values update only when their displayed content
  changes; fresh bridge indicators are checked four times per second.
- Selecting a player opens **Player details**. Casual shows Overview, History
  and Notes. Advanced/Developer also show Session, Avatar, Safety and Advanced.
  **Full profile** opens the established profile window, including its images,
  bio, groups, own-account controls and opt-in whisper pairing. Open windows keep
  their original session rather than silently switching to another person.
- Right-click or Shift+F10 offers details, notes/tags, a local incident bookmark,
  session pin, local favorite and copying available names/IDs. Presentation mode
  removes private identifiers from these actions.

## Identity and observations

Only a complete logged/API/approved-bridge account ID identifies an account.
Name-only observations use provisional keys. One unique provisional observation
can resolve to a confirmed account while preserving the original join time;
ambiguous matches remain uncertain. Helper-only map markers never gain an account
ID just because their display name matches someone.

The log worker emits normalized events to a central player-session service.
Immutable cards carry source, confidence, observation time and expiry. Advanced
shows the individual source observations, including expired values. Roles can
coexist: world creator, instance owner, network master, group owner/admin/moderator
and VRChat staff are distinct facts. The row shows up to three role labels plus
an overflow count; details show all roles.

Duplicate log events do not shift a join time. A world change closes the local
observation with `INSTANCE_ENDED`; it does **not** invent another player's leave
time. Missing logs retain a stale roster. Reconstructed, still-open visits show
an unknown elapsed time until new evidence arrives. Interrupted database records
are marked reconciling. Watching another log can rebuild the current projection;
deterministic encounter IDs prevent replay from duplicating stored visits.

## Local history and privacy

New installations default to **Session only**. Choose 7, 30, 90 days or Forever to
enable encounter storage. An encounter is an observed visit; a rejoin within the
configured window (60 seconds by default) merges into the previous encounter in
that same instance. Shared time sums observed visit segments and excludes the
gap. Missing joins and interrupted observations cannot supply an exact duration.
Counts in details refer to stored encounters and refresh after queued writes.

World name/ID history and avatar history are separate, initially disabled choices.
Raw instance codes, API profiles, voice samples and distances are not written to
the player-history database. An optional incident bookmark stores your explicit
note, up to 30 local timeline events and 20 nearby RAM samples. It is not a report
and does not establish that a person caused a problem.

**Incognito** keeps the live list working and discards the current session's
stored encounters, avatar observations and incidents, including data queued before
the switch. It also removes automatic name observations attributable to that
session. Explicit notes, tags and favorites remain. Hash-only suppression markers
prevent a later replay from restoring deleted records or an incognito session.
Disabling incognito takes effect for the next instance's history.

Notes are limited to 20,000 characters, and each player can have 30 private tags.
Favorites use the same unrestricted local store as **Favorites → VRC Eye Favorites**;
they do not change game favorites. Pins last only for the current instance.
Each player has a separate history-storage switch. Turning it off suppresses
future automatic writes; use deletion controls to remove existing records.

History is paged by encounters, avatar observations or incidents. Delete an exact
record, clear encounters while retaining notes/tags/favorites, or explicitly
delete all of that player's local data. **Export category** exports the whole
chosen category for that player to JSON, including all pages; notes and unrelated
categories are excluded. Deletion and retention do not touch Wellness history.

Presentation mode hides private notes, tags, names history, IDs, encounter details,
incident details and player timelines; it blocks private profile/export actions
and hides already-open profile windows. Optional aliases remain stable within
the current instance and are used for associated map markers too. Player banners
are suppressed. Other application pages have their own presentation/privacy
controls: this is a player-list privacy setting, not a screen-wide redaction tool.

## API enrichment

**Refresh world / friends** supplies the existing world capacity and friend-count
snapshots. The roster reuses a fresh friend-list snapshot; an unknown relationship
is never classified as a non-friend. Details can explicitly refresh relationship
status, including incoming/outgoing requests, and fetch roles for the selected
player. Profile and group lookups are lazy, cached and account scoped. Opening a
crowded instance does not trigger a profile request per player.

Role lookups share the existing conservative API rate limit (one metadata request
per minute), so a first group-role lookup can take several minutes. Closing its
window cancels the lookup. Results from a changed account or instance are discarded.
Individual facts retain the observation time of cached data and expire separately.
A role title such as “Admin” is not proof of permissions. Group moderators require
the returned moderation permission; group admins require the all-permissions role.
An API-confirmed `admin_moderator` tag supplies the separate VRChat Staff role.
Denied or missing information stays unknown.

**Friends / mute / block** opens the existing Social page with the exact selected
ID. Its reviewed actions remain explicit. Reading your own mute/block/request
lists can enrich the roster; absence from a single API page does not prove an
unmuted/unblocked state. The app cannot determine who muted or blocked you.

Full-profile previews load only when requested, with the existing host, cookie,
redirect, image-size and decode limits. A memory-only LRU now holds at most 32
previews / 8 MiB for five minutes, scoped to the signed-in account and revision.

## Optional bridge and resources

Stock log monitoring remains independent of the bridge. A compatible adapter must
advertise and receive approval for **instance.context**, and continuously report
the exact world/instance matched by the log. Each additional capability needs its
own approval. Older adapters without this context capability cannot attach player
telemetry to the new roster; their existing bridge diagnostics remain available.

- Voice activity expires after one second, accounting for source sample age;
  a 200 ms release hold smooths brief silence. Voice samples are not retained.
- Straight-line distance is displayed in feet, normally only for the selected or
  pinned player, and expires after at most three seconds. “Visible rows” widens
  display; actual producer sampling priorities remain the adapter's responsibility.
- Avatar load state, performance rank and texture-memory estimates appear only
  from associated data. Performance requires a matching avatar ID. Texture memory
  is **not total VRAM usage**. A loading timeout is an observation, not a diagnosis.
- Approved selection following is optional; opening details automatically is a
  separate setting. Disconnect, expiry, permission loss, account/runtime change
  or instance mismatch clears transient player fields.
- Safety offers voice mute/unmute, avatar visibility/audio, particles, lights,
  interactions and described client presets. A review identifies the exact user
  and client; submission rechecks the session, target and permission. Unconfirmed
  requests are not retried. VRC Eye does not bundle or inject a custom client.

Optional RAM observations use `psutil`, prepared automatically by **Start.cmd**, or approved
runtime RAM telemetry. The OS sampler identifies one VRChat process by name/PID/
creation time and reads process statistics, not memory contents. A configurable
pre/post window relates a RAM increase to nearby avatar changes, labels multiple
possible associations and explicitly leaves the cause unknown. There is no
per-avatar RAM/VRAM attribution, GPU measurement, player risk score or accusation.

## Diagnostics and later scope

**Diagnostics** offers aggregate service health, a 128-player synthetic run and
local log replay. Replay runs in a separate in-memory service without API calls,
bridge access or database writes. Reports omit names, user IDs and instance codes.
The same tools are available as `python player_replay.py --synthetic 128` or
`python player_replay.py --log "C:\\path\\output_log.txt"`. Replay accepts UTF-8
and BOM UTF-16 logs up to 256 MiB.

The supplied 194-part document explicitly includes later phases and eventual
features. This release implements the standalone session/history/roster workflow
and the connected bridge surfaces described above. VRC Eye discovery badges,
ready checks, shared bookmarks, party tracking, player-list VR/wrist/phone views,
photo associations and a full Black Box/Safety Center are later work. The existing
Wellness overlay and paired whispers remain separate. See the implementation map
in **PLAYER_LIST_DESIGN_INPUT.md**; the duplicate uploads are preserved once.

API references reviewed for these additions: [instance](https://vrchat.community/reference/get-instance),
[group member](https://vrchat.community/reference/get-group-member),
[group roles](https://vrchat.community/reference/get-group-roles),
[user tags](https://vrchat.community/tags/user), and
[friend status](https://vrchat.community/reference/get-friend-status).
Live server visibility can differ. These are community-maintained API references.
