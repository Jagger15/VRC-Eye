"""Typed OSC contracts. Descriptions are evidence, never authorization.

Native contracts checked against VRChat input, tracking and avatar-scaling docs,
and the official OSC and Camera Dolly wiki pages on 2026-10-01. A documented
endpoint is not a claim that the selected client, mode or world supports it.
"""
from dataclasses import asdict, dataclass, replace
import math
import re
import struct

from avatar_manifest import BUILTIN_PARAMETERS

SOURCES = (
    "https://docs.vrchat.com/docs/osc-as-input-controller",
    "https://docs.vrchat.com/docs/osc-eye-tracking",
    "https://docs.vrchat.com/docs/osc-trackers",
    "https://docs.vrchat.com/docs/osc-avatar-scaling",
    "https://wiki.vrchat.com/wiki/OSC",
    "https://wiki.vrchat.com/wiki/Camera_Dolly",
)
SCOPES = frozenset(("input", "microphone", "chatbox", "camera", "camera.pose",
    "dolly", "tracking.eye", "tracking.body", "avatar.parameters", "avatar.public",
    "avatar.switch", "avatar.scale", "debug", "safety", "protective"))
_TAGS = {"Bool": "b", "Int": "i", "Float": "f", "String": "s",
         "bool": "b", "int": "i", "float": "f", "string": "s",
         "T": "b", "F": "b", "b": "b", "i": "i", "f": "f", "s": "s"}
_ADDRESS = re.compile(r"/[A-Za-z0-9_.\-/]{1,255}\Z")


def valid_address(address):
    return (isinstance(address, str) and bool(_ADDRESS.fullmatch(address))
            and all(part not in ("", ".", "..") for part in address[1:].split("/")))


def typed_args(args):
    if not isinstance(args, (tuple, list)) or len(args) > 16:
        raise ValueError("OSC arguments must be an explicit list of at most 16 typed values.")
    for value in args:
        if type(value) not in (int, float, bool, str):
            raise ValueError("Unsupported OSC value type.")
        if type(value) is int and not -(2 ** 31) <= value < 2 ** 31:
            raise ValueError("OSC integers must fit signed 32 bits.")
        if type(value) is float and (not math.isfinite(value) or abs(value) > 3.4028234e38):
            raise ValueError("OSC floats must be finite 32-bit values.")
        if type(value) is str and ("\x00" in value or len(value.encode("utf-8")) > 49152):
            raise ValueError("OSC text is too large or contains a NUL character.")
    return tuple(args)


def same_arguments(left, right):
    """Compare exact OSC wire values, accounting only for float32 encoding.

    This is not an approximate numeric conversion: integer, Boolean and float
    values remain distinct, and two different representable floats differ.
    """
    if len(left) != len(right):
        return False
    for a, b in zip(left, right):
        if type(a) is not type(b):
            return False
        if type(a) is float:
            if not math.isfinite(a) or not math.isfinite(b):
                return False
            try:
                if struct.pack(">f", a) != struct.pack(">f", b):
                    return False
            except OverflowError:
                return False
        elif a != b:
            return False
    return True


@dataclass(frozen=True)
class Endpoint:
    address: str
    types: tuple
    permission: str
    direction: str = "both"
    behavior: str = "assignment"
    minimum: object = None
    maximum: object = None
    units: str = ""
    meaning: str = ""
    evidence: str = "documented, not discovered"
    conflict_group: str = ""
    cleanup: object = None
    confirmation: str = "matching state observed; causation unproven"
    compatibility_required: bool = False
    public: bool = False
    custom: bool = False
    observation_types: object = None

    @property
    def read_only(self):
        return self.direction == "read"

    def snapshot(self):
        result = asdict(self)
        result["read_only"] = self.read_only
        result["scope"] = self.permission
        return result


class EndpointRegistry:
    """Finite native allowlist plus explicitly loaded custom parameter metadata."""
    def __init__(self):
        self._items = {}
        self._tested = set()
        self.revision = 0
        self._native()

    def _add(self, address, types, permission, **fields):
        item = Endpoint(address, tuple(types), permission, **fields)
        self._items[address] = item
        return item

    def _native(self):
        axes = ("Vertical", "Horizontal", "LookHorizontal", "LookVertical", "UseAxisRight",
                "GrabAxisRight", "MoveHoldFB", "SpinHoldCwCcw", "SpinHoldUD", "SpinHoldLR")
        for name in axes:
            group = ("input:movement" if name in ("Vertical", "Horizontal") else
                     "input:look" if name.startswith("Look") else "input:" + name)
            self._add("/input/" + name, "f", "input", direction="write", behavior="continuous",
                minimum=-1.0, maximum=1.0, cleanup=(0.0,), conflict_group=group,
                compatibility_required=name in ("LookVertical", "UseAxisRight", "GrabAxisRight"),
                confirmation="local transmission only")
        buttons = ("MoveForward", "MoveBackward", "MoveLeft", "MoveRight", "LookLeft", "LookRight",
            "Jump", "Run", "ComfortLeft", "ComfortRight", "DropRight", "UseRight", "GrabRight",
            "DropLeft", "UseLeft", "GrabLeft", "PanicButton", "QuickMenuToggleLeft",
            "QuickMenuToggleRight", "Voice", "AFKToggle", "ToggleSitStand")
        for name in buttons + tuple("ShowDebugInfo" + str(n) for n in range(10)):
            scope = ("microphone" if name == "Voice" else "safety" if name == "PanicButton"
                     else "debug" if name.startswith("ShowDebug") else "input")
            group = ("input:movement" if name.startswith("Move") else "input:look" if
                     name.startswith(("Look", "Comfort")) else "input:" + name)
            self._add("/input/" + name, "i", scope, direction="write", behavior="pulse",
                minimum=0, maximum=1, cleanup=(0,), conflict_group=group,
                compatibility_required=name in ("AFKToggle", "ToggleSitStand", "ShowDebugInfo0"),
                confirmation="local transmission only; never retry a toggle automatically")
        self._add("/chatbox/input", "sbb", "chatbox", direction="write", behavior="publication",
                  conflict_group="chatbox", confirmation="submitted; visibility unconfirmed")
        self._add("/chatbox/typing", "b", "chatbox", direction="write", cleanup=(False,))
        self._add("/avatar/change", "s", "avatar.switch", behavior="assignment",
                  confirmation="requested avatar identity observed")
        self._add("/avatar/eyeheight", "f", "avatar.scale", minimum=0.01, maximum=10000.0,
                  units="meters", meaning="Supported range 0.1–100 m; world may enforce another value")
        for name in ("eyeheightmin", "eyeheightmax"):
            self._add("/avatar/" + name, "f", "avatar.scale", direction="read", units="meters")
        self._add("/avatar/eyeheightscalingallowed", "b", "avatar.scale", direction="read")
        bools = {"IsLocal", "IsOnFriendsList", "IsAnimatorEnabled", "Grounded", "Seated", "AFK",
                 "MuteSelf", "InStation", "Earmuffs", "ScaleModified"}
        ints = {"PreviewMode", "Viseme", "GestureLeft", "GestureRight", "TrackingType", "VRMode", "AvatarVersion"}
        for name in BUILTIN_PARAMETERS:
            self._add("/avatar/parameters/" + name, "b" if name in bools else "i" if name in ints else "f",
                      "avatar.parameters", direction="read", meaning="Reserved VRChat telemetry")
        self._add("/usercamera/Mode", "i", "camera", minimum=0, maximum=6)
        self._add("/usercamera/Pose", "ffffff", "camera.pose", behavior="continuous",
                  units="meters and Euler degrees", compatibility_required=True,
                  evidence="conflicting documentation: release notes writable; official OSC wiki read-only",
                  meaning="Writing may enter remote camera control; deliberate compatibility test required")
        for name in ("Close", "Capture", "CaptureDelayed"):
            self._add("/usercamera/" + name, "b", "camera", direction="write", behavior="pulse",
                      cleanup=(False,), confirmation="command sent; capture outcome unconfirmed")
        toggles = ("ShowUIInCamera", "LocalPlayer", "RemotePlayer", "Environment", "GreenScreen", "Lock",
            "SmoothMovement", "LookAtMe", "AutoLevelRoll", "AutoLevelPitch", "Flying", "TriggerTakesPhotos",
            "DollyPathsStayVisible", "AudioFromCamera", "ShowFocus", "Streaming", "RollWhileFlying",
            "OrientationIsLandscape")
        for name in toggles:
            self._add("/usercamera/" + name, "b", "camera",
                compatibility_required=name == "AudioFromCamera",
                evidence="conflicting published type descriptions" if name == "AudioFromCamera" else "documented, not discovered")
        sliders = {"Zoom": (20.,150.), "Exposure": (-10.,4.), "FocalDistance": (0.,10.), "Aperture": (1.4,32.),
            "Hue": (0.,360.), "Saturation": (0.,100.), "Lightness": (0.,50.), "LookAtMeXOffset": (-25.,25.),
            "LookAtMeYOffset": (-25.,25.), "FlySpeed": (.1,15.), "TurnSpeed": (.1,5.),
            "SmoothingStrength": (.1,10.), "PhotoRate": (.1,2.), "Duration": (.1,60.)}
        for name, limits in sliders.items():
            self._add("/usercamera/" + name, "f", "camera", minimum=limits[0], maximum=limits[1],
                compatibility_required=name == "Lightness",
                evidence="conflicting published default and range" if name == "Lightness" else "documented, not discovered")
        self._add("/dolly/Play", "b", "dolly", cleanup=(False,), conflict_group="dolly:playback")
        self._add("/dolly/PlayDelayed", "f", "dolly", direction="write", minimum=0., maximum=60.,
                  units="seconds", conflict_group="dolly:playback", confirmation="delay requested, not playback confirmed")
        self._add("/dolly/Import", "s", "dolly", direction="write", meaning="Reviewed JSON path data")
        self._add("/dolly/Export", "", "dolly", observation_types=("s",),
                  confirmation="export path observed; contents not verified")
        eye = {"EyesClosedAmount": 1, "CenterPitchYaw": 2, "CenterPitchYawDist": 3, "CenterVec": 3,
               "CenterVecFull": 3, "LeftRightPitchYaw": 4, "LeftRightVec": 6}
        for name, count in eye.items():
            self._add("/tracking/eye/" + name, "f" * count, "tracking.eye", direction="write",
                behavior="continuous", conflict_group="tracking:eyelids" if name == "EyesClosedAmount" else "tracking:gaze",
                minimum=0. if name == "EyesClosedAmount" else None,
                maximum=1. if name == "EyesClosedAmount" else None,
                meaning="Stop the source to return to native eye behavior after its timeout", confirmation="local transmission only")
        for tracker in tuple(str(n) for n in range(1, 9)) + ("head",):
            for kind in ("position", "rotation"):
                self._add("/tracking/trackers/" + tracker + "/" + kind, "fff", "tracking.body",
                    direction="write", behavior="continuous", conflict_group="tracking:body:" + tracker,
                    units="meters" if kind == "position" else "Euler degrees", confirmation="local transmission only")
        for part in ("head", "leftwrist", "rightwrist"):
            self._add("/tracking/vrsystem/" + part + "/pose", "ffffff", "tracking.body", direction="read")

    def get(self, address):
        return self._items.get(address)

    def endpoints(self):
        return tuple(self._items.values())

    def snapshot(self):
        return [dict(item.snapshot(), tested=item.address in self._tested) for item in self.endpoints()]

    def register_parameter(self, address, kind, minimum=None, maximum=None, read_only=False,
                           evidence="advertised, not tested", public=False, cleanup=None, **metadata):
        if not address.startswith("/avatar/parameters/") or not valid_address(address):
            raise ValueError("Custom controls must use a literal avatar parameter address.")
        name = address[len("/avatar/parameters/"):]
        if name in BUILTIN_PARAMETERS:
            return self._items[address]
        tag = _TAGS.get(kind)
        if tag not in ("b", "i", "f"):
            raise ValueError("Avatar parameters require Bool, Int or Float metadata.")
        for bound in (minimum, maximum):
            if bound is not None and (type(bound) not in (int, float) or not math.isfinite(bound)):
                raise ValueError("Parameter bounds must be finite numbers.")
        if minimum is not None and maximum is not None and minimum > maximum:
            raise ValueError("Minimum exceeds maximum.")
        if cleanup is not None:
            cleanup = typed_args(cleanup)
            expected = {"b": bool, "i": int, "f": float}[tag]
            if len(cleanup) != 1 or type(cleanup[0]) is not expected:
                raise ValueError("Custom cleanup must have the parameter's exact OSC type.")
            if type(cleanup[0]) in (int, float) and (minimum is not None and cleanup[0] < minimum
                    or maximum is not None and cleanup[0] > maximum):
                raise ValueError("Custom cleanup is outside the parameter range.")
            if read_only:
                raise ValueError("Read-only parameters cannot define writable cleanup.")
        if len(self._items) >= 2048 and address not in self._items:
            raise ValueError("Endpoint registry is full.")
        item = self._add(address, tag, "avatar.parameters", direction="read" if read_only else "both",
            minimum=minimum, maximum=maximum, evidence=str(evidence)[:200], custom=True, public=bool(public), cleanup=cleanup)
        self.revision += 1
        return item

    def clear_parameters(self):
        self._items = {key: value for key, value in self._items.items() if not value.custom}
        self._tested.clear()
        self.revision += 1

    def unregister_parameter(self, address):
        """Remove stale custom metadata without altering native contracts."""
        item = self._items.get(address)
        if item is None or not item.custom:
            return False
        del self._items[address]
        self._tested.discard(address)
        self.revision += 1
        return True

    def mark_tested(self, address, *, reviewed=False):
        if not reviewed or address not in self._items:
            raise ValueError("Record only an explicitly reviewed compatibility test.")
        self._tested.add(address)
        self.revision += 1

    def validate(self, address, args, write=True):
        args = typed_args(args)
        item = self.get(address)
        if item is None:
            raise ValueError("No compatible endpoint description has been loaded.")
        if write and item.read_only:
            raise ValueError("This endpoint is read-only telemetry.")
        if write and item.compatibility_required and address not in self._tested:
            raise ValueError("This endpoint requires a deliberate compatibility test before control.")
        tags = item.types if write or item.observation_types is None else item.observation_types
        if len(args) != len(tags):
            raise ValueError("Incorrect OSC argument count.")
        expected = {"i": int, "f": float, "b": bool, "s": str}
        for value, tag in zip(args, tags):
            if type(value) is not expected[tag]:
                raise ValueError("OSC types must match exactly; explicit conversion is required.")
            if type(value) in (int, float):
                if item.minimum is not None and value < item.minimum or item.maximum is not None and value > item.maximum:
                    raise ValueError("OSC value is outside the endpoint range.")
        if address == "/chatbox/input" and (len(args[0]) > 144 or args[0].count("\n") > 8):
            raise ValueError("Chatbox text exceeds 144 characters or 9 explicit lines.")
        if address == "/avatar/change" and not re.fullmatch(r"avtr_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", args[0]):
            raise ValueError("An exact VRChat avatar identifier is required.")
        if address == "/tracking/eye/CenterPitchYawDist" and args[2] <= 0:
            raise ValueError("Eye convergence distance must be positive.")
        if address.endswith(("/CenterVec", "/CenterVecFull")) and not any(args):
            raise ValueError("Eye gaze vectors cannot have zero length.")
        if address.endswith("/LeftRightVec") and (not any(args[:3]) or not any(args[3:])):
            raise ValueError("Each eye gaze vector must have nonzero length.")
        return item


Registry = EndpointRegistry
