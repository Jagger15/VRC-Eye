"""Accent derivation with readable text, independent of data and permissions."""
import colorsys

PALETTES = {
    'Dark': ('#111827', '#1e293b', '#f1f5f9', '#b6c5d8', '#67e8f9'),
    'Light': ('#f8fafc', '#e2e8f0', '#172033', '#475569', '#075985'),
    'Retro': ('#c0c0c0', '#dfdfdf', '#101010', '#343434', '#000080'),
    'Terminal': ('#06110a', '#102219', '#e4ffeb', '#a4ceae', '#7ff29c'),
    'Spacecraft': ('#0a1025', '#192441', '#edf3ff', '#adbfdf', '#82ccff'),
}


def rgb(color): return tuple(int(color[i:i+2], 16) / 255 for i in (1, 3, 5))
def hex_color(values): return '#' + ''.join(f'{round(max(0,min(1,x))*255):02x}' for x in values)


def luminance(color):
    values = [(x / 12.92 if x <= .04045 else ((x + .055) / 1.055) ** 2.4) for x in rgb(color)]
    return sum(x * w for x, w in zip(values, (.2126, .7152, .0722)))


def contrast(a, b):
    x, y = sorted((luminance(a), luminance(b)))
    return (y + .05) / (x + .05)


def readable_accent(color, backgrounds):
    if min(contrast(color, b) for b in backgrounds) >= 4.5: return color
    h, l, s = colorsys.rgb_to_hls(*rgb(color))
    candidates = [hex_color(colorsys.hls_to_rgb(h, n / 100, s)) for n in range(101)]
    valid = [c for c in candidates if min(contrast(c, b) for b in backgrounds) >= 4.5]
    if valid: return min(valid, key=lambda c: abs(colorsys.rgb_to_hls(*rgb(c))[1] - l))
    return max(('#000000', '#ffffff'), key=lambda c: min(contrast(c, b) for b in backgrounds))


def palette(preferences, original):
    from color_vision import neutral, PRESET_ACCENTS
    vision = preferences.color_vision
    if preferences.contrast == 'High contrast dark':
        base = ('#000000','#111111','#ffffff','#eeeeee','#ffff00')
        return tuple(neutral(c) for c in base) if vision == 'Monochrome' else base
    if preferences.contrast == 'High contrast light':
        base = ('#ffffff','#f4f4f4','#000000','#242424','#003c8f')
        return tuple(neutral(c) for c in base) if vision == 'Monochrome' else base
    base = PALETTES.get(preferences.theme, original)
    accent = PRESET_ACCENTS.get(vision, base[4])
    if preferences.accent_enabled:
        accent = hex_color(colorsys.hsv_to_rgb(preferences.accent_hue / 360,
                          preferences.accent_saturation / 100, preferences.accent_brightness / 100))
    if vision == 'Monochrome':
        base = tuple(neutral(c) for c in base)
        accent = neutral(accent)
    return (*base[:4], readable_accent(accent, base[:2]))


def blend(a, b, fraction): return hex_color(tuple(x * (1-fraction) + y * fraction for x,y in zip(rgb(a),rgb(b))))
