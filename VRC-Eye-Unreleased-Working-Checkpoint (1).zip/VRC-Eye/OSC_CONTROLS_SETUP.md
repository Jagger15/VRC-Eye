# VRC Eye 1.19.5 — OSC Controls

Open **VRC Eye → VRC Eye Primary → OSC Controls**. Addresses, ports, LAN exposure and OSCQuery advertisement belong in **VRC Eye → Networking → OSC Transport**. The camera, Avatar Link and Rangefinder integrations use the same application-owned OSC service.

## Start and observe

1. Run **Start.cmd**. It maintains the application's local Python environment and installs missing dependencies from the single `requirements.txt`. There is no separate OSC installer. Installing a package does not arm controls or connect a hardware provider.
2. Enable OSC in VRChat's Action Menu. VRC Eye initially receives observations; opening an OSC page does not test connectivity by moving the player, changing the microphone, publishing chat or taking a photo.
3. In **Overview**, use **Discover clients passively** and select the intended candidate when more than one appears. The candidate name is discovery information, not authenticated identity.
4. Open **Networking**, review the selected instance's transport, save, and **Connect observation only**. Manual configuration remains available. The defaults are local IP `127.0.0.1`, VRChat send port `9000`, and VRC Eye receive port `9001`. The receive port can be `0` to choose a free port. The optional fallback selects a free port when the requested one is busy; it does not take another application's socket.
5. Return to **Overview** and inspect the received avatar and endpoint evidence. Use the setup-step buttons to keep your place. Each output capability has its own review and session permission. Voice and chat publication have separate controls.

`zeroconf` provides optional mDNS discovery and OSCQuery advertisement. Start.cmd includes it in dependency setup. If it is unavailable, read-only OSCQuery URL inspection and explicitly configured local UDP remain available. Windows OSCQuery normally discovers clients on the same machine; approved remote platform routes need appropriate configuration. Discovery metadata never grants write authority.

A sender configured successfully is different from a healthy receiver, a discovered parameter description, or an observed current avatar. An unchanged value can remain valid while its selected service is demonstrably alive. Missing health evidence makes sensitive observations unknown.

## Views and tabs

All views use the same registry, scheduler, permissions and cleanup. **Casual** hides the four advanced tabs. **Advanced** and **Developer** expose all ten; Developer grants no additional send authority.

| Tab | Available work |
| --- | --- |
| Overview | Connection evidence, client selection, resumable setup checklist and troubleshooting. |
| Control Deck | Reviewed native inputs, short pulses, bounded holds, axes, local pins and distinct safety actions. |
| Avatar Parameters | Discovered or declared parameters, exact types, read-only telemetry, eligible avatar switching and eye-height requests. |
| Voice & Privacy | Matching microphone behavior, desired-state requests, bounded speech, privacy watchdog and safety sequence. |
| Chatbox | Composer, publication preview, immediate send/editor population, sound preference, explicit typing indicator and cancellation. |
| Camera | Typed settings, selected-settings presets, captures, local countdowns, history, Dolly and separately approved peer countdown captures. |
| Tracking | Declared eye/body routes, source permissions, activation, stopped/stale state and local timing evidence. |
| Presets & Rules | Compatibility previews, reviewed preset application/restoration and bounded rules. |
| Routes & Permissions | Per-source capability grants, inactive configuration import, route activation and transformation preview. |
| Inspector | Bounded action/policy ledger, local bookmarks, diagnostic evidence and an isolated simulator. |

## Permissions, ownership and stopping

Review the capability needed for an action, then review the action itself. The generic typed editor distinguishes an integer `[1]`, a float `[1.0]` and a Boolean `[true]`; it does not silently convert them. Built-in telemetry remains read-only. Compatibility descriptions are not evidence that a world or client will honor a command.

Source grants are exact. The desktop controls use `manual`; managed definitions use `route:<id>`, `preset:<id>` or `rule:<id>`. Granting a source does not activate its definitions. Avatar-visible output needs its own reviewed audience permission. Another application's direct OSC traffic is outside VRC Eye's managed routing policy.

**Stop Controls** cancels pending work, suspends VRC Eye producers and attempts releases for inputs it owns. Cleanup has priority over ordinary output and is never a blanket reset of every parameter. UDP cleanup is best effort: if a held input remains active, release it using VRChat's controls and check other senders. Closing a tab does not destroy the application service or strand its scheduled cleanup.

Account, session, selected client, avatar, schema and permission changes invalidate affected work. After an avatar switch, observe the transition, reload compatible metadata, and deliberately rearm the required capabilities. Restarting restores configuration and view preferences, never held inputs, active routes, pending captures, privacy sessions or old tracker samples.

## Voice and local safety

Set VRC Eye's microphone behavior to match VRChat: `toggle` or `hold` (the documented non-toggle behavior). `unknown` keeps the behavior unconfigured. **Request muted** and **Request unmuted** require a trustworthy `MuteSelf` observation and avoid an unnecessary toggle when the desired state is already observed. **Toggle microphone** is available only for configured toggle behavior. **Bounded hold to speak** requires hold behavior, releases automatically, and accepts at most 30 seconds. A non-toggle unmute request is a three-second bounded hold by default, not a persistent unmute switch.

The watchdog is off until explicitly started. Its default response is an alert. Granting an unrelated capability does not disable an active privacy session or cancel its unrelated queued work. Revoking microphone output leaves observation alerts visible while suspending corrective control; review the permission and watchdog policy again to resume correction. A separately selected corrective policy permits one mute attempt and then stops correcting; ambiguous or conflicting feedback does not start a retry loop. Loss of observation means privacy is unverified. VRChat mute state does not establish the state of the operating system, a physical headset switch, or microphones used by other applications.

**Activate VRChat Safe Mode** requests the native PanicButton action. **VRC Eye Safety Mode** is a separate local sequence: pause automation, release owned controls, cancel chat and local countdowns, pause media, apply available local privacy/reminder integrations, optionally request native Safe Mode and configured mute, record a bookmark, and suspend output permissions. Its result lists individual completed, requested or unverified steps. Leaving it does not automatically unmute, restart movement, republish messages or undo native Safe Mode.

## Chatbox publication

The composer publishes text; it does not read other players' chatboxes. Review the actual text and its audience. The controller enforces 144 characters, uses a conservative UTF-16 length check, and allows at most nine explicit lines. VRChat word wrapping can create additional displayed lines. The notification-sound option defaults off.

Human composition pauses background producers. Priority is user text, selected template, accepted local announcement, then background status. Each pending item has a source, session, expiry and replacement policy; newer text from one producer supersedes that producer's pending text. Output uses one scheduler, with a three-second publication interval. The typing indicator is explicitly applied and expires after 30 seconds unless deliberately applied again.

Cancelling pending output does not retract a message that has appeared in VRChat. The bounded template renderer permits plain `status`, `timer` and intentionally selected `media_title` fields; no file paths, local usernames or diagnostic contents are automatically collected. The current desktop tab provides the manual composer; provider/template producers can use the same reviewed controller rather than independent timers.

## Avatars and scaling

Switches are limited to account-bound favorites/recents/uploads evidence already available to VRC Eye, plus avatars observed locally. Entering an arbitrary avatar ID or selecting an eligibility label does not add it to that list. A transmitted request remains pending until the target avatar transition is observed. No destination preset is applied merely because a request was sent. A timeout remains unresolved.

Eye-height requests require an observed avatar and an observed scaling permission. Ordinary controls use VRC Eye bounds of **0.2–5 meters**. The panel separately reports user-selectable limits, technical OSC limits and VRC Eye's bounds. World logic may enforce a different height after first echoing the requested value; VRC Eye reports that effective change and does not continually resend its preference. Bounds or presets from another avatar are not automatically restored.

## Camera and Dolly

Use endpoint-specific types and ranges. Selected-settings presets do not enable streaming, publish files or change avatar parameters. `Mode` set to streaming is excluded from presets; deliberate individual mode/streaming settings remain separate actions. Pose writes and the conflicting audio-from-camera endpoint documentation are compatibility concerns, not universally supported controls. The high-level camera settings editor withholds pose and audio aliases; registry-based compatibility testing is an advanced integration concern. The published Lightness range also requires explicit client verification.

Choose either a **VRC Eye local countdown** (0–30 seconds) or **VRChat native delayed capture**. Cancelling the former stops its unsent request; cancelling local work cannot promise to undo a native capture already handed to VRChat. One controller coordinates capture requests from the desktop, Avatar Link, World camera workflow and accepted peer countdowns. Captures are not retried automatically. The history distinguishes scheduled/requested work and correlated file evidence. A nearby new photo can be evidence without proving which sender caused it.

An accepted Eye-to-Eye countdown does not authorize a photo. The Camera tab offers a separate single-use local review within its last 30 seconds. Peer/session/context/permission changes revoke pending work; no raw peer packet acquires camera or microphone authority.

Dolly is an optional native capability whose official page identifies a VRC+ requirement. Play, delayed play, stop, import and export use the shared service. Delayed-play feedback indicates that the delay was initiated, not that animation has begun. A passed delay without additional evidence stays unverified. Playback ownership is bounded; it is not an unattended recording scheduler.

Import accepts bounded JSON data, rejects unknown settings and nonfinite values, and checks nesting and point limits. The checked desktop profile is at most 32 KiB, 100 points total and 50 points per path. Because the public documentation does not provide a versioned native JSON file schema, the review also requires deliberate verification against a current-client native export. Rejected or unfamiliar exports require inspection, not an automatic conversion. Local-relative/world-specific context and notes travel with the path review. Import while playback or a delay is active is refused. Export requests do not upload files, and their observed path is not proof of verified contents.

## Managed routes, presets, rules and tracking

Use **Routes & Permissions** to load a validated declarative configuration. Import only stages inactive definitions. Review the source's exact capability/audience permissions, then separately review activation or application. Configuration cannot run scripts, grant itself permissions or choose transport destinations. A transformation preview sends nothing. The supplied battery example must be mapped to a real current-avatar parameter before it can be used.

Pipelines support explicit conversions and bounded transforms such as scaling, clamping, dead zones, smoothing and threshold hysteresis. Use only transformations appropriate to the signal; tracking is not processed as a button or ordinary cosmetic slider. Presets preview compatibility and ownership. Restoration may skip fields whose owners or values changed after the original application. Rules have explicit triggers, expiry, cooldown and duration limits; they are not arbitrary programs or unattended movement workflows.

Tracking requires a real external provider or deliberately selected existing local signal. For managed UDP ingress, declare an exact source IP, source port and incoming OSC address, then the destination address and compatible type. An endpoint tuple is a routing filter, not authenticated application identity. Direct provider-to-VRChat configurations can remain direct.

Eye routes declare their representation, and only one look representation owns the destination at a time. Body routes declare tracker identity, meters, Unity coordinates and Euler-degree rotations. The head reference is explicitly an alignment reference. Stale data stops forwarding rather than replaying old poses or inventing zero positions. Local sample age, rate and drop counts do not measure end-to-end hardware latency or server ping. Incoming head/wrist telemetry is separately advertised and permissioned from outbound tracking. This update supplies neither tracking hardware nor a new Unity SDK measurement helper.

## Diagnostics and verification scope

The Inspector distinguishes requested, scheduled, transmitted, blocked, expired, cancelled and matching-state-observed results. Matching feedback does not prove causation, lasting state or rendered completion. Pausing the Inspector display does not pause traffic; use **Stop Controls** for that.

Use **Save redacted diagnostics…** in the Inspector for a local JSON report. Default diagnostic exports contain metadata/counts and omit raw chat, tracking samples, avatar identities and sensitive values. Local bookmarks can feed Crash & Diagnostics. The isolated simulator uses a fake endpoint and separate state, with deliberate observations and faults such as packet loss, rejection, type changes, avatar changes and disconnects; it sends no live packets.

This release is checked with automated headless controller/UI tests, fake clocks/transports and local protocol fixtures. The development environment cannot verify native Windows GUI behavior, a live VRChat client's camera/microphone/Dolly behavior, SteamVR devices, or Unity execution. Test one deliberately chosen harmless control in your own client before relying on a capability, and retain the distinction between transmission and observation.

## Primary protocol references

Checked **2026-10-01**. Client behavior can vary by platform, world and version.

- [VRChat OSC overview](https://docs.vrchat.com/docs/osc-overview)
- [OSCQuery](https://docs.vrchat.com/docs/oscquery)
- [OSC input and chatbox controls](https://docs.vrchat.com/docs/osc-as-input-controller)
- [Avatar scaling](https://docs.vrchat.com/docs/osc-avatar-scaling)
- [Avatar switching release notes](https://docs.vrchat.com/docs/vrchat-202512)
- [Camera endpoint release notes](https://docs.vrchat.com/docs/vrchat-202533)
- [Official OSC wiki and endpoint tables](https://wiki.vrchat.com/wiki/OSC)
- [Official Camera Dolly documentation](https://wiki.vrchat.com/wiki/Camera_Dolly)
- [OSC eye tracking](https://docs.vrchat.com/docs/osc-eye-tracking)
- [OSC trackers](https://docs.vrchat.com/docs/osc-trackers)
