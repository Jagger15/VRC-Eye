# VRC Eye — Developer / Black Lab guide

## Version 1.19.8 addendum

The workspace now has **nine sections**. **Client Bridge Lab** adds eight scoped
provider views, seven telemetry/six action capabilities, conditional restoration,
API/runtime evidence and opt-in playtest cards. Read
[CLIENT_BRIDGE_LAB_GUIDE.md](CLIENT_BRIDGE_LAB_GUIDE.md) for current operation and
[CLIENT_BRIDGE_LAB_CAPABILITIES.md](CLIENT_BRIDGE_LAB_CAPABILITIES.md) for the exact
limits. The existing API catalog and workflow below are retained. References to
eight sections in the historical 1.19.7 guide describe that release, not the
current total. The API write switch and lab-control switch are separate.

## Version 1.19.7 foundation — what that build delivers

This is the first implemented Developer / Black Lab workspace on the existing
1.19.6.1 codebase. It is not a second application or an independent demonstration
API client. Live requests run through the original VRChatAPI transport and request
budget used by normal features. Sandbox and Replay are separate execution paths.

The workspace has 37 read adapters and 18 write adapters. All 55 executable entries
have offline fixture tests and fake-HTTP integration tests through the real shared
transport. The catalog also lists three explicitly non-executable future entries.
**No operation is marked live-verified.** A passing fixture test establishes what
VRC Eye does with controlled inputs, not what VRChat currently accepts from a
particular account. See DEVELOPER_CAPABILITIES.md for the full registry.

## Starting and opening the workspace

Close the previous running copy. Extract the complete ZIP into a new folder,
open VRC-Eye, and run Start.cmd. Do not move individual source files out of the
folder. The existing automatic dependency setup remains unchanged.

Set the top **View** selector to **Developer**, then select **Developer / Black
Lab** in the Advanced sidebar group. Alternatively, press **Ctrl+K** and search
for API Workbench, Traffic, Testing Lab, or another developer section. All eight
sections remain reachable through the workspace dropdown, including in smaller
windows. The page bodies scroll; text editors and tables have their own scrollbars.

A view selection is presentation only. It does not grant account permissions,
start networking listeners, arm OSC, authorize a bridge, or enable API writes.
There is no developer entitlement key or separate installation.

## Environment meanings

**Sandbox** is the default. Requests execute against synthetic in-memory records.
The synthetic executor has no reference to the live API client and performs no
network calls or database writes. It is suitable for practicing reads, edits,
verification and failure handling without a VRChat account. Generated sample IDs
are visibly synthetic, not suggested live resources.

**Replay** has no API executor at all. The Testing Lab feeds validated normalized
events through a separate instance of the real PlayerSessionService, with virtual
time and a history worker that rejects writes. It does not insert synthetic people
into the normal live roster or encounter history. The replay controls also remain
offline when opened from the Live workspace.

**Live** enables deliberately selected API actions through the existing connected
account, subject to Demo/Safe Mode restrictions, contact identification, local
scope checks, and the server's own authorization. Real database inspection and
initialized-provider snapshots also require selecting Live, but local database
work does not require a VRChat login.

Changing environments cancels pending developer work, revokes prepared reviews,
disarms live writes and resets offline fixtures/replay. Account changes similarly
invalidate the old context and clear account-scoped developer responses and
recordings. The application may have other normal features running: selecting
Sandbox is isolation of the developer executor, **not an application-wide offline
switch** or a rerouting of normal features into the simulator.

## API Workbench

### Selecting and composing

Filter the catalog by words or area. Each operation describes its method, route,
field definitions, resource scope, behavior, available verification and reference.
The source is a community reference, not a promise of official support.

Selecting a row does not discard an existing draft. Choose **Guided fields…** to
build a draft from typed fields, or **Load example** to replace the composer.
The `operation` value in Request JSON determines what executes. In Live, example
resource fields are blank rather than silently reusing synthetic IDs; own-account
fields can use the already selected account. Enter only IDs you are authorized
to use.

**Validate only** checks the local schema without sending anything. Extra body
fields, alternate hosts, arbitrary headers, scripts and unknown operations are
rejected. Request imports are bounded JSON data, never executable collections.
Response fields do not automatically become writable fields.

**Save request…** explicitly saves the JSON draft. Such files can contain target
IDs and text you typed. They are not automatically sanitized bug reports. The
save prompt distinguishes this from report export. Existing files are not silently
overwritten.

### Reads, freshness and pagination

Use **Read** for the selected read operation or **Fresh read** to avoid its local
cached observation. Responses include observation time, environment, cache state,
a sanitized response view, and a type-oriented schema. Unknown string fields and
private categories are conservatively omitted. This is not an unrestricted secret
viewer.

List operations inspect one page at a time. The result states item count, requested
page size, offset, duplicate IDs within that page and why it stopped. **Next page**
is bound to the exact preceding request; changing its filters or target requires
a new first read. Reaching a local inspection limit is not reported as fetching
all records. A short page is an observation, not an atomic snapshot of a changing
service dataset. The group-audit adapter handles its results/hasNext envelope.

**Pin response** keeps a sanitized comparison baseline in memory. Read another
response and choose **Compare response** for type and value changes. Omitted
private values cannot be compared. The tool does not yet trace every response
through normalization, store revision and final rendered UI field automatically.

### Live setup and action review

For personal authorized development, use the existing account connection rather
than importing credentials from another application. Under **Networking →
Developer API**, configure your real application contact email or HTTPS project
URL for request identification. This is application contact information, not an
authentication token or credential. Demo and Safe Mode keep this setting
session-only and do not permit live developer account operations.

For a write, select its operation, fill the exact target and proposed fields, and
choose **1. Prepare write**. Where the adapter supports it, preparation fetches a
fresh resource record and checks ownership. Preparation does not send the mutation.
The preview contains the account, operation, resource scope, old values that were
observed, proposed values, verification plan and local expiry.

In Live, explicitly select **Arm live writes (session only)**. Then choose
**2. Review & send…**, inspect the exact request and current values, and approve
that individual action. Declining the review sends nothing. A changed request
requires a new preview. Reviews are one-use and expire after 15 minutes. Changing
accounts, environment or application contact revokes them. Disarming also clears
them. Opening Developer itself never arms this switch.

The write path rechecks context and supported resource state before dispatch.
If a reviewed field changed, the write is not sent and a new review is required.
This is a last-moment comparison, not a server-side atomic transaction or a full
three-way merge editor. The normal queue interval can still separate the final
read from the write. Once dispatched, cancellation cannot unsend an operation.

### Timing and outcomes

The inherited **60-second metadata interval is VRC Eye's local pacing policy**,
not an advertised VRChat quota. The developer composer shares that budget and
client lock with normal features. A fresh preflight, recheck, write and verification
can therefore take several minutes. Opening several panels does not create a
second unmetered client. A 429 can extend the cooldown. The new workbench does not
add automatic read retries, bulk polling, request coalescing or a complete circuit
breaker; those scheduler enhancements remain future work.

Results distinguish **not sent**, **rejected**, **acknowledged**, **service state
verified**, **acknowledged; verification pending**, and **outcome unknown**.
The workbench never automatically retries a mutation. A timeout or lost response
can mean the server applied it even though VRC Eye did not receive confirmation.
When a verification adapter exists, use **Verify without repeating** to issue a
fresh read rather than submit a duplicate write. Not every operation has a
verification adapter; the catalog says which do.

Caches are invalidated before mutation dispatch, including attempts that later
have an unknown outcome. This prevents the old API snapshot being treated as fresh.
It does not mean every already-rendered normal page updates immediately. Existing
pages still use their own refresh and observation mechanisms.

Avatar selection acknowledgement does not prove that an avatar is loaded or ready
inside the VRChat client. Instance creation does not mean the client traveled or
arrived. Personal moderation preferences do not prove an immediate local protective
effect. Every action result keeps those client effects unconfirmed unless a separate
existing source actually provides evidence; this release does not add automatic
client-completion correlation.

## Traffic and Events & State

Traffic observes VRC Eye's own shared API requests, not another application's
network traffic. Records include method, sanitized route, status, timing, size,
response shape and available origin/correlation information. The workbench adds
queue, cache and action-lifecycle records. Normal API calls also receive transport
records, but not every old feature already has detailed origin annotations.

The existing Friend activity receive-only pipeline is observed without opening a
second connection. Lifecycle, bounded envelope decoding and parser support are
recorded. Unknown/malformed data is handled as diagnostics rather than instructions.
The observer does not send arbitrary pipeline commands or recover missed server
events. Sequence numbers are local and do not certify global ordering or completeness.

Events & State inspects the shared player model, including observed field candidates,
the selected source, freshness and confidence. It also offers session metadata,
the last workbench response, cache metadata and initialized provider snapshots.
Live roster inspection is bounded to 100 rows and labels a partial result. It does
not invent a server roster from a profile request. Synthetic environments show only
their isolated state. Cache invalidation clears local API observations, not notes
or encounter history, and does not automatically fetch replacements.

## Testing Lab

Sandbox failure injection includes authorization rejection, rate limiting, server
failure, timeout, malformed response, schema drift and a lost write response. The
last case waits through read-only preflights, changes the synthetic record and then
loses the mutation response. A subsequent verification read demonstrates how an
unknown outcome can be investigated without repeating the action.

The built-in deterministic player scenario includes duplicate joins, avatar changes
and one departure; it ends with 12 retained synthetic records and 11 active players.
Use Reset, Step or Run remaining events. Imported scenarios are bounded normalized
JSON events; scripts and arbitrary live action commands are not accepted.

The log-parser tool uses VRC Eye's existing parser on pasted bounded text. It shows
normalized events and counts lines with no relevant player event. Raw input is not
added to diagnostics or reports. Local fuzzing runs bounded deterministic generated
cases against VRC Eye's own parsers/redaction/decoders. It never fuzzes VRChat's
production endpoints. Replay speed controls, checkpoints, automatic scenario
reduction and cross-build first-divergence analysis remain roadmap items.

## Data & Recovery

The database picker includes initialized stores belonging to VRC Eye, not arbitrary
files or another companion's databases. Fixed read-only SQLite queries inspect
schema version, table/column names, counts and quick integrity checks. They do not
dump notes, social history rows, credentials or arbitrary query results. Interactive
inspection is limited to 512 MiB with a local time/cancellation budget.

**Create consistent backup…** uses SQLite's backup mechanism and validates the new
copy. It creates a new .sqlite3/.sqlite/.db file and does not overwrite the source
or an existing destination. Connections close explicitly to avoid Windows file
locks. A backup includes original private data: **do not treat it as a sanitized
report**. This release does not repair, replace or migrate active databases from
the Developer workspace. Staged repair/rollback is future work.

## Integrations and ownership

The Integrations section reads snapshots from already initialized OSC, Eye-to-Eye,
Companion ownership, optional bridge, Runtime Companion and resource providers.
Unavailable or uninitialized providers stay labeled as such; opening this page does
not start listeners or grant controls. Existing dedicated workspaces remain the
places for their deeper controls. OSC/peer/runtime links reuse the same controllers.

This build does not add a new Unity SDK agent, generic live Udon-variable access,
arbitrary Unity commands, a remote VRChat API relay, content uploads or model-asset
extraction. The optional bridge remains an optional provider, not a requirement
for direct web-API development.

## Diagnostic privacy, retention and export

The new recorder is memory-only by default: up to 1,000 records, approximately
2 MiB, with a 15-minute retention window. Explicit pins (up to 20) are retained in
memory until cleared; dropped/expired record counts are visible. A complete event
history is not promised. These bounds apply to the new recorder, not unrelated
existing user-managed history or diagnostics features elsewhere in VRC Eye.

Credentials, cookies, authorization values, private location/instance details,
message bodies, wellness fields and sensitive local paths are excluded or redacted
before diagnostic retention. Unknown string fields are conservatively masked.
The explicit on-device response view can show selected reviewed metadata fields,
but strict persistent exports do not preserve arbitrary raw API responses.

Reports require **Generate report preview** before **Export reviewed report…**.
Preview is in memory; export creates a new ZIP with report.json and README.txt.
Known resource IDs use fresh per-bundle pseudonyms, stable inside that bundle but
not a permanent cross-bundle identity. No raw databases, log files, copied API
response files or manually attached files are added. Review the preview and the
export before sharing. Clearing recordings or closing the app does not delete
files that you explicitly exported earlier.

## Compatibility and distribution status

The public web-API reference is community-maintained. VRChat's official Creator
Guidelines explain that these endpoints are unsupported for public use and can
change without notice, and set conditions for application identification, traffic
handling and account access. The project uses those as constraints, not an
endorsement or a guarantee that every endpoint is stable.

The inherited account connection has **not** been redesigned into a reviewed
public-distribution authentication solution. The official guidance against asking
for other users' credentials/session information remains a separate release issue.
A local contact setting, encrypted storage or successful test request does not
resolve that question. This build is an engineering/development update, not a
claim of platform approval or readiness to distribute an account-login service.

Primary policy reference, reviewed 2026-10-02:
https://hello.vrchat.com/creator-guidelines

Operation-level community references are linked in the catalog and
DEVELOPER_CAPABILITIES.md. Implementation tests, runtime limitations and exact
validation results are in VALIDATION.md.
