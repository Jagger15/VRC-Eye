"""Streaming whole-native-library restore, with one transaction and review."""
from dataclasses import dataclass
from hashlib import sha256
import json
import time
import uuid
from avatar_library_files import checked_stream,fingerprint
from native_library import canonical,validate_record,scope,identifier,TYPES,digest,fill_missing
from native_migration import strict_json
from companion_data import stamp
from vrcx_sources import stopped

LIMIT=256*1024*1024
LINE=132*1024


def stream_records(path,stop=None):
    with checked_stream(path,limit=LIMIT) as (_,stream,_):
        header=strict_json(stream.readline(LINE+1))
        if not isinstance(header,dict) or header.get('format')!='vrc-eye-native-backup' or header.get('schema')!=1:
            raise ValueError('Unsupported native backup.')
        scopes={scope(s) for s in header.get('scopes',[])}
        if not scopes or len(scopes)>1000:raise ValueError('Invalid backup workspaces.')
        checksum=sha256();count=0;seen=set()
        while True:
            stopped(stop);line=stream.readline(LINE+1)
            if not line or len(line)>LINE:raise ValueError('Truncated or oversized backup record.')
            obj=strict_json(line)
            if not isinstance(obj,dict):raise ValueError('Invalid backup row.')
            if set(obj)=={'count','sha256'}:
                if obj['count']!=count or obj['sha256']!=checksum.hexdigest() or stream.read(1):raise ValueError('Backup checksum/count mismatch.')
                return
            count+=1
            if count>500000:raise ValueError('Backup exceeds 500,000 rows.')
            checksum.update(line)
            if set(obj)=={'record'}:row=validate_record(obj['record']);deleted=False
            elif set(obj)=={'suppression'}:
                row=obj['suppression'];deleted=True
                if not isinstance(row,dict) or set(row)!={'scope','kind','id','created'} or row['kind'] not in TYPES:raise ValueError('Invalid deletion marker.')
                scope(row['scope']);identifier(row['id'])
            else:raise ValueError('Unknown backup row.')
            key=(row['scope'],row['kind'],row['id'])
            if key[0] not in scopes or key in seen:raise ValueError('Backup contains a duplicate identity or an undeclared workspace.')
            seen.add(key);yield deleted,row


def file_digest(path):
    h=sha256()
    with checked_stream(path,limit=LIMIT) as (_,stream,info):
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest(),fingerprint(info)


@dataclass(frozen=True)
class Review:
    id:str
    path:str
    digest:str
    fingerprint:dict
    revision:int
    policy:str
    counts:dict
    scopes:tuple
    expires:float


class BackupRestore:
    def __init__(self,library):self.library=library;self.review=None
    def prepare(self,path,policy='keep',stop=None):
        if policy not in ('keep','fill','replace'):raise ValueError('Choose a conflict policy.')
        checksum,fp=file_digest(path);counts=dict(records=0,conflicts=0,deletions=0,forgotten=0);scopes=set()
        with self.library.connect() as db:
            db.execute('BEGIN');revision=db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]
            for deleted,row in stream_records(path,stop):
                key=(row['scope'],row['kind'],row['id']);scopes.add(row['scope'])
                counts['deletions' if deleted else 'records']+=1
                old=self.library._row(self.library._find(db,*key))
                if not deleted and old and digest(old)!=digest(row):counts['conflicts']+=1
                if not deleted and db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():counts['forgotten']+=1
        if file_digest(path)!=(checksum,fp):raise ValueError('Backup changed during review.')
        self.review=Review(uuid.uuid4().hex,str(path),checksum,fp,revision,policy,counts,tuple(sorted(scopes)),time.monotonic()+900)
        return self.review
    def commit(self,review,stop=None,check=lambda:None):
        if review is not self.review or time.monotonic()>review.expires:raise ValueError('Backup restore review expired or was used.')
        self.review=None;check()
        if file_digest(review.path)!=(review.digest,review.fingerprint):raise ValueError('Backup changed after review.')
        changed=0;skipped=0;now=stamp()
        with self.library.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute("SELECT value FROM eye_native_meta WHERE key='revision'").fetchone()[0]!=review.revision:raise ValueError('Native data changed after review. Review restore again.')
            db.execute('INSERT INTO eye_native_batches VALUES(?,?,?,?,?)',(review.id,'Native backup restore',now,'Committed',canonical(review.counts)))
            for deleted,row in stream_records(review.path,stop):
                check();key=(row['scope'],row['kind'],row['id'])
                old=self.library._row(self.library._find(db,*key))
                if deleted:
                    # Forget choices erase before-images as well as live values.
                    db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',key)
                    db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*key,now));continue
                if db.execute('SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind=? AND id=?',key).fetchone():skipped+=1;continue
                if old:
                    if review.policy=='keep':skipped+=1;continue
                    if review.policy=='fill':row=dict(row,data=fill_missing(old['data'],row['data']),provenance=old['provenance'])
                    if digest(row)==digest(old):skipped+=1;continue
                db.execute('INSERT INTO eye_native_changes VALUES(?,?,?,?,?,?,0)',(review.id,*key,canonical(old) if old else None,digest(row)))
                # This format has no ancestral source snapshot. A restored
                # value must not inherit an unrelated pre-restore merge base.
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                db.execute('INSERT INTO eye_native_records VALUES(?,?,?,?,?,?,?) ON CONFLICT(scope,kind,id) DO UPDATE SET data=excluded.data,provenance=excluded.provenance,fingerprint=excluded.fingerprint,updated=excluded.updated',
                           (*key,canonical(row['data']),canonical(row['provenance']),digest(row),now));changed+=1
            check();self.library._validate_links(db,review.scopes)
            if file_digest(review.path)!=(review.digest,review.fingerprint):raise ValueError('Backup changed before restore completion.')
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
        return dict(id=review.id,changed=changed,preserved=skipped,deletions=review.counts['deletions'])
