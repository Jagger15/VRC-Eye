"""VRC Eye Bridge protocol 1.0: bounded JSON, typed capabilities, no remote evaluation."""
from dataclasses import dataclass
import hashlib
import hmac
import json
import math
import re
import secrets
import struct
import uuid

PROTOCOL = {"major": 1, "minor": 0}
APP_VERSION = "1.21.0"
MAX_MESSAGE = 65536
HEARTBEAT_SECONDS = 1.
LEASE_SECONDS = 5.
HANDSHAKE_SECONDS = 5.
TELEMETRY_SECONDS = 3.
MAX_CAPABILITIES = 48
MAX_PLAYERS = 128
ID = r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}"


class BridgeError(ValueError):
    pass


def exact(value, required, optional=()):
    if not isinstance(value, dict) or set(value)-set(required)-set(optional) or not set(required)<=set(value):
        raise BridgeError("Unsupported bridge record fields.")
    return value


def text(value, maximum=128):
    if not isinstance(value,str) or not 1<=len(value)<=maximum or any(ord(c)<32 or ord(c)==127 for c in value):
        raise BridgeError("Invalid bridge text.")
    return value


def ref(value, prefix=""):
    if not isinstance(value,str) or not re.fullmatch((prefix+"_" if prefix else "")+ID,value):
        raise BridgeError("An exact lowercase bridge/session/VRChat ID is required.")
    return value


def integer(value, low=0, high=2**31-1):
    if type(value) is not int or not low<=value<=high: raise BridgeError("Invalid bridge integer.")
    return value


def number(value, maximum=1e9):
    if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=maximum:
        raise BridgeError("Invalid bridge measurement.")
    return value


def boolean(value):
    if type(value) is not bool: raise BridgeError("Invalid bridge boolean.")
    return value


def choice(value, options):
    if not isinstance(value,str) or value not in options: raise BridgeError("Unsupported bridge choice.")
    return value


def canonical(value):
    try: return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode("ascii")
    except (TypeError,ValueError,RecursionError): raise BridgeError("Unsupported bridge JSON.") from None


def encode(value):
    raw=canonical(value)
    if not 1<=len(raw)<=MAX_MESSAGE: raise BridgeError("Bridge message exceeds 64 KiB.")
    return struct.pack("!I",len(raw))+raw


def decode(raw):
    if not isinstance(raw,bytes) or not 1<=len(raw)<=MAX_MESSAGE: raise BridgeError("Bridge message exceeds 64 KiB.")
    def pairs(items):
        result={}
        for k,v in items:
            if k in result: raise BridgeError("Duplicate bridge fields.")
            result[k]=v
        return result
    try:
        value=json.loads(raw.decode("utf-8"),object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(BridgeError("Nonfinite bridge JSON.")))
        def bound(item,depth=0):
            if depth>8:raise BridgeError("Bridge JSON is too deeply nested.")
            if isinstance(item,dict):
                if len(item)>256:raise BridgeError("Too many bridge fields.")
                for k,v in item.items():text(k,100);bound(v,depth+1)
            elif isinstance(item,list):
                if len(item)>MAX_PLAYERS:raise BridgeError("Too many bridge records.")
                for v in item:bound(v,depth+1)
            elif isinstance(item,str) and len(item)>2048:raise BridgeError("Bridge string is too large.")
            elif type(item) is float and not math.isfinite(item):raise BridgeError("Invalid bridge number.")
        bound(value)
        if not isinstance(value,dict):raise BridgeError("Bridge messages must be objects.")
        return value
    except (UnicodeError,ValueError,TypeError,RecursionError):
        raise BridgeError("Malformed or unsupported bridge JSON.") from None


def proof(secret, role, nonce, value):
    if not isinstance(secret,str) or not re.fullmatch(r"[0-9a-f]{64}",secret):raise BridgeError("Invalid pairing secret.")
    if role not in ("hello","welcome"):raise BridgeError("Invalid authentication role.")
    text(nonce,64)
    body=b"VRC-Eye-Bridge/1 "+role.encode()+b"\n"+nonce.encode()+b"\n"+canonical(value)
    return hmac.new(bytes.fromhex(secret),body,hashlib.sha256).hexdigest()


def verify(secret,role,nonce,value,supplied):
    if not isinstance(supplied,str) or not hmac.compare_digest(proof(secret,role,nonce,value),supplied):
        raise BridgeError("Bridge authentication failed.")


def context(value):
    exact(value,("attached","runtime_session","local_user_id"));boolean(value["attached"])
    if value["attached"]:
        ref(value["runtime_session"]);ref(value["local_user_id"],"usr")
    elif value["runtime_session"] is not None or value["local_user_id"] is not None:
        raise BridgeError("Detached clients must clear runtime identity.")
    return dict(value)


def hello(value):
    exact(value,("protocol","client","context","capabilities"))
    protocol=exact(value["protocol"],("major","minor"));integer(protocol["minor"],0,1000)
    if type(protocol["major"]) is not int or protocol["major"]!=PROTOCOL["major"]:raise BridgeError("Incompatible bridge protocol major version.")
    client=exact(value["client"],("id","name","version","kind"))
    ref(client["id"]);text(client["name"],80);text(client["version"],40);choice(client["kind"],("vrchat","diagnostic"))
    runtime=context(value["context"])
    if client["kind"]=="diagnostic" and runtime["attached"]:raise BridgeError("Diagnostic clients cannot claim VRChat attachment.")
    caps=value["capabilities"]
    if not isinstance(caps,dict) or len(caps)>MAX_CAPABILITIES:raise BridgeError("Too many bridge capabilities.")
    accepted={}
    for name,definition in caps.items():
        if not isinstance(name,str) or not re.fullmatch(r"[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){1,3}",name):raise BridgeError("Invalid capability ID.")
        exact(definition,("version",),("presets",));integer(definition["version"],1,1000)
        if "presets" in definition:
            presets=definition["presets"]
            if not isinstance(presets,dict) or not presets or set(presets)-{"normal","reduced","minimal","hidden"}:raise BridgeError("Invalid client preset definitions.")
            for description in presets.values():text(description,300)
        if name in CAPABILITIES and definition["version"]==1:
            if name in ("safety.player_preset","safety.focus_group") and not definition.get("presets"):raise BridgeError("Preset capabilities must explain their local effects.")
            accepted[name]=dict(definition)
    return accepted


def players(value,required,optional=()):
    exact(value,("players",))
    rows=value["players"]
    if not isinstance(rows,list) or len(rows)>MAX_PLAYERS:raise BridgeError("Invalid player telemetry batch.")
    seen=set()
    for row in rows:
        exact(row,("user_id",)+tuple(required),optional);ref(row["user_id"],"usr")
        if row["user_id"] in seen:raise BridgeError("Duplicate player telemetry ID.")
        seen.add(row["user_id"])
    return rows


def telemetry(name,value):
    if name.startswith("lab."):
        from bridge_lab_contract import validate_telemetry
        return validate_telemetry(name,value)
    if name=="bridge.diagnostics":
        exact(value,("uptime_seconds",));number(value["uptime_seconds"])
    elif name=="local.microphone_state":
        exact(value,("muted",));boolean(value["muted"])
    elif name=="instance.context":
        exact(value,("world_id","instance_id"),("network_master",))
        ref(value["world_id"],"wrld");text(value["instance_id"],1024)
        if "network_master" in value and value["network_master"] is not None:ref(value["network_master"],"usr")
    elif name=="player.selection":
        exact(value,("user_id",),("display_name",))
        if value["user_id"] is not None:ref(value["user_id"],"usr")
        if "display_name" in value:text(value["display_name"],128)
    elif name=="player.voice_activity":
        for row in players(value,("voice_active",),("avatar_audio_active",)):
            boolean(row["voice_active"])
            if "avatar_audio_active" in row:boolean(row["avatar_audio_active"])
    elif name=="player.distance":
        for row in players(value,("distance_m",)):number(row["distance_m"],100000)
    elif name=="avatar.load_state":
        for row in players(value,("state",),("avatar_id",)):
            choice(row["state"],("loading","ready","failed","security_failure","bundle_failure","unknown"))
            if "avatar_id" in row and row["avatar_id"] is not None:ref(row["avatar_id"],"avtr")
    elif name=="avatar.performance":
        for row in players(value,(),("avatar_id","rank","texture_memory_bytes","renderer_count","physbone_count","contact_count")):
            if "avatar_id" in row and row["avatar_id"] is not None:ref(row["avatar_id"],"avtr")
            if "rank" in row:choice(row["rank"],("Excellent","Good","Medium","Poor","Very Poor","Unknown"))
            for key in ("texture_memory_bytes","renderer_count","physbone_count","contact_count"):
                if key in row:integer(row[key],0,2**40 if key.endswith("bytes") else 10000000)
    elif name=="local.moderation_state":
        for row in players(value,(),("voice_muted","avatar_hidden","interactions_disabled","avatar_audio_enabled")):
            for key,val in row.items():
                if key!="user_id":boolean(val)
    elif name=="runtime.summary":
        exact(value,("process_id","process_started_at"),("scene","avatars","render","local_player","vr_mode","frame_ms","fps"))
        integer(value["process_id"],1);number(value["process_started_at"],2**53)
        if len(value)==2:raise BridgeError("Runtime summary requires at least one state or measurement.")
        for key in ("scene","avatars","render","local_player"):
            if key in value:choice(value[key],("unknown","initializing","ready","degraded","failed"))
        if "vr_mode" in value:choice(value["vr_mode"],("unknown","desktop","vr"))
        for key in ("frame_ms","fps"):
            if key in value:number(value[key],100000)
    elif name=="runtime.errors":
        exact(value,("process_id","process_started_at","events"));integer(value["process_id"],1);number(value["process_started_at"],2**53)
        if not isinstance(value["events"],list) or len(value["events"])>64:raise BridgeError("Runtime error batch exceeds 64 records.")
        for event in value["events"]:
            exact(event,("category","severity","code","count"))
            choice(event["category"],("runtime","graphics","assets","avatar","network","media","steamvr","osc","authentication","unknown"))
            choice(event["severity"],("warning","error","fatal"));choice(event["code"],("unknown","device_reset","shader_compile","asset_load","network"));integer(event["count"],1,10000)
    elif name=="unity.runtime_health":
        exact(value,(),("frame_ms","fps","working_set_bytes","tracking","foreground"))
        if not value:raise BridgeError("Empty runtime telemetry.")
        for key in ("frame_ms","fps"):
            if key in value:number(value[key],100000)
        if "working_set_bytes" in value:integer(value["working_set_bytes"],0,2**44)
        if "tracking" in value:choice(value["tracking"],("normal","lost","unknown"))
        if "foreground" in value:boolean(value["foreground"])
    else:raise BridgeError("Unsupported telemetry capability.")
    encode(value)
    return value


def parameters(name,value,definition=None):
    if name.startswith("lab."):
        from bridge_lab_contract import validate_action
        return validate_action(name,value)
    if name=="bridge.ping":exact(value,("nonce",));ref(value["nonce"])
    elif name=="safety.microphone_mute":exact(value,("muted",));boolean(value["muted"])
    elif name=="safety.avatar_effects":
        exact(value,("user_id","mode"));ref(value["user_id"],"usr");choice(value["mode"],("normal","reduced","minimal"))
    elif name=="safety.focus_group":
        exact(value,("user_ids","outside_preset"));ids=value["user_ids"]
        if not isinstance(ids,list) or not 1<=len(ids)<=MAX_PLAYERS:raise BridgeError("Select 1–128 distinct exact user IDs for focus safety.")
        for user in ids:ref(user,"usr")
        if len(set(ids))!=len(ids):raise BridgeError("Select distinct exact user IDs for focus safety.")
        choice(value["outside_preset"],("reduced","minimal","hidden"))
        if definition is not None and value["outside_preset"] not in definition.get("presets",{}):raise BridgeError("This client did not provide the selected preset.")
    else:
        field={"safety.voice_mute":"muted","safety.avatar_visibility":"visible","safety.avatar_audio":"enabled","safety.avatar_particles":"enabled","safety.avatar_lights":"enabled","safety.interactions":"enabled","safety.player_preset":"preset"}.get(name)
        if not field:raise BridgeError("Unsupported bridge action.")
        exact(value,("user_id",field));ref(value["user_id"],"usr")
        if field=="preset":
            choice(value[field],("normal","reduced","minimal","hidden"))
            if definition is not None and value[field] not in definition.get("presets",{}):raise BridgeError("This client did not provide the selected preset.")
        else:boolean(value[field])
    return value


def result(name,value,params):
    if name.startswith("lab."):
        from bridge_lab_contract import validate_result
        return validate_result(name,value,params)
    if name=="bridge.ping":
        exact(value,("pong",))
        if value["pong"]!=params["nonce"]:raise BridgeError("Mismatched bridge ping response.")
    else:
        exact(value,("applied",))
        if value["applied"] is not True:raise BridgeError("The client did not confirm the local action.")
    return value


@dataclass(frozen=True)
class Capability:
    title:str
    kind:str
    game:bool=True


CAPABILITIES={
    "bridge.ping":Capability("Connection round trip","action",False),
    "bridge.diagnostics":Capability("Adapter diagnostics","telemetry",False),
    "instance.context":Capability("Current instance and network master","telemetry"),
    "player.selection":Capability("Selected player","telemetry"),
    "player.voice_activity":Capability("Voice and avatar audio activity","telemetry"),
    "player.distance":Capability("Client-reported distance","telemetry"),
    "avatar.load_state":Capability("Avatar load state","telemetry"),
    "avatar.performance":Capability("Avatar performance and texture memory","telemetry"),
    "runtime.summary":Capability("Process-bound runtime summary","telemetry"),
    "runtime.errors":Capability("Process-bound normalized runtime errors","telemetry"),
    "unity.runtime_health":Capability("Runtime health","telemetry"),
    "local.microphone_state":Capability("Local microphone state","telemetry"),
    "safety.microphone_mute":Capability("Local microphone mute","action"),
    "safety.voice_mute":Capability("Local per-player voice mute","action"),
    "safety.avatar_effects":Capability("Local visual effects","action"),
    "local.moderation_state":Capability("Your local moderation state","telemetry"),
    "safety.avatar_visibility":Capability("Local avatar visibility","action"),
    "safety.avatar_audio":Capability("Local avatar audio","action"),
    "safety.avatar_particles":Capability("Local avatar particles","action"),
    "safety.avatar_lights":Capability("Local avatar lights","action"),
    "safety.interactions":Capability("Local interaction control","action"),
    "safety.player_preset":Capability("Client-defined local safety preset","action"),
    "safety.focus_group":Capability("Local focus-group safety","action")}


def fresh_id():return str(uuid.uuid4())
def fresh_secret():return secrets.token_hex(32)

# Additive v1 capability contracts; the wire envelope and legacy clients remain compatible.
from bridge_lab_contract import CONTRACTS as _LAB_CONTRACTS
CAPABILITIES.update({key: Capability(title, kind) for key, (title, kind, _) in _LAB_CONTRACTS.items()})
