"""Shared, credential-free records and persistent local companion data."""
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import csv
import json
from pathlib import Path
import re
import sqlite3
from urllib.parse import urlsplit

from player_profile import FIELDS, safe_link
from vrcx_integration import settings_path

PREFIXES = {"user":"usr", "friend":"usr", "avatar":"avtr", "world":"wrld", "group":"grp"}
_OPTION_UNSET = object()
UUID = r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"
EXTRA = set("""capacity recommendedCapacity occupants memberCount joinState membershipStatus userId
senderUserId senderUsername receiverUserId targetUserId sourceUserId targetDisplayName sourceDisplayName
created seen message details groupName inviteId invitedAt user favoriteGroup maxFavoriteGroups
maxFavoritesPerGroup defaultMaxFavoriteGroups defaultMaxFavoritesPerGroup friend vrcPlusWorld
avatar world worldName count currentAvatarThumbnailImageUrl shortCode isFriend requested received""".split())
EXTRA.update(('inviteMessage', 'requestMessage', 'responseMessage'))


def stamp(): return datetime.now(timezone.utc).isoformat(timespec="seconds")


def reference(value, prefixes):
    if not isinstance(value, str) or not re.fullmatch("(?:"+"|".join(prefixes)+")_"+UUID, value.strip()):
        raise ValueError("Enter a complete, matching VRChat ID.")
    return value.strip().lower()


def entity_id(kind, value):
    if kind not in PREFIXES: raise ValueError("Unsupported item type.")
    if isinstance(value,str) and value.startswith("https://"):
        parts = urlsplit(value)
        expected = "user" if kind == "friend" else kind
        if (parts.hostname != "vrchat.com" or parts.port not in (None,443) or parts.username or parts.password
                or parts.query or parts.fragment or not parts.path.startswith("/home/"+expected+"/")):
            raise ValueError("Use an exact official VRChat page or ID for this type.")
        value = parts.path[len("/home/"+expected+"/"):].rstrip("/")
    return reference(value,(PREFIXES[kind],))


def page_url(kind, value):
    return "https://vrchat.com/home/"+("user" if kind == "friend" else kind)+"/"+entity_id(kind,value)


def sanitize(value, depth=0):
    if depth > 9: raise ValueError("Record nesting exceeds the supported limit.")
    if isinstance(value,dict):
        if len(value)>500: raise ValueError("Too many record fields.")
        return {k:sanitize(v,depth+1) for k,v in value.items() if k in FIELDS or k in EXTRA}
    if isinstance(value,list):
        if len(value)>5000: raise ValueError("Too many records in a response.")
        return [sanitize(v,depth+1) for v in value]
    if isinstance(value,str):
        if len(value)>20000: raise ValueError("Record field exceeds the supported size.")
        return re.sub(r"~nonce\([^)]*\)","~nonce(REDACTED)",value)
    return value if value is None or type(value) in (int,bool) else None


@dataclass(frozen=True)
class Entity:
    kind: str
    id: str
    name: str
    detail: str = ""
    image: str = ""
    data: dict | None = None


def entity(kind, record):
    if not isinstance(record,dict): raise ValueError("Unsupported record.")
    data=sanitize(record)
    ref=entity_id(kind,data.get("id") or data.get("groupId"))
    name=data.get("displayName") if kind in ("user","friend") else data.get("name")
    if not isinstance(name,str) or not name: name=ref
    detail = data.get("statusDescription") if kind in ("user","friend") else data.get("authorName") or data.get("description")
    image=next((data[k] for k in ("iconUrl","userIcon","thumbnailImageUrl","imageUrl","currentAvatarThumbnailImageUrl","currentAvatarImageUrl") if safe_link(data.get(k))),"")
    return Entity(kind,ref,name,detail if isinstance(detail,str) else "",image,data)


class CompanionStore:
    """No count limit on local favorites. Paging limits memory, not stored items."""
    def __init__(self,path=None):
        self.path=Path(path) if path is not None else settings_path().with_name("companion.sqlite3")
        self._native = None
        self._native_lock = __import__('threading').RLock()

    @property
    def native(self):
        with self._native_lock:
            if self._native is None:
                from native_library import NativeLibrary
                native=NativeLibrary(self)
                if not self.option('native.legacy-favorites.v1',False):
                    native.migrate_legacy()
                    self.set_option('native.legacy-favorites.v1',True)
                self._native=native
            return self._native

    @contextmanager
    def connect(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        db=sqlite3.connect(self.path,timeout=3)
        try:
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS favorites(kind TEXT NOT NULL,id TEXT NOT NULL,name TEXT NOT NULL,collection TEXT NOT NULL,data TEXT NOT NULL,updated TEXT NOT NULL,PRIMARY KEY(kind,id))")
                db.execute("CREATE TABLE IF NOT EXISTS options(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
                db.execute("CREATE TABLE IF NOT EXISTS feed_profiles(account TEXT NOT NULL,id TEXT NOT NULL,data TEXT NOT NULL,checked TEXT NOT NULL,PRIMARY KEY(account,id))")
                db.execute("CREATE TABLE IF NOT EXISTS feed_events(serial INTEGER PRIMARY KEY AUTOINCREMENT,account TEXT NOT NULL,user_id TEXT NOT NULL,name TEXT NOT NULL,kind TEXT NOT NULL,detail TEXT NOT NULL,checked TEXT NOT NULL,source TEXT NOT NULL)")
                db.execute("CREATE INDEX IF NOT EXISTS feed_account ON feed_events(account,serial)")
                db.execute("CREATE TABLE IF NOT EXISTS wellness_sessions(id TEXT PRIMARY KEY,summary TEXT NOT NULL)")
                yield db
        finally: db.close()

    def save_favorite(self,kind,ref,name,collection="General",data=None,*,scope='shared'):
        kind="friend" if kind=="user" else kind
        if kind not in ("friend","avatar","world"): raise ValueError("Local favorites support friends, avatars and worlds.")
        ref=entity_id(kind,ref)
        if not isinstance(name,str) or len(name)>512 or not isinstance(collection,str) or not 1<=len(collection.strip())<=100:
            raise ValueError("Use a name up to 512 characters and a collection name of 1–100 characters.")
        payload=sanitize(data or {})
        payload["id"]=ref
        raw=json.dumps(payload,ensure_ascii=False)
        if len(raw.encode())>65536: raise ValueError("Favorite metadata exceeds 64 KiB; save its ID and name instead.")
        return self.native.favorite(scope,kind,ref,name or ref,collection.strip(),payload)

    def favorites(self,kind,query="",collection="",offset=0,*,scope='shared'):
        if kind not in ("friend","avatar","world") or type(offset) is not int or offset<0: raise ValueError("Invalid favorite view.")
        return self.native.collection_items(scope,kind,query,collection,offset=offset)

    def remove_favorite(self,kind,ref,*,scope='shared',membership=None):
        if membership:return self.native.forget(scope,'membership',membership)
        return self.native.forget(scope,'entity',kind+':'+entity_id(kind,ref))

    def export_favorites(self,path,*,scope='shared'):
        # Streaming backup has no per-library row limit and preserves exact Unicode text.
        with Path(path).open("x",encoding="utf-8",newline="") as stream:
            writer=csv.writer(stream); writer.writerow(("kind","id","name_json","collection_json"))
            count=0
            for kind in ('friend','avatar','world'):
                offset=0
                while True:
                    rows,total=self.favorites(kind,offset=offset,scope=scope)
                    for row in rows:
                        writer.writerow((kind,row['id'],json.dumps(row['name'],ensure_ascii=False),json.dumps(row['collection'],ensure_ascii=False)));count+=1
                    offset+=len(rows)
                    if not rows or offset>=total:break
        return count

    def import_favorites(self,path,stop=None,*,scope='shared'):
        from native_library import identity
        if Path(path).stat().st_size>128*1024*1024: raise ValueError("Import file exceeds 128 MiB. Split the backup into smaller files.")
        records={}
        with Path(path).open(encoding="utf-8-sig",newline="") as stream:
            reader=csv.DictReader(stream)
            if reader.fieldnames != ["kind","id","name_json","collection_json"]: raise ValueError("Use a VRC Eye favorites CSV backup.")
            count=0
            for row in reader:
                if stop is not None and stop.is_set(): raise ValueError("Favorites import canceled; changes rolled back.")
                if None in row or any(value is None for value in row.values()): raise ValueError("Malformed favorites CSV row.")
                kind=row["kind"]; ref=entity_id(kind,row["id"])
                if kind not in ("friend","avatar","world"): raise ValueError("Unsupported favorite type.")
                name,group=json.loads(row["name_json"]),json.loads(row["collection_json"])
                if not isinstance(name,str) or len(name)>512 or not isinstance(group,str) or not 1<=len(group.strip())<=100: raise ValueError("Invalid favorite name/collection.")
                entity=kind+':'+ref;collection=identity('collection',kind,group.strip())
                for record_kind,key,data in (('entity',entity,dict(entity_kind=kind,entity_id=ref,name=name,fields={})),('collection',collection,dict(entity_kind=kind,name=group.strip())),('membership',identity(collection,entity),dict(entity=entity,collection=collection,added=stamp(),rank=None))):
                    records[(record_kind,key)]=dict(scope=scope,kind=record_kind,id=key,data=data,provenance={'source':'VRC Eye favorites CSV'})
                count+=1
            if stop is not None and stop.is_set(): raise ValueError("Favorites import canceled; changes rolled back.")
        self.native.commit(self.native.prepare(records.values(),source='Favorites CSV',policy='fill',stop=stop),stop=stop)
        return count

    def option(self,key,default=None):
        with self.connect() as db: row=db.execute("SELECT value FROM options WHERE key=?",(key,)).fetchone()
        return json.loads(row[0]) if row else default

    def set_option(self,key,value,*,expected=_OPTION_UNSET):
        raw=json.dumps(value,ensure_ascii=False,allow_nan=False)
        if len(raw)>262144: raise ValueError("Setting is too large.")
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            from settings_history import record
            old=db.execute('SELECT value FROM options WHERE key=?',(key,)).fetchone()
            try:before=json.loads(old[0]) if old else None
            except (json.JSONDecodeError,TypeError):before=_OPTION_UNSET
            if expected is not _OPTION_UNSET and before!=expected:
                raise ValueError('Settings changed in another editor. Reload before saving.')
            # A corrupt previous document remains explicitly repairable, but its
            # unvalidated bytes must not be captured in the preference ledger.
            if before is not _OPTION_UNSET:record(db,key,before,value)
            db.execute("INSERT INTO options VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,raw))

    def compare_option(self,key,value,expected):
        return self.set_option(key,value,expected=expected)

    def profile(self,account,ref):
        with self.connect() as db: row=db.execute("SELECT data,checked FROM feed_profiles WHERE account=? AND id=?",(entity_id("user",account),entity_id("user",ref))).fetchone()
        return (sanitize(json.loads(row[0])),row[1]) if row else ({},"")

    def save_profile(self,account,ref,data,checked):
        raw=json.dumps(sanitize(data),ensure_ascii=False)
        if len(raw)>131072: raise ValueError("Feed profile exceeds 128 KiB.")
        with self.connect() as db:
            db.execute("INSERT INTO feed_profiles VALUES(?,?,?,?) ON CONFLICT(account,id) DO UPDATE SET data=excluded.data,checked=excluded.checked",(entity_id("user",account),entity_id("user",ref),raw,checked))

    def feed_event(self,account,ref,name,kind,detail,source,checked=None):
        with self.connect() as db:
            db.execute("INSERT INTO feed_events(account,user_id,name,kind,detail,checked,source) VALUES(?,?,?,?,?,?,?)",(entity_id("user",account),entity_id("user",ref),name[:512],kind[:100],detail[:10000],checked or stamp(),source[:100]))
            db.execute("DELETE FROM feed_events WHERE account=? AND serial NOT IN (SELECT serial FROM feed_events WHERE account=? ORDER BY serial DESC LIMIT 5000)",(account,account))

    def feed(self,account,offset=0,query="",*,fields=()):
        from profile_history import readable,decode,LABELS
        if not isinstance(fields,(tuple,list)) or any(k not in LABELS for k in fields):raise ValueError('Choose supported profile history fields.')
        with self.connect() as db:
            db.create_function('eye_profile_field',1,lambda value:(decode(value) or {}).get('field',''))
            clause=(' AND eye_profile_field(detail) IN ('+','.join('?' for _ in fields)+')') if fields else ''
            rows=db.execute("SELECT serial,user_id,name,kind,detail,checked,source FROM feed_events WHERE account=? AND instr(lower(name||' '||kind||' '||detail),lower(?))>0"+clause+" ORDER BY serial DESC LIMIT 100 OFFSET ?",(entity_id("user",account),query,*fields,max(0,offset))).fetchall()
        result=[dict(zip(("serial","id","name","kind","detail","checked","source"),r)) for r in rows]
        for row in result:
            change=decode(row['detail'])
            if change: row['profile_change']=change;row['detail']=readable(row['detail'])
        return result

    def forget_feed(self,account):
        with self.connect() as db:
            db.execute("DELETE FROM feed_profiles WHERE account=?",(entity_id("user",account),))
            db.execute("DELETE FROM feed_events WHERE account=?",(account,))

    def save_session(self,summary):
        raw=json.dumps(summary,allow_nan=False)
        if len(raw)>65536: raise ValueError("Session summary too large.")
        with self.connect() as db: db.execute("INSERT OR REPLACE INTO wellness_sessions VALUES(?,?)",(summary["id"],raw))

    def sessions(self):
        with self.connect() as db: rows=db.execute("SELECT summary FROM wellness_sessions ORDER BY id DESC LIMIT 100").fetchall()
        return [json.loads(r[0]) for r in rows]

    def delete_session(self,reference):
        if not isinstance(reference,str) or not 1<=len(reference)<=128:raise ValueError("Select an exact local session.")
        with self.connect() as db:db.execute("DELETE FROM wellness_sessions WHERE id=?",(reference,))

    def prune_sessions(self,before=None,*,all_history=False,preview=False):
        """Only explicit history preferences call this; ordinary reads never delete."""
        from datetime import datetime
        if before is None and not all_history:raise ValueError("Choose a retention date or all history.")
        count=0
        with self.connect() as db:
            cursor=db.execute("SELECT id,summary FROM wellness_sessions ORDER BY id")
            while True:
                rows=cursor.fetchmany(100)
                if not rows:break
                remove=[]
                for reference,raw in rows:
                    try:
                        stamp=datetime.fromisoformat(json.loads(raw).get("ended") or json.loads(raw)["started"])
                        old=stamp.replace(tzinfo=None)<before.replace(tzinfo=None) if before is not None else False
                    except (ValueError,TypeError,KeyError):old=False
                    if all_history or old:remove.append((reference,))
                count+=len(remove)
                if remove and not preview:db.executemany("DELETE FROM wellness_sessions WHERE id=?",remove)
        return count
