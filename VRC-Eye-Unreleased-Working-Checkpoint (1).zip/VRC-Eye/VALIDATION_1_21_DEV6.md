# 1.21.0 Development checkpoint 6 — validation

The final clean-extracted portable suite passed **4,448 tests and 1,059
subtests**, with no failures or errors. **26 new regressions** cover the new
contracts. The offline guard recorded **zero external socket attempts**.
Two existing warnings concern a test-class name and a duplicate-entry ZIP fixture.

## What was exercised

- Real SQLite/file workflows: live WAL cloning without source changes, scoped
  history, three-way merge conflicts, tombstones, profile bundle checksums,
  grant/secret exclusion, recovery cancellation and new-folder restore.
- Coordinated retention rollback when the account boundary changes, changed
  preview refusal, per-user isolation and incompatible WAL-store rejection.
- Actual shared API transport with synthetic replies: batch uncertainty and
  continuation, group permission changes, instance responses, gallery owned-file
  attachment/order and theme payload/acknowledgement handling.
- Actual headless desktop/batch/saved-detail callbacks and account clearing;
  local lock passphrase/backoff, cancellation/disconnection, owned-child cleanup,
  native URI handoff protocol and session queue expiry.
- Exact-byte moved-root recovery with preserved albums, changed destination
  rejection, compatible-copy rules, explicit declared-people facets, interrupted
  move reconciliation and trash denial without source deletion.
- History date/overlap semantics and mutual snapshot/opt-out provenance.
- All retained portable application regression cases.

All **570 manifest files** match the tested
extraction. All **521 Python files** parse with Python 3.10 grammar;
execution used Python 3.12.14. The seven launchers and every
Development 5 archive path are retained. Shell syntax, CLI version, dependency
consistency, final ZIP CRC and source-byte comparison passed.

`Send2Trash==2.1.0` is the new dependency. It was installed for validation;
trash behavior was exercised through a fake adapter, not a real desktop trash.

## Acceptance still open

Of **5,132 collected tests**, **473 native GUI tests skipped**,
**210 tests in 13 local-transport-associated modules were excluded**, and one
Unix bridge test was deselected. Some excluded modules contain portable unit
cases; none are counted as passed. These documented environment exclusions
mean this is not the full native/display/transport acceptance gate.
The exact command and exclusions are in BUILD_VALIDATION.json.

Offline fixtures do not establish native layout, locking, speech, URI handlers,
trash, tray, Windows/Linux credential vaults, Discord IPC, SteamVR, audio hardware,
Unity compilation, physical mobile pairing, installed VRCX coexistence, live
VRChat entitlement/permissions or third-party provider availability. No live
VRChat writes were performed.

The VRCX ledger has **49 source-implemented packages and 33 partial**.
The larger 160-package / 849-future-check roadmap remains incomplete; those
prepared checks are not reported as executed tests. This is a runnable source
ZIP, not a compiled executable, signed installer or automatic updater.

See [features and remaining gaps](VRCX_COMPLETION_DEV6.md),
[implementation ledger](IMPLEMENTATION_STATUS_1_21.md) and
[Development 5 validation](VALIDATION_1_21_DEV5.md).
