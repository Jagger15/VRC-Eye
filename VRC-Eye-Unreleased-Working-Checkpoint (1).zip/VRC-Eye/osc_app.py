"""Application lifetime, reviewed configuration, and adapters for shared OSC.

Only configuration is persisted. Permissions always require session arming;
imports and restarts cannot restore active inputs, publications or captures.
"""
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
import time

from osc_service import OSCService
from osc_controls import OSCControls
from osc_routes import OSCWorkspace
from osc_discovery import OSCDiscovery, OSCQueryServer
from osc_transport import literal_host, port


DEFAULT_TRANSPORT = dict(schema=1, target_host="127.0.0.1", target_port=9000,
    receive_host="127.0.0.1", receive_port=9001, allow_lan=False,
    fallback_port=True, advertise=True, tracking=False, auto_observe=True)
DEFAULT_PREFERENCES = dict(schema=1, view="Casual", setup_step=0, profile="Observation Only",
                          routing_mode="Observation", deck_pins=[], voice_mode="unknown")


def transport_settings(raw=None):
    if raw is None:
        return dict(DEFAULT_TRANSPORT)
    if not isinstance(raw, dict) or set(raw) - set(DEFAULT_TRANSPORT):
        raise ValueError("Unknown OSC transport setting.")
    value = dict(DEFAULT_TRANSPORT, **raw)
    if type(value["schema"]) is not int or value["schema"] != 1:
        raise ValueError("Unsupported OSC configuration version.")
    for key in ("allow_lan", "fallback_port", "advertise", "tracking", "auto_observe"):
        if type(value[key]) is not bool:
            raise ValueError("OSC switches must be true or false.")
    value["target_host"] = literal_host(value["target_host"], allow_lan=value["allow_lan"])
    value["receive_host"] = literal_host(value["receive_host"], allow_lan=value["allow_lan"], bind=True)
    value["target_port"] = port(value["target_port"])
    value["receive_port"] = port(value["receive_port"], ephemeral=True)
    return value


class OSCApplication:
    def __init__(self, app, *, service=None, discovery=None, query_server=None,
                 clock=time.monotonic, wall=time.time, autostart=True):
        self.app, self.clock, self.wall = app, clock, wall
        self.store = app.sidebar.store
        self.service = service or OSCService(clock=clock)
        self.discovery = discovery or OSCDiscovery()
        self.query_server = query_server or OSCQueryServer()
        self.discovery.context_provider = lambda: (self.service.generation, self.service.avatar_generation)
        self.closed = False
        self.message = "Observation first. Review and arm each output capability for this session."
        self._reviews, self._peer_work = {}, {}
        self._peer_reviews = {}
        self._peer_used = deque(maxlen=256)
        self._eligible_avatars = {}
        self._context = None
        self._last_diagnostics = None
        self._configuration_digest = ""
        self._discovery_description = None
        self._query_parameters = set()
        self._last_maintenance = self._last_discovery_refresh = -1e30
        self._bookmarks = deque(maxlen=32)
        self._simulator = None
        self.config = self._load("osc.transport", DEFAULT_TRANSPORT, transport_settings)
        self.preferences = self._load("osc.preferences", DEFAULT_PREFERENCES, self._preferences)
        self.workspace = OSCWorkspace(self.service, clock=clock)
        self._unsubscribe_ingress = self.service.subscribe_ingress(self.workspace.receive)
        self.controls = OSCControls(self.service, clock=clock, hooks={
            "suspend_automation": self._suspend_automation,
            "suspend_avatar_actions": self._suspend_automation,
            "pause_media": self._pause_media, "bookmark": self.bookmark,
            "local_safety": self._local_safety, "leave_safety": self._leave_safety})
        self.controls.execute(self.controls.review("voice.configure", mode=self.preferences["voice_mode"]))
        try:
            saved = self.store.option("osc.workspace", None)
            if saved is not None:
                self.workspace.import_configuration(saved)
        except (OSError, ValueError, sqlite3.Error):
            self.message = "Saved OSC configuration was invalid; it remains inactive."
        self._configuration_digest = self._digest(self.workspace.export_configuration())
        self._sync_context()
        if autostart:
            self.start_observation()

    def start_observation(self):
        if not self.blocked:
            self.discover()
            # Passive receiving only. Remote destinations require fresh review.
            if self.config["auto_observe"] and not self.config["allow_lan"]:
                try:
                    self.connect()
                except (ValueError, OSError):
                    self.message = "OSC receiving could not start. Review OSC Transport in Networking."

    @property
    def blocked(self):
        return self.closed or bool(getattr(self.app, "demo", False) or getattr(self.app, "safe_mode", False))

    def _enabled(self):
        if self.blocked:
            raise ValueError("Live OSC is disabled in Demo and startup Safe Mode. The simulator remains separate.")

    @staticmethod
    def _digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()

    def _load(self, key, default, validator):
        try:
            return validator(self.store.option(key, default))
        except (OSError, ValueError, sqlite3.Error):
            self.message = "Some saved OSC preferences were invalid; conservative defaults are in use."
            return deepcopy(default)

    @staticmethod
    def _preferences(raw):
        if not isinstance(raw, dict) or set(raw) - set(DEFAULT_PREFERENCES):
            raise ValueError("Unknown OSC preference.")
        value = dict(DEFAULT_PREFERENCES, **raw)
        if type(value["schema"]) is not int or value["schema"] != 1 or value["view"] not in ("Casual", "Advanced", "Developer"):
            raise ValueError("Invalid OSC view or preference version.")
        if type(value["setup_step"]) is not int or not 0 <= value["setup_step"] <= 12:
            raise ValueError("Invalid OSC setup step.")
        if value["profile"] not in ("Observation Only", "Basic Controls", "Creator"):
            raise ValueError("Unknown OSC operating profile.")
        if value["routing_mode"] not in ("Observation", "Coexistence", "Managed routing"):
            raise ValueError("Unknown OSC routing mode.")
        if value["voice_mode"] not in ("unknown", "toggle", "hold"):
            raise ValueError("Unknown voice behavior.")
        pins = value["deck_pins"]
        if not isinstance(pins, list) or len(pins) > 32 or any(not isinstance(x, str) or not x.startswith("/input/") or len(x) > 100 for x in pins):
            raise ValueError("Choose at most 32 input controls to pin.")
        return value

    def save_preferences(self, mapping):
        clean = self._preferences(dict(self.preferences, **mapping))
        self.store.set_option("osc.preferences", clean)
        self.preferences = clean
        return deepcopy(clean)

    def ensure_active(self):
        self._sync_context()
        self._enabled()
        return tuple(self.service.state_guard)

    def review_control(self, action, **payload):
        self.ensure_active()
        return self.controls.review(action, **payload)

    def execute_control(self, review):
        self.ensure_active()
        return self.controls.execute(review)

    def review_endpoint(self, address, args, **options):
        self.ensure_active()
        return self.service.review(address, args, **options)

    def submit_endpoint(self, review):
        self.ensure_active()
        return self.service.submit(review)

    def _sync_context(self):
        api = getattr(self.app, "api", None)
        roster = getattr(self.app, "world_roster", None)
        value = (id(api), getattr(api, "user_id", "") if getattr(api, "authenticated", False) else "",
                 getattr(api, "session_revision", 0), getattr(self.app, "data_generation", 0),
                 getattr(roster, "source", ""), getattr(roster, "generation", 0),
                 getattr(roster, "world_id", ""), self.blocked)
        if value != self._context:
            self._context = value
            self._eligible_avatars.clear()
            self._reviews.clear()
            self.service.set_context(session=self._digest(value))
            self.controls.reset_context()
            self._cancel_peer_work("Account, client, world or application mode changed")
            if self.blocked:
                self.disconnect()

    def review(self, action, **payload):
        self._enabled()
        self._sync_context()
        if action == "transport":
            data = {"settings": transport_settings(payload.get("settings"))}
        elif action == "arm":
            scopes = payload.get("scopes", [])
            if not isinstance(scopes, (list, tuple)) or not 1 <= len(scopes) <= 128 or not all(isinstance(s, str) for s in scopes):
                raise ValueError("Choose specific OSC capabilities or endpoint addresses to arm.")
            source = payload.get("source", "manual")
            if not isinstance(source, str) or not 1 <= len(source) <= 120:
                raise ValueError("Use a bounded local source label.")
            data = {"scopes": list(scopes), "source": source, "public": payload.get("public", False) is True}
        else:
            raise ValueError("Unknown OSC configuration operation.")
        result = dict(token=secrets.token_hex(16), action=action, payload=data,
            guard=tuple(self.service.state_guard), context=self._context, expires_at=self.clock() + 30)
        if len(self._reviews) >= 64:
            self._reviews.pop(next(iter(self._reviews)))
        self._reviews[result["token"]] = deepcopy(result)
        return deepcopy(result)

    def execute(self, review):
        self._enabled()
        self._sync_context()
        saved = self._reviews.pop(review.get("token"), None) if isinstance(review, dict) else None
        if saved != review or saved is None or saved["expires_at"] < self.clock() or saved["guard"] != tuple(self.service.state_guard) or saved["context"] != self._context:
            raise ValueError("OSC configuration review expired or changed. Review again.")
        data = saved["payload"]
        if saved["action"] == "transport":
            self.disconnect()
            self.store.set_option("osc.transport", data["settings"])
            self.config = deepcopy(data["settings"])
            self.discovery.stop()
            self.discovery.allow_lan = self.config["allow_lan"]
            self._discovery_description = None
            self.message = "Transport settings saved. Connect to observe; outputs require fresh arming."
            return deepcopy(self.config)
        return self.service.arm(data["scopes"], source=data["source"], reviewed=True, public=data["public"])

    def _tick_discovery(self):
        snap = self.discovery.snapshot()
        if not isinstance(snap, dict):
            return
        description = snap.get("description")
        matches = bool(description and description.get("osc_host") == self.config["target_host"]
                       and description.get("osc_port") == self.config["target_port"])
        avatar = self.service.observation("/avatar/change")
        checked = snap.get("last_checked")
        started = snap.get("description_started_at")
        fresh_schema = tuple(snap.get("description_context") or ()) == (self.service.generation, self.service.avatar_generation)
        if avatar:
            fresh_schema = fresh_schema and started is not None and started >= avatar["received_at"]
        if matches and avatar:
            advertised_avatar = next((row.get("value") for row in description.get("endpoints", [])
                                      if row.get("address") == "/avatar/change"), None)
            if advertised_avatar is not None and advertised_avatar != [avatar["value"]]:
                fresh_schema = False
        if matches:
            schema = [{k: row.get(k) for k in ("address", "type", "types", "access", "range", "description")}
                      for row in description.get("parameters", [])]
            key = (self.service.avatar_generation, self._digest(schema))
            if fresh_schema and key != self._discovery_description:
                # Metadata describes compatibility; it never activates a route
                # or elevates a native read-only endpoint.
                for address in self._query_parameters:
                    old = self.service.registry.get(address)
                    if old is not None and old.evidence.startswith("OSCQuery advertised"):
                        self.service.registry.unregister_parameter(address)
                self._query_parameters.clear()
                for item in description.get("parameters", []):
                    if item.get("type") not in ("Bool", "Int", "Float"):
                        continue
                    prior = self.service.registry.get(item["address"])
                    if prior is not None and prior.evidence.startswith("Declared Avatar Toolkit"):
                        continue
                    limits = item.get("range", [])
                    limits = limits[0] if isinstance(limits, list) and limits and isinstance(limits[0], dict) else {}
                    try:
                        self.service.registry.register_parameter(item["address"], item["type"],
                            minimum=limits.get("MIN"), maximum=limits.get("MAX"),
                            read_only=item.get("access") not in (2, 3), public=True,
                            evidence="OSCQuery advertised, not behavior tested; audience unknown")
                        self._query_parameters.add(item["address"])
                    except ValueError:
                        continue
                self._discovery_description = key
            if fresh_schema and checked is not None and 0 <= self.clock() - checked <= 10:
                self.service.mark_health(True)
        if snap.get("selected") and self.clock() - self._last_discovery_refresh >= 5 and snap.get("state") != "Loading description":
            self._last_discovery_refresh = self.clock()
            self.discovery.refresh()

    def _tick_signals(self):
        avatar = getattr(self.app, "avatar_creator", None)
        signals = getattr(avatar, "signal_snapshot", {}).get("signals", {})
        for row in self.workspace.configuration.get("routes", []):
            if row.get("source_identity") != "local-adapter" or row.get("source_endpoint"):
                continue
            source = row["source_id"]
            signal = signals.get(source)
            if signal is None:
                continue
            stamp = signal.get("observed_at")
            valid = signal.get("valid") is True and signal.get("quality") not in ("simulated", "file_analysis") and stamp is not None
            age = max(0, self.wall() - stamp) if stamp is not None else 1e6
            try:
                self.workspace.sample(row["id"], signal.get("value"), source_id=source,
                    valid=valid, sampled_at=self.clock() - age)
            except ValueError:
                continue

    def arm(self, scopes, *, source="manual", public=False):
        return self.execute(self.review("arm", scopes=scopes, source=source, public=public))

    def configure_transport(self, mapping):
        return self.execute(self.review("transport", settings=mapping))

    def connect(self):
        self._enabled()
        if self.service.snapshot().get("connected"):
            return self.service.snapshot()
        keys = ("target_host", "target_port", "receive_host", "receive_port", "allow_lan", "fallback_port")
        result = self.service.connect(**{k: self.config[k] for k in keys})
        try:
            self.query_server.start(osc_port=self.service.transport.receive_port,
                receive_host=self.config["receive_host"], allow_lan=self.config["allow_lan"],
                tracking=self.config["tracking"], advertise=self.config["advertise"])
        except (OSError, ValueError):
            self.message = "OSC receiver is available; OSCQuery advertisement failed. Manual routing remains available."
        return result

    def disconnect(self):
        self._cancel_peer_work("OSC disconnected")
        self.query_server.stop()
        self.service.disconnect()
        self.controls.reset_context()

    def discover(self):
        self._enabled()
        self.discovery.start()
        return self.discovery.snapshot()

    def select_instance(self, identifier):
        self._enabled()
        self.stop_controls("Selected OSCQuery instance changed")
        return self.discovery.select(identifier)

    def inspect_query(self, url):
        self._enabled()
        return self.discovery.inspect(url)

    def stop_controls(self, reason="Stopped by user"):
        self._reviews.clear()
        self.service.stop_controls(reason)
        self._suspend_automation()
        self.controls.reset_context()
        self._cancel_peer_work(reason)
        return self.service.snapshot()

    def _suspend_automation(self):
        self.workspace.cancel_rules("OSC controls stopped")
        for key in tuple(self.workspace.routes):
            self.workspace.stop_route(key, "OSC controls stopped")
        avatar = getattr(self.app, "avatar_creator", None)
        if avatar is not None:
            avatar.routes_enabled = False
            avatar.link.disarm()
        return "Local routes, rules, and Avatar Link writers suspended"

    def _pause_media(self):
        page = getattr(self.app.sidebar, "pages", {}).get("Media & Audio")
        if page is not None:
            page.stop()
        else:
            service = getattr(self.app, "media_service", None)
            if service is not None:
                service.stop()
        avatar = getattr(self.app, "avatar_creator", None)
        if avatar is not None:
            avatar.signals.set_media_source("none")
        return "Local media output paused"

    def _local_safety(self):
        avatar = getattr(self.app, "avatar_creator", None)
        if avatar is not None:
            avatar.clear_overlay()
            avatar.safety_active = True
        world = getattr(getattr(self.app, "world_view", None), "creator", None)
        if world is not None:
            world.clear_overlay()
        peer = getattr(self.app, "peer_service", None)
        if peer is not None:
            peer.private_mode()
        wellness = self.app.sidebar.pages.get("Wellness")
        if wellness is not None:
            if avatar is not None and avatar._safety_previous is None:
                avatar._safety_previous = wellness.engine.safety_busy
            wellness.engine.safety_busy = True
            wellness.runtime.display({})
        return "Creator cards hidden, peer sharing stopped and local reminders held"

    def _leave_safety(self):
        avatar = getattr(self.app, "avatar_creator", None)
        if avatar is not None:
            avatar.leave_safety()
        return "Local reminder hold released; OSC, media and sharing require deliberate rearming"

    def cancel_owner(self, owner):
        return self.controls.cancel_owner(owner)

    def action_status(self, identifier):
        return next((r for r in self.service.snapshot().get("actions", []) if r.get("id") == identifier),
                    {"id": identifier, "status": "expired", "detail": "No retained action record"})

    def camera_capture(self, owner="manual-camera", delay=0):
        self.ensure_active()
        result = self.controls.execute(self.controls.review("camera.capture", owner=owner, countdown=delay))
        return dict(result, id=result["action_id"])

    def camera_prepare(self, owner="world-map"):
        self.ensure_active()
        values = {"Mode": 1, "Environment": True, "GreenScreen": False,
                  "LocalPlayer": False, "RemotePlayer": False, "ShowUIInCamera": False}
        return self.controls.execute(self.controls.review("camera.preset", owner=owner, settings=values))

    def show_networking(self):
        self.app.sidebar.show("Networking")

    def show_controls(self):
        self.app.sidebar.show("VRC Eye Primary")
        page = self.app.sidebar.pages.get("VRC Eye Primary")
        if page and "OSC Controls" in getattr(page, "frames", {}):
            page.tabs.select(page.frames["OSC Controls"])

    def remember_eligible_avatars(self, entries, *, client, generation):
        self._sync_context()
        if self.blocked or client is not getattr(self.app, "api", None) or not getattr(client, "authenticated", False) or generation != getattr(self.app, "data_generation", 0):
            raise ValueError("Avatar collection belongs to a different account or log session.")
        self.controls.set_eligible_avatars(entries)
        self._eligible_avatars.update(entries)
        self._eligible_avatars = dict(list(self._eligible_avatars.items())[-1000:])
        self.controls.set_eligible_avatars(self._eligible_avatars)

    def diagnostic_report(self):
        """Default export excludes endpoint values, chat, tracking and identities."""
        snap = self.service.snapshot()
        from osc_connection_health import redacted
        return {"schema": 1, "application": "VRC Eye", "redaction": "Metadata only; values and identities omitted",
            "connection_health":redacted(self.snapshot()['connection_health']),
            "connection": {key: snap.get(key) for key in ("connected", "generation", "avatar_generation", "mode", "armed")},
            "counts": {"observations": len(snap.get("observations", {})), "owners": len(snap.get("owners", [])),
                       "actions": len(snap.get("actions", [])), "invalid": snap.get("invalid", 0), "dropped": snap.get("dropped", 0)},
            "actions": [{"status": row.get("status"), "created_at": row.get("created_at"),
                         "sent_at": row.get("sent_at")} for row in snap.get("actions", [])[-128:]],
            "limitation": "OSC observations and transmission do not establish causation or rendered completion."}

    def bookmark(self):
        value = self.diagnostic_report()
        self._bookmarks.append(value)
        crash = self.app.sidebar.pages.get("Crash & Diagnostics")
        if crash and not getattr(self.app, "demo", False):
            crash.service.offer("manual", "vrc_eye", {"reason": "manual", "category": "VRC Eye", "count": value["counts"]["actions"]})
        return value

    def export_diagnostics(self, path=None):
        if path is None:
            return self.diagnostic_report()
        with Path(path).open("x", encoding="utf-8") as stream:
            json.dump(self.diagnostic_report(), stream, ensure_ascii=False, indent=2, allow_nan=False)
        return str(path)

    def _peer_snapshot(self):
        """Use accepted service records, never raw packets or caller payloads.

        PeerService has already authenticated, validated and clock-adjusted
        these records. Its monotonic timer is the scheduling authority.
        """
        peer = getattr(self.app, "peer_service", None)
        snap = peer.snapshot() if peer is not None else {}
        snap["osc_countdowns"] = {}
        privacy = snap.get("privacy", {})
        if (self.blocked or snap.get("mode", "Private") == "Private" or
                snap.get("state") in ("BLOCKED", "CLOSED", "PRIVATE") or
                any(privacy.get(key, False) for key in ("incognito", "safety", "streamer"))):
            return snap
        peers = {p["peer_id"]: p for p in snap.get("peers", [])}
        timers = {t["id"]: t for t in snap.get("timers", [])}
        permissions = snap.get("permissions", {})
        wall, now = self.wall(), self.clock()
        for item in snap.get("inbox", []):
            peer_id, identifier = item.get("peer_id"), item.get("message_id")
            current = peers.get(peer_id, {})
            timer = timers.get(identifier, {})
            if (item.get("kind") != "countdown.start" or item.get("status") != "ACCEPTED" or
                    item.get("direction") != "incoming" or item.get("source") != "VRC_EYE" or
                    item.get("retained") or current.get("state") != "READY" or
                    not item.get("session") or item.get("session") != current.get("session") or
                    item.get("expires_at", 0) <= wall):
                continue
            payload = item.get("payload", {})
            if not isinstance(payload, dict) or set(payload) - {"countdown_id", "target_at", "title"}:
                continue
            if (timer.get("source") != "VRC_EYE" or timer.get("peer_id") != peer_id or
                    timer.get("context") != item.get("context") or timer.get("action") != "countdown" or
                    timer.get("state") not in ("RUNNING", "FINISHED")):
                continue
            deadline = timer.get("deadline")
            if type(deadline) not in (int, float) or not now - 5 < deadline <= now + 120:
                continue
            context = item.get("context", "")
            if context == item["session"]:
                context_state = {"session": context}
            else:
                context_state = next((c for c in snap.get("contexts", [])
                    if c.get("id") == context and c.get("active") is True and
                    c.get("state") == "ACTIVE" and c.get("expires_at", 0) > wall and
                    ((c.get("owner") == peer_id and c.get("session") == item["session"]) or
                     (c.get("owner") == "LOCAL" and c.get("members", {}).get(peer_id) == item["session"]))), None)
                if context_state is None:
                    continue
                context_state = {key: deepcopy(context_state.get(key)) for key in
                                 ("id", "owner", "session", "revision", "members", "expires_at")}
            scope = {"paused": bool(permissions.get("paused")),
                     "blocked": peer_id in permissions.get("blocked", []),
                     "global_denied": ["coordination", "receive"] in permissions.get("global_denied", []),
                     "rules": [r for r in permissions.get("rules", [])
                         if r.get("peer") == peer_id and r.get("family") == "coordination" and
                         r.get("direction") == "receive" and
                         (not r.get("session") or r["session"] == item["session"]) and
                         (not r.get("context") or r["context"] == context) and
                         (not r.get("message_id") or r["message_id"] == identifier)]}
            if scope["paused"] or scope["blocked"] or scope["global_denied"] or any(r.get("decision") == "deny" for r in scope["rules"]):
                continue
            timer_identity = {key: deepcopy(timer.get(key)) for key in
                              ("id", "deadline", "target_at", "peer_id", "context", "source", "action", "precision")}
            snap["osc_countdowns"][identifier] = {"message": deepcopy(item), "timer": timer_identity,
                "timer_state": timer["state"], "remaining": max(0., deadline - now),
                "permissions": self._digest(scope), "context_state": context_state}
        return snap

    def pending_peer_actions(self):
        snap = self._peer_snapshot()
        rows = []
        for identifier, row in snap["osc_countdowns"].items():
            if identifier in self._peer_used or row["timer_state"] != "RUNNING" or not 0 < row["remaining"] <= 30:
                continue
            rows.append(dict(deepcopy(row["message"]), remaining=row["remaining"],
                deadline=row["timer"]["deadline"], precision=row["timer"]["precision"],
                notice="Review one local capture within the last 30 seconds. Countdown acceptance did not authorize a photo; synchronization is approximate."))
        return rows

    def review_peer_action(self, message_id):
        self._enabled()
        self._sync_context()
        row = self._peer_snapshot()["osc_countdowns"].get(message_id)
        if row is None or message_id in self._peer_used or row["timer_state"] != "RUNNING" or not 0 < row["remaining"] <= 30:
            raise ValueError("Choose an accepted countdown from a connected peer with 1–30 seconds remaining.")
        owner = "peer-camera:" + message_id
        reviewed = self.controls.review("camera.capture", owner=owner, countdown=row["remaining"])
        result = {"token": secrets.token_hex(16), "message": row["message"],
                  "timer": row["timer"], "context_state": row["context_state"],
                  "review": reviewed, "owner": owner, "permissions": row["permissions"],
                  "guard": tuple(self.service.state_guard), "context": self._context,
                  "expires_at": min(self.clock() + 30, row["timer"]["deadline"])}
        if len(self._peer_reviews) >= 64:
            discarded = self._peer_reviews.pop(next(iter(self._peer_reviews)))
            self.controls.discard_review(discarded["review"])
        self._peer_reviews[result["token"]] = deepcopy(result)
        return deepcopy(result)

    def execute_peer_action(self, review):
        self._enabled()
        self._sync_context()
        saved = self._peer_reviews.pop(review.get("token"), None) if isinstance(review, dict) else None
        if saved is None:
            raise ValueError("Review this peer's countdown first; the approval is single-use.")
        self.controls.discard_review(saved["review"])
        if (saved != review or self.clock() >= saved["expires_at"] or
                saved["guard"] != tuple(self.service.state_guard) or saved["context"] != self._context):
            raise ValueError("Peer camera review expired or changed. Nothing was scheduled.")
        identifier = saved["message"]["message_id"]
        row = self._peer_snapshot()["osc_countdowns"].get(identifier)
        if (identifier in self._peer_used or row is None or row["timer_state"] != "RUNNING" or
                not 0 < row["remaining"] <= 30 or any(row[key] != saved[key] for key in
                ("message", "timer", "context_state", "permissions"))):
            raise ValueError("Peer session, context, countdown or permissions changed. Nothing was scheduled.")
        # The review authorizes this exact monotonic deadline. Refresh only the
        # shrinking delay so time spent reading cannot postpone the photograph.
        fresh = self.controls.review("camera.capture", owner=saved["owner"], countdown=row["remaining"])
        result = self.controls.execute(fresh)
        action_id = result.get("action_id", result.get("id"))
        self._peer_used.append(identifier)
        self._peer_work[identifier] = dict(deepcopy(saved), action_id=action_id)
        return dict(result, id=action_id, notice="One local capture scheduled. No acceptance or execution message was sent to the peer.")

    def _cancel_peer_work(self, reason):
        for row in tuple(self._peer_reviews.values()):
            self.controls.discard_review(row["review"])
        self._peer_reviews.clear()
        for row in tuple(self._peer_work.values()):
            self.cancel_owner(row["owner"])
        self._peer_work.clear()

    def _tick_peers(self):
        if not self._peer_work and not self._peer_reviews:
            return
        # OSC pumps faster than the sidebar. Apply inherited privacy and drain
        # pending peer disconnect/context events before this tick can send.
        peer_app = getattr(self.app.sidebar, "peer", None)
        if peer_app is not None:
            peer_app.tick()
        else:
            peer_service = getattr(self.app, "peer_service", None)
            if peer_service is not None:
                peer_service.tick()
        snap = self._peer_snapshot()
        for token, saved in tuple(self._peer_reviews.items()):
            row = snap["osc_countdowns"].get(saved["message"]["message_id"])
            if (row is None or self.clock() >= saved["expires_at"] or
                    saved["guard"] != tuple(self.service.state_guard) or saved["context"] != self._context or
                    any(row[key] != saved[key] for key in ("message", "timer", "context_state", "permissions"))):
                self.controls.discard_review(saved["review"])
                self._peer_reviews.pop(token, None)
        for key, row in tuple(self._peer_work.items()):
            current = snap["osc_countdowns"].get(key)
            if (current is None or row["guard"] != tuple(self.service.state_guard) or row["context"] != self._context or
                    any(current[field] != row[field] for field in ("message", "timer", "context_state", "permissions"))):
                self.cancel_owner(row["owner"])
                self._peer_work.pop(key, None)
                continue
            action = self.service.action(row["action_id"])
            if action is None or action.get("status") in ("cancelled", "failed", "expired", "rejected", "released"):
                self._peer_work.pop(key, None)

    def set_simulator(self, enabled):
        if enabled:
            if self._simulator is None:
                from osc_simulator import OSCSimulator
                self._simulator = OSCSimulator()
        elif self._simulator is not None:
            self._simulator.close()
            self._simulator = None
        return self.simulator_snapshot()

    def inject_simulation(self, event, payload=None):
        if self._simulator is None:
            raise ValueError("Start the isolated simulator first.")
        return self._simulator.inject(event, **(payload or {}))

    def simulator_snapshot(self):
        return self._simulator.snapshot() if self._simulator is not None else {"state": "Stopped", "live": False}

    def tick(self):
        if self.closed:
            return
        try:
            self._sync_context()
            self._tick_peers()  # Revoke before the scheduler can transmit.
            self._tick_signals()
            self.workspace.tick()
            self.controls.tick()
            self.service.tick()
            observed_avatar = self.service.observation("/avatar/change")
            if observed_avatar and observed_avatar.get("live"):
                self._eligible_avatars.setdefault(observed_avatar["value"], "recents")
                if len(self._eligible_avatars) > 1000:
                    self._eligible_avatars.pop(next(iter(self._eligible_avatars)))
            # Context changes may clear a controller's private eligibility cache.
            # Reapply only account-bound collection evidence and locally worn IDs.
            self.controls.set_eligible_avatars(self._eligible_avatars)
            if self.clock() - self._last_maintenance < 1:
                return
            self._last_maintenance = self.clock()
            self._tick_discovery()
            voice_mode = self.controls.snapshot()["voice"]["mode"]
            if voice_mode != self.preferences["voice_mode"]:
                self.save_preferences({"voice_mode": voice_mode})
            configuration = self.workspace.export_configuration()
            digest = self._digest(configuration)
            if digest != self._configuration_digest:
                self.store.set_option("osc.workspace", configuration)
                self._configuration_digest = digest
            snap = self.service.snapshot()
            summary = (snap.get("connected"), snap.get("generation"), snap.get("avatar_generation"),
                       snap.get("permission_revision"), snap.get("dropped", 0), snap.get("invalid", 0))
            if summary != self._last_diagnostics:
                self._last_diagnostics = summary
                crash = self.app.sidebar.pages.get("Crash & Diagnostics")
                if crash and not getattr(self.app, "demo", False):
                    crash.service.offer("osc.activity", "vrc_eye", {"state": "connected" if summary[0] else "disconnected",
                        "count": len(snap.get("owners", [])), "dropped": snap.get("dropped", 0), "errors": snap.get("invalid", 0)})
        except (ValueError, OSError, sqlite3.Error) as error:
            self.service.stop_controls("OSC application update failed")
            self.message = "OSC controls paused: " + str(error)[:300]

    def snapshot(self):
        data={"service": self.service.snapshot(), "controls": self.controls.snapshot(),
                "workspace": self.workspace.snapshot(), "discovery": self.discovery.snapshot(),
                "query_server": self.query_server.snapshot(), "transport": deepcopy(self.config),
                "preferences": deepcopy(self.preferences), "message": self.message,
                "simulator": self.simulator_snapshot()}
        data['socket']=self.service.transport.snapshot()
        from osc_connection_health import report
        data['connection_health']=report(data,now=self.clock())
        return data

    def close(self):
        if self.closed:
            return
        self.stop_controls("Application closing")
        self.closed = True
        self.workspace.close()
        self.controls.close()
        self.disconnect()
        self.discovery.stop()
        self._unsubscribe_ingress()
        if self._simulator is not None:
            self._simulator.close()
