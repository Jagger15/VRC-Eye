"""Offline player-session replay. Isolated memory only; no API, bridge or history writes."""
import argparse
import json
from pathlib import Path
import time

from avatar_watch import SessionParser
from player_sessions import PlayerSessionService,utc
from player_session_model import PlayerEvent


def synthetic(count=128):
    if type(count) is not int or not 1<=count<=2000:raise ValueError("Use 1–2000 synthetic players.")
    service=PlayerSessionService(demo=True);at=time.time()
    service.accept(PlayerEvent.make("instance.entered",utc(at),data={"world_name":"Synthetic instance"}))
    for n in range(count):
        user=f"usr_{n:08x}-1111-2222-3333-444444444444"
        service.accept(PlayerEvent.make("player.joined",utc(at),user_id=user,name=f"Demo Player {n+1}"))
        service.accept(PlayerEvent.make("avatar.changed",utc(at),user_id=user,name=f"Demo Player {n+1}",data={"avatar_name":f"Demo Avatar {n%12+1}"}))
    return service


def replay(path,stop=None):
    path=Path(path)
    if path.stat().st_size>256*1024**2:raise ValueError("Replay is limited to a 256 MiB log.")
    service=PlayerSessionService(demo=True);parser=SessionParser("offline-replay");parser.reconstructing=True
    with path.open("rb") as raw:
        prefix=raw.read(4)
    encoding="utf-16" if prefix.startswith((b"\xff\xfe",b"\xfe\xff")) else "utf-8-sig"
    count=0
    with path.open(encoding=encoding,errors="replace") as stream:
        while line:=stream.readline(524289):
            if stop is not None and stop.is_set():raise ValueError("Replay canceled.")
            count+=1
            if len(line)>524288:raise ValueError("Replay encountered an oversized log line.")
            parser.feed(line);service.ingest(parser.player_events.drain())
    service.replay_lines=count;return service


def report(service):
    return dict(mode="Isolated offline simulation",players=len(service.rows),active=sum(r.active for r in service.rows.values()),
                unresolved=sum(not r.user_id for r in service.rows.values()),conflicts=sum(r.conflict for r in service.rows.values()),
                timeline_events=len(service.timeline),normalized_events_retained=len(service.seen),history_writes=0,
                source_lines=getattr(service,"replay_lines",None),private_fields="Names, IDs, notes and instance codes omitted")


def main():
    parser=argparse.ArgumentParser(description=__doc__);source=parser.add_mutually_exclusive_group()
    source.add_argument("--log",type=Path);source.add_argument("--synthetic",type=int,default=128)
    parser.add_argument("--output",type=Path,help="Optional destination for aggregate diagnostics only")
    args=parser.parse_args();service=replay(args.log) if args.log else synthetic(args.synthetic)
    text=json.dumps(report(service),indent=2)
    if args.output:args.output.write_text(text+"\n",encoding="utf-8")
    print(text)


if __name__=="__main__":main()
