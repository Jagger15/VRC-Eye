"""Read-only state views, VRC Eye-only database diagnostics and reviewed report bundles."""
from __future__ import annotations
from copy import deepcopy
from contextlib import closing
from dataclasses import asdict, is_dataclass
from pathlib import Path
import json
import os
import platform
import sqlite3
import time
import zipfile
from developer_catalog import CATALOG_REVISION, OPERATIONS
from developer_core import bounded_json, canonical, redact, safe_text, stamp


def observe_pipeline(recorder, raw, *, account='', state='packet'):
    """Observe only VRC Eye's receive-only pipeline; never accept or log its URL/token."""
    if recorder is None: return
    if state != 'packet':
        recorder.emit('pipeline.lifecycle', {'state': state, 'transport': 'receive-only',
                      'reason': 'No automatic replay of server events; reconcile snapshots after gaps.'}, account=account)
        return
    try:
        envelope = bounded_json(raw)
        if not isinstance(envelope, dict): raise ValueError('Envelope is not an object.')
        kind = envelope.get('type')
        if not isinstance(kind, str) or len(kind) > 120: raise ValueError('Invalid event type.')
        content = envelope.get('content')
        if isinstance(content, str): content = bounded_json(content)
        from friend_feed import parse_packet
        interpreted = parse_packet(raw)
        recorder.emit('pipeline.event', {'eventType': kind, 'phase': 'decoded',
                      'parser_supported': interpreted is not None, 'payload': content,
                      'sequence_scope': 'Local recorder only; not a server global sequence'}, account=account)
    except (ValueError, TypeError, UnicodeError):
        recorder.emit('pipeline.rejected', {'reason': 'Malformed, oversized or unsupported pipeline envelope'}, account=account)


def state_snapshot(app, service, section='Players'):
    if service.environment == 'Replay': return service.replay.snapshot()
    if service.environment == 'Sandbox':
        return {'environment':'Sandbox', 'source':'Synthetic API fixtures; no live application store is accessed',
                'records':redact(deepcopy(service.sandbox.records), local=True)}
    if section == 'API cache': return service.cache_snapshot()
    players = getattr(app, 'player_sessions', None)
    if section == 'Players':
        if players is None: return {'state':'unavailable', 'reason':'Player service is not initialized.'}
        now, wall = players.clock(), players.wall()
        rows = []
        for record in list(players.rows.values())[:100]:
            observations = {}
            for field, sources in list(record.fields.items())[:40]:
                winner = record.get(field, now)
                observations[field] = {'selected':winner.inspect(now,wall),
                    'candidates':[v.inspect(now,wall) for v in list(sources.values())[:8]]}
            rows.append({'userId':record.user_id, 'name':record.name, 'state':record.presence.value,
                         'active':record.active, 'conflict':record.conflict, 'observations':observations})
        return redact({'environment':'Live', 'source':'Shared PlayerSessionService', 'revision':players.revision,
                'health':players.health, 'count':len(players.rows), 'returned':len(rows),
                'partial':len(players.rows)>len(rows), 'rows':rows}, local=True)
    if section == 'Session':
        return redact({'environment':'Live', 'source':'Shared local session store; not a live server roster',
                       'revision':getattr(players,'revision',None), 'metadata':getattr(players,'meta',{})}, local=True)
    if section == 'Last API result':
        return deepcopy(service.last_response or {'state':'No workbench response captured yet.'})
    if section == 'Providers': return integrations(app, service)
    raise ValueError('Choose a supported read-only state view.')


def integrations(app, service):
    if service.environment != 'Live':
        return {'environment':service.environment, 'live_providers':'Not inspected in this environment',
                'capabilities':['API fixture execution','Player model replay','Local log parser','Bounded parser fuzzing'],
                'network_requests':0}
    shell = getattr(app,'sidebar',None)
    pages = getattr(shell,'pages',{})
    result = {'environment':'Live', 'provider_scope':'Read-only snapshots of initialized services; nothing is started or granted.'}
    sources = {
        'OSC':getattr(app,'osc_service',None),
        'Eye-to-Eye':getattr(app,'peer_service',None),
        'Companion ownership':getattr(app,'vrcx_companion',None),
        'Optional bridge':getattr(getattr(app,'bridge',None),'state',None),
        'Runtime Companion':getattr(pages.get('Unity Player'),'service',None),
        'Resources':getattr(pages.get('Performance & Security'),'service',None),
    }
    for name, provider in sources.items():
        if provider is None or not callable(getattr(provider,'snapshot',None)):
            result[name] = {'state':'not initialized', 'reason':'Open the existing workspace; Developer does not auto-start it.'}
            continue
        try:
            value = provider.snapshot()
            # Whitelist top-level capabilities/health; never export arbitrary peer payloads or notes.
            allowed = {'connected','armed','mode','state','generation','avatar_generation','permission_revision','queue_size',
                       'invalid','dropped','cleanup_unverified','enabled','health','status','age','stale','available',
                       'advertised','capabilities','controls_enabled','requests_paused','owners','ownership','conflicts',
                       'pending','reason','serial','permissions','observations','events'}
            result[name] = redact({key:val for key,val in value.items() if key in allowed}, local=True)
        except (ValueError, RuntimeError, OSError):
            result[name] = {'state':'unavailable', 'reason':'This provider could not produce a snapshot.'}
    result['Pipeline'] = {'transport':'Receive-only observer on the existing Friend activity connection',
                          'state':'See Traffic for observed connection lifecycle and decoded envelopes',
                          'server_replay':'Unavailable; local sequence does not establish completeness.'}
    return result


def database_paths(app):
    """Only stores owned by VRC Eye; no arbitrary path or VRCX database inspection."""
    shell = getattr(app,'sidebar',None)
    player = getattr(app,'player_sessions',None)
    candidates = {'Companion':getattr(getattr(shell,'store',None),'path',None),
                  'Player history':getattr(getattr(getattr(player,'worker',None),'store',None),'path',None)}
    for label, attr in (('World creator','world_creator'),('Avatar creator','avatar_creator'),('Peer','peer_service')):
        owner = getattr(app,attr,None)
        candidates[label] = getattr(getattr(owner,'store',None),'path',None)
    world = getattr(getattr(app, 'world_view', None), 'creator', None)
    avatar = getattr(app, 'avatar_creator', None)
    for label, owner in (('World creator', world), ('Avatar creator', avatar)):
        controller = getattr(owner, 'controller', owner)
        path = getattr(getattr(controller, 'store', None), 'path', None)
        if path is not None: candidates[label] = path
    # Creator services also use controller-owned stores in earlier builds.
    for attr in ('creator_controller','avatar_creator_controller'):
        owner = getattr(app,attr,None)
        if owner is not None:
            candidates[attr.replace('_',' ').title()] = getattr(getattr(owner,'store',None),'path',None)
    return {label:Path(path).resolve() for label,path in candidates.items() if path is not None and str(path) != ':memory:'}


def _connection(path, stop=None):
    path = Path(path).resolve()
    if not path.is_file(): raise ValueError('This VRC Eye database has not been created yet.')
    if path.stat().st_size > 512*1024*1024: raise ValueError('Interactive database inspection is limited to 512 MiB.')
    db = sqlite3.connect(path.as_uri()+'?mode=ro', uri=True, timeout=2)
    db.execute('PRAGMA query_only=ON')
    deadline = time.monotonic()+8
    db.set_progress_handler(lambda:int(time.monotonic()>deadline or stop is not None and stop.is_set()),1000)
    return db


def inspect_database(path, stop=None):
    """Fixed read-only queries only; no arbitrary SQL, rows, notes or credential data."""
    with closing(_connection(path,stop)) as db:
        checks = [row[0] for row in db.execute('PRAGMA quick_check(10)').fetchmany(10)]
        version = db.execute('PRAGMA user_version').fetchone()[0]
        names = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 101").fetchall()
        rows=[]
        for (name,) in names[:100]:
            quoted='"'+name.replace('"','""')+'"'
            count=db.execute('SELECT COUNT(*) FROM '+quoted).fetchone()[0]
            columns=[{'field':v[1],'type':v[2],'not_null':bool(v[3]),'primary_key':bool(v[5])}
                     for v in db.execute('PRAGMA table_info('+quoted+')').fetchmany(200)]
            rows.append({'name':name,'count':count,'columns':columns})
        return {'source':'Explicit VRC Eye database, read-only connection', 'schema_version':version,
                'integrity':checks,'tables':rows,'partial':len(names)>100,'rows_exposed':0,'database_writes':0}


def backup_database(path, destination, stop=None):
    """Consistent SQLite backup into a NEW file. No repair or replacement of active data."""
    source, target = Path(path).resolve(), Path(destination).resolve()
    if source == target or target.suffix.lower() not in ('.sqlite','.sqlite3','.db'):
        raise ValueError('Choose a new .sqlite3 backup file, not the active database.')
    # Reserve exclusively so a race or pre-existing file cannot overwrite user data.
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    os.close(fd)
    try:
        with closing(_connection(source,stop)) as src, closing(sqlite3.connect(target)) as dst:
            deadline=time.monotonic()+15
            def progress(status,remaining,total):
                if time.monotonic()>deadline or stop is not None and stop.is_set():
                    raise ValueError('Database backup cancelled or exceeded its local time budget.')
            src.backup(dst,pages=128,progress=progress,sleep=.01)
            result=dst.execute('PRAGMA quick_check(10)').fetchmany(10)
            if result != [('ok',)]: raise ValueError('Backup integrity check did not return ok.')
        return {'source':'VRC Eye consistent database backup','integrity':'ok','active_database_replaced':False,
                'warning':'This backup contains original private application data. It is NOT a sanitized bug report.'}
    except BaseException:
        target.unlink(missing_ok=True)
        raise


def report_preview(service):
    """Generate one reviewed, pseudonymized bundle in memory; disk I/O is separate."""
    return {'format':'vrc-eye-developer-report-1', 'version':'1.21.0','created_at':stamp(),
            'catalog_revision':CATALOG_REVISION,'platform':platform.system(),'python':platform.python_version(),
            'summary':service.snapshot(),'capture':service.recorder.export(),
            'scope':{'included':['Bounded redacted event metadata','Per-bundle pseudonyms','Aggregate workbench counters'],
                     'excluded':['Credentials and session cookies','Private instance codes','Message bodies','Wellness data',
                                 'User notes','Raw logs','Raw databases','Raw API response files','Live account contact'],
                     'identifier_scope':'Fresh pseudonyms for this bundle only','manual_attachments':False},
            'validation':{'live_vrchat_tested':False,'note':'A catalog adapter is not a certificate of platform support or authorization.'}}


def export_report(destination, preview):
    if not isinstance(preview,dict) or preview.get('format') != 'vrc-eye-developer-report-1':
        raise ValueError('Preview the report before exporting it.')
    target=Path(destination)
    # Plain data only. No imported scripts, attachments or arbitrary paths enter the ZIP.
    data=json.dumps(preview,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')
    if len(data)>8*1024*1024: raise ValueError('The report exceeds its bounded export size.')
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('report.json',data)
        archive.writestr('README.txt','VRC Eye 1.21.0 developer report\nReview before sharing. Events are bounded and may be dropped or expired.\nIDs use fresh per-bundle pseudonyms; missing observations are not proof of absence.\n')
    return {'format':'ZIP','bytes':target.stat().st_size,'files':2}
