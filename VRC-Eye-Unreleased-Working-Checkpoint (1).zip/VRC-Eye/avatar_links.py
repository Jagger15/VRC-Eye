"""Validated VRChat avatar links and optional local name-match candidates."""

import json
import re
import webbrowser
from dataclasses import dataclass, replace
from pathlib import Path
from urllib.parse import urlsplit


AVATAR_ID = re.compile(r"avtr_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")


def parse_avatar_reference(value: str) -> str:
    """Accept a complete avatar ID or an official HTTPS avatar-page URL."""
    value = value.strip()
    if not value or any(ord(character) < 32 for character in value):
        raise ValueError("Paste a complete avatar ID or a VRChat avatar-page link.")
    if AVATAR_ID.fullmatch(value):
        return value.lower()
    try:
        url = urlsplit(value)
        if (url.scheme != "https" or url.hostname not in ("vrchat.com", "www.vrchat.com")
                or url.username is not None or url.password is not None or url.port is not None):
            raise ValueError
        match = re.fullmatch(r"/home/avatar/(" + AVATAR_ID.pattern + r")/?", url.path)
        if not match:
            raise ValueError
        return match.group(1).lower()
    except ValueError:
        raise ValueError("Use https://vrchat.com/home/avatar/avtr_… or the complete avtr_… ID.") from None


def avatar_url(reference: str) -> str:
    return "https://vrchat.com/home/avatar/" + parse_avatar_reference(reference)


def open_avatar_page(reference: str, opener=None) -> bool:
    """Open only a canonical VRChat page, never a URL copied verbatim from a log."""
    return bool((opener or webbrowser.open_new_tab)(avatar_url(reference)))


@dataclass(frozen=True)
class AvatarCandidate:
    avatar_id: str
    name: str
    author: str = ""
    source: str = "OSC cache"
    release_status: str = ""


def release_status_label(value: str) -> str:
    """Only explicit release states count; missing/deleted/other is unknown."""
    normalized = value.strip().casefold() if isinstance(value, str) else ""
    return {"public": "Public", "private": "Private"}.get(normalized, "Unknown")


def merge_candidates(*groups) -> list[AvatarCandidate]:
    """Collapse duplicate IDs across sources while keeping different IDs apart."""
    merged = {}
    for group in groups:
        for candidate in group:
            previous = merged.get(candidate.avatar_id)
            if previous:
                sources = list(dict.fromkeys(previous.source.split(" + ") + candidate.source.split(" + ")))
                merged[candidate.avatar_id] = replace(previous,
                    author=previous.author or candidate.author,
                    release_status=previous.release_status or candidate.release_status,
                    source=" + ".join(sources))
            else:
                merged[candidate.avatar_id] = candidate
    return sorted(merged.values(), key=lambda row: (row.name.casefold(), row.author.casefold(), row.avatar_id))


def find_local_candidates(log_location: Path, name: str) -> list[AvatarCandidate]:
    """Read OSC avatar configs. A matching name is a candidate, not an identity."""
    root = log_location.parent if log_location.is_file() else log_location
    matches = {}
    try:
        paths = (root / "OSC").glob("usr_*/Avatars/avtr_*.json")
        for path in paths:
            try:
                if path.stat().st_size > 2 * 1024 * 1024:
                    continue
                with path.open(encoding="utf-8-sig") as stream:
                    record = json.load(stream)
                if not isinstance(record, dict):
                    continue
                avatar_id = parse_avatar_reference(record.get("id", ""))
                avatar_name = record.get("name")
                if (not isinstance(avatar_name, str)
                        or avatar_name.strip().casefold() != name.strip().casefold()
                        or path.stem.lower() != avatar_id):
                    continue
                matches[avatar_id] = AvatarCandidate(avatar_id, avatar_name)
            except (OSError, ValueError, TypeError, AttributeError):
                continue
    except OSError:
        pass
    return sorted(matches.values(), key=lambda candidate: candidate.avatar_id)
