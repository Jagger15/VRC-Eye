"""Bounded embedded glTF base-color data. No URI reads or shader execution.

Reference: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
Image decoding runs only in the existing scene parser process. The parent
receives validated raw RGBA thumbnails, never compressed image payloads.
"""
from dataclasses import dataclass
import base64
from io import BytesIO
import math

MAX_TEXTURES=16
MAX_PIXELS=8*1024*1024
THUMB=256


@dataclass(frozen=True)
class Texture:
    name: str
    width: int
    height: int
    rgba: str
    wrap_s: int=10497
    wrap_t: int=10497
    source_width: int=0
    source_height: int=0
    mag_filter: int=9728
    min_filter: int=9728


@dataclass(frozen=True)
class Material:
    name: str='Default material'
    base_color: tuple=(1.,1.,1.,1.)
    texture: int=-1
    alpha: str='OPAQUE'
    cutoff: float=.5
    double_sided: bool=False
    notices: tuple=()
    uv_offset: tuple=(0.,0.)
    uv_scale: tuple=(1.,1.)
    uv_rotation: float=0.
    uv_set: int=0


def filters(mag,mini):
    if type(mag) is not int or mag not in (9728,9729) or type(mini) is not int or mini not in (9728,9729,9984,9985,9986,9987):
        raise ValueError('Unsupported texture filtering mode.')
    return mag,mini


def factor(value):
    if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=1:
        raise ValueError('Material factors must be finite values from zero to one.')
    return float(value)


def parse(doc,binary,views):
    from avatar_scene import array,integer,name,vector
    materials=array(doc,'materials',128);images=array(doc,'images',64)
    textures=array(doc,'textures',64);samplers=array(doc,'samplers',64)
    output=[];decoded=[];cache={};pixels=0
    def texture(index):
        nonlocal pixels
        integer(index,0,len(textures)-1)
        if index in cache:return cache[index]
        item=textures[index]
        if item.get('extensions'):return -1,'Texture extension not rendered.'
        source=images[integer(item.get('source'),0,len(images)-1)]
        if 'uri' in source:return -1,'External/data URI texture not read; base-color factor only.'
        if source.get('mimeType') not in ('image/png','image/jpeg') or source.get('extensions'):
            return -1,'Only embedded PNG/JPEG base-color textures are rendered.'
        view=views[integer(source.get('bufferView'),0,len(views)-1)]
        if type(view.get('buffer')) is not int or view['buffer']!=0 or view.get('extensions') or 'byteStride' in view:
            raise ValueError('Invalid embedded texture buffer view.')
        start=integer(view.get('byteOffset',0),0,len(binary));size=integer(view.get('byteLength'),1,8*1024*1024)
        if start+size>len(binary):raise ValueError('Texture exceeds the embedded buffer.')
        if len(decoded)>=MAX_TEXTURES:raise ValueError('Preview supports at most 16 decoded base-color textures.')
        sampler=samplers[integer(item['sampler'],0,len(samplers)-1)] if 'sampler' in item else {}
        wraps=tuple(sampler.get(k,10497) for k in ('wrapS','wrapT'))
        if any(type(v) is not int or v not in (10497,33071,33648) for v in wraps):raise ValueError('Unsupported texture wrap mode.')
        mag,mini=filters(sampler.get('magFilter',9728),sampler.get('minFilter',9728))
        try:
            from PIL import Image
            with Image.open(BytesIO(binary[start:start+size]),formats=('PNG','JPEG')) as image:
                if image.format!={'image/png':'PNG','image/jpeg':'JPEG'}[source['mimeType']]:raise ValueError('Texture MIME type differs from its bytes.')
                width,height=image.size;pixels+=width*height
                if width>4096 or height>4096 or width*height>4*1024*1024 or pixels>MAX_PIXELS:
                    raise ValueError('Texture exceeds the 4 megapixel image or 8 megapixel scene budget.')
                if getattr(image,'n_frames',1)!=1:raise ValueError('Animated image textures are unsupported.')
                image.load();image.thumbnail((THUMB,THUMB),Image.Resampling.BOX)
                rgba=image.convert('RGBA');encoded=base64.b64encode(rgba.tobytes()).decode('ascii')
                decoded.append(Texture(name(source.get('name'),f'Texture {index+1}'),rgba.width,rgba.height,encoded,*wraps,width,height,mag,mini))
        except ImportError:raise ValueError('Install the bundled Pillow dependency to preview embedded textures.') from None
        except (OSError,Image.DecompressionBombError):raise ValueError('Embedded texture image could not be decoded within the preview limits.') from None
        result=(len(decoded)-1,'Preview texture reduced to at most 256 px. Declared nearest/linear filters are used; unspecified filters use nearest. Mipmap modes use the matching non-mipmap fallback.')
        cache[index]=result;return result
    for index,item in enumerate(materials):
        pbr=item.get('pbrMetallicRoughness',{})
        if not isinstance(pbr,dict):raise ValueError('Invalid material PBR object.')
        color=tuple(factor(v) for v in vector(pbr.get('baseColorFactor',[1,1,1,1]),4))
        alpha=item.get('alphaMode','OPAQUE');cutoff=item.get('alphaCutoff',.5);double=item.get('doubleSided',False)
        if alpha not in ('OPAQUE','MASK','BLEND') or type(double) is not bool or type(cutoff) not in (int,float) or not math.isfinite(cutoff) or not 0<=cutoff<=1e9:
            raise ValueError('Invalid material alpha or sidedness.')
        notes=[];ref=-1;offset=(0.,0.);scale=(1.,1.);rotation=0.;coord=0;info=pbr.get('baseColorTexture')
        if info is not None:
            if not isinstance(info,dict):raise ValueError('Invalid base-color texture reference.')
            integer(info.get('texCoord',0),0,31)
            extensions=info.get('extensions',{})
            if not isinstance(extensions,dict):raise ValueError('Invalid texture extensions.')
            transform=extensions.get('KHR_texture_transform',{})
            if not isinstance(transform,dict):raise ValueError('Invalid texture transform.')
            offset=vector(transform.get('offset',[0,0]),2);scale=vector(transform.get('scale',[1,1]),2)
            rotation=vector([transform.get('rotation',0)],1)[0]
            coord=integer(transform.get('texCoord',info.get('texCoord',0)),0,31)
            if set(extensions)-{'KHR_texture_transform'}:
                if 'KHR_texture_transform' in doc.get('extensionsRequired',[]):raise ValueError('Required texture transform has an unsupported companion extension.')
                notes.append('Texture uses an unsupported extension; base-color factor only.')
            else:ref,note=texture(info.get('index'));notes.append(note)
        if item.get('extensions') or pbr.get('extensions'):notes.append('Optional material extensions are not rendered.')
        if any(k in item for k in ('normalTexture','occlusionTexture','emissiveTexture','emissiveFactor')) or 'metallicRoughnessTexture' in pbr:
            notes.append('Normal, occlusion, emission and metallic/roughness maps are not rendered.')
        output.append(Material(name(item.get('name'),f'Material {index+1}'),color,ref,alpha,float(cutoff),double,tuple(notes),offset,scale,rotation,coord))
    return tuple(output),tuple(decoded)


def decode(materials,textures):
    """Validate all child output before UI or renderer can use it."""
    from avatar_scene import integer,vector,name
    if not isinstance(materials,list) or len(materials)>128 or not isinstance(textures,list) or len(textures)>MAX_TEXTURES:
        raise ValueError('Scene appearance exceeds its result budget.')
    ts=[];ms=[]
    for item in textures:
        old={'name','width','height','rgba','wrap_s','wrap_t','source_width','source_height'}
        if not isinstance(item,dict) or set(item) not in (old,old|{'mag_filter','min_filter'}):raise ValueError('Invalid texture result.')
        w=integer(item['width'],1,THUMB);h=integer(item['height'],1,THUMB);raw=item['rgba']
        if not isinstance(raw,str) or len(raw)>THUMB*THUMB*6:raise ValueError('Texture result exceeds its byte budget.')
        try:rgba=base64.b64decode(raw,validate=True)
        except (ValueError,UnicodeError):raise ValueError('Invalid texture RGBA encoding.') from None
        if len(rgba)!=w*h*4 or any(type(item[k]) is not int or item[k] not in (10497,33071,33648) for k in ('wrap_s','wrap_t')):
            raise ValueError('Invalid raw texture size or wrapping.')
        sw=integer(item['source_width'],1,4096);sh=integer(item['source_height'],1,4096)
        if sw*sh>4*1024*1024 or w>sw or h>sh:raise ValueError('Invalid source texture dimensions.')
        mag,mini=filters(item.get('mag_filter',9728),item.get('min_filter',9728))
        ts.append(Texture(name(item['name'],'Texture'),w,h,raw,item['wrap_s'],item['wrap_t'],sw,sh,mag,mini))
    for item in materials:
        old={'name','base_color','texture','alpha','cutoff','double_sided','notices','uv_offset','uv_scale','uv_rotation'}
        if not isinstance(item,dict) or set(item) not in (old,old|{'uv_set'}):raise ValueError('Invalid material result.')
        color=tuple(factor(v) for v in vector(item['base_color'],4));ref=integer(item['texture'],-1,len(ts)-1)
        notes=item['notices'];cutoff=item['cutoff']
        if (item['alpha'] not in ('OPAQUE','MASK','BLEND') or type(item['double_sided']) is not bool
            or type(cutoff) not in (int,float) or not math.isfinite(cutoff) or not 0<=cutoff<=1e9
            or not isinstance(notes,list) or len(notes)>8 or any(not isinstance(n,str) or len(n)>300 for n in notes)):
            raise ValueError('Invalid material coverage or alpha result.')
        ms.append(Material(name(item['name'],'Material'),color,ref,item['alpha'],float(cutoff),item['double_sided'],tuple(notes),vector(item['uv_offset'],2),vector(item['uv_scale'],2),vector([item['uv_rotation']],1)[0],integer(item.get('uv_set',0),0,31)))
    if sum(t.source_width*t.source_height for t in ts)>MAX_PIXELS:raise ValueError('Source textures exceed the scene pixel budget.')
    return tuple(ms),tuple(ts)


def describe(scene,nodes=None):
    used=sorted({p.material for p in scene.parts if nodes is None or p.node in nodes})
    lines=['Base-color preview · unlit, orthographic; no Unity/PBR shader matching.']
    for ref in used:
        m=scene.materials[ref] if ref>=0 else Material()
        parts=[p for p in scene.parts if p.material==ref and (nodes is None or p.node in nodes)]
        lines+=['',m.name,f'Base color RGBA: {m.base_color} · {m.alpha} · cutoff {m.cutoff:g} · double sided {m.double_sided}',
            f'{len(parts)} primitives · UV{m.uv_set} present on {sum(bool(p.uvs) for p in parts)}',
            f'Vertex colors present on {sum(bool(p.colors) for p in parts)} · UV offset {m.uv_offset} · scale {m.uv_scale} · rotation {m.uv_rotation:g}']
        if m.texture>=0:
            t=scene.textures[m.texture];lines.append(f'{t.name}: {t.source_width} × {t.source_height} source; {t.width} × {t.height} preview pixels; wrap {t.wrap_s}/{t.wrap_t}; magnification/minification filters {t.mag_filter}/{t.min_filter}')
            lines.append(f'Decoded RGBA8 memory: {t.width*t.height*4:,} bytes retained; {t.source_width*t.source_height*4:,} bytes at source dimensions. Mip levels retained: 1. RGB samples use sRGB decoding; alpha stays linear.')
            lines.append('Transparent pixels are depth sorted within a bounded fragment budget and composited in linear light. This does not reproduce Unity/PBR lighting.')
            if any(not p.uvs for p in parts):lines.append(f'Missing UV{m.uv_set} on some primitives; those use base-color factors and vertex colors only.')
        lines.extend(m.notices)
    return '\n'.join(lines)


def transform_uv(material,uv):
    u=uv[0]*material.uv_scale[0];v=uv[1]*material.uv_scale[1]
    c=math.cos(material.uv_rotation);s=math.sin(material.uv_rotation)
    return (c*u-s*v+material.uv_offset[0],s*u+c*v+material.uv_offset[1])
