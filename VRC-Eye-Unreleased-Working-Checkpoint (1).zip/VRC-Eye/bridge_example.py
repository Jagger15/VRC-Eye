"""Run a diagnostic adapter without touching VRChat: python bridge_example.py."""
import getpass
import time

from bridge_sdk import BridgeClient
from bridge_protocol import BridgeError


def main():
    print("VRC Eye diagnostic bridge example. This does not connect to or control VRChat.")
    print("In VRC Eye: Advanced → Client bridge… → Enable bridge → Copy connection code.")
    client=BridgeClient(client_id="957e099c-dd3b-4186-8624-d6bd0445e783",name="VRC Eye diagnostic example",version="1.18.6",kind="diagnostic",
                        capabilities={"bridge.ping":{"version":1},"bridge.diagnostics":{"version":1}})
    try:
        code=getpass.getpass("Paste the connection code (hidden): ")
        client.connect(code);code=""
        print("Connected in quarantine. Approve the diagnostic capabilities in VRC Eye. Ctrl+C disconnects.")
        started=time.monotonic()
        while client.connected():
            client.publish("bridge.diagnostics",{"uptime_seconds":round(time.monotonic()-started,2)})
            time.sleep(.5)
        print(client.status)
    except (BridgeError,OSError):print("The example could not connect. Check the local connection and use a fresh connection code.")
    except KeyboardInterrupt:print("Diagnostic adapter stopped.")
    finally:client.close()


if __name__=="__main__":main()
