"""Decoded hierarchy and read-only scene controls inside the existing preview page."""
from pathlib import Path
from companion_ui import button
from friendly_ui import flow_line as line
import avatar_scene as scenes
import avatar_model_preview as model


class SceneControls:
    def __init__(self,panel):
        self.panel=panel;self.page=panel.page;page=self.page
        self.scene=None;self.hidden=set();self.focus=None;self.batches=();self.center=(0,0,0);self.radius=1
        self.renderer=None;self.image=None;self.material_focus=None;self.inspection=None
        self.display_scene=None;self.morph_overrides={};self.joint_overrides={};self.rig_inspection=None;self.pose_revision=0;self.deform_pending=False
        self.timeline=None
        self.bounds_inspection=None
        self.skin_optimization=None
        self.box=page.ttk.Frame(panel.body);self.box.pack(fill='both',expand=True,pady=8)
        page.ttk.Label(self.box,text='Scene hierarchy',style='Heading.TLabel').pack(anchor='w')
        page.ttk.Label(self.box,text='Select a node to highlight its subtree. Hidden meshes remain in memory until the preview is cleared. Frame selected shows only that subtree; Show all restores the full scene.',wraplength=1000).pack(anchor='w',pady=4)
        row=page.ttk.Frame(self.box);row.pack(fill='both',expand=True)
        self.tree=page.ttk.Treeview(row,columns=('state','vertices','triangles'),show='tree headings',height=7,selectmode='browse',takefocus=True)
        self.tree.heading('#0',text='Node');self.tree.column('#0',width=280,minwidth=120)
        for key,label in (('state','Visibility'),('vertices','Vertices'),('triangles','Triangles')):
            self.tree.heading(key,text=label);self.tree.column(key,width=110,minwidth=65)
        scroll=page.ttk.Scrollbar(row,orient='vertical',command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True)
        self.tree.bind('<<TreeviewSelect>>',lambda _:page.guard(self.select))
        row=line(page,self.box)
        button(page,row,'Hide selected subtree',self.hide_selected);button(page,row,'Show selected subtree',self.show_selected)
        button(page,row,'Frame selected subtree',self.frame_selected);button(page,row,'Show all / reset framing',self.show_all)
        button(page,row,'Materials, textures & mesh health…',self.inspect_materials)
        button(page,row,'Bones & blendshapes…',self.inspect_rig)
        button(page,row,'Animation timeline…',self.inspect_animation)
        button(page,row,'Bounds diagnostics…',self.inspect_bounds)
        button(page,row,'Skin influence trial…',self.inspect_skin)
        self.show_bounds=page.tk.BooleanVar(value=True)
        page.ttk.Checkbutton(row,text='Show bounds',variable=self.show_bounds,command=panel.schedule_render).pack(side='left')
        self.show_bones=page.tk.BooleanVar(value=False)
        page.ttk.Checkbutton(row,text='Show skeleton',variable=self.show_bones,command=panel.schedule_render).pack(side='left')
        self.detail=page.tk.StringVar(value='Load a supported scene to inspect its hierarchy.')
        page.ttk.Label(self.box,textvariable=self.detail,wraplength=1000,justify='left').pack(anchor='w',pady=5)

    def clear(self):
        if self.timeline:self.timeline.clear()
        if self.bounds_inspection:self.bounds_inspection.clear()
        if self.skin_optimization:self.skin_optimization.clear()
        if self.deform_pending and self.page.job:self.page.cancel()
        self.deform_pending=False;self.pose_revision+=1;self.display_scene=None;self.morph_overrides={};self.joint_overrides={}
        self.cancel();self.image=None
        self.scene=None;self.hidden=set();self.focus=None;self.batches=();self.material_focus=None
        if self.inspection:self.inspection.hide()
        if self.rig_inspection:self.rig_inspection.hide()
        self.tree.delete(*self.tree.get_children());self.detail.set('No scene retained.')

    def cancel(self):
        if self.renderer:self.renderer.cancel()

    def close(self):
        if self.renderer:self.renderer.close()
        if self.timeline:self.timeline.close()

    def inspect_animation(self):
        self.require()
        from avatar_animation_ui import AnimationTimeline
        if self.timeline is None:
            self.timeline=AnimationTimeline(self);self.panel.bind_focus(self.timeline.box)
        self.timeline.show()

    def inspect_bounds(self):
        self.require()
        from avatar_bounds_ui import BoundsInspection
        if self.bounds_inspection is None:
            self.bounds_inspection=BoundsInspection(self);self.panel.bind_focus(self.bounds_inspection.box)
        self.bounds_inspection.show()

    def inspect_skin(self):
        self.require()
        from avatar_skin_optimization_ui import SkinOptimization
        if self.skin_optimization is None:
            self.skin_optimization=SkinOptimization(self);self.panel.bind_focus(self.skin_optimization.box)
        self.skin_optimization.show()

    def inspect_materials(self):
        self.require()
        from avatar_scene_inspection_ui import Inspection
        if self.inspection is None:
            self.inspection=Inspection(self)
            self.panel.bind_focus(self.inspection.box)
        self.inspection.show()

    def attach(self,scene):
        self.clear();self.scene=scene;self.display_scene=scene
        for node in scene.nodes:
            parts=[p for p in scene.parts if p.node==node.index]
            self.tree.insert('' if node.parent<0 else 'n'+str(node.parent),'end',iid='n'+str(node.index),text=node.name,
                values=('Visible',sum(len(p.vertices) for p in parts),sum(len(p.triangles) for p in parts)),open=True)
        self.rebuild()

    def inspect_rig(self):
        self.require()
        from avatar_scene_rig_ui import RigInspection
        if self.rig_inspection is None:
            self.rig_inspection=RigInspection(self);self.panel.bind_focus(self.rig_inspection.box)
        self.rig_inspection.show()

    def set_morphs(self,overrides):
        self.set_pose(overrides,self.joint_overrides)

    def set_joints(self,overrides):
        self.set_pose(self.morph_overrides,overrides)

    def set_pose(self,overrides,joints):
        self.require()
        if self.page.job:raise ValueError('Wait for the current Avatar Library task to finish or stop.')
        if self.timeline:self.timeline.pause()
        from avatar_scene_deform import pose,morph_weights
        from avatar_scene_pose import offsets
        scene=self.scene;context=self.panel.context();overrides={k:tuple(v) for k,v in overrides.items()}
        counts={p.node:len(p.rig.morph_names) for p in scene.parts if p.rig and p.rig.morph_names}
        if any(type(n) is not int or n not in counts for n in overrides):raise ValueError('Select a morph-bearing node in this scene.')
        overrides={n:morph_weights(v,counts[n]) for n,v in overrides.items()}
        joints=offsets(scene,joints)
        self.pose_revision+=1;revision=self.pose_revision;self.deform_pending=True
        def done(result):
            self.deform_pending=False
            if self.panel.closed or scene is not self.scene or context!=self.panel.context() or revision!=self.pose_revision:return
            self.require();self.display_scene=result;self.morph_overrides=overrides;self.joint_overrides=joints;self.rebuild()
            if self.rig_inspection:self.rig_inspection.refresh_pose()
        try:self.page.start_task(lambda stop,progress:pose(scene,overrides,joints=joints,stop=stop),done,operation='Scene pose preview')
        except Exception:self.deform_pending=False;raise

    def require(self):
        if not self.panel.usable() or self.scene is not self.panel.mesh:raise ValueError('Load a scene in the current workspace first.')

    def selected(self):
        self.require();chosen=self.tree.selection()
        if not chosen:raise ValueError('Select a scene node first.')
        return next(n.index for n in self.scene.nodes if 'n'+str(n.index)==chosen[0])

    def selected_or_none(self):
        chosen=self.tree.selection()
        return next((n.index for n in self.scene.nodes if chosen and 'n'+str(n.index)==chosen[0]),None) if self.scene else None

    def select(self):
        if not self.scene:return
        self.require();self.update_detail();self.panel.schedule_render()

    def excluded(self):
        value=set()
        for node in self.hidden:value.update(scenes.descendants(self.scene,node))
        return value

    def rebuild(self):
        if not self.scene:return
        if self.timeline:self.timeline.pause()
        self.batches,self.center,self.radius=scenes.make_view(self.display_scene,self.hidden,self.focus)
        if self.material_focus is not None:self.batches=tuple((node,mesh) for node,mesh in self.batches if mesh.material==self.material_focus)
        excluded=self.excluded();framed=scenes.descendants(self.scene,self.focus) if self.focus is not None else None
        for node in self.scene.nodes:
            item='n'+str(node.index);values=list(self.tree.item(item)['values'])
            values[0]='Hidden' if node.index in excluded else 'Outside frame' if framed is not None and node.index not in framed else 'Visible'
            self.tree.item(item,values=values)
        self.update_detail();self.panel.update_info();self.panel.schedule_render()

    def update_detail(self):
        if not self.scene:return
        chosen=self.selected_or_none();nodes=scenes.descendants(self.scene,chosen) if chosen is not None else {n.index for n in self.scene.nodes}
        vertices=tuple(v for p in self.display_scene.parts if p.node in nodes for v in p.vertices)
        label=next((n.name for n in self.scene.nodes if n.index==chosen),'Whole scene')
        box=scenes.bounds(vertices) if vertices else None
        self.detail.set(label+'\n'+('World-space bounds (see source units below): '+repr(box) if box else 'This subtree contains no mesh geometry.')+
                        '\n'+str(sum(len(mesh.triangles) for _,mesh in self.batches))+' triangles currently displayed. '+
                        str(len({p.material for p in self.scene.parts if p.node in nodes}))+' material assignments; inspect materials for texture coverage.')

    def hide_selected(self):
        self.hidden.add(self.selected());self.focus=None;self.rebuild()

    def show_selected(self):
        chosen=self.selected();parents={n.index:n.parent for n in self.scene.nodes}
        current=chosen
        while current>=0:self.hidden.discard(current);current=parents[current]
        self.hidden.difference_update(scenes.descendants(self.scene,chosen));self.focus=None;self.rebuild()

    def frame_selected(self):
        chosen=self.selected()
        scenes.make_view(self.display_scene,self.hidden,chosen)
        self.focus=chosen;self.panel.camera=model.Camera();self.rebuild()

    def show_all(self):
        self.require();self.hidden.clear();self.focus=None;self.material_focus=None;self.panel.camera=model.Camera();self.rebuild()

    def info(self):
        from avatar_scene_sandbox import description
        from avatar_fbx_report import describe
        scene=self.scene;panel=self.panel
        if scene is None:return
        name=panel.source if panel.page.show_paths.get() else Path(panel.source).name
        panel.info.set(name+'\n'+f'{len(scene.nodes)} nodes · {len(scene.parts)} mesh primitives · '+
            f'{sum(len(p.vertices) for p in scene.parts):,} instanced vertices · {sum(len(p.triangles) for p in scene.parts):,} triangles\n'+
            f'{len(scene.skins)} skins · {len(self.joint_overrides)} joint poses · {len(self.morph_overrides)} nodes with preview weight overrides\n'+
            'Source SHA-256: '+scene.sha256+'\n'+' '.join(scene.notices)+'\n'+describe(scene.import_report)+'\n'+description()+'\nThis is the selected file snapshot; source files remain unchanged.')

    def render(self,token,width,height):
        panel=self.panel;scene=self.scene;context=panel.context()
        if panel.mode.get() in ('Base color','Textured'):
            self.render_appearance(token,width,height);return
        selected=self.selected_or_none();highlight=scenes.descendants(scene,selected) if selected is not None else set()
        faces=[]
        for node,mesh in self.batches:
            faces.extend((face,node) for face in model.project(mesh,panel.camera,width,height,coordinate_limit=10000))
        faces.sort(key=lambda item:item[0].depth)
        accent=panel.page.app.ACCENT;rgb=tuple(v//257 for v in panel.canvas.winfo_rgb(accent));wire=panel.mode.get()=='Wireframe'
        def batch(start=0):
            panel.render_after=None
            if panel.closed or token!=panel.draw_generation or scene is not panel.mesh or context!=panel.context():return
            for face,node in faces[start:start+200]:
                fill='' if wire else '#'+''.join(f'{round(v*face.shade):02x}' for v in rgb)
                panel.canvas.create_polygon(face.points,fill=fill,outline=panel.page.app.TEXT if node in highlight else accent if wire else panel.page.app.BG,
                    width=2 if node in highlight else 1,tags=('mesh','scene-node-'+str(node)))
            if start+200<len(faces):panel.render_after=panel.canvas.after(1,lambda:batch(start+200))
            else:
                if not faces:panel.canvas.create_text(width/2,height/2,text='No meshes in the current visibility/material filter · use Show all',fill=panel.page.app.TEXT)
                if self.show_bounds.get():
                    visible={node for node,_ in self.batches};nodes=(highlight & visible) if selected is not None else visible
                    for points in scenes.wire_bounds(self.display_scene,nodes,self.center,self.radius,panel.camera,width,height):
                        panel.canvas.create_line(points,fill=panel.page.app.TEXT,dash=(4,3),width=2,tags=('scene-bounds',))
                self.draw_bones(width,height)
        batch()

    def render_appearance(self,token,width,height):
        from avatar_scene_render import Renderer
        panel=self.panel;scene=self.scene;context=panel.context()
        if self.renderer is None:self.renderer=Renderer()
        dw=min(width,1280);dh=min(height,900)
        rgb=tuple(v//257 for v in panel.canvas.winfo_rgb(panel.page.app.PANEL))
        self.renderer.submit(token,(self.display_scene,self.batches,panel.camera,dw,dh),dict(textured=panel.mode.get()=='Textured',background=rgb))
        panel.canvas.create_text(width/2,height/2,text='Rendering base-color preview…',fill=panel.page.app.TEXT)
        def poll():
            panel.render_after=None
            if panel.closed or token!=panel.draw_generation or scene is not panel.mesh or context!=panel.context():return
            result=self.renderer.take(token)
            if result is None:panel.render_after=panel.canvas.after(25,poll);return
            pixels,error=result;panel.canvas.delete('all')
            if error:panel.canvas.create_text(width/2,height/2,text=error,fill=panel.page.app.TEXT,width=max(150,dw-30));return
            from PIL import Image,ImageTk
            w,h,raw=pixels
            image=Image.frombytes('RGB',(w,h),raw).resize((dw,dh),Image.Resampling.NEAREST)
            self.image=ImageTk.PhotoImage(image,master=panel.canvas)
            panel.canvas.create_image(width/2,height/2,image=self.image,anchor='center')
            selected=self.selected_or_none();visible={node for node,_ in self.batches}
            if self.show_bounds.get():
                nodes=visible & scenes.descendants(scene,selected) if selected is not None else visible
                for points in scenes.wire_bounds(self.display_scene,nodes,self.center,self.radius,panel.camera,dw,dh):
                    shifted=tuple(v+((width-dw)/2 if i%2==0 else (height-dh)/2) for i,v in enumerate(points))
                    panel.canvas.create_line(shifted,fill=panel.page.app.TEXT,dash=(4,3),width=2)
            self.draw_bones(dw,dh,(width-dw)/2,(height-dh)/2)
        poll()

    def draw_bones(self,width,height,dx=0,dy=0):
        if not self.show_bones.get():return
        from avatar_scene_deform import skeleton_lines
        panel=self.panel;visible={n for n,_ in self.batches};selected=self.selected_or_none()
        for node,points in skeleton_lines(self.display_scene,visible,self.center,self.radius,panel.camera,width,height):
            shifted=tuple(v+(dx if i%2==0 else dy) for i,v in enumerate(points))
            panel.canvas.create_line(shifted,fill=panel.page.app.TEXT if node==selected else panel.page.app.ACCENT,width=3,tags=('scene-skeleton',))
