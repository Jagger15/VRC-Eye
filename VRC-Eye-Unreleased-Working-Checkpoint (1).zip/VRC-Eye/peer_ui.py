"""Local-first VRC Eye peer workspace. Networking belongs to the application service."""

from text_viewport import window_body
from copy import deepcopy
from datetime import datetime
import time
import uuid

from companion_ui import Page, Table, button, choice, entry, line


TABS = ('Home & profile', 'Whispers & sharing', 'Planner',
        'Creator', 'Diagnostics & presets', 'Permissions', 'Developer', 'OSC Controls')
PROFILE_FIELDS = (('alias', 'Display alias'), ('bio', 'Bio'), ('pronouns', 'Pronouns'),
                  ('status_text', 'Status text'), ('favorite_color', 'Favorite color'),
                  ('icon', 'Profile icon'))
FAMILIES = ('profile', 'presence', 'whisper', 'bookmark', 'coordination', 'safety',
            'diagnostics', 'troubleshooting', 'config', 'creator', 'performance',
            'confirmation', 'notice', 'novelty', 'encounter')
VISIBILITY = {'Private': 'private', 'Approved peers': 'approved', 'This session': 'session'}
SHARE_KINDS = {'bookmark': 'bookmark.card', 'party': 'party.snapshot', 'photo': 'photo.plan',
               'cue': 'media.cue', 'checklist': 'checklist.snapshot', 'playtest': 'creator.snapshot',
               'diagnostic': 'diagnostics.card', 'performance': 'performance.card',
               'preset': 'config.package', 'session_card': 'session.card', 'ready_template': 'ready.request'}


def readable(value, depth=0, limit=16000):
    """Small, bounded human-readable preview; never executable or rich remote markup."""
    if depth > 10:
        return '…'
    if isinstance(value, dict):
        return '\n'.join(str(key).replace('_', ' ').capitalize() + ': ' + readable(item, depth + 1, limit)
                         for key, item in list(value.items())[:100])[:limit]
    if isinstance(value, (tuple, list)):
        return '\n'.join('• ' + readable(item, depth + 1, limit) for item in value[:100])[:limit] or 'None'
    if value is None:
        return 'Unavailable'
    if isinstance(value, bool):
        return 'Yes' if value else 'No'
    return str(value)[:limit]


def record_key(record):
    return record.get('id') or record.get('message_id') or record.get('peer_id')


def set_table(table, records, values):
    selected = table.selected()
    identity = record_key(selected) if selected else None
    table.set(records, values)
    if identity:
        for key, record in table.records.items():
            if record_key(record) == identity:
                table.tree.selection_set(key)
                break


class VrcEyePrimaryPage(Page):
    """A useful private workspace with explicitly reviewed peer sharing."""
    def __init__(self, shell, parent):
        super().__init__(shell, parent, 'Eye-to-Eye', task_controls=False)
        self.service = getattr(self.app, 'peer_service', None)
        if self.service is None:
            raise ValueError('VRC Eye Peer Services is unavailable.')
        self.last_draw = -float('inf')
        self.selected_peer_id = ''
        self.peer_labels = {}
        self.checkpoint = None
        self.baseline = None
        self.editing = {}
        self.pending_preview = None
        self.library_signature = None
        self.library_cache = []
        saved_view = self.shell.store.option('peer.view', 'Casual')
        self.view = self.tk.StringVar(value=saved_view if saved_view in ('Casual', 'Advanced', 'Developer') else 'Casual')
        self.summary = self.tk.StringVar()
        self.label(parent, self.summary)
        row = line(self)
        button(self, row, 'Networking', lambda: self.shell.show('Networking'))
        button(self, row, 'Revoke all sharing', self.revoke_sharing)
        choice(self, row, self.view, ('Casual', 'Advanced', 'Developer'), self.change_view, 12)
        row = line(self)
        self.ttk.Label(row, text='Peer for optional sharing').pack(side='left', padx=(0, 8))
        self.peer_choice = self.tk.StringVar(value='No peer selected')
        self.peer_picker = choice(self, row, self.peer_choice, ('No peer selected',), self.choose_peer, 48)
        self.peer_hint = self.tk.StringVar(value='Save local work anytime. Select a peer only when you want to share.')
        self.label(parent, self.peer_hint)
        self.peer_details = self.tk.StringVar()
        self.label(parent, self.peer_details)
        self.tabs = self.ttk.Notebook(parent)
        self.tabs.pack(fill='both', expand=True)
        self.frames, self.panes = {}, {}
        from resource_ui import ResourcePage
        for name in TABS:
            frame = self.ttk.Frame(self.tabs)
            self.tabs.add(frame, text=name)
            self.frames[name] = frame
            self.panes[name] = frame if name == 'OSC Controls' else ResourcePage.scrolling_pane(self, frame)
        for build in (self.build_home, self.build_sharing, self.build_planner,
                      self.build_creator, self.build_diagnostics, self.build_permissions, self.build_developer):
            build()
        from osc_ui import OSCControlsPage
        self.osc_controls = OSCControlsPage(self.frames["OSC Controls"], self.app, navigate=self.shell.show)
        self.tabs.bind("<<NotebookTabChanged>>", self.osc_tab_selected)
        self.visibility()
        self.render()
        self.status.set('Private tools are available without a peer connection. Nothing is published automatically.')

    def osc_tab_selected(self, _event=None):
        selected = self.tabs.select()
        frame = self.frames['OSC Controls']
        if selected is frame or str(selected) == str(frame):
            self.osc_controls.show(self.osc_controls.active_tab)

    def label(self, parent, variable):
        self.ttk.Label(parent, textvariable=variable, wraplength=920, justify='left').pack(anchor='w', pady=5)

    def note(self, parent, text):
        self.ttk.Label(parent, text=text, wraplength=920, justify='left', style='Muted.TLabel').pack(anchor='w', pady=5)

    def heading(self, parent, text):
        self.ttk.Label(parent, text=text, style='Title.TLabel').pack(anchor='w', pady=(12, 5))

    def field(self, parent, title, value='', options=None, width=52):
        row = line(self, parent)
        self.ttk.Label(row, text=title, width=22).pack(side='left')
        variable = self.tk.StringVar(value=value)
        if options:
            choice(self, row, variable, options, width=width)
        else:
            entry(self, row, variable, width)
        return variable

    def active(self):
        if self.closed:
            raise ValueError('This page is closed.')
        if self.app.demo or getattr(self.app, 'safe_mode', False):
            raise ValueError('Leave Demo or Safe Mode before changing real VRC Eye data or connecting.')

    def guard(self, action):
        try:
            return super().guard(action)
        except RuntimeError as error:
            self.status.set(str(error))

    def confirm(self, title, text):
        """Long disclosures need a scrollable review, not an oversized message box."""
        if len(text) < 1500:
            return super().confirm(title, text)
        window = self.tk.Toplevel(self.app.root)
        window.title(title)
        window.geometry('820x620')
        window.transient(self.app.root)
        result = {'allow': False}
        frame = self.ttk.Frame(window_body(window))
        frame.pack(fill='both', expand=True, padx=12, pady=12)
        content = self.tk.Text(frame, wrap='word', width=85, height=28)
        scrollbar = self.ttk.Scrollbar(frame, orient='vertical', command=content.yview)
        content.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        content.pack(fill='both', expand=True)
        content.insert('1.0', text)
        content.configure(state='disabled')
        controls = self.ttk.Frame(window_body(window))
        controls.pack(fill='x', padx=12, pady=(0, 12))
        def finish(allow):
            result['allow'] = allow
            window.destroy()
        self.ttk.Button(controls, text='Cancel', command=lambda: finish(False)).pack(side='right')
        self.ttk.Button(controls, text='Approve reviewed action', command=lambda: finish(True)).pack(side='right', padx=8)
        window.protocol('WM_DELETE_WINDOW', lambda: finish(False))
        window.grab_set()
        self.app.root.wait_window(window)
        return result['allow']

    def visibility(self):
        view = self.view.get()
        for name in ('Creator', 'Diagnostics & presets'):
            self.tabs.tab(self.frames[name], state='hidden' if view == 'Casual' else 'normal')
        self.tabs.tab(self.frames['Developer'], state='normal' if view == 'Developer' else 'hidden')

    def change_view(self):
        self.visibility()
        self.tabs.select(self.frames['Home & profile'])
        if not self.app.demo and not getattr(self.app, 'safe_mode', False):
            self.shell.store.set_option('peer.view', self.view.get())

    def build_home(self):
        pane = self.panes['Home & profile']
        self.note(pane, 'Private Mode keeps VRC Eye peer networking off. Your bio, notes, plans, checklists and '
                  'reports remain usable locally. VRChat account access is a separate feature. Connecting does '
                  'not publish your profile or send saved drafts.')
        self.heading(pane, 'Your local profile')
        profile = self.service.snapshot().get('profile', {})
        values, visibility = profile.get('fields', {}), profile.get('visibility', {})
        self.profile_vars, self.profile_visibility = {}, {}
        for key, title in PROFILE_FIELDS:
            row = line(self, pane)
            self.ttk.Label(row, text=title, width=17).pack(side='left')
            value = self.tk.StringVar(value=values.get(key, ''))
            visible = self.tk.StringVar(value=next((label for label, token in VISIBILITY.items()
                                                   if token == visibility.get(key)), 'Private'))
            self.profile_vars[key], self.profile_visibility[key] = value, visible
            entry(self, row, value, 47)
            choice(self, row, visible, tuple(VISIBILITY), width=17)
        self.creator_profile = self.tk.BooleanVar(value=bool(values.get('creator_mode', False)))
        self.streamer_profile = self.tk.BooleanVar(value=bool(values.get('streamer_status', False)))
        for key, title, variable in (('creator_mode', 'Creator', self.creator_profile), ('streamer_status', 'Streamer', self.streamer_profile)):
            row = line(self, pane)
            self.ttk.Checkbutton(row, text=title, variable=variable).pack(side='left')
            visible = self.tk.StringVar(value=next((label for label, token in VISIBILITY.items() if token == visibility.get(key)), 'Private'))
            self.profile_visibility[key] = visible
            choice(self, row, visible, tuple(VISIBILITY), width=17)
        self.note(pane, 'Every field starts private. Visibility allows a field '
                  'to be included only when you explicitly choose Share profile. Device identity is not a '
                  'verified VRChat account identity.')
        row = line(self, pane)
        button(self, row, 'Save profile locally', self.save_profile)
        button(self, row, 'Review & share profile…', self.share_profile)
        self.availability = self.field(pane, 'Your availability', self.service.snapshot().get('availability', 'AVAILABLE'),
                                       ('AVAILABLE', 'DND', 'AFK', 'BUSY', 'BREAK'))
        row = line(self, pane)
        button(self, row, 'Set local availability', self.save_availability)
        button(self, row, 'Share availability…', self.share_availability)
        self.heading(pane, 'Local session and reminders')
        row = line(self, pane)
        button(self, row, 'Capture local session card', self.capture_session)
        button(self, row, 'Open local planner', lambda: self.tabs.select(self.frames['Planner']))
        self.timer_summary = self.tk.StringVar()
        self.label(pane, self.timer_summary)
        self.notifications = self.tk.StringVar()
        self.label(pane, self.notifications)

    def save_profile(self):
        self.active()
        fields = {key: variable.get().strip() for key, variable in self.profile_vars.items()}
        fields.update(creator_mode=bool(self.creator_profile.get()), streamer_status=bool(self.streamer_profile.get()))
        visibility = {key: VISIBILITY[value.get()] for key, value in self.profile_visibility.items()}
        self.service.set_profile(fields, visibility=visibility)
        self.status.set('Profile saved locally. No peer received an update.')

    def share_profile(self):
        self.active()
        peer = self.peer('profile.update')
        profile = self.service.snapshot()['profile']
        disclosed = {key: value for key, value in profile.get('fields', {}).items()
                     if profile.get('visibility', {}).get(key) in ('approved', 'session')}
        if not disclosed:
            raise ValueError('All saved profile fields are private. Choose field visibility and save first.')
        if self.confirm('Share saved profile', self.send_preview(peer, 'profile.update', disclosed)):
            if self.service.snapshot()['profile'] != profile:
                raise ValueError('Your saved profile changed during review. Preview it again before sharing.')
            self.service.share_profile(peer)
            self.status.set('Profile submitted. Check delivery and the recipient’s consent status.')

    def save_availability(self):
        self.active()
        self.service.set_availability(self.availability.get())
        self.status.set('Availability set locally. Use Share availability to send an update.')
        self.render()

    def share_availability(self):
        self.send_reviewed('presence.update', {'availability': self.service.snapshot()['availability']})

    def capture_session(self):
        self.active()
        from peer_tools import session_card
        value = session_card(app=self.app)
        item = self.service.save_item('session_card', value)
        self.status.set('Local session card saved. Select it under Whispers & sharing to preview or share.')
        self.render()
        return item

    def revoke_sharing(self):
        self.service.revoke_sharing()
        self.status.set('Sharing permissions revoked. Review new requests individually.')
        self.render()

    def choose_peer(self):
        self.selected_peer_id = self.peer_labels.get(self.peer_choice.get(), '')
        self.inspect_peer()

    def focus_peer(self, peer_id, action=None):
        self.selected_peer_id = peer_id
        self.render()
        name = {'whisper': 'Whispers & sharing', 'sharing': 'Whispers & sharing',
                'photo': 'Planner', 'ready': 'Planner', 'permissions': 'Permissions',
                'diagnostics': 'Diagnostics & presets'}.get(action, 'Whispers & sharing')
        if name == 'Diagnostics & presets' and self.view.get() == 'Casual':
            self.view.set('Advanced')
            self.visibility()
        self.tabs.select(self.frames[name])
        self.inspect_peer()

    def peer(self, kind=None):
        peer_id = self.selected_peer_id
        if not peer_id:
            raise ValueError('Select a peer above. Local saving does not require a connection.')
        if kind:
            decision = self.service.capability_decision(peer_id, kind)
            allowed = decision.get('allowed', decision.get('allow', decision.get('available', False)))
            if not allowed:
                from peer_protocol import FEATURES
                known = next((p for p in self.service.snapshot().get('peers', []) if p['peer_id'] == peer_id), None)
                queueable = FEATURES.get(kind, {}).get('queueable') and known and decision.get('reason') == 'OFFLINE'
                if not queueable:
                    reasons = {'OFFLINE': 'This action needs a connected peer. Your local tools remain available.',
                               'UNSUPPORTED_REMOTE': 'The selected peer does not support this feature.',
                               'LOCAL_PERMISSION_DENIED': 'Your sharing rule denies this feature for the selected peer.'}
                    raise ValueError(reasons.get(decision.get('reason'), decision.get('reason', 'This peer action is currently unavailable.')))
        return peer_id

    def inspect_peer(self):
        value = next((p for p in self.service.snapshot().get('peers', [])
                      if p.get('peer_id') == self.selected_peer_id), None)
        if not value:
            self.peer_details.set('Connection setup and detailed peer status are available in Networking.')
            return
        latency = 'Unavailable' if value.get('latency_ms') is None else f"{value['latency_ms']:.1f} ms"
        self.peer_details.set(f"VRC Eye {value.get('version', 'unknown')} · {len(value.get('capabilities', []))} capabilities · Service latency: {latency} · Device {value['peer_id'][:18]}\nDevice identity does not verify a VRChat account. Open Networking for connection controls.")

    def send_preview(self, peer_id, kind, payload):
        preview = readable(payload, limit=100000)
        return ('To device: ' + peer_id + '\nFeature: ' + kind + '\n\n' + preview
                + '\n\nOffline queueable items remain on this device until you explicitly resend. The recipient may need to accept this item. Their copy cannot be withdrawn after delivery.')

    def send_reviewed(self, kind, payload, *, context=''):
        self.active()
        peer_id = self.peer(kind)
        from peer_protocol import validate_payload
        clean = validate_payload(kind, payload)
        if not self.confirm('Review peer share', self.send_preview(peer_id, kind, clean)):
            return None
        result = self.service.send(peer_id, kind, clean, context=context)
        self.status.set('Submitted. Delivery and consent results appear in the message list.')
        self.render()
        return result

    def build_sharing(self):
        pane = self.panes['Whispers & sharing']
        self.note(pane, 'Private notes and drafts stay on this device. Sending is a separate reviewed action. '
                  'Received cards are peer claims; saving a bookmark does not change VRChat favorites.')
        self.whisper_title = self.field(pane, 'Draft / note title', 'Private note')
        self.whisper_text = self.field(pane, 'Whisper or private note', '', width=78)
        row = line(self, pane)
        button(self, row, 'Save private note / draft', self.save_note)
        button(self, row, 'Send Whisper…', self.send_whisper)
        button(self, row, 'Review queued messages…', self.flush_queue)
        self.heading(pane, 'Bookmarks and recommendations')
        self.bookmark_type = self.field(pane, 'Reference type', 'world', ('world', 'avatar'))
        self.bookmark_id = self.field(pane, 'VRChat reference ID', '')
        self.bookmark_label = self.field(pane, 'Label', '')
        self.bookmark_note = self.field(pane, 'Your note', '')
        row = line(self, pane)
        button(self, row, 'Save local bookmark', self.save_bookmark)
        button(self, row, 'Send recommendation…', self.recommend)
        self.heading(pane, 'Local library')
        self.library_filter = self.field(pane, 'Show items', 'All', ('All', 'note', 'bookmark', 'session_card',
                        'party', 'photo', 'cue', 'ready_template', 'checklist', 'playtest', 'diagnostic', 'performance', 'preset'), 22)
        button(self, line(self, pane), 'Apply filter', self.render)
        self.library = Table(self, pane, (('kind', 'Kind', 110), ('title', 'Title / reference', 260),
                             ('source', 'Source', 110), ('revision', 'Revision', 75)), height=8, select=self.preview_library)
        row = line(self, pane)
        button(self, row, 'Preview saved item', self.preview_library)
        button(self, row, 'Share saved item…', self.share_library)
        button(self, row, 'Export saved item…', self.export_library)
        button(self, row, 'Import item file…', self.import_item)
        button(self, row, 'Delete saved item…', self.delete_library)
        self.library_preview = self.tk.StringVar(value='Select a local item to preview its contents and provenance.')
        self.label(pane, self.library_preview)
        self.heading(pane, 'Messages and requests')
        self.messages = Table(self, pane, (('direction', 'Direction', 85), ('kind', 'Feature', 170),
                              ('peer', 'Peer', 150), ('status', 'Delivery / consent', 130)), height=8, select=self.preview_message)
        self.message_preview = self.tk.StringVar(value='Select a message to preview. Accepting a request is separate from saving a received item.')
        self.label(pane, self.message_preview)
        row = line(self, pane)
        button(self, row, 'Save received card locally', self.save_received)
        button(self, row, 'Ready', lambda: self.respond_request('READY'))
        button(self, row, 'Not ready', lambda: self.respond_request('NOT_READY'))
        button(self, row, 'Decline ready check', lambda: self.respond_request('DECLINED'))
        row = line(self, pane)
        for label, value in (('Doing okay', 'OK'), ('Need a minute', 'NEED_MINUTE'), ('Leaving', 'LEAVING'), ('Dismiss check-in', 'DISMISSED')):
            button(self, row, label, lambda answer=value: self.respond_request(answer))
        row = line(self, pane)
        button(self, row, 'Allow troubleshooting request…', lambda: self.respond_troubleshooting(True))
        button(self, row, 'Decline troubleshooting', lambda: self.respond_troubleshooting(False))
        self.note(pane, 'Troubleshooting responses communicate consent only. Diagnostic information still '
                  'requires a separate preview and share. Peers cannot control your computer.')

    @staticmethod
    def item_title(record):
        data = record.get('data', {})
        return data.get('title') or data.get('label') or data.get('text', '')[:70] or data.get('target_id') or record.get('kind', 'Item')

    def save_note(self):
        self.active()
        item = self.service.local_action('add_note', title=self.whisper_title.get().strip(), text=self.whisper_text.get())
        self.status.set('Private note saved. It has not been sent.')
        self.render()
        return item

    def send_whisper(self):
        return self.send_reviewed('whisper.message', {'text': self.whisper_text.get()})

    def flush_queue(self):
        self.active()
        peer = self.peer()
        queued = [row for row in self.service.snapshot().get('outbox', []) if row['peer_id'] == peer]
        if not queued:
            raise ValueError('No locally queued messages for this peer.')
        if self.confirm('Send locally queued messages', readable([{'feature': row['kind'], 'contents': row['payload']} for row in queued], limit=1000000) + '\n\nSend these messages over the current connection? Expired items are discarded.'):
            result = self.service.flush_queued(peer)
            self.status.set('Queued messages submitted. Check each delivery state.')
            self.render()
            return result

    def bookmark_payload(self):
        return {'target_type': self.bookmark_type.get(), 'target_id': self.bookmark_id.get().strip(),
                'label': self.bookmark_label.get().strip(), 'note': self.bookmark_note.get()}

    def save_bookmark(self):
        self.active()
        item = self.service.save_item('bookmark', self.bookmark_payload())
        self.status.set('Bookmark saved locally. VRChat favorites are unchanged.')
        self.render()
        return item

    def recommend(self):
        kind = self.bookmark_type.get()
        if kind not in ('world', 'avatar'):
            raise ValueError('Choose world or avatar for a recommendation. User references can be shared as bookmarks.')
        return self.send_reviewed('recommend.' + kind, {kind + '_id': self.bookmark_id.get().strip(),
                                  'note': self.bookmark_note.get(), 'label': self.bookmark_label.get().strip()})

    def selected_item(self, table=None):
        item = (table or self.library).selected()
        if not item:
            raise ValueError('Select a saved local item first.')
        return item

    def preview_library(self):
        item = self.selected_item()
        self.library_preview.set(readable({'kind': item['kind'], 'source': item.get('source'),
                                          'revision': item.get('revision'), 'contents': item['data']}))
        if item['kind'] == 'note':
            self.whisper_title.set(item['data'].get('title', 'Private note'))
            self.whisper_text.set(item['data'].get('text', ''))

    def share_item(self, item):
        self.active()
        kind = SHARE_KINDS.get(item['kind'])
        if not kind:
            raise ValueError('This item is private-only. Copy a draft into the Whisper field to send it explicitly.')
        peer = self.peer(kind)
        if self.confirm('Share saved item', self.send_preview(peer, kind, item['data'])):
            current = next((row for row in self.service.items() if row['id'] == item['id']), None)
            if current is None or current['revision'] != item['revision'] or current['data'] != item['data']:
                raise ValueError('The saved item changed during review. Preview it again before sharing.')
            result = self.service.share_item(peer, item['id'])
            self.status.set('Saved item submitted. Your private original remains in the local library.')
            self.render()
            return result

    def share_library(self):
        return self.share_item(self.selected_item())

    def export_item(self, item):
        self.active()
        from tkinter import filedialog
        if not self.confirm('Review local export', readable(item['data'], limit=100000) + '\n\nThis file may contain your private notes or references. Save this exact item?'):
            return
        path = filedialog.asksaveasfilename(parent=self.app.root, title='Export VRC Eye item',
                    defaultextension='.json', filetypes=(('VRC Eye item', '*.json'),))
        if path:
            self.active()
            self.service.export_item(item['id'], path)
            self.status.set('Reviewed item exported.')

    def export_library(self):
        self.export_item(self.selected_item())

    def import_item(self):
        self.active()
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.app.root, title='Import VRC Eye item',
                                         filetypes=(('VRC Eye item', '*.json'),))
        if path:
            self.active()
            value = self.service.import_item(path)
            self.status.set('Imported into your local library. It was not sent and no preset was applied.')
            self.render()
            return value

    def delete_library(self):
        self.active()
        item = self.selected_item()
        if self.confirm('Delete local item', 'Delete "' + self.item_title(item) + '" from this device? Export it first if you need a backup.'):
            self.service.delete_item(item['id'])
            self.library_preview.set('Local item deleted.')
            self.render()

    def selected_message(self):
        value = self.messages.selected()
        if not value:
            raise ValueError('Select a received message first.')
        return value

    def preview_message(self):
        value = self.selected_message()
        self.message_preview.set(readable({key: value.get(key) for key in ('kind', 'peer_id', 'direction', 'status', 'context', 'payload')}))

    def save_received(self):
        self.active()
        value = self.selected_message()
        result = self.service.save_received(value['message_id'])
        self.status.set('Received card saved as a separate local item with peer provenance.')
        self.render()
        return result

    def respond_request(self, value):
        self.active()
        message = self.selected_message()
        result = self.service.respond_request(message['message_id'], value)
        self.status.set('Response submitted.')
        self.render()
        return result

    def respond_troubleshooting(self, allow):
        self.active()
        message = self.selected_message()
        if message['kind'] != 'troubleshooting.request':
            raise ValueError('Select a troubleshooting request first.')
        if allow and not self.confirm('Troubleshooting consent', readable(message['payload']) + '\n\nAllow this request? This does not grant remote control or automatically disclose diagnostics.'):
            return
        return self.respond_request(bool(allow))

    def build_planner(self):
        pane = self.panes['Planner']
        self.note(pane, 'Keep a private party plan, photo shot list, ready-check template or media cue. '
                  'Sharing copies a selected plan to the chosen peer. Media cues are coordination markers; '
                  'they do not play audio or control VRChat.')
        self.build_editor(pane, 'planner', ('party', 'photo', 'cue', 'ready_template'))
        self.heading(pane, 'Countdowns and personal reminders')
        self.countdown_title = self.field(pane, 'Timer title', 'Photo countdown')
        self.countdown_seconds = self.field(pane, 'Seconds', '5', width=12)
        self.context_name = self.field(pane, 'Shared context (optional)', '')
        self.note(pane, 'Leave context blank to use the current peer session. A shared party or playtest '
                  'uses its saved item ID. Local timers use a monotonic clock; peer synchronization shows '
                  'its measured uncertainty.')
        row = line(self, pane)
        button(self, row, 'Start local countdown', self.local_countdown)
        button(self, row, 'Share countdown…', self.share_countdown)
        button(self, row, 'Send ready check…', self.send_ready)
        self.timers = Table(self, pane, (('title', 'Timer', 230), ('time', 'Remaining seconds', 130),
                            ('state', 'State', 100), ('source', 'Source / precision', 250)), height=4)
        button(self, line(self, pane), 'Cancel selected local timer', self.cancel_timer)
        self.build_group_controls(pane)
        self.heading(pane, 'Session role and shared notices')
        self.role = self.field(pane, 'VRC Eye session role', 'Photographer',
                              ('Host', 'Co-Host', 'Photographer', 'DJ', 'Tester', 'Observer', 'Coordinator', 'None'), 20)
        button(self, line(self, pane), 'Assign role to selected peer…', self.assign_role)
        self.notice_title = self.field(pane, 'Notice title', 'Ready when you are')
        self.notice_body = self.field(pane, 'Notice body', '')
        self.notice_category = self.field(pane, 'Notice category', 'general', ('general', 'ready', 'photo', 'creator', 'safety'), 15)
        row = line(self, pane)
        button(self, row, 'Show local notice', self.local_notice)
        button(self, row, 'Share notice…', self.share_notice)
        self.novelty_style = self.field(pane, 'Celebration style', 'gentle', ('gentle', 'celebrate', 'stars'), 15)
        row = line(self, pane)
        button(self, row, 'Local celebration', self.local_novelty)
        button(self, row, 'Share celebration…', self.share_novelty)
        self.note(pane, 'The recipient controls notice and novelty presentation. DND, Safety, Streamer Mode '
                  'and reduced-motion preferences can suppress or simplify effects. Session roles are '
                  'VRC Eye coordination labels and grant no VRChat authority.')
        self.heading(pane, 'Safety check-ins')
        self.checkin_prompt = self.field(pane, 'Check-in message', 'Doing okay?')
        row = line(self, pane)
        button(self, row, 'Send check-in…', self.send_checkin)
        button(self, row, 'Share Safety Mode state…', self.share_safety)
        self.note(pane, 'Check-ins are simple communication. Safety alerts contain only the selected state '
                  'and trigger; they do not disclose a world, instance or location.')

    def build_group_controls(self, pane):
        self.heading(pane, 'Shared group workspace')
        self.note(pane, 'Select multiple connected peers with Ctrl or Shift. Each recipient decides whether to accept a group share. Ready checks keep separate answers and show No response until someone replies.')
        self.group_members = Table(self, pane, (('peer', 'Connected peer', 240), ('device', 'Device ID', 320)), height=4)
        self.group_members.tree.configure(selectmode='extended')
        row = line(self, pane)
        button(self, row, 'Share selected planner item with group…', self.share_plan_group)
        button(self, row, 'Send group ready check…', self.ready_group)
        self.group_result = self.tk.StringVar()
        self.label(pane, self.group_result)
        self.shared_contexts = Table(self, pane, (('title', 'Shared session', 230), ('state', 'State', 100), ('revision', 'Revision', 75), ('id', 'Context ID', 280)), height=4, select=self.preview_context)
        button(self, line(self, pane), 'Use selected shared context', self.use_context)
        self.context_preview = self.tk.StringVar()
        self.label(pane, self.context_preview)
        self.request_states = Table(self, pane, (('kind', 'Request', 170), ('peer', 'Peer', 180), ('response', 'Response', 140), ('active', 'Active', 65)), height=5)

    def group_peer_ids(self):
        peers = [self.group_members.records[key]['peer_id'] for key in self.group_members.tree.selection() if key in self.group_members.records]
        if not peers:
            raise ValueError('Select at least one connected peer in the group list.')
        return peers

    def share_plan_group(self, name='planner'):
        self.active()
        item = self.selected_item(self.editing[name]['table'])
        peers = self.group_peer_ids()
        if not self.confirm('Share plan with group', readable({'recipients': peers, 'plan': item['data']}, limit=100000) + '\n\nEach recipient decides whether to accept this share.'):
            return
        current = next((row for row in self.service.items() if row['id'] == item['id']), None)
        if current is None or current['revision'] != item['revision']:
            raise ValueError('The plan changed during review. Preview it again.')
        result = self.service.share_group(item['id'], peers)
        self.group_result.set(readable({'submitted': len(result['sent']), 'unavailable': result['failed']}))
        if item['kind'] in ('party', 'playtest', 'checklist'):
            self.context_name.set(item['id'])
        self.render()
        return result

    def ready_group(self):
        self.active()
        peers = self.group_peer_ids()
        fields = self.editing['planner']['values']['ready_template']
        prompt, seconds = fields['prompt'].get(), int(fields['seconds'].get())
        context = self.context_name.get().strip()
        if not context:
            raise ValueError('Share a party board and use its shared context before sending a group ready check.')
        if self.confirm('Group ready check', readable({'recipients': peers, 'prompt': prompt, 'seconds': seconds, 'context': context})):
            result = self.service.ready_group(peers, prompt, context, seconds=seconds)
            self.group_result.set(readable({'submitted': len(result['sent']), 'unavailable': result['failed']}))
            self.render()
            return result

    def use_context(self):
        context = self.shared_contexts.selected()
        if not context:
            raise ValueError('Select a shared session context first.')
        self.context_name.set(context['id'])
        self.confirm_context.set(context['id'])
        self.status.set('Selected shared context will be used for coordination and confirmation.')

    def preview_context(self):
        context = self.shared_contexts.selected()
        if context:
            self.context_preview.set(readable(context))

    def build_editor(self, pane, name, kinds):
        editor = {'kind': self.tk.StringVar(value=kinds[0]), 'values': {}, 'frames': {}, 'item_id': None}
        self.editing[name] = editor
        row = line(self, pane)
        self.ttk.Label(row, text='Plan type', width=18).pack(side='left')
        choice(self, row, editor['kind'], kinds, lambda: self.editor_visibility(name), 22)
        for kind in kinds:
            frame = self.ttk.Frame(pane)
            editor['frames'][kind] = frame
            values = {}
            for key, title, default, options in EDITOR_FIELDS[kind]:
                values[key] = self.field(frame, title, default, options)
            editor['values'][kind] = values
        self.editor_visibility(name)
        row = line(self, pane)
        button(self, row, 'Save new local plan', lambda: self.save_plan(name))
        button(self, row, 'Update loaded plan', lambda: self.save_plan(name, update=True))
        table = Table(self, pane, (('kind', 'Type', 120), ('title', 'Title', 260), ('revision', 'Revision', 80),
                                  ('source', 'Source', 100)), height=6)
        editor['table'] = table
        editor['preview'] = self.tk.StringVar(value='Local plans are not shared until you choose Share selected plan.')
        row = line(self, pane)
        button(self, row, 'Load selected plan', lambda: self.load_plan(name))
        button(self, row, 'Preview plan', lambda: self.preview_plan(name))
        button(self, row, 'Share selected plan…', lambda: self.share_item(self.selected_item(table)))
        button(self, row, 'Export plan…', lambda: self.export_item(self.selected_item(table)))
        if name == 'creator':
            button(self, line(self, pane), 'Share creator plan with selected group…', lambda: self.share_plan_group('creator'))
            self.note(pane, 'Choose group recipients in the Planner tab before sharing a creator plan with several peers.')
        self.label(pane, editor['preview'])
        if name == 'creator':
            self.checklist_index = self.field(pane, 'Checklist item number', '1', width=10)
            self.checklist_status = self.field(pane, 'Checklist result', 'PASS', ('TODO', 'IN_PROGRESS', 'PASS', 'FAIL', 'SKIPPED'), 18)
            self.checklist_note = self.field(pane, 'Result note', '')
            button(self, line(self, pane), 'Update selected checklist item', self.update_checklist)

    def editor_visibility(self, name):
        editor = self.editing[name]
        for kind, frame in editor['frames'].items():
            if kind == editor['kind'].get():
                frame.pack(fill='x')
            else:
                frame.pack_forget()

    def plan_payload(self, name, previous=None):
        editor = self.editing[name]
        kind = editor['kind'].get()
        values = {key: value.get().strip() for key, value in editor['values'][kind].items()}
        data = deepcopy(previous or {})
        if kind in ('party', 'playtest', 'checklist'):
            key = {'party': 'party_id', 'playtest': 'playtest_id', 'checklist': 'checklist_id'}[kind]
            data.setdefault(key, str(uuid.uuid4()))
            data.setdefault('revision', 0)
        if kind == 'party':
            data.update({key: value for key, value in values.items() if value})
            for key in ('current_destination', 'next_destination', 'notes'):
                if not values.get(key):
                    data.pop(key, None)
        elif kind == 'photo':
            data.update(title=values['title'], notes=values['notes'], shots=split_list(values['shots']))
        elif kind == 'cue':
            data.update(cue=values['cue'], label=values['label'], media_session_id=values['media_session_id'] or 'local-media')
            if values['position']:
                data['position'] = float(values['position'])
            else:
                data.pop('position', None)
            data.pop('execute_at', None)
        elif kind == 'ready_template':
            data.update(prompt=values['prompt'], request_id=str(uuid.uuid4()), deadline=self.service.wall() + int(values['seconds']))
        elif kind == 'playtest':
            data.update(values)
        elif kind == 'checklist':
            titles = split_list(values['items'])
            old_items = data.get('items', [])
            data['title'] = values['title']
            data['items'] = [old_items[index] if index < len(old_items) and old_items[index]['title'] == title else
                             {'item_id': str(uuid.uuid4()), 'title': title, 'status': 'TODO'}
                             for index, title in enumerate(titles)]
        return kind, data

    def save_plan(self, name, update=False):
        self.active()
        editor = self.editing[name]
        previous = None
        identifier = None
        if update:
            identifier = editor['item_id']
            previous = next((item for item in self.service.items() if item['id'] == identifier), None)
            if not previous or previous['kind'] != editor['kind'].get():
                raise ValueError('Load a saved plan of this type before updating it.')
        kind, payload = self.plan_payload(name, previous['data'] if previous else None)
        item = self.service.save_item(kind, payload, item_id=identifier)
        editor['item_id'] = item['id']
        editor['preview'].set(readable(item['data']))
        self.status.set('Local plan saved. Share explicitly when you are ready.')
        self.render()
        return item

    def load_plan(self, name):
        editor = self.editing[name]
        item = self.selected_item(editor['table'])
        kind, data = item['kind'], item['data']
        editor['kind'].set(kind)
        editor['item_id'] = item['id']
        for key, variable in editor['values'][kind].items():
            value = data.get(key, '')
            if key == 'items':
                value = '; '.join(row['title'] for row in data.get('items', []))
            elif key == 'shots':
                value = '; '.join(data.get('shots', []))
            elif key == 'seconds':
                value = '60'
            variable.set(str(value))
        self.editor_visibility(name)
        editor['preview'].set(readable(data))
        if kind in ('party', 'playtest', 'checklist'):
            self.context_name.set(item['id'])
            self.confirm_context.set(item['id'])
        self.status.set('Plan loaded into the editor. Update loaded plan saves your changes locally.')

    def preview_plan(self, name):
        editor = self.editing[name]
        item = self.selected_item(editor['table'])
        editor['preview'].set(readable(item['data']))
        if item['kind'] in ('party', 'playtest', 'checklist'):
            self.context_name.set(item['id'])
            self.confirm_context.set(item['id'])

    def local_countdown(self):
        self.active()
        timer = self.service.local_action('countdown', seconds=float(self.countdown_seconds.get()),
                                          title=self.countdown_title.get(), context=self.context_name.get().strip())
        self.status.set('Local countdown started.')
        self.render()
        return timer

    def share_countdown(self):
        seconds = float(self.countdown_seconds.get())
        if not 1 <= seconds <= 110:
            raise ValueError('Shared countdowns must be from 1 to 110 seconds.')
        return self.send_reviewed('countdown.start', {'countdown_id': str(uuid.uuid4()),
                   'title': self.countdown_title.get(), 'target_at': self.service.wall() + seconds}, context=self.context_name.get().strip())

    def send_ready(self):
        editor = self.editing['planner']['values']['ready_template']
        seconds = int(editor['seconds'].get())
        if not 1 <= seconds <= 290:
            raise ValueError('Ready checks must expire within 1 to 290 seconds.')
        return self.send_reviewed('ready.request', {'request_id': str(uuid.uuid4()),
                  'prompt': editor['prompt'].get(), 'deadline': self.service.wall() + seconds}, context=self.context_name.get().strip())

    def cancel_timer(self):
        self.active()
        timer = self.timers.selected()
        if not timer:
            raise ValueError('Select a countdown first.')
        self.service.local_action('cancel_countdown', timer_id=timer['id'])
        self.render()

    def assign_role(self):
        peer = self.peer('role.assign')
        context = self.context_name.get().strip()
        active = next((row for row in self.service.snapshot().get('contexts', []) if row['id'] == context and row.get('active')), None)
        if active is None:
            raise ValueError('Select an active shared party context before assigning a session role.')
        return self.send_reviewed('role.assign', {'role': self.role.get(), 'peer_id': peer, 'revision': active['revision']}, context=context)

    def notice_payload(self):
        return {'title': self.notice_title.get(), 'body': self.notice_body.get(),
                'category': self.notice_category.get(), 'duration': 5}

    def local_notice(self):
        self.active()
        self.service.local_action('notice', **self.notice_payload())
        self.render()

    def share_notice(self):
        return self.send_reviewed('notice.show', self.notice_payload())

    def local_novelty(self):
        self.active()
        self.service.local_action('novelty', style_id=self.novelty_style.get())
        self.render()

    def share_novelty(self):
        return self.send_reviewed('novelty.confetti', {'style_id': self.novelty_style.get(), 'execute_at': self.service.wall() + 5})

    def send_checkin(self):
        return self.send_reviewed('safety.checkin', {'request_id': str(uuid.uuid4()), 'prompt': self.checkin_prompt.get()})

    def share_safety(self):
        state = self.service.snapshot().get('privacy', {}).get('safety', False)
        return self.send_reviewed('safety.alert', {'state': 'ACTIVE' if state else 'CLEARED', 'trigger': 'MANUAL'})

    def build_creator(self):
        pane = self.panes['Creator']
        self.note(pane, 'Create solo playtests and reusable checklists without connecting. A checklist can '
                  'record pass/fail results and notes. Shared snapshots carry revisions; a received plan '
                  'never overwrites your private original.')
        self.build_editor(pane, 'creator', ('checklist', 'playtest'))
        self.heading(pane, 'Mutual evidence')
        self.confirm_context = self.field(pane, 'Shared context ID', '')
        self.confirm_category = self.field(pane, 'Observed event', 'frame_spike',
                            ('frame_spike', 'load_timeout', 'disconnect', 'runtime_unresponsive', 'other'), 25)
        row = line(self, pane)
        button(self, row, 'Record local observation', self.local_observation)
        button(self, row, 'Confirm event with peer…', self.confirm_event)
        button(self, row, 'Confirm shared encounter…', self.confirm_encounter)
        self.note(pane, 'Use the same agreed context at both installations. Confirmation establishes that '
                  'both devices reported a compatible observation; it does not prove its cause or establish '
                  'VRChat identity. Local encounters and mutually confirmed encounters remain distinct.')

    def update_checklist(self):
        self.active()
        item = self.selected_item(self.editing['creator']['table'])
        if item['kind'] != 'checklist':
            raise ValueError('Select a saved checklist first.')
        result = self.service.local_action('checklist_update', item_id=item['id'],
                    index=int(self.checklist_index.get()) - 1, status=self.checklist_status.get(), note=self.checklist_note.get())
        self.status.set('Checklist result saved locally. Share the updated snapshot explicitly.')
        self.render()
        return result

    def local_observation(self):
        self.active()
        result = self.service.local_action('confirm_event', category=self.confirm_category.get(),
                    context=self.confirm_context.get().strip(), time_bucket=int(self.service.wall() // 10))
        self.status.set('Local observation recorded. It is not a peer confirmation or a causal finding.')
        return result

    def confirm_event(self):
        self.active()
        peer = self.peer('diagnostic.confirm')
        context = self.confirm_context.get().strip()
        if not context:
            raise ValueError('Enter an agreed shared context first.')
        result = self.service.local_action('confirm_event', category=self.confirm_category.get(),
                    context=context, time_bucket=int(self.service.wall() // 10))
        payload = result.get('payload', result)
        return self.send_reviewed('diagnostic.confirm', payload, context=context)

    def confirm_encounter(self):
        self.active()
        peer = self.peer('encounter.confirm')
        context = self.confirm_context.get().strip()
        if not context:
            raise ValueError('Enter an agreed shared encounter context first.')
        if self.confirm('Confirm shared encounter', 'Confirm that you and this peer shared the same encounter?\n\nContext: ' + context + '\nThis is an explicit device report, not independent VRChat identity verification.'):
            result = self.service.local_action('confirm_encounter', peer_id=peer, context=context)
            self.service.send(peer, 'encounter.confirm', result.get('payload', result), context=context)
            self.status.set('Encounter confirmation submitted. The count increases only after a matching peer receipt.')
            self.render()
            return result

    def build_diagnostics(self):
        pane = self.panes['Diagnostics & presets']
        self.note(pane, 'Capture sanitized local summaries without a connection. Missing metrics stay '
                  'unavailable. Every shared card requires a preview; no raw logs, account credentials, '
                  'filesystem paths or private messages are included.')
        row = line(self, pane)
        button(self, row, 'Capture diagnostic card', lambda: self.capture_card('diagnostic'))
        button(self, row, 'Capture performance sample', lambda: self.capture_card('performance'))
        button(self, row, 'Save current safe preferences', self.capture_preferences)
        self.cards = Table(self, pane, (('kind', 'Card type', 130), ('title', 'Title', 220),
                            ('source', 'Source', 130), ('updated', 'Captured / saved', 160)), height=8, select=self.preview_card)
        row = line(self, pane)
        button(self, row, 'Preview card', self.preview_card)
        button(self, row, 'Share selected card…', lambda: self.share_item(self.selected_item(self.cards)))
        button(self, row, 'Export selected card…', lambda: self.export_item(self.selected_item(self.cards)))
        button(self, row, 'Import item file…', self.import_item)
        self.card_preview = self.tk.StringVar(value='Select a diagnostic card, performance sample or safe preset.')
        self.label(pane, self.card_preview)
        self.heading(pane, 'Performance comparison')
        row = line(self, pane)
        button(self, row, 'Use selected sample as baseline', self.set_baseline)
        button(self, row, 'Compare selected sample', self.compare_selected)
        self.comparison = self.tk.StringVar(value='Capture at least two samples, or import a peer report for a labeled comparison.')
        self.label(pane, self.comparison)
        self.heading(pane, 'Reviewed preference import')
        row = line(self, pane)
        button(self, row, 'Preview preset changes', self.preview_preset)
        button(self, row, 'Apply selected preset…', self.apply_preset)
        button(self, row, 'Undo last preset import…', self.rollback_preset)
        self.preset_diff = self.tk.StringVar()
        self.label(pane, self.preset_diff)
        self.note(pane, 'Presets contain only supported safe preferences. Networking permissions, secrets, '
                  'account settings and executable paths are excluded. Saved preferences also update active '
                  'supported tools. Undo checks for later edits before restoring the local checkpoint.')
        self.heading(pane, 'Request troubleshooting help')
        self.troubleshoot_note = self.field(pane, 'Request note', '')
        self.troubleshoot_sections = {name: self.tk.BooleanVar(value=True) for name in ('runtime', 'metrics', 'errors')}
        row = line(self, pane)
        for name, variable in self.troubleshoot_sections.items():
            self.ttk.Checkbutton(row, text=name.capitalize(), variable=variable).pack(side='left', padx=6)
        button(self, line(self, pane), 'Request troubleshooting…', self.request_troubleshooting)
        self.note(pane, 'This requests consent for the listed information. The recipient must separately '
                  'review and send a diagnostic card. No remote control, shell commands or filesystem '
                  'browsing is available.')

    def capture_card(self, kind):
        self.active()
        from peer_tools import diagnostic_card, performance_card
        payload = (diagnostic_card if kind == 'diagnostic' else performance_card)(app=self.app)
        item = self.service.save_item(kind, payload)
        self.card_preview.set(readable(payload))
        self.status.set('Sanitized card saved locally. Preview and share only if you want to disclose it.')
        self.render()
        return item

    def capture_preferences(self):
        self.active()
        from peer_tools import export_preferences
        payload = export_preferences(self.shell.store)
        item = self.service.save_item('preset', payload)
        self.card_preview.set(readable(payload))
        self.status.set('Safe preferences saved as a local preset. No changes were applied.')
        self.render()
        return item

    def preview_card(self):
        item = self.selected_item(self.cards)
        self.card_preview.set(readable({'source': item.get('source'), 'contents': item['data']}))

    def set_baseline(self):
        item = self.selected_item(self.cards)
        if item['kind'] != 'performance':
            raise ValueError('Select a performance sample first.')
        self.baseline = deepcopy(item)
        self.comparison.set('Baseline selected: ' + item['id'] + '\nSource: ' + item.get('source', 'Unknown'))

    def compare_selected(self):
        item = self.selected_item(self.cards)
        if item['kind'] != 'performance' or self.baseline is None:
            raise ValueError('Choose a performance baseline, then select another performance sample.')
        from peer_tools import compare_performance
        result = compare_performance(item['data'], self.baseline['data'])
        self.comparison.set('Current source: ' + item.get('source', 'Unknown') + '\nBaseline source: '
                 + self.baseline.get('source', 'Unknown') + '\n' + readable(result))
        return result

    def selected_preset(self):
        item = self.selected_item(self.cards)
        if item['kind'] != 'preset':
            raise ValueError('Select a saved preset first.')
        return item

    def preview_preset(self):
        from peer_tools import preview_preferences
        item = self.selected_preset()
        changes = preview_preferences(self.shell.store, item['data'])
        self.preset_diff.set(readable(changes) if changes else 'No supported preferences would change.')
        return changes

    def apply_preset(self):
        self.active()
        item = self.selected_preset()
        changes = self.preview_preset()
        if not changes:
            return
        if not self.confirm('Apply reviewed preferences', readable(changes) + '\n\nApply these preferences to saved settings and active supported tools?'):
            return
        self.active()
        from peer_tools import apply_preferences, preview_preferences
        if preview_preferences(self.shell.store, item['data']) != changes:
            raise ValueError('Preferences changed during review. Preview the difference again before applying.')
        self.checkpoint = apply_preferences(self.shell.store, item['data'])
        from peer_app import apply_live_preferences
        try:
            apply_live_preferences(self.app, self.shell.store)
        except Exception:
            from peer_tools import rollback_preferences
            rollback_preferences(self.shell.store, self.checkpoint)
            self.checkpoint = None
            try:
                apply_live_preferences(self.app, self.shell.store)
            except Exception:
                raise ValueError('Saved preferences were rolled back. Restart VRC Eye to restore active tools.') from None
            raise ValueError('The active tools could not apply this preset. Previous preferences were restored.') from None
        self.status.set('Preferences applied with a local rollback checkpoint.')

    def rollback_preset(self):
        self.active()
        if self.checkpoint is None:
            raise ValueError('No local preset import checkpoint is available on this page.')
        if not self.confirm('Undo preference import', 'Restore the preferences from before the last import? Undo will stop if those preferences have since changed.'):
            return
        from peer_tools import rollback_preferences
        rollback_preferences(self.shell.store, self.checkpoint)
        self.checkpoint = None
        from peer_app import apply_live_preferences
        try:
            apply_live_preferences(self.app, self.shell.store)
        except Exception:
            raise ValueError('Saved preferences were restored. Restart VRC Eye to reload active tools.') from None
        self.status.set('Previous preferences restored in saved settings and active supported tools.')
        self.preset_diff.set('Last preset import undone.')

    def request_troubleshooting(self):
        sections = [key for key, value in self.troubleshoot_sections.items() if value.get()]
        if not sections:
            raise ValueError('Select at least one information section to request.')
        return self.send_reviewed('troubleshooting.request', {'request_id': str(uuid.uuid4()),
                  'sections': sections, 'note': self.troubleshoot_note.get()})

    def build_permissions(self):
        pane = self.panes['Permissions']
        self.note(pane, 'New requests ask first. Approving one request does not trust the peer for other '
                  'features. Sending and receiving use separate rules. A block overrides sharing grants.')
        self.pending = Table(self, pane, (('peer', 'Peer', 180), ('kind', 'Requested feature', 210),
                              ('status', 'Consent state', 150)), height=7, select=self.preview_pending)
        self.pending_text = self.tk.StringVar(value='Select an incoming request to inspect its exact contents before accepting.')
        self.label(pane, self.pending_text)
        self.grant_scope = self.field(pane, 'Incoming approval scope', 'once', ('once', 'session', 'hour', 'persistent'), 18)
        row = line(self, pane)
        button(self, row, 'Allow selected request…', lambda: self.respond_pending(True))
        button(self, row, 'Deny selected request', lambda: self.respond_pending(False))
        self.heading(pane, 'Rules for the selected peer')
        self.permission_family = self.field(pane, 'Feature family', 'whisper', FAMILIES, 23)
        self.permission_direction = self.field(pane, 'Direction', 'receive', ('receive', 'send'), 18)
        self.permission_value = self.field(pane, 'Decision', 'ask', ('ask', 'allow', 'deny'), 18)
        self.permission_scope = self.field(pane, 'Rule duration', 'session', ('session', 'hour', 'persistent'), 18)
        row = line(self, pane)
        button(self, row, 'Review & save peer rule…', self.save_permission)
        button(self, row, 'Block selected peer…', lambda: self.block_peer(True))
        button(self, row, 'Unblock selected peer…', lambda: self.block_peer(False))
        button(self, row, 'Clear this conversation…', self.clear_conversation)
        self.permissions_text = self.tk.StringVar()
        self.label(pane, self.permissions_text)
        self.heading(pane, 'Your privacy and presentation')
        effective = self.service.snapshot().get('privacy', {})
        privacy = effective.get('own', effective)
        self.privacy_vars = {}
        for key, label, default in (
                ('history_enabled', 'Keep local conversation history', True),
                ('notifications', 'Show peer notifications', True),
                ('reduced_motion', 'Reduce motion and simplify celebrations', True),
                ('streamer', 'Streamer privacy', False),
                ('safety', 'Suppress novelty while in Safety Mode', False),
                ('incognito', 'Incognito: disable peer networking', False)):
            variable = self.tk.BooleanVar(value=bool(privacy.get(key, default)))
            self.privacy_vars[key] = variable
            self.ttk.Checkbutton(pane, text=label, variable=variable).pack(anchor='w', pady=3)
        self.overlay = self.tk.BooleanVar(value=bool(self.shell.store.option('peer.presentation', {}).get('overlay', False)))
        self.ttk.Checkbutton(pane, text='Show peer notices in SteamVR (requires Wellness SteamVR connection)',
                             variable=self.overlay).pack(anchor='w', pady=4)
        row = line(self, pane)
        button(self, row, 'Save privacy & presentation', self.save_privacy)
        button(self, row, 'Delete all local message history…', self.clear_history)
        self.privacy_status = self.tk.StringVar()
        self.label(pane, self.privacy_status)
        self.note(pane, 'History controls affect conversations and encounter receipts. Explicitly saved '
                  'personal notes, plans and reports remain in your local library. Existing app privacy '
                  'modes may impose additional restrictions.')

    def preview_pending(self):
        item = self.pending.selected()
        if not item:
            raise ValueError('Select an incoming permission request first.')
        self.pending_preview = item['message_id']
        self.pending_text.set(readable({'peer': item['peer_id'], 'feature': item['kind'], 'contents': item['payload']}))

    def respond_pending(self, allow):
        self.active()
        item = self.pending.selected()
        if not item:
            raise ValueError('Select a request first.')
        scope = self.grant_scope.get()
        if allow and not self.confirm('Approve incoming request', readable({'from_device': item['peer_id'],
                     'feature': item['kind'], 'contents': item['payload'], 'permission_scope': scope}, limit=100000)
                     + '\n\nThis scope applies only to this feature family and receive direction.'):
            return
        result = self.service.respond(item['message_id'], bool(allow), scope=scope if allow else 'once')
        self.pending_text.set('Request approved.' if allow else 'Request denied.')
        self.render()
        return result

    def save_permission(self):
        self.active()
        peer = self.peer()
        values = {'family': self.permission_family.get(), 'decision': self.permission_value.get(),
                  'scope': self.permission_scope.get(), 'direction': self.permission_direction.get()}
        if self.confirm('Change peer sharing rule', 'Device: ' + peer + '\n\n' + readable(values)):
            self.service.set_permission(peer, **values)
            self.status.set('Selected feature rule saved.')
            self.render()

    def block_peer(self, blocked):
        self.active()
        peer = self.peer()
        if self.confirm('Block peer' if blocked else 'Unblock peer', ('Block' if blocked else 'Unblock') + ' this device?\n\n' + peer):
            self.service.block_peer(peer, blocked=blocked)
            self.status.set('Peer blocked.' if blocked else 'Peer unblocked. Other permission rules still apply.')
            self.render()

    def save_privacy(self):
        self.active()
        values = {key: bool(variable.get()) for key, variable in self.privacy_vars.items()}
        self.service.set_privacy(**values)
        enabled = bool(self.overlay.get())
        self.shell.store.set_option('peer.presentation', {'overlay': enabled})
        self.app.peer_overlay_enabled = enabled
        self.status.set('Privacy and receiver-owned presentation preferences saved.')
        self.render()

    def clear_conversation(self):
        self.active()
        peer = self.peer()
        if self.confirm('Clear local conversation', 'Delete the local messages and encounter receipts for this device?\n\nSaved personal items and the peer’s copies are unaffected.'):
            self.service.clear_history(peer_id=peer)
            self.render()

    def clear_history(self):
        self.active()
        if self.confirm('Delete local message history', 'Delete all local peer conversations and encounter receipts?\n\nSaved personal items and other devices’ copies are unaffected.'):
            self.service.clear_history()
            self.render()

    def build_developer(self):
        pane = self.panes['Developer']
        self.note(pane, 'The inspector contains metadata, not Whisper contents, invitation secrets or '
                  'private keys. Simulations use isolated synthetic data and never send network traffic.')
        from peer_protocol import FEATURES
        self.trace_kind = self.field(pane, 'Feature to explain', 'whisper.message', tuple(FEATURES), 30)
        button(self, line(self, pane), 'Explain action availability', self.trace_capability)
        self.trace_text = self.tk.StringVar()
        self.label(pane, self.trace_text)
        self.simulation_kind = self.field(pane, 'Simulation', 'normal',
                               ('normal', 'delay', 'duplicate', 'stale', 'denied', 'revoked', 'reconnect', 'rate_limit'), 23)
        button(self, line(self, pane), 'Run isolated simulation', self.simulate)
        self.simulation_text = self.tk.StringVar()
        self.label(pane, self.simulation_text)
        self.events = Table(self, pane, (('time', 'Time', 100), ('type', 'Event', 180),
                            ('metadata', 'Sanitized metadata', 520)), height=12)
        self.developer_summary = self.tk.StringVar()
        self.label(pane, self.developer_summary)

    def trace_capability(self):
        result = self.service.capability_decision(self.peer(), self.trace_kind.get())
        self.trace_text.set(readable(result))
        return result

    def simulate(self):
        from peer_simulation import simulate
        result = simulate(self.simulation_kind.get())
        self.simulation_text.set(readable(result))
        self.status.set('Isolated simulation completed. Live peers, permissions and saved data were not changed.')
        return result

    def render(self):
        if self.closed:
            return
        data = self.service.snapshot()
        self.summary.set(f"{data.get('mode', 'Private')} · {data.get('state', 'Offline')} — {data.get('reason', '')}")
        peers = data.get('peers', [])
        self.peer_labels = {(p.get('alias') or 'Device') + ' · ' + p['peer_id'][:14] + ' · ' + p.get('state', 'Unknown'): p['peer_id'] for p in peers}
        self.peer_picker.configure(values=tuple(self.peer_labels) or ('No peer selected',))
        selected_label = next((label for label, peer_id in self.peer_labels.items() if peer_id == self.selected_peer_id), 'No peer selected')
        self.peer_choice.set(selected_label)
        chosen = next((p for p in peers if p['peer_id'] == self.selected_peer_id), None)
        if chosen:
            self.peer_hint.set(f"Selected: {chosen.get('alias') or 'Device'} · {chosen.get('state', 'Unknown')}. All shares require review; receive permissions are decided by the peer.")
        else:
            self.peer_hint.set('No peer selected. Local profile, notes, plans, timers and reports remain available.')
        self.inspect_peer()
        selected_group = [self.group_members.records[key]['peer_id'] for key in self.group_members.tree.selection() if key in self.group_members.records]
        self.group_members.set([p for p in peers if p.get('state') == 'READY'], lambda p: (p.get('alias') or 'Device', p['peer_id']))
        selected_keys = [key for key, record in self.group_members.records.items() if record['peer_id'] in selected_group]
        if selected_keys:
            self.group_members.tree.selection_set(tuple(selected_keys))
        contexts = data.get('contexts', [])
        set_table(self.shared_contexts, contexts, lambda row: (row.get('data', {}).get('title', row.get('kind', 'Session')), row.get('state'), row.get('revision'), row.get('id')))
        set_table(self.request_states, data.get('requests', []), lambda row: (row.get('kind'), row.get('peer_id', '')[:18], row.get('response', 'NO_RESPONSE'), 'Yes' if row.get('active') else 'No'))
        items = data.get('items', [])
        if data.get('item_count', len(items)) > len(items):
            signature = (data['item_count'], tuple((item['id'], item.get('revision'), item.get('updated_at')) for item in items))
            if signature != self.library_signature:
                self.library_cache = self.service.items()
                self.library_signature = signature
            items = self.library_cache
        filtered = [item for item in items if self.library_filter.get() in ('All', item['kind'])]
        set_table(self.library, filtered, lambda item: (item['kind'], self.item_title(item), item.get('source'), item.get('revision')))
        for name, editor in self.editing.items():
            records = [item for item in items if item['kind'] in editor['frames']]
            set_table(editor['table'], records, lambda item: (item['kind'], self.item_title(item), item.get('revision'), item.get('source')))
        cards = [item for item in items if item['kind'] in ('diagnostic', 'performance', 'preset')]
        set_table(self.cards, cards, lambda item: (item['kind'], self.item_title(item), item.get('source'), format_time(item.get('updated_at'))))
        messages = data.get('inbox', [])
        set_table(self.messages, messages, lambda value: (value.get('direction'), value.get('kind'),
                     value.get('peer_id', '')[:18], value.get('status')))
        pending = data.get('pending', [])
        set_table(self.pending, pending, lambda value: (value.get('peer_id', '')[:20], value.get('kind'), value.get('status', 'ASK')))
        timers = data.get('timers', [])
        set_table(self.timers, timers, lambda value: (value.get('title'), round(value.get('remaining', 0), 1),
                       value.get('state'), f"{value.get('source', 'LOCAL')} · {value.get('precision', 'Local clock')}"))
        self.timer_summary.set('Active timers: ' + str(len([x for x in timers if x.get('state') == 'RUNNING'])) +
                               ('\n' + '\n'.join(f"{x.get('title', 'Timer')}: {x.get('remaining', 0):.1f}s · {x.get('state', '')}" for x in timers[:5]) if timers else ''))
        self.notifications.set('\n'.join(readable({key: n.get(key) for key in ('title', 'body') if n.get(key)})
                                         for n in data.get('notifications', [])[-5:]))
        self.permissions_text.set(readable(data.get('permissions', {})))
        self.privacy_status.set('Effective peer privacy: ' + readable(data.get('privacy', {})) +
                               '\nSteamVR notices require the existing Wellness SteamVR connection. Desktop display remains receiver-controlled.')
        events = data.get('events', [])
        set_table(self.events, events[-100:], lambda row: (format_time(row.get('at', row.get('time'))),
                    row.get('type', row.get('kind', 'Event')), readable({k: v for k, v in row.items() if k not in ('at', 'time', 'type', 'kind')})))
        self.developer_summary.set('Counters: ' + readable(data.get('counters', {})) + '\nNo public directory or automatic VRChat identity mapping is used.')
        self.last_draw = time.monotonic()

    def tick(self):
        if self.closed:
            return
        super().tick()
        if self.osc_controls.built:
            self.guard(self.osc_controls.refresh)
        if time.monotonic() - self.last_draw >= .5:
            self.guard(self.render)

    def close(self):
        if self.closed:
            return True
        self.whisper_text.set('')
        self.checkpoint = None
        self.baseline = None
        self.osc_controls.close()
        return super().close()


def split_list(value):
    return [item.strip() for item in value.replace('\n', ';').split(';') if item.strip()]


def format_time(value):
    try:
        return datetime.fromtimestamp(value).strftime('%Y-%m-%d %H:%M:%S')
    except (TypeError, ValueError, OverflowError, OSError):
        return 'Unavailable'


EDITOR_FIELDS = {
    'party': (('title', 'Party title', 'My private party plan', None),
              ('current_destination', 'Current world ID', '', None),
              ('next_destination', 'Next world ID', '', None), ('notes', 'Plan notes', '', None)),
    'photo': (('title', 'Photo plan title', 'My photo plan', None),
              ('shots', 'Shot list (; separated)', 'Group shot; Portrait; Wide view', None),
              ('notes', 'Pose / camera notes', '', None)),
    'cue': (('label', 'Cue label', 'My media cue', None),
            ('cue', 'Cue action', 'PLAY', ('PLAY', 'PAUSE', 'SEEK', 'NEXT_MARKER', 'START_AT', 'STOP')),
            ('media_session_id', 'Media session label', 'local-media', None),
            ('position', 'Position in seconds', '0', None)),
    'ready_template': (('prompt', 'Ready-check prompt', 'Ready for a photo?', None),
                       ('seconds', 'Response window (s)', '120', None)),
    'checklist': (('title', 'Checklist title', 'Avatar playtest checklist', None),
                  ('items', 'Tasks (; separated)', 'Load avatar; Gestures; Facial expressions; Mirror check', None)),
    'playtest': (('title', 'Playtest title', 'My creator playtest', None),
                 ('target', 'Avatar / world label', '', None),
                 ('phase', 'Current phase', 'Preparation', None), ('notes', 'Playtest notes', '', None)),
}
