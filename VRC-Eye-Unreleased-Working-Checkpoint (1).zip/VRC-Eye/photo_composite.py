"""Data-only ordered contact sheets and strips, using the existing photo renderer."""
from __future__ import annotations

from io import BytesIO
from math import ceil

from avatar_library_files import check_cancel
from photo_files import MAX_BYTES, _open, _rgb, normalize_recipe, render, validate_export

MAX_SLOTS=24
MAX_CANVAS_PIXELS=16 * 1024 * 1024
LAYOUTS=('Grid','Vertical strip','Horizontal strip')


def layout(value):
    if not isinstance(value,dict) or set(value)-{'mode','columns','cell_width','cell_height','spacing','background','numbers'}:
        raise ValueError('Unsupported contact-sheet settings.')
    result={'mode':value.get('mode','Grid'),'columns':value.get('columns',3),
            'cell_width':value.get('cell_width',640),'cell_height':value.get('cell_height',480),
            'spacing':value.get('spacing',16),'background':value.get('background','White'),
            'numbers':value.get('numbers',False)}
    for k,lo,hi in (('columns',1,6),('cell_width',128,1600),('cell_height',128,1600),('spacing',0,96)):
        if type(result[k]) is not int or not lo<=result[k]<=hi:raise ValueError('Invalid '+k.replace('_',' ')+'.')
    if result['mode'] not in LAYOUTS or result['background'] not in ('White','Dark') or type(result['numbers']) is not bool:
        raise ValueError('Choose a supported layout, background and number-label setting.')
    return result


def slots(value):
    if not isinstance(value,(list,tuple)) or not 2<=len(value)<=MAX_SLOTS:
        raise ValueError('Choose 2–24 photo slots.')
    import uuid
    result=[]
    for item in value:
        if not isinstance(item,dict) or set(item)-{'photo','recipe'}:raise ValueError('Invalid photo slot.')
        try:identity=str(uuid.UUID(item['photo']))
        except (KeyError,ValueError,AttributeError,TypeError) as error:raise ValueError('Invalid photo reference.') from error
        result.append({'photo':identity,'recipe':normalize_recipe(item.get('recipe',{}))})
    return result


def geometry(settings,count):
    settings=layout(settings)
    if type(count) is not int or not 2<=count<=MAX_SLOTS:raise ValueError('Choose 2–24 photo slots.')
    cols=1 if settings['mode']=='Vertical strip' else count if settings['mode']=='Horizontal strip' else min(settings['columns'],count)
    rows=ceil(count/cols);gap=settings['spacing'];label=32 if settings['numbers'] else 0
    width=cols*settings['cell_width']+(cols+1)*gap
    height=rows*(settings['cell_height']+label)+(rows+1)*gap
    if width>8192 or height>8192 or width*height>MAX_CANVAS_PIXELS:
        raise ValueError('Canvas exceeds 8192 pixels per edge or 16 megapixels. Reduce cells, spacing or photo count.')
    return cols,rows,width,height,label


def render_sheet(selection,settings,read,*,stop=None,progress=None):
    """Read and render one source at a time; fit without cropping or enlargement."""
    from PIL import Image,ImageDraw,ImageFont
    selection=slots(selection);settings=layout(settings)
    cols,rows,w,h,label=geometry(settings,len(selection));gap=settings['spacing']
    background='white' if settings['background']=='White' else '#242424'
    ink='#242424' if settings['background']=='White' else 'white'
    canvas=Image.new('RGB',(w,h),background)
    try:
        draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=18) if settings['numbers'] else None
        total=0
        for i,item in enumerate(selection):
            check_cancel(stop);data=read(item['photo']);total+=len(data)
            if total>256*1024*1024:raise ValueError('Combined input exceeds the 256 MiB contact-sheet budget.')
            # Reuse single-image masks/crop semantics. Each slot is independent.
            recipe=dict(item['recipe']);recipe['max_edge']=min(recipe['max_edge'],max(settings['cell_width'],settings['cell_height']))
            recipe['max_edge']=max(256,recipe['max_edge'])
            prepared=render(data,recipe)
            with _open(prepared) as im:rgb=_rgb(im)
            try:
                rgb.thumbnail((settings['cell_width'],settings['cell_height']))
                x=gap+(i%cols)*(settings['cell_width']+gap)
                y=gap+(i//cols)*(settings['cell_height']+label+gap)
                canvas.paste(rgb,(x+(settings['cell_width']-rgb.width)//2,y+(settings['cell_height']-rgb.height)//2))
                if label:draw.text((x+settings['cell_width']//2,y+settings['cell_height']+label//2),str(i+1),font=font,fill=ink,anchor='mm')
            finally:rgb.close()
            if progress:progress(f'Rendered slot {i+1}/{len(selection)}.')
        check_cancel(stop);out=BytesIO();canvas.save(out,'PNG');payload=out.getvalue()
        if len(payload)>MAX_BYTES:raise ValueError('Contact sheet exceeds the 64 MiB output limit.')
        validate_export(payload);return payload
    finally:canvas.close()
