@echo off
call "%~dp0Start.cmd" --safe-mode %*
