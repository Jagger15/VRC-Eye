"""Lazy OSC workspace. Widgets request reviewed actions; they never own transports.

Transport configuration lives only in Networking. App-owned controllers continue
cleanup when a tab closes; display refresh does not drive the OSC scheduler.
"""
from __future__ import annotations

from text_viewport import window_body

from copy import deepcopy
import json
import math
from pathlib import Path
import queue
import threading
import time

from creator_ui import CreatorPanel

TABS = ("Overview", "Control Deck", "Avatar Parameters", "Voice & Privacy", "Chatbox",
        "Camera", "Tracking", "Presets & Rules", "Routes & Permissions", "Inspector")
VIEWS = ("Casual", "Advanced", "Developer")
SETUP_STEPS = ("Observe first", "Enable OSC in VRChat", "Select a client", "Review receive port",
               "Inspect passive observations", "Review available controls", "Choose permissions",
               "Review voice and publication separately", "Try a deliberate control", "Ready to rearm")
SCOPES = ("input", "microphone", "chatbox", "camera", "camera.pose", "avatar.parameters", "avatar.switch",
          "avatar.scale", "tracking.eye", "tracking.body", "dolly", "debug", "safety", "protective")


def readable(value, limit=12000):
    if value is None:
        return "Unknown"
    return (json.dumps(value, ensure_ascii=False, indent=2, default=str)
            if isinstance(value, (dict, list, tuple)) else str(value))[:limit]


def arguments(text):
    """The generic editor is exact typed JSON, with finite numbers and a size cap."""
    if len(text.encode("utf-8")) > 8192:
        raise ValueError("Arguments exceed the 8 KiB editor limit.")
    def reject(value):
        raise ValueError("Arguments must contain finite numbers.")
    try:
        values = json.loads(text, parse_constant=reject)
    except (json.JSONDecodeError, RecursionError) as error:
        raise ValueError("Enter an argument list such as [0.5], [1], [true] or [1.0, 2.0, 3.0].") from error
    if not isinstance(values, list) or not 1 <= len(values) <= 16:
        raise ValueError("Enter a list with 1–16 typed arguments.")
    if any(type(v) not in (str, int, float, bool) or isinstance(v, float) and not math.isfinite(v) for v in values):
        raise ValueError("Use finite floats, integers, booleans or strings; nested values are not OSC arguments.")
    return values


def confirm_review(app, tk, ttk, title, text):
    from tkinter import messagebox
    root = getattr(app, "root", None)
    if len(text) <= 1800:
        return messagebox.askyesno(title, text, parent=root)
    window = tk.Toplevel(root)
    window.title(title)
    window.geometry("850x630")
    window.transient(root)
    result = {"approved": False}
    content = ttk.Frame(window_body(window), padding=12)
    content.pack(fill="both", expand=True)
    editor = tk.Text(content, wrap="word", width=90, height=29)
    scroll = ttk.Scrollbar(content, orient="vertical", command=editor.yview)
    editor.configure(yscrollcommand=scroll.set)
    scroll.pack(side="right", fill="y")
    editor.pack(fill="both", expand=True)
    editor.insert("1.0", text)
    editor.configure(state="disabled")
    bar = ttk.Frame(window_body(window), padding=12)
    bar.pack(fill="x")
    def finish(approved):
        result["approved"] = approved
        window.destroy()
    ttk.Button(bar, text="Cancel", command=lambda: finish(False)).pack(side="right")
    ttk.Button(bar, text="Approve reviewed action", command=lambda: finish(True)).pack(side="right", padx=8)
    window.protocol("WM_DELETE_WINDOW", lambda: finish(False))
    window.grab_set()
    root.wait_window(window)
    return result["approved"]


class OSCControlsPage(CreatorPanel):
    def __init__(self, parent, app, *, tk=None, ttk=None, navigate=None):
        self.app, self.parent = app, parent
        self.tk, self.ttk = tk or app.tk, ttk or app.ttk
        self.controller = getattr(app, "osc_controller", None)
        self.navigate = navigate
        self.pages, self.built, self.tables, self.table_rows, self.inputs = {}, set(), {}, {}, {}
        self.closed, self.active_tab, self.last_refresh = False, "Overview", -float("inf")
        self.freeze = False
        self.export_pending = False
        self.export_output = queue.Queue(maxsize=1)
        self.data, self.endpoint_records = {}, {}
        self.status = self.tk.StringVar(value="Controls stay off until you review and enable them. Opening this page does not send an action.")
        self.summary = self.tk.StringVar(value="OSC Controls • no live actions restored")
        preferences = self.controller.preferences if self.controller is not None else {}
        self.view = self.tk.StringVar(value=preferences.get("view", "Casual"))
        self.ttk.Label(parent, textvariable=self.summary, style="Accent.TLabel", wraplength=1000).pack(anchor="w", pady=4)
        row = self._bar(parent)
        self._button(row, "Networking", self.open_networking)
        self._button(row, "Stop Controls", self.stop_controls)
        picker = self.ttk.Combobox(row, textvariable=self.view, values=VIEWS, state="readonly", width=12)
        picker.pack(side="left", padx=5)
        picker.bind("<<ComboboxSelected>>", lambda _: self._call(self.change_view))
        self.ttk.Label(parent, textvariable=self.status, wraplength=1000).pack(anchor="w", pady=3)
        self.notebook = self.ttk.Notebook(parent)
        self.notebook.pack(fill="both", expand=True)
        for name in TABS:
            page = self.ttk.Frame(self.notebook, padding=8)
            self.pages[name] = page
            self.notebook.add(page, text=name)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab)
        self.visibility()

    def announce(self, text):
        self.status.set(str(text))

    def available(self):
        if self.closed:
            raise ValueError("This OSC view is closed.")
        if self.controller is None:
            raise ValueError("The application OSC service is unavailable in this environment.")
        return self.controller

    @property
    def service(self):
        return self.available().service

    def confirm(self, title, text):
        return confirm_review(self.app, self.tk, self.ttk, title, text)

    def reviewed(self, review, submit, title="Review OSC action"):
        # Reviews are generated before the modal and consumed unchanged afterward.
        # The service, not a widget timestamp, enforces single use and generations.
        if self.confirm(title, readable(review, 262144) + "\n\nUDP transmission is not proof of VRChat execution."):
            self.available().ensure_active()
            result = submit(review)
            self.announce(readable(result, 3000))
            self.refresh(force=True)
            return result
        self.announce("Review cancelled; no action submitted.")
        return None

    def control(self, action, **payload):
        c = self.available()
        result = self.reviewed(c.review_control(action, **payload), c.execute_control, action.replace(".", " · "))
        if result is not None and action == "voice.configure":
            self.available().save_preferences({"voice_mode": payload["mode"]})
        return result

    def endpoint(self, address, values, **options):
        options.setdefault("ttl", 30)
        c = self.available()
        return self.reviewed(c.review_endpoint(address, values, source="manual", **options), c.submit_endpoint)

    def grant(self, scopes, source="manual", public=False):
        c = self.available()
        return self.reviewed(c.review("arm", scopes=list(scopes), source=source, public=public), c.execute, "Review output permissions")

    def workspace_service(self):
        self.available().ensure_active()
        return self.available().workspace

    def open_networking(self):
        if self.navigate is not None:
            self.navigate("Networking")
        else:
            self.available().show_networking()
        page = getattr(getattr(self.app, "sidebar", None), "pages", {}).get("Networking")
        if page and "OSC transport" in getattr(page, "frames", {}):
            page.tabs.select(page.frames["OSC transport"])

    def stop_controls(self):
        result = self.available().stop_controls()
        self.announce(readable(result) if result is not None else "Controls stopped. Owned cleanup requested; delivery remains unverified.")
        self.refresh(force=True)

    def visibility(self):
        advanced = {"Tracking", "Presets & Rules", "Routes & Permissions", "Inspector"}
        for name, page in self.pages.items():
            self.notebook.tab(page, state="hidden" if self.view.get() == "Casual" and name in advanced else "normal")

    def change_view(self):
        self.visibility()
        self.available().save_preferences({"view": self.view.get()})
        if self.view.get() == "Casual" and self.active_tab in {"Tracking", "Presets & Rules", "Routes & Permissions", "Inspector"}:
            self.notebook.select(self.pages["Overview"])
            self.show("Overview")

    def show(self, name):
        if self.closed or name not in self.pages:
            return
        self.active_tab = name
        if name not in self.built:
            pane = self._scroll(self.pages[name])
            if self.controller is None:
                self._note(pane, "OSC service unavailable in this environment. Restart the current application build to initialize it.")
            else:
                getattr(self, "build_" + name.lower().replace(" & ", "_").replace(" ", "_"))(pane)
            self.built.add(name)
        self.refresh(force=True)

    def label(self, parent, initial=""):
        variable = self.tk.StringVar(value=initial)
        self.ttk.Label(parent, textvariable=variable, wraplength=1000, justify="left").pack(anchor="w", pady=4)
        return variable

    def check(self, parent, text, initial=False):
        variable = self.tk.BooleanVar(value=initial)
        self.ttk.Checkbutton(parent, text=text, variable=variable).pack(anchor="w", pady=3)
        return variable

    def build_overview(self, pane):
        self._note(pane, "OSC and Eye-to-Eye networking are separate. Discovery grants no write permission. "
                   "Opening this page sends no movement, microphone, chatbox or camera command.")
        self.overview = self.label(pane)
        self.setup = self.label(pane)
        row = self._bar(pane)
        self._button(row, "Previous step", lambda: self.setup_step(-1))
        self._button(row, "Mark step reviewed", lambda: self.setup_step(1))
        self._button(row, "Find VRChat", lambda: self.available().discover())
        self._button(row, "Networking setup", self.open_networking)
        self._button(self._bar(pane), "Review basic input and camera permissions", lambda: self.grant(("input", "camera")))
        self._table(pane, "candidates", (("label", "Candidate (unverified name)", 280), ("address", "Endpoint", 230), ("state", "Evidence", 260)), 4)
        self.candidates_hint = self.label(pane)
        self._button(self._bar(pane), "Select this client", self.select_instance)
        self._note(pane, "Connect and receive-port selection live in Networking. Multiple candidates require deliberate selection. "
                   "A stable value is different from a dead service; sent commands can remain unverified.")
        self._note(pane, "Setup progress is resumable. It never restores held controls, pending publications or camera countdowns.")
        self.troubleshoot = self._field(pane, "Troubleshooting symptom", options=("No connection", "Sent but no effect", "Read-only parameter",
                    "Value changes back", "After avatar switch", "Microphone reversed", "Duplicate capture", "Motion continues"))
        self.troubleshoot_detail = self.label(pane)
        self._button(self._bar(pane), "Show next checks", self.troubleshooting)
        self._note(pane, "Use Routes & Permissions in Advanced view to review capabilities. Voice and chatbox require separate approval.")

    def setup_step(self, delta):
        preferences = self.available().preferences
        step = max(0, min(len(SETUP_STEPS) - 1, int(preferences.get("setup_step", 0)) + delta))
        self.available().save_preferences({"setup_step": step})
        self.refresh(force=True)

    def select_instance(self):
        identity = self._selected("candidates")[0]
        result = self.available().select_instance(identity)
        self.announce("Client selected for read-only inspection. " + readable(result, 1200))
        self.refresh(force=True)

    def troubleshooting(self):
        checks = {
            "No connection": "Enable OSC in VRChat, inspect discovered candidates, then review send/receive ports in Networking. Never seize another application's receive port.",
            "Sent but no effect": "Check exact address and argument type, required permission, availability evidence and selected client. A local UDP send does not acknowledge execution.",
            "Read-only parameter": "Built-in avatar parameters remain read-only. Review custom input mappings and the current avatar schema; naming alone does not imply a writable function.",
            "Value changes back": "Check active owners, avatar logic and world enforcement. Stop conflicting routes before trying again; repeated writes may fight the user's own input.",
            "After avatar switch": "Previous-avatar work is cancelled. Wait for the transition observation and fresh compatibility data, then explicitly rearm the required controls.",
            "Microphone reversed": "Review VRChat's microphone toggle setting and VRC Eye's matching behavior. If feedback is unknown, do not use desired-state actions as blind toggles.",
            "Duplicate capture": "Inspect camera history for multiple producers. Cancel local countdowns. A native delayed capture already sent may still occur; capture requests are never automatically retried.",
            "Motion continues": "Press Stop Controls. VRC Eye attempts releases only for its owned controls. Check other senders and release the input inside VRChat if cleanup remains unverified.",
        }
        self.troubleshoot_detail.set(checks[self.troubleshoot.get()])

    def build_control_deck(self, pane):
        self._note(pane, "Deliberate accessible input and testing. Short actions always have a bounded release. "
                   "Compatibility extensions require client evidence; no anti-idle or unattended movement.")
        self._table(pane, "deck", (("name", "Input", 210), ("type", "OSC types", 90), ("behavior", "Behavior", 100),
                    ("evidence", "Compatibility evidence", 300)), 7)
        self.tables["deck"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_deck))
        self.deck_address = self._field(pane, "Selected input", value="/input/Jump")
        self.deck_arguments = self._field(pane, "Typed arguments (JSON)", value="[1]")
        self.deck_duration = self._field(pane, "Release after seconds", value="0.15")
        self.deck_behavior = self._field(pane, "Interaction", options=("Single action", "Bounded hold", "Continuous value"))
        row = self._bar(pane)
        self._button(row, "Review input", self.send_deck)
        self._button(row, "Release my deck controls", self.release_deck)
        self._button(row, "Pin selected input", self.pin_deck)
        self._button(self._bar(pane), "Review momentary hold binding", self.arm_momentary)
        self.momentary_binding, self.momentary_held = None, False
        self.momentary_button = self.ttk.Button(pane, text="Hold selected input (maximum 5 seconds)")
        self.momentary_button._eye_hold_control = True
        self.momentary_button.pack(anchor="w", pady=4)
        for event in ("<ButtonPress-1>", "<KeyPress-space>"):
            self.momentary_button.bind(event, lambda _: self._call(self.press_momentary))
        for event in ("<ButtonRelease-1>", "<KeyRelease-space>", "<FocusOut>"):
            self.momentary_button.bind(event, lambda _: self._call(self.release_momentary))
        self._note(pane, "Review this binding first, then hold with the mouse or Space. Releasing or losing focus releases only this owner. A five-second service deadline still applies if the widget disappears.")
        self.deck_detail = self.label(pane)
        row = self._bar(pane)
        self._button(row, "Activate VRChat Safe Mode…", lambda: self.control("safety.native"))
        self._button(row, "Activate VRC Eye Safety Mode…", lambda: self.control("safety.eye", native=False, mute=False))
        self._note(pane, "Native Safe Mode release does not undo Safe Mode. VRC Eye Safety Mode separately pauses its own controls. "
                   "Leaving safety does not automatically unmute, resume movement or republish text.")

    def select_deck(self):
        identity = self._selected("deck")[0]
        self.deck_address.set(identity)
        item = self.endpoint_records.get(identity, {})
        types = item.get("types", item.get("argument_types", []))
        if isinstance(types, str):
            types = list(types.lstrip(","))
        self.deck_arguments.set("[1.0]" if tuple(types) in (("f",), ("Float",)) else "[1]")
        self.deck_detail.set(readable(item, 3000))

    def send_deck(self):
        address = self.deck_address.get().strip()
        if not address.startswith("/input/") or address in ("/input/Voice", "/input/PanicButton"):
            raise ValueError("Choose a deck input. Voice and native safety have dedicated reviewed controls.")
        duration = float(self.deck_duration.get())
        behavior = self.deck_behavior.get()
        endpoint = self.service.registry.get(address)
        if endpoint is None:
            raise ValueError("Select a registered input.")
        if behavior == "Continuous value" and endpoint.behavior != "continuous":
            raise ValueError("Continuous interaction requires a documented axis endpoint.")
        if behavior == "Single action" and duration > .5:
            raise ValueError("A single action is at most half a second; choose Bounded hold for a longer deliberate press.")
        if not math.isfinite(duration) or not 0.05 <= duration <= 5:
            raise ValueError("Deck actions require a release deadline from 0.05 to 5 seconds.")
        return self.endpoint(address, arguments(self.deck_arguments.get()), owner="manual:deck", duration=duration)

    def arm_momentary(self):
        c = self.available()
        address = self.deck_address.get().strip()
        if not address.startswith("/input/") or address in ("/input/Voice", "/input/PanicButton"):
            raise ValueError("Choose an input with dedicated deck ownership; voice and safety use their own controls.")
        values = arguments(self.deck_arguments.get())
        review = c.review_endpoint(address, values, source="manual", owner="manual:momentary", duration=5, ttl=30)
        if self.confirm("Review momentary input binding", readable(review, 262144) + "\n\nFor 30 seconds, this exact input can be held deliberately with this button. Every hold releases within five seconds. Nothing sends until you press."):
            c.ensure_active()
            if tuple(self.service.state_guard) != tuple(review["guard"]) or self.service.clock() >= review["expires_at"]:
                raise ValueError("The momentary binding context changed or its review expired.")
            self.release_momentary()
            self.momentary_binding = {"address": address, "args": tuple(values), "guard": tuple(review["guard"]), "expires_at": review["expires_at"]}
            self.announce("Momentary binding reviewed for 30 seconds. Hold the button deliberately to send; release returns this input to neutral.")

    def press_momentary(self):
        if self.momentary_held:
            return
        c = self.available()
        c.ensure_active()
        binding = self.momentary_binding
        if not binding or tuple(self.service.state_guard) != binding["guard"] or self.service.clock() >= binding["expires_at"]:
            self.momentary_binding = None
            raise ValueError("Review the current momentary binding before holding this input.")
        if self.deck_address.get().strip() != binding["address"] or tuple(arguments(self.deck_arguments.get())) != binding["args"]:
            raise ValueError("The deck input changed. Review its new momentary binding first.")
        review = c.review_endpoint(binding["address"], binding["args"], source="manual", owner="manual:momentary", duration=5, ttl=5)
        result = c.submit_endpoint(review)
        self.momentary_held = True
        self.announce("Held input scheduled. Release this button to request its owned neutral value.")
        return result

    def release_momentary(self):
        if self.controller is None:
            return
        self.momentary_held = False
        self.service.release_owner("manual:momentary", reason="Momentary input released")

    def release_deck(self):
        self.release_momentary()
        result = self.service.release_owner("manual:deck")
        self.announce("Deck-owned cleanup requested. " + readable(result, 2000))

    def pin_deck(self):
        address = self.deck_address.get().strip()
        if address not in self.endpoint_records or not address.startswith("/input/"):
            raise ValueError("Select a supported registry input before pinning it.")
        pins = list(self.available().preferences.get("deck_pins", []))
        if address not in pins:
            pins.append(address)
        self.available().save_preferences({"deck_pins": pins[:24]})
        self.announce("Pinned locally. Pinning never arms or sends a control.")
        self.refresh(force=True)

    def build_avatar_parameters(self, pane):
        self._note(pane, "Real mappings define types and access. Built-in AFK, MuteSelf, Upright and gestures are read-only. "
                   "Unknown values remain unknown; local computation may still produce avatar-visible output.")
        self.parameter_filter = self._field(pane, "Filter name", value="")
        self._table(pane, "parameters", (("name", "Parameter", 200), ("type", "Types", 70), ("value", "Observed", 100),
                   ("access", "Access", 110), ("audience", "Audience / sync", 120), ("owner", "Owner", 120)), 8)
        self.tables["parameters"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_parameter))
        self.parameter_address = self._field(pane, "Selected address", value="")
        self.parameter_arguments = self._field(pane, "Typed arguments (JSON)", value="[0.5]")
        self.parameter_public = self.check(pane, "Allow this manual source to produce reviewed avatar-visible output")
        row = self._bar(pane)
        self._button(row, "Review avatar permissions", lambda: self.grant(("avatar.parameters", "avatar.switch", "avatar.scale"), public=bool(self.parameter_public.get())))
        self._button(row, "Review parameter assignment", self.send_parameter)
        self.parameter_detail = self.label(pane)
        self._note(pane, "A generic value editor does not invent what a parameter named Mode or Color means. "
                   "Declared meaning, range, synchronization and audience come from compatibility metadata.")
        self.height = self._field(pane, "Requested eye height (meters)", value="1.6")
        self._button(self._bar(pane), "Review eye-height request", lambda: self.control("avatar.height", value=float(self.height.get())))
        self.scale_detail = self.label(pane)
        self._table(pane, "eligible_avatars", (("avatar", "Eligible avatar observed by VRC Eye", 380), ("basis", "Eligibility evidence", 200)), 4)
        self.tables["eligible_avatars"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_eligible_avatar))
        self._button(self._bar(pane), "Refresh known eligible avatars", lambda: self.refresh(force=True))
        self.switch_avatar = self._field(pane, "Eligible avatar ID")
        self.switch_eligibility = self._field(pane, "Eligibility evidence", value="")
        self.inputs[id(self.switch_eligibility)].configure(state="readonly")
        self._button(self._bar(pane), "Review avatar switch", lambda: self.control("avatar.switch", avatar_id=self.switch_avatar.get().strip(), eligibility=self.switch_eligibility.get()))
        self._note(pane, "Load real Game Favorites or Search My uploads / My favorites, or wear an avatar to add session recents. Local VRC Eye bookmarks do not prove VRChat eligibility. VRChat enforces access; observe the switch before applying a destination preset.")

    def select_eligible_avatar(self):
        identity = self._selected("eligible_avatars")[0]
        eligible = self.available().controls.snapshot().get("avatar", {}).get("eligible", {})
        basis = eligible.get(identity)
        if basis not in ("favorites", "recents", "uploads"):
            raise ValueError("Refresh eligible avatar evidence before choosing this avatar.")
        self.switch_avatar.set(identity)
        self.switch_eligibility.set(basis)

    def select_parameter(self):
        identity = self._selected("parameters")[0]
        self.parameter_address.set(identity)
        self.parameter_detail.set(readable({"description": self.endpoint_records.get(identity, {}),
                                          "observation": self.service.observation(identity),
                                          "owners": [r for r in self.service.snapshot().get("owners", []) if r.get("address") == identity]}, 6000))

    def send_parameter(self):
        address = self.parameter_address.get().strip()
        if not address.startswith("/avatar/parameters/"):
            raise ValueError("Select an avatar parameter from the registry.")
        return self.endpoint(address, arguments(self.parameter_arguments.get()), owner="manual:parameter")

    def build_voice_privacy(self, pane):
        self._note(pane, "Configure VRChat's actual microphone behavior before use. MuteSelf observations concern VRChat only; "
                   "they do not establish operating-system, physical headset or other-app microphone privacy.")
        self._button(self._bar(pane), "Review microphone permission", lambda: self.grant(("microphone",)))
        self.voice_state = self.label(pane)
        self.voice_mode = self._field(pane, "VRChat microphone behavior", options=("unknown", "toggle", "hold"), value=self.available().preferences.get("voice_mode", "unknown"))
        self._button(self._bar(pane), "Review microphone behavior", lambda: self.control("voice.configure", mode=self.voice_mode.get()))
        row = self._bar(pane)
        for label, action in (("Request muted", "mute"), ("Request unmuted", "unmute"), ("Toggle microphone", "toggle"), ("Release voice control", "release")):
            self._button(row, label, lambda token=action: self.control("voice." + token))
        self.voice_hold = self._field(pane, "Bounded speak duration (seconds)", value="3")
        self._button(self._bar(pane), "Review bounded hold to speak", lambda: self.control("voice.hold", seconds=float(self.voice_hold.get())))
        self.privacy_enabled = self.check(pane, "Expect muted during this explicit privacy session")
        self.privacy_corrective = self.check(pane, "Allow one reviewed corrective mute attempt when feedback is trustworthy")
        self._button(self._bar(pane), "Review privacy watchdog", lambda: self.control("voice.privacy", enabled=bool(self.privacy_enabled.get()), corrective=bool(self.privacy_corrective.get())))
        self._note(pane, "Missing or conflicting observation means privacy is unverified. The watchdog must stop and report instability rather than repeatedly toggle against your input.")
        self.safety_native = self.check(pane, "Include a native VRChat Safe Mode request in the safety sequence")
        self.safety_mute = self.check(pane, "Include a configured mute request in the safety sequence")
        row = self._bar(pane)
        self._button(row, "Review VRC Eye safety sequence", lambda: self.control("safety.eye", native=bool(self.safety_native.get()), mute=bool(self.safety_mute.get())))
        self._button(row, "Leave VRC Eye Safety Mode", lambda: self.control("safety.leave"))
        self.safety_state = self.label(pane)

    def build_chatbox(self, pane):
        self._note(pane, "Publishing sends text to your VRChat chatbox audience. This is not a chat reader. "
                   "No message is sent while you type; approved manual text outranks background output.")
        self._button(self._bar(pane), "Review chatbox publication permission", lambda: self.grant(("chatbox",)))
        self.chat_text = self._field(pane, "Message", multiline=True, value="", width=72)
        self.chat_text.bind("<KeyRelease>", lambda _: self._call(self.chat_preview))
        self.chat_text.bind("<FocusIn>", lambda _: self.available().controls.set_composing(True))
        self.chat_text.bind("<FocusOut>", lambda _: self.available().controls.set_composing(False))
        self.chat_immediate = self.check(pane, "Send immediately (off: populate VRChat's editor)", True)
        self.chat_sound = self.check(pane, "Request notification sound")
        self.chat_typing = self.check(pane, "Request typing indicator only when I explicitly apply it")
        self.chat_count = self.label(pane)
        row = self._bar(pane)
        self._button(row, "Preview publication", self.chat_preview)
        self._button(row, "Review & publish", self.publish_chat)
        self._button(row, "Apply typing indicator…", lambda: self.control("chat.typing", enabled=bool(self.chat_typing.get())))
        self._button(row, "Cancel my pending output", lambda: self.control("chat.cancel", producer="composer"))
        self.chat_state = self.label(pane)
        self._note(pane, "Cancelling queued output does not retract text that has already appeared or been seen. "
                   "Templates and providers may only publish fields you deliberately select; no usernames, paths or diagnostic text is included automatically.")
        self.chat_preview()

    def chat_preview(self):
        text = self._get(self.chat_text)
        count, lines = len(text), text.count("\n") + 1
        self.chat_count.set(f"Preview: {count}/144 characters · {lines}/9 explicit lines · wrapping can add display lines.\n" + text[:2000])
        return text

    def publish_chat(self):
        text = self.chat_preview()
        if not text.strip() or len(text) > 144 or text.count("\n") + 1 > 9:
            raise ValueError("A publication needs 1–144 characters and at most nine explicit lines.")
        return self.control("chat.publish", text=text, immediate=bool(self.chat_immediate.get()),
                            notification=bool(self.chat_sound.get()), producer="composer", kind="user", ttl=15,
                            privacy="user_approved")

    def build_camera(self, pane):
        self._note(pane, "All camera entry points share this action service. Capture transmission is unconfirmed until additional evidence arrives; "
                   "a nearby screenshot alone cannot prove which action created it. Camera pose writes require current-client verification.")
        self._button(self._bar(pane), "Review camera and Dolly permissions", lambda: self.grant(("camera", "dolly")))
        self.camera_state = self.label(pane)
        self.camera_countdown = self._field(pane, "Local countdown (seconds)", value="0")
        self.camera_native_delay = self.check(pane, "Use VRChat native delayed capture instead of a local countdown")
        row = self._bar(pane)
        self._button(row, "Review capture", lambda: self.control("camera.capture", countdown=float(self.camera_countdown.get()), native_delay=bool(self.camera_native_delay.get()), owner="camera:desktop"))
        self._button(row, "Cancel local camera work", lambda: self.control("camera.cancel", capture_id=None))
        self._note(pane, "Cancelling VRC Eye's countdown does not necessarily cancel native delayed capture already handed to VRChat.")
        self._table(pane, "camera_endpoints", (("name", "Setting / action", 210), ("type", "Types", 70), ("range", "Range / units", 200), ("evidence", "Evidence", 260)), 7)
        self.tables["camera_endpoints"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_camera))
        self.camera_name = self._field(pane, "Selected camera setting", value="Mode")
        self.camera_value = self._field(pane, "Exact value (JSON)", value="1")
        self._button(self._bar(pane), "Review camera setting", self.send_camera)
        self.camera_preset = self._field(pane, "Selected settings preset (JSON)", multiline=True, value='{"Mode": 1}')
        self._button(self._bar(pane), "Review camera preset", self.apply_camera_preset)
        self._note(pane, "Dolly is an optional VRC+ client capability. Import remains reviewed data, and active playback can make an import unavailable.")
        self.dolly_path = self._field(pane, "Dolly path JSON", multiline=True, value="{}")
        self.dolly_space = self._field(pane, "Path space", options=("local", "world"))
        self.dolly_world = self._field(pane, "World ID for world-specific path")
        self.dolly_notes = self._field(pane, "Path context notes")
        self.dolly_verified = self.check(pane, "I verified this path uses the current client native Dolly export format")
        self.dolly_delay = self._field(pane, "Dolly delay seconds", value="3")
        row = self._bar(pane)
        self._button(row, "Review Dolly import", lambda: self.control("dolly.import", json=self._get(self.dolly_path), space=self.dolly_space.get(), world_id=self.dolly_world.get().strip(), notes=self.dolly_notes.get(), format_verified=bool(self.dolly_verified.get())))
        self._button(row, "Play…", lambda: self.control("dolly.play"))
        self._button(row, "Delayed play…", lambda: self.control("dolly.delay", seconds=float(self.dolly_delay.get())))
        self._button(row, "Stop Dolly…", lambda: self.control("dolly.stop"))
        self._button(row, "Request Dolly export…", lambda: self.control("dolly.export"))
        self._note(pane, "Delay accepted is different from playback observed. Import/export requests do not upload or publish local files.")
        self._note(pane, "An accepted Eye-to-Eye countdown still needs a separate one-use local camera approval. Peer acceptance does not authorize future captures.")
        self._table(pane, "peer_camera", (("peer", "Authenticated peer", 200), ("remaining", "Countdown remaining", 180), ("notice", "Local consent", 440)), 4)
        self._button(self._bar(pane), "Review one capture for selected peer countdown", self.accept_peer_camera)

    def accept_peer_camera(self):
        c = self.available()
        return self.reviewed(c.review_peer_action(self._selected("peer_camera")[0]), c.execute_peer_action, "Review one local peer countdown capture")

    def select_camera(self):
        identity = self._selected("camera_endpoints")[0]
        self.camera_name.set(identity.rsplit("/", 1)[-1])
        item = self.endpoint_records.get(identity, {})
        kind = tuple(item.get("types", ()))
        observed = self.service.observation(identity)
        if observed and observed.get("live") and len(observed.get("args", ())) == 1:
            value = observed["args"][0]
        elif kind == ("b",):
            value = False
        elif kind == ("f",):
            value = float(item.get("minimum") if item.get("minimum") is not None else 0.)
        elif kind == ("i",):
            value = int(item.get("minimum") if item.get("minimum") is not None else 0)
        else:
            self.announce("This endpoint needs a specialized compatible controller. " + readable(item, 3000))
            return
        self.camera_value.set(json.dumps(value))
        self.announce(readable(item, 3000))

    def send_camera(self):
        value = arguments("[" + self.camera_value.get() + "]")[0]
        return self.control("camera.set", name=self.camera_name.get().strip(), value=value)

    def apply_camera_preset(self):
        settings = self.parse_object(self._get(self.camera_preset))
        return self.control("camera.preset", settings=settings)

    @staticmethod
    def parse_object(text):
        if len(text.encode("utf-8")) > 65536:
            raise ValueError("Configuration editor limit is 64 KiB.")
        try:
            def unique(pairs):
                result = {}
                for key, value in pairs:
                    if key in result:
                        raise ValueError("Configuration contains duplicate keys.")
                    result[key] = value
                return result
            def finite(value):
                raise ValueError("Configuration numbers must be finite.")
            data = json.loads(text, object_pairs_hook=unique, parse_constant=finite)
        except (json.JSONDecodeError, RecursionError) as error:
            raise ValueError("Enter a valid bounded JSON object.") from error
        if not isinstance(data, dict):
            raise ValueError("Enter a JSON object.")
        pending, count = [(data, 0)], 0
        while pending:
            value, depth = pending.pop()
            count += 1
            if depth > 16 or count > 8192:
                raise ValueError("Configuration structure is too deep or complex.")
            if isinstance(value, dict):
                pending.extend((item, depth + 1) for item in value.values())
            elif isinstance(value, list):
                pending.extend((item, depth + 1) for item in value)
        return data

    def build_tracking(self, pane):
        self._note(pane, "Tracking routes manage deliberately selected sources; VRC Eye does not manufacture real measurements. "
                   "Keep working tracking apps direct unless managed validation or transformations are useful.")
        self.tracking_state = self.label(pane)
        self._table(pane, "tracking_routes", (("name", "Route / source", 240), ("state", "State", 130), ("target", "Destination", 310)), 7)
        row = self._bar(pane)
        self._button(row, "Review tracking source permissions", lambda: self.grant_selected("route", "tracking_routes"))
        self._button(row, "Review selected tracking route", lambda: self.activate_route("tracking_routes"))
        self._button(row, "Stop selected tracking route", lambda: self.stop_route("tracking_routes"))
        self._button(row, "Open route configuration", lambda: self.select_tab("Routes & Permissions"))
        self._note(pane, "Eye look uses one representation at a time. Native eye-look and eyelid fallback can take about ten seconds after output stops. "
                   "Tracker positions use real-world meters and documented Unity coordinates; arbitrary zero positions are not a lost-tracker signal.")
        self._note(pane, "Lost providers stop forwarding stale samples. Local queue age and drop counts do not measure total tracking latency or VRChat server ping. "
                   "Incoming head/wrist telemetry and outgoing body tracking require different permissions.")

    def select_tab(self, name):
        self.notebook.select(self.pages[name])
        self.show(name)

    def build_presets_rules(self, pane):
        self._note(pane, "Presets select state assignments for a specific avatar/schema. Rules are bounded reviewed workflows. "
                   "Importing definitions never arms them, grants permissions or resumes old work.")
        self._table(pane, "presets", (("name", "Preset", 250), ("avatar", "Avatar / schema", 370)), 5)
        row = self._bar(pane)
        self._button(row, "Review preset source permissions", lambda: self.grant_selected("preset", "presets"))
        self._button(row, "Review & apply selected preset", self.apply_preset)
        self._button(row, "Review restore of selected application", self.restore_preset)
        self._table(pane, "applications", (("name", "Application", 220), ("status", "Result", 300)), 4)
        self._table(pane, "rules", (("name", "Rule", 250), ("state", "State / trigger", 350)), 5)
        row = self._bar(pane)
        self._button(row, "Review rule source permissions", lambda: self.grant_selected("rule", "rules"))
        self._button(row, "Review & arm selected rule", self.arm_rule)
        self._button(row, "Cancel all rules", self.cancel_rules)
        self.rule_trigger = self._field(pane, "Explicit trigger name", value="photo_session")
        self.rule_value = self._field(pane, "Trigger value (typed JSON)", value="true")
        self._button(self._bar(pane), "Review explicit trigger", self.trigger_rule)
        self.preset_detail = self.label(pane)
        self._button(self._bar(pane), "Edit inert configuration", lambda: self.select_tab("Routes & Permissions"))
        self._note(pane, "Restore checks current ownership and later writes. It may skip a value rather than erase a newer choice. "
                   "Stopping or switching avatars cancels delayed work; queued actions do not become transactions.")

    def apply_preset(self):
        workspace = self.workspace_service()
        return self.reviewed(workspace.preview_preset(self._selected("presets")[0]), workspace.apply_preset, "Review preset changes")

    def restore_preset(self):
        workspace = self.workspace_service()
        return self.reviewed(workspace.preview_restore(self._selected("applications")[0]), workspace.restore, "Review selective restoration")

    def arm_rule(self):
        workspace = self.workspace_service()
        review = workspace.review_rule(self._selected("rules")[0])
        audience = review["details"]["rule"]["audience"]
        return self.reviewed(review, lambda token: workspace.arm_rule(token, approved_audiences=(audience,)), "Review bounded rule and output audience")

    def cancel_rules(self):
        self.available().workspace.cancel_rules()
        self.announce("Rules cancelled. Previously transmitted effects may remain; held owned controls use service cleanup.")

    def trigger_rule(self):
        trigger, value = self.rule_trigger.get().strip(), arguments("[" + self.rule_value.get() + "]")[0]
        self.available().ensure_active()
        guard = tuple(self.service.state_guard)
        if self.confirm("Trigger reviewed rules", f"Trigger: {trigger}\nValue: {readable(value)}\n\nOnly already armed compatible rules may run."):
            self.available().ensure_active()
            if tuple(self.service.state_guard) != guard:
                raise ValueError("OSC context changed during review. Review the trigger again.")
            result = self.available().workspace.event(trigger, value, kind="explicit")
            self.announce(readable(result))

    def build_routes_permissions(self, pane):
        self._note(pane, "The OSC firewall governs managed traffic that passes through VRC Eye. Other applications sending directly "
                   "to VRChat are outside its coverage. A route label or UDP endpoint is not authenticated application identity.")
        self.routing_mode = self._field(pane, "Operating mode", options=("Observation", "Coexistence", "Managed routing"), value=self.available().preferences.get("routing_mode", "Observation"))
        self._button(self._bar(pane), "Save mode preference", self.save_mode)
        self._note(pane, "Observation grants no output. Coexistence leaves direct apps unchanged. Managed routing introduces VRC Eye as "
                   "a dependency for specifically configured routes; this choice never rewrites another application's settings.")
        self.permission_source = self._field(pane, "Permission source", value="manual")
        self.permission_public = self.check(pane, "Allow reviewed avatar-visible output for this specific source")
        self._note(pane, "Source names are exact: manual, route:<id>, preset:<id>, or rule:<id>. Grant the source its declared capabilities before reviewing its activation. Granting another source never arms it.")
        self.scope_vars = {}
        for scope in SCOPES:
            self.scope_vars[scope] = self.check(pane, "Allow deliberate local " + scope + " actions")
        row = self._bar(pane)
        self._button(row, "Review selected output permissions", self.arm_scopes)
        self._button(row, "Revoke output permissions / stop", self.stop_controls)
        self.permissions_detail = self.label(pane)
        self._table(pane, "routes", (("name", "Configured route", 220), ("source", "Source", 180), ("target", "Destination", 280), ("state", "State", 110)), 6)
        row = self._bar(pane)
        self._button(row, "Review selected route permissions", lambda: self.grant_selected("route", "routes"))
        self._button(row, "Review & activate route", self.activate_route)
        self._button(row, "Stop route", self.stop_route)
        self._note(pane, "Declarative import accepts only validated routes, presets and rules. Data cannot grant permissions, choose network destinations "
                   "or execute scripts. Edit the full configuration below; importing replaces only the reviewed configuration as described by its validator.")
        self.config_text = self._field(pane, "Configuration JSON", multiline=True, width=80,
                                      value=readable(self.available().workspace.export_configuration()))
        row = self._bar(pane)
        self._button(row, "Preview & import inactive definitions", self.import_configuration)
        self._button(row, "Load battery transformation example into editor", self.load_example)
        self.config_preview = self.label(pane)
        self.transform_route = self._field(pane, "Preview route ID")
        self.transform_value = self._field(pane, "Raw sample (typed JSON)", value="75")
        self._button(self._bar(pane), "Preview transformation without sending", self.preview_transform)
        self.transform_detail = self.label(pane)

    def save_mode(self):
        self.available().save_preferences({"routing_mode": self.routing_mode.get()})
        if self.routing_mode.get() == "Observation":
            self.available().stop_controls()
        self.announce("Mode preference saved. Output and managed routes require their own explicit approvals.")

    def arm_scopes(self):
        scopes = [scope for scope, variable in self.scope_vars.items() if variable.get()]
        if not scopes:
            raise ValueError("Select the capabilities you want to review; observing needs no output permission.")
        c = self.available()
        return self.reviewed(c.review("arm", scopes=scopes, source=self.permission_source.get().strip(), public=bool(self.permission_public.get())), c.execute, "Review local output permissions")

    def grant_selected(self, kind, table):
        workspace = self.workspace_service()
        identity = self._selected(table)[0]
        reviewer = {"route": workspace.review_route, "rule": workspace.review_rule, "preset": workspace.preview_preset}[kind]
        details = reviewer(identity)["details"]
        if kind == "preset":
            endpoints = [self.service.registry.get(row["address"]) for row in details["rows"] if row["compatible"]]
            scopes = sorted({endpoint.permission for endpoint in endpoints if endpoint is not None})
            public = any(endpoint.public for endpoint in endpoints if endpoint is not None)
        else:
            record = details[kind]
            scopes = record["capabilities"]
            public = record["audience"] == "avatar"
        if not scopes:
            raise ValueError("This definition has no compatible output capability to grant.")
        result = self.grant(scopes, source=details["source"], public=public)
        if result is not None:
            self.announce("Source permissions reviewed. Select Review & activate/apply to create a fresh action review.")
        return result

    def load_example(self):
        from osc_routes import EXAMPLE_CONFIGURATION
        self._set(self.config_text, readable(EXAMPLE_CONFIGURATION))
        self.announce("Example loaded into the editor only. Change its mapping to a real declared avatar parameter before import.")

    def activate_route(self, table="routes"):
        workspace = self.workspace_service()
        review = workspace.review_route(self._selected(table)[0])
        audience = review["details"]["route"]["audience"]
        return self.reviewed(review, lambda token: workspace.activate_route(token, approved_audiences=(audience,)), "Review managed route and output audience")

    def stop_route(self, table="routes"):
        self.available().workspace.stop_route(self._selected(table)[0])
        self.announce("Route stopped; stale samples will not be replayed.")
        self.refresh(force=True)

    def import_configuration(self):
        from osc_routes import validate_configuration
        self.available().ensure_active()
        document = validate_configuration(self.parse_object(self._get(self.config_text)))
        before = self.available().workspace.export_configuration()
        changes = []
        for category in ("routes", "presets", "rules"):
            old = {r["id"]: r for r in before[category]}
            new = {r["id"]: r for r in document[category]}
            for identity in sorted(set(old) | set(new)):
                if old.get(identity) == new.get(identity):
                    continue
                changes.append({"kind": category, "id": identity, "change": "removed" if identity not in new else "added" if identity not in old else "changed",
                                "definition": new.get(identity)})
        preview = {"changes": changes, "network_destinations": [], "grants_authority": False,
                   "activation": "Existing managed routes/rules stop. Imported definitions remain inactive until separately reviewed."}
        self.config_preview.set(readable(preview))
        if not self.confirm("Review inert configuration changes", readable(preview, 262144)):
            self.announce("Import cancelled. Existing configuration retained.")
            return None
        self.available().ensure_active()
        if self.available().workspace.export_configuration() != before or validate_configuration(self.parse_object(self._get(self.config_text))) != document:
            raise ValueError("Configuration changed during review. Preview the import again.")
        result = self.available().workspace.import_configuration(document)
        self.config_preview.set(readable(result))
        self.announce("Validated definitions imported inactive. Review permissions and each activation separately.")
        self.refresh(force=True)
        return result

    def preview_transform(self):
        workspace = self.workspace_service()
        result = workspace.preview_transform(self.transform_route.get().strip(), arguments("[" + self.transform_value.get() + "]")[0])
        self.transform_detail.set(readable(result))
        return result

    def build_inspector(self, pane):
        self.connection_health=self.label(pane)
        self._note(pane, "Bounded action and policy history answers why work was requested, blocked, cancelled or transmitted. "
                   "Sent is not delivered; matching observed state does not prove which writer caused it. Sensitive payloads stay out of default diagnostics.")
        self.inspector_filter = self._field(pane, "Filter action / endpoint / outcome")
        self.inspector_source = self._field(pane, "Source filter (blank = all)")
        self.pause_display = self.check(pane, "Pause inspector display (traffic continues)")
        row = self._bar(pane)
        self._button(row, "Refresh display", lambda: self.refresh(force=True))
        self._button(row, "Stop Controls (traffic)", self.stop_controls)
        self._table(pane, "ledger", (("id", "Action", 120), ("origin", "Origin", 100), ("endpoint", "Endpoint", 230),
                    ("result", "Result / reason", 380)), 12)
        self.tables["ledger"].bind("<<TreeviewSelect>>", lambda _: self._call(self.inspect_action))
        self.action_detail = self.label(pane)
        self._table(pane, "policy_events", (("category", "Policy event", 120), ("source", "Source", 140), ("address", "Endpoint", 230), ("detail", "Decision / reason", 370)), 6)
        self.diagnostics = self.label(pane)
        self._note(pane, "Raw chat text, precise tracking histories and sensitive parameter values are excluded from default exports. "
                   "Use the action result and service-health evidence to investigate; do not assume missing observations prove failure.")
        if hasattr(self.available(), "bookmark"):
            row = self._bar(pane)
            self._button(row, "Create local OSC diagnostic bookmark", lambda: self.announce(readable(self.available().bookmark())))
            self._button(row, "Save redacted diagnostics…", self.export_diagnostics)
        self._note(pane, "The simulator is a separate fake endpoint with no live network. Developer visibility grants no live send authority.")
        row = self._bar(pane)
        self._button(row, "Start isolated simulator", lambda: self.simulator_start(True))
        self._button(row, "Stop isolated simulator", lambda: self.simulator_start(False))
        self.simulation = self._field(pane, "Simulator fault / event", options=("advance", "observe", "packet_loss", "rejection", "type_change", "avatar_change", "conflicting_writer", "malformed", "disconnect", "reconnect", "missing_observations", "delay"))
        self.simulation_payload = self._field(pane, "Event fields (JSON object)", value='{"seconds": 1.0}')
        self._button(self._bar(pane), "Inject into simulator only", self.simulator_inject)
        self.simulation_detail = self.label(pane)

    def export_diagnostics(self):
        if self.export_pending:
            raise ValueError("A diagnostic export is already being saved.")
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=getattr(self.app, "root", None), title="Save redacted OSC diagnostics", defaultextension=".json", filetypes=(("JSON diagnostics", "*.json"),))
        if not path:
            return
        # Snapshot on the UI thread; worker writes only this immutable redacted
        # document and never reads the live service or calls Tk.
        data = json.dumps(self.available().export_diagnostics(), ensure_ascii=False, indent=2, allow_nan=False)
        if len(data.encode("utf-8")) > 262144:
            raise ValueError("Redacted export exceeds the bounded diagnostic size.")
        self.export_pending = True
        output = self.export_output
        def write():
            try:
                with Path(path).open("x", encoding="utf-8") as stream:
                    stream.write(data)
                result = "Redacted diagnostics saved. Values and identifying details were omitted."
            except OSError as error:
                result = "Could not save diagnostics: " + str(error)[:300]
            output.put_nowait(result)
        self.export_thread = threading.Thread(target=write, name="osc-diagnostic-export", daemon=True)
        self.export_thread.start()
        self.announce("Saving the reviewed metadata-only diagnostic snapshot…")

    def simulator_start(self, enabled):
        result = self.available().set_simulator(enabled)
        self.simulation_detail.set(readable(result, 6000))
        return result

    def simulator_inject(self):
        result = self.available().inject_simulation(self.simulation.get(), self.parse_object(self.simulation_payload.get()))
        self.simulation_detail.set(readable(result, 6000))
        return result

    def inspect_action(self):
        identity = self._selected("ledger")[0]
        row = self.ledger_records.get(identity, {})
        self.action_detail.set(readable(row, 8000))

    def registry_rows(self):
        registry = self.service.registry
        result = registry.snapshot()
        if isinstance(result, dict):
            result = result.get("endpoints", list(result.values()))
        return [row for row in result if isinstance(row, dict) and row.get("address")][:1024]

    def refresh(self, force=False):
        if self.closed or self.controller is None:
            return
        saved_view=getattr(self.controller,'preferences',{}).get('view',self.view.get())
        if saved_view!=self.view.get():
            self.view.set(saved_view);self.visibility()
            if saved_view=='Casual' and self.active_tab in {'Tracking','Presets & Rules','Routes & Permissions','Inspector'}:
                self.notebook.select(self.pages['Overview']);self.show('Overview')
        try:
            result = self.export_output.get_nowait()
        except queue.Empty:
            pass
        else:
            self.export_pending = False
            self.announce(result)
        if not force and hasattr(self.parent, "winfo_ismapped") and not self.parent.winfo_ismapped():
            return
        now = time.monotonic()
        if not force and now - self.last_refresh < .4:
            return
        self.last_refresh = now
        self.data = self.available().snapshot()
        service = self.data.get("service", self.data)
        controls = self.data.get("controls", {})
        workspace = self.data.get("workspace", {})
        casual = self.view.get() == "Casual"
        connection_label = str(service.get("state", "Unknown")).replace("_", " ").capitalize()
        if casual:
            self.summary.set(f"{connection_label} · {'Controls enabled for this session' if service.get('armed') else 'Controls not enabled'}")
        else:
            self.summary.set(f"{service.get('state', 'Unknown')} · {'Armed' if service.get('armed') else 'Observation / unarmed'} · "
                             f"Avatar: {service.get('avatar_id') or service.get('avatar') or 'Unknown'}")
        rows = self.registry_rows()
        self.endpoint_records = {row["address"]: row for row in rows}
        if "Overview" in self.built:
            observations = service.get("observations", {})
            health = next((r for r in observations.values() if isinstance(r, dict) and r.get("live")), None)
            if casual:
                evidence = "Recent trusted data is available." if health else "No recent trusted data has been observed yet."
                self.overview.set(f"Connection: {connection_label}\n{len(observations)} observed values. {evidence}\n"
                                  "Use Networking to change connection settings. Sending a command does not confirm that VRChat carried it out.")
            else:
                self.overview.set(readable({"connection": service.get("state", "Unknown"), "configured_send_port": service.get("target_port"),
                    "receiving_port": service.get("receive_port"), "discovery": self.data.get("discovery", {}).get("state", "Unknown"),
                    "observed_parameters": len(observations), "service_health_age": health.get("service_health_age") if health else None,
                    "observation_confidence": "Current service evidence" if health else "No current trusted observation",
                    "armed": service.get("armed", False), "generation": service.get("generation"), "avatar_generation": service.get("avatar_generation")}, 3000))
            step = max(0, min(len(SETUP_STEPS) - 1, int(self.available().preferences.get("setup_step", 0))))
            self.setup.set(f"Setup {step + 1}/{len(SETUP_STEPS)}: {SETUP_STEPS[step]}")
            discovery = self.data.get("discovery", {})
            candidates = discovery.get("candidates", [])
            if isinstance(candidates, dict):
                candidates = list(candidates.values())
            self.candidates_hint.set("No clients listed yet. Enable OSC in VRChat, then choose Find VRChat." if not candidates else "Choose the client you recognize. Finding a client does not enable control permissions.")
            self.tables["candidates"].configure(displaycolumns=("label", "state") if casual else "#all")
            self._rows("candidates", [(str(r.get("id", r.get("name", i))), (r.get("name", r.get("label", "Unnamed")),
                        r.get("url", r.get("address", "Unknown")), r.get("state", r.get("evidence", "Discovered; untrusted")))) for i, r in enumerate(candidates[:50])])
        if "Control Deck" in self.built:
            pins = self.available().preferences.get("deck_pins", [])
            deck = sorted((r for r in rows if r["address"].startswith("/input/") and r["address"] not in ("/input/Voice", "/input/PanicButton")),
                          key=lambda r: (r["address"] not in pins, r["address"]))
            self._rows("deck", [(r["address"], (("★ " if r["address"] in pins else "") + r["address"].split("/")[-1],
                        readable(r.get("types", r.get("argument_types", "Unknown"))), r.get("behavior", "Unknown"),
                        readable(r.get("evidence", "Documented; untested"), 200))) for r in deck])
        if "Avatar Parameters" in self.built:
            query = self.parameter_filter.get().casefold()
            selected = [r for r in rows if r["address"].startswith("/avatar/parameters/") and query in r["address"].casefold()]
            parameter_rows = []
            for r in selected:
                observation = self.service.observation(r["address"])
                value = observation.get("value", observation.get("args")) if isinstance(observation, dict) else None
                parameter_rows.append((r["address"], (r["address"].split("/")[-1], readable(r.get("types", "Unknown")), readable(value, 120),
                        r.get("access", r.get("direction", "Unknown")), "Avatar-visible" if r.get("public") else "Not declared / local mapping", ", ".join(str(owner.get("owner", owner.get("source", "Unknown"))) for owner in service.get("owners", []) if owner.get("address") == r["address"]) or "None owned by VRC Eye")))
            self._rows("parameters", parameter_rows)
            self.scale_detail.set(readable(controls.get("scaling", {}), 2500))
            eligible = controls.get("avatar", {}).get("eligible", {})
            self._rows("eligible_avatars", [(identity, (identity, basis)) for identity, basis in list(eligible.items())[:256]])
        if "Voice & Privacy" in self.built:
            self.voice_state.set(readable(controls.get("voice", {}), 5000))
            self.safety_state.set(readable(controls.get("safety", {}), 3000))
        if "Chatbox" in self.built:
            self.chat_state.set(readable(controls.get("chat", {}), 4000))
        if "Camera" in self.built:
            self.camera_state.set(readable(controls.get("camera", {}), 6000))
            peer_rows = self.available().pending_peer_actions()
            self._rows("peer_camera", [(r["message_id"], (r.get("peer_id", "Unknown"), f"{r.get('remaining', 0):.1f} seconds", r.get("notice", "Review required"))) for r in peer_rows[:30]])
            self._rows("camera_endpoints", [(r["address"], (r["address"].rsplit("/", 1)[-1], readable(r.get("types", "Unknown")),
                       readable({"minimum": r.get("minimum"), "maximum": r.get("maximum"), "units": r.get("units")}, 180), readable(r.get("evidence", "Documented; untested"), 250)))
                       for r in rows if r["address"].startswith("/usercamera/")])
        route_rows = workspace.get("routes", [])
        preset_rows = workspace.get("presets", [])
        rule_rows = workspace.get("rules", [])
        applications = workspace.get("applications", [])
        def records(value):
            return list(value.values()) if isinstance(value, dict) else value
        route_rows, preset_rows, rule_rows, applications = map(records, (route_rows, preset_rows, rule_rows, applications))
        route_rows = [dict(r.get("definition", {}), **r) for r in route_rows]
        if "Tracking" in self.built:
            tracking = [r for r in route_rows if "tracking" in str(r.get("destination", r.get("address", ""))) or r.get("kind") in ("eye", "body", "tracking")]
            self._rows("tracking_routes", [(str(r["id"]), (r.get("label", r.get("name", r["id"])), r.get("status", r.get("state", "Inactive")), r.get("destination", r.get("address", "Unknown")))) for r in tracking])
            self.tracking_state.set(readable([{k: r.get(k) for k in ("id", "source_id", "source_health", "sample_age", "incoming_hz", "outgoing_hz", "queue_delay", "dropped", "rejected", "owner", "status")} for r in tracking], 4000))
        if "Presets & Rules" in self.built:
            self._rows("presets", [(str(r["id"]), (r.get("label", r.get("name", r["id"])), readable({k: r.get(k) for k in ("avatar_id", "schema_revision")}, 250))) for r in preset_rows])
            self._rows("rules", [(str(r["id"]), (r.get("label", r.get("name", r["id"])), readable(r.get("state", r.get("trigger", "Inactive")), 200))) for r in rule_rows])
            self._rows("applications", [(str(r["id"]), (r.get("label", r.get("name", r["id"])), readable(r.get("summary", r.get("status", r.get("state", "Unverified"))), 350))) for r in applications])
            self.preset_detail.set(readable([{"preset_id": r.get("preset_id"), "summary": r.get("summary"), "rows": r.get("rows")} for r in applications[-3:]], 6000))
        if "Routes & Permissions" in self.built:
            self._rows("routes", [(str(r["id"]), (r.get("label", r.get("name", r["id"])), r.get("source_id", r.get("source", "Unknown")), r.get("destination", r.get("address", "Unknown")), r.get("status", r.get("state", "Inactive")))) for r in route_rows])
            self.permissions_detail.set(readable({"permissions": service.get("permissions", {}), "ownership": service.get("owners", []),
                                                  "coverage": "Managed traffic only; direct external senders remain outside coverage."}, 6000))
        if "Inspector" in self.built and not self.pause_display.get():
            from osc_connection_health import describe
            if self.data.get('connection_health'):self.connection_health.set(describe(self.data['connection_health']))
            ledger = service.get("ledger", service.get("actions", []))
            if isinstance(ledger, dict):
                ledger = list(ledger.values())
            text_filter, source_filter = self.inspector_filter.get().casefold(), self.inspector_source.get().casefold()
            filtered = [r for r in ledger[-200:] if text_filter in readable(r).casefold() and source_filter in str(r.get("source", r.get("origin", ""))).casefold()]
            self.ledger_records = {str(r.get("id", i)): r for i, r in enumerate(filtered)}
            self._rows("ledger", [(identity, (identity, r.get("source", r.get("origin", "Unknown")), r.get("address", r.get("action", "")),
                        str(r.get("status", r.get("state", "Unknown"))) + " · " + str(r.get("reason", r.get("detail", ""))))) for identity, r in self.ledger_records.items()])
            traces = [r for r in service.get("traces", [])[-100:] if text_filter in readable(r).casefold() and source_filter in str(r.get("source", "")).casefold()]
            self._rows("policy_events", [(str(i), (r.get("category", "Unknown"), r.get("source", ""), r.get("address", ""), r.get("detail", ""))) for i, r in enumerate(traces)])
            self.diagnostics.set(readable({key: service.get(key, "Unknown") for key in ("invalid", "dropped", "queue_size", "cleanup_unverified", "owners")}, 4500))

    def close(self):
        # Application-owned service handles releases independently of widgets.
        if self.closed:
            return True
        if hasattr(self, "momentary_binding"):
            self.release_momentary()
        if hasattr(self, "chat_text"):
            self._set(self.chat_text, "")
            self.available().controls.set_composing(False)
        self.closed = True
        return True


class OSCTransportPanel(CreatorPanel):
    """The sole OSC address/port editor, embedded under Networking."""
    def __init__(self, parent, app):
        self.app, self.parent = app, parent
        self.tk, self.ttk = app.tk, app.ttk
        self.controller = getattr(app, "osc_controller", None)
        self.inputs, self.tables, self.table_rows = {}, {}, {}
        self.closed = False
        self.status = self.tk.StringVar(value="OSC transport configuration is separate from Eye-to-Eye peer networking.")
        self.ttk.Label(parent, textvariable=self.status, wraplength=1000).pack(anchor="w", pady=4)
        if self.controller is None:
            self._note(parent, "OSC transport service is unavailable in this environment.")
            return
        settings = self.controller.config
        self._note(parent, "Loopback is the default. Start receiving without arming controls. Use passive OSCQuery discovery or "
                   "the manual target below. A busy receive port is reported; it is never taken from another application.")
        self.fields = {
            "target_host": self._field(parent, "VRChat target IP", value=str(settings.get("target_host", "127.0.0.1"))),
            "target_port": self._field(parent, "VRChat send port", value=str(settings.get("target_port", 9000))),
            "receive_port": self._field(parent, "VRC Eye receive port (0 = free)", value=str(settings.get("receive_port", 9001))),
        }
        self.fields["receive_host"] = self._field(parent, "VRC Eye bind address", value=str(settings.get("receive_host", "127.0.0.1")))
        self.switches = {}
        for key, title in (("allow_lan", "Allow reviewed LAN addresses (raw OSC has no authentication)"), ("fallback_port", "Choose a free receive port if the selected port is busy"), ("advertise", "Advertise the receive service using OSCQuery"), ("tracking", "Advertise optional incoming head/wrist telemetry; VRChat approval is separate"), ("auto_observe", "Start passive observation at application startup")):
            var = self.tk.BooleanVar(value=bool(settings.get(key, False)))
            self.switches[key] = var
            self.ttk.Checkbutton(parent, text=title, variable=var).pack(anchor="w", pady=3)
        self.query_url = self._field(parent, "Read-only OSCQuery URL", value="http://127.0.0.1:9002/")
        row = self._bar(parent)
        self._button(row, "Review & save OSC transport", self.configure)
        self._button(row, "Connect observation only", self.connect)
        self._button(row, "Disconnect OSC", self.disconnect)
        row = self._bar(parent)
        self._button(row, "Discover OSCQuery services", self.controller.discover)
        self._button(row, "Inspect configured OSCQuery URL", self.inspect)
        self._button(self._bar(parent), "Review selected instance transport…", self.use_selected_instance)
        self.details = self.tk.StringVar()
        self.ttk.Label(parent, textvariable=self.details, wraplength=1000, justify="left").pack(anchor="w", pady=5)
        self._note(parent, "OSCQuery metadata and candidate names are compatibility evidence, not authorization. Windows OSCQuery "
                   "typically discovers same-machine clients. Other approved platform routes need a reviewed network configuration. "
                   "Raw OSC is not an authenticated internet remote-control interface.")
        self.refresh(force=True)

    def announce(self, text):
        self.status.set(str(text))

    def confirm(self, title, text):
        return confirm_review(self.app, self.tk, self.ttk, title, text)

    def configure(self):
        settings = {"target_host": self.fields["target_host"].get().strip(), "target_port": int(self.fields["target_port"].get()),
                    "receive_host": self.fields["receive_host"].get().strip(), "receive_port": int(self.fields["receive_port"].get())}
        settings.update({key: bool(var.get()) for key, var in self.switches.items()})
        review = self.controller.review("transport", settings=settings)
        if self.confirm("Review OSC transport", readable(review) + "\n\nSaving does not arm controls or install another application."):
            result = self.controller.execute(review)
            self.announce(readable(result))
            self.refresh(force=True)
            return result

    def use_selected_instance(self):
        description = self.controller.discovery.snapshot().get("description")
        if not description or not description.get("osc_host") or not description.get("osc_port"):
            raise ValueError("Select an OSCQuery candidate and wait for its description before using its transport.")
        settings = dict(self.controller.config, target_host=description["osc_host"], target_port=description["osc_port"])
        review = self.controller.review("transport", settings=settings)
        if self.confirm("Review discovered transport", readable(review) + "\n\nDiscovery does not authenticate the service. Saving disconnects any old OSC connection; connect observation only afterward."):
            current = self.controller.discovery.snapshot().get("description")
            if current != description:
                raise ValueError("Discovered instance changed during review. Select it again.")
            result = self.controller.execute(review)
            self.fields["target_host"].set(str(settings["target_host"]))
            self.fields["target_port"].set(str(settings["target_port"]))
            self.announce("Selected instance transport saved. Connect observation only when ready.")
            self.refresh(force=True)
            return result

    def connect(self):
        result = self.controller.connect()
        self.announce("Observation connection requested; writes remain unarmed. " + readable(result, 1200))
        self.refresh(force=True)

    def disconnect(self):
        result = self.controller.disconnect()
        self.announce("OSC disconnect requested; owned cleanup is best effort. " + readable(result, 1200))
        self.refresh(force=True)

    def inspect(self):
        result = self.controller.inspect_query(self.query_url.get().strip())
        self.announce("Read-only metadata inspection requested. " + readable(result, 1200))

    def refresh(self, force=False):
        if self.closed or self.controller is None:
            return
        data = self.controller.snapshot()
        from osc_connection_health import describe
        if data.get('connection_health'):self.details.set(describe(data['connection_health']))
        else:self.details.set(readable({"transport":data.get('transport',{}),'discovery':data.get('discovery',{})},6000))

    def close(self):
        self.closed = True
        return True
