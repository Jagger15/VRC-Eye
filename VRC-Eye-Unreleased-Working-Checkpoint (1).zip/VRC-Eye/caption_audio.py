"""Caption capture ownership and a bounded, cancellable local worker transport."""
import base64
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading

ERRORS={'provider':'Offline speech package unavailable. Restart with the normal launcher to prepare dependencies.',
        'loopback':'Desktop loopback unavailable. Restart with the normal launcher and check the system audio service.',
        'model':'Choose an extracted, compatible local Vosk model folder.',
        'device':'The selected audio endpoint changed or disappeared. Discover and select it again.',
        'recognition':'Speech recognition could not continue. Check the model and audio device, then start again.',
        'format':'The audio device returned an unsupported format.',
        'protocol':'The caption provider returned invalid data. Capture stopped.',
        'source':'Select a supported caption source.'}


def spawn():
    return subprocess.Popen([sys.executable,'-u',str(Path(__file__).with_name('caption_worker.py'))],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),env=dict(os.environ,PYTHONIOENCODING='utf-8'))


def write(process,value):
    process.stdin.write((json.dumps(value,ensure_ascii=True)+'\n').encode('utf-8'));process.stdin.flush()


def dispose(process):
    if process is None:return
    if process.poll() is None:
        process.terminate()
        try:process.wait(timeout=1)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=1)
    for stream in (process.stdin,process.stdout):
        try:stream.close()
        except (OSError,ValueError):pass


def discover_loopbacks(process_factory=spawn):
    process=process_factory()
    try:
        output,_=process.communicate(json.dumps({'mode':'discover'}).encode()+b'\n',timeout=8)
        if len(output)>65536:raise ValueError(ERRORS['protocol'])
        values=[json.loads(line) for line in output.splitlines()]
        if not values or not isinstance(values[-1],dict):raise ValueError(ERRORS['protocol'])
        if values[-1].get('kind')!='devices':raise ValueError(ERRORS.get(values[-1].get('code'),ERRORS['loopback']))
        rows=values[-1]['devices']
        if not isinstance(rows,list) or len(rows)>256:raise ValueError(ERRORS['protocol'])
        for row in rows:
            if not isinstance(row,dict) or set(row)!={'kind','id','name'} or row['kind']!='loopback':raise ValueError(ERRORS['protocol'])
            if any(not isinstance(row[k],str) or not row[k] or len(row[k])>4096 or any(ord(c)<32 for c in row[k]) for k in ('id','name')):raise ValueError(ERRORS['protocol'])
        return rows
    except (KeyError,TypeError,json.JSONDecodeError):raise ValueError(ERRORS['protocol']) from None
    except subprocess.TimeoutExpired:raise ValueError('Desktop audio discovery timed out. Check the audio service or choose an input endpoint.') from None
    finally:dispose(process)


class InputLease:
    """Exclusive private tap; an already running mixer is never stopped on detach."""
    def __init__(self,engine,device,callback,cancel=None):
        self.engine=engine;self.device=device;self.callback=callback;self.owned=False;self.attached=False;self.generation=engine.generation;self.cancel=cancel or threading.Event()
    def start(self):
        engine=self.engine
        if engine.running and engine.active_sources.get('microphone')!=self.device:raise ValueError('The mixer is using another microphone path. Stop it or select the same input before starting captions.')
        self.owned=not engine.running
        engine.set_microphone_tap(self.callback);self.attached=True
        try:
            if self.owned:engine.start({'microphone':self.device},{},meter_only=True,expected_generation=self.generation,capture_owner=self,cancel=self.cancel)
        except Exception:self.close();raise
    def close(self):
        self.cancel.set()
        if self.attached:
            self.engine.clear_microphone_tap(self.callback);self.attached=False
            if self.owned:self.engine.stop_owned(self)
    def valid(self):return self.engine.running and self.engine.generation==self.generation and not self.engine.halt.is_set()


class Session:
    def __init__(self,engine,*,process_factory=spawn):
        self.engine=engine;self.process_factory=process_factory;self.thread=None;self.writer=None;self.process=None;self.lease=None
        self.halt=threading.Event();self.frames=queue.Queue(maxsize=80);self.events=queue.Queue(maxsize=40)
        self.state='Captions stopped.';self.ready=False;self.dropped=False;self.kill_timer=None;self.lock=threading.Lock();self.failure=''
    @property
    def running(self):return bool(self.thread is not None and self.thread.is_alive() or self.process is not None and self.process.poll() is None)
    def tap(self,data,channels):
        if self.halt.is_set():return
        if len(data)>3840 or channels not in (1,2):self.fail('Audio format changed; captions stopped.');return
        try:self.frames.put_nowait((data,channels))
        except queue.Full:self.fail('Caption audio queue overflowed. Capture stopped; start again to resume.')
    def fail(self,text):self.failure=text;self.halt.set();self.terminate()
    def terminate(self):
        with self.lock:
            process=self.process
            if process and process.poll() is None:
                try:process.terminate()
                except OSError:pass
                if self.kill_timer:self.kill_timer.cancel()
                def force():
                    try:
                        if process.poll() is None:process.kill()
                    except OSError:pass
                self.kill_timer=threading.Timer(1,force);self.kill_timer.daemon=True;self.kill_timer.start()
    def start(self,model,source):
        if self.running:raise ValueError('Wait for the previous caption capture to release.')
        folder=Path(model).expanduser().resolve(strict=True)
        if not folder.is_dir():raise ValueError(ERRORS['model'])
        if source.get('kind') not in ('input','loopback'):raise ValueError(ERRORS['source'])
        self.halt=threading.Event();self.frames=queue.Queue(maxsize=80);self.events=queue.Queue(maxsize=40)
        self.ready=False;self.failure='';self.state='Loading local speech model…';self.lease=None
        self.thread=threading.Thread(target=self._run,args=(str(folder),dict(source)),daemon=False,name='Eye captions supervisor');self.thread.start()
    def emit(self,value):
        if self.halt.is_set():return
        try:self.events.put_nowait(value)
        except queue.Full:self.fail('Caption display queue overflowed. Capture stopped; start again to resume.')
    def _write_audio(self,process):
        try:
            while not self.halt.is_set():
                if self.lease and not self.lease.valid():self.fail('The shared input stopped or changed. Captions stopped.');return
                try:data,channels=self.frames.get(timeout=.1)
                except queue.Empty:continue
                write(process,dict(kind='audio',data=base64.b64encode(data).decode('ascii'),channels=channels))
        except (OSError,ValueError):
            if not self.halt.is_set():self.fail('Caption worker stopped accepting audio.')
    def _run(self,model,source):
        process=None
        try:
            if self.halt.is_set():return
            process=self.process_factory()
            with self.lock:self.process=process
            if self.halt.is_set():return
            write(process,dict(mode='capture',model=model,source={k:v for k,v in source.items() if k!='device'}))
            for line in iter(lambda:process.stdout.readline(16385),b''):
                if self.halt.is_set():break
                if len(line)>16384:raise ValueError(ERRORS['protocol'])
                value=json.loads(line);kind=value.get('kind')
                if kind=='error':raise ValueError(ERRORS.get(value.get('code'),ERRORS['recognition']))
                if kind=='ready':
                    if self.ready:raise ValueError(ERRORS['protocol'])
                    if source['kind']=='input':
                        self.lease=InputLease(self.engine,source['device'],self.tap,self.halt);self.lease.start()
                        if self.halt.is_set():break
                        self.writer=threading.Thread(target=self._write_audio,args=(process,),daemon=True,name='Eye caption audio transfer');self.writer.start()
                    self.ready=True;self.state='Live captions · '+('selected desktop audio' if source['kind']=='loopback' else 'selected input')
                elif kind in ('partial','final') and self.ready:
                    self.emit((kind,value['text'],value['start'],value['end']))
                else:raise ValueError(ERRORS['protocol'])
            if not self.halt.is_set():raise ValueError('The caption provider exited. Capture stopped.')
        except Exception as exc:
            if not self.halt.is_set():self.failure=str(exc) if isinstance(exc,ValueError) else 'Caption capture could not start. Check local speech setup and device access.'
        finally:
            self.halt.set();self.ready=False
            if self.lease:self.lease.close()
            try:dispose(process)
            except (OSError,subprocess.TimeoutExpired):self.failure='Caption worker release could not be confirmed.'
            if self.kill_timer:self.kill_timer.cancel();self.kill_timer=None
            if self.writer:self.writer.join(timeout=1)
            with self.lock:
                self.process=process if process is not None and process.poll() is None else None
            self.state=self.failure or 'Captions stopped.'
            self.drain(self.frames)
    @staticmethod
    def drain(mailbox):
        while True:
            try:mailbox.get_nowait()
            except queue.Empty:return
    def retry_release(self):
        process=self.process
        try:
            dispose(process)
            with self.lock:self.process=None
            self.state='Captions stopped.'
        except (OSError,subprocess.TimeoutExpired):self.state='Caption worker release could not be confirmed. Press Stop to retry.'

    def stop(self):
        self.halt.set();self.ready=False;self.state='Stopping captions…' if self.running else 'Captions stopped.'
        if self.lease and self.lease.owned:self.lease.engine.stop_owned(self.lease)
        self.terminate();self.drain(self.events);self.drain(self.frames)
        if self.process is not None and (self.thread is None or not self.thread.is_alive()):
            self.thread=threading.Thread(target=self.retry_release,daemon=False,name='Eye caption release');self.thread.start()
