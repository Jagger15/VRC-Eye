"""Pinned UnityPy type decoding inside the contained bundle worker only.

Own bounded metadata traversal avoids Environment discovery and automatic
AssetBundle parsing. Only allowlisted native data objects are decoded. A
MonoBehaviour/MonoScript/assembly is never deserialized or executed.
"""
from types import SimpleNamespace
import struct
from avatar_bundle_container import engine_version

VERSION='1.25.4'
ALLOWED={1,4,21,23,33,43,137}
MAX_OBJECTS=4096


def preload():
    try:
        import UnityPy
        import lz4.block
        from UnityPy.helpers import TypeTreeHelper,Tpk
        from UnityPy.files.SerializedFile import SerializedType,SerializedFileHeader,FileIdentifier,LocalSerializedObjectIdentifier
        from UnityPy.files.ObjectReader import ObjectReader
        from UnityPy.streams import EndianBinaryReader
        from UnityPy.helpers.UnityVersion import UnityVersion
        if UnityPy.__version__!=VERSION:raise ValueError('Bundle preview requires exactly UnityPy '+VERSION+'.')
        TypeTreeHelper.read_typetree_boost=False
        Tpk.get_typetree();Tpk.get_common_strings()
    except ImportError:raise ValueError('Install requirements-bundles.txt into VRC Eye’s Python environment to enable bundle preview.') from None


def read(data,label,engine):
    from UnityPy.files.SerializedFile import SerializedType,SerializedFileHeader,FileIdentifier,LocalSerializedObjectIdentifier
    from UnityPy.files.ObjectReader import ObjectReader
    from UnityPy.streams import EndianBinaryReader
    from UnityPy.helpers.UnityVersion import UnityVersion
    if len(data)<48 or struct.unpack_from('>I',data,8)[0]!=22 or data[16]!=0:
        raise ValueError('Only little-endian serialized-file version 22 is supported for bundle preview.')
    metadata,size,offset,unknown=struct.unpack_from('>IQQQ',data,20)
    if size!=len(data) or not 1<=metadata<=4*1024**2 or not 48+metadata<=offset<=size or unknown:
        raise ValueError('Invalid or oversized Unity serialized-file header.')
    # The metadata reader cannot reach object payloads, even for malformed counts.
    r=EndianBinaryReader(data[:48+metadata]);header=SerializedFileHeader(r)
    header.endian='<';r.read_bytes(4);r.read_bytes(28)
    header.metadata_size=metadata;header.file_size=size;header.data_offset=offset;r.endian='<'
    version=engine_version(r.read_string_to_null())
    if version!=engine:raise ValueError('Unity bundle and serialized-file versions disagree.')
    platform=r.read_int()
    if platform not in (19,24,13):raise ValueError('Bundle target is not Windows64, Linux64 or Android; this target remains unsupported.')
    tree=r.read_u_byte()
    if tree not in (0,1):raise ValueError('Invalid Unity type-tree flag.')
    asset=SimpleNamespace(name=label,header=header,version=UnityVersion.from_str(version),unity_version=version,target_platform=platform,
        _enable_type_tree=bool(tree),big_id_enabled=0,types=[],objects={},externals=[],ref_types=[])
    def count(limit):
        n=r.read_int()
        if not 0<=n<=limit:raise ValueError('Unity serialized metadata exceeds its count budget.')
        return n
    asset.types=[SerializedType(r,asset,False) for _ in range(count(512))]
    intervals=[]
    for _ in range(count(MAX_OBJECTS)):
        obj=ObjectReader.from_reader(asset,r)
        if not 0<=obj.type_id<len(asset.types) or obj.path_id==0 or obj.path_id in asset.objects or not offset<=obj.byte_start<=size or not 0<obj.byte_size<=size-obj.byte_start:
            raise ValueError('Invalid, duplicate or out-of-file Unity object reference.')
        intervals.append((obj.byte_start,obj.byte_start+obj.byte_size));asset.objects[obj.path_id]=obj
    for _ in range(count(MAX_OBJECTS)):LocalSerializedObjectIdentifier(header,r)
    asset.externals=[FileIdentifier(header,r) for _ in range(count(128))]
    asset.ref_types=[SerializedType(r,asset,True) for _ in range(count(128))]
    r.read_string_to_null()
    if r.Position!=48+metadata:raise ValueError('Unity metadata length differs from its header.')
    ordered=sorted(intervals)
    if any(a[1]>b[0] for a,b in zip(ordered,ordered[1:])):raise ValueError('Overlapping Unity serialized objects are unsupported.')
    # Copy only selected object slices into independent readers. No file handles,
    # environment filesystem, PPtr auto-dereference or object exporter is used.
    decoded={}
    from UnityPy.helpers import Tpk,TypeTreeHelper
    for oid,obj in asset.objects.items():
        if obj.class_id not in ALLOWED:continue
        node=obj.serialized_type.node or Tpk.get_typetree_node(obj.class_id,asset.version)
        raw=data[obj.byte_start:obj.byte_start+obj.byte_size]
        value=TypeTreeHelper.read_typetree(node,EndianBinaryReader(raw,endian='<'),as_dict=True,byte_size=len(raw),check_read=True,assetsfile=None)
        if not isinstance(value,dict):raise ValueError('Unity object decoder returned an unsupported value.')
        decoded[oid]=(obj.class_id,value)
    return asset,decoded
