"""Explicit FBX input-set framing. Only the parent opens user-selected files."""
import json
import struct
from pathlib import Path
from avatar_library_files import checked_stream,check_cancel
from avatar_scene import MAX_BYTES

MAX_EXTERNAL=16*1024**2
MAX_INPUT=MAX_BYTES+MAX_EXTERNAL+16388


def basename(value):
    if not isinstance(value,str) or not 1<=len(value)<=120 or value in ('.','..') or any(c in value for c in '/\\:') or not value.isprintable():
        raise ValueError('Selected FBX textures need unique plain filenames of at most 120 characters.')
    return value


def read(path,limit,stop=None,progress=None):
    with checked_stream(path,limit=limit) as (_,stream,before):
        chunks=[];total=0
        while True:
            check_cancel(stop);block=stream.read(min(1024**2,limit+1-total))
            if not block:break
            total+=len(block)
            if total>limit:raise ValueError('Selected FBX input exceeds its byte limit.')
            chunks.append(block)
            if progress:progress(total,before.st_size)
        if total!=before.st_size:raise ValueError('Selected FBX input changed while reading.')
    return b''.join(chunks)


def stage(paths,stop=None):
    paths=tuple(paths)
    if len(paths)>16:raise ValueError('Select at most 16 external FBX textures.')
    result={};seen=set();total=0
    for path in paths:
        check_cancel(stop);label=basename(Path(path).name)
        if label.casefold() in seen:raise ValueError('Selected FBX texture filenames are ambiguous.')
        seen.add(label.casefold())
        if Path(label).suffix.lower() not in ('.png','.jpg','.jpeg'):raise ValueError('Select PNG/JPEG textures only.')
        raw=read(path,min(8*1024**2,MAX_EXTERNAL-total),stop);total+=len(raw);result[label]=raw
    return result


def pack(source,selected):
    header=json.dumps({'source':len(source),'textures':[(basename(n),len(b)) for n,b in selected.items()]},ensure_ascii=True,separators=(',',':')).encode()
    if len(header)>16384:raise ValueError('FBX input manifest exceeds its limit.')
    return struct.pack('<I',len(header))+header+source+b''.join(selected.values())


def unpack(data):
    if not isinstance(data,bytes) or not 4<=len(data)<=MAX_INPUT:raise ValueError('Invalid FBX input-set size.')
    size=struct.unpack_from('<I',data)[0]
    if not 1<=size<=16384 or 4+size>len(data):raise ValueError('Invalid FBX input manifest.')
    try:
        h=json.loads(data[4:4+size]);pos=4+size;count=h['source'];rows=h['textures']
        if set(h)!={'source','textures'} or type(count) is not int or not 32<=count<=MAX_BYTES or not isinstance(rows,list) or len(rows)>16:raise ValueError('Invalid FBX input manifest.')
        source=data[pos:pos+count];pos+=count
        if len(source)!=count:raise ValueError('Truncated FBX source.')
        selected={};seen=set();total=0
        for label,n in rows:
            basename(label)
            if label.casefold() in seen or type(n) is not int or not 1<=n<=8*1024**2:raise ValueError('Invalid FBX texture entry.')
            seen.add(label.casefold());total+=n
            if total>MAX_EXTERNAL or pos+n>len(data):raise ValueError('FBX texture bytes exceed their input range.')
            selected[label]=data[pos:pos+n];pos+=n
        if pos!=len(data):raise ValueError('Unexpected trailing FBX input bytes.')
        return source,selected
    except (KeyError,TypeError,UnicodeError,json.JSONDecodeError):raise ValueError('Invalid FBX input manifest.') from None
