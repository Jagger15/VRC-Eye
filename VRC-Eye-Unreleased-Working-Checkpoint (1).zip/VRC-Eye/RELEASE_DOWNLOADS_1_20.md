# SDK, VCC and Unity downloads — Development 5

This is a **download-only workspace**, not an installer, project updater, Unity
version resolver, or safety/compatibility certification. The new public-provider
adapters are implemented and fixture-tested. Live provider responses and real
installer downloads could not be exercised in this environment.

## Where to open it

Select **View → Advanced**, then **Advanced → SDK downloads** or **VCC downloads**.
The command palette also has **SDK downloads & Unity archive**, **VCC downloads**,
**Release download history**, and **Release sources and compatibility**.
Each workspace has **Releases**, **Downloads & Activity**, and **Sources & Limits**.
The workspace dropdown provides every section when quick tabs do not fit.

These pages share one service, one local public-metadata cache, and one download
history in the existing companion database. They do not use the VRChat account
transport. Browsing does not require a VRChat account, VCC, Unity, or a bridge.
Opening a page reads cached records only: no metadata fetch, file scan, artifact
transfer, browser handoff, installation or project modification begins.

## SDK package browsing

Choose **Official SDK packages**, then **Load / refresh this page**. This fetches
one approved official repository snapshot and accepts the Base, Avatars and Worlds
package records. Each retained row has an exact package/version/URL identity.
The SDK index is a package/version listing rather than a paged API. The VPM repo
format and package manifest fields are documented by VRChat [R1, R2].

The table shows the version, artifact filename, platform label, declared Unity
version and whether a publisher SHA-256 was supplied. Selecting a row reveals
its exact fields, package dependencies, size/publication fields when supplied,
and an explicit **compatibility not verified** distinction. Dependency strings
are declarations, not a complete resolved graph. Prerelease artifacts are hidden
until **Include prerelease artifacts** is selected.

Name/version/filename/Unity filters and package/platform filters apply to the
**loaded snapshot**. They do not query every release ever published. A filtered
empty view is labeled differently from an empty source. An invalid replacement
response does not discard the prior saved page.

Modern official VPM packages are not a guaranteed complete legacy `.unitypackage`
SDK archive. No historical URLs or missing compatibility results are fabricated.
The **Legacy SDK guidance** browser action is separate [R5]. There is no arbitrary
custom repository or local untrusted release-index import in this checkpoint.

## VCC release browsing

The VCC entry point explicitly reads the public releases list for the publisher's
`vrchat-community/creator-companion` repository [R3, R4]. It accepts published,
uploaded `.exe`, `.msi` and `.zip` artifacts with supported version tags. Drafts,
malformed records, unsupported digests and destinations are rejected. Source-code
archives are not silently substituted for installers.

Pages request up to 100 releases. **Next provider page** is available after a page
reports possible continuation; entering a page shows its cache without fetching
it automatically. The UI never declares a selected or first row the latest safe,
compatible or recommended version. A repository may contain prereleases and may
omit releases distributed elsewhere. Enable prereleases when appropriate; the
empty filtered state explicitly explains this distinction.

**Official VCC stable-download handoff** opens the provider-controlled stable URL
only after a browser review. That URL is not a pinned version in this catalog and
may initiate a browser download. Its bytes and completion are not tracked here.
Windows artifact labels do not imply native Linux VCC desktop support.

## Historical Unity editor patches

In SDK downloads, choose **Unity 2017.4 archive**, **2018.4**, **2019.4** or
**2022.3**. The adapter requests the chosen branch's published patch records using
Unity's documented release API, 25 releases per provider page, ordered by release
date [R6]. Use **Next provider page**, then explicitly load it. This is paged branch
coverage, not a hand-picked latest patch for each branch. No background crawl or
bulk download occurs. The page limit is 100 pages per source.

Exact patch suffixes and available platform/architecture artifact rows remain
visible. Results removed/unpublished by a provider, unsupported files, skipped
records and patches beyond a failed request are not invented. Unity documents
that an empty result may also occur on an error; the adapter preserves the prior
cache rather than treating that as proof that a branch disappeared [R6].

Unity artifacts use **Open selected Unity artifact in browser…**. The review
shows the exact version, platform, filename and approved URL. VRC Eye submits a
browser request only; it does not issue a Hub install URI, run an installer,
verify browser-downloaded bytes or report completion. The SDK/VCC in-app saver
retains its 2 GiB limit instead of silently expanding it for large editors.

Historical availability is not current VRChat compatibility. This checkpoint does
not invent a VCC × SDK × Unity compatibility matrix. Use the current VRChat editor
guidance and selected release notes as separate inputs [R7]. Existing VCC project
inspection and exact-version editor handoff remain separate, reviewed workflows.

## Reviewed SDK/VCC file saving

Select a supported SDK/VCC artifact and choose **Review download…**. Select a new
file outside VRC Eye's application directory and outside a detected Unity project.
The review discloses the exact source/version/URL, destination, last catalog check,
publisher size and publisher SHA-256 when supplied. Approving means **Download
only**. Canceling either dialog does not create a transfer or receipt.

A frozen, one-use review is checked before dispatch and before file commit.
Selection, catalog, account context or operating-mode changes invalidate pending
work. A changed destination parent or an existing file prevents saving. Relative,
parent-traversal, linked and Windows reparse-point paths are refused. Extension
changes are refused. Destination validation is local path checking, not a claim of
protection from a compromised operating system or every hostile local filesystem race.

There is one shared running task across the two entry points. The transfer uses
the existing bounded file saver, streams to a temporary file, checks cancellation,
checks expected length and any supplied publisher SHA-256, then commits exclusively.
It never overwrites an existing file or modifies an original. No downloaded
installer, script, archive or Unity package is executed or extracted.

The saver records a local SHA-256 even when the provider supplies none. The UI
explicitly distinguishes **publisher hash matched** from **local fingerprint
only**. Neither is a malware scan, Authenticode/signature check, provenance proof
independent of the metadata source, or guarantee of compatibility. No automatic
resume, mirror fallback, retry or replacement with another version is performed.

## Network boundaries and failure handling

Metadata and artifact requests use a separate no-cookie/no-auth urllib opener.
VRChat credentials, browser cookies, account tokens and environment proxy
credentials are not copied. Environment proxies are intentionally disabled;
restricted networks may require the reviewed official browser handoffs instead.
HTTPS origin/path/query allowlists and provider-specific redirects are checked;
redirects rebuild a GET rather than copying arbitrary headers. A redirect cannot
silently relabel a different metadata page. SDK/VCC publisher CDN redirects are
supported only on an explicitly started artifact request.

Metadata is bounded to 8 MiB, 200,000 decoded nodes and 24 nesting levels. Duplicate
JSON keys and non-finite constants are refused. SDK snapshots accept up to 5,000
version records. Artifact saves and rechecks are limited to 2 GiB. Metadata has a
90-second read budget; artifact reading has a one-hour budget and a ten-second
per-request socket timeout. Cancellation is cooperative, not instantaneous if a
network read is already waiting. Wrong content types, partial responses, invalid
lengths, oversized/encoded payloads and checksum mismatches fail visibly.

Rate-limit responses establish an in-process provider cooldown (bounded to one
day). There is no automatic retry or background polling. Conditional ETag requests
can reuse a previously validated cached page. Cache timestamps describe the last
successful retrieval/check, not a guarantee that the artifact is still available.

## Receipts, file rechecks and recovery

A durable queued receipt is written **before dispatch**; if that save fails, no
artifact request starts. Outcomes are **Saved**, **Failed**, **Canceled**,
**Interrupted** or **Uncertain**, with explicit explanations rather than an install
success claim. An unexpected provider failure may leave the outcome uncertain.
No ambiguous action is automatically repeated.

The companion database stores up to 2,000 download receipts. Local destination
paths are hidden in the page by default but are present in the local database;
this is not encryption or an application-wide streamer privacy mode. Selecting
**Show private local destination paths** affects only that workspace. An account
change hides them again. Public download history is OS-user scoped, not separate
private VRChat-account history.

**Recheck selected local file** reads only that selected path and compares current
bytes with the recorded/publisher digest. Missing/unavailable, changed/mismatched,
unsafe/unreadable and present-without-a-comparable-digest remain distinct. An
interrupted job whose file now matches still has an unconfirmed original outcome;
this does not silently become successful installation history.

A final database-save failure retains an in-memory receipt and a visible warning.
**Save pending receipts** retries only the local record save, never the download.
Restart recovery marks unfinished durable jobs Interrupted without opening their
files or repeating them. If recovery cannot complete, new downloads are blocked;
**Retry local recovery** retries local record reconciliation after the database
issue is resolved. No file is automatically deleted. A process crash can leave a
temporary or completed file; inspect it explicitly rather than assuming cleanup.

**Export selected receipt…** reviews an allowlisted, path-free JSON report without
account identity, credentials, redirect URLs or raw private error text. Export is
exclusive; existing report files are not overwritten. **Clear completed history…**
removes completed receipts only, keeps downloaded files/caches, and retains
Interrupted and Uncertain outcomes. A full history/backup/reconciliation product
is not claimed by this subset.

Demo/Safe Mode permits cached browsing but blocks the new public requests,
browser handoffs, downloads and history mutations. Existing application startup
and providers are not globally changed by this workspace's mode checks.

## Validation limits and source references

Controlled schemas, HTTP response doubles, real file writes, cancellation and
native Linux/Tk flows were tested. Live metadata endpoints were unreachable from
the build environment. No real SDK package/VCC installer/Unity editor was fetched
or executed. Native Windows, proxy-restricted networks, actual provider CDN
redirects, installed Unity/VPM and screen-reader interoperability remain untested.
This guide is not a claim that a currently reachable live feed was certified.

Documentation retrieved October 2, 2026. It defines the adapter contracts, not
verification of each current hosted artifact:

- [R1 — VRChat VPM repository format](https://vcc.docs.vrchat.com/vpm/repos/)
- [R2 — VRChat VPM package manifests](https://vcc.docs.vrchat.com/vpm/packages/)
- [R3 — GitHub public releases API](https://docs.github.com/en/rest/releases/releases)
- [R4 — Publisher's VCC release page](https://github.com/vrchat-community/creator-companion/releases)
- [R5 — VRChat legacy SDK guidance](https://vcc.docs.vrchat.com/legacy-sdk/)
- [R6 — Unity Releases API](https://docs.unity.com/en-us/oas-release/1.0.0)
- [R7 — VRChat current editor guidance](https://creators.vrchat.com/sdk/upgrade/current-unity-version/)
- [R8 — VCC download/requirements](https://vcc.docs.vrchat.com/)
