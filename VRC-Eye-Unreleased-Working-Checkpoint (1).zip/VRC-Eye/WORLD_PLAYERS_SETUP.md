# World players and visits — VRC Eye 1.18.5

Choose your active VRChat log folder and click **Watch logs**, then open
**World → Players**. This page works without a map, a custom world helper, VRCX,
an exported JSON file, or API sign-in for the basic observed roster and times.
It replays the selected log and follows new entries. **World → Map** contains
the existing layout, calibration, waypoints, and markers.

## World summary

| Field | Source and meaning |
| --- | --- |
| Current world | Name from `Entering Room`, ID from the corresponding `Joining wrld_…` entry. The detected ID also prefills World backups. |
| Players | Active visits observed in this log, including yourself when logged. A fresh helper's total count takes priority. Filters do not change the total. |
| Max players | `capacity` from this world's API metadata. This is the world limit, not a verified instance-specific/group override. `occupants` across all instances and recommended capacity are never substituted. |
| Friends here | Exact active logged `usr_…` IDs matched against the connected account's friend-list snapshot. No display-name guessing or public user-profile polling. |
| Entered | Timestamp of the observed `Entering Room` message. This is a log event, not a measurement of when loading completed. |
| Exited | First observed room-exit message. Missing exits, crashes and closing VRC Eye do not fabricate an exit timestamp. |
| Time in world | Time since the logged entry, frozen at an observed exit. Without an exit, it assumes you are still present; an old selected log can therefore show a long duration. |
| Previous exit | Most recent explicit exit in this log, retained when the next world begins. |

Press **Refresh world / friends** to connect to VRChat and fetch available
metadata. Sign-in uses the existing session-only connection; no new credential
storage is introduced. The friend list contains account IDs only and stays in
memory. The checked timestamps are visible. Disconnect discards the friend
snapshot and stops using its count.

Once connected, a new detected world gets one automatic metadata lookup.
Failures do not repeatedly retry. Use the refresh button to retry or update
friends. The shared metadata queue waits at least 60 seconds between requests;
world and friend refresh can require two requests. **Cancel lookup** stops the
queued work. Changing the world, log session, or connection rejects late results.
No account lookup is automatically sent for every person in the instance.

Unknown identities produce a **known** friend count with an unknown-identity
count. Missing/incomplete logs are labeled as such. If fresh helper and log
totals disagree, the friend count stays unknown. After you leave, both current
occupancy and current friends are unknown: the other people may still be there.
Use the same VRChat account as your game session when you want its friends counted.

## Player columns

Join and leave times come from `OnPlayerJoined` / `OnPlayerLeft` log entries.
Duplicate notifications keep the original time. A leave and subsequent rejoin
create separate rows. A player seen only through an avatar change or helper has
an unknown join time. When you leave, still-present rows become **Session ended**;
their own leave times remain unknown. **Show departed visits** controls history
visibility. This release retains up to 2,000 visits for the current/last observed
world, removing departed history first if that bound is exceeded.

Select a row to open its separate player window and see its full timestamps,
logged user ID, and metadata provenance. **Player window…** reopens that selection;
**My account…** opens your own account editor. See **PLAYER_PROFILE_SETUP.md** for
profile fields, local notes, collections and edits, and **WHISPER_SETUP.md** for
optional paired messaging. Profile lookups run only for explicitly opened windows,
not automatically for every player in the roster.
Times with no timezone in the log use the desktop's local timezone; API checked
times include their UTC offset. History is reconstructed from the log, not saved
as a second player database. The new profile notes/observed-name history are saved
separately by exact account ID; visit history still comes from the log.
Opening a new log or restarting Watch logs rebuilds
it. Avatar **Pause view** does not pause world tracking. Avatar **Clear view**
retains world visits but can clear shared player metadata.

Select a row with a logged account ID and press **Refresh selected player…**
to read its latest platform and public trust tags. Existing exact-ID player
imports remain a fallback. The API's `last_platform` is last known, not guaranteed
current. Neither current platform nor trust is proof of the value at an old
join/leave time. Trust uses the existing current tag mapping; unavailable ranks
remain unknown rather than inventing historical Veteran or Legendary ranks.

| Column | Available behavior |
| --- | --- |
| Platform | PC, Android, or iOS from a platform snapshot; unknown when omitted. |
| VR mode | With fresh updated helper data: PC VR/desktop, Android VR/non-VR, or VR/non-VR with unknown OS. Android VR does not establish Quest branding; non-VR Android does not distinguish phone from tablet. |
| FPS | Your local Unity frame count averaged over the helper's reporting interval. Remote FPS stays Unavailable. This is not a headset reprojection rate. |
| Ping (ms) | Unavailable. Networking replication timing is not substituted for network round-trip ping. |
| Feet | Existing straight-line 3D helper distance. No location or distance is inferred from names or API account metadata. |

## Optional updated world helper

Replace `Unity/World/VRCEyeMapReporter.cs` in a world you can edit, rebuild/upload
the relevant world platforms, and follow **WORLD_MAP_SETUP.md** for Udon logging
and local opt-in. Existing published worlds do not gain these fields until their
creator updates the helper. Old helpers still supply positions; the added fields
stay unknown. PC VRC Eye observes the local PC log; it does not remotely fetch a
mobile client's logs or FPS.

Click **Start helper feed** even if you have no map. Fresh data can supply VR mode,
local FPS and total count on Players. Load/calibrate a map on the Map subtab for
dots. Helper data expires within eight seconds and never erases log history.

The helper uses instance-local IDs, not VRChat account IDs. A helper row is joined
to an active log row only when its display name is unique in both sources and
the world, log source, and observed session time agree. Selected-row details
explicitly label this association as unverified. Ambiguous names stay separate.
Helper-only rows cannot trigger an account lookup. No helper association grants
avatar/world file access or changes backup permissions.

## Sources and validation limits

The log formats were checked against the VRCX project's `Dotnet/LogWatcher.cs`.
World/room line pairs in either order and the `OnPlayerLeftRoom`, `OnLeftRoom`,
and `Successfully left room` exit forms are handled. Name/ID room entries pair
only within 30 seconds; incomplete or different formats may leave fields unknown.

- VRCX parser: https://github.com/vrcx-team/VRCX/blob/master/Dotnet/LogWatcher.cs
- VRChat player API and VR mode: https://creators.vrchat.com/worlds/udon/players/
- VRChat networking statistics: https://creators.vrchat.com/worlds/udon/networking/network-stats/
- Unity frame count: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Time-frameCount.html
- Community-maintained API definitions, world metadata: https://vrchat.community/reference/get-world
- Community-maintained API definitions, signed-in account: https://vrchat.community/reference/get-current-user

Automated validation uses synthetic logs, controlled API responses, actual
temporary-file monitoring and Tk widget substitutes. No live VRChat session,
native Windows rendering, or Unity/Udon compilation was available. See
**VALIDATION.md** for the exact coverage. The app remains an external log reader;
these features do not inject client code or read game memory.
