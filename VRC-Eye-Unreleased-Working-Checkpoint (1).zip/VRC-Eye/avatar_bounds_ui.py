"""Node-local observation UI; Unity renderer corrections belong to the Toolkit."""
from tkinter import filedialog
from companion_ui import button,choice
from friendly_ui import flow_line as line
import avatar_bounds as bounds


class BoundsInspection:
    def __init__(self,controls):
        self.controls=controls;self.panel=controls.panel;self.page=page=controls.page
        self.scene=None;self.report=None;self.pending=False;self.revision=0;self.report_pose=None;self.context=None
        self.settings=None
        self.box=page.ttk.Frame(controls.box)
        page.ttk.Label(self.box,text='Bounds diagnostics',style='Heading.TLabel').pack(anchor='w')
        page.ttk.Label(self.box,text='Compare imported, displayed and sampled geometry in each pose’s node-local space. Unity renderer culling bounds are unavailable in GLB/FBX: use VRC Eye → Renderer Bounds Copies in the Unity Toolkit for root-bone-space diagnostics and reviewed prefab copies.',wraplength=1000).pack(anchor='w')
        row=line(page,self.box);page.ttk.Label(row,text='Mesh node').pack(side='left');self.node=page.tk.StringVar(value='')
        self.node_picker=choice(page,row,self.node,(),self.invalidate,width=45)
        row=line(page,self.box);page.ttk.Label(row,text='Clip scope').pack(side='left');self.clip=page.tk.StringVar(value='Imported/displayed only')
        self.clip_picker=choice(page,row,self.clip,(),self.select_clip,width=45)
        self.variables={};row=line(page,self.box)
        for key,label,value in (('start','Start seconds','0'),('end','End seconds','1'),('count','Samples (1–128)','2')):
            v=page.tk.StringVar(value=value);self.variables[key]=v;page.ttk.Label(row,text=label).pack(side='left');page.ttk.Entry(row,textvariable=v,width=10).pack(side='left')
        row=line(page,self.box);page.ttk.Label(row,text='Per-side margin XYZ (source units)').pack(side='left');self.margins=[]
        for axis in 'XYZ':
            v=page.tk.StringVar(value='0');self.margins.append(v);page.ttk.Label(row,text=axis).pack(side='left');page.ttk.Entry(row,textvariable=v,width=9).pack(side='left')
        page.ttk.Label(self.box,text='The proposal includes imported and displayed geometry plus the listed samples, with the entered margins. It makes no claim about unsampled motion, procedural deformation or FPS. Use the Unity workflow for explicit bounds corrections; this desktop view changes no renderer.',wraplength=1000).pack(anchor='w',pady=4)
        row=line(page,self.box);button(page,row,'Inspect selected scope',self.inspect);button(page,row,'Review and export observation…',self.export)
        button(page,row,'Close bounds diagnostics',self.hide)
        self.detail=page.tk.StringVar(value='Choose a scope and inspect explicitly.');page.ttk.Label(self.box,textvariable=self.detail,wraplength=1000,justify='left').pack(anchor='w',pady=5)
        self.nodes={};self.clips={}

    def invalidate(self):
        self.revision+=1;self.report=None;self.report_pose=None
        self.settings=None
        if self.pending and self.page.job:self.page.cancel()
        self.pending=False;self.detail.set('Selection changed. Inspect the scope again.')

    def show(self):
        self.controls.require();self.invalidate();c=self.controls
        self.scene=c.timeline.source if c.timeline and c.timeline.source and c.timeline.original is c.scene else c.scene
        self.nodes={f'{n.index}: {n.name}':n.index for n in self.scene.nodes if any(p.node==n.index for p in self.scene.parts)}
        self.node_picker.configure(values=tuple(self.nodes));selected=c.selected_or_none()
        self.node.set(next((k for k,v in self.nodes.items() if v==selected),next(iter(self.nodes),'')))
        clips=self.scene.animations.clips if self.scene.animations else ()
        self.clips={'Imported/displayed only':None}|{f'{i+1}: {clip.name}'+(' (unavailable)' if clip.reason else ''):i for i,clip in enumerate(clips)}
        self.clip_picker.configure(values=tuple(self.clips));self.clip.set('Imported/displayed only');self.box.pack(fill='both',expand=True,pady=8)

    def select_clip(self):
        self.invalidate();i=self.clips.get(self.clip.get())
        if i is not None:
            c=self.scene.animations.clips[i];self.variables['start'].set(str(c.start));self.variables['end'].set(str(c.end));self.variables['count'].set('1' if c.start==c.end else '16')

    def inspect(self):
        self.controls.require();self.panel.require();c=self.controls
        if self.scene is None or self.scene.sha256!=c.scene.sha256:raise ValueError('Reopen bounds diagnostics for the current scene.')
        if self.clip.get() not in self.clips or self.node.get() not in self.nodes:raise ValueError('Select a listed mesh node and clip scope.')
        if c.timeline:c.timeline.pause()
        self.invalidate();revision=self.revision;original=c.scene;displayed=c.display_scene;context=self.panel.context();clip=self.clips[self.clip.get()]
        try:
            margin=tuple(float(v.get()) for v in self.margins)
            opts={} if clip is None else dict(start=float(self.variables['start'].get()),end=float(self.variables['end'].get()),count=int(self.variables['count'].get()))
        except ValueError:raise ValueError('Enter numeric seconds/margins and an integer sample count.') from None
        scene=self.scene;node=self.nodes[self.node.get()];settings=self.selection();self.pending=True;self.detail.set('Sampling the selected bounds scope…')
        def done(result):
            if revision!=self.revision:return
            self.pending=False
            if self.panel.closed or original is not c.scene or displayed is not c.display_scene or context!=self.panel.context() or settings!=self.selection():
                self.detail.set('Scope or pose changed while sampling. Inspect again.');return
            self.report=result;self.report_pose=displayed;self.context=context;self.settings=settings;self.detail.set(bounds.describe(result))
        try:self.page.start_task(lambda stop,progress:bounds.inspect(scene,node,displayed=displayed,clip=clip,margin=margin,stop=stop,progress=progress,**opts),done,operation='Bounds observation')
        except Exception:self.pending=False;raise

    def require_report(self):
        self.controls.require();self.page.writable()
        if self.report is None or self.context!=self.panel.context() or self.report_pose is not self.controls.display_scene or self.settings!=self.selection():raise ValueError('The source, pose, settings or context changed. Inspect bounds again before export.')
        return self.report

    def selection(self):
        return self.node.get(),self.clip.get(),tuple(v.get() for v in self.variables.values()),tuple(v.get() for v in self.margins)

    def export(self):
        report=self.require_report();text=bounds.document(report)
        if not self.page.review('Export bounds observation?',text,'Choose new report file'):return
        if self.require_report() is not report:raise ValueError('Bounds review changed.')
        path=filedialog.asksaveasfilename(parent=self.page.app.root,title='New bounds observation',initialfile='avatar-bounds-observation.json',defaultextension='.json',filetypes=(('JSON report','*.json'),))
        if self.require_report() is not report:raise ValueError('Bounds review changed.')
        if path:bounds.export(report,path);self.page.status.set('Exported the reviewed bounds observation; no renderer or source was modified.')

    def hide(self):
        self.invalidate();self.scene=None;self.nodes={};self.clips={};self.node.set('');self.clip.set('');self.node_picker.configure(values=());self.clip_picker.configure(values=());self.box.pack_forget()

    def clear(self):self.hide();self.detail.set('No bounds observation retained.')
