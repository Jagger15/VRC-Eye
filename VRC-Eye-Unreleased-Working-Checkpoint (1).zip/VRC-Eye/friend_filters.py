"""Saved account-local location filters and explicit pinning; no API requests."""
import json
import unicodedata
from companion_data import entity_id

KEY='friends.locations.filters.v1.'
PRESENCES=('All','In game','Website / app','Offline','Unknown / other')
PLATFORMS=('All','PC','Android','iOS','Website','Unknown / other')
DEFAULTS=dict(friend='',world='',presence='All',platform='All',collection=None,pin_watched=True,pins=[])


def normalized(text):return unicodedata.normalize('NFKC',str(text or '')).casefold()


def settings(value,account):
    if value is None:return dict(DEFAULTS,pins=[])
    if not isinstance(value,dict) or set(value)!=set(DEFAULTS):raise ValueError('Unsupported friend-location filters.')
    d=dict(value)
    for key in ('friend','world'):
        if not isinstance(d[key],str) or len(d[key])>200 or any(ord(c)<32 for c in d[key]):raise ValueError('Use a filter of up to 200 characters.')
        d[key]=d[key].strip()
    if d['presence'] not in PRESENCES or d['platform'] not in PLATFORMS or type(d['pin_watched']) is not bool:raise ValueError('Choose supported presence and platform filters.')
    if not isinstance(d['pins'],list) or len(d['pins'])>100:raise ValueError('Pin up to 100 friends.')
    d['pins']=list(dict.fromkeys(entity_id('user',v) for v in d['pins']))
    c=d['collection']
    if c is not None:
        from native_library import identifier
        if not isinstance(c,dict) or set(c)!={'scope','target'} or c['scope'] not in (account,'shared'):raise ValueError('Choose a local friend collection for this account or Shared.')
        d['collection']=dict(scope=c['scope'],target=identifier(c['target']))
    return d


def collection_members(store,targets):
    """Bounded common membership projection for filters and watchlist rules."""
    members={}
    for scope,target in targets:
        row=store.native.get(scope,'collection',target)
        if row and row['data'].get('entity_kind')=='friend':members[(scope,target)]=set()
    with store.native.connect() as db:
        for scope in {s for s,_ in members}:
            for raw, in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='membership' ORDER BY id LIMIT 20000",(scope,)):
                d=json.loads(raw);target=members.get((scope,d.get('collection')))
                if target is not None and str(d.get('entity','')).startswith('friend:'):target.add(d['entity'][7:])
    return members


def presence(row):
    state=row.get('state')
    if state=='offline' or row.get('location')=='offline':return 'Offline'
    if state=='online':return 'In game'
    if state in ('active','active on website'):return 'Website / app'
    return 'Unknown / other'


def platform(row):
    value=normalized(row.get('platform') or row.get('last_platform'))
    return {'standalonewindows':'PC','standalonelinux':'PC','standaloneosx':'PC','android':'Android','ios':'iOS','web':'Website'}.get(value,'Unknown / other')


def filter_friends(rows,worlds,filters,*,members=None,watched=()):
    from friend_activity import shared_location
    known={w.id:w.name for w in worlds if w.kind=='world'};selected=filters['collection']
    allowed=(members or {}).get((selected['scope'],selected['target']),set()) if selected else None
    friend_terms=normalized(filters['friend']).split();world_terms=normalized(filters['world']).split()
    pinned=set(filters['pins']);priority=pinned|set(watched) if filters['pin_watched'] else pinned
    result=[]
    for row in rows:
        ref=row['id']
        if allowed is not None and ref not in allowed:continue
        name=normalized(str(row.get('displayName') or '')+' '+ref)
        if any(term not in name for term in friend_terms):continue
        location,label=shared_location(row);world=location.split(':',1)[0] if location else ''
        haystack=normalized(world+' '+known.get(world,'')+' '+label)
        if any(term not in haystack for term in world_terms):continue
        if filters['presence']!='All' and presence(row)!=filters['presence']:continue
        if filters['platform']!='All' and platform(row)!=filters['platform']:continue
        result.append(row)
    return sorted(result,key=lambda r:(r['id'] not in priority,normalized(r.get('displayName') or r['id']),r['id'])),priority
