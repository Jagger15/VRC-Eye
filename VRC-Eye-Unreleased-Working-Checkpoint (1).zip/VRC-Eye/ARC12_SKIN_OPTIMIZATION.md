# ARC-12 — conservative skin influence reduction

Initial implementation; **partial**. Build `2026.05.10.02.47.1` and compatibility version `1.21.0` remain unchanged. This checkpoint contains source, not a new installer or compiled desktop executable.

## Desktop trial

Open an authorized supported model in Avatar Library → Preview, then choose **Skin influence trial…** beneath the scene hierarchy. Choose a skinned node, a cap of 1–4 influences, a maximum error in source units, and optionally a decoded animation clip/range. **Measure reduction** compares the imported pose and the exact listed clip samples. It does not include the current manual preview pose or alter the displayed model.

For each vertex, positive weights are sorted by descending weight with bone-index tie breaking, truncated to the selected cap and renormalized. The trial applies the original morph deltas and the same pose matrices to both weight sets. It reports stored influence counts, vertices reduced, maximum Euclidean position error, RMS position error, worst part/vertex for each pose, and whether the measured maximum meets the entered tolerance. Aggregate RMS weights each sampled vertex equally. Coordinates are source world coordinates; source units are not assumed to be metres. The tolerance is a user-selected observation threshold, not a recommended quality level.

Export is separately reviewed, JSON-only and exclusive: existing files and link paths are refused. The report identifies the original source snapshot hash and explicitly records that no model asset was created, no runtime was profiled and no dependency proof was established. Selection, account, privacy, Safe Mode, closing, cancellation and changed settings invalidate results at the relevant worker/modal boundaries.

This supports decoded four-slot skin data and transform/morph animation tracks, including the supported GLB subset. Baked FBX frames cannot evaluate edited influences and are refused. Importer format support does not imply editable skin support. Sampling is bounded to 128 selected clip times plus the imported pose, four million before/after vertex visits and 15 seconds, with cooperative cancellation. Other existing import/pose budgets still apply.

## Unity mesh copies

The Toolkit menu **VRC Eye → Skin Influence Copies** supplies a Unity 2022.3 editor workflow. It has **not been compiled or run in Unity in this environment**. Run the supplied EditMode tests and qualify an authorized creator fixture before relying on it.

1. Select a saved `.prefab` root under `Assets` and one readable skinned renderer. The mesh must be saved, have 1–200,000 vertices, 1–4 stored positive influences per vertex, matching bind-pose/bone slots and matching ordered material/submesh slots. An explicit internal root bone is required. Names and component correspondence must meet the existing bounds sampler's strict constraints.
2. The prefab may contain only Transform, MeshFilter, MeshRenderer and SkinnedMeshRenderer components. Unknown scripts, missing components, Animator, cloth, constraints and other dynamic components block editing. The tool does not strip them. Use a separately prepared data-only source when appropriate; this does not qualify the original avatar's runtime behavior.
3. Set the influence cap, error threshold and up to eight explicit transform/blendshape clip ranges. Data-only temporary objects sample the imported pose and each declared time. No Animator, animation events, controllers or inspected behaviours execute. Unsupported bindings, humanoid clips and object swaps are refused. The temporary renderer uses Bone4 to compare every stored weight regardless of the source renderer/project quality. Multi-frame blendshapes remain on the cloned mesh, and sampled blendshape weights are restored across each mesh swap.
4. Review maximum/RMS position error in source world units, exact times, ignored events, quality settings and limits. Up to 257 poses and eight million baked vertex visits are permitted, with a 20-second measurement budget. No-op reductions are refused. A maximum error over the selected threshold prevents copy creation.
5. Confirm to create **only a new mesh asset plus the reviewed text** beneath an exclusive `Assets/VRC Eye Repairs` folder. Source prefabs, meshes, hierarchy, material slots and animation references are never reassigned. Manual assignment is a separate action outside this workflow.

Mesh comparison checks positions, normals, tangents, colours, UV0–UV7, non-skin vertex descriptors, bounds, ordered submesh topology/indices, bind poses, and every blendshape name/frame weight/position/normal/tangent delta. Only skin influence storage may change. Layouts which change unrelated streams are refused. The actual stored candidate is sampled, so weight storage precision changes contribute to measured error. Saved/reimported output must match the measured mesh evidence.

Preparation binds the loaded hierarchy, mesh, selected clip ranges, dependency bytes/metadata and project context; copies recheck that evidence around imports. Reviews expire after five minutes and are invalidated by cancellation or changed window context. Existing project import callbacks can run. Source or output changes interrupt the operation; retained partial outputs remain journaled. ARC-19 copy history's `Completed; no assignment` phase is the completion authority; an output or report file alone does not establish success. These checks do not OS-lock project files against a hostile concurrent process.

## Coverage and remaining work

| Acceptance concern | Implemented subset | Remaining qualification or scope |
| --- | --- | --- |
| Consistent skin and mesh correspondence | Stable reduction; bind poses and all supported non-skin mesh data preserved; new mesh only | Native import/serialization, real creator fixtures and assigned-renderer deformation/shading acceptance |
| Maximum/RMS deformation comparison | Exact declared pose set, per-sample and aggregate position metrics | Normals/tangents, between-sample motion, procedural/shader deformation and target runtime behavior |
| Unknown dynamic dependencies | Native copy path rejects all components outside a narrow data-only allowlist | Broader component/controller dependencies, other Unity versions, external runtime consumers |
| Original assets and separate assignment | No original writes or assignments; reviewed exclusive output and ARC-19 history | Native callback, domain reload, filesystem and graphical desktop acceptance |
| Performance claims | Influence counts reported as counts; no speed/memory claim | Supported-target CPU/GPU/memory profiling with comparable fixtures |
| Bone pruning and renderer consolidation | No deletion or merging; unweighted slots labeled observations | Complete dependency proof and compatible consolidation are not implemented |

**Zero weights are not proof a bone is unused.** A transform may drive children, animation, physics, constraints or scripts. Likewise, finite sampled position equivalence cannot certify every runtime pose, shader or shading result. Higher-than-four stored influences are outside the initial reduction path.

ARC-12 was the last separately missing ARC area in the current partial-completion ledger. With this initial implementation, it becomes partial: **22 partial ARC areas, zero separately missing ARC areas, and 24 open VRCX partial-area records**. No broad ARC or VRCX area is newly certified end to end. Older development gap ledgers are historical; use `PARTIAL_COMPLETION_STATUS.json` and `ARC_QUALIFICATION_STATUS.json` for this checkpoint's scope.

## Validation

Portable numerical, immutable-source, selection/cancellation and export tests are in `tests/test_skin_optimization_arc12.py` and `tests/test_skin_optimization_ui_arc12.py`. The focused run also covers existing rig, bounds and animation paths. See `validation/arc12-summary.json` for recorded counts, the exact offline regression command, excluded transport modules and skips. Headless widget tests are not graphical desktop acceptance.

Thirteen new Unity EditMode methods are supplied in `Unity/AvatarToolkit/Tests/EyeSkinInfluenceTests.cs`, bringing the supplied Toolkit total to 111, all unrun here. They cover analytic errors under negative/nonuniform scale, quality override isolation, multi-frame blendshape sampling, source/copy preservation, stable ties, error thresholds, unknown components, correspondence, canceled/stale plans, ignored events and source/output import-callback mutations. C# syntax parsing is not compilation or Unity execution.

API references consulted: [Unity 2022.3 GetAllBoneWeights](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.GetAllBoneWeights.html), [SetBoneWeights](https://docs.unity.cn/ScriptReference/Mesh.SetBoneWeights.html), [renderer quality](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/SkinnedMeshRenderer-quality.html), and [BakeMesh](https://docs.unity.cn/2022.3/Documentation/ScriptReference/SkinnedMeshRenderer.BakeMesh.html). No upstream ARC binary or proprietary optimization implementation was copied.
