"""Single-writer disk-backed Black Box ring and atomic incident preservation.

SQLite WAL is the append journal; FULL synchronous commits and per-record checksums
preserve committed evidence across interruption. The writer also holds an OS lock.
"""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import sqlite3
import time
import uuid

from crash_model import ID,WORLD,analyze,checksum,record,serialize,settings,validate_record

MAX_RECORDS=10000
ACTIVE_BYTES=16*1024**2
TOTAL_BYTES=64*1024**2


class OwnerLock:
    def __init__(self,path):self.path=Path(path);self.file=None
    def acquire(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('a+b')
        try:
            if os.name=='nt':
                import msvcrt
                self.file.seek(0);self.file.write(b'0');self.file.flush();self.file.seek(0)
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close();self.file=None
            raise ValueError('Another VRC Eye recorder owns this Black Box. Close it before enabling a second recorder.') from None
    def close(self):
        if self.file:self.file.close();self.file=None


class BlackBoxStore:
    def __init__(self,directory,config=None,wall=time.time):
        self.directory=Path(directory);self.path=self.directory/'blackbox.sqlite3';self.config=settings(config);self.wall=wall
        self.owner=OwnerLock(self.directory/'writer.lock');self.db=None;self.run=None;self.seq=0;self.last_trim=0;self.recovered=None
    def open(self,at,wall,recording=True):
        self.owner.acquire()
        try:
            self.db=sqlite3.connect(self.path,timeout=.5)
            self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL');self.db.execute('PRAGMA wal_autocheckpoint=128')
            self.db.execute('PRAGMA max_page_count=32768');self.db.execute('PRAGMA secure_delete=ON')
            self.db.executescript('''
                CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS active(seq INTEGER PRIMARY KEY,at REAL NOT NULL,wall REAL NOT NULL,data TEXT NOT NULL,hash TEXT NOT NULL,size INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS incidents(id TEXT PRIMARY KEY,created REAL NOT NULL,reason TEXT NOT NULL,summary TEXT NOT NULL,world TEXT NOT NULL DEFAULT '');
                CREATE TABLE IF NOT EXISTS evidence(incident TEXT NOT NULL,seq INTEGER NOT NULL,at REAL NOT NULL,wall REAL NOT NULL,data TEXT NOT NULL,hash TEXT NOT NULL,size INTEGER NOT NULL,PRIMARY KEY(incident,seq));
                CREATE INDEX IF NOT EXISTS evidence_incident ON evidence(incident);
            ''')
            schema=self.db.execute("SELECT value FROM state WHERE key='schema'").fetchone()
            if schema and schema[0]!='1':raise ValueError('Unsupported Black Box database schema; no migration was attempted.')
            self.prune()
            old=self.db.execute("SELECT value FROM state WHERE key='run'").fetchone()
            clean=self.db.execute("SELECT value FROM state WHERE key='clean'").fetchone()
            if old and (not clean or clean[0]!='1') and self.db.execute('SELECT 1 FROM active LIMIT 1').fetchone():
                self.recovered=self.preserve('unclean_stop',incident_id=old[0])
            if not recording:
                with self.db:self.db.execute("INSERT OR REPLACE INTO state VALUES('clean','1')")
                return self.recovered
            self.begin(at,wall)
            return self.recovered
        except Exception:self.close(clean=False);raise
    def begin(self,at,wall):
            self.run=uuid.uuid4().hex;self.seq=0
            with self.db:
                self.db.execute('DELETE FROM active')
                for key,value in (('schema','1'),('run',self.run),('clean','0')):
                    self.db.execute('INSERT OR REPLACE INTO state VALUES(?,?)',(key,value))
            self.append('start','recorder',{},at,wall)
    def pause(self,at,wall):
        if self.run:
            self.append('stop','recorder',{'clean_exit':True},at,wall)
            with self.db:self.db.execute("INSERT OR REPLACE INTO state VALUES('clean','1')")
            self.run=None
    def append(self,kind,source,payload,at,wall,confidence='direct'):
        self.seq+=1;r=record(self.seq,self.run,at,wall,kind,source,payload,confidence);data=serialize(r)
        if len(data.encode())>32768:raise ValueError('Diagnostic record exceeds 32 KiB.')
        with self.db:self.db.execute('INSERT INTO active VALUES(?,?,?,?,?,?)',(r['seq'],at,wall,data,checksum(r),len(data.encode())))
        if at-self.last_trim>=5:self.trim(at);self.last_trim=at
        return r
    def trim(self,at):
        with self.db:
            self.db.execute('DELETE FROM active WHERE at<?',(at-self.config['window_minutes']*60,))
            self.db.execute('DELETE FROM active WHERE seq <= COALESCE((SELECT seq FROM active ORDER BY seq DESC LIMIT 1 OFFSET ?),-1)',(MAX_RECORDS,))
            total=self.db.execute('SELECT COALESCE(SUM(size),0) FROM active').fetchone()[0]
            if total>ACTIVE_BYTES:
                for seq,size in self.db.execute('SELECT seq,size FROM active ORDER BY seq').fetchall():
                    if total<=ACTIVE_BYTES:break
                    self.db.execute('DELETE FROM active WHERE seq=?',(seq,));total-=size
        self.prune()
    def prune(self):
        if not self.db:return
        rows=self.db.execute('SELECT id,created FROM incidents ORDER BY created DESC,id').fetchall()
        with self.db:
            for index,(ref,created) in enumerate(rows):
                if self.config['retain_days'] and created<self.wall()-self.config['retain_days']*86400 or self.config['max_incidents'] and index>=self.config['max_incidents']:
                    self.db.execute('DELETE FROM evidence WHERE incident=?',(ref,));self.db.execute('DELETE FROM incidents WHERE id=?',(ref,))
    @staticmethod
    def decode(rows):
        records=[];damaged=0;previous=None;gaps=0
        for data,expected in rows:
            try:
                if len(data)>32768:raise ValueError()
                value=json.loads(data);validate_record(value)
                if checksum(value)!=expected:raise ValueError()
                if previous is not None and value['seq']!=previous+1:gaps+=1
                previous=value['seq'];records.append(value)
            except (ValueError,KeyError,TypeError,RecursionError):damaged+=1
        return dict(records=records,damaged=damaged,sequence_gaps=gaps)
    def active(self):return self.decode(self.db.execute('SELECT data,hash FROM active ORDER BY seq LIMIT ?',(MAX_RECORDS,)))
    def preserve(self,reason='manual',world='',incident_id=None):
        if reason not in ('manual','process_exit','hang','unclean_stop','log_crash'):raise ValueError('Unsupported incident reason.')
        ref=incident_id or uuid.uuid4().hex
        if not ID.fullmatch(ref):raise ValueError('Invalid incident identifier.')
        if self.db.execute('SELECT 1 FROM incidents WHERE id=?',(ref,)).fetchone():return ref
        self.prune();data=self.active()
        if not data['records']:raise ValueError('There is no valid Black Box evidence to preserve yet.')
        total=self.db.execute('SELECT COALESCE(SUM(size),0) FROM evidence').fetchone()[0]
        size=self.db.execute('SELECT COALESCE(SUM(size),0) FROM active').fetchone()[0]
        if total+size>TOTAL_BYTES:raise ValueError('Incident storage budget reached. Delete or export old incidents before preserving more.')
        summary=analyze(data['records'],reason,data['damaged']);summary['sequence_gaps']=data['sequence_gaps']
        world=world if self.config['remember_world'] and WORLD.fullmatch(world or '') else ''
        with self.db:
            self.db.execute('INSERT INTO incidents VALUES(?,?,?,?,?)',(ref,self.wall(),reason,serialize(summary),world))
            self.db.execute('INSERT INTO evidence SELECT ?,seq,at,wall,data,hash,size FROM active',(ref,))
        self.prune();return ref
    def add_os_evidence(self,ref,events):
        data=self.load(ref);seq=max((r['seq'] for r in data['records']),default=0)
        last=data['records'][-1] if data['records'] else None
        if not last:return
        # OS events have their own wall timestamps; monotonic placement is an estimate.
        with self.db:
            for event in events[:64]:
                seq+=1;stamp=event['wall'];at=max(0,last['at']+stamp-last['wall'])
                r=record(seq,last['run'],at,stamp,'os.evidence','windows',event['payload'],'high');raw=serialize(r)
                self.db.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?)',(ref,seq,at,stamp,raw,checksum(r),len(raw)))
        data=self.load(ref);summary=analyze(data['records'],data['reason'],data['damaged'])
        with self.db:self.db.execute('UPDATE incidents SET summary=? WHERE id=?',(serialize(summary),ref))
    def list(self):
        rows=[]
        for ref,created,reason,summary in self.db.execute('SELECT id,created,reason,summary FROM incidents ORDER BY created DESC LIMIT 100'):
            try:summary=json.loads(summary)
            except ValueError:summary={}
            rows.append(dict(id=ref,created=created,reason=reason,title=summary.get('title','Incident unavailable'),confidence=summary.get('confidence','unknown'),signature=summary.get('signature','')))
        return rows
    def load(self,ref):
        if not ID.fullmatch(ref):raise ValueError('Invalid incident identifier.')
        row=self.db.execute('SELECT reason,world,created FROM incidents WHERE id=?',(ref,)).fetchone()
        if not row:raise ValueError('Incident no longer exists.')
        data=self.decode(self.db.execute('SELECT data,hash FROM evidence WHERE incident=? ORDER BY seq LIMIT ?',(ref,MAX_RECORDS+64)))
        return dict(data,id=ref,reason=row[0],world=row[1],created=row[2],summary=analyze(data['records'],row[0],data['damaged']))
    def delete(self,ref):
        if not ID.fullmatch(ref):raise ValueError('Invalid incident identifier.')
        with self.db:self.db.execute('DELETE FROM evidence WHERE incident=?',(ref,));self.db.execute('DELETE FROM incidents WHERE id=?',(ref,))
    def forget_worlds(self):
        with self.db:self.db.execute("UPDATE incidents SET world=''")
    def status(self):
        count,first,last,total=self.db.execute('SELECT COUNT(*),MIN(at),MAX(at),COALESCE(SUM(size),0) FROM active').fetchone()
        return dict(records=count,seconds=max(0,last-first) if first is not None else 0,active_bytes=total,
                    incidents=self.db.execute('SELECT COUNT(*) FROM incidents').fetchone()[0])
    def close(self,clean=True):
        try:self._close(clean)
        finally:self.owner.close()
    def _close(self,clean):
        if self.db:
            try:
                if clean and self.run:
                    self.append('stop','recorder',{'clean_exit':True},time.monotonic(),self.wall())
                    with self.db:self.db.execute("INSERT OR REPLACE INTO state VALUES('clean','1')")
                self.db.execute('PRAGMA wal_checkpoint(PASSIVE)')
            finally:self.db.close();self.db=None
        self.owner.close()
