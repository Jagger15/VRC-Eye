# VRC Eye 1.21.0 — Development 10

Extract the complete ZIP, then run **Start.cmd** on Windows or **Start.sh** on
Linux. Existing launchers and dependencies are unchanged. This is a source
checkpoint; the ZIP includes the complete Development 9 baseline.

## Feed → Locations

Friends are grouped into world cards, then exact shared instances. Select a
card to expand its instances and friend list. Known world thumbnails are used;
missing world details queue through the existing background metadata worker
while this tab is visible. The shared one-request-per-minute metadata budget
still applies, and the initial catch-up takes priority. This can take several
minutes. At most 100 location groups are displayed; the heading reports the
shown and total counts.

Private locations, offline friends, traveling and unavailable locations have
separate groups. Counts represent observed friends, not instance occupancy.
Each expanded friend retains the sync owner's freshness label. Stale or private
observations never establish access. Join nonces are removed from group keys
and handoffs.

**Player profile** opens the existing player view. **Watch selected friend**
prefills the watch form. **Inspect / invite to selected instance** prefills
World Visits. Inspect and review there before sending an invitation or joining;
selecting a card sends no action.

## Feed → Watchlists

Choose one friend ID or an existing local friend collection, choose Online,
Status and/or Location, then **Save watch**. Up to 50 rules are saved per signed-in
account. Collections may belong to that account or Shared. Collection membership
is refreshed at most every 30 seconds, with a bounded 20,000-membership scan per
scope; huge collections beyond that coverage are not claimed as complete.

Rules are opt-in. Online alerts use live friend-online reports and suppress an
unchanged online observation. Status and location alerts compare a fresh prior
observation (less than ten minutes old). Snapshot catch-up does not generate
watchlist alerts. Overlapping friend/collection rules do not duplicate a change.

Delivery uses the existing SOCIAL ownership, quiet hours, Do Not Disturb,
batching, cooldowns, banners, sound and optional speech/VR settings. Location
alerts do not include the raw world/instance reference. The latest 200 watchlist
observations remain visible in this session even when delivery was silenced.
Account/privacy changes clear the session list and pending delivery. Removing a
watch also clears queued watchlist delivery. Nothing is sent to another user.

## Feed → Reconnect recap

The recap compares up to 1,000 saved/pre-gap friend observations with observations
received after restart, reconnect, pause or sleep. It lists presence, status,
status text and shared-location differences, and labels newly observed friends.
It updates during catch-up and reports checked and unrechecked observations.

The report compares endpoints. It cannot replay missed events, assign change
times, or establish intermediate locations. A friend absent from a received
page is not assumed offline. Results dispatched before the gap are excluded
from the recap; partial or failed friend pages remain reported as incomplete.
The current recap is session-only and cleared at account/privacy boundaries.

## Search pictures

The reproduced cache-search defect discarded `image_url` and
`thumbnail_image_url` while constructing avatar results. Both optional columns
now reach the shared card loader, while older caches still work without them.
Cached image metadata never creates a usable API avatar/asset lookup.

The loader tries the thumbnail followed by other supplied VRChat image URLs,
including the full image. AVTRdb results preserve both preview fields. Legacy
API image routes resolve on the current cookie origin. Binary image responses
are accepted only after bounded image decoding; arbitrary hosts, API routes,
credential-bearing links, excessive data and non-image content remain rejected.
Images use the current application's User-Agent and base64 PNG data for Tk.

After a failure, one automatic retry occurs after 30 seconds while the view is
active. **Retry pictures** can retry remaining failures without clearing loaded
pictures or selection (five-second click limit). The standalone avatar search,
main Search and Global quick search share this behavior. Privacy/account changes
discard stale completions; Offline mode cancels in-flight image loading.
VRChat preview loading still requires a connected account, even for cache search.

## Validation and scope

See [validation](VALIDATION_1_21.md) for executed tests and limitations. Offline
tests cover transport and preview fallback, real headless page callbacks,
account isolation, shared scheduling, watch delivery and recap semantics.
Native Windows/Linux rendering and live VRChat images/events remain unverified.

The optional updater remains preparation-only; see
[the updater plan](UPDATER_PLAN_DEV10.md). Full VRCX parity is not claimed.
