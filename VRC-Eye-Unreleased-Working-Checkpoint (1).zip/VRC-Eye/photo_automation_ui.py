"""Photos source watching and reusable contact-sheet controls."""
from __future__ import annotations

import json
from account_actions import local_writable
from avatar_library_ui import StableTable
from companion_ui import button,entry,choice
from friendly_ui import flow_line
from photo_composite import layout,slots,geometry,MAX_SLOTS,LAYOUTS
from photo_files import normalize_recipe
from photo_watch import watcher_for


class PhotoAutomationUI:
    def build_watching(self,parent):
        self.watcher=watcher_for(self.shell);self.watch_revision=self.watcher.revision
        self.watch_interval=self.tk.StringVar(value='30');self.watch_caption=self.tk.StringVar()
        row=flow_line(self,parent)
        self.ttk.Label(row,text='Watch interval (seconds)').pack(side='left',padx=4)
        choice(self,row,self.watch_interval,('10','30','60','300'),width=7)
        button(self,row,'Enable / resume watching…',self.enable_watch)
        button(self,row,'Pause selected watch',self.pause_watch)
        self.label(parent,'Watching is optional and remembered per workspace. It reconciles existing and new photos while VRC Eye runs, including when this page is closed. Files need two stable observations. Pause a source before a long manual photo task. No system background service is installed.')
        from ui_theme import responsive_wrap
        responsive_wrap(self.ttk.Label(parent,textvariable=self.watch_caption,wraplength=950),maximum=1000).pack(fill='x',pady=5)

    def enable_watch(self):
        self.revealed();local_writable(self.app);source=self.source_selected()
        interval=int(self.watch_interval.get())
        if not self.review('Enable automatic photo imports',f'Workspace: {self.scope}\nSource: {source["label"]}\nFolder: {source["path"]}\nInclude subfolders: {source["recursive"]}\nInterval: {interval} seconds\n\nThis remembered opt-in reads existing and newly appearing stable images and indexes references, metadata evidence and thumbnails while VRC Eye runs. It resumes for this workspace after restart. It does not establish capture time or photographer identity. Originals are never moved, edited or shared. Privacy view and Demo / Safe Mode pause watching.\n\nRe-enabling also retries files that reached their bounded retry limit.'):return
        self.watcher.configure(source['id'],enabled=True,interval=interval);self.refresh_sources()
        self.status.set('Folder watching enabled for this workspace. A first pass gathers stability evidence before importing.')

    def pause_watch(self):
        self.revealed();local_writable(self.app);source=self.source_selected()
        existing=self.store.watch(self.scope,source['id'])
        self.watcher.configure(source['id'],enabled=False,interval=existing['interval'] if existing else 30)
        self.refresh_sources();self.status.set('Source watch paused. An active pass will stop; completed imports remain.')

    def watching_caption(self):
        if not hasattr(self,'watch_caption'):return
        if self.private.get():self.watch_caption.set('Watching paused by Privacy view.');return
        rows=self.store.watches(self.scope);enabled=sum(r['enabled'] for r in rows)
        self.watch_caption.set(f'{enabled} of 8 possible sources enabled in this workspace. '+('Paused by Demo / Safe Mode.' if self.app.demo or getattr(self.app,'safe_mode',False) else self.watcher.status))

    def build_composer(self,parent):
        self.sheet_items=[];self.sheet_review=None;self.sheet_project=''
        self.sheet_mode=self.tk.StringVar(value='Grid');self.sheet_columns=self.tk.StringVar(value='3')
        self.sheet_width=self.tk.StringVar(value='640');self.sheet_height=self.tk.StringVar(value='480')
        self.sheet_spacing=self.tk.StringVar(value='16');self.sheet_background=self.tk.StringVar(value='White')
        self.sheet_numbers=self.tk.BooleanVar(value=False);self.sheet_name=self.tk.StringVar()
        self.sheet_caption=self.tk.StringVar(value='Add 2–24 photos in order, preview, then save the reviewed PNG.')
        self.label(parent,'Contact sheets and photo strips use an ordered set of photo references. Each image fits inside its cell without automatic cropping or enlargement. Optional numbers label positions; filenames, notes, worlds and account names are never printed. Edits from Review & Export apply only when explicitly added with edits.')
        row=flow_line(self,parent);button(self,row,'Add selected photo',lambda:self.add_sheet_photo(False))
        button(self,row,'Add selected with current edits',lambda:self.add_sheet_photo(True))
        button(self,row,'Add this visible page',self.add_sheet_page)
        self.sheet_table=StableTable(self,parent,(('position','Slot',60),('title','Photo',310),('edits','Edits',360)),height=6)
        row=flow_line(self,parent);button(self,row,'Move up',lambda:self.move_sheet(-1));button(self,row,'Move down',lambda:self.move_sheet(1))
        button(self,row,'Remove slot',self.remove_sheet_slot);button(self,row,'Clear draft',self.clear_sheet)
        row=flow_line(self,parent);choice(self,row,self.sheet_mode,LAYOUTS,width=19)
        self.ttk.Label(row,text='Grid columns').pack(side='left',padx=4);entry(self,row,self.sheet_columns,4)
        row=flow_line(self,parent)
        for caption,var in (('Cell width',self.sheet_width),('Cell height',self.sheet_height),('Spacing',self.sheet_spacing)):
            self.ttk.Label(row,text=caption).pack(side='left',padx=4);entry(self,row,var,6)
        choice(self,row,self.sheet_background,('White','Dark'),width=9)
        self.ttk.Checkbutton(row,text='Number slots',variable=self.sheet_numbers).pack(side='left',padx=4)
        row=flow_line(self,parent);button(self,row,'Generate sheet preview',self.prepare_sheet)
        button(self,row,'Inspect sheet again',self.preview_sheet);button(self,row,'Export reviewed sheet…',self.export_sheet)
        from ui_theme import responsive_wrap
        responsive_wrap(self.ttk.Label(parent,textvariable=self.sheet_caption,wraplength=950),maximum=1000).pack(fill='x',pady=5)
        row=flow_line(self,parent);self.ttk.Label(row,text='Project name').pack(side='left',padx=4);entry(self,row,self.sheet_name,28)
        button(self,row,'Save new project',lambda:self.save_sheet_project(False));button(self,row,'Update loaded project…',lambda:self.save_sheet_project(True))
        self.sheet_projects=StableTable(self,parent,(('name','Saved project',300),('count','Slots',75),('updated','Last saved',250)),height=4)
        row=flow_line(self,parent);button(self,row,'Load selected project…',self.load_sheet_project)
        button(self,row,'Delete project only…',self.delete_sheet_project)
        self.label(parent,'A saved project retains layout, order, crop and redaction recipes as local references. It does not back up source files or retain a privacy approval. Missing or hidden sources must be resolved before rendering. Canvas limit: 8192 pixels per edge and 16 megapixels.')
        for v in (self.sheet_mode,self.sheet_columns,self.sheet_width,self.sheet_height,self.sheet_spacing,self.sheet_background,self.sheet_numbers):
            v.trace_add('write',lambda *_:self.discard_sheet_review())

    def sheet_settings(self):
        try:return layout({'mode':self.sheet_mode.get(),'columns':int(self.sheet_columns.get()),'cell_width':int(self.sheet_width.get()),
                           'cell_height':int(self.sheet_height.get()),'spacing':int(self.sheet_spacing.get()),
                           'background':self.sheet_background.get(),'numbers':self.sheet_numbers.get()})
        except (ValueError,TypeError) as error:raise ValueError('Check contact-sheet settings: '+str(error)) from error

    def discard_sheet_review(self):
        self.sheet_review=None
        if hasattr(self,'export_review'):self.export_review=None
        if hasattr(self,'service'):self.service.discard_reviews()
        if hasattr(self,'export_caption'):self.export_caption.set('No current reviewed output. Generate and inspect a preview before exporting.')
        if hasattr(self,'sheet_caption'):self.sheet_caption.set('Draft changed. Generate and inspect a new sheet preview before saving.')

    def refresh_sheet(self):
        if not hasattr(self,'sheet_table'):return
        rows=[]
        if not self.private.get():
            for index,item in enumerate(self.sheet_items):
                photo=self.store.get(self.scope,item['photo']);recipe=item['recipe']
                rows.append({'id':str(index),'title':photo['title'] if photo and not photo['hidden'] else 'Missing / hidden photo',
                             'edits':('Crop · ' if recipe['crop'] else '')+str(len(recipe['redactions']))+' masks · '+recipe['border']+' border'})
        self.sheet_table.set(rows,lambda r:(int(r['id'])+1,r['title'],r['edits']))
        self.sheet_projects.set([] if self.private.get() else self.store.sheets(self.scope),lambda r:(r['name'],len(r['slots']),r['updated']))

    def add_sheet_photo(self,edits):
        self.writable();photo=self.selected()
        if photo['hidden'] or photo['status']!='Available':raise ValueError('Choose a visible, available photo.')
        if len(self.sheet_items)>=MAX_SLOTS:raise ValueError('A sheet supports at most 24 slots.')
        recipe=self.recipe() if edits else normalize_recipe({})
        self.sheet_items.append({'photo':photo['id'],'recipe':recipe});self.discard_sheet_review();self.refresh_sheet()
        self.status.set('Photo added at position '+str(len(self.sheet_items))+'.')

    def add_sheet_page(self):
        self.writable();rows=[r for r in self.visible if not r['hidden'] and r['status']=='Available']
        if not rows:raise ValueError('This page has no visible, available photos.')
        if len(rows)+len(self.sheet_items)>MAX_SLOTS:raise ValueError('The entire visible page would exceed 24 slots. Narrow filters, use Cards, or add individual photos.')
        self.sheet_items.extend({'photo':r['id'],'recipe':normalize_recipe({})} for r in rows)
        self.discard_sheet_review();self.refresh_sheet()

    def sheet_index(self):
        self.revealed();r=self.sheet_table.selected()
        if not r:raise ValueError('Select a photo slot.')
        i=int(r['id'])
        if not 0<=i<len(self.sheet_items):raise ValueError('The selected slot changed.')
        return i

    def move_sheet(self,direction):
        self.writable();i=self.sheet_index();target=i+direction
        if not 0<=target<len(self.sheet_items):return
        self.sheet_items[i],self.sheet_items[target]=self.sheet_items[target],self.sheet_items[i]
        self.discard_sheet_review();self.refresh_sheet();self.sheet_table.tree.selection_set(str(target))

    def remove_sheet_slot(self):
        self.writable();self.sheet_items.pop(self.sheet_index());self.discard_sheet_review();self.refresh_sheet()

    def clear_sheet(self):
        self.revealed();self.sheet_items=[];self.sheet_project='';self.sheet_name.set('');self.discard_sheet_review();self.refresh_sheet()

    def save_sheet_project(self,update):
        self.writable();selection=slots(self.sheet_items);settings=self.sheet_settings();geometry(settings,len(selection))
        if update:
            if not self.sheet_project:raise ValueError('Load a saved project first.')
            if not self.review('Update contact-sheet project','Replace the loaded project’s layout and ordered references with this draft? Originals and exports are unchanged.'):return
        identity=self.store.save_sheet(self.scope,self.sheet_name.get(),selection,settings,identity=self.sheet_project if update else '')
        self.sheet_project=identity;self.refresh_sheet();self.status.set('Contact-sheet project saved locally. Sources were not copied.')

    def load_sheet_project(self):
        self.writable();selected=self.sheet_projects.selected()
        if not selected:raise ValueError('Select a saved contact-sheet project.')
        current=next((r for r in self.store.sheets(self.scope) if r['id']==selected['id']),None)
        if not current:raise ValueError('This saved project is no longer present.')
        if not self.review('Load contact-sheet project','Replace the current unsaved draft with “'+current['name']+'”? No original or export changes.'):return
        self.sheet_items=slots(current['slots']);settings=layout(current['layout']);self.sheet_project=current['id'];self.sheet_name.set(current['name'])
        for k,var in (('mode',self.sheet_mode),('columns',self.sheet_columns),('cell_width',self.sheet_width),('cell_height',self.sheet_height),('spacing',self.sheet_spacing),('background',self.sheet_background),('numbers',self.sheet_numbers)):
            var.set(settings[k])
        self.discard_sheet_review();self.refresh_sheet()

    def delete_sheet_project(self):
        self.writable();r=self.sheet_projects.selected()
        if not r:raise ValueError('Select a saved project.')
        if not self.review('Delete contact-sheet project','Delete only this saved layout and its references? Photos and exported images are retained.'):return
        self.store.delete_sheet(self.scope,r['id'])
        if self.sheet_project==r['id']:self.sheet_project=''
        self.refresh_sheet()

    def prepare_sheet(self):
        self.writable();selection=slots(self.sheet_items);settings=self.sheet_settings();token=self.context()
        geometry(settings,len(selection));self.discard_review()
        def done(review):
            if slots(self.sheet_items)!=json.loads(review.selection_json) or self.sheet_settings()!=json.loads(review.layout_json):
                self.discard_sheet_review();return
            self.sheet_review=review;self.sheet_caption.set(f'{len(selection)} slots · {len(review.output):,} PNG bytes. Inspect every visible image before export.')
            from photo_ui import ImageWindow
            ImageWindow(self,review.preview,'Review contact sheet · not yet saved')
        self.launch(lambda stop,progress:self.service.prepare_sheet(selection,settings,token=token,stop=stop,progress=progress),done)

    def preview_sheet(self):
        self.revealed()
        if not self.sheet_review:raise ValueError('Generate a contact-sheet preview first.')
        from photo_ui import ImageWindow
        ImageWindow(self,self.sheet_review.preview,'Reviewed contact sheet · not yet saved')

    def export_sheet(self):
        from tkinter import filedialog
        self.writable();review=self.sheet_review;token=self.context()
        if not review or slots(self.sheet_items)!=json.loads(review.selection_json) or self.sheet_settings()!=json.loads(review.layout_json):
            raise ValueError('Generate and inspect the current sheet first.')
        path=filedialog.asksaveasfilename(parent=self.app.root,title='New contact-sheet PNG — never overwrite',initialfile='VRC-Eye-contact-sheet.png',defaultextension='.png',filetypes=[('PNG','*.png')])
        self.check_token(token)
        if not path:return
        if not self.review('Export reviewed contact sheet',f'Workspace: {self.scope}\nSlots: {len(self.sheet_items)}\nDestination: {path}\nOutput SHA-256: {review.output_digest}\n\nSave the pixels you inspected as a new flattened PNG? Source metadata is removed; visible content still needs your review. Originals are unchanged.'):return
        if self.sheet_review is not review:raise ValueError('Draft changed. Generate a new preview.')
        work=self.service.export_sheet(review,path);self.sheet_review=None
        self.launch(work,operation='Export contact sheet')
