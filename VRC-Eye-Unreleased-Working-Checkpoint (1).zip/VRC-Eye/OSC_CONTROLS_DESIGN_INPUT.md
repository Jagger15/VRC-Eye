# OSC controls design input — 1.19.5

The supplied design is preserved byte-for-byte below the marker. Implementation
uses osc_service/registry/transport/discovery as the shared core, osc_controls
for semantic workflows, osc_routes for inert configuration and managed sources,
osc_simulator for isolated faults, and osc_app/osc_avatar for application lifetime
and existing creator integration. osc_ui provides the ten workspace tabs plus
central Networking transport configuration.

The implementation does not claim native VRChat, hardware, Windows UI or actual
mDNS interoperability verification in this build environment. Optional providers
require available data; OSC cannot create genuine measurements. Native debug
views respect client/world restrictions. Pose/audio conflicts and Dolly import
format require explicit compatibility evidence; no generic world OSC API or
new Unity/runtime entitlement is implied. The existing optional Avatar Toolkit
remains its separately versioned 1.19.3 package.

Acceptance evidence and actual limitations are recorded in VALIDATION.md and
OSC_CONTROLS_SETUP.md. Configurations and prior approvals do not rearm active
controllers after restart. Source profiles and UI preferences persist; transient
actions and session grants do not.

--- BEGIN ORIGINAL SUPPLIED OSC DESIGN ---

# VRC Eye OSC Controls: the complete subsystem design

Our OSC plans should become **one shared control system for VRC Eye**, rather than a collection of unrelated buttons that each send their own packets.

The established pieces from our earlier discussions were the **OSC Hub/multiplexer, OSC Firewall, OSC Activity Inspector, input-control deck, avatar-parameter controls, chatbox and media integration, camera controls, tracking support, presets, and overlay access**.

Below, I’m expanding those into a detailed design and implementation sequence. **This is a specification—not a claim that every feature is already implemented or tested in the current application.** The Unity Avatar Toolkit remains an optional, later addition; the main OSC subsystem should be useful with the standard VRChat client and without Eye-to-Eye networking.

The most important principle is:

> **VRC Eye must distinguish what it requested, what it transmitted, what it observed, and what it actually knows succeeded.**

That distinction determines whether the rest of this system is dependable.

---

# Part I — What the OSC subsystem should be

## 1. Separate the control interface from the communication system

A camera button, a wrist button, an avatar preset, and a keyboard shortcut should not independently implement OSC.

They should all request actions from the same internal service.

For example:

```
Desktop camera button
SteamVR overlay button
Approved avatar wrist control
Local keyboard shortcut
Accepted Eye-to-Eye photo request
               │
               ▼
       Request: Camera.Capture
               │
               ▼
       Permission and safety checks
               │
               ▼
       Capability and state checks
               │
               ▼
       Conflict and scheduling checks
               │
               ▼
       Shared OSC transport
               │
               ▼
             VRChat
```

The benefit is not merely cleaner code. It means that fixing a capture bug fixes it everywhere.

The overlay cannot accidentally ignore a camera permission that the desktop interface respects. An avatar button cannot bypass a cooldown. A network request cannot access a more powerful implementation than a local button.

### The subsystem should have five internal responsibilities

**Discovery** finds the correct VRChat instance and learns what interfaces appear available.

**State tracking** records observed values, connection health, active avatar information, and pending actions.

**Policy enforcement** decides whether a particular source may perform a particular action.

**Scheduling and routing** resolve competing writers, prioritize releases, and prevent outdated work from being sent.

**Presentation** exposes the same underlying state through Casual, Advanced, Creator, Streamer, and Developer views.

These are conceptual responsibilities. They do not need to become five separate applications or a sprawling installation structure.

---

## 2. Where OSC should live in the interface

For the layout we have been developing, I would expose the main control interface from:

```
VRC Eye
└── VRC Eye Primary
    └── OSC Controls
```

Its internal tabs could be:

| Tab                  | Purpose                                                                   |
| -------------------- | ------------------------------------------------------------------------- |
| Overview             | Connection health, active avatar, active controllers, important warnings. |
| Control Deck         | User-triggered actions and favorite controls.                             |
| Avatar Parameters    | Inspect and adjust compatible avatar parameters.                          |
| Voice & Privacy      | Microphone controls, observed mute state, privacy warnings.               |
| Chatbox              | Message composer, templates, output scheduling.                           |
| Camera               | Camera actions, settings, presets, and supported Dolly functions.         |
| Tracking             | Eye, face, and body-tracking routes and diagnostics.                      |
| Presets & Rules      | Reviewed configurations and bounded local automation.                     |
| Routes & Permissions | Which applications and features may read or write which controls.         |
| Inspector            | Live activity, validation failures, conflicts, and action traces.         |

**Transport configuration should remain under `VRC Eye → Networking`.** That includes listening addresses, UDP ports, LAN exposure, device pairing, and Eye-to-Eye transport settings. The OSC pages should link there rather than maintain a second, potentially contradictory configuration.

The existing Avatar, World, Safety, and overlay interfaces should expose relevant subsets of this same subsystem.

For example, the Avatar Parameters tab under the avatar workspace should not create its own OSC receiver. It should display the shared parameter service.

---

## 3. Casual, Advanced, and Developer views should change visibility—not implementation

This follows our existing preference for one application with different complexity levels.

### Casual view

A Casual user should see ordinary controls:

```
VRChat connected
Avatar controls available

[ Microphone ] [ Camera ] [ Chatbox ]
[ My Presets ] [ Pause Controls ]

One application is controlling facial expressions.
```

They should not need to understand OSC addresses to use a reviewed control.

When something is unavailable, explain it in terms of the missing requirement:

> This avatar does not expose a compatible accessory control.

Not:

> Failed to resolve endpoint binding.

### Advanced view

Advanced mode should expose parameter names, types, ranges, ownership, routing, rate limits, compatibility evidence, and state freshness.

The user should be able to answer:

> Which application is changing this value, and why?

### Developer view

Developer mode should expose packet types, timing, queue state, parser failures, schema revisions, internal action IDs, and lifecycle transitions.

Following our earlier decision, Developer Mode does not need a new entitlement or key system during early development. However, **making developer tools visible should not automatically disable ordinary permission enforcement**.

A raw packet inspector and an unrestricted raw packet transmitter are different capabilities.

---

# Part II — Connection, discovery, and lifecycle

## 4. Treat OSC and OSCQuery as related but separate systems

OSC carries the control messages. OSCQuery provides discovery and information about an application’s address space and capabilities. VRChat supports OSCQuery for easier configuration. [VRChat](https://docs.vrchat.com/docs/oscquery)

Our interface should expose these separately.

For example:

```
OSC send path: Configured
OSC receive path: Receiving
OSCQuery discovery: Available
Parameter description: Loaded
Avatar identity: Observed
Control permissions: Read-only
```

This is more useful than one green “Connected” light.

A user might be able to send OSC while discovery is unavailable. Another user might successfully discover VRChat but have no working incoming data stream.

Those are different problems.

### Do not use a visible action as a connection test

The connection wizard must not test connectivity by unexpectedly moving the player, changing an outfit, opening the microphone, sending a chatbox message, or triggering Safe Mode.

Discovery and passive observation come first. Any test that changes VRChat should be clearly labeled and explicitly initiated.

---

## 5. Support automatic configuration first, manual configuration second

VRChat’s documented defaults are UDP port **9000 for messages received by VRChat** and **9001 for messages sent by VRChat**. Launch arguments can override them, so these values should be defaults rather than permanent assumptions. OSC is enabled through the Action Menu’s OSC controls. [VRChat](https://docs.vrchat.com/docs/osc-overview)

Our automatic setup should prefer discovered information.

The manual fallback should clearly distinguish:

```
Send messages to VRChat:
Address: 127.0.0.1
Port: discovered or manually configured

Receive messages in VRC Eye:
Address: selected local interface
Port: selected available port
```

A common source of confusion is that an application sending to VRChat does not need to claim VRChat’s receiving port for itself.

### Multiple receivers do not automatically require a hub

VRChat already supports multiple OSC receivers through OSCQuery. Therefore, VRC Eye should not claim that every other OSC application must be routed through us simply to coexist. [VRChat](https://docs.vrchat.com/docs/vrchat-202331?utm_source=chatgpt.com)

Our hub adds value through policy, transformation, diagnostics, and conflict management—not by pretending native multi-application support does not exist.

### Platform-aware discovery

VRChat’s integration documentation describes a Windows limitation in which its OSCQuery address information is served to applications on the same machine, while Android has different behavior. Our networking interface should account for platform differences rather than assume that a LAN device can always query the same information directly. [GitHub](https://github.com/vrchat-community/osc/wiki/OSCQuery)

---

## 6. The first-run setup should be a guided sequence

I would make the onboarding sequence work as follows.

1. **Start VRC Eye in observation mode.** No avatar changes, camera actions, or input commands are sent automatically.
2. **Find candidate VRChat instances.** If more than one is present, show an explicit instance selector.
3. **Ask the user to enable OSC in VRChat when necessary.** Explain the actual in-client location.
4. **Attempt OSCQuery discovery.** Record the discovered service and available endpoint descriptions.
5. **Prepare VRC Eye’s receiving endpoint.** Select an available port instead of silently displacing another application.
6. **Observe incoming information.** Show which kinds of data have actually arrived.
7. **Load compatible local metadata.** An avatar manifest or profile can improve labels, but it must not grant permissions by itself.
8. **Present a capability summary.** Separate available, unavailable, unverified, and read-only features.
9. **Let the user select an initial operating profile.** Observation Only, Basic Controls, Creator, or another reviewed profile.
10. **Configure sensitive controls independently.** Microphone behavior and chatbox publication deserve their own review.
11. **Offer a deliberately chosen test.** For example, testing a known, harmless custom parameter on a compatible avatar.
12. **Save configuration—not active button presses.** A restart must not restore movement, a held voice input, or an unfinished photo command.

The wizard should be resumable. Failing at discovery should not erase the user’s completed configuration work.

---

## 7. Connection state needs more detail than connected or disconnected

I would use states such as:

```
Disabled
Discovering
Service found
Description loaded
Receiving data
Read-only ready
Controls armed
Degraded
Reconnecting
Stopped
```

A degraded state could mean:

> VRChat is still receiving commands, but VRC Eye has lost the observation channel used to verify microphone state.

That should disable actions that require reliable microphone-state feedback without necessarily disabling an unrelated chatbox composer.

### Track liveness separately from value age

A parameter that has not changed for several minutes is not automatically broken.

The interface should distinguish:

**Last value change:** when a new value was observed.

**Service health:** whether the relevant connection or discovery service still appears available.

**Confidence in current state:** whether the stored value can reasonably still be treated as current.

Otherwise, a perfectly stable “Muted” value could be incorrectly marked stale merely because it did not change.

Conversely, a recently received value from a disconnected client should not remain trustworthy forever.

---

## 8. Bind every action to a session and avatar generation

This is one of the most important protections in the entire design.

Suppose the user activates a preset, then changes avatars before all its writes have been sent.

Without lifecycle protection, the remaining writes could reach the new avatar, where the same parameter names might have different meanings.

Every internally scheduled operation should carry something like:

```
VRChat instance identity
Connection generation
Avatar generation
Profile revision
Permission revision
Expiration time
```

When an avatar changes, VRC Eye should invalidate work tied to the previous generation before enabling compatible controls for the new one.

That includes delayed captures initiated by avatar controls, pending parameter writes, queued profile applications, temporary ownership, and rule activations.

### There is a limit to what this can prove

Our own queued work can be tagged precisely.

Ordinary incoming OSC messages do not automatically contain our internal generation IDs. A late packet therefore cannot always be conclusively assigned to an old or new avatar session.

The mitigation should combine a rearming pause, refreshed metadata, fresh observations, and conservative event handling. We should not advertise perfect stale-packet detection where the wire protocol does not provide enough information.

---

# Part III — The command system underneath every control

## 9. Build an endpoint registry

A registry should describe each supported control before any interface tries to use it.

An endpoint description should contain:

| Field                 | Why it matters                                                      |
| --------------------- | ------------------------------------------------------------------- |
| Address               | The actual OSC destination.                                         |
| Argument types        | Prevents sending the wrong payload.                                 |
| Direction             | Read, write, or both.                                               |
| Meaning               | What the value represents.                                          |
| Range or enumeration  | Prevents invalid values and misleading sliders.                     |
| Units                 | Distinguishes degrees, meters, normalized values, and other scales. |
| Command behavior      | State assignment, continuous value, pulse, or toggle.               |
| Availability evidence | Documented, advertised, observed, or tested.                        |
| Required permission   | Identifies which sources may use it.                                |
| Conflict group        | Identifies controls that cannot safely have competing writers.      |
| Cleanup behavior      | Defines what should happen when a controller stops.                 |
| Confirmation method   | States what evidence can establish success.                         |

OSCQuery can provide attributes such as access, type, value, and range, but supported attributes and endpoint descriptions can vary. Our registry should preserve the distinction between remotely advertised information and our tested behavior. [GitHub](https://github.com/Vidvox/OSCQueryProposal)

### Do not convert absence into certainty

An endpoint missing from discovery might be unavailable—or it might be omitted from the advertised tree.

An advertised endpoint might exist but behave differently than our interface expects.

The registry should therefore support:

```
Documented, not discovered
Discovered, not tested
Read observed
Write behavior tested
Conflicting documentation
Unavailable in this session
```

That is much more useful than an overly confident supported/unsupported checkbox.

---

## 10. Keep OSC types exact

The control system should explicitly represent integers, floats, booleans, strings, and multi-argument messages rather than rely on accidental conversions.

OSC messages include an address, type information, and arguments; bundles can group messages, but grouping does not turn them into an application-level transaction with rollback or confirmed execution. [Open Sound Control](https://opensoundcontrol.stanford.edu/spec-1_0.html)

For VRC Eye, this means:

**An unknown value is not zero.**

**A missing boolean is not false.**

**A percentage is not automatically a normalized float.**

**A list of three floats is not interchangeable with one string containing three numbers.**

The editor should reject non-finite values such as NaN and infinity. It should also reject invalid argument counts and unsupported types before anything reaches the output queue.

When the user changes a control’s type, the interface should show the conversion explicitly.

For example:

```
Source: Integer 75
Transformation: Divide by 100
Destination: Float 0.75
```

Not simply:

> Converted automatically.

---

## 11. Distinguish four kinds of commands

Most mistakes in control software come from treating every endpoint like a normal “set this value” field.

### State assignments

Example: set a known custom accessory parameter to a particular value.

The intended result is a state that can often be observed afterward.

Repeated assignments may be acceptable when the endpoint’s semantics are known, although unnecessary traffic should still be avoided.

### Continuous values

Example: tracking data or a continuously moving slider.

The newest value is normally more useful than a backlog of old values. These routes should use bounded, latest-value handling.

### Button pulses

Example: a user-triggered action that requires a press and release.

VRChat’s input documentation distinguishes axes from buttons and explains that controls must return to their neutral or released state. Repeated presses without releases do not behave like repeated independent clicks. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

### Toggles

Example: an action that changes the current state rather than assigning a desired state.

These are particularly dangerous to retry blindly.

A lost confirmation must not cause VRC Eye to send a second toggle and accidentally undo the first one.

**Retry behavior must be defined by command semantics, not by a universal “retry failed packets” option.**

---

## 12. Use honest action-result states

I would expose this internal progression:

```
Requested
Validated
Scheduled
Sent
Matching state observed
Outcome confirmed
Failed / expired / cancelled
```

Not every action will reach every state.

UDP does not guarantee delivery or duplicate protection. A successful local send operation is therefore not an acknowledgment from VRChat that an action was performed. [RFC Editor](https://www.rfc-editor.org/rfc/rfc768.txt)

For example:

| Action             | What VRC Eye can honestly report                                                   |
| ------------------ | ---------------------------------------------------------------------------------- |
| Parameter write    | Sent; optionally, matching value subsequently observed.                            |
| Chatbox send       | Submitted through OSC; not proof that every nearby user saw it.                    |
| Camera capture     | Capture command sent; a later screenshot may provide additional evidence.          |
| Microphone action  | Requested; observed mute state changed, remained unchanged, or became unavailable. |
| Eye-to-Eye request | Peer accepted the request; local VRChat execution is a separate result.            |

Even observing a matching value does not always prove our command caused it. Another application or the user may have changed the same setting.

The UI can still say “Requested state observed” without making an unsupported claim about causation.

---

## 13. Releases and stop commands deserve a dedicated priority path

A held input must not wait behind a large queue of cosmetic updates.

The scheduler should maintain a high-priority cleanup path for controls VRC Eye currently owns.

When a user presses **Stop Controls**, the order should be:

1. Prevent new actions from being generated.
2. Cancel queued actions that could reassert a held input.
3. Revoke relevant controller ownership.
4. Send the required release or neutral values for owned controls.
5. Stop ordinary output.
6. Mark any unverified cleanup clearly.

The cancellation must happen before releases are sent. Otherwise, an older queued “press” might be transmitted after the cleanup “release.”

### Do not indiscriminately zero every endpoint

A generic “send zero everywhere” operation could interfere with another application, reset a wanted avatar setting, or provide invalid tracking coordinates.

Cleanup must be specific to the endpoint and the controller’s ownership.

### Do not promise crash-proof releases

A separate watchdog could improve resilience when the main UI fails, but no local design can guarantee cleanup after every process, operating-system, network, or machine failure.

The interface should provide a clear recovery instruction and should never describe software-controlled microphone or movement cleanup as infallible.

---

# Part IV — The actual controls

## 14. The direct input-control deck

The deck should offer a reviewed selection of VRChat inputs rather than a giant unstructured list of addresses.

The documented input families include the following:

| Control group          | Relevant addresses                                                                    |
| ---------------------- | ------------------------------------------------------------------------------------- |
| Movement axes          | `/input/Vertical`, `/input/Horizontal`                                                |
| Horizontal looking     | `/input/LookHorizontal`, `/input/LookLeft`, `/input/LookRight`                        |
| Jump and run           | `/input/Jump`, `/input/Run`                                                           |
| VR snap turning        | `/input/ComfortLeft`, `/input/ComfortRight`                                           |
| Quick Menu             | `/input/QuickMenuToggleLeft`, `/input/QuickMenuToggleRight`                           |
| Hand interactions      | Left/right variants of `Grab`, `Use`, and `Drop` under `/input/`                      |
| Held-object adjustment | `/input/MoveHoldFB`, `/input/SpinHoldCwCcw`, `/input/SpinHoldUD`, `/input/SpinHoldLR` |

Mode and world behavior affect which inputs are useful, so the deck should expose tested compatibility rather than imply every control works identically everywhere. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

### Each deck button needs configurable interaction behavior

A control might be:

**Momentary:** active only while pressed.

**Single action:** one bounded press/release cycle.

**Continuous:** active while an analog control is moving.

**Explicitly latched:** remains active until released through the same interface, with a prominent state indicator and timeout policy.

Latched movement should not be the Casual default.

### Keep this user-directed

The purpose should be accessible input, convenient controls, and deliberate testing.

We should not turn the deck into unattended gameplay automation, anti-idle behavior, or a remote-control mechanism that another person can silently activate.

---

## 15. Compatibility-tested input extensions

The official OSC wiki lists additional inputs, including `/input/LookVertical`, `/input/AFKToggle`, and `/input/ToggleSitStand`, while also documenting differences between published descriptions and OSCQuery exposure. These belong in a compatibility-tested group, not a universal promise. [VRChat Wiki](https://wiki.vrchat.com/wiki/OSC)

Our interface should show:

```
AFK toggle
Status: Requires compatibility test

This is an input action.
It is not a write to the built-in AFK parameter.
```

Testing should be deliberate and reversible where possible.

An automatic discovery scan must not “probe” write-only inputs by activating them.

---

## 16. Native VRChat Safe Mode and VRC Eye Safety Mode must remain separate

VRChat documents `/input/PanicButton` as an input that activates Safe Mode. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

That gives us a real native action, but it should not be confused with our broader application-level safety system.

### Native action

A button labeled:

> Activate VRChat Safe Mode

requests that specific VRChat input.

Releasing the input is not the same thing as undoing Safe Mode.

### VRC Eye action

A button labeled:

> Activate VRC Eye Safety Mode

could execute a reviewed local sequence:

```
Suspend nonessential OSC automation
Release VRC Eye-owned held inputs
Stop scheduled chatbox status output
Pause approved media-driven effects
Request native VRChat Safe Mode, when configured
Apply a configured microphone privacy action
Create a local diagnostic bookmark
Optionally notify previously authorized Eye-to-Eye contacts
```

Each step needs its own result.

The final status might be:

```
Automation paused
Held inputs released
Chatbox schedule stopped
Native Safe Mode requested
Microphone state could not be verified
Diagnostic bookmark created
```

That is preferable to a misleading single message saying everything is safe.

### Restoration should be selective

Leaving VRC Eye Safety Mode should not automatically reverse every action.

In particular, it should not automatically unmute the microphone, resume movement, republish status messages, or undo a native safety action without an appropriate user decision.

---

## 17. Microphone controls need their own state machine

The voice control is important enough that it should not be implemented as an ordinary unlabeled toggle.

VRChat documents different behavior for `/input/Voice` depending on microphone settings: in toggle mode, a rising input changes mute state; in the non-toggle behavior described by the documentation, zero corresponds to muted and one to unmuted. A held toggle input can also interfere with ordinary mute controls until released. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

### The interface should distinguish intent

These are different requests:

```
Toggle microphone
Request muted
Request unmuted
Hold to speak
Release voice control
```

Only the first one is inherently a toggle.

A button labeled **Mute** should not blindly send a toggle when the current state is unknown.

### Suggested microphone states

```
Behavior not configured
State unknown
Observed muted
Observed unmuted
Mute requested
Unmute requested
Waiting for observation
Conflicting changes detected
Control suspended
```

### A “Request muted” operation should work like this

First, check that the user has configured the microphone-control behavior.

Next, check whether a sufficiently trustworthy current observation is available.

If the microphone already appears muted, avoid an unnecessary toggle.

If a change is required, issue the appropriate bounded input action.

Then release the input when required and wait for a relevant observation.

If the result is ambiguous, report that ambiguity rather than repeatedly toggling.

### Concurrent user input must be respected

The user may press their normal microphone button at the same time.

VRC Eye should not enter a tug-of-war where it repeatedly undoes user actions to maintain an old expectation.

A privacy-lock mode could have stronger behavior, but that must be explicitly activated, clearly visible, and easy to release.

### Keep the different microphone layers separate

The UI should distinguish:

```
VRChat mute state
Operating-system device state
Physical headset mute state
VRC Eye's own microphone permission
```

A confirmed mute inside VRChat should not be presented as proof that every other application has stopped recording.

Similarly, a silent input meter is not proof of muting.

---

## 18. The Mic Privacy Watchdog

This connects directly to our earlier safety plans.

The watchdog should compare an explicitly chosen expectation with observed state.

For example:

```
Expectation: Remain muted while this privacy session is active.
Observation: VRChat reports unmuted.
Action: Alert and apply the reviewed response policy.
```

Possible triggers could include a user-activated privacy session, an approved headset-presence provider, a device change, or activation of VRC Eye Safety Mode.

The response should be configurable by risk.

A conservative default is to notify and present a prominent corrective control.

A stronger local policy could attempt the configured mute action, but it should stop and report a conflict if the result remains unstable.

### Avoid false certainty

A watchdog with missing observations should say:

> Microphone privacy state is currently unverified.

Not:

> Privacy protection active.

The status should include the provider, observation time, and reason that confidence changed.

---

## 19. Chatbox controls should be a publication system

The chatbox interface should be treated as a way to publish text—not as a general chat reader.

VRChat’s documented OSC interface supports text submission and a typing indicator, including an immediate-send option and an optional notification-sound flag. The documented text constraints include 144 characters and a maximum displayed extent of nine lines. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller)

The basic composer should contain:

```
Message editor
Character and line preview
Send immediately / populate VRChat's editor
Notification sound preference
Typing-indicator preference
Destination visibility reminder
Send button
```

### Human-written text should outrank background status

If the user is composing a message, a music-status routine should not overwrite it.

I would use a simple publication priority:

```
User-composed message
Explicitly selected template
Accepted local announcement
Optional background status
```

Background output should yield automatically.

### Templates should use approved fields

A template editor could support reviewed fields such as an intentionally selected status label, timer text, or selected media title.

It should not automatically expose local usernames, file paths, window titles, device identifiers, private instance information, or diagnostic contents.

The rendered output should be previewed before enabling automatic publication.

### Receiving chat is a separate capability

The OSC chatbox endpoints are write-only. We should not describe this feature as reading other players’ chatbox messages. [VRChat Wiki](https://wiki.vrchat.com/wiki/OSC)

VRC Eye Whispers belong to the separately permissioned Eye-to-Eye system, not to a fictional incoming chatbox stream.

### Speech and translation can be optional providers

A speech-to-text or translation provider could feed the composer, but it should remain a separate module with explicit microphone and network permissions.

It should default to processing the user’s deliberately selected input—not indiscriminately transcribing other people.

---

## 20. Chatbox scheduling needs arbitration and cancellation

A single output scheduler should manage all VRC Eye chatbox producers.

For example, a status message, countdown, media title, and handwritten message should not each maintain independent timers.

Each scheduled publication should carry:

```
Producer
Priority
Creation time
Expiration time
Current session
Content privacy classification
Replacement policy
```

An outdated countdown message should expire rather than appear after the photo.

A media title from a previous track should not remain queued behind newer titles.

A message prepared before a reconnect should not automatically publish afterward.

### Do not invent a universal clearing guarantee

A “Clear my output” button should use a tested behavior and explain its scope.

Cancelling a pending VRC Eye publication is different from removing text that has already appeared in VRChat or been seen by someone else.

The interface should make that distinction explicit.

---

## 21. Avatar controls should be generated from real compatibility information

OSC avatar parameters allow external applications to interact with exposed avatar parameters. VRChat also supports local configuration mappings for their input and output addresses and types. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

A parameter browser alone is not enough.

We should turn compatible parameters into understandable controls.

For example:

| Declared meaning    | Appropriate control           |
| ------------------- | ----------------------------- |
| Accessory enabled   | Toggle.                       |
| Outfit choice       | Labeled selection.            |
| Emission intensity  | Bounded slider.               |
| Color channel       | Slider with a declared range. |
| Discrete expression | Labeled action or selection.  |
| Temporary effect    | Bounded action with cleanup.  |
| Module status       | Read-only indicator.          |

The key word is **declared**.

A parameter named `Mode` does not tell us what each integer means.

A float named `Color` does not tell us whether it represents hue, brightness, or an unrelated blend.

Without trustworthy metadata, use a generic editor and make the uncertainty visible.

---

## 22. Built-in parameters should not be displayed as ordinary writable controls

VRChat’s built-in avatar parameters—including state such as `AFK`, `MuteSelf`, `Upright`, and gesture values—are documented as read-only to OSC. Custom parameters are a separate category. [VRChat Creators](https://creators.vrchat.com/avatars/animator-parameters/?utm_source=chatgpt.com)

That distinction should be enforced by the registry.

For example:

```
Upright
Observed: 0.83
Access: Read-only
Source: VRChat built-in parameter
```

Not:

```
Upright
[ Force to 1.0 ]
```

A visual pose issue is not automatically fixed by trying to write a built-in state parameter.

This matters especially for the desktop crouch/viewpoint problem you have been investigating. Those values could help describe what is happening, but the interface must not invent a universal “force standing” repair.

---

## 23. Per-avatar presets should be reviewed snapshots

A preset should not be a raw dump of every observed value.

It should contain only the settings intentionally selected for that preset.

For example:

```
Preset: Photography

Accessory: Enabled
Expression selection: Neutral
Approved emission level: Reduced
Compatible camera preset: Portrait
```

It should normally exclude transient tracking data, built-in state, button presses, temporary request signals, and sensitive status values.

### Preset application should follow a defined sequence

1. Confirm the current avatar and compatible schema.
2. Load the preset.
3. Compute the proposed changes.
4. Mark missing or incompatible controls.
5. Check permissions.
6. Resolve conflicting writers.
7. Present a preview when required.
8. Apply compatible state assignments.
9. Observe results where possible.
10. Report applied, skipped, failed, and unverified values separately.

### Restoration must not overwrite later user choices

Suppose VRC Eye reduces an emission parameter for a photo, then the user changes it manually.

When the photo session ends, a blind restore could undo the user’s newer choice.

The restore policy should check whether VRC Eye still owns the setting and whether the current observed state matches the state it last applied.

Even that is a best-effort safeguard, not a transactional guarantee.

---

## 24. Parameter budgets, sync, and privacy must remain visible

The creator documentation distinguishes local parameter behavior from synchronized behavior. It documents a 256-bit synchronized custom-parameter budget, different costs for types, and reduced precision for remotely synchronized floats compared with local OSC-updated floats. Cross-platform synchronization also depends on matching parameter order and types. [VRChat Creators](https://creators.vrchat.com/avatars/animator-parameters/?utm_source=chatgpt.com)

Our editor should therefore show more than the numeric value.

A useful parameter row would include:

```
Name
Meaning
Local value
Writable status
Known synchronization setting
Expected audience
Current owner
Profile membership
```

### Local computation does not automatically mean private output

A battery value may originate entirely on the user’s machine.

If it drives an avatar-visible feature, it can still reveal information to other people.

The same applies to microphone state, a streamer badge, a safety indicator, and a “currently listening” display.

Our design should explicitly separate:

```
Local-only VRC Eye display
Avatar-visible presentation
Eye-to-Eye sharing
Diagnostic export
```

Permission for one should not automatically enable the others.

---

## 25. Avatar switching can be a supported control—with restrictions

VRChat added OSC avatar switching through `/avatar/change`, with switching restricted to avatars in the user’s favorites, recents, or their own uploads. [VRChat](https://docs.vrchat.com/docs/vrchat-202512?utm_source=chatgpt.com)

That means VRC Eye can offer an approved avatar-switch control without pretending it can load arbitrary inaccessible avatars.

The workflow should be:

```
User selects an eligible avatar
VRC Eye previews the switch
Current avatar-dependent actions are suspended
Switch request is transmitted
VRC Eye waits for the observed avatar transition
New compatibility information is loaded
Compatible controls are rearmed
```

Do not apply the destination avatar’s preset merely because the switch command was sent.

The transition must actually be observed.

A timeout should leave the interface in a clear unresolved state, not silently continue with assumptions about the new avatar.

---

## 26. Avatar scaling deserves a dedicated panel

VRChat exposes `/avatar/eyeheight` along with related limits and a scaling-permission endpoint. World logic can enforce a different result, and a requested value can be reported before the enforced value follows. [VRChat](https://docs.vrchat.com/docs/osc-avatar-scaling)

The panel should therefore show:

```
Observed eye height
Requested eye height
Scaling permission
Reported user-selectable limits
VRC Eye's chosen safety bounds
Last change source, when known
```

### Do not conflate different limits

The user-selectable range, the technically accepted OSC range, world-enforced behavior, and our own interface bounds are not necessarily identical.

VRC Eye should choose conservative bounds for ordinary controls and explain when an Advanced setting changes those bounds.

### Presets should be contextual

A scaling preset belongs to a particular avatar and context.

Restoring a previous avatar’s eye height on a newly selected avatar should require compatibility handling.

### Avoid feedback loops

If the world enforces a value, VRC Eye should not keep resending its preferred value indefinitely.

It should report:

> The requested height did not remain active. A different effective height was observed.

---

## 27. Camera controls should be a complete workspace

The documented camera interface includes modes, capture actions, masks, behavior settings, and numeric settings. [VRChat](https://docs.vrchat.com/docs/vrchat-202533)

The camera tab should have separate areas for **Actions**, **Composition**, **Behavior**, **Visibility**, **Presets**, and **Capture History**.

A compact registry could cover:

| Group                    | Endpoint examples                                                                                                                   |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| Modes and actions        | `/usercamera/Mode`, `/usercamera/Close`, `/usercamera/Capture`, `/usercamera/CaptureDelayed`                                        |
| Composition              | `/usercamera/Zoom`, `/usercamera/Exposure`, `/usercamera/FocalDistance`, `/usercamera/Aperture`                                     |
| Visibility               | `/usercamera/LocalPlayer`, `/usercamera/RemotePlayer`, `/usercamera/Environment`, `/usercamera/ShowUIInCamera`                      |
| Behavior                 | `/usercamera/Lock`, `/usercamera/SmoothMovement`, `/usercamera/LookAtMe`, `/usercamera/AutoLevelRoll`, `/usercamera/AutoLevelPitch` |
| Additional configuration | Greenscreen settings, movement settings, orientation, focus display, and compatible streaming settings.                             |

These controls need endpoint-specific ranges and behavior rather than an assumption that every slider uses zero to one. [VRChat](https://docs.vrchat.com/docs/vrchat-202533)

### Camera-pose writes need a specific warning

There is a documentation conflict: the release notes describe `/usercamera/Pose` as get/set, while the official OSC wiki marks it read-only. The sources also differ on the audio-from-camera endpoint name. We should therefore treat those details as compatibility-tested, not universally guaranteed. [VRChat](https://docs.vrchat.com/docs/vrchat-202533)

The registry should preserve that conflict:

```
Camera pose
Read support: available when observed
Write support: requires current-client verification
```

### A camera preset should be a selected group of settings

For example:

```
Preset: Portrait

Camera mode
Selected exposure
Selected focal settings
Orientation
Approved visibility masks
Optional behavior settings
```

It should not automatically enable streaming, publish files, or change unrelated avatar settings.

### Separate local countdowns from native delayed capture

VRC Eye can schedule a local countdown before sending a capture request.

That is different from asking VRChat to begin its own delayed capture.

The UI must explain which mechanism is active, particularly because cancelling our own timer does not necessarily cancel an action already handed off to VRChat.

### Captures should not be retried blindly

If the result is uncertain, an automatic retry could create multiple photographs.

The interface should show:

> Capture requested. No matching file has been identified yet.

A screenshot watcher can add evidence, but a nearby file creation is not always conclusive when the user or another application can also trigger captures.

---

## 28. Camera Dolly should be an optional extension of that workspace

The Camera Dolly interface documents play, delayed play, import, and export operations. Its documentation currently identifies it as a VRC+ feature. It also notes that the delayed-play feedback occurs when the delay is initiated, not necessarily when animation begins. [VRChat Wiki](https://wiki.vrchat.com/wiki/Camera_Dolly)

Our implementation should respect those distinctions.

### Path import should be reviewed data

A path importer should validate structure, size, number of points, numeric values, and supported settings.

It should not interpret imported content as executable code.

The dedicated Dolly documentation describes `/dolly/Import` as accepting path JSON and says import does nothing while playback or delayed playback is active. That behavior should be reflected in the UI. [VRChat Wiki](https://wiki.vrchat.com/wiki/Camera_Dolly?utm_source=chatgpt.com)

### Path libraries need context

A stored path should record whether it is intended to be local-relative or world-specific, along with any relevant notes.

A path created in one world should not silently be treated as appropriate in another.

### Show separate playback states

```
Path loaded
Delay requested
Waiting
Playback observed
Stopped
State unknown
```

This prevents a “play accepted” event from being incorrectly displayed as confirmed animation progress.

---

## 29. Eye-tracking controls should primarily manage a data source

VRC Eye should not claim to create genuine eye-tracking measurements merely because it can transmit OSC.

It can manage a compatible source, route it, transform it where appropriate, and diagnose its behavior.

VRChat supports several eye-look representations and a shared eyelid-closure value. The documentation instructs applications to use one eye-look representation at a time and describes a ten-second fallback timeout, separately for eyelids and eye-look. [VRChat](https://docs.vrchat.com/docs/osc-eye-tracking)

### The tracking panel should show

```
Selected source
Source health
Chosen representation
Incoming update rate
Outgoing update rate
Current route
Transformations
Rejected samples
Time since valid sample
Ownership
```

### Stopping a source must not mean repeatedly sending stale data

If a provider disappears, continuing to resend its last value could keep an unwanted override active.

The default failure behavior should be to stop forwarding according to the route policy and report the loss of input.

The native fallback timeout means that stopping output is not necessarily an instantaneous visual reset.

### Calibration belongs to the provider and route

The panel can offer explicit axis mapping, validated offsets, and smoothing settings, but changes should be previewed and reversible.

It should not silently apply guessed calibration corrections merely because a value “looks unusual.”

---

## 30. Body tracking needs stricter timing and coordinate handling

VRChat documents up to eight OSC body trackers, using position and rotation messages. Its tracking documentation specifies real-world meter scaling, Unity-style coordinates, and Euler rotation conventions. Head-reference messages are used for tracking-space alignment rather than as a generic player-position control. [VRChat](https://docs.vrchat.com/docs/osc-trackers)

Our body-tracking route should prioritize correctness and bounded latency.

### Do not accumulate old poses

A long queue of tracker updates is worse than dropping outdated samples and retaining the latest valid one.

The route should report its own queue delay and dropped-sample counts.

It should not label those measurements as total tracking latency or VRChat server latency.

### Never reset a lost tracker by sending an arbitrary zero position

A zero coordinate can be a valid location in a coordinate system, not a universal “tracker unavailable” signal.

Loss handling should follow the provider’s supported behavior and the reviewed route policy.

### Avoid unnecessary interception

A well-functioning tracking application should not be forced through VRC Eye.

Observation and compatibility tools can be useful without adding an extra routing stage.

Managed routing should be an explicit choice when its benefits justify the additional component.

### Keep outbound tracking and inbound telemetry distinct

VRChat’s OSCQuery integration supports receiving head and wrist system data after the relevant user approval. That is a different interface from transmitting tracker data into VRChat. [GitHub](https://github.com/vrchat-community/osc/wiki/OSCQuery)

Our permissions should distinguish those directions.

---

## 31. Facial-expression routing should preserve the existing owner

Custom facial-expression routes should use the avatar’s declared parameter mapping rather than assume every avatar follows the same names or ranges.

The important design problem is often ownership.

For example:

```
Face-tracking application controls:
Eye expressions
Mouth expressions
Cheek expressions

VRC Eye photo preset controls:
Accessory
Emission
Camera settings
```

A photography preset should not unexpectedly seize all facial parameters from a tracking application.

A deliberate “temporary expression override” could exist, but it should display which controls are being taken over and when ownership will return.

The return should be explicit and tested. We should not assume that another sender will automatically recover exactly as expected after being blocked for a period.

---

## 32. Local media and hardware controls should publish only reviewed signals

This is where OSC can make our existing local features useful inside a compatible avatar.

Proposed signals could include:

```
Battery level
Charging state
Resource-warning level
Selected VRC Eye mode
Media activity
Audio-reactive intensity
Timer progress
Connection indicator
User-selected status
```

These would be **our custom parameter conventions**, not stock VRChat endpoints.

For example:

```
/avatar/parameters/Eye_Battery01
/avatar/parameters/Eye_Charging
/avatar/parameters/Eye_MediaLevel
/avatar/parameters/Eye_QuietMode
```

### Every signal needs an unknown state

An unavailable battery reading must not become “zero percent.”

The avatar module could use a separate validity parameter, or the feature could stop updating and display a creator-defined unavailable state.

The correct choice belongs in the module contract.

### Numeric parameters are not a general text display

A song title, device name, or arbitrary sentence cannot be assumed to appear on an avatar merely because VRC Eye knows the string.

A text display requires a deliberately designed compatible avatar mechanism.

For ordinary integration, simple numeric and boolean signals are more realistic.

### Sampling rates should match the feature

A battery indicator should not need the same update behavior as a music-reactive effect.

Our initial rate presets should be treated as benchmark candidates, not claims about universal VRChat limits.

---

## 33. Wrist and Contact controls remain an optional Avatar Toolkit layer

This preserves our earlier priority decision: the main OSC system should work first, while the optional Unity toolkit supplies richer avatar-side controls later.

Avatar Contact Receivers can set animator parameters, and their configuration includes self/other filtering and different signal behaviors. [VRChat Creators](https://creators.vrchat.com/common-components/contacts/)

That lets a compatible avatar act as a control surface.

But the avatar-side signal should be a **request**, not unrestricted authority.

### A wrist camera button could follow this sequence

```
Avatar-side button activates
Request signal becomes observable
VRC Eye checks that the module is armed
VRC Eye checks current avatar compatibility
VRC Eye checks the permitted action
VRC Eye applies debounce and cooldown
Camera action is requested
Result state is updated
The button returns to its ready state
```

### Separate interaction states

The avatar module should distinguish:

**Touched:** the contact condition occurred.

**Accepted:** VRC Eye accepted the request.

**Completed:** an appropriate result was observed, when that is possible.

Those are not interchangeable.

### Use latches carefully

A very brief avatar-side event might be missed by an external observer. A deliberately designed request latch can make the interaction more dependable.

However, a latch needs rearming rules, timeouts, and protection against replay after reconnecting.

### A Contact signal is not identity proof

The avatar-side parameter should not be treated as authenticated evidence of which person touched the control.

Sensitive actions should therefore require stronger local arming or confirmation rather than relying on a contact name, tag, or parameter value as authorization.

---

## 34. World-creator controls must not invent a generic world OSC API

We should not create a button that sends:

```
/world/reset
```

and pretend arbitrary worlds understand it.

World-creator controls need a real, deliberately implemented integration.

Udon provides standard input events, but those are not a general external interface for calling any method in a world. [VRChat Creators](https://creators.vrchat.com/worlds/udon/input-events/)

The OSC subsystem should therefore distinguish:

```
Native VRChat input
Native debug-view request
Creator-defined helper action
Editor-only test action
Optional provider-specific action
```

### Debug controls are a useful native subset

The OSC wiki lists debug-view inputs, while the creator documentation explains that some debug views and overlays are restricted unless the world author enables access. [VRChat Wiki](https://wiki.vrchat.com/wiki/OSC)

VRC Eye can expose an appropriately labeled request to open an available debug view.

It must not imply that opening that view causes its entire contents to become available as structured OSC telemetry.

### Creator Mode is not authorization by itself

Our automatic Creator Mode can improve the interface when the logged-in user matches the world author.

That does not replace the actual permissions and transport requirements of a world helper.

The World Controls tab should show unavailable actions honestly rather than route them through invented endpoints or an assumed custom-client bridge.

---

# Part V — Routing, permissions, and conflicts

## 35. Support three routing modes

### Observation mode

VRC Eye receives permitted information and displays diagnostics.

It does not become the owner of unrelated controls.

This should be the easiest way to start.

### Coexistence mode

VRC Eye sends its own reviewed controls while other applications continue to use their existing connections.

The interface should explain that conflict visibility may be incomplete when other applications communicate directly with VRChat.

### Managed routing mode

Approved applications send selected traffic through VRC Eye.

VRC Eye can then validate, transform, rate-limit, log, and arbitrate that routed traffic.

This mode provides more control, but it also creates a dependency on the hub for those routes.

The interface should make that tradeoff clear before changing an application’s configuration.

---

## 36. The OSC Firewall only governs traffic that passes through it

This limitation must be stated plainly.

An application-level OSC router should not claim to block every packet another program might send directly to VRChat.

Our firewall is a policy engine for managed traffic.

Its interface should therefore say something like:

```
Managed routes protected: 4
Direct external routes: Outside this firewall's coverage
```

Not:

> All OSC traffic secured.

### Scope permissions narrowly

A media provider might be allowed to update an approved media-level parameter.

That does not mean it should also be able to change avatars, activate inputs, publish chatbox text, or control the camera.

Permissions should be tied to actions or narrow address groups.

### Source labels are not always verified identities

A raw packet’s address and port are not, by themselves, a robust application identity.

The UI should distinguish:

```
Configured route label
Observed network endpoint
Locally verified adapter identity
Authenticated Eye-to-Eye peer
```

Do not present an application name supplied during discovery as proof of trust.

---

## 37. Resolve multiple writers through explicit ownership

Imagine that three things try to control the same parameter:

```
Face tracking
An avatar preset
A timed expression rule
```

Without arbitration, the visible result may flicker or appear unpredictable.

Our system should assign ownership within defined control groups.

An ownership record might include:

```
Owner
Control group
Scope
Start time
Expiration
Priority
Reason
Handover policy
```

### Prefer temporary ownership over permanent takeover

A photo expression override might own a small group of facial controls for one explicitly armed photo session.

It should not become the permanent owner merely because it was the most recent feature used.

### Use an explicit priority policy

A proposed default would be:

```
Permission revocation and cleanup
Explicitly activated protective policy
Current deliberate user interaction
Active reviewed preset
Background rule
Cosmetic update
```

This is our application policy, not a VRChat rule.

### Explain conflicts before resolving them

For example:

> This preset would temporarily override three parameters currently managed by your face-tracking route.

The user should be able to skip those parameters instead of accepting a full takeover.

---

## 38. Prevent feedback loops

A typical loop could look like:

```
VRC Eye writes a parameter
VRChat reports the value
A rule treats the report as a new user action
The rule writes the parameter again
```

Or:

```
Application A → VRC Eye → Application B → VRC Eye → Application A
```

We should address this through route topology, local operation tracking, event classification, and bounded propagation.

A received observation should not automatically be treated as a new command.

A rule should distinguish:

```
State changed
State entered
State remained active
User explicitly requested action
```

We also should not globally discard identical messages. Identical values can be meaningful in some event protocols, while redundant updates are wasteful in continuous-state routes.

Deduplication must be route-specific.

---

## 39. Provide a visual transformation pipeline

Advanced users should be able to transform values without writing arbitrary executable scripts.

Useful primitives include:

```
Scale
Offset
Clamp
Invert
Dead zone
Threshold
Hysteresis
Smoothing
Enum mapping
Boolean conversion
Rate limit
```

A visual preview should show:

```
Raw value
       ↓
Transformation 1
       ↓
Transformation 2
       ↓
Validated destination value
```

### Example: battery percentage

```
Source: 75
Interpretation: Percent
Divide by 100
Clamp to 0–1
Destination: 0.75
```

### Example: a noisy cosmetic trigger

A proposed rule could activate below one threshold and clear above a different threshold.

For example, activate a low-battery decoration below 20%, then clear it above 25%.

The gap prevents repeated switching when the reading hovers near a single boundary.

### Do not smooth everything

Smoothing can be useful for some continuous visual signals.

It is inappropriate for button releases, urgent cleanup, and many discrete actions.

Each transformation should be permitted only for compatible command classes.

---

## 40. Rules and macros should be bounded workflows

Our automation should be a reviewed rule system, not a hidden general-purpose code execution engine.

A rule needs:

```
Trigger
Conditions
Required permissions
Allowed actions
Cooldown
Maximum duration
Cancellation conditions
Session scope
Failure policy
```

### Example: photography preparation

```
Trigger: User starts photo session

Conditions:
Compatible avatar
Compatible camera controls
No active safety stop

Actions:
Apply selected avatar appearance settings
Apply selected camera settings
Display local countdown
Request one capture

Cancellation:
User cancels
Avatar changes
VRChat disconnects
Safety Mode activates
```

### Example: battery decoration

```
Trigger: Battery state crosses a reviewed threshold

Conditions:
Battery reading is valid
Compatible module is active
Avatar-visible sharing is allowed

Action:
Set a coarse warning indicator

Clear:
Reading recovers through the configured threshold
Module is disabled
Permission is revoked
```

### Avoid rules that fire on every observation

“While battery is low, send another action every time a sample arrives” is not the same as “when the battery becomes low, change the indicator.”

The rule editor should make that distinction understandable.

---

## 41. Eye-to-Eye networking should exchange requests—not raw authority

This is how OSC connects to our separate networking plans.

A peer could request an approved action such as:

```
Join this photo countdown
Review this cosmetic preset
Show this shared notification
Participate in this creator test step
```

The receiving VRC Eye instance decides locally whether that request is allowed.

The flow should be:

```
Authenticated peer request
        ↓
Session and permission checks
        ↓
Local acceptance policy
        ↓
High-level local action
        ↓
Normal OSC permission and capability checks
        ↓
VRChat
```

We should not expose the local OSC port as a general internet-facing remote-control interface.

### Consent should be scoped

Accepting a photo countdown should not authorize future camera actions indefinitely.

Accepting a preset transfer should not automatically apply it.

Accepting a diagnostic request should not authorize microphone control or raw tracking export.

### Revocation should be immediate

When a session ends or permission is revoked, cancel pending peer-originated actions and prevent new ones.

### Synchronization should expose uncertainty

A shared countdown can coordinate local schedules, but acceptance, clock uncertainty, local scheduling, and VRChat execution remain separate stages.

Do not label Eye-to-Eye service latency as VRChat server ping or promise perfectly simultaneous rendering.

---

# Part VI — Diagnostics, recovery, and privacy

## 42. The OSC Activity Inspector should explain behavior

A scrolling packet list is useful, but it is not enough.

The inspector should answer:

> Why did this action happen?

> Why was this action blocked?

> Why did the displayed value change back?

A useful trace would look like:

```
Action: Apply accessory setting
Origin: Photography preset
Avatar generation: Current
Permission: Allowed
Endpoint: Compatible
Ownership: Granted
Transformation: None
Send: Completed locally
Observation: Matching value received
Result: Requested state observed
```

A blocked trace could say:

```
Action: Publish media title
Origin: Media status rule
Permission: Denied
Reason: Chatbox publication disabled for this provider
Result: Not sent
```

### Filters should be practical

Filter by provider, direction, action type, parameter, outcome, dropped-message reason, and current avatar generation.

### Separate “pause display” from “pause traffic”

Pausing the scrolling inspector should not silently stop controls.

Stopping controls should not merely freeze the display.

These controls need unmistakably different labels.

### Bound the inspector’s resource use

The inspector should use a bounded buffer and a separate display refresh rate.

A high-frequency source must not be able to make the interface unusable simply by generating a large volume of events.

---

## 43. Add an action ledger, not just packet logging

Packets show what crossed a transport.

An action ledger shows user intent and policy decisions.

For example:

```
User selected Photography preset
Three settings compatible
One setting skipped
Camera capture requested
Avatar changed
Remaining delayed actions cancelled
```

This is the information that will help troubleshoot actual user complaints.

The ledger should make partial completion obvious.

It should also distinguish an action rejected before transmission from an action sent without a verifiable result.

---

## 44. Integrate OSC events with the Black Box

Our Black Box should record a bounded, privacy-conscious history of important OSC events.

Useful default records include:

```
Connection transitions
Avatar changes
Provider starts and stops
Permission changes
Ownership conflicts
Malformed-packet counts
Queue saturation
Held-input cleanup attempts
Preset application summaries
Rule cancellations
```

Raw chatbox contents, precise tracking histories, and sensitive parameter values should not be collected by default merely because they are available.

### An OSC diagnostic bookmark should capture context

A bookmark could record:

```
Current avatar identity, with export redaction
Active profile
Provider versions
Connection mode
Relevant endpoint descriptions
Current ownership
Recent validation failures
Current pending actions
```

This would be especially useful when comparing a working and failing session.

For your desktop posture issue, a purpose-built diagnostic profile could collect permitted posture-related observations alongside our existing runtime and log information—without pretending those observations expose every internal cause.

---

## 45. Build a guided troubleshooting page

The troubleshooting system should identify the failed layer.

| Symptom                                    | First distinction to investigate                                    |
| ------------------------------------------ | ------------------------------------------------------------------- |
| Nothing appears to connect                 | Discovery, manual endpoint configuration, or OSC enablement.        |
| Commands appear to send but have no effect | Address, type, permission, compatibility, or actual delivery.       |
| Parameters appear but cannot be changed    | Read-only state, policy restriction, or wrong parameter mapping.    |
| A setting changes back immediately         | Another writer, avatar logic, world enforcement, or a restore rule. |
| Controls work on one avatar only           | Avatar-specific compatibility or stale metadata.                    |
| Controls break after switching avatars     | Lifecycle invalidation or rearming.                                 |
| Microphone behaves backward                | Incorrect microphone behavior configuration.                        |
| Camera takes duplicate pictures            | Duplicate producers or inappropriate retries.                       |
| Motion continues after releasing a control | Missing release, stale queued input, or another writer.             |
| Inspector freezes                          | Unbounded logging or excessive UI work.                             |

VRChat’s OSC Debug view can display incoming addresses and values, and opening it also enables OSC. That makes it useful for checking whether messages are reaching the client, but it is not proof that every received message produced its intended effect. [VRChat](https://docs.vrchat.com/docs/osc-debugging)

### Avoid destructive “fix everything” buttons

Troubleshooting should not default to deleting unrelated configuration, resetting large registry areas, or overwriting other applications’ settings.

A repair action should state exactly what it changes and preserve an appropriate backup.

---

## 46. Startup and recovery should fit our simplified application structure

Following the file-structure direction we discussed, OSC setup should be part of starting and configuring the application—not a collection of separate installation scripts.

On startup, VRC Eye should:

```
Load validated configuration
Apply versioned migrations when needed
Prepare local state
Start discovery
Prepare receiving services
Remain unarmed until requirements are satisfied
```

It should not restore live command state from the previous session.

### Persist these

Profiles, route definitions, approved permissions, UI preferences, compatible mappings, and user-selected defaults.

### Do not persist these as active actions

Held inputs, microphone presses, pending captures, expired peer requests, temporary ownership, old tracker poses, and unfinished countdowns.

### Recovery should be conservative

After a crash or uncertain shutdown, the system should return to an observation-first state.

It should explain which controllers require rearming rather than automatically resuming every previous activity.

---

## 47. Treat imported configurations as untrusted data

A shared preset or manifest should be able to describe controls, not grant itself authority.

Import review should show:

```
New controls
Changed addresses
Changed types or ranges
New requested permissions
New network destinations
New automatic triggers
Changed privacy classification
```

A harmless-looking preset name should not conceal a new chatbox publication rule or a route to another machine.

Imports should not execute scripts, read arbitrary local files, launch programs, or automatically activate privileged routes.

A creator signature could help establish where a manifest came from, but it should not replace the user’s permission decision.

---

## 48. Add a simulator before expanding the live feature set

A simulated VRChat endpoint would make this system much easier to test.

It should let us intentionally create:

```
Delayed observations
Missing observations
Rejected values
Changed endpoint types
Avatar transitions
Out-of-order events
Disconnected providers
Conflicting writers
Malformed packets
Port changes
```

The simulator should be visibly distinct from live mode.

A developer should be able to test a rule against a fake environment without risking movement, chatbox publication, microphone changes, or camera spam in a real session.

Recorded data replay should also default to the simulator. Replaying a captured session into live VRChat should never be an accidental consequence of opening a diagnostic file.

---

# Part VII — A 64-step implementation order

The order matters. We should establish state, permissions, and cleanup before adding an impressive number of buttons.

## Phase A — Define the contracts

**1. Define the subsystem boundary.** Identify which features are native OSC, custom-avatar functions, local VRC Eye features, and optional external-provider functions.

**2. Define the high-level action model.** Interfaces request actions such as camera capture or parameter assignment rather than constructing packets independently.

**3. Define endpoint descriptions.** Include types, direction, range, semantics, compatibility evidence, and confirmation behavior.

**4. Define action-result states.** Establish the difference between requested, sent, observed, confirmed, failed, expired, and cancelled.

**5. Define session generations.** Every internally scheduled action must identify its connection and avatar context.

**6. Define permission scopes.** Separate reading, writing, publication, tracking, inputs, camera control, and networking.

**7. Define ownership groups.** Decide which endpoints must be controlled together and which can have independent owners.

**8. Define persistence rules.** Save configuration and reviewed preferences, but never restore volatile actions as active controls.

## Phase B — Build transport and discovery

**9. Implement typed OSC serialization.** Validate address format, types, argument count, and value validity.

**10. Implement bounded packet parsing.** Reject malformed or excessive input without destabilizing the application.

**11. Implement local receiving services.** Bind only to intended interfaces and handle port conflicts explicitly.

**12. Implement OSCQuery discovery.** Discover candidate services without sending visible control actions.

**13. Implement endpoint-description loading.** Preserve missing fields and contradictions instead of filling them with invented certainty.

**14. Implement manual configuration.** Provide a working fallback with clearly labeled send and receive settings.

**15. Implement instance selection.** Prevent ambiguous attachment when multiple candidate clients exist.

**16. Implement separate connection indicators.** Report discovery, sending, receiving, and observation health independently.

## Phase C — Build the state and safety foundation

**17. Implement the observed-state store.** Record value, source, observation time, and confidence.

**18. Implement pending-action tracking.** Connect user intent to subsequent transmission and observation events.

**19. Implement avatar-transition invalidation.** Cancel old work before rearming controls for a new avatar.

**20. Implement command classification.** Distinguish assignments, continuous values, pulses, and toggles.

**21. Implement ownership arbitration.** Resolve competing writers through explicit, visible policy.

**22. Implement priority scheduling.** Prevent urgent cleanup from waiting behind cosmetic traffic.

**23. Implement owned-input release tracking.** Know exactly which held inputs VRC Eye is responsible for releasing.

**24. Implement the global stop sequence.** Block new work, cancel stale work, release owned controls, and report uncertainty.

## Phase D — Deliver the first useful interface

**25. Build Observation Only mode.** Make connection and parameter inspection useful before enabling writes.

**26. Build the parameter browser.** Show real names, types, access, state, and compatibility information.

**27. Build reviewed manual controls.** Begin with a small set of well-understood actions.

**28. Build the Control Deck.** Allow users to pin supported controls without bypassing the shared action system.

**29. Build the basic inspector.** Include filters, validation failures, and bounded history.

**30. Build the action ledger.** Record intent and decisions, not just packets.

**31. Build the setup wizard.** Guide the user from discovery through explicit arming.

**32. Build the first troubleshooting flows.** Cover no connection, no effect, wrong type, and competing writers.

## Phase E — Add sensitive and stateful controls

**33. Implement microphone behavior configuration.** Do not enable misleading mute controls before their semantics are known.

**34. Implement observed microphone state.** Distinguish muted, unmuted, unknown, and conflicting observations.

**35. Implement bounded microphone actions.** Avoid blind retry loops and accidental unmuting.

**36. Implement native Safe Mode requests.** Keep them separate from VRC Eye’s broader safety workflow.

**37. Implement the VRC Eye safety sequence.** Report each local step independently.

**38. Implement the chatbox composer.** Include publication preview, flags, and constraints.

**39. Implement chatbox arbitration.** Ensure manual messages outrank optional status output.

**40. Implement publication cancellation and expiration.** Prevent old messages from appearing after their context has ended.

## Phase F — Add avatar and camera workflows

**41. Implement per-avatar profile identity.** Bind profiles to the appropriate avatar and schema rather than display name alone.

**42. Implement preset diff and review.** Show what will change before applying a multi-setting configuration.

**43. Implement selective restoration.** Do not overwrite newer user choices blindly.

**44. Implement eligible avatar switching.** Wait for the observed transition before applying dependent actions.

**45. Implement scaling controls.** Respect permission, context, and effective observed values.

**46. Implement basic camera actions.** Begin with reviewed modes and capture operations.

**47. Implement camera settings and presets.** Use tested endpoint semantics and endpoint-specific ranges.

**48. Implement optional Dolly workflows.** Validate imported paths and distinguish delay acceptance from observed playback.

## Phase G — Add managed routes and advanced modules

**49. Implement managed-route configuration.** Explain which traffic is and is not covered by our policy engine.

**50. Implement per-route permissions.** Grant only the capabilities required by that source.

**51. Implement transformation primitives.** Provide typed, bounded operations rather than arbitrary script execution.

**52. Implement feedback-loop protection.** Separate observations from commands and bound propagation.

**53. Implement optional media and hardware signals.** Include validity state and explicit audience settings.

**54. Implement tracking-route diagnostics.** Measure local queue behavior without making unsupported end-to-end latency claims.

**55. Implement bounded rules and macros.** Require cancellation conditions, expiration, and reviewed actions.

**56. Implement the optional Avatar Link request contract.** Prepare the interface without making the Unity toolkit a dependency.

## Phase H — Integrate, test, and harden

**57. Connect the overlay to the shared action service.** Do not create separate packet implementations for VR controls.

**58. Connect Avatar, World, and Safety pages.** Reuse the same state, permissions, and ownership decisions.

**59. Connect approved Eye-to-Eye intents.** Require local authorization before translating peer requests into actions.

**60. Integrate the Black Box.** Record useful metadata while keeping sensitive payloads out of default diagnostics.

**61. Add the simulator and fault injection.** Make packet loss, stale state, and conflicts reproducible.

**62. Test lifecycle failures.** Cover avatar changes, reconnects, application shutdown, provider loss, and interrupted actions.

**63. Test platform and coexistence behavior.** Verify the actual supported environments and combinations with other applications.

**64. Establish release gates.** A control should not be labeled dependable until its permissions, cleanup, compatibility, and failure reporting have been tested.

---

# Part VIII — The acceptance tests that matter most

A feature is not finished merely because its button works once.

These are the tests I would require before trusting the subsystem.

| Test                                          | Required behavior                                                                                |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| Avatar changes during a preset                | Old queued writes are cancelled.                                                                 |
| User stops controls during a held input       | New writes stop; owned releases are prioritized.                                                 |
| UI closes while a pulse is active             | Cleanup is attempted by the control service, not dependent on the button widget remaining alive. |
| A toggle has no confirmation                  | No blind repeated toggling.                                                                      |
| A provider sends invalid types                | Messages are rejected and the reason is visible.                                                 |
| A provider floods the receiver                | Resource use remains bounded; important controls remain responsive.                              |
| Two providers target the same parameter       | The conflict is visible and governed by ownership policy.                                        |
| Another app communicates directly with VRChat | The UI does not falsely claim complete firewall coverage.                                        |
| Discovery succeeds but observations fail      | Features requiring observations become unavailable or unverified.                                |
| A stable parameter sends no new changes       | It is not automatically treated as failed solely because its value is unchanged.                 |
| A delayed photo outlives its session          | VRC Eye-owned pending work expires or is cancelled.                                              |
| A screenshot appears after capture            | Evidence is recorded without inventing a guaranteed one-to-one association.                      |
| Microphone state becomes unavailable          | Privacy status changes to unverified rather than remaining falsely reassuring.                   |
| Imported preset requests new permissions      | It remains inactive until reviewed.                                                              |
| Peer permission is revoked                    | Pending peer-originated work is cancelled and new requests are rejected.                         |
| Tracking source disappears                    | Stale values are not endlessly retransmitted.                                                    |
| World or avatar logic overrides a value       | VRC Eye reports the effective observation rather than fighting indefinitely.                     |
| Application restarts                          | Old movement, captures, microphone presses, and peer requests do not resume automatically.       |
| User changes a setting after a preset         | Restoration does not blindly erase the newer choice.                                             |
| Diagnostics are exported                      | Sensitive values and identifying details follow the selected redaction policy.                   |

---

# The finished experience

The end result should not feel like the user is operating a packet editor.

A Casual user should be able to open VRC Eye, see that VRChat is available, use a microphone control that accurately describes its behavior, send a reviewed chatbox message, take a photo, and apply a compatible avatar preset.

An Advanced user should be able to understand why a control is unavailable, identify competing writers, inspect parameter mappings, and configure narrowly scoped routes.

A Creator should be able to test compatible avatar modules and world-facing controls without confusing native OSC capabilities with custom helper functionality.

A Developer should be able to reproduce failures, inspect decisions, and verify lifecycle behavior without relying on a live VRChat session for every test.

**The real product is not “lots of OSC buttons.” It is one consistent system that knows what each button means, who may activate it, what can conflict with it, when it must stop, and what evidence exists that it worked.**