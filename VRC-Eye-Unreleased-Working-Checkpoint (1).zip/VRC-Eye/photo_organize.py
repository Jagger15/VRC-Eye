"""Journaled copy/verify/move and conflict-aware undo for selected photos."""
from hashlib import sha256
import json
import os
from pathlib import Path
import tempfile
import uuid
from avatar_library_files import fingerprint
from creator_projects import assert_no_links,local_path
from photo_files import read_photo
from photo_store import key,stamp,json_data


def prepare(store,scope,photo,destination):
    row=store.get(scope,photo)
    if not row or row['status']!='Available':raise ValueError('Select an available, indexed photo.')
    destination=assert_no_links(local_path(destination));assert_no_links(destination.parent)
    if not destination.parent.is_dir() or destination.exists():raise ValueError('Choose an existing destination folder and an unused filename.')
    if destination.suffix.casefold()!=Path(row['path']).suffix.casefold():raise ValueError('Keep the image file extension unchanged.')
    info=destination.parent.stat()
    return dict(scope=scope,photo=photo,source=row['path'],destination=str(destination),sha256=row['sha256'],
                fingerprint=row['fingerprint'],parent=[info.st_dev,info.st_ino],id=uuid.uuid4().hex)


def publish(path,data,check=lambda:None):
    path=assert_no_links(local_path(path));assert_no_links(path.parent)
    fd,tmp=tempfile.mkstemp(prefix='.eye-copy-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        check();assert_no_links(path.parent)
        # Hard-link publication is atomic and refuses an existing destination.
        # An unsupported filesystem fails without replacing any file.
        os.link(tmp,path)
    finally:
        try:os.unlink(tmp)
        except OSError:pass


class Organizer:
    def __init__(self,store):self.store=store;self.reviews={}
    def prepare(self,scope,photo,destination):
        import time
        plan=prepare(self.store,scope,photo,destination);plan['expires']=time.monotonic()+120
        self.reviews={plan['id']:json.dumps(plan,sort_keys=True)};return plan
    def journal(self,scope,identity,state,payload):
        with self.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS photo_file_actions_v1(id TEXT PRIMARY KEY,scope TEXT,photo TEXT,state TEXT,payload TEXT,updated TEXT)')
            db.execute('INSERT OR REPLACE INTO photo_file_actions_v1 VALUES(?,?,?,?,?,?)',(identity,scope,payload['photo'],state,json.dumps(payload),stamp()))
    def history(self,scope):
        with self.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS photo_file_actions_v1(id TEXT PRIMARY KEY,scope TEXT,photo TEXT,state TEXT,payload TEXT,updated TEXT)')
            return [dict(r) for r in db.execute('SELECT * FROM photo_file_actions_v1 WHERE scope=? ORDER BY updated DESC LIMIT 100',(scope,))]
    def execute(self,plan,check=lambda:None):
        import time
        if self.reviews.pop(plan.get('id'),None)!=json.dumps(plan,sort_keys=True) or time.monotonic()>plan['expires']:raise ValueError('Move review expired or changed.')
        check();row=self.store.get(plan['scope'],plan['photo'])
        if not row or (row['path'],row['sha256'],row['fingerprint'])!=(plan['source'],plan['sha256'],plan['fingerprint']):raise ValueError('The selected photo changed.')
        source=assert_no_links(local_path(plan['source']));destination=assert_no_links(local_path(plan['destination']))
        info=destination.parent.stat()
        if [info.st_dev,info.st_ino]!=plan['parent']:raise ValueError('The destination folder changed.')
        raw,_=read_photo(source,expected=plan['fingerprint'])
        if sha256(raw).hexdigest()!=plan['sha256']:raise ValueError('Source bytes changed.')
        self.journal(plan['scope'],plan['id'],'Prepared',plan)
        published=False;removed=False
        try:
            publish(destination,raw,check);published=True
            copied,fp=read_photo(destination)
            if sha256(copied).hexdigest()!=plan['sha256']:raise ValueError('Copied bytes could not be verified.')
            self.journal(plan['scope'],plan['id'],'Copy verified; source retained',plan)
            check();assert_no_links(source)
            if fingerprint(source.stat())!=plan['fingerprint']:raise ValueError('Source changed; both files retained.')
            os.unlink(source);removed=True
            evidence={k:row[k] for k in ('size','width','height','format')};evidence['fingerprint']=fp
            with self.store.connect() as db:
                db.execute('UPDATE photo_files_v4 SET path=?,path_key=?,evidence=?,source_id=?,status=?,checked=? WHERE scope=? AND photo_id=?',
                    (str(destination),key(destination),json_data(evidence),'','Available',stamp(),plan['scope'],plan['photo']))
            self.journal(plan['scope'],plan['id'],'Complete',plan);return plan
        except Exception:
            self.journal(plan['scope'],plan['id'],'Recovery required: destination published'+('; source removed' if removed else '; source retained') if published else 'Stopped before publication',plan)
            raise
    def prepare_undo(self,scope,receipt):
        if receipt.get('scope')!=scope or receipt.get('state')!='Complete':raise ValueError('Only a completed move in this workspace can be undone.')
        old=json.loads(receipt['payload']);row=self.store.get(scope,old['photo'])
        if not row or row['path']!=old['destination'] or row['sha256']!=old['sha256']:raise ValueError('Photo changed after this move; undo would overwrite newer data.')
        return self.prepare(scope,old['photo'],old['source'])

    def recover(self,scope,receipt,check=lambda:None):
        current=next((r for r in self.history(scope) if r['id']==receipt.get('id')),None)
        if current!=receipt or receipt['scope']!=scope or receipt['state']=='Complete':raise ValueError('Select an unchanged interrupted move receipt.')
        plan=json.loads(receipt['payload'])
        if plan.get('operation')=='trash':raise ValueError('Restore this file from the OS trash, then relink it in Photos.')
        row=self.store.get(scope,plan['photo'])
        if not row or row['sha256']!=plan['sha256'] or row['path'] not in (plan['source'],plan['destination']):raise ValueError('The photo changed after this move. Reconcile it manually.')
        matches=[]
        for location in (plan['destination'],plan['source']):
            path=assert_no_links(local_path(location))
            if not path.exists():continue
            raw,fp=read_photo(path)
            if sha256(raw).hexdigest()!=plan['sha256']:raise ValueError('A recorded path contains different bytes. No automatic recovery was applied.')
            matches.append((path,fp))
        if not matches:raise ValueError('Neither path contains the original bytes. Locate the photo and relink it manually.')
        path,fp=matches[0];check()
        evidence={k:row[k] for k in ('size','width','height','format')};evidence['fingerprint']=fp
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');check()
            current=db.execute('SELECT path,digest FROM photo_files_v4 WHERE scope=? AND photo_id=?',(scope,plan['photo'])).fetchone()
            if current is None or current['path']!=row['path'] or current['digest']!=row['sha256']:raise ValueError('The photo changed during recovery.')
            db.execute("UPDATE photo_files_v4 SET path=?,path_key=?,evidence=?,source_id='',status='Available',checked=? WHERE scope=? AND photo_id=?",(str(path),key(path),json_data(evidence),stamp(),scope,plan['photo']))
        state='Recovered; both identical copies retained' if len(matches)>1 else 'Recovered; verified '+('destination' if str(path)==plan['destination'] else 'source')
        self.journal(scope,plan['id'],state,plan);return state

    def trash(self,scope,photo,*,expected,check=lambda:None,trash_adapter=None):
        if trash_adapter is None:
            try:from send2trash import send2trash as trash_adapter
            except ImportError:raise ValueError('OS trash requires the optional Send2Trash package. Move to the Eye recovery folder remains available.') from None
        row=self.store.get(scope,photo)
        if not row or row['status']!='Available' or row['fingerprint']!=expected:raise ValueError('The selected photo changed. Review trash again.')
        raw,_=read_photo(row['path'],expected=expected)
        if sha256(raw).hexdigest()!=row['sha256']:raise ValueError('The photo bytes changed.')
        plan=dict(id=uuid.uuid4().hex,operation='trash',photo=photo,source=row['path'],destination='Operating-system trash',sha256=row['sha256'])
        self.journal(scope,plan['id'],'Trash prepared',plan)
        check();assert_no_links(local_path(row['path']))
        if fingerprint(Path(row['path']).stat())!=expected:raise ValueError('The photo changed before trash handoff.')
        self.journal(scope,plan['id'],'Trash handoff; outcome pending',plan)
        try:
            trash_adapter(row['path']);self.store.availability(scope,photo,'Missing')
            self.journal(scope,plan['id'],'OS trash accepted; restore through desktop trash',plan)
        except Exception:
            self.journal(scope,plan['id'],'Trash outcome unconfirmed; inspect OS trash and original path',plan);raise
        return plan['id']
