"""Local-first VRC Eye feature coordinator.

Private records and received peer claims never share an ownership namespace.
Networking is lazy, opt-in, and every disclosure is an explicit send. Nothing in
this module executes remote commands, changes VRChat, or trusts a claimed VRChat
identity. Thread callbacks enqueue bounded events; application tick owns routing.
"""
from __future__ import annotations
from collections import deque, OrderedDict
from copy import deepcopy
import base64
import hashlib
import json
from pathlib import Path
import queue
import tempfile
import threading
import time
import unicodedata
import uuid

from peer_store import PeerStore
from peer_network_settings import (SETTING_KEY, MAX_PROFILES, decode_settings, encode_settings,
                                   validate_host, validate_profile, validate_source_address)
from peer_protocol import FEATURES, PROTOCOL_VERSION, APP_VERSION, PermissionEngine, capabilities, envelope, validate_envelope, validate_payload

ITEM_MESSAGES = {
    'bookmark': 'bookmark.card', 'party': 'party.snapshot', 'photo': 'photo.plan',
    'cue': 'media.cue', 'checklist': 'checklist.snapshot', 'playtest': 'creator.snapshot',
    'diagnostic': 'diagnostics.card', 'performance': 'performance.card',
    'preset': 'config.package', 'session_card': 'session.card', 'ready_template': 'ready.request',
}
ITEM_KINDS = ('note', *ITEM_MESSAGES)
PROFILE_FIELDS = ('alias', 'bio', 'pronouns', 'status_text', 'favorite_color', 'icon', 'creator_mode', 'streamer_status')
CONTEXT_KINDS = {'lab.observation', 'party.snapshot', 'creator.snapshot', 'checklist.snapshot', 'role.assign', 'ready.request', 'ready.response', 'countdown.start', 'photo.plan', 'media.cue', 'diagnostic.confirm', 'encounter.confirm', 'novelty.confetti'}
SNAPSHOTS = {'party.snapshot': 'party_id', 'creator.snapshot': 'playtest_id', 'checklist.snapshot': 'checklist_id'}
REQUEST_RESPONSES = {'ready.request': 'ready.response', 'safety.checkin': 'safety.response', 'troubleshooting.request': 'troubleshooting.response'}
EPHEMERAL_HISTORY = {'lab.observation', 'presence.update', 'session.card', 'safety.checkin', 'safety.response', 'safety.alert', 'ready.request', 'ready.response', 'countdown.start', 'media.cue', 'novelty.confetti', 'troubleshooting.request', 'troubleshooting.response'}


def _id():
    return str(uuid.uuid4())


def _bounded_text(value, limit=4096):
    if not isinstance(value, str) or len(value) > limit or any(ord(ch) < 32 and ch not in '\n\t' for ch in value):
        raise ValueError('Text is invalid or too long.')
    return value


def _write_json(path, value):
    data = json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2)
    created = False
    try:
        with open(path, 'x', encoding='utf-8') as handle:
            created = True
            handle.write(data)
    except BaseException:
        if created:
            try:
                Path(path).unlink()
            except OSError:
                pass
        raise


class PeerService:
    def __init__(self, path=None, *, clock=time.monotonic, wall=time.time, transport_factory=None):
        self.clock, self.wall = clock, wall
        self.store = PeerStore(path)
        self.transport_factory = transport_factory
        self._transport = None
        self._tempdir = None
        self._queue = queue.Queue(maxsize=512)
        self._lock = threading.RLock()
        self._closed = False
        self._epoch = 0
        self._blocked = False
        self._block_reason = ''
        self._boundary = None
        self._mode = 'Private'
        self._reason = 'Private Mode: local tools are available; peer networking is off.'
        self._requested_mode = None
        # Read the raw value once: PeerStore.get intentionally hides bad JSON,
        # while privacy policy must distinguish corruption from a missing key.
        with self.store._lock:
            row = self.store.db.execute('SELECT value FROM peer_meta WHERE key=?', (SETTING_KEY,)).fetchone()
        self._network_config = decode_settings(row[0] if row else None)
        self._identity = ''
        self._peers = {}
        self._events = deque(maxlen=256)
        self._event_sequence = 0
        self._pending = OrderedDict()
        self._inbox = deque(maxlen=200)
        self._outbox = OrderedDict()
        self._seen = OrderedDict()
        self._rates = {}
        self._contexts = {}
        self._ended_contexts = set()
        self._item_cache = None
        self._requests = {}
        self._timers = OrderedDict()
        self._notifications = deque(maxlen=40)
        self._confirmations = {}
        self._receipts = {}
        self._counters = {'received': 0, 'sent': 0, 'rejected': 0, 'suppressed': 0, 'expired': 0, 'rate_limited': 0}
        self.permissions = PermissionEngine(clock=self.wall)
        saved = self.store.get('permissions', {})
        if saved:
            try:
                self.permissions.restore(saved)
            except (ValueError, TypeError, KeyError):
                pass
        self._profile = self.store.get('profile', {'fields': {}, 'visibility': {}, 'revision': 0})
        if not isinstance(self._profile, dict) or not isinstance(self._profile.get('fields'), dict):
            self._profile = {'fields': {}, 'visibility': {}, 'revision': 0}
        self._availability = self.store.get('availability', 'AVAILABLE')
        self._privacy = {'history_enabled': False, 'notifications': True, 'reduced_motion': True, 'streamer': False, 'safety': False, 'incognito': False, 'notifications_muted': False, 'history_inhibited': False}
        saved_privacy = self.store.get('privacy', {})
        for key in self._privacy:
            if key != 'history_inhibited' and type(saved_privacy.get(key)) is bool:
                self._privacy[key] = saved_privacy[key]
        self._privacy_own = dict(self._privacy)
        self._privacy_inherited = {}
        if self._history_enabled():
            for message in self.store.history():
                message['retained'] = True
                self._inbox.append(message)
            self._receipts = {entry['receipt_id']: entry for entry in self.store.receipts() if isinstance(entry, dict) and 'receipt_id' in entry}
        self._event('service.private')

    def _event(self, event_type, **fields):
        self._event_sequence += 1
        safe = {key: value for key, value in fields.items() if key in ('kind', 'family', 'state', 'count', 'decision', 'reason', 'source')}
        self._events.append({'sequence': self._event_sequence, 'type': event_type, 'at': self.wall(), **safe})

    def _history_enabled(self):
        return self._privacy['history_enabled'] and not self._privacy['history_inhibited'] and not self._privacy['incognito']

    def _persist_permissions(self):
        try:
            snapshot = self.permissions.snapshot(persistent_only=True)
        except TypeError:
            snapshot = self.permissions.snapshot()
            if isinstance(snapshot, dict) and isinstance(snapshot.get('grants'), list):
                snapshot['grants'] = [g for g in snapshot['grants'] if g.get('scope') == 'persistent']
        self.store.set('permissions', snapshot)

    def _network(self):
        if self._closed:
            raise ValueError('Peer Services is closed.')
        if self._blocked or self._privacy['incognito']:
            raise ValueError(self._block_reason or 'Peer networking is disabled by privacy settings.')
        if self._transport is None:
            factory = self.transport_factory
            if factory is None:
                from peer_transport import PeerTransport
                factory = PeerTransport
            if self.store.path is None:
                self._tempdir = tempfile.TemporaryDirectory(prefix='vrc-eye-peer-')
                directory = Path(self._tempdir.name)
            else:
                directory = self.store.path.with_suffix('.identity')
            epoch = self._epoch
            def callback(event):
                try:
                    self._queue.put_nowait((epoch, event))
                    return True
                except queue.Full:
                    # Transport must not acknowledge a frame that was not accepted.
                    return False
            self._transport = factory(directory, callback)
            setter = getattr(self._transport, 'set_relay_only', None)
            if setter is not None:
                setter(self._network_config['relay_only'])
        return self._transport

    def network_settings(self):
        """Return cached local choices; this neither reads disk nor connects."""
        with self._lock:
            return deepcopy(self._network_config)

    def _network_policy_reason(self, mode):
        if self._closed:
            return 'Peer Services is closed.'
        if self._blocked or self._privacy['incognito']:
            return self._block_reason or 'Peer networking is disabled by privacy settings.'
        if self._network_config['relay_only'] and mode != 'Relay':
            return 'Relay-only protection blocks direct LAN and VPN connections.'
        return ''

    def set_network_privacy(self, relay_only):
        if type(relay_only) is not bool:
            raise ValueError('Relay-only protection must be true or false.')
        with self._lock:
            if self._closed:
                raise ValueError('Peer Services is closed.')
            previous = self._network_config['relay_only']
            if relay_only and self._transport:
                state = self._transport.snapshot()
                # Unknown/in-flight routes are treated as direct unless their
                # validated request and transport both identify Relay.
                if state.get('mode') != 'Relay' or self._requested_mode not in (None, 'Relay'):
                    self.private_mode()
            proposed = dict(self._network_config, relay_only=relay_only, recovery_reason='')
            if relay_only:
                # A failed disk write cannot silently relax the live policy.
                self._network_config['relay_only'] = True
                if self._transport and hasattr(self._transport, 'set_relay_only'):
                    self._transport.set_relay_only(True)
            self.store.set(SETTING_KEY, encode_settings(proposed))
            self._network_config = proposed
            if not relay_only and self._transport and hasattr(self._transport, 'set_relay_only'):
                self._transport.set_relay_only(False)
            if previous != relay_only:
                self._event('network.policy', state='RELAY_ONLY' if relay_only else 'EXPLICIT_DIRECT_ALLOWED')
            return self.network_settings()

    def save_connection_profile(self, data, profile_id=None):
        with self._lock:
            if self._closed:
                raise ValueError('Peer Services is closed.')
            if not isinstance(data, dict):
                raise ValueError('Enter a connection profile.')
            selected = profile_id or data.get('id')
            existing = next((p for p in self._network_config['profiles'] if p['id'] == selected), None)
            if selected and existing is None:
                raise ValueError('The selected connection profile no longer exists.')
            profile = validate_profile(data, identifier=selected)
            profiles = [deepcopy(p) for p in self._network_config['profiles'] if p['id'] != selected]
            if len(profiles) >= MAX_PROFILES:
                raise ValueError('The connection profile limit has been reached.')
            profiles.append(profile)
            proposed = dict(self._network_config, profiles=profiles)
            self.store.set(SETTING_KEY, encode_settings(proposed))
            self._network_config = proposed
            return deepcopy(profile)

    def delete_connection_profile(self, profile_id):
        with self._lock:
            if self._closed:
                raise ValueError('Peer Services is closed.')
            profiles = [deepcopy(p) for p in self._network_config['profiles'] if p['id'] != profile_id]
            if len(profiles) == len(self._network_config['profiles']):
                return False
            proposed = dict(self._network_config, profiles=profiles)
            self.store.set(SETTING_KEY, encode_settings(proposed))
            self._network_config = proposed
            return True

    def preview_connection_profile(self, profile_id):
        with self._lock:
            profile = next((p for p in self._network_config['profiles'] if p['id'] == profile_id), None)
            if profile is None:
                raise ValueError('Choose a saved connection profile.')
            profile = validate_profile(deepcopy(profile))
            reason = self._network_policy_reason(profile['mode'])
            return {**profile, 'action': 'host', 'available': not reason, 'reason': reason,
                    'endpoint_visibility': 'Relay sees endpoints; peers see relay only' if profile['mode'] == 'Relay'
                    else 'Peers can see the selected network endpoint'}

    def start_connection_profile(self, profile_id):
        with self._lock:
            profile = self.preview_connection_profile(profile_id)
            if not profile['available']:
                raise ValueError(profile['reason'])
            # Source address belongs to invitation joining. Hosting binds the
            # profile address itself; a saved route never includes a secret
            # invitation and never joins a contact automatically.
            kwargs = {'relay_pin': profile['relay_pin']} if profile['mode'] == 'Relay' else {}
            return self.host(profile['address'], profile['port'], mode=profile['mode'], **kwargs)

    def host(self, address, port=0, mode='LAN', **kwargs):
        with self._lock:
            if set(kwargs) - {'relay_pin', 'alias'}:
                raise ValueError('Unsupported hosting option.')
            route = validate_host(address, port, mode, relay_pin=kwargs.get('relay_pin', ''))
            alias = kwargs.get('alias', '')
            if not isinstance(alias, str) or len(alias) > 80 or any(unicodedata.category(c).startswith('C') for c in alias):
                raise ValueError('Invalid device alias.')
            reason = self._network_policy_reason(route['mode'])
            if reason:
                raise ValueError(reason)
            transport = self._network()
            options = dict(kwargs)
            if route['mode'] == 'Relay':
                options['relay_pin'] = route['relay_pin']
            result = transport.host(route['address'], route['port'], mode=route['mode'], **options)
            self._requested_mode = route['mode']
            self._mode = route['mode']
            self._reason = 'Starting peer host.'
            self._event('network.start', state=route['mode'])
            return result

    def invite(self, ttl=600):
        with self._lock:
            if self._transport is None or self._blocked or self._privacy['incognito']:
                raise ValueError('Start a host before creating a connection invitation.')
            return self._transport.invite(ttl=ttl)

    def inspect_invitation(self, invitation):
        """Offline review: never returns bearer tokens or public-key material."""
        from peer_transport import parse_invitation
        with self._lock:
            info = parse_invitation(invitation, now=self.wall())
            route = validate_host(info['address'], info['port'], info['mode'], relay_pin=info.get('relay_pin', ''))
            key = info['key']
            device = 'eye_' + hashlib.sha256(base64.urlsafe_b64decode(key + '=' * (-len(key) % 4))).hexdigest()
            reason = self._network_policy_reason(route['mode'])
            return {'mode': route['mode'], 'address': route['address'], 'port': route['port'],
                    'endpoint': ('[' + route['address'] + ']' if ':' in route['address'] else route['address']) + ':' + str(route['port']),
                    'expires_at': info['expires'], 'device_id': device, 'pin': info['pin'],
                    'relay_pin': route['relay_pin'], 'available': not reason, 'reason': reason,
                    'endpoint_visibility': 'Relay sees endpoints; peers see relay only' if route['mode'] == 'Relay'
                    else 'Peers can see the selected network endpoint'}

    def join(self, invitation, source_address=''):
        with self._lock:
            review = self.inspect_invitation(invitation)
            source_address = validate_source_address(source_address)
            if source_address and review['mode'] == 'Relay':
                raise ValueError('Relay invitations do not accept a direct source address.')
            if not review['available']:
                raise ValueError(review['reason'])
            transport = self._network()
            options = {'alias': 'VRC Eye device'}
            if source_address:
                options['source_address'] = source_address
            result = transport.join(invitation, **options)
            self._requested_mode = review['mode']
            self._mode = 'Connecting'
            self._reason = 'Authenticating the invited device.'
            self._event('network.join')
            return result

    def _end_peer(self, peer_id):
        peer = self._peers.get(peer_id)
        if not peer:
            return
        session = peer.get('session', '')
        self._ended_contexts = {value for value in self._ended_contexts if value[0] != peer_id}
        self.permissions.end_session(session)
        peer.update(state='OFFLINE', availability='UNKNOWN', profile={}, session_card=None, roles={})
        for key, message in list(self._pending.items()):
            if message['message']['peer_id'] == peer_id:
                self._pending.pop(key, None)
        for context in self._contexts.values():
            if context['owner'] == peer_id:
                context['active'] = False
                context['state'] = 'HOST_DISCONNECTED'
        for request in self._requests.values():
            if request['peer_id'] == peer_id:
                request['active'] = False
        for timer in self._timers.values():
            if timer.get('peer_id') == peer_id and timer['state'] == 'RUNNING':
                timer['state'] = 'CANCELED'
        self._event('peer.disconnected')

    def disconnect(self, peer_id):
        with self._lock:
            if self._transport:
                self._transport.disconnect(peer_id)
            self._end_peer(peer_id)

    def private_mode(self):
        with self._lock:
            self._epoch += 1
            transport, self._transport = self._transport, None
            if transport:
                transport.close()
            for peer_id in list(self._peers):
                self._end_peer(peer_id)
            self.permissions.revoke(temporary_only=True)
            self._pending.clear()
            self._notifications.clear()
            self._mode = 'Private'
            self._requested_mode = None
            self._reason = 'Private Mode: local tools are available; peer networking is off.'
            self._event('service.private')
            if self._tempdir:
                self._tempdir.cleanup()
                self._tempdir = None

    def set_environment(self, blocked, reason=''):
        with self._lock:
            blocked = bool(blocked)
            if blocked and not self._blocked:
                self.private_mode()
            self._blocked = blocked
            self._block_reason = _bounded_text(str(reason), 200)

    def context_boundary(self, token):
        with self._lock:
            if token == self._boundary:
                return
            initial = self._boundary is None
            self._boundary = token
            if not initial:
                for peer_id, peer in self._peers.items():
                    self._ended_contexts.add((peer_id, peer.get('session'), peer.get('session')))
                    for context in self._contexts.values():
                        self._ended_contexts.add((peer_id, peer.get('session'), context['id']))
                self.permissions.revoke(temporary_only=True)
                for context in self._contexts.values():
                    context['active'] = False
                    context['state'] = 'CONTEXT_ENDED'
                self._pending.clear()
                for request in self._requests.values():
                    request['active'] = False
                for timer in self._timers.values():
                    if timer.get('source') == 'VRC_EYE':
                        timer['state'] = 'CANCELED'
                self._event('context.ended')

    def _refresh_privacy(self):
        effective = dict(self._privacy_own)
        for values in self._privacy_inherited.values():
            for key, value in values.items():
                effective[key] = effective[key] or value
        self._privacy = effective
        if effective['history_inhibited'] or effective['incognito'] or not effective['history_enabled']:
            self._inbox = deque((m for m in self._inbox if not m.get('retained')), maxlen=200)
        if effective['incognito'] and self._transport:
            self.private_mode()
        if not effective['notifications'] or effective['streamer'] or effective['notifications_muted'] or effective['safety']:
            self._notifications.clear()

    def set_inherited_privacy(self, source, **flags):
        """Restrictive app policy is additive; a page toggle cannot undo it."""
        if source not in ('players', 'wellness', 'application', 'accessibility'):
            raise ValueError('Unknown inherited privacy source.')
        allowed = {'incognito', 'streamer', 'notifications_muted', 'history_inhibited', 'reduced_motion', 'safety'}
        if set(flags) - allowed or any(type(value) is not bool for value in flags.values()):
            raise ValueError('Invalid inherited privacy restriction.')
        with self._lock:
            self._privacy_inherited[source] = dict(flags)
            self._refresh_privacy()
            return deepcopy(self._privacy)

    def set_privacy(self, *, history_enabled=None, notifications=None, reduced_motion=None,
                    streamer=None, safety=None, incognito=None, notifications_muted=None,
                    history_inhibited=None):
        with self._lock:
            values = locals().copy()
            for key in self._privacy_own:
                value = values.get(key)
                if value is not None:
                    if type(value) is not bool:
                        raise ValueError('Privacy settings must be true or false.')
                    self._privacy_own[key] = value
            self._refresh_privacy()
            self.store.set('privacy', {k: value for k, value in self._privacy_own.items() if k != 'history_inhibited'})
            return deepcopy(self._privacy)

    def set_profile(self, fields, visibility=None):
        with self._lock:
            if not isinstance(fields, dict) or any(key not in PROFILE_FIELDS for key in fields):
                raise ValueError('Unknown profile field.')
            merged = dict(self._profile['fields'])
            merged.update(fields)
            validated = validate_payload('profile.update', merged)
            validated.pop('revision', None)
            vis = dict(self._profile.get('visibility', {}))
            if visibility is not None:
                if not isinstance(visibility, dict) or any(key not in PROFILE_FIELDS or value not in ('private', 'approved', 'session') for key, value in visibility.items()):
                    raise ValueError('Invalid profile visibility.')
                vis.update(visibility)
            self._profile = {'fields': validated, 'visibility': vis, 'revision': self._profile.get('revision', 0) + 1}
            self.store.set('profile', self._profile)
            return deepcopy(self._profile)

    def set_availability(self, value):
        payload = validate_payload('presence.update', {'availability': value})
        with self._lock:
            self._availability = payload['availability']
            if self._availability in ('DND', 'BUSY'):
                self._notifications.clear()
            self.store.set('availability', self._availability)
            return self._availability

    def _local_payload(self, kind, data, identifier, revision):
        if kind not in ITEM_KINDS or not isinstance(data, dict):
            raise ValueError('Unknown local item type.')
        data = deepcopy(data)
        if kind == 'note':
            if any(key not in ('title', 'text') for key in data):
                raise ValueError('Unknown note field.')
            return {'title': _bounded_text(data.get('title', ''), 200), 'text': _bounded_text(data.get('text', ''), 16000)}
        if kind in ('party', 'playtest', 'checklist'):
            field = {'party': 'party_id', 'playtest': 'playtest_id', 'checklist': 'checklist_id'}[kind]
            data[field] = identifier
            data['revision'] = revision
        if kind == 'ready_template':
            data.setdefault('request_id', identifier)
            data.setdefault('deadline', self.wall() + 300)
        if kind == 'cue':
            data.setdefault('media_session_id', identifier)
        if kind == 'checklist':
            data['items'] = [dict({'item_id': _id(), 'status': 'TODO'}, **item) for item in data.get('items', [])]
        return validate_payload(ITEM_MESSAGES[kind], data)

    def save_item(self, kind, data, item_id=None):
        with self._lock:
            previous = self.store.item(item_id) if item_id else None
            if item_id and previous is None:
                raise ValueError('The selected local item no longer exists.')
            if previous and previous['kind'] != kind:
                raise ValueError('Cannot change the type of a saved item.')
            identifier = item_id or _id()
            revision = previous['revision'] + 1 if previous else 1
            payload = self._local_payload(kind, data, identifier, revision)
            item = {'id': identifier, 'kind': kind, 'data': payload, 'revision': revision, 'source': previous.get('source', 'LOCAL') if previous else 'LOCAL', 'updated_at': self.wall()}
            self.store.save_item(item)
            self._item_cache = None
            self._event('item.saved', kind=kind, source=item['source'])
            return deepcopy(item)

    def items(self, kind=None):
        with self._lock:
            return self.store.items(kind)

    def delete_item(self, item_id):
        with self._lock:
            result = self.store.delete_item(item_id)
            self._item_cache = None
            for context in self._contexts.values():
                if context['owner'] == 'LOCAL' and context['id'] == item_id:
                    context['active'] = False
                    context['state'] = 'DELETED'
            return result

    def export_item(self, item_id, path):
        with self._lock:
            item = self.store.item(item_id)
            if item is None:
                raise ValueError('Choose a saved local item.')
            data = {'format': 'vrc-eye-local-item', 'schema': 1, 'kind': item['kind'], 'data': item['data'], 'source': item['source']}
            _write_json(path, data)
            return str(path)

    def import_item(self, path):
        path = Path(path)
        if path.stat().st_size > 131072:
            raise ValueError('The local import is too large.')
        def unique(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError('Duplicate import keys.')
                value[key] = item
            return value
        with path.open('r', encoding='utf-8') as handle:
            data = json.loads(handle.read(131073), object_pairs_hook=unique,
                              parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid number.')))
        if not isinstance(data, dict) or data.get('format') != 'vrc-eye-local-item' or data.get('schema') != 1 or set(data) - {'format', 'schema', 'kind', 'data', 'source'}:
            raise ValueError('Unsupported local item file.')
        with self._lock:
            item = self.save_item(data['kind'], data['data'])
            item['source'] = 'IMPORTED'
            self.store.save_item(item)
            self._item_cache = None
            return deepcopy(item)

    def _permission(self, peer_id, kind, direction, message_id='', context='', consume=False):
        peer = self._peers.get(peer_id, {})
        return self.permissions.decide(peer_id, FEATURES[kind]['family'], direction=direction,
                                       session=peer.get('session', ''), context=context,
                                       message_id=message_id, now=self.wall(), consume=consume)

    def capability_decision(self, peer_id, kind):
        with self._lock:
            if kind not in FEATURES:
                return {'available': False, 'reason': 'UNSUPPORTED_LOCAL', 'local_support': False}
            peer = self._peers.get(peer_id, {})
            local = self._permission(peer_id, kind, 'send')
            online = bool(self._transport) and peer.get('state') == 'READY' and not self._blocked and not self._privacy['incognito']
            remote = FEATURES[kind]['capability'] in peer.get('capabilities', [])
            reason = 'READY_FOR_REVIEW' if online and remote and local['decision'] != 'deny' else 'OFFLINE' if not online else 'UNSUPPORTED_REMOTE' if not remote else 'LOCAL_PERMISSION_DENIED'
            return {'available': online and remote and local['decision'] != 'deny', 'reason': reason,
                    'local_support': True, 'remote_support': remote, 'protocol_compatible': peer.get('protocol_version', PROTOCOL_VERSION) == PROTOCOL_VERSION,
                    'local_permission': local['decision'], 'remote_permission': 'ASK_OR_PEER_POLICY',
                    'remote_permission_note': 'Delivery does not mean the recipient has accepted this feature.'}

    def set_permission(self, peer_id, family, decision, scope='persistent', direction='receive'):
        with self._lock:
            peer = self._peers.get(peer_id, {})
            if scope == 'once':
                raise ValueError('Use the specific incoming review for Allow Once.')
            self.permissions.set(peer_id, family, decision, scope=scope, direction=direction,
                                 session=peer.get('session', ''), now=self.wall())
            self._persist_permissions()
            if decision == 'deny':
                for key, message in list(self._pending.items()):
                    if message['message']['peer_id'] == peer_id and FEATURES[message['message']['kind']]['family'] == family:
                        self._pending.pop(key, None)
                self._notifications = deque((n for n in self._notifications if n.get('peer_id') != peer_id), maxlen=40)
            self._event('permission.changed', family=family, decision=decision)

    def block_peer(self, peer_id, blocked=True):
        with self._lock:
            self.permissions.block(peer_id, bool(blocked))
            self._persist_permissions()
            if blocked:
                self.disconnect(peer_id)
                self._notifications = deque((n for n in self._notifications if n.get('peer_id') != peer_id), maxlen=40)
                for key, message in list(self._outbox.items()):
                    if message['peer_id'] == peer_id:
                        self._outbox.pop(key, None)
            self._event('permission.blocked', state=bool(blocked))

    def revoke_sharing(self):
        with self._lock:
            # Revoking means subsequent actions ask again, including former
            # persistent grants. Whispers may stay connected but are re-reviewed.
            self.permissions.revoke(decisions=('allow',))
            self._persist_permissions()
            self._pending.clear()
            self._notifications.clear()
            for context in self._contexts.values():
                context['active'] = False
                context['state'] = 'REVOKED'
            for request in self._requests.values():
                request['active'] = False
            for timer in self._timers.values():
                if timer.get('source') == 'VRC_EYE':
                    timer['state'] = 'CANCELED'
            for peer in self._peers.values():
                peer['profile'] = {}
                peer['session_card'] = None
                peer['roles'] = {}
            self._outbox.clear()
            self._event('permission.revoked')

    def _message(self, raw, peer_id, direction, status):
        return {'message_id': raw['message_id'], 'peer_id': peer_id, 'kind': raw['kind'],
                'payload': deepcopy(raw['payload']), 'direction': direction, 'status': status,
                'context': raw['context'], 'session': raw['session'], 'generation': raw['generation'],
                'created_at': raw['created_at'], 'expires_at': raw['expires_at'],
                'source': 'LOCAL' if direction == 'outgoing' else 'VRC_EYE',
                'provenance': 'User authored' if direction == 'outgoing' else 'Authenticated device claim; not verified VRChat identity'}

    def _remember(self, message):
        for previous in self._inbox:
            if previous['message_id'] == message['message_id']:
                previous.update(deepcopy(message))
                break
        else:
            self._inbox.append(deepcopy(message))
        if self._history_enabled() and message['kind'] not in EPHEMERAL_HISTORY:
            self.store.save_history(message)

    def _context(self, peer_id, context):
        local = self._contexts.get(('LOCAL', context))
        session = self._peers.get(peer_id, {}).get('session', '')
        if local and local['active'] and local['expires_at'] > self.wall() and local.get('members', {}).get(peer_id) == session:
            return local
        remote = self._contexts.get((peer_id, context))
        if remote and remote['active'] and remote['expires_at'] > self.wall() and remote.get('session') == session:
            return remote
        return None

    def _context_valid(self, peer_id, kind, payload, context, outgoing=False):
        peer = self._peers.get(peer_id, {})
        if kind=='lab.observation' and payload.get('test_id')!=context:
            raise ValueError('Lab observation must match the explicitly joined playtest context.')
        if FEATURES[kind].get('context_required') and (peer_id, peer.get('session'), context) in self._ended_contexts:
            raise ValueError('This context ended; create a new session or reconnect before sharing it.')
        if kind in SNAPSHOTS:
            if context != payload[SNAPSHOTS[kind]]:
                raise ValueError('Shared snapshot context does not match its identifier.')
            key = ('LOCAL' if outgoing else peer_id, context)
            previous = self._contexts.get(key)
            if previous and (previous.get('members', {}).get(peer_id) == peer.get('session') if outgoing else previous.get('session') == peer.get('session')) and (previous.get('published_revisions', {}).get(peer_id, -1) if outgoing else previous.get('revision', -1)) >= payload['revision']:
                raise ValueError('The shared revision is stale. Save a new local revision first.')
            if kind == 'party.snapshot' and payload.get('host') not in (None, self._identity if outgoing else peer_id):
                raise ValueError('Only the actual sender can own a shared board.')
            return
        if FEATURES[kind].get('context_required'):
            if context != peer.get('session') and self._context(peer_id, context) is None:
                raise ValueError('This shared context is no longer active.')
        if kind == 'role.assign':
            context_state = self._context(peer_id, context)
            expected_owner = 'LOCAL' if outgoing else peer_id
            if not context_state or context_state['owner'] != expected_owner:
                raise ValueError('Only the established session owner can assign roles.')
            if payload.get('revision') != context_state['revision']:
                raise ValueError('This role assignment refers to a stale shared revision.')
            members = context_state.get('data', {}).get('members', []) + context_state.get('data', {}).get('participants', [])
            if payload['peer_id'] not in members and payload['peer_id'] not in (self._identity, peer_id):
                raise ValueError('Roles can only be assigned to this session\'s members.')
        if kind.endswith('.response'):
            request = self._requests.get((peer_id, payload['request_id']))
            if not request or not request['active'] or request['deadline'] <= self.wall() or request['context'] != context or request['session'] != peer.get('session'):
                raise ValueError('This request has ended or belongs to another session.')
            if REQUEST_RESPONSES.get(request['kind']) != kind or request['direction'] != ('incoming' if outgoing else 'outgoing'):
                raise ValueError('This response does not match a live request.')
        if kind in REQUEST_RESPONSES and (peer_id, payload['request_id']) in self._requests:
            raise ValueError('This request identifier has already been used in this session.')
        if kind == 'ready.request' and (payload['deadline'] <= self.wall() or payload['deadline'] > self.wall() + 300):
            raise ValueError('Ready checks must end within five minutes.')
        if kind == 'ready.request' and payload.get('recipients') and (peer_id if outgoing else self._identity) not in payload['recipients']:
            raise ValueError('This device is not a selected ready-check recipient.')
        if kind == 'countdown.start' and not self.wall() < payload['target_at'] <= self.wall() + 120:
            raise ValueError('Countdown target must be within two minutes.')
        if kind == 'media.cue' and 'execute_at' in payload and not self.wall() <= payload['execute_at'] <= self.wall() + 120:
            raise ValueError('This media cue is stale or too far in the future.')
        if kind == 'novelty.confetti' and not self.wall() - 2 <= payload['execute_at'] <= self.wall() + 30:
            raise ValueError('This celebration has expired or is too far in the future.')

    def send(self, peer_id, kind, payload, context=''):
        with self._lock:
            if self._closed or self._blocked or self._privacy['incognito']:
                raise ValueError('Peer networking is disabled.')
            clean = validate_payload(kind, payload)
            if kind == 'profile.update':
                allowed = {key: value for key, value in self._profile['fields'].items() if self._profile.get('visibility', {}).get(key, 'private') in ('approved', 'session')}
                for key, value in clean.items():
                    if key != 'revision' and (key not in allowed or allowed[key] != value):
                        raise ValueError('Profile fields must be saved and marked shareable before sending.')
            peer = self._peers.get(peer_id)
            if not peer:
                raise ValueError('Choose an authenticated VRC Eye peer.')
            if self._permission(peer_id, kind, 'send')['decision'] == 'deny':
                raise ValueError('Your sharing permission denies this action.')
            if peer.get('state') != 'READY' or not self._transport:
                if not FEATURES[kind]['queueable']:
                    raise ValueError('This live action requires a connected peer.')
                if len(self._outbox) >= 100:
                    raise ValueError('The local outgoing queue is full.')
                message = {'message_id': _id(), 'peer_id': peer_id, 'kind': kind, 'payload': clean,
                           'context': '', 'session': '', 'generation': 0, 'direction': 'outgoing', 'status': 'QUEUED_LOCAL',
                           'created_at': self.wall(), 'expires_at': self.wall() + FEATURES[kind]['ttl'], 'source': 'LOCAL'}
                self._outbox[message['message_id']] = message
                self._remember(message)
                return deepcopy(message)
            if FEATURES[kind]['capability'] not in peer.get('capabilities', []):
                raise ValueError('The peer does not support this feature.')
            if not context and FEATURES[kind].get('context_required'):
                context = peer['session']
            if kind == 'role.assign':
                current = self._context(peer_id, context)
                if current:
                    clean.setdefault('revision', current['revision'])
            if kind in ('encounter.confirm', 'diagnostic.confirm'):
                clean['context_hash'] = hashlib.sha256(context.encode()).hexdigest()
            self._context_valid(peer_id, kind, clean, context, outgoing=True)
            self._identity = self._transport.snapshot().get('identity') or self._identity
            raw = envelope(kind, clean, sender=self._identity, recipient=peer_id, session=peer['session'], now=self.wall(), context=context, generation=1)
            # Calling send is the user's explicit one-action disclosure review.
            # It cannot override any deny or blocked rule.
            if self._permission(peer_id, kind, 'send', raw['message_id'], context)['decision'] == 'ask':
                self.permissions.set(peer_id, FEATURES[kind]['family'], 'allow', scope='once', direction='send', session=peer['session'], context=context, message_id=raw['message_id'], now=self.wall())
            decision = self._permission(peer_id, kind, 'send', raw['message_id'], context, consume=True)
            if not decision['allow']:
                raise ValueError('Your sharing permission denies this action.')
            if not self._transport.send(peer_id, raw):
                raise ValueError('The peer connection cannot accept another message yet.')
            message = self._message(raw, peer_id, 'outgoing', 'SENDING')
            self._remember(message)
            self._track_state(message, outgoing=True)
            self._counters['sent'] += 1
            self._event('message.sent', kind=kind, family=FEATURES[kind]['family'])
            return deepcopy(message)

    def share_profile(self, peer_id):
        with self._lock:
            payload = {key: value for key, value in self._profile['fields'].items() if self._profile.get('visibility', {}).get(key, 'private') in ('approved', 'session')}
            if not payload:
                raise ValueError('Choose profile fields to share; your profile is currently private.')
            payload['revision'] = self._profile['revision']
            return self.send(peer_id, 'profile.update', payload)

    def share_item(self, peer_id, item_id):
        with self._lock:
            item = self.store.item(item_id)
            if item is None or item['kind'] not in ITEM_MESSAGES:
                raise ValueError('This local item cannot be shared; notes remain private.')
            payload = deepcopy(item['data'])
            if item['kind'] == 'ready_template':
                payload.update(request_id=_id(), deadline=self.wall() + 120)
            if item['kind'] == 'cue':
                payload.pop('execute_at', None)
            context = item_id if item['kind'] in ('party', 'playtest', 'checklist') else ''
            return self.send(peer_id, ITEM_MESSAGES[item['kind']], payload, context=context)

    def share_group(self, item_id, peer_ids):
        """Explicit fan-out; each recipient has a separate capability/consent gate."""
        if not isinstance(peer_ids, (list, tuple)) or not 1 <= len(peer_ids) <= 32:
            raise ValueError('Choose between one and thirty-two connected peers.')
        result = {'sent': [], 'failed': []}
        for peer_id in dict.fromkeys(peer_ids):
            try:
                result['sent'].append(self.share_item(peer_id, item_id))
            except ValueError as exc:
                result['failed'].append({'peer_id': peer_id, 'reason': str(exc)})
        return result

    def ready_group(self, peer_ids, prompt, context, seconds=120):
        if not isinstance(peer_ids, (list, tuple)) or not 1 <= len(peer_ids) <= 32:
            raise ValueError('Choose between one and thirty-two connected peers.')
        if type(seconds) not in (int, float) or not 1 <= seconds <= 300:
            raise ValueError('Ready checks must end within five minutes.')
        peers = list(dict.fromkeys(peer_ids))
        payload = {'request_id': _id(), 'prompt': prompt, 'deadline': self.wall() + seconds, 'recipients': peers}
        result = {'request_id': payload['request_id'], 'sent': [], 'failed': []}
        for peer_id in peers:
            try:
                result['sent'].append(self.send(peer_id, 'ready.request', payload, context=context))
            except ValueError as exc:
                result['failed'].append({'peer_id': peer_id, 'reason': str(exc)})
        return result

    def flush_queued(self, peer_id):
        with self._lock:
            results = []
            for key, message in list(self._outbox.items()):
                if message['peer_id'] != peer_id:
                    continue
                if message['expires_at'] <= self.wall():
                    message['status'] = 'EXPIRED'
                    self._remember(message)
                    self._outbox.pop(key, None)
                    continue
                result = self.send(peer_id, message['kind'], message['payload'])
                if result['status'] == 'QUEUED_LOCAL':
                    self._outbox.pop(result['message_id'], None)
                    raise ValueError('Reconnect before sending queued messages.')
                message['status'] = 'RESENT'
                self._remember(message)
                self._outbox.pop(key, None)
                results.append(result)
            return results

    def _notify(self, title, body='', *, category='general', source='LOCAL', peer_id=None, duration=6):
        if (not self._privacy['notifications'] or self._privacy['notifications_muted'] or self._privacy['streamer']
                or self._availability in ('DND', 'BUSY') or (category == 'novelty' and self._privacy['safety'])):
            self._counters['suppressed'] += 1
            return
        title, body = _bounded_text(title, 200), _bounded_text(body, 500)
        self._notifications.append({'id': _id(), 'title': title, 'body': body, 'text': title + (' — ' + body if body else ''),
                                    'category': category, 'source': source, 'peer_id': peer_id,
                                    'created_at': self.wall(), 'expires_at': self.wall() + min(10, max(2, duration)),
                                    'presentation': 'plain_text', 'sound': False, 'animation': False})

    def _schedule(self, identifier, title, seconds, *, source='LOCAL', peer_id=None, context='', action='countdown', precision='Local monotonic timer'):
        if len(self._timers) >= 50:
            for key, timer in list(self._timers.items()):
                if timer['state'] != 'RUNNING':
                    self._timers.pop(key)
        if len(self._timers) >= 50:
            raise ValueError('Too many active timers.')
        timer = {'id': identifier, 'title': _bounded_text(title, 160), 'deadline': self.clock() + max(0, seconds),
                 'target_at': self.wall() + max(0, seconds), 'state': 'RUNNING', 'source': source,
                 'peer_id': peer_id, 'context': context, 'action': action, 'precision': precision}
        self._timers[identifier] = timer
        return deepcopy(timer)

    def _track_state(self, message, outgoing=False):
        kind, payload, peer_id = message['kind'], message['payload'], message['peer_id']
        peer = self._peers[peer_id]
        context = message['context']
        if kind in SNAPSHOTS:
            key = ('LOCAL' if outgoing else peer_id, context)
            previous = self._contexts.get(key, {})
            members = dict(previous.get('members', {})) if outgoing else {}
            if outgoing:
                members[peer_id] = peer['session']
            published = dict(previous.get('published_revisions', {}))
            if outgoing:
                published[peer_id] = payload['revision']
            self._contexts[key] = {'published_revisions': published, 'id': context, 'kind': kind, 'owner': 'LOCAL' if outgoing else peer_id,
                                   'revision': payload['revision'], 'data': deepcopy(payload), 'active': True,
                                   'state': 'ACTIVE', 'session': peer['session'], 'members': members,
                                   'expires_at': message['expires_at'], 'source': 'LOCAL' if outgoing else 'VRC_EYE',
                                   'roles': deepcopy(payload.get('roles', previous.get('roles', {})))}
        elif kind in REQUEST_RESPONSES:
            self._requests[(peer_id, payload['request_id'])] = {
                'request_id': payload['request_id'], 'message_id': message['message_id'], 'kind': kind,
                'peer_id': peer_id, 'context': context, 'session': peer['session'],
                'deadline': min(payload.get('deadline', message['expires_at']), message['expires_at']),
                'active': True, 'direction': message['direction'], 'response': 'NO_RESPONSE', 'payload': deepcopy(payload)}
        elif kind.endswith('.response'):
            request = self._requests[(peer_id, payload['request_id'])]
            request['response'] = payload.get('state', 'ACCEPTED' if payload.get('accepted') else 'DECLINED')
            request['responded_at'] = self.wall()
            request['active'] = False
        elif kind == 'profile.update' and not outgoing:
            previous = peer.get('profile', {})
            if payload.get('revision', 0) < previous.get('revision', -1):
                raise ValueError('Stale profile revision.')
            peer['profile'] = deepcopy(payload)
            peer['profile_expires_at'] = message['expires_at']
        elif kind == 'presence.update' and not outgoing:
            peer['availability'] = payload['availability']
            peer['presence_expires_at'] = message['expires_at']
        elif kind == 'session.card' and not outgoing:
            peer['session_card'] = deepcopy(payload)
            peer['session_expires_at'] = message['expires_at']
        elif kind == 'role.assign':
            state = self._context(peer_id, context)
            state['roles'][payload['peer_id']] = payload['role']
            peer['roles'][context] = payload['role'] if payload['peer_id'] == peer_id else peer['roles'].get(context, 'None')
        elif kind == 'countdown.start':
            seconds = payload['target_at'] - self.wall()
            uncertainty = peer.get('clock_uncertainty_ms')
            precision = ('Approximate synchronization; clock error unavailable' if uncertainty is None else 'Approximate synchronization ±%.0f ms' % uncertainty)
            if seconds > 0:
                self._schedule(message['message_id'], payload.get('title', 'Countdown'), seconds, source='LOCAL' if outgoing else 'VRC_EYE', peer_id=peer_id, context=context, precision=precision)
        elif kind == 'novelty.confetti':
            if self._privacy['safety']:
                self._counters['suppressed'] += 1
            else:
                self._schedule(message['message_id'], 'Celebration: ' + payload['style_id'], max(0, payload['execute_at'] - self.wall()), source='LOCAL' if outgoing else 'VRC_EYE', peer_id=peer_id, context=context, action='novelty', precision='Static, motion-free celebration')
        elif kind == 'media.cue':
            # A cue is a reviewed planning marker. It cannot invoke audio or OS
            # controls. Supported playback adapters can be added independently.
            title = 'Media cue: ' + payload['cue']
            when = payload.get('execute_at', self.wall())
            self._schedule(message['message_id'], title, max(0, when - self.wall()), source='LOCAL' if outgoing else 'VRC_EYE', peer_id=peer_id, context=context, action='cue', precision='Cue marker; no automatic playback')
        elif kind in ('diagnostic.confirm', 'encounter.confirm'):
            self._record_confirmation(message, outgoing)

    def _record_confirmation(self, message, outgoing):
        payload, peer_id, context = message['payload'], message['peer_id'], message['context']
        if message['kind'] == 'encounter.confirm':
            key = ('encounter', peer_id, context)
        else:
            key = ('diagnostic', payload['category'], payload['time_bucket'], context)
        record = self._confirmations.setdefault(key, {'local': False, 'peers': set(), 'context': context, 'kind': message['kind'], 'payload': deepcopy(payload)})
        if outgoing:
            record['local'] = True
        else:
            record['peers'].add(peer_id)
        if record['local'] and peer_id in record['peers']:
            receipt_id = hashlib.sha256(('::'.join(str(v) for v in key) + ':' + peer_id).encode()).hexdigest()
            receipt = {'receipt_id': receipt_id, 'peer_id': peer_id, 'kind': message['kind'], 'confirmed_at': self.wall(), 'source': 'MUTUALLY_CONFIRMED',
                       'meaning': 'Both installations explicitly confirmed the same peer context; this does not verify VRChat location or causation.'}
            if receipt_id not in self._receipts:
                self._receipts[receipt_id] = receipt
                while len(self._receipts) > 2000:
                    self._receipts.pop(next(iter(self._receipts)))
                if self._history_enabled():
                    self.store.receipt(receipt_id, peer_id, receipt, self.wall())
                self._event('confirmation.mutual', kind=message['kind'])

    def _rate_allowed(self, peer_id, kind):
        family = FEATURES[kind]['family']
        limit, window = (2, 30) if family in ('safety', 'novelty', 'troubleshooting') else (20, 10)
        now = self.clock()
        for key, maximum, period in (((peer_id, family), limit, window), ((peer_id, '*'), 60, 10)):
            values = self._rates.setdefault(key, deque())
            while values and values[0] <= now - period:
                values.popleft()
            if len(values) >= maximum:
                return False
        if len(self._rates) > 1024:
            for key in list(self._rates)[:len(self._rates) - 1024]:
                if key not in ((peer_id, family), (peer_id, '*')):
                    self._rates.pop(key, None)
        self._rates[(peer_id, family)].append(now)
        self._rates[(peer_id, '*')].append(now)
        return True

    def _valid_raw(self, peer_id, raw):
        peer = self._peers.get(peer_id, {})
        # Transport measures remote clock minus local clock. Normalize only
        # scheduling/lifetime timestamps; event fingerprints remain explicit
        # claims. Unknown clock offset retains conservative wall-clock checks.
        offset = (peer.get('clock_offset_ms') or 0) / 1000.0
        adjusted = deepcopy(raw)
        if offset:
            for field in ('created_at', 'expires_at'):
                if type(adjusted.get(field)) in (int, float):
                    adjusted[field] -= offset
            payload = adjusted.get('payload')
            if isinstance(payload, dict):
                for field in ('deadline', 'target_at', 'execute_at'):
                    if type(payload.get(field)) in (int, float):
                        payload[field] -= offset
        clean = validate_envelope(adjusted, now=self.wall())
        if peer.get('state') != 'READY' or clean['sender'] != peer_id or clean['recipient'] != self._identity or clean['session'] != peer.get('session') or clean['generation'] != 1:
            raise ValueError('Message does not belong to the authenticated current session.')
        if FEATURES[clean['kind']]['capability'] not in peer.get('capabilities', []):
            raise ValueError('Message uses an unnegotiated capability.')
        self._context_valid(peer_id, clean['kind'], clean['payload'], clean['context'])
        if clean['kind'] == 'lab.observation' and clean['payload']['test_id'] != clean['context']:
            raise ValueError('The lab observation belongs to a different shared test context.')
        if clean['kind'] in ('encounter.confirm', 'diagnostic.confirm') and clean['payload']['context_hash'] != hashlib.sha256(clean['context'].encode()).hexdigest():
            raise ValueError('Confirmation context fingerprint does not match.')
        return clean

    def _receive(self, peer_id, raw):
        clean = self._valid_raw(peer_id, raw)
        if clean['message_id'] in self._seen:
            self._event('message.duplicate')
            return
        for identifier, expiry in list(self._seen.items()):
            if expiry <= self.wall():
                self._seen.pop(identifier, None)
        if len(self._seen) >= 2048:
            raise ValueError('Replay protection capacity reached; retry after earlier messages expire.')
        self._seen[clean['message_id']] = clean['expires_at']
        kind = clean['kind']
        if not self._rate_allowed(peer_id, kind):
            self._counters['rate_limited'] += 1
            self._event('message.rate_limited', family=FEATURES[kind]['family'])
            return
        decision = self._permission(peer_id, kind, 'receive', clean['message_id'], clean['context'])
        if decision['decision'] == 'deny':
            self._counters['rejected'] += 1
            self._event('message.denied', kind=kind, family=FEATURES[kind]['family'])
            return
        message = self._message(clean, peer_id, 'incoming', 'ASK' if decision['decision'] == 'ask' else 'ACCEPTED')
        self._counters['received'] += 1
        if decision['decision'] == 'ask':
            if len(self._pending) >= 128:
                self._counters['rejected'] += 1
                return
            self._pending[message['message_id']] = {'message': message, 'raw': deepcopy(raw)}
            self._event('message.review', kind=kind, family=FEATURES[kind]['family'])
        else:
            decision = self._permission(peer_id, kind, 'receive', clean['message_id'], clean['context'], consume=True)
            if decision['allow']:
                self._accept(message)

    def _accept(self, message):
        self._track_state(message)
        self._remember(message)
        kind, payload = message['kind'], message['payload']
        if kind == 'notice.show':
            self._notify(payload['title'], payload.get('body', ''), category=payload.get('category', 'general'), source='VRC_EYE', peer_id=message['peer_id'], duration=6)
        elif kind == 'whisper.message':
            self._notify('VRC Eye Whisper received', 'Open VRC Eye Primary to read it.', source='VRC_EYE', peer_id=message['peer_id'])
        elif kind in REQUEST_RESPONSES:
            self._notify(FEATURES[kind]['label'], 'A reviewed request is waiting for your response.', category='safety' if kind == 'safety.checkin' else 'ready', source='VRC_EYE', peer_id=message['peer_id'])
        elif kind == 'safety.alert':
            self._notify('VRC Eye Safety Mode', 'A peer shared its Safety Mode state: ' + payload['state'], category='safety', source='VRC_EYE', peer_id=message['peer_id'])
        self._event('message.accepted', kind=kind, family=FEATURES[kind]['family'])

    def respond(self, message_id, allow, scope='once'):
        with self._lock:
            pending = self._pending.pop(message_id, None)
            if pending is None:
                raise ValueError('This permission review is no longer available.')
            message, raw = pending['message'], pending['raw']
            validated = self._valid_raw(message['peer_id'], raw)
            message = self._message(validated, message['peer_id'], 'incoming', message['status'])
            kind, peer_id = message['kind'], message['peer_id']
            if not allow:
                message['status'] = 'DECLINED'
                self._remember(message)
                if scope != 'once':
                    self.set_permission(peer_id, FEATURES[kind]['family'], 'deny', scope=scope)
                self._event('message.declined', kind=kind)
                return deepcopy(message)
            # A block or explicit deny established while the review was open
            # takes precedence over the old approval screen.
            if self._permission(peer_id, kind, 'receive', message_id, message['context'])['decision'] == 'deny':
                raise ValueError('A current permission denies this review.')
            self.permissions.set(peer_id, FEATURES[kind]['family'], 'allow', scope=scope, direction='receive',
                                 session=message['session'], context=message['context'] if scope in ('once', 'session') else '', message_id=message_id if scope == 'once' else '', now=self.wall())
            decision = self._permission(peer_id, kind, 'receive', message_id, message['context'], consume=True)
            if not decision['allow']:
                raise ValueError('A current permission denies this review.')
            self._persist_permissions()
            message['status'] = 'ACCEPTED'
            self._accept(message)
            return deepcopy(message)

    def respond_request(self, message_id, value):
        with self._lock:
            message = next((m for m in self._inbox if m['message_id'] == message_id and m['direction'] == 'incoming' and m['status'] == 'ACCEPTED'), None)
            if message is None or message['kind'] not in REQUEST_RESPONSES:
                raise ValueError('Choose an accepted, active request first.')
            payload = {'request_id': message['payload']['request_id']}
            if message['kind'] == 'troubleshooting.request':
                if type(value) is not bool:
                    raise ValueError('Choose accept or decline.')
                payload['accepted'] = value
            else:
                payload['state'] = value
            return self.send(message['peer_id'], REQUEST_RESPONSES[message['kind']], payload, context=message['context'])

    def save_received(self, message_id):
        with self._lock:
            message = next((m for m in self._inbox if m['message_id'] == message_id and m['direction'] == 'incoming' and m['status'] == 'ACCEPTED'), None)
            if message is None:
                raise ValueError('Choose an accepted received card.')
            kind = next((key for key, value in ITEM_MESSAGES.items() if value == message['kind']), None)
            payload = deepcopy(message['payload'])
            if message['kind'] in ('recommend.world', 'recommend.avatar'):
                target = 'world' if message['kind'] == 'recommend.world' else 'avatar'
                kind = 'bookmark'
                payload = {'target_type': target, 'target_id': payload[target + '_id'], 'label': payload.get('label', ''), 'note': payload.get('note', '')}
            if kind is None:
                raise ValueError('This message is not a saveable local card.')
            item = self.save_item(kind, payload)
            item['source'] = 'VRC_EYE'
            item['provenance'] = 'Explicitly saved peer claim; source metadata is not independently verified.'
            self.store.save_item(item)
            self._item_cache = None
            return deepcopy(item)

    def clear_history(self, peer_id=None):
        with self._lock:
            self.store.clear_history(peer_id)
            self._inbox = deque((m for m in self._inbox if peer_id is not None and m['peer_id'] != peer_id), maxlen=200)
            self._receipts = {key: value for key, value in self._receipts.items() if peer_id is not None and value['peer_id'] != peer_id}
            if peer_id is None:
                self._confirmations.clear()
            else:
                for key, confirmation in list(self._confirmations.items()):
                    confirmation['peers'].discard(peer_id)
                    if key[0] == 'encounter' and key[1] == peer_id:
                        self._confirmations.pop(key, None)
            self._event('history.cleared')

    def local_action(self, action, **kwargs):
        with self._lock:
            if self._closed:
                raise ValueError('Peer Services is closed.')
            if action == 'countdown':
                seconds = kwargs.get('seconds', 5)
                if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not 0 < seconds <= 86400:
                    raise ValueError('Choose a countdown between one second and one day.')
                return self._schedule(_id(), kwargs.get('title', 'Countdown'), seconds, context=kwargs.get('context', ''))
            if action == 'cancel_countdown':
                timer = self._timers.get(kwargs.get('timer_id'))
                if timer is None:
                    raise ValueError('Choose an active timer.')
                timer['state'] = 'CANCELED'
                return deepcopy(timer)
            if action == 'checklist_update':
                item = self.store.item(kwargs.get('item_id'))
                if item is None or item['kind'] != 'checklist':
                    raise ValueError('Choose a saved checklist.')
                index = kwargs.get('index')
                if type(index) is not int or not 0 <= index < len(item['data']['items']):
                    raise ValueError('Choose a checklist row.')
                if 'base_revision' in kwargs and kwargs['base_revision'] != item['revision']:
                    raise ValueError('This checklist changed; reload it before editing.')
                item['data']['items'][index]['status'] = kwargs['status']
                if 'note' in kwargs:
                    item['data']['items'][index]['note'] = kwargs['note']
                return self.save_item('checklist', item['data'], item['id'])
            if action == 'add_note':
                return self.save_item('note', {'title': kwargs.get('title', 'Note'), 'text': kwargs.get('text', '')})
            if action == 'notice':
                payload = validate_payload('notice.show', {key: value for key, value in kwargs.items() if key in ('title', 'body', 'category', 'duration')})
                self._notify(payload['title'], payload.get('body', ''), category=payload.get('category', 'general'), duration=payload.get('duration', 6))
                return {'status': 'LOCAL', 'payload': payload}
            if action == 'novelty':
                payload = validate_payload('novelty.confetti', {'style_id': kwargs.get('style_id', 'gentle'), 'execute_at': self.wall()})
                self._notify('Celebration: ' + payload['style_id'], 'A gentle, motion-free celebration.', category='novelty')
                return {'status': 'LOCAL', 'payload': payload}
            if action in ('confirm_event', 'confirm_encounter'):
                peer_id = kwargs.get('peer_id', '')
                context = kwargs.get('context') or self._peers.get(peer_id, {}).get('session', '')
                if not context:
                    raise ValueError('Choose an explicit active peer or creator context.')
                context_hash = hashlib.sha256(context.encode()).hexdigest()
                if action == 'confirm_event':
                    bucket = kwargs.get('time_bucket', int(self.wall() // 5))
                    payload = validate_payload('diagnostic.confirm', {'event_id': kwargs.get('event_id') or _id(), 'category': kwargs.get('category', 'other'), 'time_bucket': bucket, 'context_hash': context_hash})
                    key = ('diagnostic', payload['category'], payload['time_bucket'], context)
                    self._confirmations.setdefault(key, {'local': True, 'peers': set(), 'context': context, 'kind': 'diagnostic.confirm', 'payload': payload})['local'] = True
                else:
                    if peer_id not in self._peers:
                        raise ValueError('Choose an authenticated peer.')
                    payload = {'encounter_id': hashlib.sha256((context + ':' + ':'.join(sorted((peer_id, self._identity)))).encode()).hexdigest(), 'context_hash': context_hash}
                    key = ('encounter', peer_id, context)
                    self._confirmations.setdefault(key, {'local': True, 'peers': set(), 'context': context, 'kind': 'encounter.confirm', 'payload': payload})['local'] = True
                return {'payload': deepcopy(payload), 'context': context, 'source': 'LOCAL'}
            if action == 'flush_queued':
                return self.flush_queued(kwargs['peer_id'])
            if action == 'dismiss_notification':
                identifier = kwargs.get('notification_id')
                self._notifications = deque((n for n in self._notifications if n['id'] != identifier), maxlen=40)
                return True
            if action == 'end_context':
                context = kwargs['context']
                for item in self._contexts.values():
                    if item['id'] == context:
                        item['active'] = False
                        item['state'] = 'ENDED'
                self.permissions.end_context(context)
                for request in self._requests.values():
                    if request['context'] == context:
                        request['active'] = False
                for timer in self._timers.values():
                    if timer['context'] == context:
                        timer['state'] = 'CANCELED'
                return True
            raise ValueError('Unknown local action.')

    def _handle_event(self, event):
        kind = event.get('type')
        if kind == 'connected':
            peer_id = event['peer_id']
            if peer_id in self.permissions.snapshot().get('blocked', []):
                if self._transport:
                    self._transport.disconnect(peer_id)
                return
            if peer_id in self._peers:
                self._end_peer(peer_id)
            if len(self._peers) >= 64 and peer_id not in self._peers:
                offline = next((pid for pid, peer in self._peers.items() if peer['state'] == 'OFFLINE'), None)
                if offline:
                    self._peers.pop(offline)
                else:
                    self._transport.disconnect(peer_id)
                    return
            self._requests = {key: request for key, request in self._requests.items() if request['peer_id'] != peer_id}
            self._peers[peer_id] = {'peer_id': peer_id, 'alias': str(event.get('alias', 'VRC Eye device'))[:120],
                                    'version': str(event.get('version', 'Unknown'))[:40], 'protocol_version': PROTOCOL_VERSION,
                                    'capabilities': [c for c in event.get('capabilities', []) if c in capabilities()],
                                    'session': event['session'], 'state': 'READY', 'profile': {}, 'availability': 'UNKNOWN',
                                    'roles': {}, 'session_card': None, 'latency_ms': None, 'clock_offset_ms': None, 'clock_uncertainty_ms': None,
                                    'connected_at': self.wall(), 'identity_kind': 'Authenticated VRC Eye device; VRChat identity unverified'}
            self._event('peer.connected', count=len(self._peers[peer_id]['capabilities']))
        elif kind == 'disconnected':
            self._end_peer(event['peer_id'])
        elif kind == 'message':
            self._receive(event['peer_id'], event['message'])
        elif kind == 'delivered':
            for message in self._inbox:
                if message['message_id'] == event.get('message_id') and message['peer_id'] == event.get('peer_id') and message['direction'] == 'outgoing' and message['session'] == self._peers.get(event.get('peer_id'), {}).get('session'):
                    message['status'] = 'DELIVERED_TO_DEVICE'
                    self._remember(message)
                    self._event('message.delivered', kind=message['kind'])
                    break
        elif kind == 'latency':
            peer = self._peers.get(event.get('peer_id'))
            if peer and peer['state'] == 'READY':
                for source, target in (('rtt_ms', 'latency_ms'), ('clock_offset_ms', 'clock_offset_ms'), ('clock_uncertainty_ms', 'clock_uncertainty_ms')):
                    value = event.get(source)
                    if type(value) in (float, int) and -1e9 < value < 1e9:
                        peer[target] = value
        elif kind == 'status':
            self._event('network.status', state=str(event.get('state', 'UNKNOWN'))[:40])

    def tick(self):
        with self._lock:
            if self._closed:
                return
            if self._transport:
                state = self._transport.snapshot()
                self._identity = state.get('identity') or self._identity
                if state.get('mode'):
                    self._mode = state['mode']
                self._reason = str(state.get('reason', ''))[:300]
            for _ in range(64):
                try:
                    epoch, event = self._queue.get_nowait()
                except queue.Empty:
                    break
                if epoch != self._epoch or not self._transport or self._blocked:
                    continue
                try:
                    self._handle_event(event)
                except (ValueError, KeyError, TypeError, OverflowError):
                    self._counters['rejected'] += 1
                    self._event('message.invalid', reason='INVALID_OR_STALE')
            now = self.wall()
            for key, pending in list(self._pending.items()):
                if pending['message']['expires_at'] <= now:
                    self._pending.pop(key)
                    self._counters['expired'] += 1
            for key, message in list(self._outbox.items()):
                if message['expires_at'] <= now:
                    message['status'] = 'EXPIRED'
                    self._remember(message)
                    self._outbox.pop(key)
            for timer in self._timers.values():
                if timer['state'] == 'RUNNING' and self.clock() >= timer['deadline']:
                    timer['state'] = 'FINISHED'
                    self._notify(timer['title'], 'Ready.' if timer['action'] == 'countdown' else 'Local cue marker.' if timer['action'] == 'cue' else 'A gentle, motion-free celebration.',
                                 category='novelty' if timer['action'] == 'novelty' else 'photo' if timer['action'] == 'countdown' else 'general', source=timer['source'], peer_id=timer.get('peer_id'))
            self._notifications = deque((n for n in self._notifications if n['expires_at'] > now), maxlen=40)
            for request in self._requests.values():
                if request['deadline'] <= now:
                    request['active'] = False
            for context in self._contexts.values():
                if context['expires_at'] <= now:
                    context['active'] = False
                    context['state'] = 'EXPIRED'
                    self.permissions.end_context(context['id'])
            for peer in self._peers.values():
                if peer.get('profile_expires_at', float('inf')) <= now:
                    peer['profile'] = {}
                if peer.get('presence_expires_at', float('inf')) <= now:
                    peer['availability'] = 'UNKNOWN'
                if peer.get('session_expires_at', float('inf')) <= now:
                    peer['session_card'] = None
            for key, expiry in list(self._seen.items()):
                if expiry <= now:
                    self._seen.pop(key, None)
            if len(self._ended_contexts) > 8192:
                self.private_mode()
                self._reason = 'Context limit reached; reconnect to begin a fresh peer session.'
            while len(self._requests) > 200:
                self._requests.pop(next(iter(self._requests)))
            while len(self._contexts) > 200:
                self._contexts.pop(next(iter(self._contexts)))
            while len(self._confirmations) > 1000:
                self._confirmations.pop(next(iter(self._confirmations)))

    def snapshot(self):
        with self._lock:
            if self._closed:
                return {'mode': 'Private', 'state': 'CLOSED', 'reason': 'Peer Services closed.', 'peers': [], 'items': [], 'pending': [], 'inbox': [], 'events': [], 'notifications': [], 'timers': [], 'network_config': deepcopy(self._network_config)}
            transport = self._transport.snapshot() if self._transport else {}
            peers = []
            for peer in self._peers.values():
                value = deepcopy(peer)
                value['encounters'] = sum(1 for receipt in self._receipts.values() if receipt['peer_id'] == peer['peer_id'] and receipt['kind'] == 'encounter.confirm')
                value['compatibility'] = 'Full' if set(value['capabilities']) == set(capabilities()) else 'Partial'
                peers.append(value)
            timers = [{**timer, 'remaining': max(0, timer['deadline'] - self.clock()) if timer['state'] == 'RUNNING' else 0} for timer in self._timers.values()]
            if self._item_cache is None:
                self._item_cache = self.store.items()
            result = {'mode': self._mode, 'state': 'BLOCKED' if self._blocked else transport.get('state', 'PRIVATE'),
                      'reason': self._block_reason if self._blocked else self._reason,
                      'identity': self._identity, 'profile': self._profile, 'availability': self._availability,
                      'peers': peers, 'pending': [pending['message'] for pending in self._pending.values()],
                      'inbox': list(self._inbox), 'events': list(self._events), 'items': self._item_cache[:250], 'item_count': len(self._item_cache),
                      'permissions': self.permissions.snapshot(), 'notifications': list(self._notifications),
                      'counters': self._counters, 'timers': timers, 'privacy': {**self._privacy, 'history_effective': self._history_enabled(), 'own': self._privacy_own, 'inherited': self._privacy_inherited},
                      'contexts': list(self._contexts.values()), 'requests': list(self._requests.values()),
                      'receipts': list(self._receipts.values()), 'outbox': list(self._outbox.values()),
                      'transport': {key: value for key, value in transport.items() if key not in ('peers', 'identity')},
                      'version': APP_VERSION, 'protocol_version': PROTOCOL_VERSION, 'network_config': self._network_config}
            return deepcopy(result)

    def close(self):
        with self._lock:
            if self._closed:
                return
            self.private_mode()
            self._closed = True
            self.store.close()
