> **Latest checkpoint: Development 21.** See DEVELOPMENT_21_VALIDATION.md and BUILD_VALIDATION.json. The historical checkpoints below retain their original evidence and limits.

# VRC Eye 1.21.0 — Development 18 validation

The final portable suite passed **5,032 tests and 1,059 subtests**, with
**zero failures/errors** and **zero blocked external-socket attempts**, in
117.71 seconds. All **85 new Development 18 tests** are included.

**475 native-GUI tests were skipped**, **1 Unix bridge case was
deselected**, and **13 local-transport modules were excluded**, matching the saved
Development 17 baseline. Skips/exclusions are not passes. 2 inherited warnings
remain in the log. BUILD_VALIDATION.json records the exact command.

The GLB tests exercise a real bundled parser subprocess with synthetic static
scene files: source preservation and digest, parent TRS/matrix composition,
negative scale, hierarchy/instancing, visibility and framing, unsigned/unindexed
and interleaved geometry, bounds, malformed/unsupported input, duplicate JSON,
external-resource refusal, result validation and cancellation. Owned-child timeout
and termination behavior is also tested with a controlled process adapter.
No third-party avatar, FBX, VRCA, Unity-bundle or installed AssetRipper import was
qualified by these fixture cases.

Local SQLite tests cover same-transaction writes/history, retained receipts,
conditional undo after restart, later-edit conflicts, stable widget identity after
reordering, scope isolation, secret/grant exclusion, invalid dependent layouts,
concurrent writers and corrupt previous-document repair without copying invalid
bytes into history. Rule checks cover priority, fallback, override, widget
visibility and current-account observations.

Headless UI checks exercise actual GLB load/render/control callbacks, hiding and
framing, privacy clearing, account/selection/close boundaries, conditional Home
rebuilds, manual override, rule editing, stale drafts and reviewed direct-edit undo.
These are display adapters, not evidence of native layout/accessibility quality.

All **595 Python files** pass Python 3.10 grammar parsing. The frozen
manifest covers **640 source files** and was
rechecked after the final suite. No runtime/test changes followed that run.
Packaging verifies CRCs and every archive member against source. All **786
Development 17 paths** are retained, with unchanged launchers and requirements.
Parent archive SHA-256: `f06813cfdcba149772e79ae448b01c5fcab53277c295035d84e923a881693688`.

Native Windows/Linux GUI rendering, large text/high contrast/keyboard behavior,
Windows parser-process lifecycle, installed AssetRipper/Unity, live VRChat/CDN
origins, SteamVR and native filesystem/power-loss acceptance remain unverified.
The GLB parser subprocess is fault separation, not an OS security sandbox. The
static scene viewer does not implement textures/materials, skinning/morph targets,
animation playback or direct FBX/VRCA/Unity-bundle decoding.

This is runnable source, not a compiled EXE, Flatpak or signed installer. Full
ARC/VRCX parity remains incomplete; see ARC_VRCX_REMAINING_DEV18.md.
