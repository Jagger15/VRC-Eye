# AssetRipper adapter contract — Development 16

The adapter uses the selected native executable, never a shell command or an
automatically installed tool. Its supported launch shape is `--headless --port 0
--log-path <new-staging-folder>/AssetRipper.log`. Native acceptance of this shape
for an exact installed release remains open.

Primary official sources checked on 2026-10-04:

- [Arguments](https://github.com/AssetRipper/AssetRipper/blob/master/Source/AssetRipper.GUI.Web/Arguments.cs)
  declares the headless, port and log-path options.
- [WebApplicationLauncher](https://github.com/AssetRipper/AssetRipper/blob/master/Source/AssetRipper.GUI.Web/WebApplicationLauncher.cs)
  registers the loopback web application, OpenAPI document, and form-based
  `POST /LoadFile` and `POST /Export/UnityProject` with a 302 completion response.
- [Maintainer CLI/API discussion](https://github.com/AssetRipper/AssetRipper/discussions/1174)
  explains that command-line arguments control the host and POST requests control
  its operations. Fork-only input/output CLI arguments are not used.

This is evidence from upstream source, not an exact installed-version contract.
The adapter inspects read-only OpenAPI candidates on the just-launched process's
verified IPv4 loopback listener. Both commands must declare single-string path
forms and a 302 response. Unknown schemas, extra required fields, authenticated
API schemes, external schema references and redirects are rejected. No arbitrary
server attachment, proxy, credential transport or repeated write request exists.
API document hashes and declared API title/version are recorded when available;
the API version is not asserted to be the installed AssetRipper release version.

The selected executable's identity is rechecked before staging and launch.
Supporting DLLs/resources and publisher/license signatures are not pinned or
authenticated. The child runs with the user's OS permissions. Process identity,
observed descendants, POSIX process-group termination and local listener ownership
are checked, but this is not a qualified isolation sandbox. Unobserved/reparented
helper behavior, Windows job containment, memory pressure and exporter disk writes
need installed-platform acceptance. Cleanup never deletes partial output or kills
a process solely by executable name.

Required native acceptance before promoting ARC-07/08/09: one exact release/hash
per platform; real OpenAPI and form semantics; unsupported-version rejection;
load/export errors and empty/partial output; account/privacy/cancel/shutdown during
each phase; owned descendants exiting; changed executable and output files; output
dependency/quality inspection; and a separately reviewed Unity import. None is
claimed passed by the synthetic protocol or headless UI fixtures.
