"""Tk-thread caption owner: explicit capture, shared privacy boundary, no transcript persistence."""
import queue
import threading
from caption_model import KEY,Preferences,Transcript
from caption_audio import Session,discover_loopbacks


class LiveCaptions:
    def __init__(self,experience,*,session=None):
        self.experience=experience;self.app=experience.app;self.root=self.app.root
        self.closed=False;self.preferences=Preferences();self.undo_value=None
        self.transcript=Transcript();self.context=self.boundary();self.active=False;self.stopping=False
        self.sources=[];self.source=None;self.discovery=None;self.results=queue.Queue(maxsize=1);self.revision=0
        self.window=None;self.panels=[];self.job=None
        from local_audio import engine_for
        self.session=session or Session(engine_for(self.app))
        self.status=self.app.tk.StringVar(value='Captions stopped. Choose a source and local speech model, then Start.')
        try:
            value=experience.shell.store.option(KEY)
            if value is not None:self.preferences=Preferences.parse(value)
        except (ValueError,OSError,__import__('sqlite3').Error):self.status.set('Caption settings could not be read. Defaults are active for this session.')
        self.transcript.resize(self.preferences.retain)
        self.button=None
        header=getattr(self.app,'header_actions',None)
        if header is not None:
            from screen_reader_model import annotate
            self.button=annotate(self.app.ttk.Button(header,text='Live captions',command=self.header_action),public=True,name=lambda:self.button.cget('text'),description='Open caption settings when stopped; stop capture when active.')
            self.button.pack(side='left',padx=6)
        self.schedule()

    def boundary(self):
        from account_header import boundary,private
        return boundary(self.app),private(self.app),bool(getattr(self.app,'_native_private',False)),bool(getattr(self.app,'demo',False)),bool(getattr(self.app,'safe_mode',False))
    def blocked(self):return any(self.boundary()[1:])
    def sync_context(self):
        state=self.boundary()
        if state!=self.context:
            self.context=state;self.revision+=1;self.stop();self.transcript.clear();self.sources=[];self.source=None
            self.status.set('Caption context changed. Content cleared; select a source and Start again.')
        return state
    def allowed(self):
        self.sync_context()
        if self.closed or self.blocked():raise ValueError('Live capture is off in privacy, Demo and Safe Mode. Leave those modes before starting captions.')
    def apply(self,raw):
        new=Preferences.parse(raw)
        if self.session.running and new.model!=self.preferences.model:raise ValueError('Stop captions before changing the speech model.')
        if not (self.app.demo or getattr(self.app,'safe_mode',False)):self.experience.shell.store.set_option(KEY,new.to_dict())
        self.undo_value=self.preferences;self.preferences=new;self.transcript.resize(new.retain)
        self.status.set('Caption settings applied'+(' for this session.' if self.app.demo or getattr(self.app,'safe_mode',False) else ' and saved.'))
        self.render()
    def undo(self):
        if self.undo_value is None:raise ValueError('No caption-settings change to undo.')
        self.apply(self.undo_value.to_dict())
    def discover(self):
        self.allowed()
        if self.discovery and self.discovery.is_alive():raise ValueError('Audio discovery is still running.')
        if self.session.running:raise ValueError('Stop captions before discovering devices.')
        self.revision+=1;revision=self.revision;context=self.context
        self.status.set('Discovering named inputs and desktop outputs…')
        Session.drain(self.results)
        def run():
            sources=[];errors=[]
            try:
                sources.extend(dict(kind='input',id=str(d.index),name=d.label,device=d) for d in self.session.engine.devices() if d.inputs>0 and d.name.casefold() not in ('default','sysdefault','pulse','pipewire'))
            except Exception:errors.append('Input discovery unavailable; check PortAudio and audio permissions.')
            try:sources.extend(discover_loopbacks())
            except (ValueError,OSError) as error:errors.append(str(error))
            try:self.results.put_nowait((revision,context,sources,errors))
            except queue.Full:pass
        self.discovery=threading.Thread(target=run,daemon=True,name='Eye caption discovery');self.discovery.start()
    def select_source(self,index):
        if self.session.running:raise ValueError('Stop captions before changing the audio source.')
        if type(index) is not int or not 0<=index<len(self.sources):raise ValueError('Discover and select a caption audio source.')
        self.source=dict(self.sources[index])
    def start(self):
        self.allowed()
        if self.source is None:raise ValueError('Discover and select a caption audio source first.')
        if not self.preferences.model:raise ValueError('Choose an extracted local Vosk speech model folder first.')
        if self.session.running:raise ValueError('Captions are already active or still releasing. Wait for Stop to finish.')
        self.transcript.clear();self.session.start(self.preferences.model,self.source);self.active=True;self.stopping=False
        self.status.set(self.session.state);self.render();self.schedule()
    def stop(self):
        self.active=False;self.session.stop();self.stopping=self.session.running;self.transcript.partial='';self.transcript.revision+=1
        self.status.set(self.session.state);self.render()
    def clear(self):
        # Stop first: pre-clear audio already held inside a decoder cannot reappear.
        self.stop();self.transcript.clear();self.status.set('Captions stopped and transcript cleared.');self.render()
    def header_action(self):
        if self.active or self.session.running:self.stop()
        else:self.open_settings()
    def open_settings(self):
        self.experience.shell.show('Accessibility');page=self.experience.shell.pages['Accessibility']
        page.tabs.select(page.frames['Live captions'])
    def open_window(self):
        if self.window:self.window.window.lift();return
        from caption_ui import CaptionWindow
        self.window=CaptionWindow(self)
    def export(self,kind='txt'):
        self.allowed()
        if not self.transcript.rows:raise ValueError('There are no finalized captions to export.')
        return self.transcript.export(kind)
    def tick(self):
        if self.closed:return
        self.sync_context()
        try:
            revision,context,sources,errors=self.results.get_nowait()
            if revision==self.revision and context==self.context and not self.blocked():
                self.sources=sources;self.source=None
                self.status.set(f'{len(sources)} sources found. Select one. '+ ' '.join(errors))
                for panel in self.panels:panel.refresh_sources()
        except queue.Empty:pass
        if self.active:
            for _ in range(40):
                try:value=self.session.events.get_nowait()
                except queue.Empty:break
                try:self.transcript.accept(value)
                except (ValueError,TypeError,KeyError):self.session.fail('Invalid caption data; capture stopped.');break
            if not self.session.running:
                self.active=False;self.transcript.partial='';self.transcript.revision+=1
            self.status.set(self.session.state)
        if self.stopping:
            self.status.set(self.session.state)
            if not self.session.running:self.stopping=False
        self.render()
    def render(self):
        if self.button:self.button.configure(text='Stop live captions' if self.active or self.session.running else 'Live captions')
        for panel in tuple(self.panels):panel.render()
        if self.window:self.window.render()
    def schedule(self):
        if self.closed or self.job is not None:return
        self.job=self.root.after(100,self.poll)
    def poll(self):
        self.job=None;self.tick();self.schedule()
    def close(self):
        if self.closed:return
        self.closed=True;self.revision+=1;self.session.stop();self.transcript.clear()
        if self.job:self.root.after_cancel(self.job);self.job=None
        if self.window:self.window.close(stop=False)
        self.panels.clear()
