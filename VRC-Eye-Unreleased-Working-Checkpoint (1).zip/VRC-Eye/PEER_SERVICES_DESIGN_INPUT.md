# VRC Eye Peer Services — design and 1.19.0 implementation map

**1.19.1 update:** Connection controls now live in **VRC Eye → Networking**.
Tailscale, ZeroTier, Radmin VPN, NetBird, explicit other VPN adapters, saved local
connection profiles and enforced relay-only privacy extend the original service.
See NETWORKING_SETUP.md. The feature map below records the initial 1.19.0 scope;
the original supplied design at the end remains unchanged.

The original supplied design follows this map unchanged. The map describes the
usable initial implementation and its boundaries; examples and longer-term goals
in the design are not a claim of shipped behavior. See PEER_SERVICES_SETUP.md for
operating steps and VALIDATION.md for the exact checks performed.

Private Mode provides local profiles, drafts, bookmarks, planning, timers, creator
checklists, diagnostics, performance comparisons and safe presets. Connecting is
optional and never publishes a saved field or object automatically. Every launch
starts disconnected. LAN, detected Hamachi IPv4 mesh and an operator-run opaque
relay provide optional live connections. No public relay or VRC Eye account
service is provisioned.

Connections authenticate installations, not VRChat accounts. The Player List
association is explicitly local and unverified. Groups connect host-to-guests;
there is no guest-to-guest routing through the host. Private items stay separate
from received snapshots, and all saved items (up to the 1,000-item bound) remain
accessible in the workspace.

Peer modules: peer_protocol.py, peer_transport.py, peer_relay.py, peer_service.py,
peer_store.py, peer_tools.py, peer_simulation.py, peer_ui.py, peer_app.py,
peer_player.py, peer_profile_link.py and peer_notify.py. Existing sidebar, profile,
Player List, Wellness runtime and Black Box integrations share these owners.

## Original features 1–32

1. VRC Eye handshake — Implemented: pinned TLS, signed device authentication, fresh session/nonces, version and capability exchange, exact device identity binding. Optional networking only. No account login or independent VRChat identity verification.
2. Capability negotiation — Implemented: intersection of versioned capability IDs and local/remote schema support. Protocol v1 and fixed limits are supported; arbitrary protocol ranges and negotiated per-capability parameter versions are not implemented. Recipient permission is evaluated on receipt, not broadcast as a fully synchronized remote permission matrix.
3. Optional profile/bio — Implemented locally: alias, bio, pronouns, status, color, symbol icon and creator/streamer flags. Per-field visibility gates an explicit share. No automatic profile publication, images or verified-friend visibility resolution. The editor keeps creator/streamer flags private.
4. Whispers — Implemented: small plain-text messages, explicit send/review, device delivery acknowledgement, per-family consent, block, local conversation deletion, optional bounded local history, local notes/drafts and an explicit local offline queue. No read receipts, attachments, public directory or server mailbox. Queued work is not automatically sent on reconnect and is not restored as an outbound job after app restart. A device receipt does not prove human reading or recipient acceptance.
5. Online/DND/AFK status — Implemented: transport connection state is separate from manually set AVAILABLE/DND/AFK/BUSY/BREAK. Availability can be local only or explicitly shared; stale remote availability becomes UNKNOWN. No automatic AFK inference or background presence publication.
6. Shared session card — Implemented: local capture and explicit share of a sanitized runtime state, available duration and desktop/VR mode with provenance and expiry. The current card does not include worlds, exact instances, current activity, party membership or arbitrary per-field session-card controls.
7. Capability badges — Scoped implementation: Player List shows one Eye linked label for a locally associated device, and device/details views show connection/version/capability information. There is no automatic peer discovery by VRChat identity or per-row photo/creator capability icon set. The label is not proof that the player runs the linked device.
8. Mutual encounters — Implemented: reciprocal explicit device confirmations bound to an agreed active peer context produce separately labeled receipts/counts; one-sided claims do not count. This does not independently prove a shared VRChat instance and does not merge with the ordinary local encounter counter.
9. Shared bookmarks — Implemented: local world/avatar references with label/note, explicit share, review, and separately chosen local save. Receiving never changes local or remote VRChat favorites automatically.
10. World recommendations — Implemented: validated world ID plus optional sender label/note, reviewed receipt and save as a local bookmark. Metadata is a peer claim; the new peer workspace does not automatically resolve current world metadata or implement a new join action.
11. Avatar recommendations — Implemented: validated avatar reference plus optional label/note, reviewed receipt and local bookmark. No avatar asset transfer, access-control bypass or private-avatar distribution. The peer workspace does not independently establish current account access to that avatar.
12. Temporary party board — Implemented: private plan, revisioned host-owned snapshots, selected-recipient fan-out, active shared contexts, roles and host-disconnected/expired/revoked states. No host transfer/election, automatic member discovery or distributed concurrent board editing. Saved private plans outlive the temporary shared session.
13. Ready checks — Implemented: reusable local templates, selected-peer or group requests, deadline, explicit READY/NOT_READY/DECLINED replies, and per-peer response display. NO_RESPONSE remains distinct. Responses are bound to the original request, recipient, session and context.
14. Shared countdowns — Implemented: local monotonic timers and explicit target timestamps rendered locally with an approximate clock-offset/uncertainty estimate. Expired events are not queued for reconnect. Clock synchronization is approximate, not precision scheduling or a guarantee under large clock skew; no per-tick network countdown messages.
15. Photo coordination — Implemented as composable tools: local shot lists/notes, shared photo-plan cards, roles, ready checks and countdowns. No automatic camera capture, avatar posing or camera bridge integration is supplied.
16. Media cues — Scoped implementation: local cue sheets and approved PLAY/PAUSE/SEEK/etc. markers, optionally scheduled and shared. Markers never operate a media player or audio device; a playback adapter and automatic synchronized playback are not implemented.
17. Safety check-ins — Implemented: explicit check-in and bounded OK/NEED_MINUTE/LEAVING/DISMISSED replies with consent, expiry and rate limits. These transient messages are excluded from retained message history. No diagnosis, emotion scoring or emergency-service behavior.
18. Safety Mode contact alert — Scoped implementation: a manually reviewed minimal ACTIVE/CLEARED state message; the local peer Safety preference suppresses novelty. No automatic alert on an existing VRChat/Safety subsystem event, selected-contact subscription or automatic world/instance disclosure is implemented. This is distinct from startup Safe Mode, which blocks optional networking.
19. Diagnostic cards — Implemented: closed-schema capture from existing Unity/Resource Guard/Black Box observations, preview, local save/export and explicit peer share. Runtime state, supported metrics, duration and incident count are available when measured. Raw logs, credentials, paths, player history and messages are excluded. Rich issue/event selection, hardware details and arbitrary log attachments are not part of the current card.
20. Remote troubleshooting — Scoped implementation: ask for runtime/metrics/errors, communicate explicit acceptance/decline, and separately preview/share diagnostic cards. Approval does not create an automatic ongoing data feed or grant remote actions. No remote desktop, shell, process manipulation, filesystem browsing or guided-action execution.
21. Version compatibility — Implemented: authenticated-device version claim, protocol version, negotiated capability intersection and action explanations. Current protocol is v1; compatibility is per capability rather than an app-version threshold. No historical schema migration/translation for future protocols is claimed.
22. One-time preset/config transfers — Implemented: supported Wellness reminder/display leaves and Resource Guard view only; local export/import and peer transfer use the same allowlist. Explicit diff/review, transactional validation/write/verification and a local undo checkpoint are supplied. Open supported tools refresh immediately without starting providers or replacing the active Wellness session; rollback will not overwrite later edits. No whole-settings replacement, account/network/permission import, durable checkpoint history or broad safety/overlay/plugin preset ecosystem.
23. Creator playtests — Implemented: local title/phase/target/notes, saved playtest plans and revisioned shared snapshots, supported by separate checklists, ready checks, diagnostics and performance cards. These can be used without networking. No automated synchronized test runner, continuous group telemetry collection or consolidated live multi-participant report engine.
24. Performance comparison — Implemented: capture current supported measurements with source/quality/count, save/share/import, and compare two cards. Missing/stale sensors remain unavailable and mismatched-source deltas are withheld. Built-in captures are point samples, not timed benchmark averages; there is no synchronized multi-device sampling campaign, hardware classification or cause attribution.
25. Peer-confirmed diagnostics — Implemented: local observation and reciprocal compatible category/time-bucket/context confirmations, with distinct per-peer receipts. The claim is that devices agreed on an observation, not that a specific avatar caused it. No automatic causal inference or automatic matching against all Black Box incidents.
26. Rendezvous tokens — Implemented: cryptographically random, expiring, one-use connection invitations with pins and device-key binding; entering Private Mode invalidates invitations. Tokens authorize a connection, not feature permissions. Purpose-specific party/creator/troubleshooting invitations, account routing and individual token management UI are not supplied. LAN/Hamachi invitations intentionally contain the endpoint; relay invitations contain only the relay route.
27. Session-only roles — Implemented: host-owned, context/revision-bound VRC Eye role labels, including Host/Co-Host/Photographer/DJ/Tester/Observer/Coordinator, expiring with context. Roles are not VRChat authority. No complete role-to-command permission delegation, host succession or remotely editable tester assignment system.
28. Shared creator checklists — Implemented: private checklist items with statuses/notes, local optimistic revision check, explicit host snapshot sharing and distinct received copies. Old shared revisions are rejected. No concurrent remote item-patch protocol, automatic conflict merge or automatic tester edits to the host's source checklist.
29. VRC Eye service latency — Implemented: peer-service round-trip measurement and approximate clock offset/uncertainty over the chosen transport. It is labeled separately from VRChat ping. Separate relay-only RTT, loss estimates, reconnect statistics and smoothing are not a complete telemetry suite here.
30. Shared overlay notifications — Implemented: consented bounded static notices in the app, plus optional SteamVR display through the existing Wellness OpenVR connection. The receiver owns visibility, duration, privacy, motion and audio behavior. Peers cannot request full-screen control, flashing or sound. No separate OpenVR connection is started by peer networking.
31. Synchronized novelty — Scoped implementation: immediate local or scheduled/shared motion-free celebration notices with fixed styles, consent, rate limiting and DND/streamer/Safety suppression. Animated particles/confetti, custom assets, flashing and synchronized sound are intentionally absent.
32. Per-user sharing permissions — Implemented per authenticated device and family, with separate send/receive rules, ASK/ALLOW/DENY, once/session/hour/persistent scopes, block, inspection, reset/revoke and reviewed incoming requests. Global/private restrictions and explicit denials win. No independently verified friend defaults, account-wide multi-device rules, copy-another-user UI, until-VRChat-player-departure scope, or separate rule for every field/event inside a family. Profile field visibility is a separate local gate.

## Support sections 33–50

33. Device identity — Persistent local device signing key and TLS identity when networking is first enabled; no cloud account layer or multi-device account routing. Private tools need no crypto package or identity provisioning.
34. Session generation — Fresh authenticated session IDs and ordered transport sequences protect reconnects; active contexts, revision checks and ended-context tombstones prevent stale actions. The envelope generation is currently fixed at 1 rather than a negotiated multi-generation protocol. Context changes invalidate temporary activity; explicit new contexts/reconnection are required as applicable.
35. Context binding — Implemented for shared session operations, responses, owner/revision mutations and mutual evidence. Player-session changes invalidate live contexts and temporary grants. New actions cannot resurrect an ended implicit session context silently.
36. Kill switch — Private Mode closes connections/listeners, discards pending reviews and temporary consent, ends shared work and leaves local tools/saved items available. App Demo, startup Safe Mode and account changes also stop networking.
37. Emergency revoke — Implemented: clear sharing grants/reviews/active shared context and queued disclosure while preserving explicit denials and blocks; transport may remain connected. It does not retract data another device already received.
38. Offline queue — Registry encodes queueability/TTL. Whispers, references and presets can be deliberately held in the local outgoing queue and reviewed/flushed after reconnection; transient ready/countdown/media/novelty events cannot queue. No relay mailbox, automatic replay or outbound queue restoration after restart.
39. Anti-spam — Bounded transport connections/handshakes/frame rate/queues plus per-peer and family message budgets, pending-review limits and bounded state. No public-service abuse account system, moderation directory or reputation service.
40. Payload limits — Strict frame and message-size limits plus bounded text, lists, nesting, storage, history, contexts, receipts, queues and peer counts. Large or malformed payloads fail without becoming app objects.
41. Schema validation — Strict JSON, duplicate-key/nonfinite/invalid-type rejection, closed schemas, exact references, bounded content and safe identifiers before dispatch. No arbitrary object deserialization or remote executable instruction schema.
42. Registry — One protocol registry supplies 28 versioned message kinds, families, TTL/queue policy, context requirements and payload limits. Runtime handler ownership remains centralized in PeerService. This is not a dynamic plugin/remote-code registration API.
43. Privacy inheritance — Player Incognito/presentation/anonymize/history restrictions and Wellness streamer restrictions feed an additive policy that a peer-page toggle cannot undo. Demo/startup Safe Mode restrictions apply. Streamer policy suppresses notices; it is not a guarantee that capturing the entire private workspace hides its editor/transcript contents. No separate Guest Mode/account trust layer is added.
44. Event inspector — Bounded sanitized feature/decision/status metadata and counters in Developer view. No message bodies, invitation tokens or private keys are placed in audit events. It is not a full raw handshake packet capture.
45. Decision tracing — Local support, negotiated remote support, protocol, connection and local permission can be explained. Remote policy remains explicitly ASK_OR_PEER_POLICY until the recipient handles the request; there is no fully replicated remote permission snapshot. Detailed context enforcement happens again on send/accept.
46. Simulation — Deterministic isolated in-memory scenarios: normal, delay, duplicate, stale, deny, revoke, reconnect and rate limit. Uses real protocol/permission primitives without live sockets or app data. Not a full network emulator with packet loss, corrupt wire frames, arbitrary old clients or simulated provider outages; separate automated socket tests cover malformed/security paths.
47. Black Box — Peer activity category/count/sequence metadata only. No peer names, IDs, addresses, profile/bio, Whisper text, tokens or arbitrary event payloads enter the recorder.
48. Outage behavior — Network failure leaves local tools usable, marks lost peers unavailable and ends their temporary activity. Explicit local files/history are independent. No hidden fallback from Relay to a direct public connection.
49. Graceful reconnect — Safe explicit reconnection with a fresh invitation/session; old temporary grants and transient events are not restored. Automatic retry/backoff, resume tokens and automatic fresh state/permission resynchronization are not implemented.
50. Server minimalism — Optional operator relay is an opaque live tunnel with bounded rendezvous state and no application message/history store. It knows endpoints and routing/traffic metadata, not inner TLS payloads. No backend account directory, relationship store, offline mailbox or remotely managed production service is deployed.


---

# Original supplied design — unchanged

# VRC Eye Peer Services

The subsystem should provide identity, secure communication, permissions, presence, ephemeral group sessions, synchronization, diagnostics, creator collaboration, and small social utilities between installations of VRC Eye.

The most important architectural rule is:

> **Build one peer-services platform, then implement the 32 features as services on top of it.**

Do **not** separately implement networking for Whispers, another connection method for Ready Checks, another for diagnostics, another for creator sessions, etc.

Your earlier Player List design already anticipated the VRC Eye ecosystem as a distinct layer containing VRC Eye identity, profiles, link capability display, Whispers, shared bookmarks, and Ready Checks, with Bridge Mode coming afterward rather than being a prerequisite.    Pasted text

That separation is extremely important.

---

# I. The architecture underneath everything

Conceptually:

```
VRC Eye
│
├── Peer Services
│   │
│   ├── IdentityService
│   ├── RelayClient
│   ├── HandshakeManager
│   ├── CapabilityRegistry
│   ├── PermissionEngine
│   ├── PresenceService
│   ├── PeerSessionManager
│   ├── PartySessionManager
│   ├── MessageRouter
│   ├── DeliveryManager
│   ├── ClockSyncService
│   ├── SanitizationService
│   ├── AbuseProtection
│   └── PeerAuditLog
│
├── Peer Features
│   ├── Whispers
│   ├── Profiles
│   ├── Recommendations
│   ├── Bookmarks
│   ├── Ready Checks
│   ├── Countdowns
│   ├── Photo Coordination
│   ├── Media Cues
│   ├── Safety Check-ins
│   ├── Diagnostics
│   ├── Troubleshooting
│   ├── Config Transfer
│   ├── Creator Sessions
│   ├── Performance Compare
│   ├── Creator Checklists
│   ├── Session Roles
│   └── Novelty Events
│
└── Presentation
    ├── Player List
    ├── Player Details
    ├── SteamVR Overlay
    ├── Desktop Notifications
    ├── Creator Mode
    ├── Safety Center
    └── Diagnostics
```

The Player List only consumes this information.

It doesn't own the networking.

Whispers don't own the networking.

Creator Mode doesn't own the networking.

Diagnostics doesn't own the networking.

Everything talks to `PeerServices`.

---

# II. VRC Eye must not expose users' IP addresses

This is one of the strongest decisions I'd preserve from the original concept.

Normal VRC Eye-to-VRC Eye communication should look like:

```
Alice VRC Eye
      │
 encrypted connection
      │
      ▼
 VRC Eye Relay
      │
 encrypted connection
      │
      ▼
Bob VRC Eye
```

Not:

```
Alice
  │
  └────────── direct Internet connection ──────────► Bob
```

A direct connection means Alice's machine learns Bob's public IP and vice versa.

There is essentially no reason Whispers, Ready Checks, diagnostic cards, countdowns, bookmarks, or creator checklists require that.

The relay can therefore perform:

```
authentication
routing
online presence
session rendezvous
connection multiplexing
rate limiting
abuse protection
offline-message handling
```

while payload contents can still be application-level encrypted where appropriate.

VRC Eye should **not invent its own cryptography**. Use a mature audited implementation/protocol for any end-to-end encryption.

---

# III. The universal VRC Eye message envelope

Every VRC Eye peer feature should ultimately become a message like this:

```
PeerEnvelope
{
    protocol_version
    message_id

    sender_account_id
    sender_device_id

    recipient_type
    recipient_id

    peer_session_id
    party_session_id?

    message_type

    created_at
    expires_at

    sequence_number?

    reply_to_message_id?

    requires_ack
    delivery_class

    payload_schema
    payload

    signature/authentication_data
}
```

For example:

```
message_type = "ready_check.request"
```

or:

```
message_type = "whisper.message"
```

or:

```
message_type = "diagnostics.card"
```

or:

```
message_type = "novelty.confetti"
```

The networking layer shouldn't really care.

It says:

> Message X from Alice to Bob uses schema Y.

Then the appropriate handler gets it.

---

# IV. Delivery classes

Don't treat every event equally.

Define something like:

```
EPHEMERAL
RELIABLE
REQUEST_RESPONSE
STATE_UPDATE
SESSION_EVENT
OFFLINE_CAPABLE
```

Examples:

```
confetti
→ EPHEMERAL

typing indication
→ EPHEMERAL

whisper
→ RELIABLE + OFFLINE_CAPABLE

ready check
→ REQUEST_RESPONSE

presence
→ STATE_UPDATE

party board update
→ SESSION_EVENT

diagnostic card
→ RELIABLE

photo countdown
→ SESSION_EVENT
```

This prevents hilarious bugs like:

> User reconnects after 20 minutes and receives twelve delayed confetti explosions followed by a photo countdown that ended yesterday.

Every message should have an expiration time.

---

# V. PeerSession should become a first-class object

Conceptually:

```
PeerSession
{
    session_id

    local_account
    local_device

    remote_account
    remote_device

    state

    started_at
    last_activity

    negotiated_protocol

    capabilities

    permissions

    latency

    clock_offset

    encryption_state

    rendezvous_context

    current_vrchat_context?

    degraded_reason?
}
```

State machine:

```
DISCONNECTED
     │
     ▼
RELAY_AVAILABLE
     │
     ▼
RENDEZVOUS
     │
     ▼
HELLO
     │
     ▼
AUTHENTICATED
     │
     ▼
NEGOTIATING
     │
     ▼
READY
     │
     ├────► DEGRADED
     │
     └────► RECONNECTING
              │
              ▼
             READY
```

Do not make:

```
connected = true
```

your entire connection model.

There will eventually be states such as:

```
Connected to relay
Peer offline

Peer online
Handshake incomplete

Peer authenticated
No compatible protocol

Peer compatible
Whispers disabled

Peer connected
Diagnostic sharing denied

Peer reconnecting

Peer connection stale
```

Those distinctions matter enormously.

---

# VI. Capability availability needs four separate gates

A feature being implemented does **not** mean it should appear.

For every action:

```
AVAILABLE =
    local_support
    AND remote_support
    AND local_permission
    AND remote_permission
    AND context_allows
```

For example:

```
Photo Countdown

Local VRC Eye supports it          ✓
Remote VRC Eye supports it         ✓
Alice allows receiving countdowns  ✓
Bob allows sending countdowns      ✓
Users share party session          ✓

AVAILABLE
```

But:

```
Remote diagnostic cards            ✓
Bob supports diagnostics            ✓
Alice denies diagnostic sharing     ✗

UNAVAILABLE
```

Your earlier design explicitly established this principle: only mutually supported/permitted actions should be presented to the user.    Pasted text

---

# VII. Permissions are more important than capabilities

I would model permissions separately from capability support.

```
PermissionGrant
{
    subject_peer_id

    capability_family

    direction:
        SEND
        RECEIVE
        BOTH

    decision:
        ALLOW
        DENY
        ASK

    scope:
        ONCE
        SESSION
        ONE_HOUR
        UNTIL_LEAVE
        PERSISTENT

    created_at
    expires_at

    granted_by_user
}
```

The previous Safety design already established the right philosophy: consent should be able to expire after one action, one session, an hour, until departure, or become an explicitly persistent friend permission.    Pasted markdown

That should become a core Peer Services primitive.

---

# VIII. Permission precedence

I would make the resolver deterministic:

```
GLOBAL EMERGENCY NETWORK OFF
        ↓
BLOCKED USER
        ↓
GLOBAL CAPABILITY DENY
        ↓
PER-USER DENY
        ↓
CURRENT SESSION RULE
        ↓
TEMPORARY GRANT
        ↓
PERSISTENT USER RULE
        ↓
FRIEND DEFAULT
        ↓
GLOBAL DEFAULT
```

`DENY` should beat `ALLOW` at higher authority.

That prevents a temporary creator session from accidentally overriding:

> Never receive diagnostic requests from this person.

---

# IX. Data provenance must continue into Peer Services

Your Player List architecture established a very useful rule: values should record whether they originated from LOG, API, LOCAL, OSC, VRC_EYE, BRIDGE, DERIVED, or UNKNOWN.    Pasted text

Peer Services should therefore generate values like:

```
status = {
    value: "DND",
    source: VRC_EYE,
    observed_at: ...
}
```

or:

```
ready_state = {
    value: READY,
    source: VRC_EYE,
    confirmed_by_peer: true
}
```

or:

```
frame_time = {
    value: 14.7ms,
    source: LOCAL,
    shared_via: VRC_EYE
}
```

Do not blur:

```
locally measured
```

with:

```
remote peer claims to have measured
```

---

# 1. VRC Eye Handshake

This is the foundation.

A handshake answers:

```
Who are you?

Can I authenticate that identity?

Which VRC Eye protocol do you speak?

Which features do you implement?

Which features are you allowing me to use?

Are we already trusted?

What session are we establishing?
```

I would structure it approximately:

```
Alice → Relay
AUTHENTICATE

Relay → Alice
AUTH_OK
account_id = eye_123

Alice requests connection:
peer = eye_987

Relay establishes rendezvous.

Alice → Bob
HELLO
protocol_range = [1.0 - 1.4]
device_session = ...
nonce = ...

Bob → Alice
HELLO_ACK
protocol_range = [1.2 - 1.5]
nonce_response = ...

Both:
negotiated = 1.4

Alice → Bob
CAPABILITY_OFFER

Bob → Alice
CAPABILITY_OFFER

Both:
calculate capability intersection

Both:
READY
```

Never authenticate peers by display name.

The stable identity should be something such as:

```
eye_account_id
```

with optionally:

```
verified_vrchat_user_id
```

Those are different identities.

A peer must never be able to say:

```
"I am usr_1234"
```

and have VRC Eye blindly believe it.

---

# 2. Capability Negotiation

Give every capability a stable machine identifier.

For example:

```
peer.whisper.v1
peer.profile.v1
peer.presence.v1
peer.session_card.v1

peer.bookmark.send.v1

peer.recommend.world.v1
peer.recommend.avatar.v1

peer.party_board.v1
peer.ready_check.v1
peer.countdown.v1
peer.photo.v1
peer.media_cue.v1

peer.safety_checkin.v1
peer.safety_mode_alert.v1

peer.diagnostic_card.v2
peer.troubleshooting.v1

peer.config_transfer.v1

peer.creator_session.v1
peer.creator_checklist.v1

peer.performance_compare.v1
peer.diagnostic_confirmation.v1

peer.overlay_notice.v1
peer.novelty.confetti.v1
```

Never implement:

```
if remote_version >= 1.18.9:
    enable_photo_button()
```

Use:

```
if peer.supports("peer.photo.v1"):
    enable_photo_button()
```

Versions are metadata.

Capabilities determine behavior.

A capability may also advertise limits:

```
peer.whisper.v1
{
    max_text_bytes: 4096
    attachments: false
    reactions: true
}
```

Negotiation takes the most restrictive compatible parameters.

---

# 3. Optional VRC Eye Profile

This should be intentionally lightweight.

Your earlier design already included an optional VRC Eye badge/profile containing things such as compatibility, shared capabilities, DND, pronouns, status, creator/streamer information—with only explicitly shared fields visible.    Pasted text

Model each field individually:

```
PeerProfile
{
    display_alias?

    status_text?

    pronouns?

    favorite_color?

    creator_mode?

    streamer_status?

    profile_icon?

    capabilities_public?

    profile_revision
}
```

Each field:

```
visibility =
    NOBODY
    APPROVED_USERS
    FRIENDS
    SESSION_MEMBERS
```

Don't make users publish a profile merely to use peer services.

A profile can be completely blank.

---

# 4. VRC Eye Whispers

Whispers should effectively be VRC Eye private messages.

But deliberately small-scale.

Not:

> Build Discord inside VRC Eye.

Default policy should remain restrictive:

```
Receive whispers from:
◉ VRChat friends using VRC Eye
○ Approved VRC Eye users
○ Nobody
```

And preferably **no global searchable user directory**.

Whisper object:

```
WhisperMessage
{
    message_id
    sender
    recipient

    sent_at
    expires_at?

    text

    reply_to?
}
```

Delivery states:

```
SENDING
SENT_TO_RELAY
DELIVERED_TO_DEVICE
FAILED
EXPIRED
```

I wouldn't make read receipts default.

Important controls:

```
Mute VRC Eye Whispers
Mute user
Block user
Allow session only
Clear conversation
Delete local history
```

Server-side offline retention should be short and purpose-specific.

Message history should primarily belong to the users, not become an enormous permanent VRC Eye cloud archive.

---

# 5. Online / DND / AFK Status

Separate these:

```
NETWORK PRESENCE
ONLINE
OFFLINE

USER AVAILABILITY
AVAILABLE
DND
AFK
BUSY
BREAK
```

Do not conflate:

```
Offline
```

with:

```
Not in VRChat.
```

Someone can have:

```
VRC Eye Online
VRChat Closed
```

Manual status should beat inferred status.

Example priority:

```
manual DND
    >
manual AFK
    >
automatic AFK
    >
available
```

Automatic AFK should have a timeout and should never reveal sensitive activity.

---

# 6. Shared Session Card

This becomes a small voluntary snapshot:

```
SESSION

World
Midnight Rooftop

Session duration
1h 24m

Mode
Desktop

Status
Taking photos
```

But each field gets privacy controls.

A user may allow:

```
share world name
```

without:

```
share exact instance
```

Instance identifiers deserve stricter privacy than ordinary world IDs.

Possible fields:

```
world
instance visibility
session duration
VR/Desktop
creator testing status
party session
current role
DND
```

Use TTLs.

When the session ends, the card becomes stale immediately.

---

# 7. Capability Badges

The Player List could show:

```
Alice    👁  📷  🧪
```

Meaning:

```
VRC Eye user
Photo Sync supported
Creator tools supported
```

But do not turn a player row into NASCAR.

You already wanted Player List badge density capped around three or four visible indicators.

Everything else should live under:

```
VRC EYE LINK
```

Expanded view:

```
Whispers               Available
Ready Checks           Available
Photo Sync             Available
Creator Session         Available
Diagnostics             Ask first
Troubleshooting         Disabled
Config Transfer         Available
```

---

# 8. Mutual Encounter Count

This needs more thought than it appears to.

Your existing local encounter counter defines an encounter as a confirmed shared instance session and deliberately merges rapid leave/rejoin noise rather than incrementing repeatedly.    Pasted text

For VRC Eye peers, create a **mutually confirmed encounter receipt**.

During a valid shared session:

```
Alice sees Bob.
Bob sees Alice.

VRC Eye session context matches.

Alice → Bob
encounter.confirm

Bob → Alice
encounter.confirm
```

Each stores:

```
ConfirmedPeerEncounter
{
    peer_account_id
    encounter_id
    confirmed_at
}
```

It doesn't have to retain the world.

Then:

```
Mutual VRC Eye encounters: 17
```

means:

> Both VRC Eye installations confirmed 17 shared encounters.

Not:

> Alice's local database says she saw Bob 17 times.

That distinction is much stronger.

It also prevents one client from simply claiming:

```
We've met 98,423 times.
```

---

# 9. Shared Bookmarks

Think of these as transferable references.

```
BookmarkCard
{
    bookmark_type

    target_id
    display_label?

    sender_note?

    created_at
}
```

Receiver gets:

```
Alice sent a bookmark

Midnight Rooftop

"Good photo world"

[ Preview ]
[ Save ]
[ Dismiss ]
```

Do not automatically modify someone's local favorites unless they have explicitly enabled it.

---

# 10. World Recommendation Cards

This is specialized bookmark UX.

Send primarily:

```
world_id
sender comment
```

Let the receiving VRC Eye resolve metadata itself.

That prevents stale or forged metadata.

Card:

```
WORLD RECOMMENDATION

Midnight Rooftop
from Alice

"Great mirror and lighting."

[ Details ]
[ Save ]
[ Open in VRChat ]
```

Privacy:

Sending a world recommendation should **not** imply:

> Alice is currently in this world.

Those are separate pieces of information.

---

# 11. Avatar Recommendation Cards

Same basic architecture:

```
AvatarRecommendation
{
    avatar_reference
    sender_note
}
```

But VRC Eye must respect avatar availability.

Do not turn it into private-avatar distribution.

If the receiver isn't legitimately able to access the avatar:

```
Avatar unavailable to this account.
```

Not:

```
Here's all the private avatar metadata so we can circumvent that.
```

This should primarily work for appropriately accessible/public avatar references.

---

# 12. Temporary Party Board

This is where the ecosystem starts becoming extremely useful.

Create an ephemeral VRC Eye session:

```
PHOTO NIGHT
────────────────────
Host          Alice
Members       5

Current:
Midnight Rooftop

Next:
Treehouse in the Shade

Status:
3 / 5 ready

Roles:
Alice     Host
Bob       Photographer
Claire    Model
Dave      DJ
Eve       —
```

Board object:

```
PartyBoard
{
    party_id
    generation

    title
    host

    members

    current_destination?
    next_destination?

    notes?

    ready_check?

    countdown?

    roles

    created_at
    expires_at
}
```

Make the host authoritative initially.

That's far easier than implementing a distributed conflict-resolution system.

If Host disconnects:

```
HOST DISCONNECTED

[ Transfer Host ]
```

Use deterministic succession only if explicitly configured.

---

# 13. Ready Checks

Request:

```
Ready Check
Photo in 30 seconds

[ Ready ]
[ Not Ready ]
```

State:

```
ReadyCheck
{
    id
    initiator

    recipients

    prompt

    started_at
    deadline

    responses
}
```

Responses:

```
READY
NOT_READY
NO_RESPONSE
DECLINED
```

Important:

Do not interpret `NO_RESPONSE` as `NOT_READY`.

UI:

```
READY CHECK

Alice      Ready
Bob        Ready
Claire     Not Ready
Dave       —
Eve        Ready

3 / 5 Ready
```

These should be completely session-scoped.

---

# 14. Shared Countdowns

Do **not** send:

```
3
2
1
```

over the network.

That will jitter horribly.

Instead synchronize clocks and send:

```
target_timestamp
```

Example:

```
COUNTDOWN_START
target_server_time = 21:42:10.500
```

Every device renders its own:

```
3
2
1
GO
```

locally.

The network only establishes the common target.

Your ClockSyncService should estimate:

```
relay RTT
peer logical RTT
clock offset
offset uncertainty
```

If confidence is poor:

```
Approximate synchronization
±140 ms
```

---

# 15. Photo Coordination

Photo Coordination becomes a composition of existing primitives.

It should use:

```
Party Board
+ Roles
+ Ready Check
+ Countdown
+ Overlay Notifications
```

For example:

```
PHOTO SESSION

Photographer    Alice
Subjects         Bob, Claire

Pose             Group shot
Camera Ready     Yes

Bob              Ready
Claire           Ready

[ Start 5 sec Countdown ]
```

Overlay:

```
PHOTO IN

3

2

1

📷
```

Later, if a legitimate bridge exposes camera-related capabilities, that can enhance it.

But Photo Coordination must work without Bridge Mode.

---

# 16. Shared Media Cues

This should synchronize **commands**, not distribute copyrighted media.

Examples:

```
PLAY
PAUSE
SEEK
NEXT_MARKER
START_AT
STOP
```

Message:

```
MediaCue
{
    cue
    media_session_id

    position?
    execute_at?

    initiator
}
```

The user already needs the relevant media available through whatever integration is controlling playback.

Useful with session DJ role:

```
DJ
Alice

Track:
Local playback source

Start together?
[ Accept ]
```

Never let another user silently start blasting audio without receiver permission.

---

# 17. Simple Safety Check-ins

This should remain intentionally simple.

Something like:

```
Alice is checking in.

Doing okay?

[ Yep ]
[ Need a minute ]
[ I'm leaving ]
[ Dismiss ]
```

No diagnosis.

No emotion scoring.

No permanent:

```
Alice was distressed 7 times this month.
```

A check-in is communication, not surveillance.

Rate-limit it heavily enough that it can't become harassment.

---

# 18. Optional “Safety Mode Activated” Friend Alert

This should be **explicit opt-in**.

Configuration:

```
When I manually activate Safety Mode:

☑ Notify selected VRC Eye contacts

Contacts:
Alice
Bob
```

Default alert:

```
Lucy activated VRC Eye Safety Mode.
```

Not:

```
Lucy is in danger at world X, instance Y, coordinates Z.
```

More context should only be included if specifically permitted.

Possible options:

```
Share:
☑ Safety Mode state
☐ Current world
☐ Current instance
☐ Diagnostic summary
```

It should also distinguish:

```
Safety Mode manually activated
```

from:

```
automatic protection triggered
```

if the underlying Safety subsystem makes that distinction.

---

# 19. Diagnostic-Card Sharing

This is one of the highest-value advanced features.

Instead of:

> Send me your entire output log.

Alice can send:

```
DIAGNOSTIC CARD

VRC Eye             1.19.2
VRChat               Running
Unity Player         Responding

Session
2h 11m

Recent issue
Avatar load timeout

GPU memory
High

Black Box incidents
2

[ Expand ]
```

Internally:

```
DiagnosticCard
{
    schema_version

    app_versions

    issue_category

    selected_metrics

    selected_events

    error_codes

    crash_signature?

    runtime_summary?

    hardware_summary?

    redactions
}
```

This absolutely needs a **SanitizationService**.

Before sending:

```
REMOVE:

authentication tokens
cookies
passwords
local account secrets
full filesystem paths where unnecessary
Windows username
machine identifiers
private notes
unrelated player history
private Whispers
raw VRChat credentials
```

Always show a preview.

---

# 20. Remote Troubleshooting Request

This should **not** initially mean remote control.

Think:

```
Alice would like to help troubleshoot.

Requested access:

✓ VRC Eye version
✓ Unity Player status
✓ Current errors
✓ Runtime metrics
✗ Logs
✗ Hardware details

Duration:
This session

[ Allow ]
[ Customize ]
[ Deny ]
```

After approval:

```
TROUBLESHOOTING SESSION

Alice can view:
Runtime status
Errors
Selected metrics

Expires:
When either user leaves

[ End Access ]
```

Initially prohibit:

```
arbitrary shell commands
arbitrary PowerShell
arbitrary process injection
arbitrary filesystem browsing
remote mouse control
remote memory access
```

Later, safe guided actions could use explicitly registered commands:

```
Request:
Restart VRC Eye overlay

[ Approve ]
```

not:

```
remote.execute("whatever Alice sent")
```

Every requested action should be locally confirmed unless the user has intentionally granted a very narrow predefined permission.

---

# 21. Version Compatibility Display

Peer panel:

```
VRC EYE LINK

Alice

VRC Eye              1.19.4
Protocol             4

Compatibility        Compatible

Whispers             ✓
Photo Sync           ✓
Creator Sessions     ✓
Diagnostics v2       ✓
Config Transfer v2   ✗
```

If versions differ:

```
Limited Compatibility

Alice is using an older peer protocol.

Unavailable:
• Config Transfer v2
• Creator Checklist comments

Everything else remains available.
```

Don't make compatibility binary unless it truly is.

---

# 22. One-Time Preset / Config Transfers

Extremely useful.

Examples:

```
overlay layout
notification preset
wellness timer preset
creator test configuration
safety UI layout
performance logging preset
```

But never send:

```
authentication tokens
VRChat credentials
private account identifiers
filesystem secrets
plugin secrets
API keys
```

Transfer:

```
ConfigTransferPackage
{
    schema
    schema_version

    sections[]

    created_by

    created_at
}
```

Receiver must see:

```
CONFIGURATION FROM ALICE

Changes:

Overlay
+ Enable FPS
+ Move panel to left

Notifications
- Disable world-change sound

Safety
No changes

[ Preview Full Diff ]
[ Import ]
[ Cancel ]
```

Before applying:

```
create configuration checkpoint
validate
migrate
apply
verify
```

If anything fails:

```
rollback
```

This should never be blind replacement of `settings.json`.

---

# 23. Shared Creator Playtest Sessions

This deserves to become one of the flagship advanced VRC Eye features.

Example:

```
CREATOR PLAYTEST
Avatar Physics Test #17

Host
Alice

Participants
Alice
Bob
Claire
Dave

Target
Avatar: TestAvatar_17

Phase
PhysBone stress test

Checklist
7 / 12

Diagnostics sharing
3 participants opted in

Performance comparison
Active
```

Possible workflow:

```
CREATE SESSION
      ↓
Invite testers
      ↓
Assign roles
      ↓
Select test target
      ↓
Load checklist
      ↓
Ready check
      ↓
Begin test phase
      ↓
Collect opt-in metrics
      ↓
Bookmark events
      ↓
Compare sanitized results
      ↓
Export playtest summary
```

This beautifully connects several VRC Eye systems instead of duplicating them.

---

# 24. Sanitized Performance Comparisons

Example:

```
PLAYTEST PERFORMANCE

                Alice       Bob        Claire

FPS             72          48         61
CPU frame       8.2ms       11.7ms      9.9ms
GPU frame       11.1ms      18.9ms     14.4ms
Memory          5.8GB       6.2GB       5.9GB
```

But context matters enormously.

The systems may differ.

So include:

```
measurement period
measurement source
sample count
quality/confidence
```

Don't present:

> Bob gets lower FPS; therefore the avatar is broken.

Instead:

> Bob's client reported higher GPU frame time during the same test window.

Hardware details should be separate permissioned data.

You could optionally normalize into classes:

```
GPU class: High
CPU class: Mid
VR mode: PCVR
```

rather than revealing full hardware fingerprints.

---

# 25. Peer-Confirmed Diagnostic Events

This is a very clever feature if implemented conservatively.

Alice sees:

```
21:42:14
Frame-time spike
```

Bob independently observes something compatible around the same point.

You can create:

```
DiagnosticEventFingerprint
{
    category
    time_bucket
    context_hash
    object_reference?
}
```

Then:

```
Alice confirms event
Bob confirms event
Claire confirms event
```

UI:

```
Frame-time spike

Observed locally
Also observed by 2 VRC Eye peers
```

Not:

```
Bob's avatar definitely crashed everyone.
```

Peer confirmation increases confidence that an **event occurred**.

It doesn't automatically establish the **cause**.

That distinction fits perfectly with your existing provenance/confidence architecture.

---

# 26. Rendezvous Tokens

Rendezvous tokens establish temporary connections without exposing network location.

Could look user-facing like:

```
VRC-EYE-8F7K-2M9Q
```

Internally it should be a much stronger opaque token.

Properties:

```
random
unpredictable
short-lived
one-use or limited-use
revocable
bound to purpose
```

Example:

```
RendezvousToken
{
    token_hash

    issuer_account

    purpose:
        PEER_CONNECT
        PARTY_JOIN
        CREATOR_SESSION
        TROUBLESHOOTING

    expires_at

    max_uses

    permissions_requested
}
```

A photo-session invite token shouldn't automatically authorize diagnostics.

A troubleshooting token shouldn't become permanent friendship.

A creator session token shouldn't grant Whispers forever.

---

# 27. Session-Only Roles

Roles:

```
Host
Co-Host
Photographer
DJ
Tester
Observer
Coordinator
```

These are **VRC Eye session roles**.

Never present them like VRChat authority.

Bad:

```
MODERATOR
```

Good:

```
VRC Eye Party Role: Photographer
```

Role permissions could include:

```
Host
  manage board
  start ready check
  assign roles

Photographer
  start photo countdown
  request ready check

DJ
  send media cues

Tester
  update assigned checklist items
```

And they disappear when the temporary session ends.

---

# 28. Shared Creator Checklists

Structured object:

```
CreatorChecklist
{
    checklist_id
    revision

    title

    items[]
}
```

Item:

```
ChecklistItem
{
    item_id

    title
    description?

    status:
        TODO
        IN_PROGRESS
        PASS
        FAIL
        SKIPPED

    assignee?

    note?

    diagnostic_event?
}
```

Example:

```
AVATAR PLAYTEST

✓ Load avatar
✓ Confirm gestures
✓ Test facial expressions
⚠ PhysBone collision
✗ Left hand gesture
○ Mirror check
○ Low-FPS test
```

Changes should use revisions:

```
revision 42
```

Update:

```
base_revision = 42
change item #7 → PASS
```

If host is already on revision 44:

```
CONFLICT
```

Then fetch current state.

---

# 29. VRC Eye-to-VRC Eye Service Latency

Explicitly name this:

> **VRC Eye Service Latency**

Do not label it merely:

```
Ping
```

because users will assume VRChat ping.

Potential measurements:

```
Relay RTT
Peer acknowledgement RTT
Clock synchronization error
Packet/message loss estimate
Reconnect count
```

Display:

```
VRC EYE CONNECTION

Relay                 31 ms
Alice                  67 ms
Clock sync             ±18 ms
Connection             Good
```

Internally use smoothing rather than displaying wild individual samples.

Something like EWMA is sufficient.

This latency can directly determine whether synchronized events should warn:

```
Photo countdown precision may be reduced.
```

---

# 30. Shared Overlay Notifications

Another very useful primitive.

Example sender requests:

```
OverlayNotice
{
    category
    priority
    title
    body
    suggested_duration
}
```

But **the receiver owns presentation**.

Alice cannot send:

```
FULLSCREEN
FLASH RAPIDLY
100% OPACITY
STAY FOREVER
```

Receiver policy decides:

```
size
position
duration
sound
animation
whether shown at all
```

Examples:

```
Bob is ready.

Photo in 5 seconds.

Creator checklist updated.

Alice sent a world recommendation.

Safety check-in from Claire.
```

This also integrates nicely with your notification router philosophy.

---

# 31. Synchronized Confetti / Novelty Interactions

This is silly.

It is also exactly the sort of feature that makes an ecosystem feel alive.

Protocol:

```
novelty.confetti
{
    execute_at
    style_id
}
```

Receiver:

```
Novelty interactions:
☑ Friends
☐ Other session members

Intensity:
Low
```

Accessibility rules:

```
Reduced Motion enabled
→ suppress or simplify animation

Streamer Mode
→ optionally suppress

DND
→ suppress sounds

Safety Mode
→ suppress novelty interactions
```

Rate limit heavily:

```
one confetti event / user / several seconds
```

Otherwise somebody will discover the confetti equivalent of a denial-of-service attack approximately six minutes after release.

---

# 32. Per-User Sharing Permissions

This ties the entire ecosystem together.

Player detail:

```
ALICE
VRC EYE SHARING
────────────────────────

Presence
Online status               Allow
DND status                  Allow
AFK status                  Allow

Session
World                        Ask
Exact instance               Never

Communication
Whispers                     Allow
Recommendations              Allow

Coordination
Ready checks                 Allow
Countdowns                   Allow
Photo coordination           Allow
Media cues                   Ask

Safety
Check-ins                    Allow
Safety Mode alerts           Allow

Diagnostics
Diagnostic cards             Ask
Troubleshooting              Never
Performance comparison       Session only

Creator
Config transfers             Ask
Creator sessions             Allow
Checklists                   Allow
```

Advanced:

```
Reset to defaults
Copy another user's permissions
Revoke temporary access
Review active grants
```

And the user should be able to answer a permission prompt:

```
Alice requests diagnostic information.

[ Allow Once ]
[ Allow This Session ]
[ Always Allow Alice ]
[ Deny ]
```

This is the actual heart of the system.

---

# Additional things I would add

These weren't really part of the original visible feature list, but I think they're important enough that I would explicitly put them into the design now.

## 33. Device identity

One VRC Eye account may eventually have:

```
Desktop PC
Laptop
Future second installation
```

So distinguish:

```
account_id
```

from:

```
device_id
```

Otherwise logging into two devices gets very weird.

Peer UI could simply say:

```
Alice
2 VRC Eye devices online
```

Most features should target the **account** and let Peer Services route to the appropriate active device.

Troubleshooting may explicitly target a device.

---

# 34. Session generation numbers

Every reconnect/world/session should get a generation.

```
party_123
generation 7
```

If an old delayed message arrives:

```
party_123
generation 6
```

discard it.

This solves a huge category of:

> Why did an old Ready Check suddenly reappear?

bugs.

---

# 35. Context binding

Some events should be tied to:

```
peer session
party session
VRChat session
world
instance
creator test session
```

Example:

```
ready check:
context = party_123

diagnostic confirmation:
context = vrchat_session_77

photo countdown:
context = photo_session_4
```

When that context disappears, related messages expire.

---

# 36. Peer Services kill switch

Put this somewhere very accessible:

```
VRC Eye Network

[ Pause Peer Services ]
```

Effect:

```
Whispers                  Offline
Presence                  Offline
Party sessions            Leave
Remote diagnostics        Revoked
Temporary permissions     Revoked
Creator sessions          Leave
```

Local VRC Eye remains fully operational.

Exactly like Bridge Mode and VRCX Companion, network features should be additive—not a dependency for local safety/runtime functionality. That same architectural independence was already part of the Player List rollout.    Pasted text

---

# 37. Permission emergency revoke

Separate from simply going offline:

```
Revoke All Active Sharing
```

This immediately kills:

```
diagnostic access
troubleshooting sessions
performance sharing
session cards
temporary profile sharing
creator telemetry
```

but could leave ordinary Whispers online.

Very useful.

---

# 38. Offline queue policy

Every message type needs an offline policy.

Example:

```
Whisper
queue up to configured retention period

World recommendation
queue

Config transfer
queue briefly

Ready check
never queue

Countdown
never queue

Media cue
never queue

Confetti
absolutely never queue

Safety Mode alert
short expiration

Troubleshooting request
short expiration
```

This should be encoded in the message-type registry, not sprinkled around feature code.

---

# 39. Universal anti-spam governor

One peer should never be able to hammer another.

Have a centralized:

```
PeerRateLimiter
```

with buckets such as:

```
whispers
recommendations
ready checks
overlay notices
safety check-ins
diagnostic requests
troubleshooting requests
novelty events
```

When exceeded:

```
Alice's VRC Eye requests are being rate limited.
```

Not thirty-seven separate warnings.

---

# 40. Payload size limits

Define them early.

Something conceptually like:

```
Whisper                 small
Profile                  tiny
Ready Check              tiny
Recommendation Card      small
Diagnostic Card          moderate
Config Transfer          moderate
Creator Checklist        moderate
```

Do not accidentally allow:

```
diagnostic_card.payload = 8 GB
```

Every schema gets:

```
maximum serialized size
maximum nested items
maximum string length
```

Validate before allocating.

---

# 41. Strict schema validation

Never deserialize peer content directly into privileged application objects.

Network:

```
JSON / MessagePack / protobuf/etc.
```

↓

```
validate schema
```

↓

```
sanitize
```

↓

```
convert to internal type
```

↓

```
dispatch
```

Invalid:

```
DROP
LOG SAFE ERROR
RATE-LIMIT REPEAT OFFENDER
```

Unknown fields should generally be ignored where forward compatibility permits.

---

# 42. Feature registry

Create something like:

```
PeerFeatureRegistry
```

Entry:

```
FeatureDefinition
{
    capability_id

    minimum_protocol

    handler

    permission_category

    default_policy

    delivery_class

    offline_policy

    max_payload

    rate_limit

    requires_party_session

    requires_same_instance

    visible_in_casual_mode
}
```

Then adding:

```
peer.novelty.snowball.v1
```

later becomes registering a feature rather than rewriting Peer Services.

---

# 43. Privacy-mode inheritance

Your existing VRC Eye privacy modes should automatically influence Peer Services.

For example:

```
Incognito Mode
→ presence hidden
→ session card hidden
→ world sharing disabled

Streamer Mode
→ redact peer names where appropriate
→ suppress sensitive overlay content

Local History Off
→ don't persist encounter receipts unnecessarily

Guest Mode
→ peer services restricted
```

One global privacy mode should not require 19 manual switches.

---

# 44. Peer event inspector

Advanced / Developer Mode should expose:

```
PEER EVENT INSPECTOR

21:42:11 handshake.hello
21:42:11 capability.offer
21:42:11 capability.accept
21:42:12 presence.update
21:42:17 ready_check.request
21:42:19 ready_check.response
```

Payloads should be sanitized.

This will save enormous amounts of debugging pain.

You will eventually receive:

> Photo Sync doesn't work with Bob.

Instead of guessing, Developer Mode can show:

```
peer.photo.v1
local       supported
remote      supported
local perm  allowed
remote perm denied

Reason:
REMOTE_PERMISSION_DENIED
```

That is gold.

---

# 45. Capability decision tracing

Even better:

```
Why is "Share Diagnostic Card" disabled?

Capability Decision
────────────────────

Local support          ✓
Remote support         ✓
Protocol compatible    ✓
Local permission       ✓
Remote permission      ✗

Result
Unavailable
```

Do this for every peer action.

Never just grey a button out mysteriously.

---

# 46. Network simulation mode

For development, create simulated peers.

Example:

```
Developer
→ Peer Simulator
```

Spawn:

```
Alice   v1.18
Bob     v1.19
Claire  800 ms latency
Dave    packet loss
Eve     incompatible capabilities
Frank   reconnecting constantly
```

Inject:

```
latency
disconnects
duplicate messages
out-of-order events
stale messages
corrupt payloads
permission denial
old protocol
clock skew
relay outage
```

This is probably one of the best additions you can make.

You do **not** want to discover distributed-state bugs exclusively by asking three friends to launch VRChat at 2 AM.

---

# 47. Peer Services Black Box integration

Your Black Box / Crash Diagnostics system should record **metadata about Peer Services**, not private content.

Good:

```
21:42:11 Peer connected
21:42:11 Protocol 4 negotiated
21:42:12 24 capabilities available
21:44:17 relay reconnect
21:44:18 peer state restored
```

Bad:

```
Alice whispered:
"Here is my extremely private message..."
```

Never dump Whisper contents into Black Box.

Diagnostic correlation can use message IDs without message bodies.

---

# 48. Relay outage behavior

If the VRC Eye service goes down:

```
VRC Eye Peer Services
Temporarily unavailable

Local VRC Eye functionality is unaffected.
```

Everything else stays functional:

```
Player List
Safety
Wellness
Black Box
Unity Player tools
VRCX Companion
local history
Bridge Mode
```

No peer-service failure should compromise those systems.

---

# 49. Graceful reconnect

After network interruption:

```
DISCONNECTED
    ↓
RECONNECTING
    ↓
AUTH
    ↓
RESUME SESSION?
```

Use resume tokens/session identifiers.

Then request a fresh snapshot:

```
party.snapshot
presence.snapshot
permission.snapshot
```

Do **not** blindly replay every missed transient event.

State gets refreshed.

Events get expired.

---

# 50. Server-side minimalism

I would intentionally design VRC Eye's backend to know as little as reasonably possible.

The relay needs:

```
account routing
connection state
approved relationship state where necessary
delivery metadata
abuse controls
temporary session membership
```

It generally does not need:

```
diagnostic payload contents
private config contents
creator checklist contents
Whisper plaintext
local VRChat history
private notes
```

That reduces both privacy concerns and backend complexity.

---

# Database organization

Locally I'd keep peer data conceptually separate:

```
peer_accounts
peer_devices

peer_relationships
peer_permissions

peer_profiles_cache

peer_encounters

peer_sessions

peer_messages

peer_bookmarks

party_sessions
party_members
party_roles

creator_sessions
creator_checklists
creator_checklist_items

diagnostic_shares
troubleshooting_sessions

config_transfers

peer_audit_events
```

Don't cram all of this into `players`.

Your mature Player object should simply reference:

```
PeerState
```

which points into Peer Services.

---

# The Player List integration

Normal player:

```
Alice
Friend • Joined 17m
```

VRC Eye peer:

```
Alice                              👁
Friend • Joined 17m
```

Expand:

```
VRC EYE
────────────────────────

Status             Online
Availability       DND
Connection         Connected
Compatibility      Full
Latency            42 ms

Shared capabilities
📷 Photo
✓ Ready Checks
🧪 Creator
```

Actions:

```
[ Whisper ]
[ Send World ]
[ Ready Check ]
[ Photo ]
[ More ▾ ]
```

`More`:

```
Send Bookmark
Recommend Avatar
Share Diagnostic Card
Invite to Party
Invite to Creator Session
Sharing Permissions
```

And again: these controls should be capability-driven. The prior specification already named Whisper, Send World, Send Bookmark, Ready Check, Photo Countdown, and Share Diagnostic Card as peer actions, with availability determined by mutual capability/permission.    Pasted text

---

# Casual versus Advanced UI

This is particularly important with 32+ capabilities.

## Casual

Show:

```
VRC Eye Friend

Online
DND

[ Whisper ]
[ Send World ]
[ Ready Check ]
[ Photo ]
```

Settings:

```
Allow VRC Eye friends
Whispers
Photo coordination
Safety check-ins
```

That's about it.

## Advanced

Show:

```
identity
device
protocol
capability matrix
permissions
latency
rendezvous state
session scopes
diagnostic sharing
troubleshooting
creator tools
config transfers
```

## Developer

Show:

```
raw handshake
protocol versions
session IDs
sequence IDs
capability advertisements
permission decision traces
clock offset
relay RTT
ack RTT
message inspector
schema revisions
reconnect state
simulation tools
```

Casual users should never need to know what a rendezvous token is.

Developers absolutely should.

---

# Recommended implementation order

I would **not** implement these in the numerical order of the feature list.

I'd build them in dependency order:

```
PHASE A — FOUNDATION

VRC Eye account identity
Device identity
Relay connection
Handshake
Rendezvous tokens
Capability negotiation
Permission engine
Message envelope
Acknowledgements
Rate limiting
Reconnect handling
Event inspector


PHASE B — BASIC PEER EXPERIENCE

VRC Eye badge
Optional profile
Online/DND/AFK
Version compatibility
Capability display
Whispers
Per-user permissions


PHASE C — SIMPLE SHARING

Shared bookmarks
World recommendations
Avatar recommendations
Shared session card
Mutual encounter confirmation


PHASE D — SESSION INFRASTRUCTURE

Temporary Party Board
Session roles
Ready checks
Clock synchronization
Shared countdowns
Overlay notifications


PHASE E — SOCIAL SESSION FEATURES

Photo coordination
Media cues
Novelty interactions


PHASE F — SAFETY

Safety check-ins
Safety Mode alerts


PHASE G — DIAGNOSTICS

Diagnostic cards
Sanitization pipeline
Peer-confirmed events
Service latency display
Remote troubleshooting


PHASE H — TRANSFER

Preset/config package format
Diff viewer
Validation
Checkpoint
Rollback


PHASE I — CREATOR MODE

Creator playtest sessions
Shared checklists
Performance comparisons
Session telemetry


PHASE J — HARDENING

Network simulator
Black Box metadata
Abuse protection
Migration tests
Relay-outage tests
Multi-device tests
Clock-skew tests
Permission fuzzing
Payload fuzzing
```

That gets you usable functionality very early.

After Phase B, VRC Eye peers can already recognize each other and communicate.

After D, it becomes a genuinely useful multiplayer companion.

After G/I, it becomes a serious creator/debugging platform.

---

# The most important conceptual boundary

There are really four distinct kinds of VRC Eye-to-VRC Eye interaction:

```
SOCIAL
Whispers
Profiles
Recommendations
Presence


COORDINATION
Party Board
Ready Checks
Countdowns
Photos
Media
Roles
Overlay Notices


SAFETY / SUPPORT
Check-ins
Safety alerts
Diagnostics
Troubleshooting


CREATOR
Playtests
Checklists
Performance comparison
Diagnostic confirmation
Config transfer
```

Permission them separately.

Someone you trust enough to:

```
send memes through Whispers
```

isn't automatically someone you trust enough to:

```
inspect diagnostic information.
```

And someone helping test your avatar doesn't automatically need:

```
your online status forever.
```

That separation is the difference between a thoughtful permission system and a giant:

```
TRUST ALICE?
YES / NO
```

button.

---

# What I would consider the final architectural goal

Eventually a peer record should look approximately like:

```
PeerState
{
    identity
    devices

    presence
    profile

    relationship

    connection
    latency

    protocol

    capabilities

    permissions

    encounter_summary

    current_party

    current_roles

    active_shares

    active_troubleshooting

    diagnostics

    creator_session
}
```

And every other VRC Eye subsystem simply asks Peer Services questions:

```
peer.is_online()

peer.supports("peer.photo.v1")

peer.can_send("peer.ready_check.v1")

peer.can_receive("peer.diagnostic_card.v2")

peer.get_presence()

peer.get_latency()

peer.get_party()

peer.get_active_roles()
```

The UI should **never** have to understand handshake packets.

The Photo system should **never** have to authenticate Bob.

The Diagnostic system should **never** need its own networking code.

The Creator Checklist should **never** need to implement reconnection.

That's the architectural payoff.

If we build **VRC Eye Peer Services** correctly first, those 32 features become mostly handlers, schemas, and UI.

If we don't, feature #32 will arrive after 31 independent networking implementations and the codebase will become a small distributed-systems-themed crime scene.