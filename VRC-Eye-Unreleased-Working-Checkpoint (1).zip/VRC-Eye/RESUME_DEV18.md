# Resume VRC Eye after Development 18

Current baseline: VRC-Eye-v1.21.0-Development-18.zip. Parent Development 17
SHA-256: `f06813cfdcba149772e79ae448b01c5fcab53277c295035d84e923a881693688`.

Read CONTINUATION_DEV18.md, BUILD_VALIDATION.json and ARC_VRCX_GAP_LEDGER_DEV18.json.
The static GLB provider is avatar_scene.py / avatar_scene_worker.py /
avatar_scene_provider.py, with avatar_scene_ui.py inside ModelPreviewPanel.
It is deliberately a static bounded subset, not FBX/VRCA or skinning/materials
parity. No network/external resource reads. Process separation is not an OS sandbox.

Conditional Home selection lives in dashboard_conditions.py and the optional
conditions field in customization.py. Per-widget when is optional. The stored
active layout remains the fallback; runtime rules do not rewrite it. Manual
layout override persists until explicitly cleared. Tables target the effective
layout. Legacy documents without conditions are retained and readable.

settings_history.py captures allowlisted CompanionStore.set_option changes in the
same transaction, excludes secrets/grants, and uses stable widget IDs for undo.
Device history and workspace history are labelled separately. Keep it distinct
from settings_bundle_history and the recovery file journal. Pure history reads
must never mutate settings or start providers. Preserve optimistic UI checks.

All Development 17 source paths are retained. Native Windows/Linux GUI, installed
AssetRipper/Unity, real VRChat/CDN and native filesystem acceptance remain open.
The ARC/VRCX inventory is 106 areas: 50 source-implemented, 39 partial, 8 missing,
7 prerequisites and 2 source-data limits. The separate 160-package roadmap is
50 source-implemented, 70 partial and 40 pending. Do not combine these inventories.

Next: material/texture preview and qualified formats; later rig/blendshape/animation
controls, typed repair-helper journal integration, native/provider acceptance.
Earlier continuation guides describe historical states.
