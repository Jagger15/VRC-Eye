"""Explicit playback of disposable scene poses. Tk callbacks never parse a file."""
import time
from companion_ui import button,choice
from friendly_ui import flow_line as line
from avatar_animation import Clock,sample,describe
from avatar_scene import make_view
from avatar_library_files import check_cancel


def sample_view(scene,index,at,hidden,focus,framing,*,anchor=-1,stop=None):
    posed=sample(scene,index,at,anchor=anchor,stop=stop)
    view=make_view(posed,hidden,focus,framing=framing);check_cancel(stop)
    return posed,view


class AnimationTimeline:
    def __init__(self,controls):
        self.controls=controls;self.panel=controls.panel;self.page=page=controls.page
        self.original=None;self.source=None;self.index=None;self.worker=None;self.pending=None
        self.timer=None;self.revision=0;self.preparing=False;self.visible=False;self.clock=Clock();self.last_request=0.;self.finishing=False;self.shown_at=None
        self.box=page.ttk.Frame(controls.box)
        page.ttk.Label(self.box,text='Animation timeline',style='Heading.TLabel').pack(anchor='w')
        page.ttk.Label(self.box,text='Play explicitly or seek a time. Geometry stays in memory; Reset restores the imported pose. Preview events, scripts, controllers, IK, audio and networking never run. Unity AnimationClips, object-reference/material swaps and humanoid retargeting are unsupported: inspect the controller and mapping in your authorized Unity project, or export individual local-space GLB clips / FBX takes.',wraplength=1000).pack(anchor='w',pady=4)
        row=line(page,self.box);page.ttk.Label(row,text='Clip').pack(side='left')
        self.clip_value=page.tk.StringVar(value='');self.clip_picker=choice(page,row,self.clip_value,(),self.select_clip,width=48)
        self.take_box=page.ttk.Frame(self.box)
        row=line(page,self.take_box);page.ttk.Label(row,text='FBX take').pack(side='left')
        self.take_value=page.tk.StringVar(value='');self.take_picker=choice(page,row,self.take_value,(),self.select_take,width=48)
        row=line(page,self.take_box);self.range_vars={}
        for key,label,value in (('start','Start seconds','0'),('end','End seconds','1'),('rate','Samples/sec (1–12)','12')):
            page.ttk.Label(row,text=label).pack(side='left');v=page.tk.StringVar(value=value);self.range_vars[key]=v
            page.ttk.Entry(row,textvariable=v,width=9).pack(side='left')
        button(page,row,'Prepare selected take range',self.prepare)
        page.ttk.Label(self.take_box,text='Up to 10 seconds and 121 samples; larger meshes need shorter ranges or lower rates. Preparation rechecks the imported file and selected texture hashes. Stop cancels the task. Between samples, FBX holds the preceding pose.',wraplength=1000).pack(anchor='w')
        row=line(page,self.box);page.ttk.Label(row,text='Position (seconds)').pack(side='left')
        self.position=page.tk.StringVar(value='0');page.ttk.Entry(row,textvariable=self.position,width=12).pack(side='left')
        self.slider_value=page.tk.StringVar(value='0')
        self.slider=page.ttk.Scale(row,from_=0,to=1,variable=self.slider_value,command=lambda v:self.position.set(f'{float(v):.6f}'),takefocus=True)
        self.slider.pack(side='left',fill='x',expand=True);button(page,row,'Seek to position',self.seek)
        row=line(page,self.box)
        button(page,row,'Previous sample',lambda:self.step(-1));button(page,row,'Next sample',lambda:self.step(1))
        button(page,row,'Play',self.play);button(page,row,'Pause',self.pause);button(page,row,'Reset imported pose',self.reset)
        self.loop=page.tk.BooleanVar(value=False);page.ttk.Checkbutton(row,text='Loop',variable=self.loop).pack(side='left')
        page.ttk.Label(row,text='Speed').pack(side='left');self.speed=page.tk.StringVar(value='1')
        choice(page,row,self.speed,('0.25','0.5','1','2','4'),width=6)
        row=line(page,self.box);page.ttk.Label(row,text='Translation anchor').pack(side='left')
        self.anchor=page.tk.StringVar(value='Follow stored motion');self.anchor_choices={'Follow stored motion':-1}
        self.anchor_picker=choice(page,row,self.anchor,tuple(self.anchor_choices),self.seek,width=48)
        page.ttk.Label(self.box,text='An anchor holds that node’s translation at the clip-start position by shifting the whole scene. Rotation still plays; this is not humanoid root-motion extraction. Framing stays fixed while playing. GLB sample buttons step 1/30 second.',wraplength=1000).pack(anchor='w')
        self.state=page.tk.StringVar(value='No animation selected.');page.ttk.Label(self.box,textvariable=self.state,wraplength=1000).pack(anchor='w',pady=4)
        self.diagnostics=page.tk.StringVar(value='');page.ttk.Label(self.box,textvariable=self.diagnostics,wraplength=1000,justify='left').pack(anchor='w')
        button(page,line(page,self.box),'Close animation timeline',self.hide)
        self.clip_choices={};self.take_choices={}

    def show(self):
        self.controls.require();scene=self.controls.scene
        if self.original is not scene:
            self.clear();self.original=self.source=scene;self.catalog()
            self.anchor_choices={'Follow stored motion':-1}|{f'{n.index}: {n.name}':n.index for n in scene.nodes}
            self.anchor_picker.configure(values=tuple(self.anchor_choices));self.anchor.set('Follow stored motion')
            takes=scene.import_report.takes if scene.import_report else ()
            self.take_choices={f'{i+1}: {t[0]}':i for i,t in enumerate(takes)}
            self.take_picker.configure(values=tuple(self.take_choices));self.take_value.set(next(iter(self.take_choices),''))
            if takes:self.select_take();self.take_box.pack(fill='x',pady=5)
            else:self.take_box.pack_forget()
        self.visible=True;self.box.pack(fill='both',expand=True,pady=8)

    def catalog(self):
        clips=self.source.animations.clips if self.source and self.source.animations else ()
        self.clip_choices={f'{i+1}: {c.name}'+(' (unavailable)' if c.reason else ''):i for i,c in enumerate(clips)}
        self.clip_picker.configure(values=tuple(self.clip_choices));self.clip_value.set(next(iter(self.clip_choices),''));self.select_clip()

    def select_clip(self):
        self.pause();self.index=self.clip_choices.get(self.clip_value.get());self.clock=Clock();self.shown_at=None
        if self.index is None:
            self.state.set('No playable clip loaded. Prepare a listed FBX take, or import a GLB with animation clips.')
            self.diagnostics.set('Unity controllers, retargeting and object-reference curves are unavailable. No controller logic is simulated.');return
        clip=self.source.animations.clips[self.index];self.clock=Clock(clip.start,clip.end)
        self.slider.configure(from_=clip.start,to=clip.end);self.set_position(clip.start)
        self.state.set('Clip unavailable.' if clip.reason else 'Ready. Play or seek explicitly; the current pose has not changed.')
        self.diagnostics.set(describe(clip))

    def select_take(self):
        self.controls.require();index=self.take_choices.get(self.take_value.get())
        if index is None:return
        _,start,end,_=self.original.import_report.takes[index]
        self.range_vars['start'].set(f'{start:.9g}');self.range_vars['end'].set(f'{min(end,start+10):.9g}')

    def prepare(self):
        self.panel.require();self.controls.require();self.pause()
        if self.original is not self.controls.scene:raise ValueError('Reopen the timeline for the current scene.')
        take=self.take_choices.get(self.take_value.get())
        if take is None:raise ValueError('Select an FBX take first.')
        from avatar_animation_fbx import request
        try:opts=request(dict(take=take,start=float(self.range_vars['start'].get()),end=float(self.range_vars['end'].get()),rate=int(self.range_vars['rate'].get())))
        except (ValueError,OverflowError):raise ValueError('Enter a finite range up to 10 seconds and an integer sample rate from 1 to 12.') from None
        from avatar_scene_provider import load_fbx_take
        scene=self.original;context=self.panel.context();self.revision+=1;revision=self.revision
        source=self.panel.source;textures=self.panel.fbx_textures;self.preparing=True;self.state.set('Preparing selected take range…')
        def done(result):
            if self.panel.closed or revision!=self.revision or scene is not self.controls.scene or context!=self.panel.context():return
            self.preparing=False;self.source=result;self.catalog();self.state.set('Take prepared. Play or seek explicitly.')
        try:self.page.start_task(lambda stop,progress:load_fbx_take(source,scene,authorized=True,textures=textures,stop=stop,progress=progress,**opts),done,operation='FBX take preparation')
        except Exception:self.preparing=False;raise

    def require_clip(self):
        self.controls.require()
        if self.page.job:raise ValueError('Wait for the current task to finish or stop.')
        if self.original is not self.controls.scene or self.source is None or self.index is None:raise ValueError('Select or prepare a playable clip first.')
        clip=self.source.animations.clips[self.index]
        if clip.reason:raise ValueError(clip.reason)
        return clip

    def set_position(self,at):
        self.slider_value.set(str(at));self.position.set(f'{at:.6f}')

    def seek(self):
        self.require_clip()
        try:at=float(self.position.get())
        except ValueError:raise ValueError('Enter a position in seconds.') from None
        self.pause();self.clock.seek(at);self.set_position(self.clock.position);self.request_frame();self.schedule()

    def step(self,direction):
        clip=self.require_clip();at=self.clock.position
        if clip.frames:
            values=[f.time for f in clip.frames if (f.time>at+1e-8 if direction>0 else f.time<at-1e-8)]
            at=(values[0] if direction>0 else values[-1]) if values else (clip.end if direction>0 else clip.start)
        else:at+=direction/30
        self.position.set(str(at));self.seek()

    def play(self):
        clip=self.require_clip();self.pause()
        if self.clock.position>=clip.end:self.clock.seek(clip.start)
        self.clock.playing=True;self.clock.last=time.monotonic();self.request_frame();self.schedule()

    def pause(self):
        self.clock.playing=False;self.clock.last=None;self.revision+=1;self.pending=None;self.finishing=False
        if self.shown_at is not None:self.clock.seek(self.shown_at);self.set_position(self.clock.position)
        if self.worker:self.worker.cancel()
        if self.timer is not None:
            try:self.panel.canvas.after_cancel(self.timer)
            except self.page.tk.TclError:pass
            self.timer=None
        if self.preparing:
            if self.page.job:self.page.cancel()
            self.preparing=False
        self.state.set('Paused. The last displayed pose is retained.')

    def reset(self):
        self.controls.require();self.pause();c=self.controls;c.pose_revision+=1
        if c.deform_pending and self.page.job:self.page.cancel()
        c.deform_pending=False;c.display_scene=c.scene;c.morph_overrides={};c.joint_overrides={};c.rebuild()
        self.shown_at=None;self.clock.seek(self.clock.start);self.set_position(self.clock.position);self.state.set('Imported pose restored.')
        if c.rig_inspection:c.rig_inspection.refresh_pose()

    def request_frame(self):
        self.require_clip();c=self.controls
        from avatar_scene_render import Renderer
        if self.worker is None:self.worker=Renderer(work=sample_view)
        anchor=self.anchor_choices.get(self.anchor.get())
        if anchor is None:raise ValueError('Choose a translation anchor from this scene.')
        self.revision+=1;token=self.revision;c.pose_revision+=1
        self.pending=(token,self.original,self.panel.context(),self.clock.position)
        self.worker.submit(token,(self.source,self.index,self.clock.position,tuple(c.hidden),c.focus,(c.center,c.radius)),dict(anchor=anchor))
        if self.clock.position==self.clock.end:self.finishing=False
        self.last_request=time.monotonic()

    def schedule(self):
        if self.timer is None:self.timer=self.panel.canvas.after(50,lambda:self.page.guard(self.tick))

    def tick(self):
        self.timer=None
        if self.panel.closed or not self.panel.usable() or self.original is not self.controls.scene:self.clear();return
        if self.page.job:self.pause();return
        now=time.monotonic();self.clock.loop=bool(self.loop.get())
        if self.speed.get() not in ('0.25','0.5','1','2','4'):self.pause();raise ValueError('Choose a listed playback speed.')
        self.clock.speed=float(self.speed.get());was_playing=self.clock.playing
        if was_playing:self.clock.update(now)
        if was_playing and not self.clock.playing:self.finishing=True
        if self.pending:
            token,original,context,at=self.pending;result=self.worker.take(token)
            if result is not None:
                self.pending=None;value,error=result
                if token!=self.revision or original is not self.controls.scene or context!=self.panel.context():self.clear();return
                if error:self.pause();self.state.set('Playback paused: '+error);return
                posed,(batches,center,radius)=value;c=self.controls;c.display_scene=posed;c.morph_overrides={};c.joint_overrides={}
                c.batches=tuple((n,m) for n,m in batches if c.material_focus is None or m.material==c.material_focus);c.center=center;c.radius=radius
                c.update_detail();self.panel.schedule_render();self.set_position(at);self.shown_at=at
                if at==self.clock.end:self.finishing=False
                self.state.set(f'{"Playing" if self.clock.playing else "Paused"} at {at:.3f} seconds. Mesh-health diagnostics describe imported geometry.')
        # Complete the terminal sample even if the clock just stopped. Never
        # cancel a slow renderer to enqueue another playback frame.
        if not self.pending and (self.clock.playing or self.finishing) and self.panel.render_after is None and now-self.last_request>=.1:self.request_frame()
        if self.pending or self.clock.playing or self.finishing:self.schedule()

    def hide(self):
        self.pause();self.visible=False;self.box.pack_forget()

    def clear(self):
        self.hide();self.original=self.source=None;self.index=None;self.clip_choices={};self.take_choices={};self.anchor_choices={'Follow stored motion':-1}
        self.clip_picker.configure(values=());self.take_picker.configure(values=());self.anchor_picker.configure(values=tuple(self.anchor_choices))
        self.clip_value.set('');self.take_value.set('');self.diagnostics.set('');self.clock=Clock();self.shown_at=None;self.set_position(0.)
        self.state.set('No animation retained.')

    def close(self):
        self.clear()
        if self.worker:self.worker.close();self.worker=None
