"""Reviewed operation registry, not an arbitrary authenticated HTTP proxy.

Reference review: 2026-10-02, community-maintained VRChat API reference.
Local validation limits are VRC Eye limits, not promises about service quotas.
No account-security, billing, credential-export, content-filter, upload, or
arbitrary-host operations are exposed here. Response fields are not write fields.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import re
from urllib.parse import quote, urlencode

from developer_core import bounded_json, canonical

CATALOG_REVISION = 'eye-api-2026-10-02.1'
REFERENCE_DATE = '2026-10-02'
UUID = r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}'
SAMPLES = {'userId': 'usr_00000000-0000-0000-0000-000000000001',
           'worldId': 'wrld_00000000-0000-0000-0000-000000000002',
           'avatarId': 'avtr_00000000-0000-0000-0000-000000000003',
           'groupId': 'grp_00000000-0000-0000-0000-000000000004',
           'targetUserId': 'usr_00000000-0000-0000-0000-000000000005',
           'roleId': 'grol_00000000-0000-0000-0000-000000000006',
           'favoriteId': 'fvrt_00000000-0000-0000-0000-000000000007',
           'notificationId': 'not_00000000-0000-0000-0000-000000000008',
           'instanceId': '12345'}


@dataclass(frozen=True)
class Field:
    kind: str = 'string'
    required: bool = False
    minimum: int = 0
    maximum: int = 512
    choices: tuple = ()
    example: object = ''
    pattern: str = ''

    def validate(self, value, name):
        if self.kind == 'integer':
            valid = type(value) is int and self.minimum <= value <= self.maximum
        elif self.kind == 'boolean':
            valid = type(value) is bool
        elif self.kind == 'strings':
            valid = (isinstance(value, list) and self.minimum <= len(value) <= self.maximum
                     and all(isinstance(v, str) and 0 < len(v) <= 128 and not any(ord(c) < 32 for c in v) for v in value))
            if valid and self.pattern:
                valid = all(re.fullmatch(self.pattern, v) is not None for v in value)
        else:
            valid = (isinstance(value, str) and self.minimum <= len(value) <= self.maximum
                     and not any(ord(c) < 32 and c not in ('\n', '\t') for c in value))
            if valid and self.pattern:
                valid = re.fullmatch(self.pattern, value) is not None
        if not valid or self.choices and value not in self.choices:
            raise ValueError(f'{name}: use {self.kind} within {self.minimum}–{self.maximum}' +
                             (f'; choices: {", ".join(map(str, self.choices))}' if self.choices else '') + '.')
        return value


def text(maximum=512, *, required=False, example='', minimum=0, pattern=''):
    return Field('string', required, minimum, maximum, (), example, pattern)


def ident(prefix, name, *, required=True):
    return text(64, required=required, minimum=40, pattern=prefix + '_' + UUID,
                example=SAMPLES.get(name, prefix + '_00000000-0000-0000-0000-000000000009'))


def enum(*values, required=False, example=None):
    return Field('string', required, 0, 512, values, values[0] if example is None else example)


def number(low, high, example, required=False):
    return Field('integer', required, low, high, (), example)


def boolean(example=False):
    return Field('boolean', False, 0, 1, (), example)


U, W, A, G = ident('usr', 'userId'), ident('wrld', 'worldId'), ident('avtr', 'avatarId'), ident('grp', 'groupId')
N = Field('string', True, 40, 64, (), SAMPLES['notificationId'], '(?:not|frq)_' + UUID)
F = ident('fvrt', 'favoriteId')
INSTANCE = text(512, required=True, minimum=1, pattern=r'[A-Za-z0-9_~().-]+', example='12345')
PAGE = {'n': number(1, 100, 20), 'offset': number(0, 1000000, 0)}
ORDER = {'sort': enum('name', 'updated', 'created', 'popularity', 'relevance'), 'order': enum('ascending', 'descending')}
MODERATION = enum('mute', 'block', 'hideAvatar', 'showAvatar', required=True)


@dataclass(frozen=True)
class Operation:
    key: str
    title: str
    family: str
    method: str
    route: str
    path_fields: dict = field(default_factory=dict)
    query_fields: dict = field(default_factory=dict)
    body_fields: dict = field(default_factory=dict)
    response: str = 'object'
    pagination: str = ''
    scope: str = 'Accessible records; server authorization applies'
    risk: str = 'read'
    preflight: str = ''
    verify: str = ''
    source_slug: str = ''
    notes: str = ''
    example_body: dict = field(default_factory=dict)
    live: bool = True
    empty_response: bool = False

    @property
    def write(self):
        return self.risk != 'read'

    @property
    def source(self):
        return 'https://vrchat.community/reference/' + (self.source_slug or self.key.replace('.', '-'))

    def example(self):
        query = {k: v.example for k, v in self.query_fields.items() if v.required}
        if self.pagination:
            query.update(n=20, offset=0)
        body = {k: v.example for k, v in self.body_fields.items() if v.required}
        body.update(self.example_body)
        paths = {k: v.example for k, v in self.path_fields.items()}
        if self.key.startswith('friends.') and 'userId' in paths:
            paths['userId'] = SAMPLES['targetUserId']
        if self.key == 'instance.create': body['ownerId'] = SAMPLES['userId']
        return {'operation': self.key, 'path': paths, 'query': query, 'body': body}

    def describe(self):
        def fields(items):
            return {k: {'type': v.kind, 'required': v.required, 'minimum': v.minimum, 'maximum': v.maximum,
                        'choices': list(v.choices), 'pattern': v.pattern} for k, v in items.items()}
        return {'operation': self.key, 'title': self.title, 'family': self.family, 'method': self.method,
                'route': self.route, 'scope': self.scope, 'risk': self.risk,
                'path': fields(self.path_fields), 'query': fields(self.query_fields), 'body': fields(self.body_fields),
                'response': self.response, 'pagination': self.pagination, 'preflight': self.preflight, 'verify': self.verify,
                'reference': self.source, 'reference_reviewed': REFERENCE_DATE, 'live_tested': False,
                'status': 'Implemented adapter; live unverified' if self.live else 'Reference only', 'notes': self.notes}


def _registry():
    ops = []
    def read(key, title, family, route, path=None, query=None, *, response='object', pagination='', scope='', slug='', notes=''):
        ops.append(Operation(key, title, family, 'GET', route, path or {}, query or {}, response=response,
                             pagination=pagination, scope=scope or 'Accessible records; server authorization applies',
                             source_slug=slug, notes=notes))
    def write(key, title, family, method, route, path=None, body=None, *, scope='Signed-in account', risk='account change',
              preflight='', verify='', slug='', example=None, notes='', empty=False):
        ops.append(Operation(key, title, family, method, route, path or {}, {}, body or {}, scope=scope,
                             risk=risk, preflight=preflight, verify=verify, source_slug=slug,
                             example_body=example or {}, notes=notes, empty_response=empty))

    read('account.get', 'Connected account', 'Account', 'auth/user', scope='Own account only', slug='get-current-user',
         notes='Uses the existing session only. It cannot submit Basic credentials or create a new login.')
    read('user.get', 'User record', 'Account', 'users/{userId}', {'userId': U}, slug='get-user')
    read('user.profile', 'Public profile', 'Account', 'profile/{userId}', {'userId': U},
         {'withGroupsAndWorlds': boolean(True)}, slug='get-public-profile')
    read('user.groups', 'Visible user groups', 'Account', 'users/{userId}/groups', {'userId': U}, response='array', slug='get-user-groups')
    read('user.group-invites', 'Own group invitations', 'Account', 'users/{userId}/groups/invited', {'userId': U},
         response='array', scope='Own account only', slug='get-user-group-invited')
    write('account.update', 'Edit own profile', 'Account', 'PUT', 'users/{userId}', {'userId': U},
          {'bio': text(512), 'statusDescription': text(32), 'status': enum('active', 'join me', 'ask me', 'busy')},
          scope='Own account only', preflight='account.get', verify='account.get', slug='update-user',
          example={'statusDescription': 'Testing VRC Eye'}, notes='Profile text/status only; no security, age, entitlement or filtering settings.')

    read('world.get', 'World record and packages', 'Worlds', 'worlds/{worldId}', {'worldId': W}, slug='get-world')
    read('world.metadata', 'World custom metadata', 'Worlds', 'worlds/{worldId}/metadata', {'worldId': W}, slug='get-world-metadata')
    read('world.publication', 'World publication eligibility', 'Worlds', 'worlds/{worldId}/publish', {'worldId': W},
         slug='get-world-publish-status', notes='canPublish is eligibility, not evidence that a world is currently public.')
    read('world.search', 'Search accessible worlds', 'Worlds', 'worlds', query={**PAGE, **ORDER,
         'search': text(), 'user': enum('me'), 'releaseStatus': enum('public', 'private', 'all')},
         response='array', pagination='offset', slug='search-worlds')
    for key, title, path, slug in (('active', 'Active worlds', 'active', 'get-active-worlds'),
                                 ('recent', 'Recently visited worlds', 'recent', 'get-recent-worlds'),
                                 ('favorites', 'Favorited worlds', 'favorites', 'get-favorited-worlds')):
        read('world.' + key, title, 'Worlds', 'worlds/' + path, query=dict(PAGE), response='array', pagination='offset', slug=slug)
    write('world.update', 'Edit owned world metadata', 'Worlds', 'PUT', 'worlds/{worldId}', {'worldId': W},
          {'name': text(64, minimum=1), 'description': text(1024), 'capacity': number(1, 80, 16),
           'recommendedCapacity': number(1, 80, 8)}, scope='Owned world only', risk='resource change',
          preflight='world.get', verify='world.get', slug='update-world', example={'description': 'VRC Eye creator playtest.'},
          notes='No build upload. Capacity limits here are local validation bounds; the server may reject a value.')
    write('world.publish', 'Request owned-world publication', 'Worlds', 'PUT', 'worlds/{worldId}/publish', {'worldId': W},
          scope='Owned world only', risk='publication change', preflight='world.get', verify='world.get', slug='publish-world',
          notes='Separate from saving metadata. Service eligibility and publication rules remain authoritative.', empty=True)
    write('world.unpublish', 'Unpublish owned world', 'Worlds', 'DELETE', 'worlds/{worldId}/publish', {'worldId': W},
          scope='Owned world only', risk='publication change', preflight='world.get', verify='world.get', slug='unpublish-world', empty=True)

    read('avatar.get', 'Avatar metadata', 'Avatars', 'avatars/{avatarId}', {'avatarId': A}, slug='get-avatar')
    read('avatar.list', 'Own or featured avatars', 'Avatars', 'avatars', query={**PAGE, 'user': enum('me'),
         'featured': boolean(True), 'releaseStatus': enum('public', 'private', 'all')}, response='array', pagination='offset',
         slug='search-avatars', notes='No global search of other users’ private avatar libraries.')
    read('avatar.favorites', 'Favorite avatars', 'Avatars', 'avatars/favorites', query=dict(PAGE), response='array', pagination='offset', slug='get-favorited-avatars')
    write('avatar.update', 'Edit owned avatar metadata', 'Avatars', 'PUT', 'avatars/{avatarId}', {'avatarId': A},
          {'name': text(64, minimum=1), 'description': text(1024)}, scope='Owned avatar only', risk='resource change',
          preflight='avatar.get', verify='avatar.get', slug='update-avatar', example={'description': 'VRC Eye avatar playtest.'})
    write('avatar.select', 'Select an accessible avatar', 'Avatars', 'PUT', 'avatars/{avatarId}/select', {'avatarId': A},
          preflight='avatar.get', verify='account.get', slug='select-avatar',
          notes='HTTP acknowledgement and service selection do not confirm client loading or avatar readiness.')

    read('instance.get', 'Inspect an explicit instance', 'Instances', 'instances/{worldId}:{instanceId}',
         {'worldId': W, 'instanceId': INSTANCE}, slug='get-instance', notes='Only a supplied instance reference. No hidden-location discovery.')
    write('instance.create', 'Create a personal test instance', 'Instances', 'POST', 'instances', body={
          'worldId': W, 'type': enum('private', 'friends', 'hidden', 'public', required=True, example='private'),
          'region': enum('us', 'use', 'eu', 'jp', required=True), 'ownerId': ident('usr', 'userId', required=False)},
          risk='instance creation', preflight='world.get', slug='create-instance',
          notes='Personal instances only in this adapter. Creation is not a join request or proof of arrival.')

    read('friends.list', 'Friends, one page at a time', 'Social', 'auth/user/friends', query={**PAGE, 'offline': boolean(False)},
         response='array', pagination='offset', scope='Own account only', slug='get-friends')
    read('friends.status', 'Friend relationship', 'Social', 'user/{userId}/friendStatus', {'userId': U}, slug='get-friend-status')
    write('friends.request', 'Send one friend request', 'Social', 'POST', 'user/{userId}/friendRequest', {'userId': U},
          risk='contact another person', verify='friends.status', slug='friend')
    write('friends.cancel-request', 'Cancel an outgoing friend request', 'Social', 'DELETE', 'user/{userId}/friendRequest', {'userId': U},
          verify='friends.status', slug='delete-friend-request')
    write('friends.remove', 'Remove one friendship', 'Social', 'DELETE', 'auth/user/friends/{userId}', {'userId': U},
          risk='relationship removal', verify='friends.status', slug='unfriend')
    read('notifications.list', 'Own notifications', 'Social', 'auth/user/notifications', query={**PAGE, 'hidden': boolean(False)},
         response='array', pagination='offset', scope='Own account only', slug='get-notifications')
    read('notifications.get', 'Own notification record', 'Social', 'auth/user/notifications/{notificationId}', {'notificationId': N},
         scope='Own account only', slug='get-notification')
    for key, title, suffix, slug in (('read', 'Mark a notification as read', 'see', 'mark-notification-as-read'),
                                   ('hide', 'Hide a notification', 'hide', 'delete-notification'),
                                   ('accept', 'Accept a friend request', 'accept', 'accept-friend-request')):
        write('notifications.' + key, title, 'Social', 'PUT', 'auth/user/notifications/{notificationId}/' + suffix,
              {'notificationId': N}, preflight='notifications.get', slug=slug)

    read('favorites.limits', 'Own favorite limits', 'Favorites', 'auth/user/favoritelimits', scope='Own account only', slug='get-favorite-limits')
    read('favorites.groups', 'Own favorite collections', 'Favorites', 'favorite/groups', query={**PAGE, 'ownerId': ident('usr', 'userId', required=False)},
         response='array', pagination='offset', scope='Own account only', slug='get-favorite-groups')
    read('favorites.list', 'Favorite entries', 'Favorites', 'favorites', query={**PAGE,
         'type': enum('friend', 'avatar', 'world'), 'tag': text(100, pattern=r'[A-Za-z0-9_-]*')},
         response='array', pagination='offset', scope='Own account only', slug='get-favorites')
    write('favorites.add', 'Add one favorite', 'Favorites', 'POST', 'favorites', body={
          'type': enum('friend', 'avatar', 'world', required=True, example='world'),
          'favoriteId': text(64, required=True, pattern='(?:usr|wrld|avtr)_' + UUID, example=SAMPLES['worldId']),
          'tags': Field('strings', True, 1, 1, (), ['worlds1'], r'[A-Za-z0-9_-]{1,100}')},
          slug='add-favorite', notes='Local bookmarks are separate; the service enforces favorite limits.')
    write('favorites.remove', 'Remove one favorite entry', 'Favorites', 'DELETE', 'favorites/{favoriteId}', {'favoriteId': F},
          risk='collection removal', slug='remove-favorite')

    read('group.get', 'Group record and own membership', 'Groups', 'groups/{groupId}', {'groupId': G}, slug='get-group')
    read('group.search', 'Search visible groups', 'Groups', 'groups', query={**PAGE, 'query': text(required=True, minimum=1, example='VRC Eye')},
         response='array', pagination='offset', slug='search-groups')
    for key, title, suffix, slug, page in (
        ('roles', 'Group role definitions', 'roles', 'get-group-roles', False),
        ('permissions', 'Possible group permissions (not grants)', 'permissions', 'get-group-permissions', False),
        ('members', 'Other group members', 'members', 'get-group-members', True),
        ('bans', 'Authorized group ban list', 'bans', 'get-group-bans', True),
        ('instances', 'Accessible group instances', 'instances', 'get-group-instances', False),
        ('invites', 'Authorized group invitations', 'invites', 'get-group-invites', True),
        ('requests', 'Authorized group join requests', 'requests', 'get-group-requests', True)):
        read('group.' + key, title, 'Groups', 'groups/{groupId}/' + suffix, {'groupId': G},
             dict(PAGE) if page else {}, response='array', pagination='offset' if page else '', slug=slug,
             notes='Permission definitions do not establish effective authority. Group member pages exclude the caller.' if key in ('permissions', 'members') else '')
    read('group.member', 'Group member record', 'Groups', 'groups/{groupId}/members/{userId}', {'groupId': G, 'userId': U}, slug='get-group-member')
    read('group.audit', 'Group audit log with continuation', 'Groups', 'groups/{groupId}/auditLogs', {'groupId': G},
         {**PAGE, 'startDate': text(64), 'endDate': text(64), 'actorIds': text(), 'targetIds': text(), 'eventTypes': text()},
         pagination='results', slug='get-group-audit-logs', notes='Uses results plus hasNext. A configured inspection limit is never labelled complete.')
    read('group.announcement', 'Group announcement', 'Groups', 'groups/{groupId}/announcement', {'groupId': G}, slug='get-group-announcement')
    write('group.update', 'Edit an owned group’s description', 'Groups', 'PUT', 'groups/{groupId}', {'groupId': G},
          {'description': text(2048)}, scope='Group owner only in this adapter', risk='resource change',
          preflight='group.get', verify='group.get', slug='update-group', example={'description': 'VRC Eye creator playtest group.'},
          notes='Role-based management expansion is not inferred from the permission-definition list.')

    read('moderation.list', 'Own personal moderation preferences', 'Moderation', 'auth/user/playermoderations',
         query={'type': enum('mute', 'block', 'hideAvatar', 'showAvatar')}, response='array', scope='Own account only', slug='get-player-moderations')
    write('moderation.apply', 'Apply one personal moderation preference', 'Moderation', 'POST', 'auth/user/playermoderations',
          body={'moderated': ident('usr', 'targetUserId'), 'type': MODERATION}, slug='moderate-user',
          notes='Account preference only. Immediate in-client protection is not confirmed by HTTP success.')
    write('moderation.reset', 'Reset one personal moderation preference', 'Moderation', 'PUT', 'auth/user/unplayermoderate',
          body={'moderated': ident('usr', 'targetUserId'), 'type': MODERATION}, slug='unmoderate-user',
          notes='Reset is distinct from setting the opposite explicit preference.')
    read('service.config', 'Service configuration snapshot', 'Service', 'config', slug='get-config',
         notes='Observation only; no local edit changes a server feature or entitlement.')

    # Registration metadata is visible without providing an unsafe generic live executor.
    for key, title, route, method, family, slug in (
        ('reference.group-role', 'Group role assignment (roadmap)', 'groups/{groupId}/members/{userId}/roles/{roleId}', 'PUT', 'Groups', 'add-group-member-role'),
        ('reference.invite', 'Send an instance invitation (roadmap)', 'invite/{userId}', 'POST', 'Social', 'invite-user'),
        ('reference.world-tags', 'Creator tag editing (roadmap)', 'worlds/{worldId}/tags', 'POST', 'Worlds', 'add-world-tags')):
        ops.append(Operation(key, title, family, method, route, risk='reference only', source_slug=slug, live=False,
                             notes='Not executable. Kept visible so documentation coverage is not confused with implemented support.'))
    return tuple(ops)


OPERATIONS = _registry()
BY_KEY = {o.key: o for o in OPERATIONS}
FAMILIES = tuple(dict.fromkeys(o.family for o in OPERATIONS))


def validate_request(value):
    """Return a normalized data-only request. Unknown fields fail closed."""
    if isinstance(value, (str, bytes)):
        value = bounded_json(value)
    else:
        value = bounded_json(canonical(value))
    if not isinstance(value, dict) or set(value) - {'operation', 'path', 'query', 'body'}:
        raise ValueError('Use only operation, path, query and body. URLs, headers and scripts are not accepted.')
    op = BY_KEY.get(value.get('operation'))
    if op is None:
        raise ValueError('Choose an operation from the reviewed catalog.')
    if not op.live:
        raise ValueError('This catalog entry is reference only; it has no executor.')
    result = {'operation': op.key}
    for part, fields in (('path', op.path_fields), ('query', op.query_fields), ('body', op.body_fields)):
        data = value.get(part, {})
        if not isinstance(data, dict) or set(data) - set(fields):
            raise ValueError(f'{part}: contains an unreviewed property. Consult the selected operation schema.')
        for name, descriptor in fields.items():
            if descriptor.required and name not in data:
                raise ValueError(f'{part}.{name} is required.')
        result[part] = {name: fields[name].validate(v, part + '.' + name) for name, v in data.items()}
    if op.key in ('account.update', 'world.update', 'avatar.update', 'group.update') and not result['body']:
        raise ValueError('Supply at least one reviewed field to change.')
    if op.key == 'avatar.list' and result['query'].get('user') != 'me' and result['query'].get('featured') is not True:
        # Make the scope explicit, not an invented global avatar search.
        result['query']['user'] = 'me'
    if op.key == 'favorites.add':
        prefix = {'friend': 'usr_', 'avatar': 'avtr_', 'world': 'wrld_'}[result['body']['type']]
        if not result['body']['favoriteId'].startswith(prefix):
            raise ValueError('Favorite type and target resource ID do not match.')
    body = result['body']
    if 'capacity' in body and 'recommendedCapacity' in body and body['recommendedCapacity'] > body['capacity']:
        raise ValueError('Recommended capacity cannot exceed capacity in this draft.')
    return op, result


def request_path(op, request):
    route = op.route.format(**{k: quote(v, safe='') for k, v in request['path'].items()})
    query = {k: str(v).lower() if type(v) is bool else v for k, v in request['query'].items()}
    return route + ('?' + urlencode(query) if query else '')


def fingerprint(request):
    import hashlib
    return hashlib.sha256(canonical(request).encode('utf-8')).hexdigest()
