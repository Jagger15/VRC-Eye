"""Rule review/revocation and batch undo beside the existing file-match tools."""
from pathlib import Path
from companion_ui import Table,button,line
import avatar_association_rules as rules


class Controls:
    def __init__(self,owner,parent):
        self.owner=owner;self.page=page=owner.page
        row=line(page,parent)
        button(page,row,'Enable exact-match rule…',self.enable)
        button(page,row,'Preview enabled rules…',self.preview)
        button(page,row,'Rules & batch undo',self.show)
        self.box=page.ttk.Frame(parent)
        page.ttk.Label(self.box,text='Rules run only when Find exact matches is pressed for their reviewed folder. Up to 64 rules per workspace. Undo retains the newest 100 receipts within 8 MiB.',wraplength=940).pack(anchor='w')
        self.table=Table(page,self.box,(('state','State',90),('folder','Folder',230),('avatar','Avatar / build',420)),height=4)
        row=line(page,self.box)
        button(page,row,'Revoke selected rule',self.revoke)
        button(page,row,'Remove selected rule',lambda:self.revoke(remove=True))
        button(page,row,'Revoke all workspace rules…',self.revoke_all)
        self.history=Table(page,self.box,(('time','Created',180),('count','References',110),('undone','Undone',100)),height=4)
        row=line(page,self.box)
        button(page,row,'Review batch undo…',self.undo)
        button(page,row,'Close rules',self.clear)

    def guard(self):
        owner=self.owner;owner.require();token=self.page.context();generation=owner.generation;account=self.page.scope
        def check():
            self.page.writable();self.page.check_context(token)
            from avatar_catalog_tools_ui import hidden
            if hidden(self.page) or self.page.scope!=account or generation!=owner.generation:raise ValueError('The file workspace changed. Review again.')
        return check

    def enable(self):
        check=self.guard();owner=self.owner;item=owner.table.selected();anchor=owner.matches.get(owner.match.get())
        if not item or not anchor or not owner.source or not item.get('evidence'):raise ValueError('Select an inspected file and one recorded exact-byte association.')
        if anchor not in item['matches'] or (anchor['sha256'],anchor['size'])!=(item['evidence']['sha256'],item['evidence']['size']):raise ValueError('Choose a current exact-byte association.')
        folder=owner.source.path if self.page.show_paths.get() else Path(owner.source.path).name
        message=(f"Folder: {folder}\nTarget: {anchor['avatar_id']}\nBuild: {anchor.get('build_id') or 'Avatar only'}\nRole: {anchor['role']}\nSHA-256: {anchor['sha256']}\nBytes: {anchor['size']}\n\n"
                 'On later Find exact matches scans of this same folder, create references for these exact bytes automatically. Existing references are preserved. No watcher starts and no files move. Conflicting rules or changed source associations require another review. The rule stays local to this workspace and can be revoked below.')
        if not self.page.review('Enable exact-byte association rule',message,'Enable for later scans'):return
        check();rules.enable(self.page.library,self.page.scope,owner.source,anchor,check=check)
        owner.status.set('Rule enabled. The next matching scan can add references automatically; each batch has conditional undo.');self.show()

    def preview(self):
        self.guard();owner=self.owner
        if owner.source is None or not owner.results or 'evidence' not in owner.results[0]:raise ValueError('Run Find exact matches first.')
        plan=rules.prepare(self.page.library,self.page.scope,owner.source,owner.results)
        self.page.review('Preview enabled association rules',rules.summary(plan),'Close preview')

    def apply_result(self,source,account,generation,token,items):
        def check():
            self.page.check_context(token)
            from avatar_catalog_tools_ui import hidden
            if hidden(self.page) or account!=self.page.scope or generation!=self.owner.generation or source is not self.owner.source:raise ValueError('Matching context changed; no rule batch was applied.')
        check();plan=rules.prepare(self.page.library,account,source,items)
        receipt=rules.apply(self.page.library,plan,check=check)
        message=(f" Rule batch saved {len(receipt['entries'])} references; use Rules & batch undo." if receipt else ' No new rule references.')
        if plan['skipped']:message+=f" {len(plan['skipped'])} rule conflicts/stale anchors need review."
        return message

    def show(self):
        self.guard();self.refresh();self.box.pack(fill='both',expand=True,pady=6)

    def refresh(self):
        library=self.page.library;account=self.page.scope
        self.table.set(rules.rows(library,account),lambda r:('Enabled' if r['enabled'] else 'Revoked',r['folder'] if self.page.show_paths.get() else Path(r['folder']).name,r['anchor']['avatar_id']+' / '+(r['anchor'].get('build_id') or 'avatar only')),identity=lambda r:r['id'])
        self.history.set(rules.rows(library,account,receipts=True),lambda r:(r['created'],len(r['entries']),len(r['undone'])),identity=lambda r:r['id'])

    def revoke(self,remove=False):
        check=self.guard();row=self.table.selected()
        if not row:raise ValueError('Select an association rule.')
        rules.revoke(self.page.library,self.page.scope,row['id'],check=check,remove=remove);self.refresh()
        self.owner.status.set('Rule removed.' if remove else 'Rule revoked. Existing references remain available for separate batch undo.')

    def revoke_all(self):
        check=self.guard()
        if not self.page.review('Revoke all workspace association rules','Disable every automatic association rule in this workspace, including other folders. Existing references remain; use batch undo to remove eligible references.','Revoke all rules'):return
        check();rules.revoke(self.page.library,self.page.scope,check=check);self.refresh()

    def undo(self):
        check=self.guard();row=self.history.selected()
        if not row:raise ValueError('Select a batch receipt.')
        plan=rules.prepare_undo(self.page.library,self.page.scope,row['id'])
        message=f"Remove {len(plan['eligible'])} unchanged catalog references. Preserve {len(plan['preserved'])} later-edited or already-removed references. Original files remain untouched.\n\nEnabled rules can recreate references on a later scan; revoke them first if you want this to stay undone."
        if not self.page.review('Review association batch undo',message,'Undo unchanged references'):return
        check();count=rules.undo(self.page.library,plan,check=check);self.refresh();self.page.refresh()
        self.owner.status.set(f'Undid {count} unchanged file references; original files remain.')

    def clear(self):
        self.table.set([],lambda r:());self.history.set([],lambda r:());self.box.pack_forget()
