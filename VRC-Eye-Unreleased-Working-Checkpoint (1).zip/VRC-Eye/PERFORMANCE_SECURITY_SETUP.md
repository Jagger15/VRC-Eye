# Performance & Security — VRC Eye 1.18.7

Open **Advanced → Performance & Security** in the left sidebar.

Resource Guard monitors local machine statistics, explains sustained pressure and
keeps a bounded diagnostic history. It is resource/stability protection, not an
antivirus, packet filter, avatar scanner, FPS booster or a guarantee against crashes.
The original 280-part proposal is preserved in PERFORMANCE_SECURITY_DESIGN_INPUT.md.

## Getting started

1. Close the previous VRC Eye version. Extract the new ZIP and run **Start.cmd**.
2. **Start.cmd** prepares the consolidated dependencies, including psutil, in
   `.recovery-env`. If setup cannot complete offline, available features still
   open; reopen **Start.cmd** online to retry. On Linux use Python 3.10+ with Tk
   and `python -m pip install -r requirements.txt` in your chosen environment,
   then `python vrc_eye.py`. **Safe-mode.cmd** skips dependency installation.
3. Resource monitoring and Balanced warnings are enabled by default. No login,
   VRCX connection, client bridge, driver changes or administrator access is needed.
4. History initially stays in memory. Enable **Record resource telemetry locally**
   only if you want disk recordings. Review the retention and delete controls.

The rest of VRC Eye remains usable without optional resource dependencies.
Demo suspends live collection and process actions and does not persist resource
preferences. The isolated warning test works without any sensors.

## Dashboard and views

Casual shows the key RAM, CPU, GPU, temperature and data-drive readings. Advanced
adds precise metric/source columns and Rules & settings / Diagnostics tabs.
Developer uses the same advanced panels, including live rule state, continuous
duration, thresholds, collection time and VRC Eye overhead metrics. No access key
is required. Scrollbars keep controls reachable at smaller window sizes.

**Monitor Only** retains dashboard state and history without warning banners.
**Balanced** adds consolidated warning banners across application pages.
**Protective** also lowers this page's graph refresh from 1 Hz to 0.2 Hz during
critical/emergency conditions. It does not change VRChat or suspend unrelated
VRC Eye subsystems. **Custom** uses your edited rules; changing a profile does not
silently replace those rules. No profile arms automatic game actions.

Snooze suppresses the current severity for ten minutes; a higher severity can
still warn. Recovery must be sustained before an active warning clears. CPU
saturation alone is an elevated informational condition; high GPU load alone has
no emergency rule. No player or world receives a danger score.

## What the numbers mean

All storage values use **GiB** (1 GiB = 1,073,741,824 bytes). Internal percentages
are fractions; ordinary rule-editor percentages use 0–100. JSON rules use 0–1.

| Measurement | Source and meaning |
| --- | --- |
| System RAM | psutil total/available; used is total minus available |
| VRChat resident RAM | Process RSS; Windows working set; not total committed memory |
| VRChat private committed memory | Windows psutil private bytes; unavailable on Linux in this release |
| Windows commit | GetPerformanceInfo pages × PageSize; not swap usage |
| System / process CPU | Nonblocking psutil counters; process percentage is normalized across logical cores |
| Device GPU memory/load/temp | NVIDIA installed nvidia-smi, or Linux AMDGPU read-only sysfs |
| VRChat-specific VRAM | Unavailable; device totals are never relabeled as process memory |
| CPU temperature | Hottest reading from recognized CPU thermal sensors when psutil supports them |
| Disk | Data/system/install drive; cache and screenshot directories can be chosen explicitly |
| VRC Eye overhead | Its own RSS, normalized CPU and core collection duration |

Process identity requires one unambiguous matching name, PID, creation time and
executable path. Missing/denied/ambiguous process information stays unknown.
A restart clears process readings and resets process-specific rule durations.
No game memory contents, credentials, chat text or voice samples are read.

NVIDIA device index chooses its reported GPU index. For the Linux AMD fallback it
chooses the index among discovered AMD cards. These are device-wide measurements,
not proof that the selected device is rendering VRChat. Windows AMD/Intel GPU
telemetry and generic per-process GPU attribution are not implemented here.
No GPU clocks, power limits or driver configuration are changed.

Core collection runs about once per second; GPU runs independently about every
three seconds with failure backoff; disk/CPU thermal run about every five seconds.
The NVIDIA command has a two-second timeout. Slow or failed auxiliary collectors
do not block core RAM/CPU collection. A core stall makes the dashboard unavailable
once its sample is five seconds old. There is no watchdog process to restart a
hung native core collector; stop/restart is refused while old workers remain alive.

## Rules

Default rules cover available RAM, Windows commit headroom, combined memory
pressure, device VRAM usage, sustained CPU saturation and the VRC Eye data drive.
Their editable defaults are policy starting points, not hardware danger limits.
Thermal rules require a user-entered threshold suitable for the hardware.

Each rule has a continuous duration, a separate recovery threshold and duration,
a notification cooldown, severity and enable switch. Single-condition rules have
a numeric editor. **Edit all rules…** exposes validated JSON and all/any composites.
Validation rejects NaN/infinity, zero durations, inverted hysteresis, duplicate
identifiers, unsupported fields and inconsistent severity thresholds on the same
metric. Settings changes reset affected evaluation state. A sampling gap or clock
rollback restarts continuous-duration evaluation rather than inventing elapsed data.

The built-in simulation feeds isolated synthetic pressure and recovery to a fresh
rule engine. It does not allocate large buffers, stop applications, write journals
or alter real monitoring state. Journal replay also runs with **zero actions**.

## Graphs, history and recordings

Graphs cover one minute, five/fifteen minutes, one hour or up to 24 hours. Recent
samples are retained for one minute, five-second min/max/mean buckets for fifteen
minutes and thirty-second buckets for 24 hours. Session peaks remain in memory.
Graphs retain spike ranges and break across missing intervals. The RAM trend is a
short-window observed slope, not a confirmed leak or a long-term baseline.

Fresh normalized world-entry, player-join and avatar-change event **types** can
appear beside memory spikes. Old reconstructed logs are excluded. Correlation
never establishes which player caused a resource change. This release does not
add GPU attribution to player rows or a full cross-subsystem event bus.

Recording is off by default. When enabled, the independent writer appends small
checksummed records, flushes each record and syncs about every five seconds plus
rotation/clean stop. Normal snapshots are written about every five seconds;
warning/critical snapshots about once per second. The queue is capped at 32 records;
dropped records are reported. Files rotate at roughly 1 MiB, with at most eight
retained files. Retention is 1, 7 or 30 days, additionally constrained by that size
cap; it does not promise that many days of history. Pruning runs at monitor startup
and journal rotation. Optional writes pause when the data-drive free-space reading
is missing/stale or below 512 MiB. It never deletes screenshots or game caches.

Files contain metric values, generic event types, rule labels and diagnostic times.
They omit process IDs/paths, GPU serials, machine names, player names, account IDs,
world/instance codes and raw game logs. Your custom rule titles are included in
resource events. There is no automatic upload. A startup check reports an absent
clean-stop marker without asserting a VRChat crash. Checksums recover intact lines
around a truncated/corrupt tail; they are not authenticity signatures.

**Export current session** writes a new JSON file containing bounded aggregate
history, peaks and events. It refuses an existing destination. **Inspect / replay
journal** reports sample, warning, recovery and damaged-line counts; it applies
current rules in an isolated engine. Replay does not automatically change profiles.
**Delete resource journals** stops recording and removes only resource journal files;
Player List, Wellness and other app history remain separate.

## Reviewed controls

**Review normal close…** identifies the exact process and asks for confirmation.
The review expires in thirty seconds. Submission checks sample freshness, process
identity, settings generation and the target again on the worker. Windows requests
WM_CLOSE; Linux requests SIGTERM. The UI reports a request, not guaranteed exit.
There is no retry or escalation. Cancel queued close works before submission;
an already-sent OS request cannot be recalled.

The Client bridge button opens the existing separately approved bridge controls.
Resource Guard itself does not issue automatic bridge actions or Safe Mode commands.

## Later stages retained in the proposal

Not implemented in 1.18.7: automatic Safe Mode, countdown auto-close, force
termination, Windows Job limits, Linux cgroup limits, CPU/priority modifications,
VR resource overlays, independent watchdogs, native responsiveness probing, OS crash
log correlation, automatic restart, cross-session/world baselines, update/driver
regression comparisons, process-group attribution and background-app cleanup.
The proposal explicitly places dangerous containment after stable monitoring.
The optional journal is a resource recorder, not the full application Black Box.

See VALIDATION.md for automated checks and target-system limitations.

## Primary implementation references reviewed

- https://psutil.readthedocs.io/stable/index.html
- https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-performance_information
- https://learn.microsoft.com/en-us/windows/win32/api/psapi/nf-psapi-getperformanceinfo
- https://docs.nvidia.com/deploy/nvidia-smi/index.html
- https://docs.kernel.org/gpu/amdgpu/driver-misc.html
