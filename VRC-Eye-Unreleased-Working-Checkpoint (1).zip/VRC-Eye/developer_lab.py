"""Offline-only fixtures and deterministic replay. No live API object is accepted."""
from __future__ import annotations
from copy import deepcopy
import random
import threading
from developer_catalog import BY_KEY, SAMPLES, validate_request
from developer_core import bounded_json, canonical, json_shape, redact, stamp
from vrchat_api import APIError

FAILURES = ('None', 'Reject 403', 'Rate limit 429', 'Service 503', 'Timeout before send',
            'Lose write response', 'Malformed response', 'Changed response schema')


class SandboxExecutor:
    """An in-memory service double. A fresh instance creates a fresh namespace."""
    def __init__(self):
        self.lock = threading.RLock()
        self.account = SAMPLES['userId']
        self.failure = 'None'
        self.calls = 0
        self.records = {
            'account': {'id': self.account, 'displayName': 'Synthetic developer', 'bio': 'Synthetic account',
                        'status': 'active', 'statusDescription': '', 'currentAvatar': SAMPLES['avatarId']},
            'world': {'id': SAMPLES['worldId'], 'authorId': self.account, 'name': 'Synthetic test world',
                      'description': 'An isolated fixture', 'capacity': 16, 'recommendedCapacity': 8,
                      'releaseStatus': 'private', 'version': 1, 'unityPackages': [{'platform': 'standalonewindows'}]},
            'avatar': {'id': SAMPLES['avatarId'], 'authorId': self.account, 'name': 'Synthetic test avatar',
                       'description': 'No asset files', 'releaseStatus': 'private', 'version': 1},
            'group': {'id': SAMPLES['groupId'], 'ownerId': self.account, 'name': 'Synthetic creator group',
                      'description': 'Test group', 'myMember': {'userId': self.account, 'roleIds': [SAMPLES['roleId']]}},
            'notification': {'id': SAMPLES['notificationId'], 'type': 'friendRequest', 'seen': False, 'hidden': False},
            'relationship': {'isFriend': False, 'incomingRequest': False, 'outgoingRequest': False},
        }
        self.favorites, self.moderations = [], []

    def inject(self, failure):
        if failure not in FAILURES:
            raise ValueError('Select one supported offline failure.')
        with self.lock:
            self.failure = failure

    def execute(self, operation, request):
        with self.lock:
            self.calls += 1
            failure, self.failure = self.failure, 'None'
            if failure == 'Timeout before send':
                raise APIError('Synthetic timeout before dispatch.', dispatched=False)
            if failure in ('Reject 403', 'Rate limit 429', 'Service 503'):
                code = int(failure.rsplit(' ', 1)[1])
                raise APIError(f'Synthetic HTTP {code}; no live traffic.', status_code=code, dispatched=True)
            if failure == 'Lose write response' and not operation.write:
                # Hold this one-shot until a mutation is actually dispatched; preflight remains usable.
                self.failure = failure
            result = self._apply(operation, request)
            if operation.write and failure == 'Lose write response':
                raise APIError('Synthetic response lost after applying the write.', dispatched=True)
            if failure == 'Malformed response':
                raise APIError('Synthetic malformed response after dispatch.', dispatched=True)
            if failure == 'Changed response schema':
                if isinstance(result, dict):
                    result['version'] = 'new-enum-shape'
                    result['newServerField'] = {'count': 3}
                elif isinstance(result, list):
                    result.append({'id': SAMPLES['targetUserId'], 'newServerField': None})
            return deepcopy(result)

    def _apply(self, op, req):
        key, body, paths = op.key, req['body'], req['path']
        if key in ('account.update', 'world.update', 'avatar.update', 'group.update'):
            record = self.records[key.split('.')[0]]
            record.update(deepcopy(body))
            return record
        if key in ('world.publish', 'world.unpublish'):
            self.records['world']['releaseStatus'] = 'public' if key.endswith('.publish') else 'private'
            return {}
        if key == 'avatar.select':
            self.records['account']['currentAvatar'] = paths['avatarId']
            return self.records['account']
        if key == 'instance.create':
            return dict(body, id=body['worldId'] + ':12345', instanceId='12345', n_users=0)
        if key.startswith('friends.') and op.write:
            relation = self.records['relationship']
            if key == 'friends.request': relation['outgoingRequest'] = True
            elif key == 'friends.cancel-request': relation['outgoingRequest'] = False
            else: relation['isFriend'] = False
            return {'success': {'message': 'Synthetic relationship action acknowledged'}}
        if key.startswith('notifications.') and op.write:
            item = self.records['notification']
            if key.endswith('.read'): item['seen'] = True
            elif key.endswith('.hide'): item['hidden'] = True
            else: self.records['relationship']['isFriend'] = True
            return item
        if key == 'favorites.add':
            item = dict(body, id=SAMPLES['favoriteId'])
            self.favorites.append(item)
            return item
        if key == 'favorites.remove':
            self.favorites = [v for v in self.favorites if v['id'] != paths['favoriteId']]
            return {'success': True}
        if key == 'moderation.apply':
            self.moderations.append(dict(body))
            return dict(body, id='synthetic-moderation')
        if key == 'moderation.reset':
            self.moderations = [v for v in self.moderations if v != body]
            return {'success': True}
        if op.write:
            raise ValueError('This synthetic operation has no fixture.')
        if key == 'account.get': return self.records['account']
        if key in ('user.get', 'user.profile'):
            return dict(self.records['account'], id=paths['userId'])
        if key in ('world.get', 'avatar.get', 'group.get'):
            record = self.records[key.split('.')[0]]
            requested = paths[key.split('.')[0] + 'Id']
            if requested != record['id']:
                return dict(record, id=requested, authorId=SAMPLES['targetUserId'], ownerId=SAMPLES['targetUserId'])
            return record
        if key == 'world.metadata': return {'metadata': {'synthetic': True}}
        if key == 'world.publication': return {'canPublish': True}
        if key == 'friends.status': return self.records['relationship']
        if key == 'notifications.get': return dict(self.records['notification'], id=paths['notificationId'])
        if key == 'instance.get': return dict(paths, id=paths['worldId'] + ':' + paths['instanceId'], n_users=0)
        if key == 'favorites.limits': return {'maxFavoritesPerGroup': {'world': 10, 'avatar': 10, 'friend': 10}, 'synthetic': True}
        if key == 'group.member': return {'userId': paths['userId'], 'groupId': paths['groupId'], 'roleIds': [SAMPLES['roleId']]}
        if key == 'group.announcement': return {'title': 'Synthetic announcement', 'created_at': '2026-01-01T00:00:00Z'}
        if key == 'service.config': return {'synthetic': True, 'clientApiVersion': 1, 'offlineFixture': True}
        rows = []
        if key in ('world.search', 'world.active', 'world.recent', 'world.favorites'): rows = [self.records['world']]
        elif key in ('avatar.list', 'avatar.favorites'): rows = [self.records['avatar']]
        elif key in ('group.search', 'user.groups', 'user.group-invites'): rows = [self.records['group']]
        elif key == 'friends.list': rows = [dict(self.records['account'], id=SAMPLES['targetUserId'])]
        elif key == 'notifications.list': rows = [self.records['notification']]
        elif key == 'favorites.list': rows = self.favorites
        elif key == 'favorites.groups': rows = [{'name': 'worlds1', 'type': 'world', 'ownerId': self.account}]
        elif key == 'moderation.list': rows = [v for v in self.moderations if not req['query'].get('type') or v['type'] == req['query']['type']]
        elif key == 'group.roles': rows = [{'id': SAMPLES['roleId'], 'name': 'Synthetic role', 'permissions': ['group-instance-create']}]
        elif key == 'group.permissions': rows = [{'name': 'group-instance-create', 'description': 'Possible permission; not a grant'}]
        elif key == 'group.members': rows = [{'userId': SAMPLES['targetUserId'], 'roleIds': []}]
        elif key == 'group.audit': rows = [{'id': 'gaud_00000000-0000-0000-0000-000000000010', 'eventType': 'group.update', 'actorId': self.account}]
        start, n = req['query'].get('offset', 0), req['query'].get('n', 20)
        page = rows[start:start+n] if op.pagination else rows
        if op.pagination == 'results': return {'results': page, 'hasNext': start + n < len(rows), 'totalCount': len(rows)}
        if op.response == 'array': return page
        return {'synthetic': True}


class _NoHistory:
    policy_revision = 0
    def submit(self, *args, **kwargs):
        raise AssertionError('Replay cannot use a history executor.')
    def close(self, *args, **kwargs): pass


class ReplayLab:
    """Virtual-clock player replay through the real model, with a prohibited history worker."""
    def __init__(self):
        self.events = []
        self.reset()
        self.load_builtin()

    def reset(self):
        from player_sessions import PlayerSessionService
        self.position = 0
        self.time = 1767225600.0
        self.service = PlayerSessionService(demo=True, worker=_NoHistory(), clock=lambda: self.time,
                                            wall=lambda: self.time)

    def load_builtin(self, count=12):
        from player_session_model import PlayerEvent, Source
        from player_sessions import utc
        if type(count) is not int or not 1 <= count <= 250:
            raise ValueError('Use between 1 and 250 synthetic players.')
        self.reset()
        self.events = [PlayerEvent.make('instance.entered', utc(self.time), data={'world_name': 'Synthetic replay'})]
        for i in range(count):
            uid = f'usr_{i+1:08x}-1111-2222-3333-444444444444'
            event = PlayerEvent.make('player.joined', utc(self.time + i + 1), user_id=uid,
                                     name=f'Synthetic player {i+1}', event_id=f'join-{i}')
            self.events.extend((event, event))  # Real deduplication, not a second simulated implementation.
            self.events.append(PlayerEvent.make('avatar.changed', utc(self.time+i+2), user_id=uid,
                                               data={'avatar_name': 'Synthetic avatar'}, event_id=f'avatar-{i}'))
        self.events.append(PlayerEvent.make('player.left', utc(self.time+count+3),
                          user_id='usr_00000001-1111-2222-3333-444444444444', name='Synthetic player 1', event_id='leave-1'))
        self.events.append(PlayerEvent.make('log.health', utc(self.time+count+4), data={'state': 'LIVE'}, source=Source.LOCAL))
        return self.snapshot()

    def import_events(self, text):
        from player_session_model import PlayerEvent
        value = bounded_json(text)
        if not isinstance(value, dict) or set(value) != {'format', 'events'} or value['format'] != 'vrc-eye-replay-1':
            raise ValueError('Use a vrc-eye-replay-1 data-only scenario.')
        if not isinstance(value['events'], list) or len(value['events']) > 2000:
            raise ValueError('A scenario may contain at most 2,000 normalized events.')
        events = []
        for item in value['events']:
            if not isinstance(item, dict) or set(item) - {'kind','stamp','user_id','name','data','source','event_id','reconstructed'}:
                raise ValueError('Unreviewed scenario field. Scripts and action executors are not accepted.')
            events.append(PlayerEvent.make(**item))
        self.reset(); self.events = events
        return self.snapshot()

    def step(self, count=1, stop=None):
        from world_players import log_epoch
        if type(count) is not int or not 1 <= count <= 2000:
            raise ValueError('Use 1–2,000 steps.')
        for _ in range(count):
            if self.position >= len(self.events) or stop is not None and stop.is_set(): break
            event = self.events[self.position]
            self.time = max(self.time, log_epoch(event.stamp) or self.time)
            self.service.accept(event)
            self.position += 1
        return self.snapshot()

    def snapshot(self):
        return {'environment': 'Replay', 'position': self.position, 'events': len(self.events),
                'virtual_time': self.time, 'players': len(self.service.rows),
                'active': sum(r.active for r in self.service.rows.values()),
                'revision': self.service.revision, 'network_requests': 0, 'history_writes': 0,
                'rows': [{'userId': r.user_id, 'name': r.name, 'state': r.presence.value,
                          'observations': {key: obs.inspect(self.time, self.time)
                            for key, values in r.fields.items() for obs in [r.get(key, self.time)]}}
                         for r in list(self.service.rows.values())[:100]]}


def parse_log(text):
    from avatar_watch import SessionParser
    if not isinstance(text, str) or len(text.encode('utf-8')) > 256*1024:
        raise ValueError('Supply no more than 256 KiB of log text.')
    parser = SessionParser('developer-offline-parser')
    parser.reconstructing = True
    rows, unrecognized = [], 0
    for number, line in enumerate(text.splitlines(True), 1):
        if len(line) > 65536: raise ValueError('A parser input line is too long.')
        parser.feed(line)
        events = parser.player_events.drain()
        if not events: unrecognized += 1
        for event in events:
            rows.append({'line': number, 'kind': event.kind, 'source': event.source.value,
                         'userId': event.user_id, 'observed_at': event.stamp, 'payload': event.data})
    return redact({'environment': 'Sandbox', 'lines': len(text.splitlines()), 'lines_without_player_events': unrecognized,
                   'events': rows, 'network_requests': 0}, local=True)


def fuzz(seed=197, count=250, stop=None):
    """Bounded deterministic property sweep over our own JSON, redactor and packet parsers."""
    from friend_feed import parse_packet
    if type(seed) is not int or not 0 <= seed <= 2**32 or type(count) is not int or not 1 <= count <= 1000:
        raise ValueError('Use seed 0–2^32 and 1–1,000 cases.')
    rng = random.Random(seed)
    rejected, parsed, failures, completed = 0, 0, [], 0
    atoms = [None, True, False, 0, 1, 'λ', '', {'type': 'unknown', 'content': '{}'}, []]
    for index in range(count):
        if stop is not None and stop.is_set(): break
        value = rng.choice(atoms)
        for _ in range(rng.randrange(1, 12)):
            value = rng.choice(([value], {'unknown': value}, {'password': value, 'count': index}))
        text = canonical(value)
        if index % 7 == 0: text = text[:-1]
        try:
            parsed_value = bounded_json(text)
            parsed += 1
            redact(parsed_value); json_shape(parsed_value)
        except ValueError: rejected += 1
        try:
            parse_packet(text)
        except (ValueError, TypeError):
            pass
        except Exception as error:
            failures.append({'seed': seed, 'case': index, 'error_type': type(error).__name__})
        completed += 1
    return {'environment': 'Sandbox', 'seed': seed, 'cases': completed, 'parsed': parsed,
            'rejected': rejected, 'unexpected_failures': failures, 'network_requests': 0,
            'scope': 'Local bounded JSON, diagnostic redaction, shape inspection and pipeline parser only'}
