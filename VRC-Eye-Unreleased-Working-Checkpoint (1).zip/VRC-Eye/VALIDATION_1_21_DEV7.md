# 1.21.0 Development checkpoint 7 — validation

The combined portable regression passed **4,476 tests and 1,059 subtests**, with
no failures or errors, in 104.42 seconds. The offline socket guard recorded
**zero blocked external attempts**. Two existing warnings concern a test-class
name and an intentionally duplicated ZIP fixture. No live VRChat writes occurred.

This build is based on the complete Development 6 ZIP (SHA-256
`a6bedc22f6a8780bd5d230e8cfa5a85c6abb617abe11b009bafbb54a594348e9`) that became
available from the preceding chat during this task. All its features and files
are retained. The continuation enhances its existing history pane; the earlier
parallel prototype was superseded and is not included as a second history UI.

The **28 new passing tests** cover real SQLite scope/isolation, source-origin ID
collisions, read-only snapshots, stale/deleted data, record byte budgets, undated
and derived timestamps, DST display offsets, retained encounter segments,
unknown durations, CSV formula escaping/no-clobber/cancellation, account changes
before UI ticks and during dialogs, privacy draft clearing, source changes,
pagination, filters, one shared route and worker/UI boundaries. UI callback tests
use headless widget fixtures; they do not establish native layout acceptance.

The suite has **473 skipped native GUI tests** and **one deselected Unix bridge
test**. The same 13 local-transport-associated modules as Development 6 remain
excluded and are not counted as passed. The virtual X server cannot establish
local listening sockets in this environment. Commands and exclusions are recorded
in `BUILD_VALIDATION.json`.

All **523 Python files** parse with Python 3.10 grammar; execution used Python
3.12.14. The **572-file source manifest** covers source, tests, launchers and
configuration. All seven launchers and requirements are unchanged from the
complete Development 6. Shell syntax and CLI version checks passed. Final ZIP
CRC, all prior paths and exact source/manifest bytes are checked during packaging.
The full regression ran against the working source; packaging checks do not claim
a second full run from a clean extraction. Runtime code is unchanged after that
regression; only release/validation documentation was finalized afterward.

Native Windows/Linux GUI and accessibility, credential vaults, tray, speech,
URI handlers, trash, SteamVR, audio hardware, Discord, Unity, physical mobile
pairing and live VRChat permissions/entitlements still need acceptance on those
systems. This is runnable source, not a compiled executable or signed installer.

VRCX package counts remain **49 source-implemented and 33 partial**. The full
roadmap is incomplete. See [continuation notes](HISTORY_CONTINUATION_DEV7.md),
[retained Development 6 features](VRCX_COMPLETION_DEV6.md), and
[prior validation](VALIDATION_1_21_DEV6.md).
