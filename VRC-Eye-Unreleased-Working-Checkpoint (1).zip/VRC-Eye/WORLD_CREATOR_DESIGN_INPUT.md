# World Creator design input — 1.19.2

The supplied text below is preserved byte-for-byte after the source marker.
This map distinguishes implemented local workflows from optional integrations
and capabilities which still need a supported runtime route.

| Spec | Feature | 1.19.2 implementation / boundary |
|---|---|---|
| 1–2 | Creator recognition and contextual workspace | Stable-account read-only recognition, cached/local/unresolved states, pin/follow workspace, eight tabs. No authority is granted by recognition. |
| 3–4 | Metadata and descriptions | Local drafts, section templates, editable-tag filtering, base/draft/latest conflict review and SDK export. No direct remote write. |
| 5–6 | Publication and platform builds | Read-only publication/package snapshot, explicit local upload/build/test evidence; current publication differs from loaded build. Publication remains SDK/website-owned. |
| 7–8 | Health and join/leave debugging | Source-scoped health, local log timeline, aggregate observed roster; unavailable and partial evidence remain explicit. |
| 9–11 | Udon errors, timeline and population | Bounded observations, exact source/build/object grouping, event/receipt ordering, evidence bookmarks, observed population graph. No inferred causation or reconstructed missing arrivals. |
| 12–13 | Version history and capacity | Local build/upload records, frame-budget/sample analysis, environment constraints. No remote archive reconstruction or automatic capacity edit. |
| 14–16 | Tasks, checklists and bookmarks | Object-scoped notes/issues, immutable checklist/profile snapshots, required evidence, portable selected evidence windows. |
| 17 | SteamVR presentation | Optional read-only card using existing runtime; configurable position/size/opacity/TTL. Interactive VR input is deferred. |
| 18 | Reports | Exact selected preview, disclosure profiles, HTML/Markdown/JSON/CSV, redaction and portable bookmark evidence. Arbitrary attachments are not silently read or packaged. |
| 19 | Test profiles | Local reusable conditions and immutable run snapshots; launch requirements recorded as instructions, never silently applied. |
| 20–22 | Helper and controls | Strict manifest, Unity exporter/Udon sample, untrusted log observations, explicit finite local MIDI route with review/cancellation/no retry. Shared/persistent controls remain blocked. |
| 23–24 | Recipes and baselines | Ordered manual runner with expected results/branches/stop conditions; compatible-condition comparisons, coverage and accepted-regression records. |
| 25–26 | Late joins and ownership | Guided convergence/ownership/suspension scenarios and scoped expected/reported states. Does not manipulate other players. |
| 27–28 | Network budgets and persistence | Structured budgets/observations and environment-specific persistence cases; no undifferentiated network score or production save-data reset. |
| 29–32 | Accessibility, movement, rendering and media | Guided templates and concrete worksheets with conditions, expected/observed results, evidence and graceful-failure cases. Human testing remains necessary. |
| 33–34 | Semantic parity and spatial routes | Creator-manifest contract comparison, named zones/routes and coverage summaries. No extraction of arbitrary runtime materials or movement. |
| 35–36 | Playtest coordination and feedback | Selected-field peer reviews, exact world/build/run imports labelled reported, local role/coverage and feedback triage records. Existing Networking service only. |
| 37–38 | Assertions and failure testing | Declared assertion scope/grace/cost, helper-reported evidence, isolated local adapter drills/manual test recipes. No untrusted assertion becomes authenticated proof. |
| 39–40 | Release gates and known issues | Explicit advisory requirements and local searchable issue knowledge with fix/verification distinctions. No auto-publish or assumed identical cause. |
| 41–42 | Dependencies and onboarding | Creator-supplied project inventory/credits, localization and onboarding worksheets with separate review/test states. No license clearance claim. |
| 43–44 | Debug audit and bounded Black Box | Manifest exposure audit, bounded local evidence capture/soak summaries, retention/drop/overhead reporting and preserved bookmark windows. No guessed crash cause or memory-leak diagnosis. |

See WORLD_CREATOR_SETUP.md and VALIDATION.md for operating details, automated
checks and platform/hardware validation still required. Local structures and
algorithms are useful without the optional integrations; native Unity, MIDI,
VRChat and SteamVR execution require testing in the creator's environment.

--- BEGIN ORIGINAL SUPPLIED TEXT (unchanged bytes) ---
Worked for 8m 53s
VRC Eye World Creator Features: a full creator workspace
The direction I would take is to make World Creator Mode a complete workspace for understanding, testing, documenting, and maintaining your worlds—not simply a collection of extra buttons that appears when you enter something you uploaded.

Your original 22 features fit together into a much larger workflow:

Recognize the world → establish what VRC Eye can actually observe → prepare a test → collect evidence → identify problems → reproduce them → verify a fix → prepare a release.

The optional world helper adds another layer: the world can deliberately describe itself to VRC Eye and expose selected controls that its creator intentionally implemented.

I’m treating this as an expansion of the planned feature set, rather than claiming all of it is already implemented. The additional ideas later in this answer are new proposals.

I. The foundation: what Creator Mode should—and should not—depend on
Before expanding the individual features, I would establish a firm architectural distinction between six sources of functionality.

Layer	What it provides	What it should not imply
Local creator workspace	Notes, TODOs, checklists, test profiles, imported reports, bookmarks, recorded history	No server or VRC Eye-to-VRC Eye connection should be required
Local session observation	Information available from your own accessible logs and supported local telemetry sources	Not unrestricted inspection of the running world
Authorized VRChat information	World metadata, publication information, and permitted account operations	Not permission to edit something merely because the interface recognizes its author
Optional Unity project integration	Build manifests, project-side validation, source mappings, supported SDK operations	Not a mandatory dependency for basic Creator Mode
Optional world helper	Creator-declared telemetry, named test events, and deliberately exposed controls	Not arbitrary Udon execution or manipulation of other worlds
Optional VRC Eye peer connection	Shared playtests, participant-submitted diagnostics, coordinated checklists	Not automatic access to another tester’s computer, logs, or VRChat client
This preserves the direction we already established for VRC Eye: one general-purpose companion, local-first functionality, and optional integrations that add capabilities rather than becoming prerequisites.

Creator Mode should also remain a presentation profile, consistent with the Casual/Advanced approach. It changes which information is prominent and which workflows are available. It is not itself an authorization mechanism.

Most importantly:

“VRC Eye recognizes that you created this world” is different from “the current operation is authorized,” and both are different from “VRC Eye has a supported technical route to perform it.”

Those three checks should remain separate throughout the entire design.

II. Your original 22 features, expanded
1. Automatic Creator Mode when the logged-in user matches the world author
The basic activation rule is straightforward: when VRC Eye has a sufficiently reliable identity for the active VRChat account and the current world’s author, it compares their stable account identifiers.

Conceptually:

activeAccountId == currentWorld.authorId

That should reveal the creator workspace for that world. It should not immediately change world settings, start sharing diagnostics, enable public debugging, or activate runtime controls.

Recognition needs several states
Instead of a single Creator Mode checkbox, I would use an internal recognition state:

State	Meaning
Confirmed author match	The current account and world author match through the selected information source
Previously recognized author	Cached information matches, but the current session has not been revalidated
Local project creator	You have opened an unpublished or local test project that has no usable published-world identity
Collaborator/tester	You have creator-workspace access for this project, but are not being represented as its publishing account
Unresolved	VRC Eye lacks enough information to make a reliable match
Not the author	The current information identifies a different publishing account
This prevents an offline cache from masquerading as fresh authorization.

Account and world changes must invalidate the right things
Changing accounts, entering another world, switching between test clients, or reconnecting should force VRC Eye to reconsider the active creator context.

Unsent notes can remain open. A pending “reset test system” request cannot simply follow you into another instance.

The workspace should also let you disable automatic switching, keep a creator workspace pinned while visiting a reference world, or use an “offer Creator Mode” notification instead of automatically navigating away from your current page.

Author identity must not be confused with runtime roles
World author, instance owner, instance master, object owner, and VRC Eye playtest host are different concepts. VRChat’s networking documentation specifically warns against using the instance-master role as a security gate, and its instance-owner property has context-dependent behavior. VRC Eye should not flatten all of these into “admin.” 

There is also an important helper limitation: the documented Udon player interfaces expose display names and network/player IDs, but do not document a general global usr_... account-ID getter. Therefore, the external application’s author comparison cannot simply be copied into Udon and assumed to work identically. 

2. Creator-specific World tab
I would make this a contextual workspace inside the World area, rather than scattering creator tools across unrelated settings pages.

A practical organization would be:

Overview · Metadata · Builds · Live Test · Diagnostics · Tasks · History · Controls

These are subsections of the creator workspace, not eight additional top-level sidebar categories.

The Overview should answer the immediate questions
On entering your world, you should be able to tell:

Which world and instance VRC Eye is observing.
Which build is actually identified, versus which build is merely advertised as latest.
Whether a test is currently running.
What sources are connected and how fresh they are.
Whether there are unresolved problems relevant to this build.
Which important tests remain incomplete.
The identity strip should stay visible while changing subsections. That is particularly important when you have several similarly named worlds, separate staging and production worlds, or multiple local clients.

A workspace should survive leaving the world
Leaving an instance should stop live observation for that instance, but should not close your notes or discard the test.

The UI could switch from:

Live test — recording

to:

Test ended — reviewing captured session

That allows the natural workflow of testing in VRChat, returning to Unity, and continuing to work from the evidence.

Missing capabilities should be explained, not disguised
A control that depends on a helper should say:

“Requires a compatible helper in this world.”

A project inspection panel should say:

“No Unity build manifest attached.”

An unavailable measurement should say:

“Not measured.”

It should not display a reassuring zero, a permanently spinning loader, or a generic “connection failed” message.

3. World metadata editor
This should be a draft-and-review editor, not a form that immediately pushes every keystroke to the live world.

The most important design decision is to maintain three separate records:

Last retrieved published values → your local draft → latest values retrieved before submission.

That makes it possible to detect another edit rather than accidentally overwriting it.

The editing workflow
You open a world, modify its supported fields, and save the draft locally. VRC Eye shows a field-by-field comparison before any remote operation.

For example, the confirmation should distinguish:

Description changed.
Tags changed.
Capacity unchanged.
Publication state unchanged.

That last part matters. Editing a description should never accidentally become a publication operation.

Before submission, VRC Eye should refresh the relevant metadata and check whether the original values have changed. When the underlying service supports conditional updates, use them. Otherwise, perform a best-effort comparison and explain that it is not an atomic conflict guarantee.

There should be more than one delivery path
The editor can be useful even before direct remote editing exists.

A local draft can be copied to the official editing interface, exported, or handed to an optional Unity integration. VRChat’s documented Public SDK API includes editor-side extension points and identifies public API methods for operations such as updating content descriptions. That is a concrete integration route, but it is not the same as a guaranteed standalone public web API. 

VRChat separately states that its web API is not documented for public usage and may change without warning. Any direct account adapter therefore needs its own compatibility handling rather than being treated as a permanent, guaranteed interface. 

Failure must preserve the draft
An expired login, rejected field, network interruption, or changed permission should never destroy the work.

The draft remains local, with a clear state such as Not submitted, Partially applied, or Confirmed applied.

4. Description, capacity, and tag tools
These deserve more attention than simply exposing three text fields.

Description tools
I would include reusable sections for controls, accessibility options, known limitations, credits, update notes, and playtest instructions.

The useful feature is not “generate a longer description.” It is maintain accurate descriptions without repeatedly rewriting the same information.

A description template might have a stable section for controls and a replaceable section for the current update. Before export, VRC Eye could flag placeholders, duplicated headings, obsolete test-build notices, or claims that no longer match the selected build.

Length validation should follow the destination’s current constraints, with cached rules clearly identified when offline.

Capacity tools
Recommended capacity and maximum capacity should be treated separately. VRChat’s documentation describes recommended capacity as affecting how public instances are presented once that threshold is reached; it is not simply a second label for the hard maximum. 

VRC Eye should therefore maintain:

Configured recommended capacity · configured maximum capacity · tested population range · evidence-supported recommendation.

The last two are local creator findings, not official VRChat limits.

An illustrative recommendation could read:

“This build has been tested with 12 participants. There is no test evidence above that population.”

That is much better than silently deciding that an empty-world frame rate proves the world can comfortably host a large crowd.

Tag tools
Tags should support local drafts, deduplication, spelling cleanup, and reusable sets.

However, VRC Eye should distinguish creator-editable tags from other labels or classifications returned by a service. It should not assume every visible string is something the creator may modify.

Suggested tags should describe the actual world, not encourage irrelevant search-term stuffing.

5. Publication-state information
This should explain the difference between what exists locally, what has been uploaded, and what users can currently access.

Those are separate questions.

A build can exist locally without being uploaded. An upload can succeed without the creator having completed every intended platform. A published world can still have an unfinished local revision.

The publication panel should combine facts and pending work
I would show the retrieved publication state, the time it was checked, the latest recorded upload result, outstanding local metadata changes, and any platform-specific uncertainty.

The panel should distinguish:

“Upload succeeded.”

from:

“This release has been verified on all intended platforms.”

Likewise, “private” is a visibility state, not a diagnosis of why a world is unavailable to a particular tester.

VRChat documents Community Labs as part of the public-world publication process and distinguishes updating an existing public world from submitting a world to Labs. VRC Eye should display those concepts accurately rather than treating every upload as a fresh publication request. 

Publication actions need an explicit boundary
Publishing, unpublishing, or changing a sensitive setting should be a separate operation with its own confirmation.

The UI should identify the exact world, show the current and requested states, and avoid automatically repeating a request after an ambiguous timeout.

A local release-readiness checklist can advise against publishing, but it should not pretend to be a VRChat moderation decision or guarantee that a world will be accepted.

6. Platform build checker
This should be a platform-and-test matrix, not just a row of platform icons.

Current creator documentation includes Windows, Android, and iOS build workflows. Therefore, the data model should not permanently assume that world compatibility means only “PC versus Quest.” 

Track several different kinds of compatibility
For each intended target, VRC Eye should distinguish:

Question	Example state
Does a build exist?	Present / missing / unknown
Is it the intended revision?	Matching / older / unverified
Did it upload successfully?	Confirmed / failed / no record
Has it been opened in the actual client?	Tested / not tested
Were important interactions tested?	Passed / failed / incomplete
Was shared behavior tested across platforms?	Verified / mismatch / untested
A platform badge alone should never imply that all six questions are answered.

“Latest metadata” is not “loaded build”
The current website information may describe an upload made after a test began. VRC Eye should not relabel the already-running session as that newer build without evidence.

An embedded helper build identifier or a matching build manifest would provide stronger identification. Without that, the UI should retain uncertainty.

Project-side checks should remain optional
An imported manifest could identify target-specific feature differences, stripped objects, shader variants, or changed networking declarations.

That deeper analysis belongs to an optional project integration. The basic checker should still work with manually recorded builds and submitted test results.

7. World health dashboard
I would avoid a single unexplained “World Health: 87%” score.

That number would hide too much: a world could have excellent frame times while an essential game system is broken.

Instead, health should have separate dimensions:

Stability · responsiveness · networking · interaction correctness · test coverage.

Every reading needs a source and scope
A useful measurement card would include the value, unit, sample period, source, and scope.

For example:

Frame-time measurement
Source: selected local runtime provider
Scope: this client
Context: current test profile
Coverage: recent samples only

This prevents local client performance from being mislabeled as a global property of the world.

Similarly, process memory is not automatically world-only memory, and a creator-defined Udon timer is not a full profiler of all engine activity.

The dashboard should prioritize change
The most useful questions are often:

What became worse after this action?
What differs from the last comparable test?
Which subsystem stopped reporting normally?

A health card should therefore be able to link directly to the error timeline, relevant test step, or comparison baseline.

With helper support, documented Udon network statistics offer useful inputs such as throughput, outbound queues, and per-object update information. Those should retain their documented meanings rather than being relabeled as generic “internet quality.” 

Unknown is a first-class result
No errors observed does not necessarily mean no errors occurred.

The dashboard should explicitly show missing log coverage, inactive instrumentation, disconnected testers, and unsupported measurements.

8. Join/leave debugging
This should reconstruct the sequence around a player’s arrival or departure, not merely append names to a list.

For a join, the useful sequence might include the observed arrival, helper initialization, restoration of relevant state, completion of a test step, and any subsequent error.

Udon provides player join and leave events, which a compatible helper could deliberately annotate with additional world-specific context. 

Initial observation is not necessarily a new arrival
Suppose VRC Eye begins observing an already-populated instance. The players it discovers should be recorded as present when observation started, not as twelve people who all joined at that instant.

Likewise, a reconstructed roster must not claim to know the true original join order unless the necessary evidence was captured.

Departure reasons need restraint
A leave event does not, by itself, prove that someone crashed, disconnected, changed worlds, or closed the application.

VRC Eye should distinguish:

“Departure observed.”

from:

“Tester reported a crash.”

and from:

“The tester’s opted-in local diagnostics recorded an unexpected process exit.”

Those are different evidence levels.

Turn sequences into useful test findings
A strong result would be:

“The door state was correct for existing participants but not confirmed for the late-joining tester.”

That points toward a reproducible synchronization test.

It should not automatically become:

“The new player broke the door.”

9. Udon log filtering
This should become a structured diagnostic view rather than a text search box with a Udon checkbox.

Useful filters would include severity, time range, world/build, script or subsystem where identifiable, repeated error group, test step, and source client.

Recognize the limits of the available log
VRChat documents that its normal log does not contain all detailed Udon information by default, while Build & Test enables additional debugging features. VRC Eye should detect or record the capture configuration and explain when a deeper diagnosis requires another run with suitable logging. 

It should not invent a script name or line number when the underlying log does not provide one.

Group repetition without erasing evidence
A repeated error should collapse into one expandable group showing the first occurrence, most recent occurrence, count, affected tests, and relevant surrounding events.

The grouping algorithm should preserve important distinctions. Two errors with similar text but different objects or builds may represent different defects.

The original evidence should remain available according to the retention policy.

Make creator-written logs more valuable
The optional helper could support stable subsystem identifiers and event codes:

Lighting / PresetApplied
RoundManager / ResetCompleted
DoorController / StateMismatch

These labels should be treated as structured data, not as commands.

A line that claims to come from a helper is not automatically authenticated simply because it has the correct prefix.

Source mapping should require a matching build
UdonSharp provides a runtime-exception debugging workflow with editor integration. VRC Eye could complement that by attaching matching source-map information when explicitly available, rather than pretending every uploaded world’s errors can be resolved back to source code. 

10. Error timeline
The error timeline should be the central place where otherwise disconnected evidence becomes understandable.

It would combine errors, join/leave observations, test actions, helper events, bookmarks, build identifiers, and selected measurements.

Use separate tracks
I would give different evidence types their own tracks so that one noisy source cannot bury everything else.

A creator could isolate a short interval and see:

Test action issued → helper accepted it → local state changed → serialization reported → one tester reported a mismatch.

That is substantially more informative than a pile of warnings.

Preserve time uncertainty
For multi-client tests, VRC Eye should store both the time an event reportedly occurred and the time it was received.

Clock alignment should have an uncertainty estimate. Two events close together should not be presented in a falsely precise order when their clocks were insufficiently synchronized.

Within a single recording process, elapsed-time ordering should not depend solely on a wall clock that can change.

Correlation is not causation
The interface should use language such as occurred near, followed, reproduced after, or supported by these observations.

A join followed by a frame-time spike is a correlation. A controlled repeated test provides stronger evidence.

Bookmark the interval, not just the error line
An error often becomes understandable through what happened immediately before it. Selecting an incident should preserve a configurable context window and the active test configuration.

11. Session population graph
This should represent the population observed during the recorded session, not imply that VRC Eye has a complete global history of the world.

The basic graph would be a step chart with markers for arrivals, departures, test phases, and important changes.

The baseline matters
When observation begins with an unknown or incomplete roster, VRC Eye should show that uncertainty.

It should not start at zero and create a dramatic population surge merely because it discovered people who were already there.

Duplicate events should be reconciled, negative counts should be treated as a data-quality problem, and reconnects should not automatically become new unique visitors.

Use the graph as a navigation tool
Selecting a population range could reveal the tests performed during that interval, the available performance samples, and the errors observed.

For example:

“Compare the same test action during the small-group and larger-group phases.”

This becomes useful when connected to the capacity assistant.

Avoid unsupported analytics claims
Time observed in a session is not automatically retention. A departure is not necessarily dissatisfaction. A repeated encounter is not necessarily a unique returning customer.

Private-instance identifiers and participant identities should be optional in exports. Aggregate population curves will often be sufficient.

12. World version history
This should be an evidence-backed local history of builds, uploads, metadata changes, and test results.

These should not all be squeezed into one “version” number.

Maintain separate identifiers
A robust record could contain a creator-assigned release label, local build identifier, published-world identifier, platform target, project revision when supplied, and the upload result.

The creator’s “Version 2.4” is not necessarily identical to an internal service version or a Unity build artifact.

Every recorded build should become a useful page
Opening a build should show what changed, what was tested, what failed, which issues were believed fixed, and which remain unverified.

The valuable question becomes:

“What evidence do we have that this build is better than the last one?”

Do not promise a history that was never captured
VRC Eye should not invent earlier versions or assume it can retrieve every previous uploaded package.

History begins with records it actually captures or imports. Earlier information can be entered manually and labeled accordingly.

Rollback should mean something precise
A metadata draft can be restored locally. Restoring a project revision requires the creator’s project history or backup. Releasing an older world build requires an appropriate supported build/upload workflow.

Those are separate operations, not one universal Undo button.

13. Capacity/performance assistant
This should help the creator design and interpret population tests rather than produce a magical maximum-player estimate.

Begin with an explicit test envelope
A capacity recommendation should identify the build, platform, hardware class where voluntarily supplied, graphics configuration, avatar conditions, active world features, test duration, and population range.

Without that context, “it ran well with twenty people” is difficult to reproduce.

Prefer frame-time distributions and repeated observations
The assistant should compare sustained behavior and spikes rather than rely only on average frame rate.

For illustration, a creator could define a target frame budget using:

frame budget in milliseconds = 1000 ÷ target frames per second

That is a target chosen for the test, not a guarantee that every participant will achieve it.

Separate world load from other conditions
VRC Eye should encourage controlled comparisons: the same route, similar settings, comparable avatar conditions, and the same enabled world systems.

A mirror-on versus mirror-off test is more interpretable than two unrelated visits with different populations and settings.

Recommendations should include their limits
A useful conclusion would be:

“The tested configuration met your selected target through the observed population range. Larger groups and mobile VR remain untested.”

The assistant should never automatically increase published capacity based on a single successful run.

It should also treat the cost of diagnostic logging and the overlay as part of the test configuration, not invisible overhead.

14. Creator notes and TODOs
These should be attached to meaningful objects in the creator workflow.

A note could belong to a world, a particular build, a test run, an error group, a platform, or an explicitly identified world subsystem.

Turn an observation into a tracked issue
From a timeline bookmark, you should be able to create an issue with its evidence already attached.

A useful issue would contain:

Observed behavior · expected behavior · reproduction conditions · affected builds · proposed fix · verification status.

The status model should distinguish fix implemented from fix verified. Those are not the same milestone.

Keep private and shared content separate
A private note should remain private when you later connect to another VRC Eye user.

Sharing a test report should not silently include every draft thought, internal discussion, or unrelated TODO associated with the world.

Support work that has not yet become a bug
Creators also need design notes, polish items, unresolved questions, and release reminders.

Not everything should be classified as an error. A questionable interaction could remain an investigation until a test clarifies it.

Search should connect the records: a subsystem name should reveal its notes, relevant incidents, affected builds, and outstanding tests.

15. Playtest checklist
The checklist should describe what constitutes a pass, not just present a list of things to click.

For example:

Late-join door state
Preparation: change the door state before the tester joins.
Expected result: the joining tester sees the current state without another interaction.
Evidence: tester confirmation or a declared helper assertion.

That is a test. “Check doors” is a reminder.

Use meaningful result states
I would support Not started, In progress, Passed, Failed, Blocked, Not applicable, and Needs verification.

Blocked matters when the necessary platform or tester is unavailable. It should not be counted as a pass.

Checklists should be versioned
When a checklist changes, older runs should retain the version they actually used.

Otherwise, a previously completed run may misleadingly appear to have covered tests that were added afterward.

Scope the result
A test can pass in the editor and remain untested in the real client.

VRChat explicitly notes that ClientSim does not simulate every client feature and has networking differences. Therefore, an editor pass should not automatically satisfy a live multiplayer or platform-specific requirement. 

Sharing remains optional
A solo creator should have the full checklist system locally. Peer connections add assignments, coordinated completion, and participant-submitted evidence.

16. Debug bookmarks
A bookmark should be a small evidence package, not merely a timestamp.

It could preserve the selected interval, world/build context, active test step, creator note, and whichever measurements were actually available.

Several bookmark types would be useful
A manual marker says “something happened here.”

An error marker points to a specific incident.

A comparison marker identifies the beginning or end of a controlled measurement.

A location marker adds a creator-declared zone or an explicitly available local position.

Those types should remain distinguishable.

The capture action should be low friction
A desktop hotkey, overlay button, or permitted controller action could create an unnamed marker immediately. You can describe it afterward.

That is useful when explaining the problem during the event would interrupt the test.

Location should not be assumed
Without a helper or another supported location source, a bookmark can still contain a manually selected zone name.

It should not display invented coordinates or reconstruct a person’s movement from unrelated data.

Bookmarks should survive report export
A report recipient should be able to understand what the bookmark refers to even without the original VRC Eye database.

The exported package should preserve the selected evidence and clearly identify omissions.

17. Creator SteamVR overlay
This should be a focused testing interface, not the entire desktop application floating in front of your face.

Valve’s OpenVR overlay interface supports application-controlled overlays displayed over the running VR scene, providing an appropriate basis for an optional SteamVR presentation layer. 

Design around short interactions
The most useful overlay actions would be:

Mark an incident · view the current test step · record pass/fail · add a short note · inspect the latest important error · operate a pinned permitted control.

Deep metadata editing and large comparison tables belong on the desktop.

Separate observation from consequential actions
A read-only diagnostic card can be easily accessible.

A shared-state reset should require a deliberate interaction and display its scope. It should not sit next to a harmless bookmark button with identical styling.

Support comfortable placement
The overlay should offer adjustable scale, left/right placement, dashboard mode, opacity, and a reduced-motion presentation.

It should avoid unsolicited flashing, sudden large panels, and input capture that interferes with ordinary VRChat interactions.

Do not create a new mandatory dependency
No SteamVR means no SteamVR overlay—not no Creator Mode.

The desktop interface remains fully useful, and any other supported presentation backend should be negotiated separately rather than assumed equivalent.

Measure its own cost
Overlay rendering and update frequency should be recorded in benchmark profiles. A performance test should be able to run with the overlay hidden while collection continues.

18. Exportable test reports
A report should communicate what was tested, what was observed, and how much confidence the evidence supports.

I would support human-readable HTML or Markdown, structured JSON, tabular CSV where appropriate, and an optional packaged report containing selected attachments.

A good report needs context
The header should identify the world, known build information, test environment, checklist version, observation period, participating sources, and limitations.

The result section should separate confirmed failures, reported problems, unresolved suspicions, and untested areas.

That prevents “we saw something strange” from becoming an apparently verified defect.

Export profiles should control disclosure
I would provide at least three report profiles:

Private archive, with the creator’s chosen detailed evidence; collaborator report, with relevant diagnostics and reduced identifiers; and public issue report, with stronger redaction.

The export preview should show exactly which attachments and fields will be included.

Redaction must cover more than names
Potentially sensitive content includes instance identifiers, private URLs, tokens, local filesystem paths, screenshots, and free-text notes.

VRChat’s own debug-view documentation cautions that some debug information should not generally be shared with other users. VRC Eye should therefore avoid blindly bundling every available debug dump or screenshot. 

Reports should remain portable
An exported report should remain readable without a VRC Eye account or a live relay.

Machine-readable exports should include a schema version so future tools can interpret them correctly.

19. Creator test profiles
A test profile should describe the conditions under which a run is intended to happen.

It could select the checklist, enabled data sources, capture verbosity, target platform, relevant world-feature settings, participant roles, performance targets, and sharing policy.

Distinguish requested conditions from observed conditions
A profile might request “desktop test with mirror disabled,” but VRC Eye should not mark those conditions as confirmed unless they are actually known.

Each important setting should be verified, manually confirmed, requested but unverified, or unavailable.

This matters when comparing tests later.

Profiles should be reusable but immutable within a run
Editing a saved profile should affect future runs. It should not rewrite the configuration associated with an already-recorded test.

A running test can record a deliberate configuration change as an event.

Examples of useful profiles
A creator might keep separate profiles for a normal-user smoke test, detailed Udon debugging, cross-platform interactions, late-join synchronization, long-session stability, and release verification.

The distinction is not merely which graphs are visible. It is which questions the test is trying to answer.

Launch settings need explicit treatment
Some debugging settings are launch-time choices. VRC Eye should identify when a requested profile requires a new client session rather than implying that all settings can be changed live. VRChat documents launch options as part of its Udon debugging workflow. 

20. Optional VRC Eye-compatible world helper
This is the feature with the largest potential—and the one that needs the most disciplined boundaries.

I would treat it as a small, optional world-side integration package, not a way to turn VRC Eye into a universal controller for arbitrary worlds.

A. The helper declares what exists
A helper manifest could identify:

Helper protocol version · creator-defined build ID · available telemetry · available controls · supported test assertions · declared zones · command restrictions.

The manifest should describe capabilities. It should not contain credentials that grant broad authority.

A compatible helper might declare:

“This build exposes round-state observations, three named checkpoints, and a local lighting preset control.”

It should not say, in effect:

“Send any method name and I will try to execute it.”

B. Outbound telemetry can start simply
The first useful integration could be structured creator-written messages in the local output log.

That would allow the world to emit named events, build identity, test checkpoints, and selected diagnostic values for the local companion to read.

This remains an observation channel. A formatted log message is not a trusted instruction to open a URL, execute a program, or change local settings.

C. Inbound control needs a real, supported transport
We should not assume that an OSC connection gives VRC Eye arbitrary access to Udon.

VRChat does document real-time MIDI input for Udon through a deliberately configured MIDI listener. That makes a tested local MIDI adapter a plausible optional route for a limited creator-defined control protocol. Device availability and routing would need to be checked on each supported configuration. 

The application could translate a permitted control into a small protocol message; the world helper would interpret only the specific messages it was built to accept.

That is different from unrestricted script execution.

D. Web-based configuration is a different capability
Udon string loading can retrieve remote text, but current documentation specifies a five-second download interval and URL restrictions. It should be treated as a constrained configuration/polling mechanism—not a general-purpose low-latency socket or unrestricted HTTP client. 

The documented URL model also distinguishes predefined URLs and user-entered URL fields; it does not support simply constructing arbitrary VRCUrl objects from strings at runtime. 

Therefore, a web-assisted helper would need its own carefully designed workflow. It should not become the mandatory basis for local Creator Mode.

E. Transport and authority remain separate
Receiving a MIDI message proves that a message arrived through that input path. It does not prove that the sender is the world’s publishing account.

Likewise, an authenticated VRC Eye peer is not automatically an authenticated VRChat world administrator.

For shared or sensitive actions, the helper needs an independently appropriate authorization and interaction model. Where that cannot be established adequately, the feature should remain local, read-only, or restricted to a deliberately configured test environment.

F. The helper must be optional in both directions
A world without the helper should remain usable.

VRC Eye without a helper should retain notes, profiles, reports, observed diagnostics, and test management.

A helper-equipped world should not malfunction because the companion is absent.

G. Keep the first helper small
I would begin with build identity, named log events, local test bookmarks, a few declared read-only values, and safe local controls.

Deeper Unity integration and complex shared control should remain later capabilities rather than prerequisites for the entire creator workspace.

21. Creator-defined world controls
These should be generated from a constrained control manifest, so VRC Eye can present useful UI without understanding the internals of every world.

Controls need types and constraints
A control declaration should include its identifier, label, description, value type, permitted range or options, current-state availability, scope, and requirements.

For example:

Control	Type	Scope
Local diagnostic labels	Toggle	Local
Lighting test preset	Selection	Declared local or shared scope
Test checkpoint	Selection	Local participant
Round test action	Button	Shared test state
Debug output level	Selection	Helper diagnostics
The UI should never have to guess whether a slider affects everyone.

State-setting is safer than ambiguous toggling
Where possible, prefer “Set debug labels to Off” over “Toggle debug labels.”

A repeated state-setting request can be easier to handle safely than a repeated toggle. The control contract should explicitly declare whether retrying is safe.

Track the full command lifecycle
A control should distinguish:

Requested → sent → accepted → applied → independently observed, with failure or timeout states where appropriate.

“Sent” does not mean “everyone in the instance saw the result.”

Scope permission narrowly
Someone might be allowed to submit observations and operate local test controls without being allowed to alter shared round state.

Creator Mode, Advanced Mode, or Developer Mode should not bypass that distinction.

Unknown control types should be shown as unsupported—not converted into a generic execute button.

22. World-side debug/reset controls intentionally exposed by the creator
The word reset is dangerously ambiguous in software design.

This feature should require every reset action to explain exactly what it resets and what it leaves alone.

Separate reset categories
I would distinguish local visual reset, local diagnostic reset, subsystem reset, shared round reset, and persistent-data operations.

A button labeled “Reset World” should be avoided unless the creator can define that phrase precisely.

Resetting a game round is not the same as restarting the VRChat instance, reloading the uploaded world, or clearing saved player progress.

Resets should use explicit contracts
A shared reset should declare its affected systems, required role, preconditions, expected result, retry behavior, and whether it is reversible.

For example:

“Reset the current test round. This affects the shared round state and test props. It does not clear saved progress.”

Handle duplicates and lost acknowledgements
A timeout should not cause VRC Eye to blindly resend a non-repeatable action.

The helper protocol should support request identifiers and, where feasible, an expected state revision. A duplicate should be recognized instead of silently performing the operation again.

Reset only what can actually be restored
The creator can implement a routine that reconstructs selected world state. That does not imply that every engine condition, failed behavior, or external dependency can be repaired live.

A failed reset should therefore end in an explicit failure or partial-result state, not an unconditional green checkmark.

Shared effects need shared-state design
VRChat’s networking model distinguishes transient events from synchronized state, and late joiners do not receive a replay of past network events. A reset that changes lasting world state must account for that distinction. 

III. Twenty-two additional creator features I would add
These are the additions I think would make the original list feel like a coherent testing and maintenance system rather than a diagnostics toolbox.

23. Reproduction recipes and guided test runs
A reproduction recipe is more detailed than a checklist item.

It records the exact starting conditions and ordered actions needed to reproduce a problem.

For example:

Start from a fresh test state.
Open the first door.
Change the lighting preset.
Have a second participant join.
Compare the reported door and lighting states.

The runner would guide participants through those steps, timestamp each completed action, and attach the resulting evidence to one run.

The important distinction is between human-performed steps, helper-confirmed steps, and automated steps. VRC Eye should not pretend a manual instruction was executed just because it displayed it.

Recipes should support expected failures, optional branches, timeouts, and stop conditions.

This would make a bug report directly reusable as a verification procedure after a fix, without relying on somebody remembering the original sequence.

24. Baseline management and regression comparisons
The version-history feature records what happened. A baseline manager determines what comparisons are meaningful.

A creator could designate a particular run as:

“Known-good reference for desktop interaction tests.”

Another could serve as the mobile performance baseline.

VRC Eye would then compare later runs against the appropriate reference rather than whichever run happened most recently.

The comparison should include new errors, recurring errors, changed measurements, missing test coverage, and configuration differences.

Crucially, it should be able to reject a misleading comparison:

“These runs used different graphics settings and different test routes.”

A regression finding should distinguish a repeatable difference from a single noisy observation.

I would also support accepted regressions: a creator may knowingly trade additional rendering cost for a new feature. The decision should record the reason and affected target, rather than hiding the change.

25. Dedicated late-join and resynchronization testing
Join/leave debugging shows the sequence. This feature would deliberately test whether world state converges correctly.

The creator would declare selected expected states: the current round, door positions, chosen environment preset, enabled systems, or other relevant world-defined values.

VRC Eye would compare what opted-in participants report after a late join.

It should allow a settling period and distinguish:

Not yet received · received but mismatched · matched · no observation available.

This is important because a temporary difference immediately after arrival is not necessarily a lasting defect.

VRChat documents that late joiners receive current synchronized-variable values and ownership information, while past events are not replayed. That gives this test a specific purpose: finding systems that accidentally rely on historical actions instead of reconstructible state. 

The report could identify the first state that failed to converge and link it to the responsible creator-declared subsystem.

26. Ownership, master-change, and suspension tests
A world should not only be tested while the first participant remains active and connected.

I would add guided tests for object-owner departure, master changes, participant suspension, resumption, and interrupted control ownership.

Each test would ask a concrete question:

Does the system recover without requiring the original participant to return?

The helper could emit ownership transitions for selected objects and indicate whether a recovery routine ran.

VRC Eye should avoid assuming that being master is a permanent role or a suitable permission check. It should also account for suspension as a distinct condition: VRChat documents that suspended devices do not run Udon code or respond to network events until the application resumes. 

Tests should be performed through normal participant behavior or controlled editor simulations, not by interfering with unrelated network traffic.

A failure should identify the system that remained dependent on an unavailable participant.

27. Network budget and congestion analyzer
This would focus on the world’s declared networking activity, not just whether the internet connection seems responsive.

With helper instrumentation, VRC Eye could correlate selected actions with outbound queue growth, serialization size, update frequency, and recovery time.

The useful output would be something like:

“This test action produced a sustained queue increase in the instrumented scoreboard system.”

That is more actionable than “network bad.”

VRChat exposes Udon network statistics and documents bandwidth-related limits and different behavior under congestion. VRC Eye should keep those limits versioned and distinguish documented constraints from a creator’s own budgets. 

I would also separate three unrelated measurements:

VRC Eye peer-service latency, observed VRChat synchronization behavior, and world-helper command completion time.

A fast Hamachi or relay connection between two companions does not prove that a world’s Udon synchronization is healthy.

28. Persistence and save-data test lab
Persistence deserves its own test area because a world can behave perfectly in one session and fail when somebody returns.

The lab would define controlled cases for a new participant, returning participant, changed save schema, missing optional values, interrupted initialization, and explicitly reset test data.

The most important UI rule is to identify the storage environment.

VRChat documents different persistence behavior for uploaded worlds, local Build & Test sessions, and ClientSim. VRC Eye should not treat those environments as interchangeable. 

A test record should identify which schema version was expected, whether restoration completed, what migration path ran, and whether the final state was verified.

Sensitive values should be excluded unless explicitly selected. Often the useful evidence is “key present with expected type,” not the full saved content.

Destructive persistence tests should use isolated test data or a separate testing environment wherever possible. “Reset current round” must never silently become “erase saved progress.”

29. Accessibility and interaction audit
I would make this a structured testing area, not an automatic accessibility score.

The audit would cover seated and standing interaction, controller and desktop input, left/right usability, readable text, non-color-only signals, subtitles or visual equivalents where relevant, and access to essential controls.

The creator could define required interactions and ask testers whether they can complete them under specific conditions.

VRC Eye should record the condition without requiring a person to disclose a diagnosis.

For example:

“Tested using seated play with reduced reach.”

The optional Unity integration could assist with measurable checks such as interface dimensions or declared interaction distances, but human evaluation remains necessary.

The useful result is an issue tied to a concrete interaction:

“The reset control is reachable from standing play but could not be activated during the seated test.”

A creator should be able to promote these findings into release-blocking requirements.

30. Spawn, collision, and locomotion audit
This would organize testing around the first moments in the world and the places where movement can fail.

The checklist would cover each intended spawn point, respawn behavior, blocked exits, unintended collision gaps, stations, moving platforms, and transitions between locomotion states.

A route-based test could record which areas were visited and where the tester marked a problem.

Without helper support, the creator could select named locations manually. With support, the world could expose stable zone identifiers and intended checkpoint locations.

The audit should distinguish world behavior from client-specific behavior by supporting reference tests and multiple environments.

A useful issue is:

“At checkpoint B, desktop interaction leaves the player unable to exit the station through the expected control.”

That is more precise than “movement broken.”

The feature should not need to force other participants around the world. Each tester can follow the route or use an intentionally exposed local checkpoint action.

31. Lighting, shader, and reflection investigator
This would connect visual complaints to repeatable rendering conditions.

The creator could define comparison presets such as standard lighting, reduced effects, reflections enabled, and reflections disabled.

A test would record which preset was active and preserve paired observations.

The optional project integration could attach relevant manifest information: intended shader variants, reflection settings, lighting configuration, and target-specific differences.

However, external VRC Eye should not claim it can discover every material, draw call, or shader cost in an arbitrary running world.

The key feature is controlled comparison:

Same viewpoint, same build, same test conditions, one declared setting changed.

Screenshots could be attached manually or through an explicitly enabled capture source.

A finding should distinguish “visually different,” “outside the creator’s expected appearance,” and “associated with a measured performance change.” Those are separate outcomes.

32. Audio, video, and external-dependency diagnostics
Many apparent world failures involve a dependency rather than the world’s basic logic.

I would add a diagnostic view for creator-declared media players, remote configuration, images, and other external resources.

For each request, it could distinguish not requested, requested, blocked by configuration, loading, failed, and ready, but only where the underlying source exposes that state.

The test matrix should include unavailable resources and users who retain default URL restrictions.

VRChat documents separate behavior and restrictions for video players, including request rate limiting and differences between editor and client playback. These are reasons to test the actual intended environment rather than infer success from an editor preview. 

Private or token-bearing URLs should be redacted in reports.

The tool should also test graceful failure: does the world remain usable when a video or remote text resource never loads?

33. Cross-platform semantic parity checker
The platform build checker asks whether builds exist and have been tested.

This additional feature asks:

“Do the builds agree on the parts of the world that are supposed to behave the same?”

A project-side manifest could compare declared networking objects, control IDs, test assertions, persistence schema, game-state definitions, and essential interaction points.

Visual assets may intentionally differ between targets. Shared-state contracts often should not.

The creator should be able to mark a difference as intentional and explain it.

For example:

“Decorative particles are omitted on this target; shared round-state declarations are unchanged.”

VRChat provides a Network ID Utility for inspecting and managing network IDs. An optional integration could incorporate relevant project-side information rather than trying to infer parity from world names or upload timestamps. 

A mismatch should block only the tests or controls it actually affects, rather than declaring the entire world unusable.

34. Spatial performance maps and repeatable test routes
A population graph explains when something happened. A spatial test map explains where.

The creator could define named zones and routes through the world, then associate local observations with those zones.

For a solo creator, this could be entirely manual: choose “Main hall,” run the measurement, and attach the result.

With helper support, declared zone transitions could be recorded automatically.

A map should show sample coverage as well as results. A room visited once should not look as well-characterized as a route tested repeatedly.

I would avoid automatically collecting other participants’ detailed movement. Their contribution should be explicitly opted in, and coarse zone summaries will often be enough.

The repeatable-route feature is particularly useful for regression testing: the same route through the same build configuration gives comparisons a meaningful structure.

35. Multi-tester coordination and synchronized evidence
This is where the World Creator workspace should connect to our VRC Eye-to-VRC Eye plans.

A playtest session could distribute a checklist, identify intended builds, assign temporary roles, coordinate countdowns, and collect selected results.

The roles might include host, observer, late joiner, mobile tester, or recorder.

They should remain playtest roles, not implied VRChat privileges.

Each participant chooses which categories to share: test completion, bookmarks, selected metrics, or diagnostic excerpts.

The creator should see source coverage clearly:

“Four participants submitted results; two supplied diagnostic measurements.”

That is not equivalent to complete visibility into every person in the instance.

The session should continue usefully through peer disconnections. Local evidence can be preserved and offered for sharing after reconnection, but private content must not suddenly upload simply because a connection becomes available.

Networking itself should remain in the existing Networking category and shared peer services, not be reimplemented inside Creator Mode.

36. Opt-in tester feedback and issue triage
Testers often describe symptoms in ordinary language. The creator needs a way to turn that into actionable evidence without demanding that everyone understand Udon.

I would add a simple feedback form with:

What happened? What did you expect? What were you doing? Did it happen again?

The form could attach the current test step and a user-selected bookmark.

A tester should preview what is sent.

On the creator side, feedback could be grouped into possible duplicates while preserving the original reports. Two people saying “the button does nothing” may be describing the same issue—or different buttons.

The triage interface should distinguish confirmed duplicate, related report, and unresolved similarity.

A useful addition would be a follow-up test request that asks the tester to repeat a specific safe procedure and submit the result, rather than opening unrestricted remote troubleshooting access.

37. Creator-defined health assertions
Instead of trying to infer every defect from errors, the world could deliberately state important conditions that should remain true.

Examples might include:

Exactly one round state is active.
Every registered test door has a valid controller.
The displayed score matches the declared round result.
All required initialization checkpoints completed.

These would be creator-defined assertions, not assumptions invented by VRC Eye.

An assertion should identify its scope, evaluation timing, failure severity, and evidence payload.

The design needs transient states. A condition may be allowed to remain unresolved briefly during initialization before becoming a failure.

Assertions should also have a cost budget. A diagnostic routine should not continuously scan the entire world every frame without justification.

This feature would turn many silent failures into named, reproducible findings while still leaving the creator in control of what “healthy” means.

38. Resilience and controlled failure-mode tests
A mature world should be tested when optional systems fail.

I would add scenarios for companion disconnect, helper timeout, missing optional configuration, unavailable media, interrupted peer sharing, and delayed participant confirmation.

The important boundary is where the failure is introduced.

VRC Eye can simulate failures in its own adapters, or the creator can expose a test switch in a private testing build. It should not manipulate unrelated players’ traffic or destabilize public sessions.

Each scenario should have an expected recovery behavior:

Continue without the optional feature.
Show a clear unavailable state.
Stop a test safely.
Retry only an explicitly repeatable operation.

The result should include whether the system recovered automatically, required a manual action, or remained in an invalid state.

This would also test VRC Eye itself: losing a helper connection should not erase the creator’s notes or report a reset as successful.

39. Release-readiness and staging workspace
I would add a release page that assembles evidence rather than inventing a universal quality score.

A release candidate could require selected checks: intended platform builds present, essential interactions tested, no unresolved blocking assertions, reviewed metadata, and no accidentally enabled test-only controls.

The creator chooses the requirements.

A separate staging-world association would be useful, but it must remain explicit. VRC Eye should never assume that two similarly named worlds are a staging/production pair.

The workspace could preserve an approval record:

“Approved for release under these known limitations.”

This is especially valuable for collaborations.

Publication still remains a separate confirmed operation. Completing the checklist should not automatically publish the world.

Likewise, a failed advisory check should not falsely imply that VRChat has rejected the content. It is a creator-defined release decision.

40. Local known-issue and diagnostic knowledge base
Over time, VRC Eye will accumulate repeated error patterns and their resolutions.

I would make that information searchable within the creator’s own projects.

An issue entry could connect an error signature, affected builds, reproduction recipe, confirmed cause, attempted fixes, and the test that verified resolution.

When the pattern returns, VRC Eye could say:

“This resembles a previously recorded issue. Here is the earlier evidence and fix.”

It should not automatically declare the causes identical.

Rules should be explainable and editable. A deterministic local matcher is useful before any more elaborate analysis system is introduced.

Any optional online analysis of private logs or source excerpts should require a separate disclosure and permission step.

The strongest version of this feature becomes the creator’s maintenance memory: not just what failed, but what was tried and what actually worked.

41. Asset, dependency, and attribution inventory
An optional project manifest could record important packages, prefab versions, dependencies, and creator-maintained attribution information.

The immediate benefit is reproducibility:

“This build used this version of the video system and this helper protocol.”

When a dependency changes, VRC Eye could identify which tests should be repeated.

The attribution portion would be a recordkeeping tool. It could flag missing credit text or unresolved provenance notes, but should not pretend to provide definitive legal clearance.

This should remain based on the creator’s supplied project information, not extraction of other people’s worlds or assets.

I would also track dependency ownership: who in a collaboration is responsible for maintaining a particular subsystem, and whether its documentation or source is available.

That helps prevent a world from becoming impossible to maintain after one collaborator leaves.

42. Localization and first-time-user testing
A world can function technically while still being confusing to someone arriving for the first time.

I would add onboarding tests for finding essential controls, understanding the objective, recognizing interactive objects, locating accessibility settings, and recovering from a mistaken action.

Localization records could track which visible text has been reviewed in each supported language.

The system should distinguish translated, reviewed, and tested-in-context. A translated string may still be truncated or positioned poorly in the actual interface.

A first-time-user test should avoid giving the participant instructions that ordinary visitors would not receive.

The result could be:

“The participant completed the setup, but only after the host explained an unlabeled control.”

That is not a code failure, yet it is a valuable creator finding.

This also ties directly to description templates and in-world help content.

43. Debug exposure and permission audit
Before a release, VRC Eye should help the creator inspect what diagnostic functionality remains exposed.

The audit would review helper controls, verbose logging, external dependencies, test-only UI, shared-state actions, and any public debugging configuration that the selected integration can actually read.

A public-build warning might say:

“This manifest still declares a shared round-reset test action.”

It should then show the action’s stated authorization requirements, rather than assuming its presence is automatically unsafe.

VRChat distinguishes restricted world debug views and allows creators to enable World Debugging for other users. VRC Eye should surface that setting when available and make clear that its own Creator Mode does not grant access to restricted built-in views. 

The audit should also check the companion side: whether exported reports include sensitive fields, whether a shared profile enables more collection than expected, and whether controls remain enabled after leaving the intended test session.

44. World-specific Black Box and long-session stability testing
This is where the creator tools should connect directly to our broader Black Box/Crash Diagnostics plans.

The world-specific Black Box would keep a bounded local history of selected events, measurements, test actions, and helper observations.

When you mark an incident—or when an available diagnostic source reports a relevant failure—it preserves the surrounding evidence according to the capture policy.

It should not promise to know the exact cause of every crash. Sometimes the final record will simply show that the process ended unexpectedly and that no more detailed evidence was available.

Long-session tests
A soak-test profile could monitor whether selected measurements drift over time, errors accumulate, helper queues stop draining, or repeated interactions leave the world in an unexpected state.

The report should distinguish ordinary growth from a suspected leak; repeated controlled observations are needed before assigning a cause.

The recorder must stay bounded
Retention, disk usage, sampling rates, and event volume should have explicit limits.

The recorder should also report dropped samples and its own overhead. A diagnostic tool that silently exhausts resources would undermine the very tests it is supposed to support.

IV. How all of these features should share data internally
The most important implementation decision is that these features should not each maintain their own incompatible version of “the current world” or “the active test.”

I would organize the creator system around a small set of shared records.

The World record
This identifies the published world when known, its local project associations, cached metadata, and creator-workspace preferences.

It should not be confused with a running instance.

The Build record
This identifies a particular artifact or declared revision, including target platform, known project information, helper manifest, and upload evidence.

A creator-assigned release label can group several platform builds without pretending they are identical artifacts.

The Test Run record
This binds together the selected build, profile snapshot, checklist version, observation window, participants, evidence sources, and outcome.

A test run should remain reproducible after the saved profile is edited.

The Observation record
Every observation should preserve:

Source · scope · event time · receipt time · units where applicable · quality/coverage · associated world/build/run.

This is how VRC Eye avoids confusing a tester’s report with a local measurement or a helper-declared assertion.

The Issue record
An issue connects observations to a tracked problem, reproduction recipe, proposed resolution, and verification evidence.

The Control Request record
A control request needs its intended world/instance/build context, operation identifier, parameters, permission decision, request ID, and lifecycle state.

This prevents the Controls page, overlay, peer requests, and test runner from each inventing their own execution rules.

One crucial consequence
A single incident could then appear naturally in several places without being duplicated:

Dashboard alert → timeline interval → bookmark → issue → failed checklist step → release blocker → exported report.

That is the connection that makes this feel like one product.

V. The privacy and connection model I would use
Your local/private-mode direction should apply to Creator Mode just as strongly as it applies to VRC Eye profiles and peer features.

Local work should stay local by default
Notes, drafts, captured history, profiles, and reports should not require a relay account.

Opening a creator workspace should not announce your presence to other users or make unpublished-world information discoverable.

“Local-only VRC Eye mode” refers to the companion’s storage and sharing behavior; it should not be presented as a claim that VRChat itself is operating offline.

Sharing should be scoped by category
A playtest session should let a participant share checklist results without sharing logs, or share an anonymized metric summary without sharing hardware details.

World authors should not automatically receive more private information simply because they authored the world.

Connection should not imply delayed publication
A private note created while disconnected should remain private after reconnecting.

VRC Eye can offer selected records for sharing, but should not interpret connectivity as consent.

Revocation needs honest limits
Stopping future collection or sharing should be straightforward.

Deleting a local report should not claim to erase copies that another participant already received.

Networking choices should remain transport choices
LAN, Hamachi, a relay, or another supported VRC Eye networking route changes how peer messages travel.

It does not change what a world helper can do, what VRChat exposes, or what another participant has permitted.

VI. The order I would prioritize
I would not start by building the most powerful world-control system.

The highest-value foundation is the part that helps creators immediately while preserving the optional nature of deeper integration.

Stage	Main deliverable	Why this order makes sense
1. Local creator workspace	Contextual World tab, notes, TODOs, checklists, profiles, bookmarks, manual build history	Useful without servers, helpers, or deep Unity integration
2. Observed diagnostics	Log filtering, error timeline, population history, evidence-backed dashboard, reports	Makes ordinary tests easier to understand and document
3. Reproducibility and comparisons	Recipes, immutable run records, baselines, regression analysis, release evidence	Turns observations into repeatable verification
4. Optional peer playtests	Shared checklists, roles, selected evidence, synchronized timelines	Builds on the shared VRC Eye networking system
5. Minimal world helper	Build identity, structured events, assertions, a few safe local controls	Adds depth without immediately creating a broad command surface
6. Optional project integration	Build manifests, source mappings, platform parity, supported SDK workflows	Preserves the earlier decision not to make deep Unity integration a near-term prerequisite
7. Advanced intentional controls	Carefully scoped shared actions and reset contracts	Built only after identity, permissions, evidence, and command handling are mature
Publication-related write operations can be introduced when their chosen adapter is ready; they should not block the local metadata-drafting tools.

VII. What a complete creator session could look like
Here is how these systems should come together in practice.

You enter your own world. VRC Eye recognizes the author match and offers the creator workspace. The identity strip shows the world, the active instance, and whether the loaded build is actually identified.

You choose a saved late-join test profile. VRC Eye creates an immutable run record and begins collecting the permitted local evidence.

Your tester joins the VRC Eye playtest session and chooses to share checklist results and selected helper observations, but not their raw log.

The test runner asks you to change a declared world state, then asks the tester to join the VRChat instance.

The helper reports that your local state is correct. The tester’s declared assertion reports a mismatch after the settling period.

VRC Eye marks the test as failed, preserves the relevant interval, and offers an issue containing the exact recipe and evidence. It does not claim the tester caused the problem.

You return to Unity, make a change, and record a new build. The previous failure automatically becomes a suggested verification test for that build.

The retest passes. The issue changes to Verified fixed in this build, while the earlier failure remains in history.

The release workspace shows that desktop late-join behavior is verified, but the corresponding mobile test is still outstanding. You decide whether to continue testing or release with a documented limitation.

Finally, you export a collaborator report containing the relevant results—not your unrelated private notes, every participant’s identifiers, or the entire contents of your diagnostic folder.

That is the end-to-end experience I would aim for.

The central idea
VRC Eye Creator Mode should help you know which world and build you are testing, what actually happened, what remains uncertain, how to reproduce a problem, and whether the next build truly fixed it.

The optional helper should then add a carefully bounded capability:

Your world can explain selected parts of itself to VRC Eye and expose only the controls you deliberately designed it to expose.

