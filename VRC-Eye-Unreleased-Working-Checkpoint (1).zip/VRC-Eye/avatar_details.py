"""Dates from avatar metadata and explicitly supplied platform download sizes."""

import json
import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from avatar_links import parse_avatar_reference


PLATFORMS = (("pc", "PC", "standalonewindows"), ("ios", "iOS", "ios"),
             ("android", "Android", "android"))
MAX_JSON_BYTES = 2 * 1024 * 1024
MAX_SIZE = 2 ** 53 - 1


def normalize_avatar_timestamp(value) -> str:
    """Validate dates and normalize zoned timestamps to UTC; reject sentinels."""
    if not isinstance(value, str) or not value.strip():
        return ""
    value = value.strip()
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            parsed = date.fromisoformat(value)
            return parsed.isoformat() if parsed.year > 1 else ""
        if not re.match(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}", value):
            return ""
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.year <= 1 or parsed.tzinfo is None:
            return ""
        return parsed.astimezone(timezone.utc).isoformat()
    except (ValueError, OverflowError):
        return ""


def avatar_day(value: str) -> str:
    timestamp = normalize_avatar_timestamp(value)
    return timestamp[:10] if timestamp else "Unknown"


@dataclass(frozen=True)
class DownloadSizes:
    avatar_id: str
    pc: int | None = None
    ios: int | None = None
    android: int | None = None
    source: str = "User entered"
    recorded_at: str = ""
    avatar_updated_at: str = ""
    stale: bool = False
    platform_sources: tuple[str, str, str] = ("", "", "")


def parse_download_size(value: str) -> int | None:
    """A blank is unknown. Unitless input means bytes; MB and MiB are distinct."""
    value = value.strip()
    if not value or value.casefold() == "unknown":
        return None
    if len(value) > 100:
        raise ValueError("The download size is too long.")
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(B|bytes|KB|MB|GB|KiB|MiB|GiB)?", value, re.IGNORECASE)
    if not match:
        raise ValueError("Use a number and unit, such as 42.5 MiB or 44564480 B. Leave unknown sizes blank.")
    multipliers = {"b": 1, "bytes": 1, "kb": 1000, "mb": 1000**2, "gb": 1000**3,
                   "kib": 1024, "mib": 1024**2, "gib": 1024**3}
    try:
        amount = Decimal(match[1]) * multipliers[(match[2] or "b").lower()]
        if not amount.is_finite() or not 0 <= amount <= MAX_SIZE:
            raise ValueError("The download size is outside the supported range.")
        return int(amount.to_integral_value(rounding=ROUND_HALF_UP))
    except InvalidOperation:
        raise ValueError("The download size is not a valid number.") from None


def format_download_size(value: int | None) -> str:
    if value is None:
        return "Unknown"
    if value < 1024:
        return f"{value} B"
    for power, unit in ((3, "GiB"), (2, "MiB"), (1, "KiB")):
        if value >= 1024**power:
            return f"{value / 1024**power:.1f} {unit}"
    return "Unknown"


def format_platform_sizes(record: DownloadSizes | None) -> str:
    return " | ".join(f"{title}: {format_download_size(getattr(record, key) if record else None)}"
                      for key, title, _native in PLATFORMS)


def sizes_are_stale(record: DownloadSizes | None, updated_at: str) -> bool:
    """Compare like-for-like metadata timestamps, never infer missing freshness."""
    if not record:
        return False
    if record.stale:
        return True
    baseline = normalize_avatar_timestamp(record.avatar_updated_at)
    current = normalize_avatar_timestamp(updated_at)
    return bool(baseline and current and baseline != current)


def parse_analysis_sizes(text: str, avatar_id: str, updated_at: str = "") -> DownloadSizes:
    """Import explicit fileSize bytes from VRCX's platform analysis shape.

    VRCX's normal avatar JSON download contains the avatar ref, not this separate
    fileAnalysis object. No size is inferred from unityPackages or other fields.
    """
    reference = parse_avatar_reference(avatar_id)
    if len(text.encode("utf-8")) > MAX_JSON_BYTES:
        raise ValueError("The analysis JSON is too large (maximum 2 MiB).")
    try:
        data = json.loads(text)
    except (ValueError, RecursionError):
        raise ValueError("Choose a valid file-analysis JSON object.") from None
    if not isinstance(data, dict):
        raise ValueError("Expected an object containing platform file-analysis results.")
    supplied_id = data.get("avatarId", data.get("id"))
    if supplied_id is not None:
        try:
            matches = parse_avatar_reference(supplied_id) == reference
        except (ValueError, TypeError, AttributeError):
            matches = False
        if not matches:
            raise ValueError("The JSON avatar ID does not match the selected avatar link.")
    analysis = data.get("fileAnalysis", data)
    if not isinstance(analysis, dict):
        raise ValueError("fileAnalysis must be an object keyed by platform.")
    sizes = {}
    for key, title, native in PLATFORMS:
        record = analysis.get(native)
        if record is None:
            sizes[key] = None
            continue
        if not isinstance(record, dict):
            raise ValueError(f"{title} analysis must be an object containing fileSize in bytes.")
        if record.get("success") is False:
            sizes[key] = None
            continue
        value = record.get("fileSize")
        if value is not None and (type(value) is not int or not 0 <= value <= MAX_SIZE):
            raise ValueError(f"{title} fileSize must be a nonnegative integer number of bytes.")
        sizes[key] = value
    if all(value is None for value in sizes.values()):
        raise ValueError("No platform fileSize values were found. For a standard VRCX avatar export, use Load avatar JSON then Fetch sizes. Otherwise enter known download sizes manually.")
    return DownloadSizes(reference, **sizes, source="Imported analysis (user assigned)",
                         recorded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                         avatar_updated_at=normalize_avatar_timestamp(updated_at))
