"""Optional World Creator adapters; one peer service and one native VR owner.

Every send is a short-lived, explicit disclosure review. Received observations
remain peer reports and cannot satisfy a local test or grant world permissions.
The static SteamVR card has no input or world-control route.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
import ctypes
import hashlib
import json
import math
import os
import re
import textwrap
import time
import uuid

from peer_protocol import validate_payload


SCHEMA = 'vrc-eye-creator-1'
PROVENANCE = 'Reported by a VRC Eye peer; not independently verified.'
SHARE_FIELDS = {
    'run': ('status', 'outcome', 'platform', 'environment', 'step', 'result', 'summary', 'steps'),
    'test_run': ('status', 'outcome', 'platform', 'environment', 'step', 'result', 'summary', 'steps'),
    'checklist': ('steps',),
    'feedback': ('happened', 'expected', 'doing', 'repeated', 'step_id', 'bookmark_id'),
    'issue': ('observed', 'expected', 'repro', 'status', 'platform'),
    'bookmark': ('label', 'note', 'step_id'),
    'observation': ('source', 'scope', 'value', 'unit', 'quality', 'label'),
}
_STATUS = {'Not started': 'TODO', 'In progress': 'IN_PROGRESS', 'Passed': 'PASS',
           'Failed': 'FAIL', 'Not applicable': 'SKIPPED', 'N/A': 'SKIPPED',
           'Blocked': 'TODO', 'Needs verification': 'TODO', 'TODO': 'TODO',
           'IN_PROGRESS': 'IN_PROGRESS', 'PASS': 'PASS', 'FAIL': 'FAIL', 'SKIPPED': 'SKIPPED'}


def _text(value, limit=500):
    if not isinstance(value, str) or len(value) > limit or any(
        (ord(ch) < 32 and ch not in '\n\t') or 0x7f <= ord(ch) < 0xa0 or
        0x202a <= ord(ch) <= 0x202e or 0x2066 <= ord(ch) <= 0x2069 or
        0xd800 <= ord(ch) <= 0xdfff for ch in value
    ):
        raise ValueError('Creator text is invalid or exceeds the sharing limit.')
    return value


def _identifier(value, *, optional=False):
    if optional and value == '':
        return value
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,128}', value):
        raise ValueError('A stable world, build, run or record identifier is required.')
    return value


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def _digest(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def _scalar(value):
    if isinstance(value, str):
        return _text(value, 1200)
    if value is None or type(value) is bool:
        return value
    if type(value) in (int, float) and math.isfinite(value) and abs(value) <= 1e15:
        return value
    raise ValueError('Select a plain-text or numeric field; nested private data is not shareable.')


def _metadata(record, world_id, build_id, run_id):
    if not isinstance(record, dict) or not isinstance(record.get('data'), dict):
        raise ValueError('Choose a saved creator record.')
    if record.get('world_id') != world_id:
        raise ValueError('The selected record belongs to another world.')
    kind = record.get('kind')
    if kind not in SHARE_FIELDS:
        raise ValueError('This record type remains local; select a supported result or feedback record.')
    if kind in ('run', 'test_run') and run_id != record.get('id'):
        raise ValueError('A shared run must retain its own run identifier; it cannot be relabelled as the selected run.')
    data = record['data']
    for key, expected in (('build_id', build_id), ('run_id', run_id)):
        if data.get(key) not in (None, '', expected):
            raise ValueError('The selected record belongs to another build or test run.')
    return dict(schema=SCHEMA, kind=kind, record_id=_identifier(record.get('id')),
                world_id=_identifier(world_id), build_id=_identifier(build_id, optional=True),
                run_id=_identifier(run_id, optional=True))


def _selected_steps(value):
    if not isinstance(value, list) or len(value) > 79:
        raise ValueError('Select a checklist with no more than 79 steps.')
    result = []
    for index, step in enumerate(value):
        if isinstance(step, str):
            step = {'title': step}
        if not isinstance(step, dict):
            raise ValueError('A checklist step is invalid.')
        title = _text(step.get('title', step.get('name', '')), 160)
        if not title:
            raise ValueError('Each shared checklist step needs a title.')
        source_status = _text(step.get('status', 'Not started'), 40)
        if source_status not in _STATUS:
            raise ValueError('A checklist step has an unsupported status.')
        details = {'creator_status': source_status}
        # Choosing steps discloses their preparation and expected outcome, but
        # never arbitrary notes, attachments, paths or private diagnostics.
        for key in ('preparation', 'expected'):
            if key in step:
                details[key] = _text(step[key], 700)
        result.append({'item_id': 'step-' + str(index + 1), 'title': title,
                       'status': _STATUS[source_status], 'description': _json(details)})
    return result


class CreatorPeerCoordinator:
    """Explicit, context-bound adapter over the application's existing service."""

    def __init__(self, peer_service, *, clock=time.monotonic, wall=time.time):
        self.service = peer_service
        self.clock, self.wall = clock, wall
        self._reviews = OrderedDict()
        self._imported = set()
        self._simulation_deadline = 0.

    def available_fields(self, record):
        return tuple(field for field in SHARE_FIELDS.get(record.get('kind'), ())
                     if field in record.get('data', {}) or field == 'steps' and 'items' in record.get('data', {}))

    def preview(self, record, *, world_id, build_id='', run_id='', fields=(), context_token='', peer_ids=()):
        """Build an exact preview; default includes no private free-text fields."""
        metadata = _metadata(record, world_id, build_id, run_id)
        if not isinstance(fields, (list, tuple)) or any(field not in SHARE_FIELDS[metadata['kind']] for field in fields):
            raise ValueError('Choose only the listed shareable fields.')
        fields = tuple(dict.fromkeys(fields))
        data = record['data']
        title = _text(data.get('title', data.get('name', 'Creator ' + metadata['kind'])), 160)
        if not title:
            title = 'Creator ' + metadata['kind']
        identifier = str(uuid.uuid4())
        if metadata['kind'] == 'checklist' or 'steps' in fields:
            kind = 'checklist.snapshot'
            if metadata['kind'] != 'checklist':
                metadata['selected'] = {field: _scalar(data[field]) for field in fields if field != 'steps' and field in data}
            marker = {'item_id': 'creator-context', 'title': 'World / build / run context (not a test)',
                      'status': 'SKIPPED', 'description': _json(metadata)}
            steps = _selected_steps(data.get('steps', data.get('items', []))) if 'steps' in fields else []
            payload = dict(checklist_id=identifier, revision=1, title=title, items=[marker, *steps])
        else:
            kind = 'creator.snapshot'
            metadata['selected'] = {field: _scalar(data[field]) for field in fields if field in data}
            notes = _json(metadata)
            if len(notes) > 2048:
                raise ValueError('Selected content exceeds one peer card. Select fewer fields; nothing was truncated or sent.')
            payload = dict(playtest_id=identifier, revision=1, title=title, phase='World Creator',
                           target=world_id, notes=notes)
        payload = validate_payload(kind, payload)
        snapshot = self.service.snapshot() if self.service is not None else {}
        sessions = {peer['peer_id']: peer.get('session', '') for peer in snapshot.get('peers', []) if peer.get('state') == 'READY'}
        if peer_ids:
            if not isinstance(peer_ids, (list, tuple)) or not 1 <= len(peer_ids) <= 32:
                raise ValueError('Choose one to thirty-two peers.')
            if any(peer not in sessions for peer in peer_ids):
                raise ValueError('Choose connected peers from Networking before reviewing the send.')
            sessions = {peer: sessions[peer] for peer in dict.fromkeys(peer_ids)}
        review = dict(id=str(uuid.uuid4()), kind=kind, payload=payload, context=identifier,
                      world_id=world_id, build_id=build_id, run_id=run_id, fields=list(fields),
                      peer_ids=list(sessions), preview_text=json.dumps(payload, ensure_ascii=False, indent=2))
        self._reviews[review['id']] = dict(review=deepcopy(review), digest=_digest(review),
                                         token=deepcopy(context_token), deadline=self.clock() + 120,
                                         sessions=sessions)
        while len(self._reviews) > 20:
            self._reviews.popitem(last=False)
        return review

    def share(self, review, peer_ids, *, context_token=''):
        """Consume a reviewed card once; disconnected sends are never queued."""
        if self.service is None:
            raise ValueError('VRC Eye peer services are unavailable; local records remain saved.')
        if not isinstance(review, dict):
            raise ValueError('Preview the selected content before sending.')
        saved = self._reviews.pop(review.get('id'), None)
        if not saved or saved['deadline'] <= self.clock() or saved['token'] != context_token or saved['digest'] != _digest(review):
            raise ValueError('The sharing review expired or the context changed. Preview again.')
        if not isinstance(peer_ids, (list, tuple)) or not 1 <= len(peer_ids) <= 32:
            raise ValueError('Choose one to thirty-two reviewed peers.')
        peers = list(dict.fromkeys(peer_ids))
        snapshot = self.service.snapshot()
        current = {peer['peer_id']: peer for peer in snapshot.get('peers', [])}
        if any(peer not in saved['sessions'] or current.get(peer, {}).get('state') != 'READY' or
               current[peer].get('session') != saved['sessions'][peer] for peer in peers):
            raise ValueError('A peer disconnected or its session changed. Preview the disclosure again.')
        if self.clock() < self._simulation_deadline:
            raise ValueError('Creator peer adapter is in the local disconnect drill. Nothing was queued; recover and review again.')
        result = {'sent': [], 'failed': []}
        for peer in peers:
            try:
                result['sent'].append(self.service.send(peer, review['kind'], review['payload'], context=review['context']))
            except ValueError as exc:
                result['failed'].append({'peer_id': peer, 'reason': str(exc)})
        return result

    def _claim(self, message, world_id, build_id, run_id):
        if message.get('direction') != 'incoming' or message.get('status') != 'ACCEPTED':
            return None
        kind, payload = message.get('kind'), message.get('payload', {})
        if kind not in ('creator.snapshot', 'checklist.snapshot'):
            return None
        try:
            payload = validate_payload(kind, payload)
            if kind == 'creator.snapshot':
                raw = payload.get('notes', '')
            else:
                rows = payload.get('items', [])
                if not rows or rows[0].get('item_id') != 'creator-context':
                    return None
                raw = rows[0].get('description', '')
            def unique(pairs):
                out = {}
                for key, value in pairs:
                    if key in out:
                        raise ValueError('Duplicate field')
                    out[key] = value
                return out
            metadata = json.loads(raw, object_pairs_hook=unique,
                                  parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid number')))
            required = {'schema', 'kind', 'record_id', 'world_id', 'build_id', 'run_id'}
            if not isinstance(metadata, dict) or set(metadata) - required - {'selected'} or not required.issubset(metadata):
                return None
            if metadata['schema'] != SCHEMA or metadata['kind'] not in SHARE_FIELDS:
                return None
            if metadata['kind'] in ('run', 'test_run') and metadata['record_id'] != metadata['run_id']:
                return None
            if (metadata['world_id'], metadata['build_id'], metadata['run_id']) != (world_id, build_id, run_id):
                return None
            _identifier(metadata['record_id'])
            if kind == 'checklist.snapshot':
                if metadata['kind'] not in ('checklist', 'run', 'test_run'):
                    return None
                selected = metadata.get('selected', {})
                if not isinstance(selected, dict) or set(selected) - (set(SHARE_FIELDS[metadata['kind']]) - {'steps'}):
                    return None
                data = {'steps': deepcopy(payload['items'][1:]), **{key: _scalar(value) for key, value in selected.items()}}
            else:
                if metadata['kind'] == 'checklist' or payload.get('target') != world_id:
                    return None
                selected = metadata.get('selected', {})
                if not isinstance(selected, dict) or set(selected) - set(SHARE_FIELDS[metadata['kind']]):
                    return None
                data = {key: _scalar(value) for key, value in selected.items()}
            claim = dict(message_id=_identifier(message.get('message_id')), peer_id=_identifier(message.get('peer_id')),
                         world_id=world_id, build_id=build_id, run_id=run_id, kind=metadata['kind'],
                         record_id=metadata['record_id'], title=payload['title'], data=data,
                         provenance=PROVENANCE, locally_verified=False, received_at=message.get('created_at'))
            claim['fingerprint'] = _digest(self._claim_key(claim))
            return claim
        except (ValueError, TypeError, KeyError, RecursionError):
            return None

    def accepted_claims(self, *, world_id, build_id='', run_id='', include_imported=False):
        """Only already-accepted peer messages, for the exact selected context."""
        if self.service is None:
            return []
        result, seen = [], set()
        for message in self.service.snapshot().get('inbox', []):
            claim = self._claim(message, world_id, build_id, run_id)
            if claim:
                key = self._claim_key(claim)
                if (include_imported or key not in self._imported) and key not in seen:
                    seen.add(key)
                    result.append(claim)
        return result

    @staticmethod
    def _claim_key(claim):
        return (claim['peer_id'], claim['record_id'], _digest({key: claim[key] for key in
                ('world_id', 'build_id', 'run_id', 'kind', 'title', 'data')}))

    def import_claim(self, message_id, *, world_id, build_id='', run_id=''):
        """Return one explicitly chosen reported result for the local store."""
        claim = next((item for item in self.accepted_claims(world_id=world_id, build_id=build_id, run_id=run_id)
                      if item['message_id'] == message_id), None)
        if claim is None:
            raise ValueError('Choose an accepted, matching result that has not already been imported.')
        if len(self._imported) >= 10000:
            raise ValueError('This session reached its peer-import limit; restart the creator workspace.')
        self._imported.add(self._claim_key(claim))
        return claim

    def coverage(self, *, world_id, build_id='', run_id=''):
        claims = self.accepted_claims(world_id=world_id, build_id=build_id, run_id=run_id, include_imported=True)
        peers = {claim['peer_id'] for claim in claims}
        measured = {claim['peer_id'] for claim in claims if claim['kind'] == 'observation' and
                    'value' in claim['data'] and 'unit' in claim['data']}
        return {'participants_reporting': len(peers), 'participants_with_measurements': len(measured),
                'scope': 'Accepted selected submissions in this local inbox; not all instance participants.'}

    def simulate_disconnect(self, seconds=30):
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 1 <= seconds <= 120:
            raise ValueError('Choose a drill duration from one to 120 seconds.')
        self._simulation_deadline = self.clock() + seconds
        return self.simulation_state()

    def recover(self):
        self._simulation_deadline = 0.
        return self.simulation_state()

    def simulation_state(self):
        remaining = max(0., self._simulation_deadline - self.clock())
        return {'active': remaining > 0, 'remaining': remaining,
                'scope': 'Creator send adapter only; existing connections and other players are unchanged.',
                'expected_recovery': 'Local evidence survives. Recover, preview and explicitly resend; nothing auto-uploads.'}

    def clear(self):
        self._reviews.clear()
        self._simulation_deadline = 0.


def overlay_payload(payload):
    """Validate the small read-only card schema before native drawing."""
    if not isinstance(payload, dict) or payload.get('enabled') is not True:
        return {}
    placement = payload.get('placement', 'right')
    if placement not in ('head', 'left', 'right', 'dashboard'):
        raise ValueError('Choose head, left, right or dashboard placement.')
    size, opacity, seconds = payload.get('size', .55), payload.get('opacity', .9), payload.get('seconds', 30)
    for value, low, high in ((size, .25, 1.5), (opacity, .2, 1.), (seconds, 1., 120.)):
        if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError('Overlay size, opacity or duration is outside its supported range.')
    return dict(enabled=True, text=_text(payload.get('text', ''), 1000), placement=placement,
                size=float(size), opacity=float(opacity), seconds=float(seconds), reduced_motion=True)


class CreatorOverlayPresenter:
    """Desktop fallback and bounded static card; never connects native inputs."""
    def __init__(self, runtime=None, *, clock=time.monotonic):
        self.runtime, self.clock = runtime, clock
        self._state = {'enabled': False, 'status': 'Desktop creator actions are available.'}
        self._deadline = 0.

    def show(self, context, step='', error='', *, placement='right', size=.55, opacity=.9, seconds=30):
        context, step, error = _text(context, 180), _text(step, 300), _text(error, 300)
        text = 'World Creator · read-only\n' + context
        if step:
            text += '\nStep: ' + step
        if error:
            text += '\nReported error: ' + error
        text += '\nMark incidents and record results on the desktop.'
        payload = overlay_payload(dict(enabled=True, text=text, placement=placement, size=size, opacity=opacity, seconds=seconds))
        snap = self.runtime.snapshot() if self.runtime is not None else {}
        available = snap.get('steamvr_available') is True and hasattr(self.runtime, 'display_creator')
        if available:
            self.runtime.display_creator(payload)
            self._deadline = self.clock() + seconds
            status = 'Read-only card requested on the existing SteamVR connection; desktop actions remain available.'
        else:
            if self.runtime is not None and hasattr(self.runtime, 'display_creator'):
                self.runtime.display_creator({})
            self._deadline = 0.
            status = 'SteamVR is not connected. Use the desktop; connect optional inputs in Wellness to show this card.'
        self._state = dict(enabled=available, status=status, text=text, placement=placement,
                           size=size, opacity=opacity, reduced_motion=True, interactive=False)
        return self.snapshot()

    def snapshot(self):
        state = deepcopy(self._state)
        if state.get('enabled') and self.clock() >= self._deadline:
            state.update(enabled=False, status='Creator card expired. Desktop actions remain available.')
            self._state = deepcopy(state)
        elif state.get('enabled') and (self.runtime is None or self.runtime.snapshot().get('steamvr_available') is not True):
            state.update(enabled=False, status='SteamVR disconnected. Show the card again after reconnecting; desktop actions remain available.')
            self._deadline = 0.
            self._state = deepcopy(state)
        return state

    def clear(self):
        if self.runtime is not None and hasattr(self.runtime, 'display_creator'):
            self.runtime.display_creator({})
        self._deadline = 0.
        self._state = {'enabled': False, 'status': 'Creator overlay hidden; desktop actions remain available.'}
        return self.snapshot()


class CreatorOverlay:
    """Owned exclusively by SteamVRProbe; no init, shutdown, input or controls."""
    def __init__(self, vr):
        self.vr = vr
        self.overlay = None
        self.hud = self.dashboard = self.thumb = None
        self._textures = {}

    def _hide(self):
        if self.overlay is not None:
            for handle in (self.hud, self.dashboard, self.thumb):
                if handle is not None:
                    self.overlay.hideOverlay(handle)

    def draw(self, payload):
        if not payload or payload.get('enabled') is not True:
            self._hide()
            return
        clean = overlay_payload(payload)
        if not clean['text']:
            self._hide()
            return
        vr = self.vr
        if self.overlay is None:
            self.overlay = vr.VROverlay()
        dashboard = clean['placement'] == 'dashboard'
        if dashboard and self.dashboard is None:
            self.dashboard, self.thumb = self.overlay.createDashboardOverlay('vrceye.creator.dashboard.' + str(os.getpid()), 'VRC Eye World Creator')
        elif not dashboard and self.hud is None:
            self.hud = self.overlay.createOverlay('vrceye.creator.' + str(os.getpid()), 'VRC Eye World Creator')
        for handle in ((self.hud,) if dashboard else (self.dashboard, self.thumb)):
            if handle is not None:
                self.overlay.hideOverlay(handle)
        handles = (self.dashboard, self.thumb) if dashboard else (self.hud,)
        for handle in handles:
            self.overlay.setOverlayInputMethod(handle, getattr(vr, 'VROverlayInputMethod_None', 0))
            self.overlay.setOverlayWidthInMeters(handle, clean['size'])
            self.overlay.setOverlayAlpha(handle, clean['opacity'])
            if self._textures.get(handle) != clean['text']:
                buffer = ctypes.create_string_buffer(creator_pixels(clean['text']))
                self.overlay.setOverlayRaw(handle, buffer, 1024, 512, 4)
                self._textures[handle] = clean['text']
        if dashboard:
            # The user opens the dashboard entry; never steal dashboard focus.
            self.overlay.showOverlay(self.thumb)
        else:
            matrix = vr.HmdMatrix34_t()
            for index in range(3):
                matrix.m[index][index] = 1.
            matrix.m[0][3] = {'head': 0., 'left': -.42, 'right': .42}[clean['placement']]
            matrix.m[1][3], matrix.m[2][3] = -.15, -1.3
            self.overlay.setOverlayTransformTrackedDeviceRelative(self.hud, vr.k_unTrackedDeviceIndex_Hmd, matrix)
            self.overlay.showOverlay(self.hud)

    def close(self):
        if self.overlay is not None:
            for handle in (self.hud, self.dashboard, self.thumb):
                if handle is not None:
                    try:
                        self.overlay.destroyOverlay(handle)
                    except Exception:
                        pass
        self.hud = self.dashboard = self.thumb = None
        self._textures.clear()


def creator_pixels(text):
    """Optional raster dependency is imported only by the existing VR worker."""
    from PIL import Image, ImageDraw, ImageFont
    picture = Image.new('RGBA', (1024, 512), (19, 27, 40, 255))
    draw = ImageDraw.Draw(picture)
    font = None
    for name in ('segoeui.ttf', 'DejaVuSans.ttf'):
        try:
            font = ImageFont.truetype(name, 24)
            break
        except OSError:
            pass
    if font is None:
        font = ImageFont.load_default(size=24)
    lines = []
    for part in str(text)[:1000].splitlines():
        lines.extend(textwrap.wrap(part, width=65) or [''])
    if len(lines) > 14:
        lines = lines[:12] + ['… Full details and actions are on the desktop.']
    draw.multiline_text((24, 20), '\n'.join(lines), font=font, fill='white', spacing=8)
    return picture.tobytes()
