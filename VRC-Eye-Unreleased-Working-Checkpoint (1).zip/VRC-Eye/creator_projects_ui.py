"""Selective VCC workspace integrated into the existing sidebar and job lifecycle."""
from __future__ import annotations

from text_viewport import window_body
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess

from companion_ui import Page, Table, button, choice, entry, line
from creator_projects import (ProjectStore, inspect_project, discover_projects,
                              read_vcc_candidates, public_report, read_bytes, local_path, assert_no_links)
from creator_project_jobs import (ProjectJobs, OPERATIONS, TEMPLATES, make_plan, make_template_plan,
                                  probe_vpm, tool_digest, run_bounded)
from friendly_ui import ScrollPane
from creator_project_recovery import CreatorRecovery,CopyReview


def review_document(app, title, text, accept='Approve'):
    """Scrollable review; no timer and no application-wide Enter binding."""
    result = [False]
    previous = app.root.focus_get()
    window = app.tk.Toplevel(app.root)
    window.title(title)
    window.geometry('860x620')
    window.minsize(430, 300)
    window.transient(app.root)
    frame = app.ttk.Frame(window_body(window), padding=14)
    frame.pack(fill='both', expand=True)
    actions = app.ttk.Frame(frame)
    actions.pack(side='bottom', fill='x', pady=(10, 0))
    def finish(value):
        result[0] = value
        window.destroy()
    cancel = app.ttk.Button(actions, text='Cancel', command=lambda: finish(False))
    cancel.pack(side='left')
    app.ttk.Button(actions, text=accept, command=lambda: finish(True)).pack(side='right')
    box = app.tk.Text(frame, wrap='word', width=70, height=20, padx=10, pady=10)
    scrollbar = app.ttk.Scrollbar(frame, command=box.yview)
    box.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side='right', fill='y')
    box.pack(fill='both', expand=True)
    box.insert('1.0', text)
    box.configure(state='disabled')
    window.bind('<Escape>', lambda event: finish(False))
    window.protocol('WM_DELETE_WINDOW', lambda: finish(False))
    window.grab_set()
    cancel.focus_set()
    app.root.wait_window(window)
    if previous is not None:
        try: previous.focus_set()
        except Exception: pass
    return result[0]


def text_area(page, parent, *, height=10):
    outer = page.ttk.Frame(parent)
    outer.pack(fill='both', expand=True, pady=5)
    text = page.tk.Text(outer, height=height, wrap='word', width=70)
    bar = page.ttk.Scrollbar(outer, command=text.yview)
    text.configure(yscrollcommand=bar.set)
    bar.pack(side='right', fill='y')
    text.pack(fill='both', expand=True)
    text.configure(state='disabled')
    return text


def set_text(widget, text):
    widget.configure(state='normal')
    widget.delete('1.0', 'end')
    widget.insert('1.0', text)
    widget.configure(state='disabled')


class CreatorProjectsPage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, 'Creator Projects')
        self.store = ProjectStore(shell.store)
        self.jobs = ProjectJobs(shell.store.path.parent)
        self.repair = CreatorRecovery(shell.store)
        self.cli = None
        self.editor = None
        self.plan = None
        self.selected_id = None
        self.offset = 0
        self.query = self.tk.StringVar()
        self.context_label = self.tk.StringVar()
        self.tool_label = self.tk.StringVar(value='VPM CLI: not reviewed. Offline project inspection remains available.')
        self.editor_label = self.tk.StringVar(value='Unity editor: not reviewed.')
        self.tabs = self.ttk.Notebook(parent)
        self.tabs.pack(fill='both', expand=True)
        self.frames = {}
        self.panes = {}
        for name in ('Projects', 'Inventory', 'Reviewed changes', 'Templates & tools', 'Activity'):
            frame = self.ttk.Frame(self.tabs)
            self.tabs.add(frame, text=name)
            self.frames[name] = frame
            self.panes[name] = ScrollPane(self.app, frame, min_width=630).body
        self.build_projects()
        self.build_inventory()
        self.build_changes()
        self.build_tools()
        self.activity = text_area(self, self.panes['Activity'], height=18)
        button(self,line(self,self.panes['Activity']),'Recovery history…',self.recovery_history)
        button(self,line(self,self.panes['Activity']),'Show durable copy-job receipts',self.copy_receipts)
        self.copy_jobs=Table(self,self.panes['Activity'],(('operation','Copy job',160),('state','File outcome',230),('catalog','Catalog publication',180)),height=5)
        button(self,line(self,self.panes['Activity']),'Review selected catalog reconciliation…',self.reconcile_copy)
        self.refresh()
        self.status.set('Offline catalog. Nothing is scanned, installed, restored or launched merely by opening this page.')

    def writable(self):
        if self.app.demo or getattr(self.app, 'safe_mode', False):
            raise ValueError('Demo and Safe Mode allow catalog viewing only. Leave these modes before saving, copying or executing tools.')

    def build_projects(self):
        pane = self.panes['Projects']
        self.ttk.Label(pane, text='Only explicitly selected locations are inspected. Missing drives remain catalog records; discovering a project does not establish ownership.', wraplength=850).pack(anchor='w', pady=5)
        row = line(self, pane)
        entry(self, row, self.query, 35).bind('<Return>', lambda event:self.guard(self.search))
        button(self, row, 'Filter', self.search)
        button(self, row, 'Previous', lambda:self.page(-1))
        button(self, row, 'Next', lambda:self.page(1))
        row = line(self, pane)
        button(self, row, 'Add project…', self.add_project)
        button(self, row, 'Discover in folder…', self.discover)
        button(self, row, 'Import VCC path list…', self.import_vcc)
        self.projects = Table(self, pane, (('name','Project',190), ('kind','Kind',110), ('unity','Unity declaration',130), ('state','Evidence state',210)), height=8, select=self.selection)
        row = line(self, pane)
        button(self, row, 'Reinspect selected', self.reinspect)
        button(self, row, 'Forget catalog entry…', self.forget)
        button(self, row, 'Open in reviewed Unity…', self.open_unity)
        self.ttk.Label(pane, textvariable=self.context_label, wraplength=850).pack(anchor='w', pady=6)
        row = line(self, pane)
        self.link_kind = self.tk.StringVar(value='avatar')
        self.link_target = self.tk.StringVar()
        choice(self, row, self.link_kind, ('avatar', 'world'), width=10)
        entry(self, row, self.link_target, 42)
        button(self, row, 'Link ID', self.link)
        self.ttk.Label(pane, text='Links are local associations, not proof of creator rights. They are isolated to the active VRC Eye account, or the local workspace when signed out.', wraplength=850, style='Muted.TLabel').pack(anchor='w', pady=6)

    def build_inventory(self):
        pane = self.panes['Inventory']
        self.ttk.Label(pane, text='Requested, locked and embedded versions are separate observations. Unity cache installation, SDK compatibility and successful compilation are not inferred.', wraplength=850).pack(anchor='w', pady=6)
        self.packages = Table(self, pane, (('name','Package',220), ('manager','Manager',100), ('requested','Requested',110), ('locked','Locked',100), ('installed','Embedded',100), ('state','State',240)), height=10)
        self.details = text_area(self, pane, height=9)
        button(self, line(self, pane), 'Export path-free inventory report…', self.export_inventory)

    def build_changes(self):
        pane = self.panes['Reviewed changes']
        self.ttk.Label(pane, text='Copy jobs create a recovery workspace: raw/ preserves the source and project/ is the editable copy. Package changes are checkpointed for reviewed undo. A restore is not a general update; Unity validation is still required.', wraplength=850).pack(anchor='w', pady=6)
        self.operation = self.tk.StringVar(value='Copy only')
        self.package = self.tk.StringVar()
        self.package_version = self.tk.StringVar()
        self.destination = self.tk.StringVar()
        for label, variable in (('Package identifier (set/remove)',self.package), ('Exact version (set only)',self.package_version), ('New recovery workspace folder (working copy in project/)',self.destination)):
            self.ttk.Label(pane,text=label).pack(anchor='w', pady=(8,2))
            self.ttk.Entry(pane,textvariable=variable).pack(fill='x')
        row=line(self,pane)
        choice(self,row,self.operation,OPERATIONS,width=24)
        button(self,row,'Choose destination parent…',self.choose_destination)
        row=line(self,pane)
        button(self,row,'Prepare review',self.prepare)
        button(self,row,'Execute reviewed job…',self.execute)
        self.review_box=text_area(self,pane,height=12)
        for variable in (self.operation,self.package,self.package_version,self.destination):
            variable.trace_add('write',lambda *args:self.invalidate())
        self.invalidate()

    def build_tools(self):
        pane=self.panes['Templates & tools']
        self.ttk.Label(pane,textvariable=self.tool_label,wraplength=850).pack(anchor='w',pady=5)
        button(self,line(self,pane),'Review installed VPM CLI…',self.choose_cli)
        self.ttk.Label(pane,text='VPM is optional. It is not downloaded or updated by VRC Eye. CLI operations may update their own caches or settings. vrc-get, automatic migration, in-place changes and remote publishing are not enabled in this checkpoint.',wraplength=850,style='Muted.TLabel').pack(anchor='w',pady=5)
        self.ttk.Separator(pane).pack(fill='x',pady=10)
        self.ttk.Label(pane,textvariable=self.editor_label,wraplength=850).pack(anchor='w')
        button(self,line(self,pane),'Review installed Unity editor…',self.choose_editor)
        self.ttk.Label(pane,text='Opening a project requires an exact match between its declared editor version and the reviewed editor version. This is not an SDK compatibility guarantee.',wraplength=850,style='Muted.TLabel').pack(anchor='w',pady=5)
        self.ttk.Separator(pane).pack(fill='x',pady=10)
        self.template=self.tk.StringVar(value='Avatar')
        self.template_destination=self.tk.StringVar()
        self.ttk.Label(pane,text='Create from an installed VPM template',style='Heading.TLabel').pack(anchor='w')
        choice(self,line(self,pane),self.template,TEMPLATES)
        self.ttk.Label(pane,text='New absolute destination folder (must not exist)').pack(anchor='w',pady=(8,2))
        self.ttk.Entry(pane,textvariable=self.template_destination).pack(fill='x')
        button(self,line(self,pane),'Review template creation…',self.create_template)
        self.ttk.Label(pane,text='These are documented template names, not a claim they are installed locally. Template availability and dependencies are determined by your reviewed CLI.',wraplength=850,style='Muted.TLabel').pack(anchor='w',pady=5)
        self.ttk.Separator(pane).pack(fill='x',pady=10)
        self.ttk.Label(pane,text='Optional Unity editor package',style='Heading.TLabel').pack(anchor='w')
        button(self,line(self,pane),'Export VRC Eye Editor Core package…',self.export_editor_package)
        button(self,line(self,pane),'Import a local editor report…',self.import_editor_report)
        self.ttk.Label(pane,text='Export saves a package; it does not install it. The editor-only helper exports an explicitly requested local report. Live pairing, background listeners, build control and publishing are not enabled.',wraplength=850,style='Muted.TLabel').pack(anchor='w',pady=5)

    def current_account(self):
        client=self.app.api
        return getattr(client,'user_id','') if client and getattr(client,'authenticated',False) else ''

    def current(self):
        if not self.selected_id:raise ValueError('Select a project first.')
        return self.store.get(self.selected_id)

    def search(self):
        self.offset=0;self.refresh()

    def page(self,direction):
        self.offset=max(0,self.offset+100*direction);self.refresh()

    def refresh(self):
        records=self.store.list(self.query.get(),self.offset)
        self.projects.set(records,lambda row:(row['label'],row['kind'],row['unity'] or 'Unknown',row['state']))
        for key,record in self.projects.records.items():
            if record['id']==self.selected_id:self.projects.tree.selection_set(key)

    def selection(self):
        record=self.projects.selected()
        if not record:return
        if record['id']!=self.selected_id:self.invalidate()
        self.selected_id=record['id']
        self.show_record(record)

    def show_record(self,record):
        links=self.store.links(record['id'],self.current_account())
        self.context_label.set('Selected path: '+record['path']+'\nLink scope: '+(self.current_account() or 'Local workspace')+'\nLinks: '+(', '.join(item['entity'] for item in links) or 'None'))
        self.packages.set(record['packages'],lambda p:tuple(p.get(k,'') or '—' for k in ('name','manager','requested','locked','installed','state')))
        set_text(self.details,json.dumps(public_report(record),ensure_ascii=False,indent=2))
        receipts=[r for r in self.store.receipts(record['id']) if not r.get('account') or r['account']==(self.current_account() or 'shared')]
        set_text(self.activity,json.dumps(receipts,ensure_ascii=False,indent=2))

    def add_paths(self,paths,issues=()):
        self.writable()
        if not paths:
            self.status.set('No supported project paths found. '+' '.join(issues));return
        # Explicit review precedes project-file inspection and catalog writes.
        preview='Add and inspect these local project locations?\n\n'+'\n'.join(paths)+'\n\n'+'\n'.join(issues)+'\n\nNo Unity launch, dependency download or project-file write will occur.'
        if not review_document(self.app,'Review project locations',preview,'Add selected locations'):return
        def work(client,stop,progress):
            added=[];errors=[]
            for path in paths:
                if stop.is_set():break
                try:
                    snapshot=inspect_project(path,stop=stop)
                    added.append(self.store.save(snapshot))
                except (ValueError,OSError):errors.append(path)
                progress(f'Cataloged {len(added)} / {len(paths)} projects')
            return added,errors
        def done(result):
            self.refresh()
            self.status.set(f'Added/refreshed {len(result[0])} projects; {len(result[1])} locations could not be inspected. Original files unchanged.')
        self.start(work,done,api=False)

    def add_project(self):
        self.writable()
        from tkinter import filedialog
        path=filedialog.askdirectory(parent=self.app.root,title='Choose a Unity project')
        if path:self.add_paths([path])

    def discover(self):
        self.writable()
        from tkinter import filedialog
        path=filedialog.askdirectory(parent=self.app.root,title='Search only this folder (three levels, bounded)')
        if path:self.start(lambda c,s,p:discover_projects(path,stop=s),lambda result:self.add_paths(result['paths'],result['issues']),api=False)

    def import_vcc(self):
        self.writable()
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title='Select VCC settings.json (read-only)',filetypes=[('JSON','*.json')])
        if path:self.start(lambda c,s,p:read_vcc_candidates(path),lambda result:self.add_paths(result['paths'],result['issues']),api=False)

    def reinspect(self):
        self.writable();record=self.current();self.invalidate()
        def work(c,s,p):return self.store.save(inspect_project(record['path'],stop=s))
        self.start(work,lambda ref:self.refreshed(ref),api=False)

    def refreshed(self,ref):
        self.selected_id=ref;self.refresh();self.show_record(self.store.get(ref))
        self.status.set('Local project metadata refreshed. No project files were changed.')

    def forget(self):
        self.writable();record=self.current()
        if not self.confirm('Forget project catalog entry','Remove this project and its account links from VRC Eye?\n\n'+record['path']+'\n\nNo project files, backups or receipts are deleted.'):return
        self.store.forget(record['id']);self.selected_id=None;self.invalidate();self.refresh()
        self.context_label.set('No project selected.');self.packages.set([],lambda row:());set_text(self.details,'');set_text(self.activity,'')

    def link(self):
        self.writable();record=self.current()
        self.store.link(record['id'],self.current_account(),self.link_kind.get(),self.link_target.get().strip())
        self.show_record(record);self.status.set('Local account-scoped association saved. Ownership and permissions were not inferred.')

    def invalidate(self):
        if self.job:self.cancel()
        if self.plan:
            if isinstance(self.plan,CopyReview):self.repair.discard(self.plan)
            else:self.jobs.discard(self.plan)
        self.plan=None;self.plan_context=None
        if hasattr(self,'review_box'):set_text(self.review_box,'No active review. Prepare a plan after selecting the source, operation and new destination.')

    def choose_destination(self):
        self.writable();record=self.current()
        from tkinter import filedialog
        parent=filedialog.askdirectory(parent=self.app.root,title='Choose a parent folder outside the original project')
        if parent:self.destination.set(str(Path(parent)/(Path(record['path']).name+'-VRC-Eye-copy')))

    def prepare(self):
        from dashboard_actions import context
        self.writable();record=self.current();self.invalidate()
        self.preparing_context=context(self.app)
        operation=self.operation.get();target=self.destination.get();package=self.package.get().strip();version=self.package_version.get().strip();tool=self.cli
        account=self.current_account() or 'shared'
        self.start(lambda c,s,p:self.repair.prepare(account,record['path'],target,operation,tool=tool,package=package,version=version,stop=s,progress=p),self.prepared,api=False)

    def prepared(self,plan):
        from dashboard_actions import context
        if isinstance(plan,CopyReview) and self.preparing_context!=context(self.app):
            self.repair.discard(plan);raise ValueError('Account or privacy changed while preparing the copy. Prepare a fresh review.')
        self.plan=plan if isinstance(plan,CopyReview) else self.jobs.offer(plan);set_text(self.review_box,plan.review_text())
        self.plan_context=context(self.app)
        self.status.set('Review prepared. No project copy or CLI command has run. Execute only after reviewing the frozen plan.')

    def execute(self):
        from dashboard_actions import context
        self.writable()
        if not self.plan:raise ValueError('Prepare a review first.')
        plan=self.plan;record=self.current();token=self.plan_context
        if token!=context(self.app):raise ValueError('Account or privacy changed after review. Prepare a fresh review.')
        if not review_document(self.app,'Review journaled project copy',plan.review_text(),'Run reviewed job'):return
        if token!=context(self.app):raise ValueError('Account or privacy changed during review. No copy was submitted.')
        self.writable();self.plan=None
        self.run_plan(plan,record['id'],expected_context=token)

    def run_plan(self,plan,ref,*,expected_context=None):
        from dashboard_actions import context
        from account_header import private
        token=context(self.app) if expected_context is None else expected_context
        def guard():
            if self.closed or context(self.app)!=token or private(self.app):raise ValueError('Account, privacy or connection mode changed. Inspect recovery history before retrying.')
            self.writable()
        def work(client,stop,progress):
            if isinstance(plan,CopyReview):
                if plan.review.account!=(self.current_account() or 'shared'):raise ValueError('Account changed after copy review. Prepare a fresh review.')
                receipt,snapshot=self.repair.execute(plan,stop=stop,progress=progress,guard=guard)
            else:receipt,snapshot=self.jobs.execute(plan,stop=stop,progress=progress)
            new_ref=None
            if snapshot and isinstance(plan,CopyReview):
                try:new_ref=self.repair.publish_catalog(receipt,snapshot,origin=ref,stop=stop,guard=guard)
                except (ValueError,OSError,sqlite3.Error):
                    receipt=dict(receipt,message=receipt['message']+' Files remain recorded; catalog publication is pending. Review the durable receipt to reconcile without replaying the tool.')
            elif snapshot:
                if ref:self.store.receipt(ref,receipt)
                new_ref=self.store.save(snapshot)
                self.store.receipt(new_ref,receipt)
            elif ref:self.store.receipt(ref,receipt)
            return receipt,new_ref
        def done(result):
            receipt,new_ref=result
            if new_ref:self.selected_id=new_ref
            self.refresh()
            set_text(self.review_box,json.dumps(receipt,ensure_ascii=False,indent=2))
            self.status.set(receipt['state']+'. '+receipt['message'])
            if self.selected_id:self.show_record(self.store.get(self.selected_id))
        self.start(work,done,api=False,mutation=True)

    def recovery_history(self):
        from recovery_journal_ui import show
        return show(self.shell,account=self.current_account() or 'shared')

    def copy_receipts(self):
        from account_header import private
        if private(self.app):raise ValueError('Reveal private information before reading copy-job receipts.')
        records=self.repair.receipts(self.current_account() or 'shared')
        self.copy_jobs.set(records,lambda r:(r['operation'],r['state'],r.get('catalog_state','Not yet verified')))
        set_text(self.activity,json.dumps(records,ensure_ascii=False,indent=2))

    def reconcile_copy(self):
        self.writable();selected=self.copy_jobs.selected()
        if not selected:raise ValueError('Show durable receipts and select a copy awaiting catalog publication.')
        from dashboard_actions import context
        from account_header import private
        token=context(self.app)
        def guard():
            if self.closed or context(self.app)!=token or private(self.app):raise ValueError('Account or privacy changed during reconciliation.')
            self.writable()
        def prepared(plan):
            guard();value=json.loads(plan.payload)
            text='Reconcile this recorded working copy with the project catalog?\n\n'+value['receipt']['destination']+'\nSHA-256: '+value['receipt']['working_digest']+'\n\nFiles and original baseline are rechecked. Only local catalog records and receipts change; no tool runs and no project file is changed. Unity compilation remains unverified.'
            if not review_document(self.app,'Reconcile creator catalog',text,'Publish catalog entry'):
                with self.repair.journal.mutex:self.repair.journal.plans.pop(plan.id,None)
                return
            guard()
            def done(ref):
                self.selected_id=ref;self.refresh();self.copy_receipts();self.status.set('Catalog entry and publication receipt committed together. No tool replayed.')
            self.start(lambda c,s,p:self.repair.reconcile_catalog(plan,stop=s,guard=guard),done,api=False,mutation=True)
        self.start(lambda c,s,p:self.repair.prepare_catalog_reconcile(self.current_account() or 'shared',selected['id'],stop=s,progress=p),prepared,api=False)

    def choose_cli(self):
        self.writable()
        from tkinter import filedialog
        candidate=shutil.which('vpm')
        path=filedialog.askopenfilename(parent=self.app.root,title='Select your installed vpm executable',initialdir=str(Path(candidate).parent) if candidate else None)
        if not path:return
        if not review_document(self.app,'Trust installed CLI','This will execute the selected local binary with --help and --version:\n\n'+path+'\n\nSelect only an installed VPM CLI you trust. A filename or hash does not certify its publisher. No project restore or package installation is requested by this check.','Inspect this CLI'):return
        self.start(lambda c,s,p:probe_vpm(path,stop=s),self.cli_ready,api=False)

    def cli_ready(self,tool):
        self.cli=tool;self.invalidate()
        self.tool_label.set('Reviewed CLI: '+tool.path+'\nReported version: '+tool.version+'\nHelp-advertised operations: '+', '.join(tool.capabilities)+'\nHash: '+tool.digest)
        self.status.set('CLI help inspected. Real project operations still require a separate review; end-to-end compatibility is unverified.')

    def choose_editor(self):
        self.writable()
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title='Select the installed Unity editor executable')
        if not path:return
        if Path(path).name.casefold() not in ('unity','unity.exe'):raise ValueError('Select the Unity editor executable, not Unity Hub or an installer.')
        if not review_document(self.app,'Trust installed Unity editor','Run this selected Unity executable with -version?\n\n'+path+'\n\nOnly select an installed editor you trust. No project is opened by this version check.','Inspect editor version'):return
        def work(c,s,p):
            digest=tool_digest(path)
            code,text=run_bounded((path,'-version'),cwd=Path(path).parent,stop=s,timeout=30)
            match=re.search(r'\b(\d{4}\.\d+\.\d+[abfp]\d+[a-z0-9]*)\b',text)
            if code!=0 or not match or tool_digest(path)!=digest:raise ValueError('Could not establish a stable exact editor version.')
            return path,digest,match.group(1)
        def done(value):
            self.editor=value;self.editor_label.set('Reviewed Unity: '+value[2]+'\n'+value[0])
        self.start(work,done,api=False)

    def open_unity(self):
        self.writable();record=self.current()
        if not self.editor:raise ValueError('Review an installed Unity editor under Templates & tools first.')
        path,digest,version=self.editor
        if not record['unity'] or record['unity']!=version:raise ValueError('Exact Unity versions do not match. Select the matching editor; this build has no upgrade override.')
        if not review_document(self.app,'Open selected project','Editor: '+version+'\nProject: '+record['path']+'\n\nOpening a project can execute its editor scripts and trigger imports. Only open projects you trust. VRC Eye does not publish content or certify compatibility.','Open in Unity'):return
        self.writable()
        if tool_digest(path)!=digest:raise ValueError('The reviewed editor changed. Inspect it again.')
        fresh=inspect_project(record['path'])
        if fresh['unity']!=version or fresh['state']=='Unavailable':raise ValueError('Project version or availability changed. Inspect again.')
        subprocess.Popen([path,'-projectPath',str(assert_no_links(local_path(record['path'])))],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,shell=False)
        self.status.set('Unity launch submitted. Successful import, compilation or opening has not been confirmed.')

    def create_template(self):
        self.writable()
        from dashboard_actions import context
        token=context(self.app)
        plan=self.repair.prepare_template(self.current_account() or 'shared',self.template_destination.get(),self.template.get(),self.cli)
        if not review_document(self.app,'Review template creation',plan.review_text(),'Create new project'):
            self.repair.discard(plan);return
        if context(self.app)!=token:
            self.repair.discard(plan);raise ValueError('Account or operating mode changed during template review.')
        self.writable();self.run_plan(plan,'',expected_context=token)

    def export_inventory(self):
        record=self.current()
        from tkinter import filedialog
        if not self.confirm('Review inventory export','Export package names, versions, issues and inspection time?\n\nLocal paths, account links, repository URLs, credentials and raw manifests are excluded.'):return
        path=filedialog.asksaveasfilename(parent=self.app.root,initialfile='VRC-Eye-Project-Inventory.json',defaultextension='.json')
        if path:
            with Path(path).open('x',encoding='utf-8') as stream:json.dump(public_report(record),stream,ensure_ascii=False,indent=2)
            self.status.set('Path-free inventory report exported. No project file was modified.')

    def export_editor_package(self):
        self.writable()
        from tkinter import filedialog
        source=Path(__file__).parent/'Unity'/'EditorCore'/'com.vrceye.editor-core-1.20.0.zip'
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Export package only — no installation',initialfile=source.name,defaultextension='.zip')
        if not path:return
        with Path(path).open('xb') as stream:stream.write(read_bytes(source,4*1024*1024))
        self.status.set('Editor Core package exported. It was not installed, imported, paired or launched.')

    def import_editor_report(self):
        self.writable();record=self.current()
        from tkinter import filedialog
        from creator_editor_report import load_report
        path=filedialog.askopenfilename(parent=self.app.root,title='Import a local VRC Eye Editor Core report',filetypes=[('JSON report','*.json')])
        if not path:return
        report=load_report(Path(path))
        preview='Associate this file with the selected project? This is a manually supplied report, not a live or authenticated connection.\n\n'+json.dumps(report,indent=2)
        if review_document(self.app,'Review editor report',preview,'Associate report'):
            self.store.receipt(record['id'],dict(schema=1,operation='Imported editor report',state='User-associated; source not authenticated',report=report))
            self.show_record(record);self.status.set('Editor report associated locally. Manifest inventory was not overwritten.')

    def account_changed(self):
        self.invalidate()
        self.copy_jobs.set([],lambda r:())
        from account_header import private
        if private(self.app):set_text(self.activity,'Private — receipt details cleared.')
        elif self.selected_id:self.show_record(self.store.get(self.selected_id))

    def tick(self):
        from account_header import private
        hidden=private(self.app)
        if hidden and not getattr(self,'receipts_hidden',False):
            self.copy_jobs.set([],lambda r:());set_text(self.activity,'Private — receipt details cleared.');self.repair.journal.clear()
        self.receipts_hidden=hidden
        super().tick()

    def close(self):
        self.invalidate()
        return super().close()
