"""Local roster display/history preferences; no account or device permissions."""
from copy import deepcopy
import math

SORTS=("Pinned / friends","Alphabetical","Join order","Recently joined","Longest present","Friends first","Authority","Encounter count","Avatar issue","Resource observation")
FILTERS=("Everyone","Friends","Non-friends","Pinned","Favorites","Has notes","Recently joined","Avatar issue","Resource observation","Authority","Group staff","VRChat staff","Bridge telemetry")
COLUMNS=("name","relation","elapsed","state","avatar","roles","seen","distance","joined","left","platform","trust","fps","ping","flags","user_id")
HISTORY=("Session only","7 days","30 days","90 days","Forever")


def defaults():
    return dict(schema=1,mode="Casual",layout="Standard",sort="Pinned / friends",filter="Everyone",search_notes=False,
                presentation=False,anonymize=False,history="Session only",avatar_history=False,world_history=False,incognito=False,
                recent_left=180.,recent_join=30.,rejoin_window=60.,loading_timeout=120.,large_rows=False,
                speaking=True,distance="Selected / pinned",follow_selection=False,open_selected=False,
                notify_friends=False,notify_pinned=False,companion_notifications=False,notifications_muted=False,
                resource_monitor=False,resource_window=10.,resource_ram_mb=256.,
                columns={"Compact":["name","elapsed","state"],"Standard":["name","relation","elapsed","state","roles"],
                         "Detailed":["name","relation","elapsed","state","avatar","roles","seen","flags"],
                         "Columns":["name","relation","joined","left","platform","trust","avatar","distance","state"]})


def validate(value):
    if not isinstance(value,dict) or set(value)-set(defaults()):raise ValueError("Unsupported player-list preferences.")
    data=defaults();data.update(deepcopy(value))
    if type(data["schema"]) is not int or data["schema"]!=1:raise ValueError("Unsupported player-list preference version.")
    for name,options in (("mode",("Casual","Advanced","Developer")),("layout",("Compact","Standard","Detailed","Columns")),("sort",SORTS),("filter",FILTERS),("history",HISTORY),("distance",("Off","Selected / pinned","Visible rows"))):
        if data[name] not in options:raise ValueError("Invalid player-list "+name+".")
    for key in ("search_notes","presentation","anonymize","avatar_history","world_history","incognito","large_rows","speaking","follow_selection","open_selected","notify_friends","notify_pinned","companion_notifications","notifications_muted","resource_monitor"):
        if type(data[key]) is not bool:raise ValueError("Player-list switches must be true or false.")
    for key,low,high in (("recent_left",0,1800),("recent_join",0,300),("rejoin_window",0,300),("loading_timeout",15,600),("resource_window",2,30),("resource_ram_mb",16,8192)):
        if type(data[key]) not in (int,float) or not math.isfinite(data[key]) or not low<=data[key]<=high:raise ValueError(f"{key.replace('_',' ')} must be {low}–{high}.")
    columns=data["columns"]
    if not isinstance(columns,dict) or set(columns)!=set(defaults()["columns"]):raise ValueError("Invalid player-list column layouts.")
    for names in columns.values():
        if not isinstance(names,list) or not 1<=len(names)<=len(COLUMNS) or len(set(names))!=len(names) or "name" not in names or set(names)-set(COLUMNS):raise ValueError("Choose unique supported columns including Name.")
    if data["anonymize"]:data["presentation"]=True
    return data


def shown_columns(settings):
    cols=settings["columns"][settings["layout"]]
    if settings["mode"]=="Casual":cols=[k for k in cols if k not in ("user_id","fps","ping","trust","platform","seen","flags")]
    if settings["presentation"]:cols=[k for k in cols if k not in ("user_id","flags","seen")]
    return tuple(cols)
