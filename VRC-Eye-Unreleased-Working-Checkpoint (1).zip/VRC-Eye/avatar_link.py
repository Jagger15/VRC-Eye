"""Local Avatar Link: reviewed, typed, manifest-scoped OSC routing.

All public methods run on the application's owning/UI thread; only LocalOSC's
bounded receiving queue has a worker. No action is executed by an OSC packet.
"""
from collections import deque
from copy import deepcopy
import math
import secrets
import time

from avatar_osc import (AVATAR_CHANGE, AVATAR_ID, PARAMETER_PREFIX, LocalOSC,
                        OSCError, port)
from osc_registry import same_arguments

ACTION_ALLOWLIST = frozenset(("select_profile", "acknowledge_reminder", "request_photo",
                             "pause_effect", "diagnostic_bookmark", "safety_profile"))
OWNER_PRIORITY = {"default": 0, "provider": 1, "profile": 2, "test": 3, "manual": 4, "heartbeat": 5}


class AvatarLinkError(ValueError):
    pass


class AvatarLink:
    def __init__(self, clock=time.monotonic, transport=None):
        self.clock = clock
        self.transport = transport if transport is not None else LocalOSC(clock=clock)
        self.context = {"account_id": "", "avatar_id": "", "platform": "Windows", "session": ""}
        self.manifest = None
        self._manifest_errors = []
        self.parameters = {}
        self.observed_avatar = ""
        self.source = None
        self.expected_source = None
        self.armed = False
        self.allow_public = False
        self.epoch = 0
        self.message = "Avatar Link is disconnected. Offline authoring remains available."
        self._reviews = {}
        self._observations = {}
        self._writers = {}
        self._last_sent = {}
        self._edges = {}
        self._requests = {}
        self._request_queue = deque(maxlen=32)
        self._commands = deque(maxlen=128)
        self._traces = deque(maxlen=256)
        self._heartbeat = {}
        self.dropped = 0

    def _trace(self, kind, name="", detail="", value=None):
        self._traces.append({"time": self.clock(), "kind": kind, "parameter": name,
                             "detail": str(detail)[:240], "value": value, "epoch": self.epoch})

    def _invalidate(self, reason, clear_avatar=False):
        if hasattr(self.transport, "invalidate"):
            self.transport.invalidate(reason)
        self.epoch += 1
        self.armed = self.allow_public = False
        self._reviews.clear()
        self._writers.clear()
        self._edges.clear()
        self._observations.clear()
        self._last_sent.clear()
        self._heartbeat.clear()
        self._request_queue.clear()
        self.transport.drain(512)
        for request in self._requests.values():
            if request["status"] in ("pending", "accepted"):
                request.update(status="cancelled", detail=reason)
        self._requests = {key: value for key, value in list(self._requests.items())[-32:]}
        for command in self._commands:
            if command["status"] in ("sent", "observed", "module_acknowledged"):
                command["status"] = "cancelled"
        if clear_avatar:
            self.observed_avatar = ""
            self.source = None
        self.message = reason
        self._trace("context", detail=reason)

    def set_context(self, account_id="", avatar_id="", platform="Windows", session=""):
        if isinstance(account_id, dict):
            context = account_id
            account_id, avatar_id, platform, session = (context.get("account_id", ""), context.get("avatar_id", ""), context.get("platform", "Windows"), context.get("session", ""))
        new = {"account_id": str(account_id or "")[:128], "avatar_id": str(avatar_id or "").lower(),
               "platform": str(platform), "session": str(session)[:256]}
        if new["platform"] not in ("Windows", "Android", "iOS", "Generic"):
            raise AvatarLinkError("Unknown avatar platform.")
        if new != self.context:
            keep_observed = all(new[key] == self.context[key] for key in ("account_id", "platform", "session")) and new["avatar_id"] == self.observed_avatar
            self.context = new
            self._invalidate("Account, avatar, platform, or client session changed. Review and arm again.", clear_avatar=not keep_observed)
            # Pre-transition queued packets can never authorize the new context.
            self.transport.drain(512)
        return self.snapshot()

    def attach_manifest(self, manifest):
        if manifest is None:
            normalized = None
        else:
            from avatar_manifest import load_manifest
            normalized = load_manifest(manifest)
        if normalized != self.manifest:
            self._invalidate("Manifest changed. Review its parameter contract before arming.")
            self.manifest = deepcopy(normalized)
            self.parameters = {item["name"]: item for item in normalized["parameters"]} if normalized else {}
            from avatar_manifest import validate_manifest
            self._manifest_errors = [item for item in validate_manifest(normalized) if item.get("severity") == "error"] if normalized else []
        return self.snapshot()

    def connect(self, receive_port=9001, target_port=9000, source_port=None, *, reviewed=False, review=None):
        if reviewed is not True:
            raise AvatarLinkError("Review the loopback listening and destination ports before connecting.")
        expected = None if source_port in (None, "") else ("127.0.0.1", port(source_port))
        self.disconnect()
        self.transport.connect(receive_port, target_port)
        self.expected_source = expected
        self.message = "Listening on loopback. Waiting for /avatar/change; OSC names are not identity proof."
        self._trace("connected", detail=f"127.0.0.1:{self.transport.receive_port} → 127.0.0.1:{self.transport.target_port}")
        return self.snapshot()

    def disconnect(self):
        # Neutral writes are best effort only while the old context is still
        # eligible. Never send old neutral values after an avatar change.
        self._neutralize()
        self.transport.close()
        self.expected_source = None
        self._invalidate("Disconnected. Visual reset cannot be guaranteed when the avatar is unreachable.", clear_avatar=True)
        return self.snapshot()

    close = disconnect

    def _compatible(self):
        if not self.transport.connected or not self.manifest or not self.source or not self.observed_avatar:
            return False
        if self.manifest["avatar_id"].lower() != self.observed_avatar:
            return False
        if self.context["avatar_id"] and self.context["avatar_id"] != self.observed_avatar:
            return False
        return self.manifest["platform"] in (self.context["platform"], "Generic")

    def review(self, action="arm", parameter=None, value=None, public=False):
        if action not in ("arm", "send"):
            raise AvatarLinkError("Unknown review operation.")
        if action == "send":
            self._parameter(parameter, value)
        token = secrets.token_hex(16)
        review = {"token": token, "action": action, "epoch": self.epoch,
                  "avatar_id": self.observed_avatar, "account_id": self.context["account_id"],
                  "platform": self.context["platform"], "manifest_revision": self.manifest.get("revision", "") if self.manifest else "",
                  "source": self.source, "parameter": parameter, "value": value,
                  "public": public is True, "expires_at": self.clock() + 60,
                  "notice": "OSC is local unauthenticated data. Synced/public parameters may be visible to other VRChat users."}
        if len(self._reviews) >= 64:
            self._reviews.pop(next(iter(self._reviews)))
        self._reviews[token] = deepcopy(review)
        return deepcopy(review)

    def _consume_review(self, review, action, parameter=None, value=None):
        token = review.get("token") if isinstance(review, dict) else review
        stored = self._reviews.pop(token, None) if isinstance(token, str) else None
        if stored is None or stored["action"] != action or stored["epoch"] != self.epoch or self.clock() > stored["expires_at"]:
            raise AvatarLinkError("Review expired or context changed. Review the action again.")
        if action == "send" and (stored["parameter"] != parameter or type(stored["value"]) is not type(value) or stored["value"] != value):
            raise AvatarLinkError("The requested value changed after review.")
        return stored

    def arm(self, review=None, allow_public=False):
        stored = self._consume_review(review, "arm")
        if not self._compatible():
            raise AvatarLinkError("A matching manifest, platform, current avatar notification, and live connection are required.")
        if self._manifest_errors:
            raise AvatarLinkError("Resolve manifest validation errors before arming: " + str(self._manifest_errors[0].get("code", "invalid contract")))
        if allow_public and not stored["public"]:
            raise AvatarLinkError("Public avatar outputs need their own reviewed approval.")
        if self.armed:
            self._neutralize()
            self._invalidate("Previous writers and requests cancelled for the new arming review.")
        self.armed, self.allow_public = True, allow_public is True
        if hasattr(self.transport, "arm_contract"):
            try:
                self.transport.arm_contract(self.manifest, self.allow_public)
            except ValueError:
                self.armed = self.allow_public = False
                raise
        # A release/press queued before local approval is not a new request.
        self.transport.drain(512)
        self._edges.clear()
        self.message = "Armed for declared parameters. Actual visual operation remains unconfirmed."
        self._trace("armed", detail="Public outputs allowed" if self.allow_public else "Private outputs only")
        return self.snapshot()

    def disarm(self):
        self._neutralize()
        self._invalidate("Writers suspended. Review and arm to resume.")
        return self.snapshot()

    def _parameter(self, name, value):
        parameter = self.parameters.get(name)
        if parameter is None or parameter["direction"] != "in":
            raise AvatarLinkError("The selected parameter is not a declared avatar input.")
        self._typed(parameter, value)
        return parameter

    @staticmethod
    def _typed(parameter, value):
        expected = {"Bool": bool, "Int": int, "Float": float}[parameter["type"]]
        if type(value) is not expected or isinstance(value, float) and not math.isfinite(value):
            raise AvatarLinkError("Value must match the declared parameter type exactly.")
        if not parameter["min"] <= value <= parameter["max"]:
            raise AvatarLinkError("Value is outside the declared parameter range.")

    def _output_allowed(self, parameter):
        if not self.armed or not self._compatible():
            raise AvatarLinkError("Avatar Link must be reviewed and armed in the current context.")
        if parameter["privacy"] == "private" and parameter["synced"]:
            raise AvatarLinkError("A private parameter marked Synced cannot receive sensitive data.")
        if (parameter["privacy"] == "public" or parameter["synced"]) and not self.allow_public:
            raise AvatarLinkError("Public avatar output is not approved for this session.")

    def send(self, name, value, owner="manual", review=None):
        self._consume_review(review, "send", name, value)
        return self._write(name, value, owner=owner, source="manual", valid=True, sampled_at=self.clock())

    def update(self, name, value, source="provider", valid=True, sampled_at=None, owner="provider"):
        return self._write(name, value, owner=owner, source=source, valid=valid, sampled_at=self.clock() if sampled_at is None else sampled_at)

    def _write(self, name, value, *, owner, source, valid, sampled_at, neutral=False, _validity=True):
        if valid is not True and name in self.parameters:
            value = self.parameters[name]["neutral"]
        parameter = self._parameter(name, value)
        self._output_allowed(parameter)
        if owner not in OWNER_PRIORITY:
            raise AvatarLinkError("Unknown parameter writer.")
        now = self.clock()
        if type(sampled_at) not in (int, float) or not math.isfinite(sampled_at) or sampled_at > now + 0.1:
            raise AvatarLinkError("Invalid signal sample time.")
        usable = valid is True and now - sampled_at <= parameter["freshness_seconds"]
        if not usable:
            value = parameter["neutral"]
        previous = self._writers.get(name)
        if previous and previous["owner"] != owner and OWNER_PRIORITY[previous["owner"]] >= OWNER_PRIORITY[owner]:
            return {"status": "blocked", "parameter": name, "detail": "A higher-priority VRC Eye writer owns this parameter."}
        sent = self._last_sent.get(name)
        if sent and now - sent["time"] < 1 / parameter["rate_hz"] and not neutral:
            return {"status": "rate_limited", "parameter": name}
        if hasattr(self.transport, "send_parameter"):
            self.transport.send_parameter(PARAMETER_PREFIX + name, value, owner=owner, neutral=neutral)
        else:
            self.transport.send(PARAMETER_PREFIX + name, value)
        writer = {"owner": owner, "source": str(source)[:120], "sampled_at": float(sampled_at), "valid": usable,
                  "value": value, "expires_at": float(sampled_at) + parameter["freshness_seconds"], "neutralized": not usable}
        self._writers[name] = writer
        command = {"id": secrets.token_hex(12), "parameter": name, "value": value, "status": "sent", "time": now,
                   "epoch": self.epoch, "owner": owner, "source": writer["source"],
                   "previous": deepcopy(previous), "detail": "Sent; destination completion unconfirmed."}
        self._commands.append(command)
        self._last_sent[name] = command
        self._trace("send", name, writer["source"], value)
        validity = parameter.get("validity", "")
        if _validity and validity and validity in self.parameters and validity != name:
            validity_parameter = self.parameters[validity]
            if validity_parameter["type"] == "Bool" and validity_parameter["direction"] == "in":
                # The validity signal uses the same permission gate, never a
                # backdoor into a separately protected public parameter.
                command["validity_result"] = self._write(validity, usable, owner=owner, source=source, valid=True, sampled_at=now, neutral=neutral, _validity=False)
        return deepcopy(command)

    def release(self, name, owner=None):
        writer = self._writers.get(name)
        if writer and (owner is None or writer["owner"] == owner):
            if hasattr(self.transport, "release_parameter"):
                self.transport.release_parameter(PARAMETER_PREFIX + name, writer["owner"])
            del self._writers[name]
            self._trace("writer_released", name)
            return True
        return False

    def release_owner(self, owner):
        """Release this broker's matching ownership without sending any value."""
        names = [name for name, writer in self._writers.items() if writer["owner"] == owner]
        for name in names:
            self.release(name, owner)
        return tuple(names)

    def review_restore(self, command_id):
        command = next((item for item in self._last_sent.values() if item["id"] == command_id), None)
        if command is None or command["owner"] != "profile" or command["epoch"] != self.epoch:
            raise AvatarLinkError("Profile output was replaced or belongs to an old context; it cannot be restored.")
        previous = command.get("previous")
        parameter = self.parameters[command["parameter"]]
        usable = bool(previous and previous["valid"] and (self.clock() <= previous["expires_at"] or
                      previous["owner"] in ("manual", "profile", "default") and not parameter["ephemeral"]))
        value = previous["value"] if usable else parameter["neutral"]
        review = self.review("send", parameter["name"], value)
        review["restore_command_id"] = command_id
        # This extra field is a scoped identity, not a user-provided value.
        self._reviews[review["token"]]["restore_command_id"] = command_id
        return review

    def restore(self, command_id, review=None):
        """Restore a reviewed profile result only while it is still the writer.

        An intervening manual, provider, test, or newer profile update prevents
        restoration. Old provider samples restore to neutral, not a stale value.
        """
        command = next((item for item in self._last_sent.values() if item["id"] == command_id), None)
        if command is None or command["owner"] != "profile" or command["epoch"] != self.epoch:
            raise AvatarLinkError("Profile output was replaced or belongs to an old context; it cannot be restored.")
        previous = command.get("previous")
        parameter = self.parameters[command["parameter"]]
        usable = bool(previous and previous["valid"] and (self.clock() <= previous["expires_at"] or
                      previous["owner"] in ("manual", "profile", "default") and not parameter["ephemeral"]))
        value = previous["value"] if usable else parameter["neutral"]
        reviewed = self._consume_review(review, "send", parameter["name"], value)
        if reviewed.get("restore_command_id") != command_id:
            raise AvatarLinkError("Review this specific profile restoration first.")
        sample_time = previous["sampled_at"] if usable and previous["owner"] in ("provider", "test") else self.clock()
        validity_result = command.get("validity_result", {})
        validity_name = parameter.get("validity", "")
        current_validity = self._last_sent.get(validity_name, {})
        restore_validity_owner = bool(validity_result.get("id") and current_validity.get("id") == validity_result["id"])
        result = self._write(parameter["name"], value, owner="profile", source="profile restore", valid=usable,
                             sampled_at=sample_time, neutral=True)
        if previous:
            writer = self._writers[parameter["name"]]
            writer["owner"], writer["source"] = previous["owner"], previous["source"]
        else:
            self.release(parameter["name"], "profile")
        if restore_validity_owner and validity_name in self._writers:
            previous_validity = validity_result.get("previous")
            if previous_validity:
                self._writers[validity_name]["owner"] = previous_validity["owner"]
                self._writers[validity_name]["source"] = previous_validity["source"]
            else:
                self.release(validity_name, "profile")
        return result

    def _neutralize(self):
        if not self.armed or not self._compatible():
            return
        for name, writer in tuple(self._writers.items()):
            parameter = self.parameters.get(name)
            if parameter is None:
                continue
            try:
                self._write(name, parameter["neutral"], owner=writer["owner"], source="neutral state", valid=False, sampled_at=self.clock(), neutral=True)
            except (AvatarLinkError, OSCError, OSError):
                self._trace("neutral_unconfirmed", name, "The destination could not be reached.")

    def _receive(self, packet):
        if packet.generation != self.transport.generation or self.clock() - packet.received_at > 1:
            self.dropped += 1
            return
        if packet.source[0] != "127.0.0.1" or self.expected_source and packet.source != self.expected_source or self.source and packet.source != self.source:
            self.dropped += 1
            return
        changes = [message for message in packet.messages if message.address == AVATAR_CHANGE]
        if changes:
            # A bundle with multiple contradictory avatar identities is not a
            # meaningful initialization event. Discard all associated values.
            if len({message.value.lower() for message in changes}) != 1:
                self.dropped += 1
                return
            changed = changes[-1].value.lower()
            self._invalidate("Avatar initialization received. Pending work cancelled; review and arm again.")
            self.source, self.observed_avatar = packet.source, changed
        if not self.source or not self.observed_avatar:
            return
        if not self._compatible():
            return
        for message in packet.messages:
            if not message.address.startswith(PARAMETER_PREFIX):
                continue
            name = message.address[len(PARAMETER_PREFIX):]
            parameter = self.parameters.get(name)
            if parameter is None:
                continue
            try:
                self._typed(parameter, message.value)
            except AvatarLinkError:
                self._trace("rejected", name, "Incoming type or range differs from manifest.")
                continue
            self._observations[name] = {"value": message.value, "last_received_at": packet.received_at,
                                       "source": "local OSC", "valid": True, "status": "observed"}
            sent = self._last_sent.get(name)
            if sent and same_arguments((sent["value"],), (message.value,)) and sent["epoch"] == self.epoch:
                sent["status"] = "observed"
                sent["detail"] = "Matching OSC value observed; visual/action completion unconfirmed."
            elif sent and sent["epoch"] == self.epoch:
                self._observations[name]["difference"] = "Observed value differs from VRC Eye's last send; another writer or authored behavior is possible, attribution unknown."
                self._trace("value_difference", name, "Cause and external writer identity are unknown.", message.value)
            for incoming in self.parameters.values():
                if incoming.get("acknowledgment") == name:
                    command = self._last_sent.get(incoming["name"])
                    if command and same_arguments((command["value"],), (message.value,)) and packet.received_at >= command["time"]:
                        command.update(status="module_acknowledged", detail="Declared acknowledgment observed; destination completion unconfirmed.")
                        heartbeat = self._heartbeat.get(incoming["name"])
                        if heartbeat:
                            heartbeat["acknowledged_at"] = packet.received_at
            if self.armed and parameter["direction"] == "out" and parameter.get("action") in ACTION_ALLOWLIST and parameter["action"] in self.manifest.get("actions", []):
                self._contact(name, parameter, message.value, packet.received_at)

    def _contact(self, name, parameter, value, now):
        edge = self._edges.setdefault(name, {"released": False, "held": False, "last": -math.inf})
        # Hysteresis makes float Contacts usable without repeated edge chatter.
        low, high = parameter["min"], parameter["max"]
        ratio = (float(value) - low) / (high - low) if high > low else float(value)
        if ratio <= 0.25:
            edge.update(released=True, held=False)
            return
        if ratio < 0.75 or edge["held"]:
            return
        edge["held"] = True
        if not edge["released"] or now - edge["last"] < 0.75:
            return
        edge.update(released=False, last=now)
        if len([item for item in self._requests.values() if item["status"] == "pending"]) >= 16:
            self.dropped += 1
            return
        request = {"id": secrets.token_hex(12), "action": parameter["action"], "parameter": name,
                   "status": "pending", "time": now, "expires_at": now + 15, "epoch": self.epoch,
                   "avatar_id": self.observed_avatar, "manifest_revision": self.manifest["revision"],
                   "detail": "Local request awaiting explicit destination review; no action executed."}
        if len(self._requests) >= 128:
            completed = next((key for key, item in self._requests.items() if item["status"] not in ("pending", "accepted")), None)
            if completed is None:
                self.dropped += 1
                return
            del self._requests[completed]
        self._requests[request["id"]] = request
        self._request_queue.append(request["id"])
        self._trace("action_requested", name, parameter["action"])

    def request(self, request_id):
        request = self._requests.get(request_id)
        if not request or request["epoch"] != self.epoch or request["status"] != "pending" or self.clock() > request["expires_at"] or not self.armed or not self._compatible():
            raise AvatarLinkError("Avatar request expired, was already handled, or its context changed.")
        return deepcopy(request)

    def drain_requests(self):
        result = []
        while self._request_queue:
            request_id = self._request_queue.popleft()
            try:
                result.append(self.request(request_id))
            except AvatarLinkError:
                pass
        return tuple(result)

    def resolve_request(self, request_id, status, detail=""):
        if status not in ("accepted", "declined", "sent", "action_confirmed", "failed"):
            raise AvatarLinkError("Unknown action result.")
        request = self._requests.get(request_id)
        if request and request["status"] in ("accepted", "sent") and status in ("sent", "action_confirmed", "failed"):
            if request["epoch"] != self.epoch or self.clock() > request["expires_at"] or not self.armed:
                raise AvatarLinkError("Accepted request context is no longer current.")
        else:
            self.request(request_id)
        request.update(status=status, detail=str(detail)[:240])
        self._trace("action_result", request["parameter"], status)
        return deepcopy(request)

    def tick(self):
        # Save current notifications before an arming invalidation drains stale
        # queues; the shared service may already have observed a new avatar.
        packets = self.transport.drain()
        if self.armed and hasattr(self.transport, "contract_armed") and not self.transport.contract_armed:
            self._invalidate("Shared OSC controls stopped or permission changed. Review and arm again.")
        if self.armed and not self.transport.connected:
            self._invalidate("OSC transport stopped. Pending work cancelled; reconnect and review again.", clear_avatar=True)
        for packet in packets:
            self._receive(packet)
        now = self.clock()
        for name, observation in self._observations.items():
            observation["valid"] = now - observation["last_received_at"] <= self.parameters[name]["freshness_seconds"]
        for request in self._requests.values():
            if request["status"] in ("pending", "accepted") and now > request["expires_at"]:
                request.update(status="expired", detail="Request timed out; it will not execute on reconnect.")
        if self.armed:
            for name, writer in tuple(self._writers.items()):
                expires = writer["owner"] in ("provider", "test") or self.parameters[name]["ephemeral"]
                if writer["owner"] != "heartbeat" and expires and now > writer["expires_at"] and not writer["neutralized"]:
                    try:
                        self._write(name, self.parameters[name]["neutral"], owner=writer["owner"], source="stale provider", valid=False, sampled_at=now, neutral=True)
                    except (AvatarLinkError, OSCError):
                        self._trace("neutral_unconfirmed", name)
            for name, parameter in self.parameters.items():
                if parameter["direction"] != "in" or parameter.get("semantic") != "heartbeat":
                    continue
                heartbeat = self._heartbeat.setdefault(name, {"last": None, "value": False, "acknowledged_at": None})
                if heartbeat["last"] is None or now - heartbeat["last"] >= max(0.5, 1 / parameter["rate_hz"]):
                    heartbeat["value"] = not heartbeat["value"]
                    value = heartbeat["value"] if parameter["type"] == "Bool" else int(heartbeat["value"]) if parameter["type"] == "Int" else float(heartbeat["value"])
                    try:
                        self._write(name, value, owner="heartbeat", source="heartbeat", valid=True, sampled_at=now)
                        heartbeat["last"] = now
                    except (AvatarLinkError, OSCError):
                        self._trace("heartbeat_failed", name)
        return self.snapshot()

    def snapshot(self):
        if not self.transport.connected:
            state = "disconnected"
        elif not self.observed_avatar:
            state = "awaiting_avatar"
        elif not self.manifest:
            state = "observing"
        elif not self._compatible():
            state = "incompatible"
        else:
            state = "armed" if self.armed else "compatible"
        parameters = []
        for name, parameter in self.parameters.items():
            item = deepcopy(parameter)
            item.update(value=None, last_received_at=None, valid=False, owner="", last_sent=None, status="declared")
            item.update(self._observations.get(name, {}))
            writer = self._writers.get(name)
            sent = self._last_sent.get(name)
            if writer:
                item["owner"] = writer["owner"]
                item["writer_source"] = writer["source"]
                item["writer_valid"] = writer["valid"]
            if sent:
                item["last_sent"] = deepcopy(sent)
                item["status"] = sent["status"]
            parameters.append(item)
        heartbeat = deepcopy(self._heartbeat)
        for name, item in heartbeat.items():
            item["valid"] = item["acknowledged_at"] is not None and self.clock() - item["acknowledged_at"] <= self.parameters[name]["freshness_seconds"]
        return {"state": state, "connected": self.transport.connected, "armed": self.armed,
                "avatar_id": self.observed_avatar, "account_id": self.context["account_id"],
                "observed_avatar_id": self.observed_avatar, "expected_avatar_id": self.context["avatar_id"],
                "platform": self.context["platform"], "manifest_revision": self.manifest["revision"] if self.manifest else "",
                "source": self.source, "receive_port": self.transport.receive_port, "target_port": self.transport.target_port,
                "allow_public": self.allow_public, "public_allowed": self.allow_public,
                "message": self.message, "epoch": self.epoch, "generation": self.epoch,
                "parameters": parameters, "commands": deepcopy(list(self._commands)),
                "manifest_errors": deepcopy(self._manifest_errors),
                "requests": deepcopy(list(self._requests.values())[-32:]), "traces": deepcopy(list(self._traces)),
                "currentparameters": deepcopy(parameters), "trace": deepcopy(list(self._traces)),
                "pending": deepcopy([request for request in self._requests.values() if request["status"] == "pending"]),
                "actions": deepcopy(list(self._requests.values())[-32:]),
                "dropped": self.dropped + self.transport.dropped, "invalid": self.transport.invalid,
                "heartbeat": heartbeat}
