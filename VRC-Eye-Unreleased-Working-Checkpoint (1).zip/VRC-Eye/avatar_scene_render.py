"""Cancellable bounded software base-color preview, with one latest-frame worker."""
import base64
import math
import threading
import time
from avatar_library_files import check_cancel, InspectionCancelled
from avatar_model_preview import project
from avatar_scene_appearance import Material,transform_uv

MAX_VISITS=4_000_000
MAX_SECONDS=4
MAX_FRAGMENTS=262144
MAX_LAYERS=64


def wrap(value,mode):
    if mode==33071:return max(0.,min(1.,value))
    whole=math.floor(value);fraction=value-whole
    return 1-fraction if mode==33648 and whole%2 else fraction


def linear(v):return v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4
def srgb(v):return round(255*(12.92*v if v<=.0031308 else 1.055*v**(1/2.4)-.055))
LINEAR=tuple(linear(v/255) for v in range(256))


def texel_index(value,size,mode):
    if mode==33071:return max(0,min(size-1,value))
    if mode==10497:return value%size
    at=value%(2*size)
    return at if at<size else 2*size-1-at


def sample_linear(texture,raw,u,v):
    """Bilinear color interpolation in linear light; coverage stays linear."""
    x=u*texture.width-.5;y=v*texture.height-.5
    ix=math.floor(x);iy=math.floor(y);fx=x-ix;fy=y-iy;out=[0.,0.,0.,0.]
    for dx,dy,weight in ((0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)):
        tx=texel_index(ix+dx,texture.width,texture.wrap_s);ty=texel_index(iy+dy,texture.height,texture.wrap_t)
        at=(ty*texture.width+tx)*4
        for k in range(3):out[k]+=LINEAR[raw[at+k]]*weight
        out[3]+=raw[at+3]/255*weight
    return tuple(out)


def linear_filter(texture,uv,points):
    """Choose mag/min from the orthographic retained-image pixel footprint."""
    ax,ay,bx,by,cx,cy=points;den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
    if abs(den)<1e-10:return texture.mag_filter==9729
    dx=[];dy=[]
    for k,size in ((0,texture.width),(1,texture.height)):
        a=uv[0][k]-uv[2][k];b=uv[1][k]-uv[2][k]
        dx.append(size*(a*(by-cy)+b*(cy-ay))/den)
        dy.append(size*(a*(cx-bx)+b*(ax-cx))/den)
    mini=max(sum(v*v for v in dx),sum(v*v for v in dy))>1
    mode=texture.min_filter if mini else texture.mag_filter
    # glTF's prescribed fallback when mipmap generation is unavailable.
    return mode in (9729,9985,9987)


def render(scene,batches,camera,width,height,*,textured=True,background=(25,25,35),stop=None):
    """Opaque depth buffer and bounded per-pixel transparent depth resolution."""
    if any(type(v) is not int or not 1<=v<=10000 for v in (width,height)):raise ValueError('Invalid preview viewport.')
    ratio=min(1.,480/width,320/height);w=max(1,round(width*ratio));h=max(1,round(height*ratio))
    pixels=bytearray(bytes(background)*w*h);depth=[-float('inf')]*(w*h)
    linear_pixels={};fragments={};fragment_count=0
    textures=[base64.b64decode(t.rgba,validate=True) for t in scene.textures]
    opaque=[];blend=[];started=time.monotonic();visits=0
    for _,mesh in batches:
        check_cancel(stop)
        material=scene.materials[mesh.material] if mesh.material>=0 else Material()
        for face in project(mesh,camera,w,h,stop=stop,coordinate_limit=10000):
            (blend if material.alpha=='BLEND' else opaque).append((face,mesh,material))
    # Lookup converts sRGB texture channels to linear, applies the linear factor,
    # then encodes the result. Alpha is linear and never gamma transformed.
    tables={}
    for face,mesh,m in opaque+blend:
        check_cancel(stop)
        if time.monotonic()-started>MAX_SECONDS:raise ValueError('Appearance preview exceeded 4 seconds. Frame a smaller subtree or choose Solid.')
        ax,ay,bx,by,cx,cy=face.points
        den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
        if abs(den)<1e-10 or den>0 and not m.double_sided:continue
        left=max(0,math.floor(min(ax,bx,cx)));right=min(w-1,math.ceil(max(ax,bx,cx)))
        top=max(0,math.floor(min(ay,by,cy)));bottom=min(h-1,math.ceil(max(ay,by,cy)))
        visits+=max(0,right-left+1)*max(0,bottom-top+1)
        if visits>MAX_VISITS:raise ValueError('Appearance preview exceeds its pixel budget. Frame a smaller subtree or choose Solid.')
        tex=scene.textures[m.texture] if textured and mesh.uvs and m.texture>=0 else None
        raw=textures[m.texture] if tex else None
        uv=[transform_uv(m,mesh.uvs[n]) for n in face.triangle] if tex else None
        bilinear=linear_filter(tex,uv,face.points) if tex else False
        vertex_colors=[mesh.colors[n] for n in face.triangle] if mesh.colors else None
        sign=1 if den>0 else -1
        edge_included=tuple(sign*(ey-sy)<0 or ey==sy and sign*(ex-sx)>0
                            for sx,sy,ex,ey in ((bx,by,cx,cy),(cx,cy,ax,ay),(ax,ay,bx,by)))
        if m.base_color not in tables:tables[m.base_color]=tuple(tuple(srgb(linear(v/255)*f) for v in range(256)) for f in m.base_color[:3])
        colors=tables[m.base_color];flat=tuple(t[255] for t in colors)
        for y in range(top,bottom+1):
            check_cancel(stop)
            if time.monotonic()-started>MAX_SECONDS:raise ValueError('Appearance preview exceeded 4 seconds. Frame a smaller subtree or choose Solid.')
            for x in range(left,right+1):
                a=((by-cy)*(x+.5-cx)+(cx-bx)*(y+.5-cy))/den
                b=((cy-ay)*(x+.5-cx)+(ax-cx)*(y+.5-cy))/den;c=1-a-b
                if min(a,b,c)<-1e-8:continue
                # Consistent half-open coverage avoids drawing a shared edge
                # twice when adjacent transparent triangles cover one pixel.
                if (abs(a)<1e-8 and not edge_included[0] or abs(b)<1e-8 and not edge_included[1]
                        or abs(c)<1e-8 and not edge_included[2]):continue
                index=y*w+x;z=a*face.depths[0]+b*face.depths[1]+c*face.depths[2]
                if z<depth[index]:continue
                alpha=m.base_color[3];rgb=flat;sampled=(1.,1.,1.)
                if tex:
                    u=a*uv[0][0]+b*uv[1][0]+c*uv[2][0];v=a*uv[0][1]+b*uv[1][1]+c*uv[2][1]
                    if bilinear:
                        rgba=sample_linear(tex,raw,u,v);sampled=rgba[:3]
                        rgb=tuple(srgb(sampled[k]*m.base_color[k]) for k in range(3));alpha*=rgba[3]
                    else:
                        tx=min(tex.width-1,int(wrap(u,tex.wrap_s)*tex.width));ty=min(tex.height-1,int(wrap(v,tex.wrap_t)*tex.height))
                        at=(ty*tex.width+tx)*4
                        sampled=tuple(LINEAR[raw[at+k]] for k in range(3))
                        rgb=tuple(colors[k][raw[at+k]] for k in range(3));alpha*=raw[at+3]/255
                if vertex_colors:
                    factors=tuple(max(0.,min(1.,a*vertex_colors[0][k]+b*vertex_colors[1][k]+c*vertex_colors[2][k])) for k in range(4))
                    # Vertex colors are linear multipliers; do not multiply encoded sRGB.
                    rgb=tuple(srgb(sampled[k]*m.base_color[k]*factors[k]) for k in range(3));alpha*=factors[3]
                if m.alpha=='MASK':
                    if alpha<m.cutoff:continue
                    alpha=1.
                elif m.alpha=='OPAQUE':alpha=1.
                if alpha<=0:continue
                at=index*3
                # Preserve linear values through compositing; encoding before
                # alpha blending incorrectly darkens translucent surfaces.
                color=tuple(sampled[k]*m.base_color[k]*(factors[k] if vertex_colors else 1.) for k in range(3))
                if m.alpha=='BLEND':
                    layers=fragments.setdefault(index,[]);fragment_count+=1
                    if fragment_count>MAX_FRAGMENTS or len(layers)>=MAX_LAYERS:
                        raise ValueError('Transparency exceeds the bounded fragment budget. Frame a smaller subtree or choose Solid.')
                    layers.append((z,color,alpha))
                else:
                    depth[index]=z;linear_pixels[index]=color;pixels[at:at+3]=bytes(rgb)
    backdrop=tuple(LINEAR[v] for v in background)
    for index,layers in fragments.items():
        check_cancel(stop)
        if time.monotonic()-started>MAX_SECONDS:raise ValueError('Appearance preview exceeded 4 seconds. Frame a smaller subtree or choose Solid.')
        color=linear_pixels.get(index,backdrop)
        for z,front,alpha in sorted(layers,key=lambda v:v[0]):
            if z<depth[index]:continue
            color=tuple(front[k]*alpha+color[k]*(1-alpha) for k in range(3))
        pixels[index*3:index*3+3]=bytes(srgb(max(0.,min(1.,v))) for v in color)
    check_cancel(stop)
    return w,h,bytes(pixels)


class Renderer:
    """A new camera request cancels previous work; at most one pending frame."""
    def __init__(self,work=None):
        self.work=work
        self.condition=threading.Condition();self.pending=None;self.active=None;self.result=None;self.closed=False
        self.thread=threading.Thread(target=self.run,daemon=True,name='VRC-Eye-Scene-Render');self.thread.start()

    def cancel(self):
        with self.condition:
            if self.active:self.active.set()
            if self.pending:self.pending[2].set()
            self.pending=None;self.result=None

    def submit(self,token,args,kwargs):
        with self.condition:
            if self.closed:raise ValueError('Scene renderer has closed.')
            self.cancel();event=threading.Event();self.pending=(token,(args,kwargs),event);self.condition.notify()

    def take(self,token):
        with self.condition:
            if self.result and self.result[0]==token:
                result=self.result[1:];self.result=None;return result
        return None

    def run(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda:self.pending is not None or self.closed)
                if self.closed:return
                token,(args,kwargs),event=self.pending;self.pending=None;self.active=event
            try:result=(self.work or render)(*args,**kwargs,stop=event);error=''
            except InspectionCancelled:result=None;error='Canceled'
            except Exception as problem:result=None;error=str(problem) if isinstance(problem,ValueError) else 'Appearance preview unavailable.'
            with self.condition:
                if not self.closed and not event.is_set():self.result=(token,result,error)
                self.active=None
            # Do not retain a scene while waiting for another camera request.
            args=kwargs=result=None

    def close(self):
        with self.condition:self.cancel();self.closed=True;self.condition.notify()
