# VRC Eye 1.20.0 — Development checkpoint 3

This checkpoint builds on the verified Development 2 archive, SHA-256
`a7f884a2c565cf6afaec7f29e203081d5296d32b10d7a67a1aa2214bbc25bab1`.
It begins the shared account-action and expanded Social/Accounts work. It is not
the complete 1.20 release or a finished multi-session account manager.

## Start and preservation

Keep testing Development 2 until you deliberately switch. Close the running copy,
back up VRC Eye's per-user settings/databases, and extract the entire
**VRC-Eye-v1.20.0-Development-3.zip into a new folder**. Open `VRC-Eye` and run the
unchanged **Start.cmd**. Do not run two copies against the same data at once.

The Development 2 archive and all its source paths are retained. The four launchers
and requirements.txt are unchanged. This is the existing source application, not a
newly compiled/signed Windows EXE. Independent remembered username/password and
scoped Enter/keypad Enter sign-in behavior remain. The prior Avatar Library,
VCC/creator, OSC/networking, resource, accessibility and other tools remain.

## Implemented in Development 3

**Community → Social:** Browse, Dashboard and Action history. Manual notification inbox
loading, received-invite/request/response views, own-group browsing, local filters
and source-page pagination supplement the existing friend/request/mute/block
views. Notification selection alone makes no write. Mark read/hide require a
separate review. World references open only a reviewed website page, not an
instance join. Snapshot counts are not account-wide totals.

**You → Accounts:** Accounts & logins, My profile and Action history. Local labels
and Main/Alt/Creator/Other roles, a truthful zero/one active-process login table,
connection replacement/disconnect warnings, and explicit own-profile refresh.
Status, status text and pronouns have changed-fields-only reviews; unavailable
fields are disabled. Selecting a label never signs in or switches an account.

**Shared reviewed-action service:** frozen one-use reviews, exact connection and
session binding, post-confirmation selection checks, queue-time freshness checks,
pre-dispatch durable receipts, cancellation and no automatic remote retry. Social,
Game Favorites add/remove and the new My profile editor use it. It does not
intercept every other legacy application's action path.

**Local action history:** initiating-account receipts distinguish Confirmed,
Rejected, Not sent and Uncertain. Restarted dispatches remain uncertain rather
than being resent. The user can acknowledge uncertainty after independent review,
clear completed records, export a selected identifier-free receipt, or retry saving
an in-memory outcome locally without repeating the remote action.

**Presentation:** page-specific privacy clearing, explicit account/game-log identity
labels, scrollable bodies and shared display/accessibility preferences. Ctrl+K
includes the new account/profile/history/dashboard destinations. This is not a
complete application-wide streamer mode or a screen-reader certification.

Read **SOCIAL_ACCOUNTS_1_20.md** for operations, states, limits and recovery.

## Testing

BUILD_VALIDATION.json records the final clean-extracted suite, grammar validation,
package preservation and native preview checks. Existing historical reports remain
separately named; DEVELOPMENT_1_20_DEV2.md and BASELINE_DEV2_VALIDATION.json are
Development 2 evidence, not new test results.

Tests cover account changes during review/queue/dispatch, same-user reconnections,
frozen targets, malformed/unknown notification data, profile diffs, denied reviews,
uncertain replies, receipt persistence failures, local-save recovery, history
privacy, selected exports, actual Tk workflows and the prior application's tests.
Native fixture teardown has explicit main-thread collection of unreachable Tk
cycles; no tests are excluded to make this checkpoint pass.

No live VRChat/VRCX request, installed VPM/Unity run, C# compilation, native Windows
run or assistive-technology interoperability is claimed. All tested account writes
use fixture responses through the existing transport; real permissions and service
behavior still require native validation.

## Remaining roadmap

There is still one active authenticated session. Simultaneous retained logins,
full account-isolated migration, NotificationV2/live subscriptions, outbound invite
composition, broader metadata edits and notification publication are not complete.
Photos, Invite Me, separate SDK/VCC release downloads, remaining accessibility/XR,
and advanced conditional avatar rendering/Unity repair/recovery remain pending.
No supplied ARC executable/DLL, authentication service, recovery/viewer binary,
new runtime dependency or silent updater is added.

See IMPLEMENTATION_STATUS_1_20.md/json for delivered versus partial/pending work.
Full original planning inputs remain in planning/; their historical build-hold
labels do not override later implementation authorization.

## Final validation result

The clean-extracted checkpoint passed **3,102 tests and 1,141 subtests**
with zero failures, errors or skips in 97.90 seconds. One pre-existing
TestListener collection warning remains. The external-socket guard recorded
zero blocked attempts; loopback fixture networking remained enabled. This is
**125 additional tests**, including **26 new native Tk workflow cases**.

All **316 Python files** passed Python 3.10 grammar checks; tests ran on
Python 3.13.5 under Linux/Xvfb. The archive contains **426 files**,
retains all **415 Development 2 paths**, adds 11 paths and modifies 19
baseline files. All four launchers and requirements.txt are byte-identical to
Development 2. Final runtime, tests, launchers, catalogs and Unity source match
the clean-tested bytes; only final validation metadata and these results were
written afterward. No platform or live-service claims exceed the tests above.
