"""Persistent batch review using the account action service and its receipts."""
import json
from companion_ui import Table,line,button,entry,choice
from vrcx_ui_jobs import LocalPage
from native_batches import service_for,GROUP_ACTIONS,CONTENT_ACTIONS


def show(owner):
    owner.require();return BatchDialog(owner)


class BatchDialog(LocalPage):
    def __init__(self,owner):
        self.owner=owner;self.window=owner.tk.Toplevel(owner.app.root);self.window.title('Reviewed batches')
        self.window.geometry('1050x820');self.window.transient(owner.app.root)
        from friendly_ui import ScrollPane
        self.viewport=ScrollPane(owner.app,self.window,min_width=960)
        super().__init__(owner.shell,self.viewport.body,'Reviewed batches')
        self.service=service_for(owner.shell);self.selected_batch=''
        actions=tuple(sorted(GROUP_ACTIONS if owner.area=='groups' else CONTENT_ACTIONS))
        selected=getattr(owner,'action_map',{}).get(owner.action.get(),'')
        self.action=self.tk.StringVar(value=selected if selected in actions else actions[0])
        self.group=self.tk.StringVar(value=owner.subject.get().split('/')[0] if owner.area=='groups' else '')
        self.label=self.tk.StringVar(value='Member batch' if owner.area=='groups' else 'Owned content batch')
        row=line(self);choice(self,row,self.action,actions,width=30);entry(self,row,self.label,30)
        if owner.area=='groups':entry(self,line(self),self.group,55)
        self.ttk.Label(self.parent,text='Exact user / owned asset IDs, one per line or comma, up to 1,000. Changes below apply to every target.').pack(anchor='w')
        self.ids=self.tk.Text(self.parent,height=5,wrap='word');self.ids.pack(fill='x')
        self.ttk.Label(self.parent,text='Changed fields as JSON (for example {"tags":["author_tag_fun"]} or {"roleId":"grol_…"}); use {} for member decisions / publishing.').pack(anchor='w')
        self.values=self.tk.Text(self.parent,height=4,wrap='word');self.values.pack(fill='x');self.values.insert('1.0','{}')
        row=line(self);button(self,row,'Save queue locally',self.create);button(self,row,'Refresh my queues',self.refresh)
        self.batches=Table(self,self.parent,(('created','Created',170),('label','Batch',500)),height=4,select=self.select)
        self.items=Table(self,self.parent,(('state','State',130),('action','Action',220),('target','Exact target',370),('receipt','Receipt',240)),height=7)
        row=line(self);button(self,row,'Review and run remaining items…',self.run);button(self,row,'Pause after current operation',self.cancel)
        self.ttk.Label(self.parent,text='Each target is checked and sent once, with its own receipt. Review expires after five minutes.\nContinue by reviewing unsent items again. Rejected, uncertain and completed items are excluded from continuation.',wraplength=960).pack(anchor='w')
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=self.app.root.after(200,self.tick);owner.image_windows.append(self)
        self.refresh()

    def create(self):
        self.ready();self.owner.require()
        from native_migration import strict_json
        raw=self.ids.get('1.0','end-1c');ids=list(dict.fromkeys(v.strip() for v in raw.replace(',', '\n').splitlines() if v.strip()))
        values=strict_json(self.values.get('1.0','end-1c'))
        self.selected_batch=self.service.create(self.label.get(),[dict(action=self.action.get(),target=ref,group=self.group.get(),values=values) for ref in ids])
        self.refresh();self.display()

    def refresh(self):
        self.ready();self.owner.require()
        self.batches.set(self.service.list(),lambda r:(r['created'],r['label']))

    def select(self):
        row=self.batches.selected();self.selected_batch=row['id'] if row else '';self.display()

    def display(self):
        rows=self.service.rows(self.selected_batch) if self.selected_batch else []
        self.items.set(rows,lambda r:(r['state'],r['proposal']['action'],r['proposal']['target'],r['receipt']))

    def run(self):
        self.ready();self.owner.require();token=self.token();approval=self.service.prepare(self.selected_batch)
        try:
            from creator_projects_ui import review_document
            summary='Active account: '+approval.account+'\nThe following exact operations may be sent during the next five minutes:\n\n'
            summary+='\n'.join(json.dumps(json.loads(raw),ensure_ascii=False) for _,raw in approval.rows)
            if not review_document(self.app,'Review remaining batch',summary,accept='Run these reviewed operations'):return
            self.verify(token)
            if self.selected_batch!=approval.batch:raise ValueError('The batch selection changed.')
            submitted=approval
            self.start(lambda c,s,p:self.service.run(submitted,stop=s,progress=p),lambda rows:(self.display(),self.status.set(f'{len(rows)} outcomes recorded. Review remaining unsent targets to continue.')),api=True,mutation=True)
            approval=None
        finally:
            if approval:self.service.discard(approval)

    def clear_preview(self):
        self.selected_batch='';self.batches.set([],lambda r:());self.items.set([],lambda r:())
        self.ids.delete('1.0','end');self.values.delete('1.0','end');self.values.insert('1.0','{}');self.group.set('')

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(200,self.tick)

    def close(self):
        if self.closed:return
        self.app.root.after_cancel(self.timer);self.clear_preview();super().close();self.window.destroy()
        if self in self.owner.image_windows:self.owner.image_windows.remove(self)
