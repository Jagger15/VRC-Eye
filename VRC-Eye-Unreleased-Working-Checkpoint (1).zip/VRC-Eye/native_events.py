"""Shared scoped observations and notification projection; never an API owner."""
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime,timezone
from hashlib import sha256
import json
import time
import uuid
from companion_data import entity_id,stamp
from native_library import identity


class EventHub:
    def __init__(self,shell):
        self.shell=shell;self.account='';self.generation=None;self.revision=0
        self.notifications=OrderedDict();self.records=OrderedDict();self.delivery=[];self.gaps=[];self.listeners={}
        self.versions=OrderedDict();self.floor=0;self.cleared=0
        self.social_delivery=[]

    def boundary(self):
        app=self.shell.app;client=app.api
        from account_header import private
        return (client,getattr(client,'user_id',''),getattr(client,'session_revision',0),getattr(app,'data_generation',0),private(app),bool(app.demo or getattr(app,'safe_mode',False)),
                bool(getattr(client,'authenticated',False)),bool(getattr(client,'closed',None) and client.closed.is_set()))

    def sync(self):
        current=self.boundary()
        if current!=self.generation:
            self.generation=current;self.account=current[1] if current[6] and not current[7] else '';self.notifications.clear();self.records.clear();self.delivery.clear();self.gaps.clear();self.revision+=1
            self.versions.clear();self.floor=0;self.cleared=0
            self.social_delivery.clear()
        return bool(self.account and not current[4] and not current[5])

    def gap(self,reason):
        if not self.sync():return
        record=dict(category='connection-gap',reported_time=None,observed_at=stamp(),reason=reason[:500],historical=False)
        self.gaps=(self.gaps+[record])[-100:];self.revision+=1
        self.shell.store.native.put(self.account,'coverage',str(uuid.uuid4()),record,provenance={'source':'VRChat pipeline observation'})

    def notification(self,data,family,*,live=False,deleted=False,after=None):
        if not self.sync():return
        from companion_data import reference
        from native_api import bounded
        data=bounded(data);ref=reference(data.get('id') or data.get('notificationId'),('not','ntf'))
        if data.get('receiverUserId',self.account)!=self.account:return
        key=family+':'+ref;previous=self.notifications.get(key)
        if family not in ('v1','v2'):raise ValueError('Unsupported notification family.')
        if after is not None and (after<self.floor or self.versions.get(key,0)>after or family=='v1' and self.cleared>after):return
        if previous and previous.get('deleted') and not deleted:return
        with self.shell.store.native.connect() as db:
            if db.execute("SELECT 1 FROM eye_native_suppressed WHERE scope=? AND kind='notification' AND id=?",(self.account,key)).fetchone():
                self.notifications.pop(key,None);self.records.pop(key,None);return
        # Server revision/time is evidence where supplied. Reject an older update;
        # otherwise preserve receipt ordering without claiming a server sequence.
        when=data.get('updatedAt') or data.get('createdAt') or data.get('created_at')
        if previous and when and previous.get('reported_time') and when<previous['reported_time']:return
        digest=sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
        if previous and previous['digest']==digest and previous.get('deleted')==deleted:
            previous['observed_at']=stamp();self.revision+=1;return
        record=dict(api_family=family,id=ref,type=data.get('type','unknown'),seen=data.get('seen'),deleted=deleted,
            senderUserId=data.get('senderUserId',''),senderUsername=data.get('senderUsername',''),
            message=data.get('message') or data.get('title',''),reported_time=when,observed_at=stamp(),digest=digest,
            historical=False,actionable=False)
        self.notifications[key]=record;self.notifications.move_to_end(key)
        self.records[key]=dict(data,id=ref);self.records.move_to_end(key)
        while len(self.notifications)>1000:
            old,_=self.notifications.popitem(last=False);self.records.pop(old,None)
        self.revision+=1
        self.versions[key]=self.revision;self.versions.move_to_end(key)
        while len(self.versions)>2000:
            _,version=self.versions.popitem(last=False);self.floor=max(self.floor,version)
        if live and not previous and not deleted:self.delivery=(self.delivery+[dict(record,delivery_id=key)])[-200:]
        persisted={k:v for k,v in record.items() if k not in ('senderUsername','message')}
        if self.shell.store.option('native.history.private-text',False):persisted.update(senderUsername=record['senderUsername'],message=record['message'])
        self.shell.store.native.put(self.account,'notification',key,persisted,provenance={'source':'Live VRChat pipeline' if live else 'VRChat inbox snapshot'})

    def packet(self,kind,data):
        """Apply partial updates and tombstones without manufacturing action evidence."""
        if not self.sync() or data.get('receiverUserId',self.account)!=self.account:return
        if kind in ('notification','notification-v2'):
            self.notification(data,'v2' if kind.endswith('v2') else 'v1',live=True);return
        if kind=='clear-notification':
            self.revision+=1;self.cleared=self.revision
            keys=[key for key in self.notifications if key.startswith('v1:')]
        elif kind=='notification-v2-delete':keys=['v2:'+ref for ref in data['ids']]
        elif kind in ('see-notification','hide-notification','notification-v2-update'):
            keys=[('v2:' if kind=='notification-v2-update' else 'v1:')+data['id']]
        else:return
        for key in keys:
            family,ref=key.split(':',1)
            previous=self.records.get(key,{})
            row=dict(previous,id=ref)
            if kind=='notification-v2-update':row.update(data['updates'])
            elif kind=='see-notification':row['seen']=True
            deleted=kind in ('clear-notification','hide-notification','notification-v2-delete')
            self.notification(row,family,deleted=deleted)
            # Seen/deleted messages must not remain queued for a banner or speech.
            if deleted or row.get('seen') is True:self.delivery=[r for r in self.delivery if r['delivery_id']!=key]

    def project(self):
        if not self.sync():return dict(revision=self.revision,notifications=(),gaps=(),account='',coverage='Hidden or disconnected')
        revision=self.shell.store.native.revision()
        if getattr(self,'native_revision',None)!=revision:
            self.native_revision=revision
            with self.shell.store.native.connect() as db:
                forgotten={r[0] for r in db.execute("SELECT id FROM eye_native_suppressed WHERE scope=? AND kind='notification'",(self.account,))}
            for key in forgotten:self.notifications.pop(key,None);self.records.pop(key,None)
            self.delivery=[r for r in self.delivery if r['delivery_id'] not in forgotten]
        return dict(revision=self.revision,notifications=tuple(dict(r) for r in self.notifications.values()),gaps=tuple(self.gaps),account=self.account,
            coverage='Partial observed coverage; '+str(len(self.gaps))+' known gap(s)')


def hub_for(shell):
    hub=getattr(shell,'event_hub',None)
    if hub is None:hub=EventHub(shell);shell.event_hub=hub
    return hub
