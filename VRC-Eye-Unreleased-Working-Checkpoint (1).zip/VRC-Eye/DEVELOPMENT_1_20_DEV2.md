# VRC Eye 1.20.0 — Development checkpoint 2

This checkpoint builds on the verified Development 1 source archive, SHA-256
`0071900d96e85cf3a3f7bf5189ff33bdf31375536e355063443bea7719eb35ed`.
It implements the native avatar-library/inventory portion of the Release.zip
integration review. It is not the complete 1.20 roadmap or a complete ARC clone.

## Start

Close your previous VRC Eye instance. Back up your VRC Eye per-user data, including
the existing creator database, and retain your previous application folder. Extract
**the entire VRC-Eye-v1.20.0-Development-2.zip into a new folder**, open `VRC-Eye`,
and run **Start.cmd**. Do not run two copies against the same settings/databases.

The four launchers and requirements.txt are unchanged from Development 1. This is
the existing source-based application/launcher, not a newly signed Windows EXE.
Remember username/password and scoped Enter/keypad Enter behavior remain. Merely
opening the new workspace performs no networking, scanning, downloads or Unity work.

## Added in Development 2

**Primary → Players & avatars → Avatars → Library** contains Library, Details &
Builds, Local Files, Shader Packages and Activity sections. Ctrl+K finds these pages.
The command palette now exposes 85 destinations without dropping the final entries
from an empty-query listing. All previous creator tabs remain.

The native catalog provides stable-ID list/card browsing, saved thumbnails,
combined filters, local favorites/notes, explicit metadata imports and existing
search-result saves. Observed build records distinguish platform/Unity/asset/file
revision evidence and support A/B field comparison. Unknown or old data is not
recast as complete history or permission to edit.

The file inventory supports explicit registration, SHA-256 evidence, rechecks,
missing/changed states, duplicate-byte grouping and verified no-overwrite copying.
Originals remain unchanged. A completed transfer through the Library's existing
VRCA dialog route can be reviewed and registered; historic/other transfers are not
automatically backfilled. Cancellable workers and receipts stay bound to the
initiating account; a late completion cannot move into the newly selected account.

Local 2D preview attachment and reviewed remote thumbnails use bounded rendering.
Shader/source and supported ZIP/TAR/Unitypackage inspection is data-only, with
readable package/shader/material-reference/license-declaration summaries and optional
raw evidence. External material references are unresolved, not confirmed missing
shaders. No scripts are imported, no archives extracted, no shaders repaired.

Existing VCC project associations and creator handoffs are reused. The catalog
adds tables to the existing AvatarStore database rather than introducing another
app/provider/credential system. The new local Privacy view is deliberately scoped
to this workspace; standard selected-report exports omit paths/notes/images/account
IDs/provider URLs but retain reviewed avatar IDs and names.

Read **AVATAR_LIBRARY_1_20.md** for operations, explicit reviews, recovery and limits.

## Preserved Development 1 work

Creator Projects discovery/catalog/dependency evidence, reviewed new-copy VPM
adapters, template/editor handoffs, Editor Core source package, accessibility
foundations, Resource/VRCX repairs, Useful Links and navigation remain. Their
installed VPM/Unity/Windows/live-service verification limitations remain too.
DEVELOPMENT_1_20_DEV1.md and BASELINE_DEV1_VALIDATION.json are historical records,
not claims that those old test counts describe this checkpoint.

## Validation

BUILD_VALIDATION.json records the final actual test run, clean-package verification,
syntax checks and platform limitations. Tests use synthetic identities/assets,
controlled HTTP/providers and loopback fixtures with external sockets blocked.
Real Linux/Tk tests exercise cards, keyboard navigation, imports/reviews, file
registration/recheck/copy, package inspection, 2D previews, account changes during
jobs, privacy clearing, scoped exports, project associations and scaled sections.
The screenshots likewise contain only explicitly synthetic fixtures.

No live VRChat/VRCX account request/download, actual installed Unity/VPM run, C#
compilation, native Windows runtime or screen-reader interoperability test was
performed. The 2D preview is not an actual-model renderer. Passing offline tests
is not evidence that an external service currently accepts a particular request.

## Remaining scope

Full Social/Accounts, Photos, Invite Me, separate SDK/VCC release-download management,
remaining accessibility/XR work and deeper VCC integration remain pending. For the
ARC-inspired work, actual-model preview, Unity repairs/recovery, automatic backfill,
bulk operations and HTML gallery export remain conditional/pending. No supplied
ARC executable/DLL, authentication, service or bundled recovery/viewer was added.
No silent runtime dependency updater was introduced.

The status matrix distinguishes these remaining items from delivered code. Original
planning documents remain unchanged, including their historical version/hold text;
the later authorization to build supersedes the hold, not the evidence requirements.

## Final checkpoint results

Clean-extracted final source: **2,977 tests and 1,141 subtests passed**,
zero failures/errors/skips, one pre-existing TestListener collection warning.
The external-socket guard recorded zero blocked external attempts. All
308 Python files pass Python 3.10 grammar checks. The final archive retains
all 406 Development 1 paths and adds 9 files, for 415 packaged files.
All four launchers and requirements.txt are byte-identical to Development 1.
