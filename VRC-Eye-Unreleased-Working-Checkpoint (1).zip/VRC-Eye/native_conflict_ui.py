"""Per-field comparison inside the existing VRCX import review."""
from dataclasses import replace
import json

from companion_ui import Table, line, button, note
from native_conflicts import MAX_CHOICES, differences, key
from vrcx_ui_jobs import LocalPage


def show(owner):
    owner.ready()
    if not owner.preview or owner.review_form!=owner.form():raise ValueError('Prepare an import for the current selections first.')
    if not owner.preview.plan.conflicts:raise ValueError('This import has no conflicting records.')
    current=getattr(owner,'conflict_window',None)
    if current and not current.closed:current.window.lift();return current
    current=ConflictDialog(owner);owner.conflict_window=current;return current


def value_text(row,source):
    return json.dumps(row[source],ensure_ascii=False,indent=2) if row[source+'_present'] else '(field absent — choosing this removes it)'


class ConflictDialog(LocalPage):
    def __init__(self,owner):
        self.owner=owner;app=owner.app;self.owner_token=owner.token();self.review=owner.preview;self.review_form=owner.form()
        self.window=app.tk.Toplevel(owner.window);self.window.title('Choose imported fields');self.window.geometry('1080x790');self.window.transient(owner.window)
        self.window.minsize(760,560)
        from friendly_ui import ScrollPane
        self.viewport=ScrollPane(app,self.window,min_width=1040)
        frame=app.ttk.Frame(self.viewport.body,padding=12);frame.pack(fill='both',expand=True)
        super().__init__(owner.shell,frame,'Import conflict review')
        self.pairs=json.loads(self.review.plan.conflict_records_json);self.offset=0;self.field_rows=[];self.selected_key=None
        self.decisions={(tuple(r['key']),tuple(r['path'])):r['choice'] for r in json.loads(self.review.plan.choices_json)}
        self.updates={};self.count=self.tk.StringVar()
        note(self,'Compare each local value with the imported value. Unchanged choices follow the import policy: '+self.review.plan.policy+'. '
             'Lists are chosen as a whole. Applying choices updates the review; use Commit reviewed import to save the data.')
        self.record_table=Table(self,frame,(('scope','Workspace',180),('kind','Kind',100),('id','Record',570)),height=6,select=self.select_record)
        row=line(self);button(self,row,'Previous records',lambda:self.page(max(0,self.offset-100)));button(self,row,'Next records',lambda:self.page(self.offset+100))
        self.ttk.Label(row,textvariable=self.count).pack(side='left',padx=8)
        self.field_table=Table(self,frame,(('path','Field',200),('local','Local value',310),('incoming','Imported value',310),('choice','Choice',130)),height=6,select=self.select_field)
        panes=self.ttk.Frame(frame);panes.pack(fill='both',expand=True)
        self.values={}
        for label,source in (('Local value','local'),('Imported value','incoming')):
            box=self.ttk.LabelFrame(panes,text=label,padding=4);box.pack(side='left',fill='both',expand=True)
            widget=self.tk.Text(box,height=7,width=50,wrap='word',state='disabled');widget.pack(side='left',fill='both',expand=True)
            scroll=self.ttk.Scrollbar(box,orient='vertical',command=widget.yview);scroll.pack(side='right',fill='y');widget.configure(yscrollcommand=scroll.set)
            self.values[source]=widget
        row=line(self)
        for label,take in (('Keep local field','local'),('Use imported field','incoming'),('Use import policy','policy')):
            button(self,row,label,lambda take=take:self.choose(take))
        row=line(self);button(self,row,'Keep every field in selected record',lambda:self.choose('local',whole=True))
        button(self,row,'Use every imported field in selected record',lambda:self.choose('incoming',whole=True))
        row=line(self);button(self,row,'Apply choices to review',self.apply);button(self,row,'Discard changes',self.close)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(150,self.tick);self.page(0)

    def valid(self):
        self.owner.verify(self.owner_token)
        if self.owner.preview is not self.review or self.owner.form()!=self.review_form:raise ValueError('The import selection changed. Prepare the review again.')

    def page(self,offset):
        self.ready();self.valid()
        if offset and offset>=len(self.pairs):return
        self.offset=offset;self.record_table.set(self.pairs[offset:offset+100],lambda pair:(pair[0]['scope'],pair[0]['kind'],pair[0]['id']))
        self.field_rows=[];self.selected_key=None;self.field_table.set([],lambda r:());self.clear_values()
        self.count.set(f'{len(self.pairs):,} conflicting records · page {offset//100+1} · {len(self.decisions):,} field choices')

    def clear_values(self):
        for widget in self.values.values():widget.configure(state='normal');widget.delete('1.0','end');widget.configure(state='disabled')

    def select_record(self):
        self.ready();self.valid();pair=self.record_table.selected();self.clear_values()
        if not pair:return
        self.selected_key=key(pair[0]);self.field_rows=differences(pair[0]['data'],pair[1]['data']);self.render_fields()

    def render_fields(self):
        self.field_table.set(self.field_rows,lambda r:(json.dumps(r['path'],ensure_ascii=False),
            value_text(r,'local')[:140],value_text(r,'incoming')[:140],
            self.decisions.get((self.selected_key,tuple(r['path'])),'Import policy')))
        self.count.set(f'{len(self.pairs):,} conflicting records · page {self.offset//100+1} · {len(self.decisions):,} field choices')

    def select_field(self):
        self.ready();self.valid();row=self.field_table.selected();self.clear_values()
        if not row:return
        for source,widget in self.values.items():
            widget.configure(state='normal');widget.insert('1.0',value_text(row,source));widget.configure(state='disabled')

    def choose(self,take,whole=False):
        self.ready();self.valid()
        rows=self.field_rows if whole else [self.field_table.selected()]
        if not rows or not rows[0]:raise ValueError('Select a conflicting field first.')
        decisions=dict(self.decisions);updates=dict(self.updates)
        for row in rows:
            ident=(self.selected_key,tuple(row['path']));updates[ident]=take
            if take=='policy':decisions.pop(ident,None)
            else:decisions[ident]=take
        if max(len(decisions),len(updates))>MAX_CHOICES:raise ValueError('Apply at most 10,000 field choices in one review.')
        self.decisions=decisions;self.updates=updates;self.render_fields()

    def apply(self):
        self.ready();self.valid();token=self.token()
        if not self.updates:raise ValueError('Choose a field before applying changes.')
        choices=[dict(key=list(k),path=list(p),choice=take) for (k,p),take in self.updates.items()]
        def check():
            # Worker checks use Python context/revision state only. Tk variables
            # are compared on the UI thread before and after this worker.
            self.verify(token);self.owner.verify(self.owner_token)
            if self.owner.preview is not self.review:raise ValueError('The import review changed.')
        def done(plan):
            self.valid();report=dict(self.review.report,native_changes=len(plan.records),field_choices=len(json.loads(plan.choices_json)))
            self.owner.preview=replace(self.review,plan=plan,report=report)
            self.owner.summary.set(f"{report['source_rows']:,} source rows → {report['native_changes']:,} native changes; {report['conflicts']:,} conflicts; {report['field_choices']:,} explicit field choices.\n"+
                '\n'.join(report['warnings']+report['incomplete']))
            self.close()
        self.start(lambda c,s,p:self.owner.library.resolve_fields(self.review.plan,choices,stop=s,check=check),done)

    def clear_preview(self):
        self.close()

    def tick(self):
        if self.closed:return
        self.tick_job()
        if self.closed:return
        try:self.valid()
        except ValueError:self.close();return
        self.timer=self.app.root.after(150,self.tick)

    def close(self):
        if self.closed:return
        super().close();self.pairs=[];self.field_rows=[];self.decisions={};self.updates={};self.review=None
        self.record_table.set([],lambda r:());self.field_table.set([],lambda r:());self.clear_values()
        self.app.root.after_cancel(self.timer);self.window.destroy()
        if getattr(self.owner,'conflict_window',None) is self:self.owner.conflict_window=None
