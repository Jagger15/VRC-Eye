"""Bounded account-scoped presets and search preferences in CompanionStore."""
from contextlib import contextmanager
import hashlib
import json
import time

from account_actions import text
from companion_data import entity_id
from player_profile import STATUSES


def scope(value):
    return 'local' if value == 'local' else entity_id('user', value)


def preset(value):
    if not isinstance(value, dict) or set(value) != {'status', 'statusDescription'}:
        raise ValueError('A preset contains only status and statusDescription.')
    if value['status'] not in STATUSES.values():
        raise ValueError('Choose a supported status.')
    return {'status': value['status'], 'statusDescription': text(value['statusDescription'], 32)}


def search(value):
    expected = {'schema', 'kind', 'query', 'scope', 'sort'}
    if not isinstance(value, dict) or set(value) != expected or type(value['schema']) is not int or value['schema'] != 1:
        raise ValueError('Unsupported saved search schema.')
    kind = value['kind']
    scopes = {'Users': ('Public / featured',), 'Groups': ('Public / featured',),
              'Worlds': ('Public / featured', 'My uploads'),
              'Avatars': ('Public / featured', 'My uploads', 'My avatar favorites')}
    if not isinstance(kind, str) or kind not in scopes or value['scope'] not in scopes[kind] or value['sort'] != 'Provider default':
        raise ValueError('Choose a supported collection for this search type. Sorting follows the existing provider.')
    query = text(value['query'], 512)
    if '://' in query:
        query = entity_id({'Users': 'user', 'Worlds': 'world', 'Groups': 'group', 'Avatars': 'avatar'}[kind], query)
    if any(token in query.casefold() for token in ('~nonce(', '~private(', '~hidden(', 'authtoken=', 'token=', 'password=')):
        raise ValueError('Saved searches cannot contain instance capabilities or credentials.')
    return dict(schema=1, kind=kind, query=query, scope=value['scope'], sort='Provider default')


class LocalPreferences:
    def __init__(self, store):
        self.store = store

    @contextmanager
    def connect(self):
        with self.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS account_local_121(account TEXT NOT NULL, kind TEXT NOT NULL, key TEXT NOT NULL, label TEXT NOT NULL, value TEXT NOT NULL, updated INTEGER NOT NULL, PRIMARY KEY(account,kind,key))')
            yield db

    def rows(self, account, kind):
        account = scope(account)
        if kind not in ('preset', 'search', 'recent'):
            raise ValueError('Unsupported local collection.')
        limit = 10 if kind == 'preset' else 50 if kind == 'search' else 20
        with self.connect() as db:
            rows = db.execute('SELECT key,label,value FROM account_local_121 WHERE account=? AND kind=? ORDER BY updated DESC LIMIT ?', (account, kind, limit)).fetchall()
        result = []
        for key, label, raw in rows:
            if len(raw) > 4096:
                raise ValueError('Stored preferences exceed the supported size.')
            value = (preset if kind == 'preset' else search)(json.loads(raw))
            result.append(dict(key=key, label=text(label, 80), value=value))
        if kind=='preset':
            from native_library import scope as native_scope
            known={json.dumps(r['value'],sort_keys=True) for r in result}
            for target in dict.fromkeys((native_scope(account),'shared')):
                for record in self.store.native.rows(target,'preference',limit=1000)[0]:
                    data=record['data']
                    if data.get('type')!='status-preset':continue
                    try:value=preset(data.get('values'))
                    except ValueError:continue
                    if json.dumps(value,sort_keys=True) in known:continue
                    known.add(json.dumps(value,sort_keys=True))
                    result.append(dict(key='native:'+target+':'+record['id'],label=text(data.get('name','Imported preset'),80),value=value))
        return result

    def save(self, account, kind, label, value):
        account = scope(account)
        if kind not in ('preset', 'search', 'recent') or kind == 'preset' and account == 'local':
            raise ValueError('Status presets require the active account workspace.')
        value = (preset if kind == 'preset' else search)(value)
        label = text(label, 80)
        if not label:
            raise ValueError('Enter a local name.')
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)
        key = hashlib.sha256(raw.encode()).hexdigest()  # Exact duplicate values coalesce.
        limit = 10 if kind == 'preset' else 50 if kind == 'search' else 20
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            exists = db.execute('SELECT 1 FROM account_local_121 WHERE account=? AND kind=? AND key=?', (account, kind, key)).fetchone()
            count = db.execute('SELECT COUNT(*) FROM account_local_121 WHERE account=? AND kind=?', (account, kind)).fetchone()[0]
            if not exists and count >= limit and kind != 'recent':
                raise ValueError(f'This account already has {limit} entries. Remove one first.')
            if not exists and db.execute('SELECT COUNT(*) FROM account_local_121').fetchone()[0] >= 8192:
                raise ValueError('Local preference storage is full. Remove unused entries first.')
            db.execute('INSERT OR REPLACE INTO account_local_121 VALUES(?,?,?,?,?,?)', (account, kind, key, label, raw, time.time_ns()))
            if kind == 'recent':
                db.execute('DELETE FROM account_local_121 WHERE account=? AND kind=? AND key NOT IN (SELECT key FROM account_local_121 WHERE account=? AND kind=? ORDER BY updated DESC LIMIT 20)', (account, kind, account, kind))
        return key

    def remove(self, account, kind, key=None):
        account = scope(account)
        if isinstance(key,str) and key.startswith('native:'):
            _,target,ref=key.split(':',2)
            if target not in ('shared',account):raise ValueError('This imported preset belongs to another workspace.')
            return self.store.native.forget(target,'preference',ref)
        if kind not in ('preset', 'search', 'recent'):
            raise ValueError('Unsupported local collection.')
        with self.connect() as db:
            if key is None:
                db.execute('DELETE FROM account_local_121 WHERE account=? AND kind=?', (account, kind))
            else:
                db.execute('DELETE FROM account_local_121 WHERE account=? AND kind=? AND key=?', (account, kind, key))

    def remembering(self, account, value=None):
        account = scope(account)
        with self.connect() as db:
            if value is not None:
                if type(value) is not bool:
                    raise ValueError('Choose whether to remember recent searches.')
                db.execute('INSERT OR REPLACE INTO account_local_121 VALUES(?,?,?,?,?,?)', (account, 'preference', 'recent', '', json.dumps(value), time.time_ns()))
            row = db.execute("SELECT value FROM account_local_121 WHERE account=? AND kind='preference' AND key='recent'", (account,)).fetchone()
        return bool(row and row[0] == 'true')
