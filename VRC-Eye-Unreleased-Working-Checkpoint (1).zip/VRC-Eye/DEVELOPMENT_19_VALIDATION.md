# Development 19 validation

The final unified build passed **5,060 tests and 1,059 subtests**, with **zero
failures/errors** and **zero blocked external-socket attempts**, in **126.85 seconds**.
All **28 new Development 19 cases** are included, alongside the complete inherited
portable regression including the Development 18 GLB and direct-settings tests.

**475 native-GUI tests were skipped**, **1 Unix bridge case was deselected**, and
**13 local-transport modules were excluded**, retaining the Development 18 gates.
Skips and exclusions are not passes. Two inherited warnings remain: TestListener
collection and the intentionally duplicate VRChat.exe archive fixture.

New cases cover combined conditions, contradictory/duplicate/oversized inputs,
unknown power state, evaluation without mutation, shared backup/history behavior,
field-level undo preserving later edits, temporary/persistent selection interaction,
no-write pause, timer preservation, privacy clearing, empty views and real editor
callbacks using headless display adapters.

All **597 Python files** parse under Python 3.10 grammar. All **642 frozen source
hashes** match after the final run; no runtime/test edits followed that run.
ZIP packaging checks CRCs and compares all member bytes against source. All
**801 Development 18 archive paths** are retained. Launchers, requirements,
static GLB provider/viewer code and the shared settings-history owner are unchanged.
Parent archive SHA-256: `3c8dd442c3aaab77c0f477c2e2b9025aa070314e8e1664fb176566a53679cb5b`.

Native Windows/Linux GUI rendering, keyboard navigation, high contrast, large text,
Windows parser lifecycle, installed AssetRipper/Unity, live VRChat/CDN and SteamVR
acceptance remain unverified. Headless UI checks are not native visual acceptance.
No live VRChat action or third-party model was used. The inherited scene parser
provides process fault separation, not an OS security sandbox.

## Exact portable regression command

```bash
PYTHONPATH=.:tests python3 -m pytest -q --tb=short -rf -p tools.offline_test_guard --durations=10 -o faulthandler_timeout=60 --ignore=tests/test_media_mpris_bus_121.py --ignore=tests/test_session_secret_service_protocol.py --ignore=tests/test_peer_transport.py --ignore=tests/test_networking_integration.py --ignore=tests/test_osc_transport.py --ignore=tests/test_osc_discovery.py --ignore=tests/test_osc_simulator.py --ignore=tests/test_avatar_link.py --ignore=tests/test_avatar_osc.py --ignore=tests/test_avatar_creator_app.py --ignore=tests/test_rangefinder.py --ignore=tests/test_camera_capture.py --ignore=tests/test_osc_avatar.py --deselect=tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore --junitxml=../release-dev19-tests.xml
```

## Retained local-transport exclusions

- tests/test_media_mpris_bus_121.py
- tests/test_session_secret_service_protocol.py
- tests/test_peer_transport.py
- tests/test_networking_integration.py
- tests/test_osc_transport.py
- tests/test_osc_discovery.py
- tests/test_osc_simulator.py
- tests/test_avatar_link.py
- tests/test_avatar_osc.py
- tests/test_avatar_creator_app.py
- tests/test_rangefinder.py
- tests/test_camera_capture.py
- tests/test_osc_avatar.py
