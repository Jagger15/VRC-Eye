"""Explicit, bounded take baking. The caller runs this after kernel containment."""
from dataclasses import asdict,replace
import math
from avatar_scene import integer,vector
from avatar_animation import Animation,Clip,Frame,decode,MAX_FRAME_NODES,MAX_FRAME_VERTICES


def request(raw):
    if not isinstance(raw,dict) or set(raw)!={'take','start','end','rate'}:raise ValueError('Invalid FBX take preparation request.')
    take=integer(raw['take'],0,63);rate=integer(raw['rate'],1,12)
    start,end=vector([raw['start'],raw['end']],2)
    if not -86400<=start<=end<=86400 or end-start>10:raise ValueError('Choose up to 10 seconds within the take, at 1–12 samples per second.')
    return dict(take=take,start=start,end=end,rate=rate)


def prepare(source,selected,raw):
    from avatar_fbx_scene import parse
    opts=request(raw);cache={};scene=parse(source,selected,texture_cache=cache)
    take=opts['take'];start=opts['start'];end=opts['end'];rate=opts['rate']
    if take>=len(scene.import_report.takes):raise ValueError('Select an existing FBX take.')
    label,lo,hi,layers=scene.import_report.takes[take]
    if start<lo or end>hi:raise ValueError('Choose a range within the selected FBX take.')
    steps=math.ceil((end-start)*rate);count=steps+1
    if count*len(scene.nodes)>MAX_FRAME_NODES or count*sum(len(p.vertices) for p in scene.parts)>MAX_FRAME_VERTICES:
        raise ValueError('This range exceeds 300,000 retained vertices or 20,000 node matrices. Shorten the range or lower the sample rate.')
    frames=[]
    for i in range(count):
        at=end if i==steps else start+i/rate
        pose=parse(source,selected,sample=(take,at),texture_cache=cache)
        # Only numeric poses/colors may vary. Object-reference swaps and UV or
        # texture animation must not be mislabeled as supported material swaps.
        if tuple((n.index,n.parent,n.name) for n in pose.nodes)!=tuple((n.index,n.parent,n.name) for n in scene.nodes) or len(pose.parts)!=len(scene.parts) or len(pose.materials)!=len(scene.materials):
            raise ValueError('FBX take changes the scene catalog; export individual clips with stable topology.')
        if any(replace(a,vertices=b.vertices,health=b.health)!=b for a,b in zip(pose.parts,scene.parts)) or any(replace(a,base_color=b.base_color)!=b for a,b in zip(pose.materials,scene.materials)) or pose.textures!=scene.textures:
            raise ValueError('FBX take changes topology, UVs or material/texture bindings; that animation is unsupported.')
        frames.append(Frame(at,tuple(n.matrix for n in pose.nodes),tuple(p.vertices for p in pose.parts),tuple(m.base_color for m in pose.materials)))
    clip=Clip(label,start,end,frames=tuple(frames),notes=(
        f'ufbx 0.23.1 sampled {layers} stored animation layers at up to {rate} Hz, including both endpoints. Poses hold between samples.',
        'Node transforms, stored skin/blend deformation and diffuse colors only. Constraints, events, controllers, object-reference swaps, humanoid retargeting, audio and network actions do not run.'))
    animation=decode(asdict(Animation((),(clip,))),scene)
    return replace(scene,animations=animation)
