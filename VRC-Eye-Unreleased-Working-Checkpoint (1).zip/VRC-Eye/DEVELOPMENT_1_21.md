# VRC Eye 1.21.0 — Development checkpoint 15

Current build: [continuation and setup](CONTINUATION_DEV15.md). The complete saved Development 14 implementation is retained. See [current validation](VALIDATION_1_21.md) and [all remaining ARC/VRCX areas](ARC_VRCX_REMAINING_DEV15.md).

The following Development 7 and earlier notes are retained historical context.

# VRC Eye 1.21.0 — Development checkpoint 7

This build enhances the existing VRC Eye workspaces with native VRCX replacement
features. VRCX can supply selected migration data; it is not required for daily
use. The previous compass, media, creator and external diagnostics remain included.
The full replacement roadmap is still in progress.

## New in Development 7

Preserves every Development 6 feature and expands its existing History & discovery
page with category/undated filters, timezone-aware displays, explicit time evidence,
source/account checks, segmented encounter durations and cancelable reviewed CSV
exports. Feed and the data manager open the same page. See
[the continuation guide](HISTORY_CONTINUATION_DEV7.md).

## Retained from Development 6

Adds cross-source history, discovery and graphs; durable reviewed batch queues;
owned appearance choices and themes; group instances/gallery images; native joins;
local speech/shared SteamVR feed and richer Discord presence; account isolation,
local locking, WAL snapshots, three-way imports, coordinated history deletion,
verified photo recovery and profile backup/recovery. See
[the feature guide and remaining gaps](VRCX_COMPLETION_DEV6.md).

## New in Development 5

Adds field-by-field VRCX import conflict choices, group role deletion and gallery
administration, filtered inventory with unequip and three additional cosmetic
slots, and animated emoji playback/frame-rate presets. Reward-redemption reply
handling is corrected. See [the batch guide](VRCX_BATCH1_1_21.md) for entry points
and remaining scope.

## Start and update

Close the old copy, extract the ZIP into a separate folder, open `VRC-Eye`, and
run **Start.cmd** on Windows or **bash Start.sh** on Linux. Python 3.10 or newer
with Tkinter is required; Linux also needs venv support. The launcher prepares
the app-local dependencies. QR pairing and optional tray dependencies
are `qrcode` and `pystray`; OS trash adds `Send2Trash==2.1.0`. Demo and Safe-mode launchers remain available without
installing feature dependencies. With a prepared environment, run `python vrc_eye.py`.

Keep the old copy and back up your per-user VRC Eye data before moving important
data into the new collection model. Different extraction folders share the same
per-user data locations. Retained legacy tables are not a complete reverse
migration: new native collection edits will not all appear in older builds.
This package contains runnable source, not a compiled executable or signed installer.

## Existing workspaces, expanded

| Workspace | Changes |
| --- | --- |
| Favorites / VRCX Companion | Native collections, multiple memberships, notes, tags, ordering and empty groups; existing favorites and CSV/ID exchange share the same records. Selected VRCX database migration has explicit scope/account mapping, conflict review, receipts and conditional rollback. Native backups use checksummed JSONL with reviewed atomic restore. |
| Search | Image tiles for players, worlds and avatars; bounded thumbnail loading; instant local entity/annotation search; explicit optional avatar metadata provider selection. |
| Accounts / Social | Protected retained-account switching; shared profile and world editors; a unified notification inbox; ordinary invitation replies, saved invitation messages and photo invitations; group membership, moderation, role, post, calendar and lifecycle actions. |
| Account media / Inventory | Reviewed image preparation, gallery/icon/sticker/emoji/print workflows, owned-avatar/world cover uploads, inventory browsing, consumption, rewards, archive state and supported equipment slots. Cover upload and attachment are separate reviewed actions. |
| Photos | Image-loading repairs, recursive indexing, imported context and searchable metadata, selected-file relinking, original-preserving metadata copies, and reviewed file organization with recovery and undo. |
| Home / Customization | Shared inbox and desktop summaries, saved layouts, themes, hue and typography settings; Desktop controls for quiet hours, coalesced notifications, local Discord presence, optional tray, approved application starts, crash recovery, configuration edits and preference profiles. |
| Networking | Foreground local-network mobile pairing with a QR code and pinned TLS identity; requires a compatible mobile app. |

Migration and backups are available from the existing Favorites/VRCX tools and
Desktop controls. Close VRCX before selecting its database: an active WAL/SHM
source is rejected. Reviews retain exact source and destination checks; credentials
are not imported. Restore and forgetting operations should be reviewed carefully
because they change local records. Photo metadata describes recorded context;
it does not prove who is visible in an image.

Desktop notifications, public status checks, optional translation/media lookups,
Discord and program starts remain separately configured. Discord needs your own
registered application ID. Remote service writes require account access and an
explicit action review. Signing in does not guarantee service entitlement.

## Requested fixes retained

- Hidden account information can be revealed again; display-name styling follows
  the login accent. Section disclosure buttons retain navigation and Home while
  removing the redundant current-page wording.
- Photo view state and thumbnail loading are corrected. Search tiles show names
  and appropriate images for worlds, players and avatars.
- VRChat SDK and VCC download sources are separate from the useful Unity archive
  downloads. Files are downloaded with reviewed destinations; installation is separate.
- Performance and security views distinguish measured, stale and unavailable
  evidence and use reviewed exact-process actions. They are not a complete security scanner.

## Remaining work and acceptance

The VRCX ledger has **32 source-implemented and 50 partial packages**. Remaining
scope is recorded per package in [implementation status](IMPLEMENTATION_STATUS_1_21.md).
Examples include complete legacy timeline/graph migration, gallery image
management, longer moderation batches, cosmetic/template drilldowns,
speech/VR notifications, richer Discord join features and signed update installation.
Group batch reviews currently accept one or two targets. Native backup restore
supports up to 500,000 records / 256 MiB; ordinary VRCX import review supports
10,000 records / 32 MiB. History filters apply before that selection budget.

Real Windows tray/startup/credential behavior, SteamVR hardware, audio devices,
Unity compilation, live VRChat API writes, installed VRCX migration and physical
phone pairing have not been accepted in this build environment. Offline tests
cover their supported contracts and failure cases; see [validation](VALIDATION_1_21.md).
OS startup configuration requires a packaged executable and remains unavailable
from this source launcher. No signed automatic updater is included.

Historical checkpoints: [Development 4](DEVELOPMENT_1_21_DEV4.md),
[Development 3](DEVELOPMENT_1_21_DEV3.md),
[Development 2](DEVELOPMENT_1_21_DEV2.md), and
[external tracking guide](EXTERNAL_TRACKING_GUIDE.md).
