"""Explicit, cancellable photo tasks and one-use reviewed exports.

One service belongs to the sidebar, one task at a time. Receipts are committed
before work; a finished export is retained in its initiating scope even when the
visible account changes immediately afterward. No polling, network or OSC here.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
import threading
import time
import uuid

from account_actions import local_writable
from avatar_library import active_scope, context_token, scope_id
from avatar_library_files import check_cancel, InspectionCancelled, fingerprint
from creator_projects import assert_no_links, local_path
from photo_files import (MAX_BYTES, inspect_photo, read_photo, walk_source, verified_data,
                         normalize_recipe, render, save_new, check_directory, directory_identity)
from photo_store import PhotoStore, key, retained_session

IMPORT_LIMIT = 256
IMPORT_BYTE_BUDGET = 512 * 1024 * 1024
IMPORT_SECONDS = 120
REVIEW_SECONDS = 300


@dataclass(frozen=True)
class ExportReview:
    id: str
    scope: str
    photo: str
    source_digest: str
    recipe_json: str
    output: bytes
    preview: bytes
    output_digest: str
    expires: float
    token: tuple


@dataclass(frozen=True)
class SheetReview:
    id: str
    scope: str
    selection_json: str
    layout_json: str
    evidence_json: str
    output: bytes
    preview: bytes
    output_digest: str
    expires: float
    token: tuple


class PhotoService:
    def __init__(self,app,store,*,clock=time.monotonic):
        self.app=app;self.store=store;self.clock=clock
        self.lock=threading.RLock();self.active=False;self.reviews={};self.volatile={}

    def scope(self):return active_scope(self.app)
    def token(self):return context_token(self.app)

    def check(self,token,stop=None):
        check_cancel(stop)
        local_writable(self.app)
        if self.token()!=token:raise InspectionCancelled('Account or operating mode changed. No further photos will be imported in this task.')

    def execute(self,operation,work,*,token=None,stop=None,progress=None):
        """Callback returns (result, completion state, safe summary)."""
        token=self.token() if token is None else token; self.check(token,stop); scope=scope_id(token[2] if token[1] else 'local')
        with self.lock:
            if self.active:raise ValueError('A photo task is still running or stopping. Wait for its outcome.')
            receipt=self.store.begin_job(scope,operation);self.active=True
        state='Failed';result=None;detail='The task ended without a complete result.'
        try:
            self.check(token,stop)
            result,state,detail=work(scope,token,stop,progress or (lambda x:None))
        except InspectionCancelled:
            state='Cancelled';detail='Cancellation stopped further work. Previously imported records or completed exports remain in their initiating workspace.'
        except (ValueError,OSError,sqlite3.Error) as error:
            state='Failed';detail='The task could not finish: '+str(error)[:700]
        except Exception:
            state='Failed';detail='Unexpected input or storage failure; no automatic retry. Inspect the local outcome before repeating.'
        try:self.store.finish_job(scope,receipt,state,detail)
        except (ValueError,OSError,sqlite3.Error):
            with self.lock:self.volatile[receipt]=(scope,state,detail)
            detail+=' Final receipt save failed; the Running record may need manual review after restart.'
        finally:
            with self.lock:self.active=False
        return {'state':state,'detail':detail,'result':result,'receipt':receipt,'scope':scope}

    def import_paths(self,paths,*,source_id='',minimum_age=0):
        paths=tuple(str(local_path(p)) for p in paths)
        if not paths:raise ValueError('Select at least one photo.')
        if len(paths)>IMPORT_LIMIT:raise ValueError('Select at most 256 individual photos per import.')
        def work(scope,token,stop,progress):
            totals={'imported':0,'unchanged':0,'replaced':0,'skipped':0,'last_photo':'','errors':[]}
            started=self.clock();read_bytes=0
            for index,path in enumerate(paths):
                self.check(token,stop)
                try:
                    info=assert_no_links(local_path(path)).stat()
                    if read_bytes+info.st_size>IMPORT_BYTE_BUDGET or self.clock()-started>IMPORT_SECONDS:
                        totals['skipped']+=len(paths)-index;break
                    read_bytes+=info.st_size
                    observed=inspect_photo(path,stop=stop,minimum_age=minimum_age)
                    self.check(token,stop)
                    identity,state=self.store.observe(scope,observed,source_id=source_id)
                    totals[{'Unchanged':'unchanged','New version':'replaced','Imported':'imported'}[state]]+=1
                    totals['last_photo']=identity
                except InspectionCancelled:raise
                except (OSError,ValueError) as error:
                    totals['skipped']+=1
                    if len(totals['errors'])<10:totals['errors'].append(f'Item {index+1}: '+self.import_error(error))
                progress(f'Processed {index+1}/{len(paths)} selected photos.')
            state='Partial' if totals['skipped'] else 'Complete'
            return totals,state,self._summary(totals)
        return work

    @staticmethod
    def _summary(t):
        result=f"{t['imported']} new, {t['replaced']} new versions, {t['unchanged']} unchanged, {t['skipped']} not imported. Originals were not modified."
        if t.get('errors'):result+='\n'+'\n'.join(t['errors'][:3])
        return result

    @staticmethod
    def import_error(error):
        from avatar_creator_store import sanitize_export
        if isinstance(error,PermissionError):return 'Access denied. Choose a readable local photo or folder.'
        if isinstance(error,FileNotFoundError):return 'File unavailable. Make cloud photos available offline, then retry.'
        return sanitize_export(str(error))[:240] or 'Unsupported or unreadable image.'

    def scan(self,source_id):
        def work(scope,token,stop,progress):
            source=self.store.source(scope,source_id)
            if not source:raise ValueError('The source is no longer approved for this workspace.')
            try:
                walk=walk_source(source['path'],recursive=source['recursive'],expected=source['identity'],stop=stop,progress=progress)
            except (OSError,ValueError):
                self.store.source_state(scope,source_id,'Unavailable or replaced; records retained')
                raise
            totals={'imported':0,'unchanged':0,'replaced':0,'skipped':0,'last_photo':'','errors':[],'complete':walk.complete}
            start=self.clock(); processed=0;read_bytes=0
            for path in walk.files:
                self.check(token,stop)
                # Cheap stable-stat skip makes explicit incremental rescans advance
                # without repeatedly decoding every previously imported photo.
                old=self.store.by_path(scope,path)
                try:
                    info=assert_no_links(local_path(path)).stat()
                    if old and old['status']=='Available' and old['thumbnail'] and fingerprint(info)==old['fingerprint']:
                        if old['source_id']!=source_id:
                            self.check(token,stop);check_directory(source['path'],source['identity'])
                            if self.store.source(scope,source_id)!=source:raise InspectionCancelled('Photo source changed. Scan cancelled.')
                            self.store.associate_source(scope,old['id'],source_id)
                        totals['unchanged']+=1;totals['last_photo']=old['id'];continue
                    if self.store.is_export(path):
                        totals['skipped']+=1;continue
                    if processed>=IMPORT_LIMIT or read_bytes+info.st_size>IMPORT_BYTE_BUDGET or self.clock()-start>IMPORT_SECONDS:
                        totals['complete']=False;break
                    processed+=1;read_bytes+=info.st_size
                    observed=inspect_photo(path,stop=stop,minimum_age=1)
                    self.check(token,stop);check_directory(source['path'],source['identity'])
                    # Re-approval/removal while a task runs invalidates remaining work.
                    if self.store.source(scope,source_id)!=source:raise InspectionCancelled('Photo source changed. Scan cancelled.')
                    identity,state=self.store.observe(scope,observed,source_id=source_id)
                    totals[{'Unchanged':'unchanged','New version':'replaced','Imported':'imported'}[state]]+=1
                    totals['last_photo']=identity
                except InspectionCancelled:raise
                except (OSError,ValueError) as error:
                    totals['skipped']+=1
                    if len(totals['errors'])<10:totals['errors'].append(f'Item {processed}: '+self.import_error(error))
                    if old:self.store.availability(scope,old['id'],'Unreadable')
                progress(f"Scan: {totals['imported']+totals['replaced']} imported; {totals['unchanged']} unchanged; {totals['skipped']} skipped.")
            self.check(token,stop);check_directory(source['path'],source['identity'])
            if totals['complete']:
                self.store.missing_after_scan(scope,source_id,walk.files)
            note='Complete' if totals['complete'] and not totals['skipped'] else 'Partial'
            self.store.source_state(scope,source_id,note+' scan; '+str(len(walk.files))+' candidates')
            hint=(' No supported images were found. If your photos are in date folders, enable Include subfolders and reapprove this source.'
                  if not walk.files and not source['recursive'] else '')
            return totals,note,self._summary(totals)+hint+(' Run Scan again to continue within the bounded import budget.' if not totals['complete'] else '')
        return work

    def recheck(self,photo_id):
        def work(scope,token,stop,progress):
            row=self.store.get(scope,photo_id)
            if not row:raise ValueError('Select an existing photo.')
            if row['status']=='Replaced':raise ValueError('This old version was replaced at its location. Relink identical bytes or select the newer photo.')
            state='Available';observation=None
            try:
                observation=inspect_photo(row['path'],stop=stop)
                if observation['sha256']!=row['sha256']:state='Changed'
            except FileNotFoundError:state='Missing'
            except InspectionCancelled:raise
            except (OSError,ValueError):state='Unreadable'
            self.check(token,stop)
            if state=='Available':self.store.observe(scope,observation,source_id=row['source_id'])
            else:self.store.availability(scope,photo_id,state)
            return state,'Complete','Photo recheck: '+state+'. No original was changed.'
        return work

    def prepare_export(self,photo_id,recipe,*,token=None,stop=None):
        token=self.token() if token is None else token;self.check(token,stop);scope=scope_id(token[2] if token[1] else 'local')
        row=self.store.get(scope,photo_id)
        if not row or row['hidden'] or row['status']!='Available':raise ValueError('Select a visible, available photo.')
        recipe=normalize_recipe(recipe);data=verified_data(row,stop=stop)
        output=render(data,recipe);self.check(token,stop)
        preview=render(output,{'max_edge':1200},preview_edge=1200)
        result=ExportReview(str(uuid.uuid4()),scope,photo_id,row['sha256'],json.dumps(recipe,sort_keys=True),output,preview,sha256(output).hexdigest(),self.clock()+REVIEW_SECONDS,token)
        with self.lock:
            self.reviews.clear()  # At most one full-size reviewed image retained.
            self.reviews[result.id]=result
        return result

    def discard_reviews(self):
        with self.lock:self.reviews.clear()

    def prepare_sheet(self,selection,settings,*,token=None,stop=None,progress=None):
        from photo_composite import slots,layout,geometry,render_sheet
        token=self.token() if token is None else token;self.check(token,stop)
        scope=scope_id(token[2] if token[1] else 'local')
        selection=slots(selection);settings=layout(settings);geometry(settings,len(selection));evidence={}
        def read(identity):
            self.check(token,stop);row=self.store.get(scope,identity)
            if not row or row['hidden'] or row['status']!='Available':raise ValueError('A contact-sheet photo is missing, hidden or unavailable.')
            data=verified_data(row,stop=stop);evidence[identity]=row['sha256'];return data
        output=render_sheet(selection,settings,read,stop=stop,progress=progress);self.check(token,stop)
        preview=render(output,{'max_edge':1200},preview_edge=1200)
        result=SheetReview(str(uuid.uuid4()),scope,json.dumps(selection,sort_keys=True),json.dumps(settings,sort_keys=True),
                           json.dumps(evidence,sort_keys=True),output,preview,sha256(output).hexdigest(),self.clock()+REVIEW_SECONDS,token)
        with self.lock:
            self.reviews.clear();self.reviews[result.id]=result
        return result

    def export_sheet(self,review,destination):
        destination=assert_no_links(local_path(destination))
        if destination.suffix.lower()!='.png':raise ValueError('Choose a new PNG filename.')
        parent_identity=directory_identity(destination.parent)
        def work(scope,token,stop,progress):
            with self.lock:found=self.reviews.pop(getattr(review,'id',None),None)
            if found is not review or token!=review.token or scope!=review.scope or self.clock()>=review.expires:
                raise ValueError('The contact-sheet review expired, changed, was used or belongs to another context. Preview again.')
            evidence=json.loads(review.evidence_json);selection=json.loads(review.selection_json);settings=json.loads(review.layout_json)
            for identity,digest in evidence.items():
                self.check(token,stop);row=self.store.get(scope,identity)
                if not row or row['hidden'] or row['status']!='Available' or row['sha256']!=digest:
                    raise ValueError('A source photo changed or became unavailable. Preview again.')
                verified_data(row,stop=stop)
            self.check(token,stop);check_directory(destination.parent,parent_identity)
            intent=self.store.begin_export(scope,selection[0]['photo'],destination,review.output_digest)
            self.check(token,stop);output=save_new(destination,review.output,stop=stop)
            try:
                self.store.record_sheet_export(scope,selection,settings,output,evidence)
                self.store.finish_export(scope,intent,'Saved','Reviewed contact sheet saved; originals unchanged.')
            except (ValueError,OSError,sqlite3.Error):
                return output,'Partial','The contact-sheet PNG WAS SAVED, but its completion record could not be saved. Inspect its recorded destination before repeating.'
            return output,'Complete','Contact-sheet PNG saved. Originals unchanged. Review visible pixels before sharing.'
        return work

    def export(self,review,destination):
        destination=assert_no_links(local_path(destination))
        if destination.suffix.lower()!='.png':raise ValueError('Choose a new PNG filename for the flattened export.')
        parent_identity=directory_identity(destination.parent)
        def work(scope,token,stop,progress):
            with self.lock:
                found=self.reviews.pop(getattr(review,'id',None),None)
            if found is not review or token!=review.token or scope!=review.scope or self.clock()>=review.expires:
                raise ValueError('The export review was changed, used, expired or belongs to another context. Preview again.')
            row=self.store.get(scope,review.photo)
            if not row or row['hidden'] or row['sha256']!=review.source_digest or row['status']!='Available':
                raise ValueError('The source selection changed since review. Preview again.')
            verified_data(row,stop=stop)  # Full hash recheck at the side-effect boundary.
            self.check(token,stop);check_directory(destination.parent,parent_identity)
            # A durable private destination record exists BEFORE any file can be created.
            intent=self.store.begin_export(scope,review.photo,destination,review.output_digest)
            self.check(token,stop)
            output=save_new(destination,review.output,stop=stop)
            # Persist completion under the initiating identity even after cancellation.
            try:
                self.store.record_export(scope,review.photo,output,json.loads(review.recipe_json))
                self.store.finish_export(scope,intent,'Saved','Expected bytes were saved and recorded. No original was changed.')
            except (ValueError,OSError,sqlite3.Error):
                return output,'Partial','The new PNG WAS SAVED, but its completion record could not be saved. Inspect the recorded destination; do not repeat automatically.'
            return output,'Complete','Flattened PNG saved without source metadata. Review visible pixels; this is not a privacy guarantee. Originals unchanged.'
        return work

    def relink(self,photo_id,path):
        def work(scope,token,stop,progress):
            observed=inspect_photo(path,stop=stop)
            self.check(token,stop)
            row=self.store.relink(scope,photo_id,observed)
            return row['id'],'Complete','Relinked identical bytes. Favorites, album membership and manual links were preserved; no file moved.'
        return work

    def retry_receipt(self,identity):
        local_writable(self.app)
        with self.lock:
            value=self.volatile.get(identity)
            if not value or value[0]!=self.scope():raise ValueError('No pending receipt save in this workspace.')
            self.store.finish_job(*((value[0],identity)+value[1:]))
            self.volatile.pop(identity,None)

    def link_session(self,photo_id,session_id,history,*,incognito=False):
        local_writable(self.app)
        if not retained_session(history,session_id,incognito=incognito):raise ValueError('Choose a retained, nonprivate session; missing or forgotten history cannot be reconstructed.')
        self.store.edit(self.scope(),photo_id,session_id=session_id)


def service_for(shell):
    service=getattr(shell,'photo_service',None)
    if service is None:
        service=PhotoService(shell.app,PhotoStore(shell.store));shell.photo_service=service
    return service
