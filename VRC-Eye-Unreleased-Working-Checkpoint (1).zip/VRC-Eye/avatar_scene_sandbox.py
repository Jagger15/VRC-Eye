"""Linux kernel restrictions for the bundled, single-threaded scene worker.

Install after trusted imports and before reading model bytes. No filesystem,
network, process creation or descriptor acquisition syscall is permitted. Only
stdin reads, stdout/stderr writes and in-process memory/time operations remain.
This is deliberately not a policy for an external exporter or the main app.
libseccomp API: https://github.com/seccomp/libseccomp/tree/main/doc
"""
import ctypes
import errno
import os
import stat
import sys

POLICY='linux-seccomp-glb-v1'
UNCONTAINED='resource-limited-worker'


def description():
    if sys.platform.startswith('linux'):
        return 'Linux scene worker: file access, networking and process creation are denied by the kernel.'
    return 'GLB worker has resource limits; OS file and network containment is unavailable on this platform.'


def preload():
    """Resolve the parser's lazy imports before untrusted input is consumed."""
    import avatar_scene_appearance
    import avatar_scene_deform
    import avatar_scene_pose
    import avatar_mesh_health
    import avatar_animation
    import avatar_animation_glb
    # Only these two formats are accepted. Importing every Pillow plugin would
    # unnecessarily enlarge the trusted bootstrap and its dependency surface.
    try:
        from PIL import Image, PngImagePlugin, JpegImagePlugin
        Image.preinit()
    except ImportError:
        # Geometry still works without optional image decoding. The parser gives
        # its existing explicit dependency error for an embedded texture.
        pass


class _Compare(ctypes.Structure):
    _fields_=[('arg',ctypes.c_uint),('op',ctypes.c_int),
              ('datum_a',ctypes.c_uint64),('datum_b',ctypes.c_uint64)]


def _check_descriptors():
    # An inherited open file/socket could bypass an open/socket syscall ban.
    # Fail closed if the worker contract has acquired any extra descriptor.
    for name in os.listdir('/proc/self/fd'):
        fd=int(name)
        try:info=os.fstat(fd)
        except OSError as error:
            if error.errno==errno.EBADF:continue  # closed listdir descriptor
            raise
        if fd>2:raise ValueError('GLB containment refused an unexpected open descriptor.')
        if fd<2 and not stat.S_ISFIFO(info.st_mode):
            raise ValueError('GLB containment requires pipe input and output.')
        if fd==2 and not (stat.S_ISFIFO(info.st_mode) or stat.S_ISCHR(info.st_mode)):
            raise ValueError('GLB containment refused an unexpected error destination.')
    if len(os.listdir('/proc/self/task'))!=1:
        raise ValueError('GLB containment requires a single-threaded parser worker.')


def install():
    """Irreversibly restrict this worker. Linux never falls back silently."""
    if not sys.platform.startswith('linux'):return UNCONTAINED
    try:
        _check_descriptors()
        lib=ctypes.CDLL('libseccomp.so.2',use_errno=True)
        lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
        lib.seccomp_release.argtypes=[ctypes.c_void_p];lib.seccomp_release.restype=None
        lib.seccomp_attr_set.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_uint32];lib.seccomp_attr_set.restype=ctypes.c_int
        lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
        lib.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.POINTER(_Compare)]
        lib.seccomp_rule_add_array.restype=ctypes.c_int
        lib.seccomp_load.argtypes=[ctypes.c_void_p];lib.seccomp_load.restype=ctypes.c_int
        context=lib.seccomp_init(0x00050000|errno.EPERM)  # SCMP_ACT_ERRNO
        if not context:raise ValueError('GLB containment could not allocate a syscall filter.')
        try:
            # CTL_NNP=3, CTL_TSYNC=4. Keep the default bad-architecture kill
            # action, do not add alternate ABIs, and do not weaken outer filters.
            for attribute in (3,4):
                if lib.seccomp_attr_set(context,attribute,1)!=0:
                    raise ValueError('GLB containment could not configure kernel restrictions.')
            def allow(name,fd=None):
                number=lib.seccomp_syscall_resolve_name(name.encode('ascii'))
                if number<0:return  # absent on this native architecture
                comparison=None if fd is None else _Compare(0,4,fd,0)  # SCMP_CMP_EQ
                result=lib.seccomp_rule_add_array(context,0x7fff0000,number,
                    0 if comparison is None else 1,None if comparison is None else ctypes.byref(comparison))
                if result!=0:raise ValueError('GLB containment could not construct its syscall policy.')
            allow('read',0)
            for fd in (1,2):allow('write',fd)
            for fd in (0,1,2):allow('fstat',fd);allow('fstat64',fd);allow('close',fd)
            for name in ('brk','mmap','mmap2','mprotect','munmap','mremap','madvise',
                         'rt_sigaction','rt_sigprocmask','rt_sigreturn','sigreturn',
                         'futex','futex_time64','clock_gettime','clock_gettime64',
                         'clock_nanosleep','clock_nanosleep_time64','nanosleep',
                         'gettimeofday','time','getpid','gettid','getrandom',
                         'sched_yield','restart_syscall','exit','exit_group'):
                allow(name)
            if lib.seccomp_load(context)!=0:
                raise ValueError('The host refused GLB kernel containment. No model was parsed.')
        finally:lib.seccomp_release(context)
    except (OSError,AttributeError) as error:
        raise ValueError('Linux GLB preview requires libseccomp.so.2 and kernel seccomp support. No model was parsed.') from error
    return POLICY
