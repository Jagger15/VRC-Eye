"""Display a one-use mobile link for the existing authenticated peer host."""

from text_viewport import window_body
from io import BytesIO
import ipaddress
import time


def mobile_link(invitation, *, now=None):
    from peer_transport import parse_invitation
    info=parse_invitation(invitation,now=now)
    if info['mode']!='LAN':raise ValueError('Mobile pairing currently supports the same local network. Choose LAN in Easy Connect.')
    address=ipaddress.ip_address(info['address'])
    if address.is_loopback or address.is_link_local or address.is_unspecified or address.is_multicast or not address.is_private:
        raise ValueError('Choose your PC’s local network adapter, not loopback, before inviting your phone.')
    return 'vrceye://pair?invite='+invitation,info['expires']


def qr_png(link):
    try:import qrcode
    except ImportError:raise ValueError('QR support is unavailable. Update the app’s dependencies or use the invitation text in the mobile app.') from None
    code=qrcode.QRCode(box_size=4,border=4,error_correction=qrcode.constants.ERROR_CORRECT_M)
    code.add_data(link);code.make(fit=True)
    output=BytesIO();code.make_image(fill_color='black',back_color='white').save(output,format='PNG')
    return output.getvalue()


class MobileInvitation:
    def __init__(self,page):
        page.active()
        # Validate the selected host before issuing a secret.
        snap=page.service.snapshot();transport=snap.get('transport',{})
        address=transport.get('address','')
        try:parsed=ipaddress.ip_address(address)
        except ValueError:raise ValueError('Create a LAN connection using your PC’s local adapter first.') from None
        if snap.get('mode')!='LAN' or parsed.is_loopback or parsed.is_link_local or parsed.is_unspecified or parsed.is_multicast or not parsed.is_private:
            raise ValueError('Choose your PC’s LAN adapter in Easy Connect, then create the connection.')
        invitation=page.service.invite(ttl=600)
        link,self.expires=mobile_link(invitation)
        data=qr_png(link)
        self.page=page;self.context=page.context();self.window=page.tk.Toplevel(page.app.root)
        self.window.title('Connect VRC Eye Mobile');self.window.transient(page.app.root)
        self.image=page.tk.PhotoImage(master=self.window,data=data)
        frame=page.ttk.Frame(window_body(self.window),padding=16);frame.pack(fill='both',expand=True)
        page.ttk.Label(frame,text='Scan with your phone camera',style='Heading.TLabel').pack()
        page.ttk.Label(frame,image=self.image).pack(pady=8)
        page.ttk.Label(frame,text='Open the link in VRC Eye Mobile, review this PC, then Connect.\nUse the same local network. This invitation expires in 10 minutes and works once.',wraplength=470,justify='center').pack(pady=6)
        self.token=page.tk.StringVar(value=invitation)
        page.ttk.Entry(frame,textvariable=self.token,width=55,state='readonly').pack(fill='x')
        page.ttk.Label(frame,text='Or paste this invitation into Mobile → More → Connect desktop.\nSharing cards uses your existing Eye-to-Eye permissions.',wraplength=470,justify='center').pack(pady=8)
        page.ttk.Button(frame,text='Close invitation',command=self.close).pack()
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.alive=True;self.after=self.window.after(500,self.check)

    def check(self):
        if not self.alive:return
        data=self.page.service.snapshot()
        if self.page.closed or self.context!=self.page.context() or time.time()>=self.expires or data.get('mode')!='LAN' or data.get('state') in ('PRIVATE','BLOCKED','CLOSED'):
            self.close();return
        self.after=self.window.after(500,self.check)

    def close(self):
        if not self.alive:return
        self.alive=False;self.token.set('');self.window.after_cancel(self.after);self.window.destroy();self.image=None
