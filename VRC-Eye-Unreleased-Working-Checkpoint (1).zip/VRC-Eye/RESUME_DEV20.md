# Resume VRC Eye from Development 20

Use VRC-Eye-v1.21.0-Development-20.zip as the current source baseline. It starts from complete Dev19 SHA-256 82c60be6114cb6bf3e5510bb0ec5525cb2f0c9f34a32dc575bc8312b0f6670bd; never branch from the superseded interim Home-only Dev18.

The user authorized the scoped first batch after all utility and ARC/VRCX gap reviews: typed sidebar settings/history and coverage, source freshness/optional cadence, bounded GLB appearance, checkpointed recovery helpers, session-day photos, structured private composer drafts and OSC connection diagnostics. These are implemented through existing owners; no provided mod source/binary was copied or executed.

Read DEVELOPMENT_20_RELEASE_NOTES.md, DEVELOPMENT_20_VALIDATION.md, BUILD_VALIDATION.json and ARC_VRCX_REMAINING_DEV20.md. The full 106-area ledger is ARC_VRCX_GAP_LEDGER_DEV20.json. Material viewing is now Partial; 40 partial and 7 missing areas remain.

Native Windows/Linux rendering/accessibility and installed VPM/Unity/AssetRipper/live-provider qualification remain open. Do not call the GLB parser or external helper an OS sandbox. Broader Unity helper checkpoints, shader/rig/animation/import formats and other utility proposals remain later work. Preserve the Dev19 archive and prior review deliverables.

Source launch: Start.cmd on Windows or bash Start.sh on Linux, after extracting separately. This is not a signed installer or full 1.21 parity release.
