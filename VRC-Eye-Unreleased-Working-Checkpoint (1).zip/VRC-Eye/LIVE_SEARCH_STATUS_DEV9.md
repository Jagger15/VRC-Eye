# VRC Eye 1.21.0 — Development 9

This checkpoint builds on the complete Development 8 source. It adds wider
automatic view updates, a global local search, and optional automatic status rules.

## Live views

- An explicitly loaded Search page refreshes automatically while visible, with
  the same query, collection and page offset. It uses the existing automatic-sync
  worker and metadata budget. It becomes eligible after five minutes; low-power
  mode uses fifteen minutes after an automatic refresh. Other queued work can
  delay it. Hidden or changed views do not accept pending results.
- Friend name, status and image observations flow into existing tile views.
  Successful searches share their metadata with other open tile views and global
  search. These are display observations, not authorization for remote actions.
- In-place tile updates preserve selection, keyboard focus and scroll position.
  A changed image URL invalidates its thumbnail. New search queries and pages
  still replace their result set deliberately.
- No second pipeline or background account login is introduced. Pausing automatic
  sync stops view polling. Privacy and account changes clear transient data.

## Global quick search

Use **Global quick search…** in the sidebar or Search page, or **Ctrl+Shift+K**.
The existing Ctrl+K tool palette remains available. The new chord is remappable;
if an older shortcut profile already uses it, that assignment wins and the new
search remains available by mouse.

One local query searches user/friend, world, avatar and group observations,
including saved notes, memos, tags, labels, names and IDs. Exact names and IDs
rank ahead of approximate matches; words of four or more characters tolerate a
small typo. Current-account records and explicitly shared records are included;
inactive accounts are excluded. Results use the existing image tiles.

Search is debounced and reruns when its observed data or native notes change.
It does not submit a remote name query. Displaying thumbnails can use the existing
authenticated image loader; its normal host restrictions, bounds and cache apply.
Coverage is bounded to 6,000 recently updated entities and 12,000 annotations per
scope, 1,000 saved friend profiles and up to 2,000 session observations. At most
100 matches are displayed. Very large libraries may have additional matches.

## Automatic status rules

Open **Accounts → My profile → Automatic status rules…**.

1. Add up to sixteen ordered rules and save them for the active account.
2. Choose the instance access type, an optional status, and an optional description.
   `{world}` and `{access}` are supported; outgoing descriptions are limited to
   32 characters. The preview shows the current matching rule and outgoing values.
3. Optionally require a recently observed friend in the same instance from one
   of your local friend collections. Missing or hidden locations never count as
   evidence that a friend is present. Shared collections are identified separately.
4. Select **Review and enable for this session…**. Saving rules alone does not
   enable them. The first matching rule wins; no match leaves status unchanged.

Rules require a selected **live VRChat log whose local user matches the active
API account**. They use known instance metadata; they do not discover hidden
locations. A match must remain stable for twenty seconds. The worker fetches the
current own profile before writing, shares the existing API lock and request
budget, sends only changed fields and records the result in Action history.
Writes are spaced at least five minutes apart. The API budget may add delay.

Enablement lasts only for this account session. Restart, account/session changes,
privacy, offline mode, a long sleep/interruption and paused sync stop automatic writes. Manual status edits
in Eye pause rules; observed external edits also pause them, and the fresh profile
read detects changes missed by the stream. An uncertain or rejected write pauses
automation without retrying it. Rules never restore an older status when paused.
Closing the rules window leaves an enabled session running; **Pause now** stops it.

World-name templates can disclose a private world's name in your profile status.
The enable review includes the exact templates and conditions. Credentials,
instance nonces and description contents are excluded from action receipts.

## Scope and validation

Existing features, launchers and requirements are retained. Full VRCX parity is
not claimed. This is a source checkpoint, not a compiled executable or signed
installer. See `VALIDATION_1_21.md` and `BUILD_VALIDATION.json` for test results.

Native Windows/Linux GUI rendering, real VRChat status writes and pipeline
behavior, credential vaults, Discord/tray integrations and SteamVR still require
live acceptance. Portable tests use synthetic responses; they are not evidence
that a real account was contacted. Status updates reuse the existing user-update
adapter and its response validation. Protocol reference reviewed October 4, 2026:
https://vrchat.community/reference/update-user

Still outside this checkpoint: watchlists and owned-content monitoring across
every workspace, a general automation engine, broad status-condition types such
as schedules, the image-editor/table-controls expansion, advanced graph layouts,
new group conveniences, a production updater, and complete migration parity.
