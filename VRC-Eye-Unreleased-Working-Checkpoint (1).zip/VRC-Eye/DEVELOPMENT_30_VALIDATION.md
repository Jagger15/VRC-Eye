> Historical evidence for the candidate before autonomous completion. See [current frozen-source verification](AUTONOMOUS_COMPLETION_VALIDATION.md) for the new regression and remaining gates.

# Development 30 candidate — retained baseline validation

The final frozen source passed the portable development gates. This is a source candidate for device testing; native platform/provider qualification remains open.

| Check | Final result |
| --- | --- |
| Focused regression | 327 passed; 14 subtests passed; 5 display-dependent tests skipped |
| Full portable regression | 5,410 passed; 1,065 subtests passed; 516 skipped; 1 deselected |
| Failures / errors | 0 / 0 |
| New cases | 21 portable tests passed; 4 native ttk gates included and skipped without a display |
| Source freeze | 673 tracked source/test/assembly files; no changes during final verification |
| Python compatibility syntax | 653 files parsed using Python 3.10 grammar |
| External socket guard | Enabled in both runs; 0 blocked attempts |
| Public/internal identity | 2026.05.10.02.47.1 / 1.21.0 retained |

## Evidence

Completed JUnit and terminal reports are in `validation/milestone30-focused-final.*` and `validation/milestone30-portable-final.*`. Exact commands, durations, SHA-256 hashes and exclusions are recorded in `PENDING_WORKING_VALIDATION.json` → `milestone30_update`. The source manifest for this retained run is `BASELINE_PRE_AUTONOMOUS_SOURCE_MANIFEST.json`; the previous checkpoint's manifest is retained as `BASELINE_PRE_MILESTONE30_SOURCE_MANIFEST.json`.

The suite covers shared process status, stale/unknown handling, log rollover/source generations and navigation, modal account/privacy changes, real SQLite read-only checking, metadata pack identity/bookmarks/comparison, owned image persistence/removal, image compositing, numeric/slider synchronization, invalid opacity edits and portable appearance migration. It also reruns the existing recovery, settings, GLB, creator, UI callback and service tests.

An earlier full pass also succeeded; final review added immediate numeric-opacity preview and invalid-edit handling before a fresh source freeze and the final full run. No final source edits occurred after verification started.

## Exclusions and remaining gates

- 516 prerequisite-dependent tests skipped, including 4 new native ttk gates. This environment has no graphical display; attempted Xvfb download was unavailable from configured package indices.
- 13 transport-dependent modules excluded and 1 native Unix SDK case deselected, matching the retained portable baseline.
- No Windows/Linux desktop/accessibility qualification, live Steam/VRChat/Wine/Proton/Flatpak visibility qualification, native SteamVR/media/keyring operation, installed Unity/VPM/AssetRipper acceptance, power-loss qualification or signed-distribution validation.
- The Development 30 label denotes the cumulative source candidate; broader partial work and native distribution gates remain open.

The two pytest warnings are an existing non-test helper class with a constructor and a deliberate duplicate ZIP entry used to verify archive rejection. Neither is an application runtime failure.

Native ttk gates exercise rounded controls at 100/150/200 percent scale, native keyboard activation and preserved text/input state, flat/high-contrast restoration, bounded element reuse, background resize stability and privacy clearing. Their presence is not proof they passed; they require a graphical desktop.

The unchanged portable exclusions are:

- `tests/test_media_mpris_bus_121.py`
- `tests/test_session_secret_service_protocol.py`
- `tests/test_peer_transport.py`
- `tests/test_networking_integration.py`
- `tests/test_osc_transport.py`
- `tests/test_osc_discovery.py`
- `tests/test_osc_simulator.py`
- `tests/test_avatar_link.py`
- `tests/test_avatar_osc.py`
- `tests/test_avatar_creator_app.py`
- `tests/test_rangefinder.py`
- `tests/test_camera_capture.py`
- `tests/test_osc_avatar.py`

Deselected: `tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore`.
