# 1.21.0 Development checkpoint 3 — validation

The cleanly extracted source package passed **4,941 tests and 1,194 subtests**, with no failures, errors or skips, in 367.41 seconds. There were 3 warnings.

The offline guard recorded **zero external socket attempts**. Local loopback and
IPC were permitted for isolated fixtures. No live VRChat account, user keyring or
SteamVR hardware was used. Neither supplied source archive was executed.

## Verified here

- All 499 manifest-covered source files matched the clean tested copy before and after the suite. All 578 Development 2 archive paths were retained.
- Python 3.10 grammar parsing of 450 Python files; execution used Python 3.12.14. Existing Windows/Linux launchers and dependency definitions are retained.
- SpaceCal profile schema, bounds, duplicates, finite values, units, distinct rotation orders, point/vector inverse calculations, identity matching and sanitized reports. Registry access has controlled contract coverage only.
- Device diagnostics on the existing OpenVR owner: explicit opt-in, 64-slot bounds, 2 Hz sampling, 0.9-second expiry, pose validity, disconnected/out-of-range/rotation-only distinctions, generation and privacy cancellation. Pinned Python/ctypes wrappers were tested without native initialization.
- Selected loader source/install evidence, TOML scalar declarations including digit-bearing keys, startup log claims, severity summaries, resource limits and new-file sanitized reports. The supplied MelonLoader ZIP was inspected read-only and correctly classified as source evidence.
- Tracking application worker ownership, selected-file reads, offline previews, account/privacy invalidation, stale worker rejection, and atomic export cancellation. Demo/Safe states block hardware and registry access while allowing selected JSON inspection.
- Native Tk navigation, new tracking/loader controls, sidebar disclosure without redundant state words, keyboard/focus behavior and retained integration flows. Visual checks use synthetic data and the isolated test application.
- Retained compass, account/session, media/audio, VRCX, creator, installation-inspection and other baseline regression checks. The isolated Secret Service protocol fixture remains distinct from a user's desktop keyring.

The initial clean run passed 4,939 tests with one failure in the tracking Settings
200% keyboard-focus visibility check. A nested-row reflow could move an already
focused control without resizing the outer panel. The layout visibility hook was
corrected, with a regression covering retained focus and manual scrolling, before
the final clean run reported above.

The next run passed 4,940 tests with one obsolete label-wrap fixture expectation.
The fixture was corrected to capture the initialized binding baseline and ignore
only blank Tcl separator lines; application code did not change after that run.

The original Development 2 validation is nested in BUILD_VALIDATION.json. The full
regression output accompanies this build. Future roadmap acceptance checklists
are not counted as completed tests.

## Native acceptance still needed

Real SteamVR rendering, device enumeration/poses, wrist event delivery, controller
input, GPU performance and VR comfort remain unverified. Native Windows registry
reads need acceptance on a real current-user SpaceCal installation. Registry tests
here do not prove a particular user's settings exist or can be read.

Saved SpaceCal configuration does not prove current calibration activity or
quality. The offline transform worksheet assumes an identity existing driver
origin and excludes live blending. It is not applied to live absolute poses.
Pimax aliases and incomplete HMD identities are reported with limited/candidate
status, not normalized into a confident calibration match.

Windows DPAPI/ACL behavior, real desktop Secret Service, live VRChat authentication,
audio hardware, native media routes, Unity compilation and VRCX platform acceptance
retain the baseline limitations. A failed or hung native cleanup cannot be reported
as successful; ownership remains guarded for retry or an explicit unconfirmed quit.

The Xvfb environment has incomplete punctuation glyph coverage. These images
verify Linux test layout and flow, not Windows typography or screen-reader support.

## Build scope and EAC

This is **1.21.0 Development checkpoint 3**, a runnable source ZIP with Windows and
Linux launchers. It is not a compiled executable, signed installer or completed
1.21 roadmap. All 160 prepared packages and 849 future checks remain visible in
the ledger; 13 packages are partial and 147 pending under its broad scope.

The new integrations inspect external files and use the existing external OpenVR
owner. No supplied loader/driver binaries, client injection, process-memory reads,
EAC bypass, calibration IPC writer or chaperone mutation are included. This is
not EAC certification. Remote-player ESP and world-space registration remain pending.

No user database, saved secret, runtime log, Python environment or uploaded
installation/source archive is included in the release. The existing bundled
EditorCore source-package ZIP is retained.

See [development notes](DEVELOPMENT_1_21.md), [integration guide](EXTERNAL_TRACKING_GUIDE.md),
[source review](SOURCE_INTEGRATIONS_1_21_DEV3.md) and [implementation status](IMPLEMENTATION_STATUS_1_21.md).
