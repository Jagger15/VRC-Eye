# VRC Eye 1.21.0 — Development 19

This is the unified continuation of the completed Development 18 build. Another
Development 18 completed while this chat was implementing overlapping Home work.
The final build uses that completed source as its baseline, preserves its static
GLB scene viewer and shared settings-history implementation, and integrates this
chat's additional Home functionality into the existing services.

## Start and update

Close the older copy, extract **VRC-Eye-v1.21.0-Development-19.zip** into a separate
folder, and run **Start.cmd** on Windows or **bash Start.sh** on Linux. Existing
per-user data locations and launchers are retained. This is runnable source,
not a compiled EXE, Flatpak or signed installer.

## Combined conditions and power rules

In **Customization → Profiles & sharing**, a Home rule can now require up to four
conditions at once. The existing condition selector is followed by three optional
**Also require** selectors. All chosen conditions must match; the first enabled
matching rule still wins. Use Always for unused selectors.

The same combined conditions are available under **Customization → Home layout →
Show widget when**. Apply widget settings and visibility to save the change.

The existing sign-in, offline/online mode, observed-session, privacy, DND and
interface-mode conditions are retained. **Balanced power** and **Low power** use
the existing Desktop controls power preference. If that owner is unavailable,
neither specific power condition matches.

For example, a Creator layout can require Advanced mode, Signed in, Privacy
visible and DND off together. A compact media card can require Low power and
Privacy visible. Duplicate or contradictory conditions are rejected before saving.
No condition starts a collector, changes permissions or enables a connection.
Online mode remains a local setting, not proof of internet reachability.

Earlier single-condition documents remain readable. Combined conditions retain
the existing Home export/import, selective settings backup/restore and direct
settings-history paths. A combined condition is one list field during undo;
later changes to that list are preserved. Development 18 readers cannot interpret
the new multi-condition lists or power options; use this build for those exports.

## Temporary Home fallback

**Use fallback this session** temporarily shows the saved default layout.
**Resume saved selection** restores the saved automatic/manual selection policy.
This pause creates no saved setting or history receipt, resets when the Home
controller/app is recreated, and preserves a persistent manual override.

The existing **Hold this layout** remains persistent across restart. Choosing it,
or **Clear manual override**, ends the temporary pause. Widget visibility rules
continue to apply in the fallback. The session timer survives layout switches.

## Clearer Home presentation

Home reports how many cards are hidden by conditions and explains when no cards
match. Customize Home stays reachable. Privacy mode masks the layout title and
clears/disables the layout-name picker. The Home control row uses the existing
responsive layout helper. Native large-text/keyboard rendering still needs testing.

## Preserved Development 18 work

- **Static GLB scene inspection:** Avatar Library → 3D preview → Choose static GLB
  scene. Actual embedded triangle geometry, scene hierarchy, bounds, subtree
  visibility/framing and the original OBJ viewer are retained. Material/texture,
  rig/blendshape and animation rendering, direct FBX/VRCA/Unity-bundle decoding
  and OS sandbox containment remain outside this static viewer.
- **Shared direct-settings history:** Customization → History → Settings and
  layout history / undo. The existing transactional field-level journal covers
  supported appearance, Home, notification display/focus, shortcuts, friend filters
  and private saved tag views. Stable widget IDs preserve history across reordering.
  There is one shared journal, with device/workspace scope and conditional undo.
- All Development 17 tags, selective backups and recovery working-copy tools remain.

The [remaining-functions report](ARC_VRCX_REMAINING_DEV19.md) records **39 partial
and 8 missing ARC/VRCX areas**, plus the separate provider/acceptance and source-data
limits. Full ARC/VRCX parity is not claimed.

# Development 19 validation

The final unified build passed **5,060 tests and 1,059 subtests**, with **zero
failures/errors** and **zero blocked external-socket attempts**, in **126.85 seconds**.
All **28 new Development 19 cases** are included, alongside the complete inherited
portable regression including the Development 18 GLB and direct-settings tests.

**475 native-GUI tests were skipped**, **1 Unix bridge case was deselected**, and
**13 local-transport modules were excluded**, retaining the Development 18 gates.
Skips and exclusions are not passes. Two inherited warnings remain: TestListener
collection and the intentionally duplicate VRChat.exe archive fixture.

New cases cover combined conditions, contradictory/duplicate/oversized inputs,
unknown power state, evaluation without mutation, shared backup/history behavior,
field-level undo preserving later edits, temporary/persistent selection interaction,
no-write pause, timer preservation, privacy clearing, empty views and real editor
callbacks using headless display adapters.

All **597 Python files** parse under Python 3.10 grammar. All **642 frozen source
hashes** match after the final run; no runtime/test edits followed that run.
ZIP packaging checks CRCs and compares all member bytes against source. All
**801 Development 18 archive paths** are retained. Launchers, requirements,
static GLB provider/viewer code and the shared settings-history owner are unchanged.
Parent archive SHA-256: `3c8dd442c3aaab77c0f477c2e2b9025aa070314e8e1664fb176566a53679cb5b`.

Native Windows/Linux GUI rendering, keyboard navigation, high contrast, large text,
Windows parser lifecycle, installed AssetRipper/Unity, live VRChat/CDN and SteamVR
acceptance remain unverified. Headless UI checks are not native visual acceptance.
No live VRChat action or third-party model was used. The inherited scene parser
provides process fault separation, not an OS security sandbox.

## Exact portable regression command

```bash
PYTHONPATH=.:tests python3 -m pytest -q --tb=short -rf -p tools.offline_test_guard --durations=10 -o faulthandler_timeout=60 --ignore=tests/test_media_mpris_bus_121.py --ignore=tests/test_session_secret_service_protocol.py --ignore=tests/test_peer_transport.py --ignore=tests/test_networking_integration.py --ignore=tests/test_osc_transport.py --ignore=tests/test_osc_discovery.py --ignore=tests/test_osc_simulator.py --ignore=tests/test_avatar_link.py --ignore=tests/test_avatar_osc.py --ignore=tests/test_avatar_creator_app.py --ignore=tests/test_rangefinder.py --ignore=tests/test_camera_capture.py --ignore=tests/test_osc_avatar.py --deselect=tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore --junitxml=../release-dev19-tests.xml
```

## Retained local-transport exclusions

- tests/test_media_mpris_bus_121.py
- tests/test_session_secret_service_protocol.py
- tests/test_peer_transport.py
- tests/test_networking_integration.py
- tests/test_osc_transport.py
- tests/test_osc_discovery.py
- tests/test_osc_simulator.py
- tests/test_avatar_link.py
- tests/test_avatar_osc.py
- tests/test_avatar_creator_app.py
- tests/test_rangefinder.py
- tests/test_camera_capture.py
- tests/test_osc_avatar.py
