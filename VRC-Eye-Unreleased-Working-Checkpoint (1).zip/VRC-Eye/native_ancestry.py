"""Three-way field merge with explicit source ancestry and conservative conflicts."""
from copy import deepcopy
from native_library import canonical

MISSING=object()


def lineage(record):
    p=record['provenance']
    if not p.get('lineage') or not p.get('table'):return ''
    return canonical({k:p.get(k,'') for k in ('lineage','table','source_account')})


def merge(base,local,incoming,path=()):
    """Lists are atomic. Conflicting concurrent changes preserve local values."""
    result={};conflicts=[]
    for name in sorted(set(base)|set(local)|set(incoming)):
        a=base.get(name,MISSING);b=local.get(name,MISSING);c=incoming.get(name,MISSING)
        equal=lambda x,y:x is y or x is not MISSING and y is not MISSING and canonical(x)==canonical(y)
        if equal(b,c) or equal(c,a):value=b
        elif equal(b,a):value=c
        elif isinstance(a,dict) and isinstance(b,dict) and isinstance(c,dict):
            value,extra=merge(a,b,c,path+(name,));conflicts.extend(extra)
        else:value=b;conflicts.append(path+(name,))
        if value is not MISSING:result[name]=deepcopy(value)
    return result,conflicts
