"""Local-only UI additions; applying remote status still uses existing review."""
from account_actions import account_id, local_writable
from account_header import private
from account_local_121 import LocalPreferences, preset, search
from companion_ui import Table, line, button, entry, choice
from player_profile import STATUSES


class StatusPresets:
    def __init__(self, page, parent):
        self.page = page
        self.store = LocalPreferences(page.shell.store)
        self.label = page.tk.StringVar()
        self.status = page.tk.StringVar(value='Online')
        self.description = page.tk.StringVar()
        page.ttk.Label(parent, text='Local status presets (up to 10 per account)', style='Subtitle.TLabel').pack(anchor='w', pady=(12, 4))
        self.table = Table(page, parent, (('label', 'Preset', 200), ('status', 'Status', 140), ('text', 'Status text', 300)), height=3, select=self.selected)
        row = line(page, parent)
        entry(page, row, self.label, 20)
        choice(page, row, self.status, tuple(STATUSES), width=15)
        entry(page, row, self.description, 34)
        row = line(page, parent)
        button(page, row, 'Save local preset', self.save)
        button(page, row, 'Use in profile draft', self.use)
        button(page, row, 'Remove preset', self.remove)
        page.ttk.Label(parent, text='Names and status text stay in this account’s local workspace. Saving or selecting never sends a status. Load your profile, use a preset, then Review changed fields to apply it.', wraplength=930, style='Muted.TLabel').pack(anchor='w')

    def require(self):
        self.page.require_revealed()
        if private(self.page.app):
            raise ValueError('Reveal account identity before editing status presets.')
        own = account_id(self.page.app)
        if not own:
            raise ValueError('Sign in to choose the preset workspace.')
        return own

    def refresh(self):
        self.last_private = private(self.page.app)
        self.label.set(''); self.status.set('Online'); self.description.set('')
        own = account_id(self.page.app)
        rows = self.store.rows(own, 'preset') if own and not self.page.private.get() and not private(self.page.app) else []
        self.table.set(rows, lambda r: (r['label'], r['value']['status'], r['value']['statusDescription']))

    def tick(self):
        if private(self.page.app) != getattr(self, 'last_private', None):
            self.refresh()

    def selected(self):
        self.require()
        row = self.table.selected()
        if row:
            self.label.set(row['label'])
            self.status.set(next(k for k, v in STATUSES.items() if v == row['value']['status']))
            self.description.set(row['value']['statusDescription'])

    def save(self):
        own = self.require(); local_writable(self.page.app)
        self.store.save(own, 'preset', self.label.get(), dict(status=STATUSES.get(self.status.get()), statusDescription=self.description.get()))
        self.refresh(); self.page.status.set('Local preset saved. Nothing sent to VRChat.')

    def use(self):
        self.require()
        row = self.table.selected()
        result = self.page.profile_result
        if not row or result is None:
            raise ValueError('Select a preset and refresh your own profile first.')
        if result.data.get('status') not in STATUSES.values() or not isinstance(result.data.get('statusDescription'), str):
            raise ValueError('The returned profile does not expose editable status fields.')
        value = preset(row['value'])
        self.page.profile_status.set(next(k for k, v in STATUSES.items() if v == value['status']))
        self.page.profile_description.set(value['statusDescription'])
        self.page.status.set('Preset copied to the profile draft. Review changed fields to send it.')

    def remove(self):
        own = self.require(); local_writable(self.page.app)
        row = self.table.selected()
        if not row:
            raise ValueError('Select a local preset.')
        self.store.remove(own, 'preset', row['key'])
        self.refresh(); self.page.status.set('Local preset removed. Remote status unchanged.')


class SavedSearches:
    def __init__(self, page, parent):
        from friendly_ui import flow_line as line
        self.page = page
        self.store = LocalPreferences(page.shell.store)
        self.label = page.tk.StringVar()
        self.remember = page.tk.BooleanVar(value=False)
        self.mode = page.tk.StringVar(value='Saved searches')
        self.last_private = None
        row = line(page, parent)
        choice(page, row, self.mode, ('Saved searches', 'Recent searches'), self.refresh, 21)
        entry(page, row, self.label, 22)
        button(page, row, 'Save search', self.save)
        page.ttk.Checkbutton(row, text='Remember recent searches (this workspace)', variable=self.remember, command=lambda: page.guard(self.remember_changed)).pack(side='left', padx=6)
        self.table = Table(page, parent, (('label', 'Saved / recent search', 220), ('kind', 'Type', 95), ('scope', 'Collection', 180)), height=3)
        row = line(page, parent)
        button(page, row, 'Load search form', self.load)
        button(page, row, 'Remove selected', self.remove)
        button(page, row, 'Clear recent searches', self.clear_recent)
        for label, scope in (('Featured avatars', 'Public / featured'), ('My uploads', 'My uploads'), ('My avatar favorites', 'My avatar favorites')):
            button(page, row, label, lambda scope=scope: self.quick(scope))
        page.ttk.Label(parent, text='Saved queries are local and account scoped. Recent history is opt-in (20 entries). Loading a form or quick view never searches; press Search / load. No result payloads are saved.', wraplength=1000, style='Muted.TLabel').pack(anchor='w')
        self.refresh()

    def scope(self):
        return account_id(self.page.app) or 'local'

    def require(self, write=False):
        if private(self.page.app):
            raise ValueError('Search history is hidden by privacy settings.')
        if self.page.account != self.page.context():
            self.page.account_changed()
            raise ValueError('The account changed. Select a search again.')
        if write:
            local_writable(self.page.app)
        return self.scope()

    def value(self):
        return search(dict(schema=1, kind=self.page.kind.get(), query=self.page.query.get(), scope=self.page.scope.get(), sort='Provider default'))

    def refresh(self):
        hidden = private(self.page.app)
        self.last_private = hidden
        self.label.set('')
        self.remember.set(False if hidden else self.store.remembering(self.scope()))
        kind = 'recent' if self.mode.get() == 'Recent searches' else 'search'
        rows = [] if hidden else self.store.rows(self.scope(), kind)
        self.table.set(rows, lambda r: (r['label'], r['value']['kind'], r['value']['scope']))

    def tick(self):
        if private(self.page.app) != self.last_private:
            self.page.reset(); self.page.query.set(''); self.refresh()

    def save(self):
        own = self.require(True); value = self.value()
        self.store.save(own, 'search', self.label.get() or (value['kind'] + ' · ' + (value['query'] or value['scope']))[:80], value)
        self.refresh(); self.page.status.set('Search saved locally. No request sent.')

    def apply(self, value):
        self.require(); value = search(value)
        self.page.reset()
        self.page.kind.set(value['kind']); self.page.query.set(value['query']); self.page.scope.set(value['scope'])
        self.page.status.set('Search form loaded. Press Search / load to run it.')

    def load(self):
        self.require()
        row = self.table.selected()
        if not row:
            raise ValueError('Select a saved or recent search.')
        self.apply(row['value'])

    def quick(self, scope):
        self.apply(dict(schema=1, kind='Avatars', query='', scope=scope, sort='Provider default'))

    def remember_changed(self):
        own = self.require(True)
        self.store.remembering(own, bool(self.remember.get()))
        self.page.status.set('Recent search history enabled for this workspace.' if self.remember.get() else 'Future searches will not be remembered. Clear recent searches removes existing entries.')

    def record(self, value):
        own = self.require(True)
        if self.remember.get() and self.store.remembering(own):
            value = search(value)
            self.store.save(own, 'recent', (value['kind'] + ' · ' + (value['query'] or value['scope']))[:80], value)
            self.refresh()

    def remove(self):
        own = self.require(True); row = self.table.selected()
        if not row:
            raise ValueError('Select a saved or recent search.')
        self.page.reset()
        self.store.remove(own, 'recent' if self.mode.get() == 'Recent searches' else 'search', row['key'])
        self.refresh()

    def clear_recent(self):
        own = self.require(True)
        self.page.reset()
        self.store.remove(own, 'recent'); self.refresh()
        self.page.status.set('Recent searches cleared. Saved searches are unchanged.')
