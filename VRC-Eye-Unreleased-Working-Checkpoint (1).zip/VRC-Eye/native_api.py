"""Typed VRCX-equivalent workflows on Eye's existing VRChat transport.

Contracts are independently implemented from VRCX 2026.09.16 src/api and
the community API contracts recorded in VRCX_BATCH1_1_21.md.
Snapshots are RAM-only. Imported records never become permission evidence.
All mutations are dispatched through account_actions.ActionService.
"""
from dataclasses import dataclass, field
from datetime import datetime
import json
import re
from urllib.parse import urlencode, quote, urlsplit

from companion_data import entity_id, reference, stamp
from player_api import context, check_context, lock
from vrchat_api import APIError

FIELDS=frozenset('''id userId ownerId authorId groupId name displayName shortCode discriminator description bio bioLinks pronouns
    imageUrl thumbnailImageUrl iconUrl bannerUrl userIcon bannerCustomUrl bannerType bannerColor backgroundType backgroundTextureId
    backgroundGradientBottom backgroundGradientTop backgroundTemplateId themeId themeButtonColor themeIconColor themeSubtextColor
    iconFrame nameplateEffect profileEffect themes buttonColor iconColor subtextColor hasVrcPlus badges badgeId showcased languages
    status statusDescription releaseStatus tags capacity recommendedCapacity visits favorites version created_at updated_at createdAt updatedAt
    senderUserId senderUsername receiverUserId type message title text seen expiresAt expiry canDelete responses data details link
    canRespond responseType responseData imageId worldId worldName notificationId isFollowing isFollowingEvent startsAt endsAt category
    accessType platforms roleIds roleId roles permissions myMember membershipStatus isRepresenting isSubscribed joinedAt isVerified
    isAddedOnJoin isSelfAssignable requiresTwoFactor requiresPurchase order rules links joinState privacy memberCount galleries
    galleryId postId eventId sendNotification sendCreationNotification hostEarlyJoinMinutes guestEarlyJoinMinutes closeInstanceAfterEndMinutes
    allowGroupJoinPrompt announcement members results total hasNext items inventoryId inventoryTemplateId template holderId itemType
    itemTypeFriendlyName itemName itemDescription itemImageUrl itemThumbnailImageUrl flags archived equipSlot quantity
    item availableItems inventoryItems inventoryTemplates isConsumable bundleContents contents rewards success status_code statusCode
    errorCode versions file url sizeInBytes mimeType extension messageType slot updatedAt timestamp note printId authorName
    count isComplete canTransfer transferTargetId transferTargetUserId requiredSubscription created updated targetUserId user friendId
    isAgeVerified identityVerified location instanceId world active canRequestInvite full restricted contentSettings defaultRoleId
    groupName userDisplayName fileId assetVersion credits price imageWidth imageHeight visibility imageThumbnailUrl
    requirements groupNotMonetized hasVRCPlus hasVerifiedEmail targetCanOwnMoreGroups targetIsGroupMember
    animationStyle frames framesOverTime loopStyle isArchived defaultRole isManagementRole membersOnly
    roleIdsToAutoApprove roleIdsToManage roleIdsToSubmit roleIdsToView
    templateId approved approvedAt approvedByUserId submittedByUserId region groupAccessType ageGate displayName
    queueEnabled instancePersistenceEnabled playerPersistenceEnabled public canAccess userCount n_users maxCapacity
    animationStyle loopStyle maskTag assetUrl attributes defaultAttributes metadata assetBundleUrl platform unityVersion
'''.split())
COLLECTIONS=('message','response','request','requestResponse')
GROUP_LISTS={'members':'members','roles':'roles','requests':'requests','invites':'invites','bans':'bans','posts':'posts','audit':'auditLogs'}
GROUP_PERMISSION={
 'group-invite':'group-invites-manage','group-cancel-invite':'group-invites-manage',
 'group-kick':'group-members-remove','group-ban':'group-bans-manage','group-unban':'group-bans-manage',
 'group-accept-request':'group-members-manage','group-reject-request':'group-members-manage','group-block-request':'group-members-manage',
 'group-role-create':'group-roles-manage','group-role-edit':'group-roles-manage','group-role-delete':'group-roles-manage','group-role-add':'group-roles-assign','group-role-remove':'group-roles-assign',
 'group-gallery-create':'group-galleries-manage','group-gallery-edit':'group-galleries-manage','group-gallery-delete':'group-galleries-manage',
 'group-gallery-add-image':'group-galleries-manage','group-gallery-remove-image':'group-galleries-manage','group-gallery-order':'group-galleries-manage',
 'group-post-create':'group-announcement-manage','group-post-edit':'group-announcement-manage','group-post-delete':'group-announcement-manage',
 'group-event-create':'group-calendar-manage','group-event-edit':'group-calendar-manage','group-event-delete':'group-calendar-manage',
 'group-settings':'group-data-manage'}
ACTIONS=frozenset(GROUP_PERMISSION)|frozenset(('notification2-see','notification2-hide','notification2-respond','saved-message-edit',
 'profile-edit','favorite-group-edit','favorite-group-clear','world-edit','world-publish','world-unpublish',
 'group-join','group-leave','group-cancel-request','group-represent','group-block','group-create','group-transfer','group-delete','group-event-follow',
 'media-delete','print-delete','inventory-consume','inventory-equip','inventory-unequip','inventory-archive','inventory-unarchive','reward-redeem','avatar-image','world-image',
 'profile-theme-create','profile-theme-edit','profile-theme-delete','group-instance-create'))
# Existing VRCX loading-screen contract plus the community specification's
# profile cosmetics slots. These names are also fixed routes for unequip.
EQUIP_SLOTS=('drone','warp','portal','loadingscreen','iconFrame','nameplateEffect','profileEffect')
INVENTORY_TYPES=('bundle','droneskin','emoji','iconFrame','nameplateEffect','portalskin','profileEffect','prop','sticker','warpeffect')


def text(value,maximum=2000):
    from account_actions import text as validate
    return validate(value,maximum,multiline=True)


def token(value,maximum=120):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_.:@-]{1,'+str(maximum)+'}',value):raise ValueError('A service identifier is missing or unsupported.')
    return value


def bounded(value,depth=0):
    if depth>10:raise APIError('The service response is nested too deeply.')
    if isinstance(value,dict):
        if len(value)>256:raise APIError('Too many fields in a service record.')
        return {k:bounded(v,depth+1) for k,v in value.items() if k in FIELDS}
    if isinstance(value,list):
        if len(value)>5000:raise APIError('The service response exceeds the supported record budget.')
        return [bounded(v,depth+1) for v in value]
    if isinstance(value,str):return text(value,20000)
    if value is None or type(value) in (bool,int):return value
    if type(value)is float and __import__('math').isfinite(value):return value
    raise APIError('Unsupported service value.')


def encoded(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


@dataclass(frozen=True)
class Snapshot:
    kind:str
    subject:str
    account:tuple
    checked:float
    checked_at:str
    payload:str=field(repr=False)
    source_client:object=field(repr=False,compare=False)
    offset:int=0
    more:bool=False
    query:str=''
    complete_collection:bool=False
    @property
    def data(self):return json.loads(self.payload)


@dataclass(frozen=True)
class Mutation:
    action:str
    path:str=field(repr=False)
    method:str
    payload:str=field(repr=False)
    target:str
    fields:tuple=field(repr=False)
    snapshot:Snapshot=field(repr=False)
    expected_id:str=''
    permission:str=''
    guard_json:str=field(default='{}',repr=False)


def fresh(client,snapshot,kind=None):
    if (not isinstance(snapshot,Snapshot) or snapshot.source_client is not client or snapshot.account!=context(client)
        or not 0<=client.clock()-snapshot.checked<300 or kind and snapshot.kind!=kind):
        raise ValueError('Refresh this view using the active account before reviewing the action.')
    return snapshot.data


def selected(client,snapshot,row,kind=None):
    data=fresh(client,snapshot,kind)
    rows=data if isinstance(data,list) else data.get('results',data.get('data',data.get('items',[])))
    if not isinstance(row,dict) or not isinstance(rows,list) or row not in rows:raise ValueError('Select a record from the refreshed service page.')
    return json.loads(encoded(row))


def read(client,kind,*,subject='',offset=0,query='',filters=None,stop=None,progress=None):
    from companion_api import offset_value
    offset_value(offset);own=context(client)[0];params={'n':100,'offset':offset};many=True;paged=True
    if kind=='notifications-v2':path='notifications'
    elif kind=='messages':
        if subject not in COLLECTIONS:raise ValueError('Choose an invitation message collection.')
        path=f'message/{own}/{subject}';params={};paged=False
    elif kind in ('profile','profile-themes'):path=f'profile/{own}';params={'asSelf':'true'};many=paged=False;subject=own
    elif kind=='worlds':path='worlds';params.update(user='me',releaseStatus='all',sort='updated',order='descending')
    elif kind=='world':subject=entity_id('world',subject);path='worlds/'+subject;params={};many=paged=False
    elif kind in ('avatar','avatar-gallery'):
        subject=entity_id('avatar',subject);path='avatars/'+subject;params={};many=paged=False
    elif kind in ('group','group-galleries'):subject=entity_id('group',subject);path='groups/'+subject;params={'includeRoles':'true'};many=paged=False
    elif kind.startswith('group-') and kind[6:] in GROUP_LISTS:
        subject=entity_id('group',subject);path=f'groups/{subject}/{GROUP_LISTS[kind[6:]]}'
    elif kind=='group-instances':subject=entity_id('group',subject);path=f'users/{own}/instances/groups/{subject}';params={};paged=False
    elif kind=='group-calendar':subject=entity_id('group',subject);path='calendar/'+subject;params={};many=paged=False
    elif kind in ('group-gallery','group-gallery-pending'):
        group,gallery=subject.split('/',1);group=entity_id('group',group);gallery=reference(gallery,('ggal',));path=f'groups/{group}/galleries/{gallery}'
        if kind=='group-gallery-pending':params['approved']='false'
    elif kind=='group-templates':path='groups/roleTemplates';params={};paged=False
    elif kind=='group-transfer-check':
        group,user=subject.split('/',1);group=entity_id('group',group);user=entity_id('user',user)
        path=f'groups/{group}/transfer';params={'transferTargetId':user};many=paged=False
    elif kind in ('gallery','icons','stickers','emoji'):
        path='files';params.update(tag={'gallery':'gallery','icons':'icon','stickers':'sticker','emoji':'emoji'}[kind])
    elif kind=='prints':path=f'prints/user/{own}'
    elif kind in ('inventory','inventory-archived'):path='inventory';params.update(order='descending',archived='true' if kind=='inventory-archived' else 'false');many=False
    elif kind=='inventory-global':path='inventory/global';params={};paged=False
    elif kind=='inventory-item':path='inventory/'+reference(subject,('inv',));params={};many=paged=False
    elif kind=='inventory-template':path='inventory/template/'+token(subject);params={};many=paged=False
    else:raise ValueError('Unsupported native service view.')
    if filters:
        if kind not in ('inventory','inventory-archived') or not isinstance(filters,dict) or set(filters)-{'equipSlot','types','tags','seen','flags','notFlags','order'}:
            raise ValueError('Choose supported inventory filters.')
        for key,value in filters.items():
            if key=='equipSlot':
                if value not in EQUIP_SLOTS:raise ValueError('Choose a supported equipment slot.')
                params[key]=value
            elif key=='seen':
                if type(value)is not bool:raise ValueError('Seen must be true or false.')
                params[key]='true' if value else 'false'
            elif key=='types':
                if value not in INVENTORY_TYPES:raise ValueError('Choose a supported inventory item type.')
                params[key]=value
            elif key=='order':
                if value not in ('ascending','descending'):raise ValueError('Choose ascending or descending inventory order.')
                params[key]=value
            elif key in ('flags','notFlags'):
                if not isinstance(value,str) or len(value)>512:raise ValueError('Choose a bounded inventory flag list.')
                params[key]=','.join(token(v.strip(),80) for v in value.split(',') if v.strip())
            else:params[key]=token(value,100)
    if query:params['search']=text(query,256)
    route=path+('?' + urlencode(params) if params else '')
    expected=context(client);lock(client,stop)
    try:
        check_context(client,expected,stop);client._wait_metadata(stop,progress);check_context(client,expected,stop)
        raw=client._request(route,expect_list=many);check_context(client,expected,stop)
        data=bounded(raw)
        if many and len(data)>(100 if paged else 5000):raise APIError('The returned page is larger than requested.')
        if kind in ('profile','profile-themes','world','group','group-galleries','avatar','avatar-gallery','inventory-item','inventory-template') and data.get('id')!=subject:raise APIError('The returned identity differs from the requested record.')
        if kind=='profile-themes':
            data=data.get('themes')
            if not isinstance(data,list) or any(not isinstance(r,dict) for r in data):raise APIError('The profile did not return its themes.')
        if kind in ('group-gallery','group-gallery-pending'):
            group,gallery=subject.split('/',1)
            if any(not isinstance(r,dict) or r.get('groupId')!=group or r.get('galleryId')!=gallery for r in data):raise APIError('The images belong to a different group gallery.')
        if kind=='group-galleries':
            data=data.get('galleries')
            if not isinstance(data,list) or any(not isinstance(r,dict) for r in data):raise APIError('The group did not return its galleries.')
        if kind in ('avatar','avatar-gallery') and data.get('authorId')!=own:raise APIError('Refresh an avatar owned by the active account.')
        if kind=='avatar-gallery':
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            images=client._request('files?'+urlencode(dict(tag='avatargallery',galleryId=subject,n=100,offset=offset)),expect_list=True)
            if len(images)>100:raise APIError('The avatar gallery page exceeds its limit.')
            data['items']=bounded(images)
        if kind=='worlds' and any(r.get('authorId')!=own for r in data):raise APIError('An owned-world response belongs to another user.')
        if kind=='notifications-v2' and any(r.get('receiverUserId',own)!=own for r in data):raise APIError('A notification belongs to another recipient.')
        if kind=='messages' and any(r.get('userId',own)!=own or r.get('messageType')!=subject for r in data):raise APIError('An invitation message belongs to another account or collection.')
        records=data if isinstance(data,list) else data.get('data',[]) if kind in ('inventory','inventory-archived') else data.get('items',[]) if kind=='avatar-gallery' else []
        if kind in ('inventory','inventory-archived') and (not isinstance(records,list) or len(records)>100):raise APIError('Unsupported inventory page.')
        if kind in ('inventory','inventory-archived') and any(not isinstance(r,dict) or r.get('holderId',own)!=own for r in records):raise APIError('An inventory item belongs to another holder.')
        return Snapshot(kind,subject,expected,client.clock(),stamp(),encoded(data),client,offset,bool((paged or kind=='avatar-gallery') and len(records)==100),query)
    finally:client.lock.release()


def _gallery_pages(client,group,gallery,expected,*,stop=None,progress=None):
    """Caller owns the transport lock. Fixed route, unfiltered, bounded pages."""
    rows=[];images=set();files=set()
    for offset in range(0,2001,100):
        check_context(client,expected,stop);client._wait_metadata(stop,progress);check_context(client,expected,stop)
        page=bounded(client._request(f'groups/{group}/galleries/{gallery}?'+urlencode(dict(n=100,offset=offset)),expect_list=True))
        check_context(client,expected,stop)
        if not isinstance(page,list) or len(page)>100:raise APIError('Gallery pagination exceeded its page contract.')
        for row in page:
            if not isinstance(row,dict) or row.get('groupId')!=group or row.get('galleryId')!=gallery:raise APIError('The images belong to a different group gallery.')
            image=reference(row.get('id'),('ggim',));file=reference(row.get('fileId'),('file',))
            if image in images or file in files:raise ValueError('Gallery pagination repeated an image or file. Refresh after the gallery stops changing.')
            images.add(image);files.add(file);rows.append(row)
            if len(rows)>2000:raise ValueError('Complete gallery review is limited to 2,000 images.')
        if len(page)<100:return rows
    raise ValueError('Gallery completeness could not be established within its page budget.')


def read_gallery_complete(client,subject,*,stop=None,progress=None):
    group,gallery=subject.split('/',1);group=entity_id('group',group);gallery=reference(gallery,('ggal',))
    expected=context(client);lock(client,stop)
    try:
        data=_gallery_pages(client,group,gallery,expected,stop=stop,progress=progress)
        return Snapshot('group-gallery',group+'/'+gallery,expected,client.clock(),stamp(),encoded(data),client,complete_collection=True)
    finally:client.lock.release()


def allowed(group,own,permission):
    if not isinstance(group,dict) or not isinstance(group.get('myMember'),dict):return False
    member=group['myMember']
    if member.get('userId',own)!=own:return False
    permissions=member.get('permissions')
    return isinstance(permissions,list) and ('*' in permissions or permission in permissions)


def patch(values,spec):
    if not isinstance(values,dict) or not values or set(values)-set(spec):raise ValueError('Only the displayed editable fields can be submitted.')
    out={}
    for key,value in values.items():
        rule=spec[key]
        if isinstance(rule,int):out[key]=text(value,rule)
        elif rule is bool:
            if type(value)is not bool:raise ValueError(key+' must be true or false.')
            out[key]=value
        elif isinstance(rule,tuple):
            if value not in rule:raise ValueError('Choose a supported '+key+'.')
            out[key]=value
        elif rule=='links':
            if not isinstance(value,list) or len(value)>10:raise ValueError('Use at most ten links.')
            out[key]=[]
            for url in value:
                u=urlsplit(text(url,2048))
                if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:raise ValueError('Use ordinary HTTP(S) links without credentials.')
                out[key].append(url)
        elif rule=='strings':
            if not isinstance(value,list) or len(value)>100:raise ValueError('Use at most 100 values.')
            out[key]=list(dict.fromkeys(text(v,120) for v in value))
        elif rule=='number':
            if type(value)is not int or not 0<=value<=100000:raise ValueError(key+' must be a nonnegative whole number up to 100,000.')
            out[key]=value
        elif rule=='date':
            try:date=datetime.fromisoformat(value.replace('Z','+00:00'))
            except (ValueError,AttributeError):raise ValueError(key+' must be an ISO timestamp with time zone.') from None
            if date.tzinfo is None:raise ValueError(key+' needs a time zone.')
            out[key]=date.isoformat()
        elif rule=='color':
            if not isinstance(value,str) or not re.fullmatch(r'#?[0-9a-fA-F]{6}',value):raise ValueError('Colors use RRGGBB or #RRGGBB.')
            out[key]=value.lstrip('#').upper()
        elif rule=='image-url':
            if value!='' and (not isinstance(value,str) or not re.fullmatch(r'https://api\.vrchat\.cloud/api/1/file/file_[0-9a-fA-F-]{36}/[1-9][0-9]*/file',value)):
                raise ValueError('Select a completed VRChat image URL from your media.')
            out[key]=value
    return out


PROFILE={'bio':512,'bioLinks':'links','bannerType':('avatarBanner','color','customImage'),'bannerColor':'color',
 'backgroundType':('gradient','texture'),'backgroundTextureId':120,'backgroundTemplateId':120,'backgroundGradientTop':'color','backgroundGradientBottom':'color',
 'bannerCustomUrl':'image-url','userIcon':'image-url',
 'themeId':120,'themeButtonColor':'color','themeIconColor':'color','themeSubtextColor':'color','iconFrame':120,'nameplateEffect':120,'profileEffect':120}
WORLD={'name':100,'description':2048,'tags':'strings','capacity':'number','recommendedCapacity':'number'}
ROLE={'name':100,'description':1000,'isAddedOnJoin':bool,'isSelfAssignable':bool,'requiresTwoFactor':bool,'permissions':'strings','order':'number'}
POST={'title':100,'text':2000,'imageId':120,'sendNotification':bool}
EVENT={'title':100,'description':2000,'startsAt':'date','endsAt':'date','accessType':('group','public'),'category':100,
       'tags':'strings','imageId':120,'roleIds':'strings','platforms':'strings','languages':'strings','sendCreationNotification':bool,
       'hostEarlyJoinMinutes':'number','guestEarlyJoinMinutes':'number','closeInstanceAfterEndMinutes':'number'}
GROUP={'name':100,'shortCode':6,'description':2000,'joinState':('open','request','invite','closed'),'languages':'strings',
       'rules':10000,'links':'links','bannerId':120,'iconId':120,'allowGroupJoinPrompt':bool}
GALLERY={'name':100,'description':1000,'membersOnly':bool,'roleIdsToAutoApprove':'strings',
         'roleIdsToManage':'strings','roleIdsToSubmit':'strings','roleIdsToView':'strings'}
THEME={'name':100,'buttonColor':'color','iconColor':'color','subtextColor':'color'}
GROUP_INSTANCE={'worldId':120,'groupAccessType':('members','plus','public'),'region':('us','use','eu','jp'),
    'roleIds':'strings','ageGate':bool,'displayName':64,'queueEnabled':bool,'instancePersistenceEnabled':bool,'playerPersistenceEnabled':bool}


def removable_role(role,group_id):
    if (not isinstance(role,dict) or role.get('groupId')!=group_id or role.get('defaultRole') is not False
        or role.get('isManagementRole') is not False or not isinstance(role.get('permissions'),list)
        or '*' in role['permissions']):
        raise ValueError('Only a confirmed ordinary role can be deleted. Default and management roles are protected.')
    reference(role.get('id'),('grol',))
    return role


def gallery_roles(values,group):
    roles={r.get('id') for r in group.get('roles') or [] if isinstance(r,dict)}
    for key,value in values.items():
        if key.startswith('roleIdsTo'):
            if any(reference(ref,('grol',)) not in roles for ref in value):raise ValueError('Choose roles returned for this group.')


def prepare(client,action,*,result,row=None,values=None,target='',group_result=None):
    if action not in ACTIONS:raise ValueError('This native action has no verified source contract.')
    own=context(client)[0];data=fresh(client,result);values=values or {};body={};method='PUT';path='';expected='';permission=''
    fields=[];receipt_target=own;snapshot=result;guard={}
    if action.startswith('notification2-'):
        r=selected(client,result,row,'notifications-v2');ref=reference(r.get('id'),('not','ntf'))
        if r.get('receiverUserId',own)!=own:raise ValueError('Select your own notification.')
        path='notifications/'+ref;receipt_target=ref
        if action=='notification2-hide':method='DELETE'
        elif action=='notification2-see':method='POST';path+='/see'
        else:
            response=values.get('response')
            if not isinstance(response,dict) or response not in r.get('responses',[]) or not isinstance(response.get('type'),str):raise ValueError('Choose a response supplied by this notification.')
            method='POST';path+='/respond';body=dict(notificationId=ref,responseType=text(response['type'],120),responseData=text(response.get('data',''),4096))
            fields.append(('Response',None,response['type']))
    elif action=='saved-message-edit':
        r=selected(client,result,row,'messages');slot=r.get('slot')
        if type(slot)is not int or not 0<=slot<=11:raise ValueError('Choose an existing message slot from 0–11.')
        body=patch(values,{'message':2000});path=f'message/{own}/{result.subject}/{slot}';receipt_target=f'{own} · {result.subject} · {slot}'
        fields=[('Message',r.get('message'),body['message'])]
    elif action=='profile-edit':
        fresh(client,result,'profile')
        if data.get('id')!=own:raise ValueError('Refresh your own profile.')
        body=patch(values,PROFILE);path='profile/'+own;expected=own
        fields=[(k,data.get(k),v) for k,v in body.items() if data.get(k)!=v]
        if not fields:raise ValueError('No profile fields changed.')
    elif action.startswith('profile-theme-'):
        if result.kind!='profile-themes' or result.subject!=own:raise ValueError('Refresh your own profile themes first.')
        path='profile/theme';receipt_target='Profile theme';method='POST'
        if action!='profile-theme-create':
            r=selected(client,result,row,'profile-themes');expected=token(r.get('id'));guard=r
            path+='/'+expected;receipt_target+=' · '+expected;method='DELETE' if action.endswith('delete') else 'PUT'
        if method!='DELETE':
            body=patch(values,THEME)
            if not body.get('name','').strip():raise ValueError('Give the profile theme a name.')
            if method=='PUT':body['themeId']=expected
            fields=[(k,guard.get(k),v) for k,v in body.items()]
    elif action.startswith('favorite-group-'):
        # Preserve the existing result owner; conversion happens only for a fresh
        # Game Favorites result in bridge_favorite_group below.
        if result.kind!='favorite-group' or data.get('ownerId')!=own:raise ValueError('Refresh and select one of your own game lists.')
        kind=data.get('type');name=token(data.get('name'),100)
        if kind not in ('avatar','world','vrcPlusWorld','friend'):raise ValueError('Unsupported game favorite type.')
        path=f'favorite/group/{kind}/{quote(name,safe="")}/{own}';receipt_target=kind+' · '+name
        if action.endswith('clear'):method='DELETE';body={'type':kind,'group':name}
        else:body=patch(values,{'displayName':100,'visibility':('private','friends','public')});body.update(type=kind,group=name)
        fields=[(k,data.get(k),v) for k,v in body.items()]
    elif action in ('world-edit','world-publish','world-unpublish'):
        fresh(client,result,'world');ref=entity_id('world',data.get('id'))
        if data.get('authorId')!=own:raise ValueError('Only your own uploaded world can be changed.')
        path='worlds/'+ref;receipt_target=expected=ref
        if action=='world-edit':body=patch(values,WORLD);fields=[(k,data.get(k),v) for k,v in body.items()]
        else:path+='/publish';method='DELETE' if action=='world-unpublish' else 'PUT';body={'worldId':ref}
    elif action=='group-create':
        if result.kind!='profile' or data.get('id')!=own:raise ValueError('Refresh your profile before creating a group.')
        spec={k:GROUP[k] for k in ('name','shortCode','description','joinState','bannerId','iconId')}
        spec.update(privacy=('public','default'),roleTemplate=('default','managedFree','managedInvite','managedRequest'))
        body=patch(values,spec)
        if not body.get('name') or not body.get('shortCode'):raise ValueError('A group name and short code are required.')
        path='groups';method='POST';receipt_target='New group';fields=[(k,None,v) for k,v in body.items()]
    elif action.startswith('group-'):
        group=fresh(client,group_result or result,'group');snapshot=group_result or result
        ref=entity_id('group',group.get('id'));path='groups/'+ref;receipt_target=ref
        if result.kind.startswith('group') and result.subject.split('/')[0]!=ref:raise ValueError('The selected page and permission review belong to different groups.')
        permission=GROUP_PERMISSION.get(action,'')
        if action=='group-instance-create':
            access=values.get('groupAccessType')
            permission={'members':'group-instance-open-create','plus':'group-instance-plus-create','public':'group-instance-public-create'}.get(access,'')
            if not permission:raise ValueError('Choose a supported group access type.')
        if permission and not allowed(group,own,permission):raise ValueError('Your current group membership does not grant '+permission+'.')
        if action in ('group-transfer','group-delete') and group.get('ownerId')!=own:raise ValueError('Only the confirmed current group owner can review this action.')
        user_actions={'group-invite','group-cancel-invite','group-kick','group-ban','group-unban','group-accept-request','group-reject-request','group-block-request','group-role-add','group-role-remove','group-transfer'}
        if action in user_actions:
            target=entity_id('user',target);receipt_target+=' · '+target
            if target==own and action in ('group-kick','group-ban','group-transfer'):raise ValueError('Choose another group member.')
        if action=='group-instance-create':
            body=patch(values,GROUP_INSTANCE);body['worldId']=entity_id('world',body.get('worldId'))
            if not body.get('region'):raise ValueError('Select an instance region.')
            if body.get('roleIds') and body['groupAccessType']!='members':raise ValueError('Role restrictions require a members instance.')
            roles={r.get('id') for r in group.get('roles') or [] if isinstance(r,dict)}
            if any(reference(r,('grol',)) not in roles for r in body.get('roleIds',[])):raise ValueError('Select roles returned for this group.')
            if body.get('ageGate') and not allowed(group,own,'group-instance-age-gated-create'):raise ValueError('Your group does not grant creation of age-gated instances.')
            body.update(type='group',ownerId=ref);path='instances';method='POST';guard={'worldId':body['worldId']}
            fields=[(k,None,v) for k,v in body.items()]
        elif action=='group-invite':path+='/invites';method='POST';body={'userId':target}
        elif action=='group-cancel-invite':path+='/invites/'+target;method='DELETE'
        elif action=='group-kick':path+='/members/'+target;method='DELETE'
        elif action=='group-ban':path+='/bans';method='POST';body={'userId':target}
        elif action=='group-unban':path+='/bans/'+target;method='DELETE'
        elif action in ('group-accept-request','group-reject-request','group-block-request'):
            path+='/requests/'+target;body={'action':{'group-accept-request':'accept','group-reject-request':'reject','group-block-request':'block'}[action]}
        elif action in ('group-role-add','group-role-remove'):
            role=reference(values.get('roleId'),('grol',));path+=f'/members/{target}/roles/{role}';method='PUT' if action.endswith('add') else 'DELETE';receipt_target+=' · '+role
        elif action in ('group-role-create','group-role-edit'):
            body=patch(values,ROLE);path+='/roles';method='POST'
            if action.endswith('edit'):path+='/'+reference(target,('grol',));method='PUT'
            # An account may never grant permissions absent from its effective grant.
            granted=group.get('myMember',{}).get('permissions',[])
            if '*' not in granted and not set(body.get('permissions',[]))<=set(granted):raise ValueError('A role cannot grant permissions you do not currently hold.')
        elif action=='group-role-delete':
            r=removable_role(selected(client,result,row,'group-roles'),ref)
            if values or target and target!=r['id']:raise ValueError('Select the exact role to delete.')
            guard=r;expected=r['id'];path+='/roles/'+expected;method='DELETE';receipt_target+=' · '+expected
            fields=[('Role',r.get('name') or expected,'Deleted'),('Effect',None,'Members lose this role and its permissions.')]
        elif action in ('group-gallery-add-image','group-gallery-remove-image','group-gallery-order'):
            if result.kind not in ('group-gallery','group-gallery-pending'):raise ValueError('Load the exact group gallery first.')
            gallery=reference(result.subject.split('/',1)[1],('ggal',));path+=f'/galleries/{gallery}/images'
            guard={'gallery':gallery,'offset':result.offset,'pending':result.kind=='group-gallery-pending'}
            if action=='group-gallery-add-image':
                body={'fileId':reference(values.get('fileId'),('file',))};method='POST'
                if set(values)!={'fileId'}:raise ValueError('Select one uploaded file.')
            elif action=='group-gallery-remove-image':
                r=selected(client,result,row);expected=reference(r.get('id'),('ggim',));guard['image']=r
                path+='/'+expected;method='DELETE'
            else:
                if result.offset or result.more or result.query or result.kind!='group-gallery':raise ValueError('Ordering requires a complete, unfiltered gallery. Load the complete gallery before review.')
                if len(data)>=100 and not result.complete_collection:raise ValueError('Load the complete gallery before ordering multiple pages.')
                ids=values.get('ids');current=[r.get('fileId') for r in data]
                if set(values)!={'ids'} or not isinstance(ids,list) or not ids or len(ids)!=len(set(ids)) or set(ids)!=set(current):raise ValueError('Order every returned gallery file exactly once.')
                body={'galleryId':gallery,'ids':[reference(v,('file',)) for v in ids]};path='files/order';guard['files']=current;guard['all_pages']=result.complete_collection
            receipt_target+=' · '+gallery;fields=[(k,None,v) for k,v in body.items()] or [('Image',expected,'Removed from group gallery')]
        elif action.startswith('group-gallery-'):
            path+='/galleries'
            if action=='group-gallery-create':
                body=patch(values,GALLERY);method='POST'
                if not body.get('name','').strip():raise ValueError('Give the gallery a name.')
                gallery_roles(body,group)
            else:
                r=selected(client,result,row,'group-galleries');expected=reference(r.get('id'),('ggal',))
                if target and target!=expected:raise ValueError('Select the exact gallery to change.')
                guard=r;path+='/'+expected;receipt_target+=' · '+expected
                if action=='group-gallery-delete':
                    if values:raise ValueError('Gallery deletion accepts only the selected gallery.')
                    method='DELETE';fields=[('Gallery',r.get('name') or expected,'Deleted'),('Effect',None,'The gallery and its image entries will be removed.')]
                else:
                    body=patch(values,GALLERY);gallery_roles(body,group)
                    if 'name' in body and not body['name'].strip():raise ValueError('Give the gallery a name.')
                    fields=[(k,r.get(k),v) for k,v in body.items() if r.get(k)!=v]
                    if not fields:raise ValueError('No gallery fields changed.')
        elif action in ('group-post-create','group-post-edit','group-post-delete'):
            path+='/posts'
            if action!='group-post-create':path+='/'+reference(target,('gpos',))
            method='POST' if action.endswith('create') else 'DELETE' if action.endswith('delete') else 'PUT'
            if method!='DELETE':body=patch(values,POST)
        elif action.startswith('group-event-'):
            path='calendar/'+ref
            if action=='group-event-create':path+='/event';method='POST';body=patch(values,EVENT)
            else:
                path+='/'+reference(target,('cal',))
                if action=='group-event-edit':path+='/event';body=patch(values,{k:v for k,v in EVENT.items() if k!='sendCreationNotification'})
                elif action=='group-event-follow':path+='/follow';method='POST';body=patch(values,{'isFollowing':bool})
                else:method='DELETE'
            if 'startsAt' in body and 'endsAt' in body and datetime.fromisoformat(body['endsAt'])<=datetime.fromisoformat(body['startsAt']):raise ValueError('An event must end after it starts.')
        elif action=='group-settings':body=patch(values,GROUP)
        elif action=='group-transfer':
            transfer=fresh(client,result,'group-transfer-check')
            required=('groupNotMonetized','hasVRCPlus','hasVerifiedEmail','targetCanOwnMoreGroups','targetIsGroupMember')
            if result.subject!=ref+'/'+target or any(transfer.get('requirements',{}).get(k) is not True for k in required):raise ValueError('Every transfer requirement must be confirmed for this exact recipient.')
            path+='/transfer';method='POST';body={'transferTargetId':target}
        elif action=='group-delete':method='DELETE';body={'hardDelete':False}
        elif action=='group-represent':path+='/representation';body=patch(values,{'isRepresenting':bool})
        elif action=='group-cancel-request':path+='/requests';method='DELETE'
        else:path+='/'+{'group-join':'join','group-leave':'leave','group-block':'block'}[action];method='POST'
        if not fields:fields=[(k,None,v) for k,v in body.items()]
    elif action in ('avatar-image','world-image'):
        kind=action.split('-')[0];fresh(client,result,kind)
        if data.get('authorId')!=own:raise ValueError('Only an owned asset can receive a new image.')
        if set(values)!={'imageUrl','fileId'}:raise ValueError('Choose an uploaded image returned for this account.')
        file_id=reference(values['fileId'],('file',));url=values['imageUrl']
        if not isinstance(url,str) or not re.fullmatch(r'https://api\.vrchat\.cloud/api/1/file/'+re.escape(file_id)+r'/[1-9][0-9]*/file',url):raise ValueError('Use the exact VRChat file URL returned by the upload.')
        path=('avatars/' if kind=='avatar' else 'worlds/')+data['id'];body={'imageUrl':url};expected=data['id'];receipt_target=data['id']
        fields=[('Previous image',data.get('imageUrl'),url),('Uploaded file',None,file_id)]
    elif action in ('media-delete','print-delete','inventory-consume'):
        r=selected(client,result,row);ref=r.get('id') or r.get('inventoryId')
        if action=='media-delete':
            if result.kind not in ('gallery','icons','stickers','emoji','avatar-gallery'):raise ValueError('Choose an account media record.')
            ref=reference(ref,('file',));path='file/'+ref;method='DELETE'
            if r.get('ownerId',own)!=own:raise ValueError('This file belongs to another account.')
        elif action=='print-delete':
            if result.kind!='prints':raise ValueError('Choose a print from your current account.')
            ref=reference(ref,('prnt',));path='prints/'+ref;method='DELETE'
            if r.get('authorId',own)!=own:raise ValueError('This print belongs to another account.')
        else:
            if result.kind!='inventory':raise ValueError('Choose an item from your current inventory.')
            if r.get('itemType')!='bundle':raise ValueError('Only a currently returned inventory bundle can be consumed.')
            ref=reference(ref,('inv',));path='inventory/'+ref+'/consume';method='PUT';body={'inventoryId':ref}
            if r.get('holderId',own)!=own:raise ValueError('This item belongs to another account.')
        receipt_target=ref
    elif action=='reward-redeem':
        if result.kind!='profile' or data.get('id')!=own:raise ValueError('Refresh your own profile before redeeming a code.')
        body=patch(values,{'code':200})
        if not body.get('code','').strip():raise ValueError('Enter a reward code before reviewing redemption.')
        path='reward/redeem';method='POST';receipt_target=own+' · reward redemption'
        fields=[('Reward code (not retained)',None,body['code'])]
    elif action in ('inventory-equip','inventory-unequip','inventory-archive','inventory-unarchive'):
        r=selected(client,result,row)
        if result.kind not in ('inventory','inventory-archived'):raise ValueError('Select a returned item from your own inventory.')
        if r.get('holderId')!=own:raise ValueError('The service must identify you as the holder of this item.')
        ref=reference(r.get('id') or r.get('inventoryId'),('inv',));path='inventory/'+ref;method='PUT';expected=ref;receipt_target=ref
        if action=='inventory-equip':
            body=patch(values,{'equipSlot':EQUIP_SLOTS})
            if r.get('isArchived') is True:raise ValueError('Unarchive this item before equipping it.')
            body['inventoryId']=ref;path+='/equip';fields=[('Equipment slot',r.get('equipSlot'),body['equipSlot']),('Item',None,r.get('itemName') or ref)]
        elif action=='inventory-unequip':
            slot=r.get('equipSlot')
            if values or slot not in EQUIP_SLOTS:raise ValueError('Select an equipped item with a supported slot.')
            guard={'equipSlot':slot};path='inventory/'+slot+'/equip';method='DELETE'
            fields=[('Equipment slot',slot,'Empty'),('Currently equipped item',r.get('itemName') or ref,'Unequipped; kept in inventory')]
        else:
            if values:raise ValueError('Archive actions accept only the selected item.')
            body={'isArchived':action=='inventory-archive'};fields=[('Archived',r.get('isArchived'),body['isArchived'])]
    if not path:raise ValueError('No supported route for this action.')
    if not fields:fields=[('Action',None,action.replace('-',' ')),('Target',None,receipt_target)]
    return Mutation(action,path,method,encoded(body),receipt_target,tuple(fields),snapshot,expected,permission,encoded(guard))


def bridge_favorite_group(client,result,row):
    import companion_api as api
    api.selected_record(client,result,row,'favorite-groups')
    if result.source_client is not client:raise ValueError('Refresh the game lists first.')
    return Snapshot('favorite-group',row['name'],result.account,result.checked,result.checked_at,encoded(bounded(row)),client)


def dispatch(client,plan,*,stop=None,progress=None,before_dispatch=None,on_confirmed=None):
    if not isinstance(plan,Mutation):raise ValueError('Prepare a native action first.')
    fresh(client,plan.snapshot);expected=plan.snapshot.account;lock(client,stop)
    try:
        check_context(client,expected,stop)
        if plan.snapshot.kind=='group':
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            route='groups/'+entity_id('group',plan.snapshot.subject)
            if plan.action.startswith('group-gallery-') or plan.action=='group-instance-create':route+='?includeRoles=true'
            group=client._request(route)
            if group.get('id')!=plan.snapshot.subject:raise APIError('Group identity changed while reviewing.')
            if plan.permission and not allowed(group,expected[0],plan.permission):raise ValueError('Your group permission changed before dispatch.')
            if plan.action in ('group-role-create','group-role-edit'):
                granted=group.get('myMember',{}).get('permissions',[])
                if '*' not in granted and not set(json.loads(plan.payload).get('permissions',[]))<=set(granted):raise ValueError('The permissions you may grant changed before dispatch.')
            if plan.action in ('group-transfer','group-delete') and group.get('ownerId')!=expected[0]:raise ValueError('Group ownership changed before dispatch.')
            if plan.action=='group-role-delete':
                client._wait_metadata(stop,progress);check_context(client,expected,stop)
                roles=client._request('groups/'+plan.snapshot.subject+'/roles',expect_list=True)
                role=next((r for r in roles if isinstance(r,dict) and r.get('id')==plan.expected_id),None)
                removable_role(role,plan.snapshot.subject)
                if encoded(bounded(role))!=plan.guard_json:raise ValueError('The role changed after review. Refresh it before deleting.')
            if plan.action in ('group-gallery-create','group-gallery-edit','group-gallery-delete'):
                gallery_roles(json.loads(plan.payload),group)
                if plan.action!='group-gallery-create':
                    gallery=next((r for r in group.get('galleries',[]) if isinstance(r,dict) and r.get('id')==plan.expected_id),None)
                    if gallery is None or encoded(bounded(gallery))!=plan.guard_json:raise ValueError('The gallery changed after review. Refresh it first.')
            if plan.action=='group-instance-create':
                body=json.loads(plan.payload)
                if body.get('ageGate') and not allowed(group,expected[0],'group-instance-age-gated-create'):raise ValueError('Age-gated creation permission changed.')
                roles={r.get('id') for r in group.get('roles',[]) if isinstance(r,dict)}
                if not set(body.get('roleIds',[]))<=roles:raise ValueError('The selected instance roles changed.')
                client._wait_metadata(stop,progress);check_context(client,expected,stop)
                world=client._request('worlds/'+body['worldId'])
                if world.get('id')!=body['worldId']:raise ValueError('The selected world is no longer available.')
            if plan.action in ('group-gallery-add-image','group-gallery-remove-image','group-gallery-order'):
                guard=json.loads(plan.guard_json);gallery=guard['gallery']
                if not any(r.get('id')==gallery for r in group.get('galleries',[]) if isinstance(r,dict)):raise ValueError('The selected gallery is no longer available.')
                if plan.action=='group-gallery-add-image':
                    client._wait_metadata(stop,progress);check_context(client,expected,stop)
                    file=client._request('file/'+json.loads(plan.payload)['fileId'])
                    if file.get('id')!=json.loads(plan.payload)['fileId'] or file.get('ownerId')!=expected[0] or not any(v.get('file',{}).get('status')=='complete' for v in file.get('versions',[])):
                        raise ValueError('Select a completed image owned by the active account.')
                else:
                    if plan.action=='group-gallery-order' and guard.get('all_pages'):
                        images=_gallery_pages(client,plan.snapshot.subject,gallery,expected,stop=stop,progress=progress)
                    else:
                        client._wait_metadata(stop,progress);check_context(client,expected,stop)
                        params=dict(n=100,offset=guard['offset'])
                        if guard.get('pending'):params['approved']='false'
                        images=client._request(f'groups/{plan.snapshot.subject}/galleries/{gallery}?'+urlencode(params),expect_list=True)
                    if plan.action=='group-gallery-order':
                        if (not guard.get('all_pages') and len(images)>=100) or [r.get('fileId') for r in images]!=guard['files']:raise ValueError('The gallery order or membership changed after review.')
                    else:
                        image=next((r for r in images if r.get('id')==plan.expected_id),None)
                        if image is None or encoded(bounded(image))!=encoded(guard['image']):raise ValueError('The selected gallery image changed after review.')
        if plan.action.startswith('profile-theme-'):
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            profile=client._request('profile/'+expected[0]+'?asSelf=true')
            if profile.get('id')!=expected[0]:raise ValueError('Profile ownership changed.')
            if plan.expected_id:
                theme=next((r for r in profile.get('themes',[]) if isinstance(r,dict) and r.get('id')==plan.expected_id),None)
                if theme is None or encoded(bounded(theme))!=plan.guard_json:raise ValueError('This profile theme changed after review.')
        if plan.action=='profile-edit':
            for field,url in json.loads(plan.payload).items():
                if field not in ('userIcon','bannerCustomUrl') or not url:continue
                file_id=url.split('/file/',1)[1].split('/')[0]
                client._wait_metadata(stop,progress);check_context(client,expected,stop)
                file=client._request('file/'+file_id)
                if file.get('id')!=file_id or file.get('ownerId')!=expected[0] or not any(v.get('file',{}).get('url')==url and v.get('file',{}).get('status')=='complete' for v in file.get('versions',[])):
                    raise ValueError('The selected profile image must be a completed image owned by the active account.')
        if plan.action in ('avatar-image','world-image'):
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            asset=client._request(plan.path)
            if asset.get('id')!=plan.expected_id or asset.get('authorId')!=expected[0]:raise ValueError('Asset ownership changed before image attachment.')
            url=json.loads(plan.payload)['imageUrl'];file_id=url.split('/file/',1)[1].split('/')[0]
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            uploaded=client._request('file/'+file_id)
            if uploaded.get('id')!=file_id or uploaded.get('ownerId')!=expected[0] or not any(v.get('file',{}).get('url')==url and v.get('file',{}).get('status')=='complete' for v in uploaded.get('versions',[])):
                raise ValueError('The image is not a completed file owned by the current account.')
        if plan.action in ('inventory-equip','inventory-unequip','inventory-archive','inventory-unarchive'):
            client._wait_metadata(stop,progress);check_context(client,expected,stop)
            item=client._request('inventory/'+plan.expected_id)
            if item.get('id')!=plan.expected_id or item.get('holderId')!=expected[0]:raise ValueError('The item is no longer confirmed in your inventory.')
            if plan.action=='inventory-equip' and item.get('isArchived') is True:raise ValueError('The item was archived after review.')
            if plan.action=='inventory-unequip' and item.get('equipSlot')!=json.loads(plan.guard_json)['equipSlot']:raise ValueError('The equipped slot changed after review. Refresh inventory first.')
        client._wait_metadata(stop,progress);check_context(client,expected,stop);fresh(client,plan.snapshot)
        if before_dispatch:before_dispatch()
        special=plan.action in ('group-role-delete','inventory-unequip','reward-redeem')
        options={'expect_list':True} if plan.action in ('group-role-delete','reward-redeem') else {'expect_string':True} if plan.action=='inventory-unequip' else {}
        response=client._request(plan.path,method=plan.method,payload=json.loads(plan.payload) or None,allow_empty=not special,**options)
        if plan.action=='group-role-delete':
            if any(not isinstance(r,dict) or r.get('id')==plan.expected_id for r in response):raise APIError('The service did not return a remaining-role list without the deleted role.')
            if len(response)>1000:raise APIError('The remaining-role response exceeds its limit.')
            for role in response:
                reference(role.get('id'),('grol',))
                if role.get('groupId',plan.snapshot.subject)!=plan.snapshot.subject:raise APIError('The returned roles belong to a different group.')
        elif plan.action=='inventory-unequip':
            if not isinstance(response,str) or not response.strip():raise APIError('The service did not acknowledge the equipment change.')
        elif plan.action=='reward-redeem':
            if not 1<=len(response)<=100 or any(not isinstance(r,dict) or r.get('redemptionCode')!=json.loads(plan.payload)['code']
                or not isinstance(r.get('redeemedRewards'),list) or 'error' in r or r.get('errorCode') for r in response):
                raise APIError('The service did not return a redemption result for the reviewed code.')
        elif plan.expected_id and plan.action not in ('group-gallery-delete','group-gallery-remove-image','profile-theme-edit','profile-theme-delete') and response.get('id')!=plan.expected_id:raise APIError('The service did not acknowledge the expected resource.')
        if plan.action=='group-gallery-create':reference(response.get('id'),('ggal',))
        if plan.action=='group-gallery-delete' and not response.get('success'):raise APIError('The service did not acknowledge gallery deletion.')
        if plan.action=='profile-theme-create':token(response.get('id'))
        if plan.action=='group-gallery-add-image':
            reference(response.get('id'),('ggim',))
            if response.get('groupId')!=plan.snapshot.subject or response.get('galleryId')!=json.loads(plan.guard_json)['gallery'] or response.get('fileId')!=json.loads(plan.payload)['fileId']:raise APIError('The gallery reply does not match the reviewed destination and image.')
        if plan.action=='group-gallery-remove-image' and not response.get('success'):raise APIError('The gallery image removal was not acknowledged.')
        if plan.action=='group-instance-create':
            body=json.loads(plan.payload)
            if response.get('worldId')!=body['worldId'] or response.get('ownerId')!=body['ownerId'] or response.get('type')!='group':raise APIError('The created instance differs from the reviewed group and world.')
        if isinstance(response,dict) and (response.get('success') is False or response.get('errorCode')):raise APIError('The service did not confirm the requested action.')
        if on_confirmed:on_confirmed()
        check_context(client,expected,stop)
        if plan.action=='group-instance-create':return bounded(response)
        return 'The service acknowledged the request. Refresh this view to inspect the resulting state.'
    finally:client.lock.release()
