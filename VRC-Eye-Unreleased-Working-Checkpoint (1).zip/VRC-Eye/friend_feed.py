"""Observed friend changes and an optional receive-only VRChat pipeline connection."""
import json
from http.cookies import SimpleCookie
import queue
import threading
import random
import hashlib
from urllib.parse import quote
from urllib.request import Request

from companion_data import entity_id, sanitize, stamp
from vrchat_api import APIError, API_ROOT, USER_AGENT
from developer_data import observe_pipeline

from profile_history import LABELS as WATCH


class FeedModel:
    def __init__(self,store,account):
        self.store,self.account=store,entity_id("user",account)
        self.friends={}; self.checked={}; self.revision=0

    def restore(self):
        """Bounded, account-local display cache; never proof of current presence."""
        size=0
        with self.store.connect() as db:
            rows=db.execute('SELECT id,data,checked FROM feed_profiles WHERE account=? ORDER BY checked DESC LIMIT 1000',(self.account,))
            for ref,raw,checked in rows:
                size+=len(raw.encode('utf-8'))
                if size>4*1024*1024:break
                try:
                    value=json.loads(raw)
                    if not isinstance(value,dict) or entity_id('user',value.get('id'))!=ref:continue
                    self.friends[ref]=sanitize(value);self.checked[ref]=checked
                except (ValueError,TypeError,RecursionError):continue
        self.revision+=1

    def observe(self,record,source="VRChat API",presence=None):
        if not isinstance(record,dict): raise ValueError("Invalid friend record.")
        ref=entity_id("user",record.get("id"))
        from profile_history import normalized_fields, observe
        incoming=normalized_fields(record)
        inferred=set()
        incoming["id"]=ref
        if presence is not None: incoming["state"]=presence
        if incoming.get("state")=="offline": incoming["location"]="offline"; inferred.add('location')
        elif presence is not None and "location" not in incoming:
            incoming["location"]="Not supplied with this presence update"
            inferred.add('location')
        old,_=self.store.profile(self.account,ref)
        if "status" in incoming and incoming["status"]!=old.get("status") and "location" not in incoming:
            incoming["location"]="Unavailable (status changed; refresh location)"
            inferred.add('location')
        current=observe(self.store,self.account,incoming,source,inferred=inferred)
        now=stamp(); name=current.get("displayName") or ref
        if not isinstance(name,str): name=ref
        if isinstance(incoming.get("groups"),list) and isinstance(old.get("groups"),list):
            old_ids={v.get("groupId") or v.get("id") for v in old["groups"] if isinstance(v,dict)}
            for group in incoming["groups"]:
                if not isinstance(group,dict): continue
                gid=group.get("groupId") or group.get("id")
                if gid and gid not in old_ids:
                    self.store.feed_event(self.account,ref,name,"Group appeared",f"{group.get('name') or gid}\nNewly visible since the previous snapshot; the actual join time is unknown.",source,now)
        self.friends[ref]=current; self.checked[ref]=now; self.revision+=1
        return current

    def log_avatar(self,event):
        if event.user_id not in self.friends or event.kind not in ("Changed","First seen"): return
        # A log avatar name cannot overwrite the API's independently identified current avatar ID/image.
        self.store.feed_event(self.account,event.user_id,event.player,"Avatar observed in shared instance",
            f"{event.previous or 'Unknown'} → {event.avatar}\nLog time: {event.timestamp}; avatar ID not established by the name.","Selected game log")
        self.revision+=1

    def pipeline(self,packet):
        kind,data=packet
        ref=entity_id("user",data.get("userId") or data.get("userid"))
        if kind=="friend-delete":
            old=self.friends.pop(ref,{})
            self.store.feed_event(self.account,ref,old.get("displayName") or ref,"Friendship changed","Friend removed from this account. This does not establish who removed whom.","VRChat pipeline")
            self.revision+=1; return
        user=data.get("user") or {}
        if not isinstance(user,dict): raise ValueError("Invalid pipeline user.")
        if user.get("id") and entity_id("user",user["id"])!=ref: raise ValueError("Pipeline user mismatch.")
        user=dict(user,id=ref)
        if "location" in data: user["location"]=data["location"]
        if data.get("worldId")=="private": user["location"]="private"
        if "platform" in data: user["platform"]=data["platform"]
        presence={"friend-online":"online","friend-active":"active on website","friend-offline":"offline"}.get(kind)
        if ref not in self.friends and kind not in ("friend-add","friend-online","friend-active","friend-location","friend-update","friend-offline"):
            return
        current=self.observe(user,"VRChat pipeline",presence)
        if kind in ("friend-online","friend-active","friend-offline","friend-add"):
            # The service explicitly emitted this event, even if no baseline exists yet.
            self.store.feed_event(self.account,ref,current.get("displayName") or ref,kind.replace('friend-','').title(),
                "Reported by the live pipeline at receipt time.","VRChat pipeline")


class PipelineSessionError(APIError):
    """A credential rejection with no credential-bearing server text."""


def parse_packet(raw):
    if not isinstance(raw,(str,bytes)) or len(raw)>2*1024*1024: raise ValueError("Pipeline packet exceeds 2 MiB.")
    try:
        body=json.loads(raw)
        if not isinstance(body,dict): raise ValueError
        if 'err' in body:
            if 'auth' in str(body['err']).lower() or 'session' in str(body['err']).lower():
                raise PipelineSessionError('The live session was rejected. Sign in again.',status_code=401)
            raise ValueError
        kind=body.get("type")
        if kind not in ("friend-add","friend-delete","friend-online","friend-active","friend-offline","friend-update","friend-location",
                        'user-update','notification','notification-v2','notification-v2-update','notification-v2-delete',
                        'see-notification','hide-notification','clear-notification','response-notification'): return None
        content=body.get("content")
        from companion_data import reference
        if kind=='clear-notification':return kind,{}
        if kind in ('see-notification','hide-notification'):
            if isinstance(content,str) and content.startswith('"'):content=json.loads(content)
            return kind,{'id':reference(content,('not','ntf'))}
        data=json.loads(content) if isinstance(content,str) else content
        if not isinstance(data,dict): raise ValueError
        from native_api import bounded
        if kind=='notification-v2-delete':
            ids=data.get('ids')
            if ids is None:ids=[data.get('id') or data.get('notificationId')]
            if not isinstance(ids,list) or not 1<=len(ids)<=1000:raise ValueError
            data={'ids':list(dict.fromkeys(reference(ref,('not','ntf')) for ref in ids)),
                  **({'receiverUserId':entity_id('user',data['receiverUserId'])} if 'receiverUserId' in data else {})}
        elif kind=='notification-v2-update':
            ref=reference(data.get('id') or data.get('notificationId'),('not','ntf'))
            updates=data.get('updates')
            if not isinstance(updates,dict):raise ValueError
            if any(k in updates for k in ('id','notificationId','receiverUserId')):raise ValueError
            data={'id':ref,'updates':bounded(updates),
                  **({'receiverUserId':entity_id('user',data['receiverUserId'])} if 'receiverUserId' in data else {})}
        elif kind.startswith('notification'):
            reference(data.get('id') or data.get('notificationId'),('not','ntf'))
            data=bounded(data)
        elif kind=='response-notification':
            data={'id':reference(data.get('notificationId'),('not','ntf')),
                  'responseId':reference(data.get('responseId'),('not','ntf')),
                  'receiverId':entity_id('user',data.get('receiverId'))}
        else:
            ref=entity_id("user",data.get("userId") or data.get("userid"))
            user=data.get('user',{})
            if not isinstance(user,dict) or user.get('id',ref)!=ref:raise ValueError
            data=sanitize(data);data['userId']=ref
        return kind,data
    except (ValueError,TypeError,RecursionError): raise ValueError("Unsupported live packet; a snapshot is needed.") from None


def pipeline_token(client):
    client._check()
    if not client.authenticated: raise APIError("Connect to VRChat first.")
    request=Request(API_ROOT+"auth/user")
    client.jar.add_cookie_header(request)
    parsed=SimpleCookie(); parsed.load(request.get_header("Cookie", ""))
    value=parsed.get("auth")
    if not value or not value.value or len(value.value)>2048: raise APIError("The VRChat session has no usable pipeline credential. Reconnect to VRChat.")
    return value.value


class Pipeline:
    def __init__(self,app,connector=None):
        self.app=app; self.connector=connector; self.stop=threading.Event(); self.output=queue.Queue(maxsize=512)
        self.socket=None; self.thread=None
        self.finished=threading.Event()
        self.gaps=0;self.overflow=False

    def start(self):
        client=self.app.api
        if not client or not client.authenticated:raise APIError('Connect to VRChat first.')
        if self.connector is None:
            try: import websocket
            except ImportError: raise APIError("Live Feed needs its optional dependency. Start.cmd prepares it automatically; reopen it online to retry. Manual friend refresh remains available.") from None
            self.connector=websocket.create_connection
        expected=(client,client.user_id,client.session_revision,getattr(self.app,'data_generation',0))
        self.app.transfer_stops.append(self.stop)
        def active():
            return not self.stop.is_set() and not getattr(self.app,'_native_private',False) and not self.app.demo and not getattr(self.app,'safe_mode',False) and self.app.api is client and client.authenticated and (client,client.user_id,client.session_revision,getattr(self.app,'data_generation',0))==expected
        def emit(kind,value):
            try: self.output.put_nowait((kind,value))
            except queue.Full:
                self.overflow=True;self.gaps+=1
                try:self.output.get_nowait();self.output.put_nowait(('gap','Live queue overflowed. Refresh to reconcile; missed events cannot be replayed.'))
                except (queue.Empty,queue.Full):pass
                self.stop.set()
        def run():
            try:
                # One owner, at most five reconnect attempts per Start gesture.
                # GET auth / ?auth= follows the supplied current VRCX contract.
                from player_api import lock,check_context
                previous=None;terminal=False
                for attempt in range(6):
                    if not active():break
                    try:
                        lock(client,self.stop)
                        try:
                            check_context(client,expected[1:3],self.stop);client._wait_metadata(self.stop,None)
                            auth=client._request('auth')
                            check_context(client,expected[1:3],self.stop)
                        finally:client.lock.release()
                        token=auth.get('token') if auth.get('ok') is True else None
                        if not isinstance(token,str) or not 1<=len(token)<=2048 or any(ord(c)<33 for c in token):raise APIError('No pipeline token was supplied.')
                        if not active():break
                        self.socket=self.connector('wss://pipeline.vrchat.cloud/?auth='+quote(token,safe=''),timeout=6,
                            header={'User-Agent':('VRC-Eye/1.21.0 '+client.application_contact) if getattr(client,'application_contact','') else USER_AGENT},redirect_limit=0,enable_multithread=True)
                        token=None;auth=None
                        if getattr(self.socket,'status',None)!=101:raise APIError('Pipeline handshake was not accepted.')
                        if not active():break
                        emit('reconcile','Connected. Reconciling bounded friend and inbox snapshots; gaps cannot be replayed.')
                        observe_pipeline(getattr(client,'diagnostics',None),None,account=expected[1],state='connected')
                        while active():
                            try:raw=self.socket.recv()
                            except Exception as error:
                                if type(error).__name__ in ('WebSocketTimeoutException','TimeoutError','timeout'):continue
                                raise
                            if not raw:raise APIError('Pipeline closed.')
                            if not active():break
                            try:packet=parse_packet(raw)
                            except ValueError:emit('gap','Unsupported live packet. Snapshot coverage may be incomplete.');continue
                            if packet:
                                fingerprint=hashlib.sha256(json.dumps(packet,sort_keys=True).encode()).digest()
                                if fingerprint==previous:continue
                                previous=fingerprint;emit('packet',packet)
                    except Exception as error:
                        if not active():break
                        if isinstance(error,PipelineSessionError) or getattr(error,'status_code',None) in (401,403):
                            emit('auth-error','The live session was rejected. Sign in again.');terminal=True;break
                        self.gaps+=1;emit('gap','Live connection interrupted. Changes during the gap are unknown.')
                        observe_pipeline(getattr(client,'diagnostics',None),None,account=expected[1],state='disconnected; reconciliation required')
                    finally:
                        if self.socket is not None:
                            try:self.socket.close(timeout=1)
                            except Exception:pass
                            self.socket=None
                    if not active() or attempt==5:break
                    delay=min(30,2**attempt)+random.random()
                    emit('status',f'Reconnecting in {delay:.0f} seconds (attempt {attempt+1}/5)…')
                    if self.stop.wait(delay):break
                if active() and not terminal:emit('error','Reconnect budget exhausted. The background service will retry after a cooldown.')
            finally:
                self.stop.set()
                if self.socket is not None:
                    try: self.socket.close(timeout=1)
                    except Exception: pass
                if self.stop in self.app.transfer_stops: self.app.transfer_stops.remove(self.stop)
                self.finished.set()
        self.thread=threading.Thread(target=run,daemon=True); self.thread.start()

    def close(self):
        self.stop.set()
        if self.socket is not None:
            try: self.socket.shutdown()
            except Exception: pass
