# VRC Eye 1.18.5 companion pages

Extract the complete ZIP into a new folder and run **Start.cmd**. Python 3.10 or
newer with Tkinter is required. Close the old release first. Settings and local
notes remain in your existing VRC Eye settings folder; no VRCX or JSON export is
required for the new online pages.

**Start.cmd** prepares the release's `.recovery-env` automatically, including
packages for live friend connections, expanded image decoding, encryption and
supplied-key recovery. If setup cannot finish offline, available core features
still open. Reopen **Start.cmd** when online to retry missing dependencies.

## Navigation and shared connection

| Sidebar page | What it contains |
| --- | --- |
| Primary | Existing Avatars and World tabs, player windows, maps, backups and other tools |
| Feed | Friend snapshots, live friend events, current picture previews and observed changes |
| Game Log | Searchable recorded activity, assets, media URLs, image previews, errors and explicit crash markers |
| Search | Users, worlds, groups and supported avatar collections or exact IDs |
| Favorites | Separate Game Favorites and unrestricted VRC Eye Favorites |
| Social | Friend lists, incoming friend/group invitations, and your own mutes and blocks |
| Wellness | Optional editable reminders, profiles, session/break timers and summaries |

**VRChat connection…** uses the existing login and two-factor verification
flow. Requests share the existing metadata queue: one request per 60 seconds.
A combined profile/groups refresh therefore needs two slots. Waiting is shown;
**Cancel pending task** cancels queued work. Pages do not sign in automatically.
Changing accounts clears the old account's visible online data. Demo disables
API actions and keeps sample logs separate from real Feed history.

Every account-changing action shows its exact target for review. Do not repeat
an action after an uncertain response without refreshing its list: the server
may have completed it even if the acknowledgement was lost. VRC Eye does not
retry writes automatically. Invite and game-list writes require recently
returned records; refresh when a five-minute record expires, including time
spent waiting in the queue.

## Feed

1. Sign in and open **Feed**. Choose online/website or offline friends and use
   **Refresh friends**. **Next friends page** loads the next 100 returned records.
   Loaded friends accumulate for this Feed session; an absent page entry is not
   considered offline.
2. Use **Start live Feed** for the optional receive-only VRChat pipeline
   connection. Stop it with **Stop live Feed**. A disconnect is shown; explicitly
   reconnect after checking your session. Missed events are not replayed.
3. Select a friend and use **Refresh profile + groups** for bio and visible-group
   snapshots. Available profile fields still update if the group request is
   denied. The optional snapshot cycle rotates through loaded friends; each
   friend needs two metadata requests, so large lists refresh slowly.
4. **Load current pictures** fetches the snapshot's profile and avatar images
   from supported VRChat image hosts. JPEG/WebP decoding needs the extras.
   Pictures do not refresh by themselves; reload them after a new snapshot.
5. **Observed changes** shows name, bio, status, presence, shared location, avatar
   and picture changes when those fields were actually supplied. Search and
   page through this account's retained history. Select an event for its full
   details and source.

The first snapshot establishes a baseline, not historical change events.
An avatar image change is labeled as an image change; it does not prove a new
avatar ID. Newly visible groups are **Group appeared**, because group visibility
can change and the API does not establish the actual join time. Private or
unavailable locations are not reconstructed. Partial records retain previously
observed fields: these are snapshots, not guarantees of the person's live state.
Historical game-log avatar names are not assigned to API avatar IDs.

The latest 5,000 observed events per signed-in account are stored locally, along
with comparison snapshots. **Forget this account's history…** deletes both for
that account. Stopping Feed does not erase saved history. Friend pictures are
held in memory; the app does not create an image archive.

## Game Log

Choose the log using the existing top **Open log…** or **Watch logs** controls.
Game Log consumes the same decoded lines, including lines without avatar events.
Filter by category and text, select an entry for full text, then choose one of
its recorded URLs. **Open link…** reviews the URL before opening your browser.
Non-HTTP protocols remain visible as text.

**Preview image** explicitly retrieves the selected image and shows it in the
page. It sends no login cookies. Automatic preview supports public HTTPS on
port 443, verifies each redirect and rejects private/local network addresses.
The host sees your connection. Supported responses are PNG/JPEG/GIF/WebP,
limited to 8 MiB and bounded decoded dimensions. Private or signed image URLs
may be unavailable. Known credential-bearing URLs are redacted and not made
clickable. **Copy entry / nearby context** includes neighboring retained lines.

A video resolution/load request is labeled **playback unconfirmed**. A recognized
start/end marker updates that recorded state; the app cannot verify that a
screen is currently playing it. Ordinary errors, EOF and normal shutdown are
not called crashes. The Crashes filter shows explicit markers, not a diagnosis
of what caused a crash. The log may omit assets, media or events entirely.

The newest 10,000 non-empty lines are retained in memory and displayed 200 per
page. The status shows how many older lines rolled out. **Export filtered log…**
saves the retained matching entries as JSON lines. A new log or reset clears
this view. Exports refuse to overwrite existing files; choose a new filename.
Review exported personal log content before sharing it; redaction covers known
credential patterns, not every possible secret or user-written message.

## Search

Choose Users, Worlds, Groups or Avatars, enter text or an exact ID/page URL, and
press **Search / load**. User/world/group results have 100 entries per page.
Worlds can use public search or **My uploads**. Avatar collections are featured,
your uploads or your game favorites; names/creators filter the current 50-entry
page, with later pages available through **Next** within the existing 1,000-item
API browsing window. The API is not an unrestricted global avatar-name index.

**Avatar search / VRCX…** opens the existing avatar search tool, including local
VRCX cache search and its download/archive workflows. **Avatar VRCA…** on an
avatar result performs the existing standalone exact-ID lookup/download flow;
it does not assign that avatar to a player. Existing access, supplied-key and
backup restrictions remain in effect. A name or favorite record does not grant
asset access or prove ownership.

Results link to the VRChat website. Users can open their existing secondary
profile window. Users, avatars and worlds can be saved to local favorites.
Group search has website and invitation workflows but no invented game-favorite
type: groups are not added to the friend/avatar/world local collection types.

## Favorites

**VRC Eye Favorites** works while signed out. Choose friend/avatar/world, paste
an exact ID or official page, and set a display name and local collection name.
**Save / update local entry** creates it or updates the existing type/ID record.
There is no app-imposed count limit and no VRC+ requirement. Each item has one
local collection label; update the label to move it. Search text and an optional
exact collection filter, then page through 100 entries at a time.

**Export all local favorites…** streams every entry to a CSV backup; names and
collection labels are JSON-quoted within CSV for exact Unicode round trips.
**Import local backup…** merges this format, updating matching type/ID names
and collections in one transaction. A malformed or canceled import rolls back.
Each import file is limited to 128 MiB; this is not a library item-count limit.
Exports refuse existing paths. These favorites are local bookmarks, not saved
VRCA/VRCW files, and are shared by the app's users on this computer.

**Game Favorites** reads your actual VRChat favorite lists. Load the lists,
choose one and load its items. IDs remain visible when the server omits names;
**Look up selected** resolves one name using an additional queued request.
**Refresh account limits** shows VRChat's returned number of lists and slots
for each type. Entitlements such as the requested free/VRC+ avatar capacities
are enforced by the server; the app does not grant extra game slots.

Adding requires an exact matching item ID and a recently refreshed owned list.
Removing uses the returned favorite record ID, not the avatar/user/world ID.
If one server record is attached to several list tags, the review warns that
removal applies to that complete record. Adding a game friend favorite still
requires whatever friendship and list permissions VRChat imposes. Local
favorites and game favorites never synchronize implicitly.

## Social

Load online/website friends, offline friends, incoming friend requests, group
invites, **My mutes**, or **My blocks**. Friend requests are filtered from paged
notifications; an empty filtered page can still have a next page.

Select a record for its exact ID and profile/page controls. Friend requests and
group invites can be accepted or declined after review. Accepting a group invite
requires the server to confirm actual membership; a pending membership request
is not reported as success. A declined group invite does not additionally block
the group.

The user ID field supports reviewed add/remove-friend, mute/unmute and
block/unblock actions. Unmute/unblock resets your corresponding moderation.
Refresh afterward to observe server state. These are your moderation records;
there is no claim to reveal who muted or blocked you. No action is triggered
by simply selecting a row.

## Wellness

Version 1.18.5 expands this page into **Casual** and **Advanced** views. Read
**WELLNESS_SETUP.md** for complete controls, device support, migration and privacy.

Manual use remains local and independent of VRChat login, VRCX and the bridge.
All reminder types start off on a fresh install. Profiles, first/repeat delays,
clock meals, per-day bedtimes, quiet hours, Focus/DND and consolidated reminders
are editable. Short breaks preserve timer progress; the default five-minute
meaningful break resets relevant reminders. Standing/sitting remain manual.

Optional integrations add observed process sessions, SteamVR proximity and
batteries, a head/wrist/dashboard overlay, and Windows per-application audio
metering and reviewed volume/mute/exit requests. **Start.cmd** prepares their packages automatically;
connect inputs explicitly. Unknown readings stay unknown, and no Wellness
condition automatically changes audio or closes VRChat.

Fresh installations keep the latest summary in memory only. Privacy / history
provides none/session/7-day/30-day/keep retention, deletion and explicitly
opted-in summary exports. Existing releases retain their prior saved-history
behavior until you change it. Templates contain configuration only; simulation
uses a separate engine. No health scores, streaks, calorie targets, emotional
responses or social status changes are produced. Windows/SteamVR integrations
still require a live hardware check; see **VALIDATION.md**.

## Data and release notes

The new `companion.sqlite3` is beside the existing settings file, normally under
`%APPDATA%\VRC-Eye` on Windows. It contains local favorites, account-scoped Feed
history/comparison snapshots, wellness settings/profiles and session summaries.
It does not store VRChat login credentials. Existing player notes keep their
separate storage. Close the app before copying these databases as a full backup.

This release was tested with controlled HTTP/WebSocket responses, synthetic
logs, temporary databases and headless Tk substitutes. The included
**VALIDATION.md** distinguishes these checks from live Windows, VRChat and
Unity testing. Source and tests are included. The package is versioned
**VRC-Eye-v1.18.5.zip**; the next incremental release is **1.18.6**, with the
agreed inclusive `.10` rollover retained.

The optional **Advanced → Client bridge…** panel is documented in
**BRIDGE_SETUP.md**. All seven companion pages remain usable without it.

## Implementation sources

Reviewed September 30–October 1, 2026. The community API project documents
observed endpoints; live access and fields may vary with the service/account.

- [VRChat API community reference](https://vrchat.community/reference)
- [Friends endpoint](https://vrchat.community/reference/get-friends)
- [User search](https://vrchat.community/reference/search-users)
- [World search](https://vrchat.community/reference/search-worlds)
- [Group search](https://vrchat.community/reference/search-groups)
- [Favorite limits](https://vrchat.community/reference/get-favorite-limits)
- [Add favorite](https://vrchat.community/reference/add-favorite)
- [Remove favorite](https://vrchat.community/reference/remove-favorite)
- [Receive-only pipeline message definitions](https://vrchat.community/websocket)
- [websocket-client connection implementation](https://websocket-client.readthedocs.io/en/latest/_modules/websocket/_core.html)
- [VRCX log parser](https://github.com/vrcx-team/VRCX/blob/master/Dotnet/LogWatcher.cs)
