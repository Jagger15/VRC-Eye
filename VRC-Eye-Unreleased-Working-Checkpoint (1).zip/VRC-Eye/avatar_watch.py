#!/usr/bin/env python3
"""VRC Eye: a local VRChat avatar-change viewer with optional VRCA saving.

Python 3.10+ with Tkinter. Start.cmd prepares feature packages automatically.
Managed Python environments can run: python vrc_eye.py [--logs DIRECTORY] [--demo]
"""

from __future__ import annotations

from text_viewport import window_body

import argparse
import codecs
import csv
import os
import queue
import re
import sqlite3
import threading
import time
from collections import deque
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from avatar_links import (avatar_url, find_local_candidates, merge_candidates, open_avatar_page,
                          parse_avatar_reference, release_status_label)
from avatar_details import (DownloadSizes, MAX_JSON_BYTES, PLATFORMS, avatar_day, format_platform_sizes,
                            sizes_are_stale)
from vrcx_integration import (CachedVisibility, VRCXError, find_vrcx_candidates,
                              load_vrcx_settings, read_vrcx_visibility, settings_path)
from avatar_performance import performance_label
from player_trust import trust_label
from player_platforms import (PlayerPlatform, USER_ID_PATTERN, parse_user_id, platform_details,
                              platform_for_event, platform_label)
from world_players import RosterSnapshot, WorldRoster, ROOM_EXITS


# Retained API/peer compatibility baseline; BUILD_VERSION is the public build name.
VERSION = "1.21.0"
BUILD_VERSION = "2026.05.10.02.47.1"
BUILD_TIMESTAMP = "2026-10-05T02:47:00-04:00"
BUILD_CHANNEL = "Development checkpoint 21"
BUILD_SUFFIX = "Development-21"
MAX_EVENTS = 3000
MAX_LINE = 262144
READ_SIZE = 262144
POLL_SECONDS = 0.5

# Only accept real log headers and the components that emit these events.
# This also avoids treating ordinary Udon/chat messages as avatar events.
HEADER = re.compile(
    r"^\ufeff?\s*\[?(\d{4}[./-]\d{2}[./-]\d{2}[ T]\d{2}:\d{2}:\d{2}"
    r"(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\]?"
    r"\s+\[?(?:Log|Info|Debug|Warning)\]?\s*(?:-\s*)?"
    r"\[(Behaviour|NetworkManager|Player|RoomManager)\]\s*(.*)$"
)
USER_SUFFIX = re.compile(r"\s+\(usr_[0-9a-fA-F-]+\)$")
USER_ID_SUFFIX = re.compile(rf"\s+\(({USER_ID_PATTERN})\)$")
LOCAL_PLAYER = re.compile(r'^Initialized PlayerAPI "(.*)" is local\s*$')


@dataclass(frozen=True)
class AvatarEvent:
    timestamp: str
    player: str
    previous: str
    avatar: str
    kind: str
    room: str
    source: str
    note: str = ""
    user_id: str = ""


class SessionParser:
    """Track log names and explicit join IDs within one room, without API calls."""

    def __init__(self, source: str = ""):
        self.source = source
        self.local_player = ""
        self.room = ""
        self.players: set[str] = set()
        self.avatars: dict[str, str] = {}
        self.player_ids: dict[str, set[str]] = {}
        self.world_roster = WorldRoster(source)
        from player_log_events import RosterEvents
        self.player_events = RosterEvents()
        self.reconstructing = False

    def reset_room(self):
        self.players.clear()
        self.avatars.clear()
        self.player_ids.clear()

    def feed(self, line: str) -> AvatarEvent | None:
        event = self._feed(line)
        self.player_events.capture(self.world_roster.snapshot(), event, reconstructed=self.reconstructing)
        return event

    def _feed(self, line: str) -> AvatarEvent | None:
        match = HEADER.match(line.rstrip("\r\n"))
        if not match:
            return None
        stamp, component, message = match.groups()
        self.world_roster.feed_entry(stamp, component, message)

        local = LOCAL_PLAYER.fullmatch(message)
        if local and component in ("Behaviour", "Player"):
            self.local_player = local.group(1)
            self.players.add(self.local_player)
            return None

        if component in ("Behaviour", "RoomManager"):
            if message.startswith("Entering Room: "):
                self.room = message[len("Entering Room: "):].strip()
                self.reset_room()
                return None
            if message.startswith("Joining wrld_"):
                self.reset_room()
                return None
            if message in ROOM_EXITS:
                self.reset_room()
                self.room = ""
                return None

        if component in ("Behaviour", "NetworkManager"):
            for action in ("OnPlayerJoined ", "OnPlayerLeft "):
                if message.startswith(action):
                    payload = message[len(action):].strip()
                    identity = USER_ID_SUFFIX.search(payload)
                    user_id = parse_user_id(identity.group(1)) if identity else ""
                    name = USER_SUFFIX.sub("", payload).strip()
                    if name:
                        if action == "OnPlayerJoined ":
                            self.players.add(name)
                            ids = self.player_ids.setdefault(name, set())
                            if ids and user_id not in ids:
                                self.avatars.pop(name, None)
                            ids.add(user_id)
                        else:
                            ids = self.player_ids.get(name, set())
                            if user_id:
                                ids.discard(user_id)
                            else:
                                ids.clear()
                            if not ids:
                                self.player_ids.pop(name, None)
                                self.players.discard(name)
                            self.avatars.pop(name, None)
                    return None

        if component != "Behaviour" or not message.startswith("Switching "):
            return None
        payload = message[len("Switching "):]
        separator = " to avatar "
        # A known roster name removes ambiguity if an avatar name itself
        # contains the delimiter. Otherwise retain the log's last delimiter.
        names = self.players | self.avatars.keys()
        candidates = [n for n in names if payload.startswith(n + separator)]
        note = ""
        if candidates:
            player = max(candidates, key=len)
            avatar = payload[len(player + separator):]
        else:
            player, found, avatar = payload.rpartition(separator)
            if not found:
                return None
            if payload.count(separator) > 1:
                note = "Name boundary is uncertain: repeated 'to avatar' in log entry."
        player, avatar = player.strip(), avatar.strip()
        if not player or not avatar:
            return None
        ids = self.player_ids.get(player, set())
        user_id = next(iter(ids)) if len(ids) == 1 and not note else ""
        if len(ids) > 1:
            note = "Player identity is uncertain: conflicting join entries share this display name."
        previous = self.avatars.get(player, "")
        kind = "First seen" if not previous else ("Reload" if avatar == previous else "Changed")
        if note:
            kind = "Uncertain"
        else:
            self.avatars[player] = avatar
        event = AvatarEvent(stamp, player, previous, avatar, kind,
                            self.room, self.source, note, user_id)
        self.world_roster.observe_player(player, stamp, user_id)
        return event


@dataclass
class ReadBatch:
    reset: bool
    source: str
    lines: list[str]
    size: int
    offset: int
    modified: float
    skipped: int
    encoding: str = "utf-8-sig"
    pending: int = 0
    roster: RosterSnapshot | None = None
    player_events: tuple = ()


class Diagnostics:
    """Counters only: reports contain no player names or log payloads."""

    def __init__(self):
        self.lines = 0
        self.headers = 0
        self.avatar_mentions = 0
        self.switch_candidates = 0
        self.rejected_switches = 0

    def observe(self, line: str, event: AvatarEvent | None):
        self.lines += 1
        self.headers += bool(HEADER.match(line))
        lower = line.casefold()
        self.avatar_mentions += "avatar" in lower
        candidate = "switching " in lower and " to avatar " in lower
        self.switch_candidates += candidate
        self.rejected_switches += candidate and event is None

    def snapshot(self):
        return dict(vars(self))


def diagnosis(stats: dict, matched: int, retained: int, visible: int) -> str:
    if matched:
        if not retained:
            return "History cleared — waiting for the next avatar entry."
        if not visible:
            return "Avatar entries found, but hidden by filters. Click Show all."
        return "Avatar entries detected."
    if stats.get("switch_candidates", 0):
        return "Switch-shaped lines found, but not parsed. Copy Diagnostics and provide an anonymized switch line."
    if stats.get("lines", 0) and not stats.get("headers", 0):
        return "Log header format not recognized. Copy Diagnostics and provide an anonymized switch line."
    if stats.get("lines", 0):
        return "No named avatar-switch entries found in this log yet. Check the active log and try an avatar switch."
    return "Waiting for complete log lines."


class LogFollower:
    """Incrementally read the latest output log; retain incomplete UTF-8 lines."""

    def __init__(self, folder: Path, *, tail_only: bool = False):
        self.folder = folder
        self.tail_only = tail_only
        self.path: Path | None = None
        self.identity = None
        self.offset = 0
        self.pending = ""
        self.sniff = b""
        self.decoder = None
        self.encoding = "detecting"
        self.dropping_line = False

    def latest_path(self) -> Path | None:
        if self.folder.is_file():
            return self.folder
        # Filename ordering uses VRChat's session-start timestamp, so touching
        # an older log does not accidentally switch away from the active one.
        paths = [p for p in self.folder.glob("output_log_*.txt") if p.is_file()]
        return max(paths, key=lambda p: p.name) if paths else None

    def poll(self, limit: int = READ_SIZE) -> ReadBatch | None:
        path = self.latest_path()
        if path is None:
            return None
        with path.open("rb") as stream:
            info = os.fstat(stream.fileno())
            identity = (info.st_dev, info.st_ino)
            reset = path != self.path or identity != self.identity or info.st_size < self.offset
            if reset:
                self.path, self.identity = path, identity
                self.offset, self.pending, self.dropping_line = 0, "", False
                self.decoder, self.sniff, self.encoding = None, b"", "detecting"
                if self.tail_only:
                    # A live position feed must never replay old session data.
                    start = stream.read(4)
                    self.encoding = ("utf-16-le" if start.startswith(codecs.BOM_UTF16_LE) else
                                     "utf-16-be" if start.startswith(codecs.BOM_UTF16_BE) else "utf-8")
                    self.decoder = codecs.getincrementaldecoder(self.encoding)(errors="replace")
                    self.offset = info.st_size
                    unit = 2 if self.encoding.startswith("utf-16") else 1
                    if info.st_size:
                        stream.seek(max(0, info.st_size - unit))
                        ending = stream.read(unit).decode(self.encoding, errors="replace")
                        self.dropping_line = ending != "\n"
                        if unit == 2 and info.st_size % 2:
                            stream.seek(info.st_size - 1)
                            self.decoder.decode(stream.read(1))
                    else:
                        # Let the normal BOM detector handle a newly created,
                        # empty log when its first bytes arrive.
                        self.decoder, self.encoding = None, "detecting"
            stream.seek(self.offset)
            block = stream.read(limit)
            self.offset += len(block)
        if self.decoder is None:
            self.sniff += block
            # Wait for enough bytes to distinguish BOMs, including split reads.
            partial_bom = any(bom.startswith(self.sniff) and len(self.sniff) < len(bom)
                              for bom in (codecs.BOM_UTF8, codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE))
            if self.sniff and not partial_bom and (len(self.sniff) >= 4 or self.offset >= info.st_size):
                if self.sniff.startswith((b"\xff\xfe", b"\xfe\xff")):
                    self.encoding = "utf-16"
                else:
                    self.encoding = "utf-8-sig"
                self.decoder = codecs.getincrementaldecoder(self.encoding)(errors="replace")
                text = self.decoder.decode(self.sniff)
                self.sniff = b""
            else:
                text = ""
        else:
            text = self.decoder.decode(block)
        if self.dropping_line:
            boundary = text.find("\n")
            if boundary < 0:
                text = ""
            else:
                text = text[boundary + 1:]
                self.dropping_line = False
        parts = (self.pending + text).split("\n")
        self.pending = parts.pop()
        lines = [part.rstrip("\r")
                 for part in parts if len(part) <= MAX_LINE]
        skipped = sum(len(part) > MAX_LINE for part in parts)
        if len(self.pending) > MAX_LINE:
            self.pending = ""
            self.dropping_line = True
            skipped += 1
        return ReadBatch(reset, path.name, lines, info.st_size,
                         self.offset, info.st_mtime, skipped, self.encoding, len(self.pending))


def monitor(folder: Path, output: queue.Queue, stop: threading.Event):
    follower = LogFollower(folder)
    parser = SessionParser()
    diagnostics = Diagnostics()

    def send(value):
        while not stop.is_set():
            try:
                output.put(value, timeout=0.1)
                return
            except queue.Full:
                continue

    while not stop.is_set():
        try:
            batch = follower.poll()
            if batch is None:
                send(("waiting", str(folder)))
            else:
                if batch.reset:
                    parser = SessionParser(batch.source)
                    diagnostics = Diagnostics()
                events = []
                if batch.reset: parser.reconstructing = True
                for line in batch.lines:
                    event = parser.feed(line)
                    diagnostics.observe(line, event)
                    if event is not None:
                        events.append(event)
                batch = replace(batch, roster=parser.world_roster.snapshot(), player_events=parser.player_events.drain())
                if batch.offset >= batch.size: parser.reconstructing = False
                send(("batch", batch, events, parser.local_player, parser.room, diagnostics.snapshot()))
                if batch.offset < batch.size:
                    continue  # Catch up promptly, without running on the UI thread.
        except OSError as error:
            send(("error", f"Cannot read logs: {error}. Retrying…"))
        stop.wait(POLL_SECONDS)


def default_log_folder() -> Path:
    if os.name == "nt":
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / "AppData/LocalLow/VRChat/VRChat"
    # Linux users can choose their Proton prefix with Browse or --logs.
    return Path.home() / ".local/share/Steam/steamapps/compatdata/438100/pfx/drive_c/users/steamuser/AppData/LocalLow/VRChat/VRChat"


def safe_csv_cell(value: str) -> str:
    """Prevent player/avatar names from becoming spreadsheet formulas."""
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


def event_visibility(event: AvatarEvent, links: dict, visibility: dict) -> tuple[str, str, str]:
    """Keep the status tied to the selected ID and retain uncertain provenance."""
    link = links.get(event)
    record = visibility.get(link[0]) if link else None
    if not record:
        return "Unknown", "", ""
    label = record.visibility
    if label in ("Public", "Private") and "(unverified)" in link[1]:
        label += "*"
    return label, record.source + ": " + record.note, record.read_at


def event_downloads_and_dates(event: AvatarEvent, links: dict, visibility: dict,
                              downloads: dict) -> tuple[str, str, str]:
    link = links.get(event)
    reference = link[0] if link else ""
    metadata = visibility.get(reference)
    sizes = downloads.get(reference)
    size_text = format_platform_sizes(sizes)
    created = avatar_day(metadata.created_at) if metadata else "Unknown"
    updated = avatar_day(metadata.updated_at) if metadata else "Unknown"
    if link and "(unverified)" in link[1]:
        if sizes:
            size_text += "*"
        if created != "Unknown":
            created += "*"
        if updated != "Unknown":
            updated += "*"
    if sizes_are_stale(sizes, metadata.updated_at if metadata else ""):
        size_text += " [stale]"
    return size_text, created, updated


def write_csv(path: Path, events: list[AvatarEvent], links: dict | None = None,
              visibility: dict | None = None, downloads: dict | None = None,
              player_platforms: dict | None = None, avatar_performance: dict | None = None):
    links = links or {}
    visibility = visibility or {}
    downloads = downloads or {}
    player_platforms = player_platforms or {}
    avatar_performance = avatar_performance or {}
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("Log time", "Player", "Previous avatar", "New avatar", "Event", "World", "Source", "Note",
                         "Avatar page", "Link source", "Visibility (cached)", "Visibility source",
                         "Visibility read at (UTC)", "Download sizes", "Download sizes source",
                         "Sizes recorded at (UTC)", "Sizes linked update timestamp", "Size freshness",
                         "Uploaded / created (UTC)", "Last updated (UTC)", "Player user ID (log)",
                         "Player platform", "Player platform source", "Player platform checked/imported at (UTC)",
                         "Player platform freshness", "Trust rank (tags)", "Trust source", "Trust checked/imported at (UTC)",
                         "Trust note", "Performance by platform", "Performance source", "Performance checked/imported at (UTC)"))
        for event in events:
            reference, source = links.get(event, ("", ""))
            status, status_source, checked = event_visibility(event, links, visibility)
            size_text, _created_day, _updated_day = event_downloads_and_dates(event, links, visibility, downloads)
            record, sizes = visibility.get(reference), downloads.get(reference)
            created, updated = (record.created_at, record.updated_at) if record else ("", "")
            device = platform_for_event(event, player_platforms)
            rating = avatar_performance.get(reference)
            writer.writerow([safe_csv_cell(value) for value in (
                event.timestamp, event.player, event.previous, event.avatar,
                event.kind, event.room, event.source, event.note,
                avatar_url(reference) if reference else "", source, status, status_source, checked,
                size_text, sizes.source if sizes else "", sizes.recorded_at if sizes else "",
                sizes.avatar_updated_at if sizes else "",
                ("Stale: cached update timestamp changed" if sizes_are_stale(sizes, updated) else
                 "Same cached update timestamp" if sizes and sizes.avatar_updated_at and updated else "Unknown"),
                created or "Unknown", updated or "Unknown", event.user_id,
                device.label if device else "Unknown", device.source if device else "",
                device.imported_at if device else "",
                "Latest available user data; source age and platform at event time unknown" if device else "Unknown",
                device.trust_rank if device else "Unknown", device.origin + ": tags" if device else "",
                device.imported_at if device else "", device.trust_note if device else "",
                rating.label if rating else "Unknown", rating.source if rating else "", rating.checked_at if rating else "")])


class AvatarWatch:
    BG = "#11151e"
    PANEL = "#1b2230"
    TEXT = "#edf3fc"
    MUTED = "#a5b2c7"
    ACCENT = "#65dbbf"

    def __init__(self, root, folder: Path, demo: bool = False, vrcx_database: Path | None = None, safe_mode: bool = False):
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk, self.root = tk, ttk, root
        self.events: deque[AvatarEvent] = deque(maxlen=MAX_EVENTS)
        self.avatar_links: dict[AvatarEvent, tuple[str, str]] = {}
        self.visibility: dict[str, CachedVisibility] = {}
        self.downloads: dict[str, DownloadSizes] = {}
        self.player_platforms: dict[str, PlayerPlatform] = {}
        self.world_roster = RosterSnapshot()
        self.avatar_performance = {}
        self.shader_reports = {}
        self.api = None
        self.connection_window = None
        self.range_window = None
        self.rangefinder_close = None
        self.online_visibility = {}
        self.online_avatar_ids = set()
        self.asset_exports = {}
        self.asset_selections = {}
        self.data_generation = 0
        self.visibility_request = 0
        self.transfer_stops = []
        self.row_menu = None
        self.visible: list[AvatarEvent] = []
        self.output: queue.Queue = queue.Queue(maxsize=24)
        self.stop = threading.Event()
        self.worker = None
        self.demo = False
        self.safe_mode = safe_mode
        self.paused = False
        self.local_player = ""
        self.last_modified = 0.0
        self.source = ""
        self.read_lines = 0
        self.matched = 0
        self.discarded = 0
        self.stats = {}
        self.batch = None
        self.dirty = True
        self.query = tk.StringVar()
        self.folder = tk.StringVar(value=str(folder))
        self.settings_file = settings_path()
        settings = load_vrcx_settings(self.settings_file)
        self.vrcx_path = tk.StringVar(value=str(vrcx_database) if vrcx_database else settings["vrcx_database"])
        self.vrcx_enabled = tk.BooleanVar(value=False if safe_mode else (settings["vrcx_enabled"] if not vrcx_database else True))
        self.show_first = tk.BooleanVar(value=True)
        self.show_reload = tk.BooleanVar(value=True)
        self.hide_self = tk.BooleanVar(value=False)
        self.on_top = tk.BooleanVar(value=False)
        self.state = tk.StringVar(value="Starting…")
        self.activity = tk.StringVar(value="")
        self.count = tk.StringVar(value="0 events")
        self.context = tk.StringVar(value="")
        self.detail = tk.StringVar(value="Select an event to see the full names and source.")
        self.link_status = tk.StringVar(value="Select an event to open its avatar page.")
        self.visibility_status = tk.StringVar(value="Select an avatar link for cached dates/status. Sizes: use Download sizes to fetch or enter values. * = unverified association.")
        root.title("VRC Eye")
        root.geometry("1360x900")
        root.minsize(1060, 720)
        root.configure(bg=self.BG)
        root.protocol("WM_DELETE_WINDOW", self.window_close)
        self.make_styles()
        self.build()
        self.query.trace_add("write", lambda *_: self.refresh())
        if demo:
            self.load_demo()
        else:
            self.start_monitor()
        self.root.after(150, self.pump)

    def make_styles(self):
        from ui_theme import apply_theme
        apply_theme(self, getattr(self, "presentation", None))

    def build(self):
        ttk = self.ttk
        from text_viewport import DesktopZoom
        self.text_zoom = DesktopZoom(self)
        outer = ttk.Frame(self.text_zoom.body(self.root), padding=(20, 16))
        outer.pack(fill="both", expand=True)
        # Reserve the footer before the expanding pages so it stays visible.
        self.build_footer = ttk.Frame(outer, padding=(0, 8, 0, 0))
        self.build_footer.pack(side="bottom", fill="x")
        self.build_label = ttk.Label(self.build_footer, text=f"VRC Eye · {BUILD_VERSION}", style="Small.TLabel")
        self.build_label.pack(side="right")
        self.header = ttk.Frame(outer)
        self.header.pack(fill="x")
        ttk.Label(self.header, text="VRC Eye", style="Brand.TLabel").pack(side="left")
        self.header_actions = ttk.Frame(self.header)
        self.header_actions.pack(side="right")
        from desktop_appearance import Backdrop
        self.backdrop=Backdrop(self,outer,self.header)
        from ui_preferences import Presentation
        self.backdrop.apply(getattr(self,'presentation',None) or Presentation())

        from companion_ui import Sidebar
        self.sidebar = Sidebar(self, outer)
        from account_header import AccountHeader
        self.account_header = AccountHeader(self, outer)
        self.account_header.frame.pack(fill="x", before=self.sidebar.frame, pady=(8, 0))
        from osc_app import OSCApplication
        self.osc_controller = OSCApplication(self, autostart=False)
        self.osc_service = self.osc_controller.service
        self.pages = ttk.Notebook(self.sidebar.primary)
        self.pages.pack(fill="both", expand=True, pady=(8, 0))
        self.avatar_page = ttk.Frame(self.pages, padding=(0, 12, 0, 0))
        self.world_page = ttk.Frame(self.pages, padding=(0, 12, 0, 0))
        self.pages.add(self.avatar_page, text="Avatars")
        self.pages.add(self.world_page, text="World")
        from world_view import WorldView
        self.world_view = WorldView(self, self.world_page)
        self.avatar_sections = ttk.Notebook(self.avatar_page)
        self.avatar_sections.pack(fill="both", expand=True)
        self.avatar_activity = ttk.Frame(self.avatar_sections)
        self.avatar_sections.add(self.avatar_activity, text="Activity")
        outer = self.avatar_activity

        tools = ttk.Frame(outer)
        tools.pack(fill="x", pady=(5, 5))
        ttk.Label(tools, text="Find", style="Muted.TLabel").pack(side="left", padx=(0, 8))
        ttk.Entry(tools, textvariable=self.query, width=25).pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.pause_button = ttk.Button(tools, text="Pause view", command=self.toggle_pause)
        self.pause_button.pack(side="left", padx=(0, 8))
        ttk.Button(tools, text="Show all", command=self.show_all).pack(side="left", padx=(0, 8))
        ttk.Button(tools, text="Export CSV", command=self.export).pack(side="left", padx=(0, 8))
        ttk.Button(tools, text="Clear view", command=self.clear_view).pack(side="left")

        options = ttk.Frame(outer)
        self.avatar_filter_row = options
        options.pack(fill="x", pady=(0, 10))
        for label, variable in (("First loads", self.show_first), ("Reloads", self.show_reload), ("Hide my avatar", self.hide_self)):
            ttk.Checkbutton(options, text=label, variable=variable, command=self.refresh).pack(side="left", padx=(0, 14))
        ttk.Checkbutton(options, text="Always on top", variable=self.on_top,
                        command=lambda: self.root.attributes("-topmost", self.on_top.get())).pack(side="left")
        ttk.Label(options, textvariable=self.count, style="Muted.TLabel").pack(side="right")
        footer_box = ttk.Frame(outer)
        footer_box.pack(side="bottom", fill="x", pady=(8, 0))

        table_frame = ttk.Frame(outer)
        table_frame.pack(fill="both", expand=True)
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        columns = ("time", "player", "platform", "trust", "before", "after", "performance", "visibility", "downloads", "created", "updated", "kind")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse", height=7)
        for column, title, width in (("time", "TIME", 92), ("player", "PLAYER", 155),
                                     ("platform", "PLAYER PLATFORM", 205),
                                     ("trust", "TRUST RANK (TAGS)", 170),
                                     ("performance", "PERFORMANCE (PC / iOS / ANDROID)", 440),
                                     ("before", "PREVIOUS AVATAR", 185), ("after", "NEW AVATAR", 185),
                                     ("visibility", "VISIBILITY (CACHED)", 165),
                                     ("downloads", "DOWNLOAD SIZES", 365),
                                     ("created", "UPLOADED / CREATED (UTC)", 190),
                                     ("updated", "LAST UPDATED (UTC)", 165), ("kind", "EVENT", 100)):
            self.table.heading(column, text=title, anchor="w")
            self.table.column(column, width=width, minwidth=70, anchor="w", stretch=column in ("player", "before", "after"))
        from color_vision import status_tags
        status_tags(self.table, self)
        self.table.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.table.configure(yscrollcommand=scroll.set)
        horizontal = ttk.Scrollbar(table_frame, orient="horizontal", command=self.table.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        self.table.configure(xscrollcommand=horizontal.set)
        self.table.bind("<<TreeviewSelect>>", self.select)
        self.table.bind("<Double-1>", self.open_row_avatar)
        self.table.bind('<Return>', lambda _: (self.open_selected_avatar(), 'break')[-1])
        self.table.bind("<Button-3>", self.show_row_menu)
        self.table.bind("<Shift-F10>", lambda event: self.show_row_menu(event, keyboard=True))
        self.table.bind("<KeyPress-Menu>", lambda event: self.show_row_menu(event, keyboard=True))
        self.empty = ttk.Label(table_frame, text="Waiting for avatar events…", style="Muted.TLabel", justify="center")
        self.empty.place(relx=0.5, rely=0.5, anchor="center")

        links = ttk.Frame(footer_box)
        links.pack(fill="x", pady=(2, 4))
        self.open_link_button = ttk.Button(links, text="Open on VRChat", style="Accent.TButton",
                                           command=self.open_selected_avatar, state="disabled")
        self.open_link_button.pack(side="left", padx=(0, 8))
        self.copy_link_button = ttk.Button(links, text="Copy link", command=self.copy_avatar_link, state="disabled")
        self.copy_link_button.pack(side="left", padx=(0, 8))
        self.player_button = ttk.Button(links, text="Player details…", command=self.show_player_platform, state="disabled")
        self.player_button.pack(side="left", padx=(0, 8))
        ttk.Button(links, text="Help", style="Quiet.TButton", command=self.help).pack(side="right")
        ttk.Label(footer_box, textvariable=self.link_status, style="Muted.TLabel", wraplength=940).pack(anchor="w", pady=(0, 3))
        from friendly_ui import Disclosure
        self.avatar_more = Disclosure(self, footer_box, "avatar details and file tools")
        details = self.avatar_more.body
        visibility_row = ttk.Frame(details)
        visibility_row.pack(fill="x", pady=(2, 4))
        self.refresh_visibility_button = ttk.Button(visibility_row, text="Refresh cached status", command=self.refresh_visibility)
        self.refresh_visibility_button.pack(side="left", padx=(0, 8))
        self.sizes_button = ttk.Button(visibility_row, text="Download sizes…", command=self.edit_download_sizes, state="disabled")
        self.sizes_button.pack(side="left", padx=(0, 8))
        self.set_link_button = ttk.Button(visibility_row, text="Set / change link…", command=self.choose_avatar_link, state="disabled")
        self.set_link_button.pack(side="left", padx=(0, 8))
        ttk.Button(visibility_row, text="Rescue cached avatar…", command=self.rescue_cached_avatar).pack(side="left")
        files_row = ttk.Frame(details)
        files_row.pack(fill="x", pady=(2, 4))
        ttk.Button(files_row, text="Save VRCA…", command=self.save_vrca).pack(side="left", padx=(0, 8))
        self.local_save_button = ttk.Button(files_row, text="Save local avatar…", command=self.save_local_avatar, state="disabled")
        self.local_save_button.pack(side="left", padx=(0, 8))
        ttk.Button(files_row, text="Archive public…", command=self.archive_public_avatar).pack(side="left", padx=(0, 8))
        ttk.Button(files_row, text="Diagnostics", command=self.diagnostics).pack(side="left", padx=(0, 8))
        ttk.Button(files_row, text="Demo", command=self.load_demo).pack(side="left")
        ttk.Label(details, textvariable=self.visibility_status, style="Muted.TLabel", wraplength=940).pack(anchor="w", pady=(4, 0))
        ttk.Label(details, textvariable=self.detail, wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=(4, 0))
        ttk.Label(details, textvariable=self.context, wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=(4, 0))
        ttk.Label(footer_box, text="Right-click an avatar row for all actions · Shift+F10 also opens the menu",
                  style="Small.TLabel").pack(anchor="w", pady=(2, 0))
        from avatar_creator_app import AvatarCreatorWorkspace
        self.avatar_creator = AvatarCreatorWorkspace(self, self.avatar_sections)
        from friendly_ui import FriendlyExperience
        self.experience = FriendlyExperience(self)
        self.root.after(50, self.osc_controller.start_observation)
        self.root.after(20, self.pump_osc)

    def pump_osc(self):
        controller = getattr(self, "osc_controller", None)
        if controller is not None and not controller.closed:
            controller.tick()
            self.root.after(20, self.pump_osc)

    def stop_worker(self):
        if getattr(self, "sidebar", None):
            self.sidebar.reset_log()
        self.world_roster = RosterSnapshot()
        world_view = getattr(self, "world_view", None)
        if world_view is not None:
            world_view.stop_feed()
        self.stop.set()
        # A new queue makes late results from a previous worker harmless.
        self.output = queue.Queue(maxsize=24)
        self.stop = threading.Event()

    def start_monitor(self):
        from tkinter import messagebox
        value = self.folder.get().strip()
        if not value:
            messagebox.showinfo("Choose a folder", "Choose the VRChat log folder first.")
            return
        folder = Path(os.path.expandvars(value)).expanduser()
        if folder.is_file() and folder.suffix.lower() != ".txt":
            messagebox.showerror("Choose a log", "Select an output_log_*.txt file or its folder.")
            return
        self.stop_worker()
        self.demo, self.paused = False, False
        self.pause_button.configure(text="Pause view")
        self.events.clear()
        self.avatar_links.clear()
        self.reset_download_data()
        self.reset_visibility()
        self.local_player, self.source = "", ""
        self.read_lines = self.matched = self.discarded = 0
        self.stats, self.batch = {}, None
        self.last_modified = 0
        self.detail.set("Select an event to see the full names and source.")
        self.state.set("Looking for VRChat logs…")
        self.folder.set(str(folder))
        self.worker = threading.Thread(target=monitor, args=(folder, self.output, self.stop), daemon=True)
        self.worker.start()
        self.refresh()

    def browse(self):
        from tkinter import filedialog
        folder = filedialog.askdirectory(title="Select the VRChat log folder", mustexist=True)
        if folder:
            self.folder.set(folder)
            self.start_monitor()

    def open_log(self):
        from tkinter import filedialog
        selected = filedialog.askopenfilename(title="Select a VRChat output log to follow",
                    filetypes=[("VRChat output logs", "output_log_*.txt"), ("Text logs", "*.txt")])
        if selected:
            self.folder.set(selected)
            self.start_monitor()

    def show_all(self):
        self.paused = False
        self.pause_button.configure(text="Pause view")
        self.show_first.set(True)
        self.show_reload.set(True)
        self.hide_self.set(False)
        self.query.set("")
        self.refresh()

    def diagnostics(self):
        window = self.tk.Toplevel(self.root)
        window.title("VRC Eye · Diagnostics")
        window.geometry("780x560")
        window.configure(bg=self.BG)
        batch = self.batch
        counts = {key: self.stats.get(key, 0) for key in (
            "lines", "headers", "avatar_mentions", "switch_candidates", "rejected_switches")}
        report = (
            f"VRC Eye {BUILD_VERSION} diagnostic report\n"
            f"Build timestamp: {BUILD_TIMESTAMP}\n"
            f"Demo mode: {self.demo}\n"
            f"Source log: {self.source or '(none)'}\n"
            f"File mode: {'specific file' if Path(self.folder.get()).is_file() else 'automatic folder'}\n"
            f"File encoding: {batch.encoding if batch else '(not read)'}\n"
            f"Bytes read / file size: {batch.offset if batch else 0} / {batch.size if batch else 0}\n"
            f"Pending partial-line characters: {batch.pending if batch else 0}\n"
            f"Complete lines: {counts['lines']}\n"
            f"Recognized log headers: {counts['headers']}\n"
            f"Lines mentioning avatar: {counts['avatar_mentions']}\n"
            f"Switch-shaped lines: {counts['switch_candidates']}\n"
            f"Rejected switch-shaped lines: {counts['rejected_switches']}\n"
            f"Parsed avatar events: {self.matched}\n"
            f"Retained / displayed events: {len(self.events)} / {len(self.visible)}\n"
            f"Oversized lines skipped: {self.discarded}\n"
            f"Local player identified: {bool(self.local_player)}\n"
            f"VRCX cache matching enabled: {self.vrcx_enabled.get()}\n"
            f"Filters: first={self.show_first.get()}, reload={self.show_reload.get()}, "
            f"hide_self={self.hide_self.get()}, search={bool(self.query.get())}, paused={self.paused}\n\n"
            + diagnosis(self.stats, self.matched, len(self.events), len(self.visible))
            + "\n\nIf no switch-shaped lines are present, reading other avatar-related log lines cannot "
            "reliably tell us which player changed avatars.\n\n"
            "This report contains counters and the log filename, not player names or log contents."
        )
        box = self.tk.Text(window_body(window), wrap="word", background=self.PANEL, foreground=self.TEXT,
                           borderwidth=0, padx=18, pady=18)
        box.pack(fill="both", expand=True, padx=14, pady=14)
        box.insert("1.0", report)
        box.configure(state="disabled")

        def copy_report():
            self.root.clipboard_clear()
            self.root.clipboard_append(report)
            copy_button.configure(text="Copied")

        copy_button = self.ttk.Button(window_body(window), text="Copy report", command=copy_report)
        copy_button.pack(pady=(0, 14))

    def pump(self):
        changed = False
        started = time.monotonic()
        while time.monotonic() - started < 0.03:
            try:
                message = self.output.get_nowait()
            except queue.Empty:
                break
            if message[0] == "waiting":
                if getattr(self, "player_sessions", None): self.player_sessions.set_health("WAITING")
                self.state.set("Waiting for logs — start VRChat or choose its log folder")
                self.activity.set("Looking for output_log_*.txt in the selected folder.")
            elif message[0] == "error":
                if getattr(self, "player_sessions", None): self.player_sessions.set_health("ERROR")
                self.state.set("Log access interrupted")
                self.activity.set(message[1])
            else:
                _, batch, events, local, room, stats = message
                if batch.reset:
                    self.events.clear()
                    self.avatar_links.clear()
                    self.reset_download_data()
                    self.reset_visibility()
                    self.read_lines = self.matched = self.discarded = 0
                    self.detail.set("A new log was opened. Showing events from this VRChat session.")
                    changed = True
                if getattr(self, "sidebar", None):
                    self.sidebar.ingest(batch, events)
                self.source, self.last_modified = batch.source, batch.modified
                if batch.roster is not None:
                    self.world_roster = batch.roster
                self.stats, self.batch = stats, batch
                creator = getattr(getattr(self, "world_view", None), "creator", None)
                if creator is not None:
                    try:
                        creator.ingest(batch)
                    except (OSError, ValueError, sqlite3.Error) as error:
                        creator.capture_enabled = False
                        creator.announce("Creator capture paused: " + str(error))
                self.read_lines += len(batch.lines)
                self.matched += len(events)
                self.discarded += batch.skipped
                self.events.extend(events)
                changed = changed or bool(events) or self.local_player != local
                self.local_player = local
                if batch.offset < batch.size:
                    self.state.set(f"Reading session history… {int(100 * batch.offset / max(1, batch.size))}%")
                else:
                    self.state.set("View paused — still collecting events" if self.paused else
                                   "Watching local log" if self.matched else
                                   "Reading log — no avatar events detected (see Diagnostics)")
                self.activity.set(f"{batch.source}  •  {self.read_lines:,} lines read  •  {self.matched:,} avatar entries")
                who = f"Local player: {local}" if local else "Local player not identified yet; your entries may be included."
                self.context.set((f"World: {room}  •  " if room else "") + who)
        if changed:
            self.dirty = True
        if self.dirty and not self.paused:
            self.refresh()
        avatar_creator = getattr(self, "avatar_creator", None)
        if avatar_creator is not None:
            avatar_creator.tick()
        self.root.after(150, self.pump)

    def filtered(self):
        query = self.query.get().strip().casefold()
        return [event for event in self.events
                if (self.show_first.get() or event.kind != "First seen")
                and (self.show_reload.get() or event.kind != "Reload")
                and not (self.hide_self.get() and self.local_player and event.player == self.local_player)
                and (not query or query in " ".join((event.player, event.previous, event.avatar, event.room)).casefold())]

    def refresh(self):
        if self.paused:
            self.dirty = True
            return
        previous_selection = self.table.selection()
        selected = None
        if previous_selection:
            index = int(previous_selection[0])
            if index < len(self.visible):
                selected = self.visible[index]
        position = self.table.yview()[0]
        self.visible = list(reversed(self.filtered()))
        children = self.table.get_children()
        if children:
            self.table.delete(*children)
        for index, event in enumerate(self.visible):
            tag = "changed" if event.kind == "Changed" else "uncertain" if event.kind == "Uncertain" else "muted"
            size_text, created, updated = event_downloads_and_dates(event, self.avatar_links, self.visibility, self.downloads)
            self.table.insert("", "end", iid=str(index), values=(event.timestamp.split(" ", 1)[-1],
                              event.player, platform_label(event, self.player_platforms), trust_label(event, self.player_platforms), event.previous or "—", event.avatar,
                              performance_label(event, self.avatar_links, self.avatar_performance),
                              event_visibility(event, self.avatar_links, self.visibility)[0], size_text, created, updated,
                              event.kind), tags=(tag,))
            if event == selected:
                self.table.selection_set(str(index))
        self.table.yview_moveto(position)
        if self.visible:
            self.empty.place_forget()
        else:
            text = "Avatar entries are hidden by filters.\nClick Show all to display them." if self.events else "No avatar entries detected yet.\nClick Diagnostics to check the log and parser."
            self.empty.configure(text=text)
            self.empty.place(relx=0.5, rely=0.5, anchor="center")
        switches = sum(event.kind == "Changed" for event in self.visible)
        self.count.set(f"{len(self.visible):,} shown · {switches:,} changes")
        keep = set(self.events) | set(self.visible)
        self.avatar_links = {event: link for event, link in self.avatar_links.items() if event in keep}
        linked_ids = {link[0] for link in self.avatar_links.values()}
        self.visibility = {reference: value for reference, value in self.visibility.items() if reference in linked_ids}
        self.avatar_performance = {reference: value for reference, value in self.avatar_performance.items() if reference in linked_ids}
        self.shader_reports = {reference: value for reference, value in self.shader_reports.items() if reference in linked_ids}
        self.downloads = {reference: value for reference, value in self.downloads.items() if reference in linked_ids}
        user_ids = {event.user_id for event in keep if event.user_id}
        user_ids.update(visit.user_id for visit in self.world_roster.visits if visit.user_id)
        self.player_platforms = {reference: value for reference, value in self.player_platforms.items() if reference in user_ids}
        self.update_link_controls()
        self.dirty = False

    def select(self, _event=None):
        self.update_link_controls()
        selection = self.table.selection()
        if not selection:
            return
        index = int(selection[0])
        if index >= len(self.visible):
            return
        event = self.visible[index]
        visibility, status_source, _checked = event_visibility(event, self.avatar_links, self.visibility)
        sizes, created, updated = event_downloads_and_dates(event, self.avatar_links, self.visibility, self.downloads)
        link = self.avatar_links.get(event)
        supplied = self.downloads.get(link[0]) if link else None
        size_source = f"{supplied.source}; selected builds may be outdated" if supplied else "no size data — open Download sizes to fetch or enter values"
        if not status_source:
            status_source = ("No cached status loaded; use Refresh details." if event in self.avatar_links else
                             "Select an avatar link to look up its status.")
        self.detail.set(f"{event.player}   |   {event.previous or '(not yet observed)'} → {event.avatar}\n"
                        f"{event.timestamp} · {event.kind} · {event.source}\n"
                        f"{platform_details(event, self.player_platforms)}\n"
                        f"Visibility: {visibility} · {status_source}\n"
                        f"Uploaded/created: {created} · Last updated: {updated} (UTC, cached)\n"
                        f"{sizes} · {size_source}"
                        + (f"\n{event.note}" if event.note else ""))

    def selected_event(self):
        selection = self.table.selection()
        if selection:
            index = int(selection[0])
            if 0 <= index < len(self.visible):
                return self.visible[index]
        return None

    def update_link_controls(self):
        event = self.selected_event()
        enabled = "normal" if event else "disabled"
        self.open_link_button.configure(state=enabled)
        self.set_link_button.configure(state=enabled)
        linked = self.avatar_links.get(event)
        self.copy_link_button.configure(state="normal" if linked else "disabled")
        self.sizes_button.configure(state="normal" if event and not self.demo else "disabled")
        self.local_save_button.configure(state="normal" if event and not self.demo else "disabled")
        self.player_button.configure(state=enabled)
        if linked:
            self.link_status.set(f"{linked[1]} · ready to open")
        elif event:
            self.link_status.set("Avatar ID unknown — choose a local match or paste a link.")
        else:
            self.link_status.set("Select an event to open its avatar page.")

    def open_row_avatar(self, event):
        row = self.table.identify_row(event.y)
        if row:
            self.table.selection_set(row)
            self.open_selected_avatar()

    def show_row_menu(self, pointer=None, *, keyboard=False):
        if keyboard:
            selection = self.table.selection()
            row = selection[0] if selection else ""
        else:
            row = self.table.identify_row(pointer.y) if pointer else ""
        if not row:
            return "break"
        self.table.selection_set(row)
        self.table.focus(row)
        self.select()
        event = self.selected_event()
        if event is None:
            return "break"
        link, generation = self.avatar_links.get(event), self.data_generation
        if self.row_menu is not None:
            self.row_menu.destroy()
        menu = self.tk.Menu(self.root, tearoff=False)
        self.row_menu = menu
        avatar = self.tk.Menu(menu, tearoff=False)
        menu.add_cascade(label="Avatar", menu=avatar)

        def action(callback):
            return lambda: self.invoke_row_action(event, link, generation, callback)

        active = "disabled" if self.demo else "normal"
        avatar.add_command(label="Download VRCA…", command=action(self.save_vrca), state=active)
        avatar.add_command(label="Save local avatar…", command=action(self.save_local_avatar), state=active)
        avatar.add_command(label="Download sizes…", command=action(self.edit_download_sizes), state=active)
        avatar.add_command(label="Rescue cached avatar…", command=action(self.rescue_cached_avatar), state=active)
        avatar.add_command(label="Archive public avatar…", command=action(self.archive_public_avatar), state=active)
        avatar.add_command(label="Performance & Shader Watch…", command=action(self.inspect_avatar), state=active)
        avatar.add_separator()
        avatar.add_command(label="Open on VRChat", command=action(self.open_selected_avatar))
        avatar.add_command(label="Copy avatar link", command=action(self.copy_avatar_link), state="normal" if link else "disabled")
        avatar.add_command(label="Set / change link…", command=action(self.choose_avatar_link))
        menu.add_command(label="Player details…", command=action(self.show_player_platform))
        if keyboard:
            self.table.see(row)
            bounds = self.table.bbox(row)
            x = self.table.winfo_rootx() + 30
            y = self.table.winfo_rooty() + (bounds[1] + bounds[3] if bounds else 30)
        else:
            x, y = pointer.x_root, pointer.y_root
        try:
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()
        return "break"

    def invoke_row_action(self, event, link, generation, callback):
        """A live refresh may change row indices while a menu remains open."""
        if not self.event_context_current(event, link, generation) or event not in self.visible:
            from tkinter import messagebox
            messagebox.showinfo("Row changed", "The selected row or avatar changed. Reopen the menu on the row you want.", parent=self.root)
            return
        row = str(self.visible.index(event))
        self.table.selection_set(row)
        self.table.focus(row)
        self.select()
        callback()

    def inspect_avatar(self):
        from inspection_dialog import show_inspection_dialog
        event = self.selected_event()
        if event is None or self.demo:
            return
        if event not in self.avatar_links:
            self.choose_avatar_link(on_selected=self.inspect_avatar)
            return
        show_inspection_dialog(self, event)

    def remember_performance(self, event, record, *, link, generation):
        if not self.event_context_current(event, link, generation) or record.avatar_id != link[0]:
            raise ValueError("The row, avatar ID or session changed. Reopen the viewer.")
        self.avatar_performance[record.avatar_id] = record
        self.refresh_visibility_cells()

    def remember_shader_report(self, event, report, *, link, generation):
        if not self.event_context_current(event, link, generation) or report.avatar_id != link[0]:
            raise ValueError("The shader report does not match the current avatar selection.")
        self.shader_reports.setdefault(report.avatar_id, {})[report.platform] = report

    def show_player_platform(self):
        from player_dialog import show_player_dialog
        event = self.selected_event()
        if event:
            show_player_dialog(self, event)

    def remember_player_platform(self, event, record, *, generation):
        if (self.demo or generation != self.data_generation or
                (event not in self.events and event not in self.visible)):
            raise ValueError("The log session or event changed. Reopen Player details for the current row.")
        reference = parse_user_id(event.user_id)
        if record is None:
            self.player_platforms.pop(reference, None)
        elif record.user_id != reference:
            raise ValueError("The imported user ID does not match this player's ID in the log.")
        else:
            self.player_platforms[reference] = record
        self.refresh_player_cells()

    def refresh_player_cells(self):
        for index, event in enumerate(self.visible):
            if self.table.exists(str(index)):
                self.table.set(str(index), "platform", platform_label(event, self.player_platforms))
                self.table.set(str(index), "trust", trust_label(event, self.player_platforms))
        if self.selected_event():
            self.select()

    def reset_player_data(self):
        self.player_platforms.clear()

    def open_selected_avatar(self):
        event = self.selected_event()
        if not event:
            return
        linked = self.avatar_links.get(event)
        if linked:
            self.launch_avatar_page(linked[0])
        else:
            self.choose_avatar_link(open_after=True)

    def launch_avatar_page(self, reference):
        from tkinter import messagebox
        import webbrowser
        try:
            opened = open_avatar_page(reference)
        except (OSError, ValueError, webbrowser.Error):
            opened = False
        if not opened:
            self.root.clipboard_clear()
            self.root.clipboard_append(avatar_url(reference))
            messagebox.showinfo("Avatar link copied", "The browser could not be opened. The avatar link was copied for you to paste into your browser.")

    def copy_avatar_link(self):
        linked = self.avatar_links.get(self.selected_event())
        if linked:
            self.root.clipboard_clear()
            self.root.clipboard_append(avatar_url(linked[0]))
            self.link_status.set("Avatar link copied.")

    def save_vrca(self):
        from vrca_dialog import show_vrca_dialog
        event = self.selected_event() if not self.demo else None
        link = self.avatar_links.get(event)
        if event and self.api and self.api.authenticated and (not link or link[0] not in self.asset_exports):
            self.prepare_avatar_data(event, lambda: show_vrca_dialog(self, self.avatar_links[event][0], event=event))
            return
        show_vrca_dialog(self, link[0] if link else "", event=event)

    def configure_api(self):
        from online_dialog import show_connection_dialog
        show_connection_dialog(self)

    def search_avatars(self):
        from search_dialog import show_search_dialog
        show_search_dialog(self)

    def rescue_cached_avatar(self):
        from cache_rescue import show_rescue_dialog
        event = self.selected_event() if not self.demo else None
        link = self.avatar_links.get(event)
        show_rescue_dialog(self, event=event, avatar_id=link[0] if link else "")

    def archive_public_avatar(self):
        from public_archive import show_public_archive
        event = self.selected_event() if not self.demo else None
        link = self.avatar_links.get(event)
        show_public_archive(self, link[0] if link else "")

    def show_rangefinder(self):
        from range_dialog import show_range_dialog
        show_range_dialog(self)

    def remember_search_avatar(self, result, *, client, generation):
        if (client is None or client is not self.api or not client.authenticated or generation != self.data_generation):
            raise ValueError("The connection or log session changed. Run the search again.")
        reference = parse_avatar_reference(result.metadata.avatar_id)
        if result.export is not None:
            if result.export.avatar_id != reference:
                raise ValueError("The file metadata does not match this avatar ID.")
            self.remember_avatar_export(result.export, generation=generation)
            self.online_avatar_ids.add(reference)
        self.online_visibility[reference] = result.metadata
        self.visibility[reference] = result.metadata
        if result.performance:
            self.avatar_performance[reference] = result.performance
        sizes = self.downloads.get(reference)
        if sizes and sizes_are_stale(sizes, result.metadata.updated_at):
            self.downloads[reference] = replace(sizes, stale=True)
        self.refresh_visibility_cells()

    def open_search_download(self, item, *, client, generation, parent=None):
        """A search result is independent of the current log-table selection."""
        from online_dialog import lookup_online
        from vrca_dialog import show_vrca_dialog
        reference = parse_avatar_reference(item.avatar_id)

        def open_result(result):
            if result.metadata.avatar_id != reference:
                raise ValueError("The lookup returned a different avatar ID.")
            self.remember_search_avatar(result, client=client, generation=generation)
            if result.export is None:
                raise ValueError(result.file_error)
            show_vrca_dialog(self, reference)

        if client is None or client is not self.api or not client.authenticated or generation != self.data_generation:
            raise ValueError("The connection or session changed. Run the search again before downloading.")
        if item.lookup is not None and item.lookup.export is not None:
            open_result(item.lookup)
        else:
            lookup_online(self, "avatar", reference, open_result, parent=parent)

    def fetch_standalone_avatar(self, reference, on_ready, *, parent=None, on_fallback=None):
        from online_dialog import lookup_online, show_connection_dialog
        if not self.api or not self.api.authenticated:
            show_connection_dialog(self, lambda: self.fetch_standalone_avatar(reference, on_ready,
                parent=parent, on_fallback=on_fallback))
            return
        client, generation = self.api, self.data_generation

        def apply(result):
            if result.metadata.avatar_id != reference:
                raise ValueError("The lookup returned a different avatar ID.")
            self.remember_search_avatar(result, client=client, generation=generation)
            if result.export is None:
                raise ValueError(result.file_error)
            on_ready()

        lookup_online(self, "avatar", reference, apply, parent=parent, on_fallback=on_fallback)

    def set_api_client(self, client):
        if self.api is client:
            return
        if self.api:
            self.api.close()
            self.data_generation += 1
        for stop in tuple(self.transfer_stops):
            stop.set()
        self.api = client
        if getattr(self, "sidebar", None):
            self.sidebar.account_changed()
        for reference in self.online_avatar_ids:
            self.asset_exports.pop(reference, None)
            self.asset_selections.pop(reference, None)
        self.online_avatar_ids.clear()
        self.online_visibility.clear()
        self.visibility = {key: value for key, value in self.visibility.items() if value.source != "VRChat API"}
        self.player_platforms = {key: value for key, value in self.player_platforms.items() if value.origin != "VRChat API"}
        self.avatar_performance = {key: value for key, value in self.avatar_performance.items() if value.source != "VRChat API"}
        self.refresh_visibility_cells()
        self.refresh_player_cells()

        header = getattr(self, "account_header", None)
        if header is not None:
            header.tick()

    def refresh_details(self):
        event = self.selected_event()
        if event and not self.demo and self.api and self.api.authenticated:
            if event not in self.avatar_links:
                self.choose_avatar_link(on_selected=lambda: self.fetch_avatar_online(event))
            else:
                self.fetch_avatar_online(event)
        else:
            self.refresh_visibility()

    def apply_online_avatar(self, event, result, *, link, generation, expected_export):
        if (not self.event_context_current(event, link, generation) or
                self.asset_exports.get(link[0]) is not expected_export):
            raise ValueError("The row, session, or loaded avatar files changed. Reopen the lookup.")
        if result.metadata.avatar_id != link[0]:
            raise ValueError("The returned avatar ID does not match this row.")
        if result.export is not None:
            self.remember_avatar_export(result.export, event=event, link=link, generation=generation)
            self.online_avatar_ids.add(link[0])
        self.online_visibility[link[0]] = result.metadata
        self.visibility[link[0]] = result.metadata
        if result.performance:
            self.avatar_performance[link[0]] = result.performance
        sizes = self.downloads.get(link[0])
        if sizes_are_stale(sizes, result.metadata.updated_at) and sizes:
            self.downloads[link[0]] = replace(sizes, stale=True)
        self.refresh_visibility_cells()
        self.visibility_status.set("Avatar details read from VRChat. " + (result.file_error or "File URLs are ready; select the build you need."))

    def fetch_avatar_online(self, event, on_ready=None, *, parent=None, on_fallback=None):
        from online_dialog import lookup_online
        link = self.avatar_links.get(event)
        if not link:
            return
        generation = self.data_generation
        expected_export = self.asset_exports.get(link[0])

        def apply(result):
            self.apply_online_avatar(event, result, link=link, generation=generation, expected_export=expected_export)
            if result.export is None and on_ready:
                raise ValueError(result.file_error)
            if on_ready:
                on_ready()

        lookup_online(self, "avatar", link[0], apply, parent=parent, on_fallback=on_fallback)

    def prepare_avatar_data(self, event, on_ready):
        """Normal workflow: known ID -> direct lookup; imports remain explicit fallback."""
        if event not in self.avatar_links:
            if self.api and self.api.authenticated:
                self.choose_avatar_link(on_selected=lambda: self.prepare_avatar_data(event, on_ready))
            elif self.load_avatar_export(event):
                on_ready()
            return
        if self.asset_exports.get(self.avatar_links[event][0]):
            on_ready()
            return

        def fallback():
            if self.load_avatar_export(event):
                on_ready()

        if self.api and self.api.authenticated:
            self.fetch_avatar_online(event, on_ready, on_fallback=fallback)
        else:
            fallback()

    def reset_download_data(self):
        self.data_generation += 1
        self.downloads.clear()
        self.avatar_performance.clear()
        self.shader_reports.clear()
        self.asset_exports.clear()
        self.asset_selections.clear()
        self.online_visibility.clear()
        self.online_avatar_ids.clear()
        self.reset_player_data()

    def event_context_current(self, event, link, generation):
        return self.data_generation == generation and (event is None or
            ((event in self.events or event in self.visible) and self.avatar_links.get(event) == link))

    def remember_avatar_export(self, export, *, event=None, link=None, generation):
        from download_sizes import default_selections
        if not self.event_context_current(event, link, generation):
            raise ValueError("The event or avatar selection changed. Reopen this action for the current row.")
        if link and link[0] != export.avatar_id:
            raise ValueError("The JSON avatar ID does not match this event's selected avatar.")
        if event is not None and not link:
            self.avatar_links[event] = (export.avatar_id, "Imported avatar JSON (unverified)")
        previous = self.asset_exports.get(export.avatar_id)
        if previous and previous.choices != export.choices and export.avatar_id in self.downloads:
            self.downloads[export.avatar_id] = replace(self.downloads[export.avatar_id], stale=True)
        self.asset_exports[export.avatar_id] = export
        if export.performance:
            self.avatar_performance[export.avatar_id] = export.performance
        self.online_avatar_ids.discard(export.avatar_id)
        self.asset_selections[export.avatar_id] = default_selections(export, self.asset_selections.get(export.avatar_id))
        self.refresh_visibility_cells()
        self.update_link_controls()

    def load_avatar_export(self, event, parent=None):
        from tkinter import filedialog, messagebox
        from vrca_files import VRCAError, parse_avatar_assets
        link = self.avatar_links.get(event)
        generation = self.data_generation
        path = filedialog.askopenfilename(parent=parent or self.root,
            title="Select avatar JSON for this event (the log has no file ID)",
            filetypes=[("Avatar JSON", "*.json"), ("All files", "*")])
        if not path:
            return None
        try:
            with Path(path).open("rb") as stream:
                data = stream.read(MAX_JSON_BYTES + 1)
            if len(data) > MAX_JSON_BYTES:
                raise ValueError("Avatar JSON is too large (maximum 2 MiB).")
            export = parse_avatar_assets(data.decode("utf-8-sig"), link[0] if link else "")
            self.remember_avatar_export(export, event=event, link=link, generation=generation)
        except (OSError, UnicodeError, ValueError, VRCAError) as error:
            messagebox.showerror("Could not load avatar JSON", str(error), parent=parent or self.root)
            return None
        self.refresh_visibility()
        return export

    def save_local_avatar(self):
        event = self.selected_event()
        if event and not self.demo:
            self.prepare_avatar_data(event, lambda: self.open_local_avatar(event))

    def open_local_avatar(self, event):
        from cache_dialog import show_cache_dialog
        from vrca_dialog import show_vrca_dialog
        if not event or self.demo:
            return
        link = self.avatar_links.get(event)
        export = self.asset_exports.get(link[0]) if link else None
        if not export:
            export = self.load_avatar_export(event)
        if not export:
            return
        choice = self.asset_selections.get(export.avatar_id, {}).get("pc")
        if choice and choice in export.choices:
            show_cache_dialog(self, choice.url, export.avatar_id)
        else:
            show_vrca_dialog(self, export.avatar_id, event=event, prefer_local=True)

    def record_asset_download(self, export, choice, amount, *, event, link, generation):
        from download_sizes import choice_description, merge_size_readings
        if (not self.event_context_current(event, link, generation) or
                self.asset_exports.get(export.avatar_id) is not export or choice not in export.choices):
            return False
        key = next(key for key, title, _native in PLATFORMS if title == choice.platform)
        metadata = self.visibility.get(export.avatar_id)
        self.downloads[export.avatar_id] = merge_size_readings(export.avatar_id, self.downloads.get(export.avatar_id),
            {key: (amount, "Completed download · " + choice_description(choice))}, metadata.updated_at if metadata else "")
        self.refresh_visibility_cells()
        return True

    def edit_download_sizes(self):
        from size_dialog import show_sizes_dialog
        event = self.selected_event()
        if not event or self.demo:
            return
        if self.api and self.api.authenticated:
            self.prepare_avatar_data(event, lambda: show_sizes_dialog(self, event))
            return
        if event not in self.avatar_links and not self.load_avatar_export(event):
            return
        show_sizes_dialog(self, event)

    def reset_visibility(self):
        # Discard a lookup completing after a log/settings change or clear.
        self.visibility_request += 1
        self.visibility.clear()
        self.visibility.update(self.online_visibility)
        self.visibility_status.set("Select an avatar link for cached dates/status. Sizes: use Download sizes to fetch or enter values. * = unverified association.")

    def refresh_visibility_cells(self):
        # An explicit status refresh also works on the paused, frozen event list.
        for index, event in enumerate(self.visible):
            if self.table.exists(str(index)):
                self.table.set(str(index), "performance", performance_label(event, self.avatar_links, self.avatar_performance))
                self.table.set(str(index), "visibility", event_visibility(event, self.avatar_links, self.visibility)[0])
                sizes, created, updated = event_downloads_and_dates(event, self.avatar_links, self.visibility, self.downloads)
                for column, value in (("downloads", sizes), ("created", created), ("updated", updated)):
                    self.table.set(str(index), column, value)
        if self.selected_event():
            self.select()

    def refresh_visibility(self):
        self.reset_visibility()
        request = self.visibility_request
        self.refresh_visibility_cells()
        if self.demo:
            self.visibility_status.set("Demo events have no real avatar IDs, so dates, status, and sizes are Unknown.")
            return
        if not self.vrcx_enabled.get():
            self.visibility_status.set("Enable avatar-cache access in Advanced → VRCX Companion to read cached dates and public/private status. Download sizes are handled separately.")
            return
        references = {link[0] for link in self.avatar_links.values()}
        if not references:
            self.visibility_status.set("Select a row, then Set / change link… to choose an avatar. Details require a selected ID.")
            return
        location = Path(os.path.expandvars(self.vrcx_path.get())).expanduser()
        self.visibility_status.set(f"Reading cached dates and visibility for {len(references):,} selected avatar IDs…")
        results = queue.Queue(maxsize=1)

        def lookup():
            try:
                results.put((read_vrcx_visibility(location, references), ""))
            except (VRCXError, ValueError) as error:
                results.put(({}, str(error)))

        def done():
            if request != self.visibility_request:
                return
            try:
                found, error = results.get_nowait()
            except queue.Empty:
                self.root.after(100, done)
                return
            linked_ids = {link[0] for link in self.avatar_links.values()}
            self.visibility = {reference: value for reference, value in found.items() if reference in linked_ids}
            self.visibility.update({reference: value for reference, value in self.online_visibility.items() if reference in linked_ids})
            for reference, sizes in self.downloads.items():
                metadata = self.visibility.get(reference)
                if sizes_are_stale(sizes, metadata.updated_at if metadata else ""):
                    self.downloads[reference] = replace(sizes, stale=True)
            self.refresh_visibility_cells()
            if error:
                self.visibility_status.set("Cached details unavailable. " + error)
            else:
                known = sum(record.visibility != "Unknown" for record in self.visibility.values())
                self.visibility_status.set(f"Cached details read; {known:,} / {len(self.visibility):,} IDs have visibility. "
                                           "Sizes: use Download sizes to fetch or enter values. * = unverified match. Cache may be outdated.")

        threading.Thread(target=lookup, daemon=True).start()
        self.root.after(100, done)

    def configure_vrcx(self):
        """Legacy callers share the VRCX Companion navigation destination."""
        self.sidebar.show("VRCX Companion")

    def choose_avatar_link(self, open_after=False, on_selected=None):
        from tkinter import messagebox
        event = self.selected_event()
        if not event:
            return
        generation = self.data_generation
        window = self.tk.Toplevel(self.root)
        window.title("Choose an avatar page")
        window.geometry("1120x620")
        window.configure(bg=self.BG)
        frame = self.ttk.Frame(window_body(window), padding=20)
        frame.pack(fill="both", expand=True)
        self.ttk.Label(frame, text=event.avatar, font='EyeAvatarFont', wraplength=730).pack(anchor="w")
        self.ttk.Label(frame, text="The log provides a name, not a verified avatar ID. Paste a known page link or choose a possible local match.",
                       style="Muted.TLabel", wraplength=730).pack(anchor="w", pady=(8, 12))
        current = self.avatar_links.get(event)
        value = self.tk.StringVar(value=avatar_url(current[0]) if current else "")
        entry = self.ttk.Entry(frame, textvariable=value)
        entry.pack(fill="x")
        self.ttk.Label(frame, text="https://vrchat.com/home/avatar/avtr_…  or a complete avtr_… ID",
                       style="Muted.TLabel").pack(anchor="w", pady=(5, 8))

        def remember(reference, source):
            if generation != self.data_generation or (event not in self.events and event not in self.visible):
                messagebox.showinfo("Row changed", "The session changed. Reopen the avatar chooser.", parent=window)
                return
            self.avatar_links[event] = (parse_avatar_reference(reference), source)
            window.destroy()
            self.update_link_controls()
            self.refresh_visibility()
            if open_after:
                self.launch_avatar_page(reference)
            if on_selected:
                on_selected()

        def use_pasted():
            try:
                reference = parse_avatar_reference(value.get())
            except ValueError as error:
                messagebox.showerror("Invalid avatar link", str(error), parent=window)
                return
            remember(reference, "Pasted link")

        self.ttk.Button(frame, text="Use link and open" if open_after else "Save link for this event",
                         style="Accent.TButton", command=use_pasted).pack(anchor="w", pady=(0, 16))
        entry.bind("<Return>", lambda _event: use_pasted())
        status = self.tk.StringVar(value="Checking VRCX and locally saved avatars…")
        self.ttk.Label(frame, textvariable=status, style="Muted.TLabel", wraplength=960).pack(anchor="w", pady=(0, 6))
        choices_frame = self.ttk.Frame(frame)
        choices_frame.pack(fill="both", expand=True)
        choices_frame.rowconfigure(0, weight=1)
        choices_frame.columnconfigure(0, weight=1)
        choices = self.ttk.Treeview(choices_frame, columns=("name", "author", "visibility", "source", "id"),
                                    show="headings", height=5, selectmode="browse")
        choices.heading("name", text="POSSIBLE NAME MATCH")
        choices.heading("author", text="CREATOR")
        choices.heading("visibility", text="VISIBILITY (CACHED)")
        choices.heading("source", text="SOURCE")
        choices.heading("id", text="AVATAR ID")
        choices.column("name", width=190)
        choices.column("author", width=150)
        choices.column("visibility", width=160, stretch=False)
        choices.column("source", width=165)
        choices.column("id", width=425)
        choices.grid(row=0, column=0, sticky="nsew")
        vertical = self.ttk.Scrollbar(choices_frame, orient="vertical", command=choices.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = self.ttk.Scrollbar(choices_frame, orient="horizontal", command=choices.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        choices.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        candidates = []

        def use_candidate():
            selection = choices.selection()
            if selection:
                candidate = candidates[int(selection[0])]
                remember(candidate.avatar_id, candidate.source + " name match (unverified)")

        pick = self.ttk.Button(frame, text="Use selected match and open" if open_after else "Use selected match",
                                command=use_candidate, state="disabled")
        pick.pack(anchor="w", pady=(10, 4))
        choices.bind("<<TreeviewSelect>>", lambda _: pick.configure(state="normal" if choices.selection() else "disabled"))
        self.ttk.Label(frame, text="Different avatars can share a name. Links apply only to this event and are included in CSV exports.",
                       style="Muted.TLabel", wraplength=730).pack(anchor="w", pady=(4, 0))
        result_queue = queue.Queue(maxsize=1)
        location = Path(os.path.expandvars(self.folder.get())).expanduser()
        is_demo = self.demo
        use_vrcx = self.vrcx_enabled.get() and not is_demo
        vrcx_location = Path(os.path.expandvars(self.vrcx_path.get())).expanduser()

        def lookup():
            local = find_local_candidates(location, event.avatar) if not is_demo else []
            vrcx_matches = []
            information = "VRCX matching is disabled." if not is_demo else "Demo mode: no real avatar lookup."
            if use_vrcx:
                try:
                    result = find_vrcx_candidates(vrcx_location, event.avatar)
                    vrcx_matches = result.candidates
                    information = f"VRCX: {len(vrcx_matches)} name matches."
                    if result.truncated:
                        information += " Only the first 200 are shown; paste an ID to select another."
                    elif not vrcx_matches:
                        information += " This name may not be in VRCX’s saved avatar list."
                except VRCXError as error:
                    information = str(error)
            result_queue.put((merge_candidates(vrcx_matches, local), information))

        def finish_lookup():
            if not window.winfo_exists():
                return
            try:
                found, information = result_queue.get_nowait()
            except queue.Empty:
                self.root.after(100, finish_lookup)
                return
            candidates.extend(found)
            for index, candidate in enumerate(found):
                choices.insert("", "end", iid=str(index), values=(candidate.name, candidate.author or "—",
                               release_status_label(candidate.release_status), candidate.source, candidate.avatar_id))
            summary = f"{len(found)} possible matches. Choose the avatar you want to view." if found else "No match found. Paste an avatar link or ID above."
            status.set(summary + "\n" + information)

        threading.Thread(target=lookup, daemon=True).start()
        self.root.after(100, finish_lookup)
        entry.focus_set()

    def toggle_pause(self):
        self.paused = not self.paused
        self.pause_button.configure(text="Resume view" if self.paused else "Pause view")
        self.state.set("DEMO — sample data" if self.demo else "View paused — still collecting events" if self.paused else "Watching local log")
        if not self.paused:
            self.refresh()

    def clear_view(self):
        self.events.clear()
        self.avatar_links.clear()
        self.reset_download_data()
        self.reset_visibility()
        self.detail.set("View cleared. Previous-avatar tracking continues for new events.")
        self.paused = False
        self.pause_button.configure(text="Pause view")
        self.refresh()

    def export(self):
        from tkinter import filedialog, messagebox
        events = list(reversed(self.visible))
        if not events:
            messagebox.showinfo("Nothing to export", "No visible events. Adjust the filters or wait for avatar entries.")
            return
        path = filedialog.asksaveasfilename(title="Export visible avatar events", defaultextension=".csv",
                                           initialfile="avatar-changes.csv", filetypes=[("CSV", "*.csv")])
        if path:
            try:
                write_csv(Path(path), events, self.avatar_links, self.visibility, self.downloads, self.player_platforms, self.avatar_performance)
                self.detail.set(f"Exported {len(events):,} visible events to {path}")
            except OSError as error:
                messagebox.showerror("Export failed", str(error))

    def load_demo(self):
        coordinator=getattr(self,'vrcx_companion',None)
        if coordinator:coordinator.set_environment(True)
        peers=getattr(self,'peer_service',None)
        if peers:peers.set_environment(True, 'Demo')
        self.stop_worker()
        self.demo, self.paused = True, False
        self.pause_button.configure(text="Pause view")
        self.events.clear()
        self.avatar_links.clear()
        self.reset_download_data()
        self.reset_visibility()
        self.stats, self.batch = {}, None
        self.source = "sample-data.txt"
        self.query.set("")
        self.show_first.set(True)
        self.show_reload.set(False)
        parser = SessionParser("sample-data.txt")
        start = datetime.now() - timedelta(minutes=3)
        messages = [
            'Entering Room: Sample Observatory',
            'Initialized PlayerAPI "You (demo)" is local',
            'OnPlayerJoined Nova', 'OnPlayerJoined Comet', 'OnPlayerJoined Pixel',
            'Switching Nova to avatar Moon Rabbit',
            'Switching Comet to avatar Copper Robot',
            'Switching Pixel to avatar Cloud Fox',
            'Switching Nova to avatar Star Pilot',
            'Switching Comet to avatar Paper Dragon',
            'Switching You (demo) to avatar Sample Avatar',
            'Switching Pixel to avatar Lantern Cat',
            'Switching Nova to avatar Star Pilot',
        ]
        if getattr(self, "sidebar", None):
            self.sidebar.log.add_lines([f"{start:%Y.%m.%d %H:%M:%S} Log - {m}" for m in messages], "sample-data.txt", True)
            self.sidebar.account_changed()
        for index, message in enumerate(messages):
            stamp = (start + timedelta(seconds=13 * index)).strftime("%Y.%m.%d %H:%M:%S")
            event = parser.feed(f"{stamp} Log        -  [Behaviour] {message}")
            if event:
                self.events.append(event)
        self.matched = len(self.events)
        self.read_lines = len(messages)
        self.stats = {"lines": len(messages), "headers": len(messages),
                      "avatar_mentions": self.matched, "switch_candidates": self.matched,
                      "rejected_switches": 0}
        self.local_player = parser.local_player
        self.world_roster = parser.world_roster.snapshot()
        self.state.set("DEMO — sample data")
        self.activity.set("These names and events are examples. Click Watch logs to monitor your own session.")
        self.context.set("World: Sample Observatory  •  Local player: You (demo)")
        self.detail.set("Changed = a different name observed. First seen = no previous avatar known. Reload = same name again.")
        self.refresh()

    def help(self):
        from tkinter import messagebox
        messagebox.showinfo("VRC Eye setup", (
            "Use the sidebar for Primary, Feed, Game Log, Search, Favorites, Social and Wellness, plus Performance & Security under Advanced. Read COMPANION_SETUP.md for the new pages. "
            "Watch your VRChat log folder or choose Open log. If the avatar feed is empty, use Show all and Diagnostics. "
            "Only the log's named avatar-switch entries can appear.\n\n"
            "World → Players shows observed joins/leaves, the current world, counts, and visit times without a map. "
            "Refresh world / friends connects for capacity and the signed-in account's friend count. "
            "Refresh selected player… uses the logged user ID for platform and trust snapshots. "
            "Remote FPS, player ping, and exact Android device models are unavailable. Read WORLD_PLAYERS_SETUP.md.\n\n"
            "Select a player for a separate tabbed profile window with visible social/collection data, local notes, images and filtered JSON. "
            "My account… edits your own status, joinability/privacy preferences and owned-avatar metadata after review. "
            "Whisper uses a private pairing invitation and a shared relay; the relay server is included. "
            "Read PLAYER_PROFILE_SETUP.md and WHISPER_SETUP.md. Start.cmd automatically prepares packages for optional whispers and expanded image previews; reopen it online to retry missing dependencies.\n\n"
            "Use World → Map for overhead maps, saved waypoints, and player markers in supported worlds. "
            "Open Map setup… there for the included Udon world helper and calibration instructions. "
            "The app cannot automatically map or locate every player in arbitrary worlds.\n\n"
            "World → World backups… downloads VRCW builds or recovers matching cache entries. "
            "Sign in to verify the world's author. Your own worlds can be backed up unchanged or decrypted with your key; "
            "a friend's world requires verified friendship, their supplied key, and your confirmation of permission. "
            "Read WORLD_BACKUP_SETUP.md for the supported encryption format and recovery package installation.\n\n"
            "Right-click Avatar → Performance & Shader Watch… for reported platform ratings and local Unity shader reports. "
            "Player details… includes public trust-tag ranks and explains why Blocked me is unavailable.\n\n"
            "World → Rangefinder… shows pointing distance in feet using OSC from your configured avatar. "
            "Read RANGEFINDER_SETUP.md and upload the avatar setup first. No API sign-in or VRCX is needed. "
            "It measures the player collider you point at and does not identify or track usernames. "
            "Start listening, enable OSC in VRChat, and point at a player and away to initialize.\n\n"
            "VRChat connection… enables direct metadata lookup with an optional login. "
            "Use your VRChat username/password and the verification method requested by VRChat. "
            "Remember username and Remember password are independent; saved passwords use Windows Credential Manager. "
            "Press Enter to sign in or verify. Codes/cookies stay in memory; credentials are never taken from VRCX or your browser. "
            "Disconnect discards this app's session. API access may fail or change.\n\n"
            "Search → Search avatars… browses your uploads, favorites, or featured avatars. Advanced → VRCX Companion contains local-cache search and settings. "
            "Enter a name/creator, or a full avatar ID/page link for exact lookup. Online name filters cover loaded pages only; "
            "use Load more for later pages. Global avatar-name search is not available. Select a result, then Download VRCA… "
            "to choose its build and save directly, without an event row or JSON import.\n\n"
            "Select a row and assign its avatar link or choose a possible local/VRCX name match. "
            "Names alone do not establish avatar IDs. Right-click → Avatar → Download VRCA… uses direct "
            "lookup when connected; JSON import is a backup. Choose the build and an accessible file. "
            "Save local avatar uses the same metadata to locate its cached PC file.\n\n"
            "Archive public… checks an exact avatar ID's public status and file metadata through your normal connection. "
            "Choose a build, then Download public VRCA or Find cached build. No JSON file or key is required to save "
            "unchanged bytes. File access still applies, and any encryption remains unchanged.\n\n"
            "Rescue cached avatar… opens a local cache browser without sign-in or JSON. An optional exact-ID lookup "
            "can match a known build. Save selected keeps the original bytes; Decrypt with key… accepts a matching "
            "hexadecimal/Base64 key through a masked paste field. Start.cmd prepares the packages for that optional step automatically; reopen it online if setup was unavailable. "
            "A VRCA copy does not reconstruct the original Unity project.\n\n"
            "Download sizes… fetches file metadata directly when connected, then Fetch sizes reads file headers. "
            "PC, iOS, and Android stay together. Missing totals remain Unknown; manual sizes and analysis JSON are available. "
            "Cache size is not download size or VRAM. Saved files are not repaired or installed.\n\n"
            "Refresh details uses VRChat for the selected avatar when connected, otherwise the VRCX cache. "
            "Dates/status are snapshots; an asterisk marks an unverified event-to-avatar link. "
            "Creation is the avatar record date, not a platform upload date.\n\n"
            "Player details… looks up the exact user ID from the join log. It opens an online lookup when connected; "
            "user JSON import/paste is a backup. PC/Android/iOS are snapshots, and last_platform is labeled last known. "
            "Neither the API nor an import proves the device at an old event's timestamp. "
            "Android includes standalone headsets and phones; PC includes VR and desktop.\n\n"
            "Metadata requests are spaced at least 60 seconds apart; recent same-ID results are reused with their original time. "
            "The wait can be cancelled. There is no background roster polling. Access failures keep existing data, which may be outdated.\n\n"
            "Pause freezes the view while collection continues. Export CSV preserves visible rows and data sources. "
            "Clear view, a new log/watch, demo, or exit discards row metadata. The last 3,000 events are retained. "
            "Read README.md for cache-file limits, setup, and known limitations."
        ))

    def window_close(self):
        sidebar=getattr(self,'sidebar',None)
        if sidebar:
            from desktop_service import service_for
            return service_for(sidebar).window_close()
        return self.close()

    def close(self):
        for window in tuple(getattr(self, "player_profile_windows", {}).values()):
            if not window.close():
                return  # Keep the app open when unsaved local notes could not be written.
        if getattr(self, "sidebar", None) and not self.sidebar.close():
            return
        inspection_reports = getattr(self, 'inspection_reports_window', None)
        if inspection_reports is not None:
            inspection_reports.close()
        setup_health=getattr(getattr(self,'sidebar',None),'setup_health_window',None)
        if setup_health is not None:setup_health.close()
        avatar_creator = getattr(self, "avatar_creator", None)
        if avatar_creator is not None:
            avatar_creator.close()
        world_view = getattr(self, "world_view", None)
        if world_view is not None:
            world_view.close()
        range_close = getattr(self, "rangefinder_close", None)
        if range_close is not None:
            range_close()
        osc_controller = getattr(self, "osc_controller", None)
        if osc_controller is not None:
            osc_controller.close()
        for stop in tuple(self.transfer_stops):
            stop.set()
        self.visibility_request += 1
        if self.api:
            self.api.close()
        self.stop.set()
        guard = getattr(self, "startup_guard", None)
        if guard:
            try: guard.ready()
            except OSError: pass
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--logs", type=Path, default=default_log_folder(), help="VRChat log folder or specific .txt file")
    parser.add_argument("--demo", action="store_true", help="Show clearly labeled sample events")
    parser.add_argument("--vrcx-db", type=Path, help="Override the VRCX database file for this launch")
    parser.add_argument("--safe-mode", action="store_true", help="Start with optional integrations disabled; keep Black Box available")
    parser.add_argument('--profile-dir',type=Path,help='Use a separate local profile folder, including a verified recovered backup')
    parser.add_argument("--version", action="version", version=BUILD_VERSION)
    args = parser.parse_args()
    if args.profile_dir:
        from creator_projects import assert_no_links,local_path
        folder=assert_no_links(local_path(args.profile_dir))
        os.environ['VRC_EYE_PROFILE_DIR']=str(folder)
    import tkinter as tk
    if os.name == "nt":
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError, OSError):
            pass
    root = tk.Tk()
    from crash_boot import StartupGuard
    from tkinter import messagebox
    guard = StartupGuard(settings_path().with_name("startup-state.json"))
    safe_mode = args.safe_mode
    try:
        if not args.demo and guard.begin() and not safe_mode:
            safe_mode = messagebox.askyesno("VRC Eye startup recovery", "Three previous starts did not reach the ready checkpoint. Start in Safe Mode with optional integrations disabled?", parent=root)
    except (OSError, ValueError):
        guard.close()  # Startup recovery is optional; a second recorder still fails closed.
    try:
        app = AvatarWatch(root, args.logs, args.demo, args.vrcx_db, safe_mode=safe_mode)
        app.startup_guard = guard
        original_report = root.report_callback_exception
        def report(kind, value, trace):
            page = app.sidebar.pages.get("Crash & Diagnostics")
            if page and not app.demo: page.service.offer("eye.error", "vrc_eye", {"count": 1, "category": "VRC Eye"})
            original_report(kind, value, trace)
        root.report_callback_exception = report
        def ready():
            try: guard.ready()
            except OSError: pass
        root.after(30000, ready)
        root.mainloop()
    finally:
        guard.close()


if __name__ == "__main__":
    main()
