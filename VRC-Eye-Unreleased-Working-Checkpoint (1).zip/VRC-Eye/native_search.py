"""Bounded instant search over the existing local observation owners."""
import json
import unicodedata
from companion_data import Entity,entity
from native_library import scope,plain
from vrcx_sources import stopped


def normalized(value):return unicodedata.normalize('NFKC',value).casefold()


def match_score(query, name, ref, extra=''):
    """Require every term; tolerate a small typo only in words of 4+ letters."""
    from difflib import SequenceMatcher
    import re
    query=normalized(query).strip();name=normalized(name)
    haystack=name+' '+normalized(ref)+' '+normalized(extra)
    if query==normalized(ref):return 1000
    if query==name:return 900
    tokens=re.findall(r'\w+',haystack)[:500];score=0
    for term in query.split():
        if term in haystack:score+=100 if term in name else 60;continue
        if len(term)<4:return 0
        best=max((SequenceMatcher(None,term,word).ratio() for word in tokens
                  if abs(len(term)-len(word))<=2),default=0)
        if best<.75:return 0
        score+=int(best*40)
    return score+(100 if name.startswith(query) else 0)


def global_search(store,account,query,*,observations=(),stop=None,limit=100):
    """One bounded local index across entities, saved notes/tags and observations.

    Account rows override shared copies. No API request or remote name search.
    The scan budget is explicit; it does not claim all records in huge libraries.
    """
    query=plain(query,512).strip()
    if not query:return []
    pool={};notes={};budget=6000
    targets=list(dict.fromkeys(('shared',scope(account))))
    for target in targets:
        used=0
        with store.native.connect() as db:
            for raw, in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='annotation' ORDER BY updated DESC LIMIT 12000",(target,)):
                stopped(stop);d=json.loads(raw)
                notes.setdefault((target,d.get('entity')),[]).append(str(d.get('value',''))[:2000])
            for raw, in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='entity' ORDER BY updated DESC LIMIT 6000",(target,)):
                stopped(stop);d=json.loads(raw);kind=d.get('entity_kind');kind='user' if kind=='friend' else kind
                if kind not in ('user','world','avatar','group'):continue
                fields=dict(d.get('fields',{}));ref=d['entity_id']
                fields.update(id=ref);fields['displayName' if kind=='user' else 'name']=d.get('name') or ref
                for src,dst in (('image_url','imageUrl'),('thumbnail_image_url','thumbnailImageUrl')):
                    if src in fields:fields.setdefault(dst,fields[src])
                row=entity(kind,fields)
                from shared_notes import entity_keys
                extra=' '.join(value for alias in entity_keys(d['entity_kind'],ref) for value in notes.get((target,alias),[]))
                pool[(kind,ref)]=(row,extra);used+=1
                if used>=budget:break
    if scope(account)!='shared':
        with store.connect() as db:
            for raw, in db.execute('SELECT data FROM feed_profiles WHERE account=? ORDER BY checked DESC LIMIT 1000',(scope(account),)):
                stopped(stop);row=entity('user',json.loads(raw));k=(row.kind,row.id)
                pool[k]=(row,pool.get(k,(None,''))[1])
    for row in observations:
        stopped(stop);k=('user' if row.kind=='friend' else row.kind,row.id)
        pool[k]=(row,pool.get(k,(None,''))[1])
    ranked=[]
    for row,annotation in pool.values():
        stopped(stop);data=row.data or {}
        extra=' '.join(str(data.get(k,'')) for k in ('username','description','bio','statusDescription'))+' '+annotation
        score=match_score(query,row.name,row.id,extra)
        if score:ranked.append((-score,normalized(row.name),row.kind,row.id,
            Entity(row.kind,row.id,row.name,'Local '+row.kind+' · '+row.detail,row.image,row.data)))
    return [r[-1] for r in sorted(ranked,key=lambda r:r[:4])[:max(1,min(100,limit))]]


def search(store,account,kind,query,*,stop=None,limit=100):
    query=normalized(plain(query,512));terms=query.split()
    if not terms:return []
    scopes=list(dict.fromkeys((scope(account),'shared')));found={}
    native=store.native
    def add(ref,name,fields,origin):
        stopped(stop)
        if len(found)>=limit or ref in found:return
        haystack=normalized(name+' '+ref+' '+str(fields.get('description',''))+' '+str(fields.get('bio',''))+' '+str(fields.get('local_notes','')))
        if not all(term in haystack for term in terms):return
        payload=dict(fields,id=ref)
        payload['displayName' if kind=='user' else 'name']=name
        for source,target in (('image_url','imageUrl'),('thumbnail_image_url','thumbnailImageUrl')):
            if source in payload:payload[target]=payload[source]
        row=entity(kind,payload)
        found[ref]=Entity(row.kind,row.id,row.name,'Local observation · '+origin,row.image,row.data)
    for target in scopes:
        with native.connect() as db:
            notes={}
            for r in db.execute("SELECT data FROM eye_native_records WHERE scope=? AND kind='annotation'",(target,)):
                stopped(stop);d=json.loads(r[0]);notes.setdefault(d.get('entity'),[]).append(d.get('value',''))
            for record in db.execute("SELECT * FROM eye_native_records WHERE scope=? AND kind='entity'",(target,)):
                stopped(stop);d=json.loads(record['data'])
                if d.get('entity_kind')!=('friend' if kind=='user' else kind):continue
                fields=dict(d.get('fields',{}),local_notes=' '.join(notes.get(record['id'],[])))
                add(d['entity_id'],d.get('name') or d['entity_id'],fields,'shared library' if target=='shared' else 'account library')
                if len(found)>=limit:return list(found.values())
            if kind=='user' and target!='shared':
                for row in db.execute('SELECT id,data FROM feed_profiles WHERE account=?',(target,)):
                    d=json.loads(row['data']);add(row['id'],d.get('displayName') or row['id'],d,'observed friend profile')
                    if len(found)>=limit:return list(found.values())
    return sorted(found.values(),key=lambda r:(not normalized(r.name).startswith(query),normalized(r.name),r.id))
