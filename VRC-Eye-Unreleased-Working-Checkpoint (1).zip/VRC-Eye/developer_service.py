"""Developer workbench orchestration over VRC Eye's existing authenticated API.

Live operations reuse the client lock, request pacing, cookies, cache and request
transport. Sandbox and Replay never receive that client. No automatic write retry.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
import re
import secrets
import threading
import time
from urllib.parse import urlsplit

from developer_catalog import BY_KEY, OPERATIONS, SAMPLES, CATALOG_REVISION, validate_request, request_path, fingerprint
from developer_core import Recorder, canonical, redact, safe_route, stamp, trace_scope, json_shape, value_diff
from developer_lab import SandboxExecutor, ReplayLab
from vrchat_api import APIError, METADATA_INTERVAL
import player_api

ENVIRONMENTS = ('Sandbox', 'Live', 'Replay')
CONTACT_KEY = 'developer.api.contact'


def validate_contact(value):
    value = str(value).strip()
    if not value: return ''
    if len(value) > 180 or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise ValueError('Use a contact email or HTTPS project URL without spaces or controls.')
    email = re.fullmatch(r'[A-Za-z0-9.!#$%&\'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', value)
    parts = urlsplit(value)
    url = parts.scheme == 'https' and bool(parts.hostname) and not parts.username and not parts.password and not parts.fragment
    if not email and not url:
        raise ValueError('Use your real application contact email or HTTPS project URL; no invented placeholder.')
    if url and (parts.query or parts.port not in (None,443)):
        raise ValueError('The project contact URL must have no query, credentials or nonstandard port.')
    return value


@dataclass(frozen=True)
class Execution:
    environment: str
    generation: int
    client: object
    identity: tuple
    sandbox: object
    correlation: str
    cancel: object


class _CombinedStop:
    def __init__(self, *events): self.events = events
    def is_set(self): return any(event is not None and event.is_set() for event in self.events)


@dataclass
class Prepared:
    token: str
    request: dict
    context: Execution
    created: float
    baseline: dict
    preview: dict
    used: bool = False


class DeveloperService:
    def __init__(self, app=None, *, clock=time.monotonic):
        self.app, self.clock = app, clock
        self.recorder = Recorder(clock=clock)
        self.environment = 'Sandbox'
        self.generation = 0
        self.live_writes = False
        self.closed = False
        self.contact = ''
        self.lock = threading.RLock()
        self.sandbox = SandboxExecutor()
        self.replay = ReplayLab()
        self.prepared = {}
        self.results = []
        self.epoch_stop = threading.Event()
        self._account = None
        self.last_response = None
        self.comparison_response = None
        self.local_reads = 0
        self.cache_hits = 0
        self.account_changed()
        from bridge_lab_service import BridgeLabService
        self.bridge_lab = BridgeLabService(self, clock=clock)

    def configure_contact(self, value):
        contact = validate_contact(value)
        with self.lock:
            self.contact = contact
            # An approved action cannot silently change its application identity.
            self._cancel_locked()
            client = getattr(self.app, 'api', None)
            if client is not None: client.application_contact = contact
        return contact

    def _cancel_locked(self):
        if getattr(self, "bridge_lab", None): self.bridge_lab.invalidate()
        self.generation += 1
        self.live_writes = False
        self.prepared.clear()
        self.epoch_stop.set()
        self.epoch_stop = threading.Event()

    def switch(self, environment):
        if environment not in ENVIRONMENTS: raise ValueError('Choose Sandbox, Live or Replay.')
        with self.lock:
            if self.closed: raise ValueError('Developer service is closed.')
            if environment != self.environment:
                self._cancel_locked()
                self.environment = environment
                self.last_response = self.comparison_response = None
                self.results.clear()
                # Offline namespaces are reset rather than carrying writes between environments.
                self.sandbox = SandboxExecutor()
                self.replay = ReplayLab()
                self.recorder.emit('environment.changed', {'environment': environment, 'live_writes': False}, environment=environment)
        return self.snapshot()

    def account_changed(self):
        client = getattr(self.app, 'api', None)
        identity = (client, getattr(client, 'user_id', ''), getattr(client, 'session_revision', 0),
                    bool(getattr(client, 'authenticated', False)), bool(getattr(self.app, 'demo', False)))
        with self.lock:
            if identity != self._account:
                previous = self._account[0] if self._account else None
                if previous is not None and previous is not client and getattr(previous, 'diagnostics', None) is self.recorder:
                    # In-flight old-account work must not reappear in the active recorder.
                    previous.diagnostics = Recorder()
                    previous.diagnostics.enabled = False
                self._cancel_locked()
                self._account = identity
                self.last_response = self.comparison_response = None
                self.results.clear()
                self.recorder.clear()
            if client is not None:
                client.diagnostics = self.recorder
                client.application_contact = self.contact

    def arm(self, enabled):
        with self.lock:
            if not enabled:
                self.live_writes = False
                self.prepared.clear()
                return
        if self.environment != 'Live':
            raise ValueError('Live-write arming is available only in Live. Sandbox writes are isolated.')
        self._capture()
        with self.lock:
            self.live_writes = True
        self.recorder.emit('policy.changed', {'live_writes': True, 'reason': 'Explicit session-only developer arming'}, environment='Live')

    def _capture(self):
        with self.lock:
            if self.closed: raise ValueError('Developer service is closed.')
            environment, generation, sandbox = self.environment, self.generation, self.sandbox
            client, identity = None, (sandbox.account, 0)
            if environment == 'Replay':
                raise ValueError('Replay has no API executor. Use the replay controls in Testing Lab.')
            if environment == 'Live':
                if bool(getattr(self.app, 'demo', False)) or bool(getattr(self.app, 'safe_mode', False)):
                    raise ValueError('Live developer API access is disabled in Demo and Safe Mode.')
                client = getattr(self.app, 'api', None)
                if client is None: raise ValueError('Connect the existing VRChat account first. No separate developer login is created.')
                identity = player_api.context(client)
                if not self.contact: raise ValueError('Set a real application contact under VRC Eye → Networking → Developer API first.')
                client.application_contact = self.contact
                client.diagnostics = self.recorder
            return Execution(environment, generation, client, identity, sandbox, secrets.token_hex(12), self.epoch_stop)

    def _check(self, ctx, stop=None):
        if stop is not None and stop.is_set(): raise APIError('Developer action cancelled before the next dispatch.')
        with self.lock:
            if self.closed or ctx.environment != self.environment or ctx.generation != self.generation:
                raise APIError('Developer environment or account context changed; action invalidated.')
            if ctx.environment == 'Live':
                if getattr(self.app, 'api', None) is not ctx.client:
                    raise APIError('The active API connection changed.')
                if getattr(self.app, 'demo', False) or getattr(self.app, 'safe_mode', False):
                    raise APIError('Live developer access became unavailable.')
                player_api.check_context(ctx.client, ctx.identity, stop)

    def _scope_check(self, op, req, ctx, baseline=None):
        account = ctx.identity[0]
        if op.scope == 'Own account only':
            target = req['path'].get('userId') or req['query'].get('ownerId') or account
            if target != account: raise ValueError('This operation is restricted to the connected account.')
        if op.key == 'instance.create':
            if req['body'].get('ownerId', account) != account:
                raise ValueError('A personal test instance cannot be created under another account’s ownership.')
            if req['body']['type'] != 'public' and 'ownerId' not in req['body']:
                raise ValueError('A non-public personal instance requires ownerId set to your connected account.')
        if op.key in ('friends.request', 'friends.cancel-request', 'friends.remove') and req['path']['userId'] == account:
            raise ValueError('Choose another user, not the connected account.')
        if op.key.startswith('moderation.') and op.write and req['body']['moderated'] == account:
            raise ValueError('Choose another user for a personal moderation preference.')
        if baseline is not None:
            if op.scope in ('Owned world only', 'Owned avatar only') and baseline.get('authorId') != account:
                raise ValueError('The fresh record does not establish that this account owns the resource.')
            if op.scope == 'Group owner only in this adapter' and baseline.get('ownerId') != account:
                raise ValueError('This adapter requires the reported group owner; role definitions do not grant this action.')
            if op.key == 'account.update' and baseline.get('id') != account:
                raise ValueError('The account response did not match the selected account.')
            if op.key == 'avatar.select' and baseline.get('releaseStatus') != 'public' and baseline.get('authorId') != account:
                raise ValueError('The avatar is not reported public or owned by this account; selection is not authorized by this adapter.')
            if op.key == 'world.update':
                capacity = req['body'].get('capacity', baseline.get('capacity'))
                recommended = req['body'].get('recommendedCapacity', baseline.get('recommendedCapacity'))
                if type(capacity) is int and type(recommended) is int and recommended > capacity:
                    raise ValueError('The proposed values would leave recommended capacity above capacity.')
            if op.key == 'notifications.accept' and baseline.get('type') != 'friendRequest':
                raise ValueError('This action accepts only a returned friend-request notification.')

    def _validate_response(self, op, req, result, ctx):
        if (op.response == 'array' and not isinstance(result, list)) or (op.response != 'array' and not isinstance(result, dict)):
            raise APIError('The operation returned an unexpected JSON root type.', dispatched=True)
        if isinstance(result, dict) and 'error' in result:
            raise APIError('The operation returned an error record.', dispatched=True)
        identities = {'world.get': 'worldId', 'avatar.get': 'avatarId', 'user.get': 'userId',
                      'group.get': 'groupId', 'notifications.get': 'notificationId'}
        field = identities.get(op.key)
        if field and result.get('id') != req['path'][field]:
            raise APIError('The returned resource identity did not match the request.', dispatched=True)
        if op.key == 'account.get' and result.get('id') != ctx.identity[0]:
            raise APIError('The returned account identity did not match the active account.', dispatched=True)
        if op.pagination == 'results' and (not isinstance(result.get('results'), list) or type(result.get('hasNext')) is not bool):
            raise APIError('Pagination requires a results array and an explicit hasNext boolean.', dispatched=True)
        return result

    def _call(self, op, req, ctx, *, stop=None, progress=None, fresh=False):
        stop = _CombinedStop(stop, ctx.cancel)
        self._check(ctx, stop)
        self._scope_check(op, req, ctx)
        path = request_path(op, req)
        if ctx.environment == 'Sandbox':
            result = ctx.sandbox.execute(op, req)
            try: self._check(ctx, stop)
            except APIError as error:
                error.dispatched = op.write
                raise
            self._validate_response(op, req, result, ctx)
            self.recorder.emit('api.fixture', {'method': op.method, 'route': safe_route(path), 'response': result,
                               'status': 'completed', 'synthetic': True}, environment='Sandbox',
                               account=ctx.identity[0], operation=op.key, correlation=ctx.correlation)
            return result, False
        client = ctx.client
        expected = ctx.identity
        cache_key = ('developer-read', expected[0], expected[1], path)
        queued = self.clock()
        self.recorder.emit('api.queued', {'method': op.method, 'route': safe_route(path),
                           'reason': 'Shared client lock and configured metadata budget'}, account=expected[0],
                           operation=op.key, correlation=ctx.correlation)
        player_api.lock(client, stop)
        try:
            self._check(ctx, stop)
            cached = client.cache.get(cache_key) if not op.write and not fresh else None
            if cached and 0 <= client.clock() - cached[0] < METADATA_INTERVAL:
                self.cache_hits += 1
                self.recorder.emit('api.cache', {'cache_state': 'fresh', 'route': safe_route(path)},
                                   account=expected[0], operation=op.key, correlation=ctx.correlation)
                return deepcopy(cached[1]), True
            client._wait_metadata(stop, progress)
            self._check(ctx, stop)
            if op.write and not self.live_writes: raise ValueError('Live writes were disarmed before dispatch.')
            self.recorder.emit('api.dispatch', {'method': op.method, 'route': safe_route(path),
                               'queue_wait_ms': round((self.clock()-queued)*1000, 3)}, account=expected[0],
                               operation=op.key, correlation=ctx.correlation)
            if op.write:
                # Invalidate BEFORE dispatch: a lost write response can still mean the server changed.
                # Old metadata must not remain fresh even when the outcome is unknown.
                invalidated = len(client.cache)
                client.cache.clear()
                client.world_records.clear()
                if hasattr(client, '_preview_cache'): client._preview_cache.clear()
                if op.key.startswith('friends.'):
                    client.friends, client.friends_checked_at = None, ''
                self.recorder.emit('state.cache.invalidated', {'entries': invalidated, 'scope': 'Current account API cache'},
                                   account=expected[0], operation=op.key, correlation=ctx.correlation)
            with trace_scope('Developer / API Workbench', op.key, ctx.correlation):
                kwargs = dict(expect_list=op.response == 'array', method=op.method)
                if op.write:
                    kwargs['payload'] = req['body'] if req['body'] or op.method in ('POST','PUT') else None
                if op.empty_response: kwargs['allow_empty'] = True
                result = client._request(path, **kwargs)
            # A response from an old account is not allowed to populate this workbench or cache.
            try: self._check(ctx, stop)
            except APIError as error:
                error.dispatched = op.write
                raise
            self._validate_response(op, req, result, ctx)
            if not op.write:
                client.cache[cache_key] = (client.clock(), deepcopy(result))
                while len(client.cache) > 200: client.cache.pop(next(iter(client.cache)))
            return result, False
        finally:
            client.lock.release()

    def _related(self, key, req):
        op = BY_KEY[key]
        values = dict(req['body']); values.update(req['path'])
        related = {'operation': key, 'path': {k: values[k] for k in op.path_fields}, 'query': {}, 'body': {}}
        return validate_request(related)

    def _result(self, op, req, ctx, document, cached=False):
        rows = document.get('results') if op.pagination == 'results' else document if isinstance(document, list) else None
        page = None
        if op.pagination:
            count, n = len(rows), req['query'].get('n', 20)
            ids = [item.get('id', item.get('userId')) for item in rows if isinstance(item, dict)]
            ids = [item for item in ids if isinstance(item, str)]
            duplicates = len(ids) - len(set(ids))
            more = document['hasNext'] if op.pagination == 'results' else count >= n
            page = {'returned': count, 'requested': n, 'offset': req['query'].get('offset', 0),
                    'duplicate_ids_in_page': duplicates, 'may_have_next': more,
                    'next_offset': req['query'].get('offset', 0) + n if more else None,
                    'stop_reason': ('Endpoint reports hasNext=false' if op.pagination == 'results' else 'Short page observed; changing dataset is not an atomic snapshot') if not more
                                   else 'One-page inspection limit; more data may exist'}
        return {'environment': ctx.environment, 'operation': op.key, 'method': op.method, 'route': safe_route(request_path(op, req)),
                'observed_at': stamp(), 'cache_state': 'fresh cache' if cached else 'fetched', 'synthetic': ctx.environment != 'Live',
                'response': redact(document, local=True), 'schema': json_shape(document), 'pagination': page,
                'outcome': 'read completed', 'request_fingerprint': fingerprint(req), 'catalog_revision': CATALOG_REVISION}

    def _retain(self, result, ctx):
        self._check(ctx)
        with self.lock:
            self.last_response = deepcopy(result)
            self.results.append(redact(result))
            del self.results[:-30]
        if getattr(self, "bridge_lab", None): self.bridge_lab.observe_api(result, ctx)
        return result

    def read(self, value, *, stop=None, progress=None, fresh=False):
        op, req = validate_request(value)
        if op.write: raise ValueError('This is a write operation. Prepare and review it instead.')
        ctx = self._capture()
        self._scope_check(op, req, ctx)
        document, cached = self._call(op, req, ctx, stop=stop, progress=progress, fresh=fresh)
        self.local_reads += 1
        return self._retain(self._result(op, req, ctx, document, cached), ctx)

    def prepare(self, value, *, stop=None, progress=None):
        op, req = validate_request(value)
        if not op.write: raise ValueError('Choose a write operation to prepare.')
        ctx = self._capture()
        self._scope_check(op, req, ctx)
        baseline = {}
        if op.preflight:
            read_op, read_req = self._related(op.preflight, req)
            baseline, _ = self._call(read_op, read_req, ctx, stop=stop, progress=progress, fresh=True)
            self._scope_check(op, req, ctx, baseline)
        preview = {'environment': ctx.environment, 'account': ctx.identity[0], 'operation': op.key,
                   'method': op.method, 'route': safe_route(request_path(op, req)), 'risk': op.risk, 'scope': op.scope,
                   'request': deepcopy(req), 'current_values': {k: baseline.get(k, '[not observed]') for k in req['body']},
                   'proposed_values': deepcopy(req['body']), 'verification': op.verify or 'No automatic verification adapter; acknowledgement only',
                   'note': op.notes, 'expires_seconds': 900,
                   'concurrency': 'Fresh comparison before dispatch; no claim of an atomic server transaction.'}
        token = secrets.token_urlsafe(24)
        with self.lock:
            self._check(ctx, stop)
            if len(self.prepared) >= 20: self.prepared.clear()
            self.prepared[token] = Prepared(token, deepcopy(req), ctx, self.clock(), deepcopy(baseline), preview)
        self.recorder.emit('action.prepared', {'operation': op.key, 'method': op.method, 'risk': op.risk,
                           'phase': 'preview', 'fields': [{'field': k} for k in req['body']]},
                           environment=ctx.environment, account=ctx.identity[0], correlation=ctx.correlation)
        return {'token': token, 'preview': preview, 'fingerprint': fingerprint(req)}

    def execute(self, token, value, *, stop=None, progress=None):
        op, req = validate_request(value)
        with self.lock:
            prepared = self.prepared.get(token)
            if prepared is None or prepared.used:
                raise ValueError('This review has expired or was already used. Prepare the action again.')
            if fingerprint(req) != fingerprint(prepared.request):
                self.prepared.pop(token, None)
                raise ValueError('The request changed after review. Prepare the new exact request.')
            if self.clock() - prepared.created > 900:
                self.prepared.pop(token, None)
                raise ValueError('This review expired. Refresh and prepare it again.')
            ctx = prepared.context
            self._check(ctx, stop)
            if ctx.environment == 'Live' and not self.live_writes:
                raise ValueError('Live writes are not armed for this session.')
            # Consume approval BEFORE queueing: no repeated click can duplicate the action.
            prepared.used = True
        outcome = {'environment': ctx.environment, 'operation': op.key, 'outcome': 'not sent',
                   'synthetic': ctx.environment != 'Live', 'observed_at': stamp(), 'correlation': ctx.correlation,
                   'local_client_effect': 'Unconfirmed; HTTP/API state is not live client telemetry.'}
        sent = False
        try:
            if op.preflight:
                read_op, read_req = self._related(op.preflight, req)
                latest, _ = self._call(read_op, read_req, ctx, stop=stop, progress=progress, fresh=True)
                self._scope_check(op, req, ctx, latest)
                relevant = set(req['body']) | ({'releaseStatus'} if op.key in ('world.publish', 'world.unpublish', 'avatar.select') else set())
                if any(type(latest.get(k)) is not type(prepared.baseline.get(k)) or latest.get(k) != prepared.baseline.get(k) for k in relevant):
                    raise ValueError('The service changed a reviewed field after preview. Nothing was written. Prepare a three-way comparison again.')
            self._check(ctx, stop)
            # A transport exception after this point may indicate a lost response, not a rejected write.
            sent = True
            document, _ = self._call(op, req, ctx, stop=stop, progress=progress, fresh=True)
            outcome.update(outcome='acknowledged', response=redact(document, local=True),
                           verification='Not performed; acknowledgement alone does not prove observable effects.')
        except (APIError, ValueError) as error:
            dispatched = sent and bool(getattr(error, 'dispatched', False))
            status = getattr(error, 'status_code', None)
            # 408, 5xx and post-dispatch failures remain uncertain. No automatic repeated mutation.
            state = 'rejected' if dispatched and status is not None and 400 <= status < 500 and status != 408 else 'outcome unknown' if dispatched else 'not sent'
            outcome.update(outcome=state, reason=str(error), status_code=status, automatic_retry=False,
                           verification='Use a separate fresh verification read before considering another action.' if dispatched else 'No mutation dispatch was recorded.')
            self._record_outcome(outcome, ctx)
            if ctx.environment == self.environment and ctx.generation == self.generation:
                try: self._retain(outcome, ctx)
                except APIError: pass
            return outcome
        self._record_outcome(outcome, ctx)
        if op.verify:
            try:
                verification = self._verify(op, req, ctx, stop=stop, progress=progress)
                outcome.update(verification)
            except (APIError, ValueError) as error:
                outcome.update(outcome='acknowledged; verification pending', verification=str(error))
        self._record_outcome(outcome, ctx)
        return self._retain(outcome, ctx)

    def _verify(self, op, req, ctx, *, stop=None, progress=None):
        read_op, read_req = self._related(op.verify, req)
        observed, _ = self._call(read_op, read_req, ctx, stop=stop, progress=progress, fresh=True)
        expected = req['body'] if op.key in ('account.update','world.update','avatar.update','group.update') else {}
        if op.key == 'avatar.select': expected = {'currentAvatar': req['path']['avatarId']}
        if op.key == 'world.publish': expected = {'releaseStatus': 'public'}
        if op.key == 'world.unpublish': expected = {'releaseStatus': 'private'}
        if op.key == 'friends.request': expected = {'outgoingRequest': True}
        if op.key == 'friends.cancel-request': expected = {'outgoingRequest': False}
        if op.key == 'friends.remove': expected = {'isFriend': False}
        matched = bool(expected) and all(type(observed.get(k)) is type(v) and observed.get(k) == v for k,v in expected.items())
        return {'outcome': 'service state verified' if matched else 'acknowledged; verification pending',
                'verification': 'Reviewed service fields match; local client effects still unconfirmed.' if matched else 'Verification response did not yet establish the requested state.',
                'verification_response': redact(observed, local=True)}

    def verify(self, value, *, stop=None, progress=None):
        op, req = validate_request(value)
        if not op.write or not op.verify: raise ValueError('This operation has no verification adapter. Inspect its affected resource separately.')
        ctx = self._capture()
        self._scope_check(op, req, ctx)
        outcome = self._verify(op, req, ctx, stop=stop, progress=progress)
        outcome.update(environment=ctx.environment, operation=op.key, observed_at=stamp(),
                       synthetic=ctx.environment != 'Live', local_client_effect='Unconfirmed')
        return self._retain(outcome, ctx)

    def _record_outcome(self, outcome, ctx):
        # Do not place old-account outcomes in the active account's event view.
        if ctx.generation != self.generation: return
        self.recorder.emit('action.outcome', outcome, environment=ctx.environment,
                           account=ctx.identity[0], operation=outcome['operation'], correlation=ctx.correlation)

    def cache_snapshot(self):
        if self.environment != 'Live': return {'environment': self.environment, 'scope': 'No live cache access in this environment'}
        ctx = self._capture()
        if not ctx.client.lock.acquire(timeout=.05):
            return {'state': 'busy', 'reason': 'The shared API request currently owns the cache lock.'}
        try:
            self._check(ctx)
            now = ctx.client.clock()
            rows = []
            for key, value in list(ctx.client.cache.items())[:200]:
                age = max(0, now-value[0]) if isinstance(value, tuple) and value and isinstance(value[0], (float,int)) else None
                rows.append({'scope': str(key[0])[:80], 'age_seconds': round(age,2) if age is not None else None,
                             'cache_state': 'fresh' if age is not None and age < METADATA_INTERVAL else 'stale',
                             'path': safe_route(str(key[-1])) if key[0] == 'developer-read' else '[resource key omitted]'})
            return {'environment': 'Live', 'entries': rows, 'count': len(rows), 'shared_budget_seconds': METADATA_INTERVAL,
                    'server_quota': 'Unknown; this interval is a local policy, not an allowance from VRChat.'}
        finally: ctx.client.lock.release()

    def invalidate_cache(self):
        ctx = self._capture()
        if ctx.environment != 'Live': return {'cleared': 0, 'environment': ctx.environment}
        if not ctx.client.lock.acquire(timeout=.1): raise ValueError('The shared API is busy. Cancel or finish its task first.')
        try:
            self._check(ctx)
            count = len(ctx.client.cache)
            ctx.client.cache.clear(); ctx.client.world_records.clear()
            self.recorder.emit('state.cache.invalidated', {'entries':count, 'reason':'Explicit local cache invalidation'})
            return {'cleared': count, 'environment': 'Live', 'network_requests': 0}
        finally: ctx.client.lock.release()

    def reset_sandbox(self):
        with self.lock:
            if self.environment != 'Sandbox': raise ValueError('Choose Sandbox before resetting synthetic fixtures.')
            self._cancel_locked(); self.sandbox = SandboxExecutor()
            self.last_response = None
        return self.snapshot()

    def snapshot(self):
        with self.lock:
            return {'version': '1.21.0', 'environment': self.environment, 'generation': self.generation,
                    'live_writes': self.live_writes, 'account_connected': bool(getattr(getattr(self.app,'api',None),'authenticated',False)),
                    'contact_configured': bool(self.contact), 'prepared_actions': sum(not p.used for p in self.prepared.values()),
                    'operations': len(OPERATIONS), 'implemented_reads': sum(not o.write for o in OPERATIONS if o.live),
                    'implemented_writes': sum(o.write for o in OPERATIONS if o.live), 'reference_only': sum(not o.live for o in OPERATIONS),
                    'live_verified_operations': 0, 'local_reads': self.local_reads, 'cache_hits': self.cache_hits,
                    'recorder': self.recorder.stats(), 'synthetic_requests': self.sandbox.calls,
                    'replay_position': self.replay.position, 'client_bridge_lab': self.bridge_lab.summary(), 'network_configuration': 'VRC Eye → Networking → Developer API'}

    def close(self):
        if getattr(self, "bridge_lab", None): self.bridge_lab.close()
        with self.lock:
            self._cancel_locked(); self.closed = True
            self.last_response = self.comparison_response = None
            self.results.clear(); self.recorder.clear()
