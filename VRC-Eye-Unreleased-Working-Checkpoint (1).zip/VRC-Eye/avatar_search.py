"""Bounded search results shared by API and local-cache searches."""

from dataclasses import dataclass


PAGE_SIZE = 50
MAX_RESULTS = 1000
SCOPES = (("My uploads", "mine"), ("My favorites", "favorites"),
          ("Featured avatars", "featured"), ("VRCX cache", "vrcx"))


@dataclass(frozen=True)
class AvatarSearchItem:
    avatar_id: str
    name: str
    author: str
    visibility: str
    platforms: tuple[str, ...]
    source: str
    checked_at: str
    lookup: object | None = None
    image_url: str = ''
    thumbnail_image_url: str = ''


@dataclass(frozen=True)
class AvatarSearchPage:
    items: tuple[AvatarSearchItem, ...]
    offset: int
    has_more: bool
    skipped: int = 0


def check_offset(offset):
    if type(offset) is not int or offset < 0 or offset >= MAX_RESULTS or offset % PAGE_SIZE:
        raise ValueError("Choose a valid page within the first 1,000 results.")


def search_text(value):
    if not isinstance(value, str) or len(value) > 512 or "\x00" in value:
        raise ValueError("Search text must be at most 512 characters without null bytes.")
    return value.strip()


def filter_items(items, query):
    text = search_text(query).casefold()
    return [item for item in items if not text or text in
            " ".join((item.name, item.author, item.avatar_id)).casefold()]


def merge_items(current, incoming):
    """Keep IDs distinct even when names match; deduplicate across shifted pages."""
    results = {item.avatar_id: item for item in current}
    results.update((item.avatar_id, item) for item in incoming)
    return list(results.values())[:MAX_RESULTS]
