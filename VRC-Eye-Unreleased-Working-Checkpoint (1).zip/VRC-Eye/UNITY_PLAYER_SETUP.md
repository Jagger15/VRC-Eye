# Unity Player — VRC Eye 1.18.9

Close the previous VRC Eye instance, extract VRC-Eye-v1.18.9.zip, and run Start.cmd.
Open **Advanced → Unity Player**. Python 3.10+ with Tkinter is required.
**Start.cmd** automatically prepares psutil and the other app dependencies.
If package setup cannot finish offline, available monitoring still opens; reopen
**Start.cmd** when online to retry. No VRChat login or bridge is required for
external monitoring.

## Included views

Casual mode shows Overview, Window, Startup & launch, and History. Advanced adds
Runtime & graphics, Logs, and Compatibility. Developer also shows generation,
session, PID, sample age, provider health and the normalized runtime event stream.
The service starts in the background even if the page is never opened. Monitoring
can be disabled explicitly, and Demo never opens live providers or runs actions.

- **Overview:** process lifecycle, responsiveness, resource pressure, recent error
  counts and hang/recovery counts. Internal game readiness is separately reported.
- **Runtime & graphics:** recognized Unity version, executable architecture,
  logged renderer/adapter/driver, shared resource values with sources/ages, and a
  60-second graph from Resource Guard. GPU totals remain device-wide.
- **Window:** Windows geometry, display topology/work areas, DPI, focus,
  minimized/maximized state, monitor-covering geometry and off-screen detection.
- **Startup & launch:** observed milestones, first responsive-window timing,
  recent summary baseline, launch intent and typed launch profiles.
- **Logs:** normalized warnings, errors, category counts and bursts, linked to the
  existing Game Log. Raw log text is not duplicated in runtime history.
- **Compatibility:** capability states for process, window, generic log parsing,
  shared GPU measurements and optional runtime bridge reports; no guessed global
  driver/runtime compatibility verdict.
- **History:** session-only by default; opt into 7, 30 or 90 days, capped at 50
  summaries. Includes observed duration, exit evidence, hang/recovery counts,
  longest observed hang, observed startup time, error count and resource peaks.
- **Developer:** isolated start → six-second hang → recovery simulation; no OS
  mutations, live-state changes, saved records or synthetic Black Box incidents.

## How observations are resolved

RuntimeService owns a coherent RuntimeModel and returns detached snapshots. A
process identity uses PID, creation time and exact executable path in memory.
Each new identity receives a new runtime generation and session. Window, runtime
metadata, counters and bridge state are cleared across generations. Resource Guard
is the first measurement source; an existing fresh Black Box core sample is reused
when available. Only if neither supplies a sample does Unity Player invoke its
own core fallback. GPU collection is never duplicated by this feature.

Process states distinguish unknown/ambiguous identity, not running, starting,
initializing, running, degraded, unresponsive and exit evidence. Two distinct
confirmed absent samples establish an exit; stale data or access failure does not.
A recent explicit crash marker or application-quit marker can qualify that exit;
otherwise it remains UNKNOWN_EXIT. OS termination is not inferred from a missing
process. A hang that recovers is not a crash. An observation gap ends continuous
hang timing without inventing a recovery or the duration of an unobserved interval.

Startup timing is **time to an observed responsive window**, only when VRC Eye
observed the process within ten seconds of creation. Attaching to an already
running client does not create a startup measurement. This metric does not prove
that login, world loading or application initialization completed. Milestone
seconds are measured from when this service began observing the runtime.

Metadata uses recognized log patterns and a bounded PE header read for architecture.
It never loads the executable or reads live process memory. A bounded 64 KiB log
header read requires its first timestamp to fit the target launch. Metadata and
PE architecture are normally read once per process/log source; missing Unity
metadata can retry at 30-second intervals. Reconcile explicitly requests a recheck.
Unrecognized versions/formats remain unknown or partially supported. Logged adapter
names do not establish Windows preferred-GPU selection or process GPU allocation.

Live log events must be fresh and belong to the runtime's observed start window.
Error categories are heuristic labels, not diagnoses. Ten errors within ten seconds
create a normalized burst event, limited to one burst notification per 30 seconds.
Runtime events are bounded to 512; the live error window retains at most 2,048
entries and ingress is bounded to 512 queued items. Dropped events generate a gap
marker. UI redraws are coalesced to roughly 1 Hz, or 0.5 Hz in the Low overhead
profile. Process and window observations run at about 1 Hz; display changes are
recognized by comparing these samples, not by a native display-event subscription.

## Reviewed window operations

The supported Windows provider requires exactly one visible, unowned UnityWndClass
window belonging to the verified VRChat process. Other classes, ambiguous windows,
missing permissions and unavailable APIs produce unavailable state.

Available operations are Bring to Front, Restore Window, Center Window, Move to
Primary Display, Recover Window, Default Size (up to 1280×720 inside the primary display
work area), and Restore Known-Good Position. Known-good geometry is session-local,
recorded only from a restored, on-screen, non-monitor-covering window.

Each request has a one-minute review expiry. The worker rechecks the runtime
generation, process identity, HWND, window rectangle and monitor topology after
the confirmation dialog. Changes cancel the request. Native APIs check window
ownership again before mutation. No request is retried automatically. Windows can
refuse foreground activation; asynchronous restore/reposition requests are reported
as queued rather than claimed to have completed.

Repositioning needs consistent per-monitor DPI coordinates. Restore a minimized or
maximized window first, then review the new position. A window covering a monitor
must be switched to windowed mode before repositioning. Covering a monitor does
not establish exclusive fullscreen. No global display settings, refresh rates,
Unity internals or game camera/height settings are changed.

## Launch profiles

Profiles inherit defaults, a named preset and the selected profile's saved typed
overrides. Changing the preset loads its defaults. The current edited profile is
saved; this is not an arbitrary executable or shell-command launcher.

| Profile | Actual behavior |
| --- | --- |
| Normal | Steam's default VRChat startup; no forced VR mode |
| Desktop | Requests the documented `--no-vr` option |
| Troubleshooting | Desktop, documented debug menu, windowed mode |
| Creator / Test | Debug menu; optional local world/avatar watching is an explicit checkbox |
| Low overhead | Normal launch; Unity Player page redraws slow to 0.5 Hz |
| Custom | The same supported typed fields with user overrides |

Supported fields: desktop/debug switches, width+height, monitor index, fullscreen,
FPS cap and optional local test world/avatar watching. Zero in a numeric field
uses application defaults. Width and height must be supplied together. Local test
watching can cause VRChat to join a newly built local world or switch an updated
test avatar; launch review explains this. Unsupported flags, arbitrary text,
process-priority overrides and forced graphics backends are not accepted.

The request uses a fixed VRChat Steam URI, with allowlisted arguments URL encoded.
The worker checks that VRChat is absent immediately before opening that URI and
rejects repeat requests for 30 seconds. A handler accepting the URI does not prove
a successful game launch. Steam can prompt or apply its own saved options. Launch
intent and observed mode remain separate; process-bound runtime.summary telemetry
can report a match/mismatch for a desktop request. Steam behavior and native URI
argument handling require target-system verification.

Profiles do not edit Steam settings, disable unrelated modules, change the user's
Home, stop a running client or bypass the application launcher. The Black Box and
Resource Guard retain their independent settings. Deeper orchestration from the
long-term design is not presented as a working feature here.

## Bridge integration

Existing authenticated Bridge 1.0 negotiation, permissions, lease expiry, account
scope, telemetry TTL and typed capability validation remain in force. The existing
Player List continues to own selection, voice, distance, avatar load/performance
and reviewed local controls; Unity Player does not create a second player database.

Two additive telemetry capabilities (capability version 1) are now recognized:

- `runtime.summary`: requires `process_id` and `process_started_at` (Unix seconds),
  with optional scene/avatars/render/local_player states, VR mode, frame time and FPS.
- `runtime.errors`: the same process identity plus up to 64 normalized error rows;
  each has category, severity, enumerated code and count. No arbitrary error text,
  object dump, method execution, memory access or player identifiers are accepted.

Unity Player rejects reports whose PID/creation time does not match its observed
process, old-generation reports and reports over three seconds old. Error batches
are counted once per observed sample. Disconnection, lease loss or capability loss
removes that capability's state; unknown values never become zero/false/healthy.
The older `unity.runtime_health` capability is displayed as an explicitly unbound
client report because its schema does not establish an OS process identity.

A compatible adapter must implement these capabilities voluntarily. This release
does not inject, install or create a VRChat-side client component. An example of
valid new payloads is included in BRIDGE_PROTOCOL.md.

## Integration and privacy

New runtime transitions enter the existing Black Box as `runtime.*` events with
normalized state/milestone/category metadata, source/confidence and generation.
Personal process paths, HWND/PID, names and raw logs are not sent to the recorder.
The independent Black Box retains ownership of incident preservation and its
existing durable storage/retention rules. Unity Player's own history is separate.

An observed process exit informs PlayerSessionService. Active rows become uncertain
ended presence; it does not manufacture exact player leave timestamps. A delayed
exit notification cannot close a newer player instance. Bridge player actions retain
the existing exact-instance/account review requirements.

Persistent runtime summaries live in `unity-runtime-history.json` beside
`companion.sqlite3`. Retention defaults to off. Only opted-in summaries are written,
using atomic replacement and a 50-row cap. Disabling retention deletes the saved
file; Clear runtime summaries removes runtime summaries only. Live samples remain
in bounded memory or the separately configured Black Box. Closing VRC Eye does not
invent a VRChat exit or save an incomplete session as a completed one.

Reviewed JSON exports include sanitized versions, resource values, normalized
runtime events, approved structured runtime summary/health fields and retained
summaries. Credentials, raw logs, personal paths, private instance codes, notes,
player/account/avatar IDs, PID/window handles and adapter names are excluded.
Exact timestamps remain. An existing export file is never overwritten. No upload
or sharing is performed by the feature.

## Current boundaries and validation

VRChat is the included application profile. Other Unity application profiles,
exact multi-GPU attribution, exhaustive renderer/driver compatibility data,
comprehensive tracking providers, per-world/per-avatar runtime history, learned
regression prediction, dedicated runtime VR overlays and automatic remediation are
later extensions from the supplied discussion. The current implementation provides
local capability status, summary baselines and version-change observations, not
global driver verdicts or player blame.

See VALIDATION.md for executed tests and native checks still required. Native
Windows window APIs, Steam launch, real VRChat sessions, mixed-DPI/multiple-monitor
recovery, native Tk layout and hardware/VR behavior were not available in the build
environment. A real target-system test remains necessary before treating those
paths as verified. No live game process was launched, moved or terminated during
this build.

Provider references reviewed during implementation:
- https://docs.vrchat.com/docs/launch-options
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setwindowpos
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getwindowrect
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-showwindowasync
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-enumdisplaymonitors
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getmonitorinfow
