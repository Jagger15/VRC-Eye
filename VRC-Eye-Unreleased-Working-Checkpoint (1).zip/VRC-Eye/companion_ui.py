"""Sidebar, shared controls and account-bound background jobs for companion pages."""
import base64
import math
import queue
import sqlite3
import threading
import time
import webbrowser

from companion_data import CompanionStore, Entity, entity_id, page_url
from game_log import GameLog
from vrchat_api import APIError
from screen_reader_model import annotate


def line(page, parent=None):
    frame = page.ttk.Frame(parent or page.parent); frame.pack(fill="x", pady=4); return frame


def button(page, parent, text, command):
    widget = page.ttk.Button(parent, text=text, command=lambda: page.guard(command))
    widget.pack(side="left", padx=(0, 6)); return widget


def entry(page, parent, variable, width=28):
    widget = page.ttk.Entry(parent, textvariable=variable, width=width); widget.pack(side="left", padx=(0, 6))
    label_input(page,widget,variable);return widget


def label_input(page,widget,variable):
    from screen_reader_tk import label_for
    try:
        if label_for(widget):return
    except AttributeError:pass
    for name,value in vars(page).items():
        if value is variable and not name.startswith('_'):
            title={'query':'Search','ref':'ID or URL','destination':'Destination','note':'Note'}.get(name,name.replace('_',' ').title())
            annotate(widget,name=title);break


def choice(page, parent, variable, values, callback=None, width=22):
    widget = page.ttk.Combobox(parent, textvariable=variable, values=values, state="readonly", width=width)
    widget.pack(side="left", padx=(0, 6))
    label_input(page,widget,variable)
    if callback: widget.bind("<<ComboboxSelected>>", lambda _: page.guard(callback))
    return widget


def note(page, text):
    page.ttk.Label(page.parent, text=text, wraplength=1050, style="Muted.TLabel").pack(anchor="w", pady=5)


class Table:
    def __init__(self, page, parent, columns, *, height=12, select=None):
        self.page = page
        self._context = page.context() if callable(getattr(page, 'context', None)) else None
        box = page.ttk.Frame(parent); box.pack(fill="both", expand=True, pady=5)
        self.tree = page.ttk.Treeview(box, columns=tuple(k for k, _, _ in columns), show="headings", height=height, selectmode="browse")
        for key, title, width in columns:
            self.tree.heading(key, text=title); self.tree.column(key, width=width, minwidth=65, stretch=True)
        y = page.ttk.Scrollbar(box, orient="vertical", command=self.tree.yview)
        x = page.ttk.Scrollbar(box, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        x.pack(side="bottom", fill="x"); y.pack(side="right", fill="y"); self.tree.pack(fill="both", expand=True)
        self.records = {}
        annotate(self.tree,name=' / '.join(title for _,title,_ in columns),description='Arrow keys select rows. Enter reads full row details unless this view supplies an action. Shift+F10 opens row actions; Ctrl+Shift+F10 opens details and sorting. Shift+Left/Right scroll columns.')
        if select: self.tree.bind("<<TreeviewSelect>>", lambda _: page.guard(select))

    def set(self, records, values, *, identity=None):
        self.tree._eye_content_revision=getattr(self.tree,'_eye_content_revision',0)+1
        selected = self.selected()
        context = self.page.context() if callable(getattr(self.page, 'context', None)) else None
        if context != self._context: selected = None
        self._context = context
        def stable(record):
            if identity: return identity(record)
            if isinstance(record, dict) and record.get('id') is not None:
                return (record.get('kind'), record['id'])
            if getattr(record, 'id', None) is not None:
                return (getattr(record, 'kind', None), record.id)
            return id(record)
        wanted=stable(selected) if selected is not None else None
        position=None
        try:position=self.tree.yview()
        except (AttributeError,TypeError):pass
        children = self.tree.get_children()
        if children: self.tree.delete(*children)
        self.records = {str(i): record for i, record in enumerate(records)}
        for key, record in self.records.items():
            self.tree.insert("", "end", iid=key, values=values(record))
            if wanted is not None and stable(record)==wanted:
                self.tree.selection_set(key)
                try:self.tree.focus(key)
                except AttributeError:pass
        if isinstance(position,(tuple,list)) and position:
            try:self.tree.yview_moveto(position[0])
            except (AttributeError,TypeError):pass

    def selected(self):
        return next((self.records[key] for key in self.tree.selection() if key in self.records), None)


class Page:
    def __init__(self, shell, parent, title, *, task_controls=True):
        self.shell, self.app, self.parent = shell, shell.app, parent
        self.tk, self.ttk = self.app.tk, self.app.ttk
        self.closed = False; self.job = None; self.revision = 0; self.account = self.context()
        self.status = self.tk.StringVar(value="Ready.")
        annotate(self.ttk.Label(parent, text=title, style="Title.TLabel"),role='heading',public=True).pack(anchor="w")
        from ui_theme import responsive_wrap
        status_label=annotate(responsive_wrap(self.ttk.Label(parent, textvariable=self.status, wraplength=1050)),name=title+' status',role='status',value=self.status.get)
        status_label._eye_live_key='page-status';status_label.pack(anchor="w", pady=5)
        if task_controls:
            row = line(self)
            button(self, row, "Cancel pending task", self.cancel)

    def context(self):
        client = self.app.api
        return (client, getattr(client, "user_id", ""), getattr(client, "session_revision", 0), bool(getattr(client, "authenticated", False)), bool(self.app.demo))

    def guard(self, action):
        try: return action()
        except (ValueError, APIError, OSError, sqlite3.Error) as error:
            self.status.set(str(error))
            from screen_reader import announce
            announce(self.app,str(error),priority=True,key='page-status')

    def connect(self):
        from online_dialog import show_connection_dialog
        show_connection_dialog(self.app)

    def connected(self):
        if self.app.demo: raise ValueError("API actions are disabled in Demo. Watch a real log to leave Demo.")
        if not self.app.api or not self.app.api.authenticated: raise ValueError("Use VRChat connection… to sign in first.")
        return self.app.api

    def start(self, work, done, *, api=True, mutation=False):
        if self.closed: return
        if self.job: raise ValueError("A task is already pending on this page. Wait or cancel it first.")
        client = self.connected() if api else self.app.api
        context = self.context(); revision = self.revision
        stop = threading.Event(); output = queue.Queue(maxsize=30)
        self.app.transfer_stops.append(stop)
        def emit(kind, value):
            try: output.put_nowait((kind, value))
            except queue.Full:
                if kind != "progress":
                    while not output.empty():
                        try: output.get_nowait()
                        except queue.Empty: break
                    output.put_nowait((kind, value))
        def run():
            try:
                value = work(client, stop, lambda text: emit("progress", text))
                emit("done", value)
            except (ValueError, APIError, OSError, sqlite3.Error) as error:
                emit("error", str(error) + (" No automatic retry; refresh to verify whether the action took effect." if mutation else ""))
            except Exception:
                emit("error", "The task could not process this response. Refresh and try again." + (" Check the list before repeating an action." if mutation else ""))
            finally:
                if stop in self.app.transfer_stops: self.app.transfer_stops.remove(stop)
        self.job = dict(stop=stop, output=output, context=context, revision=revision, done=done, api=api, mutation=mutation)
        self.status.set("Queued… Metadata requests share the existing connection's interval." if api else "Queued… Local task; no VRChat authentication is required.")
        threading.Thread(target=run, daemon=True).start()

    def tick(self):
        if self.closed: return
        if self.context() != self.account:
            self.cancel(); self.account = self.context(); self.account_changed()
        job = self.job
        if not job: return
        if job["stop"].is_set() or job["revision"] != self.revision or job["api"] and job["context"] != self.context():
            self.cancel(); return
        for _ in range(30):
            try: kind, value = job["output"].get_nowait()
            except queue.Empty: break
            if kind == "progress": self.status.set(value)
            else:
                self.job = None
                if kind == "error":
                    self.status.set(value)
                    from screen_reader import announce
                    announce(self.app,value,priority=True,key='page-status')
                else:
                    self.status.set("Task complete."); self.guard(lambda: job["done"](value))
                break

    def cancel(self):
        if self.job:
            self.job["stop"].set()
            self.status.set("Task canceled. An already submitted action may have taken effect; refresh its list." if self.job["mutation"] else "Task canceled.")
        self.job = None; self.revision += 1

    def account_changed(self): pass

    def close(self):
        self.cancel(); self.closed = True; return True

    def confirm(self, title, text):
        from tkinter import messagebox
        return messagebox.askyesno(title, text, parent=self.app.root)

    def open_item(self, record):
        if not record: raise ValueError("Select an item first.")
        webbrowser.open(page_url(record.kind, record.id))

    def profile(self, record):
        if not record or record.kind not in ("user", "friend"): raise ValueError("Select a user first.")
        from world_players import PlayerVisit, PlayerRow
        from player_profile_dialog import show_profile
        visit = PlayerVisit(0, record.name, entity_id("user", record.id), state="Account view", note="API/collection selection; this does not establish a world visit.")
        row = PlayerRow("companion:"+record.id, record.name, visit, None, None, bool(self.app.api and self.app.api.user_id == record.id), ())
        show_profile(self.app.world_view, row)

    def favorite(self, record):
        if not record: raise ValueError("Select an item first.")
        if self.app.demo: raise ValueError("Leave Demo before saving real favorites.")
        from tkinter import simpledialog
        group = simpledialog.askstring("VRC Eye favorite", "Local collection name (no item-count limit):", initialvalue="General", parent=self.app.root)
        if group is None: return
        self.shell.store.save_favorite(record.kind, record.id, record.name, group, record.data)
        self.status.set("Saved to VRC Eye Favorites. Game favorites were not changed.")


class Picture:
    def __init__(self, page, parent, title):
        self.page = page; self.photo = None; self.url = ""
        self.label = page.ttk.Label(parent, text=title+" — not loaded"); self.label.pack(side="left", padx=8)
        self.title = title

    def clear(self, url=""):
        self.url = url; self.photo = None
        self.label.configure(image="", text=self.title+(" — preview available" if url else " — unavailable"))

    def show(self, data):
        self.photo = self.page.tk.PhotoImage(master=self.page.app.root, data=base64.b64encode(data).decode("ascii"))
        # Keep two profile pictures within the sidebar content width.
        factor = max(1, math.ceil(self.photo.width()/360), math.ceil(self.photo.height()/130))
        if factor > 1: self.photo = self.photo.subsample(factor)
        self.label.configure(image=self.photo, text="")


class Sidebar:
    def __init__(self, app, parent):
        self.app = app; self.closed = False; self.pages = {}; self.current = "Primary"; self.auto_wellness_checked = False; self.auto_resource_checked = False
        self.store = CompanionStore(getattr(app, "companion_store_path", None)); self.log = GameLog()
        from developer_service import DeveloperService, CONTACT_KEY
        self.developer = DeveloperService(app)
        app.developer_service = self.developer
        try: self.developer.configure_contact(self.store.option(CONTACT_KEY, ""))
        except (ValueError, OSError, sqlite3.Error): pass
        from vrcx_companion_service import CompanionService
        try: self.companion = CompanionService(self.store.option("vrcx.companion", None))
        except ValueError: self.companion = CompanionService()
        app.vrcx_companion = self.companion
        self.companion.set_environment(bool(app.demo or getattr(app, 'safe_mode', False)))
        self.companion_event = 0
        from peer_app import PeerApp
        self.peer = PeerApp(app, self.store)
        from client_bridge import ClientBridge
        app.bridge = ClientBridge()
        from ui_preferences import Presentation, PREFERENCE_KEY
        from ui_navigation import NAV_GROUPS
        from sidebar_state import SidebarState, PREFERENCE as SIDEBAR_PREFERENCE
        try:
            self.presentation = Presentation.from_value(self.store.option(PREFERENCE_KEY))
        except (ValueError, OSError, sqlite3.Error):
            self.presentation = Presentation()
        app.presentation = self.presentation
        try: sidebar_value = self.store.option(SIDEBAR_PREFERENCE)
        except (ValueError, OSError, sqlite3.Error): sidebar_value = None
        self.sidebar_state = SidebarState(sidebar_value, self.presentation.mode)
        self._nav_idle = None
        ttk, tk = app.ttk, app.tk
        self.frame = ttk.Frame(parent); self.frame.pack(fill="both", expand=True, pady=(14, 0))
        navigation = ttk.Frame(self.frame, padding=(0, 0, 14, 0)); navigation.pack(side="left", fill="y")
        footer = ttk.Frame(navigation); footer.pack(side="bottom", fill="x", pady=(10, 0))
        self.nav_canvas = tk.Canvas(navigation, background=app.BG, highlightthickness=0, width=202)
        nav_scroll = ttk.Scrollbar(navigation, orient="vertical", command=self.nav_canvas.yview)
        self.nav_canvas.configure(yscrollcommand=nav_scroll.set)
        nav_scroll.pack(side="right", fill="y"); self.nav_canvas.pack(side="left", fill="both", expand=True)
        nav = ttk.Frame(self.nav_canvas, padding=(0, 0, 6, 0))
        nav._eye_scroll_canvas = self.nav_canvas
        self.nav_canvas._eye_scroll_canvas = self.nav_canvas
        nav_item = self.nav_canvas.create_window(0, 0, window=nav, anchor="nw")
        nav.bind("<Configure>", lambda _: self.nav_canvas.configure(scrollregion=self.nav_canvas.bbox("all")))
        self.nav_canvas.bind("<Configure>", lambda event: self.nav_canvas.itemconfigure(nav_item, width=event.width))
        self.selected = tk.StringVar(value="Primary")
        self.buttons, self.nav_groups, self.nav_bodies, self.nav_headings = {}, {}, {}, {}
        self.nav_tools = ttk.Frame(nav)
        self.nav_tools.pack(fill='x', pady=(0, 8))
        ttk.Button(self.nav_tools,text='Global quick search…',style='Quiet.TButton',
                   command=lambda: __import__('quick_search_ui').show(self)).pack(fill='x',pady=2)
        ttk.Button(self.nav_tools,text='Session tools…',style='Quiet.TButton',
                   command=lambda: __import__('mod_tools_ui').show(self)).pack(fill='x',pady=2)
        self.section_controls = {}
        for label, callback in (('Expand all sections', lambda: self.set_sections(True)),
                                ('Collapse all sections', lambda: self.set_sections(False)),
                                ('Reset sidebar sections', self.reset_sections)):
            widget = ttk.Button(self.nav_tools, text=label, style='Quiet.TButton', command=callback)
            widget.pack(fill='x', pady=1)
            self.section_controls[label] = widget
            self._bind_nav_focus(widget)
        for group_index, (group, entries) in enumerate(NAV_GROUPS):
            section = ttk.Frame(nav)
            section.pack(fill="x", pady=(0, 10))
            self.nav_groups[group] = section
            if group_index:ttk.Separator(section, orient="horizontal").pack(fill="x", padx=8, pady=(3, 8))
            heading = ttk.Button(section, style='Disclosure.Nav.TButton', takefocus=True,
                                 command=lambda g=group: self.toggle_section(g))
            heading.pack(fill='x', pady=(4, 5))
            annotate(heading,public=True,description='Expand or collapse this navigation section.')
            self.nav_headings[group] = heading
            self._bind_nav_focus(heading)
            for sequence, value in (('<Left>', False), ('<Right>', True)):
                heading.bind(sequence, lambda event, g=group, v=value: self._disclose_key(g, v))
            for sequence in ('<Return>', '<KP_Enter>', '<space>'):
                heading.bind(sequence, lambda event, g=group: self._disclose_key(g))
            heading.bind('<KeyRelease-space>', lambda event: 'break')
            body = ttk.Frame(section)
            self.nav_bodies[group] = body
            for name, label in entries:
                self.buttons[name] = ttk.Button(body, text=label, style="Nav.TButton", command=lambda n=name: self.show(n))
                annotate(self.buttons[name],public=True)
                self.buttons[name].pack(fill="x", pady=1)
                self._bind_nav_focus(self.buttons[name])
        # Compatibility names refer to the same disclosure, not a second switch.
        self.more_button = self.nav_headings['Advanced']
        self.buttons["Settings"] = ttk.Button(footer, text="Settings", style="Nav.TButton", command=lambda: self.show("Settings"))
        annotate(self.buttons["Settings"],public=True)
        self.buttons["Settings"].pack(fill="x", pady=(0, 5))
        from online_dialog import show_connection_dialog
        ttk.Button(footer, text="VRChat account…", style="Quiet.TButton", command=lambda: show_connection_dialog(app)).pack(fill="x")
        self.account_label = tk.StringVar(value="VRChat: not signed in")
        ttk.Label(footer, textvariable=self.account_label, style="Small.TLabel").pack(anchor="w", padx=10, pady=(5, 0))
        self.bridge_status = tk.StringVar(value="Bridge: disabled")
        self.set_navigation_mode(self.presentation.mode)
        self.content = ttk.Frame(self.frame); self.content.pack(side="left", fill="both", expand=True)
        self.alert_host = ttk.Frame(self.content)
        self.alert_canvas = tk.Canvas(self.alert_host, background=app.BG, highlightthickness=1,
                                      highlightcolor=app.ACCENT, height=1, takefocus=True)
        alert_scroll = ttk.Scrollbar(self.alert_host, orient='vertical', command=self.alert_canvas.yview)
        alert_scroll.pack(side='right', fill='y')
        self.alert_canvas.configure(yscrollcommand=alert_scroll.set)
        self.alert_canvas.pack(side='left', fill='both', expand=True)
        alert = self.alert_body = ttk.Frame(self.alert_canvas)
        alert._eye_scroll_canvas = self.alert_canvas
        self.alert_canvas._eye_scroll_canvas = self.alert_canvas
        alert_item = self.alert_canvas.create_window(0, 0, window=alert, anchor='nw')
        self.alert_canvas.bind('<Configure>', lambda event: self.alert_canvas.itemconfigure(alert_item, width=event.width - 2))
        alert.bind('<Configure>', lambda _: self._layout_alerts())
        self.content.bind('<Configure>', lambda _: self._layout_alerts(), add='+')
        for key, amount, unit in (('<Up>', -1, 'units'), ('<Down>', 1, 'units'),
                                  ('<Prior>', -1, 'pages'), ('<Next>', 1, 'pages')):
            self.alert_canvas.bind(key, lambda event, a=amount, u=unit: self._scroll_alerts(a, u))
        self.alert_canvas.bind('<Home>', lambda _: self._scroll_alerts_edge(0))
        self.alert_canvas.bind('<End>', lambda _: self._scroll_alerts_edge(1))
        self.banner = tk.StringVar(value="")
        self.resource_banner = tk.StringVar(value="")
        self.peer_banner = tk.StringVar(value="")
        self.ui_notice = tk.StringVar(value="")
        self.native_banner = tk.StringVar(value="")
        self.alert_labels = []
        for variable in (self.banner, self.resource_banner, self.peer_banner, self.ui_notice, self.native_banner):
            from ui_theme import responsive_wrap
            label = responsive_wrap(ttk.Label(alert, textvariable=variable, wraplength=900, style="Accent.TLabel"), maximum=1050)
            if variable is not self.native_banner:annotate(label,name='Application alert',role='status',value=variable.get)
            self.alert_labels.append((variable, label))
            variable.trace_add("write", lambda *_: self.refresh_alerts())
        self.primary = ttk.Frame(self.content); self.primary.pack(fill="both", expand=True)
        self.frames = {"Primary": self.primary}
        self.timer = app.root.after(250, self.tick)
        # Sidebar is assigned to app before this callback runs.  Header and the
        # rest of the shell can finish constructing before a restore is offered.
        self._restore_install = app.root.after_idle(self._install_restore)

    def _install_restore(self):
        self._restore_install = None
        if not self.closed:
            from session_restore import install_session_restore
            install_session_restore(self.app)

    def ensure_page(self, name):
        if name not in self.frames:
            from companion_pages import FeedPage, GameLogPage, SearchPage, FavoritesPage, SocialPage
            from wellness_ui import WellnessPage
            from resource_ui import ResourcePage
            from crash_ui import CrashPage
            from unity_ui import UnityPage
            from vrcx_companion_ui import VrcxCompanionPage
            from peer_ui import VrcEyePrimaryPage
            from peer_network_ui import NetworkingPage
            from friendly_ui import HomePage, SettingsPage
            from developer_ui import DeveloperPage
            from creator_projects_ui import CreatorProjectsPage
            from accessibility_ui import AccessibilityPage
            from useful_links_ui import UsefulLinksPage
            from account_workspace_ui import AccountsPage
            from photo_ui import PhotosPage
            from world_visits_ui import WorldVisitsPage
            from release_downloads_ui import SDKDownloadsPage, VCCDownloadsPage, UnityDownloadsPage
            from media_ui import MediaPage
            from customization_ui import CustomizationPage
            from vr_center_ui import VRCenterPage
            classes = {"SDK Downloads": SDKDownloadsPage, "VCC Downloads": VCCDownloadsPage, "World Visits": WorldVisitsPage, "Photos": PhotosPage, "Accounts": AccountsPage, "Creator Projects": CreatorProjectsPage, "Accessibility": AccessibilityPage, "Useful Links": UsefulLinksPage, "Developer": DeveloperPage, "Home": HomePage, "Settings": SettingsPage, "Feed": FeedPage, "Game Log": GameLogPage, "Search": SearchPage, "Favorites": FavoritesPage, "Social": SocialPage, "Wellness": WellnessPage, "Performance & Security": ResourcePage, "Crash & Diagnostics": CrashPage, "Unity Player": UnityPage, "VRCX Companion": VrcxCompanionPage, "VRC Eye Primary": VrcEyePrimaryPage, "Networking": NetworkingPage}
            frame = self.app.ttk.Frame(self.content, padding=(10, 0, 0, 0))
            classes["Media & Audio"] = MediaPage
            classes['Unity Downloads'] = UnityDownloadsPage
            classes['Customization'] = CustomizationPage
            classes['VR Center'] = VRCenterPage
            try: page = classes[name](self, frame)
            except (ValueError, OSError, sqlite3.Error) as error:
                frame.destroy()
                from tkinter import messagebox
                messagebox.showerror(name, str(error), parent=self.app.root); return False
            if name == "Media & Audio":
                from audio_ui import AudioPanel
                page.audio_extension = AudioPanel(page, page.audio_host)
            self.frames[name] = frame; self.pages[name] = page
            experience = getattr(self.app, "experience", None)
            if experience: experience.decorate_page(name, page)
        return True

    def show(self, name):
        self.sync_account_boundary()
        if self.closed or name not in self.buttons or not self.ensure_page(name): return
        self.frames[self.current].pack_forget()
        self.frames[name].pack(fill="both", expand=True)
        self.current = name; self.selected.set(name)
        from ui_navigation import PAGE_GROUP
        self.sidebar_state.visit(PAGE_GROUP.get(name))
        self.refresh_navigation()
        header = getattr(self.app, "account_header", None)
        if header is not None: header.refresh()
        service = getattr(self.app, "player_sessions", None)
        if name == "Primary" and service and not service.demo: service.refresh_local()
        for label, widget in self.buttons.items(): widget.configure(style="Selected.Nav.TButton" if label == name else "Nav.TButton")
        experience = getattr(self.app, "experience", None)
        if experience: experience.page_changed(name)

    def set_navigation_mode(self, mode):
        self.sidebar_state.mode = mode
        self.refresh_navigation()

    def toggle_extra_navigation(self):
        self.toggle_section('Advanced')

    def reveal_advanced(self):
        self.sidebar_state.visit('Advanced')
        self.refresh_navigation()

    def refresh_navigation(self):
        from ui_navigation import PAGE_GROUP,LABELS
        from novelty import owned
        active = PAGE_GROUP.get(self.current)
        scale = getattr(getattr(self.app, 'presentation', None), 'scale', 100)
        percent = getattr(getattr(self.app, 'presentation', None), 'font_percent', 100)
        if percent > 200:scale = max(scale, percent)
        self.nav_canvas.configure(width=round(220 * scale / 100))
        try:
            style = self.app.ttk.Style(self.app.root)
            font = style.lookup('NavSection.TLabel', 'font')
            style.configure('Disclosure.Nav.TButton', font=font, anchor='w')
            style.configure('Active.Disclosure.Nav.TButton', font=font, foreground=self.app.ACCENT, anchor='w')
            style.map('Active.Disclosure.Nav.TButton', foreground=[('active', self.app.ACCENT)])
        except AttributeError:
            pass  # Headless widget fixtures do not own a native style database.
        for group, body in self.nav_bodies.items():
            expanded = self.sidebar_state.expanded(group)
            heading = self.nav_headings[group]
            if expanded:
                body.pack(fill='x')
            else:
                focus = self.app.root.focus_get()
                node = focus
                while node is not None and node is not body:
                    node = getattr(node, 'master', None)
                if node is body:
                    heading.focus_set()
                body.pack_forget()
            heading.configure(text=('- ' if expanded else '+ ') + owned(self.app,group),
                              style='Active.Disclosure.Nav.TButton' if active == group else 'Disclosure.Nav.TButton')
        self.extra_navigation = self.sidebar_state.expanded('Advanced')
        for name,widget in self.buttons.items():widget.configure(text=owned(self.app,LABELS.get(name,name)))
        focus = self.app.root.focus_get()
        navigation_widgets = (*self.nav_headings.values(), *self.buttons.values(), *self.section_controls.values())
        self._schedule_nav_layout(focus if focus in navigation_widgets else None)

    def _save_sections(self):
        if not (self.app.demo or getattr(self.app, 'safe_mode', False)):
            from sidebar_state import PREFERENCE
            try: self.store.set_option(PREFERENCE, self.sidebar_state.record())
            except (ValueError, OSError, sqlite3.Error):
                notice = getattr(self, 'ui_notice', None)
                if notice: notice.set('Sidebar layout changed for this session; it could not be saved.')

    def toggle_section(self, group):
        self.set_section(group, not self.sidebar_state.expanded(group))

    def set_section(self, group, expanded):
        self.sidebar_state.set(group, expanded)
        self.refresh_navigation()
        self._save_sections()

    def set_sections(self, expanded):
        self.sidebar_state.set_all(expanded)
        self.refresh_navigation()
        self._save_sections()

    def reset_sections(self):
        self.sidebar_state.reset()
        self.refresh_navigation()
        self._save_sections()

    def _disclose_key(self, group, expanded=None):
        if expanded is None: self.toggle_section(group)
        else: self.set_section(group, expanded)
        return 'break'

    def _bind_nav_focus(self, widget):
        widget.bind('<FocusIn>', lambda event, w=widget: self._schedule_nav_layout(w), add='+')

    def _schedule_nav_layout(self, widget=None):
        if self.closed: return
        if self._nav_idle:
            self.app.root.after_cancel(self._nav_idle)
        def finish():
            self._nav_idle = None
            if self.closed: return
            self.nav_canvas.configure(scrollregion=self.nav_canvas.bbox('all'))
            if widget is None or self.app.root.focus_get() is not widget: return
            try:
                if not widget.winfo_ismapped(): return
                top = widget.winfo_rooty() - self.nav_canvas.winfo_rooty()
                height = self.nav_canvas.winfo_height()
                bounds = self.nav_canvas.bbox('all')
                if not bounds or bounds[3] <= height: return
                offset = self.nav_canvas.canvasy(0)
                if top < 0: offset += top
                elif top + widget.winfo_height() > height: offset += top + widget.winfo_height() - height
                else: return
                self.nav_canvas.yview_moveto(max(0, offset) / bounds[3])
            except (AttributeError, RuntimeError):
                pass
        self._nav_idle = self.app.root.after_idle(finish)

    def refresh_alerts(self):
        visible = False
        for variable, label in self.alert_labels:
            label.pack_forget()
            if variable.get():
                visible = True
                label.pack(anchor="w", fill="x", pady=(3, 1))
        if visible:
            self.alert_host.pack(side='bottom', fill='x', before=self.frames[self.current])
            self._layout_alerts()
        else:
            if self.app.root.focus_get() is self.alert_canvas:
                keyboard=getattr(self.app,'keyboard',None)
                if keyboard:keyboard.focus_content()
                else:self.frames[self.current].focus_set()
            self.alert_host.pack_forget()

    def _layout_alerts(self):
        # Full notices remain readable by wheel, scrollbar and local keyboard
        # scrolling, without consuming the workspace at larger text scales.
        limit = max(28, min(96, self.content.winfo_height() // 4))
        self.alert_canvas.configure(height=min(self.alert_body.winfo_reqheight(), limit),
                                    scrollregion=self.alert_canvas.bbox('all'))

    def _scroll_alerts(self, amount, unit):
        self.alert_canvas.yview_scroll(amount, unit)
        return 'break'

    def _scroll_alerts_edge(self, fraction):
        self.alert_canvas.yview_moveto(fraction)
        return 'break'

    def ingest(self, batch, events=()):
        service = getattr(self.app, "player_sessions", None)
        if service:
            if getattr(batch,"player_events",()):
                service.ingest(batch.player_events)
                service.adapter.previous=batch.roster
            elif getattr(batch,"roster",None) is not None: service.observe_roster(batch.roster, events)
            service.set_health("RECONCILING" if getattr(batch,"offset",0) < getattr(batch,"size",0) else "LIVE")
        resource = self.pages.get("Performance & Security")
        if resource and not self.app.demo:
            from world_players import log_epoch
            for event in getattr(batch, "player_events", ()):
                if not event.reconstructed:
                    stamp = log_epoch(event.stamp)
                    if stamp is not None: resource.service.context(event.kind, stamp, event.event_id)
        before = self.log.serial if self.log.source == str(batch.source) and not batch.reset else 0
        self.log.add_lines(batch.lines, str(batch.source), batch.reset)
        diagnostics = self.pages.get("Crash & Diagnostics")
        if diagnostics and not self.app.demo: diagnostics.on_events(batch, (item for item in self.log.items if item.serial > before))
        unity = self.pages.get("Unity Player")
        if unity and not self.app.demo: unity.on_logs(batch.source, (item for item in self.log.items if item.serial > before))
        wellness = self.pages.get("Wellness")
        if wellness and not self.app.demo: wellness.on_log_items(item for item in self.log.items if item.serial > before)
        developer = getattr(self, "developer", None)
        if developer:
            for event in list(getattr(batch, "player_events", ()))[:200]:
                developer.recorder.emit("state.player." + event.kind,
                    {"kind": event.kind, "userId": event.user_id, "source": event.source.value,
                     "observed_at": event.stamp, "reconstructed": event.reconstructed,
                     "revision": getattr(service, "revision", None)},
                    environment="Sandbox" if self.app.demo else "Live", origin="Shared player ingest")
        # Historical log events remain in Game Log. API Feed history starts with observed API snapshots.

    def reset_log(self):
        self.log.reset()
        service=getattr(self.app,"player_sessions",None)
        if service:service.set_health("RECONCILING");service.allow_rebuild=True

    def sync_account_boundary(self):
        header = getattr(self.app, "account_header", None)
        if header is not None and header.tick():
            self.account_changed()

    def tick(self):
        if self.closed: return
        self.sync_account_boundary()
        from account_header import private as native_private
        self.app._native_private=native_private(self.app)
        from picture_cache import service_for as pictures_for
        try:pictures_for(self.app)
        except (ValueError,OSError,sqlite3.Error):pass
        rules=getattr(self,'status_rules',None)
        if rules:
            try:rules.tick()
            except (ValueError,APIError,OSError,sqlite3.Error):rules.pause('Paused · status rules need attention. Open Automatic status rules to review.')
        from automatic_sync import sync_for
        try:sync_for(self).tick()
        except (ValueError,APIError,OSError,sqlite3.Error):
            # Stop automatic work if its local publication store cannot settle.
            sync=getattr(self,'automatic_sync',None)
            if sync:sync.close()
            self.native_banner.set('Automatic sync stopped. Check local storage and restart VRC Eye.')
        from spatial_app import install as install_spatial
        spatial = install_spatial(self.app)
        from photo_watch import watcher_for
        photo_page=self.pages.get('Photos')
        watcher=watcher_for(self);desktop=getattr(self,'desktop_service',None)
        background=self.app.root.state() in ('iconic','withdrawn')
        pause_photos=self.app._native_private or bool(photo_page and photo_page.private.get()) or bool(background and desktop and not desktop.policy['background_photos'])
        watcher.set_private(pause_photos)
        watcher.tick(foreground_busy=bool(photo_page and photo_page.job) or pause_photos)
        if getattr(self, "developer", None): self.developer.account_changed()
        blocked = bool(self.app.demo or getattr(self.app, "safe_mode", False))
        self.companion.set_environment(blocked)
        if not blocked: self.companion.start()
        if not getattr(self, "auto_resource_checked", False):
            self.auto_resource_checked = True
            self.ensure_page("Performance & Security")
        if not getattr(self, "auto_crash_checked", False):
            self.auto_crash_checked = True
            self.ensure_page("Crash & Diagnostics")
        if not getattr(self, "auto_unity_checked", False):
            self.auto_unity_checked = True
            self.ensure_page("Unity Player")
        if not self.auto_wellness_checked:
            self.auto_wellness_checked = True
            settings = self.store.option("wellness.settings", {})
            if isinstance(settings, dict) and settings.get("auto_session") is True and not self.app.demo and not getattr(self.app,"safe_mode",False): self.ensure_page("Wellness")
        self.app.bridge.environment(self.app.api.user_id if self.app.api and self.app.api.authenticated else "", bool(self.app.demo))
        bridge = self.app.bridge.state.snapshot()
        self.bridge_status.set("Bridge: connected" if bridge["session"] and bridge["available"] else "Bridge: quarantine" if bridge["session"] else "Bridge: waiting" if self.app.bridge.listener is not None else "Bridge: disabled")
        self.peer.tick()
        if getattr(self, "developer", None): self.developer.bridge_lab.tick()
        from mod_tools import service_for as tools_for
        session_tools=tools_for(self)
        for name,page in tuple(self.pages.items()):
            with session_tools.costs.measure(name):page.guard(page.tick)
        session_tools.tick()
        spatial.tick()
        tracking = getattr(self.app, 'tracking_app', None)
        if tracking is not None: tracking.tick()
        self.coordinate()
        from desktop_service import service_for as desktop_for
        try: desktop_for(self).tick()
        except (ValueError,OSError,sqlite3.Error): self.native_banner.set('Desktop services need attention. Open Desktop controls to review.')
        experience = getattr(self.app, "experience", None)
        if experience: experience.tick()
        self.timer = self.app.root.after(250, self.tick)

    def coordinate(self):
        """Share own-app state and sanitized decisions without coupling providers."""
        unity = self.pages.get('Unity Player')
        if unity:
            snap = unity.service.snapshot()
            self.companion.runtime_boundary((snap['generation'], snap['identity']))
        players = getattr(self.app, 'player_sessions', None)
        prefs = players.settings if players else {}
        social = (prefs.get('notify_friends') or prefs.get('notify_pinned')) and not any(prefs.get(k) for k in ('notifications_muted', 'companion_notifications', 'presentation'))
        desktop=getattr(self,'desktop_service',None);policy=desktop.policy if desktop else {}
        self.companion.set_eye_features({'SOCIAL': 'on' if social else 'off', 'ACCOUNT': 'on' if policy.get('banners') else 'off', 'SESSION': 'off',
            'PRESENCE': 'on' if policy.get('discord') else 'off', 'LAUNCH': 'on' if unity and unity.settings['enabled'] else 'off', 'RESTART': 'on' if policy.get('recover_crashes') else 'off'})
        diagnostics = self.pages.get('Crash & Diagnostics')
        for event in self.companion.snapshot()['events']:
            if event['seq'] <= self.companion_event: continue
            if diagnostics and not self.app.demo:
                diagnostics.service.offer('companion.'+event['kind'], 'vrc_eye', dict(event['payload'], segment=event['generation']))
            self.companion_event = event['seq']

    def account_changed(self):
        from picture_cache import service_for as pictures_for
        try:pictures_for(self.app)
        except (ValueError,OSError,sqlite3.Error):pass
        header = getattr(self.app, "account_header", None)
        if header is not None: header.tick()
        if getattr(self,'automatic_sync',None):self.automatic_sync.sync_context()
        if getattr(self,'status_rules',None):self.status_rules.sync_context()
        if getattr(self,'live_catalog',None):self.live_catalog.sync()
        if getattr(self,'photo_watcher',None):self.photo_watcher.invalidate()
        if getattr(self, "account_actions", None): self.account_actions.invalidate()
        if getattr(self, "developer", None): self.developer.account_changed()
        spatial = getattr(self.app, 'spatial_app', None)
        if spatial is not None: spatial.account_changed()
        tracking = getattr(self.app, 'tracking_app', None)
        if tracking is not None: tracking.account_changed()
        self.peer.account_changed()
        self.app.bridge.environment(self.app.api.user_id if self.app.api and self.app.api.authenticated else "", bool(self.app.demo))
        service = getattr(self.app, "player_sessions", None)
        if service: service.enrich_friends(self.app.api)
        for page in tuple(self.pages.values()):
            page.cancel(); page.account = page.context(); page.guard(page.account_changed)

    def _wait_for_restore_close(self, restore):
        token = (restore, restore.generation)
        if getattr(self, '_restore_abandon', None) == token:
            return True
        started = getattr(self, '_restore_close_started', None)
        if started is None:
            self._restore_close_started = started = time.monotonic()
        if time.monotonic() - started < 20:
            if not getattr(self, '_restore_close_retry', None):
                def retry_restore():
                    self._restore_close_retry = None
                    if not self.closed: self.app.close()
                self._restore_close_retry = self.app.root.after(150, retry_restore)
        else:
            self.ui_notice.set('Saved-session removal is still settling. The app remains open; review Account status before closing again.')
            from tkinter import messagebox
            accepted = messagebox.askyesno('Saved-session removal is not confirmed',
                'Protected storage has not finished responding. Saved-session removal or disable is not confirmed; '
                'the session may remain saved on this computer.\n\nQuit anyway?', parent=self.app.root)
            if accepted and (restore, restore.generation) == token:
                # Consent alone does not cancel the controller. Other close
                # gates must succeed before the terminal abandonment below.
                self._restore_abandon = token
                return True
        return False

    def close(self):
        restore = getattr(self.app, 'session_restore', None)
        if restore is not None and restore.prepare_close() is False:
            if not self._wait_for_restore_close(restore): return False
        restore_retry = getattr(self, '_restore_close_retry', None)
        if restore_retry:
            self.app.root.after_cancel(restore_retry)
            self._restore_close_retry = None
        self._restore_close_started = None
        session_tools=getattr(self,'session_tools',None)
        if session_tools and session_tools.speech:session_tools.speech.stop(discard=True)
        media = self.pages.get("Media & Audio")
        if media and not media.prepare_close():
            self.show("Media & Audio")
            engine = getattr(getattr(media, "audio_extension", None), "engine", None)
            setup = getattr(getattr(media, "audio_extension", None), "job", None)
            active = media.service.active or bool(engine and engine.running) or bool(setup and setup.is_alive())
            failed = getattr(media.service, "cleanup_failed", False) or bool(engine and engine.unreleased_streams)
            if active and not failed and not getattr(self, "_media_close_retry", None):
                def retry():
                    self._media_close_retry = None
                    if not self.closed: self.app.close()
                self._media_close_retry = self.app.root.after(100, retry)
            return False
        retry = getattr(self, "_media_close_retry", None)
        if retry:
            self.app.root.after_cancel(retry)
            self._media_close_retry = None
        wellness = self.pages.get("Wellness")
        if wellness and not wellness.prepare_close(): return False
        # Other close gates may run modal callbacks. Recheck removal at the
        # final boundary before closing the controller or any other services.
        if restore is not None and restore.prepare_close() is False:
            if not self._wait_for_restore_close(restore): return False
            restore.abandon_close()
        if restore is not None and restore.close() is False:
            # The controller normally cannot change here without a Tk turn;
            # keep the window open if a custom provider still reports pending.
            self._wait_for_restore_close(restore)
            return False
        if session_tools:session_tools.close()
        from spatial_app import close as close_spatial
        close_spatial(self.app)
        from tracking_app import close as close_tracking
        close_tracking(self.app)
        experience = getattr(self.app, "experience", None)
        if experience: experience.close()
        self.app.bridge.stop()
        if getattr(self,'desktop_dialog',None):self.desktop_dialog.close()
        if getattr(self,'native_data_dialog',None):self.native_data_dialog.close()
        if getattr(self,'desktop_service',None):self.desktop_service.close()
        if getattr(self,'automatic_sync',None):self.automatic_sync.close()
        if getattr(self,'quick_search_dialog',None):self.quick_search_dialog.close()
        if getattr(self,'picture_cache_dialog',None):self.picture_cache_dialog.close()
        if getattr(self,'picture_cache',None):self.picture_cache.token=None
        if getattr(self,'status_rules_dialog',None):self.status_rules_dialog.close()
        if getattr(self,'status_rules',None):self.status_rules.close()
        self.companion.close()
        self.peer.close()
        if getattr(self, "developer", None): self.developer.close()
        exchange = getattr(self.app, 'vrcx_exchange_dialog', None)
        if exchange: exchange.close()
        local_vrcx = getattr(self.app, 'vrcx_local_dialog', None)
        if local_vrcx: local_vrcx.close()
        dialog = getattr(self.app, "bridge_dialog", None)
        if dialog: dialog.close()
        self.closed = True
        if self._restore_install:
            self.app.root.after_cancel(self._restore_install)
            self._restore_install = None
        if self._nav_idle:
            self.app.root.after_cancel(self._nav_idle)
            self._nav_idle = None
        header = getattr(self.app, "account_header", None)
        if header is not None: header.close()
        if getattr(self,'photo_watcher',None):self.photo_watcher.close()
        try: self.app.root.after_cancel(self.timer)
        except Exception: pass
        for page in tuple(self.pages.values()): page.close()
        return True
