# Development 3 — source integration record

Reviewed 2026-10-03. Both user-supplied archives were treated as local data.
Their programs, build scripts, installers, assemblies and drivers were not run.
The release includes independently implemented Python interoperability, not the
supplied archives or their binaries.

## Inputs

| Archive | ZIP entries | Declared uncompressed bytes | SHA-256 |
| --- | ---: | ---: | --- |
| MelonLoader-0.7.3.zip | 628 | 134,990,138 | `247285390b2beb47aae1c23c5c0f3b333e1a5c2b1a8330afde18c2fa9d8e69c8` |
| OpenVR-SpaceCalibrator-1.5.1.zip | 482 | 8,068,210 | `6586a2f4224da75cdfc02c8f2a58cd99c36287e748df91a4013b16bfae2d9fb7` |

## Attribution and licensing

MelonLoader 0.7.3 is a Lava Gang project, with Apache 2.0 in its main LICENSE.md
and separately licensed dependencies described in NOTICE.txt and its README.
The source declares the version in Directory.Build.props. This integration
implements a bounded reader for its file formats; no loader/runtime code or
binary is included. Upstream: https://github.com/LavaGang/MelonLoader.

SpaceCalibrator profile interoperability was informed by
OpenVR-SpaceCalibrator 1.5.1, the supplied Hyblocker fork. Its main LICENSE credits
2023–2024 Hyblocker and contributors and 2020–2022 Justin Li and contributors under
MIT. Bundled dependency notices have their own terms, including MPL-2.0 Eigen
components. No driver, MinHook code, shared-memory implementation, solver, native
library or asset is included. Upstream: https://github.com/hyblocker/OpenVR-SpaceCalibrator.

## Verified source contracts

Paths are relative to each supplied archive's source root.

| Source | Contract used by VRC Eye |
| --- | --- |
| MelonLoader/LoaderConfig.cs | UserData/Loader.cfg uses TOML with loader, console, logs, mono_debug_server and unityengine sections; launch overrides follow parsing. |
| MelonLoader/Core.cs; Utils/MelonEnvironment.cs; InternalUtils/UnityInformationHandler.cs | Fixed loader/game/runtime/architecture/Unity startup fields; raw command lines and paths are excluded. |
| MelonLoader.Bootstrap/Logging/MelonLogger.cs | Latest.log and archived logs, timestamp framing, warning/error markers. Selected historical logs are read; directory inspection uses Latest.log. |
| MelonLoader Directory.Build.props | Declared version/build targets are source evidence, not proof of an installed or running loader. |
| SpaceCal src/overlay/Configuration.cpp | Root JSON array; stock loader selects element zero. Current-user Config REG_SZ is beneath Software/Classes/Local Settings/Software/OpenVR-SpaceCalibrator. |
| SpaceCal src/overlay/Calibration.cpp | Primary Rz(roll) Ry(yaw) Rx(pitch) uses degrees; saved translation uses centimetres. |
| SpaceCal src/overlay/Configuration.cpp relative_transform | Relative Rx(roll) Ry(yaw) Rz(pitch) uses radians and metre translation. |
| SpaceCal src/driver/ServerTrackedDeviceProvider.cpp; IsometryTransform.h | Scale affects device-local position before its existing driver origin. Offline preview assumes that origin is identity and excludes live blending. |
| SpaceCal src/overlay/VRState.cpp; Calibration.cpp | Pimax Crystal names are synthesized from extra native properties. VRC Eye reports unsupported aliases/candidates rather than guessing a normalized live system. HMD model/serial variations remain candidates. |
| SpaceCal src/common/Protocol.h | Native protocol 4 has mutation requests and a raw pose ring buffer, without a supported read-only current-calibration snapshot. VRC Eye does not open the pipe or shared memory. |
| SpaceCal src/driver/InterfaceHookInjector.cpp | The supplied driver hooks SteamVR pose updates. VRC Eye neither copies nor installs that driver. |

README configuration examples can differ from source defaults, so loader views
show only supported observed declarations. Source/install markers, historical
logs and current device observations remain separate evidence. A filename cannot
prove integrity, compatibility, active loading or the cause of a launch failure.

Independent review caught and corrected digit-bearing loader config keys and
SpaceCal Pimax alias handling before packaging. Pure parser/geometry tests,
injected registry/OpenVR contracts and native Tk checks are included. The exact
clean-build results are recorded in VALIDATION_1_21.md and BUILD_VALIDATION.json.

## EAC design decision

VRChat's published security guidance distinguishes standalone SteamVR tools and
overlays from modified clients:
https://hello.vrchat.com/blog/vrchat-security-update.
The implemented scope uses external selected-file inspection and VRC Eye's
existing OpenVR owner. No VRChat injection, client patch, process-memory access,
loader execution or EAC workaround is provided. This record is not certification
of the build or of third-party programs. Native hardware/platform acceptance is
still required. Official troubleshooting remains an explicit browser handoff.
