"""Native, account-scoped avatar catalog on the existing AvatarStore connection.

This is an observation/inventory layer, not an authentication or asset-access
provider. Provider endpoint/image URLs, cookies and authentication fields are not persisted; user-entered descriptive text may contain links. The legacy creator
records remain untouched and cannot accidentally export the new private rows.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from datetime import datetime, timezone
from urllib.parse import urlsplit

from avatar_creator_store import json_copy, validate_avatar_id
from avatar_details import normalize_avatar_timestamp
from avatar_links import parse_avatar_reference
from companion_data import entity_id

SCHEMA = "vrc-eye-avatar-library-1"
KINDS = frozenset(("avatar", "build", "file", "package", "job", "backfill", "transfer"))
SOURCES = ("Manual entry", "Imported JSON", "VRChat API", "VRCX cache", "Saved search", "Creator workspace")
MAX_ROWS = 30000
MAX_BYTES = 64 * 1024 * 1024
MAX_AVATARS = 5000
MAX_BUILDS = 1000
PAGE_SIZE = 48
_TABLE = "avatar_library_120_records"
_PLATFORMS = {"standalonewindows": "PC", "windows": "PC", "pc": "PC", "android": "Android", "quest": "Android", "ios": "iOS"}
_HEX = re.compile(r"[a-f0-9]{64}\Z")


def scope_id(account=""):
    """Empty is an explicitly separate local workspace, never another account."""
    return "local" if account in (None, "", "local") else entity_id("user", account)


def active_scope(app):
    client = getattr(app, "api", None)
    return entity_id("user", getattr(client, "user_id", "")) if getattr(client, "authenticated", False) else "local"


def context_token(app):
    client = getattr(app, "api", None)
    # A context marker is observational, not authorization. Existing search may
    # open during incomplete authentication; validate the ID only when selecting
    # the actual catalog scope (active_scope), never weaken that write boundary.
    return (id(client), bool(getattr(client, "authenticated", False)),
            getattr(client, "user_id", ""), getattr(client, "session_revision", 0),
            getattr(app, "data_generation", 0), bool(getattr(app, "demo", False)),
            bool(getattr(app, "safe_mode", False)))


def stamp(clock=time.time):
    return datetime.fromtimestamp(clock(), timezone.utc).isoformat(timespec="seconds")


def text(value, limit=512, default=""):
    if value is None:
        return default
    if not isinstance(value, str):
        raise ValueError("A catalog text field must be a string.")
    if len(value) > limit or any(ord(c) < 32 and c not in "\n\t" for c in value):
        raise ValueError("A catalog text field is too long or contains control characters.")
    # Reject surrogate code points rather than losing characters during encoding.
    try:
        value.encode("utf-8")
    except UnicodeError as error:
        raise ValueError("Catalog text must be valid Unicode.") from error
    return value.strip()


def scalar(value, limit=100):
    if type(value) is int and 0 <= value <= 2**53 - 1:
        return str(value)
    return text(value, limit)


def decode_document(data):
    if not isinstance(data, (bytes, str)):
        raise ValueError("Select a UTF-8 JSON document.")
    if len(data if isinstance(data, bytes) else data.encode("utf-8")) > 2 * 1024 * 1024:
        raise ValueError("Avatar metadata imports are limited to 2 MiB.")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON field names are not supported.")
            result[key] = value
        return result
    def constant(_):
        raise ValueError("Non-finite JSON values are not supported.")
    try:
        result = json.loads(data.decode("utf-8-sig") if isinstance(data, bytes) else data,
                            object_pairs_hook=pairs, parse_constant=constant)
    except (UnicodeError, RecursionError, TypeError) as error:
        raise ValueError("The metadata must be a bounded UTF-8 JSON object.") from error
    if not isinstance(result, dict):
        raise ValueError("Import one avatar object, not a list of accounts or an executable profile.")
    return result


def build_identity(package):
    """Identify evidence without retaining signed URLs or manufacturing history."""
    if not isinstance(package, dict):
        raise ValueError("Build observations must be objects.")
    raw_platform = text(package.get("platform"), 80)
    platform = _PLATFORMS.get(raw_platform.casefold(), raw_platform or "Unknown")
    build = {"platform": platform, "unity": scalar(package.get("unityVersion")),
             "asset_version": scalar(package.get("assetVersion")),
             "variant": scalar(package.get("variant"), 80) or "Unknown",
             "created_at": normalize_avatar_timestamp(package.get("created_at")),
             "file_id": "", "file_version": "", "locator_fingerprint": ""}
    raw_url = package.get("assetUrl")
    if isinstance(raw_url, str) and raw_url:
        from vrca_files import VRCAError, validate_asset_url
        try:
            parts = urlsplit(validate_asset_url(raw_url))
        except (VRCAError, ValueError):
            pass
        else:
            match = re.search(r"/file/(file_[a-fA-F0-9-]+)/([1-9][0-9]*)/file/?$", parts.path)
            if match:
                try:
                    build["file_id"] = "file_" + str(uuid.UUID(match[1][5:]))
                    build["file_version"] = match[2]
                except ValueError:
                    pass
            # This is only a locator fingerprint, not a digest of avatar bytes.
            build["locator_fingerprint"] = hashlib.sha256((parts.hostname + parts.path).encode()).hexdigest()
    if not build["file_id"]:
        supplied = package.get("fileId")
        if isinstance(supplied, str):
            try: build["file_id"] = "file_" + str(uuid.UUID(supplied.removeprefix("file_")))
            except ValueError: pass
        build["file_version"] = scalar(package.get("fileVersion"))
    identity = {k: v for k, v in build.items() if k != "created_at"}
    build["id"] = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    build["identity_evidence"] = ("File revision" if build["file_id"] and build["file_version"] else
                                  "Locator and descriptors" if build["locator_fingerprint"] else
                                  "Descriptors only; distinct unnamed builds may be indistinguishable")
    return build


def normalize_observation(document, source="Imported JSON"):
    if source not in SOURCES or not isinstance(document, dict):
        raise ValueError("Choose a supported metadata observation source.")
    raw_id = document.get("id", "")
    avatar = validate_avatar_id(raw_id) if isinstance(raw_id, str) and raw_id.startswith("local:") else parse_avatar_reference(raw_id)
    metadata = {"id": avatar}
    for incoming, target, limit in (("name", "name", 512), ("authorName", "author", 512),
                                    ("description", "description", 16000)):
        if incoming in document:
            metadata[target] = text(document[incoming], limit)
    if "authorId" in document:
        value = document["authorId"]
        metadata["author_id"] = entity_id("user", value) if value else ""
    if "releaseStatus" in document:
        value = text(document["releaseStatus"], 64).casefold()
        metadata["visibility"] = value if value in ("public", "private", "hidden", "unavailable") else "unknown"
    for key in ("created_at", "updated_at"):
        if key in document:
            metadata[key] = normalize_avatar_timestamp(document[key])
    if "tags" in document:
        if not isinstance(document["tags"], list) or len(document["tags"]) > 100:
            raise ValueError("Avatar tags must be a list of at most 100 strings.")
        metadata["tags"] = list(dict.fromkeys(text(x, 128) for x in document["tags"]))
    if "version" in document:
        metadata["version"] = scalar(document["version"])
    packages = document.get("unityPackages", [])
    if packages is None:
        packages = []
    if not isinstance(packages, list) or len(packages) > MAX_BUILDS:
        raise ValueError("An observation is limited to 1,000 build descriptors.")
    unique = {}
    for package in packages:
        build = build_identity(package)
        unique[build["id"]] = build
    builds = list(unique.values())
    if "unityPackages" in document:
        metadata["platforms"] = sorted({b["platform"] for b in builds})
        metadata["current_builds"] = list(unique)
    image = ""
    for key in ("thumbnailImageUrl", "imageUrl"):
        value = document.get(key)
        if not value:
            continue
        from profile_images import image_url
        from vrchat_api import APIError
        try: image = image_url(value)
        except (APIError, ValueError, TypeError): continue
        break
    return {"metadata": json_copy(metadata), "builds": json_copy(builds, require_dict=False),
            "source": source, "preview_url": image}


def document_from_item(item):
    """Reuse already loaded search evidence; never issue an additional request."""
    lookup = getattr(item, "lookup", None)
    data = dict(getattr(lookup, "details", None) or {})
    data.update(id=item.avatar_id, name=item.name, authorName=item.author,
                releaseStatus=item.visibility.casefold())
    metadata = getattr(lookup, "metadata", None)
    if metadata:
        data.update(created_at=metadata.created_at, updated_at=metadata.updated_at)
    export = getattr(lookup, "export", None)
    if export is not None:
        data["unityPackages"] = [{"platform": c.platform, "unityVersion": c.unity_version,
                                  "assetVersion": c.asset_version, "variant": c.variant,
                                  "assetUrl": c.url} for c in export.choices]
    elif item.platforms:
        data["unityPackages"] = [{"platform": p} for p in item.platforms]
    return data


class AvatarLibrary:
    """A scoped view of new records in the pre-existing AvatarStore database."""
    def __init__(self, store, *, max_rows=MAX_ROWS, max_bytes=MAX_BYTES, clock=time.time):
        if type(max_rows) is not int or not 1 <= max_rows <= MAX_ROWS:
            raise ValueError("Invalid avatar catalog record limit.")
        if type(max_bytes) is not int or not 1 <= max_bytes <= MAX_BYTES:
            raise ValueError("Invalid avatar catalog byte limit.")
        self.store, self.clock = store, clock
        self.max_rows, self.max_bytes = max_rows, max_bytes
        self.revision = 0
        self.boot_id = str(uuid.uuid4())
        with store._transaction() as db:
            db.execute(f"""CREATE TABLE IF NOT EXISTS {_TABLE}(
                scope TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL,
                avatar_id TEXT NOT NULL, data TEXT NOT NULL, data_bytes INTEGER NOT NULL,
                updated TEXT NOT NULL, PRIMARY KEY(scope,kind,id))""")
            db.execute(f"CREATE INDEX IF NOT EXISTS avatar_library_120_context ON {_TABLE}(scope,kind,avatar_id,updated)")

    def _put(self, db, scope, kind, identifier, avatar, data):
        if kind not in KINDS:
            raise ValueError("Unknown avatar library record kind.")
        clean = json_copy(data)
        raw = json.dumps(clean, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        size = len(raw.encode("utf-8"))
        old = db.execute(f"SELECT data_bytes FROM {_TABLE} WHERE scope=? AND kind=? AND id=?", (scope, kind, identifier)).fetchone()
        count, total = db.execute(f"SELECT count(*),coalesce(sum(data_bytes),0) FROM {_TABLE}").fetchone()
        if count + (0 if old else 1) > self.max_rows or total - (old[0] if old else 0) + size > self.max_bytes:
            raise ValueError("Avatar catalog is full. Explicitly forget unneeded records; nothing was automatically deleted.")
        db.execute(f"INSERT INTO {_TABLE} VALUES(?,?,?,?,?,?,?) ON CONFLICT(scope,kind,id) DO UPDATE SET data=excluded.data,data_bytes=excluded.data_bytes,updated=excluded.updated",
                   (scope, kind, identifier, avatar, raw, size, stamp(self.clock)))
        return clean

    @staticmethod
    def _load(db, scope, kind, identifier):
        row = db.execute(f"SELECT data FROM {_TABLE} WHERE scope=? AND kind=? AND id=?", (scope, kind, identifier)).fetchone()
        return json.loads(row[0]) if row else None

    def get(self, scope, avatar):
        return self.record(scope, "avatar", validate_avatar_id(avatar))

    def record(self, scope, kind, identifier):
        scope = scope_id(scope)
        if kind not in KINDS:
            raise ValueError("Unknown catalog record kind.")
        with self.store._lock:
            if self.store._closed:
                raise RuntimeError("The avatar workspace is closed.")
            result=self._load(self.store._db, scope, kind, identifier)
        if kind=='avatar' and getattr(self,'native',None):
            from native_legacy import avatar_projection,merge_avatar
            result=merge_avatar(avatar_projection(self.native,scope,identifier),result)
        return result

    def _observe_into(self, db, scope, observation, source, now):
        """Apply one normalized observation within the caller's transaction."""
        avatar = observation["metadata"]["id"]
        old = self._load(db, scope, "avatar", avatar)
        if old is None:
            count = db.execute(f"SELECT count(*) FROM {_TABLE} WHERE kind='avatar' AND scope=?", (scope,)).fetchone()[0]
            if count >= MAX_AVATARS:
                raise ValueError("This workspace is limited to 5,000 catalog avatars.")
        row = old or {"id": avatar, "name": "", "author": "", "author_id": "", "description": "", "visibility": "unknown",
                      "platforms": [], "tags": [], "favorite": False, "notes": "", "first_seen": now,
                      "field_evidence": {}, "sources": [], "history": [], "thumbnail": ""}
        changes = {k: {"before": row.get(k), "after": v} for k, v in observation["metadata"].items()
                   if k != "id" and row.get(k) != v}
        row.update(observation["metadata"])
        for key in observation["metadata"]:
            row["field_evidence"][key] = {"source": source, "observed_at": now}
        row["source"], row["last_seen"] = source, now
        row["sources"] = list(dict.fromkeys(row["sources"] + [source]))
        if changes:
            # Descriptive snapshots only; no endpoint URLs or raw source objects.
            row["history"] = (row["history"] + [{"at": now, "source": source, "fields": sorted(changes)}])[-50:]
        self._put(db, scope, "avatar", avatar, avatar, row)
        existing_builds = db.execute(f"SELECT count(*) FROM {_TABLE} WHERE scope=? AND kind='build' AND avatar_id=?", (scope, avatar)).fetchone()[0]
        for build in observation["builds"]:
            key = hashlib.sha256((avatar + build["id"]).encode()).hexdigest()
            prior = self._load(db, scope, "build", key)
            if prior is None:
                existing_builds += 1
                if existing_builds > MAX_BUILDS:
                    raise ValueError("This avatar has reached its 1,000 observed-build limit.")
            item = dict(build, id=key, descriptor_id=build["id"], avatar_id=avatar,
                        first_seen=prior["first_seen"] if prior else now, last_seen=now,
                        source=source, sources=list(dict.fromkeys((prior or {}).get("sources", []) + [source])))
            self._put(db, scope, "build", key, avatar, item)
        return json_copy(row)

    def observe(self, scope, document, source="Imported JSON"):
        observation = normalize_observation(document, source)
        scope = scope_id(scope)
        with self.store._transaction() as db:
            row = self._observe_into(db, scope, observation, source, stamp(self.clock))
        self.revision += 1
        return row

    def observe_batch(self, scope, documents, source="Imported JSON", *, expected=None, stop=None):
        """All-or-nothing reviewed import; protect current rows from stale reviews.

        expected uses canonical JSON of each full prior row, or None for a new ID.
        Private notes/favorites/previews are carried by the shared observation path.
        """
        from avatar_library_files import check_cancel
        scope = scope_id(scope)
        if not isinstance(documents, (list, tuple)) or not 1 <= len(documents) <= 500:
            raise ValueError("Bulk imports require between 1 and 500 avatar objects.")
        check_cancel(stop)
        try:
            raw = json.dumps(documents, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
        except (TypeError, UnicodeError, RecursionError) as error:
            raise ValueError("Bulk metadata must be bounded JSON data.") from error
        if len(raw) > 8 * 1024 * 1024:
            raise ValueError("Bulk metadata is limited to 8 MiB.")
        observations = []
        build_count = 0
        for document in documents:
            check_cancel(stop)
            item = normalize_observation(document, source)
            build_count += len(item["builds"])
            if build_count > 2048:
                raise ValueError("A bulk import is limited to 2,048 build observations.")
            observations.append(item)
        identifiers = [item["metadata"]["id"] for item in observations]
        if len(set(identifiers)) != len(identifiers):
            raise ValueError("Bulk imports cannot contain duplicate avatar identities.")
        if expected is not None and (not isinstance(expected, dict) or set(expected) != set(identifiers)
                or any(value is not None and not isinstance(value, str) for value in expected.values())):
            raise ValueError("The reviewed prior-state evidence does not match this import.")
        rows = []
        with self.store._transaction() as db:
            check_cancel(stop)
            if expected is not None:
                for identifier in identifiers:
                    current = self._load(db, scope, "avatar", identifier)
                    canonical = None if current is None else json.dumps(current, sort_keys=True,
                        separators=(",", ":"), ensure_ascii=False, allow_nan=False)
                    if canonical != expected[identifier]:
                        raise ValueError("The catalog changed after review. Inspect and review the import again.")
            now = stamp(self.clock)
            for item in observations:
                check_cancel(stop)
                rows.append(self._observe_into(db, scope, item, source, now))
            check_cancel(stop)
        self.revision += 1
        return rows

    def records(self, scope, kind, avatar=None, *, limit=1000):
        scope = scope_id(scope)
        if kind not in KINDS or type(limit) is not int or not 1 <= limit <= MAX_ROWS:
            raise ValueError("Invalid catalog record query.")
        clause, params = "scope=? AND kind=?", [scope, kind]
        if avatar is not None:
            clause += " AND avatar_id=?"
            params.append(validate_avatar_id(avatar))
        with self.store._lock:
            if self.store._closed:
                raise RuntimeError("The avatar workspace is closed.")
            rows = self.store._db.execute(f"SELECT data FROM {_TABLE} WHERE {clause} ORDER BY updated DESC,id LIMIT ?", (*params, limit)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def list(self, scope, *, query="", platform="All", visibility="All", favorite=False,
             local_files=False, source="All", after="", before="", sort="Name", offset=0, limit=PAGE_SIZE):
        scope = scope_id(scope)
        query = text(query, 512).casefold()
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 96:
            raise ValueError("Invalid avatar catalog page.")
        for date in (after, before):
            if date and (not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date) or not normalize_avatar_timestamp(date)):
                raise ValueError("Date filters use YYYY-MM-DD.")
        if after and before and after > before:
            raise ValueError("The first date must not be after the last date.")
        rows = self.records(scope, "avatar", limit=MAX_AVATARS)
        if getattr(self,'native',None):
            from native_legacy import avatar_projection,merge_avatar
            known={r['id']:r for r in rows};offset_native=0
            while True:
                native_rows,total_native=self.native.rows(scope,'entity',offset=offset_native,limit=1000)
                for record in native_rows:
                    if record['data'].get('entity_kind')=='avatar':
                        ref=record['data']['entity_id'];known[ref]=merge_avatar(avatar_projection(self.native,scope,ref),known.get(ref))
                offset_native+=len(native_rows)
                if not native_rows or offset_native>=total_native:break
            rows=list(known.values())
        file_avatars = {r["avatar_id"] for r in self.records(scope, "file", limit=MAX_ROWS) if r.get("role") != "preview"} if local_files else set()
        filtered = []
        for r in rows:
            haystack = " ".join([r["id"], r.get("name", ""), r.get("author", ""), r.get("author_id", ""),
                                  r.get("description", ""), " ".join(r.get("tags", [])), ' '.join(r.get('local_tags',[])),r.get('notes','')]).casefold()
            day = r.get("updated_at") or ""
            if query and not all(term in haystack for term in query.split()): continue
            if platform != "All" and platform not in r.get("platforms", []): continue
            if visibility != "All" and r.get("visibility", "unknown") != visibility.casefold(): continue
            if favorite and not r.get("favorite"): continue
            if local_files and r["id"] not in file_avatars: continue
            if source != "All" and source not in r.get("sources", []): continue
            if (after or before) and not day: continue
            if after and day[:10] < after: continue
            if before and day[:10] > before: continue
            filtered.append(r)
        if sort == "Name": filtered.sort(key=lambda r: (r.get("name", "").casefold(), r["id"]))
        elif sort == "Last observed": filtered.sort(key=lambda r: (r.get("last_seen", ""), r["id"]), reverse=True)
        elif sort == "Updated": filtered.sort(key=lambda r: (r.get("updated_at") or "", r["id"]), reverse=True)
        else: raise ValueError("Choose Name, Last observed or Updated ordering.")
        return {"items": filtered[offset:offset+limit], "total": len(filtered), "offset": offset,
                "has_more": offset + limit < len(filtered)}

    def note_view(self,scope,avatar):
        import shared_notes
        def earlier():
            with self.store._lock:row=self._load(self.store._db,scope_id(scope),'avatar',avatar)
            return {'Earlier avatar catalog note':(row or {}).get('notes','')}
        return shared_notes.read(self.native,scope,'avatar',avatar,legacy=earlier()),earlier

    def edit_local(self, scope, avatar, *, favorite=None, notes=None, thumbnail=None, notes_view=None, reconcile=False, guard=lambda:None):
        scope, avatar = scope_id(scope), validate_avatar_id(avatar)
        if notes is not None and getattr(self,'native',None) is not None and not avatar.startswith('local:'):
            if favorite is not None or thumbnail is not None:raise ValueError('Save shared notes separately from favorite or thumbnail changes.')
            import shared_notes
            view,earlier=self.note_view(scope,avatar)
            view=notes_view or view
            if view.scope!=shared_notes.scope(scope) or view.ref!=avatar:raise ValueError('Notes belong to a different avatar workspace.')
            shared_notes.save(self.native,view,notes,legacy_now=earlier,reconcile=reconcile,guard=guard)
            self.revision+=1
            return
        projected=self.get(scope,avatar)
        with self.store._transaction() as db:
            row = self._load(db, scope, "avatar", avatar) or projected
            if row is None: raise ValueError("This avatar is not in the current catalog scope.")
            if favorite is not None:
                if type(favorite) is not bool: raise ValueError("The favorite setting must be true or false.")
                row["favorite"] = favorite
            if notes is not None: row["notes"] = text(notes, 16000)
            if thumbnail is not None:
                # Only PNG data generated by the bounded preview decoder enters here.
                import base64
                if not isinstance(thumbnail, str) or len(thumbnail) > 180000:
                    raise ValueError("The saved thumbnail is too large.")
                if thumbnail:
                    try: raw = base64.b64decode(thumbnail, validate=True)
                    except (ValueError, TypeError) as error: raise ValueError("Invalid thumbnail encoding.") from error
                    from avatar_library_files import image_preview
                    thumbnail = base64.b64encode(image_preview(raw, (220, 140))).decode("ascii")
                row["thumbnail"] = thumbnail
            self._put(db, scope, "avatar", avatar, avatar, row)
        self.revision += 1
        return row

    def register_file(self, scope, avatar, evidence, *, build_id="", role="asset", provenance="User-authorized local file", before_commit=None):
        scope, avatar = scope_id(scope), validate_avatar_id(avatar)
        if role not in ("asset", "preview", "source", "package"):
            raise ValueError("Choose a known local file role.")
        if before_commit is not None and not callable(before_commit):
            raise ValueError("The file validation callback must be callable.")
        from avatar_library_files import validate_evidence
        evidence = validate_evidence(evidence)
        with self.store._transaction() as db:
            row = self._register_file_into(db, scope, avatar, evidence, build_id=build_id, role=role, provenance=provenance)
            if before_commit is not None: before_commit()
        self.revision += 1
        return row

    def _register_file_into(self, db, scope, avatar, evidence, *, build_id='', role='asset', provenance='User-authorized local file'):
        """Shared registration inside an owner-held transaction, including batch receipts."""
        from avatar_library_files import validate_evidence
        scope,avatar=scope_id(scope),validate_avatar_id(avatar);evidence=validate_evidence(evidence)
        if role not in ('asset','preview','source','package'):raise ValueError('Choose a known local file role.')
        now=stamp(self.clock)
        identifier=str(uuid.uuid5(uuid.NAMESPACE_URL,'vrc-eye-file:'+avatar+':'+build_id+':'+evidence['path']+':'+role))
        if self._load(db,scope,'avatar',avatar) is None:raise ValueError("Choose an avatar from this account's catalog first.")
        if build_id:
            build=self._load(db,scope,'build',build_id)
            if not build or build['avatar_id']!=avatar:raise ValueError('The build belongs to a different avatar or account.')
        old=self._load(db,scope,'file',identifier)
        row=dict(evidence,id=identifier,avatar_id=avatar,build_id=build_id,role=role,provenance=text(provenance,160),
                 first_seen=old['first_seen'] if old else now,checked_at=now,availability='Recorded',previous_digests=(old or {}).get('previous_digests',[]))
        if old and old['sha256']!=evidence['sha256']:row['previous_digests']=(row['previous_digests']+[old['sha256']])[-10:]
        self._put(db,scope,'file',identifier,avatar,row)
        return row

    def update_file_check(self, scope, identifier, result):
        scope = scope_id(scope)
        state = result.get("availability")
        if state not in ("Matches recorded bytes", "Changed", "Unavailable", "Unreadable"):
            raise ValueError("Unknown file-check state.")
        with self.store._transaction() as db:
            row = self._load(db, scope, "file", identifier)
            if not row: raise ValueError("This file record was removed.")
            if result.get("expected_sha256") != row["sha256"]:
                raise ValueError("The file reference changed while it was being checked.")
            row["availability"], row["checked_at"] = state, stamp(self.clock)
            row["observed_sha256"] = result.get("observed_sha256", "")
            self._put(db, scope, "file", identifier, row["avatar_id"], row)
        self.revision += 1

    def save_package(self, scope, avatar, report):
        scope, avatar = scope_id(scope), validate_avatar_id(avatar)
        clean = json_copy(report)
        if clean.get("schema") != "vrc-eye-package-inspection-1" or not _HEX.fullmatch(clean.get("sha256", "")):
            raise ValueError("Expected a bounded package-inspection report.")
        identifier = str(uuid.uuid5(uuid.NAMESPACE_URL, "vrc-eye-package:" + avatar + ":" + clean["path"]))
        clean.update(id=identifier, avatar_id=avatar, inspected_at=stamp(self.clock))
        with self.store._transaction() as db:
            if not self._load(db, scope, "avatar", avatar): raise ValueError("Choose an avatar in this scope.")
            self._put(db, scope, "package", identifier, avatar, clean)
        self.revision += 1
        return clean

    def duplicates(self, scope, kind="file"):
        if kind not in ("file", "package"): raise ValueError("Duplicate checks support files and packages.")
        groups = {}
        for row in self.records(scope, kind, limit=MAX_ROWS):
            groups.setdefault(row["sha256"], []).append({"id": row["id"], "avatar_id": row["avatar_id"], "name": row.get("name", "")})
        return {key: value for key, value in groups.items() if len(value) > 1}

    def forget(self, scope, kind, identifier):
        scope = scope_id(scope)
        if kind not in ("avatar", "file", "package"):
            raise ValueError("Only catalog avatars, file references and package reports can be forgotten here.")
        with self.store._transaction() as db:
            if kind == "avatar":
                live = db.execute(f"SELECT data FROM {_TABLE} WHERE scope=? AND avatar_id=? AND kind='job'", (scope, identifier)).fetchall()
                if any(json.loads(x[0]).get("state") in ("Running", "Prepared") and json.loads(x[0]).get("boot_id") == self.boot_id for x in live):
                    raise ValueError("Cancel or finish this avatar's job before removing its records.")
                # Retain job receipts so a copy outcome remains reviewable.
                db.execute(f"DELETE FROM {_TABLE} WHERE scope=? AND avatar_id=? AND kind NOT IN ('job','backfill','transfer')", (scope, identifier))
            else:
                row = self._load(db, scope, kind, identifier)
                db.execute(f"DELETE FROM {_TABLE} WHERE scope=? AND kind=? AND id=?", (scope, kind, identifier))
                if kind == "file" and row and row.get("role") == "preview":
                    avatar = self._load(db, scope, "avatar", row["avatar_id"])
                    if avatar:
                        avatar["thumbnail"] = ""
                        self._put(db, scope, "avatar", avatar["id"], avatar["id"], avatar)
        if kind=='avatar' and getattr(self,'native',None):self.native.forget(scope,'entity','avatar:'+identifier)
        self.revision += 1

    def begin_job(self, scope, avatar, operation, *, destination=""):
        scope, avatar = scope_id(scope), validate_avatar_id(avatar)
        row = {"id": str(uuid.uuid4()), "avatar_id": avatar, "operation": text(operation, 100),
               "state": "Running", "started_at": stamp(self.clock), "finished_at": "", "boot_id": self.boot_id,
               "destination": text(destination, 8192), "message": ""}
        with self.store._transaction() as db:
            if not self._load(db, scope, "avatar", avatar): raise ValueError("Choose a catalog avatar first.")
            self._put(db, scope, "job", row["id"], avatar, row)
        self.revision += 1
        return row["id"]

    def finish_job(self, scope, identifier, state, message=""):
        scope = scope_id(scope)
        if state not in ("Complete", "Cancelled", "Failed", "Needs review"):
            raise ValueError("Unknown job outcome.")
        with self.store._transaction() as db:
            row = self._load(db, scope, "job", identifier)
            if not row: raise ValueError("Missing job receipt.")
            row.update(state=state, message=text(message, 1000), finished_at=stamp(self.clock))
            self._put(db, scope, "job", identifier, row["avatar_id"], row)
        self.revision += 1

    def jobs(self, scope, avatar=None):
        rows = self.records(scope, "job", avatar, limit=200)
        for row in rows:
            if row["state"] in ("Running", "Prepared") and row.get("boot_id") != self.boot_id:
                row["state"] = "Interrupted / outcome unverified"
                row["message"] = "Inspect the recorded destination. No automatic retry or deletion."
        return rows

    def export(self, scope, avatars):
        """Allowlisted, selected-data-only report; excludes images, notes and URLs."""
        if not isinstance(avatars, (list, tuple)) or not 1 <= len(avatars) <= 100:
            raise ValueError("Select 1–100 avatars for one report.")
        scope = scope_id(scope)
        output = []
        for avatar in dict.fromkeys(avatars):
            row = self.get(scope, avatar)
            if row is None: raise ValueError("An export selection is not in this account's library.")
            # Human-entered names still require review: the report is not anonymized.
            record = {k: row.get(k) for k in ("id", "name", "author", "visibility", "platforms", "first_seen", "last_seen", "source")}
            record["builds"] = [{k: b.get(k) for k in ("platform", "unity", "asset_version", "variant", "first_seen", "last_seen", "identity_evidence")}
                                for b in self.records(scope, "build", avatar)]
            record["files"] = [{k: f.get(k) for k in ("role", "sha256", "size", "availability", "checked_at")}
                               for f in self.records(scope, "file", avatar)]
            record["packages"] = [{k: p.get(k) for k in ("sha256", "size", "shader_count", "material_count", "inspected_at")}
                                  for p in self.records(scope, "package", avatar)]
            output.append(record)
        from avatar_creator_store import sanitize_export
        return {"schema": SCHEMA, "exported_at": stamp(self.clock),
                "privacy": "Selected records only. Names and avatar IDs remain; review before sharing. Local paths, account IDs, descriptions, notes, thumbnails, endpoints and raw manifests are excluded.",
                "avatars": sanitize_export(output)}
