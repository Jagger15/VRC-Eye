# Selective VCC integration — Development checkpoint 1

## What is implemented, and what is not

VRC Eye coordinates a **local project workspace** and a deliberately restricted
installed-tool adapter. It is not VCC, not an authenticated VCC bridge, and not a
replacement package resolver. VCC and Unity are not bundled. No VRChat sign-in is
required for local catalog work. Demo/Safe Mode permits viewing but blocks new
catalog writes and tool execution.

Discovery, inventory, real copy jobs, strict reports and native UI flows are tested
locally. CLI argument generation and outcome handling have fixture tests. A real
installed VPM or Unity editor was **not** exercised. Windows/Mac tool-launch behavior,
OS process-tree termination, SDK compilation and runtime package compatibility
need native tests. The Editor Core source package is a development preview.

## Opening the workspace

Select Advanced view, then **Advanced → Creator Projects (VCC)**. It is also
reachable from Ctrl+K in any presentation view. Inside the page, use the workspace
selector to choose Projects, Inventory, Reviewed changes, Templates & tools, or
Activity. Changing presentation does not grant account or transport permissions.

### Add and discover

Add project selects one root. Discover in folder examines only the selected
parent, with a depth/entry limit; partial results are labeled. Import VCC path list
reads only the documented `userProjects` path array from a settings file you
choose. It does not import VCC repository headers, credentials, global settings,
account state or licenses. Unsupported schemas require explicit folder selection.
Review the candidate list before catalog inspection. No drive-wide scan occurs.

Locations must be absolute native paths. Linux/Proton Windows paths are not guessed:
select the actual mounted path. Symbolic links, junctions/reparse points and
unavailable paths are distinguished. Missing projects retain their identity and
last observed inventory. Discovery is limited to 5,000 examined entries, three
folder levels and 256 projects per scan; choose a narrower folder for more.

### Inventory and association

Inspection reads bounded project-version, UPM/VPM and direct embedded-package
manifests, not executable code or Unity's Library cache. Requested, locked and
embedded versions remain separate fields. A UPM lock entry does not establish
that its cache is installed. A matching VPM embedded manifest is evidence, not a
successful build. Malformed files, missing locks, mismatches and mixed SDKs are
review states, not automatically repaired. Read observations are not a filesystem
transaction against a concurrently changing Unity project.

Avatar/world links are deliberate local associations, scoped to the selected
VRC Eye account or the signed-out local workspace. They neither prove ownership
nor unlock creator operations. The main project list itself is an OS-user-local
filesystem catalog. Full multi-account isolation remains a separate workstream.

Forget removes the catalog record and links, **not files or receipts**. Inventory
exports omit paths, account links, repository URLs and raw manifests. Package
names/versions and inspection issues still reveal something about the project;
review before sharing. Activity/disk receipts are local records, not sanitized
public reports. Local project paths are visible in this workspace; automatic
streamer-screen redaction of the new project UI is not complete. Do not assume
those local views are safe to screen-share merely because an exported inventory
report omits paths.

## Review an installed VPM CLI

Under Templates & tools, select the actual installed `vpm` / `vpm.exe`. The review
explains that executing an installed binary is a trust decision. VRC Eye requests
help and version output with bounded subprocess execution. A name or digest is
**not publisher authentication**. The executable digest binds this review to that
selected file only; an external .NET shim's dependencies/runtime/store are not
fully integrity-attested. Capability detection from help is advisory and does not
replace an end-to-end test with the installed version.

Nothing automatically installs or updates .NET, VPM, Unity Hub, VCC, SDK packages
or templates. The app does not call VPM's `check unity`, because the official
command can update VPM settings. Use VCC's own setup for missing requirements.
No `vrc-get` adapter is implemented in this checkpoint.

## Reviewed changes on new copies

Select a source project and an **unused destination outside it**. Choose one:

| Operation | Actual command shape after source copying |
|---|---|
| Copy only | No external command |
| Restore packages | `vpm resolve project <new-copy>` |
| Set package version | `vpm add package <id>@<exact-version> -p <new-copy>` |
| Remove package | `vpm remove package <id> -p <new-copy>` |

Commands are arrays, not shell strings. Package IDs and exact versions are
validated; arbitrary arguments, URLs, version ranges, latest selection and force
removal are not accepted. Restore requires a VPM manifest. Legacy migration and
in-place mutation are not exposed.

Prepare review hashes source content and freezes the command, destination and
tool reference. Nothing is copied or executed at that stage. Changing operation,
package, version, destination, selected source or account invalidates the UI
review. A review is one-use, including failures; it is never automatically replayed.

Execute rechecks the selected binary, source content, destination, disk allowance
and absence of an observed Unity lock file. Close Unity/VCC and other tools before
starting: VRC Eye's reservations coordinate VRC Eye jobs, **not external editors**.
Copy uses exclusive file creation, preserves originals, rechecks source changes and
excludes root Library, Temp, Logs, Obj and version-control caches. Other source
files—including private files present in a project—remain in the local copy.
No backup completeness claim is made for omitted history/cache directories.

The review budget is 50,000 entries and 8 GiB of source data. The free-space guard
requires twice the source size plus 256 MiB; it is not a promise of sufficient disk
space for arbitrarily large downloaded dependencies. Copies/inspection are
cancellable and run through the existing page job lifecycle.

**Restore is not a read-only check.** The documented VPM resolve operation may
restore dependencies and delete legacy packages. Package changes can also modify
transitive dependencies. This adapter has no verified resolver dry-run, so a full
pre-execution dependency diff is **unknown**. Effects are limited to the new
project target by the command VRC Eye constructs, but a trusted external tool can
also change its own caches/settings. This is not an operating-system sandbox.

CLI runtime is bounded to 10 minutes; output is drained into a 64 KiB bounded
buffer and never stored in receipts. Cancellation/timeout stops the launched
process/group as supported. Windows descendant completion remains unverified.
A failed, timed-out or cancelled copy is retained for inspection, not deleted.
The app never automatically retries a submitted write.

Zero CLI exit plus a readable destination produces **CLI completed; Unity
validation required**. Missing output, nonzero exit, changed source/tool or parse
failure is not success. The receipt records submission/outcome evidence. It does
not certify compilation, VRChat upload or VCC acceptance.

## Templates and Unity handoff

Documented template choices are Base, Avatar, World and UdonSharp. These are not
advertised as locally installed until your tool actually handles the request.
The reviewed command is `vpm new <name> <template> -p <existing-parent>` with an
unused expected target. VRC Eye inspects the expected destination afterward and
reports failure/unverified output instead of assuming a zero exit produced it.
It does not run `install templates`, which can replace existing template data.

Unity handoff requires you to review a selected Unity executable with `-version`.
Its reported editor version must exactly match the project's current declaration.
Opening still requires confirmation, because opening a Unity project can execute
its editor scripts and perform imports. VRC Eye submits `-projectPath` without a
shell, reports only submission, and does not claim a successful open or compile.
There is no version-mismatch override or automated Unity migration here.

## Optional Editor Core package

Exporting the included ZIP only writes a package file. It does not import scripts
into a project. Inspect the source before deliberately importing it into a project
copy using your chosen Unity/VPM workflow. Read `Unity/EditorCore/README.md`.

The editor menu **Tools → VRC Eye → Local Project Snapshot** exposes an explicitly
invoked capture and export. Reports include exact editor version, package versions
and sources, build-target label, editor-state flags, selected-object count,
dirty-scene count and timestamp. Paths, object names, accounts, credentials and raw
logs are omitted. The package adds no runtime/avatar/world components.

Import a local editor report under Templates & tools. Strict data-only validation
rejects unknown fields/commands, duplicate packages, inconsistent counts, invalid
types and oversized payloads. You manually associate it with a project after
review; it is **not authenticated live evidence** and never overwrites the desktop
manifest inventory.

Live pairing/IPC, project-scoped permission negotiation, event reports, test/build
control, Editor/Avatar/World extension packages, custom template management and a
published VPM repository remain future work. Existing creator tools are retained.
No content publishing is implemented by this adapter.

## Primary references checked for this implementation

Checked October 2, 2026. These references define the external commands/formats;
they do not verify the user's installed tools or certify this development build.

- Official VPM CLI: https://vcc.docs.vrchat.com/vpm/cli/
- Official VPM templates: https://vcc.docs.vrchat.com/vpm/templates/
- Official VPM package format: https://vcc.docs.vrchat.com/vpm/packages/
- Unity 2022.3 package API: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PackageManager.PackageInfo.GetAllRegisteredPackages.html

Use current vendor instructions for setup. Do not infer that a version mentioned
in an old project or synthetic test fixture is the recommended current SDK/editor.
