# VRC Eye 1.21.0 — Development 15

Development 15 resumes the completed Development 14 source archive. The other chat
finished saving that archive after this continuation chat started. This build uses
that completed archive as its baseline and adds the compatible remaining fixes.
Earlier parallel recovery work is a separate historical checkpoint.

The integrated Avatar Library Transfers page, strong-validator resume, bounded
opt-in retries, publication recovery, sortable/filterable Home tables and shared
profile/avatar/Favorites notes are retained. Their entry points and limits are in
[the Development 14 guide](TRANSFERS_NOTES_DASHBOARDS_DEV14.md).

## Player-session notes

Open a player from the roster, then **Notes**. The note text now comes from the same
account-scoped store as profiles and Favorites. **Save notes and tags** updates the
shared note and the existing roster filtering tags. These roster tags remain separate
from annotation tags in the shared editor, and are labeled accordingly.

**Shared notes / tags…** opens the existing common editor. Earlier note text is
shown for review before its first shared save; it stays in its original database.
Later changes made by an older app require another review. Clearing a shared note
stays cleared even when older source text still exists. Native annotation tag colors
and user/friend alias handling are retained.

Inline drafts retain the exact note revision and workspace that were displayed.
A newer edit in another window, a changed earlier note, or an account change blocks
a stale save. Refreshing roster data does not make a stale draft current. Errors
keep the draft visible; **Reload saved notes** asks before discarding unsaved text.
Account changes clear the old visible draft. The common editor retains its existing
privacy and account guards. Nothing is sent to VRChat by these note operations.

Deleting player notes clears the earlier player text and canonical text. Other
shared annotation tags are preserved; the existing player-list tag deletion still
applies to roster tags. The two stores are separate databases; this is not a claim
of a cross-database atomic transaction or universal data deletion.

## Start and update

Close the old copy, extract **VRC-Eye-v1.21.0-Development-15.zip** into a separate
folder, open **VRC-Eye**, and run **Start.cmd** on Windows or **bash Start.sh** on
Linux. Existing launchers, Python/Tk requirements and dependencies are unchanged.
The package is runnable source, not a compiled executable or signed installer.
Different extraction folders use the same per-user data locations. New shared-note
edits do not overwrite earlier text in the legacy store, so older builds can show
older text. Keep the prior archive and your usual data backup when updating.

## Validation and remaining work

The new tests cover shared profile/roster ownership, one-query projections, alias and
clear markers, reviewed legacy reconciliation, workspace-bound revisions, stale
drafts after refresh, note deletion, failed note commits, repeated inline saves,
privacy/account transitions and reload cancellation. Existing history UI fixtures
now settle the real storage-startup jobs before capturing source-stability snapshots;
the production source-change guards are unchanged.

Exact final regression results and environment exclusions are in
[validation](VALIDATION_1_21.md) and BUILD_VALIDATION.json. Native Windows/Linux GUI,
live VRChat/CDN and other external-provider acceptance remain open. The
[ARC/VRCX inventory](ARC_VRCX_REMAINING_DEV15.md) still has 47 missing/partial areas;
this continuation improves one partial area without claiming full parity.
