# Avatar Library — Development 8

Development 8 extends the existing catalog with [OBJ previews, bulk import, HTML galleries, folder discovery and manual recovery preparation](ARC_FEATURES_1_20_DEV8.md).
[Owned-avatar metadata editing](SOCIAL_AVATARS_1_20_DEV7.md) remains a separate
Accounts panel. The foundation and its current limits are described below.

This is a VRC Eye implementation of selected avatar-management ideas from the
Release.zip review. It does not embed, launch, or reproduce the supplied ARC app.
No ARC login/server/key or bundled recovery/viewer executable is required.

## Opening the workspace

Open **Primary → Players & avatars → Avatars → Library**, or press **Ctrl+K** and
search **Avatar Library**. The existing Activity, Creator, Modules, Avatar Link,
Parameters, Preview, Tests, Diagnostics, Profiles and History tools remain.

The Library page has nine internal sections: **Library**, **Details & Builds**,
**Local Files**, **Shader Packages**, **3D preview**, **Folder discovery**,
**Import & export**, **Recovery**, and **Activity**. These use one catalog;
they are not separate avatar databases. The page scrolls, tables have scrollbars,
and the section selector remains a navigation alternative. The new command-palette
entries are navigation only, not commands that send requests or arm controls.

Opening the page starts no scan, remote request, Unity process, image fetch, OSC
operation, avatar switch or download. Demo/Safe Mode permits browsing but blocks
saving and starting file/remote jobs. Leave those modes to test changes with your
own explicitly selected files. No synthetic demo avatars are inserted into your
real catalog by the shipped application. Screenshots use test-only examples.

## Add saved observations

**Add avatar ID** accepts a full avatar ID, a supported VRChat avatar-page link,
or a local creator UUID. Enter an optional local display name. Review before
saving. This does not fetch an avatar or establish ownership.

**Import avatar JSON** reads one bounded UTF-8 avatar metadata object. It recognizes
name, creator name/ID, description, tags, visibility, dates, avatar record version,
and available `unityPackages` descriptors. It does not execute scripts, apply
settings or import other account credentials. Duplicate JSON keys, invalid types,
non-finite numbers and oversized inputs are rejected. Review the normalized
metadata and number of build descriptors before saving.

**Save creator workspace** adds an explicit catalog observation for the current
creator identity. It does not silently migrate all legacy creator notes/workspaces.
**Browse online** opens the existing search dialog; a new **Save selected to Avatar
Library** action saves only the reviewed result, using the same already loaded
metadata. It does not perform an extra search, download, avatar change or favorite
write. VRCX search continues to use the existing separate cache integration.

**Refresh from VRChat** deliberately calls the existing account transport, cache
and request budget, then asks separately whether to save its result. Access and
API failures remain failures; no new authentication system or endpoint bypass is
added. The adapters are exercised offline, not certified against live VRChat.

Local first/last-saved timestamps mean when VRC Eye recorded an observation. They
are not proof that a cached response was freshly fetched from the server. Source
and field-evidence information remain available in raw details; reported record
creation/update dates are separate fields. Missing data stays unknown.

## Browse and compare

Switch between a stable-identity **List** and a paged **Cards** view. Cards show
text and, when explicitly enabled, thumbnails you saved. Arrow keys move between
cards; Tab/Enter and ordinary table navigation are available. Selecting a record
never changes the worn avatar. Duplicate display names retain distinct IDs.

Combine text terms across name/ID/creator/description/tags with platform,
visibility, source, local favorite, file-record and reported-update-date filters.
Date inputs use YYYY-MM-DD. **Has file records** means inventory references exist;
it does not claim that the files are currently accessible. Lists show up to 48
records per page; cards show 12. Previous/Next change pages. A selected record
may remain selected while filters hide it; the selection strip identifies the
current target. Actions use that target, not whichever row has moved into its place.

Favorites and notes are local VRC Eye state, not VRChat favorites or online avatar
metadata edits. Notes are excluded from standard reports. Details has a readable
summary by default; **Raw details** exposes the retained structured evidence.

Builds distinguish reported platform, Unity declaration, asset version, file ID,
file revision and variant. They retain descriptors from successive observations.
They do not reconstruct a full server archive, invent unavailable revisions, or
prove that a file builds/loads. Records without a file revision are labeled as
weaker descriptor evidence. Two unnamed builds with identical available descriptors
may be indistinguishable. Choose **comparison A**, select another observed build,
then **Compare A with selected** for a field comparison.

## Local file inventory and copying

Select an avatar, optionally select a build in Details & Builds, and use **Register
local file**. Hashing runs in a cancellable worker. Review the avatar/build, source,
size and SHA-256, and confirm that you own or have permission to preserve the file.
The result is a reference; registration does not move or transform the original.
A recognizable bundle header is only a header check, not validation of its contents.

**Recheck selected file** reports matching bytes, changed, unavailable, or unreadable.
A missing drive does not erase catalog records. Rechecking never silently replaces
the recorded original hash. Explicit registration of a changed reference retains
a bounded previous-digest history. File dates and hashes are evidence, not ownership.

**Copy selected file** uses the shared bounded atomic-publication primitive. Choose
a new destination filename. Existing files are never overwritten, and the source
must still match the recorded evidence. Links/reparse points and special files
are rejected. A cancellation before publication removes the temporary copy; a
completed copy is never deleted because cancellation arrived afterward. The final
file is recorded in the initiating account scope, even if the visible account
changed immediately after completion. This is a byte copy, not extraction,
repair, source recovery, Unity import, or a guarantee that the avatar is usable.

Duplicate checking groups recorded equal SHA-256 values within the current scope.
It does not merge avatars/files, delete anything, or establish current availability.
**Forget reference only** removes a database reference, not the physical file.
There is intentionally no permanent-file-delete control in this checkpoint.

**Download / save VRCA** opens the existing transfer dialog, with its existing
access, destination, platform/build selection and cancellation behavior. A completed
transfer from this route can be inspected and registered after an explicit
association review. Old downloads, transfers from other entry points, and transfers
whose dialog is closed before its completion callback are not automatically
backfilled. A file that was saved but not inventoried remains on disk; register it
manually after checking its origin and permissions. No new downloader or ARC service
has been introduced. Live transfers were not used for validation.

## 2D previews

Attach a selected local PNG/JPEG/WebP/GIF. The original remains unchanged. A
metadata-free, first-frame thumbnail and a source reference are saved only after
review. Open the attached preview for scroll/zoom/reset; local bytes must still
match the saved hash. Enable **Show saved thumbnails** to show thumbnails on cards.
An explicit **Load remote thumbnail** action uses the existing restricted image
provider and current-session image URL. Provider URLs are not persisted in this
catalog, so a later session may need a metadata refresh/import to obtain one.

A thumbnail and a source reference are distinct. A saved thumbnail can remain
available after its original drive disconnects; opening a source-backed preview
may fail until that drive returns. Forgetting a preview reference clears the saved
thumbnail for that avatar. These controls display 2D images. The separate
**3D preview** section now loads bounded local OBJ geometry; neither viewer
loads VRCA models, runs avatar scripts or provides a Unity runtime.

## Shader/package inspection

Choose an authorized ZIP, supported Unitypackage/TAR/TGZ, or shader source file.
Inspection reads bounded data without extracting it, installing a package, importing
Unity scripts, running a DLL/executable, or contacting a repository.

The report includes package identity/version/license declarations when readable,
license-file presence, declared dependency requirements, shader names/source entries,
material shader references, hashes and duplicate shader bytes. Readable summaries
come first; raw details retain exact evidence. A material reference resolved within
the selected package is distinct from **External / unresolved here**. The latter
is not a claim that the shader is missing from your Unity project. No dependency
solver, shader compiler, material replacement or license certification runs.

Archive paths, duplicate/case-colliding names, links, special/encrypted members and
size budgets are checked. TAR parsing deliberately rejects extension/sparse/link
records it does not support, including PAX/long-name headers; some legitimate large
or unusual packages therefore require a future adapter rather than unsafe fallback.
Unsupported input is not proof a package is malicious. Manifests can contain code
packages; inspecting their declarations does not execute that code.

Detailed lists retain at most 200 shaders and 200 materials and clearly mark
truncation. Counts describe recognized names, not successfully compiled assets.
Missing license evidence means unknown permission, not permission to reuse.
Identical package hashes are reported within the current account scope; reports
and original package files remain separate. Forgetting a report preserves its file.

## Project associations

Details & Builds can link a published avatar ID to an existing **Creator Projects
(VCC)** catalog entry. The same account-scoped association table is used from both
workspaces. No project folder is changed. A link is your annotation, not proof of
authorship or proof that the project produced an observed build. Open the existing
creator tools for that avatar, or open Creator Projects to inspect the selected
project. The Development 1 exact-version editor handoff and reviewed project-copy
workflows are retained.
Local creator UUID-to-project links are not yet supported by that shared ID service.

## Scope, privacy and exports

The catalog lives in new namespaced tables on the existing AvatarStore connection
and database. Legacy creator tables/records are not destructively migrated. A
signed-out local scope and individual validated account-ID scopes are distinct.
Switching scope clears selections, preview windows, transient URLs and pending
reviews. It cancels in-flight work; the worker slot remains occupied until the
worker exits. Changing the selected avatar also requests cancellation of a pending
task so its review cannot silently reselect the old target.

This is logical isolation for the new catalog, not completion of the wider
multi-account Social/Accounts roadmap. It is not encrypted at-rest storage or
protection from another process with access to the same OS user's files. Back up
the existing creator database and protect your OS account appropriately.

**Privacy view (this workspace)** hides identifying detail panels, names, paths,
notes and previews and blocks detailed actions until turned off. Local paths are
hidden by default independently of this mode. Relative asset paths inside a
selected package remain useful inspection data. Privacy view is not an
application-wide streamer-mode guarantee: other VRC Eye pages/dialogs retain their
own privacy behavior. File pickers and explicit reviews can display local paths.
Saved favorites/platform/status counts are not all hidden by this local mode.

**Export selected report** provides a reviewable data-only JSON report, saved to a
new file. Standard exports omit source filesystem paths, notes, thumbnails,
descriptions, account IDs and provider endpoints. Avatar IDs and display/creator
names remain visible and must be reviewed before sharing. Raw details are not the
standard export format. The exporter does not upload anything.

**Import & export** adds reviewed metadata batches of up to 500 distinct avatar
IDs and static HTML galleries for a selected avatar or the current filtered page.
Bulk import preserves existing local private state, and gallery thumbnails are
optional. See the [Development 8 guide](ARC_FEATURES_1_20_DEV8.md) for exact formats,
review boundaries and gallery contents. These operations are not full catalog
backup/restore or automatic sharing.

## Task receipts and recovery

One local worker runs at a time on the Library page. Existing VRCA transfers retain
their own dialog/worker lifecycle. Activity shows up to 200 recent scoped receipts;
receipts are not automatically deleted. An inspection marked Complete means the
worker completed, not that you accepted its later save review. Inputs and copy
destinations are captured at start; a changed visible account cannot retarget them.

An interrupted prior-run task is displayed as **Interrupted / outcome unverified**.
Inspect its recorded destination before repeating it. Do not assume an interrupted
job is either a complete copy or a failed copy. No automatic retry, deletion,
resume, or crash reconciliation is performed. The database is the receipt store;
closing the app requests cancellation. Unresponsive OS/filesystem I/O can delay
worker shutdown, especially on unavailable external/network locations.

## Practical limits

Single-avatar metadata input: 2 MiB. Bulk metadata input: 8 MiB, 500 avatars and
2,048 build descriptors per reviewed batch. Up to 5,000 avatar records per scope and 1,000 observed
build descriptors per avatar. Catalog total: 30,000 rows and 64 MiB serialized data,
with the shared 256 KiB per-record ceiling. Those limits include retained metadata,
file/package/job records and thumbnails; very detailed reports can hit the record
ceiling and fail with a visible error. Forget unwanted references/records instead
of assuming unlimited retention.

Local file inspection/copy: 2 GiB maximum. Packages: 256 MiB input, 512 MiB total
expanded bytes, 128 MiB per member, 4,096 entries. Candidate text: 256 KiB per entry
and 16 MiB retained aggregate. Images: 8 MiB input, 16 million pixels, 8,192 maximum
side; thumbnail/preview are bounded renditions. These are conservative app limits,
not changes to Unity/VRChat format limits. Unsupported larger assets are not decoded
through an unbounded fallback. Normal file record views are bounded to 1,000 records
per avatar; raw device/inode fingerprints are implementation evidence only.

## Still pending / not claimed

Direct VRCA/FBX rendering, Unity-runtime shader/rig/animation preview, complete
material/mesh/animation repair, automatic source extraction, broad historic transfer
backfill and complete multi-account migration remain unfinished. Development 8
provides bounded OBJ viewing, selected-folder rescans, batch metadata import, HTML
galleries, manual recovery preparation and experimental Unity repair-copy source
tools. Owned-avatar metadata editing is available separately under Accounts. No
ARC binaries, FACS-derived source, AssetRipper or third-party viewer is bundled.

Validation uses native Linux/Tk, fixtures and local synthetic files. Final
Development 8 clean-package results: 4,044 tests and 1,141 subtests passed; see BUILD_VALIDATION.json. Native Windows filesystem/credential behavior, live VRChat/VRCX
requests, installed Unity/AssetRipper, production avatar assets and screen-reader
interoperability require separate testing. Exercised keyboard, privacy and display
paths do not certify every window/scale or assistive-technology combination.

## Implementation map

`avatar_library.py`: normalized scoped catalog on AvatarStore; observed builds,
references, reports and receipts. `avatar_library_files.py`: bounded read/copy/
image/package inspection. `avatar_library_display.py`: readable evidence summaries.
`avatar_library_ui.py`: shared native page and one-worker review lifecycle.
`avatar_model_preview.py` and its UI: local OBJ geometry.
`avatar_folder_discovery.py` and its UI: bounded selected-folder discovery.
`avatar_catalog_bulk.py` and its UI: atomic metadata import and inert HTML export.
`avatar_recovery_provider.py` and its UI: manual recovery preparation and output
inspection. Optional editor repair tools live in `Unity/AvatarToolkit`.
Existing search, VRCA dialog, API lookup metadata, creator workspace, project link
service and command palette are extended rather than replaced.

Primary implementation references consulted during development: Python's `tarfile`
documentation on untrusted archive limitations and Pillow's Image documentation on
image/decompression limits. VRC Eye uses its own non-extracting bounded reader here;
these references do not certify arbitrary assets or replace native testing.

https://docs.python.org/3/library/tarfile.html
https://pillow.readthedocs.io/en/stable/reference/Image.html
