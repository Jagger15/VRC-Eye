# VRC Eye 1.18.9 — Unity Player implementation map

The complete supplied discussion follows byte-for-byte after this preface.
The requested sidebar name is **Advanced → Unity Player**.

| Discussion areas | Included behavior / limits |
| --- | --- |
| External-mode boundary (1–3, 65–67, 72) | Stock VRChat process/log/window/resource observation; no injection, memory inspection or arbitrary Unity execution |
| Lifecycle, responsiveness and generations (4, 16–18, 45–49, 111–112) | Central RuntimeModel, fresh identity checks, separate hang/recovery/exit evidence, per-process generations and conservative Player Store exit cleanup |
| Runtime/renderer metadata (5–10) | Recognized log fields, bounded PE architecture read, shared GPU telemetry; process GPU selection and exhaustive driver attribution remain unknown |
| Display/window recovery (11–15) | Low-frequency Windows observations, reviewed exact-target operations, current work-area placement and session-local known-good geometry; native event subscription remains future |
| Startup and intent (20–23, 37) | Observed milestone timeline, first responsive-window timing and local summary range; no assertion of completed internal login/world loading |
| Logs/resources/health (24–31, 43–44) | Fresh normalized categories, burst rates, shared metrics, independent provider fallback and provenance; canonical avatar/player state stays in Player Store |
| Launch profiles (32–36) | Typed presets plus selected-profile overrides; reviewed Steam launch with supported flags, optional local build watching; no automatic global module/plugin orchestration |
| Compatibility (38–42, 95, 97–100) | Local capability matrix, partial-parser status, version change and summary baseline; no community/global compatibility verdict or predictive regression engine |
| Bridge (50–71) | Existing permission/lease protocol plus process-bound runtime.summary/runtime.errors; old runtime health visibly unbound; existing Player List capabilities reused |
| UI and development tools (73–79, 109, 114–116) | Casual/Advanced/Developer views, normalized developer stream, reconciliation, sanitized export and isolated start/hang/recovery simulator |
| Failure/replay integration (80–88) | Deterministic state tests, provider failure fallback, Black Box runtime event producer and existing incident/replay tools; dedicated runtime VR overlay remains later |
| Per-world/avatar history and stores (89–96) | Existing player/avatar ownership retained; no new per-world/avatar runtime scoring/history or duplicate identity database |
| Privacy/retention/performance (101–110) | Bounded queues/snapshots/events, opt-in 50-summary history, expiry, reviewed exports, coalesced redraws and background providers |
| Feature health / broader roadmap (113, 117) | Unity Player capability status now; a global health matrix, other Unity target profiles and richer orchestration remain extensions |

Modules: unity_model.py, unity_windows.py, unity_launch.py, unity_history.py,
unity_service.py and unity_ui.py. Existing sidebar, bridge, player-session and
Black Box contracts are extended rather than duplicated. Operating details and
specific limits: UNITY_PLAYER_SETUP.md. Executed checks: VALIDATION.md.

---

Absolutely. The **Unity Player / Runtime Companion Tools** were planned as one of VRC Eye’s later **Useful Tools** subsystems, and the important thing is that the name describes two related layers rather than one giant “Unity hacking” feature.

The first layer is the **Unity Player Companion**: VRC Eye watches the Unity application from the outside and understands as much as it safely can about the process, renderer, graphics environment, window, startup, shutdown, logs, resources, hangs, crashes, and compatibility.

The second layer is the **Runtime Companion**: when an already-running, compatible client voluntarily connects to VRC Eye through the optional Client Bridge, VRC Eye can receive **structured runtime telemetry** that an external application cannot normally see. That bridge may tell VRC Eye about things such as avatar initialization, selected players, speaking state, precise avatar load state, renderer problems, scene/runtime health, and richer performance information. The important architectural rule was that the bridge provides specific capabilities; VRC Eye does **not** gain unrestricted access to Unity.    Pasted markdown

So the intended architecture is basically:

```
                     VRC EYE
                        │
        ┌───────────────┴───────────────┐
        │                               │
 EXTERNAL COMPANION                OPTIONAL BRIDGE
        │                               │
 Windows / Process                 Structured IPC
 GPU / Display                    Capability API
 Logs / Files                     Client telemetry
 SteamVR / OS                     Runtime telemetry
 Window state                     Local client controls
        │                               │
        └───────────────┬───────────────┘
                        │
                 NORMALIZED STATE
                        │
              Analysis / Diagnostics
                        │
        Player Store / Safety / Black Box
                        │
           Desktop / VR Overlay / Tools
```

And the absolute rule underneath all of it was:

```
NO BRIDGE
≠
NO UNITY COMPANION
```

The external Unity companion remains useful by itself.

---

# 1. What “Unity Player” means here

The tool is concerned with the **running Unity Player application**, not with turning VRC Eye into the Unity Editor.

For VRChat, the primary target happens to be VRChat's Unity process, but architecturally I would avoid hard-coding every concept directly to:

```
VRChat.exe
```

Instead, the subsystem could have a model roughly like:

```
UnityRuntimeTarget
    process
    executable
    installation
    unity_version
    architecture
    renderer
    gpu
    display
    windows
    startup_state
    runtime_state
    responsiveness
    logs
    resources
    compatibility
```

VRChat then becomes one supported target/application profile:

```
Application Profile
    VRChat
```

That gives us room later for testing tools, Creator workflows, or other Unity applications without rewriting the entire runtime monitor.

---

# 2. The hard external-mode boundary

This was one of the clearest parts of the original plan.

The stock Unity Player Companion does **not** perform:

```
DLL injection
process injection
arbitrary process-memory reads/writes
Unity GameObject enumeration
Mono/IL2CPP object walking
PlayerLoop modification
Unity internal method calls
runtime patching
function hooking
arbitrary shader manipulation inside VRChat
protected asset extraction
```

So this is emphatically **not**:

```
VRC Eye
    ↓
open VRChat memory
    ↓
crawl Unity objects
    ↓
modify runtime
```

External Mode is much closer to:

```
VRC Eye
    ↓
observe OS-visible state
    ↓
interpret Unity/VRChat-visible logs
    ↓
observe renderer/GPU/process/display/window behavior
    ↓
build useful runtime state
```

That separation was deliberate because it gives us a stable baseline that doesn't depend on internal Unity layouts or a particular client.

---

# 3. Runtime Target Discovery

The first job of the subsystem is figuring out what is actually running.

Instead of simply checking:

```
Is VRChat.exe alive?
```

I would have a **Runtime Target Resolver**.

Conceptually:

```
Runtime Discovery
────────────────────

Application       VRChat
Process           VRChat.exe
PID               18472

Architecture      x64
Status            Running

Runtime Family    Unity
Unity Version     Detected
Renderer          Detected
VR Mode           SteamVR

Installation      Resolved
Logs              Available
Bridge            Not connected
```

The target resolver should be responsible for process lifecycle rather than letting every feature independently poll for VRChat.

That means:

```
RuntimeTargetStore
```

becomes the central truth.

---

# 4. Process lifecycle state

The runtime companion should understand substantially more than `running=true`.

A useful state machine would be:

```
NOT_RUNNING
    ↓
STARTING
    ↓
INITIALIZING
    ↓
RUNNING
    ↓
DEGRADED
    ↓
UNRESPONSIVE
```

with possible exits to:

```
EXITING
EXITED_CLEANLY
CRASHED
TERMINATED
UNKNOWN_EXIT
```

And recovery transitions such as:

```
UNRESPONSIVE
     ↓
RUNNING
```

must be supported.

A five-second hang should not permanently classify a session as crashed.

---

# 5. Unity version detection

One of the original backlog items was explicit **Unity runtime/version detection**.

The Companion should identify whatever version can be reliably established without poking through live process memory.

For example:

```
UNITY RUNTIME

Application       VRChat
Runtime           Unity
Unity Version     2022.x.x
Architecture      x64

Detection Source
Application metadata

Confidence
High
```

The exact source can vary, but the important concept is **provenance**.

Internally:

```
ObservedValue(
    value = "...",
    source = APPLICATION_METADATA,
    confidence = HIGH,
    observed_at = ...
)
```

If VRC Eye cannot determine it:

```
Unity Version
Unknown
```

not:

```
Unity Version
2022.something probably
```

---

# 6. Why Unity version matters

This isn't just trivia.

The compatibility system can correlate runtime versions with things such as:

```
known renderer behavior
known startup behavior
known log formats
known argument behavior
known VR runtime interaction
known VRC Eye parsing support
```

Then the UI might say:

```
Runtime Compatibility

Unity runtime recognized        ✓
Log parser compatible           ✓
Renderer telemetry              ✓
Window management               ✓
Bridge runtime API              N/A
```

If VRChat changes Unity versions:

```
Runtime changed since previous launch.

Previous:
Unity A

Current:
Unity B
```

That event can also enter diagnostics.

---

# 7. Renderer detection

Another specific original requirement was **renderer monitoring**.

The Companion should determine the graphics environment as reliably as possible.

Conceptually:

```
RENDERER

Graphics API        Direct3D 11
GPU                 NVIDIA ...
Adapter             0
Dedicated VRAM      ...
Driver              ...

Display Mode        Windowed
VR Runtime          SteamVR
```

This is extremely useful because some problems that users describe as:

> “Unity is broken”

are actually:

```
driver
GPU selection
display
compositor
renderer
```

problems.

---

# 8. Multi-GPU awareness

This matters especially on laptops.

Suppose Windows exposes:

```
GPU 0
Integrated

GPU 1
Discrete
```

VRC Eye should try to establish what the Unity process is actually using where trustworthy.

Then:

```
VRChat

Preferred GPU
Discrete

Observed GPU activity
GPU 1

Status
Expected
```

Or:

```
⚠ GPU selection appears unusual.

VRChat activity is being observed primarily
on the integrated adapter.
```

Notice the wording.

Not:

> “Windows definitely launched VRChat on the wrong GPU.”

unless that is actually known.

---

# 9. Renderer health

Renderer monitoring should not merely display the GPU name.

The state could resemble:

```
RendererHealth

api
adapter
driver
gpu_load
vram
shared_memory
display_state
presentation_state
device_reset_events
error_events
telemetry_health
```

Then the Companion could derive:

```
Healthy
Busy
Memory Pressure
Degraded
Device Reset Observed
Telemetry Unavailable
```

This feeds directly into both Runtime Companion and Black Box.

---

# 10. VRAM belongs here too

Although Resource Guard owns the general protection logic, Unity Companion needs the current runtime resource context.

For example:

```
VRChat Runtime

VRAM
7.2 / 8.0 GB

System RAM
18.4 GB

GPU
94%

CPU
61%

Renderer State
Busy

Unity Errors
3 recent
```

It should not duplicate Resource Guard's data collection.

Instead:

```
Resource Monitor
      ↓
Resource Store
      ↓
Unity Companion
```

uses the existing normalized state.

That prevents two separate GPU monitors from disagreeing.

---

# 11. Display and presentation monitoring

The original scope also explicitly included **display monitoring**.

This should understand the Unity application's window/display configuration.

Things worth representing include:

```
current monitor
window position
window size
minimized state
maximized state
focus state
fullscreen/windowed state where observable
DPI/scaling environment
desktop resolution
display connect/disconnect events
```

This becomes particularly valuable for weird desktop-mode problems.

---

# 12. Window Companion

This could honestly become one of the deceptively useful parts.

A dedicated panel might be:

```
VRCHAT WINDOW
────────────────────────

State             Running
Visible           Yes
Focused           No

Display           Monitor 2
Position          2560, 140
Size              1920 × 1080

[ Bring to Front ]
[ Move to Primary Display ]
[ Center Window ]
[ Restore Window ]
```

All of these are normal local desktop-window operations.

No Unity internals required.

---

# 13. Lost-window recovery

Suppose the user disconnects a monitor while VRChat is open.

Windows/applications occasionally retain coordinates that make a window effectively unreachable.

VRC Eye could recognize something like:

```
VRChat window bounds:

X = 5119
Y = 204

Current desktop bounds:

X = 0 → 3839
```

and say:

```
VRChat's window appears to be outside
the active desktop area.

[ Recover Window ]
```

Recovery would simply reposition the application's window into a visible area.

That is exactly the sort of thing I had in mind with the original **window recovery** item.

---

# 14. Window recovery presets

Potential actions:

```
Center on Current Monitor
Move to Primary Monitor
Restore Default Size
Restore Previous Known-Good Position
Bring Window On-Screen
```

VRC Eye should save a **known-good geometry** rather than only remembering the most recent geometry.

Because if the latest state is already broken:

```
latest state = off-screen
```

restoring it accomplishes nothing.

---

# 15. Display-change detection

The runtime companion should subscribe to/display events rather than hammering the system constantly.

Example timeline:

```
20:14:12
Monitor 2 disconnected

20:14:13
Desktop topology changed

20:14:14
VRChat window remained assigned outside
current visible desktop

20:14:15
Window Recovery available
```

That event can also appear in Black Box if a crash or graphics issue follows.

---

# 16. Runtime responsiveness monitor

A central responsibility is determining:

> Is the Unity player actually responding?

That should be independent from:

```
process exists
```

because:

```
VRChat.exe exists
```

does not mean VRChat is healthy.

State:

```
Process        Running
Window         Present
Responsiveness Normal
```

can degrade into:

```
Process        Running
Window         Present
Responsiveness Slow
```

then:

```
Process        Running
Responsiveness Unresponsive
Duration       8.2 sec
```

---

# 17. A hang is not automatically a crash

The Runtime Companion should preserve this distinction religiously.

Example A:

```
20:41:17 VRChat becomes unresponsive
20:41:23 VRChat responds again

Classification:
Transient Hang
Duration:
6.0 seconds
```

Example B:

```
20:41:17 VRChat becomes unresponsive
20:41:35 process terminates

Classification:
Hang followed by process exit
```

Example C:

```
20:41:17 process disappears immediately

Classification:
Unexpected process exit
No pre-exit hang observed
```

Those represent different diagnostic situations.

---

# 18. Hang duration tracking

I would explicitly record:

```
started_at
last_responsive_at
duration
recovered_at
process_state
renderer_state
resource_snapshot
recent_errors
```

Then Player/runtime history can show:

```
This Session

Short stalls             4
Long hangs               1
Longest                  8.7 sec
Recovered hangs          5
Crash-after-hang         0
```

Advanced Mode could expose this.

---

# 19. Hang correlation

Because all runtime events enter the common event system, we can correlate:

```
avatar loading
    ↓
VRAM increase
    ↓
Unity errors
    ↓
renderer load
    ↓
hang
```

without claiming:

```
avatar caused hang
```

The same correlation-vs-causation rule from Black Box applies here.

---

# 20. Startup diagnostics

This was one of the specific planned categories.

The Runtime Companion should treat application startup as its own observable sequence.

Something like:

```
Launch requested
      ↓
Process created
      ↓
Window created
      ↓
Unity initialization
      ↓
VR runtime initialization
      ↓
VRChat log initialized
      ↓
Application usable
```

Externally, we won't always be able to authoritatively observe every internal Unity stage.

So the state model needs to support:

```
observed
derived
unknown
```

rather than pretending we see everything.

---

# 21. Startup timeline

A useful diagnostic screen:

```
VRCHAT STARTUP
────────────────────────────

00.000    Launch requested
00.412    VRChat.exe created
01.083    Unity log active
02.711    Main window detected
04.426    SteamVR connection observed
09.114    Login/session activity detected
12.202    Runtime ready

Total
12.2 sec
```

If startup hangs:

```
Startup stalled.

Last observed milestone:
Unity log initialized

Duration:
47 seconds
```

---

# 22. Historical startup baseline

After enough sessions:

```
Typical startup
11–16 sec

Current startup
31 sec
```

VRC Eye could say:

```
Startup is taking longer than your recent sessions.
```

That's better than a universal threshold because different computers behave very differently.

---

# 23. Startup regression detection

This was part of the broader compatibility/intelligence idea.

Suppose:

```
Driver update
Sep 24

VRChat update
Sep 26

Average startup:
Before  13 sec
After   29 sec
```

The system may say:

```
Startup time increased after a recent
software/environment change.

Correlation only.
```

It should not conclude:

> “NVIDIA broke VRChat.”

---

# 24. Log Companion

The Runtime Companion should have a **Unity/VRChat Log Interpreter**, but not merely expose raw logs.

The external layer can normalize relevant events into categories such as:

```
Runtime
Graphics
Asset Loading
Avatar Loading
Networking
Media
SteamVR
OSC
Authentication
Application
Unknown Unity
```

The Black Box plan already called for normalized Unity warning/exception, shader, asset, networking, avatar and SteamVR-related events rather than treating every line equally.    Pasted markdown

---

# 25. Error rate matters more than one warning

Unity applications can produce harmless warnings.

Therefore:

```
1 warning
```

should not automatically become a red alert.

The runtime analyzer should track:

```
rate
burst
recurrence
newness
severity
subsystem
proximity to degradation
```

So:

```
Unity errors
2 / hour
```

might be noise.

But:

```
Unity errors
84 / 10 seconds
```

immediately before a hang is diagnostically significant.

---

# 26. Unknown errors stay unknown

This principle carries over from our other systems.

If VRC Eye sees:

```
weird Unity message
```

and doesn't understand it, the correct state is:

```
Unclassified Unity Runtime Event
```

not:

```
GPU Crash
```

The Runtime Companion should contain an explicit:

```
UNKNOWN
```

class everywhere necessary.

---

# 27. Resource telemetry

Another explicit original feature category.

The Companion should have access to:

```
VRChat CPU
VRChat memory
system CPU
system RAM
commit
GPU load
VRAM
disk activity
temperature
network health
```

but again, **Resource Guard owns collection**.

Unity Companion consumes it.

Conceptually:

```
PerformanceStore
       │
       ├── Safety Center
       ├── Black Box
       ├── Resource Dashboard
       └── Unity Runtime Companion
```

---

# 28. Runtime performance summary

Instead of forcing people to interpret twelve graphs:

```
UNITY RUNTIME HEALTH

CPU              Normal
GPU              High
VRAM             High
Memory           Normal
Disk             Busy
Renderer         Responsive
Unity Errors     Elevated
VR Runtime       Healthy

Overall
DEGRADED
```

The overall state is derived from explicit rules.

UI colors never decide the facts.

That matches the Player Store design principle that state belongs in the model, not the UI. The mature Player model similarly separates `SafetyState`, `BridgeState`, and `DiagnosticsState` instead of asking the interface to infer meaning.    Pasted text(1)

---

# 29. Safe Arrival plugs directly into Runtime Companion

This is an important crossover.

When entering a large public instance, the Safety design already planned to watch player population, simultaneous avatar loads, VRChat/system RAM, VRAM, GPU pressure, performance degradation, audio, tracking, and network state.    Pasted markdown

The Unity Runtime Companion is one of the providers feeding that.

So Safe Arrival can say:

```
SAFE ARRIVAL

Runtime              Stable
Players              46
Avatars Loading      19
VRAM                 88%
Unity Errors         Low
Tracking             Normal

Heightened monitoring:
18 sec
```

The Safety Center doesn't need to understand how every metric was collected.

It asks Runtime Companion / Resource Store for normalized state.

---

# 30. Avatar loading as runtime state

This also integrates directly with Player Store.

Externally VRC Eye may observe:

```
UNKNOWN
CHANGING
LOADING
READY
FAILED
LOAD_STALLED
```

depending on what trustworthy signals are available.

The Bridge can improve precision later.

The Player specification explicitly placed precise avatar load state and avatar performance in optional Bridge Phase 9, after the stock Player List is already complete.    Pasted text(1)

---

# 31. Why “observed resource impact” matters

External VRC Eye may see:

```
Alice changes avatar

VRAM
6.1 → 6.9 GB

RAM
17.0 → 17.8 GB
```

That does not prove:

```
Alice's avatar uses exactly 800 MB.
```

There may have been unrelated allocations.

So Runtime Companion stores:

```
ResourceObservation

event
avatar_change

delta_vram
+800 MB

window
4.2 sec

confidence
Medium

causation
Not established
```

This can feed the Player Store's `resource_warning` field, which was already part of the safety state design.    Pasted text(1)

---

# 32. Launch Companion

The original backlog also included **launch profiles**.

I see that as a safe way for VRC Eye to become the preferred front end for starting VRChat.

Something like:

```
VRCHAT LAUNCH

Profile
Normal VR

Runtime
SteamVR

Display
Desktop window → Monitor 2

VRC Eye
Black Box           On
Resource Guard      On
Overlay             On

[ Launch ]
```

This is orchestration around the application, not modification of Unity.

---

# 33. Launch profiles should represent intent

Possible profile *types* are more useful than arbitrary command-line dumping.

Conceptually:

```
Normal VR
Desktop
Troubleshooting
Creator/Test
Low-Overhead
Custom
```

A profile might contain:

```
desired VR mode
supported application arguments
window recovery preference
which VRC Eye modules start
overlay state
diagnostic verbosity
Black Box state
post-launch behavior
```

VRC Eye should only expose application arguments it understands or let an Advanced user explicitly manage custom ones.

---

# 34. Troubleshooting launch profile

This one could be extremely useful.

For example:

```
TROUBLESHOOTING PROFILE

Black Box             Enhanced
Log Monitoring        Detailed
Runtime Companion     Detailed
Resource Sampling     Detailed
Optional Plugins      Disabled
Experimental Modules  Disabled
Overlay               Minimal
```

Then the user can reproduce a problem with far cleaner evidence.

---

# 35. VRC Eye low-overhead profile

If the user suspects VRC Eye itself:

```
LOW-OVERHEAD PROFILE

Runtime Monitor       On
Black Box             On
Critical Safety       On

Player History        Off
Rich Overlay          Off
Integrations          Off
Nonessential Tools    Off
```

This fits beautifully with Safe Mode.

---

# 36. Profile inheritance

I wouldn't duplicate all settings.

Internally:

```
Base Profile
    ↓
VR Profile
    ↓
User Overrides
```

or:

```
Normal
 + diagnostics=true
 + overlay=minimal
```

rather than storing hundreds of copied settings per profile.

---

# 37. Startup intent tracking

If VRC Eye starts VRChat, it can record:

```
Launch Intent
```

Then after startup:

```
Requested:
VR mode

Observed:
VR mode

Result:
Matched
```

That allows detection of:

```
Requested Desktop
Observed SteamVR launch
```

or other unexpected startup state.

Again, report the mismatch; don't invent the reason.

---

# 38. Compatibility database

This was another explicit planned feature, and I think it deserves to become its own proper subsystem.

Not an online “is this driver good?” rumor list.

Instead:

```
RuntimeCompatibilityStore
```

stores observations about combinations such as:

```
VRC Eye version
VRChat version
Unity runtime
OS
GPU vendor
GPU driver
SteamVR version
Bridge protocol
```

The first purpose is to answer:

> Does VRC Eye know how to interpret this runtime environment?

---

# 39. Capability compatibility

For example:

```
COMPATIBILITY

VRChat runtime              Recognized
Unity log parser            Supported
Window recovery             Supported
GPU telemetry               Supported
VRAM telemetry              Supported
SteamVR telemetry           Supported

Bridge
Not connected
```

Or:

```
Unity version changed.

Basic monitoring            Available
Log interpretation          Partial
Advanced event parsing      Validation pending
```

That is much safer than pretending every update is completely understood.

---

# 40. Compatibility is capability-based

The same philosophy applies to the Client Bridge.

We already planned the Bridge around a capability object like:

```
player_selection
voice_activity
distance
avatar_load_state
avatar_performance
avatar_safety_controls
interaction_state
runtime_summary
```

and the UI asks whether a capability is supported rather than checking a particular client name.    Pasted text(1)

That means:

```
Bad

if client == FooClient:
    showRuntimePanel()
```

versus:

```
Good

if bridge.supports("runtime.summary"):
    showRuntimePanel()
```

Much more future-proof.

---

# 41. Runtime compatibility states

I would use something like:

```
SUPPORTED
SUPPORTED_PARTIAL
UNKNOWN
DEGRADED
INCOMPATIBLE
DISABLED
```

with reason codes.

Example:

```
Runtime Log Parser

State
SUPPORTED_PARTIAL

Reason
New Unity runtime detected.

Still available:
generic errors
startup monitoring
process health

Temporarily unavailable:
specialized event classification
```

That is much better than making the entire companion fail.

---

# 42. Unknown future runtime

A VRChat update could change behavior tomorrow.

VRC Eye should degrade like:

```
Process Monitor          ✓
Window Tools             ✓
OS Resource Monitor      ✓
GPU Monitor              ✓
Generic Log Reader       ✓

Known Unity Parsing      ⚠ Partial
Special Runtime Rules    ✗ Disabled
```

Never:

```
Unknown Unity version
→ Entire VRC Eye dies
```

---

# 43. Runtime Feature Health

We already established the concept of subsystem health elsewhere.

Runtime Companion should participate:

```
UNITY COMPANION HEALTH

Process Monitor        Healthy
Runtime Detection      Healthy
Logs                   Healthy
Renderer               Healthy
GPU Telemetry          Healthy
Window Manager         Healthy
SteamVR                Healthy
Bridge Runtime         Disconnected
```

The Player system likewise was planned to report independent health for roster, identity, history, API enrichment, and Bridge rather than failing wholesale, which is exactly the degradation model Runtime Companion should copy.    Pasted text(1)

---

# 44. Provider independence

Internally, don't let:

```
UnityRuntimeService
```

directly own Windows, GPU, logs, SteamVR, Bridge and Player Store.

Instead:

```
ProcessProvider
WindowProvider
RuntimeMetadataProvider
LogProvider
GraphicsProvider
DisplayProvider
ResourceProvider
SteamVRProvider
BridgeProvider
```

feed:

```
RuntimeStore
```

Then:

```
RuntimeAnalyzer
```

operates on normalized state.

---

# 45. Runtime Store

Conceptually:

```
RuntimeState
├── Identity
├── Lifecycle
├── RuntimeVersion
├── Renderer
├── Display
├── Window
├── Resources
├── Responsiveness
├── Startup
├── Logs
├── VRRuntime
├── Compatibility
├── Bridge
└── Diagnostics
```

Just like PlayerStore, the UI does not own any of this.

---

# 46. Immutable runtime snapshots

UI should consume something like:

```
RuntimeSnapshot
```

not query six background workers independently.

Otherwise the screen might show:

```
Process     Running
PID         old process
VRAM        previous process
Window      new process
```

after a restart.

A coherent snapshot eliminates a whole class of race conditions.

---

# 47. Session generations

Every VRChat launch should receive a new runtime generation/session ID.

For example:

```
Runtime Session
R-20261001-0042
```

If PID 17000 exits and PID 18000 starts:

```
old RuntimeState
```

must not bleed into the new process.

So:

```
ProcessSession
    runtime_session_id
    pid
    created_at
    exited_at
    exit_reason
```

---

# 48. Event bus

All important runtime transitions should publish events.

For example:

```
runtime.process.started
runtime.process.exited
runtime.window.created
runtime.window.offscreen
runtime.responsiveness.degraded
runtime.hang.started
runtime.hang.recovered
runtime.renderer.changed
runtime.display.changed
runtime.error.observed
runtime.compatibility.changed
runtime.bridge.available
```

Then Black Box subscribes.

Safety subscribes.

Overlay subscribes.

Diagnostics subscribes.

Nobody needs to scrape another UI module.

---

# 49. Runtime event provenance

Every event needs:

```
timestamp
source
confidence
runtime_session
event_type
payload
```

Example:

```
Event
runtime.avatar.load

Source
bridge.avatar_load_state

Confidence
AUTHORITATIVE

Runtime Session
R-42

Observed
21:14:13.337
```

Versus:

```
Event
runtime.avatar.load_suspected

Source
log_parser

Confidence
MEDIUM
```

That distinction is incredibly important.

---

# 50. External mode versus Bridge mode

The UI should make the difference obvious without making stock mode look crippled.

Maybe:

```
RUNTIME COMPANION

External Monitoring
● Active

Client Bridge
○ Not connected

Available externally:
✓ process health
✓ startup diagnostics
✓ log analysis
✓ renderer/GPU monitoring
✓ resources
✓ display/window tools
✓ crash/hang detection

Bridge enhancements:
○ precise runtime state
○ selected-player synchronization
○ speaking state
○ detailed avatar telemetry
○ local client safety controls
```

---

# 51. Bridge activation sequence

This was deliberately supposed to be:

```
STANDARD MODE
     ↓
compatible bridge appears
     ↓
handshake
     ↓
protocol version check
     ↓
capability negotiation
     ↓
permissions
     ↓
BRIDGE MODE
```

Not:

```
detect custom client
→ poke it
```

VRC Eye waits for a compatible, explicitly supported bridge.

---

# 52. Localhost IPC

The bridge design was an **already-active client voluntarily exposing a local IPC endpoint**.

Conceptually:

```
VRChat Client Plugin
        ⇅
 localhost IPC
        ⇅
     VRC Eye
```

That boundary is crucial.

VRC Eye doesn't inject the bridge into VRChat.

The client/extension owns its Unity-side component.

VRC Eye is merely its companion.

---

# 53. Protocol handshake

Something like:

```
HELLO

Bridge
ExampleBridge

Protocol
2

Capabilities
player.selection
player.voice_activity
avatar.load_state
avatar.performance
runtime.summary
runtime.errors
```

Then VRC Eye responds with whatever handshake/permission negotiation our eventual protocol defines.

---

# 54. Bridge protocol versioning

Never assume protocol v1 forever.

Model:

```
protocol_major
protocol_minor
bridge_version
capabilities
optional_extensions
```

Rules:

```
Major mismatch
→ reject incompatible protocol

Minor mismatch
→ negotiate common capabilities

Unknown capability
→ ignore safely
```

That lets the bridge ecosystem evolve independently.

---

# 55. Runtime Summary capability

One of the capabilities explicitly contemplated was:

```
runtime_summary
```

This could provide a structured summary such as:

```
RuntimeSummary

scene_state
avatar_system_state
render_state
local_player_state
error_state
frame_health
```

But VRC Eye should not say:

> Give me arbitrary Unity objects.

It asks:

> Do you support `runtime.summary`?

---

# 56. Runtime error capability

Bridge mode can expose **local Unity errors** with better context than an external log parser.

The Safety plan specifically contemplated bridge-provided avatar initialization state, Unity errors, unusual renderer behavior, scene/runtime health and richer performance telemetry, while still requiring structured telemetry rather than arbitrary Unity-function execution.    Pasted markdown

A payload could conceptually be:

```
RuntimeErrorEvent

category
renderer

severity
warning

component
avatar-render

timestamp
...

player_context
usr_...  [if legitimately relevant]

details
structured fields
```

No giant arbitrary object serialization necessary.

---

# 57. Avatar initialization telemetry

External mode may only infer:

```
Avatar changing...
```

Bridge mode may know:

```
REQUESTED
DOWNLOADING
INSTANTIATING
INITIALIZING
READY
FAILED
```

That gives the Player List much richer state.

The Player Store can display:

```
Alice
Avatar initializing...
```

and later:

```
Alice
Avatar ready
```

---

# 58. Selected-player synchronization

This was one of the explicit bridge plans.

If VRChat selection changes:

```
player.selected usr_123
```

then VRC Eye can:

```
highlight Alice
scroll Alice into view
optionally open detail panel
```

The original Player List spec even had settings for following the VRChat selection and optionally opening details.    Pasted text(1)

This is where Runtime Companion and Player Companion really merge.

---

# 59. Speaking telemetry

Speaking indicators are exactly the sort of information External Mode shouldn't fake.

Bridge mode can supply:

```
player.voice_activity
```

and Player Store changes:

```
Alice     🔊
Bob
Charlie  🔊
```

Event-driven.

Not 60-Hz polling.

---

# 60. Player distance

Another bridge capability:

```
distance
```

Again, selected/pinned players should receive priority.

We already planned not to hammer 80 players at extremely high rates. The Player subsystem's performance target was an 80-user instance with multiple events per second and minimal UI lag, using tiered update rates rather than refreshing everything constantly.    Pasted text(1)

So something like:

```
Selected player    5 Hz
Pinned              2 Hz
Visible rows        1 Hz
Others              none/on demand
```

makes much more sense than:

```
80 × 60 updates/sec
```

---

# 61. Exact distance versus categories

Desktop Advanced mode:

```
Distance
3.2 m
```

Compact overlay:

```
Nearby
```

or:

```
Near
Mid
Far
```

This reduces noise and possibly bridge traffic.

---

# 62. Avatar performance telemetry

Bridge mode can add authoritative local-client information such as:

```
Performance Rank
Texture Memory
Renderer Count
PhysBone data
Contact data
Load State
Avatar Audio
Effects State
```

when the bridge supports those fields.

That data is qualitatively different from external resource correlation.

So provenance might say:

```
Texture Memory
184 MB

Source
Client Bridge

Confidence
Direct
```

versus:

```
Observed VRAM increase
+620 MB

Source
System correlation

Confidence
Medium
```

Never merge those into the same thing.

---

# 63. Per-player local safety

This is another bridge/runtime crossover.

A compatible client can expose safe **local-only** actions.

For example:

```
[ Mute Locally ]
[ Hide Avatar ]
[ Disable Avatar Audio ]
[ Reduce Effects ]
[ Pause Interaction ]
```

The Player safety plan expressly kept these actions local to the user's own client, not actions against another person's client.    Pasted markdown

---

# 64. Safety presets

Rather than twelve toggles:

```
Normal
Reduced
Minimal
Hidden
```

The client can define what those mean.

VRC Eye requests:

```
player.safety_preset = REDUCED
```

The bridge decides how to implement it.

That preserves clean ownership:

```
VRC Eye
requests intent

Bridge
implements supported client behavior
```

---

# 65. No arbitrary “execute Unity”

I would make this a literal architectural rule.

Bridge API:

```
runtime.get_summary
player.get_distance
avatar.get_load_state
player.apply_local_safety
```

Good.

API:

```
unity.execute("FindObjectsOfType...")
unity.call(methodAddress...)
memory.read(...)
memory.write(...)
```

Absolutely contrary to the design.

The bridge is supposed to make VRC Eye **more observable**, not turn it into a remote Unity console.

---

# 66. No GameObject browser

This deserves special emphasis because “Unity Runtime Companion” can easily imply it.

We're **not** planning:

```
Scene
 ├─ GameObject
 │   ├─ Transform
 │   ├─ Animator
 │   └─ ...
```

for arbitrary VRChat runtime internals.

That would cross directly into the category we intentionally excluded from External Mode and did not want the bridge designed around either.

If a bridge exposes:

```
avatar.renderer_count = 86
```

that's fine.

It doesn't need to hand us 86 renderer objects.

---

# 67. No PlayerLoop hooks

Likewise, Runtime Companion doesn't need to insert callbacks into Unity's PlayerLoop.

If the client wants to collect its own telemetry internally, that is an implementation detail of the client-side bridge.

VRC Eye receives the resulting **sanitized structured state**.

---

# 68. Bridge disconnect

This is critical.

Suppose:

```
Alice
Speaking       Yes
Distance       2.7 m
Performance    Very Poor
```

and the bridge disconnects.

Bad behavior:

```
Speaking       No
Distance       0 m
Performance    Excellent
```

Those values falsely imply real observations.

Correct:

```
Speaking       Unavailable
Distance       Unavailable
Performance    Stale

Bridge disconnected
Last update 4 sec ago
```

Core Player List and external Runtime Companion stay active.

---

# 69. Capability disappearance

The same applies if one individual capability vanishes.

Example:

```
Bridge connected

runtime.summary      ✓
player.selection     ✓
voice.activity       ✗
```

Don't disable Bridge Mode entirely.

Only the unsupported feature becomes unavailable.

---

# 70. Staleness

Every bridge-derived runtime value should carry age.

For example:

```
Scene Health
Healthy

Source
Bridge

Age
52 ms
```

If IPC stalls:

```
Scene Health
STALE

Last update
7.4 sec ago
```

This becomes especially important for Safety.

---

# 71. Heartbeat

Bridge protocol should have some concept of health/heartbeat.

Conceptually:

```
CONNECTED
HEALTHY

CONNECTED
DELAYED

CONNECTED
STALE

DISCONNECTED
```

The state transition must happen even if the socket technically remains alive but stops producing meaningful data.

---

# 72. Runtime Companion must never depend on Bridge

This point is so central that it should appear in the code architecture.

Bad:

```
RuntimeCompanion.start()
    require Bridge
```

Correct:

```
RuntimeCompanion
    ExternalProviders
    OptionalBridgeProvider
```

Bridge data enriches the model.

It doesn't instantiate the model.

That same principle was already baked into the Player List implementation order: Bridge features come after the stock roster, identity, history, avatar state, roles, Safety, UX, and ecosystem layers.    Pasted text(1)

---

# 73. Casual Mode

The Casual UI should be extremely simple.

Something like:

```
UNITY RUNTIME

VRChat
Running normally

Graphics
Normal

Memory
Normal

SteamVR
Connected

No problems detected.
```

When there's a problem:

```
VRChat is running but has
stopped responding.

Duration
8 seconds

[ Wait ]
[ View Details ]
```

No Unity jargon unless necessary.

---

# 74. Advanced Mode

Advanced might show:

```
Runtime
Unity ...

Renderer
D3D11

GPU
...

VRAM
7.1 / 8.0 GB

Process CPU
47%

Working Set
8.4 GB

Window
1920×1080
Monitor 2

Responsiveness
Normal

Recent Unity Errors
3
```

With history graphs.

---

# 75. Developer Mode

Developer Mode is where we stop hiding plumbing.

Potential fields:

```
PID
process start timestamp
runtime session ID
provider ID
raw event type
source
confidence
cache age
poll duration
last successful sample
error counts
bridge protocol
bridge capabilities
bridge round-trip
raw normalized state
```

This parallels our existing plan to expose raw events, timestamps, providers, sequence numbers, DB IDs, resolver state, cache age, bridge capabilities, payload summaries, polling latency and journal information in Developer diagnostics.

---

# 76. Raw runtime event stream

Developer view could look like:

```
21:44:17.102
runtime.process.heartbeat

source:
windows.process

pid:
18472
```

```
21:44:17.221
runtime.graphics.sample

gpu:
1

vram:
7.31 GB
```

```
21:44:17.337
bridge.runtime.health

scene:
ready

render:
degraded
```

```
21:44:17.442
runtime.log.error

category:
avatar
```

Great for debugging VRC Eye itself.

---

# 77. Runtime debug console

Eventually:

```
RUNTIME COMPANION DEBUG

Target          VRChat
Session         R-0042
PID             18472

External
Process         LIVE
Logs            LIVE
Graphics        LIVE
Window          LIVE
SteamVR         LIVE

Bridge
Connected       YES
Protocol        2.1
Latency         4 ms
Capabilities    8

Events/sec      14.2

[ Dump Runtime State ]
[ Dump Capabilities ]
[ Reconcile ]
```

This should remain Developer-only.

---

# 78. Simulator

Just as we planned a fake Player Store simulator, Runtime Companion should have one.

Commands conceptually:

```
runtime start
runtime hang
runtime recover
runtime crash
renderer pressure high
window offscreen
display disconnect
unity-error burst
bridge connect
bridge disconnect
bridge runtime degraded
```

Then we can test everything without intentionally crashing VRChat.

---

# 79. Replay tests

Feed:

```
00:00 process start
00:04 Unity log active
00:11 runtime ready
10:00 world join
10:04 VRAM rise
10:06 Unity error burst
10:07 hang
10:13 recover
```

Verify:

```
final state RUNNING
hang count 1
hang duration 6 sec
Black Box markers correct
UI health correct
```

---

# 80. Crash tests

Important cases:

```
process exits while responsive
process hangs then exits
process forcibly terminated
VRC Eye dies first
Windows shuts down
GPU telemetry disappears
log file stops updating
SteamVR dies
Bridge dies
```

Each should yield a distinct runtime state.

---

# 81. Provider failure tests

Suppose the log reader fails.

Correct:

```
Runtime Process       Healthy
Renderer              Healthy
Logs                  Unavailable
Bridge                Connected
```

Incorrect:

```
Runtime Unknown
```

unless the log source was genuinely required for that specific state.

---

# 82. Black Box integration

The Runtime Companion should be one of Black Box's richest producers.

It contributes events such as:

```
runtime start
runtime stop
startup milestones
hang start
hang recovery
window/display changes
renderer health
Unity error bursts
Bridge runtime state
compatibility changes
```

Then Black Box combines those with system-level telemetry.

---

# 83. Runtime incident example

A future replay could say:

```
21:03:14
Remote avatar initialization began

21:03:16
VRAM 78 → 86%

21:03:18
Renderer health changed:
Normal → High Pressure

21:03:20
Unity error burst observed

21:03:21
Runtime responsiveness:
Normal → Slow

21:03:23
VRChat:
Unresponsive

21:03:31
VRChat:
Responsive
```

Classification:

```
Recovered Runtime Hang
Duration 8.0 sec
```

No crash.

---

# 84. Crash example

```
21:03:14 avatar loads
21:03:18 VRAM rises
21:03:20 Unity errors
21:03:23 unresponsive
21:03:38 process exits
```

Then Runtime Companion says:

```
VRChat became unresponsive before exiting.

Observed beforehand:
• GPU memory pressure
• elevated Unity errors
• avatar loading activity

Cause:
Not conclusively established
```

Exactly the same evidence philosophy as Black Box.

---

# 85. Safety Center integration

Unity Runtime Companion feeds Safety Center with:

```
runtime health
renderer health
hang state
startup anomalies
VRAM pressure
error bursts
bridge runtime health
```

But Safety decides whether to act.

So:

```
Runtime Companion
OBSERVES

Safety Rules
DECIDE

Safety Action
ACTS
```

Runtime Companion shouldn't spontaneously close VRChat because one metric turns red.

---

# 86. Overlay integration

VR overlay should show only actionable runtime events.

For example:

```
⚠ VRChat is not responding
8 sec
```

or:

```
⚠ GPU memory is nearly full
```

Not:

```
UnityRuntimeProvider.GraphicsAdapter
sample latency 12 ms
```

That's Developer desktop information.

---

# 87. Window recovery in overlay

Potentially:

```
Desktop VRChat window
appears off-screen.

[ Recover Window ]
```

This is particularly handy in VR because the user may not want to remove the headset just to wrestle with Windows.

---

# 88. Runtime health history

Session history might show:

```
RUNTIME THIS SESSION

Duration          2h 41m

Hangs             2
Recovered         2
Crashes           0

Peak VRAM         91%
Peak RAM          ...
Unity Error Bursts 1

SteamVR Loss      0
Bridge Loss       1
```

Again, only meaningful metrics.

---

# 89. Per-world runtime history

This connects to Personal World Safety Memory.

VRC Eye may privately remember:

```
Your previous sessions here:

Sessions               7
Crashes                2
High VRAM sessions     4
Long load sessions     3
```

Wording:

> “Your machine has previously experienced high VRAM usage here.”

Not:

> “This world is dangerous.”

---

# 90. Per-avatar correlation

Likewise:

```
Observed after this avatar loaded on your PC:
Large resource increase occurred twice.
```

Not:

```
Malicious Avatar
```

The Player Store safety design explicitly avoids turning observed resource warnings into hidden accusations.

---

# 91. Player Store integration

Runtime Companion doesn't create a second player database.

It publishes player-related observations to:

```
PlayerStore
```

The mature Player model already separates identity, presence, relationship, roles, avatar state, history, local metadata, safety, peer/bridge and diagnostics.    Pasted text(1)

So:

```
Runtime Companion
      ↓
player runtime event
      ↓
PlayerStore
      ↓
PlayerCardData
```

---

# 92. Avatar Store integration

Same philosophy.

If we maintain an Avatar Store/cache later:

```
AvatarStore
```

owns avatar identity/known metadata.

Runtime Companion contributes:

```
load event
performance observation
load failure
local runtime telemetry
```

It doesn't own the avatar itself.

---

# 93. No duplicate truths

There should never be:

```
Player List says avatar READY
Runtime Companion says LOADING
Safety Center says UNKNOWN
```

because three modules invented independent state machines.

Instead:

```
AvatarStateStore
```

receives observations from:

```
logs
API
bridge
runtime
```

and resolves a canonical state.

---

# 94. Source precedence

For example:

```
Bridge authoritative runtime event
    >
trusted explicit log event
    >
derived external observation
```

but precedence is field-specific.

An API isn't automatically authoritative for something it cannot know live.

The resolver should know:

```
Which source is authoritative
for WHICH FIELD?
```

---

# 95. Compatibility database and source precedence

This becomes useful after updates.

Suppose a new VRChat release changes log wording.

Compatibility says:

```
Log avatar-state resolver
Degraded
```

Bridge remains:

```
avatar.load_state
Available
```

So canonical AvatarState can continue using Bridge data while External Mode marks that particular parser partially unavailable.

---

# 96. Runtime Companion and Creator Mode

This also has a natural place in future Creator workflows.

Creator profile could emphasize:

```
startup
world transitions
late joins
avatar initialization
resource changes
runtime errors
player join order
```

without exposing arbitrary private runtime internals.

The Player specification already contemplated Creator views for join order, time since instance start and playtest-related state while explicitly avoiding arbitrary private runtime information.

---

# 97. Compatibility change notifications

Don't annoy the user every launch.

Notify only when materially useful:

```
VRChat runtime changed.

VRC Eye has switched some runtime
parsers to compatibility mode.

Core monitoring remains available.

[ Details ]
```

Developer Mode can show every version change.

Casual shouldn't.

---

# 98. Runtime launch history

Each session record could contain:

```
runtime_session_id
application_version
unity_version
VRC Eye version
OS build
GPU driver
SteamVR version
launch_profile
startup_duration
exit_classification
```

That's incredibly valuable later for regression analysis.

---

# 99. Regression comparison

Example:

```
Sessions before update
Average hang rate:
0.2/session

Sessions after update
Average hang rate:
2.4/session
```

VRC Eye can say:

```
Runtime hangs have occurred more frequently
in sessions since the environment changed.
```

Not:

```
The update definitely caused hangs.
```

---

# 100. Compatibility knowledge should distinguish local from global

Initially most compatibility intelligence should be:

```
YOUR MACHINE
YOUR SESSIONS
```

If we ever add community compatibility data later, it must be clearly separated:

```
Local observation

Community observation

Official compatibility
```

Never merge anecdotal telemetry into an authoritative verdict.

---

# 101. Privacy

The Runtime Companion is potentially capable of collecting a lot of session context.

So we should avoid:

```
raw permanent event hoarding
```

by default.

Live high-frequency runtime samples belong primarily in:

```
memory
rolling telemetry
Black Box
```

not permanent history.

Long-term history stores summaries.

---

# 102. Retention example

Permanent-ish session record:

```
Session lasted 2h41m
2 recovered hangs
peak VRAM 91%
1 bridge disconnect
clean exit
```

not:

```
every 250 ms sample
for three years
```

unless the user explicitly enables some developer recording feature.

---

# 103. Export sanitization

Runtime diagnostic exports should redact:

```
tokens
private instance identifiers
filesystem usernames
sensitive bridge credentials
unnecessary user IDs
private notes
```

while retaining enough runtime evidence to troubleshoot.

---

# 104. Performance budget

The Runtime Companion must never become the thing causing Unity performance issues.

Collection needs:

```
event-driven where possible
low-frequency polling where not
adaptive sampling for incidents
background workers
bounded queues
coalesced UI updates
```

High-frequency bridge data should not produce a full UI redraw per packet.

---

# 105. Polling tiers

Conceptually:

```
Process existence
low cost / frequent

Window geometry
event-driven or low frequency

GPU resource state
moderate rate

Temperature
slow

Compatibility metadata
once per session

Version info
once per launch

Voice
event-driven

Distance
selected/pinned rate limited
```

This is much more sane than running everything at 60 Hz.

---

# 106. Thread model

Likely:

```
Process Monitor
Graphics Monitor
Log Reader
Bridge Listener
SteamVR Provider
Database Worker
Analysis Worker
UI Thread
```

All communicate through event/state queues.

Never:

```
background GPU monitor
→ directly mutate UI widget
```

---

# 107. Backpressure

If Runtime Companion receives events faster than it can display them:

```
do not let queue grow forever
```

Coalesce sample-type data.

Example:

```
GPU sample 81%
GPU sample 82%
GPU sample 83%
GPU sample 84%
```

UI may only need latest:

```
84%
```

But error events may need preservation.

Different event classes need different queue policies.

---

# 108. Failure isolation

If:

```
DisplayProvider
```

throws an exception, it must not kill:

```
ProcessMonitor
```

If Bridge parser breaks, it must not kill External Mode.

If GPU monitoring fails, Black Box should still record other state.

Each provider has:

```
HEALTHY
DEGRADED
FAILED
DISABLED
```

---

# 109. Runtime self-diagnostics

VRC Eye should monitor Runtime Companion itself.

Example:

```
Graphics provider

Samples
2 Hz

Last success
140 ms ago

Errors
0
```

Developer Mode.

If it fails:

```
GPU runtime telemetry unavailable.

VRChat monitoring remains active.
```

---

# 110. Recovery after provider failure

Providers should be allowed to reconnect/reinitialize.

Example:

```
SteamVR unavailable
    ↓
SteamVR starts
    ↓
SteamVR Provider reconnects
```

without restarting VRC Eye.

Same for Bridge.

---

# 111. Process restart handling

If VRChat crashes then relaunches:

```
Runtime Session A
CLOSED

Runtime Session B
NEW
```

Do not merely change PID inside the same session.

This matters for:

```
startup timing
crash classification
Black Box
PlayerStore session cleanup
history
```

---

# 112. World/player cleanup after crash

On process exit:

```
Runtime Session closes
      ↓
Instance Session closes unexpectedly
      ↓
Players close with estimated/unknown departure
      ↓
Black Box preserves crash window
```

Do not manufacture exact leave times.

---

# 113. Integration with our “Feature Health Matrix”

Eventually the global status could show:

```
VRC EYE HEALTH

VRChat Runtime          Healthy
Player Store            Healthy
Safety                  Healthy
Resource Guard          Healthy
SteamVR                 Healthy
Black Box               Recording
Runtime Bridge          Disconnected
```

Bridge disconnected is not necessarily yellow/red.

If it was never required:

```
Disconnected
```

is simply a valid state.

---

# 114. Planned sidebar location

This was meant as a later **Useful Tools** capability rather than turning the main interface into a Unity engineering console.

A reasonable presentation consistent with the plan would be:

```
Useful Tools
└── Unity Runtime
    ├── Overview
    ├── Runtime
    ├── Graphics
    ├── Window
    ├── Startup
    ├── Logs
    ├── Compatibility
    └── Bridge
```

while the features themselves surface elsewhere when appropriate:

```
Safety Center
Black Box
Player List
VR Overlay
Diagnostics
```

So there is one subsystem, not five independent implementations.

---

# 115. Overview page

I imagine:

```
UNITY PLAYER / RUNTIME COMPANION
══════════════════════════════════

VRChat                       Running
Runtime                      Unity • Recognized
Responsiveness               Normal
Graphics                     Healthy
SteamVR                      Connected
Memory                       Normal
Unity Errors                 0 recent

External Companion           Active

Runtime Bridge
Not connected
Advanced runtime telemetry unavailable

Session
1h 27m

[ Runtime Details ]
[ Window Tools ]
[ Logs ]
[ Diagnostics ]
```

---

# 116. Bridge-connected overview

Then:

```
UNITY PLAYER / RUNTIME COMPANION
══════════════════════════════════

VRChat                       Running
Runtime                      Unity • Recognized
Responsiveness               Normal
Graphics                     Healthy

Runtime Bridge               Connected
Protocol                     2.1

Enhanced telemetry
✓ Runtime health
✓ Player selection
✓ Voice state
✓ Avatar state
✓ Avatar performance

[ Runtime Details ]
```

No giant “CUSTOM CLIENT DETECTED” banner.

Bridge is just another provider.

---

# 117. The philosophical center of the entire feature

The clearest way to summarize what we had planned is that **Unity Player / Runtime Companion is supposed to make Unity/VRChat observable and recoverable without making VRC Eye invasive**.

External mode answers:

```
What process is running?
Which Unity/runtime environment is this?
What renderer/GPU/display is being used?
Is the window healthy?
Is the application responding?
What is startup doing?
What are the logs saying?
How are system resources behaving?
Did the application hang?
Did it crash?
Has the environment changed?
Can VRC Eye recover common desktop/runtime problems?
```

Optional Bridge Mode adds:

```
What does the compatible client explicitly know?
Which player is selected?
Who is currently speaking?
How far away is the selected player?
What exact avatar-load stage is occurring?
What avatar/runtime performance state is exposed?
What runtime errors/health information is exposed?
Which local safety actions does the client support?
```

But it **doesn't** change the architecture into:

```
Give VRC Eye arbitrary Unity access.
```

That was specifically the direction we did **not** want.

The end result is something much closer to a combination of a **Unity process supervisor + graphics/runtime monitor + startup troubleshooter + window recovery utility + compatibility manager + diagnostics engine + optional structured runtime dashboard**.

And because it plugs into the same Player Store, Resource Store, Safety Center, Black Box, overlay, and Client Bridge architecture we're already building, a runtime observation only needs to be collected once and can then appear everywhere it is useful. The Player subsystem already follows this centralized source-of-truth approach, including bridge capabilities, diagnostics state, selected-player synchronization, safety state, and graceful degradation rather than letting each UI invent its own facts.    Pasted text(1)    Pasted text(1)

**Most importantly: the original backlog boundary remains intact — runtime/version detection, renderer/GPU/display monitoring, window recovery, hang/crash detection, startup/log diagnostics, resource telemetry, launch profiles, and compatibility management are the stock external companion; GameObject inspection, arbitrary memory access, injection, PlayerLoop hooks, and unrestricted Unity calls are not. The optional bridge adds only capabilities that the connected client explicitly chooses to expose.**