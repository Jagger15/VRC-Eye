"""Feed tabs for shared locations, selected-friend alerts and reconnect recap."""
from companion_data import entity
from companion_ui import Table, line, button, entry, choice
from friend_activity import EVENTS, EVENT_LABELS, grouped_locations
import friend_filters
from friendly_ui import ScrollPane
from live_catalog import catalog_for
from search_tiles import ResultTiles


class FriendViews:
    def __init__(self, page, tabs):
        self.page=page;self.tabs=tabs;self.app=page.app;self.tk=page.tk;self.ttk=page.ttk
        self.shell=page.shell;self.sync=page.sync;self.context=page.context
        self.frames={name:self.ttk.Frame(tabs) for name in ('Locations','Watchlists','Reconnect recap')}
        for name,frame in self.frames.items():tabs.add(frame,text=name)
        self.token=None;self.signature=None;self.groups={};self.attempted=set();self.closed=False
        self.filters=friend_filters.settings(None,'');self.priority=set()
        self.viewport=ScrollPane(self.app,self.frames['Locations'],min_width=480)
        body=self.viewport.body
        self.filter_friend=self.tk.StringVar();self.filter_world=self.tk.StringVar()
        self.filter_presence=self.tk.StringVar(value='All');self.filter_platform=self.tk.StringVar(value='All')
        self.filter_collection=self.tk.StringVar(value='All collections');self.pin_watched=self.tk.BooleanVar(value=True)
        row=line(page,body);self.ttk.Label(row,text='Friend name / ID').pack(side='left');entry(page,row,self.filter_friend,28)
        self.ttk.Label(row,text='World name / ID').pack(side='left');entry(page,row,self.filter_world,28)
        row=line(page,body);self.ttk.Label(row,text='Presence').pack(side='left')
        choice(page,row,self.filter_presence,friend_filters.PRESENCES,width=20)
        self.ttk.Label(row,text='Reported platform').pack(side='left');choice(page,row,self.filter_platform,friend_filters.PLATFORMS,width=18)
        row=line(page,body);self.filter_collection_control=choice(page,row,self.filter_collection,('All collections',),width=52)
        self.ttk.Checkbutton(row,text='Pin watched friends',variable=self.pin_watched).pack(side='left')
        row=line(page,body);button(page,row,'Apply filters',self.apply_filters);button(page,row,'Reset filters',self.reset_filters)
        button(page,row,'Refresh collections',self.refresh_filters)
        self.location_summary=self.tk.StringVar()
        self.ttk.Label(body,textvariable=self.location_summary,wraplength=950).pack(anchor='w',pady=5)
        self.cards=ResultTiles(self,body,self.select_world,limit=100,active=self.locations_visible,project=False)
        self.instances=Table(page,body,(('instance','Shared instance / visibility',520),('count','Friends observed',150)),height=4,select=self.select_instance)
        self.friends=Table(page,body,(('name','Friend',200),('pin','Priority',90),('status','Status',140),('fresh','Freshness',350)),height=6)
        row=line(page,body)
        button(page,row,'Player profile…',lambda:page.profile(self.selected_friend()))
        button(page,row,'Watch selected friend',self.watch_friend)
        button(page,row,'Pin / unpin friend',self.toggle_pin)
        button(page,row,'Inspect / invite to selected instance…',self.invite)
        row=line(page,body);button(page,row,'Retry pictures',self.cards.retry_images)
        button(page,row,'Picture cache…',lambda:__import__('picture_cache_ui').show(self.shell))
        self.ttk.Label(body,text='Select a world to expand its shared instances and friends. Saved locations may be stale. World details load as the shared sync budget allows; counts are observed friends, not instance occupancy.',wraplength=950).pack(anchor='w',pady=6)

        self.watch_viewport=ScrollPane(self.app,self.frames['Watchlists'],min_width=480)
        body=self.watch_viewport.body;self.watch_scope=self.tk.StringVar(value='Friend ID')
        self.user=self.tk.StringVar();self.collection=self.tk.StringVar(value='Choose a collection')
        self.collections={};self.event_values={e:self.tk.BooleanVar(value=e=='online') for e in EVENTS}
        self.watch_world=self.tk.StringVar();self.minimum=self.tk.StringVar(value='3');self.mute_duration=self.tk.StringVar(value='1 hour')
        self.rules=Table(page,body,(('target','Watched friend / collection',270),('events','Alert condition',460),('mute','Mute',130)),height=5,select=self.select_rule)
        row=line(page,body);choice(page,row,self.watch_scope,('Friend ID','Local friend collection'),width=23)
        entry(page,row,self.user,48)
        row=line(page,body)
        self.collection_control=choice(page,row,self.collection,('Choose a collection',),width=60)
        button(page,row,'Refresh collections',self.refresh_collections)
        for start in (0,3):
            row=line(page,body)
            for e in EVENTS[start:start+3]:self.ttk.Checkbutton(row,text=EVENT_LABELS[e],variable=self.event_values[e]).pack(side='left',padx=6)
        row=line(page,body);self.ttk.Label(row,text='World ID (required for Enters world)').pack(side='left');entry(page,row,self.watch_world,44)
        button(page,line(page,body),'Use selected Locations world',self.use_world)
        row=line(page,body);self.ttk.Label(row,text='Friends gather: minimum in one shared instance (2–50)').pack(side='left');entry(page,row,self.minimum,5)
        row=line(page,body);button(page,row,'Save watch',self.save_watch);button(page,row,'Remove selected watch',self.remove_watch)
        row=line(page,body);choice(page,row,self.mute_duration,('15 minutes','1 hour','8 hours'),width=15)
        button(page,row,'Mute selected watch',self.mute_watch);button(page,row,'Unmute selected watch',lambda:self.mute_watch(0))
        self.ttk.Label(body,text='Enters world and Leaves Busy require a fresh earlier observation. Friends gather applies to a local collection and alerts when its threshold is crossed in one explicitly shared instance. A World ID also limits gathering alerts; blank means any shared world. Mutes expire automatically without replaying missed alerts.',wraplength=950).pack(anchor='w',pady=6)
        self.ttk.Label(body,text='Only selected friends or local friend collections trigger alerts. Saved per signed-in account. Online alerts use live reports; status/location alerts need a fresh earlier observation. Quiet hours, Do Not Disturb, cooldowns and notification ownership apply. Snapshot catch-up does not replay alerts.',wraplength=950).pack(anchor='w',pady=6)
        self.alerts=Table(page,body,(('time','Observed (UTC)',175),('name','Friend',200),('event','Watchlist update',450)),height=6)
        self.ttk.Label(body,text='Latest 200 watchlist observations from this session. Listed events may have been silenced by your notification settings.',wraplength=950).pack(anchor='w')

        body=self.frames['Reconnect recap'];self.recap_text=self.tk.StringVar();self.recap_detail=self.tk.StringVar()
        self.ttk.Label(body,textvariable=self.recap_text,wraplength=980).pack(anchor='w',pady=8)
        self.recap=Table(page,body,(('name','Friend',160),('field','Observation',130),('before','Before gap / saved',280),('after','After reconnect',280)),height=8,select=self.select_recap)
        self.ttk.Label(body,textvariable=self.recap_detail,wraplength=980).pack(anchor='w',pady=6)
        button(page,line(page,body),'Player profile…',self.recap_profile)

    @property
    def activity(self):return self.sync.activity

    def locations_visible(self):
        return not self.closed and self.shell.current=='Feed' and str(self.tabs.select())==str(self.frames['Locations'])

    def selected_friend(self):
        row=self.friends.selected()
        if not row:raise ValueError('Select a friend in the expanded list.')
        return entity('user',row)

    def select_world(self):
        selected=self.cards.selected();group=self.groups.get(selected.id) if selected else None
        rows=[dict(location=key,friends=rows) for key,rows in group['instances'].items()] if group else []
        self.instances.set(rows,lambda r:(r['location'],len(r['friends'])),identity=lambda r:r['location'])
        if rows and not self.instances.selected():self.instances.tree.selection_set('0')
        self.select_instance()

    def select_instance(self):
        row=self.instances.selected()
        self.friends.set(row['friends'] if row else [],lambda r:(r.get('displayName') or r['id'],'Pinned' if r['id'] in self.filters['pins'] else 'Watched' if r['id'] in self.priority else '',r.get('status','Unavailable'),self.sync.freshness(r['id'])),identity=lambda r:r['id'])

    def filter_form(self):
        selected=self.filter_collection.get()
        if selected!='All collections' and selected not in self.collections:raise ValueError('Choose an available friend collection or All collections.')
        return dict(friend=self.filter_friend.get(),world=self.filter_world.get(),presence=self.filter_presence.get(),
            platform=self.filter_platform.get(),collection=self.collections.get(selected),pin_watched=bool(self.pin_watched.get()),pins=list(self.filters['pins']))

    def show_filters(self):
        for name in ('friend','world','presence','platform'):getattr(self,'filter_'+name).set(self.filters[name])
        selected=self.filters['collection']
        self.filter_collection.set(next((k for k,v in self.collections.items() if v==selected),'Missing collection' if selected else 'All collections'))
        self.pin_watched.set(self.filters['pin_watched'])

    def load_filters(self):
        account=self.sync.model.account if self.sync.model else ''
        try:self.filters=friend_filters.settings(self.shell.store.option(friend_filters.KEY+account),account)
        except (ValueError,TypeError):self.filters=friend_filters.settings(None,account)
        self.show_filters()

    def persist_filters(self,value):
        from account_actions import local_writable
        from account_header import private
        local_writable(self.app);self.sync.sync_context()
        if not self.sync.model or private(self.app):raise ValueError('Sign in and reveal account information first.')
        if self.token!=self.context():self.tick();raise ValueError('The account changed. Choose filters again.')
        account=self.sync.model.account;value=friend_filters.settings(value,account)
        self.shell.store.set_option(friend_filters.KEY+account,value);self.filters=value;self.show_filters();self.signature=None;self.tick()

    def apply_filters(self):self.persist_filters(self.filter_form())

    def reset_filters(self):self.persist_filters(dict(friend_filters.settings(None,''),pins=list(self.filters['pins'])))

    def refresh_filters(self):
        from account_header import private
        if private(self.app):raise ValueError('Reveal account information first.')
        self.refresh_collections();self.signature=None;self.tick()

    def toggle_pin(self):
        ref=self.selected_friend().id;pins=list(self.filters['pins'])
        if ref in pins:pins.remove(ref)
        else:pins.append(ref)
        self.persist_filters(dict(self.filters,pins=pins))

    def invite(self):
        from world_visits import location
        from world_visits_ui import open_for_world
        row=self.instances.selected()
        if not row:raise ValueError('Select an explicitly shared instance.')
        try:world,instance=location(row['location'])
        except ValueError:raise ValueError('This location is not shared as an exact destination.') from None
        page=open_for_world(self.shell,entity('world',{'id':world}))
        page.destination.set(world+':'+instance);page.tabs.select(page.frames['Existing instance'])
        page.status.set('Shared observation selected. Inspect this destination before reviewing an invitation or join.')
        return page

    def watch_friend(self):
        self.user.set(self.selected_friend().id);self.watch_scope.set('Friend ID');self.tabs.select(self.frames['Watchlists'])

    def refresh_collections(self):
        self.collections={}
        model=self.sync.model
        if model:
            for scope in (model.account,'shared'):
                for row in self.shell.store.native.collections(scope,'friend'):
                    label=row['data']['name']+' · '+('Shared' if scope=='shared' else 'This account')+' · '+row['id'][:8]
                    self.collections[label]=dict(scope=scope,target=row['id'])
        self.collection_control.configure(values=tuple(self.collections) or ('Choose a collection',))
        self.filter_collection_control.configure(values=('All collections',)+tuple(self.collections))
        if self.collection.get() not in self.collections:self.collection.set(next(iter(self.collections),'Choose a collection'))
        self.activity.members_due=0

    def rule_name(self,row):
        if row['kind']=='user':
            friend=self.sync.model.friends.get(row['target'],{}) if self.sync.model else {}
            return str(friend.get('displayName') or row['target'])
        return next((k for k,v in self.collections.items() if v==dict(scope=row['scope'],target=row['target'])), 'Missing collection · '+row['target'])

    def save_watch(self):
        self.watch_ready()
        if self.watch_scope.get()=='Friend ID':
            row=dict(kind='user',scope=self.sync.model.account,target=self.user.get().strip())
        else:
            selected=self.collections.get(self.collection.get())
            if not selected:raise ValueError('Choose an existing local friend collection.')
            row=dict(kind='collection',**selected)
        row['events']=[e for e in EVENTS if self.event_values[e].get()]
        if self.watch_world.get().strip():row['world']=self.watch_world.get().strip()
        if 'gathering' in row['events']:
            try:row['minimum']=int(self.minimum.get())
            except ValueError:raise ValueError('Use a whole number from 2 to 50 for Friends gather.') from None
        previous=next((r for r in self.activity.rules if (r['kind'],r['scope'],r['target'])==(row['kind'],row['scope'],row['target'])),{})
        if previous.get('muted_until'):row['muted_until']=previous['muted_until']
        rows=[r for r in self.activity.rules if (r['kind'],r['scope'],r['target'])!=(row['kind'],row['scope'],row['target'])]
        self.activity.save_rules(rows+[row]);self.signature=None;self.tick()
        self.page.status.set('Watch saved for this account. Future matching live observations use your notification settings.')

    def remove_watch(self):
        self.watch_ready()
        row=self.rules.selected()
        if not row:raise ValueError('Select a watch first.')
        self.activity.save_rules([r for r in self.activity.rules if r!=row]);self.signature=None;self.tick()

    def select_rule(self):
        row=self.rules.selected()
        if not row:return
        self.watch_scope.set('Friend ID' if row['kind']=='user' else 'Local friend collection')
        if row['kind']=='user':self.user.set(row['target'])
        else:self.collection.set(self.rule_name(row))
        for e in EVENTS:self.event_values[e].set(e in row['events'])
        self.watch_world.set(row.get('world',''));self.minimum.set(str(row.get('minimum',3)))

    def use_world(self):
        selected=self.cards.selected()
        if not selected or selected.kind!='world':raise ValueError('Choose a shared world on Locations first.')
        self.watch_world.set(selected.id)

    def mute_watch(self,seconds=None):
        self.watch_ready()
        row=self.rules.selected()
        if not row:raise ValueError('Select a watch first.')
        if seconds is None:seconds={'15 minutes':900,'1 hour':3600,'8 hours':28800}[self.mute_duration.get()]
        self.activity.mute(row,seconds);self.signature=None;self.tick()

    def watch_ready(self):
        from account_header import private
        self.sync.sync_context()
        if not self.sync.model or private(self.app):raise ValueError('Sign in and reveal account information first.')
        if self.token!=self.context():self.tick();raise ValueError('The account changed. Select the watch again.')

    def rule_condition(self,row):
        text=', '.join(EVENT_LABELS[e] for e in row['events'])
        if 'gathering' in row['events']:text+=f" · ≥{row.get('minimum',3)} friends"
        if row.get('world'):text+=' · '+row['world']
        return text

    def mute_label(self,row):
        import math
        remaining=self.activity.mute_remaining(row)
        return f'Muted · {math.ceil(remaining/60)} min' if remaining else 'Active'

    def select_recap(self):
        row=self.recap.selected()
        self.recap_detail.set((row['name']+' · '+row['field']+'\nBefore: '+row['before']+'\nAfter: '+row['after']) if row else '')

    def recap_profile(self):
        row=self.recap.selected()
        if not row:raise ValueError('Select a friend from the recap.')
        self.page.profile(entity('user',dict(id=row['id'],displayName=row['name'])))

    def queue_world(self):
        watch=self.sync.watches.get('friend-locations')
        if watch and not watch['valid']():self.sync.unwatch('friend-locations')
        if not self.locations_visible() or self.sync.blocked() or 'friend-locations' in self.sync.watches:return
        catalog=catalog_for(self.shell)
        wanted=next((g['world'] for g in self.groups.values() if g['world'] and g['world'] not in self.attempted and ('world',g['world']) not in catalog.rows),None)
        if not wanted:return
        token=self.context();after=catalog.revision
        def publish(result):
            catalog.publish(result.data,after=after);self.attempted.add(wanted);self.sync.unwatch('friend-locations')
        def valid():return token==self.context() and self.locations_visible() and wanted in self.groups
        from companion_api import read
        self.sync.watch('friend-locations',lambda c,s:read(c,'world-search',query=wanted,stop=s),publish,valid,immediate=True)

    def clear(self):
        self.cards.set([]);self.instances.set([],lambda r:());self.friends.set([],lambda r:())
        self.rules.set([],lambda r:());self.alerts.set([],lambda r:());self.recap.set([],lambda r:())
        self.recap_detail.set('');self.recap_text.set('');self.location_summary.set('')
        self.user.set('');self.groups={};self.signature=None;self.attempted.clear();self.collections={}
        self.collection.set('Choose a collection');self.collection_control.configure(values=('Choose a collection',))
        self.filters=friend_filters.settings(None,'');self.priority=set();self.show_filters()
        self.filter_collection_control.configure(values=('All collections',))
        self.watch_world.set('');self.minimum.set('3')
        for e in EVENTS:self.event_values[e].set(e=='online')
        self.sync.unwatch('friend-locations')

    def tick(self):
        from account_header import private
        if self.closed:return
        current=self.context()
        if current!=self.token:
            self.clear();self.token=current
            if not private(self.app):self.refresh_collections();self.load_filters()
        if private(self.app) or not self.sync.model:return
        catalog=catalog_for(self.shell);worlds=catalog.snapshot()
        signature=(self.sync.model.revision,self.activity.revision,catalog.revision,int(self.sync.clock()//30),self.sync.pipe_state,self.sync.blocked())
        if signature!=self.signature:
            selected=self.filters['collection']
            members=friend_filters.collection_members(self.shell.store,[(selected['scope'],selected['target'])]) if selected else {}
            rows,self.priority=friend_filters.filter_friends(self.sync.model.friends.values(),worlds,self.filters,members=members,watched=self.activity.watched_ids())
            groups=grouped_locations(rows,worlds,priority=self.priority)
            self.groups={g['id']:g for g in groups[:100]}
            self.cards.set([g['card'] for g in self.groups.values()],preserve=True);self.select_world()
            self.location_summary.set(f'{len(rows)} of {len(self.sync.model.friends)} observed friends match · showing {len(self.groups)} of {len(groups)} location groups. Filters and pins are saved for this account; platform is a reported value, not headset mode.')
            self.rules.set(self.activity.rules,lambda r:(self.rule_name(r),self.rule_condition(r),self.mute_label(r)),identity=lambda r:(r['kind'],r['scope'],r['target']))
            self.alerts.set(list(reversed(self.activity.alerts)),lambda r:(r['observed_at'],r['senderUsername'],r['message']))
            self.recap_text.set(self.activity.recap_summary())
            self.recap.set(self.activity.recap_rows(),lambda r:(r['name'],r['field'],r['before'][:180],r['after'][:180]),identity=lambda r:(r['id'],r['field']))
            self.select_recap();self.signature=signature
        self.cards.tick();self.queue_world()

    def close(self):
        self.closed=True;self.cards.close();self.sync.unwatch('friend-locations')
