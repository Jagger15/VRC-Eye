"""Device-owned background image, bounded decoding and native ttk decoration."""
from copy import deepcopy
from hashlib import sha256
import io
from pathlib import Path
import re

KEY='ui.background.asset.v1'


def decode(path):
    from inspection_inputs import snapshot
    data,_=snapshot(path,20*1024*1024)
    try:
        from PIL import Image,ImageOps
    except ImportError:
        from wallpaper_png import decode as read_png,encode,thumbnail
        return encode(thumbnail(read_png(data)))
    try:
        with Image.open(io.BytesIO(data)) as source:
            if source.format not in ('PNG','JPEG','WEBP') or source.width*source.height>16000000:
                raise ValueError('Choose a PNG, JPEG or WebP image up to 16 million pixels.')
            source.seek(0);image=ImageOps.exif_transpose(source).convert('RGBA')
            image.thumbnail((2560,1440),Image.Resampling.LANCZOS)
        out=io.BytesIO();image.save(out,format='PNG')
        return out.getvalue()
    except (Image.DecompressionBombError,OSError) as error:
        raise ValueError('The background image could not be decoded within its limits.') from error


def asset_path(store,value):
    if not isinstance(value,dict) or set(value)!={'schema','sha256'} or type(value['schema']) is not int or value['schema']!=1 or not isinstance(value['sha256'],str) or not re.fullmatch('[0-9a-f]{64}',value['sha256']):
        raise ValueError('Choose a new local background image.')
    return Path(store.path).parent/'appearance'/('background-'+value['sha256']+'.png')


def install(store,data,*,expected,guard=lambda:None):
    from inspection_inputs import snapshot
    from photo_organize import publish
    from creator_projects import assert_no_links
    guard();value=dict(schema=1,sha256=sha256(data).hexdigest());path=asset_path(store,value)
    assert_no_links(path.parent);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        _,digest=snapshot(path,20*1024*1024)
        if digest!=value['sha256']:raise ValueError('The saved background changed. Remove it before choosing it again.')
    else:publish(path,data,guard)
    guard();store.set_option(KEY,value,expected=expected)
    # Retain the current image only. Replacing the original external image is
    # never part of this operation; stale local copies are harmless on failure.
    if expected and expected!=value:
        try:asset_path(store,expected).unlink(missing_ok=True)
        except (ValueError,OSError):pass
    return value


def load(store):
    from inspection_inputs import snapshot
    value=store.option(KEY)
    if value is None:return None
    data,digest=snapshot(asset_path(store,value),20*1024*1024)
    if digest!=value['sha256']:raise ValueError('The saved background no longer matches its recorded image.')
    try:
        from PIL import Image
    except ImportError:
        from wallpaper_png import decode as read_png
        return read_png(data,max_size=(2560,1440))
    with Image.open(io.BytesIO(data)) as image:
        if image.format!='PNG' or image.width>2560 or image.height>1440:raise ValueError('The saved background exceeds its limits.')
        return image.convert('RGBA')


def composite(image,size,color,opacity):
    from wallpaper_png import Raster,composite as png_composite
    if isinstance(image,Raster):return png_composite(image,size,color,opacity)
    try:
        from PIL import Image,ImageOps
    except ImportError:
        return png_composite(image,size,color,opacity)
    if type(opacity) is not int or not 0<=opacity<=100:raise ValueError('Opacity must be an integer from 0 to 100.')
    w,h=size
    if not 1<=w<=4096 or not 1<=h<=2160:raise ValueError('Background preview size exceeds its limit.')
    base=Image.new('RGB',(w,h),color)
    if image is not None and opacity:
        layer=ImageOps.fit(image,(w,h),method=Image.Resampling.BILINEAR)
        base.paste(layer,(0,0),layer.getchannel('A').point(lambda a:round(a*opacity/100)))
    return base


def photo_image(image,*,master):
    """Use Tk's built-in PPM reader for dependency-free rendered frames."""
    from wallpaper_png import Raster
    if isinstance(image,Raster):
        from tkinter import PhotoImage
        return PhotoImage(data=image.ppm(),format='PPM',master=master)
    from PIL import ImageTk
    return ImageTk.PhotoImage(image,master=master)


def rounded_image(fill,outline,*,size=28,radius=8,width=1):
    from PIL import Image,ImageDraw
    image=Image.new('RGBA',(size*3,size*3))
    ImageDraw.Draw(image).rounded_rectangle((2,2,size*3-3,size*3-3),radius=radius*3,fill=fill,outline=outline,width=width*3)
    return image.resize((size,size),Image.Resampling.LANCZOS)


def rounded(app,style,preferences,colors):
    """Replace decorations only; retain native text, focus and input elements."""
    names=('TButton','Accent.TButton','Quiet.TButton','Nav.TButton','Selected.Nav.TButton','TEntry','TSpinbox','TCombobox')
    if not hasattr(app,'_flat_controls'):
        app._flat_controls={name:deepcopy(style.layout(name)) for name in names}
        app._rounded_images={}
    for name,layout in app._flat_controls.items():style.layout(name,deepcopy(layout))
    if not preferences.rounded_controls or preferences.contrast!='Default':return
    from PIL import ImageTk
    bg,panel,text,muted,accent,hover,line,selected=colors
    for name in names:
        fill=accent if name=='Accent.TButton' else selected if name=='Selected.Nav.TButton' else bg if name in ('Nav.TButton','Quiet.TButton') else panel
        variants=(('normal',fill,line),('disabled',panel,line),('focus',fill,accent),('active',hover,line),('pressed',selected,accent))
        images=[]
        for state,surface,edge in variants:
            image=rounded_image(surface,edge,width=2 if state=='focus' else 1)
            key=(name,state)
            if key in app._rounded_images:app._rounded_images[key].paste(image)
            else:app._rounded_images[key]=ImageTk.PhotoImage(image,master=app.root)
            images.append(app._rounded_images[key])
        element='EyeRound.'+name
        if element not in style.element_names():
            style.element_create(element,'image',images[0],('disabled',images[1]),('focus',images[2]),('pressed',images[4]),('active',images[3]),border=10,sticky='nsew')
        layout=deepcopy(app._flat_controls[name])
        # Clam's border/field owns the original focus/padding/label or input
        # subtree. Preserve the subtree, arrows and bindtags verbatim.
        layout[0]=(element,layout[0][1]);style.layout(name,layout)


class Backdrop:
    """One retained image and a debounced render for the shell banner/margins."""
    def __init__(self,app,outer,header):
        self.app,self.outer,self.header=app,outer,header
        self.image=None;self.photo=None;self.pending=None;self.loaded=object();self.last=None;self.closed=False
        self.style=app.ttk.Style(app.root);self.original_header_padding=()
        self.style.layout('EyeBackdrop.TFrame',[('Frame.border',dict(sticky='nswe'))])
        self.outer.bind('<Configure>',self.schedule,add='+')

    def schedule(self,event=None):
        if self.closed:return
        if self.pending:self.app.root.after_cancel(self.pending)
        self.pending=self.app.root.after(150,self.paint)

    def apply(self,preferences):
        self.preferences=preferences;self.last=None;self.schedule()

    def paint(self):
        if self.closed:return
        self.pending=None;app=self.app;preferences=self.preferences
        from account_header import private
        blocked=private(app) or getattr(app,'safe_mode',False) or getattr(app,'demo',False) or preferences.contrast!='Default'
        store=app.sidebar.store;value=None if blocked else store.option(KEY)
        if value!=self.loaded:
            self.loaded=deepcopy(value);self.image=None
            if value:
                try:self.image=load(store)
                except (OSError,ValueError,ImportError):pass
        enabled=self.image is not None and preferences.background_opacity>0 and not blocked
        self.header.configure(padding=(12,26) if enabled else self.original_header_padding)
        if not enabled:
            self.outer.configure(style='TFrame');self.header.configure(style='TFrame');self.last=None;return
        size=(max(1,min(4096,self.outer.winfo_width())),max(1,min(2160,self.outer.winfo_height())))
        signature=(size,preferences.background_opacity,app.BG,value)
        if signature==self.last:return
        image=composite(self.image,size,app.BG,preferences.background_opacity)
        # Named image is replaced in place so the ttk element remains bounded.
        if self.photo is None:
            self.photo=photo_image(image,master=app.root)
            self.style.element_create('EyeBackground','image',self.photo,sticky='nswe',width=1,height=1,padding=0)
            self.style.layout('EyeBackdrop.TFrame',[('EyeBackground',dict(sticky='nswe'))])
        else:
            # PhotoImage.paste requires identical dimensions. Tcl's image copy
            # supports size changes while keeping the referenced image name.
            temporary=photo_image(image,master=app.root)
            app.root.tk.call(str(self.photo),'copy',str(temporary),'-shrink')
        self.outer.configure(style='EyeBackdrop.TFrame');self.header.configure(style='EyeBackdrop.TFrame');self.last=signature

    def tick(self):
        from account_header import private
        token=(private(self.app),getattr(self.app,'safe_mode',False),getattr(self.app,'demo',False))
        if token!=getattr(self,'privacy_token',None):
            if self.pending:self.app.root.after_cancel(self.pending)
            self.privacy_token=token;self.paint()

    def close(self):
        self.closed=True
        if self.pending:self.app.root.after_cancel(self.pending)
        self.pending=None;self.image=None;self.photo=None
