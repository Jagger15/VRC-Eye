"""In-app mascot drawings and explicit local celebration previews."""
import math
import time
from companion_ui import button,choice,entry
from friendly_ui import flow_line as line
from novelty import install,SKINS,validate

class NoveltySettings:
    def __init__(self,page,parent):
        self.page,self.app=page,page.app;self.engine=install(self.app);self.vars={};p=self.engine.settings
        self.frame=parent
        def toggle(key,text):
            var=page.tk.BooleanVar(value=p[key]);self.vars[key]=var;page.ttk.Checkbutton(parent,text=text,variable=var).pack(anchor='w',pady=3)
        toggle('enabled','Enable novelty presentation');toggle('ow0','Ow0 wording · R → W in navigation and Home descriptions')
        toggle('birthday','Celebrate my birthday once per year');row=line(page,parent)
        for key,title,limit in (('month','Month',12),('day','Day',31)):
            page.ttk.Label(row,text=title).pack(side='left');self.vars[key]=page.tk.IntVar(value=p[key]);page.ttk.Spinbox(row,from_=1,to=limit,textvariable=self.vars[key],width=5).pack(side='left',padx=8)
        self.vars['name']=page.tk.StringVar(value=p['name']);row=line(page,parent);page.ttk.Label(row,text='Greeting name (optional)').pack(side='left');entry(page,row,self.vars['name'],25)
        self.vars['feb29']=page.tk.StringVar(value=p['feb29']);row=line(page,parent);page.ttk.Label(row,text='February 29 in other years').pack(side='left');choice(page,row,self.vars['feb29'],('February 28','March 1','Leap years only'))
        toggle('weekend','Show the weekend conure');row=line(page,parent);self.days=[]
        for index,name in enumerate(('Mon','Tue','Wed','Thu','Fri','Sat','Sun')):
            v=page.tk.BooleanVar(value=index in p['days']);self.days.append(v);page.ttk.Checkbutton(row,text=name,variable=v).pack(side='left')
        self.vars['frequency']=page.tk.StringVar(value=p['frequency']);row=line(page,parent);page.ttk.Label(row,text='Weekend frequency').pack(side='left');choice(page,row,self.vars['frequency'],('Weekly','Daily','Manual only'))
        self.vars['message']=page.tk.StringVar(value=p['message']);row=line(page,parent);page.ttk.Label(row,text='Weekend message').pack(side='left');entry(page,row,self.vars['message'],44)
        self.vars['animation']=page.tk.StringVar(value=p['animation']);row=line(page,parent);page.ttk.Label(row,text='Motion').pack(side='left');choice(page,row,self.vars['animation'],('Off','Gentle','Celebrate'))
        toggle('sounds','Short system chime · volume follows your operating system');toggle('show_mascot','Keep a quiet mascot on Home')
        self.vars['skin']=page.tk.StringVar(value=p['skin']);row=line(page,parent);page.ttk.Label(row,text='Mascot').pack(side='left');choice(page,row,self.vars['skin'],SKINS)
        row=line(page,parent);button(page,row,'Save novelty settings',self.save)
        button(page,row,'Preview birthday',lambda:self.preview('birthday'));button(page,row,'Preview weekend',lambda:self.preview('weekend'));button(page,row,'Preview mascot',lambda:self.preview('mascot'))
        page.ttk.Label(parent,text='Previews stay local and do not consume calendar events. Birthdays need no birth year. Automatic celebrations appear on the first eligible Home visit on the launch date. Weekly conures use the local ISO calendar week. Motion ends after five seconds; Reduced Motion, DND, privacy and quiet hours suppress effects. Usernames, paths, messages and diagnostic values keep their exact wording.',style='Muted.TLabel',wraplength=850,justify='left').pack(anchor='w',fill='x',pady=10)
    def candidate(self):return validate(dict(self.engine.settings,**{k:v.get() for k,v in self.vars.items()},days=[i for i,v in enumerate(self.days) if v.get()]))
    def save(self):self.engine.save(self.candidate());self.page.status.set('Novelty preferences saved')
    def preview(self,kind):
        from account_header import private
        if private(self.app):raise ValueError('Novelty previews are hidden by the current privacy or Demo setting.')
        prefs=self.candidate();self.page.shell.show('Home');self.engine.present(kind,preview=True,settings=prefs)
        self.page.shell.pages['Home'].novelty.render()

class NoveltyPanel:
    def __init__(self,page,parent):
        self.page,self.app=page,page.app;self.engine=install(self.app)
        self.slot=page.ttk.Frame(parent);self.slot.pack(fill='x')
        self.frame=page.ttk.Frame(self.slot,style='Card.TFrame',padding=12)
        self.canvas=page.tk.Canvas(self.frame,width=180,height=125,highlightthickness=0);self.canvas.pack(side='left')
        body=page.ttk.Frame(self.frame,style='Card.TFrame');body.pack(side='left',fill='both',expand=True,padx=12)
        self.message=page.tk.StringVar();page.ttk.Label(body,textvariable=self.message,style='CardValue.TLabel',wraplength=550).pack(anchor='w')
        row=page.ttk.Frame(body,style='Card.TFrame');row.pack(anchor='w',pady=8)
        button(page,row,'Wave',lambda:self.engine.present('mascot',preview=True));button(page,row,'Dismiss',self.engine.dismiss)
        button(page,row,'Novelty settings…',self.settings)
        self.last=None
    def settings(self):
        self.page.shell.show('Customization');p=self.page.shell.pages['Customization'];p.tabs.select(p.frames['Novelty'])
    def render(self):
        from account_header import private
        state=self.engine.state;p=self.engine.settings
        if self.page.shell.current!='Home':return
        visible=not private(self.app) and (state is not None or p['enabled'] and p['show_mascot'])
        if not visible:self.frame.pack_forget();return
        self.frame.pack(fill='x',pady=(2,12))
        from mod_tools import presentation_due
        if not presentation_due(self.app,'mascot',.2):return
        from mascot_pack import render_home
        if render_home(self):return
        elapsed=time.monotonic()-state['started'] if state else 6
        motion=state is not None and state['animation']!='Off' and elapsed<5 and not getattr(getattr(self.app,'presentation',None),'reduced_motion',False) and not self.engine.quiet()
        phase=math.sin(elapsed*5)*5 if motion else 0;skin=state['skin'] if state else p['skin']
        text=state['text'] if state else 'Your quiet VRC Eye companion'
        self.message.set(('Local preview · ' if state and state['preview'] else '')+text)
        signature=(skin,round(phase),self.app.PANEL,self.app.ACCENT,bool(state),state['animation'] if state else '')
        if signature==self.last:return
        self.last=signature;c=self.canvas;c.configure(background=self.app.PANEL);c.delete('all');y=phase
        if skin=='Conure':
            c.create_polygon(71,80+y,61,120,88,91+y,fill='#31868b',outline='')
            c.create_oval(49,45+y,116,105+y,fill='#47aa6b',outline=self.app.TEXT,width=1)
            c.create_oval(75,23+y,120,68+y,fill='#f4c950',outline='')
            c.create_oval(50,49+y,88,95+y,fill='#38895d',outline='')
            c.create_polygon(115,43+y,135,50+y,116,57+y,fill='#ef8541',outline='')
            c.create_oval(104,34+y,113,43+y,fill='white',outline='');c.create_oval(108,37+y,112,41+y,fill='#121827')
            for x in (79,101):c.create_line(x,100+y,x,111,x+8,111,fill=self.app.TEXT,width=2)
        elif skin=='Cat':
            c.create_polygon(53,60+y,52,27+y,77,46+y,102,46+y,128,27+y,125,70+y,fill=self.app.ACCENT,outline='')
            c.create_oval(51,42+y,130,104+y,fill=self.app.ACCENT,outline=self.app.TEXT)
            for x in (75,109):c.create_oval(x-4,67+y,x+4,75+y,fill='#172033',outline='')
            c.create_polygon(88,81+y,96,81+y,92,87+y,fill='#172033')
        elif skin=='Slime':
            c.create_oval(43,48+y,136,107+y,fill=self.app.ACCENT,outline=self.app.TEXT)
            for x in (77,105):c.create_oval(x-3,74+y,x+3,82+y,fill='#172033',outline='')
            c.create_arc(80,78+y,102,94+y,start=180,extent=180,style='arc',outline='#172033',width=2)
        else:
            if skin=='Drone':
                for x in (30,120):c.create_oval(x,36+y,x+32,47+y,outline=self.app.TEXT,width=3)
                c.create_line(48,48+y,71,69+y,108,69+y,139,48+y,fill=self.app.ACCENT,width=3)
            c.create_oval(54,45+y,126,103+y,fill=self.app.ACCENT,outline=self.app.TEXT,width=2)
            c.create_oval(68,58+y,112,91+y,fill='white',outline='');c.create_oval(82+phase,63+y,103+phase,86+y,fill='#172033',outline='')
        if state and state['kind']=='birthday':
            c.create_polygon(83,23+y,99,3+y,114,25+y,fill='#f0a5cc',outline='')
            if state['animation']!='Off':
                for n in range(12 if state['animation']=='Gentle' else 24):
                    x=(n*47)%175;y2=((n*29)+int(elapsed*9 if motion else 0))%120
                    c.create_oval(x,y2,x+3,y2+3,fill=self.app.ACCENT,outline='')
