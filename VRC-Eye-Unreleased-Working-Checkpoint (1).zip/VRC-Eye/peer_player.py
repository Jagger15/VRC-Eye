"""Explicit local player-to-device associations; never proof of VRChat identity."""

from text_viewport import window_body
from companion_data import entity_id
import sqlite3


def _available(app):
    players = getattr(app, 'player_sessions', None)
    if bool(getattr(app, 'demo', False)):
        raise ValueError('Player links are unavailable in Demo.')
    if players and players.settings.get('presentation'):
        raise ValueError('Disable presentation mode to view private player links.')
    service = getattr(app, 'peer_service', None)
    if service is None:
        raise ValueError('Open VRC Eye Primary to access peer tools.')
    return service


def _links(app):
    cached = getattr(app, '_peer_player_links', None)
    if cached is not None:
        return cached
    raw = app.sidebar.store.option('peer.player_links', {})
    result = {}
    if isinstance(raw, dict):
        for user, peer in list(raw.items())[:2000]:
            try:
                user = entity_id('user', user)
            except ValueError:
                continue
            if isinstance(peer, str) and 1 <= len(peer) <= 128:
                result[user] = peer
    app._peer_player_links = result
    return result


def save_link(app, user_id, peer_id):
    service = _available(app)
    user_id = entity_id('user', user_id)
    links = dict(_links(app))
    if peer_id:
        known = {p.get('peer_id', p.get('id')) for p in service.snapshot().get('peers', [])}
        if peer_id not in known:
            raise ValueError('Choose a known VRC Eye device first.')
        if user_id not in links and len(links) >= 2000:
            raise ValueError('Remove an unused player link before adding another.')
        links[user_id] = peer_id
    else:
        links.pop(user_id, None)
    app.sidebar.store.set_option('peer.player_links', links)
    app._peer_player_links = links


def player_index(app):
    """One bounded snapshot for a complete visible roster, with no remote lookup."""
    try:
        service = _available(app)
        links = _links(app)
    except (ValueError, OSError, sqlite3.Error):
        return {}
    if not links:
        return {}
    peers = {p.get('peer_id', p.get('id')): p for p in service.snapshot().get('peers', [])}
    return {user: dict(peer_id=peer, peer=peers.get(peer)) for user, peer in links.items()}


def summary(app, user_id):
    item = player_index(app).get(user_id)
    if not item:
        return 'No locally linked VRC Eye device. Use VRC Eye link to associate a device explicitly.'
    peer = item['peer']
    lines = ['Device associated by you on this computer; VRChat account identity is not verified.']
    if peer:
        lines.append('Connection: ' + str(peer.get('state', 'Unknown')))
        lines.append('VRC Eye version: ' + str(peer.get('version', 'Unknown')))
        caps = peer.get('capabilities', [])
        lines.append(f'Advertised capabilities: {len(caps)}. Actions also require permission.')
    else:
        lines.append('Connection: not currently available. A saved link does not establish presence.')
    return '\n'.join(lines)


def open_peer_player(app, user_id='', alias=''):
    """Review a local association or navigate to its existing peer; never connect/send."""
    service = _available(app)
    if not user_id:
        app.sidebar.show('VRC Eye Primary')
        return
    user_id = entity_id('user', user_id)
    from tkinter import messagebox
    import tkinter as tk
    from tkinter import ttk
    window = tk.Toplevel(app.root)
    window.title('VRC Eye player link')
    window.geometry('720x330')
    box = ttk.Frame(window_body(window), padding=16)
    box.pack(fill='both', expand=True)
    ttk.Label(box, text=alias or user_id, style='Title.TLabel').pack(anchor='w')
    ttk.Label(box, text='Associate a VRC Eye device with this player on this computer. '
              'This does not verify their VRChat identity, grant permissions or send data.',
              wraplength=660).pack(anchor='w', pady=10)
    peers = service.snapshot().get('peers', [])
    choices = {'No linked device': ''}
    for peer in peers:
        peer_id = peer.get('peer_id', peer.get('id', ''))
        if not peer_id:
            continue
        label = str(peer.get('alias') or 'VRC Eye device')[:80] + ' · ' + peer_id
        choices[label] = peer_id
    current = _links(app).get(user_id, '')
    if current and current not in choices.values():
        choices['Saved device · ' + current] = current
    selected = tk.StringVar(value=next((k for k, v in choices.items() if v == current), 'No linked device'))
    ttk.Combobox(box, textvariable=selected, values=tuple(choices), state='readonly', width=85).pack(fill='x')
    state = tk.StringVar(value=summary(app, user_id))
    ttk.Label(box, textvariable=state, wraplength=660).pack(anchor='w', pady=10)
    def account_context():
        return (getattr(app, 'data_generation', 0), getattr(app, 'api', None))
    generation = account_context()

    def guard(action):
        try:
            _available(app)
            if generation != account_context():
                raise ValueError('The account changed. Reopen the player link.')
            action()
        except (ValueError, OSError, sqlite3.Error) as error:
            state.set(str(error))

    def save():
        peer_id = choices.get(selected.get(), '')
        if peer_id == _links(app).get(user_id, ''):
            state.set('The local association is unchanged.')
            return
        if messagebox.askyesno('Save local player association',
                'Save this association only on this computer? The selected device is not verified as this VRChat account.', parent=window):
            _available(app)
            if generation != account_context():
                raise ValueError('The account changed. Reopen the player link.')
            save_link(app, user_id, peer_id)
            state.set('Local association saved. No information was sent.')

    def open_workspace():
        app.sidebar.show('VRC Eye Primary')
        page = app.sidebar.pages.get('VRC Eye Primary')
        peer_id = choices.get(selected.get(), '')
        if page and peer_id:
            page.focus_peer(peer_id)
        window.destroy()

    row = ttk.Frame(box)
    row.pack(fill='x', pady=8)
    ttk.Button(row, text='Save local link', command=lambda: guard(save)).pack(side='left', padx=4)
    ttk.Button(row, text='Open VRC Eye Primary', command=lambda: guard(open_workspace)).pack(side='left', padx=4)
    ttk.Button(row, text='Close', command=window.destroy).pack(side='right')
    windows = getattr(app, 'player_private_windows', [])
    windows = [item for item in windows if item.winfo_exists()]
    windows.append(window)
    for old in windows[:-20]:
        old.destroy()
    app.player_private_windows = windows[-20:]
    return window
