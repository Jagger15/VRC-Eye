"""Ephemeral associations over retained log evidence, never a cause detector."""
from collections import deque
from datetime import datetime
import re
import time

from media_error_reference import log_findings
from media_history import safe_url

SCHEMA='vrc-eye-media-log-analysis-1'
WINDOW_SECONDS=120
MAX_ITEMS=10000
MAX_EVENTS=200
MAX_RECENT=256
WORLD=re.compile(r'\bwrld_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b')
END=re.compile(r'\b(?:onleftroom|successfully left room|onapplicationquit)\b',re.I)


def log_time(value):
    """Preserve unknown timezone; only compare timestamps of the same kind."""
    if not isinstance(value,str) or len(value)>48:return None
    if not re.fullmatch(r'\d{4}[./-]\d{2}[./-]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,9})?(?:Z|[+-]\d{2}:?\d{2})?',value):return None
    try:return datetime.fromisoformat(value[:10].replace('.','-').replace('/','-')+value[10:].replace(',','.').replace('Z','+00:00'))
    except ValueError:return None


def elapsed(now,before):
    if now is None or before is None or (now.tzinfo is None)!=(before.tzinfo is None):return None
    return (now-before).total_seconds()


def correlate(items,saved_records=(),*,stop=None):
    if len(items)>MAX_ITEMS or len(saved_records)>500:raise ValueError('Inspect at most 10,000 retained lines and 500 saved media records.')
    deadline=time.monotonic()+10
    def check():
        if stop is not None and stop.is_set():raise ValueError('Media inspection canceled.')
        if time.monotonic()>deadline:raise ValueError('Media inspection time limit reached.')
    saved={}
    for row in saved_records:
        check();url=safe_url(row.get('url'))
        if url:saved[url]=saved.get(url,0)+1
    recent=deque(maxlen=MAX_RECENT);events=deque(maxlen=MAX_EVENTS)
    source=None;visit=None;world_id=None;previous=None;total=0;bounded=False;evicted={}
    for item in items:
        check();when=log_time(item.stamp);delta=elapsed(when,previous)
        if item.source!=source or item.category=='Worlds' or item.category=='Crashes' or END.search(item.message):
            recent.clear();evicted.clear();visit=None;world_id=None
        if item.source!=source:source=item.source
        if item.category=='Worlds':
            visit=item.serial;match=WORLD.search(item.message);world_id=match[0] if match else None
        # A backward clock jump is a boundary for time-based association.
        if delta is not None and delta<0:recent.clear();evicted.clear()
        previous=when
        if item.playback=='Playback stop/end reported':
            recent=deque((r for r in recent if r['family']!='VideoError'),maxlen=MAX_RECENT)
            evicted.pop('VideoError',None)
        findings=log_findings(item.message)
        urls=tuple(dict.fromkeys(url for raw in item.urls if (url:=safe_url(raw))))[:16]
        for finding in findings:
            family=finding['family'].rsplit('.',1)[-1]
            age=elapsed(when,evicted.get(family));limited=not urls and age is not None and 0<=age<=WINDOW_SECONDS
            candidates=[dict(serial=item.serial,log_time=item.stamp,url=url,seconds_before=0,
                             basis='URL in the same log entry',saved_url_matches=saved.get(url,0)) for url in urls]
            if candidates:basis='Same entry; the log does not establish which URL failed'
            else:
                candidates=[]
                for candidate in recent:
                    seconds=elapsed(when,candidate['when'])
                    if candidate['family']==family and seconds is not None and 0<=seconds<=WINDOW_SECONDS:
                        candidates.append(dict(serial=candidate['serial'],log_time=candidate['log_time'],url=candidate['url'],
                            seconds_before=seconds,basis='Preceding media entry within 120 seconds',saved_url_matches=saved.get(candidate['url'],0)))
                basis=('Ambiguous: several preceding media entries' if len(candidates)>1 else
                       'One preceding media entry; association only' if candidates else 'No qualifying retained media entry')
                if limited:basis='Incomplete: earlier entries inside the time window exceeded the context limit'
            row=dict(finding,observed_at=item.stamp or 'Unknown',log_serial=item.serial,
                     visit_start_serial=visit,world_id=world_id,association=basis,candidate_count=len(candidates),
                     candidates=candidates[-8:],candidates_omitted=max(0,len(candidates)-8),candidate_search_limited=limited,
                     visit_evidence='Observed world marker' if visit is not None else 'Start unavailable in retained context')
            events.append(row);total+=1
        # An error entry is never promoted to a new media request.
        family='VideoError' if item.category=='Videos' else 'VRCImageDownloadError' if item.category=='Images' else None
        if family and not findings and item.playback!='Playback stop/end reported':
            for url in urls:
                if len(recent)==MAX_RECENT:
                    bounded=True;old=recent[0]
                    if old['when'] is not None:evicted[old['family']]=old['when']
                recent.append(dict(family=family,serial=item.serial,log_time=item.stamp,when=when,url=url))
    return dict(schema=SCHEMA,events=list(reversed(events)),scanned_lines=len(items),error_count=total,
                older_errors_omitted=max(0,total-MAX_EVENTS),request_context_bounded=bounded,
                saved_records_inspected=len(saved_records),window_seconds=WINDOW_SECONDS,
                provenance='Snapshot of retained Game Log entries; explicit SDK error families only. Nearby entries and matching saved URLs are associations, not causes or proof of playback/account ownership. Up to 256 preceding media entries are considered; refresh explicitly.')


def export_document(report):
    """Allowlist export: no addresses, paths, raw logs, titles or instance tokens."""
    if report.get('schema')!=SCHEMA:return report
    fields=('family','raw_code','label','state','explanation','observed_at','log_serial','visit_start_serial','world_id',
            'association','candidate_count','candidates_omitted','candidate_search_limited','visit_evidence')
    result={k:report[k] for k in ('schema','scanned_lines','error_count','older_errors_omitted','request_context_bounded',
                                'saved_records_inspected','window_seconds','provenance')}
    result['events']=[dict({k:row[k] for k in fields},candidates=[{k:c[k] for k in
        ('serial','log_time','seconds_before','basis','saved_url_matches')} for c in row['candidates']]) for row in report['events']]
    result['export_scope']='URLs, source paths, raw log text, saved titles and instance details omitted.'
    return result
