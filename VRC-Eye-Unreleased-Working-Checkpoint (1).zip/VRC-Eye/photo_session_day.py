"""Derived photo grouping; original dates and capture evidence stay unchanged."""
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
from native_library import scope

KEY='photos.session-day.v1.'


def key(account):return KEY+scope('shared' if account=='local' else account)


def zone(value):
    if value=='Local':return None
    if value=='UTC':return timezone.utc
    if not isinstance(value,str) or len(value)>100:raise ValueError('Choose Local, UTC, or an installed IANA time zone.')
    try:return ZoneInfo(value)
    except (ValueError,ZoneInfoNotFoundError):raise ValueError('Time zone unavailable on this computer. Choose Local, UTC, or an installed IANA zone.') from None


def settings(raw=None):
    value=dict(schema=1,enabled=False,cutoff=240,timezone='Local',assume_naive=False)
    if raw is not None:
        if not isinstance(raw,dict) or set(raw)!=set(value):raise ValueError('Unsupported photo session-day preferences.')
        value.update(raw)
    if type(value['schema']) is not int or value['schema']!=1 or type(value['enabled']) is not bool or type(value['assume_naive']) is not bool or type(value['cutoff']) is not int or not 0<=value['cutoff']<=1439:
        raise ValueError('Choose a valid session-day cutoff from 00:00 to 23:59.')
    zone(value['timezone']);return value


def load(store,account):return settings(store.option(key(account)))


def group(value,policy):
    if not policy['enabled']:return {'day':'','basis':'Session-day grouping off'}
    try:
        if not isinstance(value,str) or len(value)>100 or 'T' not in value and ' ' not in value:raise ValueError()
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
        target=zone(policy['timezone']);assumed=stamp.tzinfo is None
        if assumed:
            if not policy['assume_naive']:return {'day':'','basis':'Timezone unknown; not grouped'}
            # For naive declarations only wall-clock time/date is used. No
            # instant or DST fold is invented, and no capture time is rewritten.
        else:stamp=stamp.astimezone(target)
        day=stamp.date()-(timedelta(days=1) if stamp.hour*60+stamp.minute<policy['cutoff'] else timedelta())
        return {'day':day.isoformat(),'basis':('Assumed wall time in ' if assumed else 'Converted to ')+policy['timezone']}
    except (ValueError,OverflowError,OSError):return {'day':'','basis':'Date unavailable; not grouped'}


def label(value,policy):
    result=group(value,policy)
    return result['day']+' · '+result['basis'] if result['day'] else result['basis']
