"""Owned cosmetic choices feeding the existing reviewed profile action."""

from text_viewport import window_body
from companion_ui import line, button, choice
from vrcx_ui_jobs import LocalPage
from account_workspace_ui import submit_review
import native_api as api

# Identifiers in the VRCX 2026.09.16 profile editor. Entitlements are enforced
# by VRChat; a visible catalog entry is not an entitlement assertion.
BACKGROUNDS=('grid','filigree','bit-mountain','approach','planet-fall','jungle',
 'light-streams','koi','moonlight','machine','topology','circuit','kawaii-cupcakes',
 'bokeh','hologram','flow','jelly','cheese','alchemy','sunset-mountain','magic-rocks',
 'city-stillness','music','wolf-running','dragon-smoke','night-rain','butterfly-zero',
 'i-am-speed','ronin','abduction','cat-dream','virtual-waves','bolt-and-snail','escape')
COSMETICS=('iconFrame','nameplateEffect','profileEffect')


def options(profile, inventory, files, own):
    result={key:{'Keep current':None,'Clear':''} for key in (*COSMETICS,'themeId','userIcon','bannerCustomUrl')}
    result['backgroundTextureId']={'Keep current':None,**{v.replace('-',' ').title():v for v in BACKGROUNDS}}
    for row in inventory:
        key=row.get('itemType'); ref=row.get('templateId')
        if key in COSMETICS and row.get('holderId')==own and not row.get('isArchived') and isinstance(ref,str) and ref:
            result[key][str(row.get('itemName') or row.get('name') or ref)+' · '+ref]=ref
    for theme in profile.get('themes') or []:
        if isinstance(theme,dict) and theme.get('id'):
            result['themeId'][str(theme.get('name') or theme['id'])+' · '+theme['id']]=theme['id']
    for row in files:
        if row.get('ownerId')!=own:continue
        versions=row.get('versions') or []
        completed=[v.get('file',{}).get('url') for v in versions if isinstance(v,dict) and v.get('file',{}).get('status')=='complete']
        if not completed:continue
        url=completed[-1]
        try:api.patch({'userIcon':url},api.PROFILE)
        except ValueError:continue
        label=str(row.get('name') or row['id'])+' · '+row['id']
        result['userIcon'][label]=url;result['bannerCustomUrl'][label]=url
    return result


def show(owner):
    owner.require()
    return AppearanceDialog(owner)


class AppearanceDialog(LocalPage):
    def __init__(self,owner):
        self.owner=owner;self.window=owner.tk.Toplevel(owner.app.root);self.window.title('Profile appearance')
        self.window.transient(owner.app.root)
        parent=owner.ttk.Frame(window_body(self.window),padding=12);parent.pack(fill='both',expand=True)
        super().__init__(owner.shell,parent,'Profile appearance')
        self.snapshot=None;self.choices={};self.vars={};self.boxes={}
        self.ttk.Label(parent,text='Load your owned items, select changes, then review the exact profile update.\nBackground catalog choices may require VRC+. VRChat decides entitlement.',wraplength=780).pack(anchor='w')
        button(self,line(self),'Load profile and owned cosmetics',self.load)
        for key in (*COSMETICS,'themeId','backgroundTextureId','userIcon','bannerCustomUrl'):
            row=line(self);self.ttk.Label(row,text=key,width=24).pack(side='left')
            var=self.tk.StringVar(value='Keep current');self.vars[key]=var
            self.boxes[key]=choice(self,row,var,('Keep current',),width=70)
        self.ttk.Label(parent,text='For custom colors and gradients, use the Biography / appearance form.\nSelecting a texture also selects the texture background; selecting a banner image selects Custom image.',wraplength=780).pack(anchor='w',pady=8)
        button(self,line(self),'Review appearance changes…',self.submit)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=self.app.root.after(200,self.tick)
        owner.image_windows.append(self)

    def load(self):
        self.ready();self.owner.require()
        def work(c,s,p):
            profile=api.read(c,'profile',stop=s,progress=p);inventory=[];files=[]
            for kind,target in (('inventory',inventory),('icons',files),('gallery',files)):
                for offset in range(0,2000,100):
                    result=api.read(c,kind,offset=offset,stop=s,progress=p)
                    data=result.data;target.extend(data if isinstance(data,list) else data.get('data',[]))
                    if not result.more:break
                else:raise ValueError('More than 2,000 items in a category. Use the inventory filters and profile form for this account.')
            return profile,options(profile.data,inventory,files,profile.account[0])
        def done(result):
            self.snapshot,self.choices=result
            for key,var in self.vars.items():
                var.set('Keep current');self.boxes[key].configure(values=tuple(self.choices[key]))
            self.status.set('Owned choices loaded. Empty cosmetic categories mean no eligible items were returned.')
        self.start(work,done,api=True)

    def draft(self):
        if not self.snapshot:raise ValueError('Load your owned appearance choices first.')
        values={}
        for key,var in self.vars.items():
            if var.get() not in self.choices[key]:raise ValueError('Select a returned appearance choice.')
            value=self.choices[key][var.get()]
            if value is not None:values[key]=value
        if values.get('backgroundTextureId'):values.update(backgroundType='texture',backgroundTemplateId='')
        if values.get('bannerCustomUrl'):values['bannerType']='customImage'
        return values

    def submit(self):
        self.ready();self.owner.require()
        submit_review(self,'profile-edit',result=self.snapshot,values=self.draft(),
            view_guard=lambda:(self.token(),self.draft()),done=lambda outcome:(self.clear_preview(),self.status.set(outcome.message)))

    def clear_preview(self):
        self.snapshot=None;self.choices={}
        for key,var in self.vars.items():var.set('Keep current');self.boxes[key].configure(values=('Keep current',))

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(200,self.tick)

    def close(self):
        if self.closed:return
        self.app.root.after_cancel(self.timer);self.clear_preview();super().close();self.window.destroy()
        if self in self.owner.image_windows:self.owner.image_windows.remove(self)
