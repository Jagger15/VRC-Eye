"""Explicit per-source metadata-copy rules for the existing photo watcher."""
from hashlib import sha256
from pathlib import Path
import json
from contextlib import contextmanager
from creator_projects import assert_no_links,local_path
from photo_files import read_photo,directory_identity,check_directory
from photo_metadata import inspect_metadata
from photo_context import description,metadata_copy
from photo_organize import publish


@contextmanager
def connect(store):
    with store.connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS photo_compatible_rules(scope TEXT,source TEXT,enabled INTEGER,settings TEXT,PRIMARY KEY(scope,source))')
        yield db


def configure(store,scope,source,folder,*,enabled=True,sidecar=False,grouping=None):
    original=store.source(scope,source)
    if not original:raise ValueError('Choose an approved photo source.')
    folder=assert_no_links(local_path(folder));identity=directory_identity(folder)
    # A watcher must never recursively consume its own generated copies.
    for root in store.sources(scope):
        if folder.is_relative_to(local_path(root['path'])):raise ValueError('Choose an export folder outside every watched photo source.')
    settings=dict(folder=str(folder),identity=identity,sidecar=bool(sidecar))
    if grouping is not None:
        from photo_session_day import settings as day_settings
        settings['grouping']=day_settings(grouping)
    with connect(store) as db:db.execute('INSERT OR REPLACE INTO photo_compatible_rules VALUES(?,?,?,?)',(scope,source,int(enabled),json.dumps(settings)))
    return settings


def rule(store,scope,source):
    with connect(store) as db:row=db.execute('SELECT settings FROM photo_compatible_rules WHERE scope=? AND source=? AND enabled=1',(scope,source)).fetchone()
    return json.loads(row[0]) if row else None


def disable(store,scope,source):
    with connect(store) as db:db.execute('UPDATE photo_compatible_rules SET enabled=0 WHERE scope=? AND source=?',(scope,source))


def declared(raw):
    rows=inspect_metadata(raw)['candidates'];values={}
    for row in rows:
        if row['field'] in ('world_id','world_name','timestamp'):values.setdefault(row['field'],set()).add(str(row['value']))
    if any(len(v)>1 for v in values.values()):raise ValueError('Conflicting declared metadata needs manual review.')
    world=next(iter(values.get('world_id',())), '');when=next(iter(values.get('timestamp',())), '')
    if not world and not when:raise ValueError('No supported world or timestamp declaration to export.')
    return description(world,next(iter(values.get('world_name',())),''),when)


def export(store,scope,source,photo,*,check=lambda:None,stop=None):
    config=rule(store,scope,source)
    if not config:return None
    row=store.get(scope,photo)
    if not row or row['source_id']!=source:raise ValueError('The photo source changed.')
    check_directory(config['folder'],config['identity']);check()
    raw,_=read_photo(row['path'],expected=row['fingerprint'],stop=stop);fields=declared(raw)
    data=(json.dumps(fields,ensure_ascii=False,indent=2)+'\n').encode() if config['sidecar'] else metadata_copy(raw,fields)
    digest=sha256(data).hexdigest();name=sha256((row['sha256']+str(config['sidecar'])).encode()).hexdigest()
    target=Path(config['folder'])/(name+('.json' if config['sidecar'] else '.png'))
    from photo_session_day import group,settings as day_settings
    grouping=day_settings(config.get('grouping'))
    if grouping['enabled']:
        day=group(fields.get('timestamp',''),grouping)['day']
        if not day:raise ValueError('No supported capture timestamp for the enabled session-day export folders. Review this photo manually.')
        check();check_directory(config['folder'],config['identity'])
        folder=assert_no_links(Path(config['folder'])/day);folder.mkdir(exist_ok=True)
        folder_identity=directory_identity(folder);target=folder/target.name
    intent=store.begin_export(scope,photo,target,digest)
    try:
        def valid():
            check();check_directory(config['folder'],config['identity'])
            if grouping['enabled']:check_directory(target.parent,folder_identity)
            if rule(store,scope,source)!=config:raise ValueError('The compatible-export rule changed.')
        publish(target,data,valid)
        store.finish_export(scope,intent,'Saved','Compatible metadata copy verified; original photo preserved.')
        return str(target)
    except Exception:
        store.finish_export(scope,intent,'Inspect destination','Automatic export stopped. Inspect destination before any manual retry.')
        raise
