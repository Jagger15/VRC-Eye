# World Visits / Invite Me — Development 4 guide

## Scope

Open **Community → Invite Me**, or Ctrl+K → World visits · Invite Me. The workspace
has Existing instance, New personal instance and Action history. Opening it makes
no request and does not start/launch/join VRChat. World search and local/game
favorites can prefill a selected world; Photos can do the same for a manually
linked world. A world ID alone is not an instance, permission or entitlement.

This is an adapter to the community-maintained VRChat API specification, not an
official integration or proof of current live service acceptance. It uses the
existing VRChatAPI transport, request budget and one active authenticated session.
The native account-action lifecycle is fixture-tested; real invitations and
instance creation have not been sent during validation.

## Invite yourself to an existing exact instance

Enter an explicit `world:instance` reference, an instance ID with the world above,
or an exact HTTPS vrchat.com/home/launch link containing one worldId and one
instanceId. Extra/duplicate fields, other hosts, malformed paths, control text,
and private/offline placeholder markers are not accepted. Custom client locations,
hidden-instance discovery, redirect following and access bypasses are not provided.

The exact input is masked by default because it can contain a private nonce or
owner/location details. You may deliberately show it on this screen. It is not
displayed in ordinary summaries or durable receipt targets.

Choose **Inspect exact instance**. The returned world and instance identities must
match each other and your selected destination. The page shows supplied type,
region, population and capacity observations, leaving missing values unknown.
A currently active inspection expires after two minutes. Explicit full/no-capacity,
closed/inactive, eligibility-restricted or role-restricted results are not
submitted by this workspace. The server still decides current access and all
eligibility; absence of a returned restriction is not proof of permission.

Choose **Invite Me to inspected instance…**. A modal review shows the acting
account and exact private destination. Approve only the intended target. This is
one POST through a single-use review; repeated clicks/reused reviews cannot repeat
that request. Input/account/operating-mode changes during review or queued waiting
invalidate it. Uncertain outcomes block repeating the matching action until
independently reviewed and acknowledged through the shared history workflow.

The expected returned notification must identify the acting recipient, invite
type and exact selected destination. An acknowledgement is **not** proof that a
notification reached the game or that the user arrived. There is no automatic
join or launch command. Inspect again before a separate subsequent invitation.

## Create a personal instance, then separately invite yourself

Select an exact world ID or supported world webpage and choose **Read selected
world**. Select Invite only, Friends, Friends+ or Public and an exposed region.
Creation binds ownerId to the current authenticated account; it does not accept
another owner, group-role options or arbitrary request fields.

Choose **Create one personal instance…** and review. The expected creation reply
must confirm the world, consistent exact instance identity, your ownership, type
and region. An incomplete or contradictory reply is Uncertain, not falsely
presented as a new usable instance. Do not automatically repeat creation.

After acknowledged creation, its returned destination appears under Existing
instance. **No self-invitation is sent.** You must review and approve Invite Me
as a separate action, with a separate receipt and fresh inspection where needed.
The API may materialize or retain an instance differently from what its UI label
suggests; this checkpoint claims only the checked response, not game arrival or
lasting remote availability.

## Receipts and recovery

Action history is the same initiating-account system used by Dev3 Social, Game
Favorites and My profile. A receipt is durably saved before dispatch. Failed
initial receipt storage prevents sending. Confirmed, Rejected, Not sent and
Uncertain states remain distinct. A response that establishes the initiating
account's action can be recorded as Confirmed even if the visible account changed
immediately afterward; the old response is not shown in the new account's form.

For a self-invite, the durable target is the world ID plus an SHA-256 digest of
the exact location, not the raw instance capability. In-memory forms, snapshots
and explicit action reviews necessarily retain the exact reference while needed.
The existing diagnostic redactor is retained. No exact input is added to photo
metadata, settings, action receipt bodies or custom external services.

Do not confuse Confirmed with delivered/arrived, or Cancelled with remotely undone.
An already-dispatched request cannot reliably be recalled. A failed final receipt
save retains the local in-memory outcome for the existing local-only save retry.
Interrupted uncertain actions are never sent again automatically. Exported selected
history uses the existing privacy-filtered receipt format.

Privacy view and account changes clear the page's exact input and snapshots. The
privacy toggle is local to this page; it is not a complete application-wide privacy
system. Shared-world history, outbound friend-invite composition, multi-account
retained authentication and every legacy write-path migration remain separate work.

## Reference and testing boundary

The following primary community specification files were checked October 2, 2026:

https://github.com/vrchatapi/specification/blob/master/openapi/components/paths/invite.yaml
https://github.com/vrchatapi/specification/blob/master/openapi/components/paths/instances.yaml
https://github.com/vrchatapi/specification/blob/master/openapi/components/schemas/Instance.yaml
https://github.com/vrchatapi/specification/blob/master/openapi/components/requests/CreateInstanceRequest.yaml
https://github.com/vrchatapi/specification/blob/master/openapi/components/schemas/SentNotification.yaml
https://github.com/vrchatapi/specification/blob/master/openapi/components/schemas/NotificationDetailInvite.yaml

These are community-maintained schemas, not official VRChat support or approval.
Strict response checking may deliberately mark a live reply Uncertain if the
service changes. No source proves operation acceptance for a particular account.
Native Windows, live VRChat/VRCX, Unity/VPM and assistive-technology interoperability
were not tested in this checkpoint.
