"""Accessible local caption controls and a resizable desktop caption window."""
from pathlib import Path
from caption_model import Preferences,PALETTES
from companion_ui import button,entry,choice
from friendly_ui import flow_line as line
from screen_reader_model import annotate
from text_viewport import window_body


def caption_text(app,parent,owner):
    text=annotate(app.tk.Text(parent,height=owner.preferences.lines,wrap='word',state='disabled',takefocus=True),
                  name='Live caption text',role='text',description='Automatic speech recognition can be inaccurate. Partial text begins with an ellipsis. Text stays in memory unless explicitly exported.')
    text._eye_announce=False;text.pack(fill='both',expand=True,pady=8)
    return text


def paint(app,text,owner,cache):
    prefs=owner.preferences;content='' if owner.blocked() else owner.transcript.display(prefs)
    colors=PALETTES[prefs.palette]
    if colors is None:colors=(getattr(app,'TEXT','#ffffff'),getattr(app,'BG','#101820'))
    state=(content,prefs,colors)
    if cache==state:return cache
    from text_scaling import font_for
    text.configure(state='normal',font=font_for(text,prefs.points),foreground=colors[0],background=colors[1],height=prefs.lines)
    text.delete('1.0','end');text.insert('1.0',content);text.see('end');text.configure(state='disabled')
    return state


class CaptionPanel:
    def __init__(self,page,parent):
        self.page=page;self.app=page.app;self.owner=page.experience.captions;self.parent=parent;self.cache=None
        self.tk=page.tk;self.ttk=page.ttk;self.variables={}
        self.ttk.Label(parent,text='Offline live captions',style='Heading.TLabel').pack(anchor='w')
        self.ttk.Label(parent,text='Choose a microphone / virtual input, or desktop output loopback. Desktop capture includes everything audible on that endpoint; player names and individual speakers are not identified. The selected model determines the language. Captions are not translations.',wraplength=780).pack(fill='x',pady=8)
        row=line(page,parent);button(page,row,'Discover caption audio sources',self.owner.discover)
        self.source=self.tk.StringVar(value='Choose a source')
        self.source_box=annotate(choice(page,parent,self.source,('Choose a source',),self.select_source,width=48),name='Caption audio source')
        self.variables['model']=self.tk.StringVar(value=self.owner.preferences.model)
        self.ttk.Label(parent,text='Extracted local Vosk speech model folder').pack(anchor='w',pady=(8,0))
        row=line(page,parent);annotate(entry(page,row,self.variables['model'],42),name='Local caption speech model folder')
        button(page,row,'Choose model folder…',self.choose_model)
        row=line(page,parent);button(page,row,'Speech model downloads',self.models);button(page,row,'Open setup health',lambda:__import__('desktop_health_ui').show(page.shell))
        self.ttk.Label(parent,text='The normal launcher prepares speech packages. Download and extract a Vosk model for the spoken language, then choose its folder. Recognition runs locally; no audio or text is uploaded and no model downloads automatically.',wraplength=780,style='Muted.TLabel').pack(fill='x',pady=6)
        for name,label,low,high in (('points','Caption font size (points; app text scaling also applies)',12,48),('lines','Visible caption lines',1,8),('retain','Maximum finalized captions kept in memory',10,200)):
            self.ttk.Label(parent,text=label).pack(anchor='w');var=self.tk.StringVar(value=str(getattr(self.owner.preferences,name)));self.variables[name]=var
            annotate(self.ttk.Spinbox(parent,from_=low,to=high,textvariable=var,width=8),name=label).pack(anchor='w',pady=3)
        self.variables['palette']=self.tk.StringVar(value=self.owner.preferences.palette)
        annotate(choice(page,parent,self.variables['palette'],tuple(PALETTES)),name='Caption colors')
        for name,title in (('topmost','Keep detached captions on top'),('partials','Show provisional speech while recognizing'),('timestamps','Show elapsed timestamps')):
            var=self.tk.BooleanVar(value=getattr(self.owner.preferences,name));self.variables[name]=var
            self.ttk.Checkbutton(parent,text=title,variable=var).pack(anchor='w',pady=3)
        row=line(page,parent);button(page,row,'Apply caption settings',self.apply);button(page,row,'Undo caption settings',self.undo);button(page,row,'Reset caption settings',self.reset)
        row=line(page,parent);button(page,row,'Start captions',self.start);button(page,row,'Stop captions',self.owner.stop);button(page,row,'Clear transcript',self.owner.clear)
        row=line(page,parent);button(page,row,'Detach caption window',self.owner.open_window);button(page,row,'Export transcript TXT…',lambda:self.export('txt'));button(page,row,'Export subtitles SRT…',lambda:self.export('srt'))
        self.ttk.Label(parent,textvariable=self.owner.status,wraplength=780).pack(fill='x',pady=6)
        self.text=caption_text(self.app,parent,self.owner)
        self.retained=self.tk.StringVar();self.ttk.Label(parent,textvariable=self.retained,wraplength=780).pack(fill='x')
        self.ttk.Label(parent,text='Start is required each session. Stop discards provisional text; Clear also stops capture. Privacy/account changes clear all captions. Closing the detached window stops capture. Exports contain finalized retained captions only; timings are approximate. Captions are not saved automatically or sent to chatbox / peers.',wraplength=780,style='Muted.TLabel').pack(fill='x',pady=8)
        self.owner.panels.append(self);parent.bind('<Destroy>',lambda e:self.close() if e.widget is parent else None,add='+')
        self.refresh_sources();self.render()
    def refresh_sources(self):
        self.labels=[('Desktop · ' if d['kind']=='loopback' else 'Input · ')+d['name']+' ['+str(i+1)+']' for i,d in enumerate(self.owner.sources)]
        self.source_box.configure(values=('Choose a source',*self.labels));self.source.set('Choose a source')
    def select_source(self):
        if self.source.get() not in self.labels:raise ValueError('Select a discovered caption source.')
        self.owner.select_source(self.labels.index(self.source.get()))
    def choose_model(self):
        from tkinter import filedialog
        folder=filedialog.askdirectory(parent=self.app.root,title='Choose extracted local Vosk speech model')
        if folder:self.variables['model'].set(folder)
    def models(self):
        import webbrowser
        webbrowser.open('https://alphacephei.com/vosk/models')
    def values(self):
        result={name:var.get() for name,var in self.variables.items()}
        for name in ('points','lines','retain'):
            value=result[name]
            if not value.isdecimal() or len(value)>4:raise ValueError('Caption sizes and counts must be whole numbers.')
            result[name]=int(value)
        return result
    def apply(self):self.owner.apply(self.values())
    def sync(self):
        for name,var in self.variables.items():var.set(getattr(self.owner.preferences,name))
    def undo(self):self.owner.undo();self.sync()
    def reset(self):self.owner.apply(Preferences().to_dict());self.sync()
    def start(self):
        proposed=Preferences.parse(self.values())
        if proposed!=self.owner.preferences:self.owner.apply(proposed.to_dict())
        self.owner.start()
    def export(self,kind):
        from tkinter import filedialog
        data=self.owner.export(kind);context=self.owner.context;generation=self.owner.transcript.generation
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Export retained caption transcript',initialfile='VRC-Eye-Captions.'+kind,defaultextension='.'+kind,confirmoverwrite=False)
        if not path:return
        self.owner.allowed()
        if context!=self.owner.context or generation!=self.owner.transcript.generation:raise ValueError('Caption content changed while choosing a destination. Export again.')
        with Path(path).open('x',encoding='utf-8') as stream:stream.write(data)
        self.page.status.set('Retained finalized captions exported. No audio was saved.')
    def render(self):
        self.cache=paint(self.app,self.text,self.owner,self.cache)
        self.retained.set(f'{len(self.owner.transcript.rows)} finalized captions in memory; {self.owner.transcript.dropped} older captions rolled out.')
    def close(self):
        if self in self.owner.panels:self.owner.panels.remove(self)


class CaptionWindow:
    def __init__(self,owner):
        self.owner=owner;self.app=owner.app;self.cache=None;self.closed=False;self.topmost=None
        app=self.app;self.window=app.tk.Toplevel(app.root);self.window.title('VRC Eye · Live captions');self.window.geometry('850x320');self.window.minsize(360,180)
        parent=app.ttk.Frame(window_body(self.window),padding=12);parent.pack(fill='both',expand=True)
        row=app.ttk.Frame(parent);row.pack(fill='x')
        app.ttk.Button(row,text='Stop captions',command=owner.stop).pack(side='left')
        app.ttk.Button(row,text='Clear transcript',command=owner.clear).pack(side='left',padx=6)
        app.ttk.Button(row,text='Close captions',command=self.close).pack(side='left')
        app.ttk.Label(parent,textvariable=owner.status,wraplength=780).pack(fill='x')
        self.text=caption_text(app,parent,owner)
        self.window.bind('<Escape>',lambda _:self.close());self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.render()
    def render(self):
        if self.closed:return
        self.cache=paint(self.app,self.text,self.owner,self.cache)
        if self.topmost!=self.owner.preferences.topmost:
            self.topmost=self.owner.preferences.topmost
            try:self.window.attributes('-topmost',self.topmost)
            except self.app.tk.TclError:self.owner.status.set('This desktop does not support always-on-top captions. The window remains usable.')
    def close(self,stop=True):
        if self.closed:return
        self.closed=True
        if self.owner.window is self:self.owner.window=None
        if stop:self.owner.stop()
        self.window.destroy()
