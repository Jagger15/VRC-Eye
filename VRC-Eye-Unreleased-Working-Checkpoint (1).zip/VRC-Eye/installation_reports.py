"""Sanitized frozen installation reports and explicit selected-baseline comparison."""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
import json
import math
from pathlib import Path
import re
import time

from avatar_library_files import checked_stream, check_cancel, InspectionCancelled
from creator_projects import assert_no_links, local_path
from installation_inspector import (ENGINE, HEX, KNOWN_ROLES, MAX_ENTRIES,
    REPORT_LIMIT, SCHEMA, InstallationSnapshot)
from vrca_files import _save_stream, VRCAError, VRCACancelled

STATES = frozenset(('observed', 'unreadable', 'limited', 'encrypted'))
ARCHITECTURES = frozenset(('x86', 'x86_64', 'arm', 'arm64', 'arm64ec', 'arm64x', 'unknown'))

def export_engine(value):
    if not isinstance(value, str): return None
    match = re.match(r'((?:20\d\d|6000)\.\d{1,3}\.\d{1,4}[abfp]\d{1,3})(?:-DWR)?', value)
    return match[0] if match else None


def _path_key(snapshot, record):
    # Prefix-independent comparison within one unambiguous installation root.
    # Separate namespace prevents an outside-wrapper entry aliasing an inner file.
    if snapshot.root_prefix and record.path.startswith(snapshot.root_prefix):
        value = 'inside\0' + record.path[len(snapshot.root_prefix):].casefold()
    elif snapshot.root_prefix:
        value = 'outside\0' + record.path.casefold()
    else:
        value = 'inside\0' + record.path.casefold()
    return sha256(value.encode('utf-8')).hexdigest()


def baseline_document(snapshot):
    """Opaque path keys permit comparisons; absolute/relative filenames are omitted."""
    return {'schema': SCHEMA, 'kind': 'comparison-baseline', 'snapshot_id': snapshot.id,
        'observed_at': snapshot.observed_at, 'inventory_complete': snapshot.inventory_complete,
        'metadata_complete': snapshot.metadata_complete, 'historical': True,
        'engine_versions': sorted({export_engine(v) for v in snapshot.summary.get('engine_versions', []) if export_engine(v)}),
        'files': [{'path_key': _path_key(snapshot, r), 'role': r.role, 'size': r.size,
                   'state': r.state, 'sha256': r.sha256} for r in snapshot.files]}


def _finite(value): return type(value) in (int, float) and math.isfinite(value)


def validate_baseline(value):
    allowed = {'schema', 'kind', 'snapshot_id', 'observed_at', 'inventory_complete', 'metadata_complete', 'historical', 'engine_versions', 'files'}
    if not isinstance(value, dict) or set(value) != allowed or value.get('schema') != SCHEMA or value.get('kind') != 'comparison-baseline' or value.get('historical') is not True:
        raise ValueError('This is not a supported historical installation baseline.')
    if not isinstance(value['snapshot_id'], str) or not re.fullmatch('[0-9a-f]{32}', value['snapshot_id']) or not _finite(value['observed_at']) or not 0 <= value['observed_at'] <= 10**11:
        raise ValueError('Baseline observation identity is invalid.')
    if any(type(value[k]) is not bool for k in ('inventory_complete', 'metadata_complete')): raise ValueError('Baseline coverage is invalid.')
    versions = value['engine_versions']; rows = value['files']
    if not isinstance(versions, list) or len(versions) > 32 or any(not isinstance(v, str) or not ENGINE.fullmatch(v) for v in versions): raise ValueError('Baseline engine versions are invalid.')
    if not isinstance(rows, list) or len(rows) > MAX_ENTRIES: raise ValueError('Baseline file count exceeds the supported limit.')
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'path_key', 'role', 'size', 'state', 'sha256'}: raise ValueError('Baseline file evidence has unsupported fields.')
        key = row['path_key']
        if not isinstance(key, str) or not HEX.fullmatch(key) or key in seen: raise ValueError('Baseline file identities are invalid or duplicated.')
        seen.add(key)
        if not isinstance(row['role'], str) or row['role'] not in KNOWN_ROLES or not isinstance(row['state'], str) or row['state'] not in STATES or type(row['size']) is not int or not 0 <= row['size'] <= 8 * 1024**3:
            raise ValueError('Baseline file evidence is invalid.')
        if not isinstance(row['sha256'], str) or row['sha256'] and not HEX.fullmatch(row['sha256']): raise ValueError('Baseline digest is invalid.')
    # Return a detached document; imported evidence never gains live filesystem authority.
    return json.loads(json.dumps(value, allow_nan=False))


def load_baseline(path):
    with checked_stream(path, limit=REPORT_LIMIT) as (_, stream, _):
        try:
            def pairs(items):
                out = {}
                for key, val in items:
                    if key in out: raise ValueError('Duplicate baseline key.')
                    out[key] = val
                return out
            value = json.loads(stream.read(REPORT_LIMIT + 1), object_pairs_hook=pairs)
        except (UnicodeError, json.JSONDecodeError, RecursionError): raise ValueError('Baseline JSON could not be read within its supported limits.') from None
    return validate_baseline(value)


def compare_baseline(snapshot, baseline):
    baseline = validate_baseline(baseline)
    old = {r['path_key']: r for r in baseline['files']}; current = baseline_document(snapshot)
    new = {r['path_key']: r for r in current['files']}; rows = []
    names = {_path_key(snapshot, r): r.path for r in snapshot.files}
    for key in sorted(set(old) | set(new)):
        a, b = old.get(key), new.get(key)
        if a is None: state = 'added' if baseline['inventory_complete'] else 'unverified prior presence'
        elif b is None: state = 'removed' if snapshot.inventory_complete else 'unverified current presence'
        elif a['state'] != 'observed' or b['state'] != 'observed': state = 'unverified content'
        elif a['size'] != b['size']: state = 'changed size'
        elif a['sha256'] and b['sha256']: state = 'matching selected bytes' if a['sha256'] == b['sha256'] else 'changed selected bytes'
        else: state = 'unverified content'
        rows.append({'path_key': key, 'name': names.get(key, 'Absent baseline item'), 'role': (b or a)['role'], 'state': state})
    return {'baseline_id': baseline['snapshot_id'], 'snapshot_id': snapshot.id,
        'baseline_observed_at': baseline['observed_at'], 'current_observed_at': snapshot.observed_at,
        'version_boundary': baseline['engine_versions'] != current['engine_versions'],
        'rows': rows, 'meaning': 'Equality is with the selected historical snapshot only. Differences are not malware, tampering or official integrity verdicts.'}


def report_document(snapshot, *, comparison=None, association=None, wall=time.time):
    files = []
    for i, record in enumerate(snapshot.files):
        metadata = record.metadata; architecture = metadata.get('architecture')
        row = {'id': f'file_{i+1:04d}', 'role': record.role, 'size': record.size, 'state': record.state,
               'metadata_state': metadata.get('state') if metadata.get('state') in ('parsed', 'partial', 'not-pe', 'unsupported', 'limited') else 'not-inspected',
               'architecture': architecture if architecture in ARCHITECTURES else 'unknown', 'sha256': record.sha256,
               'signature_trust': 'unverified'}
        if type(metadata.get('certificate_table_present')) is bool: row['certificate_table_present'] = metadata['certificate_table_present']
        for field in ('header_state', 'version_state', 'imports_state', 'certificate_state'):
            value = metadata.get(field)
            if value in ('parsed', 'partial', 'not-pe', 'unsupported', 'limited', 'absent', 'declared', 'not-inspected'):
                row[field] = value
        versions = metadata.get('version_strings', {}); version = versions.get('ProductVersion')
        if export_engine(version): row['engine_marker'] = export_engine(version)
        row['direct_import_count'] = len(metadata.get('direct_imports', []))
        files.append(row)
    document = {'schema': SCHEMA, 'kind': 'sanitized-report', 'report_id': uuid_hex(),
        'snapshot_id': snapshot.id, 'observed_at': snapshot.observed_at, 'exported_at': wall(),
        'source_kind': snapshot.source_kind, 'inventory_complete': snapshot.inventory_complete,
        'metadata_complete': snapshot.metadata_complete, 'historical': True,
        'application_release': 'unknown', 'steam_build_id': 'unknown', 'files': files,
        'scope': 'Selected local historical evidence. Paths, arbitrary names, raw commands, accounts, log text, service identifiers and imported file contents are excluded. Exact timestamps and selected file digests remain. No official integrity or active capability claim.'}
    if comparison and comparison.get('snapshot_id') == snapshot.id:
        counts = {}
        allowed = {'added', 'removed', 'changed size', 'matching selected bytes', 'changed selected bytes', 'unverified content', 'unverified prior presence', 'unverified current presence'}
        for row in comparison.get('rows', []):
            if row.get('state') in allowed: counts[row['state']] = counts.get(row['state'], 0) + 1
        document['comparison'] = {'counts': counts, 'version_boundary': comparison.get('version_boundary') is True}
    if association and association.get('snapshot_id') == snapshot.id:
        document['runtime_association'] = {'state': 'associated' if association.get('state') == 'associated' else 'unverified', 'historical': True}
        value = association.get('runtime_engine_version')
        if export_engine(value): document['runtime_association']['runtime_engine_version'] = export_engine(value)
    return document


def uuid_hex():
    import uuid
    return uuid.uuid4().hex


def write_document(path, document, *, stop=None, before_commit=None):
    """Existing exclusive-publication primitive; cancellation removes private partial output."""
    target = assert_no_links(local_path(path))
    if target.suffix.casefold() != '.json': raise ValueError('Choose a new .json filename.')
    if target.exists() or not target.parent.is_dir(): raise ValueError('Choose a new filename in an existing folder. Existing files are never overwritten.')
    data = json.dumps(document, ensure_ascii=True, indent=2, allow_nan=False).encode('utf-8')
    if len(data) > REPORT_LIMIT: raise ValueError('Installation evidence export exceeds its bounded size limit.')
    check_cancel(stop)
    try:
        _save_stream(BytesIO(data), target, len(data), sha256(data).hexdigest(), stop, None,
            network=False, suffixes=('.json',), before_commit=before_commit)
    except VRCACancelled as error: raise InspectionCancelled(str(error)) from error
    except VRCAError as error: raise ValueError(str(error)) from error
    return str(target)
