"""Immutable player-session events, observations and desktop/overlay snapshots."""
from dataclasses import dataclass,field
from enum import Enum
import math
import re
from collections import deque
from copy import deepcopy

from player_platforms import parse_user_id
from world_players import log_epoch


class Source(str,Enum):
    LOG="LOG";API="API";LOCAL="LOCAL";OSC="OSC";VRC_EYE="VRC_EYE";BRIDGE="BRIDGE";DERIVED="DERIVED";UNKNOWN="UNKNOWN"


class Confidence(str,Enum):
    AUTHORITATIVE="AUTHORITATIVE";HIGH="HIGH";MEDIUM="MEDIUM";LOW="LOW";UNKNOWN="UNKNOWN"


class Presence(str,Enum):
    UNKNOWN="UNKNOWN";JOINING="JOINING";PRESENT="PRESENT";LEAVING="LEAVING";LEFT="LEFT";STALE="STALE";ERROR="ERROR";RECONCILING="RECONCILING"


class Friend(str,Enum):
    UNKNOWN="Unknown";NOT_FRIEND="Not friend";FRIEND="Friend";REQUEST_SENT="Request sent";REQUEST_RECEIVED="Request received"


ACTIVE={Presence.JOINING,Presence.PRESENT,Presence.STALE,Presence.RECONCILING}
LOAD_STATES={"UNKNOWN","CHANGED","LOADING","READY","DOWNLOAD_FAILED","BUNDLE_FAILED","SECURITY_FAILED","LOAD_FAILED","UNKNOWN_FAILURE","LOAD_STALLED"}
ROLE_ORDER=("VRChat Staff","Instance Owner","Group Owner","Group Admin","Group Moderator","World Creator","Network Master")
EVENT_KINDS={"instance.entered","instance.left","player.joined","player.left","player.resolved","avatar.changed","avatar.load","friendship.updated","roles.updated","bridge.selection","resource.sample","log.health","local.updated"}
ID=re.compile(r"(?:usr|avtr|wrld|grp)_[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}")


def clean(value,limit=512):
    return "".join(c for c in str(value)[:limit] if c in "\n\t" or ord(c)>=32 and ord(c)!=127)


def exact_id(value,prefix):
    if not isinstance(value,str) or not ID.fullmatch(value) or not value.startswith(prefix+"_"):raise ValueError("An exact "+prefix+" ID is required.")
    return value


def seconds_label(value):
    if value is None:return "Unknown"
    value=max(0,int(value));days,value=divmod(value,86400);hours,value=divmod(value,3600);minutes,seconds=divmod(value,60)
    return f"{days}d {hours}h" if days else f"{hours}h {minutes}m" if hours else f"{minutes}m" if minutes else f"{seconds}s"


@dataclass(frozen=True)
class ObservedValue:
    value: object=None
    source: Source=Source.UNKNOWN
    confidence: Confidence=Confidence.UNKNOWN
    observed_at: str=""
    received: float=0.
    expires: float|None=None
    detail: str=""
    scope: str=""

    def fresh(self,now):return self.source!=Source.UNKNOWN and self.value is not None and (self.expires is None or self.received<=now<self.expires)
    def display(self,now):return self.value if self.fresh(now) else None
    def inspect(self,now,wall=None):
        return dict(value=self.display(now),source=self.source.value,confidence=self.confidence.value,observed_at=self.observed_at,
                    received_age_seconds=max(0,round(now-self.received,1)),observed_age_seconds=max(0,round(wall-log_epoch(self.observed_at),1)) if wall is not None and log_epoch(self.observed_at) is not None else None,
                    fresh=self.fresh(now),detail=self.detail,scope=self.scope)


# Field-specific precedence; callers still isolate account/instance scope first.
PRECEDENCE={
    "friend":(Source.API,),"world_creator":(Source.API,),"instance_owner":(Source.API,),"roles":(Source.API,Source.BRIDGE),
    "load":(Source.BRIDGE,Source.LOG,Source.DERIVED),"avatar_id":(Source.BRIDGE,Source.LOG,Source.API),
    "avatar_name":(Source.LOG,Source.API,Source.BRIDGE),"performance":(Source.BRIDGE,Source.API,Source.LOCAL),
    "speaking":(Source.BRIDGE,),"distance":(Source.BRIDGE,Source.LOG),"moderation":(Source.BRIDGE,Source.API)}


def preferred(field,values,now):
    order=PRECEDENCE.get(field,(Source.LOG,Source.API,Source.LOCAL,Source.BRIDGE,Source.DERIVED))
    fresh=[v for v in values if v.fresh(now) and v.source in order]
    return min(fresh,key=lambda v:(order.index(v.source),-v.received)) if fresh else ObservedValue()


@dataclass(frozen=True)
class PlayerEvent:
    kind:str
    stamp:str
    user_id:str=""
    name:str=""
    payload:tuple=()
    source:Source=Source.LOG
    confidence:Confidence=Confidence.HIGH
    event_id:str=""
    reconstructed:bool=False

    @classmethod
    def make(cls,kind,stamp,*,user_id="",name="",data=None,source=Source.LOG,confidence=Confidence.HIGH,event_id="",reconstructed=False):
        if kind not in EVENT_KINDS or log_epoch(stamp) is None:raise ValueError("Unsupported player event or timestamp.")
        if user_id:user_id=parse_user_id(user_id)
        if not isinstance(data or {},dict) or len(data or {})>32:raise ValueError("Player event payload is too large.")
        # All normalized values are scalars or scalar tuples; raw API/log objects stay outside the event bus.
        values=[]
        for key,value in (data or {}).items():
            if not isinstance(key,str) or len(key)>80:raise ValueError("Invalid player event key.")
            if isinstance(value,list):value=tuple(value)
            candidates=value if isinstance(value,tuple) else (value,)
            if len(candidates)>128:raise ValueError("Player event list exceeds its limit.")
            for item in candidates:
                if item is not None and type(item) not in (str,bool,int,float):raise ValueError("Player events accept only scalar values.")
                if isinstance(item,str) and len(item)>2048:raise ValueError("Player event text exceeds its limit.")
                if type(item) in (int,float) and (not math.isfinite(item) or abs(item)>2**53):raise ValueError("Invalid event measurement.")
            values.append((key,value))
        return cls(kind,stamp,user_id,clean(name),tuple(values),Source(source),Confidence(confidence),str(event_id)[:128],bool(reconstructed))

    @property
    def data(self):return dict(self.payload)


class EventBus:
    """Bounded producer queue; the model and UI consume on their owning thread."""
    def __init__(self,limit=2048):
        import queue
        self.queue=queue.Queue(maxsize=limit);self.dropped=0;self.total=0
    def publish(self,event):
        import queue
        if not isinstance(event,PlayerEvent):raise ValueError("Publish a normalized PlayerEvent.")
        try:self.queue.put_nowait(event);self.total+=1;return True
        except queue.Full:self.dropped+=1;return False
    def drain(self,limit=512):
        import queue
        result=[]
        for _ in range(limit):
            try:result.append(self.queue.get_nowait())
            except queue.Empty:break
        return tuple(result)


@dataclass
class PlayerSession:
    key:str
    instance_key:str
    name:str
    user_id:str=""
    joined_at:str=""
    first_observed:str=""
    left_at:str=""
    closed_at:str=""
    presence:Presence=Presence.UNKNOWN
    end_reason:str=""
    reconstructed:bool=False
    conflict:bool=False
    local:bool=False
    pinned:bool=False
    avatar_changes:int=0
    avatar_last_token:tuple=()
    avatar_last_seen:float=0.
    observed_names:tuple=()
    fields:dict=field(default_factory=dict)
    visit_segments:list=field(default_factory=list)
    timeline:deque=field(default_factory=lambda:deque(maxlen=200))

    @property
    def active(self):return self.presence in ACTIVE
    def put(self,name,value,source,confidence,stamp,now,*,ttl=None,detail="",scope=""):
        observation=ObservedValue(value,Source(source),Confidence(confidence),stamp,now,None if ttl is None else now+ttl,detail,scope)
        self.fields.setdefault(name,{})[Source(source)]=observation
    def get(self,name,now):return preferred(name,self.fields.get(name,{}).values(),now)
    def seconds(self,now_epoch):
        start=log_epoch(self.joined_at);end=log_epoch(self.left_at or self.closed_at) if not self.active else now_epoch
        return max(0,int(end-start)) if start is not None and end is not None else None


@dataclass(frozen=True)
class PlayerCardData:
    key:str
    instance_key:str
    user_id:str
    name:str
    presence:Presence
    joined_at:str
    left_at:str
    closed_at:str
    duration_seconds:int|None
    relationship:ObservedValue
    roles:tuple
    avatar_name:ObservedValue
    avatar_id:ObservedValue
    load_state:ObservedValue
    performance:ObservedValue
    texture_memory:ObservedValue
    speaking:ObservedValue
    distance:ObservedValue
    resource:ObservedValue
    moderation:tuple
    primary_status:str
    secondary_flags:tuple
    local:bool=False
    pinned:bool=False
    favorite:bool=False
    note:str=""
    tags:tuple=()
    names:tuple=()
    encounters:int=0
    shared_seconds:int=0
    first_seen:str=""
    last_seen:str=""
    reconstructed:bool=False
    conflict:bool=False
    avatar_changes:int=0
    incident_count:int=0
    end_reason:str=""
    diagnostics:tuple=()

    @property
    def active(self):return self.presence in ACTIVE


def primary_status(presence,load,speaking,resource,joined_seconds,recent_join=30):
    if presence==Presence.LEFT:return "Left recently"
    if presence in (Presence.STALE,Presence.RECONCILING,Presence.ERROR):return presence.value.title()
    if isinstance(load,str) and (load.endswith("FAILED") or load=="UNKNOWN_FAILURE"):return "Avatar error"
    if resource:return "Resource observation"
    if load=="LOAD_STALLED":return "Avatar taking longer"
    if load=="LOADING":return "Avatar loading"
    if speaking is True:return "Speaking"
    if joined_seconds is not None and joined_seconds<recent_join:return "Recently joined"
    if load=="CHANGED":return "Avatar changed"
    return "Present" if presence==Presence.PRESENT else "Observed"
