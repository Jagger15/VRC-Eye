"""Passive, bounded external MelonLoader evidence; never loads or changes a client.

Source markers, shipped layout markers, configuration declarations and historical
log claims remain separate. This module performs no extraction or network I/O.
The config reader deliberately accepts only a small, scalar TOML subset.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import PurePosixPath
import re
import time
import uuid
import xml.etree.ElementTree as ET
import zipfile

from avatar_library_files import checked_stream, InspectionCancelled
from creator_projects import assert_no_links, local_path
from installation_inspector import Budget, BudgetExceeded, InstallationSource, SourceChanged

SCHEMA = 'vrc-eye-loader-evidence-1'
CONFIG_LIMIT = 128 * 1024
LOG_LIMIT = 2 * 1024 * 1024
MAX_DOCUMENTS = 16
MAX_LOG_LINES = 20000
VERSION = re.compile(r'[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}(?:\.[0-9]{1,4})?\Z')
UNITY_VERSION = re.compile(r'(?:[0-9]{1,4})\.[0-9]{1,3}\.[0-9]{1,4}[abcfpx][0-9]{1,3}\Z')
FRAMEWORKS = frozenset(('net35', 'net6'))
TARGETS = {
    'BootstrapTarget': frozenset(('net9',)),
    'DotNetTarget': frozenset(('net6',)),
    'MonoTarget': frozenset(('net35',)),
    'MonoBleedingEdgeTarget': frozenset(('net472',)),
}
ARTIFACTS = frozenset(('source-tree', 'installed-evidence', 'mixed-evidence', 'config', 'log', 'unknown'))
STATES = frozenset(('parsed', 'invalid-or-unsupported', 'limited', 'unreadable'))
BOUNDARY = ('External historical evidence only. File presence and log declarations do not establish '
            'active loading, compatibility, official integrity or authorization. No client code is loaded or changed.')
FINDINGS = {
    'source': 'Source-tree markers were observed; source files are not an installed or active loader.',
    'installed': 'Loader distribution layout markers were observed; their presence does not prove active loading.',
    'mixed': 'Both source and distribution layout markers were observed; their provenance remains separate.',
    'unknown': 'No complete source or distribution layout marker set was established within inspected coverage.',
    'weak': 'A version.dll filename is a weak generic proxy marker and does not identify MelonLoader.',
    'partial': 'Inventory or metadata coverage is partial; missing observations do not prove absence.',
    'config': 'Configuration values are file declarations only; launch overrides and effective runtime values are unknown.',
    'log': 'Log fields are historical text claims; message categories are lexical hints, not a diagnosis.',
    'multiple': 'Multiple candidate documents or roots were observed; they were not merged into one installation.',
}

_BOOLS = {
    'loader': ('disable', 'debug_mode', 'capture_player_logs', 'force_quit', 'disable_start_screen',
               'launch_debugger', 'disable_subfolder_load', 'disable_subfolder_manifest'),
    'console': ('hide_warnings', 'hide_console', 'console_on_top', 'dont_set_title'),
    'mono_debug_server': ('debug_suspend',),
    'unityengine': ('disable_console_log_cleaner', 'mono_bleeding_edge_environment_patches',
                    'force_offline_generation', 'force_regeneration', 'enable_cpp2il_call_analyzer',
                    'enable_cpp2il_native_method_detector'),
}
BOOL_FIELDS = frozenset(section + '.' + key for section, keys in _BOOLS.items() for key in keys)
UINT_FIELDS = frozenset(('logs.max_logs', 'mono_debug_server.debug_port'))
ENUM_FIELDS = {
    'loader.harmony_log_level': frozenset(('None', 'Info', 'Warn', 'Error', 'Debug', 'IL')),
    'loader.theme': frozenset(('Normal', 'Magenta', 'Rainbow', 'RandomRainbow', 'Lemon')),
}
PRIVATE_FIELDS = frozenset(('loader.hostfxr_path_override', 'mono_debug_server.debug_ip_address',
    'unityengine.mono_search_path_override', 'unityengine.force_generator_regex'))
VERSION_FIELDS = {'unityengine.version_override': UNITY_VERSION,
                  'unityengine.force_il2cpp_dumper_version': VERSION}
SECTIONS = frozenset(('loader', 'console', 'logs', 'mono_debug_server', 'unityengine'))
CATEGORIES = ('assembly_or_dependency', 'runtime_initialization', 'logging', 'exception', 'other')
LOG_ENUMS = {'game_types': frozenset(('Il2cpp', 'Mono', 'MonoBleedingEdge')),
             'architectures': frozenset(('x86', 'x64')), 'runtimes': FRAMEWORKS}


@dataclass(frozen=True)
class LoaderSnapshot:
    id: str
    observed_at: float
    source: str  # Local selection only; never exported.
    source_kind: str
    artifact_kind: str
    inventory_complete: bool
    metadata_complete: bool
    findings: tuple[str, ...]
    summary_json: str

    @property
    def summary(self):
        return json.loads(self.summary_json)


def _encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _empty_summary():
    return dict(file_count=0, source_root_count=0, installed_root_count=0, installed_frameworks=[],
                weak_proxy_count=0, config_count=0, log_count=0, source_versions=[], source_targets={},
                configs=[], logs=[])


def _strip_comment(line):
    quote = None; escaped = False
    for index, char in enumerate(line):
        if ord(char) < 32 and char != '\t': raise ValueError('Unsupported configuration character.')
        if quote:
            if escaped: escaped = False
            elif char == '\\' and quote == '"': escaped = True
            elif char == quote: quote = None
        elif char in ('"', "'"): quote = char
        elif char == '#': return line[:index].strip()
    if quote: raise ValueError('Unsupported configuration string.')
    return line.strip()


def _scalar(value):
    if value in ('true', 'false'): return value == 'true'
    if re.fullmatch(r'(?:0|[1-9][0-9]{0,9})', value):
        number = int(value)
        if number <= 2**32 - 1: return number
    if len(value) >= 2 and value[0] == value[-1] == "'" and "'" not in value[1:-1]:
        return value[1:-1]
    if value.startswith('"') and not value.startswith('"""'):
        # JSON's single-line quoted-string subset deliberately excludes TOML's
        # multiline strings, arbitrary escapes, tables, dates and expressions.
        if any(match[1] == '/' for match in re.finditer(r'\\(.)', value)):
            raise ValueError('JSON-only slash escape is not supported TOML.')
        result = json.loads(value)
        if isinstance(result, str) and not any(ord(c) < 32 or 0xD800 <= ord(c) <= 0xDFFF for c in result):
            return result
    raise ValueError('Unsupported scalar configuration value.')


def _config_value(key, value, *, exported=False):
    if key in BOOL_FIELDS:
        if type(value) is bool: return value
    elif key in UINT_FIELDS:
        if type(value) is int and 0 <= value <= 2**32 - 1: return value
    elif key in ENUM_FIELDS:
        if isinstance(value, str) and value in ENUM_FIELDS[key]: return value
    elif key in PRIVATE_FIELDS:
        if isinstance(value, str):
            if exported:
                if value in ('set', 'empty'): return value
            else: return 'set' if value else 'empty'
    elif key in VERSION_FIELDS:
        if isinstance(value, str) and (not value or VERSION_FIELDS[key].fullmatch(value)): return value
    else:
        raise KeyError(key)
    raise ValueError('Unsupported declared configuration type.')


def parse_config(text, *, stop=None):
    """Return only explicit, typed declarations. Invalid documents yield no fields."""
    from avatar_library_files import check_cancel
    result = {'state': 'parsed', 'fields': {}, 'omitted_fields': 0}
    try:
        if not isinstance(text, str) or len(text.encode('utf-8')) > CONFIG_LIMIT: raise ValueError()
        section = None; sections = set(); keys = set()
        for number, raw in enumerate(text.splitlines(), 1):
            check_cancel(stop)
            if number > 4096 or len(raw) > 4096: raise ValueError()
            line = _strip_comment(raw)
            if not line: continue
            if line.startswith('['):
                match = re.fullmatch(r'\[([a-z_]+)\]', line)
                if not match or match[1] not in SECTIONS or match[1] in sections: raise ValueError()
                section = match[1]; sections.add(section); continue
            match = re.fullmatch(r'([a-z_][a-z0-9_]*)\s*=\s*(.+)', line)
            if section is None or not match: raise ValueError()
            key = section + '.' + match[1]
            if key in keys: raise ValueError()
            keys.add(key); value = _scalar(match[2].strip())
            try: result['fields'][key] = _config_value(key, value)
            except KeyError: result['omitted_fields'] += 1
    except InspectionCancelled: raise
    except (ValueError, UnicodeError, RecursionError):
        return {'state': 'invalid-or-unsupported', 'fields': {}, 'omitted_fields': 0}
    return result


_TIME_PREFIX = re.compile(r'^\[(?:[01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]\.[0-9]{3}\]\s*')
_LOADER_LINE = re.compile(r'(?:MelonLoader|LemonLoader) v([0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}(?:\.[0-9]{1,4})?) (?:Open-Beta|ALPHA Pre-Release)\Z')


def parse_log(text, *, stop=None):
    """Normalize selected historical text without retaining a line or section name."""
    from avatar_library_files import check_cancel
    result = dict(state='parsed', lines=0, matched_lines=0, warning_count=0, error_count=0,
                  categories={key: 0 for key in CATEGORIES}, loader_versions=[], game_types=[],
                  architectures=[], runtimes=[], unity_versions=[])
    if not isinstance(text, str) or len(text.encode('utf-8')) > LOG_LIMIT:
        result['state'] = 'limited'; return result
    values = {key: set() for key in ('loader_versions', 'game_types', 'architectures', 'runtimes', 'unity_versions')}
    for number, line in enumerate(text.splitlines(), 1):
        check_cancel(stop)
        if number > MAX_LOG_LINES: result['state'] = 'limited'; break
        result['lines'] += 1
        if len(line) > 8192: result['state'] = 'limited'; continue
        # Only timestamped logger records can contribute claims or severities.
        prefix = _TIME_PREFIX.match(line)
        if not prefix: continue
        body = line[prefix.end():]
        severity = re.match(r'^\[(WARNING|ERROR)\](?:\s|$)', body)
        if severity:
            result['warning_count' if severity[1] == 'WARNING' else 'error_count'] += 1
            result['matched_lines'] += 1
            # Remove the optional provider/module section before lexical hints.
            message = re.sub(r'^\[[^\]\r\n]{0,128}\]\s*', '', body[severity.end():].lstrip()).casefold()
            category = 'assembly_or_dependency' if any(s in message for s in ('assembly', 'dependency', 'dependencies')) else (
                'runtime_initialization' if any(s in message for s in ('hostfxr', '.net', 'initialize', 'initialization', 'could not load mono', 'could not load il2cpp')) else (
                'logging' if any(s in message for s in ('log file', 'latest.log', 'logging')) else (
                'exception' if 'exception' in message else 'other')))
            result['categories'][category] += 1
            continue
        # Startup lines are normally unsectioned; only the fixed loader label
        # is accepted as an optional section, never arbitrary mod names.
        body = re.sub(r'^\[(?:MelonLoader|LemonLoader)\]\s*', '', body)
        match = _LOADER_LINE.fullmatch(body)
        found = None
        if match: found = ('loader_versions', match[1])
        for label, key in (('Game Type: ', 'game_types'), ('Game Arch: ', 'architectures'), ('Runtime Type: ', 'runtimes')):
            if body.startswith(label) and body[len(label):] in LOG_ENUMS[key]: found = (key, body[len(label):])
        if body.startswith('Unity Version: ') and UNITY_VERSION.fullmatch(body[15:]): found = ('unity_versions', body[15:])
        if found:
            key, value = found
            if len(values[key]) < 16 or value in values[key]: values[key].add(value)
            else: result['state'] = 'limited'
            result['matched_lines'] += 1
    result.update({key: sorted(value) for key, value in values.items()})
    return result


def _source_declarations(text):
    if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper(): raise ValueError('Unsupported source XML.')
    root = ET.fromstring(text)
    nodes = list(root.iter())
    if len(nodes) > 2048: raise ValueError('Source XML structure limit.')
    versions = set(); targets = {}
    for node in nodes:
        value = (node.text or '').strip()
        if node.tag == 'Version' and VERSION.fullmatch(value): versions.add(value)
        elif node.tag in TARGETS and value in TARGETS[node.tag]: targets.setdefault(node.tag, set()).add(value)
    return sorted(versions)[:16], {key: sorted(values) for key, values in targets.items()}


def _read_document(source, name, limit):
    size = source.entries[name]['size']
    if size > limit: raise BudgetExceeded('Selected diagnostic document exceeds its read limit.')
    with source.reader(name) as read: return read(0, size).decode('utf-8-sig')


def _document(source, name, kind, stop):
    try:
        text = _read_document(source, name, CONFIG_LIMIT if kind == 'config' else LOG_LIMIT)
        return (parse_config if kind == 'config' else parse_log)(text, stop=stop)
    except (InspectionCancelled, SourceChanged): raise
    except BudgetExceeded: return {'state': 'limited'}
    except (OSError, ValueError, UnicodeError, zipfile.BadZipFile, RuntimeError): return {'state': 'unreadable'}


def _findings(kind, summary, complete):
    keys = []
    if kind == 'mixed-evidence': keys.append('mixed')
    elif kind == 'source-tree': keys.append('source')
    elif kind == 'installed-evidence': keys.append('installed')
    elif kind == 'unknown': keys.append('unknown')
    if summary['weak_proxy_count']: keys.append('weak')
    if summary['config_count']: keys.append('config')
    if summary['log_count']: keys.append('log')
    if any(summary[key] > 1 for key in ('source_root_count', 'installed_root_count', 'config_count', 'log_count')): keys.append('multiple')
    if not complete: keys.append('partial')
    return tuple(FINDINGS[key] for key in keys)


def inspect(target, *, stop=None, progress=None):
    """Inspect only one explicit local folder, ZIP, config or historical log."""
    budget = Budget(stop, progress); budget.check()
    path = assert_no_links(local_path(target)); summary = _empty_summary()
    inventory_complete = metadata_complete = True
    suffix = path.suffix.casefold()
    if not path.is_dir() and suffix in ('.cfg', '.log'):
        kind = 'config' if suffix == '.cfg' else 'log'
        limit = CONFIG_LIMIT if kind == 'config' else LOG_LIMIT
        with checked_stream(path, limit=limit) as (_, stream, info):
            budget.consume(info.st_size); raw = stream.read(info.st_size + 1)
            if len(raw) != info.st_size: raise SourceChanged('Selected diagnostic file changed during inspection.')
            try: result = (parse_config if kind == 'config' else parse_log)(raw.decode('utf-8-sig'), stop=stop)
            except UnicodeError: result = {'state': 'unreadable'}
            budget.check()
        summary['file_count'] = 1; summary[kind + '_count'] = 1; summary[kind + 's'] = [result]
        metadata_complete = result['state'] == 'parsed'; source_kind = kind
    else:
        with InstallationSource(path, budget) as source:
            source_kind = source.kind
            names = {name.casefold(): name for name in source.entries}
            summary['file_count'] = len(names)
            source_roots = []
            for name in names:
                if name == 'directory.build.props' or name.endswith('/directory.build.props'):
                    prefix = name[:-len('directory.build.props')]
                    markers = (prefix + 'melonloader/loaderconfig.cs', prefix + 'melonloader.bootstrap/melonloader.bootstrap.csproj')
                    if all(marker in names for marker in markers): source_roots.append(prefix)
            installed_roots = set(); frameworks = set()
            for name in names:
                match = re.fullmatch(r'(.*?)(?:melonloader)/(net6|net35)/melonloader\.dll', name)
                if match and (not match[1] or match[1].endswith('/')):
                    installed_roots.add(match[1]); frameworks.add(match[2])
            summary.update(source_root_count=len(source_roots), installed_root_count=len(installed_roots), installed_frameworks=sorted(frameworks))
            summary['weak_proxy_count'] = sum(PurePosixPath(name).name == 'version.dll' for name in names)
            kind = ('mixed-evidence' if source_roots and installed_roots else 'source-tree' if source_roots else
                    'installed-evidence' if installed_roots else 'unknown')
            versions = set(); targets = {}
            for prefix in sorted(source_roots)[:MAX_DOCUMENTS]:
                budget.check()
                try:
                    found, fields = _source_declarations(_read_document(source, names[prefix + 'directory.build.props'], CONFIG_LIMIT))
                    versions.update(found)
                    for key, values in fields.items(): targets.setdefault(key, set()).update(values)
                except (InspectionCancelled, SourceChanged): raise
                except (OSError, ValueError, UnicodeError, ET.ParseError, zipfile.BadZipFile, RuntimeError): metadata_complete = False
            summary['source_versions'] = sorted(versions)[:16]
            summary['source_targets'] = {key: sorted(values) for key, values in targets.items()}
            if len(source_roots) > MAX_DOCUMENTS or len(versions) > 16: metadata_complete = False
            for doc_kind, ending in (('config', 'userdata/loader.cfg'), ('log', 'melonloader/latest.log')):
                selected = sorted(name for lower, name in names.items() if lower == ending or lower.endswith('/' + ending))
                summary[doc_kind + '_count'] = len(selected)
                for index, name in enumerate(selected[:MAX_DOCUMENTS]):
                    budget.update(index, len(selected)); result = _document(source, name, doc_kind, stop)
                    summary[doc_kind + 's'].append(result)
                    if result['state'] != 'parsed': metadata_complete = False
                if len(selected) > MAX_DOCUMENTS: metadata_complete = False
            source.verify(); inventory_complete = source.complete
    budget.check()
    return LoaderSnapshot(uuid.uuid4().hex, time.time(), str(path), source_kind, kind,
                          inventory_complete, metadata_complete,
                          _findings(kind, summary, inventory_complete and metadata_complete), _encoded(summary))


inspect_loader = inspect


def _count(value, maximum=2**32 - 1):
    return value if type(value) is int and 0 <= value <= maximum else 0


def _safe_list(value, predicate):
    return sorted({item for item in value[:16] if isinstance(item, str) and predicate(item)}) if isinstance(value, list) else []


def report_document(snapshot):
    """Rebuild an export allowlist; never serialize a snapshot's arbitrary fields."""
    original = snapshot.summary; summary = _empty_summary()
    for key in ('file_count', 'source_root_count', 'installed_root_count', 'weak_proxy_count', 'config_count', 'log_count'):
        summary[key] = _count(original.get(key))
    summary['installed_frameworks'] = _safe_list(original.get('installed_frameworks'), lambda v: v in FRAMEWORKS)
    summary['source_versions'] = _safe_list(original.get('source_versions'), VERSION.fullmatch)
    target_values = original.get('source_targets', {})
    if isinstance(target_values, dict):
        summary['source_targets'] = {key: _safe_list(target_values[key], lambda v, allowed=allowed: v in allowed)
                                     for key, allowed in TARGETS.items() if key in target_values}
    for plural in ('configs', 'logs'):
        rows = original.get(plural)
        if not isinstance(rows, list): continue
        for row in rows[:MAX_DOCUMENTS]:
            if not isinstance(row, dict): continue
            clean = {'state': row.get('state') if row.get('state') in STATES else 'invalid-or-unsupported'}
            if plural == 'configs':
                clean.update(fields={}, omitted_fields=_count(row.get('omitted_fields')))
                if clean['state'] == 'parsed' and isinstance(row.get('fields'), dict):
                    for key, value in row['fields'].items():
                        try: clean['fields'][key] = _config_value(key, value, exported=True)
                        except (ValueError, KeyError, TypeError): pass
            else:
                for key in ('lines', 'matched_lines', 'warning_count', 'error_count'): clean[key] = _count(row.get(key), MAX_LOG_LINES)
                categories = row.get('categories', {})
                clean['categories'] = {key: _count(categories.get(key), MAX_LOG_LINES) for key in CATEGORIES} if isinstance(categories, dict) else {}
                for key, allowed in LOG_ENUMS.items(): clean[key] = _safe_list(row.get(key), lambda v, allowed=allowed: v in allowed)
                clean['loader_versions'] = _safe_list(row.get('loader_versions'), VERSION.fullmatch)
                clean['unity_versions'] = _safe_list(row.get('unity_versions'), UNITY_VERSION.fullmatch)
            summary[plural].append(clean)
    observed = snapshot.observed_at
    return {'schema': SCHEMA, 'kind': 'sanitized-loader-report', 'historical': True,
            'snapshot_id': snapshot.id if isinstance(snapshot.id, str) and re.fullmatch('[0-9a-f]{32}', snapshot.id) else None,
            'observed_at': observed if type(observed) in (int, float) and math.isfinite(observed) and 0 <= observed <= 10**11 else None,
            'source_kind': snapshot.source_kind if snapshot.source_kind in ('folder', 'zip', 'config', 'log') else 'unknown',
            'artifact_kind': snapshot.artifact_kind if snapshot.artifact_kind in ARTIFACTS else 'unknown',
            'inventory_complete': snapshot.inventory_complete is True, 'metadata_complete': snapshot.metadata_complete is True,
            'summary': summary, 'findings': [value for value in snapshot.findings if value in FINDINGS.values()],
            'scope': BOUNDARY,
            'excluded': ['Source paths', 'Arbitrary filenames', 'Raw logs', 'Raw configuration text',
                         'Commands', 'Module names', 'Network addresses', 'Credentials']}
