"""Bounded, memory-only developer diagnostics shared by the real API adapter.

This module never performs network I/O, opens account stores, or logs secrets.
Response shape and local display are deliberately separate from report export.
"""
from __future__ import annotations

from collections import deque
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from enum import Enum
import hashlib
import hmac
import json
import math
import re
import secrets
import threading
import time
from urllib.parse import parse_qsl, urlencode, urlsplit

MAX_INPUT = 256 * 1024
MAX_DEPTH = 20
MAX_NODES = 15000
_SCOPE = ContextVar('vrc_eye_developer_trace', default=None)
IDS = re.compile(r'\b(?:usr|wrld|avtr|grp|grol|fvrt|not|frq|invm|gaud|file)_[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b', re.I)
SENSITIVE = re.compile(r'password|passwd|secret|token|cookie|authorization|twofactor|recoverycode|email|birth|friendkey|sessionkey|ipaddress|ip_address|nonce|secureName|shortName|location|instanceId|instance_id|note|wellness|message|contentSettings|contentfilters', re.I)
FREE_TEXT = frozenset(('bio', 'description', 'statusDescription', 'displayName', 'name', 'authorName', 'actorDisplayName', 'text', 'details'))
# Unknown string values are described by type/length, not retained by default.
REVIEWED_STRINGS = frozenset(('id', 'authorId', 'ownerId', 'userId', 'worldId', 'avatarId', 'groupId', 'roleId',
    'targetId', 'actorId', 'targetUserId', 'sourceUserId', 'senderUserId', 'receiverUserId', 'favoriteId', 'currentAvatar',
    'status', 'state', 'releaseStatus', 'platform', 'last_platform', 'region', 'type', 'kind', 'eventType', 'membershipStatus',
    'joinState', 'visibility', 'created_at', 'updated_at', 'observed_at', 'checked_at', 'unityVersion', 'organization',
    'environment', 'operation', 'method', 'origin', 'correlation', 'outcome', 'reason', 'route', 'source', 'phase', 'account',
    'stage', 'provider', 'confidence', 'field', 'path', 'change', 'expected_type', 'observed_type', 'error_type', 'schema',
    'version', 'reference_reviewed', 'live_tested', 'risk', 'verification', 'permission', 'transport', 'format', 'condition',
    'stop_reason', 'source_operation', 'cache_state', 'title', 'scope', 'adapter', 'reference', 'catalog_revision'))
SAFE_QUERY = frozenset(('n', 'offset', 'offline', 'sort', 'order', 'releaseStatus', 'featured', 'user', 'type', 'hidden'))


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


def bounded_json(text, *, limit=MAX_INPUT):
    """Strict JSON: reject duplicate keys, non-finite values and excessive structure."""
    if isinstance(text, bytes):
        if len(text) > limit:
            raise ValueError('JSON input exceeds its size limit.')
        text = text.decode('utf-8-sig')
    if not isinstance(text, str) or len(text.encode('utf-8')) > limit:
        raise ValueError('JSON input exceeds its size limit.')
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError('Duplicate JSON properties are not accepted.')
            out[key] = value
        return out
    def constant(_):
        raise ValueError('Non-finite JSON numbers are not accepted.')
    try:
        value = json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    except (RecursionError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError('Input is not bounded, valid JSON.') from error
    stack, nodes = [(value, 0)], 0
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if depth > MAX_DEPTH or nodes > MAX_NODES:
            raise ValueError('JSON nesting or item count exceeds the local limit.')
        if isinstance(item, dict):
            if any(len(k) > 160 or any(ord(c) < 32 for c in k) for k in item):
                raise ValueError('JSON property names are too long or contain controls.')
            stack.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            stack.extend((v, depth + 1) for v in item)
        elif isinstance(item, float) and not math.isfinite(item):
            raise ValueError('Non-finite JSON numbers are not accepted.')
    return value


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def safe_text(value, limit=2048):
    text = ''.join(c for c in str(value)[:limit] if ord(c) >= 32 or c in '\n\t')
    text = re.sub(r'(?i)\b(?:Basic|Bearer)\s+[A-Za-z0-9+/_=.-]+', '[credential removed]', text)
    text = re.sub(r'(?i)(?:authToken|password|auth|twoFactorAuth|token|secret)\s*[=:]\s*[^\s,;\"}]+', '[credential removed]', text)
    text = re.sub(r'wrld_[0-9a-fA-F-]{36}:[^\s\"<>]+', '[private instance reference omitted]', text)
    text = re.sub(r'~(?:private|hidden|friends|nonce)\([^)]*\)', '[private instance capability omitted]', text)
    text = re.sub(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', '[email removed]', text)
    text = re.sub(r'(?<![\w.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?::[0-9]{1,5})?(?![\w.])', '[network address removed]', text)
    text = re.sub(r'(?i)(?:https?|wss?)://[^\s\"<>]+', '[URL removed]', text)
    text = re.sub(r'(?i)(?:[a-z]:[\\/]|/(?:home|Users|mnt)/)[^\n\"<>]*', '[local path removed]', text)
    return text


def redact(value, *, local=False, key='', depth=0, _budget=None):
    """Sanitize before retaining a diagnostic payload, with conservative unknowns.

    local=True permits reviewed metadata text in the on-device response viewer.
    Exports use local=False again, plus fresh per-bundle identifier pseudonyms.
    """
    budget = _budget if _budget is not None else [4000]
    budget[0] -= 1
    if budget[0] < 0 or depth > 12:
        return '[diagnostic limit]'
    if SENSITIVE.search(str(key)):
        return '[private field omitted]'
    if isinstance(value, Enum):
        value = value.value
    if is_dataclass(value):
        value = asdict(value)
    if isinstance(value, dict):
        out = {}
        for k, v in list(value.items())[:200]:
            k = safe_text(k, 120)
            out[k] = redact(v, local=local, key=k, depth=depth + 1, _budget=budget)
        if len(value) > 200:
            out['_omitted_properties'] = len(value) - 200
        return out
    if isinstance(value, (list, tuple, deque)):
        result = [redact(v, local=local, key=key, depth=depth + 1, _budget=budget) for v in list(value)[:100]]
        if len(value) > 100:
            result.append({'_omitted_items': len(value) - 100})
        return result
    if value is None or type(value) is bool:
        return value
    if type(value) in (int, float):
        return value if abs(value) <= 2**53 and math.isfinite(value) else '[out-of-range number]'
    if isinstance(value, str):
        if key in FREE_TEXT:
            return safe_text(value, 16000 if local else 512) if local else f'[text omitted; {len(value)} characters]'
        if key in REVIEWED_STRINGS or IDS.fullmatch(value) or value.startswith('[private field omitted]') or value.startswith('[text omitted;'):
            return safe_text(value)
        return f'[unreviewed string; {len(value)} characters]'
    return '[unsupported value]'


def safe_route(path):
    parsed = urlsplit(str(path))
    route = parsed.path[:1024]
    # Private instance capabilities are never retained, even inside another URL.
    route = re.sub(r'(^|/)(instances|invite)/[^?]+', r'\1\2/[target omitted]', route)
    route = re.sub(r'(/worlds/[^/]+/)[^/]+~.*', r'\1[instance omitted]', route)
    pairs = [(safe_text(k, 80), safe_text(v, 100) if k in SAFE_QUERY else '[value omitted]')
             for k, v in parse_qsl(parsed.query, keep_blank_values=True)[:40]]
    return route + ('?' + urlencode(pairs) if pairs else '')


def json_shape(value, *, limit=600):
    """Type-only shape; field additions/removals can be compared without private values."""
    result = {}
    def walk(item, path, depth):
        if len(result) >= limit or depth > 12:
            return
        kind = ('null' if item is None else 'boolean' if type(item) is bool else 'integer' if type(item) is int
                else 'number' if type(item) is float else 'string' if isinstance(item, str)
                else 'array' if isinstance(item, list) else 'object' if isinstance(item, dict) else 'unsupported')
        result.setdefault(path, set()).add(kind)
        if isinstance(item, dict):
            for key, child in list(item.items())[:100]:
                if not SENSITIVE.search(str(key)):
                    walk(child, path + '/' + safe_text(key, 100).replace('~', '~0').replace('/', '~1'), depth + 1)
        elif isinstance(item, list):
            for child in item[:20]:
                walk(child, path + '/*', depth + 1)
    walk(value, '$', 0)
    return {path: '|'.join(sorted(types)) for path, types in sorted(result.items())}


def schema_diff(before, after):
    a, b = json_shape(before), json_shape(after)
    return [{'path': p, 'change': 'added' if p not in a else 'removed' if p not in b else 'type changed',
             'expected_type': a.get(p, 'absent'), 'observed_type': b.get(p, 'absent')}
            for p in sorted(set(a) | set(b)) if a.get(p) != b.get(p)]


def value_diff(before, after, *, limit=200):
    """Exact type-aware comparison for reviewed drafts and sanitized observations."""
    result = []
    missing = object()
    def walk(a, b, path, depth=0):
        if len(result) >= limit or depth > MAX_DEPTH:
            return
        if isinstance(a, dict) and isinstance(b, dict):
            for k in sorted(set(a) | set(b)):
                walk(a.get(k, missing), b.get(k, missing), path + '/' + k, depth + 1)
        elif type(a) is not type(b) or a != b:
            result.append({'path': path or '/', 'before': '[absent]' if a is missing else a,
                           'after': '[absent]' if b is missing else b})
    walk(before, after, '')
    return result


@contextmanager
def trace_scope(origin, operation='', correlation=''):
    current = _SCOPE.get() or {}
    token = _SCOPE.set({'origin': safe_text(origin, 120), 'operation': safe_text(operation, 120),
                        'correlation': correlation or current.get('correlation') or secrets.token_hex(8)})
    try:
        yield _SCOPE.get()
    finally:
        _SCOPE.reset(token)


def current_scope():
    return dict(_SCOPE.get() or {'origin': 'existing API adapter', 'operation': '', 'correlation': secrets.token_hex(8)})


class Recorder:
    """Memory-only bounded event ring, TTL and byte budget, safe across workers."""
    def __init__(self, *, maximum=1000, max_bytes=2 * 1024 * 1024, retention=900, clock=time.monotonic):
        self.maximum = max(1, min(maximum, 5000))
        self.max_bytes, self.retention, self.clock = max_bytes, retention, clock
        self.lock = threading.RLock()
        self.rows, self.pins = deque(), {}
        self.sequence = self.dropped = self.expired = self.bytes = 0
        self.enabled = True

    def _prune(self):
        while self.rows and self.clock() - self.rows[0][0] >= self.retention:
            _, size, _ = self.rows.popleft()
            self.bytes -= size
            self.expired += 1

    def emit(self, kind, data=None, *, environment='Live', account='', correlation='', origin='', operation=''):
        if not self.enabled:
            return 0
        scope = current_scope()
        # Private user-supplied text is never part of the event metadata.
        row = {'kind': safe_text(kind, 100), 'environment': environment, 'account': account,
               'origin': origin or scope['origin'], 'operation': operation or scope['operation'],
               'correlation': correlation or scope['correlation'], 'observed_at': stamp(),
               'payload': redact(data or {})}
        with self.lock:
            self.sequence += 1
            row['sequence'] = self.sequence
            size = len(canonical(row).encode('utf-8'))
            self._prune()
            if size > self.max_bytes:
                self.dropped += 1
                return 0
            while self.rows and (len(self.rows) >= self.maximum or self.bytes + size > self.max_bytes):
                _, previous, _ = self.rows.popleft()
                self.bytes -= previous
                self.dropped += 1
            self.rows.append((self.clock(), size, row))
            self.bytes += size
            return row['sequence']

    def snapshot(self, *, query='', kind='', limit=1000):
        with self.lock:
            self._prune()
            values = [row for _, _, row in self.rows]
            if kind:
                values = [r for r in values if r['kind'].startswith(kind)]
            terms = str(query).casefold().split()[:10]
            if terms:
                values = [r for r in values if all(t in canonical(r).casefold() for t in terms)]
            return deepcopy(values[-max(1, min(limit, 5000)):])

    def pin(self, sequence):
        with self.lock:
            row = next((r for _, _, r in self.rows if r['sequence'] == sequence), None)
            if row is None:
                raise ValueError('This event has expired. Select a current event.')
            if len(self.pins) >= 20 and sequence not in self.pins:
                raise ValueError('At most 20 events may be pinned. Clear pins first.')
            self.pins[sequence] = deepcopy(row)

    def clear(self):
        with self.lock:
            self.rows.clear()
            self.pins.clear()
            self.bytes = self.dropped = self.expired = 0
            self.sequence += 1

    def stats(self):
        with self.lock:
            self._prune()
            return {'retained': len(self.rows), 'pinned': len(self.pins), 'bytes': self.bytes,
                    'dropped': self.dropped, 'expired': self.expired, 'retention_seconds': self.retention,
                    'maximum': self.maximum, 'persistent_recording': False, 'sequence': self.sequence}

    def export(self):
        """Pseudonyms are stable within this return value, never between bundles."""
        salt = secrets.token_bytes(32)
        with self.lock:
            result = {'stats': self.stats(), 'events': self.snapshot(), 'pinned': deepcopy(list(self.pins.values()))}
        text = canonical(result)
        def replace_id(match):
            old = match.group(0)
            digest = hmac.new(salt, old.encode(), hashlib.sha256).hexdigest()[:32]
            return old.split('_', 1)[0] + '_' + '-'.join((digest[:8], digest[8:12], digest[12:16], digest[16:20], digest[20:]))
        return json.loads(IDS.sub(replace_id, text))
