"""Opt-in, scope-bound polling of approved folders. No native watcher dependency.

One bounded pass shares PhotoService's worker slot. Idle passes keep only a
latest status; actual import batches use the existing durable receipt ledger.
"""
from __future__ import annotations

import threading
import time

from avatar_library import active_scope
from avatar_library_files import InspectionCancelled, fingerprint
from creator_projects import assert_no_links, local_path
from photo_files import MAX_BYTES, check_directory, inspect_photo, walk_source
from photo_store import key

WATCH_FILES = 32
WATCH_BYTES = 128 * 1024 * 1024
WATCH_SECONDS = 15
STABLE_SECONDS = 2
RETRY_LIMIT = 3


class PhotoWatcher:
    def __init__(self, service, *, clock=time.monotonic):
        self.service=service;self.store=service.store;self.app=service.app;self.clock=clock
        self.thread=None;self.stop=threading.Event();self.closed=False;self.private=False
        self.context=service.token();self.next_due={};self.observations={};self.cursors={}
        self.next_check=0;self.revision=0;self.status='No folders are watched unless explicitly enabled.'
        self.failures={}

    def invalidate(self):
        self.stop.set();self.next_check=0
        self.next_due.clear();self.observations.clear();self.cursors.clear();self.failures.clear()

    def set_private(self, value):
        if self.private!=bool(value):
            self.private=bool(value);self.invalidate()

    def configure(self, source_id, *, enabled, interval=30):
        token=self.service.token();self.service.check(token)
        scope=active_scope(self.app);source=self.store.source(scope,source_id)
        if not source:raise ValueError('Select an approved photo source.')
        if enabled:check_directory(source['path'],source['identity'])
        self.service.check(token)
        result=self.store.configure_watch(scope,source_id,enabled=enabled,interval=interval)
        self.invalidate();self.revision+=1
        return result

    def _guard(self, token, stop, source, config):
        if self.private or self.closed or self.app.demo or getattr(self.app,'safe_mode',False) or getattr(self.app,'_native_private',False):
            raise InspectionCancelled('Folder watching is paused.')
        self.service.check(token,stop)
        current=self.store.watch(config['scope'],source['id'])
        actual=self.store.source(config['scope'],source['id'])
        if (not current or not current['enabled'] or current['revision']!=config['revision']
                or not actual or any(actual[k]!=source[k] for k in ('path','identity','recursive'))):
            raise InspectionCancelled('Watch approval changed. Remaining imports were cancelled.')
        check_directory(source['path'],source['identity'])

    def run_once(self, source, config, token, stop):
        """Worker-only pass, also callable synchronously in deterministic tests."""
        scope=config['scope'];identity=source['id'];rev=config['revision'];cache_key=(scope,identity,rev)
        with self.service.lock:
            if self.service.active:return {'state':'Busy','detail':'A foreground photo task is active.'}
            self.service.active=True
        receipt=None;state='Failed';detail='Watch pass stopped; inspect its status.'
        totals={'imported':0,'replaced':0,'unchanged':0,'waiting':0,'retry':0,'exhausted':0,'deferred':0}
        try:
            self._guard(token,stop,source,config)
            # One replaceable status per source, committed before filesystem work.
            self.store.watch_status(scope,identity,rev,'Checking','Reconciling the approved source. No import is presumed complete.')
            walk=walk_source(source['path'],recursive=source['recursive'],expected=source['identity'],stop=stop,seconds=WATCH_SECONDS)
            self._guard(token,stop,source,config)
            previous=self.observations.get(cache_key,{})
            observed={};eligible=[];inventory=self.store.file_evidence(scope);exports=self.store.export_paths();now=self.clock()
            discovery_partial=False
            for path in walk.files:
                self.service.check(token,stop)
                if self.clock()-now>WATCH_SECONDS:
                    discovery_partial=True;break
                try:info=assert_no_links(local_path(path)).stat();fp=fingerprint(info)
                except (OSError,ValueError):totals['retry']+=1;continue
                old=inventory.get(key(path))
                if old and old['status']=='Available' and old['fingerprint']==fp and old['source_id']==identity:
                    totals['unchanged']+=1;continue
                if key(path) in exports:continue
                last=previous.get(path)
                item=last if last and last['fp']==fp else {'fp':fp,'since':now,'errors':0}
                observed[path]=dict(item)
                if not 0<info.st_size<=MAX_BYTES:
                    observed[path]['errors']=RETRY_LIMIT;totals['exhausted']+=1;continue
                if not last or last['fp']!=fp or now-item['since']<STABLE_SECONDS:
                    totals['waiting']+=1;continue
                if item['errors']>=RETRY_LIMIT:
                    totals['exhausted']+=1;continue
                eligible.append((path,fp,info.st_size))
            # Rotate candidates so large archives and unreadable inputs cannot starve later files.
            cursor=self.cursors.get(cache_key,'')
            eligible=[x for x in eligible if x[0]>cursor]+[x for x in eligible if x[0]<=cursor]
            started=self.clock();read_bytes=processed=0
            for path,fp,size in eligible:
                self._guard(token,stop,source,config)
                if processed>=WATCH_FILES or read_bytes+size>WATCH_BYTES or self.clock()-started>WATCH_SECONDS:
                    totals['deferred']+=1;continue
                if receipt is None:receipt=self.store.begin_job(scope,'Watched photo import')
                processed+=1;read_bytes+=size;self.cursors[cache_key]=path
                try:
                    item=inspect_photo(path,expected=fp,minimum_age=STABLE_SECONDS,stop=stop)
                    self._guard(token,stop,source,config)
                    photo,outcome=self.store.observe(scope,item,source_id=identity)
                    projection=getattr(self.service,'context_projection',None)
                    if outcome=='Imported' and projection and projection['token']==token and 0<=time.monotonic()-projection['at']<=10:
                        try:
                            from photo_files import read_photo
                            from photo_context import record
                            raw,_=read_photo(path,expected=fp,stop=stop)
                            self._guard(token,stop,source,config)
                            record(self.store,scope,photo,raw,projection['session'],adopt=True)
                        except ValueError:pass # Unknown metadata never prevents ordinary indexing.
                    totals[{'Imported':'imported','New version':'replaced','Unchanged':'unchanged'}[outcome]]+=1
                    if outcome=='Imported':
                        try:
                            from photo_compatible import export
                            if export(self.store,scope,identity,photo,stop=stop,check=lambda:self._guard(token,stop,source,config)):
                                totals['compatible_exports']=totals.get('compatible_exports',0)+1
                        except InspectionCancelled:raise
                        except (ValueError,OSError):totals['export_review']=totals.get('export_review',0)+1
                    observed.pop(path,None)
                except InspectionCancelled:raise
                except (OSError,ValueError):
                    observed[path]['errors']+=1;totals['retry']+=1
            self._guard(token,stop,source,config)
            self.observations[cache_key]=observed
            if walk.complete:self.store.missing_after_scan(scope,identity,walk.files)
            state='Idle' if walk.complete and not discovery_partial and not any(totals[k] for k in ('waiting','retry','exhausted','deferred')) else 'Partial'
            detail=(f"{totals['imported']} new, {totals['replaced']} new versions, {totals['unchanged']} unchanged; "
                    f"{totals['waiting']} stabilizing, {totals['retry']} retrying, {totals['exhausted']} need manual retry, {totals['deferred']} deferred.")
            if not walk.complete:detail+=' Discovery incomplete; use a smaller source. Unseen references were retained.'
            if discovery_partial:detail+=' Stat-check budget reached; remaining candidates will be checked later. Use a smaller source if this repeats.'
            if totals.get('compatible_exports') or totals.get('export_review'):detail+=f" Compatible exports: {totals.get('compatible_exports',0)} saved, {totals.get('export_review',0)} need review."
            self.failures[cache_key]=0
        except InspectionCancelled:
            state='Paused';detail='Remaining work stopped. Completed imports stay in the initiating workspace.'
        except ValueError:
            # Folder replacement is distinct from offline/unreadable I/O. Reapproval
            # must happen before any automatic import can continue from a new root.
            try:check_directory(source['path'],source['identity'])
            except ValueError:
                self.store.watch_block(scope,identity,rev)
                state='Reapproval required';detail='The folder identity changed. Reapprove the source and enable watching again.'
            except OSError:
                state='Unavailable';detail='Source unavailable; references retained. A later bounded pass will retry.'
            else:
                state='Failed';detail='Local storage or approval prevented this pass. Review Activity and retry watching explicitly.'
        except OSError:
            state='Unavailable';detail='Source unavailable; references retained. A later bounded pass will retry.'
        except Exception:
            state='Failed';detail='The pass could not finish. No imports are presumed successful; inspect Activity before retrying.'
        finally:
            try:
                if receipt:
                    receipt_state='Cancelled' if state=='Paused' else 'Failed' if state in ('Failed','Unavailable','Reapproval required') else 'Complete' if state=='Idle' else 'Partial'
                    try:self.store.finish_job(scope,receipt,receipt_state,detail)
                    except Exception:self.service.volatile[receipt]=(scope,receipt_state,detail)
                self.store.watch_status(scope,identity,rev,state,detail)
            except Exception:
                state='Failed';detail='Could not save watch status. Inspect Activity before retrying.'
            finally:
                with self.service.lock:self.service.active=False
        if state in ('Unavailable','Failed'):
            self.observations.pop(cache_key,None)  # Reconnection needs fresh stability evidence.
            self.failures[cache_key]=min(5,self.failures.get(cache_key,0)+1)
        delay=min(300,config['interval']*(2**self.failures.get(cache_key,0)))
        self.next_due[cache_key]=self.clock()+delay
        self.status=detail;self.revision+=1
        return dict(state=state,detail=detail,totals=totals,receipt=receipt)

    def tick(self, *, foreground_busy=False):
        if self.closed:return
        token=self.service.token()
        if token!=self.context:
            self.context=token;self.invalidate()
        if self.thread:
            if self.thread.is_alive():return
            self.thread.join();self.thread=None
        if self.private or self.app.demo or getattr(self.app,'safe_mode',False):return
        if foreground_busy or self.service.active:return
        now=self.clock()
        if now<self.next_check:return
        self.next_check=now+2
        try:
            configs=[r for r in self.store.watches(active_scope(self.app)) if r['enabled']]
            valid={(r['scope'],r['source'],r['revision']) for r in configs}
            for mapping in (self.observations,self.next_due,self.cursors,self.failures):
                for k in tuple(mapping):
                    if k not in valid:mapping.pop(k,None)
            # Earliest-due ordering gives every approved source a turn.
            configs.sort(key=lambda r:self.next_due.get((r['scope'],r['source'],r['revision']),0))
            for config in configs:
                k=(config['scope'],config['source'],config['revision'])
                if now<self.next_due.get(k,0):continue
                source=self.store.source(config['scope'],config['source'])
                if not source:continue
                self.stop=threading.Event()
                self.thread=threading.Thread(target=self.run_once,args=(source,config,token,self.stop),name='VRC-Eye-Photo-Watch',daemon=False)
                self.thread.start();break
        except Exception:
            self.status='Watching could not read local settings. Retry from Photos → Sources.'
            self.next_check=now+30

    def close(self):
        self.closed=True;self.stop.set()
        if self.thread:self.thread.join(timeout=2)


def watcher_for(shell):
    watcher=getattr(shell,'photo_watcher',None)
    if watcher is None:
        from photo_service import service_for
        watcher=PhotoWatcher(service_for(shell));shell.photo_watcher=watcher
    return watcher
