"""Image review attached to an existing service-media workspace."""

from text_viewport import window_body
from io import BytesIO
from tkinter import filedialog
from companion_ui import line,button,entry,choice
from vrcx_ui_jobs import LocalPage
from account_workspace_ui import submit_review
import native_images


def show(owner):
    owner.require()
    if not owner.result:raise ValueError('Refresh the destination media view before choosing an upload.')
    return ImageDialog(owner)


class ImageDialog(LocalPage):
    def __init__(self,owner):
        self.owner=owner;app=owner.app;self.window=app.tk.Toplevel(app.root);self.window.title('Review image upload');self.window.transient(app.root)
        frame=app.ttk.Frame(window_body(self.window),padding=12);frame.pack(fill='both',expand=True)
        super().__init__(owner.shell,frame,'Image upload')
        self.result=owner.result;self.draft=None;self.image=None;self.uploaded_file=None
        self.frames=();self.atlas_image=None;self.frame_index=0;self.play_timer=None;self.playing=False;self.play_token=None
        self.show_atlas=self.tk.BooleanVar(value=False);self.frame_info=self.tk.StringVar()
        self.square=self.tk.BooleanVar(value=self.result.kind in ('icons','stickers','emoji'))
        self.animated=self.tk.BooleanVar(value=False);self.fps=self.tk.StringVar(value='12')
        self.mask=self.tk.StringVar(value='square');self.motion=self.tk.StringVar(value='stop');self.loop=self.tk.StringVar(value='linear');self.direction=1
        self.print_time=self.tk.StringVar();self.print_note=self.tk.StringVar()
        self.ttk.Checkbutton(frame,text='Center-crop to square',variable=self.square,command=self.clear_preview).pack(anchor='w')
        if self.result.kind in ('stickers','emoji'):
            row=line(self);self.ttk.Label(row,text='Service image mask').pack(side='left');choice(self,row,self.mask,native_images.MASKS,width=14)
        if self.result.kind=='emoji':
            row=line(self);self.ttk.Checkbutton(row,text='Convert animated GIF / WebP to a reviewed emoji atlas',variable=self.animated,command=self.clear_preview).pack(side='left')
            self.ttk.Label(row,text='FPS (1–64)').pack(side='left');entry(self,row,self.fps,5)
            for label,fps in (('Slow · 8',8),('Standard · 12',12),('Smooth · 24',24)):
                button(self,row,label,lambda value=fps:self.fps.set(str(value)))
            self.fps.trace_add('write',lambda *_:self.clear_preview())
            row=line(self);self.ttk.Label(row,text='Motion effect').pack(side='left');choice(self,row,self.motion,native_images.ANIMATION_STYLES,width=18)
            self.ttk.Label(row,text='Frame loop').pack(side='left');choice(self,row,self.loop,native_images.LOOP_STYLES,self.preview_mode,14)
            self.ttk.Label(frame,text='Preview shows the outgoing image frames. VRChat applies the selected mask and 3D motion effect.').pack(anchor='w')
        if self.result.kind=='prints':
            from datetime import datetime,timezone
            self.print_time.set(datetime.now(timezone.utc).isoformat(timespec='seconds'))
            row=line(self);self.ttk.Label(row,text='Print capture time (with UTC offset)').pack(side='left');entry(self,row,self.print_time,34)
            row=line(self);self.ttk.Label(row,text='Print note').pack(side='left');entry(self,row,self.print_note,65)
        row=line(self);button(self,row,'Choose image…',self.choose);button(self,row,'Review upload…',self.submit)
        if self.result.kind in ('avatar','world'):button(self,row,'Review attaching uploaded cover…',self.attach)
        if self.result.kind in ('group-gallery','group-gallery-pending'):button(self,row,'Review adding uploaded image to group…',self.attach)
        self.preview_label=self.ttk.Label(frame);self.preview_label.pack(padx=12,pady=8)
        if self.result.kind=='emoji':
            row=line(self);button(self,row,'Play / pause',self.play_pause)
            button(self,row,'Previous frame',lambda:self.step_frame(-1));button(self,row,'Next frame',lambda:self.step_frame(1))
            self.ttk.Checkbutton(row,text='Show outgoing atlas',variable=self.show_atlas,command=self.preview_mode).pack(side='left')
            self.ttk.Label(frame,textvariable=self.frame_info).pack(anchor='w')
        self.details=self.tk.StringVar(value='Original files are preserved. Preview the exact outgoing PNG before submitting.')
        from screen_reader_model import annotate
        annotate(self.preview_label,name='Outgoing image preview',role='graphic',value=lambda:self.details.get()+'. '+self.frame_info.get(),description='Read-only image metadata; no generated visual description.')
        self.ttk.Label(frame,textvariable=self.details,wraplength=650).pack(anchor='w',pady=8)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(150,self.tick)
        owner.image_windows.append(self)

    def clear_preview(self):
        self.stop_playback();self.cancel();self.draft=None;self.image=None;self.uploaded_file=None
        self.frames=();self.atlas_image=None;self.frame_index=0;self.direction=1;self.frame_info.set('')
        if hasattr(self,'preview_label'):self.preview_label.configure(image='')
        if hasattr(self,'details'):self.details.set('Image preview cleared. Select an image explicitly.')
        if getattr(self.app,'_native_private',False):self.print_time.set('');self.print_note.set('')

    def choose(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,filetypes=[('Images','*.png *.jpg *.jpeg *.webp *.bmp *.gif'),('All files','*')])
        self.verify(token)
        if not path:return
        self.clear_preview()
        square=bool(self.square.get())
        animated=bool(self.animated.get())
        try:fps=int(self.fps.get())
        except ValueError:raise ValueError('Enter a whole-number frame rate.') from None
        def done(draft):
            from PIL import Image,ImageTk
            with Image.open(BytesIO(draft.png)) as image:
                image.thumbnail((600,400));self.atlas_image=ImageTk.PhotoImage(image,master=self.window)
            self.frames=tuple(ImageTk.PhotoImage(frame,master=self.window) for frame in native_images.preview_frames(draft)) if draft.frames>1 else ()
            self.draft=draft;self.frame_index=0;self.display_frame()
            self.details.set(f'{draft.width} × {draft.height} · {len(draft.png):,} bytes\n{draft.transformation}\nOriginal: {draft.original_size[0]} × {draft.original_size[1]}')
            if self.frames and not self.show_atlas.get() and not self.reduced_motion():self.play_pause()
        self.start(lambda c,s,p:native_images.stage(path,square=square,animated=animated,fps=fps,print_image=self.result.kind=='prints'),done)

    def reduced_motion(self):
        return bool(getattr(getattr(getattr(self.app,'experience',None),'preferences',None),'reduced_motion',False))

    def stop_playback(self):
        if self.play_timer is not None:self.app.root.after_cancel(self.play_timer)
        self.play_timer=None;self.playing=False;self.play_token=None

    def display_frame(self):
        self.image=self.frames[self.frame_index] if self.frames and not self.show_atlas.get() else self.atlas_image
        self.preview_label.configure(image=self.image or '')
        self.frame_info.set(f'Frame {self.frame_index+1} of {len(self.frames)} · {self.draft.fps} FPS' if self.frames else '')

    def preview_mode(self):
        self.stop_playback();self.direction=1;self.display_frame()

    def step_frame(self,delta):
        self.ready();self.owner.require();self.stop_playback()
        if not self.frames:raise ValueError('Choose an animated emoji first.')
        self.show_atlas.set(False);self.frame_index=(self.frame_index+delta)%len(self.frames);self.display_frame()

    def play_pause(self):
        self.ready();self.owner.require()
        if self.playing:self.stop_playback();return
        if not self.frames:raise ValueError('Choose an animated emoji first.')
        if self.reduced_motion():raise ValueError('Reduced motion is enabled. Use the frame buttons to inspect the animation.')
        self.show_atlas.set(False);self.playing=True;self.play_token=self.token();self.display_frame()
        self.play_timer=self.app.root.after(max(16,round(1000/self.draft.fps)),self.advance_frame)

    def advance_frame(self):
        self.play_timer=None
        if not self.playing or self.closed:return
        from vrchat_api import APIError
        try:self.verify(self.play_token);self.owner.require()
        except (ValueError,APIError):self.clear_preview();return
        if self.reduced_motion():self.stop_playback();return
        if self.loop.get()=='pingpong':
            if self.frame_index+self.direction not in range(len(self.frames)):self.direction=-self.direction
            self.frame_index+=self.direction
        else:self.frame_index=(self.frame_index+1)%len(self.frames)
        self.display_frame()
        self.play_timer=self.app.root.after(max(16,round(1000/self.draft.fps)),self.advance_frame)

    def submit(self):
        self.ready();self.owner.require()
        if not self.draft:raise ValueError('Choose and preview an image first.')
        values={'image':self.draft}
        if self.result.kind in ('stickers','emoji'):values['maskTag']=self.mask.get()
        if self.result.kind=='emoji':values.update(animationStyle=self.motion.get(),loopStyle=self.loop.get())
        if self.result.kind=='prints':values.update(timestamp=self.print_time.get(),note=self.print_note.get())
        submit_review(self,'upload-image',result=self.result,values=values,view_guard=lambda:(self.token(),id(self.draft),self.print_time.get(),self.print_note.get(),self.mask.get(),self.motion.get(),self.loop.get()),done=self.uploaded)

    def uploaded(self,outcome):
        self.clear_preview();self.status.set(outcome.message)
        if outcome.state=='Confirmed':
            self.uploaded_file=outcome.value
            self.details.set('Uploaded file: '+outcome.value.get('id','')+'. '+('Review attaching it to the owned asset as a separate action.' if self.result.kind in ('avatar','world') else 'Refresh the destination to view it.')+' The original local image was preserved.')

    def attach(self):
        self.ready();self.owner.require()
        if not self.uploaded_file:raise ValueError('Upload an image and confirm its result first.')
        if self.result.kind in ('group-gallery','group-gallery-pending'):
            selected=self.uploaded_file;gallery=self.result;group=gallery.subject.split('/')[0]
            def refreshed(grants):
                if self.uploaded_file is not selected:raise ValueError('The image selection changed.')
                submit_review(self,'group-gallery-add-image',result=gallery,values={'fileId':selected['id']},group_result=grants,
                    view_guard=lambda:(self.token(),id(self.uploaded_file)),done=lambda outcome:self.details.set(outcome.message))
            self.start(lambda c,s,p:__import__('native_api').read(c,'group',subject=group,stop=s,progress=p),refreshed,api=True)
            return
        versions=self.uploaded_file.get('versions',[])
        if not versions:raise ValueError('The upload reply did not return a completed image version. Refresh the asset before retrying.')
        url=versions[-1].get('file',{}).get('url','')
        selected=self.uploaded_file;kind=self.result.kind;subject=self.result.subject
        def refreshed(result):
            if self.uploaded_file is not selected:raise ValueError('The uploaded file selection changed. Review it again.')
            self.result=result
            submit_review(self,kind+'-image',result=result,
                values={'fileId':selected['id'],'imageUrl':url},view_guard=lambda:(self.token(),id(self.uploaded_file)),
                done=lambda outcome:self.details.set(outcome.message+' The uploaded file is retained; prior images were not deleted.'))
        import native_api
        self.start(lambda c,s,p:native_api.read(c,kind,subject=subject,stop=s,progress=p),refreshed,api=True)

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(150,self.tick)

    def close(self):
        if self.closed:return
        self.stop_playback();super().close();self.draft=None;self.image=None;self.frames=();self.atlas_image=None
        if self in self.owner.image_windows:self.owner.image_windows.remove(self)
        self.app.root.after_cancel(self.timer);self.window.destroy()
