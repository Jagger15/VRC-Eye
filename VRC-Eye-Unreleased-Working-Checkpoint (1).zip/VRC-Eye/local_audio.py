"""User-selected clips and local speech on the one application audio engine."""
from array import array
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import queue
import threading
import time


@dataclass(frozen=True)
class Clip:
    path:str
    sha256:str
    rate:int
    channels:int
    seconds:float
    peak:float
    samples:bytes


def read_clip(path,stop=None):
    """Bound decoded frames before allocation; output is 48k stereo float32."""
    path=Path(path).resolve(strict=True)
    if not path.is_file() or path.stat().st_size>32*1024**2:raise ValueError('Choose an audio file smaller than 32 MiB.')
    from avatar_library_files import checked_stream
    with checked_stream(path,limit=32*1024**2) as (_,stream,before):
        raw=stream.read(32*1024**2+1)
        if len(raw)>32*1024**2 or len(raw)!=before.st_size:raise ValueError('The clip changed or exceeded its size budget.')
    try:
        import soundfile as sf
        import numpy as np
    except (ImportError,OSError):raise ValueError('Audio clip decoding needs soundfile/libsndfile; restart with the launcher.') from None
    from io import BytesIO
    try:
        with sf.SoundFile(BytesIO(raw)) as stream:
            rate,channels,frames=stream.samplerate,stream.channels,len(stream)
            if not 8000<=rate<=192000 or channels not in (1,2) or not 0<frames<=rate*90:
                raise ValueError('Choose a mono/stereo clip up to 90 seconds, at 8–192 kHz.')
            if stop and stop.is_set():raise ValueError('Clip load cancelled.')
            data=stream.read(frames,dtype='float32',always_2d=True)
        if not np.isfinite(data).all():raise ValueError('Clip contains invalid samples.')
        peak=float(np.max(np.abs(data)))
        if channels==1:data=np.repeat(data,2,axis=1)
        if rate!=48000:
            count=round(frames*48000/rate)
            # Linear interpolation for short cue previews; the selected mixer
            # still limits every output. No native decoder or shell is spawned.
            x=np.arange(count,dtype=np.float64)*rate/48000
            data=np.column_stack([np.interp(x,np.arange(frames),data[:,c]) for c in range(2)]).astype('float32')
        if stop and stop.is_set():raise ValueError('Clip load cancelled.')
        return Clip(str(path),hashlib.sha256(raw).hexdigest(),rate,channels,frames/rate,peak,data.astype('float32').tobytes())
    except (RuntimeError,TypeError) as exc:raise ValueError('The installed decoder could not read this audio format.') from exc


class ClipPlayer:
    """A single bounded clip, pulled by the existing mixer thread."""
    def __init__(self):self.lock=threading.Lock();self.data=array('f');self.at=0;self.loop=False;self.private=True;self.gain=.5;self.playing=False
    def play(self,clip,*,private=True,loop=False,gain=.5):
        if not isinstance(clip,Clip) or not 0<len(clip.samples)<=48000*2*4*90 or len(clip.samples)%8:raise ValueError('Invalid decoded clip.')
        if type(private) is not bool or type(loop) is not bool or not math.isfinite(gain) or not 0<=gain<=1:raise ValueError('Invalid clip routing or gain.')
        data=array('f');data.frombytes(clip.samples)
        if any(not math.isfinite(x) for x in data):raise ValueError('Invalid clip samples.')
        with self.lock:self.data=data;self.at=0;self.private=private;self.loop=loop;self.gain=gain;self.playing=True
    def stop(self):
        with self.lock:self.data=array('f');self.at=0;self.playing=False
    def pull(self,frames):
        with self.lock:
            if not self.playing:return None
            output=array('f',[0])*(frames*2)
            for i in range(len(output)):
                if self.at>=len(self.data):
                    if self.loop:self.at=0
                    else:self.playing=False;break
                output[i]=self.data[self.at];self.at+=1
            return output,self.private,self.gain


class Speech:
    """Optional Vosk worker. Capture is a tap on the shared selected mic."""
    def __init__(self,engine):
        self.engine=engine;self.job=None;self.halt=threading.Event();self.frames=queue.Queue(maxsize=25);self.events=queue.Queue(maxsize=16)
        self.state='Not capturing';self.owned=False;self.engine_generation=None;self.generation=0;self.discard=False;self.input_lost=False
    @property
    def running(self):return bool(self.job and self.job.is_alive())
    def emit(self,text,final=False,*,generation=None):
        if generation is not None and generation!=self.generation:return
        try:self.events.put_nowait((self.generation,text[:6000],final))
        except queue.Full:
            try:self.events.get_nowait()
            except queue.Empty:pass
            try:self.events.put_nowait((self.generation,text[:6000],final))
            except queue.Full:pass
    def tap(self,data,channels):
        if self.halt.is_set():return
        try:self.frames.put_nowait((data,channels))
        except queue.Full:self.input_lost=True;self.halt.set();self.state='Stopped: speech input queue overflow; draft discarded'
    def start(self,model_path,device,guard,recognizer_factory=None):
        if self.running:raise ValueError('Wait for the previous speech capture to release.')
        path=Path(model_path).expanduser().resolve(strict=True)
        if not path.is_dir():raise ValueError('Choose an extracted local Vosk model folder.')
        if self.engine.running and 'microphone' not in getattr(self.engine,'active_sources',{}):raise ValueError('The active mix has no microphone. Stop it and select your microphone first.')
        self.generation+=1;generation=self.generation;self.halt=threading.Event();self.discard=False;self.input_lost=False
        self.frames=queue.Queue(maxsize=25);self.events=queue.Queue(maxsize=16)
        self.owned=not self.engine.running;self.engine_generation=self.engine.generation
        self.state='Loading local recognition model; microphone not yet requested'
        def run():
            words=[];started=time.monotonic();attached=False
            try:
                if recognizer_factory:recognizer=recognizer_factory(str(path))
                else:
                    try:from vosk import Model,KaldiRecognizer
                    except (ImportError,OSError):raise ValueError('Local transcription needs optional vosk. Install requirements-speech.txt and choose a local model.') from None
                    recognizer=KaldiRecognizer(Model(str(path)),48000)
                if self.halt.is_set() or not guard():return
                self.engine.set_microphone_tap(self.tap);attached=True
                if self.owned:
                    self.engine.start({'microphone':device},{},meter_only=True,expected_generation=self.engine_generation)
                self.state='Local transcription · no new output route armed; existing microphone routes remain active'
                while not self.halt.is_set() and time.monotonic()-started<45:
                    if not guard() or generation!=self.generation:self.discard=True;break
                    if not self.engine.running:raise ValueError('Microphone capture stopped; draft discarded.')
                    try:data,channels=self.frames.get(timeout=.1)
                    except queue.Empty:continue
                    samples=array('f');samples.frombytes(data);pcm=array('h')
                    for i in range(0,len(samples),channels):
                        value=sum(samples[i:i+channels])/channels
                        if not math.isfinite(value):raise ValueError('Invalid microphone samples.')
                        pcm.append(round(max(-1,min(1,value))*32767))
                    if recognizer.AcceptWaveform(pcm.tobytes()):
                        result=json.loads(recognizer.Result()).get('text','');words.append(result)
                        self.emit(' '.join(words),generation=generation)
                    else:self.emit(' '.join(words+[json.loads(recognizer.PartialResult()).get('partial','')]),generation=generation)
                if not self.discard and not self.input_lost and guard():
                    words.append(json.loads(recognizer.FinalResult()).get('text',''));self.emit(' '.join(words).strip(),True,generation=generation)
                    self.state='Capture ended · review the private draft'
            except Exception as exc:
                self.discard=True;self.state=str(exc)[:220] if isinstance(exc,ValueError) else 'Local speech provider failed; draft discarded'
            finally:
                if self.discard or self.input_lost:self.emit('',True,generation=generation)
                if attached:
                    clear=getattr(self.engine,'clear_microphone_tap',None)
                    if clear:clear(self.tap)
                    else:self.engine.set_microphone_tap(None)
                if self.owned and self.engine.generation==self.engine_generation:self.engine.stop()
                while not self.frames.empty():
                    try:self.frames.get_nowait()
                    except queue.Empty:break
        self.job=threading.Thread(target=run,daemon=True,name='Eye local speech');self.job.start()
    def stop(self,discard=False):
        self.discard=self.discard or discard;self.halt.set()
        if discard:
            self.generation+=1
            while not self.events.empty():
                try:self.events.get_nowait()
                except queue.Empty:break


def engine_for(app):
    if not getattr(app,'shared_audio',None):
        from audio_engine import AudioEngine
        app.shared_audio=AudioEngine()
    return app.shared_audio
