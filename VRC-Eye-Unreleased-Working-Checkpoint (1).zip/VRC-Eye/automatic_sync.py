"""One shell-owned receive-only pipeline and paced snapshot/view scheduler.

Tk owns publication. Workers only read through the active API's existing lock
and request budget. No saved/inactive account is contacted here.
"""
from collections import deque, OrderedDict
import queue
import sqlite3
import threading
import time

from account_header import boundary, private
from companion_data import entity_id, stamp, sanitize
from friend_feed import FeedModel, Pipeline
from native_events import hub_for
from session_restore import offline
from vrchat_api import APIError

KEY='network.automatic_sync.v1'
KINDS=('friends-online','notifications','notifications-v2','self-profile','friends-offline')
INTERVAL=300


def read_snapshot(client,kind,offset,stop):
    import companion_api, native_api
    reader=native_api.read if kind=='notifications-v2' else companion_api.read
    return reader(client,kind,offset=offset,stop=stop)


class AutomaticSync:
    def __init__(self,shell,*,clock=time.monotonic,pipeline_factory=Pipeline,reader=read_snapshot):
        self.shell,self.app=shell,shell.app
        self.clock,self.pipeline_factory,self.reader=clock,pipeline_factory,reader
        self.hub=hub_for(shell)
        self.enabled=self.store.option(KEY,True) is True
        self.context=None;self.closed=False;self.model=None;self.generation=0
        self.pipeline=None;self.pipeline_context=None;self.pipe_state='stopped'
        self.pipeline_retry=0.;self.pipeline_failures=0;self.auth_blocked=False
        self.job=None;self.tasks=deque();self.next_cycle=0.;self.cycle=0
        self.watches={}
        self.sequence=0;self.friend_versions=OrderedDict();self.friend_floor=0;self.fresh={}
        self.self_profile={};self.self_checked='';self.self_version=0
        self.coverage={};self.last_packet='';self.last_snapshot='';self.problem=''
        self.last_tick=self.clock();self.last_wall=time.time();self.stale=set()
        from friend_activity import FriendActivity
        self.activity=FriendActivity(self);self.pause_reason=''
        self.sync_context()

    @property
    def store(self):return self.shell.store

    def token(self):return boundary(self.app),private(self.app),offline(self.app)

    def sync_context(self):
        current=self.token()
        if current==self.context:return
        self.cancel();self.context=current;self.generation+=1
        self.model=None;self.fresh.clear();self.friend_versions.clear();self.friend_floor=0
        self.stale.clear()
        self.self_profile={};self.self_checked='';self.self_version=0
        self.sequence=0;self.coverage={};self.last_packet='';self.last_snapshot='';self.problem=''
        self.auth_blocked=False;self.pipeline_failures=0;self.pipeline_retry=0;self.next_cycle=0
        self.watches.clear()
        self.hub.sync()
        client=self.app.api
        if client and client.authenticated and not current[1] and not self.app.demo and not getattr(self.app,'safe_mode',False):
            self.model=FeedModel(self.store,client.user_id);self.model.restore()
        self.activity.reset();self.pause_reason=''

    def blocked(self):
        if self.closed:return 'Stopped'
        if self.app.demo or getattr(self.app,'safe_mode',False):return 'Paused in Demo / Safe mode'
        if private(self.app):return 'Paused · private information hidden'
        if offline(self.app):return 'Offline · showing saved observations'
        client=self.app.api
        if not client or not client.authenticated or client.closed.is_set():return 'Sign-in required'
        if self.auth_blocked:return 'Sign-in required · live session rejected'
        if not self.enabled:return 'Paused · automatic sync disabled'
        desktop=getattr(self.shell,'desktop_service',None)
        if desktop and not desktop.policy['background_feed'] and self.app.root.state() in ('iconic','withdrawn'):
            return 'Paused while minimized'
        return ''

    def cancel(self):
        self.tasks.clear()
        if self.model:self.stale.update(self.model.friends)
        if self.job:self.job['stop'].set()
        if self.pipeline:self.pipeline.close()
        self.pipeline_context=None
        self.pipe_state='stopped'

    def configure(self,enabled):
        from account_actions import local_writable
        local_writable(self.app)
        if type(enabled) is not bool:raise ValueError('Automatic sync must be enabled or disabled.')
        self.store.set_option(KEY,enabled);self.enabled=enabled
        if not enabled:
            self.activity.gap('Automatic sync paused. Events during the pause are unknown.')
            self.cancel()
        else:self.next_cycle=0;self.pipeline_retry=0

    def request_sync(self):
        self.sync_context()
        reason=self.blocked()
        if reason:raise ValueError(reason+'. Resume automatic sync to request a catch-up.')
        if self.tasks or self.job:return False
        self.cycle+=1
        self.tasks.extend((kind,0,self.sequence,self.hub.revision) for kind in KINDS)
        self.next_cycle=float('inf');self.problem=''
        for kind in KINDS:self.coverage[kind]={'state':'queued','pages':0}
        return True

    def foreground_busy(self):
        """Yield before dispatch rather than hold the shared lock during a wait."""
        pages=list(getattr(self.shell,'pages',{}).values())
        for page in tuple(pages):pages.extend(getattr(page,'native_panels',()))
        pages.extend(v for v in (getattr(self.shell,'desktop_dialog',None),getattr(self.shell,'native_data_dialog',None)) if v)
        if getattr(self.shell,'status_rules',None):pages.append(self.shell.status_rules)
        return any(getattr(page,'job',None) for page in pages)

    def budget_ready(self):
        client=self.app.api
        return bool(client and client.clock()>=client.next_metadata and not client.lock.locked() and not self.foreground_busy())

    def watch(self,key,reader,publish,valid,*,immediate=False):
        """Refresh an explicitly opened visible view through the existing worker."""
        self.watches[key]=dict(reader=reader,publish=publish,valid=valid,due=self.clock()+(0 if immediate else 300),context=self.context)

    def unwatch(self,key):
        self.watches.pop(key,None)
        if self.job and self.job['task'][0]=='view:'+key:self.job['stop'].set()

    def _queue_watch(self):
        if self.tasks or self.job:return
        for key,watch in tuple(self.watches.items()):
            if watch['context']!=self.context:self.watches.pop(key,None);continue
            if self.clock()>=watch['due'] and watch['valid']():
                self.tasks.append(('view:'+key,0,self.sequence,self.hub.revision));return

    def _launch(self,task):
        if task[0].startswith('view:'):
            watch=self.watches.get(task[0][5:])
            if not watch or not watch['valid']():return
        client=self.app.api;stop=threading.Event();output=queue.Queue(maxsize=1)
        job=dict(task=task,stop=stop,output=output,generation=self.generation,context=self.context,activity_epoch=self.activity.epoch)
        if task[0].startswith('view:'):job['watch']=self.watches.get(task[0][5:])
        self.job=job;self.app.transfer_stops.append(stop)
        def run():
            try:
                if stop.is_set():return
                value=job['watch']['reader'](client,stop) if job.get('watch') else self.reader(client,task[0],task[1],stop)
                output.put_nowait(('done',value))
            except (APIError,ValueError,OSError,sqlite3.Error) as error:
                output.put_nowait(('error',getattr(error,'status_code',None)))
            except Exception:output.put_nowait(('error',None))
            finally:
                job['finished']=True
                if stop in self.app.transfer_stops:self.app.transfer_stops.remove(stop)
        threading.Thread(target=run,daemon=True).start()

    def _finish_job(self):
        job=self.job
        if not job or not job.get('finished'):return
        self.job=None
        if job['stop'].is_set() or job['generation']!=self.generation or job['context']!=self.token():return
        try:kind,result=job['output'].get_nowait()
        except queue.Empty:return
        task,offset,after,hub_after=job['task']
        if task.startswith('view:'):
            watch=job.get('watch');key=task[5:]
            if not watch or self.watches.get(key) is not watch:return
            desktop=getattr(self.shell,'desktop_service',None)
            watch['due']=self.clock()+(900 if desktop and desktop.policy['power']=='Low power' else 300)
            if kind=='done' and watch['valid']() and result.account==(self.app.api.user_id,self.app.api.session_revision):
                watch['publish'](result)
            elif kind=='error':self.problem='A visible view could not refresh; its previous observations remain visible.'
            return
        if kind=='error':
            self.coverage[task]={'state':'sign-in required' if result==401 else 'unavailable' if result in (403,404) else 'retry later','pages':offset//100}
            self.problem='Some snapshots could not be refreshed; previous observations remain visible.'
            if getattr(self.app.api,'connection_state','')=='unreachable' and self.pipeline:
                self.pipeline.close();self.pipe_state='reconnecting'
                self.hub.gap('The API could not be reached. Reconnecting; events during the gap are unknown.')
                self.activity.gap('The API could not be reached. Events during the connection gap are unknown.')
        else:
            if result.account!=(self.app.api.user_id,self.app.api.session_revision):return
            try:
                if task.startswith('friends-'):self.observe_friends(result,after=after,recap_epoch=job['activity_epoch'])
                elif task=='self-profile':self.observe_self(result.data,after=after)
                else:self.observe_inbox(result,after=hub_after)
            except (ValueError,APIError):
                self.coverage[task]={'state':'unavailable','pages':offset//100}
                self.problem='A snapshot contained unsupported data. Other datasets continue updating.'
                if not self.tasks:self.next_cycle=self.clock()+INTERVAL;self.activity.finish()
                return
            self.last_snapshot=stamp()
            maximum=20 if task.startswith('friends-') else 3
            more=result.more;pages=offset//100+1
            self.coverage[task]={'state':'partial' if more else 'checked','pages':pages,'checked':self.last_snapshot}
            if more and pages<maximum:self.tasks.append((task,offset+100,after,hub_after))
        if not self.tasks:
            desktop=getattr(self.shell,'desktop_service',None)
            period=900 if desktop and desktop.policy['power']=='Low power' else INTERVAL
            self.next_cycle=self.clock()+period
            self.activity.finish()

    def _friend_mark(self,ref):
        self.sequence+=1;self.friend_versions[ref]=self.sequence;self.friend_versions.move_to_end(ref)
        while len(self.friend_versions)>5000:
            _,version=self.friend_versions.popitem(last=False);self.friend_floor=max(self.friend_floor,version)

    def observe_friends(self,result,*,after=None,recap_epoch=None):
        self.sync_context()
        if not self.model or result.account!=(self.app.api.user_id,self.app.api.session_revision):return
        if getattr(result,'source_client',None) not in (None,self.app.api):return
        for row in result.data:
            ref=entity_id('user',row.get('id'))
            if after is not None and (after<self.friend_floor or self.friend_versions.get(ref,0)>after):continue
            current=self.model.observe(row,'VRChat friends snapshot','offline' if result.kind=='friends-offline' else row.get('state') or 'online / website active')
            self.activity.capture(current,epoch=recap_epoch)
            self.fresh[ref]=(self.clock(),'Snapshot')
            self.stale.discard(ref)
        self.activity.seed_gathering()

    def observe_inbox(self,result,*,after=None):
        self.sync_context()
        if not self.model or result.account!=(self.app.api.user_id,self.app.api.session_revision):return
        if getattr(result,'source_client',None) not in (None,self.app.api):return
        for row in result.data:self.hub.notification(row,'v2' if result.kind=='notifications-v2' else 'v1',after=after)

    def observe_self(self,data,*,after=None,live=False):
        if not self.model or after is not None and self.self_version>after:return
        ref=entity_id('user',data.get('id'))
        if ref!=self.model.account:return
        # Keep presentation fields only; auth/user also includes private session data.
        from friend_feed import WATCH
        keys=set(WATCH)|{'id','username','pronouns'}
        incoming={k:v for k,v in sanitize(data).items() if k in keys and (v is None or isinstance(v,str))}
        if 'username' in data:
            from account_header import name
            if name(data['username']):incoming['username']=name(data['username'])
        merged=dict(self.self_profile);merged.update(incoming)
        identity=getattr(self.app.api,'account_identity',None)
        if identity:
            merged.setdefault('username',identity.username);merged.setdefault('displayName',identity.display_name)
        self.self_profile=merged;self.self_checked=stamp()
        self.app.api._remember_identity(merged)
        if not live:
            from vrchat_api import friend_ids
            current=friend_ids(data)
            if current is not None:
                for user in tuple(self.model.friends):
                    if user not in current and (after is None or self.friend_versions.get(user,0)<=after):
                        self.model.friends.pop(user,None);self.model.checked.pop(user,None);self.fresh.pop(user,None);self.model.revision+=1
        if live:self.sequence+=1;self.self_version=self.sequence

    def packet(self,packet):
        self.sync_context()
        if self.blocked() or not self.model:return
        kind,data=packet;self.last_packet=stamp()
        if kind.startswith('friend-'):
            ref=entity_id('user',data.get('userId') or data.get('userid'))
            old=dict(self.model.friends.get(ref,{}));fresh=self.fresh.get(ref)
            trusted=bool(fresh and ref not in self.stale and 0<=self.clock()-fresh[0]<600)
            self._friend_mark(ref);self.model.pipeline(packet)
            self.activity.observe_live(kind,old,self.model.friends.get(ref),trusted=trusted)
            if kind in ('friend-add','friend-delete'):
                self.app.api.friends=None;self.app.api.friends_checked_at=''
            if kind=='friend-delete':self.fresh.pop(ref,None)
            else:self.fresh[ref]=(self.clock(),'Live observation');self.stale.discard(ref)
        elif kind=='user-update':
            ref=entity_id('user',data.get('userId') or data.get('userid'))
            if ref==self.model.account:self.observe_self(dict(data.get('user',{}),id=ref),live=True)
        elif kind=='response-notification':
            if data.get('receiverId')==self.model.account and not self.tasks:self.next_cycle=0
        else:self.hub.packet(kind,data)

    def _pipeline_tick(self):
        pipe=self.pipeline
        if pipe:
            # A normally ended worker can leave its final events in the queue.
            valid=self.pipeline_context==self.context and not self.blocked()
            for _ in range(64):
                try:kind,value=pipe.output.get_nowait()
                except queue.Empty:break
                if not valid:continue
                try:
                    if kind=='packet':self.packet(value)
                    elif kind=='reconcile':
                        self.pipe_state='live';self.pipeline_failures=0
                        if not self.tasks and not self.job:self.next_cycle=0
                    elif kind=='auth-error':self.auth_blocked=True;pipe.close();self.tasks.clear()
                    elif kind=='gap':
                        self.pipe_state='reconnecting';self.hub.gap(value)
                        self.activity.gap(value)
                        if self.model:self.stale.update(self.model.friends)
                    elif kind=='status':self.pipe_state='reconnecting'
                    elif kind=='error':self.pipe_state='reconnecting'
                except (ValueError,APIError):
                    self.hub.gap('A live update could not be applied. Snapshot coverage may be incomplete.')
                    self.activity.gap('A live update could not be applied. Events during this observation gap are unknown.')
                    if not self.tasks:self.next_cycle=0
            if pipe.finished.is_set() and pipe.output.empty():
                self.pipeline=None
                if self.pipeline_context==self.context and not self.blocked():
                    self.pipeline_failures+=1
                    self.pipeline_retry=self.clock()+min(900,60*2**min(self.pipeline_failures-1,4))
                    self.pipe_state='reconnecting'
        if not self.pipeline and self.clock()>=self.pipeline_retry and not self.blocked() and self.budget_ready():
            self.pipeline_context=self.context
            try:
                pipe=self.pipeline_factory(self.app);pipe.start();self.pipeline=pipe;self.pipe_state='connecting'
            except (APIError,OSError):
                self.pipeline=None;self.pipe_state='unavailable';self.pipeline_retry=self.clock()+900
                self.problem='Live connection unavailable; scheduled snapshots remain enabled.'

    def tick(self):
        if self.closed:return
        self.sync_context()
        now=self.clock();wall=time.time();gap=max(now-self.last_tick,wall-self.last_wall)
        self.last_tick=now;self.last_wall=wall
        if gap>90 and not self.blocked():
            self.cancel();self.generation+=1;self.next_cycle=0;self.pipeline_retry=0
            self.hub.gap('Observation resumed after a pause or sleep. Catching up; missed events cannot be replayed.')
            self.activity.gap('Observation resumed after a pause or sleep. Missed events and their times are unknown.')
        reason=self.blocked()
        if reason:
            if not self.pause_reason and self.fresh:self.activity.gap(reason+'. Events during this gap are unknown.')
            self.pause_reason=reason
            self.cancel();self._finish_job()
            if self.pipeline and self.pipeline.finished.is_set():self.pipeline=None
            return
        self.pause_reason=''
        self._pipeline_tick()
        # A rejection received above stops snapshot work in this same tick.
        if self.blocked():self.cancel();return
        self._finish_job()
        self._queue_watch()
        if not self.tasks and not self.job and self.clock()>=self.next_cycle:self.request_sync()
        if self.tasks and not self.job and self.pipe_state!='connecting' and self.budget_ready():self._launch(self.tasks.popleft())

    def freshness(self,ref):
        value=self.fresh.get(ref)
        if not value:return 'Saved observation · not checked this session'
        age=max(0,int(self.clock()-value[0]));text='just now' if age<60 else f'{age//60} min ago'
        if ref in self.stale or self.blocked() or self.pipe_state!='live':return value[1]+' '+text+' · may be stale'
        return value[1]+' '+text

    def summary(self):
        self.sync_context()
        reason=self.blocked()
        if reason:return reason
        title={'live':'Live','connecting':'Connecting','reconnecting':'Reconnecting','unavailable':'Live unavailable · snapshots enabled','stopped':'Starting'}.get(self.pipe_state,'Starting')
        count=len(self.tasks)+bool(self.job)
        text=title+(' · '+str(count)+' snapshot page(s) queued' if count else ' · background checks enabled')
        client=self.app.api
        delay=max(0,int(client.next_metadata-client.clock()))
        if count and delay:text+=f' · shared request budget: {delay}s'
        if self.last_snapshot:text+=' · last snapshot '+self.last_snapshot
        if any(v['state'] in ('partial','retry later','unavailable') for v in self.coverage.values()):text+=' · coverage partial'
        if self.problem:text+=' · '+self.problem
        return text

    def forget_feed(self):
        self.sync_context()
        if not self.model:raise ValueError('Sign in and reveal account information first.')
        self.cancel();self.generation+=1
        self.store.forget_feed(self.model.account);self.model=FeedModel(self.store,self.model.account)
        self.fresh.clear();self.friend_versions.clear();self.friend_floor=0;self.sequence=0;self.next_cycle=0
        self.pipeline_context=None
        self.activity.reset()

    def close(self):self.closed=True;self.cancel()


def sync_for(shell):
    service=getattr(shell,'automatic_sync',None)
    if service is None:service=AutomaticSync(shell);shell.automatic_sync=service
    return service
