"""Native Client Bridge Lab. Forms prepare reviews; browsing never sends controls."""
from __future__ import annotations

from text_viewport import window_body
from pathlib import Path
import json
from companion_ui import Table, button, choice, entry, line
from bridge_lab_contract import ELIGIBLE_MODULES, RECOVERIES, BUILT_INS
from bridge_lab_peers import CATEGORIES, compare_cards
from bridge_lab_service import write_new_json
from developer_core import bounded_json

SECTIONS = ('Self-avatar', 'Parameters', 'Local isolation', 'Module isolation', 'Recovery',
            'Creator diagnostics', 'API/runtime comparison', 'Playtest comparison')
SCENARIOS = ('posture_transition', 'competing_writer', 'context_change', 'disconnect', 'lost_ack', 'recovery_unhealthy')


class ClientLabPanel:
    def __init__(self, page, parent):
        self.page, self.app, self.parent = page, page.app, parent
        self.service = page.service.bridge_lab
        self.tk, self.ttk = page.tk, page.ttk
        self.windows = []; self.boxes = {}; self.tables = {}; self.last_context = None
        self.report = None; self.card = None; self.last_preview = None
        self.header = self.tk.StringVar(); self.arm_var = self.tk.BooleanVar(value=False)
        page.heading(parent, 'Client Bridge Lab — Unsupported & Experimental')
        page.note(parent, 'Inspect your own avatar and explicitly exposed integration state. Sandbox is synthetic and isolated; Live requires a compatible voluntary provider. No modified client or VRChat instrumentation is included.')
        page.note(parent, self.header)
        row = line(page,parent)
        button(page,row,'Bridge settings',lambda:page.open_index('network:Client Bridge'))
        self.ttk.Checkbutton(row,text='Arm live lab controls',variable=self.arm_var,command=lambda:page.guard(self.change_arm)).pack(side='left',padx=8)
        button(page,row,'Stop / restore',self.stop)
        row = line(page,parent)
        button(page,row,'Capabilities & context',self.inspect_capabilities)
        button(page,row,'Experiment ledger',self.ledger)
        button(page,row,'Preview report',self.preview_report)
        row=line(page,parent)
        button(page,row,'Export reviewed report…',self.export_report)
        button(page,row,'Import report into Replay…',self.import_replay)
        row = line(page,parent)
        self.section = self.tk.StringVar(value=SECTIONS[0])
        choice(page,row,self.section,SECTIONS,lambda:self.show(self.section.get()),width=28)
        button(page,row,'Refresh observations',self.tick)
        self.holder = self.ttk.Frame(parent); self.holder.pack(fill='both',expand=True)
        self.panes = {name:self.ttk.Frame(self.holder) for name in SECTIONS}
        self.build_self(); self.build_parameters(); self.build_presentation(); self.build_modules()
        self.build_recovery(); self.build_creator(); self.build_consistency(); self.build_playtest()
        page.heading(parent,'Offline contract scenarios')
        page.note(parent,'These controls affect the isolated Sandbox fixture only. Lost acknowledgement applies to the next request. Reset returns to a fresh synthetic connection; it does not reconnect a live provider.')
        row=line(page,parent); self.scenario=self.tk.StringVar(value=SCENARIOS[0])
        choice(page,row,self.scenario,SCENARIOS,width=24)
        button(page,row,'Inject in Sandbox',self.inject)
        button(page,row,'Reset Sandbox',self.reset)
        self.show(SECTIONS[0])

    def show(self,name):
        if name not in self.panes:return False
        for frame in self.panes.values():frame.pack_forget()
        self.panes[name].pack(fill='both',expand=True);self.section.set(name);self.tick();return True

    def table(self,name,columns,height=5,select=None):
        table=Table(self.page,self.panes[name],columns,height=height,select=select)
        self.tables[name]=table;return table

    def box(self,name,height=12):
        box=self.page.text_box(self.panes[name],height=height)
        self.boxes[name]=box;return box

    def output(self,title,value,height=22):
        """Render supplied data as text, never scripts/HTML. No export side effect."""
        window=self.tk.Toplevel(self.app.root);window.title('VRC Eye · '+title)
        window.geometry('950x740');window.minsize(620,440);window.configure(bg=self.app.BG)
        parent=self.ttk.Frame(window_body(window),padding=16);parent.pack(fill='both',expand=True)
        self.page.heading(parent,title)
        box=self.page.text_box(parent,height=height);self.page.put(box,value)
        button(self.page,line(self.page,parent),'Close',window.destroy)
        self.windows.append(window)
        return window,parent

    def prepare(self,capability,options):
        preview=self.service.prepare(capability,options)
        self.last_preview=preview
        self._context_changed()
        window,parent=self.output('Review exact experiment',preview,20)
        self.page.note(parent,'This review expires after 30 seconds and is bound to the current connection, account, avatar/world, configuration and permissions. No operation has been sent.')
        button(self.page,line(self.page,parent),'Confirm & dispatch this experiment',lambda:self.execute_preview(preview,window))
        self.page.status.set('Experiment prepared, not sent. Inspect its target, side effects and restoration conditions.')
        return preview

    def execute_preview(self,preview,window=None):
        if not self.page.confirm('Dispatch this exact experiment?',
            preview['risk']+'\n\n'+'\n'.join(preview['effects'])+'\n\n'+preview['restoration']):return None
        result=self.service.execute(preview['token'])
        if window is not None and window.winfo_exists():window.destroy()
        self.page.status.set('Experiment queued. Acknowledgement and observed completion are separate; inspect the ledger.')
        self.tick();return result

    def change_arm(self):
        try:
            value=bool(self.arm_var.get())
            if value and not self.page.confirm('Arm experimental live lab controls?',
                'Only explicitly reviewed, approved capabilities can run. Provider claims are not verified compatibility. Own-avatar effects may synchronize or persist, and creator controls may change shared test state. API and OSC permissions are unchanged. Continue?'):return
            self.service.arm(value)
        finally:self.arm_var.set(self.service.armed);self.tick()

    def stop(self):
        self.service.stop_all();self.tick()
        self.page.status.set('Stopped pending experiments. Restoration is attempted only with fresh matching state; check the ledger for confirmed or unknown outcomes.')

    def build_self(self):
        pane=self.panes['Self-avatar'];self.page.heading(pane,'Self-avatar state timeline')
        self.self_summary=self.tk.StringVar();self.page.note(pane,self.self_summary)
        self.page.note(pane,'Initialization, posture and tracking are provider observations, not a diagnosis. Upright, TrackingType, VRMode and InStation are observation-only.')
        self.table('Self-avatar',(('time','Elapsed ms',100),('event','Event',170),('phase','Phase',110),('upright','Upright',75),('tracking','Tracking',80),('source','Evidence',220)),height=8)
        button(self.page,line(self.page,pane),'Inspect complete timeline',lambda:self.output('Self-avatar evidence',self.service.view('Self-avatar')))

    def build_parameters(self):
        pane=self.panes['Parameters'];self.page.heading(pane,'Parameter write tracing')
        self.page.note(pane,'Select a fresh custom parameter or enter its exact name. JSON values are true/false, an integer, or a decimal. Built-ins remain read-only regardless of provider advertising; unknown writers remain unknown.')
        self.table('Parameters',(('name','Parameter',165),('value','Observed',90),('type','Type',65),('write','Write',75),('sync','Sync',75),('save','Saved',75),('writer','Writer',140)),height=4,select=self.select_parameter)
        row=line(self.page,pane);self.param_name=self.tk.StringVar();self.param_value=self.tk.StringVar(value='true');self.param_duration=self.tk.StringVar(value='5')
        self.ttk.Label(row,text='Name').pack(side='left',padx=4);entry(self.page,row,self.param_name,width=24)
        self.ttk.Label(row,text='Value').pack(side='left',padx=4);entry(self.page,row,self.param_value,width=12)
        row=line(self.page,pane)
        self.ttk.Label(row,text='Hold seconds').pack(side='left',padx=4);entry(self.page,row,self.param_duration,width=5)
        row=line(self.page,pane);button(self.page,row,'Prepare parameter test',self.prepare_parameter)
        button(self.page,row,'Inspect write attribution',lambda:self.output('Requested / dispatched / observed',self.service.view('Parameters')))
        button(self.page,line(self.page,pane),'Existing OSC inspector',lambda:self.page.open_index('osc:Inspector'))
        self.page.note(pane,'The test sets one bounded value, observes it, then attempts compare-and-restore. It never overwrites a later revision to force a preset. No OSC route is granted or used by these bridge controls.')
        self.box('Parameters',height=8)

    def select_parameter(self):
        row=self.tables['Parameters'].selected()
        if row:self.param_name.set(row['name']);self.param_value.set(json.dumps(row['value']))

    def prepare_parameter(self):
        return self.prepare('lab.parameter_set',dict(name=self.param_name.get().strip(),value=bounded_json(self.param_value.get()),duration_seconds=int(self.param_duration.get())))

    def build_presentation(self):
        pane=self.panes['Local isolation'];self.page.heading(pane,'Local rendering & audio isolation')
        self.page.note(pane,'Baseline → one exposure reduction → observation → compare-and-restore. Targets are only those the provider explicitly supplies for these controls. No reveal, unhide, see-through, or protection-disabling action is provided.')
        self.table('Local isolation',(('target','Reported target',270),('hidden','Hidden',90),('audio','Audio suppressed',130),('effects','Effects',100),('rev','Revision',80)),height=4,select=self.select_target)
        row=line(self.page,pane);self.target=self.tk.StringVar();self.effect=self.tk.StringVar(value='hide');self.effect_duration=self.tk.StringVar(value='5')
        entry(self.page,row,self.target,width=43)
        row=line(self.page,pane);choice(self.page,row,self.effect,('hide','suppress_audio','reduce_effects','minimal_effects'),width=19)
        self.ttk.Label(row,text='Seconds').pack(side='left',padx=4);entry(self.page,row,self.effect_duration,width=5)
        button(self.page,line(self.page,pane),'Prepare local reduction',lambda:self.prepare('lab.presentation_reduce',dict(target_user_id=self.target.get().strip(),mode=self.effect.get(),duration_seconds=int(self.effect_duration.get()))))
        self.box('Local isolation',height=10)

    def select_target(self):
        row=self.tables['Local isolation'].selected()
        if row:self.target.set(row['target_user_id'])

    def build_modules(self):
        pane=self.panes['Module isolation'];self.page.heading(pane,'Integration-module conflict isolation')
        self.page.note(pane,'Compare one integration-owned diagnostic, overlay or input-routing module. Security, authentication, privacy and enforcement components are not eligible, even when advertised as pausable.')
        self.table('Module isolation',(('id','Module',170),('kind','Category',130),('version','Version',90),('revision','Config',65),('state','Eligibility',250)),height=4,select=self.select_module)
        row=line(self.page,pane);self.module=self.tk.StringVar();self.module_duration=self.tk.StringVar(value='5')
        self.ttk.Label(row,text='Module').pack(side='left',padx=4);entry(self.page,row,self.module,width=34)
        row=line(self.page,pane)
        self.ttk.Label(row,text='Seconds').pack(side='left',padx=4);entry(self.page,row,self.module_duration,width=5)
        button(self.page,row,'Prepare pause',lambda:self.prepare('lab.module_pause',dict(module_id=self.module.get().strip(),duration_seconds=int(self.module_duration.get()))))
        self.box('Module isolation',height=10)

    def select_module(self):
        row=self.tables['Module isolation'].selected()
        if row:self.module.set(row['id'])

    def build_recovery(self):
        pane=self.panes['Recovery'];self.page.heading(pane,'Targeted integration recovery')
        self.page.note(pane,'Requested → acknowledged → fresh correlated telemetry → healthy report. The provider must identify the exact owned channel; this cannot reload an avatar, change the microphone, reset safety, or leave an instance.')
        row=line(self.page,pane);self.recovery=self.tk.StringVar(value='telemetry.rebuild');self.channel=self.tk.StringVar(value='diagnostics')
        choice(self.page,row,self.recovery,tuple(RECOVERIES),width=25);entry(self.page,row,self.channel,width=24)
        button(self.page,line(self.page,pane),'Prepare recovery',lambda:self.prepare('lab.recover',dict(operation=self.recovery.get(),channel=self.channel.get().strip())))
        self.box('Recovery',height=17)

    def build_creator(self):
        pane=self.panes['Creator diagnostics'];self.page.heading(pane,'Creator-exposed diagnostics & controls')
        self.page.note(pane,'Inspect the manifest, its specific effect and current playtest authority. World authorship alone is not authorization. Persistent/destructive/unknown-scope controls are not executable through this adapter.')
        row=line(self.page,pane);button(self.page,row,'Review current manifest & authority',self.review_creator)
        row=line(self.page,pane);self.creator_control=self.tk.StringVar();entry(self.page,row,self.creator_control,width=29)
        button(self.page,row,'Prepare named control',lambda:self.prepare('lab.creator_action',dict(control_id=self.creator_control.get().strip())))
        self.box('Creator diagnostics',height=18)

    def review_creator(self):
        current=self.service.view('Creator diagnostics');self.output('Creator manifest & authority evidence',current)
        if not self.page.confirm('Review this creator manifest?',
            'Review the manifest shown in the inspection window, including exact control effects and reported session authority. This local review does not prove that the provider has server-side authority. Continue for this context only?'):return
        result=self.service.review_manifest();self.page.status.set(result['status']);self.tick();return result

    def build_consistency(self):
        pane=self.panes['API/runtime comparison'];self.page.heading(pane,'API versus runtime evidence')
        self.page.note(pane,'Compare an existing account.get response with the current provider and available OSC context. Reading an avatar record does not prove that it is selected. No discrepancy triggers a corrective write or repeated selection request.')
        row=line(self.page,pane);button(self.page,row,'Open API Workbench',lambda:self.page.open_index('developer:API Workbench'))
        button(self.page,row,'Compare captured evidence',self.tick)
        self.box('API/runtime comparison',height=20)

    def build_playtest(self):
        pane=self.panes['Playtest comparison'];self.page.heading(pane,'Cooperative playtest comparison')
        self.page.note(pane,'Each participant deliberately joins the same test and chooses categories. Live sharing uses the existing Eye-to-Eye permission and acceptance workflow. Use an already shared Creator playtest ID or the selected peer’s current session ID; a new local test does not establish a network context.')
        row=line(self.page,pane);self.test_id=self.tk.StringVar();entry(self.page,row,self.test_id,width=42)
        row=line(self.page,pane);button(self.page,row,'Start / join test',self.start_test)
        button(self.page,row,'Existing Creator playtests',lambda:self.page.open_index('peer:Creator'))
        row=line(self.page,pane);self.categories={c:self.tk.BooleanVar(value=False) for c in CATEGORIES}
        for c,v in self.categories.items():self.ttk.Checkbutton(row,text=c.replace('_',' '),variable=v).pack(side='left',padx=7)
        row=line(self.page,pane);self.milestone=self.tk.StringVar(value='round_started');self.alignment=self.tk.StringVar(value='local_start');self.uncertainty=self.tk.StringVar(value='')
        entry(self.page,row,self.milestone,width=23);choice(self.page,row,self.alignment,('local_start','participant_shared_cue'),width=25)
        row=line(self.page,pane)
        self.ttk.Label(row,text='Uncertainty ±ms').pack(side='left',padx=4);entry(self.page,row,self.uncertainty,width=8)
        self.page.note(pane,'Shared-cue alignment is a participant assumption, not measured clock synchronization. Join/start at the deliberately shared cue and include your start-alignment error in the bound. Independent local starts cannot establish which client observed an event first.')
        row=line(self.page,pane);button(self.page,row,'Preview selected card',self.preview_card)
        button(self.page,row,'Add preview to comparison',self.add_preview)
        row=line(self.page,pane);button(self.page,row,'Export preview…',self.export_card)
        button(self.page,row,'Import card…',self.import_card)
        row=line(self.page,pane);self.peer=self.tk.StringVar();self.peer_picker=choice(self.page,row,self.peer,(),width=40)
        row=line(self.page,pane);button(self.page,row,'Send reviewed card',self.send_card)
        button(self.page,row,'Load accepted cards',self.load_accepted)
        button(self.page,line(self.page,pane),'Use selected peer session as test ID',self.join_peer_session)
        self.box('Playtest comparison',height=10)

    def start_test(self):
        result=self.service.start_test(self.test_id.get().strip() or None);self.test_id.set(result['test_id'])
        self.card=None;self.page.status.set('Joined local test context. No peer message or provider control was sent.');self.tick();return result

    def preview_card(self):
        uncertainty=None if not self.uncertainty.get().strip() else float(self.uncertainty.get())
        self.card=self.service.make_card(self.milestone.get().strip(),[c for c,v in self.categories.items() if v.get()],alignment=self.alignment.get(),uncertainty_ms=uncertainty)
        self.output('Preview exact opt-in observation card',self.card);return self.card

    def _card(self):
        if self.card is None:raise ValueError('Prepare and inspect an observation card first.')
        if not self.service.test or self.card['test_id']!=self.service.test['id']:raise ValueError('The reviewed card belongs to a previous test.')
        return self.card

    def add_preview(self):
        self.service.add_card(self._card());self.tick()

    def export_card(self):
        from tkinter import filedialog
        card=self._card()
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Save reviewed observation card as a new file',defaultextension='.json',initialfile='vrc-eye-playtest-card.json')
        if path:write_new_json(path,card);self.page.status.set('Only the reviewed categories were exported; no identities or private instance codes.')

    def import_card(self):
        raw=self.read_file('Import a deliberately shared observation card')
        if raw is not None:self.service.add_card(bounded_json(raw));self.tick()

    def send_card(self):
        card=self._card();peer_id=self.peer_map.get(self.peer.get())
        if not peer_id:raise ValueError('Choose an existing authenticated peer. This page does not connect a peer.')
        if not self.page.confirm('Send this reviewed diagnostic card?',
            'Send the exact preview to '+self.peer.get()+' through the current Eye-to-Eye connection? Only the selected categories are shared. The recipient must separately accept it.'):return
        self.service.send_card(peer_id,card);self.page.status.set('Reviewed card sent through Eye-to-Eye; recipient acceptance is separate.')

    def join_peer_session(self):
        peer_id=self.peer_map.get(self.peer.get())
        if not peer_id:raise ValueError('Choose a current authenticated Eye-to-Eye peer first.')
        row=next((p for p in self.app.peer_service.snapshot().get('peers',[]) if p['peer_id']==peer_id and p.get('state')=='READY'),None)
        if row is None:raise ValueError('That peer is no longer connected.')
        self.test_id.set(row['session']);return self.start_test()

    def load_accepted(self):
        count=0
        for row in self.service.received_cards():self.service.add_card(row['payload']);count+=1
        self.tick();self.page.status.set(f'Loaded {count} accepted card(s) from the current test. Pending peer requests are not silently accepted.')

    def read_file(self,title):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,title=title,filetypes=[('JSON','*.json')])
        if not path:return None
        with open(Path(path),'rb') as stream:raw=stream.read(256*1024+1)
        if len(raw)>256*1024:raise ValueError('The data file exceeds the local 256 KiB limit.')
        try:return raw.decode('utf-8-sig')
        except UnicodeError as error:raise ValueError('Choose a UTF-8 JSON data file.') from error

    def inspect_capabilities(self):self.output('Reviewed capability contracts & current context',self.service.snapshot())
    def ledger(self):self.output('Experiment lifecycle & restoration outcomes',self.service.snapshot()['experiments'])
    def preview_report(self):
        self.report=self.service.report_preview();self.output('Sanitized report preview',self.report);return self.report
    def export_report(self):
        from tkinter import filedialog
        if self.report is None:raise ValueError('Generate and inspect the sanitized report preview first.')
        path=filedialog.asksaveasfilename(parent=self.app.root,title='Save the reviewed report as a new file',defaultextension='.json',initialfile='vrc-eye-client-lab-report.json')
        if path:write_new_json(path,self.report);self.page.status.set('The reviewed sanitized report was saved; existing files are never silently overwritten.')
    def import_replay(self):
        if self.service.environment!='Replay':raise ValueError('Select Replay in the Developer environment before importing a report.')
        raw=self.read_file('Open a sanitized Client Lab report')
        if raw is not None:self.service.load_replay(raw);self.tick()
    def inject(self):self.service.inject(self.scenario.get());self.tick()
    def reset(self):self.service.reset_sandbox();self.clear();self.tick()

    def clear(self):
        self.report=None;self.card=None;self.last_preview=None
        for window in self.windows:
            try:
                if window.winfo_exists():window.destroy()
            except self.tk.TclError:pass
        self.windows.clear()
        for box in self.boxes.values():self.page.put(box,{'state':'Previous context cleared.'})
        for table in self.tables.values():table.set([],lambda r:())
        for attr in ('param_name','target','module','creator_control','test_id','peer'):
            if hasattr(self,attr):getattr(self,attr).set('')
        self.arm_var.set(False)

    def _context_changed(self):
        key=(self.service.environment,self.page.service.generation,self.service.signature)
        if self.last_context is not None and key!=self.last_context:self.clear()
        self.last_context=key

    def tick(self):
        self.service.tick();self._context_changed();snap=self.service.snapshot()
        self.arm_var.set(snap['armed'])
        provider=(snap['provider'] or {}).get('name','No compatible provider')
        context=snap['context'];scope=('context '+str(context['revision'])+' · account …'+context['account_id'][-8:]) if context else 'No fresh approved context'
        available=sum(v['available'] for v in snap['channels'].values())
        experiment=next((r for r in reversed(snap['experiments']) if not r['finished']),None)
        outcome=experiment['status'] if experiment else snap['experiments'][-1]['status'] if snap['experiments'] else 'No experiment running'
        self.header.set(f"{snap['environment']} · {provider}\n{scope} · {available}/13 named capabilities available · Live compatibility unverified\n{outcome} · Live lab controls {'ARMED' if snap['armed'] else 'disarmed'}")
        name=self.section.get()
        if name=='API/runtime comparison':self.page.put(self.boxes[name],self.service.consistency());return
        if name=='Playtest comparison':
            self.peer_map={}
            peers=getattr(self.app,'peer_service',None)
            if peers and self.service.environment=='Live':
                for peer in peers.snapshot().get('peers',[]):
                    if peer.get('state')=='READY':
                        label=(peer.get('label') or peer.get('name') or 'Peer')+' · '+peer['peer_id'][-8:]
                        self.peer_map[label]=peer['peer_id']
            self.peer_picker.configure(values=tuple(self.peer_map))
            if self.peer.get() not in self.peer_map:self.peer.set('')
            self.page.put(self.boxes[name],dict(test=self.service.test,comparison=compare_cards(list(self.service.peer_cards.values())),accepted_cards_available=len(self.service.received_cards())))
            return
        data=self.service.view(name);sample=(data.get('sample') or {}).get('value',{})
        if name=='Self-avatar':
            self.self_summary.set('Phase: '+str(sample.get('phase','unavailable'))+' · Capture overhead reported by provider: '+str(snap['provider_capture_cost_ms'])+' ms · Dropped timeline records: '+str(snap['dropped']['timeline']))
            self.tables[name].set(data.get('timeline',[]),lambda r:(r['elapsed_ms'],r['event'],r['phase'],r.get('upright','—'),r.get('tracking_type','—'),r['provider']))
        elif name=='Parameters':
            rows=sample.get('parameters',[])
            self.tables[name].set(rows,lambda r:(r['name'],json.dumps(r['value']),r['type'],'yes' if r['writable'] and r['name'] not in BUILT_INS else 'read-only',r['synced'],r['saved'],r.get('writer','source unknown')))
            self.page.put(self.boxes[name],{'state':data.get('state'),'recent_observations':data.get('trace',[])[-12:],'experiments':data.get('experiments',[])[-2:]})
        elif name=='Local isolation':
            self.tables[name].set(sample.get('targets',[]),lambda r:(r['target_user_id'],r['avatar_hidden'],r['audio_suppressed'],r['effects'],r['revision']))
            self.page.put(self.boxes[name],{'metrics':data.get('metrics'),'experiments':data.get('experiments',[])[-2:],'interpretation':'Single-sample correlation, not a causal conclusion or accusation.'})
        elif name=='Module isolation':
            self.tables[name].set(sample.get('modules',[]),lambda r:(r['id'],r['kind'],r['version'],r['config_revision'],'eligible' if r['kind'] in ELIGIBLE_MODULES and r['can_pause'] and not r['paused'] else 'protected / unavailable / paused'))
            self.page.put(self.boxes[name],{'metrics':data.get('metrics'),'experiments':data.get('experiments',[])[-2:]})
        else:self.page.put(self.boxes[name],data)
        if self.service.environment=='Replay':
            if name in self.boxes:self.page.put(self.boxes[name],data)
            elif name=='Self-avatar':self.self_summary.set('Replay is report inspection only. No provider or action executor is present; open a data inspection view to read the report.')

    def close(self):self.clear()
