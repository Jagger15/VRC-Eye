"""Bounded, read-only source-primitive diagnostics; no guessed mesh repairs."""
from collections import Counter
import math

FIELDS = ('source_vertices', 'source_triangles', 'unused_vertices', 'degenerate_triangles',
          'duplicate_triangles', 'boundary_edges', 'nonmanifold_edges', 'winding_edges',
          'normals_present', 'zero_normals', 'nonunit_normals', 'tangents_present',
          'invalid_tangents', 'nonorthogonal_tangents', 'uvs_present', 'degenerate_uv_triangles')
LEGACY_FIELDS = FIELDS
FIELDS += ('surface_components', 'nonmanifold_vertices', 'disconnected_vertex_fans')


def topology(triangles):
    """Inspect the index complex of unique, nondegenerate faces in linear space.

    Each manifold vertex has a single fan whose edges meet at most two faces.
    Disconnected fans catch bow-tie vertices even when every edge is manifold.
    Components share source indices; coincident seams are deliberately not welded.
    """
    incident = {}; edges = {}; parents = {}
    def root(v):
        while parents[v] != v:
            parents[v] = parents[parents[v]]; v = parents[v]
        return v
    for i, tri in enumerate(triangles):
        for v in tri:
            incident.setdefault(v, []).append(i); parents.setdefault(v, v)
        a = root(tri[0])
        for v in tri[1:]:parents[root(v)] = a
        for a, b in zip(tri, tri[1:]+tri[:1]):
            edges.setdefault(tuple(sorted((a, b))), []).append(i)
    bad = disconnected = 0
    for v, faces in incident.items():
        groups = {i:i for i in faces}; branching = False
        def fan(i):
            while groups[i] != i:
                groups[i] = groups[groups[i]]; i = groups[i]
            return i
        for i in faces:
            for neighbor in triangles[i]:
                if neighbor == v:continue
                linked = edges[tuple(sorted((v, neighbor)))]
                branching |= len(linked) > 2
                groups[fan(i)] = fan(linked[0])
        separate = len({fan(i) for i in faces}) > 1
        disconnected += separate
        bad += branching or separate
    return len({root(v) for v in parents}), bad, disconnected


def analyze(vertices, triangles, *, normals=(), tangents=(), uvs=()):
    """Counts use source indices and source-space geometry, before display remapping.

    Index seams can create boundary edges; an open surface is not automatically
    broken. Topology uses unique nondegenerate faces without welding seams.
    This does not test self-intersections or shader behavior.
    """
    out = dict.fromkeys(FIELDS, 0)
    out.update(source_vertices=len(vertices), source_triangles=len(triangles),
               normals_present=int(bool(normals)), tangents_present=int(bool(tangents)),
               uvs_present=int(bool(uvs)))
    used=set(); faces=Counter(); edges=Counter(); directions=Counter(); valid=[]; unique=set()
    def dot(a,b): return sum(x*y for x,y in zip(a,b))
    for tri in triangles:
        used.update(tri); faces[tuple(sorted(tri))]+=1
        a,b,c=(vertices[i] for i in tri)
        ab=tuple(b[k]-a[k] for k in range(3));ac=tuple(c[k]-a[k] for k in range(3))
        cross=(ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0])
        if len(set(tri))<3 or dot(cross,cross)<=1e-20*max(dot(ab,ab),dot(ac,ac))**2:
            out['degenerate_triangles']+=1
        else:
            key=tuple(sorted(tri))
            if key not in unique:valid.append(tri);unique.add(key)
            for x,y in zip(tri,tri[1:]+tri[:1]):
                key=tuple(sorted((x,y)));edges[key]+=1;directions[key]+=1 if x<y else -1
        if uvs:
            x,y,z=(uvs[i] for i in tri)
            if abs((y[0]-x[0])*(z[1]-x[1])-(y[1]-x[1])*(z[0]-x[0]))<=1e-12:
                out['degenerate_uv_triangles']+=1
    out['unused_vertices']=len(vertices)-len(used)
    out['duplicate_triangles']=sum(n-1 for n in faces.values())
    out['boundary_edges']=sum(n==1 for n in edges.values())
    out['nonmanifold_edges']=sum(n>2 for n in edges.values())
    out['winding_edges']=sum(n==2 and abs(directions[key])==2 for key,n in edges.items())
    out['surface_components'],out['nonmanifold_vertices'],out['disconnected_vertex_fans']=topology(valid)
    for n in normals:
        length=math.sqrt(dot(n,n))
        out['zero_normals']+=length<=1e-12
        out['nonunit_normals']+=abs(length-1)>1e-3
    for i,t in enumerate(tangents):
        length=math.sqrt(dot(t[:3],t[:3]))
        out['invalid_tangents']+=abs(length-1)>1e-3 or t[3] not in (-1.,1.)
        if normals:
            n=normals[i];nl=math.sqrt(dot(n,n))
            out['nonorthogonal_tangents']+=bool(length>1e-12 and nl>1e-12 and abs(dot(n,t[:3]))/(length*nl)>1e-3)
    return tuple((key,int(out[key])) for key in FIELDS)


def decode(raw):
    if not isinstance(raw,list) or len(raw) not in (len(LEGACY_FIELDS),len(FIELDS)): raise ValueError('Invalid mesh health result.')
    result=[]
    for row,key in zip(raw,FIELDS):
        if not isinstance(row,list) or len(row)!=2 or row[0]!=key or type(row[1]) is not int or not 0<=row[1]<=300000:
            raise ValueError('Invalid mesh health count.')
        if key.endswith('_present') and row[1] not in (0,1): raise ValueError('Invalid mesh stream coverage.')
        result.append(tuple(row))
    return tuple(result)


def describe(part):
    h=dict(part.health)
    if not h:return 'No source mesh diagnostics from this provider.'
    lines=['Source-primitive diagnostics; counts precede preview remapping.']
    lines.extend(key.replace('_',' ').capitalize()+': '+str(value) for key,value in h.items())
    lines += ['','Boundary edges may be intentional openings or split UV/normal seams.',
              'Vertex fans and surface components use unique nondegenerate faces within this primitive. Coincident vertices are not welded; separate primitives are not joined.',
              'Missing normals/tangents can be generated by an importer; they are not proof of a broken avatar.',
              'No self-intersection, deformation, Unity shader or runtime-performance verdict.']
    return '\n'.join(lines)
