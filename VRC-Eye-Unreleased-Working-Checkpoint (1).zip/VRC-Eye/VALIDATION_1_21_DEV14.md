# VRC Eye 1.21.0 — Development 14 validation

The final frozen-source portable regression passed **4,779 tests and 1,059
subtests**, with **zero failures/errors** and **zero blocked external-socket attempts**,
in 132.63 seconds. No runtime, test, launcher or dependency bytes changed
after this run. The archive is verified byte-for-byte against that source.

**475 native GUI cases remain skipped**, **1 Unix bridge case is deselected**,
and the same **13 local-transport modules** are excluded as Development 13. Exclusions
and skips are not passes. The 2 existing warnings concern a test-listener
constructor and a deliberately duplicated archive member.

All **565 Python files** parse with the Python 3.10 grammar. The source
manifest covers **610 runtime/test/launcher/requirements/Unity files**.
All **735 Development 13 archive paths** remain present. Launchers and
requirements are unchanged. Package creation checks every archived source byte
and the archive CRCs.

The **54 new cases** exercise transfer completion, restart/resume, exact byte ranges,
strong validators, initial/redirect resource identity, signed URL redaction, bad
ranges/HTTP 200 rejection, changed partials, account/cancellation boundaries, retry
caps and Retry-After, permanent failures, publication crash reconciliation, no-overwrite
publication, partial limits and discard, common notes ownership, alias/legacy conflicts,
stale editors, source changes, clear semantics, tag colors, rollback on failed commit,
account guards, note-marker persistence, typed dashboard sorting/filtering, settings
round-trip, stable selection/private clearing, and actual headless transfer workflows.

Native Tk visual/keyboard/accessibility acceptance remains unverified because the
execution environment has no display. The prior Xvfb/local-socket restriction was
retained; no new Xvfb or approval escalation attempt was made. Native Windows file
locks/publication, live VRChat/CDN range behavior, protected credential storage,
Unity, SteamVR, audio hardware, tray, Discord and installer acceptance remain open.
Headless widgets and fake HTTP/provider fixtures do not certify those environments.

This is a **runnable Windows/Linux Python source ZIP**, not a compiled executable
or signed installer. No user-uploaded mod or recovery binary was executed, no live
VRChat action was sent, and no update was published. BUILD_VALIDATION.json contains
the complete command and exclusions. ARC_VRCX_REMAINING_DEV14.md documents the
remaining scope, including general provider/transfer integration and richer ARC tools.
