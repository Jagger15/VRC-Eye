"""The existing Favorites/VRCX workspaces' migration and data-management dialog."""

from text_viewport import window_body
import json
from datetime import datetime, timezone
from tkinter import filedialog, simpledialog
from companion_ui import Table, line, button, choice, entry, note
from vrcx_ui_jobs import LocalPage
import native_migration as migration


def show(shell):
    current=getattr(shell,'native_data_dialog',None)
    if current and not current.closed:current.window.lift();return current
    current=NativeDataDialog(shell);shell.native_data_dialog=current;return current


class NativeDataDialog(LocalPage):
    def __init__(self,shell):
        app=shell.app;self.window=app.tk.Toplevel(app.root)
        self.window.title('VRC Eye data — migrate, back up and manage history')
        self.window.geometry('1100x840');self.window.minsize(760,600);self.window.transient(app.root)
        from friendly_ui import ScrollPane
        self.viewport=ScrollPane(app,self.window,min_width=1040);frame=self.viewport.body
        super().__init__(shell,frame,'VRC Eye data')
        self.library=shell.store.native;self.inventory=None;self.preview=None;self.review_form=None;self.conflict_window=None
        self.categories={};self.mapping={};self.batch_rows=[];self.offset=0
        self.workspace=self.tk.StringVar(value='Shared local library');self.policy=self.tk.StringVar(value='keep')
        self.lineage=self.tk.StringVar(value='My VRCX library');self.after=self.tk.StringVar();self.before=self.tk.StringVar()
        self.private_fields=self.tk.BooleanVar(value=False);self.relationships=self.tk.BooleanVar(value=False)
        self.record_kind=self.tk.StringVar(value='event');self.query=self.tk.StringVar()
        self.setup_privacy()
        row=line(self);choice(self,row,self.workspace,('Shared local library','Current account'),self.invalidate,25)
        note(self,'VRCX is an optional import source. Collections, notes, tags and history live in VRC Eye after import. '
             'Select a closed, consistent VRCX database. Credentials are never imported. Global source data goes to the chosen workspace; map account histories explicitly below.')
        tabs=self.ttk.Notebook(frame);tabs.pack(fill='both',expand=True)
        imports=self.ttk.Frame(tabs,padding=8);data=self.ttk.Frame(tabs,padding=8);history=self.ttk.Frame(tabs,padding=8)
        tabs.add(imports,text='VRCX import');tabs.add(data,text='Backup and recovery');tabs.add(history,text='Local history and records')
        self.tabs=tabs;self.history_frame=history;self.browse_revision=None;self.browse_signature=None
        row=line(self,imports);button(self,row,'Choose VRCX database…',self.choose_source)
        button(self,row,'Capture live VRCX snapshot…',self.capture_source)
        button(self,row,'Bring earlier Eye imports into native views…',self.legacy)
        self.source_note=self.tk.StringVar(value='Choose VRCX.sqlite3 or metadataCache.db to inventory its supported tables.')
        self.ttk.Label(imports,textvariable=self.source_note,wraplength=980).pack(anchor='w',pady=5)
        self.category_frame=self.ttk.LabelFrame(imports,text='Selected categories',padding=6);self.category_frame.pack(fill='x')
        self.mapping_frame=self.ttk.LabelFrame(imports,text='Source account → destination workspace',padding=6);self.mapping_frame.pack(fill='x',pady=6)
        row=line(self,imports);self.ttk.Label(row,text='Source library label').pack(side='left');entry(self,row,self.lineage,25)
        self.ttk.Label(row,text='On conflict').pack(side='left');choice(self,row,self.policy,('keep','fill','replace','merge'),width=12)
        row=line(self,imports);self.ttk.Label(row,text='History dates (ISO), after / before').pack(side='left');entry(self,row,self.after,18);entry(self,row,self.before,18)
        row=line(self,imports)
        self.ttk.Checkbutton(row,text='Include private message / biography text',variable=self.private_fields).pack(side='left')
        self.ttk.Checkbutton(row,text='Include relationship / moderation observations',variable=self.relationships).pack(side='left')
        row=line(self,imports);button(self,row,'Prepare review',self.prepare)
        button(self,row,'Choose conflicting fields…',lambda:__import__('native_conflict_ui').show(self))
        button(self,row,'Commit reviewed import…',self.commit)
        self.summary=self.tk.StringVar(value='No import prepared.')
        self.ttk.Label(imports,textvariable=self.summary,wraplength=980).pack(anchor='w',pady=8)
        row=line(self,data);button(self,row,'Back up selected workspace…',lambda:self.backup(False));button(self,row,'Back up every workspace…',lambda:self.backup(True))
        button(self,row,'Review native backup restore…',self.restore)
        row=line(self,data);button(self,row,'Back up desktop profile…',self.backup_profile);button(self,row,'Recover profile into new folder…',self.restore_profile)
        button(self,row,'Verify profile backup…',self.verify_profile)
        row=line(self,data);button(self,row,'Selective settings backup / undo…',lambda:__import__('settings_bundle_ui').show(self.shell))
        button(self,row,'Private tags and saved views…',lambda:__import__('shared_tags_ui').show(self.shell,account=self.target_scope()))
        note(self,'Profile bundles include the supported companion, player and creator stores, photo catalog and presentation settings. Recovery uses a new folder; sign-ins, automatic services and executable approvals are excluded. Original photos and Unity project files stay in their existing folders.')
        self.ttk.Label(data,text='Native JSONL backups preserve multi-collection membership, empty collections, annotations, provenance and deletion history. '
            'They contain private local data, but no login sessions. VRCX import previews support 10,000 records / 32 MiB; native backup restores stream up to 500,000 records / 256 MiB in one transaction.',wraplength=980).pack(anchor='w',pady=6)
        self.batch_table=Table(self,data,(('when','Time',170),('source','Source',300),('state','State',170),('summary','Result',300)),height=8)
        row=line(self,data);button(self,row,'Refresh migration / edit receipts',self.refresh_batches);button(self,row,'Roll back selected batch…',self.rollback)
        button(self,row,'Roll back selected records…',self.rollback_records)
        row=line(self,history);choice(self,row,self.record_kind,('All records','event','notification','relationship','aggregate','entity','annotation','preference','photo-reference','coverage','source','saved-search'),width=18)
        entry(self,row,self.query,28);button(self,row,'Refresh',lambda:self.browse(0));button(self,row,'Previous',lambda:self.browse(max(0,self.offset-100)));button(self,row,'Next',lambda:self.browse(self.offset+100))
        self.record_table=Table(self,history,(('type','Type',100),('time','Reported time',180),('id','Record',280),('value','Details',450)),height=12,select=self.detail)
        self.details=self.tk.StringVar(value='Imported notifications and relationships are historical observations. They cannot authorize an online action.')
        self.ttk.Label(history,textvariable=self.details,wraplength=980).pack(anchor='w',pady=5)
        row=line(self,history);button(self,row,'Forget selected record…',self.forget);button(self,row,'Retain history from a date…',self.retain)
        button(self,row,'Forget a user’s retained history…',self.forget_user_history)
        button(self,row,'Associate selected photo reference…',self.link_photo)
        button(self,line(self,history),'History & discovery…',lambda:__import__('social_history_ui').show(self.shell))
        button(self,line(self),'Close',self.close)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.timer=app.root.after(150,self.tick)
        for value in (self.lineage,self.policy,self.after,self.before,self.private_fields,self.relationships):
            value.trace_add('write',lambda *_:self.invalidate())

    def target_scope(self):
        if self.workspace.get()=='Shared local library':return 'shared'
        client=self.app.api
        if not client or not client.authenticated:raise ValueError('Connect an account or choose the shared workspace.')
        from companion_data import entity_id
        return entity_id('user',client.user_id)

    def capture_source(self):
        self.ready();token=self.token()
        source=filedialog.askopenfilename(parent=self.window,title='Choose the VRCX database to snapshot',filetypes=[('SQLite database','*.sqlite3 *.db')]);self.verify(token)
        if not source:return
        target=filedialog.asksaveasfilename(parent=self.window,title='Save a standalone snapshot',initialfile='VRCX-snapshot.sqlite3',defaultextension='.sqlite3');self.verify(token)
        if not target:return
        from native_snapshot import capture_checked
        self.start(lambda c,s,p:capture_checked(source,target,stop=s),lambda path:self.status.set('Snapshot saved. Choose this snapshot as the import source: '+path))

    def clear_preview(self):
        self.browse_revision=None;self.browse_signature=None
        if self.conflict_window and not self.conflict_window.closed:self.conflict_window.close()
        if self.preview:self.library.discard(self.preview.plan)
        self.preview=None;self.review_form=None
        for key in ('summary','details'):
            if hasattr(self,key):getattr(self,key).set('Review cleared. Refresh explicitly.')
        if hasattr(self,'record_table'):self.record_table.set([],lambda r:())
        if hasattr(self,'batch_table'):self.batch_table.set([],lambda r:())

    def invalidate(self):
        super().invalidate()
        if getattr(self,'private_value',False) or getattr(self.app,'_native_private',False) or self.context()!=self.account:
            self.clear_source()

    def clear_source(self):
        self.inventory=None;self.categories={};self.mapping={}
        self.source_note.set('Source details cleared. Choose and inventory the database again.')
        self.query.set('')
        for frame in (self.category_frame,self.mapping_frame):
            for child in frame.winfo_children():child.destroy()

    def account_changed(self):
        super().account_changed();self.clear_source()

    def form(self):
        return (self.target_scope(),self.lineage.get(),self.policy.get(),self.after.get(),self.before.get(),
                bool(self.private_fields.get()),bool(self.relationships.get()),
                tuple((k,v.get()) for k,v in self.categories.items()),tuple((k,v.get()) for k,v in self.mapping.items()))

    def choose_source(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,title='Select a closed VRCX database',filetypes=[('SQLite database','*.sqlite3 *.db'),('All files','*')])
        self.verify(token)
        if not path:return
        self.clear_preview()
        def done(inventory):
            self.inventory=inventory;self.categories={};self.mapping={}
            for frame in (self.category_frame,self.mapping_frame):
                for child in frame.winfo_children():child.destroy()
            categories=sorted({t.category for t in inventory.tables})
            for n,category in enumerate(categories):
                value=self.tk.BooleanVar(value=category in ('Favorite collections','Avatar metadata','World metadata','Memos and tags'))
                self.categories[category]=value
                value.trace_add('write',lambda *_:self.invalidate())
                count=sum(t.rows for t in inventory.tables if t.category==category)
                self.ttk.Checkbutton(self.category_frame,text=f'{category} ({count:,})',variable=value).grid(row=n//3,column=n%3,sticky='w',padx=8,pady=2)
            for account in sorted({t.account for t in inventory.tables if t.account!='shared'}):
                row=self.ttk.Frame(self.mapping_frame);row.pack(fill='x',pady=2)
                self.ttk.Label(row,text=account,width=44).pack(side='left')
                value=self.tk.StringVar(value='Exclude');self.mapping[account]=value
                value.trace_add('write',lambda *_:self.invalidate())
                choices=['Exclude','shared',account]
                current=getattr(self.app.api,'user_id','')
                if current and current not in choices:choices.append(current)
                choice(self,row,value,choices,width=44)
            self.source_note.set(f'{len(inventory.tables)} supported tables, {sum(t.rows for t in inventory.tables):,} rows. '+ '; '.join(inventory.warnings))
        self.start(lambda c,s,p:migration.inspect(path,s),done)

    def prepare(self):
        self.ready()
        if not self.inventory:raise ValueError('Choose and inventory the source first.')
        self.clear_preview()
        form=self.form();target,label,policy,after,before,private,relationships,categories,mapping=form
        # Exclusion is made at the table inventory level so an unselected account
        # never becomes an implicit association with the active login.
        from dataclasses import replace
        inventory=replace(self.inventory,tables=tuple(t for t in self.inventory.tables if t.account=='shared' or dict(mapping).get(t.account)!='Exclude'))
        chosen=[k for k,v in categories if v and any(t.category==k for t in inventory.tables)]
        def done(result):
            if form!=self.form():raise ValueError('Selections changed; prepare the import again.')
            self.preview=result;self.review_form=form
            report=result.report
            self.summary.set(f"{report['source_rows']:,} source rows → {report['native_changes']:,} native changes; {report['conflicts']:,} conflicts; {report['suppressed']:,} forgotten records skipped.\n"+
                '\n'.join(report['warnings']+report['incomplete']))
        self.start(lambda c,s,p:migration.prepare(inventory,self.library,categories=chosen,
            account_map={k:v for k,v in mapping if v!='Exclude'},global_scope=target,lineage=label,policy=policy,
            include_private=private,include_relationships=relationships,after=after,before=before,stop=s),done)

    def commit(self):
        self.ready();review=self.preview;form=self.form();token=self.token()
        if self.conflict_window and not self.conflict_window.closed:raise ValueError('Apply or discard the open field choices before committing the import.')
        if not review or self.review_form!=form:raise ValueError('Prepare a review for the current selections.')
        report=json.dumps(review.report,ensure_ascii=False,indent=2)
        if not self.confirm('Commit VRCX import',report+'\n\nApply these local changes? A receipt and rollback before-images will be saved.'):return
        self.verify(token)
        if form!=self.form():raise ValueError('Selections changed. Prepare again.')
        self.start(lambda c,s,p:migration.commit(review,self.library,stop=s,check=lambda:self.verify(token)),self.completed,mutation=True)

    def completed(self,result):
        self.clear_preview();self.status.set('Completed: '+json.dumps(result,ensure_ascii=False));self.refresh_batches()
        page=self.shell.pages.get('Favorites')
        if page:page.local.guard(lambda:page.local.load(0))

    def backup(self,all_scopes):
        self.ready();token=self.token();scopes=self.library.scopes() if all_scopes else [self.target_scope()]
        if not scopes:scopes=[self.target_scope()]
        path=filedialog.asksaveasfilename(parent=self.window,initialfile='VRC-Eye-native-backup.jsonl',defaultextension='.jsonl',filetypes=[('Native data backup','*.jsonl')])
        self.verify(token)
        if path:self.start(lambda c,s,p:self.library.export_backup(path,scopes,stop=s),lambda n:self.status.set(f'Backed up {n:,} records across {len(scopes)} workspace(s).'))

    def restore(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,filetypes=[('Native data backup','*.jsonl')])
        self.verify(token)
        if not path:return
        policy=self.policy.get()
        from native_backup import BackupRestore
        restore=BackupRestore(self.library)
        def work(c,s,p):
            return restore.prepare(path,policy,stop=s)
        def done(result):
            plan=result;current=self.token()
            if not self.confirm('Restore native backup',f"Workspaces: {', '.join(plan.scopes)}\n{json.dumps(plan.counts)}. Conflict policy: {policy}.\n\nDeletion markers remove matching local records and preserve prior forget choices. Apply this reviewed restore?"):return
            self.verify(current)
            self.start(lambda c,s,p:restore.commit(plan,stop=s,check=lambda:self.verify(current)),self.completed,mutation=True)
        self.start(work,done)

    def backup_profile(self):
        self.ready();token=self.token()
        path=filedialog.asksaveasfilename(parent=self.window,initialfile='VRC-Eye-profile.zip',defaultextension='.zip');self.verify(token)
        if not path:return
        import desktop_backup
        paths=desktop_backup.sources(self.shell)
        self.start(lambda c,s,p:desktop_backup.create(paths,path,stop=s,check=lambda:self.verify(token)),
            lambda result:self.status.set('Verified profile backup saved: '+str(len(result['files']))+' data stores.'))

    def verify_profile(self):
        self.ready();token=self.token()
        path=filedialog.askopenfilename(parent=self.window,filetypes=[('Profile backup','*.zip')]);self.verify(token)
        if not path:return
        import desktop_backup
        from creator_projects_ui import review_document
        def done(report):
            self.verify(token)
            review_document(self.app,'Profile backup verification',desktop_backup.verification_summary(report),accept='Close')
            self.verify(token)
            self.status.set('Profile backup verified. No profile was created or changed.')
        self.start(lambda c,s,p:desktop_backup.verify(path,stop=s,check=lambda:self.verify(token)),done)

    def restore_profile(self):
        self.ready();token=self.token();path=filedialog.askopenfilename(parent=self.window,filetypes=[('Profile backup','*.zip')]);self.verify(token)
        if not path:return
        import desktop_backup
        def reviewed(report):
            manifest=report['manifest']
            current=self.token()
            from creator_projects_ui import review_document
            if not review_document(self.app,'Recover desktop profile',desktop_backup.verification_summary(report)+'\n\nRecover into a new folder?',accept='Choose new recovery folder'):return
            self.verify(current)
            parent=filedialog.askdirectory(parent=self.window,title='Parent folder for a NEW recovered profile');self.verify(current)
            if not parent:return
            from pathlib import Path
            target=Path(parent)/('VRC-Eye-Recovered-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
            self.start(lambda c,s,p:desktop_backup.restore(path,target,manifest,stop=s,check=lambda:self.verify(current)),
                lambda folder:self.status.set('Recovery verified. Close Eye, then start with --profile-dir "'+folder+'". Your current profile is unchanged.'),mutation=True)
        self.start(lambda c,s,p:desktop_backup.verify(path,stop=s,check=lambda:self.verify(token)),reviewed)

    def refresh_batches(self):
        self.ready();rows=self.library.batches(self.target_scope())
        self.batch_table.set(rows,lambda r:(r['created'],r['source'],r['state'],r['summary']))

    def rollback(self):
        self.ready();row=self.batch_table.selected();target=self.target_scope();token=self.token()
        if not row:raise ValueError('Choose a receipt.')
        with self.library.connect() as db:keys={(r[0],r[1],r[2]) for r in db.execute('SELECT scope,kind,id FROM eye_native_changes WHERE batch=? AND scope=? AND rolled_back=0',(row['id'],target))}
        if self.confirm('Roll back local changes',f"Restore {len(keys)} record(s) in this workspace from {row['source']}? Newer edits cause a conflict and are preserved."):
            self.verify(token);self.start(lambda c,s,p:self.library.rollback(row['id'],selected=keys,stop=s),self.completed,mutation=True)

    def rollback_records(self):
        self.ready();row=self.batch_table.selected();target=self.target_scope();token=self.token()
        if not row:raise ValueError('Choose a receipt.')
        with self.library.connect() as db:records=[tuple(r) for r in db.execute('SELECT scope,kind,id FROM eye_native_changes WHERE batch=? AND scope=? AND rolled_back=0 ORDER BY kind,id',(row['id'],target))]
        window=self.tk.Toplevel(self.window);window.title('Select records to roll back');window.geometry('800x500')
        box=self.tk.Listbox(window_body(window),selectmode='extended',exportselection=False);box.pack(fill='both',expand=True)
        for r in records:box.insert('end',r[1]+' · '+r[2])
        def apply():
            self.verify(token);selected={records[i] for i in box.curselection()}
            if not selected:raise ValueError('Choose records to roll back.')
            if self.confirm('Selected rollback',f'Restore {len(selected)} selected records? Collections and memberships must remain consistent.'):
                self.verify(token);window.destroy();self.start(lambda c,s,p:self.library.rollback(row['id'],selected=selected,stop=s),self.completed,mutation=True)
        bar=self.ttk.Frame(window_body(window));bar.pack(fill='x');button(self,bar,'Review selected rollback…',apply)

    def browse(self,offset):
        self.ready();signature=(self.target_scope(),self.record_kind.get(),self.query.get())
        if offset and signature!=self.browse_signature:raise ValueError('Search changed. Refresh from the first page.')
        expected=self.browse_revision if offset else None
        def done(result):
            if signature!=(self.target_scope(),self.record_kind.get(),self.query.get()):raise ValueError('Search changed while reading. Refresh explicitly.')
            if offset and not result['records']:return
            self.browse_signature=signature;self.browse_revision=result['revision'];self.offset=offset
            self.record_table.set(result['records'],lambda r:(r['kind'],r['data'].get('reported_time',''),r['id'],json.dumps(r['data'],ensure_ascii=False)[:300]),identity=lambda r:(r['scope'],r['kind'],r['id']))
            self.status.set(f"{result['total']:,} records · page {offset//100+1} · library revision {result['revision']}. Searches all retained native records in this workspace.")
        self.start(lambda c,s,p:self.library.search_page(signature[0],None if signature[1]=='All records' else signature[1],signature[2],offset=offset,revision=expected,stop=s),done)

    def detail(self):
        r=self.record_table.selected()
        if r:self.details.set(json.dumps(r,ensure_ascii=False,indent=2)[:8000])

    def forget(self):
        self.ready();r=self.record_table.selected();token=self.token()
        if not r:raise ValueError('Select a record.')
        if self.confirm('Forget local record','Delete the payload and its rollback copies? Later imports and old backups will not resurrect this record.'):
            self.verify(token);self.library.forget(r['scope'],r['kind'],r['id']);self.browse(0)

    def link_photo(self):
        self.ready();source=self.record_table.selected();token=self.token()
        if not source or source['kind']!='photo-reference':raise ValueError('Select an imported photo-reference record first.')
        path=filedialog.askopenfilename(parent=self.window,title='Select the current local photo to associate',filetypes=[('Photos','*.png *.jpg *.jpeg *.webp')])
        self.verify(token)
        if not path:return
        from photo_service import service_for
        from native_photo_link import PhotoReferenceLink
        service=service_for(self.shell);link=PhotoReferenceLink(self.library,service)
        def reviewed(plan):
            self.verify(token);observed=json.loads(plan.observation_json)
            text=(f"Historical reference: {source['data'].get('source_path','')}\nSelected file: {observed['path']}\nDestination photo workspace: {plan.scope}\nSHA-256: {observed['sha256']}\nEvidence: {plan.evidence}\n\n"
                  'VRCX did not store a file fingerprint. This cannot prove historical byte identity. Import the selected file and associate this reference? Manual photo notes and context are preserved.')
            if not self.confirm('Review photo reference association',text):return
            self.verify(token);work=link.commit(plan);photo_token=service.token()
            def completed(result):
                self.browse(0);self.status.set(result['state']+': '+result['detail'])
            self.start(lambda c,s,p:service.execute('Imported photo reference association',work,token=photo_token,stop=s,progress=p),completed,mutation=True)
        self.start(lambda c,s,p:link.prepare(source,path,stop=s),reviewed)

    def retain(self):
        self.ready();target=self.target_scope();token=self.token()
        date=simpledialog.askstring('History retention','Keep events and notification archives from this date onward (YYYY-MM-DD).',parent=self.window)
        self.verify(token)
        if not date:return
        cutoff=datetime.fromisoformat(date).replace(tzinfo=timezone.utc).isoformat()
        self.coordinated_history(target,token,before=cutoff)

    def forget_user_history(self):
        self.ready();target=self.target_scope();token=self.token()
        user=simpledialog.askstring('Forget retained history','Exact user ID whose native history, friend-feed events and roster encounters should be forgotten:',parent=self.window)
        self.verify(token)
        if user:self.coordinated_history(target,token,user=user.strip())

    def coordinated_history(self,target,token,**filters):
        from player_history import PlayerHistory
        from history_retention import Retention
        players=PlayerHistory(getattr(self.app,'player_store_path',None),self.shell.store.path,account_scope=target)
        service=Retention(self.library,players)
        def prepared(review):
            counts={key:len(value) for key,value in review['rows'].items()}
            if not self.confirm('Review coordinated history deletion',f'Workspace: {target}\nUser: {filters.get("user") or "All users"}\nCounts: {json.dumps(counts)}\n\nDelete these retained observations and their native rollback copies together? Personal notes, favorites, photos and action receipts are preserved. This does not delete the original game logs or VRCX source archive.'):return
            self.verify(token)
            def done(result):
                self.app.data_generation=getattr(self.app,'data_generation',0)+1
                sessions=getattr(self.app,'player_sessions',None)
                if sessions:sessions.local.clear();sessions.refresh_local()
                self.account_changed();self.browse(0);self.status.set('Retained history deleted: '+json.dumps(result))
            self.start(lambda c,s,p:service.commit(review,stop=s,check=lambda:self.verify(token)),done,mutation=True)
        self.start(lambda c,s,p:service.prepare(target,stop=s,**filters),prepared)

    def legacy(self):
        self.ready();target=self.target_scope();token=self.token()
        from native_legacy import prepare_earlier_imports
        plan=prepare_earlier_imports(self.library,target)
        if self.confirm('Unify earlier imports',f'Bring {len(plan.records):,} records into Favorites and native avatar/history views? Existing local edits are kept. Original earlier-import tables are retained.'):
            self.verify(token);self.start(lambda c,s,p:self.library.commit(plan,stop=s,check=lambda:self.verify(token)),self.completed,mutation=True)

    def tick(self):
        if self.closed:return
        self.tick_job();self.timer=self.app.root.after(150,self.tick)

    def close(self):
        if self.closed:return
        super().close();self.clear_preview()
        if getattr(self,'timer',None):self.app.root.after_cancel(self.timer)
        self.window.destroy()
