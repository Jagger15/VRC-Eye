"""Bounded parser pipes and resident-memory observation; not an OS sandbox."""
import subprocess
import threading
import time
import psutil
from avatar_library_files import check_cancel

MEMORY_LIMIT=1024*1024*1024


def exchange(process,source,*,limit,timeout,stop=None,memory_limit=MEMORY_LIMIT,kernel_memory_limit=False):
    """Drain no more than limit bytes, including while the child is still alive.

    The caller owns/reaps the process. Reader/writer threads are returned through
    process._vrc_eye_io and joined by cleanup after process termination.
    """
    check_cancel(stop)
    if timeout<=0:raise ValueError('Scene parsing exceeded its time budget.')
    try:owner=psutil.Process(process.pid);born=owner.create_time()
    except (psutil.NoSuchProcess,psutil.AccessDenied):
        # The bundled Unix bootstrap establishes RLIMIT_AS before it reads any
        # input. A restricted /proc view must not be misreported as RSS proof.
        if not kernel_memory_limit:raise ValueError('Scene parser memory inspection is unavailable.') from None
        owner=None;born=None
    output=bytearray();overflow=threading.Event();failed=threading.Event()
    def read():
        try:
            while True:
                chunk=process.stdout.read(min(8192,limit-len(output)+1))
                if not chunk:return
                if len(output)+len(chunk)>limit:overflow.set();return
                output.extend(chunk)
        except (OSError,ValueError):failed.set()
    def write():
        try:
            data=memoryview(source);offset=0
            while offset<len(data):
                count=process.stdin.write(data[offset:offset+65536])
                if not count:failed.set();return
                offset+=count
            process.stdin.close()
        except (OSError,ValueError):failed.set()
    reader=threading.Thread(target=read,daemon=True,name='VRC-Eye-Scene-Output')
    writer=threading.Thread(target=write,daemon=True,name='VRC-Eye-Scene-Input')
    process._vrc_eye_io=(reader,writer);reader.start();writer.start();deadline=time.monotonic()+timeout
    while True:
        check_cancel(stop)
        if overflow.is_set():raise ValueError('Scene parser output exceeded the bounded IPC budget.')
        if time.monotonic()>=deadline:raise ValueError('Scene parsing exceeded its time budget. Export a smaller static copy.')
        if process.poll() is not None and not reader.is_alive() and not writer.is_alive():break
        try:
            if owner is not None:
                if owner.create_time()!=born:raise ValueError('Scene parser process identity changed.')
                if owner.memory_info().rss>memory_limit:raise ValueError('Scene parser exceeded its resident-memory budget.')
        except psutil.NoSuchProcess:
            if process.poll() is None and not kernel_memory_limit:raise ValueError('Scene parser process identity became unavailable.') from None
            owner=None
        except psutil.AccessDenied:
            if not kernel_memory_limit:raise ValueError('Scene parser memory could not be inspected; no result was accepted.') from None
            owner=None
        # The UI worker remains cancellable while both pipe threads make progress.
        if stop:stop.wait(.02)
        else:time.sleep(.02)
    check_cancel(stop)
    if overflow.is_set() or failed.is_set():raise ValueError('Scene parser pipes did not complete within their limits.')
    return bytes(output)


def close(process):
    if process.poll() is None:
        process.terminate()
        try:process.wait(timeout=1)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=2)
    for thread in getattr(process,'_vrc_eye_io',()):thread.join(1)
    for pipe in (process.stdin,process.stdout):
        if pipe is not None:pipe.close()
    if any(t.is_alive() for t in getattr(process,'_vrc_eye_io',())):
        raise ValueError('Scene parser pipe ownership did not settle; preview unavailable.')
