"""Searchable activity, media links, explicit public image previews and local exports."""
import json
from pathlib import Path
import webbrowser
from urllib.parse import urlsplit

from companion_ui import Page, Table, Picture, line, button, choice, entry, note
from game_log import CATEGORIES
from media_preview import fetch_public_image
from player_profile import safe_link


class GameLogPage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, "Game Log")
        self.category = self.tk.StringVar(value="All"); self.query = self.tk.StringVar(value="")
        self.detail = self.tk.StringVar(value="Select a log entry."); self.video = self.tk.StringVar(value="No video URL recorded in this view.")
        self.url = self.tk.StringVar(value=""); self.auto = self.tk.BooleanVar(value=True)
        self.offset = 0; self.seen = -1; self.total = 0; self.selection_item = None
        self.log_generation=None;self.log_context=None
        row = line(self); choice(self, row, self.category, CATEGORIES, lambda: self.refresh(0), 14); entry(self, row, self.query, 28)
        button(self, row, "Filter", lambda: self.refresh(0)); button(self, row, "Previous", lambda: self.refresh(max(0, self.offset-200)))
        button(self, row, "Next", self.next)
        self.ttk.Checkbutton(row, text="Follow log", variable=self.auto).pack(side="left")
        note(self, "Only recorded log activity is available. Asset visibility is incomplete. Video load requests do not prove playback; explicit crash markers do not establish a cause. Up to 10,000 recent non-empty lines are retained; exports cover that retained view.")
        self.ttk.Label(parent, textvariable=self.video, wraplength=1020).pack(anchor="w", pady=3)
        self.table = Table(self, parent, (("time", "Log time", 165), ("category", "Category", 90), ("level", "Level", 75), ("text", "Recorded activity", 550)), height=8, select=self.selection)
        self.text = self.tk.Text(parent, height=5, wrap="word"); self.text.pack(fill="x", pady=5); self.text.configure(state="disabled")
        row = line(self); self.url_box = choice(self, row, self.url, (), self.clear_picture, 65)
        button(self, row, "Open link…", self.open_url); button(self, row, "Preview image", self.preview)
        self.picture = Picture(self, line(self), "Selected image")
        row = line(self); button(self, row, "Export filtered log…", self.export)
        button(self, row, "Copy entry / nearby context", self.copy)
        self.refresh(0)

    def tick(self):
        super().tick()
        from account_header import private
        if private(self.app):
            self.table.set([],lambda r:());self.clear_selection();self.video.set('Private information hidden');self.seen=-1;return
        if self.auto.get() and self.seen != self.shell.log.revision: self.refresh(self.offset)

    def refresh(self, offset):
        from account_header import private
        from dashboard_actions import context
        if private(self.app):self.table.set([],lambda r:());self.clear_selection();self.video.set('Private information hidden');return
        view=self.shell.log.projection(self.category.get(),self.query.get(),offset)
        if offset and not view['rows']:
            offset=max(0,((view['total']-1)//200)*200);view=self.shell.log.projection(self.category.get(),self.query.get(),offset)
        if self.log_generation!=view['generation'] or self.log_context!=context(self.app):
            self.table.set([],lambda r:());self.clear_selection()
        self.log_generation=view['generation'];self.log_context=context(self.app)
        self.offset = offset; rows=view['rows'];self.total=view['total']
        self.table.set(rows, lambda r: (r.stamp, r.category, r.severity, r.message[:400]),identity=lambda r:r.serial)
        self.seen = self.shell.log.revision
        current = self.shell.log.latest_video
        self.video.set(("Latest recorded video: "+current.playback+" · "+current.stamp+" · "+(current.urls[0] if current.urls else "No URL")) if current else "No active recorded video URL. Playback state may be unavailable.")
        self.status.set(f"{self.total} matching retained lines · showing {offset+1 if rows else 0}–{offset+len(rows)} · {self.shell.log.dropped} older lines rolled out. Source: {self.shell.log.source or 'Choose a log above.'}")
        if not self.table.selected(): self.clear_selection()

    def select_entry(self,serial,generation):
        self.require_current(generation)
        self.category.set('All');self.query.set('');rows=list(reversed(self.shell.log.items))
        position=next((n for n,r in enumerate(rows) if r.serial==serial),None)
        if position is None:raise ValueError('That log entry is no longer retained.')
        self.refresh((position//200)*200)
        key=next(k for k,r in self.table.records.items() if r.serial==serial)
        self.table.tree.selection_set(key);self.table.tree.see(key);self.selection()

    def require_current(self,generation=None):
        from account_header import private
        from dashboard_actions import context
        if private(self.app) or self.log_context is not None and self.log_context!=context(self.app):
            raise ValueError('Account or privacy changed. Refresh the log view.')
        expected=self.log_generation if generation is None else generation
        if expected is not None and expected!=self.shell.log.generation:raise ValueError('The log source changed. Refresh the log view.')

    def next(self):
        if self.offset+200 < self.total: self.refresh(self.offset+200)

    def clear_picture(self):
        self.cancel(); self.picture.clear()

    def clear_selection(self):
        self.selection_item = None
        self.clear_picture(); self.url.set(""); self.url_box.configure(values=())
        self.text.configure(state="normal"); self.text.delete("1.0", "end"); self.text.configure(state="disabled")

    def selection(self):
        self.require_current()
        row = self.table.selected()
        if row is not None and row is self.selection_item: return
        self.selection_item = row
        self.clear_picture()
        if not row: self.clear_selection(); return
        self.url_box.configure(values=row.urls); self.url.set(row.urls[0] if row.urls else "")
        self.text.configure(state="normal"); self.text.delete("1.0", "end")
        self.text.insert("1.0", f"{row.stamp} [{row.severity}] {row.category}\n{row.message}\n{row.playback}\nWorld context: {row.world or 'Unavailable'}\nSource: {row.source}")
        from media_error_reference import log_summary
        explanation=log_summary(row.message)
        if explanation:self.text.insert('end','\n\nMedia error reference\n'+explanation)
        self.text.configure(state="disabled")

    def selected_url(self):
        self.require_current()
        row = self.table.selected(); url = self.url.get()
        if not row or url not in row.urls: raise ValueError("Select an entry and one of its recorded URLs.")
        return row, url

    def open_url(self):
        _, url = self.selected_url()
        if not safe_link(url): raise ValueError("Only HTTP(S) links can be opened here. Other protocol URLs remain visible in the entry.")
        if self.confirm("Open recorded link", f"Open this externally supplied URL in your browser?\n\n{url}"):
            self.require_current()
            if self.selected_url()[1]!=url:raise ValueError('Selection changed. Select the link again.')
            webbrowser.open(url)

    def preview(self):
        row, url = self.selected_url()
        if not self.confirm("Load external image", f"Retrieve an image from {urlsplit(url).hostname}?\n\n{url}\n\nThe host sees a request from your connection. VRC Eye sends no login cookies."): return
        self.require_current()
        if self.table.selected() is not row or self.url.get() != url: raise ValueError("Selection changed. Select the image again.")
        def done(data):
            self.require_current()
            if self.table.selected() is row and self.url.get() == url: self.picture.show(data)
        self.start(lambda c,s,p: fetch_public_image(url, stop=s), done, api=False)

    def copy(self):
        self.require_current()
        row = self.table.selected()
        if not row: raise ValueError("Select an entry.")
        self.app.root.clipboard_clear(); self.app.root.clipboard_append(self.shell.log.around(row.serial))
        self.status.set("Copied nearby retained log context. Review before sharing; log text may contain personal information.")

    def export(self):
        self.require_current()
        from tkinter import filedialog
        name = filedialog.asksaveasfilename(parent=self.app.root, defaultextension=".jsonl", filetypes=[("JSON lines", "*.jsonl")], initialfile="VRC-Eye-game-log.jsonl")
        if not name: return
        self.require_current()
        from dataclasses import asdict
        rows = [r for r in self.shell.log.items if (self.category.get() == "All" or r.category == self.category.get()) and self.query.get().casefold() in (r.message+" "+r.world).casefold()]
        with Path(name).open("x", encoding="utf-8") as stream:
            for row in rows: stream.write(json.dumps(asdict(row), ensure_ascii=False)+"\n")
        self.status.set(f"Exported {len(rows)} retained entries. Review personal log content before sharing.")
