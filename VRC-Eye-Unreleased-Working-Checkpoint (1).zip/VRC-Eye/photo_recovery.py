"""Moved-root recovery reuses relative paths only after exact byte verification."""
from hashlib import sha256
from pathlib import Path
import json
import time
import uuid
from creator_projects import assert_no_links,local_path
from photo_files import directory_identity,check_directory,read_photo
from photo_store import key,stamp,json_data
from vrcx_sources import stopped


class RootRecovery:
    def __init__(self,store):self.store=store;self.review=None
    def prepare(self,scope,source,destination,*,stop=None):
        selected=self.store.source(scope,source)
        if not selected:raise ValueError('Choose the original photo source.')
        target=assert_no_links(local_path(destination));identity=directory_identity(target);root=local_path(selected['path'])
        if target==root:raise ValueError('Choose the folder where the source was moved or copied.')
        with self.store.connect() as db:
            rows=[dict(r) for r in db.execute('SELECT photo_id,path,digest,evidence FROM photo_files_v4 WHERE scope=? AND source_id=?',(scope,source))]
        if len(rows)>2000:raise ValueError('This source exceeds the 2,000-reference recovery limit. Recover individual files or split the source.')
        matches=[];missing=[];total=0
        for row in rows:
            stopped(stop)
            try:relative=local_path(row['path']).relative_to(root)
            except ValueError:missing.append(row['photo_id']);continue
            new=assert_no_links(target/relative)
            if not new.is_file():missing.append(row['photo_id']);continue
            total+=new.stat().st_size
            if total>512*1024*1024:raise ValueError('Moved-root verification exceeds 512 MiB. Relink the largest files individually first.')
            raw,fp=read_photo(new,stop=stop)
            if sha256(raw).hexdigest()!=row['digest']:missing.append(row['photo_id']);continue
            matches.append(dict(row,destination=str(new),fingerprint=fp))
        check_directory(target,identity)
        self.review=dict(scope=scope,source=selected,destination=str(target),identity=identity,matches=matches,
            unmatched=missing,expires=time.monotonic()+900,id=uuid.uuid4().hex)
        self.frozen=json.dumps(self.review,sort_keys=True);return self.review
    def commit(self,review,*,stop=None,check=lambda:None):
        if review is not self.review or json.dumps(review,sort_keys=True)!=self.frozen or time.monotonic()>review['expires']:raise ValueError('Review the moved source again.')
        self.review=None;scope=review['scope'];old=review['source'];check_directory(review['destination'],review['identity']);check()
        if self.store.source(scope,old['id'])!=old:raise ValueError('The source approval changed.')
        for row in review['matches']:
            stopped(stop);raw,_=read_photo(row['destination'],expected=row['fingerprint'],stop=stop)
            if sha256(raw).hexdigest()!=row['digest']:raise ValueError('A destination changed after review.')
        # Add/reuse the approved new root; no source bytes are moved or deleted.
        if not review['matches']:raise ValueError('No exact byte matches were found. No catalog references were changed.')
        new=self.store.add_source(scope,review['destination'],old['label'][:88]+' (recovered)',recursive=old['recursive'])
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE');check()
            db.execute('DELETE FROM photo_watches_v6 WHERE scope=? AND source=?',(scope,old['id']))
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='photo_compatible_rules'").fetchone():
                db.execute('UPDATE photo_compatible_rules SET enabled=0 WHERE scope=? AND source=?',(scope,old['id']))
            for row in review['matches']:
                stopped(stop);check();evidence=json.loads(row['evidence']);evidence['fingerprint']=row['fingerprint']
                changed=db.execute("UPDATE photo_files_v4 SET path=?,path_key=?,source_id=?,evidence=?,status='Available',checked=? WHERE scope=? AND photo_id=? AND path=? AND digest=? AND source_id=?",
                    (row['destination'],key(row['destination']),new['id'],json_data(evidence),stamp(),scope,row['photo_id'],row['path'],row['digest'],old['id'])).rowcount
                if changed!=1:raise ValueError('A catalog reference changed; recovery was rolled back.')
            check_directory(review['destination'],review['identity']);check()
        return dict(matched=len(review['matches']),unmatched=len(review['unmatched']),source=new['id'])
