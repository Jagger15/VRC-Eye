"""Session-scoped display observations shared by search and existing tile views."""
from collections import OrderedDict
from dataclasses import replace

from account_header import boundary, private
from companion_data import Entity, entity


def key(row):return ('user' if row.kind == 'friend' else row.kind, row.id)


class LiveCatalog:
    def __init__(self, shell):
        self.shell=shell;self.context=None;self.revision=0
        self.rows=OrderedDict();self.versions={};self.signature=None;self.friends=set();self.friend_rows={}

    def sync(self):
        app=self.shell.app;context=(boundary(app),private(app))
        if context!=self.context:
            self.context=context;self.rows.clear();self.versions.clear();self.friends.clear()
            self.friend_rows.clear()
            self.signature=None;self.revision+=1
        return not context[1] and not app.demo and not getattr(app,'safe_mode',False)

    def publish(self, rows, *, after=None):
        if not self.sync():return
        for row in rows:
            if not isinstance(row,Entity) or row.kind not in ('user','friend','world','avatar','group'):continue
            ref=key(row)
            if after is not None and self.versions.get(ref,0)>after:continue
            old=self.rows.get(ref)
            if old==row:continue
            self.revision+=1;self.rows[ref]=row;self.rows.move_to_end(ref);self.versions[ref]=self.revision
            while len(self.rows)>2000:
                dropped,_=self.rows.popitem(last=False);self.versions.pop(dropped,None)

    def refresh(self):
        if not self.sync():return
        sync=getattr(self.shell,'automatic_sync',None)
        if not sync:return
        sync.sync_context()
        model=sync.model
        signature=(sync.generation,getattr(model,'revision',0),sync.self_checked,dict(sync.self_profile))
        if signature==self.signature:return
        self.signature=signature
        current=set(model.friends) if model else set()
        for ref in self.friends-current:
            old=self.rows.get(('user',ref))
            if old:
                data=dict(old.data or {},state='Unavailable',location='Friendship no longer observed',isFriend=False)
                self.publish([entity('user',data)])
        self.friends=current
        self.friend_rows={ref:row for ref,row in self.friend_rows.items() if ref in current}
        if model:
            for row in tuple(model.friends.values())[-1000:]:
                if row==self.friend_rows.get(row['id']):continue
                self.friend_rows[row['id']]=dict(row)
                record=entity('user',row)
                self.publish([replace(record,detail=(record.detail+' · Observed '+model.checked.get(record.id,'previously')).strip(' ·'))])
        if sync.self_profile:self.publish([entity('user',sync.self_profile)])

    def project(self, rows):
        self.refresh()
        if not self.sync():return []
        result=[]
        for row in rows:
            latest=self.rows.get(key(row))
            if latest:
                # Keep saved notes/fields that were not supplied by this observation.
                data=dict(row.data or {});data.update(latest.data or {})
                row=replace(latest,data=data)
            result.append(row)
        return result

    def snapshot(self):
        self.refresh()
        return tuple(self.rows.values())


def catalog_for(shell):
    value=getattr(shell,'live_catalog',None)
    if value is None:value=LiveCatalog(shell);shell.live_catalog=value
    return value
