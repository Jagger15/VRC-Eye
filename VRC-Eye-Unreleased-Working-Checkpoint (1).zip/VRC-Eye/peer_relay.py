"""Optional operator-hosted opaque VRC Eye TLS rendezvous relay.

Run explicitly: python peer_relay.py --bind 127.0.0.1 --port 8769
Use --bind with the relay machine's reachable adapter for remote clients. Share
its printed certificate fingerprint through a trusted channel. This server has
no accounts, public directory, content logging, offline storage or remote admin.
Both peers connect outward. The inner pinned TLS session belongs to the apps;
the relay terminates only the outer transport and sees endpoints and traffic
sizes, not VRC Eye payloads or device handshake contents.
"""
from __future__ import annotations

import argparse
import collections
import os
from pathlib import Path
import secrets
import select
import socket
import threading
import time

from peer_transport import (_FrameReader, _send_frame, _load_identity, _unb64,
                            HANDSHAKE_TIMEOUT)

MAX_CLIENTS = 96
MAX_ROOMS = 32
MAX_PENDING = 16
MAX_TUNNEL_BYTES = 512 * 1024 * 1024


class RelayServer:
    def __init__(self, directory, address='127.0.0.1', port=8769):
        self.directory, self.address, self.port = Path(directory), address, port
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.listener = None
        self.identity = None
        self.rooms, self.sockets, self.threads = {}, set(), set()
        self.last_error = ''

    @property
    def fingerprint(self):
        return self.identity['pin'] if self.identity else ''

    def _spawn(self, callback, *args):
        def run():
            try:
                callback(*args)
            finally:
                with self.lock:
                    self.threads.discard(threading.current_thread())
        thread = threading.Thread(target=run, daemon=True, name='VRC-Eye-Relay')
        with self.lock:
            if self.stop.is_set():
                return
            self.threads.add(thread)
        thread.start()

    def start(self):
        """Explicit CLI/test setup; do not call on an application's UI thread."""
        if self.listener is not None or self.stop.is_set():
            raise ValueError('Relay already started or closed')
        self.identity = _load_identity(self.directory)
        family = socket.AF_INET6 if ':' in self.address else socket.AF_INET
        listener = socket.socket(family, socket.SOCK_STREAM)
        try:
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind((self.address, self.port))
            listener.listen(64)
            listener.settimeout(.25)
        except Exception:
            listener.close()
            raise
        self.listener = listener
        self.port = listener.getsockname()[1]
        self._spawn(self._accept)
        return self

    def _dispose(self, stream):
        with self.lock:
            self.sockets.discard(stream)
        try:
            stream.shutdown(socket.SHUT_RDWR)
        except (OSError, ValueError):
            pass
        try:
            stream.close()
        except OSError:
            pass

    def _accept(self):
        while not self.stop.is_set():
            try:
                raw, _ = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with self.lock:
                if len(self.sockets) >= MAX_CLIENTS:
                    raw.close()
                    continue
                self.sockets.add(raw)
            raw.settimeout(HANDSHAKE_TIMEOUT)
            self._spawn(self._client, raw)

    def _client(self, raw):
        stream = None
        try:
            stream = self.identity['context'].wrap_socket(raw, server_side=True, do_handshake_on_connect=False)
            with self.lock:
                self.sockets.discard(raw)
                self.sockets.add(stream)
            stream.do_handshake()
            request = _FrameReader(stream, deadline=time.monotonic() + HANDSHAKE_TIMEOUT).read()
            op = request.get('op')
            room_id = request.get('room')
            _unb64(room_id, 32)
            if op == 'host' and set(request) == {'op', 'room'}:
                self._host(stream, room_id)
            elif op == 'join' and set(request) == {'op', 'room'}:
                self._guest(stream, room_id)
            elif op == 'attach' and set(request) == {'op', 'room', 'connection'}:
                self._attach(stream, room_id, request['connection'])
            else:
                raise ValueError('Invalid relay request')
        except Exception:
            # No endpoint, invitation, identity, or content logging.
            self.last_error = 'A relay connection was rejected or disconnected'
        finally:
            self._dispose(stream or raw)

    def _host(self, stream, room_id):
        room = {'stream': stream, 'write_lock': threading.Lock(), 'pending': {},
                'recent': collections.deque(), 'closed': threading.Event()}
        with self.lock:
            if room_id in self.rooms or len(self.rooms) >= MAX_ROOMS:
                raise ValueError('Relay room unavailable')
            self.rooms[room_id] = room
        try:
            _send_frame(stream, {'op': 'ready'})
            stream.settimeout(.25)
            while not self.stop.is_set():
                try:
                    data = stream.recv(1)
                    if not data:
                        return
                    raise ValueError('Unexpected control traffic')
                except socket.timeout:
                    continue
        finally:
            room['closed'].set()
            with self.lock:
                if self.rooms.get(room_id) is room:
                    del self.rooms[room_id]
                pending = list(room['pending'].values())
            for item in pending:
                item['ready'].set()
                item['done'].set()
                self._dispose(item['guest'])
                if item.get('attach'):
                    self._dispose(item['attach'])

    def _guest(self, stream, room_id):
        connection = secrets.token_hex(16)
        pending = {'guest': stream, 'ready': threading.Event(), 'done': threading.Event(), 'attach': None}
        with self.lock:
            room = self.rooms.get(room_id)
            if not room or room['closed'].is_set() or len(room['pending']) >= MAX_PENDING:
                raise ValueError('Relay room unavailable')
            now = time.monotonic()
            while room['recent'] and now - room['recent'][0] > 60:
                room['recent'].popleft()
            if len(room['recent']) >= 60:
                raise ValueError('Relay room rate limited')
            room['recent'].append(now)
            room['pending'][connection] = pending
        try:
            with room['write_lock']:
                _send_frame(room['stream'], {'op': 'incoming', 'connection': connection})
            if not pending['ready'].wait(HANDSHAKE_TIMEOUT) or not pending['attach'] or room['closed'].is_set():
                raise ValueError('Relay pairing timed out')
            attached = pending['attach']
            _send_frame(stream, {'op': 'paired'})
            _send_frame(attached, {'op': 'paired'})
            stream.settimeout(.5)
            attached.settimeout(.5)
            self._tunnel(stream, attached, pending['done'])
        finally:
            pending['done'].set()
            with self.lock:
                room['pending'].pop(connection, None)
            if pending['attach']:
                self._dispose(pending['attach'])

    def _attach(self, stream, room_id, connection):
        if not isinstance(connection, str) or len(connection) != 32:
            raise ValueError('Invalid relay attachment')
        with self.lock:
            room = self.rooms.get(room_id)
            pending = room['pending'].get(connection) if room else None
            if not pending or pending['attach'] or room['closed'].is_set():
                raise ValueError('Relay attachment unavailable')
            pending['attach'] = stream
            pending['ready'].set()
        while not self.stop.is_set() and not pending['done'].wait(.25):
            pass

    def _tunnel(self, first, second, done):
        # One worker owns both SSL sockets: OpenSSL objects are not touched
        # concurrently by independent read/write pump threads.
        last_activity, total = time.monotonic(), 0
        try:
            while not self.stop.is_set() and not done.is_set():
                if time.monotonic() - last_activity > 60:
                    return
                ready = [stream for stream in (first, second) if stream.pending()]
                if not ready:
                    ready = select.select([first, second], [], [], .25)[0]
                for source in ready:
                    try:
                        data = source.recv(16384)
                    except socket.timeout:
                        continue
                    if not data:
                        return
                    last_activity = time.monotonic()
                    total += len(data)
                    if total > MAX_TUNNEL_BYTES:
                        return
                    (second if source is first else first).sendall(data)
        except Exception:
            pass
        finally:
            done.set()

    def close(self):
        self.stop.set()
        if self.listener:
            self._dispose(self.listener)
        with self.lock:
            streams = list(self.sockets)
        for stream in streams:
            self._dispose(stream)

    def wait_closed(self, timeout=3.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self.lock:
                threads = list(self.threads)
            if not threads:
                return True
            for thread in threads:
                thread.join(max(0, min(.1, deadline - time.monotonic())))
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bind', default='127.0.0.1', help='Relay adapter address (default loopback only)')
    parser.add_argument('--port', type=int, default=8769)
    parser.add_argument('--directory', default=str(Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'VRC-Eye-Relay'))
    args = parser.parse_args()
    relay = RelayServer(args.directory, args.bind, args.port).start()
    print('VRC Eye opaque relay listening on %s:%s' % (args.bind, relay.port))
    print('Certificate SHA-256 fingerprint: ' + relay.fingerprint)
    print('Share this fingerprint through a trusted channel. Ctrl+C stops the relay.')
    try:
        while not relay.stop.wait(.5):
            pass
    except KeyboardInterrupt:
        pass
    finally:
        relay.close()
        relay.wait_closed()


if __name__ == '__main__':
    main()
