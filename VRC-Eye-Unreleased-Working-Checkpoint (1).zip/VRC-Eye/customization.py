"""Local presentation/layout documents. Imports cannot start services or carry secrets."""
from copy import deepcopy
import json
from pathlib import Path
import uuid

from ui_preferences import Presentation

KEY = 'ui.customization'
WIDGETS = {'session':'Session', 'activity':'Avatar activity', 'account':'Account',
           'shortcuts':'Quick actions', 'performance':'Performance', 'notes':'Quick notes',
           'timer':'Session timer', 'eye':'Eye-to-Eye', 'media':'Media', 'photos':'Photos',
           'worlds':'World favorites', 'tasks':'Creator tasks', 'events':'Events', 'downloads':'Downloads',
           'inbox':'Inbox', 'health':'Service health', 'history':'Observed history', 'presence':'Discord presence',
           'runtime':'Unity runtime', 'diagnostics':'Crash diagnostics','applications':'Steam & VRChat','gamelog':'Game log'}
APPEARANCE = tuple(k for k in Presentation.__dataclass_fields__ if k not in ('schema','mode','start_page'))


def label(value):
    if not isinstance(value,str) or not 1 <= len(value.strip()) <= 80 or any(ord(c)<32 for c in value):
        raise ValueError('Use a name between 1 and 80 characters.')
    return value.strip()


def widget(kind):
    if not isinstance(kind,str) or kind not in WIDGETS: raise ValueError('Choose an available widget.')
    return dict(id=uuid.uuid4().hex,kind=kind,size='Standard',collapsed=False,pinned=False)


def defaults():
    rows=[dict(widget(k),id=uuid.uuid5(uuid.NAMESPACE_URL,'vrc-eye/default-widget/'+k).hex)
          for k in ('session','activity','account','shortcuts','performance','notes')]
    return dict(schema=1,active='Everyday',layouts={'Everyday':rows},profiles={},history=[])


def validate(raw):
    if not isinstance(raw,dict) or not {'schema','active','layouts','profiles','history'}<=set(raw) or set(raw)-{'schema','active','layouts','profiles','history','conditions'} or type(raw['schema']) is not int or raw['schema']!=1:
        raise ValueError('Unsupported customization document.')
    value=deepcopy(raw);layouts=value['layouts'];profiles=value['profiles']
    if not isinstance(layouts,dict) or not 1<=len(layouts)<=12 or not isinstance(value['active'],str) or value['active'] not in layouts:
        raise ValueError('Keep between 1 and 12 named Home layouts.')
    for name,rows in layouts.items():
        label(name)
        if not isinstance(rows,list) or len(rows)>30:raise ValueError('A layout supports up to 30 widgets.')
        ids=set()
        for row in rows:
            if not isinstance(row,dict) or not {'id','kind','size','collapsed','pinned'}<=set(row) or set(row)-{'id','kind','size','collapsed','pinned','filter','columns','sort','descending','when','hidden','span','height'}:
                raise ValueError('Unsupported widget settings.')
            if (type(row.get('hidden',False)) is not bool or type(row.get('span',0)) is not int or not 0<=row.get('span',0)<=3
                    or type(row.get('height',0)) is not int or not 0<=row.get('height',0)<=1200):
                raise ValueError('Use a boolean hidden flag, 0–3 columns and a minimum height of 0–1200.')
            if (not isinstance(row['id'],str) or len(row['id'])!=32 or any(c not in '0123456789abcdef' for c in row['id'])
                    or row['id'] in ids or not isinstance(row['kind'],str) or not __import__('re').fullmatch('[a-zA-Z0-9_-]{1,64}',row['kind']) or row['size'] not in ('Compact','Standard','Wide')
                    or type(row['collapsed']) is not bool or type(row['pinned']) is not bool):
                raise ValueError('Invalid widget configuration.')
            if not isinstance(row.get('filter',''),str) or len(row.get('filter',''))>256:raise ValueError('Widget filters support up to 256 characters.')
            columns=row.get('columns',[])
            if not isinstance(columns,list) or len(columns)>12 or any(c not in ('name','type','time','status','source','freshness') for c in columns):raise ValueError('Unsupported widget columns.')
            if len(columns)!=len(set(columns)):raise ValueError('Choose each widget column once.')
            if row.get('sort','time') not in ('name','type','time','status','source','freshness') or type(row.get('descending',True)) is not bool:
                raise ValueError('Choose a supported widget sort column and direction.')
            ids.add(row['id'])
            from dashboard_conditions import terms
            terms(row.get('when','Always'))
    if 'conditions' in value:
        from dashboard_conditions import validate as conditions
        value['conditions']=conditions(value['conditions'],layouts)
    if not isinstance(profiles,dict) or len(profiles)>20:raise ValueError('Keep up to 20 appearance profiles.')
    for name,prefs in profiles.items():
        label(name)
        if not isinstance(prefs,dict) or set(prefs)-set(APPEARANCE):raise ValueError('Profiles contain appearance settings only.')
        Presentation().changed(**prefs)
    if not isinstance(value['history'],list) or len(value['history'])>30 or any(not isinstance(x,str) or len(x)>160 for x in value['history']):
        raise ValueError('Invalid customization history.')
    return value


def load(app):
    raw=getattr(app,'_customization_session',None)
    if raw is None:raw=app.sidebar.store.option(KEY,None)
    if raw is None:return defaults()
    return validate(raw)


def save(app,value,reason,*,rebuild=True,expected=None):
    value=validate(value);value['history']=(value['history']+[str(reason)[:160]])[-30:]
    if app.demo or getattr(app,'safe_mode',False):app._customization_session=value
    else:
        store=app.sidebar.store
        if expected is not None:
            raw=store.option(KEY,None)
            current=validate(raw) if raw is not None else defaults()
            if current!=expected:raise ValueError('Home settings changed in another editor. Reload before saving.')
            if hasattr(store,'compare_option'):store.compare_option(KEY,value,raw)
            else:store.set_option(KEY,value)
        else:store.set_option(KEY,value)
        app._customization_session=None
    home=app.sidebar.pages.get('Home')
    if rebuild and home and hasattr(home,'dashboard'):home.dashboard.rebuild(value)
    return value


def update_widget(app,identifier,*,layout=None,**changes):
    """Merge a card edit into the latest layout, preserving other editors' work."""
    value=load(app)
    before=deepcopy(value)
    rows=value['layouts'].get(layout or value['active'],[])
    row=next((r for r in rows if r['id']==identifier),None)
    if row is None:raise ValueError('This Home layout changed. Reopen the card.')
    row.update(changes)
    save(app,value,'Home table options changed',rebuild=False,expected=before)
    editor=app.sidebar.pages.get('Customization')
    if editor is not None and hasattr(editor,'state'):
        editor.state=deepcopy(value);editor.refresh()
    return deepcopy(row)


def theme_document(prefs):
    return dict(schema=1,kind='vrc-eye-appearance',appearance={k:getattr(prefs,k) for k in APPEARANCE})


def parse_theme(raw):
    if not isinstance(raw,dict) or set(raw)!={'schema','kind','appearance'} or type(raw['schema']) is not int or raw['schema']!=1 or raw['kind']!='vrc-eye-appearance':
        raise ValueError('Choose a VRC Eye appearance file.')
    changes=raw['appearance']
    if not isinstance(changes,dict) or set(changes)-set(APPEARANCE):raise ValueError('A theme may contain appearance fields only.')
    changes=dict(changes)
    if 'font_scale' not in changes and set(changes) & {'scale','text_scale','text_size'}:
        changes['font_scale']=0
    Presentation().changed(**changes)
    return changes


def read_document(path):
    from avatar_library_files import checked_stream
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('Duplicate document fields are not accepted.')
            result[k]=v
        return result
    with checked_stream(path,limit=65536) as (_,stream,_):data=stream.read(65537)
    if len(data)>65536:raise ValueError('Choose a settings document under 64 KiB.')
    try:return json.loads(data.decode('utf-8'),object_pairs_hook=pairs)
    except (UnicodeError,json.JSONDecodeError,RecursionError):raise ValueError('Invalid settings JSON.') from None
