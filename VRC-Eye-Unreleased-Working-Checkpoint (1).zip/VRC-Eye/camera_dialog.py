"""Preview and import a native camera photo into the World tab."""
from __future__ import annotations

from text_viewport import window_body

import base64
import os
from pathlib import Path
import queue
import tempfile
import threading

from camera_capture import (CameraError, default_photo_folder, png_dimensions,
                            read_photo, reduction_factor, save_png, watch_shared_capture)
from world_map import MAX_IMAGE, MapProfile, image_dimensions


def make_map_png(data, tk, parent):
    """Decode using the same native Tk engine as the map; downsample large photos.

    This changes image resolution only. It does not rectify perspective or
    remove roofs/occluders, and never modifies the original camera file.
    """
    width, height = png_dimensions(data)
    photo = tk.PhotoImage(data=base64.b64encode(data).decode("ascii"), master=parent)
    if (photo.width(), photo.height()) != (width, height):
        raise CameraError("Decoded image dimensions do not match the PNG header.")
    factor = reduction_factor(width, height)
    reduced = photo.subsample(factor) if factor > 1 else photo
    if factor > 1 or len(data) > MAX_IMAGE:
        with tempfile.TemporaryDirectory(prefix="vrc-eye-photo-") as folder:
            file = Path(folder) / "map.png"
            reduced.write(str(file), format="png")
            with file.open("rb") as stream:
                data = stream.read(MAX_IMAGE + 1)
    image_dimensions(data)
    return data, reduced


class CameraDialog:
    def __init__(self, view):
        self.view, self.app = view, view.app
        self.tk, self.ttk = view.tk, view.ttk
        self.window = self.tk.Toplevel(self.app.root)
        self.window.title("VRC Eye • Capture a map photo")
        self.window.geometry("920x790")
        self.window.minsize(920, 740)
        self.window.configure(bg=self.app.BG)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.closed = False
        self.timer = None
        self.stop = threading.Event()
        self.output = queue.Queue()
        self.busy = False
        self.photos = ()
        self.image = self.preview = self.data = None
        self.photo_path = None
        self.folder = self.tk.StringVar(value=str(default_photo_folder(Path(self.app.folder.get()))))
        self.owner = "world-map:" + str(id(self))
        self.capture_action = self.capture_gate = None
        self.capture_record_id = None
        self.status = self.tk.StringVar(value="Position the in-game camera above the area, looking straight down.")
        self.build()
        self.poll()

    def build(self):
        ttk = self.ttk
        body = ttk.Frame(window_body(self.window), padding=18)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Use VRChat's own camera", style="Accent.TLabel").pack(anchor="w")
        ttk.Label(body, text="1. Enable OSC and open the native Photo camera in VRChat. Fly it above the area and aim straight down.\n"
            "2. Keep it still; turn off focus blur and filters. Use 2160p / 4K or lower. A higher view with narrower FOV looks flatter.\n"
            "3. Capture below, preview the result, then use it as your map. Camera range and ceilings may limit what you can see.",
            style="Muted.TLabel", wraplength=850).pack(anchor="w", pady=(7, 12))
        row = ttk.Frame(body)
        row.pack(fill="x")
        ttk.Label(row, text="Photos folder").pack(side="left", padx=(0, 8))
        self.folder_entry = ttk.Entry(row, textvariable=self.folder)
        self.folder_entry.pack(side="left", fill="x", expand=True)
        self.browse_button = ttk.Button(row, text="Browse…", command=self.browse)
        self.browse_button.pack(side="left", padx=(8, 0))
        controls = ttk.Frame(body)
        controls.pack(fill="x", pady=(10, 4))
        self.prepare_button = ttk.Button(controls, text="Prepare Photo camera", command=self.prepare)
        self.prepare_button.pack(side="left", padx=(0, 8))
        self.capture_button = ttk.Button(controls, text="Capture + watch", command=lambda: self.start(True))
        self.capture_button.pack(side="left", padx=(0, 8))
        self.watch_button = ttk.Button(controls, text="Watch manual shot", command=lambda: self.start(False))
        self.watch_button.pack(side="left", padx=(0, 8))
        self.cancel_button = ttk.Button(controls, text="Cancel", command=self.cancel, state="disabled")
        self.cancel_button.pack(side="left")
        ttk.Button(controls, text="Networking…", command=self.networking).pack(side="left", padx=8)
        ttk.Button(controls, text="OSC Controls…", command=self.show_controls).pack(side="left")
        ttk.Label(body, text="Prepare sets Photo mode, shows the environment, and hides avatars/UI. These settings stay until changed in VRChat.\n"
            "Camera actions use shared OSC permissions. Configure the connection in Networking and enable camera controls in OSC Controls.",
            style="Muted.TLabel", wraplength=850).pack(anchor="w", pady=(0, 10))
        self.results = ttk.Combobox(body, state="readonly", values=())
        self.results.pack(fill="x")
        self.results.bind("<<ComboboxSelected>>", self.select_photo)
        self.preview_label = ttk.Label(body, text="Photo preview", anchor="center")
        self.preview_label.pack(fill="both", expand=True, pady=10)
        ttk.Label(body, textvariable=self.status, style="Accent.TLabel", wraplength=850).pack(anchor="w")
        ttk.Label(body, text="This is a perspective photo, not an orthographic floor plan. Roofs and uneven terrain remain in the image.\n"
            "Importing starts an uncalibrated map. Live player dots still need the world helper and matching calibration.",
            style="Muted.TLabel", wraplength=850).pack(anchor="w", pady=(9, 9))
        buttons = ttk.Frame(body)
        buttons.pack(fill="x")
        self.existing_button = ttk.Button(buttons, text="Choose existing PNG…", command=self.choose_existing)
        self.existing_button.pack(side="left")
        self.save_button = ttk.Button(buttons, text="Save map PNG…", command=self.save, state="disabled")
        self.save_button.pack(side="left", padx=8)
        self.use_button = ttk.Button(buttons, text="Use photo as map", command=self.use, state="disabled", style="Accent.TButton")
        self.use_button.pack(side="right")

    def set_busy(self, busy):
        self.busy = busy
        for widget in (self.folder_entry, self.browse_button, self.prepare_button,
                       self.capture_button, self.watch_button, self.existing_button):
            widget.configure(state="disabled" if busy else "normal")
        self.results.configure(state="disabled" if busy else "readonly")
        self.cancel_button.configure(state="normal" if busy else "disabled")
        state = "normal" if self.data and not busy else "disabled"
        self.use_button.configure(state=state)
        self.save_button.configure(state=state)

    def clear_preview(self):
        self.data = self.image = self.preview = self.photo_path = None
        self.preview_label.configure(image="", text="Photo preview")
        self.use_button.configure(state="disabled")
        self.save_button.configure(state="disabled")

    def browse(self):
        from tkinter import filedialog
        selected = filedialog.askdirectory(title="Choose VRChat's photo output folder", parent=self.window)
        if selected and not self.closed:
            self.folder.set(selected)

    def prepare(self):
        try:
            self.controller().camera_prepare(owner=self.owner)
            self.status.set("Camera setup requested through shared OSC. Check the in-game view before capturing.")
        except (OSError, ValueError) as error:
            self.status.set(str(error))

    def controller(self):
        controller = getattr(self.app, "osc_controller", None)
        if controller is None:
            raise CameraError("Shared OSC is unavailable. Open VRC Eye → VRC Eye Primary → OSC Controls to check setup.")
        return controller

    def networking(self):
        sidebar = getattr(self.app, "sidebar", None)
        if sidebar is not None:
            sidebar.show("Networking")
        else:
            self.status.set("Open VRC Eye → Networking to configure the shared OSC connection.")

    def show_controls(self):
        try:
            self.controller().show_controls()
        except (OSError, ValueError) as error:
            self.status.set(str(error))

    def start(self, trigger):
        if self.busy or self.closed:
            return
        try:
            value = self.folder.get().strip()
            if not value:
                raise CameraError("Choose VRChat's photo output folder first.")
            folder = Path(os.path.expandvars(value)).expanduser()
            if trigger:
                self.controller()
        except ValueError as error:
            self.status.set(str(error))
            return
        self.clear_preview()
        self.photos = ()
        self.results.configure(values=())
        self.results.set("")
        self.stop = threading.Event()
        self.output = queue.Queue()
        self.capture_action = self.capture_gate = None
        self.capture_record_id = None
        self.set_busy(True)
        self.status.set("Checking the photo folder…")
        threading.Thread(target=watch_shared_capture, args=(folder, trigger, self.output, self.stop),
                         daemon=True).start()

    def poll(self):
        if self.closed:
            return
        while True:
            try:
                kind, value = self.output.get_nowait()
            except queue.Empty:
                break
            if kind == "status":
                self.status.set(value)
            elif kind == "capture_ready":
                if self.stop.is_set() or not self.busy:
                    continue
                try:
                    self.capture_gate = value
                    result = self.controller().camera_capture(owner=self.owner)
                    self.capture_action = result.get("id") if isinstance(result, dict) else None
                    self.capture_record_id = result.get("capture_id") if isinstance(result, dict) else None
                    self.status.set("Capture requested through shared OSC; waiting for transmission…")
                    self.capture_result(result)
                except (OSError, ValueError) as error:
                    self.capture_failed(str(error))
            elif kind == "error":
                self.capture_failed(value)
            elif kind == "photos":
                self.photos = value
                self.set_busy(False)
                self.results.configure(values=[str(p.path) for p in self.photos])
                self.results.current(0)
                self.select_photo()
        if self.capture_action is not None and not self.stop.is_set():
            try:
                result = self.controller().action_status(self.capture_action)
                self.capture_result(result)
            except (OSError, ValueError) as error:
                self.capture_failed(str(error))
        self.timer = self.app.root.after(150, self.poll)

    def capture_result(self, result):
        if not isinstance(result, dict):
            self.capture_failed("Capture status is unavailable. The request will not be retried automatically.")
            return
        status = result.get("status", "")
        if status in {"sent", "transmitted", "observed", "matching_state_observed", "acknowledged", "action_confirmed"}:
            if self.capture_gate is not None:
                self.capture_gate.set()
            self.capture_action = self.capture_gate = None
        elif status in {"failed", "denied", "cancelled", "expired", "stale", "rejected", "blocked"}:
            self.capture_failed(result.get("detail") or result.get("message") or
                                "Capture was not transmitted. Review shared OSC permissions and connection.")
        elif not self.capture_action:
            self.capture_failed("No capture receipt is available. The request will not be retried automatically.")

    def capture_failed(self, message):
        self.stop.set()
        self.cancel_controls()
        self.set_busy(False)
        self.status.set(message)

    def select_photo(self, _event=None):
        index = self.results.current()
        if 0 <= index < len(self.photos):
            photo = self.photos[index]
            self.load(photo.path, photo)
            if self.data and self.capture_record_id is not None:
                try:
                    self.controller().controls.observe_capture_file(photo.path, capture_id=self.capture_record_id)
                except (OSError, ValueError):
                    # File selection remains useful if the action aged out of
                    # the bounded ledger. No new capture is requested.
                    pass

    def choose_existing(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.window, title="Choose an overhead VRChat photo",
            initialdir=self.folder.get(), filetypes=[("PNG photo", "*.png")])
        if path and not self.closed:
            self.photos = ()
            self.results.configure(values=())
            self.results.set("")
            self.load(Path(path))

    def load(self, path, expected=None):
        self.clear_preview()
        try:
            data, image = make_map_png(read_photo(path, expected), self.tk, self.window)
            factor = max(1, (image.width() + 719) // 720, (image.height() + 279) // 280)
            preview = image.subsample(factor)
        except (OSError, ValueError, self.tk.TclError) as error:
            self.status.set("Cannot load photo: " + str(error))
            return
        self.data, self.image, self.preview, self.photo_path = data, image, preview, path
        self.preview_label.configure(image=preview, text="")
        self.use_button.configure(state="normal")
        self.save_button.configure(state="normal")
        self.status.set(f"{path.name} • Map copy {image.width()} × {image.height()} • Review the image before using it.")

    def use(self):
        if not self.data or self.closed or self.busy or not self.view.can_replace():
            return
        try:
            self.view.set_profile(MapProfile("Camera map", "", self.data, 0., 1., 0., 1., calibrated=False), True)
        except (ValueError, self.tk.TclError) as error:
            self.status.set("Cannot use photo: " + str(error))
            return
        self.close()

    def save(self):
        from tkinter import filedialog
        if not self.data or self.busy:
            return
        file = filedialog.asksaveasfilename(parent=self.window, title="Save a new map PNG",
            defaultextension=".png", initialfile="world-camera-map.png", filetypes=[("PNG image", "*.png")])
        if file and not self.closed:
            try:
                save_png(Path(file), self.data)
                self.status.set("Saved map PNG: " + file)
            except (OSError, ValueError) as error:
                self.status.set("Could not save; choose a new filename. " + str(error))

    def cancel(self):
        self.stop.set()
        self.cancel_controls()
        self.output = queue.Queue()
        self.set_busy(False)
        self.status.set("Cancelled. A photo already requested may still be saved by VRChat.")

    def cancel_controls(self):
        self.capture_action = self.capture_gate = None
        self.capture_record_id = None
        controller = getattr(self.app, "osc_controller", None)
        if controller is not None:
            try:
                controller.cancel_owner(self.owner)
            except (OSError, ValueError):
                # The shared service owns cleanup reporting; closing a preview
                # must still stop its watcher even if the connection was lost.
                pass

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.stop.set()
        self.cancel_controls()
        self.output = queue.Queue()
        if self.timer is not None:
            self.app.root.after_cancel(self.timer)
        self.window.destroy()
        if getattr(self.view, "camera_dialog", None) is self:
            self.view.camera_dialog = None
