# VRC Eye 1.21.0 — Development 9 validation

The final portable regression passed **4,564 tests and 1,059 subtests**,
with zero failures/errors and zero blocked external-socket attempts in 94.27s.
There are **473 skipped native-GUI cases**, **1 deselected Unix bridge case**,
and the same **13 excluded local-transport modules** as Development 8. Skips and
exclusions are not passes. The environment cannot establish the virtual X server's
local listening sockets. The two warnings are the pre-existing TestListener
constructor and deliberately duplicated ZIP-member cases.

The 45 new focused cases cover shared view scheduling and pacing, live selection
and image changes, scoped fuzzy search and notes, privacy/account cancellation,
ordered status conditions, real reviewed dispatch against synthetic responses,
manual override, uncertain replies, and monotonic/wall-clock sleep boundaries.
Headless widget tests exercise callbacks; they do not establish native rendering.

All **532 Python files** parse with Python 3.10 grammar. Execution used
Python 3.12.14. The source manifest covers **581 files**.
Seven launchers and requirements.txt are byte-identical to Development 8. Shell
syntax and the CLI version check passed. Packaging checks CRC, all baseline paths,
manifest hashes, and exact archive/source bytes. No second full clean-extraction
test run is claimed. Runtime code was unchanged after the final regression.

An initial run found one release-label assertion still expecting Development 8;
the label was updated and the complete suite rerun successfully. Sleep-boundary
coverage was added before the final run.

Native Windows/Linux GUI, credential vaults, tray/speech, Discord and SteamVR,
real VRChat authentication/events and actual status writes remain unverified.
This is runnable source, not a compiled executable or signed installer.

See [Development 9 guide](LIVE_SEARCH_STATUS_DEV9.md),
[previous validation](VALIDATION_1_21_DEV8.md), and BUILD_VALIDATION.json for
the exact command and exclusions. Full VRCX parity remains incomplete.
