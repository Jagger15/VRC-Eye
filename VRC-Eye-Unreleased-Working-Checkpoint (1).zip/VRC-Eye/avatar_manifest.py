"""Data-only Avatar Toolkit contracts, planning, and evidence-based validation.

Schema 1 never loads assets, executes actions, fetches references, or establishes
ownership. Source/generated describe the exported evidence, not the worn build.
"""
import copy
import hashlib
import json
import math
import re

from avatar_creator_store import json_copy, validate_avatar_id

SCHEMA_VERSION = 1
MAX_MANIFEST_BYTES = 256 * 1024
PLATFORMS = ("Windows", "Android", "iOS", "Generic")
PARAMETER_TYPES = ("Bool", "Int", "Float")
ACTIONS = frozenset(("select_profile", "acknowledge_reminder", "request_photo",
                     "pause_effect", "diagnostic_bookmark", "safety_profile"))
CAPABILITIES = frozenset(("battery_display", "status_display", "safety_profile",
    "streamer_badge", "music_visualizer", "camera_request", "dnd_afk",
    "connection_indicator", "hardware_status", "resource_warning", "media_effect",
    "contact_button", "physbone_debug", "wrist_controller", "diagnostic_bookmark",
    "test_marker", "profile_select", "reminder_ack", "raycast_helper"))
CONSTRAINT_SOURCE = "https://creators.vrchat.com/avatars/animator-parameters/"
CONSTRAINT_REVISION = "VRChat documentation checked 2026-10-01"
SYNC_BUDGET_BITS = 256
BUILTIN_PARAMETERS = frozenset(("IsLocal", "PreviewMode", "Viseme", "Voice", "GestureLeft",
    "GestureRight", "GestureLeftWeight", "GestureRightWeight", "AngularY", "VelocityX",
    "VelocityY", "VelocityZ", "VelocityMagnitude", "Upright", "Grounded", "Seated", "AFK",
    "TrackingType", "VRMode", "MuteSelf", "InStation", "Earmuffs", "IsOnFriendsList",
    "AvatarVersion", "IsAnimatorEnabled", "ScaleModified", "ScaleFactor", "ScaleFactorInverse",
    "EyeHeightAsMeters", "EyeHeightAsPercent"))
_SLUG = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.-]{0,79}\Z")
_FIELDS = {"schema", "avatar_id", "package_id", "platform", "revision", "build_id",
    "stage", "toolkit_version", "label", "parameters", "modules", "capabilities",
    "actions", "hierarchy", "bindings", "rig", "routes", "assets", "migrations"}


def _object(value, fields, label):
    if not isinstance(value, dict):
        raise ValueError(label + " must be an object.")
    unknown = set(value) - set(fields)
    if unknown:
        raise ValueError(label + " has unsupported fields: " + ", ".join(sorted(unknown)))
    return value


def _text(value, label, limit=256, empty=True):
    if not isinstance(value, str) or len(value) > limit or (not empty and not value.strip()):
        raise ValueError(label + " must be text of at most " + str(limit) + " characters.")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError(label + " cannot contain control characters.")
    return value


def _slug(value, label, empty=False):
    if empty and value == "":
        return value
    if not isinstance(value, str) or not _SLUG.fullmatch(value) or value in (".", ".."):
        raise ValueError(label + " must be a short portable identifier, not a path or URL.")
    return value


def _name(value, label="Parameter name", empty=False):
    if empty and value == "":
        return value
    value = _text(value, label, 128, False)
    if value.startswith("/") or not re.fullmatch(r"[A-Za-z0-9_./-]+", value):
        raise ValueError(label + " must be a literal relative OSC parameter name.")
    if any(part in ("", ".", "..") for part in value.split("/")):
        raise ValueError(label + " cannot contain empty or traversal segments.")
    return value


def _boolean(value, label):
    if type(value) is not bool:
        raise ValueError(label + " must be a Boolean.")
    return value


def _number(value, label, minimum=None, maximum=None, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(label + " must be finite numeric data.")
    if integer and type(value) is not int:
        raise ValueError(label + " must be an integer.")
    if minimum is not None and value < minimum or maximum is not None and value > maximum:
        raise ValueError(label + " is outside the supported range.")
    return value


def _choice(value, choices, label):
    if not isinstance(value, str) or value not in choices:
        raise ValueError(label + " must be one of " + ", ".join(sorted(choices)) + ".")
    return value


def _list(value, label, limit=512):
    if not isinstance(value, list) or len(value) > limit:
        raise ValueError(label + " must be a list with at most " + str(limit) + " entries.")
    return value


def _unique(items, key, label):
    values = [item[key] if key else item for item in items]
    if len(values) != len(set(values)):
        raise ValueError(label + " contains duplicate identifiers.")
    return items


def parameter_value(parameter, value):
    """Check without coercing Bool/Int/Float; return exact supported value."""
    kind = parameter["type"]
    if kind == "Bool":
        return _boolean(value, parameter["name"])
    checked = _number(value, parameter["name"], parameter["min"], parameter["max"], kind == "Int")
    return float(checked) if kind == "Float" else checked


def _parameter(raw):
    fields = {"name", "type", "direction", "default", "neutral", "min", "max", "synced",
        "saved", "privacy", "module", "semantic", "validity", "freshness_seconds",
        "ephemeral", "action", "acknowledgment", "rate_hz"}
    raw = _object(raw, fields, "Parameter")
    kind = _choice(raw.get("type"), PARAMETER_TYPES, "Parameter type")
    low, high, default = {"Bool": (0, 1, False), "Int": (0, 255, 0), "Float": (-1.0, 1.0, 0.0)}[kind]
    minimum = _number(raw.get("min", low), "Parameter minimum", low, high, kind == "Int")
    maximum = _number(raw.get("max", high), "Parameter maximum", low, high, kind == "Int")
    if minimum > maximum or kind == "Bool" and (minimum, maximum) != (0, 1):
        raise ValueError("Parameter range is reversed or invalid for a Boolean.")
    result = {"name": _name(raw.get("name")), "type": kind,
        "direction": _choice(raw.get("direction"), ("in", "out"), "Parameter direction"),
        "min": minimum, "max": maximum,
        "synced": _boolean(raw.get("synced", False), "Synced"),
        "saved": _boolean(raw.get("saved", False), "Saved"),
        "privacy": _choice(raw.get("privacy", "private"), ("private", "public"), "Privacy"),
        "module": _slug(raw.get("module", ""), "Module", True),
        "semantic": _text(raw.get("semantic", ""), "Semantic meaning"),
        "validity": _name(raw.get("validity", ""), "Validity parameter", True),
        "freshness_seconds": _number(raw.get("freshness_seconds", 5), "Freshness", .05, 3600),
        "ephemeral": _boolean(raw.get("ephemeral", False), "Ephemeral"),
        "action": _choice(raw.get("action", ""), ACTIONS | {""}, "Action"),
        "acknowledgment": _name(raw.get("acknowledgment", ""), "Acknowledgment parameter", True),
        "rate_hz": _number(raw.get("rate_hz", 10), "Rate", .01, 60)}
    result["default"] = parameter_value(result, raw.get("default", default))
    result["neutral"] = parameter_value(result, raw.get("neutral", default))
    if result["action"] and result["direction"] != "out":
        raise ValueError("Only parameters coming out of the avatar may request a local action.")
    return result


def _module(raw):
    raw = _object(raw, {"id", "version", "dependencies", "platforms", "owned_objects", "anchors",
        "menu_entries", "tier", "costs", "description", "uninstall"}, "Module")
    result = {"id": _slug(raw.get("id"), "Module ID"),
        "version": _text(raw.get("version", "1"), "Module version", 80, False),
        "tier": _choice(raw.get("tier", "minimal"), ("minimal", "standard", "elaborate"), "Tier"),
        "description": _text(raw.get("description", ""), "Module description", 1000),
        "uninstall": _choice(raw.get("uninstall", "owned_only"), ("owned_only",), "Uninstall policy")}
    for key in ("dependencies", "owned_objects", "anchors"):
        result[key] = _unique([_slug(x, key) for x in _list(raw.get(key, []), key, 256)], None, key)
    result["platforms"] = _unique([_choice(x, PLATFORMS, "Module platform") for x in
        _list(raw.get("platforms", ["Generic"]), "Module platforms", 4)], None, "Platforms")
    result["menu_entries"] = [_text(x, "Menu label", 80, False) for x in
        _list(raw.get("menu_entries", []), "Menu entries", 64)]
    costs = _object(raw.get("costs", {}), {"renderers", "materials", "contacts", "physbones", "animations"}, "Costs")
    result["costs"] = {key: _number(value, key, 0, 1000000, True) for key, value in costs.items()}
    return result


def _hierarchy(raw):
    raw = _object(raw, {"id", "parent", "name", "module", "components", "anchor", "generated_id"}, "Hierarchy object")
    return {"id": _slug(raw.get("id"), "Object ID"), "parent": _slug(raw.get("parent", ""), "Parent", True),
        "name": _text(raw.get("name", "Object"), "Object display label", 128),
        "module": _slug(raw.get("module", ""), "Object module", True),
        "components": [_text(x, "Component label", 128) for x in _list(raw.get("components", []), "Components", 64)],
        "anchor": _boolean(raw.get("anchor", False), "Anchor"),
        "generated_id": _slug(raw.get("generated_id", ""), "Generated object", True)}


def _vector(value, label, default):
    values = _list(default if value is None else value, label, 3)
    if len(values) != 3:
        raise ValueError(label + " needs exactly three coordinates.")
    return [_number(x, label, -100000, 100000) for x in values]


def _rig(raw):
    raw = _object(raw, {"kind", "bones", "viewpoint", "sockets"}, "Rig")
    bones = raw.get("bones", {})
    if not isinstance(bones, dict) or len(bones) > 128:
        raise ValueError("Rig bones must be a bounded mapping.")
    result = {"kind": _choice(raw.get("kind", "unknown"), ("humanoid", "generic", "unknown"), "Rig kind"),
        "bones": {_slug(key, "Bone semantic"): _slug(value, "Bone object") for key, value in bones.items()},
        "viewpoint": None if raw.get("viewpoint") is None else _vector(raw["viewpoint"], "Viewpoint", [0, 0, 0]),
        "sockets": []}
    for socket in _list(raw.get("sockets", []), "Sockets", 64):
        _object(socket, {"id", "object", "module", "side", "position", "rotation", "scale"}, "Socket")
        result["sockets"].append({"id": _slug(socket.get("id"), "Socket ID"),
            "object": _slug(socket.get("object"), "Socket object"),
            "module": _slug(socket.get("module", ""), "Socket module", True),
            "side": _choice(socket.get("side", "manual"), ("left", "right", "center", "manual"), "Socket side"),
            "position": _vector(socket.get("position"), "Position", [0, 0, 0]),
            "rotation": _vector(socket.get("rotation"), "Rotation", [0, 0, 0]),
            "scale": _vector(socket.get("scale"), "Scale", [1, 1, 1])})
    _unique(result["sockets"], "id", "Sockets")
    return result


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Manifest contains duplicate JSON keys.")
        result[key] = value
    return result


def load_manifest(source):
    """Strict bounded import; a string is JSON, never a filename or URL."""
    if isinstance(source, bytes):
        if len(source) > MAX_MANIFEST_BYTES:
            raise ValueError("Manifest exceeds 256 KiB.")
        try:
            source = source.decode("utf-8-sig")
        except UnicodeError as error:
            raise ValueError("Manifest must be UTF-8 JSON.") from error
    if isinstance(source, str):
        try:
            if len(source.encode("utf-8")) > MAX_MANIFEST_BYTES:
                raise ValueError("Manifest exceeds 256 KiB.")
            source = json.loads(source, object_pairs_hook=_pairs,
                parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Non-finite JSON constant: " + value)))
        except (UnicodeError, RecursionError, json.JSONDecodeError) as error:
            raise ValueError("Manifest must be bounded UTF-8 JSON, not a file reference or executable document.") from error
    raw = _object(json_copy(source), _FIELDS, "Manifest")
    if type(raw.get("schema")) is not int or raw["schema"] != SCHEMA_VERSION:
        raise ValueError("Unsupported avatar manifest schema; expected schema 1.")
    result = {"schema": 1, "avatar_id": validate_avatar_id(raw.get("avatar_id")),
        "package_id": _slug(raw.get("package_id", "local-avatar"), "Package ID"),
        "platform": _choice(raw.get("platform", "Generic"), PLATFORMS, "Platform"),
        "revision": _text(raw.get("revision", "1"), "Revision", 80, False),
        "build_id": _text(raw.get("build_id", ""), "Build ID", 128),
        "stage": _choice(raw.get("stage", "source"), ("source", "generated"), "Evidence stage"),
        "toolkit_version": _text(raw.get("toolkit_version", ""), "Toolkit version", 80),
        "label": _text(raw.get("label", "Avatar workspace"), "Label", 128),
        "parameters": _unique([_parameter(x) for x in _list(raw.get("parameters", []), "Parameters", 512)], "name", "Parameters"),
        "modules": _unique([_module(x) for x in _list(raw.get("modules", []), "Modules", 128)], "id", "Modules"),
        "hierarchy": _unique([_hierarchy(x) for x in _list(raw.get("hierarchy", []), "Hierarchy", 2000)], "id", "Hierarchy"),
        "rig": _rig(raw.get("rig", {})), "bindings": [], "routes": [], "assets": [], "migrations": []}
    for key, allowed in (("actions", ACTIONS), ("capabilities", CAPABILITIES)):
        result[key] = _unique([_choice(x, allowed, key) for x in _list(raw.get(key, []), key, 64)], None, key)
    for binding in _list(raw.get("bindings", []), "Bindings", 2000):
        _object(binding, {"object", "property", "module", "layer"}, "Binding")
        result["bindings"].append({"object": _slug(binding.get("object"), "Binding object"),
            "property": _text(binding.get("property"), "Binding property", 128, False),
            "module": _slug(binding.get("module"), "Binding module"),
            "layer": _text(binding.get("layer", "FX"), "Layer", 80, False)})
    for route in _list(raw.get("routes", []), "Routes", 512):
        _object(route, {"source", "target", "transform", "public_approved"}, "Route")
        result["routes"].append({"source": _name(route.get("source")), "target": _name(route.get("target")),
            "transform": _choice(route.get("transform", "identity"), ("identity", "normalize", "threshold", "invert"), "Transform"),
            "public_approved": _boolean(route.get("public_approved", False), "Public approval")})
    for asset in _list(raw.get("assets", []), "Asset references", 64):
        _object(asset, {"id", "kind", "sha256", "permission"}, "Asset reference")
        digest = asset.get("sha256", "")
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("Asset references require a lowercase SHA-256 digest; they never name a file or URL.")
        result["assets"].append({"id": _slug(asset.get("id"), "Asset ID"),
            "kind": _choice(asset.get("kind"), ("preview", "thumbnail", "hierarchy", "documentation"), "Asset kind"),
            "sha256": digest, "permission": _choice(asset.get("permission", "local_only"), ("local_only", "explicit_share"), "Asset permission")})
    _unique(result["assets"], "id", "Asset references")
    for migration in _list(raw.get("migrations", []), "Migrations", 512):
        _object(migration, {"from_revision", "from_parameter", "to_parameter", "reason"}, "Migration")
        result["migrations"].append({"from_revision": _text(migration.get("from_revision"), "Old revision", 80, False),
            "from_parameter": _name(migration.get("from_parameter")), "to_parameter": _name(migration.get("to_parameter")),
            "reason": _text(migration.get("reason", ""), "Migration reason", 500)})
    validity_graph = {p["name"]: [p["validity"]] if p["validity"] else [] for p in result["parameters"]}
    if next(_cycles(validity_graph), None) is not None:
        raise ValueError("Validity flags cannot reference themselves or form cycles.")
    # Normalization is bounded too; defaults must not inflate a small input beyond the record limit.
    return json_copy(result)


def manifest_digest(manifest):
    return hashlib.sha256(json.dumps(load_manifest(manifest), sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def parameter_budget(manifest):
    data = load_manifest(manifest)
    rows = [{"name": p["name"], "type": p["type"], "synced": p["synced"],
        "bits": (1 if p["type"] == "Bool" else 8) if p["synced"] and p["name"] not in BUILTIN_PARAMETERS else 0} for p in data["parameters"]]
    used = sum(row["bits"] for row in rows)
    return {"used_bits": used, "limit_bits": SYNC_BUDGET_BITS, "remaining_bits": SYNC_BUDGET_BITS - used,
        "parameters": rows, "within_budget": used <= SYNC_BUDGET_BITS,
        "constraint_source": CONSTRAINT_SOURCE, "constraint_revision": CONSTRAINT_REVISION,
        "scope": data["stage"] + " declared expression parameters; not a runtime measurement"}


def _finding(severity, code, affected, evidence, symptom, remedy):
    return dict(severity=severity, code=code, affected=affected, evidence=evidence, symptom=symptom, remedy=remedy)


def _cycles(graph):
    # Each bounded graph is analyzed iteratively to avoid recursion on hostile imports.
    remaining = set(graph)
    while remaining:
        start = min(remaining)
        stack = [(start, iter(graph.get(start, ())))]
        active, done = {start}, set()
        while stack:
            node, children = stack[-1]
            try:
                child = next(children)
            except StopIteration:
                stack.pop(); active.remove(node); done.add(node)
                continue
            if child in active:
                yield [x[0] for x in stack] + [child]
            elif child in graph and child not in done:
                active.add(child); stack.append((child, iter(graph[child])))
        remaining -= done


def validate_manifest(manifest):
    """Return scoped static findings; absence of errors never means runtime pass."""
    data = load_manifest(manifest)
    findings = []
    add = lambda *args: findings.append(_finding(*args))
    parameters = {x["name"]: x for x in data["parameters"]}
    modules = {x["id"]: x for x in data["modules"]}
    objects = {x["id"]: x for x in data["hierarchy"]}
    budget = parameter_budget(data)
    if not budget["within_budget"]:
        add("error", "parameter_budget", "Expression parameters", str(budget["used_bits"]) + " / 256 synchronized bits",
            "The declared synchronized layout exceeds the documented budget.", "Remove or make suitable private parameters unsynchronized after review.")
    for p in data["parameters"]:
        if p["name"] in BUILTIN_PARAMETERS and p["direction"] == "in":
            add("error", "builtin_readonly", p["name"], "VRChat built-in Animator parameter",
                "OSC cannot write this native VRChat state.", "Use an intentionally authored EYE input for manual intent and keep native state read-only.")
        if p["module"] and p["module"] not in modules:
            add("error", "missing_module", p["name"], p["module"], "The parameter has no supplied module owner.", "Include its module definition or correct its association.")
        if p["privacy"] == "private" and p["synced"]:
            add("error", "private_synced", p["name"], "private + Synced", "This authored channel can expose a private value through VRChat synchronization.", "Create a separate unsynchronized private channel; review any public derivative.")
        if p["saved"] and (p["ephemeral"] or p["action"]):
            add("error", "saved_transient", p["name"], "Saved ephemeral/action parameter", "A stale request or connection state could return after reload.", "Disable Saved for this transient parameter in the authored avatar.")
        if p["action"] and p["action"] not in data["actions"]:
            add("error", "undeclared_action", p["name"], p["action"], "The request is absent from the explicit manifest action vocabulary.", "Declare the supported action and review its local permission separately.")
        if p["action"] and (p["default"] != p["neutral"] or p["default"] not in (False, 0, 0.0)):
            add("error", "active_request_default", p["name"], "Request default is non-neutral", "Initialization could resemble an action request.", "Use a neutral zero/false request default and an explicit edge or latch handshake.")
        for field in ("validity", "acknowledgment"):
            ref = p[field]
            if ref and ref not in parameters:
                add("error", "missing_" + field, p["name"], ref, "Freshness or request feedback cannot be interpreted.", "Export the final emitted companion parameter or repair this mapping.")
            elif ref and field == "validity" and (parameters[ref]["type"] != "Bool" or parameters[ref]["direction"] != p["direction"]):
                add("error", "invalid_validity_contract", p["name"], ref, "Validity must be a Boolean traveling in the same direction.", "Use a distinct Boolean validity channel beside this reading.")
        if not p["semantic"]:
            add("information", "meaning_unspecified", p["name"], "No semantic meaning supplied", "Name matching alone cannot establish compatibility.", "Describe the value, unit, and unavailable behavior.")
    module_graph = {}
    for module in data["modules"]:
        module_graph[module["id"]] = module["dependencies"]
        for dependency in module["dependencies"]:
            if dependency not in modules:
                add("error", "missing_dependency", module["id"], dependency, "An installation prerequisite is missing.", "Supply the dependency before installation.")
        if data["platform"] not in module["platforms"] and "Generic" not in module["platforms"]:
            add("error", "unsupported_platform", module["id"], data["platform"], "This module does not declare support for the selected platform.", "Choose a supported variant or remove it at build time.")
        if len(module["menu_entries"]) > 8:
            add("warning", "menu_capacity", module["id"], str(len(module["menu_entries"])) + " proposed controls", "One Expressions Menu is limited to eight controls.", "Create reviewed submenus; do not overwrite existing entries.")
        for anchor in module["anchors"]:
            if anchor not in objects:
                add("error", "missing_anchor", module["id"], anchor, "Attachment placement cannot be inspected.", "Assign an authorized attachment object or manual socket.")
    for cycle in _cycles(module_graph):
        add("error", "dependency_cycle", cycle[0], " -> ".join(cycle), "The module installation order is cyclic.", "Remove the cycle or combine the tightly coupled modules explicitly.")
    for node in data["hierarchy"]:
        if node["parent"] and node["parent"] not in objects:
            add("warning", "missing_parent", node["id"], node["parent"], "The supplied hierarchy is incomplete.", "Export the selected subtree with its root parent empty.")
    for cycle in _cycles({x["id"]: [x["parent"]] if x["parent"] else [] for x in data["hierarchy"]}):
        add("error", "hierarchy_cycle", cycle[0], " -> ".join(cycle), "This hierarchy cannot represent a valid object tree.", "Re-export an acyclic authorized hierarchy snapshot.")
    owners = {}
    for binding in data["bindings"]:
        key = binding["object"], binding["property"]
        owners.setdefault(key, []).append(binding)
        module = modules.get(binding["module"])
        if not module or binding["object"] not in objects:
            add("error", "missing_binding_target", binding["object"], binding["module"], "A declared writer references an absent module or object.", "Include the authorized target and module metadata.")
        elif binding["object"] not in module["owned_objects"]:
            add("warning", "binding_outside_ownership", binding["object"], binding["property"] + " by " + binding["module"], "The module writes outside its declared owned objects.", "Review the integration boundary; isolate its visual object where possible.")
    for (obj, prop), bindings in owners.items():
        writers = {(x["module"], x["layer"]) for x in bindings}
        if len(writers) > 1:
            add("warning", "property_conflict", obj, prop + ": " + ", ".join(sorted(x + "/" + y for x, y in writers)),
                "Multiple declared writers may overwrite the same property.", "Inspect their layer/state conditions; this static overlap is not proof of a runtime failure.")
    adjacency = {}
    for route in data["routes"]:
        if route["source"] not in parameters or route["target"] not in parameters:
            add("error", "missing_route_endpoint", route["target"], route["source"], "The declared data flow cannot be resolved.", "Use final emitted parameter names.")
            continue
        adjacency.setdefault(route["source"], []).append(route["target"])
        if not route["public_approved"] and parameters[route["target"]]["synced"]:
            add("error", "unreviewed_public_route", route["target"], route["source"], "The route targets a synchronized channel without declared review.", "Withhold values by default and require separate local runtime consent.")
    # Follow indirect paths too; a private value may pass through a nominally public intermediate.
    for name, parameter in parameters.items():
        if parameter["privacy"] != "private":
            continue
        pending, seen = [name], {name}
        while pending:
            current = pending.pop()
            for target in adjacency.get(current, ()):
                if target in seen:
                    continue
                seen.add(target); pending.append(target)
                if parameters[target]["synced"]:
                    add("warning", "private_public_flow", target, "Private input " + name + " reaches a synchronized output",
                        "Even a transformed value may disclose information.", "Review the complete path and keep public permission separate from local use.")
    for cycle in _cycles(adjacency):
        add("warning", "signal_cycle", cycle[0], " -> ".join(cycle), "A feedback route may oscillate or retain stale state.", "Define arbitration, neutral state, and explicit timing before runtime testing.")
    rig = data["rig"]
    for name, object_id in rig["bones"].items():
        if object_id not in objects:
            add("warning", "missing_rig_object", name, object_id, "The bone mapping cannot be inspected.", "Export the relevant authorized rig subtree.")
    for socket in rig["sockets"]:
        if socket["object"] not in objects:
            add("error", "missing_socket", socket["id"], socket["object"], "The socket's anchor is absent.", "Assign a valid manual or rig anchor.")
        if any(x <= 0 for x in socket["scale"]):
            add("warning", "socket_scale", socket["id"], str(socket["scale"]), "A zero or mirrored socket scale may impair fit or controls.", "Inspect its generated transform; do not alter avatar proportions automatically.")
    add("not tested", "runtime_unverified", "Runtime behavior", "Imported " + data["stage"] + " evidence only",
        "Static checks do not verify worn build identity, visual effects, or action completion.", "Run selected live tests with explicit authorization and retain their observations.")
    if data["stage"] == "source":
        add("not tested", "generated_unverified", "Generated build", "Source stage manifest",
            "Build processors may rename, merge, or strip this contract.", "Export and validate the generated build separately before claiming final compatibility.")
    add("not tested", "animator_graph_unverified", "Animator state graphs", "Property binding summary only",
        "Transition reachability and every external writer are outside this manifest's evidence.", "Inspect authorized Unity controllers and perform scoped runtime tests.")
    return findings


def platform_parity(first, second):
    a, b = load_manifest(first), load_manifest(second)
    results = []
    if a["avatar_id"] != b["avatar_id"]:
        results.append(_finding("error", "different_avatar", "Platform comparison", a["avatar_id"] + " / " + b["avatar_id"],
            "These manifests identify different avatars.", "Select variants of the same intended avatar."))
    left = [p for p in a["parameters"] if p["name"] not in BUILTIN_PARAMETERS]
    right = [p for p in b["parameters"] if p["name"] not in BUILTIN_PARAMETERS]
    for index in range(max(len(left), len(right))):
        x = left[index] if index < len(left) else None
        y = right[index] if index < len(right) else None
        if x is None or y is None or (x["type"], x["synced"]) != (y["type"], y["synced"]):
            results.append(_finding("error", "platform_slot_type", "Expression slot " + str(index + 1),
                str((x and (x["name"], x["type"]), y and (y["name"], y["type"]))),
                "The complete expression layout differs in position, type, or synchronization; VRChat recommends sharing the same asset across platforms.", "Preserve the complete shared ordered layout across both generated builds."))
        elif x["name"] != y["name"] or x["semantic"] != y["semantic"]:
            results.append(_finding("warning", "platform_slot_meaning", "Expression slot " + str(index + 1), x["name"] + " / " + y["name"],
                "The same typed slot has different declared meanings or names.", "Confirm matching semantics; matching types alone do not establish intended behavior."))
    return results


def compare_manifests(first, second):
    """Semantic rows preserve old/new typed values, including defaults and privacy."""
    a, b = load_manifest(first), load_manifest(second)
    rows = []
    for field in ("avatar_id", "platform", "revision", "build_id", "stage", "toolkit_version", "rig", "capabilities", "actions", "bindings", "routes", "assets", "migrations"):
        if a[field] != b[field]:
            rows.append({"section": "context", "name": field, "change": "changed", "before": a[field], "after": b[field]})
    for section, key in (("parameters", "name"), ("modules", "id"), ("hierarchy", "id")):
        left, right = {x[key]: x for x in a[section]}, {x[key]: x for x in b[section]}
        for name in sorted(left.keys() | right.keys()):
            if name not in left or name not in right or left[name] != right[name]:
                rows.append({"section": section, "name": name, "change": "added" if name not in left else "removed" if name not in right else "changed",
                    "before": left.get(name), "after": right.get(name)})
    old_order = [(p["name"], p["type"], p["synced"]) for p in a["parameters"]]
    new_order = [(p["name"], p["type"], p["synced"]) for p in b["parameters"]]
    if old_order != new_order:
        rows.append({"section": "parameters", "name": "expression parameter order", "change": "changed", "before": old_order, "after": new_order})
    return copy.deepcopy(rows)


def installation_plan(existing, proposed):
    """Plan an append-only merge; no project files are modified by this function."""
    base, addition = load_manifest(existing), load_manifest(proposed)
    merged, changes, conflicts = copy.deepcopy(base), [], []
    if base["avatar_id"] != addition["avatar_id"] or base["platform"] != addition["platform"]:
        conflicts.append("Installation requires the same avatar and platform context.")
    for section, key in (("parameters", "name"), ("modules", "id"), ("hierarchy", "id")):
        known = {x[key]: x for x in merged[section]}
        for item in addition[section]:
            name = item[key]
            if name not in known:
                merged[section].append(copy.deepcopy(item)); known[name] = item
                changes.append({"section": section, "name": name, "change": "add"})
            elif known[name] != item:
                conflicts.append(section + " collision: " + name + "; review an explicit mapping or keep the existing definition.")
    for field in ("capabilities", "actions", "bindings", "routes", "assets", "migrations"):
        for item in addition[field]:
            if item not in merged[field]:
                merged[field].append(copy.deepcopy(item))
    old = parameter_budget(base)["used_bits"]
    budget = parameter_budget(merged)
    findings = validate_manifest(merged)
    conflicts.extend(x["code"] + ": " + x["affected"] for x in findings if x["severity"] == "error")
    return {"changes": changes, "conflicts": conflicts, "total_bits": budget["used_bits"],
        "incremental_bits": budget["used_bits"] - old, "can_install": not conflicts,
        "manifest": merged, "findings": findings,
        "scope": "Proposed data contract only; Unity asset changes require a reviewed owned installation."}
