# Development 21 validation

Final portable regression on frozen source: **5,160 passed and 1,059 subtests passed; zero failures or errors**, in 137.39 seconds. All **45 new cases** ran. There were 475 native-display skips, one deselected case and two inherited warnings. The external-socket guard blocked zero attempted external connections.

## Evidence

| Area | Verification |
|---|---|
| Scene inspection — 15 new cases | Real bounded GLB parser subprocess, normalized vertex colors, linear RGB multiplication, UV transforms, source mesh health, malformed typed output, unsupported texture-coordinate fallback and image-channel/UV inspection. |
| Association rules — 12 new cases | Real files and SQLite transactions; matching evidence, changed/revoked/new-conflicting rules, account isolation, atomic rollback, unchanged-only batch undo and preservation of later edits. |
| Profile history and settings — 11 new cases | Typed appearance/preferences, partial and older observations, per-field sources, filtering before pagination, ten-section selective/profile coverage, conditional undo, old bundle compatibility and exclusion of operating authority. |
| Headless workflows — 7 new cases | Inspector material isolation/zoom/privacy; enable rule → scan → receipt → revoke → undo and changed review context; history filter/detail; new settings controls. Existing related regressions also ran. |

## Reproducibility

- Python 3.12.14 executed the suite. All 620 Python source files parse with Python 3.10 grammar; this is syntax compatibility, not an executed Python 3.10 matrix.
- SOURCE_CHECKPOINT_MANIFEST.json records 665 runtime, test, launcher and source hashes. They all matched after the final run. No frozen source changed afterward.
- The complete 830-file Development 20 baseline remains independently byte-verified against its original ZIP. Every previous file path is retained; this release intentionally updates affected source and current metadata.
- Baseline SHA-256: `87a3354528a4c783804159ceafca0e99ca10c9ba87851288d8abbba3f367aee0`.
- The exclusive-create packager checks ZIP CRC and every archived member against source. The separate HTML build report records the final ZIP size, file count and SHA-256.
- This is runnable source with the existing Windows/Linux launchers. It contains no compiled application, signed installer, credentials, runtime profile, test caches or supplied utility/mod binaries.

## Environment limits

All 475 skipped tests report a missing Tk display. No native display or Xvfb is available. Native Windows/Linux layout, keyboard, high contrast, large text, tray and render performance, plus live VRChat/CDN, installed VPM/Unity/AssetRipper, SteamVR and power-loss acceptance remain open. Headless callback checks do not substitute for these gates.

The inherited portable exclusions were retained without expansion:

- `tests/test_media_mpris_bus_121.py`
- `tests/test_session_secret_service_protocol.py`
- `tests/test_peer_transport.py`
- `tests/test_networking_integration.py`
- `tests/test_osc_transport.py`
- `tests/test_osc_discovery.py`
- `tests/test_osc_simulator.py`
- `tests/test_avatar_link.py`
- `tests/test_avatar_osc.py`
- `tests/test_avatar_creator_app.py`
- `tests/test_rangefinder.py`
- `tests/test_camera_capture.py`
- `tests/test_osc_avatar.py`

One individual deselection: `tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore`.

The two inherited warnings are the pytest TestListener constructor collection warning and a deliberate duplicate `VRChat.exe` ZIP fixture.

## Exact final command

```sh
PYTHONPATH=.:tests python3 -m pytest -q --tb=short -rf -p tools.offline_test_guard --durations=10 -o faulthandler_timeout=60 --ignore=tests/test_media_mpris_bus_121.py --ignore=tests/test_session_secret_service_protocol.py --ignore=tests/test_peer_transport.py --ignore=tests/test_networking_integration.py --ignore=tests/test_osc_transport.py --ignore=tests/test_osc_discovery.py --ignore=tests/test_osc_simulator.py --ignore=tests/test_avatar_link.py --ignore=tests/test_avatar_osc.py --ignore=tests/test_avatar_creator_app.py --ignore=tests/test_rangefinder.py --ignore=tests/test_camera_capture.py --ignore=tests/test_osc_avatar.py --deselect=tests/test_bridge_lab_sdk.py::test_native_unix_sdk_and_host_dispatch_then_observe_and_restore --junitxml=../release-dev21-tests.xml
```

BUILD_VALIDATION.json is the current machine-readable record; BASELINE_1_21_DEV20_VALIDATION.json preserves Development 20 unchanged.
