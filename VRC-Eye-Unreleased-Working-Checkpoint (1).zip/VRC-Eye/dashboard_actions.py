"""Fixed, local navigation targets. Dashboard rows never authorize a mutation."""
import time
from companion_data import Entity,entity_id
from account_header import boundary,private
from native_library import scope


def context(app):
    from session_restore import offline
    return boundary(app),private(app),offline(app)


def workspace(app):
    client=getattr(app,'api',None)
    return scope(getattr(client,'user_id','') if getattr(client,'authenticated',False) else 'shared')


def freshness(projection,*,offline=False,now=None):
    if not projection or not projection.get('checked'):return 'Waiting for a dashboard snapshot'
    age=max(0,int((time.time() if now is None else now)-projection['checked']))
    state='Offline' if offline else 'Stale display' if age>15 else 'Display updated'
    return f'{state} · {age}s ago · row sources may be historical'


def open_target(page,target,token,account,*,action='open'):
    if context(page.app)!=token or private(page.app) or workspace(page.app)!=account:
        raise ValueError('Account, privacy or connection mode changed. Wait for refreshed Home rows.')
    if not isinstance(target,dict):raise ValueError('This summary has no individual item to open.')
    kind=target.get('kind');ref=target.get('id');shell=page.shell
    if kind in ('friend','user','world','avatar','group'):
        entity_id(kind,ref)
        if action=='notes':
            from shared_notes_ui import show
            return show(shell,kind,ref,account=account)
        if (action=='profile' or kind in ('friend','user')) and not token[2]:
            return page.profile(Entity(kind,ref,target.get('name',ref)))
        from native_saved_details import show
        return show(shell,kind,ref)
    if action!='open':raise ValueError('Notes/profile actions apply only to an entity row.')
    if kind=='log':
        log=getattr(shell,'log',None)
        if not log or log.generation!=target.get('generation'):raise ValueError('The log source changed. Refresh Home.')
        if not any(r.serial==ref for r in log.items):raise ValueError('That log line has rolled out of the retained view.')
        shell.show('Game Log');owner=shell.pages['Game Log'];owner.select_entry(ref,target['generation']);return
    if kind=='notification':
        from native_events import hub_for
        from native_inbox_ui import UnifiedInbox
        family=target.get('family')
        if not any(r['id']==ref and r['api_family']==family and not r.get('deleted') for r in hub_for(shell).project()['notifications']):
            raise ValueError('That notification was removed or is no longer in this account.')
        shell.show('Social');owner=shell.pages['Social'];owner.require_revealed()
        inbox=next(p for p in owner.native_panels if isinstance(p,UnifiedInbox))
        inbox.query.set('');inbox.unread.set(False);inbox.render()
        key=next((k for k,r in inbox.table.records.items() if r[0]==family and r[1]['id']==ref),None)
        if key is None:raise ValueError('The notification changed. Refresh the Inbox.')
        owner.tabs.select(owner.frames['Inbox']);inbox.table.tree.selection_set(key);inbox.table.tree.see(key);inbox.selection()
        inbox.status.set('Selected from Home. Choose an action here to fetch current evidence and review it.')
        return
    if kind=='photo':
        shell.show('Photos');owner=shell.pages['Photos'];owner.revealed()
        if not owner.store.get(owner.scope,ref):raise ValueError('This photo is no longer in the current workspace.')
        owner.select(ref);return
    if kind=='project':
        shell.show('Creator Projects');owner=shell.pages['Creator Projects'];record=owner.store.get(ref)
        if not record:raise ValueError('The saved project was removed.')
        owner.selected_id=ref;owner.show_record(record);return
    if kind=='release':
        route='VCC Downloads' if target.get('source','').startswith('vcc') else 'SDK Downloads'
        shell.show(route);owner=shell.pages[route];owner.refresh_history()
        key=next((k for k,r in owner.history.records.items() if r['id']==ref),None)
        if key is None:raise ValueError('This download receipt was removed.')
        owner.tabs.select(owner.frames['Downloads & Activity']);owner.history.tree.selection_set(key);owner.history.tree.see(key);owner.history_selection();return
    if kind=='transfer':
        from transfer_center_ui import show
        return show(shell,select=ref)
    raise ValueError('This row has no supported contextual action.')
