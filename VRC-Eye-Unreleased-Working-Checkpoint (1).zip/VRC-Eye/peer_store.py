"""Bounded, separate local storage for VRC Eye Peer Services.

Construction performs local SQLite operations only. Explicitly saved personal items
are separate from optional conversation history. No connection tokens are stored.
"""
from __future__ import annotations
import json
import sqlite3
import threading
from pathlib import Path

MAX_JSON = 131072
MAX_ITEMS = 1000
MAX_HISTORY = 2000


def _json(value):
    text = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
    if len(text.encode('utf-8')) > MAX_JSON:
        raise ValueError('Peer record is too large.')
    return text


class PeerStore:
    def __init__(self, path=None):
        self.path = Path(path) if path is not None and str(path) != ":memory:" else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.db = sqlite3.connect(str(self.path) if self.path else ':memory:', check_same_thread=False)
        self.db.execute('PRAGMA busy_timeout=1000')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS peer_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS peer_items(id TEXT PRIMARY KEY, kind TEXT NOT NULL,
            value TEXT NOT NULL, updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS peer_history(id TEXT PRIMARY KEY, peer TEXT NOT NULL,
            value TEXT NOT NULL, updated REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS peer_receipts(id TEXT PRIMARY KEY, peer TEXT NOT NULL,
            value TEXT NOT NULL, updated REAL NOT NULL);
        ''')
        self.db.commit()
        self.closed = False

    def get(self, key, default=None):
        with self._lock:
            row = self.db.execute('SELECT value FROM peer_meta WHERE key=?', (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row[0])
        except (ValueError, TypeError):
            return default

    def set(self, key, value):
        encoded = _json(value)
        with self._lock, self.db:
            self.db.execute('INSERT INTO peer_meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, encoded))

    def items(self, kind=None):
        with self._lock:
            if kind is None:
                rows = self.db.execute('SELECT value FROM peer_items ORDER BY updated DESC LIMIT ?', (MAX_ITEMS,)).fetchall()
            else:
                rows = self.db.execute('SELECT value FROM peer_items WHERE kind=? ORDER BY updated DESC LIMIT ?', (kind, MAX_ITEMS)).fetchall()
        result = []
        for row in rows:
            try:
                result.append(json.loads(row[0]))
            except ValueError:
                continue
        return result

    def item(self, identifier):
        with self._lock:
            row = self.db.execute('SELECT value FROM peer_items WHERE id=?', (identifier,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_item(self, item):
        encoded = _json(item)
        with self._lock, self.db:
            exists = self.db.execute('SELECT 1 FROM peer_items WHERE id=?', (item['id'],)).fetchone()
            count = self.db.execute('SELECT count(*) FROM peer_items').fetchone()[0]
            if not exists and count >= MAX_ITEMS:
                raise ValueError('Local item limit reached; export or delete older items first.')
            self.db.execute('INSERT INTO peer_items VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,value=excluded.value,updated=excluded.updated', (item['id'], item['kind'], encoded, item['updated_at']))
        return item

    def delete_item(self, identifier):
        with self._lock, self.db:
            return bool(self.db.execute('DELETE FROM peer_items WHERE id=?', (identifier,)).rowcount)

    def history(self):
        with self._lock:
            rows = self.db.execute('SELECT value FROM peer_history ORDER BY updated DESC LIMIT 200').fetchall()
        return [json.loads(row[0]) for row in reversed(rows)]

    def save_history(self, item):
        encoded = _json(item)
        with self._lock, self.db:
            self.db.execute('INSERT INTO peer_history VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value,updated=excluded.updated', (item['message_id'], item['peer_id'], encoded, item['created_at']))
            self.db.execute('DELETE FROM peer_history WHERE id NOT IN (SELECT id FROM peer_history ORDER BY updated DESC LIMIT ?)', (MAX_HISTORY,))

    def clear_history(self, peer=None):
        with self._lock, self.db:
            if peer is None:
                self.db.execute('DELETE FROM peer_history')
                self.db.execute('DELETE FROM peer_receipts')
            else:
                self.db.execute('DELETE FROM peer_history WHERE peer=?', (peer,))
                self.db.execute('DELETE FROM peer_receipts WHERE peer=?', (peer,))

    def receipt(self, identifier, peer, value, at):
        encoded = _json(value)
        with self._lock, self.db:
            self.db.execute('INSERT OR IGNORE INTO peer_receipts VALUES(?,?,?,?)', (identifier, peer, encoded, at))
            self.db.execute('DELETE FROM peer_receipts WHERE id NOT IN (SELECT id FROM peer_receipts ORDER BY updated DESC LIMIT ?)', (MAX_HISTORY,))

    def receipts(self):
        with self._lock:
            rows = self.db.execute('SELECT value FROM peer_receipts ORDER BY updated DESC LIMIT ?', (MAX_HISTORY,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def close(self):
        with self._lock:
            if not self.closed:
                self.closed = True
                self.db.close()
