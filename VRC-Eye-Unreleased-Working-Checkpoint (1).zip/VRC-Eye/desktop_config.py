"""Reviewed updates of one selected VRChat config, preserving unknown fields."""
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import tempfile
import time
import uuid
from avatar_library_files import checked_stream,fingerprint
from creator_projects import assert_no_links,local_path
from vrchat_config import CONFIG_LIMIT,unique_object

FIELDS={'disableRichPresence':bool,'picture_output_split_by_date':bool,
        'picture_output_folder':str,'cache_directory':str,
        'cache_size':(30,102400),'cache_expiry_delay':(30,36500),
        'camera_res_width':(1280,7680),'camera_res_height':(720,4320),
        'screenshot_res_width':(1280,3840),'screenshot_res_height':(720,2160)}


def changes(value):
    if not isinstance(value,dict) or not value or set(value)-FIELDS.keys():raise ValueError('Choose supported configuration fields.')
    for key,item in value.items():
        rule=FIELDS[key]
        if item is None:continue # Explicit removal restores VRChat's default.
        if rule is bool and type(item) is not bool:raise ValueError(key+' must be true or false.')
        if rule is str and (not isinstance(item,str) or not 1<=len(item)<=4096 or any(ord(c)<32 for c in item)):
            raise ValueError(key+' must be a bounded path without control characters.')
        if isinstance(rule,tuple) and (type(item) is not int or not rule[0]<=item<=rule[1]):raise ValueError(f'{key} must be between {rule[0]} and {rule[1]}.')
    return value


def read(path):
    path=assert_no_links(local_path(path))
    if path.name!='config.json':raise ValueError('Select the exact VRChat config.json file.')
    assert_no_links(path.parent);info=path.parent.stat();parent=(info.st_dev,info.st_ino)
    try:
        with checked_stream(path,limit=CONFIG_LIMIT) as (_,stream,info):raw=stream.read(CONFIG_LIMIT+1);fp=fingerprint(info)
    except FileNotFoundError:raw=b'';fp=None
    if len(raw)>CONFIG_LIMIT:raise ValueError('Configuration exceeds 1 MiB.')
    try:data=json.loads(raw.decode('utf-8-sig'),object_pairs_hook=unique_object) if raw else {}
    except (UnicodeError,ValueError,RecursionError):raise ValueError('Invalid configuration JSON; no changes made.') from None
    if not isinstance(data,dict):raise ValueError('Expected a configuration object.')
    return path,raw,fp,parent,data


@dataclass(frozen=True)
class Review:
    nonce:str
    path:str
    before:bytes
    fingerprint:object
    parent:object
    after:bytes
    diff:tuple
    expires:float


class ConfigEditor:
    def __init__(self,*,clock=time.monotonic):self.clock=clock;self.reviews={}

    def prepare(self,path,values):
        changes(values);path,raw,fp,parent,data=read(path);diff=[]
        for key,value in values.items():
            diff.append((key,data.get(key,'<default>'),'<default>' if value is None else value))
            if value is None:data.pop(key,None)
            else:data[key]=value
        try:after=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
        except (ValueError,RecursionError):raise ValueError('Configuration cannot be safely serialized.') from None
        if len(after)>CONFIG_LIMIT:raise ValueError('Updated configuration exceeds 1 MiB.')
        review=Review(uuid.uuid4().hex,str(path),raw,fp,parent,after,tuple(diff),self.clock()+120)
        self.reviews={review.nonce:review};return review

    def commit(self,review,check=lambda:None):
        if self.reviews.pop(review.nonce,None) is not review or self.clock()>review.expires:raise ValueError('Review expired or already used.')
        check();path,raw,fp,parent,_=read(review.path)
        if (raw,fp,parent)!=(review.before,review.fingerprint,review.parent):raise ValueError('Configuration changed. Review again.')
        backup=path.with_name('config.eye-backup-'+review.nonce+'.json')
        with backup.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        temporary=None
        try:
            fd,temporary=tempfile.mkstemp(prefix='.eye-config-',dir=path.parent)
            with os.fdopen(fd,'wb') as stream:stream.write(review.after);stream.flush();os.fsync(stream.fileno())
            check();_,current,current_fp,current_parent,_=read(path)
            if (current,current_fp,current_parent)!=(raw,fp,parent):raise ValueError('Configuration changed before publication. Backup retained.')
            os.replace(temporary,path);temporary=None
            return dict(path=str(path),backup=str(backup),before=sha256(raw).hexdigest(),after=sha256(review.after).hexdigest(),
                        state='Saved; restart VRChat to apply documented configuration changes')
        finally:
            if temporary:
                try:os.unlink(temporary)
                except OSError:pass

    def prepare_restore(self,receipt):
        path,raw,fp,parent,_=read(receipt['path'])
        if sha256(raw).hexdigest()!=receipt['after']:raise ValueError('Configuration changed since this edit; restoration would overwrite newer changes.')
        with checked_stream(receipt['backup'],limit=CONFIG_LIMIT) as (_,stream,_):before=stream.read(CONFIG_LIMIT+1)
        if sha256(before).hexdigest()!=receipt['before']:raise ValueError('Backup changed; restoration refused.')
        # An originally absent configuration is restored as an empty object,
        # with the difference stated in the review rather than deleting a file.
        after=before or b'{}\n'
        review=Review(uuid.uuid4().hex,str(path),raw,fp,parent,after,(('Entire selected file','Current edit','Verified previous bytes or empty configuration'),),self.clock()+120)
        self.reviews={review.nonce:review};return review
