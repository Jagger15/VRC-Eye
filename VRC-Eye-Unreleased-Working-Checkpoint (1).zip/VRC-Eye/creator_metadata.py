"""Pure local metadata preparation, recognition, and conflict review.

Author recognition is presentation context only. This module never authorizes a
remote write; exported drafts are for review in VRChat's supported editor route.
Default limits bound local storage and are not claimed to be service limits.
"""
import json
import re
from creator_store import json_copy


DESCRIPTION_SECTIONS = ("controls", "accessibility", "known_limitations", "credits",
                        "update_notes", "playtest_instructions")
SECTION_LABELS = {"controls": "Controls", "accessibility": "Accessibility",
                  "known_limitations": "Known limitations", "credits": "Credits",
                  "update_notes": "Update notes", "playtest_instructions": "Playtest instructions"}
LOCAL_LIMITS = {"name": 200, "description": 20000, "tags": 32, "tag_length": 100, "capacity": 10000}
EDITABLE_FIELDS = ("name", "description", "tags", "capacity", "recommended_capacity")
_MISSING = object()
_USER = re.compile(r"usr_[A-Za-z0-9][A-Za-z0-9_-]{0,127}\Z")


def normalize_tags(tags):
    if isinstance(tags, str):
        tags = tags.split(",")
    if not isinstance(tags, list):
        raise ValueError("Creator tags must be a list or comma-separated text.")
    cleaned, seen = [], set()
    for value in tags:
        if not isinstance(value, str):
            raise ValueError("Each creator tag must be text.")
        value = " ".join(value.strip().split())
        if not value:
            continue
        if any(ord(character) < 32 for character in value):
            raise ValueError("Creator tags cannot contain control characters.")
        if value.casefold() not in seen:
            seen.add(value.casefold())
            cleaned.append(value)
    return cleaned


def validate_draft(draft, limits=None):
    clean = json_copy(draft)
    bounds = dict(LOCAL_LIMITS)
    if limits is not None:
        if not isinstance(limits, dict) or set(limits) - set(bounds):
            raise ValueError("Unknown destination constraint.")
        for key, value in limits.items():
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= LOCAL_LIMITS[key]:
                raise ValueError("Invalid destination constraint for " + key + ".")
        bounds.update(limits)
    if "recommendedCapacity" in clean:
        if "recommended_capacity" in clean and clean["recommended_capacity"] != clean["recommendedCapacity"]:
            raise ValueError("Conflicting recommended capacity fields.")
        clean["recommended_capacity"] = clean.pop("recommendedCapacity")
    unknown = set(clean) - set(EDITABLE_FIELDS)
    if unknown:
        raise ValueError("These fields are not local metadata draft fields: " + ", ".join(sorted(unknown)) + ". Publication is a separate operation.")
    for field in ("name", "description"):
        if field in clean:
            if not isinstance(clean[field], str):
                raise ValueError(field.capitalize() + " must be text.")
            clean[field] = clean[field].replace("\r\n", "\n").replace("\r", "\n").strip()
            if field == "name" and not clean[field]:
                raise ValueError("A world name cannot be empty.")
            if len(clean[field]) > bounds[field]:
                raise ValueError(field.capitalize() + " exceeds the selected limit of " + str(bounds[field]) + " characters.")
            if any(ord(character) < 32 and character not in "\n\t" for character in clean[field]):
                raise ValueError(field.capitalize() + " contains unsupported control characters.")
    if "tags" in clean:
        clean["tags"] = normalize_tags(clean["tags"])
        if len(clean["tags"]) > bounds["tags"] or any(len(tag) > bounds["tag_length"] for tag in clean["tags"]):
            raise ValueError("Creator tags exceed the selected count or length limit.")
    for field in ("capacity", "recommended_capacity"):
        if field in clean:
            value = clean[field]
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= bounds["capacity"]:
                raise ValueError(field.replace("_", " ").capitalize() + " must be a positive whole number within the selected limit.")
    if "capacity" in clean and "recommended_capacity" in clean and clean["recommended_capacity"] > clean["capacity"]:
        raise ValueError("Recommended capacity cannot exceed configured maximum capacity.")
    return clean


def _field_values(before, after):
    result = {"before": None if before is _MISSING else before,
              "after": None if after is _MISSING else after}
    if before is _MISSING or after is _MISSING:
        result.update(before_present=before is not _MISSING, after_present=after is not _MISSING)
    return result


def _same(left, right):
    if left is _MISSING or right is _MISSING:
        return left is right
    return json.dumps(left, sort_keys=True) == json.dumps(right, sort_keys=True)


def metadata_diff(base, draft):
    base, draft = json_copy(base), json_copy(draft)
    return {field: _field_values(base.get(field, _MISSING), draft.get(field, _MISSING))
            for field in sorted(set(base) | set(draft))
            if not _same(base.get(field, _MISSING), draft.get(field, _MISSING))}


def three_way_merge(base, draft, latest):
    """Merge independent field edits; retain latest for unresolved conflicts.

    A missing field is deletion, distinct from a field whose value is null.
    This local comparison is not an atomic remote-write guarantee.
    """
    base, draft, latest = json_copy(base), json_copy(draft), json_copy(latest)
    merged, conflicts = {}, {}
    for field in sorted(set(base) | set(draft) | set(latest)):
        old, edited, current = (values.get(field, _MISSING) for values in (base, draft, latest))
        if _same(edited, old):
            selected = current
        elif _same(current, old) or _same(edited, current):
            selected = edited
        else:
            selected = current
            conflict = {"base": None if old is _MISSING else old,
                        "draft": None if edited is _MISSING else edited,
                        "latest": None if current is _MISSING else current}
            if _MISSING in (old, edited, current):
                conflict.update(base_present=old is not _MISSING,
                                draft_present=edited is not _MISSING,
                                latest_present=current is not _MISSING)
            conflicts[field] = conflict
        if selected is not _MISSING:
            merged[field] = selected
    return {"merged": merged, "conflicts": conflicts}


def editable_metadata(document):
    """Separate draft fields from identity/publication and service classifications.

    API creator tags use author_tag_ labels. Other returned tags remain read-only;
    an explicit authorTags field also supplies creator labels when available.
    """
    document = json_copy(document)
    draft = {key: document[key] for key in ("name", "description", "capacity")
             if key in document and document[key] is not None}
    if document.get("recommendedCapacity") is not None:
        draft["recommended_capacity"] = document["recommendedCapacity"]
    elif document.get("recommended_capacity") is not None:
        draft["recommended_capacity"] = document["recommended_capacity"]
    if isinstance(document.get("authorTags"), list):
        draft["tags"] = normalize_tags(document["authorTags"])
    elif isinstance(document.get("tags"), list):
        draft["tags"] = normalize_tags([tag[len("author_tag_"):] for tag in document["tags"]
                                       if isinstance(tag, str) and tag.startswith("author_tag_")])
    return draft


def classification_tags(document):
    if not isinstance(document, dict) or not isinstance(document.get("tags", []), list):
        raise ValueError("World classifications must come from a metadata object.")
    return [tag for tag in document.get("tags", [])
            if isinstance(tag, str) and not tag.startswith("author_tag_")]


def build_description(sections):
    if not isinstance(sections, dict) or set(sections) - set(DESCRIPTION_SECTIONS):
        raise ValueError("Choose supported description sections.")
    parts = []
    for key in DESCRIPTION_SECTIONS:
        value = sections.get(key, "")
        if not isinstance(value, str):
            raise ValueError("Description sections must contain text.")
        if value.strip():
            parts.append(SECTION_LABELS[key] + "\n" + value.strip())
    return validate_draft({"description": "\n\n".join(parts)})["description"]


def description_warnings(text, build_label=None):
    if not isinstance(text, str):
        raise ValueError("Description must be text.")
    warnings = []
    if re.search(r"\{\{[^}]+\}\}|\[(?:TODO|TBD|INSERT|REPLACE|PLACEHOLDER)[^]]*\]|\b(?:TODO|TBD|FIXME)\b", text, re.I):
        warnings.append("The description contains unfinished placeholders.")
    normalized = [line.strip().rstrip(":").lstrip("# ").casefold() for line in text.splitlines()]
    for label in SECTION_LABELS.values():
        if normalized.count(label.casefold()) > 1:
            warnings.append("Repeated description heading: " + label + ".")
    if re.search(r"\b(?:test[- ]build|playtest[- ]only|temporary test|do not publish)\b", text, re.I):
        warnings.append("Review the test-build notice before using this description for a release.")
    if build_label and not isinstance(build_label, str):
        raise ValueError("The selected build label must be text.")
    if build_label and re.search(r"\b(?:version|build)\s+[\w.-]+", text, re.I) and build_label.casefold() not in text.casefold():
        warnings.append("A version or build is mentioned, but the selected build label is absent; check whether the description is current.")
    return warnings


def recognize_creator(account_id, author_id, *, fresh=False, local_project=False, collaborator=False):
    valid_account = isinstance(account_id, str) and bool(_USER.fullmatch(account_id))
    valid_author = isinstance(author_id, str) and bool(_USER.fullmatch(author_id))
    match = bool(valid_account and valid_author and account_id == author_id)
    if local_project:
        state, label = "local_project", "Local project creator"
        reason = "This is an explicitly local project; no publishing-account authority is inferred."
    elif match:
        state = "confirmed_author" if fresh else "cached_author"
        label = "Confirmed author match" if fresh else "Previously recognized author"
        reason = "Stable account and author IDs match" + (" through current information." if fresh else " in cached information; revalidation is needed.")
    elif collaborator:
        state, label = "collaborator", "Collaborator / tester"
        reason = "Local workspace access does not identify this account as the publisher."
    elif valid_account and valid_author:
        state, label = "not_author", "Not the author"
        reason = "The current account and the recorded publishing account differ."
    else:
        state, label = "unresolved", "Unresolved"
        reason = "A reliable active account or world author ID is unavailable."
    return {"state": state, "label": label, "reason": reason, "author_match": match,
            "authorized": False}


def prepare_metadata_record(base, draft, latest=None, *, source="manual", checked_at=None, limits=None):
    """Keep all three versions and explicit draft state for review/export."""
    clean = validate_draft(draft, limits)
    base = json_copy(base)
    latest = json_copy(base if latest is None else latest)
    result = three_way_merge(base, clean, latest)
    return {"base": base, "draft": clean, "latest": latest, "merged": result["merged"],
            "conflicts": result["conflicts"], "diff": metadata_diff(latest, result["merged"]),
            "state": "Not submitted", "source": str(source)[:100], "checked_at": checked_at,
            "destination": "Review in the official editing interface or a supported Unity SDK integration.",
            "constraint_source": "Supplied destination rules" if limits is not None else "Local safety bounds; verify current destination limits",
            "conflict_guarantee": "Local field comparison only; no atomic remote update was performed."}
