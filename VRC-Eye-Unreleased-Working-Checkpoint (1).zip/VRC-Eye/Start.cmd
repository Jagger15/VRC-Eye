@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0.recovery-env\Scripts\python.exe" (
    "%~dp0.recovery-env\Scripts\python.exe" -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 goto local_python
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 goto python_launcher
)
where python >nul 2>nul
if not errorlevel 1 (
    python -c "import sys, tkinter; assert sys.version_info >= (3, 10)" >nul 2>nul
    if not errorlevel 1 goto system_python
)
echo VRC Eye needs Python 3.10 or newer with Tkinter.
echo Install Python for Windows from https://www.python.org/downloads/windows/
echo Keep the Tcl/Tk option enabled, then run Start.cmd again.
echo Feature packages are prepared automatically when VRC Eye starts.
pause
exit /b 1
:local_python
"%~dp0.recovery-env\Scripts\python.exe" "%~dp0bootstrap.py" %*
goto finished
:python_launcher
py -3 "%~dp0bootstrap.py" %*
goto finished
:system_python
python "%~dp0bootstrap.py" %*
:finished
set "VRC_EYE_EXIT=%ERRORLEVEL%"
if not "%VRC_EYE_EXIT%"=="0" pause
exit /b %VRC_EYE_EXIT%
