# ARC and VRCX functions still incomplete in VRC Eye Development 13

Date: 4 October 2026. Baselines: supplied VRCX **2026.09.16** source and the supplied ARC package, main **1.41.3.112**, Core **1.0.4.0**, using the retained static review. This is a disposition of all **106 tracked ARC/VRCX feature areas** (82 VRCX, 24 ARC), not a claim to enumerate every hidden binary function or later upstream change.

## What Development 13 closes or improves

- **Scoped catalog metadata backfill (ARC-20): source implemented.** Reviewed background batches, missing/stale/selected field policies, optional thumbnails, shared API pacing, conflict preservation, durable item outcomes and reviewed restart continuation. Native/live acceptance remains. No unattended whole-catalog scheduler is claimed.
- **Profile history (VX-NATIVE-06): improved, still partial.** Structured before/after comparisons for supported supplied fields, field observation times, repeat suppression and a dedicated filtered view. Every historical schema and every producer/property are not covered.
- **File association (ARC-21): improved, still partial.** Bounded exact-byte duplicate/match discovery, explicit multi-candidate review and file health. Automatic association rules and bulk undo are still missing.
- **Job recovery (ARC-24): improved, still partial.** Metadata updates and item receipts now commit atomically; interrupted runs can be reviewed and continued. This does not supply resumable transfers or external recovery-process reconciliation.

| Classification | Areas |
|---|---|
| Source implemented; native/live acceptance open | 50 |
| Acceptance / provider prerequisite | 7 |
| Partial | 35 |
| Source-data limitation | 2 |
| Missing | 12 |

There are **47 areas classified as missing or partial**. Another nine have acceptance/provider prerequisites or source-data limits. Source implementation is not a claim that native Windows/Linux, live services, Unity or SteamVR acceptance has passed.

## Suggested next work

| Order | Follow-up | Concrete addition | Dependency / limit |
|---|---|---|---|
| 1 | ARC resumable transfers and recovery | Resume supported authorized downloads after interruption; bounded transient retries; visible pending/completed/uncertain outcomes. | ARC-22/23/24: persist transfer state and validate unchanged remote bytes/account/destination before resuming. Unsupported servers restart only after review. |
| 2 | VRCX dashboard consistency | Bring the remaining generic widgets up to the history tables: useful columns, sorting, consistent filters and saved layouts. | VX-DESK-01/02: extend existing widgets and projections; no new polling owner. |
| 3 | VRCX unified notes | Reconcile legacy note editors and canonical annotations, preserving conflicts and account scope. | VX-MIG-14: define one owner per note and review existing duplicates. |
| 4 | ARC recovery provider integration | Select a qualified AssetRipper version and connect staged recovery, progress, cancellation and editor handoff. | ARC-07/08/09/24: verify the exact provider interface, process lifecycle and output evidence first. |
| 5 | ARC richer avatar preview | Actual textured model inspection, then rigs/blendshapes, then animation playback. | ARC-01 through ARC-06: a qualified scene parser/viewer is the prerequisite; current OBJ geometry is not a full Unity viewer. |
| 6 | VRCX Discord/VR interaction | Interactive join requests and configurable overlay notification/invite actions. | Native Discord/SteamVR acceptance and existing action permissions remain prerequisites. |

Automatic update installation is still a separate distribution milestone: Eye needs its own feed/signing keys and a platform-tested installer/rollback path. It must not consume VRCX release binaries as Eye updates.

## ARC — all 24 tracked areas

| ID | Function | State | Existing scope | What remains |
|---|---|---|---|---|
| ARC-01 | Isolated avatar provider contract and lifecycle | Missing | OBJ preview and manual source-project inspection are available. | Qualified, isolated rich-avatar viewer/parser provider with bounded IPC, version checks, resource limits and proven host containment. |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing | Bundle preservation/header inspection is not scene decoding. | Decode authorized VRCA/Unity bundles into actual mesh/material/rig/animation scene data; supported-version and missing-dependency reporting. |
| ARC-03 | Authorized FBX import and scene inspection | Missing | Selected OBJ geometry is supported. | FBX import/scene inspection including axes, units, importer settings, takes and external dependency handling. |
| ARC-04 | Actual material and texture viewer | Missing | OBJ uses flat shading/wireframe; it does not load textures. | Actual material/submesh assignments, texture and alpha display, UV channels, typed shader properties and rendered shader fallbacks. |
| ARC-05 | Rig, skinning and blendshape viewer | Missing | Creator-declared hierarchy and a generic mannequin do not supply an actual rig. | Bone/bind-pose/influence inspection, skinned preview, reversible poses and blendshape controls. |
| ARC-06 | Clip, take and safe controller animation preview | Missing | Declared parameter/test workflows do not evaluate an actual Unity avatar. | Actual clip/take playback and scrubbing, speed/loop/root-motion controls and safe Animator/controller-subset preview. |
| ARC-07 | AssetRipper provider selection, version and provenance | Missing | Manual official-provider guidance and staged input are available. | Selected AssetRipper provider registry with exact executable/version/hash/platform/license/capability validation. |
| ARC-08 | Integrated user-owned recovery orchestration | Partial | User prepares a staging folder, runs the external GUI manually, then inspects output. | Integrated owned-process recovery/export orchestration with a verified exact-version interface, cancellation and child-process cleanup. |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial | Manual recovery handoff hashes and bounded output/project inspection exist. | Complete recovered-output manifests, dependency/loss reports, immutable raw-versus-repaired lineage and a reviewed automatic editor handoff. |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing | Generic creator validation is not the renderer-bounds repair workflow. | Compare real mesh/renderer/pose bounds and apply reviewed bounds corrections or margins to clones. |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing | No general mesh/importer settings copier is implemented. | Compatible mesh/renderer/importer setting transfer with typed diffs, fresh copies and controlled reimport policy. |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing | No actual rig/skinned-mesh optimizer is implemented. | Dependency-checked influence reduction, proven-unused bone removal and renderer consolidation with measured deformation comparisons. |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial | The experimental Unity source can duplicate a readable mesh and recalculate missing normals; no retopology/decimation/UV reconstruction. | Full topology/stream/index/tangent diagnostics and narrowly reviewed tangent repairs. |
| ARC-14 | Shader and material compatibility diagnostics | Partial | Read-only shader/package inventory and a selected shader-replacement copy exist. | Real shader/pipeline/platform compatibility, typed-property/keyword/texture-dependency analysis and measured compile availability. |
| ARC-15 | Typed material property mapping on copies | Partial | A single shader replacement on a copied material is not property migration. | Exact-shader-version mapping profiles and reviewed texture, offset/scale, color, number/vector, queue and keyword transfer. |
| ARC-16 | Reviewed shader package install and removal | Partial | Read-only shader inventories and generic project-copy package jobs exist. | Shader-specific install/remove planning with dependency review, post-operation compilation/diffs and change-aware removal journal. |
| ARC-17 | Animation and controller dependency repair copies | Partial | Experimental clip-copy binding-prefix remap exists; controllers remain unchanged. | Object-reference curve repairs, clip swaps and cloned Animator/override-controller dependency closure repair. |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial | Dev12 adds stable-ID declared hierarchy/component comparison; experimental copied-prefab missing-script removal already exists. | Actual serialized-asset/component dependency graph, allowlisted component copying and reference remapping on clones. |
| ARC-19 | General repair-copy journal and conditional rollback | Partial | Current copy-only operations and local reviews do not provide the entire cross-operation recovery contract. | One durable general repair-copy journal with source/dependency evidence, owned-output phases and conditional rollback across richer repairs. |
| ARC-20 | Scoped automated catalog metadata backfill | Source implemented; native/live acceptance open | Development 13 implements reviewed batches of 1–100 selected catalog entries: missing/stale/selected field policies, optional thumbnails, shared API pacing, per-field conflict checks, source/freshness evidence, atomic publication receipts, cancellation and reviewed restart continuation. | Native desktop/live-provider acceptance remains. No unattended whole-catalog schedule or automatic restart retry; the requested scoped batch workflow is implemented. |
| ARC-21 | Evidence-based automated local-file association | Partial | Development 13 adds bounded selected-folder SHA-256/size matching, duplicate groups, explicit multi-candidate association review, stable evidence checks and catalog file-health checks. | Separately enabled deterministic automatic association rules, scope-wide rule revocation and mass-association undo remain open. Matches reuse recorded associations and never prove ownership or semantic avatar identity. |
| ARC-22 | Opt-in resumable authorized transfers | Missing | Existing authorized downloads and local copies are retained; no general automatic resume claim. | Durable resumable partial transfers with strong validator/range support, fresh account/destination checks and complete final integrity verification. |
| ARC-23 | Explicit bounded transient retry policy | Missing | Automatic friend reconnection is a separate feature and does not complete this asset job policy. | Explicit opt-in bounded transient retry policy for these asset/recovery jobs, sharing backoff and the original approval lease. |
| ARC-24 | Durable job and publication crash reconciliation | Partial | Metadata updates now have durable per-item state, atomic catalog/result publication, prior-boot interruption display and freshly reviewed continuation. Existing local file/job receipts remain. | General crash reconciliation across partial transfers, source/output/process identities, external recovery/export phases and publication remains incomplete; metadata-job recovery does not complete those contracts. |

The optional Unity repair-copy source has not been compiled or exercised in Unity here. Declared hierarchy comparison, the generic mannequin and flat OBJ preview do not supply real skinned Unity avatar inspection.

## VRCX — remaining missing or partial functions

| ID | Function | What remains |
|---|---|---|
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | All other profile fields/producers, every historical source schema and unobserved changes remain outside coverage. Actual change times and hidden data cannot be reconstructed from snapshots. |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | General creator duplicate detection across asset/model content, complete historical asset-version acquisition and actual rollback remain missing. Exact local hashes do not establish equivalent avatars. |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Image approval has no verified endpoint in the pinned source. Ordering is limited to one complete unfiltered page of fewer than 100 images. |
| VX-MIG-01 | Versioned source contract inventory | Additional historical source-version adapters are not exhaustive. |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Requires rollback-journal stores. This does not erase physical logs/photos, original VRCX files, all creator/media stores or minimal action receipts. |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Independent live stores are not universally one atomic database. Profile snapshots can represent slightly different instants. |
| VX-MIG-14 | User, world and avatar memos plus account notes | Legacy note editors and canonical annotation editors remain separate; automatic bidirectional note synchronization is not implemented. |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Persistent custom-user-tag VRCX producer/export contract remains conditional. |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Additional individual display/date/sidebar preference mappings need explicit equivalent contracts. |
| VX-MIG-20 | Video, resource and auxiliary game-log history | All version-specific auxiliary payloads remain conditional. |
| VX-MIG-23 | Notification archives and invite message details | Exhaustive nested payloads across historical versions are not supported. |
| VX-MIG-25 | Print favorite references and conditional print metadata | Complete historical print metadata/export schemas remain conditional. |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Exhaustive legacy/cross-application formats are not claimed. |
| VX-MIG-28 | Saved searches, filters and portable views | No verified persisted VRCX saved-search producer was found; such migration remains conditional. |
| VX-MIG-29 | Native selective backup and complete restore | Original photos/Unity projects, protected login sessions, execution/network approvals and unrecognized stores are excluded. This is not every possible application store. |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Complete bidirectional VRCX roundtrip is not claimed; ID/CSV exports lose richer native relationships/history. |
| VX-DESK-01 | Shared dashboard projections | Every earlier runtime/log widget is not a common immutable subscription API. |
| VX-DESK-02 | Configurable dashboards and widget layouts | Generic status/media widgets do not offer the same sortable tabular semantics as history/photo/download rows. |
| VX-DESK-06 | Discord content, join controls and coexistence | Interactive Discord join-request acceptance is not implemented. Native Discord IPC and application registration remain user/environment prerequisites. |
| VX-DESK-08 | Opt-in crash recovery controller | Unattended private-instance rejoin and installed native crash/launch acceptance remain incomplete. |
| VX-DESK-15 | Tray/background and low-power operation | Native tray/startup/shutdown acceptance and comprehensive adaptive sensor/provider throttling remain. |
| VX-DESK-16 | Settings profiles, backup and rollback UX | History and undo cover ten desktop presentation/notification fields, not every setting store; protected secrets and source assets are not portable profile data. |
| VX-DESK-17 | Optional update channels and recoverable installation | Publisher endpoint, trusted signing keys, installer/update-channel implementation and native rollback acceptance remain missing. |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Live provider acceptance, broader providers and generalized playback-error correlation remain incomplete. |

**Overlay parity:** the retained shared SteamVR social overlay is read-only. Interactive notifications/invites and complete configurable overlay event/widget coverage remain incomplete. Desktop boards and the composer do not supply those VR interactions.

## Acceptance prerequisites and source-data limits

| ID | Area | Classification | Remaining check / limit |
|---|---|---|---|
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite | Native window, idle-event and Windows/Linux protected-vault acceptance remain. The lock is a UI privacy boundary, not disk encryption. |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite | Provider availability/access/terms and live metadata/image results need acceptance; no VRCX-only entitlement is assumed. |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation | Source groups absent from the selected database cannot be reconstructed. |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation | The source has no file fingerprint, so historical byte identity cannot be proven. No implicit path scans or roster matching. |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite | Installed protocol registration/focus/delivery requires native OS acceptance. |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite | The full prepared acceptance matrix, native Windows and release gates remain open. |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite | Native Discord application registration and Windows/Linux IPC acceptance remain required. |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite | Native launch/cleanup acceptance remains. No process-name killing, force-kill fallback or application-readiness claim. |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite | Installed zero-VRCX and coexistence acceptance remains; all parity gaps remain visible in this ledger. |

A transient upstream feature does not establish a persisted migration schema. The pinned source showed in-memory custom-tag behavior but no verified persistent custom-tag or saved-search producer for a migration adapter. Missing historical photo fingerprints and absent favorite-group records cannot be invented.

## Deliberately excluded ARC behavior

- ARC authentication/server-key dependence or importing ARC cookies; automatic uploading/reporting of local avatar caches.
- Private-asset access-control bypass, hotswap upload substitution or content/safety-filter bypass.
- Executing bundled old-mod programs merely because they were uploaded.
- Claiming omitted scripts, shader source or animation authoring history can be reconstructed from absent data.

These are dispositions, not promised future features. Reference programs and mods were not executed.

## Full 106-area disposition

| ID | Feature | Development 13 classification |
|---|---|---|
| VX-NATIVE-01 | One normalized event timeline and inbox state | Source implemented; native/live acceptance open |
| VX-NATIVE-02 | Account storage isolation and safe legacy migration | Source implemented; native/live acceptance open |
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite |
| VX-NATIVE-04 | Resilient friend live feed with bounded reconciliation | Source implemented; native/live acceptance open |
| VX-NATIVE-05 | Unified notifications including NotificationV2 | Source implemented; native/live acceptance open |
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Partial |
| VX-NATIVE-07 | Complete invitation responses | Source implemented; native/live acceptance open |
| VX-NATIVE-08 | Edit saved invitation messages | Source implemented; native/live acceptance open |
| VX-NATIVE-09 | Photo invitations and replies | Source implemented; native/live acceptance open |
| VX-NATIVE-10 | Complete own-profile editor | Source implemented; native/live acceptance open |
| VX-NATIVE-11 | Shared bounded image upload transport | Source implemented; native/live acceptance open |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | Partial |
| VX-NATIVE-13 | Everyday owned-world editor and publication | Source implemented; native/live acceptance open |
| VX-NATIVE-14 | Group details, membership and permission-aware navigation | Source implemented; native/live acceptance open |
| VX-NATIVE-15 | Group moderation and reviewed batch operations | Source implemented; native/live acceptance open |
| VX-NATIVE-16 | Group role management | Source implemented; native/live acceptance open |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Partial |
| VX-NATIVE-18 | Group calendars and event management | Source implemented; native/live acceptance open |
| VX-NATIVE-19 | Group creation, settings and ownership lifecycle | Source implemented; native/live acceptance open |
| VX-NATIVE-20 | Instant local entity search | Source implemented; native/live acceptance open |
| VX-NATIVE-21 | Manage VRChat favorite groups within service limits | Source implemented; native/live acceptance open |
| VX-NATIVE-22 | Complete native local collections and exports | Source implemented; native/live acceptance open |
| VX-NATIVE-23 | Group instances and explicit visit handoff | Source implemented; native/live acceptance open |
| VX-NATIVE-24 | VRChat gallery and account icon management | Source implemented; native/live acceptance open |
| VX-NATIVE-25 | Sticker and emoji management | Source implemented; native/live acceptance open |
| VX-NATIVE-26 | VRChat print browsing and publishing | Source implemented; native/live acceptance open |
| VX-NATIVE-27 | Inventory and cosmetic catalog browser | Source implemented; native/live acceptance open |
| VX-NATIVE-28 | Inventory consume, reward and supported equipment actions | Source implemented; native/live acceptance open |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite |
| VX-MIG-01 | Versioned source contract inventory | Partial |
| VX-MIG-02 | Consistent read-only SQLite and WAL acquisition | Source implemented; native/live acceptance open |
| VX-MIG-03 | Explicit source-account and destination-scope mapping | Source implemented; native/live acceptance open |
| VX-MIG-04 | Native entity, collections and annotation data model | Source implemented; native/live acceptance open |
| VX-MIG-05 | Provenance, immutable review and migration ledger | Source implemented; native/live acceptance open |
| VX-MIG-06 | Deterministic deduplication and field-level conflicts | Source implemented; native/live acceptance open |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Partial |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Partial |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation |
| VX-MIG-10 | Unify imported and existing native Favorites | Source implemented; native/live acceptance open |
| VX-MIG-11 | Bulk avatar observations integrated with AvatarLibrary | Source implemented; native/live acceptance open |
| VX-MIG-12 | World and user descriptive observations | Source implemented; native/live acceptance open |
| VX-MIG-13 | Local avatar tags with native editing and filtering | Source implemented; native/live acceptance open |
| VX-MIG-14 | User, world and avatar memos plus account notes | Partial |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Partial |
| VX-MIG-16 | Selected VRCX status preset import | Source implemented; native/live acceptance open |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Partial |
| VX-MIG-18 | Avatar-use aggregate history | Source implemented; native/live acceptance open |
| VX-MIG-19 | World visits, join/leave and portal event history | Source implemented; native/live acceptance open |
| VX-MIG-20 | Video, resource and auxiliary game-log history | Partial |
| VX-MIG-21 | Friend changes and social observation feeds | Source implemented; native/live acceptance open |
| VX-MIG-22 | Derived activity sessions and analytics provenance | Source implemented; native/live acceptance open |
| VX-MIG-23 | Notification archives and invite message details | Partial |
| VX-MIG-24 | Moderation observations and mutual graph snapshots | Source implemented; native/live acceptance open |
| VX-MIG-25 | Print favorite references and conditional print metadata | Partial |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Partial |
| VX-MIG-28 | Saved searches, filters and portable views | Partial |
| VX-MIG-29 | Native selective backup and complete restore | Partial |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Partial |
| VX-MIG-31 | Selective migration workspace and standalone native routes | Source implemented; native/live acceptance open |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite |
| VX-DESK-01 | Shared dashboard projections | Partial |
| VX-DESK-02 | Configurable dashboards and widget layouts | Partial |
| VX-DESK-03 | Unified notification delivery and focus rules | Source implemented; native/live acceptance open |
| VX-DESK-04 | Activity charts, heatmaps and history analysis | Source implemented; native/live acceptance open |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite |
| VX-DESK-06 | Discord content, join controls and coexistence | Partial |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite |
| VX-DESK-08 | Opt-in crash recovery controller | Partial |
| VX-DESK-09 | Reviewed join and last-instance recovery orchestration | Source implemented; native/live acceptance open |
| VX-DESK-10 | Automatic photo context association | Source implemented; native/live acceptance open |
| VX-DESK-11 | Optional compatible photo metadata output | Source implemented; native/live acceptance open |
| VX-DESK-12 | Photo organization, source moves and recovery | Source implemented; native/live acceptance open |
| VX-DESK-13 | Photo metadata index and richer gallery search | Source implemented; native/live acceptance open |
| VX-DESK-14 | VRChat service-health integration | Source implemented; native/live acceptance open |
| VX-DESK-15 | Tray/background and low-power operation | Partial |
| VX-DESK-16 | Settings profiles, backup and rollback UX | Partial |
| VX-DESK-17 | Optional update channels and recoverable installation | Partial |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Partial |
| VX-DESK-19 | Reviewed VRChat configuration and launch settings editor | Source implemented; native/live acceptance open |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite |
| ARC-01 | Isolated avatar provider contract and lifecycle | Missing |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing |
| ARC-03 | Authorized FBX import and scene inspection | Missing |
| ARC-04 | Actual material and texture viewer | Missing |
| ARC-05 | Rig, skinning and blendshape viewer | Missing |
| ARC-06 | Clip, take and safe controller animation preview | Missing |
| ARC-07 | AssetRipper provider selection, version and provenance | Missing |
| ARC-08 | Integrated user-owned recovery orchestration | Partial |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial |
| ARC-14 | Shader and material compatibility diagnostics | Partial |
| ARC-15 | Typed material property mapping on copies | Partial |
| ARC-16 | Reviewed shader package install and removal | Partial |
| ARC-17 | Animation and controller dependency repair copies | Partial |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial |
| ARC-19 | General repair-copy journal and conditional rollback | Partial |
| ARC-20 | Scoped automated catalog metadata backfill | Source implemented; native/live acceptance open |
| ARC-21 | Evidence-based automated local-file association | Partial |
| ARC-22 | Opt-in resumable authorized transfers | Missing |
| ARC-23 | Explicit bounded transient retry policy | Missing |
| ARC-24 | Durable job and publication crash reconciliation | Partial |

## Evidence and practical limits

- ARC_VRCX_GAP_LEDGER_DEV13.json records every area, remaining scope, source files and reference evidence.
- IMPLEMENTATION_STATUS_1_21.json retains the broader 160-area roadmap; the 106-area report selects ARC/VRCX packages.
- CATALOG_HISTORY_DEV13.md documents this batch; SESSION_TOOLS_DEV12.md retains the 25 mod-inspired proposal outcomes and optional extensions.
- VALIDATION_1_21.md reports executed checks and environment exclusions. Offline fixtures do not prove live entitlement, native rendering or upstream parity.
- Retained persistent login/sync, ordinary friend/group actions, notes/tags, saved filters and photo metadata are not listed as wholly missing.
- Primary implementation references: supplied VRCX source, retained static ARC review, and public community API repository https://github.com/vrchatapi/specification (community-maintained, not official service support).
