# Resume VRC Eye after Development 16

Use **VRC-Eye-v1.21.0-Development-16.zip** as the current source checkpoint.
It descends from the saved Development 15 archive, SHA-256
`aa691c5e93f91601e0ee786949df6bdfe72b698cd795340ad42c7b59cc5b4894`. Earlier continuation guides remain
historical. Do not start again from the parallel Development 14 recovery branch.

Keep `avatar_transfer_jobs.py` as the byte/range/publication owner. Its default
avatar behavior remains; `file_transfer_jobs.py` supplies scoped world/public
receipts, URL/suffix policy and persistent host cooldowns. The common
`transfer_center_ui.py` obtains fresh reviewed source closures from World backups
and SDK/VCC pages. Supplied-key decryption and Unity browser downloads retain
their original flows. No startup job resumes or process replay exists.

`assetripper_jobs.py` / `assetripper_ui.py` implement reviewed native-tool selection,
owned loopback API probing, staging/export/cancel/log phases and output inventory.
`avatar_recovery_provider.py` remains the manual preparation/output-inspection
owner. The managed UI uses a distinct execution review. Exact installed-release,
API, descendant cleanup, provider quality and Unity import acceptance remain open;
see ASSETRIPPER_PROVIDER_DEV16.md. An executable hash is not publisher verification.

`dashboard_actions.py` keeps Home targets as local fixed navigation. The table
retains stable identity/filter/column behavior. Notification targets carry API
family plus ID and navigate to existing action reviews. Snapshot age does not
assert source freshness. Shared notes remain owned by shared_notes.py and the
Development 15 player-session integration; roster filtering tags remain separate.

Final validation: **4,867 tests + 1,059 subtests passed**, 475
native-GUI cases skipped, one bridge case deselected, 13 transport modules excluded,
zero failures/errors and blocked external-socket attempts. New Development 16
coverage: 74 fixture/headless cases. Manifest: 619
source files; Python 3.10 grammar: 574 files. Exact command and
environment limits are in BUILD_VALIDATION.json.

The current 106-area ledger is ARC_VRCX_GAP_LEDGER_DEV16.json and its human report
ARC_VRCX_REMAINING_DEV16.md: 50 source implemented (native/live acceptance open),
38 partial, 9 missing, 7 prerequisites, 2 source-data limitations. The separate
160-package roadmap contains 50 source implemented, 69 partial and 41 pending.
Later suggested work remains: unified filtering tags, wider settings backup/undo,
a qualified scene viewer, general Unity repair journals, interactive Discord/VR,
and an independently qualified updater feed/installer/rollback contract.
