# 1.21.0 Development checkpoint 8 — validation

The final working source passed **4,519 portable tests and 1,059 subtests** in
108.10 seconds, with zero failures/errors and zero blocked external-socket
attempts. The 43 new deterministic tests exercise automatic sync lifecycle,
shared pacing and Retry-After, cancellation and sleep recovery, active-account
isolation, live/snapshot ordering, event formats, cache freshness, notification
patches/deletions/grouping, and real UI callbacks including action preflight.

The suite includes **473 skipped native GUI tests**, **one deselected Unix bridge
test**, and the same **13 excluded local-transport modules** as Development 7.
These exclusions are not passes. The environment cannot establish the virtual
X server's local listening sockets. Two pre-existing warnings concern a test
class constructor and an intentionally duplicated ZIP member.

All **526 Python files** pass Python 3.10 grammar checks; execution used
Python 3.12.14. The source manifest covers **575 files**. Shell syntax and
CLI version checks passed. All seven launchers and requirements are unchanged
from Development 7. Packaging verifies ZIP CRC, retention of all baseline paths,
manifest hashes and exact archive/source bytes. The full regression ran against
the final working source; no second full clean-extraction run is claimed. Runtime
code is unchanged after regression; release documentation was finalized afterward.

Native Windows/Linux GUI, credential vaults, tray, speech, SteamVR, and live
VRChat authentication/events/permissions remain unverified. The existing pipeline
token handshake is retained and still needs live acceptance. This is runnable
source, not a compiled executable or signed installer.

See [Development 8 changes](AUTOMATIC_SYNC_DEV8.md), [prior validation](VALIDATION_1_21_DEV7.md),
and `BUILD_VALIDATION.json` for the exact command and exclusions. VRCX package
counts remain 49 source-implemented / 33 partial; complete parity and the wider
roadmap are unfinished.
