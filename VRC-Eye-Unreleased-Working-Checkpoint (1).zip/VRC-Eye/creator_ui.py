"""Local-first World Creator notebook. Optional integrations stay explicit.

The tabs are built on selection so opening the ordinary World roster does not
open devices, fetch metadata, or allocate the creator's larger editors.
"""
from __future__ import annotations

from text_viewport import window_body

import json
from pathlib import Path
import sqlite3
import time
import uuid


TABS = ("Creator", "Metadata", "Builds", "Live Test", "Diagnostics", "Tasks", "History", "Controls")
REPORT_PROFILES = ("public", "collaborator", "private")

# Field definitions are also used for validation and are intentionally ordinary
# text/choice forms. Imported manifests are the only JSON-oriented input.
WORKSHEETS = {
    "note": ("Design note", (("title", "Title"), ("category", "Category", ("Design", "Polish", "Question", "Reminder")),
        ("body", "Note", "text"), ("subsystem", "Subsystem"), ("build_id", "Build ID"))),
    "issue": ("Issue / investigation", (("title", "Title"), ("status", "Status", ("Investigation", "Open", "Fix implemented", "Fix verified", "Accepted")),
        ("observed", "Observed behavior", "text"), ("expected", "Expected behavior", "text"),
        ("reproduction", "Reproduction conditions", "text"), ("affected_builds", "Affected builds", "list"),
        ("proposed_fix", "Proposed fix", "text"), ("verification", "Verification evidence", "text"), ("subsystem", "Subsystem"))),
    "recipe": ("Reproduction recipe", (("title", "Title"), ("preparation", "Starting conditions", "text"),
        ("steps", "Ordered human steps (one per line)", "lines"), ("expected", "Expected result", "text"),
        ("stop_conditions", "Stop conditions / timeouts", "text"), ("optional_branches", "Optional branches", "text"))),
    "profile": ("Test profile", (("title", "Title"), ("platform", "Target platform", ("Windows", "Android", "iOS", "Other")),
        ("environment", "Environment", ("Real client", "Build & Test", "ClientSim", "Editor")),
        ("conditions", "Requested conditions (one per line)", "lines"), ("route", "Route"), ("graphics", "Graphics settings"),
        ("avatar_conditions", "Avatar conditions"), ("target_fps", "Target FPS"), ("launch_options", "Launch settings / restart needed"),
        ("capture_sources", "Capture sources", "list"), ("diagnostic_overhead", "Logging / overlay overhead"))),
    "route": ("Zones / test route", (("title", "Route name"), ("zones", "Ordered named zones (one per line)", "lines"),
        ("preparation", "Starting conditions", "text"), ("expected", "Expected coverage", "text"), ("build_id", "Build ID"))),
    "accessibility": ("Accessibility audit", (("title", "Interaction"), ("condition", "Test condition (no diagnosis required)"),
        ("input", "Input method"), ("expected", "Expected outcome", "text"), ("observed", "Observed outcome", "text"),
        ("status", "Result", ("Not started", "Passed", "Failed", "Blocked", "Needs verification")), ("release_blocking", "Release blocking", ("No", "Yes")))),
    "persistence": ("Persistence case", (("title", "Case"), ("environment", "Storage environment", ("Uploaded world", "Build & Test", "ClientSim")),
        ("schema_version", "Expected schema version"), ("case", "Scenario", ("New participant", "Returning participant", "Migration", "Missing optional value", "Interrupted initialization", "Isolated reset")),
        ("expected", "Expected restoration / types", "text"), ("observed", "Observed result (exclude saved values)", "text"), ("verified", "Verification", ("Unverified", "Verified", "Failed")))),
    "network_budget": ("Network budget", (("title", "Subsystem"), ("measurement", "Measurement", ("Serialization bytes", "Queue depth", "Update frequency", "Recovery time")),
        ("budget", "Creator budget"), ("unit", "Unit"), ("source", "Instrumentation source"), ("observed", "Observed range / period", "text"),
        ("reference", "Documented constraint and version", "text"))),
    "visual_comparison": ("Lighting / shader comparison", (("title", "Comparison"), ("build_id", "Build ID"), ("viewpoint", "Viewpoint / zone"),
        ("baseline", "Baseline preset"), ("candidate", "Changed preset"), ("conditions", "Controlled conditions", "text"),
        ("appearance", "Visual result", "text"), ("performance", "Measured performance evidence", "text"))),
    "dependency": ("Audio / video / dependency", (("title", "Dependency"), ("kind", "Type", ("Audio", "Video", "Remote text", "Image", "Other")),
        ("environment", "Environment"), ("state", "Observed state", ("Unknown", "Not requested", "Requested", "Blocked", "Loading", "Failed", "Ready")),
        ("restriction", "URL restriction condition"), ("fallback", "Expected graceful failure", "text"), ("observed", "Observed behavior", "text"))),
    "feedback": ("Tester feedback", (("title", "Title"), ("role", "Playtest role"), ("observed", "What happened", "text"),
        ("expected", "What was expected", "text"), ("action", "Action before the issue", "text"), ("repeated", "Repeated?", ("Unknown", "Once", "Repeated")),
        ("relationship", "Related issue", ("Unclassified", "Similar", "Related", "Duplicate confirmed")), ("evidence_ids", "Selected evidence IDs", "list"))),
    "assertion": ("Health assertion", (("title", "Assertion"), ("subsystem", "Subsystem"), ("scope", "Scope"), ("expected", "Expected state", "text"),
        ("grace_seconds", "Settling / grace seconds"), ("severity", "Failure severity", ("info", "warning", "error")),
        ("budget", "Sampling / cost budget"), ("evidence", "Selected evidence", "text"))),
    "failure_test": ("Controlled failure case", (("title", "Case"), ("adapter", "Owned adapter / test helper"),
        ("failure", "Controlled failure condition", "text"), ("expected_recovery", "Expected recovery", "text"),
        ("timeout", "Time bound"), ("stop_conditions", "Stop conditions", "text"), ("observed", "Observed recovery", "text"))),
    "known_issue": ("Known issue knowledge base", (("title", "Issue"), ("signature", "Error signature"), ("affected_builds", "Affected builds", "list"),
        ("reproduction", "Reproduction", "text"), ("cause", "Cause and confidence", "text"), ("attempts", "Fix attempts", "text"),
        ("verified_test", "Verified test / evidence", "text"))),
    "asset": ("Asset / attribution", (("title", "Asset / package"), ("version", "Version"), ("owner", "Owner / author"),
        ("provenance", "Creator-provided provenance"), ("credits", "Credit text", "text"), ("license_note", "License review note", "text"), ("dependencies", "Dependencies", "list"))),
    "localization": ("Localization / onboarding", (("title", "Interaction / message"), ("language", "Language"),
        ("translation", "Translation / instruction", "text"), ("review", "Translation review", ("Not reviewed", "Reviewed", "Needs changes")),
        ("context_result", "In-context test", ("Untested", "Passed", "Failed", "Blocked")), ("first_time", "First-time / no-coaching observation", "text"))),
    "accepted_regression": ("Accepted regression", (("title", "Decision"), ("baseline_id", "Baseline run ID"), ("candidate_id", "Candidate run ID"),
        ("target", "Affected target"), ("reason", "Reason / tradeoff", "text"), ("evidence_ids", "Evidence IDs", "list"))),
    "release_requirement": ("Release requirement", (("title", "Requirement"), ("platform", "Required platform"),
        ("environment", "Required environment", ("Real client", "Build & Test", "ClientSim", "Editor")),
        ("test", "Essential test / assertion"), ("build_id", "Target build"), ("status", "Review", ("Untested", "Satisfied", "Blocked", "Accepted limitation")),
        ("evidence_ids", "Evidence IDs", "list"), ("limitations", "Known limitations", "text"))),
}

# Reuse the workflow model's record shapes so saved profiles, recipes and release
# requirements are usable by the guided runner and comparison engine.
from creator_workflows import WORKSHEETS as MODEL_WORKSHEETS, STEP_STATUSES, ISSUE_STATES
for _kind, _sheet in MODEL_WORKSHEETS.items():
    _fields = []
    for _key, _label, _type in _sheet["fields"]:
        _choice = STEP_STATUSES if _key == "status" else None
        if _key == "environment":
            _choice = ("Real client", "Build & Test", "ClientSim", "Editor")
        elif _key == "requirement_type":
            _choice = ("manual", "step", "platform_build", "issue")
        elif _key == "triage_state":
            _choice = ("New report", "Unresolved similarity", "Related report", "Confirmed duplicate")
        elif _key == "state" and _kind == "media":
            _choice = ("Unknown", "Not requested", "Requested", "Blocked", "Loading", "Failed", "Ready")
        _fields.append((_key, _label + (" (record ID)" if _key.endswith("_id") else ""), _choice or ("text" if _type == "multiline" else None)))
    WORKSHEETS[_kind] = (_sheet["label"], tuple(_fields))
WORKSHEETS["issue"] = ("Issue / investigation", (("title", "Title"), ("status", "Status", ISSUE_STATES),
    ("observed", "Observed behavior", "text"), ("expected", "Expected behavior", "text"),
    ("reproduction", "Reproduction conditions", "text"), ("proposed_fix", "Proposed fix", "text"),
    ("verification_run_id", "Completed retest record ID"), ("verification_step_id", "Passed retest step ID")))


def display_record(record):
    data = record.get("data", {})
    return str(data.get("title") or data.get("name") or data.get("label") or data.get("summary") or record["id"])


def field_value(value, field_type=None):
    if field_type in ("list", "lines") and isinstance(value, (list, tuple)):
        return ("\n" if field_type == "lines" else ", ").join(str(v) for v in value)
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, indent=2)
    return "" if value is None else str(value)


class CreatorPanel:
    def __init__(self, controller, notebook):
        self.controller, self.notebook = controller, notebook
        self.tk, self.ttk = controller.tk, controller.ttk
        self.pages, self.built, self.tables = {}, set(), {}
        self.table_rows = {}
        self.editors = {}
        self.inputs = {}
        self.closed = False
        self.workspace = ""
        self.active_tab = "Creator"
        self.last_refresh = 0.
        self.metadata_base, self.metadata_latest, self.metadata_conflicts = {}, {}, {}
        self.metadata_record_id = None
        self.metadata_world = ""
        self.report_preview = None
        self.control_review = None
        self.task_id = None
        self.summary = self.tk.StringVar(value="Creator workspace is local. Choose a world or create a project.")
        self.status = self.tk.StringVar(value="Private local workspace. Sharing and device connections are optional.")
        for name in TABS:
            page = self.ttk.Frame(notebook, padding=10)
            self.pages[name] = page
            notebook.add(page, text=name)
            self.ttk.Label(page, textvariable=self.summary, style="Accent.TLabel", wraplength=1050).pack(anchor="w", pady=(0, 6))
        notebook.bind("<<NotebookTabChanged>>", self.on_tab)

    def _call(self, function, *args, **kwargs):
        try:
            return function(*args, **kwargs)
        except (ValueError, OSError, RuntimeError, KeyError, TypeError, sqlite3.Error) as exc:
            self.announce(str(exc))
            return None

    def announce(self, text):
        self.status.set(str(text))
        if hasattr(self.controller, "announce"):
            self.controller.announce(str(text))

    def world(self):
        self.controller.refresh_context()
        world = self.controller.current_world()
        if not world:
            raise ValueError("Choose a world or create a local project in Creator first.")
        if self.workspace and world != self.workspace:
            self.refresh(force=True)
            raise ValueError("The workspace changed. Review the current form before saving.")
        return world

    def _button(self, parent, label, command):
        button = self.ttk.Button(parent, text=label, command=lambda: self._call(command))
        button.pack(side="left", padx=(0, 7), pady=3)
        return button

    def _bar(self, parent):
        result = self.ttk.Frame(parent)
        result.pack(fill="x", pady=3)
        return result

    def _note(self, parent, text):
        self.ttk.Label(parent, text=text, style="Muted.TLabel", wraplength=1020).pack(anchor="w", pady=(3, 6))

    def _field(self, parent, label, *, options=None, multiline=False, value="", width=40):
        row = self.ttk.Frame(parent)
        row.pack(fill="x", pady=3)
        self.ttk.Label(row, text=label, width=31).pack(side="left", anchor="n")
        if multiline:
            widget = self.tk.Text(row, height=4, width=width, wrap="word", undo=True)
            widget.pack(side="left", fill="x", expand=True)
            widget.insert("1.0", value)
            return widget
        variable = self.tk.StringVar(value=value)
        kind = self.ttk.Combobox if options is not None else self.ttk.Entry
        kwargs = {"values": tuple(options), "state": "readonly"} if options is not None else {}
        widget = kind(row, textvariable=variable, width=width, **kwargs)
        widget.pack(side="left", fill="x", expand=True)
        self.inputs[id(variable)] = widget
        if options and not value:
            variable.set(options[0])
        return variable

    def _text(self, parent, height=7):
        widget = self.tk.Text(parent, height=height, wrap="word", state="disabled")
        widget.pack(fill="both", expand=True, pady=5)
        return widget

    @staticmethod
    def _get(editor):
        try:
            return editor.get("1.0", "end-1c")
        except TypeError:
            return editor.get()

    @staticmethod
    def _set(editor, value, readonly=False):
        value = str(value)
        if hasattr(editor, "set"):
            editor.set(value)
        else:
            if readonly:
                editor.configure(state="normal")
            editor.delete("1.0", "end")
            editor.insert("1.0", value)
            if readonly:
                editor.configure(state="disabled")

    def _scroll(self, parent):
        shell = self.ttk.Frame(parent)
        shell.pack(fill="both", expand=True)
        canvas = self.tk.Canvas(shell, highlightthickness=0, height=440)
        canvas.pack(side="left", fill="both", expand=True)
        scroll = self.ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        scroll.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scroll.set)
        content = self.ttk.Frame(canvas)
        window = canvas.create_window((0, 0), window=content, anchor="nw")
        content.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, width=e.width))
        return content

    def _table(self, parent, key, columns, height=8, multiple=False):
        frame = self.ttk.Frame(parent)
        frame.pack(fill="both", expand=True, pady=5)
        tree = self.ttk.Treeview(frame, columns=tuple(c[0] for c in columns), show="headings",
                                 selectmode="extended" if multiple else "browse", height=height)
        tree.pack(side="left", fill="both", expand=True)
        for name, label, width in columns:
            tree.heading(name, text=label)
            tree.column(name, width=width, minwidth=60, stretch=True)
        scroll = self.ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        scroll.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scroll.set)
        self.tables[key] = tree
        return tree

    def _rows(self, key, rows):
        tree = self.tables[key]
        old = self.table_rows.get(key, {})
        current = {}
        for identity, values in rows:
            values = tuple(values)
            current[identity] = values
            if identity not in old:
                tree.insert("", "end", iid=identity, values=values)
            elif old[identity] != values:
                tree.item(identity, values=values)
        removed = [identity for identity in old if identity not in current]
        if removed:
            tree.delete(*removed)
        self.table_rows[key] = current

    def _choices(self, variable, values):
        self.inputs[id(variable)].configure(values=tuple(values))
        if variable.get() not in values:
            variable.set(values[0] if values else "")

    def _selected(self, key, required=True):
        rows = tuple(self.tables[key].selection())
        if required and not rows:
            raise ValueError("Select a record first.")
        return rows

    def on_tab(self, _event=None):
        selected = self.notebook.select()
        for name, page in self.pages.items():
            if selected is page or str(selected) == str(page):
                self.show(name)
                break

    def show(self, name):
        if self.closed or name not in self.pages:
            return
        self.active_tab = name
        if name not in self.built:
            content = self._scroll(self.pages[name])
            getattr(self, "build_" + name.lower().replace(" ", "_"))(content)
            self.ttk.Label(self.pages[name], textvariable=self.status, style="Muted.TLabel", wraplength=1050).pack(anchor="w", pady=5)
            self.built.add(name)
        self.refresh(force=True)

    def refresh(self, force=False):
        if self.closed:
            return
        context = self.controller.context or {}
        world = self.controller.current_world() or ""
        changed = world != self.workspace
        if changed:
            if "Metadata" in self.built and self.metadata_world:
                self._call(self.save_metadata, silent=True, world_id=self.metadata_world, preserve_invalid=True)
            self.workspace = world
            self.report_preview = self.control_review = None
            self.task_id = None
            if "Metadata" in self.built:
                self.load_metadata()
            for name in ("build_fields", "task_fields"):
                for editor in getattr(self, name, {}).values():
                    widget = self.inputs.get(id(editor))
                    options = widget.cget("values") if widget is not None and hasattr(widget, "cget") else ()
                    self._set(editor, options[0] if options else "")
            if "Live Test" in self.built:
                self._set(self.step_evidence, "")
                self._set(self.step_details, "Choose a run in the current workspace.", True)
                self._rows("steps", ())
        recognition = context.get("recognition", "Unresolved")
        if isinstance(recognition, dict):
            recognition = recognition.get("label", recognition.get("state", "Unresolved"))
        self.summary.set(f"Workspace: {world or 'No world selected'}  |  {recognition}\n"
                         f"Loaded build: {context.get('build_id') or 'Unknown'}  |  "
                         f"Source: {context.get('source') or 'Local workspace'}  |  {context.get('freshness') or 'No live evidence'}")
        if "Creator" in self.built:
            self.capture.set(bool(getattr(self.controller, "capture_enabled", False)))
        if not force and not changed and time.monotonic() - self.last_refresh < 2:
            return
        self.last_refresh = time.monotonic()
        if self.active_tab in self.built:
            method = getattr(self, "refresh_" + self.active_tab.lower().replace(" ", "_"), None)
            if method:
                self._call(method)

    def build_creator(self, parent):
        self._note(parent, "Creator Mode organizes your work. Recognized authorship, permission to change a world, and an available control route are separate checks. Everything here stays local until you explicitly export or share it.")
        self.project_name = self._field(parent, "Local project name")
        self.project_world = self._field(parent, "World ID / saved local project ID")
        bar = self._bar(parent)
        self._button(bar, "Open / pin workspace", self.pin_world)
        self._button(bar, "New local project", self.new_project)
        self._button(bar, "Use observed world", self.use_observed_world)
        self._button(self._bar(parent), "Associate local test session…", self.associate_local_test)
        self.capture = self.tk.BooleanVar(value=getattr(self.controller, "capture_enabled", False))
        self.ttk.Checkbutton(parent, text="Collect creator diagnostics from the selected log and existing measurements",
                             variable=self.capture, command=lambda: self._call(self.toggle_capture)).pack(anchor="w", pady=7)
        self._note(parent, "Collection is bounded and optional. Missing, old, or partial sources remain unknown. Enabling collection does not enable a device, API connection, or peer connection.")
        self._button(self._bar(parent), "Mark incident now", lambda: self.controller.add_bookmark())
        if hasattr(self.controller, "show_overlay"):
            self.overlay_placement = self._field(parent, "SteamVR card placement", options=("right", "left", "head", "dashboard"))
            self.overlay_size = self._field(parent, "Card width (metres)", value="0.55")
            self.overlay_opacity = self._field(parent, "Card opacity", value="0.9")
            bar = self._bar(parent)
            self._button(bar, "Show creator card", self.show_overlay)
            self._button(bar, "Hide creator card", lambda: self.controller.clear_overlay())
            self._note(parent, "Optional read-only card uses an already connected SteamVR runtime. Desktop controls remain available. Card placement and rendering count as benchmark conditions.")
        self.overview = self._text(parent, 10)

    def refresh_creator(self):
        records = self.controller.store.list(world_id=self.workspace, limit=500) if self.workspace else []
        counts = {}
        for row in records:
            counts[row["kind"]] = counts.get(row["kind"], 0) + 1
        text = "Local records\n" + ("\n".join(f"{kind.replace('_', ' ').title()}: {count}" for kind, count in sorted(counts.items())) or "No records yet.")
        text += "\n\nStart with a metadata draft, a recorded build, or a Live Test template.\nTasks contains structured worksheets for accessibility, persistence, routes, localization, known issues, dependencies and release requirements."
        self._set(self.overview, text, True)

    def pin_world(self):
        world = self.project_world.get().strip()
        if not world:
            raise ValueError("Enter a world ID or choose New local project.")
        self.controller.set_workspace(world, self.project_name.get().strip())
        self.refresh(force=True)

    def new_project(self):
        name = self.project_name.get().strip() or "Untitled local world"
        world = "local:" + str(uuid.uuid4())
        self.controller.set_workspace(world, name)
        self.project_world.set(world)
        self.announce("Created a private local project. You can work before a world is uploaded.")
        self.refresh(force=True)

    def use_observed_world(self):
        self.controller.refresh_context()
        world = (self.controller.context or {}).get("live_world_id")
        if not world or str(world).startswith("local:"):
            raise ValueError("No published world is currently observed.")
        self.controller.follow_current_world()
        self.project_world.set(world)
        self.refresh(force=True)

    def toggle_capture(self):
        self.controller.set_capture(bool(self.capture.get()))
        self.announce("Creator capture enabled." if self.capture.get() else "Creator capture stopped; local records retained.")

    def associate_local_test(self):
        from tkinter import messagebox
        world = self.world()
        if not world.startswith("local:"):
            raise ValueError("Choose a local project to associate an unpublished Build & Test session.")
        if not messagebox.askyesno("Associate local test session", "Associate the current selected local test log with this project?\n\nThis is a manual project association. It does not verify the loaded build. Capture remains off until you enable it."):
            return
        self.controller.refresh_context()
        if self.controller.current_world() != world:
            raise ValueError("The workspace changed. Review the session association again.")
        self.controller.bind_local_test_session()
        self.announce("Local test session associated manually. Confirm its loaded build separately when needed.")

    def show_overlay(self):
        self.world()
        run = self.controller.store.get(getattr(self.controller, "active_run_id", "")) if getattr(self.controller, "active_run_id", None) else None
        steps = run["data"].get("steps", []) if run else []
        step = next((s.get("title", "") for s in steps if s.get("status") in ("In progress", "Not started")), "")
        groups = self.controller.diagnostics.error_groups(self.world())
        error = groups[0].get("summary", "") if groups else ""
        result = self.controller.show_overlay(step=step, error=error, placement=self.overlay_placement.get(), size=float(self.overlay_size.get()), opacity=float(self.overlay_opacity.get()))
        self.announce(result)

    def build_metadata(self, parent):
        self._note(parent, "Draft metadata locally, compare it with refreshed metadata, then export it for the VRChat SDK. Saving a draft does not publish, upload, or change world access.")
        self.metadata_fields = {}
        for key, label, multiline in (("name", "World name", False), ("description", "Description", True), ("tags", "Creator tags (comma separated)", False),
                                       ("capacity", "Maximum capacity", False), ("recommended_capacity", "Recommended capacity", False)):
            self.metadata_fields[key] = self._field(parent, label, multiline=multiline)
        bar = self._bar(parent)
        self._button(bar, "Save local draft", self.save_metadata)
        self._button(bar, "Refresh metadata for comparison", self.refresh_metadata)
        self._button(bar, "Resolve conflicts…", self.resolve_metadata)
        self._button(bar, "Export draft for SDK…", self.export_metadata)
        self.description_section = self._field(parent, "Description section", options=("Controls", "Accessibility", "Known limitations", "Credits", "Update notes", "Playtest instructions"))
        self.description_content = self._field(parent, "Section text", multiline=True)
        self._button(self._bar(parent), "Append description section", self.append_description)
        self.metadata_diff_view = self._text(parent, 9)
        self.load_metadata()

    def _metadata_document(self):
        from creator_metadata import validate_draft
        draft = {key: self._get(editor).strip() for key, editor in self.metadata_fields.items()}
        for field in ("capacity", "recommended_capacity"):
            if draft[field] == "":
                draft.pop(field)
            else:
                try:
                    draft[field] = int(draft[field])
                except ValueError as exc:
                    raise ValueError(f"{field.replace('_', ' ').title()} must be an integer.") from exc
        return validate_draft(draft)

    def _metadata_values(self, document):
        from creator_metadata import editable_metadata
        return editable_metadata(document)

    def load_metadata(self):
        world = self.controller.current_world() or ""
        self.metadata_world = world
        records = self.controller.store.list(kind="metadata_draft", world_id=world, limit=1) if world else []
        info = self.controller.world_info or {}
        if not isinstance(info, dict) or info.get("id", world) != world:
            info = {}
        self.metadata_base = self._metadata_values(info)
        self.metadata_latest = dict(self.metadata_base)
        self.metadata_conflicts = {}
        self.metadata_record_id = None
        draft = self.metadata_base
        if not draft.get("name"):
            projects = self.controller.store.list(kind="world", world_id=world, limit=1) if world else []
            draft = dict(draft, name=projects[0]["data"].get("name", "Untitled local world") if projects else "Untitled local world")
        if records:
            record = records[0]
            self.metadata_record_id = record["id"]
            self.metadata_base = record["data"].get("base", {})
            self.metadata_latest = record["data"].get("latest", self.metadata_base)
            self.metadata_conflicts = record["data"].get("conflicts", {})
            draft = record["data"].get("draft", {})
        for key, editor in self.metadata_fields.items():
            self._set(editor, field_value(draft.get(key), "list" if key == "tags" else None))
        self.refresh_metadata_diff()

    def save_metadata(self, silent=False, world_id=None, preserve_invalid=False):
        world = world_id or self.world()
        error = ""
        try:
            draft = self._metadata_document()
        except ValueError as exc:
            if not preserve_invalid:
                raise
            draft = {key: self._get(editor) for key, editor in self.metadata_fields.items()}
            error = str(exc)
        data = {"title": "Metadata draft", "base": self.metadata_base, "draft": draft,
                "latest": self.metadata_latest, "conflicts": self.metadata_conflicts, "submission": "Local draft; not submitted"}
        if error:
            data["validation_error"] = error
        record = self.controller.store.save("metadata_draft", world, data, self.metadata_record_id)
        self.metadata_record_id = record["id"]
        self.refresh_metadata_diff()
        if not silent:
            self.announce("Metadata draft saved locally. No remote change was made.")
        return record

    def refresh_metadata(self):
        self.world()
        self.save_metadata(silent=True)
        world = self.metadata_world
        def complete(document, error=""):
            if self.closed or self.controller.current_world() != world:
                return
            if error:
                self.announce(error + " Draft retained.")
                return
            from creator_metadata import three_way_merge
            current = self._metadata_document()
            latest = self._metadata_values(document)
            result = three_way_merge(self.metadata_base, current, latest)
            self.metadata_latest, self.metadata_conflicts = latest, result["conflicts"]
            merged = result["merged"]
            # Preserve user text in the editor while conflicts await a decision.
            for key in self.metadata_conflicts:
                if key in current:
                    merged[key] = current[key]
            for key, editor in self.metadata_fields.items():
                self._set(editor, field_value(merged.get(key), "list" if key == "tags" else None))
            if not self.metadata_conflicts:
                self.metadata_base = latest
            self.save_metadata(silent=True)
            self.announce(f"Metadata refreshed. {len(self.metadata_conflicts)} conflicting field(s); draft preserved.")
        self.controller.refresh_metadata(complete)

    def refresh_metadata_diff(self):
        from creator_metadata import metadata_diff, description_warnings
        try:
            draft = self._metadata_document()
            diff = metadata_diff(self.metadata_latest or self.metadata_base, draft)
            lines = ["Local changes compared with last checked metadata:"]
            for key, change in diff.items():
                lines.extend((f"\n{key}", f"  Checked: {field_value(change['before'])}", f"  Draft: {field_value(change['after'])}"))
            if not diff:
                lines.append("No changed fields.")
            if self.metadata_conflicts:
                lines.append("\nConflicts need your decision: " + ", ".join(self.metadata_conflicts))
            lines.extend("\nCheck: " + warning for warning in description_warnings(draft.get("description", "")))
            info = self.controller.world_info or {}
            if isinstance(info, dict) and info.get("id") == self.metadata_world:
                from creator_metadata import classification_tags
                lines.append("\nLast checked publication facts (independent of the loaded build):")
                lines.append("  Access: " + str(info.get("releaseStatus", "Unknown")))
                lines.append("  Published revision: " + str(info.get("version", "Unknown")))
                lines.append("  Service classifications: " + (", ".join(classification_tags(info)) or "None recorded"))
            lines.append("\nPublication status and uploaded versions are evidence only. Publishing and access changes remain explicit VRChat SDK actions.")
            self._set(self.metadata_diff_view, "\n".join(lines), True)
        except ValueError as exc:
            self._set(self.metadata_diff_view, str(exc), True)

    def resolve_metadata(self):
        from tkinter import messagebox
        decisions = {}
        for key, values in self.metadata_conflicts.items():
            decision = messagebox.askyesnocancel("Resolve metadata conflict", f"{key}\n\nOriginal: {field_value(values.get('base'))}\n\nYour draft: {field_value(values.get('draft'))}\n\nLatest: {field_value(values.get('latest'))}\n\nYes: keep your draft. No: use latest. Cancel: decide later.")
            if decision is None:
                return
            decisions[key] = values.get("draft" if decision else "latest")
        for key, value in decisions.items():
            if key in self.metadata_fields:
                self._set(self.metadata_fields[key], field_value(value, "list" if key == "tags" else None))
        self.metadata_base = dict(self.metadata_latest)
        self.metadata_conflicts = {}
        self.save_metadata()

    def append_description(self):
        content = self._get(self.description_content).strip()
        if not content:
            raise ValueError("Enter section text first.")
        editor = self.metadata_fields["description"]
        existing = self._get(editor).rstrip()
        self._set(editor, (existing + "\n\n" if existing else "") + self.description_section.get() + "\n" + content)
        self.refresh_metadata_diff()

    def export_metadata(self):
        from tkinter import filedialog
        if self.metadata_conflicts:
            raise ValueError("Resolve metadata conflicts before exporting the draft for the SDK.")
        record = self.save_metadata(silent=True)
        path = filedialog.asksaveasfilename(title="Export local world metadata draft", defaultextension=".json", filetypes=(("JSON draft", "*.json"),))
        if not path:
            return
        self.controller.refresh_context()
        if self.controller.current_world() != record["world_id"]:
            raise ValueError("The workspace changed while choosing a file. Review the draft again.")
        document = {"schema": 1, "world_id": record["world_id"], "route": "Review and apply in the VRChat SDK", "submitted": False, "draft": record["data"]["draft"]}
        Path(path).write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self.announce("Draft exported for review in the SDK. The world has not been changed.")

    def build_builds(self, parent):
        self._note(parent, "Record builds and platform evidence separately. A published version does not identify the build currently loaded by a client.")
        self.build_fields = {}
        fields = (("title", "Creator release / label"), ("local_build_id", "Creator-defined build ID"), ("platform", "Platform", ("Windows", "Android", "iOS", "Other")),
                  ("project_revision", "Project revision"), ("artifact_status", "Artifact presence", ("Unknown", "Present", "Missing")),
                  ("revision_status", "Revision match", ("Unverified", "Matching", "Older")), ("upload_status", "Upload evidence", ("No record", "Confirmed", "Failed")),
                  ("client_test_status", "Real client test", ("Not tested", "Tested")), ("interaction_status", "Interaction tests", ("Incomplete", "Passed", "Failed")),
                  ("parity_status", "Cross-platform semantics", ("Untested", "Verified", "Mismatch")), ("evidence", "Evidence / intentional differences", "text"))
        for spec in fields:
            key, label, *kind = spec
            kind = kind[0] if kind else None
            self.build_fields[key] = self._field(parent, label, options=kind if isinstance(kind, tuple) else None, multiline=kind == "text")
        bar = self._bar(parent)
        self._button(bar, "Record build evidence", self.save_build)
        self._button(bar, "Import project manifest…", self.import_manifest)
        self._button(bar, "Compare selected manifests", self.compare_manifests)
        self._table(parent, "builds", (("kind", "Record", 100), ("title", "Build / platform", 250), ("status", "Evidence", 290)), height=5, multiple=True)
        self.build_details = self._text(parent, 6)
        self.tables["builds"].bind("<<TreeviewSelect>>", lambda _: self.show_record("builds", self.build_details))

    def save_build(self):
        data = {key: self._get(value).strip() for key, value in self.build_fields.items()}
        if not data["local_build_id"] or not data["title"]:
            raise ValueError("A build label and creator-defined build ID are required.")
        self.controller.workflows.save_worksheet(self.world(), "build", data)
        self.announce("Build evidence recorded. Loaded-build identity remains independent.")
        self.refresh(force=True)

    def refresh_builds(self):
        records = self.controller.store.list(world_id=self.workspace, limit=500) if self.workspace else []
        rows = []
        for r in records:
            if r["kind"] in ("build", "manifest", "project_manifest", "helper_manifest"):
                d = r["data"]
                rows.append((r["id"], (r["kind"], display_record(r) + " / " + str(d.get("platform", "Unknown")), d.get("client_test_status") or d.get("build_id", "Recorded locally"))))
        self._rows("builds", rows)

    def compare_manifests(self):
        from creator_helper import compare_manifests
        selected = self._selected("builds")
        if len(selected) != 2:
            raise ValueError("Select exactly two imported manifests to compare their declarations.")
        manifests = []
        for identity in selected:
            record = self.controller.store.get(identity)
            if record["kind"] not in ("manifest", "project_manifest", "helper_manifest"):
                raise ValueError("Both selections must be imported manifests.")
            manifests.append(record["data"].get("manifest", record["data"]))
        differences = compare_manifests(*manifests)
        self._set(self.build_details, json.dumps(differences, indent=2, ensure_ascii=False) if differences else "No differences in the declared contracts. Runtime behavior still requires testing.", True)

    def build_live_test(self, parent):
        from creator_workflows import TEMPLATES, ENVIRONMENTS, STEP_STATUSES
        self._note(parent, "Runs keep immutable copies of the selected checklist and profile. A displayed instruction is not an executed action. Record evidence for pass/fail; blocked and untested steps are not passes.")
        self.template_keys = tuple(TEMPLATES)
        self.test_template = self._field(parent, "Test template", options=self.template_keys)
        self.test_environment = self._field(parent, "Test environment", options=ENVIRONMENTS)
        self.test_build = self._field(parent, "Recorded build", options=("Unknown build",))
        self.test_profile = self._field(parent, "Saved test profile", options=("Template defaults",))
        self.test_recipe = self._field(parent, "Saved reproduction recipe", options=("Use selected template",))
        self.build_choices, self.profile_choices, self.recipe_choices = {}, {}, {}
        bar = self._bar(parent)
        self._button(bar, "Start guided test", self.start_run)
        self._button(bar, "Mark incident", lambda: self.controller.add_bookmark())
        self._button(bar, "Finish selected run", self.finish_run)
        self._table(parent, "runs", (("title", "Run", 290), ("environment", "Environment", 130), ("status", "Status", 110)), height=4)
        self.tables["runs"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_run))
        self._table(parent, "steps", (("title", "Step", 300), ("status", "Result", 130), ("execution", "Evidence source", 140)), height=5)
        self.tables["steps"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_step))
        self.step_details = self._text(parent, 5)
        self.step_status = self._field(parent, "Result", options=STEP_STATUSES)
        self.step_evidence = self._field(parent, "What was observed / evidence", multiline=True)
        self._button(self._bar(parent), "Record human-observed result", self.save_step)
        from creator_workflows import COMPARISON_CONDITIONS, CONDITION_STATES
        self.condition_key = self._field(parent, "Run condition", options=COMPARISON_CONDITIONS)
        self.condition_value = self._field(parent, "Condition value")
        self.condition_status = self._field(parent, "Evidence for condition", options=tuple(s for s in CONDITION_STATES if s != "Verified"))
        self._button(self._bar(parent), "Record selected run condition", self.save_condition)

    def refresh_live_test(self):
        records = self.controller.store.list(kind="run", world_id=self.workspace, limit=200) if self.workspace else []
        for kind, variable, attr, default in (("build", self.test_build, "build_choices", "Unknown build"), ("profile", self.test_profile, "profile_choices", "Template defaults"), ("recipe", self.test_recipe, "recipe_choices", "Use selected template")):
            choices = {display_record(r) + " · " + r["id"][-8:]: r["id"] for r in self.controller.store.list(kind=kind, world_id=self.workspace, limit=200)} if self.workspace else {}
            setattr(self, attr, choices)
            self._choices(variable, (default, *choices))
        self._rows("runs", ((r["id"], (display_record(r), r["data"].get("environment", "Unknown"), r["data"].get("status", "Unknown"))) for r in records))
        if self._selected("runs", False):
            self.select_run(reset=False)

    def start_run(self):
        world = self.world()
        installed = self.controller.workflows.install_template(world, self.test_template.get())
        profile_id = self.profile_choices.get(self.test_profile.get()) or installed["profile"]["id"]
        build_id = self.build_choices.get(self.test_build.get())
        recipe_id = self.recipe_choices.get(self.test_recipe.get())
        if recipe_id:
            run = self.controller.workflows.start_recipe(recipe_id, profile_id=profile_id, build_id=build_id, environment=self.test_environment.get())
        else:
            run = self.controller.workflows.start_run(world, profile_id=profile_id, checklist_id=installed["checklist"]["id"], build_id=build_id, environment=self.test_environment.get())
        self.controller.active_run_id = run["id"]
        self.refresh_live_test()
        self.tables["runs"].selection_set(run["id"])
        self.select_run()
        self.announce("Guided run started. Conditions remain requested until verified.")

    def select_run(self, reset=True):
        identity = self._selected("runs")[0]
        record = self.controller.store.get(identity)
        if not record:
            return
        loaded = getattr(self.controller, "loaded_build_id", "")
        matches = not loaded or not record["data"].get("build_id") or loaded == record["data"]["build_id"]
        self.controller.active_run_id = identity if record["data"].get("status") == "Active" and matches else None
        self._rows("steps", ((s["id"], (s.get("title", s["id"]), s.get("status", "Not started"), s.get("execution", "manual"))) for s in record["data"].get("steps", [])))
        if reset:
            self._set(self.step_details, "Select a step to see preparation, expected result and required evidence.", True)

    def select_step(self):
        run = self.controller.store.get(self._selected("runs")[0])
        step_id = self._selected("steps")[0]
        step = next(step for step in run["data"]["steps"] if step["id"] == step_id)
        self._set(self.step_details, f"{step.get('title', '')}\n\nPreparation: {step.get('preparation', '')}\nExpected: {step.get('expected', '')}\nEvidence: {step.get('evidence_hint', '')}", True)
        conditions = [f"{label}: {step.get(key)}" for key, label in (("timeout_seconds", "Time bound (seconds)"), ("stop_condition", "Stop condition"), ("branches", "Optional branches"), ("expected_failure", "Expected failure")) if step.get(key)]
        if conditions:
            current = self._get(self.step_details)
            self._set(self.step_details, current + "\n" + "\n".join(conditions) + "\nThese are manual instructions; no action or pass is inferred.", True)
        self.step_status.set(step.get("status", "Not started"))
        self._set(self.step_evidence, step.get("evidence", ""))

    def save_step(self):
        self.world()
        run_id, step_id = self._selected("runs")[0], self._selected("steps")[0]
        self.controller.workflows.set_step_result(run_id, step_id, self.step_status.get(), evidence=self._get(self.step_evidence).strip(), execution="manual")
        self.select_run(reset=False)
        self.announce("Step result recorded with a human-observed evidence source.")

    def finish_run(self):
        self.world()
        self.controller.workflows.finish_run(self._selected("runs")[0])
        self.refresh_live_test()
        self.announce("Run finished. Unfinished and blocked coverage remain visible.")

    def save_condition(self):
        self.world()
        self.controller.workflows.set_condition(self._selected("runs")[0], self.condition_key.get(), self.condition_value.get().strip(), self.condition_status.get(), source="Creator entry")
        self.announce("Run condition recorded with its explicit confirmation state.")

    def build_diagnostics(self, parent):
        self._note(parent, "Observed log events and explicitly selected sources only. Timelines show sequence and possible correlations, not causes. Process memory is not world memory; absent measurements are unknown.")
        self.diag_filters = {}
        for key, label in (("severity", "Severity"), ("source", "Source contains"), ("subsystem", "Subsystem contains"), ("build_id", "Build ID"), ("run_id", "Run ID")):
            self.diag_filters[key] = self._field(parent, label, options=("All", "info", "warning", "error", "fatal", "unknown") if key == "severity" else None)
        self.diag_analysis = self._field(parent, "Analysis", options=("Health and errors", "Capacity and frame time", "World networking", "Zone coverage", "Long-session stability"))
        self.target_fps = self._field(parent, "Creator frame target (FPS)", value="90")
        bar = self._bar(parent)
        self._button(bar, "Apply filters", self.refresh_diagnostics)
        self._button(bar, "Mark incident", lambda: self.controller.add_bookmark())
        self._button(bar, "Create issue from selection", self.issue_from_selection)
        self._table(parent, "observations", (("time", "Received", 110), ("kind", "Kind / severity", 135), ("summary", "Observation", 450), ("source", "Source", 150)), height=8, multiple=True)
        self.population_canvas = self.tk.Canvas(parent, height=125, background="#101722", highlightthickness=0)
        from color_vision import canvas_ink
        canvas_ink(self.population_canvas)
        self.population_canvas.pack(fill="x", pady=5)
        from color_vision import POPULATION_LEGEND
        self._note(parent, POPULATION_LEGEND)
        self.health_view = self._text(parent, 8)
        self._report_bar(parent, "observations")

    def refresh_diagnostics(self):
        if not self.workspace:
            self._rows("observations", ())
            return
        rows = self.controller.diagnostics.timeline(self.workspace)
        if not isinstance(rows, (list, tuple)):
            rows = list(rows)
        selected = []
        for row in rows:
            d = row.get("data", row)
            keep = True
            for key, editor in self.diag_filters.items():
                value = editor.get().strip()
                if value and value != "All" and value.casefold() not in str(d.get(key, "")).casefold():
                    keep = False
            if keep:
                selected.append(row)
        self._rows("observations", ((r.get("id", str(i)), (self._time(r.get("data", r).get("receipt_time", r.get("created_at"))),
              r.get("data", r).get("kind", "observation") + " / " + r.get("data", r).get("severity", "info"),
              r.get("data", r).get("summary", ""), r.get("data", r).get("source", "Unknown"))) for i, r in enumerate(selected)))
        from creator_diagnostics import capacity_summary, network_summary, zone_coverage, soak_summary
        analysis = self.diag_analysis.get()
        if analysis == "Capacity and frame time":
            result = capacity_summary(selected, float(self.target_fps.get()))
        elif analysis == "World networking":
            result = network_summary(selected)
        elif analysis == "Zone coverage":
            result = {"zones": zone_coverage(selected), "coverage": "Only selected observations; missing zones remain untested."}
        elif analysis == "Long-session stability":
            result = {"measurements": soak_summary(selected), "interpretation": "Observed drift does not establish a leak or crash cause."}
        else:
            result = {"health": self.controller.diagnostics.health(self.workspace), "error_groups": self.controller.diagnostics.error_groups(self.workspace)}
        retention = self.controller.diagnostics.retention_status()
        self._set(self.health_view, analysis + "\n" + json.dumps(result, indent=2, ensure_ascii=False) +
                  "\n\nRetention / collection overhead\n" + json.dumps(retention, indent=2, ensure_ascii=False), True)
        self.draw_population(rows)

    @staticmethod
    def _time(value):
        if isinstance(value, (int, float)):
            return time.strftime("%H:%M:%S", time.localtime(value))
        return str(value or "Unknown")[:22]

    def draw_population(self, rows):
        from color_vision import canvas_ink
        canvas = canvas_ink(self.population_canvas, getattr(self, 'app', None))
        canvas.delete("all")
        samples = []
        for record in rows:
            d = record.get("data", record)
            if d.get("kind") in ("population", "player_count", "population_sample"):
                details = d.get("details") or {}
                samples.append((d.get("receipt_time", record.get("created_at", 0)), d.get("value"), d.get("quality", "unknown"), bool(details.get("initial_observation") or details.get("ended"))))
        canvas.create_text(8, 10, anchor="nw", fill='@text', text="Observed population · gaps and incomplete coverage are not zero")
        from screen_reader_alternatives import chart
        chart(self.population_canvas,'Observed population',[(str(t),v,v) for t,v,quality,boundary in sorted(samples,key=lambda row:row[0])],lambda v:f'{v:g} people',events='Observation quality and session boundaries are in the population table. Gaps and incomplete coverage are not zero.')
        values = [s[1] for s in samples if isinstance(s[1], (int, float))]
        if not values:
            canvas.create_text(8, 45, anchor="nw", fill='@muted', text="No observed population samples.")
            return
        samples.sort(key=lambda s: s[0])
        width = max(400, canvas.winfo_width()) - 55
        first, last = samples[0][0], samples[-1][0]
        peak = max(1, max(values))
        prior = None
        for observed, count, quality, boundary in samples:
            if boundary or not isinstance(count, (int, float)) or quality in ("unknown", "stale", "unavailable"):
                prior = None
            if not isinstance(count, (int, float)):
                continue
            x = 35 + width * ((observed - first) / (last - first) if last != first else .5)
            y = 100 - 65 * count / peak
            reliable = quality not in ("unknown", "stale", "unavailable")
            confirmed = quality in ("complete", "observed", "confirmed")
            color = '@success' if confirmed else '@warning'
            if prior and reliable and prior[2]:
                canvas.create_line(prior[0], prior[1], x, prior[1], x, y, fill=color, width=2,
                                   dash=() if confirmed and prior[3] else (4, 3))
            if confirmed:
                canvas.create_oval(x-4, y-4, x+4, y+4, fill=color, outline=color)
            else:
                canvas.create_polygon(x, y-5, x+5, y, x, y+5, x-5, y, fill=color, outline=color)
            prior = x, y, reliable, confirmed
        canvas.create_text(8, 40, anchor="nw", fill='@muted', text=str(peak))

    def issue_from_selection(self):
        ids = list(self._selected("observations"))
        records = [self.controller.store.get(identity) for identity in ids]
        observed = "\n".join(r["data"].get("summary", "") for r in records if r)
        issue = self.controller.workflows.issue_from_evidence(self.world(), ids, title="Investigation from selected evidence", observed=observed,
                      build_id=(self.controller.context or {}).get("build_id"), run_id=getattr(self.controller, "active_run_id", None))
        self.announce("Issue created with selected evidence: " + issue["id"])

    def build_tasks(self, parent):
        self._note(parent, "Private notes, investigations and structured audit worksheets. Fix implemented and fix verified are separate. These records do not automatically enter reports or peer messages.")
        self.task_kind = self._field(parent, "Worksheet", options=tuple(label for label, _ in WORKSHEETS.values()))
        self.task_search = self._field(parent, "Search title / subsystem / evidence")
        bar = self._bar(parent)
        self._button(bar, "Show worksheet", self.change_worksheet)
        self._button(bar, "Search records", self.refresh_tasks)
        self._button(bar, "New record", self.new_task)
        self.task_form = self.ttk.Frame(parent)
        self.task_form.pack(fill="x")
        self.task_fields, self.task_specs = {}, ()
        bar = self._bar(parent)
        self._button(bar, "Save private record", self.save_task)
        self._button(bar, "Delete selected record…", self.delete_task)
        self._table(parent, "tasks", (("kind", "Worksheet", 180), ("title", "Title", 360), ("status", "Status / subsystem", 220)), height=6)
        self.tables["tasks"].bind("<<TreeviewSelect>>", lambda _: self._call(self.load_task))
        self.change_worksheet()

    def _task_kind_key(self):
        return next(key for key, (label, _) in WORKSHEETS.items() if label == self.task_kind.get())

    def change_worksheet(self):
        self.task_id = None
        for child in self.task_form.winfo_children():
            child.destroy()
        key = self._task_kind_key()
        self.task_specs = WORKSHEETS[key][1]
        self.task_fields = {}
        for spec in self.task_specs:
            name, label, *kind = spec
            kind = kind[0] if kind else None
            self.task_fields[name] = self._field(self.task_form, label, options=kind if isinstance(kind, tuple) else None, multiline=kind in ("text", "lines"))
        self.refresh_tasks()

    def new_task(self):
        self.change_worksheet()
        self.announce("New private worksheet. Save when ready.")

    def refresh_tasks(self):
        records = self.controller.store.list(world_id=self.workspace, limit=500) if self.workspace else []
        query = self.task_search.get().strip().casefold()
        kind = self._task_kind_key()
        selected = [r for r in records if r["kind"] == kind and (not query or query in json.dumps(r["data"], ensure_ascii=False).casefold())]
        self._rows("tasks", ((r["id"], (WORKSHEETS[kind][0], display_record(r), r["data"].get("status") or r["data"].get("subsystem", "Private"))) for r in selected))

    def save_task(self):
        data = {}
        for spec in self.task_specs:
            key, _, *kind = spec
            kind = kind[0] if kind else None
            value = self._get(self.task_fields[key]).strip()
            if kind in ("list", "lines"):
                value = [piece.strip() for piece in (value.splitlines() if kind == "lines" else value.split(",")) if piece.strip()]
            data[key] = value
        if not data.get("title"):
            raise ValueError("Enter a title for this worksheet.")
        kind = self._task_kind_key()
        if kind in MODEL_WORKSHEETS:
            record = self.controller.workflows.save_worksheet(self.world(), kind, data, self.task_id)
        elif kind == "issue":
            if self.task_id:
                record = self.controller.store.get(self.task_id)
                if not record or record["world_id"] != self.world():
                    raise ValueError("This issue is no longer in the active workspace.")
            else:
                if data["status"] == "Verified fixed":
                    raise ValueError("Create the investigation first, then select a completed verification run and passed step.")
                record = self.controller.workflows.issue_from_evidence(self.world(), title=data["title"], observed=data["observed"], expected=data["expected"], reproduction=data["reproduction"])
                self.task_id = record["id"]
            record = self.controller.workflows.update_issue(record["id"], data["status"], proposed_fix=data.get("proposed_fix"), verification_run_id=data.get("verification_run_id") or None, verification_step_id=data.get("verification_step_id") or None)
            updated = dict(record["data"])
            updated.update({k: data[k] for k in ("title", "observed", "expected", "reproduction")})
            record = self.controller.store.save("issue", self.world(), updated, record["id"])
        else:
            data["visibility"] = "private"
            record = self.controller.store.save(kind, self.world(), data, self.task_id)
        self.task_id = record["id"]
        self.refresh_tasks()
        self.tables["tasks"].selection_set(self.task_id)
        self.announce("Private worksheet saved locally.")

    def load_task(self):
        record = self.controller.store.get(self._selected("tasks")[0])
        if not record or record["kind"] != self._task_kind_key():
            return
        self.task_id = record["id"]
        for spec in self.task_specs:
            key, _, *kind = spec
            self._set(self.task_fields[key], field_value(record["data"].get(key), kind[0] if kind else None))

    def delete_task(self):
        from tkinter import messagebox
        identity = self._selected("tasks")[0]
        record = self.controller.store.get(identity)
        if messagebox.askyesno("Delete private worksheet", f"Delete {display_record(record)}? This cannot be undone."):
            self.controller.refresh_context()
            if record["world_id"] != self.controller.current_world():
                raise ValueError("The workspace changed. Select the record again before deleting it.")
            self.controller.store.delete(identity)
            self.new_task()

    def build_history(self, parent):
        self._note(parent, "Selected records are the only report inputs. Public reports remove free text by default; preview the exact result before saving. Local draft rollback, project rollback and uploading a build are separate actions.")
        self._table(parent, "history", (("kind", "Record", 150), ("title", "Title / context", 420), ("updated", "Updated", 140)), height=9, multiple=True)
        self.tables["history"].bind("<<TreeviewSelect>>", lambda _: self.show_record("history", self.history_details))
        bar = self._bar(parent)
        self._button(bar, "Set selected run as baseline", self.set_baseline)
        self._button(bar, "Compare two selected runs", self.compare_runs)
        self._button(bar, "Evaluate release coverage", self.evaluate_release)
        self.history_details = self._text(parent, 10)
        self._report_bar(parent, "history")
        self._button(self._bar(parent), "Review selected record for peer sharing…", self.review_share)
        self._button(self._bar(parent), "Import accepted peer test results", self.import_peer_results)

    def refresh_history(self):
        records = self.controller.store.list(world_id=self.workspace, limit=500) if self.workspace else []
        self._rows("history", ((r["id"], (r["kind"], display_record(r), self._time(r["updated_at"]))) for r in records))

    def show_record(self, table, target):
        selected = self._selected(table, False)
        if not selected:
            return
        record = self.controller.store.get(selected[0])
        self._set(target, json.dumps(record, indent=2, ensure_ascii=False), True)

    def set_baseline(self):
        record = self.controller.store.get(self._selected("history")[0])
        if record["kind"] != "run":
            raise ValueError("Select a completed test run as the baseline.")
        if record["data"].get("status") == "Active":
            raise ValueError("Finish the run before making it a baseline.")
        self.controller.workflows.designate_baseline(record["id"], title=display_record(record))
        self.refresh_history()
        self.announce("Baseline recorded. Comparison still checks that test conditions match.")

    def compare_runs(self):
        identities = self._selected("history")
        if len(identities) != 2:
            raise ValueError("Select exactly two test runs (older run is the baseline).")
        records = [self.controller.store.get(identity) for identity in identities]
        if any(record["kind"] != "run" for record in records):
            raise ValueError("Both selections must be test runs.")
        records.sort(key=lambda r: r["created_at"])
        result = self.controller.workflows.compare_runs(records[0]["id"], records[1]["id"])
        from creator_diagnostics import compare_observations
        before = self.controller.diagnostics.timeline(self.world(), run_id=records[0]["id"])
        after = self.controller.diagnostics.timeline(self.world(), run_id=records[1]["id"])
        result["observed_differences"] = compare_observations(before, after, comparable=result.get("comparable", False), reasons=result.get("reasons", []))
        self._set(self.history_details, json.dumps(result, indent=2, ensure_ascii=False), True)

    def evaluate_release(self):
        requirements = []
        for record in self.controller.store.list(kind="release_requirement", world_id=self.world()):
            data = record["data"]
            requirements.append(dict(data, kind=data.get("requirement_type", "manual"), label=data.get("title", "Requirement"), platform=data.get("target_platform", "")))
        if not requirements:
            raise ValueError("Add release requirements in Tasks first.")
        result = self.controller.workflows.evaluate_release(self.world(), requirements)
        self._set(self.history_details, json.dumps(result, indent=2, ensure_ascii=False) + "\n\nLocal readiness review only. This does not publish a world or claim platform approval.", True)

    def _report_bar(self, parent, source):
        group = self.ttk.Frame(parent)
        group.pack(fill="x", pady=6)
        profile = self._field(group, "Report disclosure", options=REPORT_PROFILES)
        format_ = self._field(group, "Report format", options=("html", "md", "json", "csv"))
        include_text = self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(group, text="Include selected records' free text after reviewing it", variable=include_text).pack(anchor="w")
        bar = self._bar(group)
        self._button(bar, "Preview selected report…", lambda: self.preview_report(source, profile.get(), format_.get(), bool(include_text.get())))

    def preview_report(self, source, profile, format_, include_text=False):
        from creator_reports import preview_report
        preview = preview_report(self.controller.store, self.world(), list(self._selected(source)), profile=profile, format=format_, include_text=include_text)
        self.report_preview = preview
        self._preview_window("Exact report preview", preview.document, lambda: self.save_report(preview),
                             "Save this reviewed report…", "Only selected records are included. Review private text, paths, URLs and omissions before saving.")

    def _preview_window(self, title, body, confirm, confirm_label, explanation=""):
        dialog = self.tk.Toplevel(self.pages[self.active_tab])
        dialog.title(title)
        dialog.geometry("900x650")
        parent = self.ttk.Frame(window_body(dialog), padding=12)
        parent.pack(fill="both", expand=True)
        self._note(parent, explanation)
        view = self._text(parent, 24)
        if isinstance(body, bytes):
            body = body.decode("utf-8")
        self._set(view, body, True)
        bar = self._bar(parent)
        self._button(bar, confirm_label, confirm)
        self._button(bar, "Close", dialog.destroy)
        return dialog

    def save_report(self, preview):
        from tkinter import filedialog
        from creator_reports import export_report
        if self.closed or preview is not self.report_preview:
            raise ValueError("This report preview is no longer current. Create a new preview.")
        extension = "." + preview.format
        path = filedialog.asksaveasfilename(title="Save reviewed creator report", defaultextension=extension)
        if path:
            self.controller.refresh_context()
            if preview is not self.report_preview:
                raise ValueError("The report preview changed. Review again before exporting.")
            export_report(preview, path)
            self.announce("Saved the exact reviewed report. No peer or server received it.")

    def review_share(self):
        self.controller.refresh_context()
        if self.closed or self.controller.app.demo or getattr(self.controller.app, "safe_mode", False):
            raise ValueError("Creator peer sharing is unavailable in Demo, startup Safe Mode, or a closed workspace.")
        selected = self._selected("history")
        if len(selected) != 1:
            raise ValueError("Select one record to review for optional peer sharing.")
        from tkinter import simpledialog
        record = self.controller.store.get(selected[0])
        coordinator = self.controller.peer_coordinator
        fields = coordinator.available_fields(record)
        peers = self.controller.app.peer_service.snapshot().get("peers", [])
        connected = [peer for peer in peers if peer.get("state") == "READY"]
        if not connected:
            raise ValueError("Connect an approved peer in VRC Eye → Networking first.")
        # Recipients and disclosure are chosen explicitly. The integration does
        # not infer that all connected peers should receive a private record.
        choices = "\n".join(str(p["peer_id"]) + " · " + str(p.get("alias", "Peer device")) for p in connected)
        recipient = simpledialog.askstring("Choose one peer", "Enter one connected peer ID:\n" + choices)
        if not recipient:
            return
        recipient = recipient.strip()
        allowed = {str(p["peer_id"]) for p in connected}
        if recipient not in allowed:
            raise ValueError("Choose an exact connected peer ID from the list.")
        disclosure = simpledialog.askstring("Choose fields", "Available fields: " + ", ".join(fields) + "\nEnter comma-separated fields to include. Blank includes no free text.", initialvalue="")
        if disclosure is None:
            return
        self.controller.refresh_context()
        if record["world_id"] != self.controller.current_world():
            raise ValueError("The workspace changed. Select the record again.")
        linked_run = record["id"] if record["kind"] in ("run", "test_run") else record["data"].get("run_id") or ""
        linked_build = record["data"].get("build_id") or ""
        review = coordinator.preview(record, world_id=self.world(), build_id=linked_build, run_id=linked_run, fields=tuple(f.strip() for f in disclosure.split(",") if f.strip()), context_token=self.controller.guard_token, peer_ids=[recipient])
        def share():
            self.controller.refresh_context()
            if self.closed or self.controller.app.demo or getattr(self.controller.app, "safe_mode", False):
                raise ValueError("Creator peer sharing is unavailable in this app mode. Nothing was sent.")
            if self.controller.peer_coordinator is not coordinator:
                raise ValueError("Peer services changed. Preview the record and recipient again.")
            result = coordinator.share(review, [recipient], context_token=self.controller.guard_token)
            if result["failed"]:
                raise ValueError("Peer send failed: " + "; ".join(item["reason"] for item in result["failed"]) + ". Preview again before retrying.")
            if not result["sent"]:
                raise ValueError("No peer send was requested. Preview again before retrying.")
            self.announce("Peer send requested. Delivery and acceptance are shown in VRC Eye.")
        self._preview_window("Exact peer-share preview", review["preview_text"], share, "Send this reviewed record", "Recipient device: " + recipient + "\nSharing roles grant no VRChat privileges. Previously sent copies cannot be revoked.")

    def import_peer_results(self):
        self.controller.refresh_context()
        records = self.controller.import_peer_results()
        self.refresh_history()
        self.announce(f"Imported {len(records)} accepted peer result(s), labeled as peer reports and not locally verified.")

    def build_controls(self, parent):
        self._note(parent, "Only declared helper controls are available. Manifest import does not prove the current loaded build or grant authority. Shared and persistent operations remain unavailable without an independently supported authorization route.")
        bar = self._bar(parent)
        self._button(bar, "Import helper manifest…", self.import_manifest)
        self._button(bar, "Audit declared debug exposure", self.audit_manifest)
        self._button(bar, "Find MIDI output ports", self.find_midi)
        self.loaded_build = self._field(parent, "Current loaded test build ID")
        self._button(self._bar(parent), "Confirm the build I am testing…", self.confirm_build)
        self.midi_port = self._field(parent, "Explicit MIDI output port")
        bar = self._bar(parent)
        self._button(bar, "Connect selected MIDI port", self.open_midi)
        self._button(bar, "Disconnect MIDI", self.close_midi)
        self._table(parent, "controls", (("label", "Declared control", 280), ("type", "Type", 100), ("scope", "Scope", 100), ("requirements", "Requirements", 320)), height=5)
        self.tables["controls"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_control))
        self.control_form = self.ttk.Frame(parent)
        self.control_form.pack(fill="x")
        self.control_value = None
        self.control_details = self._text(parent, 7)
        bar = self._bar(parent)
        self._button(bar, "Review selected control…", self.review_control)
        self._table(parent, "commands", (("label", "Control / request", 300), ("status", "Lifecycle", 170), ("scope", "Scope", 100)), height=5)
        self.tables["commands"].bind("<<TreeviewSelect>>", lambda _: self._call(self.show_command))
        self._note(parent, "Sent, accepted, applied and independently observed are separate states. A timeout never automatically retries a command. Ordinary OSC does not provide arbitrary Udon execution.")

    def import_manifest(self):
        from tkinter import filedialog
        world = self.world()
        path = filedialog.askopenfilename(title="Import creator-provided manifest", filetypes=(("JSON manifest", "*.json"),))
        if not path:
            return
        self.controller.refresh_context()
        if self.controller.current_world() != world:
            raise ValueError("The workspace changed while selecting a manifest. Choose it again.")
        result = self.controller.import_manifest(path)
        self.control_review = None
        self.announce("Creator-provided manifest imported. Loaded-build identity must be confirmed independently.")
        self.refresh(force=True)
        return result

    def refresh_controls(self):
        manifest = getattr(self.controller, "helper_manifest", None) or {}
        self._rows("controls", ((c["id"], (c.get("label", c["id"]), c.get("type", "Unsupported"), c.get("scope", "Unknown"), ", ".join(c.get("requirements", [])))) for c in manifest.get("controls", [])))
        if hasattr(self.controller, "control_requests"):
            self._rows("commands", ((r["id"], (r.get("label", r.get("control_id", r["id"])), r.get("status", "Unknown"), r.get("scope", "Unknown"))) for r in self.controller.control_requests()))

    def select_control(self):
        identity = self._selected("controls")[0]
        manifest = self.controller.helper_manifest or {}
        control = next(c for c in manifest.get("controls", []) if c["id"] == identity)
        for child in self.control_form.winfo_children():
            child.destroy()
        type_ = control.get("type")
        options = ("Off", "On") if type_ == "toggle" else tuple(control.get("options", ())) if type_ == "selection" else None
        self.control_value = None if type_ == "button" else self._field(self.control_form, "Requested state", options=options, value=str(control.get("min", "")) if type_ == "integer" else "")
        self.control_review = None
        self._set(self.control_details, json.dumps(control, indent=2, ensure_ascii=False), True)

    def review_control(self):
        identity = self._selected("controls")[0]
        control = next(c for c in (self.controller.helper_manifest or {}).get("controls", []) if c["id"] == identity)
        type_ = control.get("type")
        if type_ not in ("toggle", "selection", "integer", "button"):
            raise ValueError("This declared control type is unsupported.")
        if type_ != "button" and self.control_value is None:
            self.select_control()
            raise ValueError("Choose the requested state before reviewing this control.")
        value = True if type_ == "button" else self.control_value.get()
        if type_ == "toggle":
            if value not in ("On", "Off"):
                raise ValueError("Select On or Off explicitly before reviewing this control.")
            value = value == "On"
        elif type_ == "integer":
            value = int(value)
        review = self.controller.review_control(identity, value)
        self.control_review = review
        self._preview_window("Review declared control", json.dumps(review, indent=2, ensure_ascii=False), lambda: self.execute_control(review),
                             "Send this exact reviewed request", "Check the world, build, scope, affected systems and requested state. This request is not automatically retried.")

    def execute_control(self, review):
        if self.closed or review is not self.control_review:
            raise ValueError("The control review is no longer current. Review again.")
        result = self.controller.execute_control(review["id"], consent=True)
        self.control_review = None
        self.refresh_controls()
        self.announce("Control lifecycle: " + str(result.get("status", "Unknown")))

    def audit_manifest(self):
        from creator_helper import debug_audit
        manifest = getattr(self.controller, "helper_manifest", None)
        if not manifest:
            raise ValueError("Import a creator-provided manifest first.")
        self._set(self.control_details, json.dumps(debug_audit(manifest), indent=2, ensure_ascii=False), True)

    def show_command(self):
        identity = self._selected("commands")[0]
        record = next(r for r in self.controller.control_requests() if r["id"] == identity)
        self._set(self.control_details, json.dumps(record, indent=2, ensure_ascii=False) + "\n\nHelper-reported status is a claim; sent is not independently observed application.", True)

    def find_midi(self):
        ports = self.controller.midi_ports()
        self._set(self.control_details, "Available output ports:\n" + ("\n".join(ports) if ports else "None available. Desktop workflows remain available."), True)

    def open_midi(self):
        port = self.midi_port.get().strip()
        if not port:
            raise ValueError("Enter an explicitly selected MIDI output port.")
        self.controller.open_midi(port)
        self.announce("MIDI output connected. Every declared command still needs review.")

    def close_midi(self):
        self.controller.midi.close()
        self.announce("MIDI output disconnected.")

    def confirm_build(self):
        from tkinter import messagebox
        world = self.world()
        build = self.loaded_build.get().strip()
        if not build:
            raise ValueError("Enter the actual loaded test build identifier.")
        if not messagebox.askyesno("Confirm loaded test build", f"Are you currently testing build {build} in {world}?\n\nThis is your explicit manual confirmation, not proof from published metadata. It clears when the client session changes."):
            return
        self.controller.refresh_context()
        if self.controller.current_world() != world:
            raise ValueError("The workspace changed. Confirm the loaded build again.")
        self.controller.confirm_test_build(build)
        self.announce("Current test build manually confirmed for this session.")

    def close(self):
        if self.closed:
            return
        if "Metadata" in self.built and self.metadata_world:
            self._call(self.save_metadata, silent=True, world_id=self.metadata_world, preserve_invalid=True)
        self.closed = True
        self.report_preview = self.control_review = None
