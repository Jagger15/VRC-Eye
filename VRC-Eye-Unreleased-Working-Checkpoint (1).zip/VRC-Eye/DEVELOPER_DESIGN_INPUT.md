Yes—**VRC Eye’s Developer Mode should include a genuine VRChat API workbench, including direct reads, carefully reviewed writes, live response inspection, and detailed tracing of how those operations affect VRC Eye and VRChat.** It should not stop at log viewers, simulated buttons, or diagnostics that never actually interact with the service.

The earlier **Developer / Black Lab** ideas already covered raw API responses, endpoint and schema comparisons, request timing and rate-limit diagnostics, OSC inspection, parser fuzzing, mock sessions, simulated player/avatar/world events, corrupted-cache testing, feature overrides, forced failures, database repair, and compatibility testing.

Our existing specifications also established detailed event provenance, provider health, state dumps, replay testing, and a Player Store debugger. Those remain the foundation rather than being replaced by the API work.    Pasted markdown(3)    Pasted text

Below is the expanded design. Features described as proposed are roadmap items—not claims that they are already implemented.

# Part I — What Developer Mode should actually be

## 1. A developer workspace, not merely a “show more information” switch

Developer Mode should have two related purposes.

The first is **understanding VRC Eye**: why a player appeared, why an avatar was marked unavailable, why a request was delayed, why a notification was suppressed, why a permission check failed, or why a database migration changed something.

The second is **developing integrations with VRChat**: examining authorized API responses, testing a supported operation, comparing endpoint behavior, validating an adapter, observing OSC parameters, and connecting creator-side SDK events to the rest of VRC Eye.

Those purposes should share the same underlying services.

For example, a normal user clicking “Refresh World” and a developer testing that same world lookup should use the same request scheduler, authentication provider, cache, parser, and World Store. Otherwise, the developer tool might work while the real feature remains broken.

The workbench should answer:

> What did we intend to do, what actually happened, what evidence supports that conclusion, and which component made each decision?

That is the central organizing principle.

## 2. Keep the earlier decision: unrestricted developer access during preparation

We previously settled on **keeping Developer Mode unrestricted during early development**, with stronger entitlement controls deferred. The existing OSC specification explicitly preserves that decision while distinguishing visibility from permission enforcement.    Pasted markdown(8)

That means we do not need to interrupt development now with account-bound developer keys, device enrollment, or a separate restricted build.

However, there are three different permissions involved:

| Permission                 | What it means                                                                      |
| -------------------------- | ---------------------------------------------------------------------------------- |
| Developer workspace access | Whether someone can open VRC Eye’s developer tools.                                |
| VRC Eye action permission  | Whether a particular feature, plugin, peer, or interface may request an operation. |
| VRChat authorization       | Whether VRChat permits the authenticated account to perform that operation.        |

Opening Developer Mode affects the first row. It should not silently grant the other two.

For the earlier login-dependent API features, live account access remains separate from local development. A parser test, database inspection, or offline replay should not require a VRChat login.

Later, the universal build could support signed developer entitlements or an optional developer module. That should remain an access-management project, not a prerequisite for building the tools.

## 3. Separate the interfaces that people often call “the VRChat API”

We should explicitly distinguish the **web API**, its **real-time event pipeline**, **OSC/OSCQuery**, and the **Unity SDK’s public APIs**. These are different integration surfaces with different purposes. VRChat documents OSC and public SDK interfaces directly; the web API reference is community-maintained and can change without notice. [VRChat](https://docs.vrchat.com/docs/osc-overview)

Inside VRC Eye, every capability should identify its actual route.

For example:

| Proposed capability                           | Appropriate integration route         |
| --------------------------------------------- | ------------------------------------- |
| Inspect an accessible world record            | Web API                               |
| Observe an account notification               | WebSocket pipeline                    |
| Change a compatible avatar parameter          | OSC                                   |
| Discover advertised OSC parameters            | OSCQuery                              |
| Observe a creator’s build result              | Unity SDK integration                 |
| Read an intentionally exposed helper event    | Creator helper integration            |
| Observe additional optional runtime telemetry | Separately reviewed bridge capability |

This prevents misleading claims such as “API connected, therefore we can inspect every Unity object.”

It also prevents the opposite mistake: treating legitimate web API functionality as though it requires a custom-client bridge.

**The direct API workbench should remain useful with ordinary VRChat and no bridge.**

## 4. Give it a coherent home in the interface

I would create one dedicated Developer workspace with grouped sections rather than dozens of disconnected debug windows.

| Developer section     | Main contents                                                               |
| --------------------- | --------------------------------------------------------------------------- |
| Overview              | Feature health, active environment, important failures, running experiments |
| API Workbench         | Endpoint catalog, requests, responses, authorized action testing            |
| Events & State        | Event streams, Player Store, World Store, ownership and provenance          |
| Testing Lab           | Simulator, replay, failure injection, parser tests                          |
| Data & Recovery       | Cache, database inspection, migrations, repair previews                     |
| Integrations          | OSC, SDK, creator helpers, Runtime Companion, optional bridges              |
| Performance & Reports | Profiling, compatibility comparisons, Black Box, sanitized exports          |

Transport configuration should stay in **VRC Eye → Networking**, consistent with our existing organization. Developer pages should link to those settings rather than maintain competing copies.    Pasted markdown(8)

A persistent header should show the selected environment, active account alias, whether live writes are enabled, and whether an experiment is running.

That header matters more than decorative warning colors. A developer should never have to guess whether a request will touch real account data.

## 5. Make Live, Sandbox, and Replay genuinely different environments

These should not be three labels over the same execution path.

**Live** means VRC Eye can communicate with real services through an authorized integration.

**Sandbox** means synthetic accounts, fake resources, a separate database, and controlled responses. It should not possess live credentials or a working route to production writes.

**Replay** means previously captured, sanitized events are being fed back through VRC Eye’s processing logic.

The isolation needs to exist below the interface. A replayed “send invite” event must not become a real invitation merely because a listener was accidentally left attached.

I would give each environment its own service wiring, storage namespace, action executor, and outbound-network policy. Replay would use a recording executor that says, “The application would have requested this action,” without performing it.

Switching environments should cancel pending work and clear environment-specific state. It should not carry a queued write from Sandbox into Live.

# Part II — The direct VRChat API workbench

## 6. Establish the actual API boundary without watering down the feature set

VRChat’s published Creator Guidelines permit API applications under conditions, while warning that endpoints are unsupported for public use and may change. The same guidelines restrict credential collection, uploads on another user’s behalf, unmetered traffic, and acting for users from external infrastructure. They also require proper application identification. [hello.vrchat.com](https://hello.vrchat.com/creator-guidelines)

That does **not** mean our developer tools must be limited to fake data.

It means the architecture should distinguish:

**Personal developer experiments:** operations performed by the developer against resources their own account can legitimately access.

**Public application features:** functionality that also needs a reviewed authentication and distribution model.

**Supported creator integrations:** extensions within the creator’s own SDK workflow.

**Unverified capabilities:** ideas whose technical behavior or permitted integration route still needs investigation.

The workbench should make these distinctions visible per operation, not bury them in one disclaimer.

## 7. Build a versioned endpoint catalog

The endpoint catalog should be more useful than a list of URLs.

Every entry should describe its method, route, purpose, request structure, response structure, authentication requirement, side effects, applicable resource types, expected errors, compatibility evidence, and last verification date.

It should also record **where our understanding came from**:

> Community reference revision; local adapter version; test fixture; most recent successful observation.

A catalog entry should never imply that every field present in a response is writable.

For instance, a world response may contain identifiers, counts, publication information, and package metadata. The editor should expose only fields that the corresponding write operation actually accepts.

Each operation should have a status such as **implemented**, **observed but not integrated**, **experimental**, **temporarily disabled**, or **reference only**.

“Reference only” is important. Documentation completeness should not automatically turn every described operation into a clickable live action.

## 8. Treat authentication as a distinct engineering and release issue

The community reference documents session-based authentication and warns against repeatedly creating new sessions. Meanwhile, VRChat’s official guidance says applications should not request or store other users’ credentials or session information. A technically functioning login flow is therefore not, by itself, evidence that our public-release authentication design is acceptable. [VRChat Community](https://vrchat.community/reference/get-current-user)

I would make the authentication panel a **state inspector**, not a secret viewer.

It should display the selected account alias, connection state, last successful authenticated request, pending verification state, session invalidation reason, and whether work is paused.

It should never provide “copy auth token” as a routine debugging convenience.

There is also a current documentation nuance: the community reference describes an OAuth redirect-code operation requiring an existing session, plus service-specific SSO tokens. Those entries do not establish a general self-service OAuth integration for VRC Eye. We should not present that problem as solved. [VRChat Community](https://vrchat.community/reference/get-oauth-redirect-code)

For public distribution, the sign-in approach needs its own explicit review. Encrypting cookies locally would not, on its own, resolve the policy question.

For development, we can still design and test the entire adapter architecture with synthetic authentication states and appropriately authorized personal experiments.

## 9. Add a raw request and response inspector

This should be one of the main developer features.

For every request, the inspector should show:

**Origin:** which feature, interface, plugin, or developer action initiated it.

**Intent:** what the application was attempting to accomplish.

**Transport:** method, sanitized route, timing, status, response size, and retry history.

**Interpretation:** which parser handled the response and what it produced.

**Consequences:** which cache entries, application stores, and visible fields changed.

A useful trace might look like this:

```
Action: world.refresh
Origin: World Creator workspace

Request:
GET world record
Account: Developer account A
Queue wait: 18 ms
Network duration: 241 ms

Response:
HTTP 200
Schema adapter: world-v3
Unknown fields: 1

Application result:
World Store revision 184 → 185
Description changed
Creator ownership unchanged
```

Those are illustrative values, not observed results.

The inspector should support filtering, searching, pinning, comparing two responses, and jumping directly to the state changes caused by a request.

“Raw” should mean **before VRC Eye’s interpretation**, not “credentials and private data are exposed without controls.”

## 10. Instrument VRC Eye’s own traffic rather than intercepting everything

The default network inspector should observe requests made by VRC Eye’s own API service.

That gives us precise attribution without needing to intercept unrelated browser sessions or VRChat’s encrypted traffic.

It also makes the records more useful. We know which feature initiated a request, which cancellation token controlled it, which policy decision allowed it, and which application state was waiting for the result.

A generic packet capture cannot automatically provide those explanations.

For SDK-side integrations, the integration should report its own structured lifecycle events. For peer networking, VRC Eye should instrument its own transport. For OSC, it should inspect packets passing through its own routing service.

This keeps the developer workbench focused on interfaces we actually control and can meaningfully explain.

## 11. Add a request composer that can send real, reviewed operations

The request composer should support path parameters, query parameters, structured bodies, saved requests, response comparisons, and environment selection.

It should offer two editing styles.

**Guided mode** would generate a form from the operation definition.

**Developer mode** would expose the request structure directly while still using the same validation, authorization, and scheduling services.

Before execution, a preview should summarize:

> This request changes your selected world’s description. It does not upload content. It will use account A. The existing value was last checked 12 seconds ago.

Imported request collections should be treated as data. They should not execute embedded scripts, access arbitrary files, or inherit credentials for an unrelated host.

A developer should be able to adjust a query, inspect an unexpected field, and test a new adapter. They should not accidentally turn a copied request into a credential-bearing call to an arbitrary destination.

## 12. Classify operations by behavior, not only by HTTP method

We should not use a rule as simplistic as “GET is harmless; everything else is dangerous.”

The documented current-user endpoint can perform authentication when credentials are supplied, illustrating why the operation’s semantics matter. [VRChat Community](https://vrchat.community/reference/get-current-user)

Each operation should explicitly declare whether it reads data, creates a session, changes account state, changes a resource, sends something to another person, or performs a destructive action.

It should also declare whether it is safe to retry, whether verification is available, and whether an inverse operation exists.

A read-only experiment might still expose sensitive account data. A metadata edit might be reversible. An invitation might be harmless in isolation but should not be repeatedly sent by a test runner.

This behavioral classification should drive the composer, permission checks, replay behavior, and audit trail.

## 13. Give live writes a complete action lifecycle

A server-changing request—often called a *mutation*—should move through a visible sequence.

The proposed sequence is:

```
Draft
→ Validate
→ Check account and resource permissions
→ Check current resource state
→ Preview exact change
→ Obtain confirmation where required
→ Queue
→ Revalidate before dispatch
→ Send
→ Interpret response
→ Verify observable result
→ Update local state
→ Record outcome
```

The second validation before dispatch matters. An action may sit in a queue while the user changes accounts, leaves a group, switches worlds, or edits the same resource elsewhere.

A confirmed action should be bound to its original account, resource, payload, and relevant context. Changing one should invalidate the previous confirmation.

A success message should also describe what succeeded.

“Request accepted” is not the same as “the new avatar is visibly loaded.”

“Metadata updated” is not the same as “every running instance is now using a new world build.”

## 14. Distinguish rejection, failure, cancellation, and unknown outcome

This is one of the most important details in the entire API design.

Suppose VRC Eye sends an operation and the connection drops before the response arrives. There are at least two possibilities: the server never applied it, or the server applied it but the response was lost.

The application should not collapse both into “failed—retry?”

I would model outcomes as **not sent**, **rejected**, **completed**, **cancelled before dispatch**, **verification pending**, and **outcome unknown**.

For an unknown outcome, the next step should be a supported verification read when one exists—not an automatic duplicate write.

An internal action ID helps VRC Eye recognize its own repeated attempts, but it does not magically give VRChat server-side duplicate protection.

Similarly, “Undo” should mean a separately reviewed compensating action. It should not promise that an invitation can be unsent or that a sequence of account changes is one reversible transaction.

## 15. Create one shared request scheduler

Every API-backed feature should use the same scheduler.

The Player List should not have one independent polling loop while the World tab, Avatar tab, Developer tab, and overlay each make their own copy of the same request.

The scheduler should merge duplicate reads, prioritize user-triggered work, cancel stale work, limit concurrency, and expose why a request is waiting.

A request could be waiting because of a local budget, a server-requested cooldown, an account transition, a resource lock, or another request already fetching the same data.

The developer view should show those reasons directly.

VRChat’s guidance calls for caching, backoff, appropriate handling of HTTP errors, and avoiding synchronized polling spikes. The community documentation also warns that rate limits should not be treated as a predictable fixed allowance. [VRChat](https://hello.vrchat.com/creator-guidelines)

We should therefore expose **VRC Eye’s configured budget** separately from **anything actually reported by the server**.

No invented “VRChat allows exactly this many requests” indicator.

## 16. Make retry behavior inspectable

The scheduler should record each retry decision.

For a failed read, the trace might say:

> Temporary network failure; eligible for retry; next attempt delayed; maximum attempt count not reached.

For a permission failure:

> Not retried because the response indicates insufficient authorization.

For an uncertain write:

> Automatic retry suppressed because the original operation may already have completed.

Where a meaningful retry delay is supplied, the adapter should honor it. Otherwise, VRC Eye should use its own conservative backoff with randomized timing.

A developer should be able to simulate these cases locally and see exactly which rule was selected.

The retry controller should also expose a circuit breaker: a temporary pause that prevents one failing provider from generating an endless stream of work.

Opening a debug panel must not bypass that pause.

## 17. Add a cache inspector with reasons, not just contents

The cache inspector should explain why a value is being reused.

Each entry should carry its account scope, resource key, source operation, fetch time, expiry policy, validation state, and dependencies.

It should distinguish **fresh**, **stale but usable**, **refreshing**, **invalidated**, and **unavailable**.

For example:

> The world description is cached and usable. A refresh is running. The publication-state panel requires fresher data and is waiting.

Developer actions should include refreshing one resource, invalidating a particular family, comparing cached and incoming values, and testing stale-data behavior.

A “clear everything” button can exist, but it should not be the primary repair strategy.

Most importantly, account-specific entries must not cross account boundaries. Switching accounts should not briefly show the previous account’s private data while a refresh catches up.

## 18. Build a pagination debugger

List endpoints deserve their own tooling because many subtle problems happen between pages.

The debugger should show the request parameters for each page, returned item count, duplicate identifiers, continuation information, and why retrieval stopped.

It should distinguish:

> Complete according to the endpoint’s pagination mechanism.

from:

> Stopped because VRC Eye reached its configured inspection limit.

Those are not the same result.

The test lab should cover empty middle pages, repeated pages, items appearing or disappearing between requests, malformed continuation data, and cancellation halfway through.

The UI should never silently present a partial result as “all friends,” “all favorites,” or “all group activity.”

For changing datasets, the debugger should also make clear that a multi-page fetch is not necessarily a perfectly simultaneous snapshot.

## 19. Add a WebSocket pipeline inspector

The community reference describes VRChat’s pipeline as a receive-only event stream. It also documents messages whose contents require an additional decoding step. We should treat it as an event source, not a channel for sending arbitrary commands. [VRChat Community](https://vrchat.community/websocket)

The inspector should display connection lifecycle, decoded event type, arrival time, parsing outcome, duplicate handling, downstream state changes, and reconnect behavior.

A particularly valuable view would show the complete chain:

> Pipeline event arrived → account state updated → notification policy evaluated → popup suppressed because Companion Mode owns that notification.

Unknown event types should be recorded in a bounded diagnostic form rather than crashing the connection.

On reconnect, VRC Eye should not assume it received every event during the interruption. It should perform appropriately scoped reconciliation and mark any interval whose completeness is unknown.

Locally assigned sequence numbers should be labeled as local. They are not evidence of a server-provided global ordering.

## 20. Build a response-to-state comparison tool

For a selected resource, the workbench should display several representations side by side:

**Received response:** sanitized data before normalization.

**Parsed model:** what the API adapter understood.

**Application store:** what VRC Eye currently considers authoritative.

**Visible interface:** what a particular page is displaying.

This would make bugs much easier to isolate.

A world might have the correct name in the response but an old name in the store. That points toward parsing or reconciliation.

The store might be correct while the interface remains old. That points toward UI subscriptions or rendering.

The response itself might be old while the cache claims it is fresh. That points toward cache policy or request handling.

The tool should identify the first stage where the representations diverged.

# Part III — Concrete features that interact closely with the API

## 21. Connected-account and own-profile workbench

The account workbench should expose the account data needed to understand VRC Eye’s integration, using the documented current-user operation as one reference point. [VRChat Community](https://vrchat.community/reference/get-current-user)

Its normal view should focus on useful state: account identity, connection health, supported profile fields, relevant permissions, and current integration status.

Its developer view should show field-level provenance and the difference between an observed value, a cached value, and a locally requested value.

For supported own-profile edits, I would add a change composer that sends only the reviewed fields rather than round-tripping the entire account response.

That avoids turning a large response object into an accidental write payload.

Account security, identity verification, and similarly sensitive account-management operations should not become generic test buttons. The workbench’s purpose is developing the companion, not making every account operation equally easy to trigger.

## 22. World metadata inspection and controlled editing

This is a strong candidate for direct API functionality.

The community reference documents a world-update operation at `PUT /worlds/{worldId}`. It should be treated as an unofficial integration whose accepted fields and authorization need validation. [VRChat Community](https://vrchat.community/reference/update-world)

The proposed world workbench should provide a structured metadata view, a sanitized raw view, field comparisons, current ownership evidence, pending local edits, and a record of previous snapshots captured by VRC Eye.

For fields supported by the verified adapter, the editor could prepare changes to descriptions, names, tags, or capacity-related settings.

A three-way comparison would be particularly useful:

> Value when editing began; value currently on the service; value the user now proposes.

Where an endpoint supports a suitable concurrency mechanism, use it. Otherwise, a last-moment comparison can reduce accidental overwrites, but the UI should not pretend it provides a fully atomic guarantee.

World ownership should make creator tools discoverable. The server’s authorization remains decisive.

## 23. Publication and platform-state diagnostics

The World Creator tools should have a publication-state inspector that keeps separate the resource’s reported publication state, available platform packages, local project state, and the last build known to VRC Eye.

The API reference includes world publication and package-related information, but VRC Eye’s proposed history would be a record of what it observed—not a reconstruction of every historical state VRChat has ever stored. [VRChat Community](https://vrchat.community/getting-started)

A useful report might say:

> The local project was built after the last successful upload recorded by this workspace. The service currently reports a Windows package. No matching Android package was observed in the latest accessible response.

The wording should remain tied to evidence.

An absent field, an unavailable request, and a genuinely missing package should be different states.

Publication-changing actions should have their own preview and confirmation. They should not be hidden inside a general “save metadata” button.

## 24. Avatar metadata and selection workbench

The community reference documents both avatar metadata updates and a selection operation at `PUT /avatars/{avatarId}/select`. [VRChat Community](https://vrchat.community/reference/update-avatar)

I would include authorized avatar-record inspection, comparisons between snapshots, supported metadata edits for owned resources, and explicit selection of an avatar the account is permitted to use.

The selection workflow should expose separate milestones:

**Requested:** VRC Eye initiated the operation.

**Acknowledged:** the API returned an interpretable result.

**Observed:** a supported local source indicated the selected avatar changed.

**Ready:** a source with the necessary capability indicated readiness.

The last two must not be fabricated merely because the HTTP request succeeded.

This workbench should not equate access to an avatar record with ownership of its source project or permission to extract its assets.

The API record, creator workspace, and live avatar state are related—but they are not interchangeable.

## 25. Instance inspection, creation, and join diagnostics

The community reference includes an instance-creation operation at `POST /instances`. [VRChat Community](https://vrchat.community/reference/create-instance)

The proposed instance workbench should parse known instance references, display the settings the account can access, prepare supported creation requests, and explain the results.

It should keep **instance created**, **join requested**, **client traveling**, and **local arrival observed** separate.

A created instance is not proof that the local client joined it.

Likewise, a recently reported population count should carry an observation time rather than being presented as a guaranteed live roster.

This section should also explain distinct roles: world author, instance creator, group owner, group role holder, and creator-defined world authority. VRC Eye should not treat one label as granting every other kind of control.

Testing should use resources and sessions the developer is entitled to manage—not attempts to discover hidden locations.

## 26. Friends, invitations, and notification lifecycle tools

These should include real account operations where the selected integration supports them, not merely local stand-ins.

The community reference describes friend requests, invitations, invitation requests, and notification operations. [VRChat Community](https://vrchat.community/getting-started)

The developer value is in exposing their lifecycle.

For an invitation, the trace should distinguish the user’s intent, request submission, API result, any later relevant event, local notification handling, and final known state.

The test environment should simulate expired notifications, duplicate events, acceptances arriving after refresh, and reconnects during a pending operation.

Live actions should remain individual and deliberate. A “repeat until something happens” test makes sense against a mock server, not against another person’s notifications.

Companion Mode should be able to suppress duplicate presentation without suppressing the underlying state update.

## 27. Favorites inspection and synchronization planning

The favorites workbench should compare VRC Eye’s local collections with the account’s accessible service-side favorites.

It should be able to prepare an explicit synchronization plan:

> Add these entries; leave these unchanged; remove these selected entries; these operations cannot currently proceed.

The reference includes an account favorite-limits endpoint, so supported limits should be read from the relevant account response rather than assumed from a fixed UI layout. [VRChat Community](https://vrchat.community/reference/get-favorite-limits)

A multi-operation synchronization should maintain per-item outcomes.

If seven changes succeed and the eighth fails, the report should preserve that partial result. It should not pretend the entire job either fully happened or fully rolled back.

Local bookmarks should remain a separate feature. VRC Eye can keep its own organizational information without misrepresenting it as additional server-side favorite capacity.

## 28. Group permissions and audit-log workbench

This could become one of the most useful API-close developer areas.

The reference documents group audit-log retrieval and a group-permissions catalog. Importantly, a list of possible permissions is not automatically a list of permissions granted to the current user. [VRChat Community](https://vrchat.community/reference/get-group-audit-logs)

Our workbench should therefore separate:

**Permission definitions:** what a permission means.

**Role assignments:** what roles are reported for the current account.

**Effective capability:** what VRC Eye believes the account may currently do.

**Server result:** whether the attempted operation was actually authorized.

The audit viewer should support scoped filtering, pagination diagnostics, sanitized exports, and correlation with actions initiated by VRC Eye.

For supported group-management writes, the preview must specify the scope. Removing group membership, changing a role, and performing an instance-specific moderation action should never share an ambiguous “Remove user” label.

## 29. Personal moderation-state inspection and controlled actions

This is another concrete API-adjacent area, particularly relevant to the Safety system.

The community reference distinguishes personal player-moderation records from staff moderation and documents operations such as mute, block, hide-avatar, and show-avatar preferences. [VRChat Community](https://vrchat.community/reference/moderate-user)

I would add an inspector for the account’s own reported moderation choices and a controlled action path for supported changes.

The UI should keep three things separate:

> Account preference requested; service-side preference observed; immediate client behavior confirmed or unconfirmed.

That distinction prevents the Safety system from claiming an immediate protective effect that its current evidence cannot establish.

“Reset to default” must also be distinguished from applying the opposite explicit preference.

A developer should be able to inspect why the application chose a particular safety action without gaining a way to bypass another person’s privacy or platform controls.

## 30. Service configuration and compatibility snapshots

The workbench should capture selected accessible service-configuration and notice data when the integration legitimately provides it.

The API reference includes configuration and service-information operations. [VRChat Community](https://vrchat.community/getting-started)

Our proposed tool should compare snapshots and identify changes that might affect an adapter.

For example:

> A previously observed value is absent; a new option appeared; a field changed type; a feature now reports unavailable.

The local compatibility layer should interpret those changes conservatively.

A reported feature flag is evidence about service state, not permission for VRC Eye to force-enable that feature.

Similarly, an entitlement field should be treated as an observation. Changing VRC Eye’s local copy must not be presented as changing the account’s actual entitlement.

## 31. A deliberate experimental-endpoint registration workflow

We should leave room for close API development beyond the initially implemented operations.

A developer could register a new operation definition with a route, request schema, response schema, side-effect classification, reference evidence, resource scope, and test cases.

The first stage should be local: validate it against fixtures and a mock executor.

The next stage could be a deliberately initiated live test against a resource the developer is authorized to use, provided the integration route has been reviewed.

The experiment should record what was expected, what was observed, and what remains unknown.

It should not silently graduate into a normal feature after one successful request.

This gives us room to investigate unfamiliar API behavior without making Developer Mode an indiscriminate endpoint-probing tool.

# Part IV — Events, state, simulation, and failure testing

## 32. A unified event inspector

Every significant subsystem should emit structured events into the same developer-facing event system.

Events should contain a type, source provider, application session, relevant account or resource scope, receive time, optional source time, correlation identifier, and processing result.

An event’s payload should be separate from its metadata so the recorder can retain useful structure without retaining unnecessary private content.

The inspector should support filtering by player, world, avatar, provider, action, or incident.

It should also distinguish an original event from a derived conclusion.

For example:

> API response received.

is different from:

> World ownership resolved.

and both are different from:

> Creator tools made visible.

Clicking the final UI event should let the developer trace backward to the evidence and decisions that produced it.

## 33. Store inspectors for players, worlds, avatars, and runtime state

Our earlier Player List plan already called for a Developer-mode Player Store console with state dumps, simulation, reconciliation, and queue visibility.    Pasted text

I would extend that pattern across VRC Eye.

Each store inspector should show the current record, revision, last update, responsible provider, pending work, unresolved conflicts, and relevant event history.

For players, it should explain provisional identities, merges, active encounters, recently left records, and stale roster information.

For worlds, it should separate the current local session from API metadata and creator workspace data.

For avatars, it should separate the selected identifier, metadata record, parameter schema, and loading observations.

A repair or reconciliation button should generate a preview where possible. “Reconcile” should not mean silently inventing missing facts.

## 34. Field-level provenance and confidence

A single “source: API” label on a large object is not enough.

A player record may combine an identity from a log, profile details from an API response, an encounter time from local history, and optional telemetry from a bridge.

Each important field should retain its own provenance.

I would show whether the value is **directly observed**, **derived**, **cached**, **inferred**, or **unavailable**.

Conflicting evidence should remain inspectable.

For example:

> A local session event says the player left. A delayed profile response arrived afterward. The profile response updated metadata but did not restore the player to the active roster.

This is where many subtle bugs become understandable.

The provenance system should explain why a value won, not just display the winning value.

## 35. Clock and ordering diagnostics

VRC Eye should record both human-readable timestamps and an appropriate monotonic time for local durations.

For remote sources, it should preserve source-provided time separately from local arrival time.

That lets the developer distinguish an event generated earlier but received late from an event genuinely generated later.

Peer clock-offset estimates should carry uncertainty rather than claiming perfect synchronization.

The event inspector should also show the scope of each sequence number: local process, provider connection, replay file, or peer session.

Ordering rules should be explicit. A delayed response from an older account session should not overwrite data belonging to the current session.

This deserves dedicated tests because an otherwise correct parser can still produce incorrect state when events arrive in an unexpected order.

## 36. Log-parser development tools

VRChat’s creator documentation describes its output logs and additional Udon debugging options. It also warns that verbose debugging increases log volume and can reduce performance. [VRChat Creators](https://creators.vrchat.com/worlds/udon/debugging-udon-projects/)

Our parser workbench should accept a supplied log segment and show the line classification, extracted fields, normalized event, and resulting state update.

It should support comparing two parser versions against the same input.

Tests should cover incomplete lines, multiline exceptions, repeated messages, Unicode, truncated files, rotation, unknown formats, and data arriving in small chunks.

A parser failure should identify the specific rule and input position without dumping unrelated private log content.

The tool should also report lines that were intentionally ignored. Otherwise, “no events produced” could mean either that nothing relevant happened or that the parser stopped recognizing the format.

## 37. A synthetic VRChat-session simulator

The simulator should create controlled player, world, avatar, API, runtime, and integration events.

This extends the fake-roster and Runtime Companion simulators already described in our specifications.    Pasted markdown(4)    Pasted text

A scenario could represent a world join, several player arrivals, delayed identity resolution, avatar changes, an API interruption, and a bridge disconnect.

The key is that the simulator feeds the same application logic used in normal operation.

It should support repeatable random seeds, virtual time, saved scenarios, expected final states, and event-by-event stepping.

Synthetic players should be visibly synthetic and stored separately from real encounters.

A simulated crash should change the simulated provider’s state. It should not intentionally crash VRChat to test the interface.

## 38. Deterministic replay

Replay should allow a developer to take a sanitized incident and run it through a particular VRC Eye version.

The replay controller should support pause, single-step, speed changes, checkpoints, and jumps to a particular action or failure.

It should capture not only the incoming events but also the configuration needed to interpret them: relevant feature flags, adapter versions, state-machine versions, and policy settings.

Otherwise, two replays of the same events may differ for reasons that are invisible.

A powerful comparison would run the same fixture through two application builds and show the first divergent state.

For example:

> Both versions processed the same leave event. The older build retained a player row; the newer build closed the encounter.

Replay should explain the difference without making any live network changes.

## 39. Failure injection across individual providers

The failure lab should simulate delayed API responses, malformed responses, rate limiting, unavailable databases, missing logs, stale OSC discovery, peer disconnects, and renderer telemetry gaps.

Failures should be injectable at a particular point in an action’s lifecycle.

“Fail before sending” and “lose the response after sending” should be different test cases.

The resulting application behavior should be evaluated per subsystem.

The existing design already says that API, bridge, and database failures should not automatically destroy the live Player List; unavailable sources should degrade their own fields appropriately.    Pasted text

I would extend that principle throughout VRC Eye.

The dashboard should show a partial failure precisely rather than turn every indicator red because one optional provider stopped responding.

## 40. Parser fuzzing and property-based tests

Fuzzing here means generating unusual inputs to test **our own parsers and adapters locally**.

Useful cases include oversized strings, unexpected nulls, deeply nested structures, invalid enum values, duplicate identifiers, missing fields, and unusual event orderings.

The test runner should impose memory and execution limits so the test itself cannot freeze the application indefinitely.

Property-based tests should verify rules that remain true across many generated scenarios.

Examples include: a duplicate join does not create a duplicate active record; an old-account response cannot update the new account; a replay cannot perform a live action; an unknown permission value cannot grant authority.

When a generated case fails, the lab should preserve the seed and reduce the input to a smaller reproducible example.

None of this requires sending malformed traffic to VRChat’s production service.

## 41. Feature-flag overrides and forced failures

The earlier Black Lab plan included feature overrides, and they remain useful.

A developer should be able to enable a VRC Eye prototype, force a local fallback path, simulate a missing capability, or test how an unavailable feature is presented.

Every override should have an owner, scope, reason, activation time, and expiry or reset behavior.

A session-only override should disappear when the session ends.

The interface should display a persistent “overrides active” indicator, with a readable list of the changes.

These are **VRC Eye’s local implementation flags**. They should not pretend to alter VRChat’s server permissions, account entitlements, or platform restrictions.

A “restore standard behavior” action should disable overrides and cancel incompatible pending experiments.

## 42. Separate application testing from live service testing

Most regression tests should run without VRChat, without a real account, and without network access.

Live checks should be a small, explicitly selected category.

The test runner should show its execution plan before starting:

> Offline parser tests; database migration tests; replay tests; no live service operations.

Or:

> One authorized live read; no writes; selected account and resource shown.

Tests that change real state should not run automatically because someone clicked “Run all.”

They should be individually classified, scoped, and reviewed.

This keeps a large developer suite practical. We can test thousands of event sequences locally while reserving service access for the small number of behaviors that genuinely require it.

# Part V — Data, recovery, and compatibility

## 43. Database inspection and repair

The database workbench should expose schema version, migration history, table sizes, queue health, integrity results, and relevant record relationships.

For routine inspection, I would prefer safe query presets and a constrained read-only connection over an unrestricted console attached to the live database.

Repair should be a staged process.

First diagnose. Then create a consistent backup or working copy. Apply the proposed repair to that copy. Run integrity and application-level checks. Show the difference. Only then offer replacement of the active database under controlled conditions.

A repair report should say which records changed and why.

It should distinguish disposable cached data from user-authored notes, saved presets, encounter history, and other information that may not be reconstructible.

These tools should operate on VRC Eye’s data. They should not become a route for editing VRCX’s database or harvesting another application’s authentication state.

## 44. Migration and rollback testing

Every database or configuration migration should have a testable contract.

The lab should be able to create an older supported data layout, run the migration, compare expected results, and simulate interruption.

Tests should cover low disk space, permission failures, partially written files, duplicate startup attempts, and a previous migration that did not finish cleanly.

Application rollback and data rollback should be treated separately.

Installing an older executable does not necessarily make it capable of understanding a newer database.

The update system should therefore record compatibility boundaries and preserve appropriate recovery material before irreversible changes.

This fits the simpler distribution direction we discussed: one launcher can coordinate setup and migrations without scattering separate installation scripts around the package.

## 45. Schema and endpoint compatibility laboratory

A *schema* is the expected structure of a request or response.

The compatibility lab should compare our pinned expectation with sanitized observed responses and test fixtures.

It should classify changes as added fields, removed fields, type changes, new enum values, changed nullability, changed error shapes, or altered behavior.

The response parser should usually tolerate harmless extra information. A write builder should be stricter because sending an unexpected field can have consequences.

A new field should not automatically become a new editable control.

Compatibility reports should also distinguish:

> The service changed.

from:

> The community specification changed.

from:

> Our adapter changed.

Those events are related but not identical.

An observed discrepancy should produce a reproducible local case and identify which real features are affected.

## 46. Diagnostic redaction before persistence

Our existing Black Box design already requires sanitized bundles, export previews, and removal of credentials, private instance information, and sensitive local paths.    Pasted markdown(3)

I would move that protection earlier in the pipeline.

Sensitive values should be removed or transformed before they reach persistent diagnostic logs—not only when a ZIP file is exported.

Unknown response fields deserve conservative handling because a new server field could contain information our old redactor does not recognize.

Exports should support stable pseudonyms within one bundle so a developer can follow “Player A” across events without receiving the original identifier.

Those pseudonyms should not create a permanent cross-bundle tracking identity.

The preview should show included categories, redacted categories, omitted payloads, and whether the bundle contains any manually added files.

## 47. Retention and diagnostic scope

The developer recorder should not quietly become a permanent archive of every account response and social event.

I would separate short-lived request diagnostics, incident recordings, explicitly saved test fixtures, and user-managed history.

Each category should have its own retention policy.

Saving an API response as a regression fixture should require sanitization and a clear label describing why it is retained.

A crash incident should preserve the relevant interval rather than the entire day’s activity by default.

The developer workspace should also show its own storage use and allow selective deletion.

Privacy-sensitive categories such as wellness state, private notes, and message content should be excluded from ordinary developer exports unless specifically necessary and deliberately included.

# Part VI — Integration-specific developer tools

## 48. OSC and OSCQuery inspection

VRChat documents OSC avatar parameters and OSCQuery as supported integration surfaces. OSCQuery discovery and OSC message delivery should be inspected separately. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

The developer tools should show discovered services, parameter addresses, types, advertised access, observed values, route ownership, write conflicts, queue state, and validation failures.

A parameter trace should explain which controller requested a value and why the routing service allowed, transformed, delayed, or rejected it.

The inspector should distinguish an observed incoming value from a desired outgoing value.

That is essential when two applications are trying to control the same parameter or when a write has been sent but no confirmation is available.

Connection testing should begin with discovery and passive observation. Our existing OSC specification already rejects using unexpected movement, microphone changes, or other visible actions as silent connection tests.    Pasted markdown(8)

## 49. Public Unity SDK integration

VRChat’s public SDK API exposes build lifecycle hooks, upload-result events, and build/test methods, and recommends public interfaces rather than reflection into SDK internals. [VRChat Creators](https://creators.vrchat.com/sdk/public-sdk-api/)

The Developer workspace should receive structured events from an optional editor integration running in the creator’s own project.

It could show the selected project, SDK version, target platform, build start, validation result, build completion, upload outcome, and associated workspace record.

The connection should identify which project produced the event. Two Unity projects open at once must not overwrite each other’s state.

The editor integration should send only the information VRC Eye needs, not arbitrary project contents or authentication material.

For publication workflows, I would keep the creator in the supported SDK process rather than add a standalone upload-on-behalf service. VRC Eye can prepare context, observe results, and explain failures without duplicating every internal upload mechanism.

## 50. Creator-helper and world-debug integration

The World Creator tools should be able to consume intentionally exposed diagnostic events from a compatible creator helper.

A helper manifest should describe each event, field, control, required permission, and expected version.

A proposed reset control should identify what it resets and its scope. “Reset round” and “erase persistent user data” must never be presented as equivalent actions.

The integration also needs a concrete transport design. We should not promise that the ordinary web API lets an external application read arbitrary live Udon variables.

VRChat documents Udon networking and creator debugging as their own systems. Our helper would need to work within supported mechanisms and the creator’s deliberately exposed contract. [VRChat Creators](https://creators.vrchat.com/worlds/udon/networking/)

The developer workbench should validate that contract, simulate it locally, and explain when a capability is unavailable.

## 51. ClientSim and creator test environments

VRChat provides ClientSim for testing world behavior within Unity. [VRChat Creators](https://creators.vrchat.com/worlds/clientsim/)

VRC Eye’s simulator should not pretend to replace it.

The two tools would serve different purposes: ClientSim helps test creator content, while VRC Eye’s simulator tests how the companion reacts to events and integration messages.

An editor adapter could correlate a creator test case with VRC Eye’s event timeline.

For example, a creator triggers a test interaction, the helper emits a structured event, VRC Eye updates the test checklist, and the developer view records the entire path.

The report should clearly label whether the evidence came from an editor simulation or a real VRChat session.

Passing in one environment should not automatically be represented as passing in the other.

## 52. Runtime Companion developer view

The Runtime Companion should expose process identity, session boundaries, provider health, sample age, polling cost, log availability, resource observations, and inferred runtime state.

The existing specification already includes raw runtime events, state and capability dumps, reconciliation, simulated hangs, crashes, and provider failures.    Pasted markdown(4)    Pasted markdown(4)

I would add a “why this state?” explanation.

For example:

> Runtime marked unresponsive because the selected responsiveness provider exceeded its threshold. Process-exit evidence is absent. Logs are still updating.

That is better than a single unexplained “crashed” label.

Developer test profiles should also manage verbose debugging deliberately and restore ordinary settings afterward. The official documentation warns against leaving unnecessary debugging enabled continuously. [VRChat Creators](https://creators.vrchat.com/worlds/udon/debugging-udon-projects/)

## 53. Optional bridge contract testing

The optional bridge should remain an additional provider, not the foundation of the application.

Its developer page should show protocol version, authenticated peer identity, capability advertisements, connection health, sequence handling, payload validation, and permission decisions.

A contract tester should be able to simulate missing capabilities, incompatible versions, stalled heartbeats, malformed messages, and disconnects.

Missing telemetry should become unavailable or stale—not a fabricated zero. That behavior is already explicit in our bridge and Black Box plans.    Pasted markdown(3)

A bridge’s existence does not authorize whatever its other endpoint does. VRChat’s terms restrict unauthorized modification and circumvention, so compatibility and permitted implementation remain separate questions. [VRChat](https://hello.vrchat.com/legal)

The Developer workspace should not add arbitrary memory operations or unrestricted Unity commands to the bridge contract.

## 54. Eye-to-Eye networking diagnostics

The networking developer view should explain handshake negotiation, peer identity, session roles, permissions, message validation, acknowledgements, latency, reconnects, and transport selection.

Those fields are already part of our Eye-to-Eye developer roadmap.    Pasted markdown(6)

I would add a message-to-action trace:

> Peer requested a diagnostic card → sharing policy checked → selected fields sanitized → user approval obtained where required → response delivered.

The peer protocol must not forward VRChat credentials or become a general remote API executor.

An Eye-to-Eye relay should transport Eye-to-Eye messages. It should not silently perform another user’s VRChat account operations.

Network simulation should cover reordered messages, duplicate acknowledgements, clock differences, relay outages, and reconnecting with an expired session role.

## 55. Companion Mode and integration ownership tracing

The developer tools should explain which application or subsystem owns a particular responsibility.

For example, VRCX Companion Mode may be configured to own a notification while VRC Eye continues updating its Player Store.

The existing plan explicitly distinguishes notification deduplication from roster state.    Pasted text

An ownership inspector should show the selected owner, the evidence that the integration is available, the fallback owner, and the most recent handoff.

It should also expose conflicts:

> Two providers claim responsibility for this popup.

or:

> The preferred companion is unavailable; VRC Eye’s fallback is active.

The integration should only claim capabilities supplied by a real, supported connection or explicit configuration. Process detection alone should not be treated as proof of an undocumented control interface.

# Part VII — Black Box, performance, extensions, and delivery

## 56. Connect API actions to the Black Box timeline

Every important API action should be linkable to an incident timeline.

A developer should be able to select a failure and see nearby API errors, reconnects, parser changes, store updates, resource observations, and relevant UI actions.

The trace should preserve causal links where VRC Eye knows them.

For example:

> This request directly caused this cache invalidation.

But coincident events should remain correlations:

> An avatar-related event and a resource increase occurred near each other.

The recorder should not turn that into an unsupported accusation that a particular person caused a crash.

A useful incident report would identify the strongest evidence, alternative explanations, missing providers, and the first point at which the application behaved unexpectedly.

## 57. Profile VRC Eye itself

Developer tooling can create its own performance problems, so it needs measurement.

The performance page should show CPU use, memory growth, event throughput, queue lengths, database-write delay, UI-update frequency, request counts, and dropped diagnostic records.

Each provider should have a visible sampling cost.

The recorder should use bounded buffers and report when it drops data. Silent loss creates false confidence in an apparently complete trace.

A “diagnostic overhead” view should compare ordinary operation with the current developer instrumentation.

If enabling raw event capture causes UI stutter, the tool should expose that directly rather than blame VRChat.

The first performance targets should be regression budgets for VRC Eye itself, not invented promises about how much it will improve the game.

## 58. A developer extension API

Eventually, VRC Eye could expose a small extension interface for custom panels, parsers, report generators, and local test scenarios.

Extensions should request named capabilities rather than receive unrestricted access to the API client, database, or secret store.

An extension that needs world metadata should request the shared world service. It should not create an independent authentication flow or bypass the scheduler.

Imported extensions should declare their version, requested permissions, data access, and compatibility requirements.

For stronger isolation, risky extensions could run outside the main process. Merely placing code in a “plugins” folder should not be presented as a security boundary.

This would allow VRC Eye to grow without turning the core application into an unstructured collection of privileged scripts.

## 59. Secure the local developer interface

A local web panel or developer socket should not assume that “localhost” alone is sufficient authorization.

The design should include authenticated connections, limited binding, origin checks where applicable, per-operation permissions, and explicit treatment of browser-originated requests.

Live account operations should not become callable by any webpage that happens to discover a local port.

Developer request imports and report viewers should render untrusted strings as data, not executable content.

The workbench should also avoid accidentally exposing itself to the LAN when the user intended only local debugging.

Networking configuration should clearly identify which interfaces are listening and which clients are authorized.

## 60. Generate useful bug reports and minimal reproductions

The report generator should capture the application version, relevant adapters, environment, selected feature configuration, expected behavior, observed behavior, and a sanitized reproduction.

A particularly useful addition would be **automatic scenario reduction**.

Suppose a failure occurred in a recording containing thousands of events. The lab could try removing irrelevant segments while checking whether the failure still reproduces.

The result might be a much smaller case containing one account switch, one delayed API response, and one incorrect store update.

That is far more useful than a massive undifferentiated log.

The report should also distinguish a confirmed application defect from an unverified compatibility issue or a missing external capability.

# Part VIII — How the pieces should work together

## 61. Example: a world-description update that appears not to save

The developer opens the world’s record and sees the current service value, cached value, and local draft.

They submit a reviewed change. The action trace records the selected account, resource, validated field set, request, response, and verification result.

Now suppose the API response reflects the new description but the World tab still shows the old one.

The comparison tool reveals that the normalized World Store contains the new value, while the page is subscribed to an outdated record revision.

The developer bookmarks the incident, exports a sanitized fixture, and runs it against the next build.

The regression test succeeds only when the visible page updates without another request.

The point is not merely that the workbench can send the update. It can explain which layer failed after the update.

## 62. Example: switching accounts while a request is in flight

Account A starts a profile-related read.

Before the response arrives, the user switches to account B.

The request remains tagged with account A’s session generation. When it finishes, the gateway recognizes that it belongs to an older context.

The response may be recorded in account A’s appropriately scoped diagnostics, but it must not update account B’s store or interface.

The simulator should reproduce this with a deliberately delayed response.

The acceptance test should verify both data isolation and presentation: no brief display of account A’s private information, no write sent under the wrong account, and no stale confirmation reused.

This is exactly the kind of bug that a simple API explorer would miss and an integrated developer workbench should catch.

## 63. Example: API interruption during a crowded session

The local roster continues receiving session events while API enrichment starts failing.

The request scheduler pauses suitable work and records the reason. Profile and metadata fields become stale where necessary.

The Player Store remains active. It does not delete players because an unrelated profile lookup failed.

The Developer dashboard shows the separation between roster health, API enrichment, database history, OSC, and optional telemetry.

When the API recovers, reconciliation refreshes relevant records without recreating encounters or duplicating notifications.

The saved scenario becomes a regression test for recovery behavior.

This is a direct continuation of the failure-isolation philosophy already present in our Player List plan.

## 64. Example: an avatar-selection request with uncertain local completion

The developer selects an accessible avatar through the reviewed operation.

The API result is recorded as acknowledged, but the local observation provider does not yet report the new avatar.

The interface displays:

> Selection acknowledged; local change not yet confirmed.

It does not repeatedly send the selection request.

Later, an appropriate local event arrives and completes the observed-change stage. A separate readiness stage remains dependent on its own evidence.

In Replay, the same sequence can be tested with the local event delayed, missing, duplicated, or arriving before the API response.

That gives us a real account action with a carefully modeled asynchronous outcome—not a button that calls an endpoint and immediately declares everything successful.

# Part IX — Implementation order and completion criteria

## 65. Build the shared foundation before the large collection of panels

I would start with the event envelope, action lifecycle, environment isolation, provider health model, redaction service, and shared API gateway.

Then add the raw inspector, basic state viewers, cache visibility, and a small number of well-understood reads.

After that, implement the simulator and replay runner.

Only then should the first live-write workbench be added, using one narrowly scoped operation with a complete preview, dispatch, verification, and outcome model.

That order creates reusable infrastructure rather than dozens of special-case buttons.

The group, favorites, publication, and more complicated account workflows should come after the system can already handle cancellation, partial success, uncertain outcomes, and account changes.

## 66. A practical staged roadmap

| Stage                   | Deliverable                                                                       |
| ----------------------- | --------------------------------------------------------------------------------- |
| Foundation              | Shared action model, environment isolation, provenance, redaction                 |
| Inspection              | Request viewer, event viewer, store inspectors, cache diagnostics                 |
| Offline testing         | Simulator, replay, parser fixtures, failure injection                             |
| First live operations   | Selected authorized reads and narrowly reviewed writes                            |
| Expanded API workspaces | Worlds, avatars, instances, favorites, groups, moderation preferences             |
| Integration development | OSC, SDK, creator helpers, runtime and peer contract tests                        |
| Recovery and release    | Database repair, migration tests, compatibility reports, reproducible bug bundles |

The first useful release does not need every panel.

It does need the foundations to be genuine. A request viewer that bypasses the application’s real API client would be a poor foundation, even if it looks impressive.

Similarly, a replay tool that can still reach live executors should not be considered complete.

## 67. What “done” should mean

I would define completion through observable behavior rather than the number of tabs.

A developer should be able to trace a user action from its origin through authorization, scheduling, request handling, normalization, state changes, and presentation.

Every important field should explain its source and freshness.

Every provider failure should degrade the appropriate capability rather than corrupt unrelated state.

Every live write should have a clearly modeled outcome, including uncertainty where verification is missing.

Every offline test and replay should be unable to perform a live operation by construction.

Every diagnostic export should be reviewable and sanitized before sharing.

Every experimental override should be visible and reversible at the VRC Eye configuration level.

And every API capability should distinguish **documented expectation**, **observed behavior**, **implemented support**, and **remaining uncertainty**.

---

**The resulting Developer Mode would be much more than a debug console.** It would let us inspect VRC Eye’s internal decisions, exercise legitimate VRChat API operations, develop new adapters, test failure conditions without disrupting real sessions, and turn actual incidents into repeatable regression tests.

The direct API work should be a first-class part of that design: **real requests and meaningful account/resource operations, paired with precise authorization, state verification, and explanations of what actually happened.**