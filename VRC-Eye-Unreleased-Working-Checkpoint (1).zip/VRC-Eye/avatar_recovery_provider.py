"""Recovery preparation and manual-export inspection; no extraction provider.

Official AssetRipper GUI arguments inspected 2026-10-03 expose server/logging
options, not a supported input/output export CLI. Never guess fork arguments.
https://github.com/AssetRipper/AssetRipper/blob/master/Source/AssetRipper.GUI.Web/Arguments.cs
This module never launches a tool, reads keys, extracts bundles or runs scripts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import re
import stat
import threading
import time
import uuid

from avatar_library_files import (inspect_file, checked_stream, copy_record,
                                  check_cancel, fingerprint, FILE_LIMIT)
from companion_data import entity_id, stamp
from creator_projects import assert_no_links, local_path, inspect_project

SCHEMA = 'vrc-eye.recovery-handoff.v1'
MANIFEST = 'recovery-handoff.json'
MAX_ENTRIES = 20_000
MAX_DEPTH = 24
MAX_TREE_BYTES = 8 * 1024**3
REVIEW_SECONDS = 300.
UNITY = re.compile(r'\d{4}\.\d+\.\d+[abfp]\d+[a-z0-9]*\Z')
VERSION = re.compile(r'[~^<>=0-9.a-zA-Z+*| -]{1,100}\Z')
BUCKETS = {
    'Scripts': {'.cs', '.js', '.boo'}, 'Assemblies': {'.dll'},
    'Meshes / models': {'.fbx', '.obj', '.blend', '.dae', '.gltf', '.glb'},
    'Materials': {'.mat'}, 'Shaders': {'.shader', '.shadergraph', '.shadersubgraph', '.hlsl', '.cginc', '.compute'},
    'Animations / controllers': {'.anim', '.controller', '.overridecontroller', '.mask'},
    'Prefabs': {'.prefab'}, 'Scenes': {'.unity'},
    'Textures': {'.png', '.jpg', '.jpeg', '.tga', '.dds', '.psd', '.exr', '.hdr', '.bmp'},
    'Audio': {'.wav', '.ogg', '.mp3', '.aiff'},
    'Serialized assets (type uninspected)': {'.asset'}, 'Metadata sidecars': {'.meta'},
}


@dataclass(frozen=True)
class Source:
    path: str = field(repr=False)
    size: int
    digest: str
    identity: tuple
    signature: str
    unity: str

    def evidence(self):
        return {'path': self.path, 'name': Path(self.path).name, 'size': self.size,
                'sha256': self.digest, 'fingerprint': dict(self.identity),
                'header': 'Unity bundle header'}

    def summary(self):
        return (f'Bytes: {self.size:,}\nSHA-256: {self.digest}\nHeader: {self.signature}\n'
                f'Header Unity version: {self.unity or "Unknown"}\n'
                'Header and hash do not establish ownership, encryption state, integrity of internal assets, or source recoverability.')


@dataclass(frozen=True)
class PreparationReview:
    identity: str
    source: Source = field(repr=False)
    destination: str = field(repr=False)
    parent_identity: tuple
    avatar: str
    expires: float

    def summary(self):
        return (f'Selected avatar association: {self.avatar}\nSource: {self.source.path}\n'
                f'NEW folder: {self.destination}\n\n{self.source.summary()}\n\n'
                'Create input.bundle, recovery-handoff.json, and an empty RecoveredProject folder. '
                'The manifest records source digest, size, header, and the selected avatar association. '
                'It excludes the original path and account identity. The association is your declaration, not proof of ownership.\n\n'
                'This preserves a verified copy for manual work. It does not extract Unity source, '
                'decrypt files, install or launch AssetRipper, or restore missing source assets. '
                'A failed or cancelled job can leave its fresh staging folder for inspection. Existing files are never overwritten.')


def inspect_source(path, *, stop=None, progress=None):
    evidence = inspect_file(path, stop=stop, progress=progress)
    if not evidence['size'] or evidence['header'] != 'Unity bundle header':
        raise ValueError('Choose a nonempty file with a recognized UnityFS, UnityWeb or UnityRaw header. Unknown/damaged files can still be preserved using Local Files.')
    with checked_stream(evidence['path'], expected=evidence['fingerprint']) as (_, stream, _):
        prefix = stream.read(512)
    signature = prefix.split(b'\0', 1)[0].decode('ascii')
    # Unity bundle headers place format version, Unity version and revision after
    # the signature. This is a bounded hint only; no body/decompression is read.
    header_end = len(signature) + 1 + 4
    parts = prefix[header_end:].split(b'\0', 2)
    versions = []
    for value in parts[:2]:
        try:
            text = value.decode('ascii')
        except UnicodeError:
            continue
        if UNITY.fullmatch(text):
            versions.append(text)
    check_cancel(stop)
    return Source(evidence['path'], evidence['size'], evidence['sha256'],
                  tuple(sorted(evidence['fingerprint'].items())), signature, versions[-1] if versions else '')


def _parent_identity(path):
    info = path.stat()
    if not stat.S_ISDIR(info.st_mode):
        raise ValueError('Select an existing ordinary parent folder.')
    return info.st_dev, info.st_ino


def _destination(value):
    path = assert_no_links(local_path(value))
    if path.exists() or path.is_symlink():
        raise ValueError('Choose a new staging folder; existing folders are never reused or overwritten.')
    parent = assert_no_links(path.parent)
    identity = _parent_identity(parent)
    app = Path(__file__).resolve().parent
    if path == app or app in path.parents:
        raise ValueError('Choose a staging folder outside the VRC Eye application.')
    for ancestor in (parent, *parent.parents):
        if (ancestor / 'Assets').is_dir() and (ancestor / 'ProjectSettings').is_dir():
            raise ValueError('Choose a staging folder outside existing Unity projects.')
    return path, identity


def _write_new(path, value, *, before_commit=None, stop=None):
    from vrca_files import _save_stream, VRCAError, VRCACancelled
    from avatar_library_files import InspectionCancelled
    raw = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False).encode('utf-8')
    try:
        _save_stream(BytesIO(raw), path, len(raw), sha256(raw).hexdigest(), stop, None,
                     network=False, suffixes=('.json',), before_commit=before_commit)
    except VRCACancelled as error:
        raise InspectionCancelled(str(error)) from error
    except VRCAError as error:
        raise ValueError(str(error)) from error


class PreparationService:
    def __init__(self, *, clock=time.monotonic):
        self.clock = clock
        self._plans = {}
        self._lock = threading.Lock()

    def clear(self):
        with self._lock:
            self._plans.clear()

    def discard(self, review):
        with self._lock:
            self._plans.pop(review.identity, None)

    def prepare(self, source, destination, avatar):
        if not isinstance(source, Source):
            raise ValueError('Inspect one local bundle before preparing its handoff.')
        entity_id('avatar', avatar)
        path, identity = _destination(destination)
        review = PreparationReview(str(uuid.uuid4()), source, str(path), identity,
                                   avatar, self.clock() + REVIEW_SECONDS)
        with self._lock:
            self._plans = {k: v for k, v in self._plans.items() if v.expires > self.clock()}
            if len(self._plans) >= 8:
                raise ValueError('Close an existing recovery preparation review first.')
            self._plans[review.identity] = review
        return review

    def execute(self, review, *, stop=None, progress=None, context_check=lambda: None):
        with self._lock:
            if (not isinstance(review, PreparationReview) or
                    self._plans.get(review.identity) is not review):
                raise ValueError('This preparation review was used or cleared; review again.')
            self._plans.pop(review.identity)
        if self.clock() >= review.expires:
            raise ValueError('Preparation review expired. Inspect and review again.')
        check_cancel(stop); context_check()
        current = inspect_source(review.source.path, stop=stop, progress=progress)
        if current != review.source:
            raise ValueError('Source bytes or identity changed after inspection. Inspect again.')
        if self.clock() >= review.expires:
            raise ValueError('Preparation review expired during source verification. Review again.')
        target, parent_identity = _destination(review.destination)
        if parent_identity != review.parent_identity:
            raise ValueError('The destination parent changed. Choose and review a fresh location.')
        check_cancel(stop); context_check()
        target.mkdir(mode=0o700)  # Exclusive directory creation; an existing target fails.
        target_identity = _parent_identity(target)
        def stable_paths():
            assert_no_links(target)
            if _parent_identity(target) != target_identity or _parent_identity(target.parent) != parent_identity:
                raise ValueError('The staging folder changed. Inspect the recorded destination before repeating.')
        def stable():
            check_cancel(stop); context_check(); stable_paths()
        stable()
        copy = copy_record(review.source.evidence(), target / 'input.bundle', stop=stop, progress=progress,
                           before_commit=stable)
        stable()
        (target / 'RecoveredProject').mkdir(mode=0o700)
        manifest = {'schema': SCHEMA, 'created': stamp(), 'avatar_association': review.avatar,
                    'source': {'sha256': review.source.digest, 'size': review.source.size,
                               'signature': review.source.signature, 'unity_header': review.source.unity},
                    'input': 'input.bundle', 'suggested_output': 'RecoveredProject',
                    'operation': 'Verified source-copy staging only',
                    'extraction': 'Not performed', 'derivation': 'Not established',
                    'limits': 'The bundle may omit original scripts, source textures, shader source, editor settings or authoring history.'}
        stable(); _write_new(target / MANIFEST, manifest, before_commit=stable, stop=stop)
        stable_paths()
        # Publication is complete; late cancellation must not relabel the bytes.
        return {'destination': str(target), 'manifest': str(target / MANIFEST),
                'source': copy, 'state': 'Prepared for manual export; no extraction performed',
                'avatar': review.avatar}


def inspect_handoff(folder, *, stop=None):
    root = assert_no_links(local_path(folder))
    root_identity = _parent_identity(root)
    with checked_stream(root / MANIFEST, limit=64 * 1024) as (_, stream, _):
        try:
            manifest = json.loads(stream.read().decode('utf-8'))
        except (ValueError, UnicodeError, RecursionError) as error:
            raise ValueError('The handoff manifest is not supported JSON.') from error
    if not isinstance(manifest, dict) or manifest.get('schema') != SCHEMA or manifest.get('input') != 'input.bundle':
        raise ValueError('Select a VRC Eye recovery handoff folder.')
    source = manifest.get('source')
    if (not isinstance(source, dict) or not re.fullmatch('[a-f0-9]{64}', str(source.get('sha256', ''))) or
            type(source.get('size')) is not int or not 1 <= source['size'] <= FILE_LIMIT):
        raise ValueError('The handoff source evidence is invalid.')
    evidence = inspect_source(root / 'input.bundle', stop=stop)
    assert_no_links(root)
    if _parent_identity(root) != root_identity:
        raise ValueError('The handoff folder changed during inspection. Select and inspect it again.')
    return {'source_sha256': evidence.digest, 'source_size': evidence.size,
            'source_matches_manifest': evidence.digest == source['sha256'] and evidence.size == source['size'],
            'unity_header': evidence.unity,
            'manifest_authenticity': 'Local editable record; not signed and not proof of ownership or derivation.'}


def inspect_output(folder, *, handoff=None, stop=None, progress=None):
    """Bounded read-only structure inventory, not a Unity import or derivation test."""
    root = assert_no_links(local_path(folder))
    if not root.is_dir():
        raise ValueError('Choose the exported Unity source folder itself.')
    counts = {name: 0 for name in BUCKETS}; counts['Other files'] = 0
    entries, total, files, directories, seen = 0, 0, 0, 0, []
    pending = [(root, 0)]
    folder_evidence = []
    missing_meta = 0
    while pending:
        check_cancel(stop)
        current, depth = pending.pop()
        if depth > MAX_DEPTH:
            raise ValueError('The output exceeds the 24-level inspection depth limit.')
        assert_no_links(current)
        directory_info = current.stat()
        if not stat.S_ISDIR(directory_info.st_mode):
            raise ValueError('An output directory changed during inspection.')
        folder_evidence.append((current, fingerprint(directory_info)))
        with os.scandir(current) as stream:
            for child in stream:
                check_cancel(stop); entries += 1
                if entries > MAX_ENTRIES:
                    raise ValueError('The output exceeds the 20,000-entry inspection limit; no partial report was accepted.')
                path = assert_no_links(Path(child.path)); info = path.lstat()
                relative = path.relative_to(root).as_posix()
                if stat.S_ISDIR(info.st_mode):
                    directories += 1; pending.append((path, depth + 1)); continue
                if not stat.S_ISREG(info.st_mode):
                    raise ValueError('The selected output contains a special file; no report was accepted.')
                files += 1; total += info.st_size
                if total > MAX_TREE_BYTES:
                    raise ValueError('The output exceeds the 8 GiB declared-file-size inspection limit.')
                fp = fingerprint(info); seen.append((path, fp))
                suffix = path.suffix.lower()
                bucket = next((name for name, extensions in BUCKETS.items() if suffix in extensions), 'Other files')
                counts[bucket] += 1
                if relative.startswith('Assets/') and suffix != '.meta' and not path.with_name(path.name + '.meta').is_file():
                    missing_meta += 1
        if progress:
            progress(f'Inspecting output: {files:,} regular files; {total:,} declared bytes')
    def unchanged():
        for path, fp in folder_evidence + seen:
            check_cancel(stop); assert_no_links(path)
            if fingerprint(path.stat()) != fp:
                raise ValueError('The output changed while inspected; wait for the exporter to finish and inspect again.')
    unchanged()
    required = ('Assets', 'Packages', 'ProjectSettings', 'ProjectSettings/ProjectVersion.txt', 'Packages/manifest.json')
    missing = [name for name in required if not (root / name).exists()]
    project = None
    if all((root / folder).is_dir() for folder in ('Assets', 'Packages', 'ProjectSettings')):
        project = inspect_project(root, stop=stop)
    packages = []
    if project:
        for item in project['packages']:
            entry = {key: item[key] for key in ('name', 'manager', 'state')}
            for key in ('requested', 'locked', 'installed'):
                value = item[key]
                entry[key] = value if not value or VERSION.fullmatch(value) else '[non-version declaration omitted]'
            packages.append(entry)
    comparison = {'state': 'No handoff selected; no input/output relationship is assumed.'}
    if handoff is not None:
        comparison = inspect_handoff(handoff, stop=stop)
        declared = project['unity'] if project else ''
        comparison['declared_unity_matches_header'] = (declared == comparison['unity_header']) if declared and comparison['unity_header'] else None
        comparison['derivation'] = 'Not established. Matching versions or a handoff selection do not prove these files came from this bundle.'
    unchanged()
    return {'schema': 'vrc-eye.recovery-output-inspection.v1', 'checked': stamp(),
            'files': files, 'directories': directories, 'declared_bytes': total,
            'inventory': counts, 'missing_project_entries': missing,
            'assets_without_meta_sidecar': missing_meta,
            'unity': project['unity'] if project else '', 'dependencies': packages,
            'project_issues': project['issues'] if project else ['No complete Unity project structure was established.'],
            'comparison': comparison,
            'limits': 'Counts are extension-based, not parsed asset types. No scripts, Unity, or AssetRipper were run. No material, mesh, animation, license, provenance, build compatibility or complete original-source recovery is established.'}
