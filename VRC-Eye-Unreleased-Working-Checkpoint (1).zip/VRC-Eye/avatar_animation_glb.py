"""Bounded glTF 2.0 animation accessors; unsupported clips remain inspectable."""
from dataclasses import asdict
import struct
from avatar_scene import integer,vector,array,name,local_matrix
from avatar_animation import Base,Track,Clip,Animation,decode,MAX_COMPONENTS


def parse(doc,binary,views,accessors,scene):
    source=array(doc,'animations',32)
    if not source:return None
    bases=tuple(Base(n.index,local_matrix(doc['nodes'][n.index]),vector(doc['nodes'][n.index].get('translation',[0,0,0]),3),vector(doc['nodes'][n.index].get('rotation',[0,0,0,1]),4),vector(doc['nodes'][n.index].get('scale',[1,1,1]),3)) for n in scene.nodes)
    known={n.index for n in scene.nodes};morphs={p.node:len(p.rig.morph_names) for p in scene.parts if p.rig};budget=[0];cache={}
    def read(index,kind):
        index=integer(index,0,len(accessors)-1)
        if (index,kind) in cache:return cache[index,kind]
        a=accessors[index];width={'SCALAR':1,'VEC3':3,'VEC4':4}[kind]
        if a.get('componentType')!=5126 or a.get('type')!=kind or a.get('normalized',False) is not False or 'sparse' in a or a.get('extensions'):
            raise ValueError('Animation needs dense FLOAT accessors without extensions.')
        count=integer(a.get('count'),1,MAX_COMPONENTS);budget[0]+=count*width
        if budget[0]>MAX_COMPONENTS:raise ValueError('Animation exceeds 250,000 decoded numeric components.')
        v=views[integer(a.get('bufferView'),0,len(views)-1)]
        if type(v.get('buffer')) is not int or v['buffer']!=0 or 'byteStride' in v or v.get('extensions'):raise ValueError('Animation needs tightly packed embedded buffers.')
        start=integer(v.get('byteOffset',0),0,len(binary));size=integer(v.get('byteLength'),1,len(binary));offset=integer(a.get('byteOffset',0),0,size)
        if (start+offset)%4 or start+size>len(binary) or offset+count*width*4>size:raise ValueError('Animation accessor exceeds its aligned byte range.')
        values=tuple(vector(struct.unpack_from('<'+'f'*width,binary,start+offset+i*width*4),width) for i in range(count))
        cache[index,kind]=values;return values
    clips=[]
    for i,clip in enumerate(source):
        label=name(clip.get('name'),f'Clip {i+1}');tracks=[];notes=[]
        try:
            if clip.get('extensions'):raise ValueError('Animation extensions require a different provider.')
            samplers=array(clip,'samplers',256);channels=array(clip,'channels',256);ignored=0
            for channel in channels:
                target=channel.get('target')
                if not isinstance(target,dict) or channel.get('extensions') or target.get('extensions'):raise ValueError('Animation target extensions, including material/object-reference channels, are unsupported.')
                node=target.get('node')
                if node is None:ignored+=1;continue
                node=integer(node,0,len(doc['nodes'])-1)
                if node not in known:ignored+=1;continue
                path=target.get('path')
                if path not in ('translation','rotation','scale','weights'):raise ValueError('Only translation, rotation, scale and morph weights are supported.')
                if path!='weights' and 'matrix' in doc['nodes'][node]:raise ValueError('Animated transform targets must declare TRS, not a matrix. Re-export decomposed node transforms.')
                sampler=samplers[integer(channel.get('sampler'),0,len(samplers)-1)]
                if sampler.get('extensions'):raise ValueError('Animation sampler extensions are unsupported.')
                mode=sampler.get('interpolation','LINEAR')
                if mode not in ('STEP','LINEAR','CUBICSPLINE'):raise ValueError('Unsupported animation interpolation mode.')
                times=tuple(v[0] for v in read(sampler.get('input'),'SCALAR'))
                if not 1<=len(times)<=4096 or times[0]<0 or times[-1]>3600:raise ValueError('Animation supports up to 4,096 keys and one hour per clip.')
                kind='SCALAR' if path=='weights' else 'VEC4' if path=='rotation' else 'VEC3';values=read(sampler.get('output'),kind)
                if path=='weights':
                    width=morphs.get(node,0)
                    if not width or len(values)%width:raise ValueError('Morph animation must match existing mesh targets.')
                    values=tuple(tuple(values[j+k][0] for k in range(width)) for j in range(0,len(values),width))
                tracks.append(Track(node,path,mode,times,values))
            if not tracks:raise ValueError('No supported channel targets the displayed scene.')
            if ignored:notes.append(f'{ignored} channels outside the displayed scene or without a node were ignored.')
            notes.append('Local node transforms and position morph weights only. No events, object-reference/material swaps, humanoid retargeting, controllers, IK, audio or networking run.')
            candidate=Clip(label,min(t.times[0] for t in tracks),max(t.times[-1] for t in tracks),tuple(tracks),notes=tuple(notes))
            # Reuse the parent-side semantic checks. A bad clip never replaces
            # the usable imported static scene with a fabricated animation.
            decode(asdict(Animation(bases,tuple(clips+[candidate]))),scene)
            clips.append(candidate)
        except (ValueError,TypeError,KeyError,IndexError) as error:
            message=str(error)[:300] if isinstance(error,ValueError) else 'Malformed animation declaration.'
            clips.append(Clip(label,0.,0.,reason=message))
    return decode(asdict(Animation(bases,tuple(clips))),scene)
