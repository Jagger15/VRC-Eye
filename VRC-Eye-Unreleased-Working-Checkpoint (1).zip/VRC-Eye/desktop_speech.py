"""Optional local speech, using bounded child processes with literal stdin."""
import base64
import os
from pathlib import Path
import shutil
import subprocess
import threading


def command():
    if os.name=='nt':
        root=os.environ.get('SystemRoot','C:\\Windows')
        executable=Path(root)/'System32/WindowsPowerShell/v1.0/powershell.exe'
        if not executable.is_file():raise ValueError('Windows local speech is unavailable.')
        script="[Console]::InputEncoding = [System.Text.Encoding]::UTF8; $voice = New-Object -ComObject SAPI.SpVoice; $text = [Console]::In.ReadToEnd(); [void]$voice.Speak($text)"
        return [str(executable),'-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(script.encode('utf-16-le')).decode('ascii')]
    executable=shutil.which('espeak-ng') or shutil.which('espeak')
    if not executable:raise ValueError('Local speech requires espeak-ng or espeak on Linux.')
    return [executable,'--stdin','-s','165']


class Speech:
    def __init__(self):
        self.lock=threading.RLock();self.process=None;self.generation=0;self.status='Local speech disabled'
    def cancel(self):
        with self.lock:
            self.generation+=1
            if self.process and self.process.poll() is None:
                try:self.process.terminate()
                except OSError:pass
    def say(self,text):
        text=' '.join(str(text).split())[:350]
        if not text:return
        self.cancel();generation=self.generation
        def work():
            child=None
            try:
                args=command()
                with self.lock:
                    if generation!=self.generation:return
                    child=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                        shell=False,creationflags=0x08000000 if os.name=='nt' else 0)
                    self.process=child
                child.communicate(text.encode('utf-8'),timeout=30)
                self.status='Local speech completed' if child.returncode==0 else 'Local speech was not confirmed'
            except subprocess.TimeoutExpired:
                child.terminate();self.status='Local speech timed out'
            except (ValueError,OSError) as error:self.status=str(error)
            finally:
                if child and child.poll() is None:
                    child.kill();child.wait(timeout=2)
                with self.lock:
                    if self.process is child:self.process=None
        threading.Thread(target=work,daemon=True,name='VRC-Eye-Local-Speech').start()
    def close(self):self.cancel()
