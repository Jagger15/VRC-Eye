"""Local Photos workspace. No implicit scanning, network, capture or file changes.

All decoded images and filesystem tasks run outside Tk. One task retains its
slot until the worker actually stops; account/privacy changes discard visual
results, not completed records in the initiating workspace.
"""
from __future__ import annotations

from text_viewport import window_body

import base64
import json
from pathlib import Path
import queue
import sqlite3
import threading

from account_actions import local_writable
from account_workspace_ui import WorkspacePane
from avatar_library import active_scope, context_token
from avatar_library_files import InspectionCancelled
from avatar_library_ui import StableTable
from avatar_creator_store import sanitize_export
from companion_data import Entity, entity_id
from companion_ui import Page, line, button, entry, choice
from creator_projects_ui import review_document, text_area, set_text
from photo_files import (inspect_photo, verified_data, render, normalize_recipe,
                         source_candidates, save_new)
from photo_service import service_for
from photo_store import filters, retained_sessions, retained_session
from photo_automation_ui import PhotoAutomationUI

SECTIONS=('Library','Sources','Albums & Sessions','Review & Export','Photo Booth','Activity')


class ImageWindow:
    """Bounded 2D preview with standard buttons, keyboard scrolling and pan."""
    def __init__(self,page,payload,title):
        self.page=page;tk=page.tk;ttk=page.ttk
        self.window=tk.Toplevel(page.app.root);self.window.title(title)
        self.window.geometry('1000x760');self.window.minsize(640,440)
        self.window.transient(page.app.root);self.window.protocol('WM_DELETE_WINDOW',self.close)
        row=ttk.Frame(window_body(self.window),padding=8);row.pack(fill='x')
        for name,command in (('Smaller',lambda:self.zoom(-1)),('Larger',lambda:self.zoom(1)),('Reset',self.reset),('Close',self.close)):
            ttk.Button(row,text=name,command=command).pack(side='left',padx=4)
        self.caption=tk.StringVar(value='2D preview only. Arrow keys scroll; drag to pan. No source is changed.')
        ttk.Label(window_body(self.window),textvariable=self.caption,wraplength=900).pack(anchor='w',padx=8,pady=4)
        body=ttk.Frame(window_body(self.window));body.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(body,background=page.app.BG,highlightthickness=2,takefocus=True)
        from screen_reader_model import annotate
        annotate(self.canvas,name=title,value=self.caption.get,description='Image preview. The Photos details contain filename, dimensions, dates, favorite state, notes and available world/session metadata. No visual content is inferred.')
        y=ttk.Scrollbar(body,orient='vertical',command=self.canvas.yview)
        x=ttk.Scrollbar(body,orient='horizontal',command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        x.pack(side='bottom',fill='x');y.pack(side='right',fill='y');self.canvas.pack(fill='both',expand=True)
        self.base=tk.PhotoImage(master=self.window,data=base64.b64encode(payload))
        self.image=None;self.level=0;self.item=self.canvas.create_image(0,0,anchor='nw');self.apply()
        self.canvas.bind('<ButtonPress-1>',lambda e:self.canvas.scan_mark(e.x,e.y))
        self.canvas.bind('<B1-Motion>',lambda e:self.canvas.scan_dragto(e.x,e.y,gain=1))
        for sequence,axis,amount in (('<Left>','x',-1),('<Right>','x',1),('<Up>','y',-1),('<Down>','y',1)):
            self.canvas.bind(sequence,lambda e,a=axis,n=amount:(getattr(self.canvas,a+'view_scroll')(n,'units'),'break')[-1])
        self.window.bind('<Escape>',lambda e:self.close());self.canvas.focus_set()
        page.windows.append(self)

    def apply(self):
        self.image=self.base.subsample(2) if self.level<0 else self.base.zoom(2) if self.level>0 else self.base
        self.canvas.itemconfigure(self.item,image=self.image)
        self.canvas.configure(scrollregion=(0,0,self.image.width(),self.image.height()))
    def zoom(self,direction):self.level=max(-1,min(1,self.level+direction));self.apply()
    def reset(self):self.level=0;self.apply();self.canvas.xview_moveto(0);self.canvas.yview_moveto(0)
    def close(self):
        if self in self.page.windows:self.page.windows.remove(self)
        if self.window.winfo_exists():self.window.destroy()
        self.image=None;self.base=None


class PhotosPage(PhotoAutomationUI,Page):
    def __init__(self,shell,parent):
        self.viewport=WorkspacePane(shell.app,parent);parent=self.viewport.body
        super().__init__(shell,parent,'VRChat Photos')
        self.service=service_for(shell);self.store=self.service.store;self.scope=active_scope(self.app)
        self.windows=[];self.images=[];self.visible=[];self.selected_id='';self.offset=0;self.total=0
        self.album_filter='';self.session_filter='';self.source_filter='';self.export_review=None
        self.candidate_rows={};self.session_offset=0;self.sessions_loaded=False
        self.private=self.tk.BooleanVar(value=False);self.paths=self.tk.BooleanVar(value=False)
        self.caption=self.tk.StringVar();self.selected_caption=self.tk.StringVar(value='Select an imported photo.')
        row=line(self)
        self.ttk.Checkbutton(row,text='Privacy view (this workspace)',variable=self.private,command=lambda:self.guard(self.privacy_changed)).pack(side='left',padx=6)
        self.ttk.Checkbutton(row,text='Show local paths',variable=self.paths,command=lambda:self.guard(self.paths_changed)).pack(side='left',padx=6)
        self.ttk.Label(parent,textvariable=self.caption,wraplength=1040,style='Accent.TLabel').pack(anchor='w',pady=4)
        self.ttk.Label(parent,textvariable=self.selected_caption,wraplength=1040).pack(anchor='w',pady=4)
        self.tabs=self.ttk.Notebook(parent);self.tabs.pack(fill='both',expand=True)
        self.frames={name:self.ttk.Frame(self.tabs,padding=6) for name in SECTIONS}
        for name,frame in self.frames.items():self.tabs.add(frame,text=name)
        self.build_library(self.frames['Library']);self.build_sources(self.frames['Sources'])
        self.build_albums(self.frames['Albums & Sessions']);self.build_export(self.frames['Review & Export'])
        self.build_booth(self.frames['Photo Booth']);self.build_activity(self.frames['Activity'])
        self.refresh()
        self.status.set('Local library. Only explicitly enabled source watches import automatically. No online requests or image sharing.')

    def context(self):return context_token(self.app)
    def safe_text(self,value):
        if self.private.get():return 'Private details hidden.'
        return str(value) if self.paths.get() else sanitize_export(str(value))
    def guard(self,action):
        from tkinter import TclError
        try:
            if hasattr(self,'service') and self.context()!=self.account:
                self.account_changed();return
            return action()
        except (ValueError,OSError,sqlite3.Error,RuntimeError,TclError) as error:self.status.set(self.safe_text(error))
    def revealed(self):
        if self.private.get():raise ValueError('Reveal this workspace before viewing or acting.')
        if self.closed:raise ValueError('The Photos workspace is closed.')
        if self.context()!=self.account:self.account_changed();raise ValueError('The account changed. Review this workspace again.')
    def writable(self):
        self.revealed();local_writable(self.app)
        watcher=getattr(self,'watcher',None)
        if self.job or self.service.active or watcher and watcher.thread and watcher.thread.is_alive():
            raise ValueError('A photo task is running or stopping. Wait, or pause the source watch in Sources.')
    def check_token(self,token):
        self.revealed()
        if token!=self.context():raise ValueError('The account or operating mode changed. Nothing was assigned to the new workspace.')
    def review(self,title,text):
        token=self.context()
        accepted=review_document(self.app,title,text,accept='Approve')
        self.check_token(token)
        return accepted
    def label(self,parent,text):
        from ui_theme import responsive_wrap
        responsive_wrap(self.ttk.Label(parent,text=text,wraplength=1000,style='Muted.TLabel'),maximum=1000).pack(anchor='w',fill='x',pady=5)
    def selected(self):
        self.revealed();row=self.store.get(self.scope,self.selected_id)
        if not row:raise ValueError('Select a photo in this workspace first.')
        return row
    def source_selected(self):
        self.revealed();row=self.sources_table.selected()
        if not row:raise ValueError('Select an approved source first.')
        current=self.store.source(self.scope,row['id'])
        if not current:raise ValueError('The selected source was removed.')
        return current
    def select(self,identity):
        if self.private.get():return
        if identity!=self.selected_id:
            self.selected_id=identity;self.discard_review();self.refresh_details(load_draft=True)
        else:self.refresh_details()
    def table_select(self):
        row=self.catalog.selected()
        if row:self.select(row['id'])

    def build_library(self,parent):
        self.query=self.tk.StringVar();self.after=self.tk.StringVar();self.before=self.tk.StringVar()
        self.world_filter=self.tk.StringVar();self.state_filter=self.tk.StringVar(value='All')
        self.author_filter=self.tk.StringVar();self.participant_filter=self.tk.StringVar()
        self.favorites_only=self.tk.BooleanVar(value=False);self.hidden_only=self.tk.BooleanVar(value=False)
        self.view=self.tk.StringVar(value='Cards');self.thumbnails=self.tk.BooleanVar(value=True)
        self.count=self.tk.StringVar();self.details=self.tk.StringVar()
        self.title=self.tk.StringVar();self.world=self.tk.StringVar()
        self.label(parent,'Photos are local references, not online VRChat uploads. Dates are labeled by evidence; metadata and session links are not proof of where or when a picture was taken.')
        row=line(self,parent);self.ttk.Label(row,text='Find title / notes').pack(side='left',padx=4)
        entry(self,row,self.query,30).bind('<Return>',lambda e:(self.guard(self.search),'break')[-1])
        button(self,row,'Apply filters',self.search);button(self,row,'Reset filters',self.reset_filters)
        choice(self,row,self.view,('List','Cards'),self.search,width=9)
        row=line(self,parent)
        self.ttk.Checkbutton(row,text='Favorites',variable=self.favorites_only,command=lambda:self.guard(self.search)).pack(side='left',padx=4)
        self.ttk.Checkbutton(row,text='Hidden only',variable=self.hidden_only,command=lambda:self.guard(self.search)).pack(side='left',padx=4)
        self.ttk.Checkbutton(row,text='Saved thumbnails',variable=self.thumbnails,command=lambda:self.guard(self.render_rows)).pack(side='left',padx=4)
        choice(self,row,self.state_filter,('All','Available','Missing','Changed','Unreadable','Replaced'),self.search,width=14)
        row=line(self,parent);self.ttk.Label(row,text='Date from / to (YYYY-MM-DD)').pack(side='left',padx=4)
        entry(self,row,self.after,12);entry(self,row,self.before,12)
        self.ttk.Label(row,text='Manual world ID filter').pack(side='left',padx=4);entry(self,row,self.world_filter,42)
        row=line(self,parent);self.ttk.Label(row,text='Indexed author ID').pack(side='left');entry(self,row,self.author_filter,43)
        self.ttk.Label(row,text='Declared participant ID').pack(side='left');entry(self,row,self.participant_filter,43)
        from photo_session_day_ui import Controls
        self.day_controls=Controls(self,parent)
        self.results_host=self.ttk.Frame(parent);self.results_host.pack(fill='both',expand=True)
        self.list_container=self.ttk.Frame(self.results_host);self.list_container.pack(fill='both',expand=True)
        self.catalog=StableTable(self,self.list_container,(('title','Photo',240),('date','Date evidence',175),('basis','Date basis',240),('day','Session day (derived)',260),('state','Last-known file state',165),('favorite','Favorite',75)),height=8,select=self.table_select)
        self.cards=self.ttk.Frame(self.results_host)
        row=line(self,parent);button(self,row,'Previous',lambda:self.change_page(-1));button(self,row,'Next',lambda:self.change_page(1))
        self.ttk.Label(row,textvariable=self.count).pack(side='left',padx=8)
        row=line(self,parent)
        button(self,row,'Import selected files…',self.import_files);button(self,row,'Preview selected',self.preview)
        button(self,row,'Toggle favorite',self.toggle_favorite);button(self,row,'Hide / restore reference…',self.hide)
        row=line(self,parent);button(self,row,'Recheck selected file',self.recheck);button(self,row,'Relink identical file…',self.relink)
        button(self,row,'Duplicate report',self.duplicate_report);button(self,row,'Review & export',lambda:self.tabs.select(self.frames['Review & Export']))
        self.ttk.Label(parent,textvariable=self.details,wraplength=1000).pack(anchor='w',pady=6)
        row=line(self,parent);self.ttk.Label(row,text='Local title').pack(side='left',padx=4);entry(self,row,self.title,65)
        row=line(self,parent);self.ttk.Label(row,text='Manual world ID (optional)').pack(side='left',padx=4);entry(self,row,self.world,48)
        button(self,row,'Open world page…',self.open_world)
        button(self,row,'World Invite Me…',self.open_visit)
        self.label(parent,'Private local notes. These are not written into the original image or sent to another user.')
        self.notes=text_area(self,parent,height=4);self.notes.configure(state='normal')
        row=line(self,parent);button(self,row,'Save title / notes / world link',self.save_notes)
        button(self,row,'Inspect metadata privacy report',self.privacy_report)
        row=line(self,parent)
        self.metadata_sensitive=self.tk.BooleanVar(value=False)
        button(self,row,'Inspect embedded VRCX / VRChat metadata',self.structured_metadata)
        button(self,line(self,parent),'Photo context, metadata copies & file organization…',lambda:__import__('photo_context_ui').show(self))
        self.ttk.Checkbutton(row,text='Reveal sensitive declarations for this inspection',variable=self.metadata_sensitive).pack(side='left',padx=4)
        from friendly_ui import flow_line
        row=flow_line(self,parent);button(self,row,'Add selected to contact sheet',lambda:self.add_sheet_photo(False))
        button(self,row,'Open contact sheet / strip',lambda:self.tabs.select(self.frames['Photo Booth']))

    def build_sources(self,parent):
        self.source_label=self.tk.StringVar();self.recursive=self.tk.BooleanVar(value=True)
        self.prefix=self.tk.StringVar();self.source_detail=self.tk.StringVar();self.config_folder=self.tk.StringVar()
        self.label(parent,'Approve folders explicitly, then scan manually or enable watching separately. Approval alone does not scan. Symlinks/reparse points are not followed. A missing or remounted root never implies all its photos were deleted.')
        row=line(self,parent);self.ttk.Label(row,text='Source label').pack(side='left',padx=4);entry(self,row,self.source_label,28)
        self.ttk.Checkbutton(row,text='Include subfolders (bounded)',variable=self.recursive).pack(side='left',padx=6)
        button(self,row,'Approve folder…',self.add_source)
        self.sources_table=StableTable(self,parent,(('label','Source',220),('scope','Scan scope',140),('state','Last observation',410)),height=6,select=self.source_selection)
        self.ttk.Label(parent,textvariable=self.source_detail,wraplength=1000).pack(anchor='w',pady=4)
        row=line(self,parent);button(self,row,'Scan selected source',self.scan);button(self,row,'Show source photos',self.filter_source)
        button(self,row,'Review / reapprove source…',self.reapprove);button(self,row,'Remove source approval…',self.remove_source)
        button(self,row,'Recover moved source folder…',self.recover_root)
        self.build_watching(parent)
        self.label(parent,'Folder suggestions read only configuration and standard locations. They do not enumerate images. On Linux an optional explicitly selected Proton prefix maps C: paths; custom drives must be selected manually.')
        row=line(self,parent);self.ttk.Label(row,text='Optional Proton prefix').pack(side='left',padx=4);entry(self,row,self.prefix,50)
        button(self,row,'Choose prefix…',self.choose_prefix);button(self,row,'Find folder suggestions',self.discover)
        row=line(self,parent);self.ttk.Label(row,text='Optional config folder (blank uses selected logs)').pack(side='left',padx=4)
        entry(self,row,self.config_folder,38);button(self,row,'Choose config folder…',self.choose_config_folder)
        self.candidates=StableTable(self,parent,(('basis','Suggestion evidence',240),('path','Location / status',530)),height=4)
        row=line(self,parent);button(self,row,'Approve selected suggestion…',self.approve_candidate)

    def build_albums(self,parent):
        self.album_name=self.tk.StringVar();self.session_caption=self.tk.StringVar(value='Retained session history is loaded only on request.')
        self.label(parent,'Albums are references, not file copies. Smart albums evaluate their saved title/date/world/favorite/state filters. Different photos with identical bytes stay separate.')
        row=line(self,parent);entry(self,row,self.album_name,35)
        button(self,row,'New manual album',lambda:self.new_album(False));button(self,row,'Save filters as smart album',lambda:self.new_album(True))
        self.albums_table=StableTable(self,parent,(('name','Album',260),('type','Membership',160),('cover','Cover',320)),height=5)
        row=line(self,parent);button(self,row,'Open selected album',self.filter_album)
        button(self,row,'Add selected photo',lambda:self.membership(True));button(self,row,'Remove selected photo',lambda:self.membership(False))
        row=line(self,parent);button(self,row,'Use photo as album cover',self.album_cover);button(self,row,'Preview album cover',self.preview_album_cover)
        button(self,row,'Delete album only…',self.delete_album)
        self.label(parent,'Session associations are manual corrections against the existing retained history. A roster is not evidence of who appears in a photo. Private, forgotten or unavailable sessions are not reconstructed. This is local OS-user history, not verified account ownership.')
        row=line(self,parent);button(self,row,'Load retained sessions',lambda:self.load_sessions(0))
        button(self,row,'Previous sessions',lambda:self.load_sessions(max(0,self.session_offset-100)))
        button(self,row,'Next sessions',lambda:self.load_sessions(self.session_offset+100))
        self.sessions_table=StableTable(self,parent,(('world','Retained world',300),('start','Started',190),('id','Session reference',300)),height=5)
        self.ttk.Label(parent,textvariable=self.session_caption,wraplength=1000).pack(anchor='w',pady=4)
        row=line(self,parent);button(self,row,'Link photo to selected session…',self.link_session)
        button(self,row,'Unlink photo',self.unlink_session);button(self,row,'Show session photos',self.filter_session)
        row=line(self,parent);button(self,row,'Use photo as session cover',self.session_cover);button(self,row,'Preview session cover',self.preview_session_cover)

    def build_export(self,parent):
        self.crop=self.tk.StringVar();self.redactions=self.tk.StringVar();self.edge=self.tk.StringVar(value='4096')
        self.border=self.tk.StringVar(value='None');self.export_caption=self.tk.StringVar(value='Generate a preview, inspect the actual output, then explicitly export. No automatic sharing.')
        self.label(parent,'Export edits only a NEW PNG. Coordinates use oriented source pixels, before cropping or resizing: x0,y0,x1,y1 (right/bottom exclusive). Opaque black masks are applied before crop and resize. Transparent input is flattened against white.')
        row=line(self,parent);self.ttk.Label(row,text='Crop (blank = whole photo)').pack(side='left',padx=4);entry(self,row,self.crop,38)
        row=line(self,parent);self.ttk.Label(row,text='Opaque rectangles; separate with ;').pack(side='left',padx=4);entry(self,row,self.redactions,65)
        row=line(self,parent);self.ttk.Label(row,text='Maximum image edge before border').pack(side='left',padx=4)
        entry(self,row,self.edge,8);choice(self,row,self.border,('None','White','Dark'),width=10)
        button(self,row,'Reset recipe',self.reset_recipe)
        row=line(self,parent);button(self,row,'Generate reviewed output',self.prepare_export)
        button(self,row,'Inspect output again',self.preview_export);button(self,row,'Export reviewed PNG…',self.export)
        self.ttk.Label(parent,textvariable=self.export_caption,wraplength=1000).pack(anchor='w',pady=6)
        self.label(parent,'Metadata presence checks are not visible-content scanning. Review names, screens, codes, people and other visible details yourself. Output contains only flattened RGB PNG pixels: no source EXIF/text/ICC metadata, source file, hidden layers or sidecars. No privacy guarantee is implied.')
        for var in (self.crop,self.redactions,self.edge,self.border):var.trace_add('write',lambda *_:self.discard_review())

    def build_booth(self,parent):
        self.build_composer(parent)
        self.label(parent,'Static photo-booth borders are available in Review & Export: White or Dark. They are flattened into a new image and never modify the original. Coordinated countdowns and camera controls remain in the existing shared workspaces.')
        row=line(self,parent);button(self,row,'Create bordered export',lambda:self.tabs.select(self.frames['Review & Export']))
        button(self,row,'Open existing OSC Camera',lambda:self.app.experience.open_tool('osc:Camera'))
        button(self,row,'Open Eye-to-Eye Planner',lambda:self.app.experience.open_tool('peer:Planner'))
        self.label(parent,'Camera buttons only navigate. They do not arm OSC, take a picture, start a countdown, hide players, launch VRChat or send a photo. Camera-trigger attribution and direct image sharing remain separate work.')

    def build_activity(self,parent):
        self.activity_detail=self.tk.StringVar()
        self.label(parent,'Local activity, latest 100 tasks and export destinations. A stopped or interrupted task is never replayed automatically. Completed files and imported records can remain after cancellation.')
        row=line(self,parent);button(self,row,'Refresh activity',self.refresh_activity);button(self,row,'Clear completed tasks…',self.clear_activity)
        button(self,row,'Retry receipt save locally',self.retry_receipt)
        self.jobs_table=StableTable(self,parent,(('created','Time',200),('operation','Task',230),('state','Outcome',290)),height=6,select=self.activity_selection)
        row=line(self,parent);button(self,row,'Acknowledge interrupted task…',self.acknowledge_job)
        button(self,row,'Export selected data-only receipt…',self.export_receipt)
        self.exports_table=StableTable(self,parent,(('created','Time',190),('state','Export record',230),('path','Destination',380)),height=5,select=self.activity_selection)
        row=line(self,parent);button(self,row,'Acknowledge destination after inspection…',self.acknowledge_export)
        button(self,row,'Clear completed destination reviews…',self.clear_export_history)
        button(self,row,'Clear disposable thumbnails…',self.clear_thumbnails)
        self.ttk.Label(parent,textvariable=self.activity_detail,wraplength=1000).pack(anchor='w',pady=5)

    def query_values(self):
        return filters({'query':self.query.get(),'after':self.after.get(),'before':self.before.get(),
                        'favorite':self.favorites_only.get(),'world':self.world_filter.get(),'status':self.state_filter.get(),
                        'author':self.author_filter.get(),'participant':self.participant_filter.get(),'session_day':self.day_controls.filter.get()})
    def recover_root(self):
        self.writable();source=self.source_selected();token=self.service.token()
        folder=filedialog.askdirectory(parent=self.app.root,title='Choose the moved or copied source folder');self.service.check(token)
        if not folder:return
        from photo_recovery import RootRecovery
        recovery=RootRecovery(self.store)
        def prepared(review):
            if not self.review('Recover moved photo source',f"{len(review['matches'])} exact byte matches; {len(review['unmatched'])} unmatched references stay in the original source.\nNew source: {folder}\n\nRepoint the verified catalog references? Originals, notes and albums are preserved."):return
            self.service.check(token)
            def work(c,s,p):return recovery.commit(review,stop=s,check=lambda:self.service.check(token,s))
            self.start(work,lambda result:(self.refresh_sources(),self.refresh_library(),self.status.set('Recovered '+str(result['matched'])+' exact photo references.')),api=False,mutation=True)
        self.start(lambda c,s,p:recovery.prepare(self.scope,source['id'],folder,stop=s),prepared,api=False)
    def search(self):self.revealed();self.offset=0;self.refresh_library()
    def reset_filters(self):
        self.day_controls.filter.set('')
        self.query.set('');self.after.set('');self.before.set('');self.world_filter.set('');self.author_filter.set('');self.participant_filter.set('');self.favorites_only.set(False)
        self.hidden_only.set(False);self.state_filter.set('All');self.album_filter=self.session_filter=self.source_filter='';self.offset=0
        self.refresh_library()
    def change_page(self,direction):
        step=12 if self.view.get()=='Cards' else 48
        if direction>0 and self.offset+step>=self.total:return
        self.offset=max(0,self.offset+direction*step);self.refresh_library()
    def refresh(self):
        self.scope=active_scope(self.app)
        if self.day_controls.account!=self.scope:self.day_controls.reload()
        self.caption.set('Privacy view: identities, photos and paths hidden.' if self.private.get() else
                         'Photo workspace: '+('Local / not signed in' if self.scope=='local' else self.scope)+' · device-local catalog, not encrypted or a retained-login manager')
        self.refresh_library();self.refresh_sources();self.refresh_albums();self.refresh_activity();self.refresh_sheet()
    def refresh_library(self):
        if self.private.get():self.visible=[];self.total=0
        else:
            result=self.store.list(self.scope,query=self.query_values(),album=self.album_filter,session=self.session_filter,
                                   source=self.source_filter,hidden=self.hidden_only.get(),offset=self.offset,limit=12 if self.view.get()=='Cards' else 48)
            self.visible=result['items'];self.total=result['total']
        if self.selected_id not in {r['id'] for r in self.visible}:
            self.selected_id='';self.discard_review();self.clear_draft()
        self.render_rows();self.refresh_details()
    def render_rows(self):
        self.images.clear()
        for widget in self.cards.winfo_children():widget.destroy()
        from photo_session_day import load,label as day_label
        day_policy=load(self.shell.store,self.scope)
        self.catalog.set(self.visible,lambda r:(r['title'],r['date_value'],r['metadata']['date_basis'],day_label(r['date_value'],day_policy),r['status'],'Yes' if r['favorite'] else 'No'))
        if self.view.get()=='Cards' and not self.private.get():
            self.list_container.pack_forget();self.cards.pack(fill='both',expand=True)
            for index,r in enumerate(self.visible):
                box=self.ttk.Frame(self.cards,padding=5);box.grid(row=index//3,column=index%3,sticky='nsew',padx=4,pady=4)
                image=None
                if self.thumbnails.get() and r['thumbnail'] and r['status']=='Available':
                    try:
                        image=self.tk.PhotoImage(master=self.app.root,data=base64.b64encode(r['thumbnail']));self.images.append(image)
                    except self.tk.TclError:
                        self.status.set('A saved thumbnail could not be displayed. Select that photo and Recheck selected file to rebuild it.')
                label=r['title'][:55]+'\n'+r['status']+(' · Favorite' if r['favorite'] else '')
                if day_policy['enabled']:label+='\n'+day_label(r['date_value'],day_policy)
                control=self.ttk.Button(box,text=label,image=image or '',compound='top',command=lambda identity=r['id']:self.guard(lambda:self.select(identity)))
                control.pack(fill='both',expand=True);self.cards.columnconfigure(index%3,weight=1)
        else:
            self.cards.pack_forget();self.list_container.pack(fill='both',expand=True)
        detail=' · filtered by '+', '.join(name for name,v in (('album',self.album_filter),('source',self.source_filter),('session',self.session_filter)) if v) if any((self.album_filter,self.source_filter,self.session_filter)) else ''
        self.count.set(f'{self.total} matching photos · showing {len(self.visible)} · offset {self.offset}'+detail)
    def set_notes(self,value):
        set_text(self.notes,value);self.notes.configure(state='normal')
    def paths_changed(self):
        self.refresh_details();self.refresh_activity();self.source_selection()
        if self.candidate_rows:
            self.candidates.set(list(self.candidate_rows.values()),lambda r:(r['basis'],(r['path'] if self.paths.get() else 'Location hidden until review')+(' · '+r['issue'] if r['issue'] else '')))
    def clear_draft(self):
        if hasattr(self,'title'):self.title.set('');self.world.set('');self.set_notes('')
    def refresh_details(self,load_draft=False):
        r=self.store.get(self.scope,self.selected_id) if self.selected_id and not self.private.get() else None
        if not r:
            self.selected_caption.set('Private details hidden.' if self.private.get() else 'Select an imported photo.')
            self.details.set('No photo selected.');return
        self.selected_caption.set('Selected: '+r['title']+' · last known '+r['status'])
        session=retained_session(self.history(),r['session_id'],incognito=self.incognito()) if r['session_id'] else None
        content=f"{r['width']} × {r['height']} oriented pixels · {r['format']} · {r['size']:,} bytes\nDate: {r['date_value']} — {r['metadata']['date_basis']}\nSHA-256: {r['sha256']}\nWorld: {r['world_id'] or 'Not linked'} (manual; not instance access)\nSession: "+(session['id'] if session else 'No available retained link')
        content+='\nFile content last checked: '+r['checked']+' (not continuous monitoring)'
        if self.paths.get():content+='\nLocal reference: '+r['path']
        self.details.set(content)
        if load_draft:self.title.set(r['title']);self.world.set(r['world_id']);self.set_notes(r['notes'])
        if hasattr(self,'source_detail'):self.source_selection()
    def refresh_sources(self):
        rows=[] if self.private.get() else self.store.sources(self.scope)
        watches={r['source']:r for r in self.store.watches(self.scope)} if not self.private.get() else {}
        self.sources_table.set(rows,lambda r:(r['label'],'Subfolders' if r['recursive'] else 'Folder only',
            (('Watch: '+watches[r['id']]['state']) if r['id'] in watches else r['state'])))
        self.source_selection()
        self.watching_caption()
    def source_selection(self):
        row=self.sources_table.selected()
        self.source_detail.set('Select an approved source.' if not row or self.private.get() else row['label']+' · '+row['state']+('\n'+row['path'] if self.paths.get() else '\nLocal path hidden; approval reviews show the exact destination.'))
        if row and not self.private.get():
            watch=self.store.watch(self.scope,row['id'])
            if watch:self.source_detail.set(self.source_detail.get()+f'\nWatch {"enabled" if watch["enabled"] else "paused"} · {watch["interval"]} seconds · {watch["state"]}\n'+watch['detail'])
    def refresh_albums(self):
        rows=[] if self.private.get() else self.store.albums(self.scope)
        def values(r):
            cover=self.store.get(self.scope,r['cover']) if r['cover'] else None
            return r['name'],'Smart filters' if r['query'] else 'Manual','Available' if cover and not cover['hidden'] and cover['status']=='Available' else 'None / unavailable'
        self.albums_table.set(rows,values)
    def refresh_activity(self):
        private=self.private.get()
        self.jobs_table.set([] if private else self.store.jobs(self.scope),lambda r:(r['created'],r['operation'],r['state']))
        self.exports_table.set([] if private else self.store.export_intents(self.scope),lambda r:(r['created'],r['state'],r['path'] if self.paths.get() else 'Local path hidden'))
        self.activity_selection()
    def activity_selection(self):
        row=self.jobs_table.selected();dest=self.exports_table.selected()
        parts=[]
        if row:parts.append(row['state']+': '+self.safe_text(row['detail']))
        if dest:parts.append(dest['state']+': '+dest['detail']+('\n'+dest['path'] if self.paths.get() else ''))
        if any(v[0]==self.scope for v in self.service.volatile.values()):parts.append('A task outcome is held in memory because its final receipt could not be saved. Retry saving locally; no task is repeated.')
        self.activity_detail.set('Private details hidden.' if self.private.get() else '\n'.join(parts) or 'Select a local record. Nothing is retried automatically.')

    def launch(self,work,done=None,*,operation=None):
        self.writable();token=self.context();stop=threading.Event();results=queue.Queue(maxsize=1)
        job={'token':token,'revision':self.revision,'stop':stop,'results':results,'progress':'','done':done,'operation':operation}
        def progress(value):job['progress']=str(value)[:600]
        def run():
            try:
                self.service.check(token,stop)
                result=self.service.execute(operation,work,token=token,stop=stop,progress=progress) if operation else work(stop,progress)
                results.put((True,result))
            except Exception as error:results.put((False,error))
        thread=threading.Thread(target=run,name='VRC-Eye-Photos',daemon=False);job['thread']=thread
        self.job=job;self.status.set('Working locally…');thread.start()
    def tick(self):
        if self.closed:return
        if self.context()!=self.account:self.account_changed()
        if self.watcher.revision!=self.watch_revision and not self.job:
            self.watch_revision=self.watcher.revision;self.refresh()
        job=self.job
        if not job:return
        if job['token']==self.context() and not self.private.get() and job['progress']:self.status.set(self.safe_text(job['progress']));job['progress']=''
        if job['thread'].is_alive():return
        self.job=None
        try:ok,value=job['results'].get_nowait()
        except queue.Empty:self.status.set('The local task ended without a result. Inspect Activity.');return
        if job['token']!=self.context() or self.private.get() or job['stop'].is_set() or job['revision']!=self.revision:return
        if not ok:self.status.set(self.safe_text(value));return
        if job['operation']:
            self.refresh();self.status.set(self.safe_text(value['detail']))
            if value['state'] not in ('Complete','Partial'):return
        if not job['operation']:self.status.set('Local result ready. No original was modified.')
        if job['done']:self.guard(lambda:job['done'](value))
    def cancel(self):
        self.revision+=1
        if self.job:self.job['stop'].set();self.status.set('Cancellation requested; the task keeps its slot until it stops.')
        elif getattr(self,'watcher',None) and self.watcher.thread and self.watcher.thread.is_alive():
            self.watcher.stop.set();self.status.set('Current watch pass cancelled. Use Pause selected watch to stop future passes too.')
        if hasattr(self,'service'):self.discard_review()
    def discard_review(self):
        self.export_review=None
        if hasattr(self,'sheet_review'):self.sheet_review=None
        if hasattr(self,'sheet_caption'):self.sheet_caption.set('No current sheet preview. Generate and inspect the output before saving.')
        if hasattr(self,'service'):self.service.discard_reviews()
        if hasattr(self,'export_caption'):self.export_caption.set('No current reviewed output. Generate and inspect a preview before exporting.')
    def close_windows(self):
        for window in tuple(self.windows):window.close()
    def privacy_changed(self):
        if hasattr(self,'metadata_sensitive'):self.metadata_sensitive.set(False)
        if hasattr(self,'watcher'):self.watcher.set_private(self.private.get())
        self.cancel();self.close_windows();self.images.clear();self.selected_id='';self.clear_draft();self.reset_recipe()
        if hasattr(self,'sheet_items'):
            self.sheet_items=[];self.sheet_project='';self.sheet_name.set('');self.discard_sheet_review()
        self.query.set('');self.world_filter.set('');self.author_filter.set('');self.participant_filter.set('');self.prefix.set('');self.config_folder.set('');self.source_label.set('');self.album_name.set('')
        self.paths.set(False)
        self.candidates.set([],lambda r:());self.candidate_rows={};self.sessions_table.set([],lambda r:());self.sessions_loaded=False
        self.album_filter=self.session_filter=self.source_filter='';self.refresh()
    def account_changed(self):
        self.account=self.context();self.scope=active_scope(self.app)
        if hasattr(self,'private'):
            self.after.set('');self.before.set('');self.offset=0;self.privacy_changed()
            self.status.set('Account/operating mode changed. Previous previews and reviews cleared; completed tasks remain in their initiating workspace.')
    def close(self):
        self.cancel();self.closed=True;self.close_windows();self.images.clear()
        if self.job:self.job['thread'].join(timeout=2)

    def import_files(self):
        from tkinter import filedialog
        self.writable();token=self.context()
        paths=filedialog.askopenfilenames(parent=self.app.root,title='Select photos to reference in place',filetypes=[('Single-frame photos','*.png *.jpg *.jpeg *.webp')])
        self.check_token(token)
        if not paths:return
        if not self.review('Import photo references',f'Workspace: {self.scope}\n{len(paths)} selected files.\n\nOriginals are read, never moved or edited. Private local paths, metadata evidence and disposable thumbnails are stored on this device.\n\n'+ '\n'.join(paths)):return
        self.launch(self.service.import_paths(paths),self.import_finished,operation='Import photos')
    def import_finished(self,outcome):
        result=outcome.get('result') or {};identity=result.get('last_photo') if isinstance(result,dict) else ''
        if identity:
            self.reset_filters();self.select(identity);self.tabs.select(self.frames['Library'])
    def preview(self):
        row=self.selected();self.preview_photo(row['id'])
    def preview_photo(self,identity):
        row=self.store.get(self.scope,identity)
        if not row or row['hidden'] or row['status']!='Available':raise ValueError('Choose a visible, available photo.')
        self.launch(lambda stop,progress:render(verified_data(row,stop=stop),{'max_edge':1200},preview_edge=1200),
                    lambda payload:ImageWindow(self,payload,'Photo preview · source unchanged'))
    def toggle_favorite(self):
        self.writable();r=self.selected();self.store.edit(self.scope,r['id'],favorite=not r['favorite']);self.refresh_library()
    def hide(self):
        self.writable();r=self.selected();hidden=not r['hidden']
        if not self.review('Hide / restore photo reference',r['title']+'\n\n'+('Hide' if hidden else 'Restore')+' this photo in the local library only? The image file, notes and album membership are retained. This is NOT file deletion.'):return
        self.store.edit(self.scope,r['id'],hidden=hidden);self.refresh_library();self.refresh_albums()
    def recheck(self):
        row=self.selected();self.launch(self.service.recheck(row['id']),operation='Recheck photo')
    def relink(self):
        from tkinter import filedialog
        self.writable();r=self.selected();token=self.context()
        path=filedialog.askopenfilename(parent=self.app.root,title='Select identical photo bytes at a new location')
        self.check_token(token)
        if not path:return
        if not self.review('Relink same photo',r['title']+'\nNew location: '+path+'\n\nA full hash must match. No photos or files are merged, moved or deleted.'):return
        self.launch(self.service.relink(r['id'],path),operation='Relink photo')
    def save_notes(self):
        self.writable();row=self.selected()
        self.store.edit(self.scope,row['id'],title=self.title.get(),notes=self.notes.get('1.0','end-1c'),world_id=self.world.get().strip())
        self.refresh_library();self.status.set('Saved local photo organization. Original metadata unchanged.')
    def privacy_report(self):
        row=self.selected();meta=row['metadata']
        message={'image_dimensions':[row['width'],row['height']],'date':row['date_value'],'date_basis':meta['date_basis'],
                 'metadata_fields_present':meta['metadata_fields'],'gps_metadata_present':meta['gps_present'],
                 'text_metadata_present':meta['text_metadata_present'],'world_id_candidates_unverified':meta['world_candidates'],
                 'warnings':meta['warnings'],'visible_content_scan':'Not performed','metadata_changes_in_export':'Source metadata removed; visible pixels remain unless cropped or masked'}
        review_document(self.app,'Metadata presence report — NOT a privacy clearance',json.dumps(message,indent=2),accept='Close report')

    def structured_metadata(self):
        from photo_metadata import inspect_metadata, public_report
        row=self.selected(); identity=row['id']; sensitive=self.metadata_sensitive.get()
        token=self.context()
        def done(result):
            self.check_token(token)
            if self.selected_id!=identity or self.metadata_sensitive.get()!=sensitive:
                raise ValueError('Photo or disclosure selection changed. Inspect again.')
            report=public_report(result,sensitive)
            report['file_evidence']={'sha256':row['sha256'],'meaning':'Read from the selected file with its saved fingerprint and digest rechecked.'}
            report['other_date_candidates']=row['metadata'].get('date_candidates',[])
            declared={r['value'] for r in result['candidates'] if r['field']=='timestamp'}
            observed={r['value'] for r in report['other_date_candidates']}
            if declared and observed and declared!=observed:
                report['date_comparison']='Embedded, EXIF/filename/filesystem dates may disagree or use different timezone evidence. No preferred date was assigned.'
            review_document(self.app,'Embedded metadata declarations · no automatic association',json.dumps(report,indent=2,ensure_ascii=False),accept='Close report')
        self.launch(lambda stop,progress:inspect_metadata(verified_data(row,stop=stop)),done)
    def duplicate_report(self):
        self.revealed();rows=self.store.duplicates(self.scope)
        review_document(self.app,'Recorded exact-byte duplicate groups',json.dumps(rows,indent=2)+'\n\nRecorded hashes only; recheck files for current evidence. Separate photo identities and privacy scopes are never merged. Nothing is deleted.',accept='Close report')
    def open_visit(self):
        row=self.selected()
        if not row["world_id"]:raise ValueError("Save a manual world association first. Metadata is not instance access.")
        __import__("world_visits_ui").open_for_world(self.shell,Entity("world",row["world_id"],row["world_id"]))

    def open_world(self):
        row=self.selected()
        if not row['world_id']:raise ValueError('Save a manual world link first. A metadata candidate is not automatically adopted.')
        if self.review('Open world website',row['world_id']+'\nOpen the existing world webpage? This does not join an instance or disclose the photo.'):
            self.open_item(Entity('world',entity_id('world',row['world_id']),row['world_id']))

    def approve_path(self,path,label='',recursive=False):
        self.writable()
        if self.review('Approve photo source',f'Workspace: {self.scope}\nFolder: {path}\nInclude subfolders: {recursive}\n\nRead images with a separate Scan action or by explicitly enabling watching. Reapproving clears the previous watch opt-in. Scans are bounded, skip links and preserve originals. The folder is recorded locally.'):
            self.store.add_source(self.scope,path,label,recursive);self.refresh_sources();self.status.set('Source approved. No scan started.')
    def add_source(self):
        from tkinter import filedialog
        self.writable();token=self.context();path=filedialog.askdirectory(parent=self.app.root,title='Choose photo source folder');self.check_token(token)
        if path:self.approve_path(path,self.source_label.get(),self.recursive.get())
    def reapprove(self):
        r=self.source_selected();self.approve_path(r['path'],r['label'],self.recursive.get())
    def remove_source(self):
        self.writable();r=self.source_selected()
        if self.review('Remove folder approval',r['label']+'\n\nRemove this source approval and its watch settings? Photo records, albums and all image files remain.'):
            self.store.forget_source(self.scope,r['id']);self.source_filter='';self.refresh()
    def scan(self):
        self.writable();r=self.source_selected()
        if not self.review('Scan approved photo source',r['label']+'\n'+r['path']+f"\nSubfolders: {r['recursive']}\n\nRead supported single-frame images; create/update local references and thumbnails. At most 256 new/changed images and 512 MiB per pass. No file modifications."):return
        self.launch(self.service.scan(r['id']),self.import_finished,operation='Scan photo source')
    def filter_source(self):
        r=self.source_selected();self.reset_filters();self.source_filter=r['id'];self.refresh_library();self.tabs.select(self.frames['Library'])
    def choose_prefix(self):
        from tkinter import filedialog
        self.revealed();token=self.context();path=filedialog.askdirectory(parent=self.app.root,title='Select explicit Proton prefix');self.check_token(token)
        if path:self.prefix.set(path)
    def choose_config_folder(self):
        from tkinter import filedialog
        self.revealed();token=self.context();path=filedialog.askdirectory(parent=self.app.root,title='Select VRChat folder containing config.json');self.check_token(token)
        if path:self.config_folder.set(path)
    def discover(self):
        self.revealed();prefix=self.prefix.get().strip() or None
        log=self.config_folder.get().strip() or (self.app.folder.get() if hasattr(self.app,'folder') else None)
        selection=(self.config_folder.get(),self.prefix.get())
        # Pure suggestions; never enumerate image directories.
        def finished(rows):
            if selection!=(self.config_folder.get(),self.prefix.get()):raise ValueError('Discovery selection changed. Find folder suggestions again.')
            for index,row in enumerate(rows):row['id']=str(index)
            self.candidate_rows={r['id']:r for r in rows}
            self.candidates.set(rows,lambda r:(r['basis'],(r['path'] if self.paths.get() else 'Location hidden until review')+(' · '+r['issue'] if r['issue'] else '')))
        self.launch(lambda stop,progress:source_candidates(log,prefix=prefix),finished)
    def approve_candidate(self):
        row=self.candidates.selected()
        if not row or not row['path']:raise ValueError('Select a usable folder suggestion or choose its actual folder manually.')
        self.approve_path(row['path'],self.source_label.get(),self.recursive.get())

    def album_selected(self):
        self.revealed();r=self.albums_table.selected()
        if not r:raise ValueError('Select an album.')
        return r
    def new_album(self,smart):
        self.writable();self.store.add_album(self.scope,self.album_name.get(),query=self.query_values() if smart else None);self.refresh_albums()
    def membership(self,add):
        self.writable();r=self.selected();a=self.album_selected();self.store.album_member(self.scope,a['id'],r['id'],add=add);self.refresh_albums();self.refresh_library()
    def filter_album(self):
        a=self.album_selected();self.reset_filters();self.album_filter=a['id'];self.refresh_library();self.tabs.select(self.frames['Library'])
    def album_cover(self):
        self.writable();r=self.selected();a=self.album_selected();self.store.set_cover(self.scope,r['id'],album=a['id']);self.refresh_albums()
    def preview_album_cover(self):
        a=self.album_selected();self.preview_photo(a['cover'])
    def delete_album(self):
        self.writable();a=self.album_selected()
        if self.review('Delete local album',a['name']+'\n\nRemove only this album and its membership references? Photos and files are retained.'):
            self.store.delete_album(self.scope,a['id']);self.album_filter='';self.refresh()
    def history(self):
        service=getattr(self.app,'player_sessions',None)
        return getattr(getattr(service,'worker',None),'store',None)
    def incognito(self):
        service=getattr(self.app,'player_sessions',None)
        return bool(getattr(service,'demo',False) or getattr(service,'settings',{}).get('incognito',False))
    def load_sessions(self,offset):
        self.revealed();rows=retained_sessions(self.history(),incognito=self.incognito(),offset=offset)
        self.session_offset=offset;self.sessions_loaded=True
        self.sessions_table.set(rows,lambda r:(r['world_name'] or 'Unknown',r['started'],r['id']))
        self.session_caption.set(f'{len(rows)} retained nonprivate sessions on this page · offset {offset}. No account ownership is inferred.')
    def session_selected(self):
        self.revealed();r=self.sessions_table.selected()
        if not r:raise ValueError('Load and select a retained session first.')
        current=retained_session(self.history(),r['id'],incognito=self.incognito())
        if not current:raise ValueError('This session is now private, forgotten or unavailable. Reload history.')
        return current
    def link_session(self):
        self.writable();p=self.selected();s=self.session_selected()
        if self.review('Manually associate photo and session',p['title']+'\nSession: '+s['id']+'\n\nThis records your manual association, not evidence of capture timing or who is pictured.'):
            self.service.link_session(p['id'],s['id'],self.history(),incognito=self.incognito());self.refresh_details()
    def unlink_session(self):
        self.writable();self.store.edit(self.scope,self.selected()['id'],session_id='');self.refresh_details()
    def filter_session(self):
        s=self.session_selected();self.reset_filters();self.session_filter=s['id'];self.refresh_library();self.tabs.select(self.frames['Library'])
    def session_cover(self):
        self.writable();s=self.session_selected();self.store.set_cover(self.scope,self.selected()['id'],session=s['id'])
        self.status.set('Saved this workspace’s session cover reference. No image was copied or shared.')
    def preview_session_cover(self):
        s=self.session_selected();row=self.store.session_cover(self.scope,s['id'])
        if not row:raise ValueError('No visible, available cover for this session.')
        self.preview_photo(row['id'])

    @staticmethod
    def rectangle(value):
        try:return [int(n.strip()) for n in value.split(',')]
        except ValueError as error:raise ValueError('Use whole-pixel coordinates: x0,y0,x1,y1.') from error
    def recipe(self):
        try:edge=int(self.edge.get())
        except ValueError as error:raise ValueError('Maximum image edge must be a whole number.') from error
        return normalize_recipe({'crop':self.rectangle(self.crop.get()) if self.crop.get().strip() else None,
                                  'redactions':[self.rectangle(s) for s in self.redactions.get().split(';') if s.strip()],
                                  'max_edge':edge,'border':self.border.get()})
    def reset_recipe(self):
        if not hasattr(self,'crop'):return
        self.crop.set('');self.redactions.set('');self.edge.set('4096');self.border.set('None');self.discard_review()
    def prepare_export(self):
        r=self.selected();recipe=self.recipe();token=self.context();identity=r['id']
        def finished(review):
            if self.selected_id!=identity or self.recipe()!=json.loads(review.recipe_json):self.discard_review();return
            self.export_review=review
            self.export_caption.set('Reviewed output: '+f'{len(review.output):,} bytes PNG · SHA-256 {review.output_digest}\nInspect the pixels and confirm Export. Changing the selection, recipe, account or privacy mode discards approval.')
            ImageWindow(self,review.preview,'Review resulting pixels · not yet saved')
        self.launch(lambda stop,progress:self.service.prepare_export(identity,recipe,token=token,stop=stop),finished)
    def preview_export(self):
        self.revealed()
        if not self.export_review:raise ValueError('Generate an output review first.')
        ImageWindow(self,self.export_review.preview,'Reviewed output · not yet saved')
    def export(self):
        from tkinter import filedialog
        self.writable();r=self.export_review;token=self.context()
        if not r or self.selected_id!=r.photo or self.recipe()!=json.loads(r.recipe_json):raise ValueError('Generate and inspect the output for the current selection and recipe first.')
        path=filedialog.asksaveasfilename(parent=self.app.root,title='New metadata-free PNG — never overwrite',initialfile='VRC-Eye-photo.png',defaultextension='.png',filetypes=[('PNG','*.png')]);self.check_token(token)
        if not path:return
        if not self.review('Export reviewed photo',f'Workspace: {self.scope}\nSource photo: {self.selected()["title"]}\nDestination: {path}\nOutput SHA-256: {r.output_digest}\n\nConfirm that you inspected the resulting pixels. This writes a new flattened PNG only, with no metadata or sidecars. It does NOT establish that visible content is safe to share. Originals are unchanged.'):return
        if self.export_review is not r or self.selected_id!=r.photo:raise ValueError('Photo or recipe changed. Preview again.')
        work=self.service.export(r,path);self.export_review=None
        self.launch(work,operation='Export reviewed PNG')
    def clear_activity(self):
        self.writable()
        if self.review('Clear completed photo task history','Remove completed task receipts only? Interrupted / Running receipts are retained. Photos, destinations and files remain.'):
            self.store.clear_jobs(self.scope);self.refresh_activity()
    def acknowledge_job(self):
        self.writable();r=self.jobs_table.selected()
        if not r:raise ValueError('Select an interrupted older-session task.')
        if self.review('Acknowledge interrupted photo task','Confirm that you inspected the original task and any destination. Acknowledgement does not prove completion and never repeats the action.'):
            self.store.acknowledge_job(self.scope,r['id']);self.refresh_activity()
    def acknowledge_export(self):
        self.writable();r=self.exports_table.selected()
        if not r:raise ValueError('Select an export destination record.')
        if self.review('Acknowledge inspected destination',r['path']+'\n\nInspect this exact location independently first. This marks only your acknowledgement, not successful image validation. Nothing is repeated or deleted.'):
            self.store.finish_export(self.scope,r['id'],'Acknowledged','Outcome acknowledged after manual inspection; no automatic recovery action.');self.refresh_activity()
    def clear_export_history(self):
        self.writable()
        if self.review('Clear completed export reviews','Clear Saved/Acknowledged destination reviews only? Unresolved destinations remain. The separate export inventory and files remain unchanged.'):
            self.store.clear_export_intents(self.scope);self.refresh_activity()
    def clear_thumbnails(self):
        self.writable()
        if self.review('Clear disposable thumbnail cache','Clear thumbnails in this workspace only? Originals and records remain. Explicit file rechecks rebuild individual thumbnails.'):
            self.store.clear_thumbnails(self.scope);self.refresh_library()
    def retry_receipt(self):
        self.writable();r=self.jobs_table.selected()
        if not r:raise ValueError('Select the task whose outcome needs a local save retry.')
        self.service.retry_receipt(r['id']);self.refresh_activity()
    def export_receipt(self):
        from tkinter import filedialog
        self.writable();r=self.jobs_table.selected();token=self.context()
        if not r:raise ValueError('Select a task receipt.')
        report={'format':'vrc-eye-photo-task-report','version':1,'operation':r['operation'],'state':r['state'],'created':r['created'],
                'omitted':'Account, photo and session identifiers, title, notes, file paths, metadata, images and raw error details.'}
        if not self.review('Export selected data-only receipt',json.dumps(report,indent=2)):return
        path=filedialog.asksaveasfilename(parent=self.app.root,initialfile='VRC-Eye-photo-task.json',defaultextension='.json');self.check_token(token)
        if path:save_new(path,json.dumps(report,indent=2).encode('utf-8'));self.status.set('Saved selected identifier-free task report. No image exported.')
