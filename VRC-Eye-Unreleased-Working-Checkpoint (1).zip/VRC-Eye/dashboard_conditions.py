"""Data-only Home layout selection. Never starts services or changes permissions."""
from copy import deepcopy

CONDITIONS = ('Always', 'Signed in', 'Signed out', 'Offline mode', 'Online mode',
              'Observed session', 'No observed session', 'Privacy hidden',
              'Privacy visible', 'DND on', 'DND off', 'Casual mode',
              'Advanced mode', 'Developer mode', 'Balanced power', 'Low power',
              'Steam running','Steam not observed','VRChat running','VRChat not observed')


def terms(raw):
    """Older single strings stay valid; lists combine at most four distinct facts."""
    items = [raw] if isinstance(raw, str) else raw
    if not isinstance(items, list) or not 1 <= len(items) <= 4 or any(not isinstance(x, str) or x not in CONDITIONS for x in items):
        raise ValueError('Choose one to four supported Home conditions.')
    if len(set(items)) != len(items): raise ValueError('Choose each Home condition once.')
    if len(items) > 1 and 'Always' in items: raise ValueError('Always cannot be combined with another condition.')
    groups = [('Signed in', 'Signed out'), ('Offline mode', 'Online mode'),
              ('Observed session', 'No observed session'), ('Privacy hidden', 'Privacy visible'),
              ('DND on', 'DND off'), ('Casual mode', 'Advanced mode', 'Developer mode'),
              ('Balanced power', 'Low power'),('Steam running','Steam not observed'),('VRChat running','VRChat not observed')]
    if any(sum(x in items for x in group) > 1 for group in groups):
        raise ValueError('Conflicting Home conditions cannot match. Choose one value per setting.')
    return list(items)


def describe(raw): return ' and '.join(terms(raw))


def defaults():
    return dict(enabled=False, override='', rules=[])


def validate(raw, layouts):
    if not isinstance(raw, dict) or set(raw) != {'enabled', 'override', 'rules'}:
        raise ValueError('Unsupported Home profile conditions.')
    if type(raw['enabled']) is not bool or not isinstance(raw['override'], str) or raw['override'] and raw['override'] not in layouts:
        raise ValueError('Choose an existing layout for the manual override.')
    if not isinstance(raw['rules'], list) or len(raw['rules']) > 20:
        raise ValueError('Keep up to 20 ordered Home profile rules.')
    ids = set()
    for rule in raw['rules']:
        if not isinstance(rule, dict) or set(rule) != {'id', 'name', 'layout', 'when', 'enabled'}:
            raise ValueError('Unsupported Home profile rule.')
        from customization import label
        label(rule['name'])
        if (not isinstance(rule['id'], str) or len(rule['id']) != 32 or
                any(c not in '0123456789abcdef' for c in rule['id']) or rule['id'] in ids or
                not isinstance(rule['layout'], str) or rule['layout'] not in layouts or
                type(rule['enabled']) is not bool):
            raise ValueError('Choose a unique rule, existing layout and supported condition.')
        terms(rule['when'])
        ids.add(rule['id'])
    return deepcopy(raw)


def facts(app):
    from account_header import private
    from session_restore import offline
    api = getattr(app, 'api', None)
    players = getattr(app, 'player_sessions', None)
    meta = getattr(players, 'meta', {}) or {}
    user = getattr(api, 'user_id', '')
    session = bool(user and getattr(players, 'local_user_id', '') == user and
                   meta.get('world_id') and not meta.get('ended'))
    shell = getattr(app, 'sidebar', None)
    policy = getattr(getattr(shell, 'desktop_service', None), 'policy', {})
    prefs = getattr(getattr(app, 'experience', None), 'preferences', None)
    from application_status import snapshot
    applications=snapshot(shell) if shell else {}
    return dict(signed_in=bool(getattr(api, 'authenticated', False)), offline=offline(app),
                session=session, private=private(app), dnd=bool(policy.get('dnd', False)),
                mode=getattr(prefs, 'mode', 'Casual'), power=policy.get('power'),
                steam=applications.get('Steam',{}).get('running'),vrchat=applications.get('VRChat',{}).get('running'))


def matches(condition, state):
    return all(_matches_one(term, state) for term in terms(condition))


def _matches_one(condition, state):
    mapping = {'Signed in': ('signed_in', True), 'Signed out': ('signed_in', False),
               'Offline mode': ('offline', True), 'Online mode': ('offline', False),
               'Observed session': ('session', True), 'No observed session': ('session', False),
               'Privacy hidden': ('private', True), 'Privacy visible': ('private', False),
               'DND on': ('dnd', True), 'DND off': ('dnd', False),
               'Steam running':('steam',True),'Steam not observed':('steam',False),
               'VRChat running':('vrchat',True),'VRChat not observed':('vrchat',False)}
    if condition == 'Always': return True
    if condition in ('Balanced power', 'Low power'):
        return state.get('power') == ('Balanced' if condition == 'Balanced power' else 'Low power')
    if condition.endswith(' mode') and condition[:-5] in ('Casual', 'Advanced', 'Developer'):
        return state.get('mode') == condition[:-5]
    key, expected = mapping[condition]
    # Unknown facts never satisfy either side of a condition.
    return type(state.get(key)) is bool and state[key] == expected


def resolve(document, state, *, paused=False):
    conditions = validate(document.get('conditions', defaults()), document['layouts'])
    name = document['active']; reason = 'Saved default'
    if paused:
        reason = 'Session pause; saved default'
    elif conditions['override']:
        name = conditions['override']; reason = 'Manual override'
    elif conditions['enabled']:
        for rule in conditions['rules']:
            if rule['enabled'] and matches(rule['when'], state):
                name = rule['layout']; reason = 'Rule: ' + rule['name']; break
        else: reason = 'No matching rule; saved default'
    rows = [deepcopy(row) for row in document['layouts'][name]
            if not row.get('hidden',False) and matches(row.get('when', 'Always'), state)]
    return dict(name=name, reason=reason, rows=rows)


def forget_layout(document, name):
    """Remove only conditions referencing a deliberately deleted layout."""
    value = document.get('conditions')
    if value:
        value['rules'] = [r for r in value['rules'] if r['layout'] != name]
        if value['override'] == name: value['override'] = ''
