"""Reviewed user workflows over the application's shared OSC service.

This module owns no socket, thread, device, account, or automatic connection.
Call ``tick`` on the UI pump after the shared service has received observations.
Native OSC submissions are evidence of a request, not proof of its effect.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import json
import math
import re
import string
import time
import uuid

_AVATAR = re.compile(r"avtr_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z")
_CHAT_PRIORITIES = {"user": 100, "template": 80, "announcement": 60, "background": 20}
_TEMPLATE_FIELDS = frozenset({"status", "timer", "media_title"})
_TERMINAL_FAILURES = frozenset({"cancelled", "expired", "failed", "blocked", "rejected"})
_SENT_STATES = frozenset({"sent", "transmitted", "released", "observed", "acknowledged", "action_confirmed", "matching_state_observed"})
_CAMERA_SETTINGS = frozenset({
    "Mode", "Zoom", "Exposure", "FocalDistance", "Aperture", "Hue", "Saturation", "Lightness",
    "LookAtMeXOffset", "LookAtMeYOffset", "FlySpeed", "TurnSpeed", "SmoothingStrength", "PhotoRate",
    "Duration", "ShowUIInCamera", "Lock", "LocalPlayer", "RemotePlayer", "Environment", "GreenScreen",
    "SmoothMovement", "LookAtMe", "AutoLevelRoll", "AutoLevelPitch", "Flying", "TriggerTakesPhotos",
    "DollyPathsStayVisible", "ShowFocus", "RollWhileFlying", "OrientationIsLandscape",
})
# Pose and CameraEars have conflicting source documentation. Streaming is an
# independently reviewed publication setting and is intentionally not in presets.
_CAMERA_PRESET_SETTINGS = _CAMERA_SETTINGS - {"Mode"}


def _number(value, low, high, label):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{label} must be a finite number from {low} to {high}")
    return float(value)


def _bool(value, label):
    if type(value) is not bool:
        raise ValueError(f"{label} must be a Boolean")
    return value


def _text(value, maximum, label, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()) or "\0" in value:
        raise ValueError(f"Invalid {label}")
    return value


def preview_chat(text):
    """Conservative composer limit; wrapping depends on VRChat's actual display."""
    _text(text, 144, "chatbox message")
    if any(ord(ch) < 32 and ch != "\n" for ch in text):
        raise ValueError("Chatbox text may contain newlines, but no other control characters")
    units = len(text.encode("utf-16-le")) // 2
    lines = text.count("\n") + 1
    if units > 144 or lines > 9:
        raise ValueError("Chatbox text must fit 144 characters and at most nine explicit lines")
    return {"text": text, "characters": len(text), "utf16_units": units, "lines": lines,
            "warning": "VRChat word wrapping can add displayed lines. Nearby users may see this text."}


def render_chat_template(template, fields):
    """Render only plain approved placeholders; no attribute access or formatting."""
    _text(template, 1024, "template")
    if not isinstance(fields, dict) or any(key not in _TEMPLATE_FIELDS for key in fields):
        raise ValueError("Template fields must be status, timer, or an intentionally selected media_title")
    chunks = []
    for literal, field, spec, conversion in string.Formatter().parse(template):
        chunks.append(literal)
        if field is not None:
            if field not in _TEMPLATE_FIELDS or spec or conversion or field not in fields:
                raise ValueError("Only approved plain template fields are supported")
            chunks.append(_text(fields[field], 144, "template field", empty=True))
    return preview_chat("".join(chunks))


def validate_dolly_json(source):
    """Bound untrusted native path JSON without inventing a native path schema.

    The official Dolly page documents JSON import, but not a versioned file
    schema. We validate JSON resources and documented numeric properties, count
    point lists when present, and keep the original structure. Live import also
    requires explicit current-client format verification in the review.
    """
    if isinstance(source, bytes):
        if len(source) > 32768:
            raise ValueError("Dolly JSON exceeds the 32 KiB OSC import limit")
        source = source.decode("utf-8")
    _text(source, 32768, "Dolly JSON")
    if len(source.encode("utf-8")) > 32768:
        raise ValueError("Dolly JSON exceeds the 32 KiB OSC import limit")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate Dolly JSON property")
            result[key] = value
        return result
    try:
        document = json.loads(source, object_pairs_hook=pairs,
                              parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON number")))
    except (TypeError, RecursionError, json.JSONDecodeError) as exc:
        raise ValueError("Invalid Dolly JSON") from exc
    if not isinstance(document, dict):
        raise ValueError("Dolly import must contain a JSON object exported by the current client")
    limits = {"zoom": (20, 150), "exposure": (-10, 4), "focaldistance": (0, 10), "aperture": (1.4, 32),
              "hue": (0, 360), "saturation": (0, 100), "lightness": (0, 100),
              "lookatmexoffset": (-25, 25), "lookatmeyoffset": (-25, 25),
              "duration": (.1, 60), "speed": (.1, 15), "flyspeed": (.1, 15), "photorate": (.1, 2)}
    nodes = 0
    points = 0
    unknown = set()
    structural = {"paths", "points", "position", "rotation", "x", "y", "z", "w", "islocal", "index", "path",
                  "settings", "version", "name", "isspeedbased", "isusinglookatme", "isusinggreenscreen",
                  "isusingmultistream", "isrelativetoplayer", "pathtype", "looptype", "capturetype", "focusmode", "anchormode"}
    def visit(value, depth=0, key=""):
        nonlocal nodes, points
        nodes += 1
        if depth > 12 or nodes > 4096:
            raise ValueError("Dolly JSON is too deeply nested or complex")
        if isinstance(value, dict):
            if len(value) > 64:
                raise ValueError("Too many Dolly properties")
            for item_key, child in value.items():
                if not isinstance(item_key, str) or len(item_key) > 64 or "\0" in item_key:
                    raise ValueError("Invalid Dolly property name")
                normalized = item_key.replace("_", "").lower()
                if normalized in limits:
                    _number(child, *limits[normalized], item_key)
                elif normalized == "islocal" and type(child) is not bool:
                    raise ValueError("Dolly isLocal must be Boolean")
                elif normalized not in structural:
                    unknown.add(item_key)
                visit(child, depth + 1, normalized)
        elif isinstance(value, list):
            if len(value) > 100:
                raise ValueError("Dolly arrays may contain at most 100 entries")
            if key == "points":
                if len(value) > 50 or any(not isinstance(point, dict) for point in value):
                    raise ValueError("Dolly supports at most 50 point objects per path")
                points += len(value)
                if points > 100:
                    raise ValueError("Dolly supports at most 100 points total in the Windows profile")
            for child in value:
                visit(child, depth + 1)
        elif type(value) in (int, float):
            _number(value, -1000000, 1000000, "Dolly numeric value")
        elif isinstance(value, str):
            _text(value, 512, "Dolly string", empty=True)
        elif value is not None and type(value) is not bool:
            raise ValueError("Unsupported Dolly value")
    visit(document)
    if not points:
        raise ValueError("No supported points list found; inspect a current-client Dolly export first")
    if unknown:
        raise ValueError("Unrecognized Dolly settings: " + ", ".join(sorted(unknown)[:8]))
    return {"json": json.dumps(document, ensure_ascii=False, separators=(",", ":"), allow_nan=False),
            "points": points, "schema_verified": False,
            "warning": "Bounds checked; current-client native format still needs explicit verification. VRC+ may be required."}


class OSCControls:
    """One set of voice/chat/camera/avatar workflows shared by all front ends."""
    ACTIONS = frozenset({
        "voice.configure", "voice.mute", "voice.unmute", "voice.toggle", "voice.hold", "voice.release", "voice.privacy",
        "chat.publish", "chat.cancel", "chat.typing", "camera.set", "camera.capture", "camera.cancel", "camera.preset",
        "dolly.play", "dolly.delay", "dolly.stop", "dolly.import", "dolly.export", "avatar.switch", "avatar.height",
        "safety.native", "safety.eye", "safety.leave",
    })

    def __init__(self, service, *, clock=time.monotonic, hooks=None):
        self.service = service
        self.clock = clock
        self.hooks = dict(hooks or {})
        self._guard = self._service_guard()
        self._context_guard = self._service_context_guard()
        self._reviews = {}
        self._voice_mode = "unknown"
        self._voice_pending = None
        self._voice_result = "Behavior not configured"
        self._privacy = {"enabled": False, "corrective": False, "attempted": False, "status": "Off"}
        self._chat = []
        self._chat_guards = {}
        self._chat_history = deque(maxlen=128)
        self._chat_next = 0.0
        self._composing = False
        self._typing = False
        self._typing_until = None
        self._captures = deque(maxlen=128)
        self._capture_next = 0.0
        self._camera_presets = {}
        self._dolly = {"state": "State unknown", "delay_until": None, "request_at": None, "path": None}
        self._height = {"requested": None, "status": "No height requested", "action_id": None, "at": None}
        self._height_bounds = (.2, 5.0)
        self._eligible = {}
        self._switch = None
        self._safety = {"active": False, "steps": []}

    def _service_guard(self):
        return tuple(self.service.state_guard)

    def _service_context_guard(self):
        return tuple(getattr(self.service, "context_guard", self.service.state_guard))

    def _permitted(self, address):
        return bool(self.service.is_granted("manual", address))

    def _obs(self, address):
        item = self.service.observation(address)
        if not item or not item.get("live", False):
            return None
        return item

    def _value(self, address):
        item = self._obs(address)
        return None if item is None else item.get("value", (item.get("args") or (None,))[0])

    def _action(self, action_id):
        return self.service.action(action_id) or {}

    def _submit(self, address, args, *, owner="controls", duration=None, delay=0, ttl=5, priority=None):
        review = self.service.review(address, tuple(args), source="manual", owner=owner,
                                     duration=duration, delay=delay, ttl=ttl, priority=priority)
        return self.service.submit(review)

    def _sensitive_observations(self, action):
        addresses = ()
        if action in {"voice.mute", "voice.unmute", "voice.toggle", "voice.hold"}:
            addresses = ("/avatar/parameters/MuteSelf",)
        elif action == "avatar.height":
            addresses = ("/avatar/eyeheightscalingallowed", "/avatar/change")
        elif action.startswith("dolly."):
            addresses = ("/dolly/Play",)
        return tuple((address, self._value(address)) for address in addresses)

    def review(self, action, **payload):
        self._check_context()
        if action not in self.ACTIONS:
            raise ValueError("Unsupported OSC control action")
        payload = deepcopy(payload)
        if action == "camera.capture" and "delay" in payload:
            if "countdown" in payload:
                raise ValueError("Use only one local countdown option")
            payload["countdown"] = payload.pop("delay")
        if action == "camera.preset" and "values" in payload:
            if "settings" in payload:
                raise ValueError("Use only one camera preset settings map")
            values = payload.pop("values")
            if not isinstance(values, dict):
                raise ValueError("Camera preset values must be a map")
            payload["settings"] = {key.removeprefix("/usercamera/"): value for key, value in values.items() if isinstance(key, str)}
            if len(payload["settings"]) != len(values):
                raise ValueError("Camera settings need unique endpoint names")
        if action == "avatar.switch" and "eligibility" not in payload:
            payload["eligibility"] = self._eligible.get(payload.get("avatar_id"))
        clean = self._validate(action, payload)
        review = {"id": uuid.uuid4().hex, "action": action, "payload": clean,
                  "guard": self._guard, "expires_at": self.clock() + 30,
                  "observations": self._sensitive_observations(action)}
        self._reviews = {key: item for key, item in self._reviews.items() if item["expires_at"] > self.clock()}
        if len(self._reviews) >= 128:
            self._reviews.pop(next(iter(self._reviews)))
        self._reviews[review["id"]] = deepcopy(review)
        return deepcopy(review)

    def execute(self, review):
        self._check_context()
        stored = self._reviews.pop(review.get("id"), None) if isinstance(review, dict) else None
        if stored is None or stored != review or stored["guard"] != self._guard or stored["expires_at"] <= self.clock():
            raise ValueError("OSC control review expired or changed; review this action again")
        action, payload = stored["action"], stored["payload"]
        if stored["observations"] != self._sensitive_observations(action):
            raise ValueError("Relevant observations changed; review this action again")
        self._validate(action, payload)
        return self._execute(action, payload)

    def discard_review(self, review):
        """Drop an obsolete controller preview without transmitting anything."""
        if not isinstance(review, dict):
            return False
        return self._reviews.pop(review.get("id"), None) is not None

    def _validate(self, action, p):
        # Unknown keys cannot quietly widen a reviewed action.
        allowed = {
            "voice.configure": {"mode"}, "voice.mute": set(), "voice.unmute": {"seconds"},
            "voice.toggle": set(), "voice.hold": {"seconds"}, "voice.release": set(),
            "voice.privacy": {"enabled", "corrective"}, "chat.publish": {"text", "immediate", "notification", "producer", "kind", "ttl", "privacy"},
            "chat.cancel": {"producer"}, "chat.typing": {"enabled"},
            "camera.set": {"name", "value", "owner"}, "camera.capture": {"countdown", "native_delay", "owner"},
            "camera.cancel": {"capture_id"}, "camera.preset": {"settings", "owner"},
            "dolly.play": set(), "dolly.delay": {"seconds"}, "dolly.stop": set(), "dolly.export": set(),
            "dolly.import": {"json", "space", "world_id", "notes", "format_verified"},
            "avatar.switch": {"avatar_id", "eligibility"}, "avatar.height": {"value"},
            "safety.native": set(), "safety.eye": {"native", "mute"}, "safety.leave": set(),
        }[action]
        if set(p) - allowed:
            raise ValueError("Unknown OSC control option")
        if action == "voice.configure":
            if p.get("mode") not in {"unknown", "toggle", "hold"}:
                raise ValueError("Choose the microphone behavior configured in VRChat")
        elif action in {"voice.mute", "voice.unmute", "voice.toggle", "voice.hold"}:
            if self._voice_mode == "unknown":
                raise ValueError("Configure VRChat microphone behavior first")
            if self._voice_pending:
                raise ValueError("Wait for the pending microphone result or release voice control")
            if action in {"voice.mute", "voice.unmute"} and type(self._value("/avatar/parameters/MuteSelf")) is not bool:
                raise ValueError("VRChat mute state is unverified; no mute/unmute command was sent")
            if action == "voice.toggle" and self._voice_mode != "toggle":
                raise ValueError("Toggle microphone requires VRChat's toggle voice setting")
            if action == "voice.hold" and self._voice_mode != "hold":
                raise ValueError("Hold to speak requires VRChat's non-toggle voice setting")
            if "seconds" in p:
                _number(p["seconds"], .1, 30, "Voice hold duration")
        elif action == "voice.privacy":
            _bool(p.get("enabled"), "Privacy session")
            _bool(p.get("corrective", False), "Corrective policy")
        elif action == "chat.publish":
            preview_chat(p.get("text"))
            _bool(p.get("immediate", True), "Immediate send")
            _bool(p.get("notification", False), "Notification sound")
            _text(p.get("producer", "composer"), 64, "chatbox producer")
            if p.get("kind", "user") not in _CHAT_PRIORITIES:
                raise ValueError("Unknown chatbox producer priority")
            if p.get("privacy", "user_approved") != "user_approved":
                raise ValueError("Review the actual public text before scheduling chatbox output")
            _number(p.get("ttl", 15), .1, 60, "Publication lifetime")
        elif action == "chat.cancel":
            if p.get("producer") is not None:
                _text(p["producer"], 64, "chatbox producer")
        elif action == "chat.typing":
            _bool(p.get("enabled"), "Typing indicator")
        elif action == "camera.set":
            if p.get("name") not in _CAMERA_SETTINGS | {"Close", "Streaming"}:
                raise ValueError("Unsupported or unverified camera endpoint")
            self.service.review("/usercamera/" + p["name"], (p.get("value"),), source="manual", owner=p.get("owner", "camera"))
        elif action == "camera.preset":
            settings = p.get("settings")
            if not isinstance(settings, dict) or not settings or len(settings) > 24:
                raise ValueError("Select between one and 24 camera preset settings")
            for name, value in settings.items():
                if name not in _CAMERA_PRESET_SETTINGS and not (name == "Mode" and value in (0, 1, 3, 4, 5, 6) and type(value) is int):
                    raise ValueError("Presets cannot enable streaming or unsupported camera settings")
                self.service.review("/usercamera/" + name, (value,), source="manual", owner=p.get("owner", "camera"))
        elif action == "camera.capture":
            _number(p.get("countdown", 0), 0, 30, "Local countdown")
            _bool(p.get("native_delay", False), "Native capture delay")
            if p.get("native_delay", False) and p.get("countdown", 0):
                raise ValueError("Choose either a VRC Eye countdown or VRChat's native delayed capture")
        elif action == "camera.cancel":
            if p.get("capture_id") is not None:
                _text(p["capture_id"], 64, "capture identifier")
        elif action == "dolly.delay":
            _number(p.get("seconds"), .1, 30, "Dolly delay")
        elif action == "dolly.import":
            validate_dolly_json(p.get("json"))
            if p.get("space", "local") not in {"local", "world"}:
                raise ValueError("Choose local-relative or world-specific path context")
            if p.get("space") == "world":
                _text(p.get("world_id"), 128, "world context")
            _text(p.get("notes", ""), 1024, "Dolly notes", empty=True)
            if p.get("format_verified") is not True:
                raise ValueError("Verify the current-client native export format before importing this path")
            if self._dolly["state"] in {"Delay requested", "Waiting", "Playback observed", "Playback requested"} or self._value("/dolly/Play") is True:
                raise ValueError("Stop Dolly playback and its delay before importing")
        elif action == "avatar.switch":
            avatar = p.get("avatar_id")
            if not isinstance(avatar, str) or not _AVATAR.fullmatch(avatar) or avatar not in self._eligible:
                raise ValueError("Select an avatar observed in your favorites, recents, or own uploads")
            if p.get("eligibility", self._eligible[avatar]) != self._eligible[avatar]:
                raise ValueError("Avatar eligibility changed; refresh the eligible list")
            if self._switch and self._switch["status"] == "Waiting for avatar transition":
                raise ValueError("An avatar switch is already awaiting observation")
        elif action == "avatar.height":
            _number(p.get("value"), *self._height_bounds, "VRC Eye eye-height bounds")
            if self._value("/avatar/eyeheightscalingallowed") is not True:
                raise ValueError("Scaling permission is disabled or currently unverified")
            if not self._value("/avatar/change"):
                raise ValueError("Observe the current avatar before applying scaling")
        elif action == "safety.eye":
            _bool(p.get("native", False), "Native Safe Mode step")
            _bool(p.get("mute", False), "Microphone privacy step")
        if "owner" in p:
            _text(p["owner"], 64, "control owner")
        return p

    def _execute(self, action, p):
        now = self.clock()
        if action == "voice.configure":
            self.service.release_owner("voice")
            self._voice_mode = p["mode"]
            self._reviews.clear()
            self._privacy = {"enabled": False, "corrective": False, "attempted": False, "status": "Off; voice behavior changed"}
            self._voice_pending = None
            self._voice_result = "Behavior not configured" if p["mode"] == "unknown" else "Behavior configured; observation required"
            return {"status": "configured", "mode": p["mode"]}
        if action == "voice.release":
            self.service.release_owner("voice")
            self._voice_pending = None
            self._voice_result = "Voice control released; native mute state must be observed"
            return {"status": "released", "detail": self._voice_result}
        if action.startswith("voice.") and action != "voice.privacy":
            desired = True if action == "voice.mute" else False if action in {"voice.unmute", "voice.hold"} else None
            observed = self._value("/avatar/parameters/MuteSelf")
            if desired is not None and observed is desired and action != "voice.hold":
                self._voice_result = "Observed muted" if desired else "Observed unmuted"
                return {"status": "already_observed", "muted": desired}
            value = 1 if self._voice_mode == "toggle" or desired is False else 0
            duration = .15 if self._voice_mode == "toggle" or value == 0 else float(p.get("seconds", 3))
            result = self._submit("/input/Voice", (value,), owner="voice", duration=duration)
            self._voice_pending = {"action_id": result["id"], "desired": desired, "baseline": observed,
                                   "at": now, "deadline": now + 3, "observed": False}
            self._voice_result = "Waiting for observation"
            return {**result, "detail": "Voice requested; wait for VRChat mute-state observation", "hold_seconds": duration if self._voice_mode == "hold" and value else None}
        if action == "voice.privacy":
            self._privacy = {"enabled": p["enabled"], "corrective": p.get("corrective", False),
                             "attempted": False, "status": "Waiting for observation" if p["enabled"] else "Off"}
            return deepcopy(self._privacy)
        if action == "chat.publish":
            kind = p.get("kind", "user")
            producer = p.get("producer", "composer")
            # A newer title or countdown supersedes its producer's pending text.
            self._cancel_chat(producer=producer, detail="Replaced by newer text")
            if len(self._chat) >= 64:
                raise ValueError("Chatbox publication queue is full")
            row = {"id": uuid.uuid4().hex, "producer": producer, "priority": _CHAT_PRIORITIES[kind], "kind": kind,
                   "created_at": now, "expires_at": now + float(p.get("ttl", 15)), "guard": self._guard,
                   "text": p["text"], "immediate": p.get("immediate", True), "notification": p.get("notification", False),
                   "privacy": "user_approved", "replacement": "latest-per-producer", "status": "pending", "action_id": None}
            self._chat.append(row)
            if kind == "user":
                self._yield_chat_to_composer()
                self._composing = False
                self._release_typing()
            return deepcopy(row)
        if action == "chat.cancel":
            count = self._cancel_chat(p.get("producer"), "Cancelled locally")
            self._composing = False
            self._release_typing()
            return {"status": "cancelled", "count": count, "detail": "Pending VRC Eye publications cancelled; text already shown in VRChat is not erased"}
        if action == "chat.typing":
            if not p["enabled"]:
                self._release_typing()
                return {"status": "released"}
            self._composing = True
            self._yield_chat_to_composer()
            result = self._submit("/chatbox/typing", (True,), owner="chat-typing", duration=30)
            self._typing = True
            self._typing_until = now + 30
            return result
        if action == "camera.set":
            return self._submit("/usercamera/" + p["name"], (p["value"],), owner=p.get("owner", "camera"))
        if action == "camera.preset":
            results = []
            for name, value in p["settings"].items():
                results.append(self._submit("/usercamera/" + name, (value,), owner=p.get("owner", "camera")))
            return {"status": "requested", "steps": results, "detail": "Selected camera settings requested; no file publication enabled"}
        if action == "camera.capture":
            if now < self._capture_next:
                raise ValueError("Wait for the camera capture cooldown")
            if any(row["status"] in {"scheduled", "requested"} and not row.get("sent_at") for row in self._captures):
                raise ValueError("A capture is already scheduled")
            delay = float(p.get("countdown", 0))
            native = p.get("native_delay", False)
            owner = p.get("owner", "camera")
            result = self._submit("/usercamera/CaptureDelayed" if native else "/usercamera/Capture", (True,),
                                  owner=owner, delay=delay, ttl=delay + 5)
            row = {"id": uuid.uuid4().hex, "action_id": result["id"], "owner": owner, "status": "scheduled",
                   "created_at": now, "due_at": now + delay, "native_delay": native, "sent_at": None,
                   "file": None, "detail": "VRChat native delayed capture" if native else "VRC Eye local countdown" if delay else "Capture scheduled"}
            self._captures.append(row)
            self._capture_next = now + delay + 3
            return {**deepcopy(row), "id": result["id"], "capture_id": row["id"]}
        if action == "camera.cancel":
            return self._cancel_captures(p.get("capture_id"))
        if action.startswith("dolly."):
            if action == "dolly.play":
                result = self._submit("/dolly/Play", (True,), owner="dolly")
                self._dolly.update(state="Playback requested", delay_until=None, request_at=now)
            elif action == "dolly.delay":
                result = self._submit("/dolly/PlayDelayed", (float(p["seconds"]),), owner="dolly")
                self._dolly.update(state="Delay requested", delay_until=now + float(p["seconds"]), request_at=now)
            elif action == "dolly.stop":
                result = self._submit("/dolly/Play", (False,), owner="dolly")
                self._dolly.update(state="Stop requested", delay_until=None, request_at=now)
            elif action == "dolly.export":
                result = self._submit("/dolly/Export", (), owner="dolly")
            else:
                checked = validate_dolly_json(p["json"])
                result = self._submit("/dolly/Import", (checked["json"],), owner="dolly")
                self._dolly.update(state="Path import requested", path={"space": p.get("space", "local"), "world_id": p.get("world_id", ""),
                                   "notes": p.get("notes", ""), "points": checked["points"]}, request_at=now)
            return {**result, "detail": self._dolly["state"]}
        if action == "avatar.height":
            result = self._submit("/avatar/eyeheight", (float(p["value"]),), owner="avatar-scaling")
            self._height = {"requested": float(p["value"]), "status": "Height requested; waiting for effective height",
                            "action_id": result["id"], "at": now, "avatar_id": self._value("/avatar/change")}
            return result
        if action == "avatar.switch":
            self._hook("suspend_avatar_actions")
            result = self._submit("/avatar/change", (p["avatar_id"],), owner="avatar-switch")
            self._switch = {"avatar_id": p["avatar_id"], "action_id": result["id"], "at": now, "deadline": now + 15,
                            "status": "Waiting for avatar transition", "eligibility": self._eligible[p["avatar_id"]]}
            return deepcopy(self._switch)
        if action == "safety.native":
            return self._submit("/input/PanicButton", (1,), owner="native-safety")
        if action == "safety.eye":
            return self._enter_safety(p)
        self._hook("leave_safety")
        self._safety["active"] = False
        return {"status": "left", "detail": "VRC Eye Safety Mode ended; held inputs, microphone, automation, chat, and native Safe Mode are not restored automatically"}

    def _hook(self, name):
        function = self.hooks.get(name)
        return function() if function is not None else None

    def _enter_safety(self, p):
        steps = []
        def step(name, function):
            try:
                result = function()
                status = "requested" if isinstance(result, dict) and result.get("sent_at") is not None else "completed"
                steps.append({"step": name, "status": status, "result": result})
            except Exception as exc:
                steps.append({"step": name, "status": "unverified", "detail": str(exc)[:200]})
        def hooked(name):
            if name not in self.hooks:
                raise ValueError("This local integration is unavailable")
            return self._hook(name)
        step("Pause VRC Eye automation", lambda: hooked("suspend_automation"))
        # Preserve only the permissions already granted while completing this
        # reviewed sequence. No permission is granted or restored here.
        step("Release VRC Eye-owned OSC inputs", lambda: self.service.release_all(reason="VRC Eye Safety Mode"))
        step("Cancel scheduled chatbox output", lambda: self._cancel_chat(detail="VRC Eye Safety Mode"))
        step("Cancel local capture countdowns", self._cancel_captures)
        step("Pause approved media effects", lambda: hooked("pause_media"))
        step("Local privacy and reminders", lambda: hooked("local_safety"))
        if p.get("native"):
            def native():
                request = self.service.review("/input/PanicButton", (1,), source="manual", owner="native-safety")
                return self.service.send_now(request)
            step("Request native VRChat Safe Mode", native)
        if p.get("mute"):
            def mute():
                self._voice_pending = None
                self._validate("voice.mute", {})
                result = self._execute("voice.mute", {})
                if result.get("id"):
                    return self.service.flush_action(result["id"])
                return result
            step("Request VRChat microphone mute", mute)
        step("Create local diagnostic bookmark", lambda: hooked("bookmark"))
        # Owed releases use the urgent path, including short native button pulses.
        # This does not undo native Safe Mode and never restores a microphone.
        step("Suspend OSC output permissions", lambda: self.service.stop_controls(reason="VRC Eye Safety Mode"))
        self._guard = self._service_guard()
        self._reviews.clear()
        self._safety = {"active": True, "steps": steps}
        return deepcopy(self._safety)

    def set_composing(self, composing=True):
        """Local editor focus; no typing publication without its own permission."""
        self._composing = _bool(composing, "Composer state")
        if composing:
            self._yield_chat_to_composer()
        else:
            self._release_typing()

    def _yield_chat_to_composer(self):
        for row in self._chat:
            if row["kind"] != "user" and row.get("action_id"):
                command = self._action(row["action_id"])
                if command.get("sent_at") is None and command.get("status") not in _SENT_STATES:
                    self.service.cancel(row["action_id"], reason="Human composition has priority")
                    row.update(action_id=None, status="pending")
                    self._chat_next = self.clock()

    def _release_typing(self):
        if self._typing:
            self.service.release_owner("chat-typing")
        self._typing = False
        self._typing_until = None

    def cancel_chat_producer(self, producer):
        """Cancel only a named local producer, including after permissions close."""
        if not isinstance(producer, str) or not producer or len(producer) > 100:
            raise ValueError("Choose a valid chat producer.")
        return self._cancel_chat(producer, detail="Producer stopped")

    def guard_chat_publication(self, publication_id, predicate):
        """Fail-closed final preflight for a specific reviewed publication."""
        if not callable(predicate):
            raise ValueError("A local publication predicate is required.")
        row = next((row for row in self._chat if row['id'] == publication_id), None)
        if row is None:
            raise ValueError("The chat publication is no longer pending.")
        if row.get('action_id'):
            self.service.guard_dispatch(row['action_id'], predicate)
        self._chat_guards[publication_id] = predicate

    def _finish_chat_command(self, row):
        """Preserve transmission evidence before later producer/context changes."""
        if not row.get('action_id'):
            return False
        command = self._action(row['action_id'])
        sent = command.get('sent_at') is not None or command.get('status') in _SENT_STATES
        if not sent and command.get('status') not in _TERMINAL_FAILURES:
            return False
        row.update(status='submitted' if sent else command['status'],
                   detail='Submitted through OSC; receipt by other users is unverified' if sent else command.get('detail', ''))
        self._chat_history.append(deepcopy(row))
        self._chat.remove(row)
        self._chat_guards.pop(row['id'], None)
        return True

    def _cancel_chat(self, producer=None, detail="Cancelled locally"):
        count = 0
        for row in list(self._chat):
            if producer is None or row["producer"] == producer:
                if self._finish_chat_command(row):
                    continue
                if row.get("action_id"):
                    self.service.cancel(row["action_id"], reason=detail)
                row.update(status="cancelled", detail=detail)
                self._chat_history.append(deepcopy(row))
                self._chat.remove(row)
                self._chat_guards.pop(row['id'], None)
                count += 1
        return count

    def _cancel_captures(self, capture_id=None):
        cancelled, handed_off = 0, 0
        for row in self._captures:
            if capture_id is not None and row["id"] != capture_id:
                continue
            current = self._action(row["action_id"])
            if row.get("sent_at") is not None or current.get("status") in _SENT_STATES or current.get("sent_at") is not None:
                handed_off += 1
                row["detail"] = "Already handed to VRChat; cancelling a local timer cannot undo a native capture"
            elif row["status"] not in _TERMINAL_FAILURES:
                self.service.cancel(row["action_id"], reason="Local capture cancelled")
                row.update(status="cancelled", detail="Local capture cancelled before transmission")
                cancelled += 1
        if cancelled:
            self._capture_next = self.clock()
        return {"status": "cancelled", "cancelled": cancelled, "already_handed_off": handed_off}

    def cancel_owner(self, owner):
        """Cleanup adapter for World/Avatar camera dialogs sharing this controller."""
        self.service.release_owner(owner)
        for row in self._captures:
            if row["owner"] == owner and row.get("sent_at") is None:
                self._cancel_captures(row["id"])

    def observe_capture_file(self, path, *, capture_id=None):
        """Record selected-folder evidence without claiming causal attribution."""
        name = str(path).replace("\\", "/").rsplit("/", 1)[-1]
        _text(name, 255, "capture filename")
        choices = [row for row in self._captures if row.get("sent_at") is not None and (capture_id is None or row["id"] == capture_id)]
        if not choices:
            return None
        row = choices[-1]
        row.update(file=name, status="file_observed", detail="A nearby photo file was observed; it may have been triggered by another control")
        return deepcopy(row)

    def set_eligible_avatars(self, entries):
        """App supplies a fresh local list from its existing account data, never ids from peers."""
        self._check_context()
        if not isinstance(entries, dict) or len(entries) > 2000:
            raise ValueError("Expected a bounded avatar eligibility mapping")
        clean = {}
        for avatar, basis in entries.items():
            if not isinstance(avatar, str) or not _AVATAR.fullmatch(avatar) or basis not in {"favorites", "recents", "uploads"}:
                raise ValueError("Invalid avatar eligibility entry")
            clean[avatar] = basis
        self._eligible = clean

    def set_height_bounds(self, minimum=.2, maximum=5.0, *, reviewed=False):
        if not reviewed:
            raise ValueError("Review advanced eye-height bounds first")
        low = _number(minimum, .1, 100, "Minimum supported eye height")
        high = _number(maximum, .1, 100, "Maximum supported eye height")
        if low >= high:
            raise ValueError("Eye-height minimum must be below maximum")
        self._height_bounds = (low, high)
        self._reviews.clear()

    def _check_context(self):
        current = self._service_guard()
        context = self._service_context_guard()
        if context != self._context_guard:
            self.reset_context("OSC session, avatar, profile, or metadata changed")
        elif current != self._guard:
            # An unsubmitted preview must be reviewed again after any permission
            # change. Already accepted work survives unrelated capability grants.
            self._reviews.clear()
            self._guard = current
            self._check_permissions()

    def _check_permissions(self):
        if not self._permitted("/input/Voice"):
            self.service.release_owner("voice")
            if self._voice_pending:
                self._voice_pending = None
                self._voice_result = "Control suspended; microphone output permission was revoked"
            if self._privacy["enabled"]:
                self._privacy["correction_suspended"] = True
                self._privacy["status"] = "Microphone control permission unavailable; privacy observation alerts remain active"
        if not self._permitted("/chatbox/input"):
            self._cancel_chat(detail="Chatbox publication permission revoked")
        if not self._permitted("/chatbox/typing"):
            self._release_typing()
        for row in self._captures:
            endpoint = "/usercamera/CaptureDelayed" if row["native_delay"] else "/usercamera/Capture"
            if not self._permitted(endpoint) and row.get("sent_at") is None:
                self._cancel_captures(row["id"])
        if not self._permitted("/dolly/Play") and self._dolly["request_at"] is not None:
            self.service.release_owner("dolly")
            self._dolly.update(state="Control revoked; playback state unverified", delay_until=None, request_at=None)
        if not self._permitted("/avatar/eyeheight") and self._height.get("action_id"):
            self.service.cancel(self._height["action_id"], reason="Scaling control permission revoked")
            self._height["status"] = "Scaling control permission revoked; effective height is observation only"
        if not self._permitted("/avatar/change") and self._switch and self._switch["status"] == "Waiting for avatar transition":
            self.service.cancel(self._switch["action_id"], reason="Avatar switch permission revoked")
            self._switch["status"] = "Unresolved; avatar switch permission revoked"

    def reset_context(self, reason="Context changed"):
        self._reviews.clear()
        self._eligible.clear()
        self._cancel_chat(detail=reason)
        self._release_typing()
        self._composing = False
        self._cancel_captures()
        self.service.release_owner("voice")
        self._voice_pending = None
        self._voice_result = "Control suspended; " + reason
        self._privacy = {"enabled": False, "corrective": False, "attempted": False, "status": "Off; " + reason}
        self._height = {"requested": None, "status": reason, "action_id": None, "at": None}
        if self._switch and self._switch["status"] == "Waiting for avatar transition":
            observation = self._obs("/avatar/change")
            command = self._action(self._switch["action_id"])
            if observation and observation.get("value") == self._switch["avatar_id"] and observation.get("received_at", -1) >= self._switch["at"] and (command.get("sent_at") is not None or command.get("status") in _SENT_STATES):
                self._switch["status"] = "Avatar transition observed; compatibility review required"
                self._hook("avatar_transition")
            else:
                self._switch["status"] = "Unresolved; " + reason
        self._dolly.update(state="State unknown", delay_until=None, request_at=None)
        self._guard = self._service_guard()
        self._context_guard = self._service_context_guard()

    def tick(self):
        self._check_context()
        now = self.clock()
        self._tick_voice(now)
        if self._typing_until is not None and now >= self._typing_until:
            self._typing = False
            self._typing_until = None
        self._tick_chat(now)
        for row in self._captures:
            current = self._action(row["action_id"])
            status = current.get("status")
            if status in _SENT_STATES or current.get("sent_at") is not None:
                row["sent_at"] = current.get("sent_at", now)
                if row["status"] != "file_observed":
                    row.update(status="requested", detail="Capture requested. No matching file has been identified yet.")
            elif status in _TERMINAL_FAILURES and row.get("sent_at") is None:
                row.update(status=status, detail=current.get("detail", status))
        observed = self._obs("/dolly/Play")
        if observed and self._dolly["request_at"] is not None and observed.get("received_at", -1) >= self._dolly["request_at"]:
            if observed.get("value") is False:
                self._dolly.update(state="Stopped", delay_until=None)
            elif self._dolly["delay_until"] is not None:
                self._dolly["state"] = "Waiting" if now < self._dolly["delay_until"] else "Delay elapsed; playback unverified"
            else:
                self._dolly["state"] = "Playback observed"
        height = self._obs("/avatar/eyeheight")
        if height and self._height["requested"] is not None and height.get("received_at", -1) >= self._height["at"]:
            value = height.get("value")
            if type(value) in (int, float):
                self._height["status"] = "Requested height observed; world enforcement may follow" if math.isclose(value, self._height["requested"], rel_tol=1e-4) else "A different effective height was observed; the requested value will not be resent"
        if self._switch and self._switch["status"] == "Waiting for avatar transition":
            observed = self._obs("/avatar/change")
            command = self._action(self._switch["action_id"])
            if command.get("status") in _TERMINAL_FAILURES:
                self._switch["status"] = "Unresolved; switch " + command["status"]
            elif observed and observed.get("value") == self._switch["avatar_id"] and observed.get("received_at", -1) >= self._switch["at"] and (command.get("status") in _SENT_STATES or command.get("sent_at") is not None):
                self._switch["status"] = "Avatar transition observed; compatibility review required"
                self._hook("avatar_transition")
            elif now >= self._switch["deadline"]:
                self._switch["status"] = "Unresolved; no matching avatar transition was observed"
        return self.snapshot()

    def _tick_voice(self, now):
        observation = self._obs("/avatar/parameters/MuteSelf")
        muted = observation.get("value") if observation else None
        if type(muted) is not bool:
            muted = None
        pending = self._voice_pending
        if pending:
            command = self._action(pending["action_id"])
            if command.get("status") in _TERMINAL_FAILURES:
                self._voice_result = "Control suspended; " + command["status"]
                self._voice_pending = None
            elif observation and observation.get("received_at", -1) > pending["at"] and (command.get("sent_at") is not None or command.get("status") in _SENT_STATES):
                desired = pending["desired"]
                expected = not pending["baseline"] if desired is None and type(pending["baseline"]) is bool else desired
                if muted is expected:
                    self._voice_result = "Observed muted" if muted else "Observed unmuted"
                    self._voice_pending = None
                else:
                    self._voice_result = "Conflicting changes detected; no automatic retry"
                    self._voice_pending = None
            elif now >= pending["deadline"]:
                self._voice_result = "Microphone privacy state is currently unverified; no automatic retry"
                self._voice_pending = None
        elif muted is None and self._voice_mode != "unknown":
            self._voice_result = "State unknown; microphone privacy is unverified"
        elif muted is not None and self._voice_result in {"Observed muted", "Observed unmuted", "Behavior configured; observation required"}:
            self._voice_result = "Observed muted" if muted else "Observed unmuted"
        if self._privacy["enabled"]:
            if muted is None:
                self._privacy["status"] = "Microphone privacy state is currently unverified" + ("; corrective control is blocked" if self._privacy.get("correction_suspended") or not self._permitted("/input/Voice") else "")
            elif muted:
                self._privacy["status"] = "VRChat reports muted; this does not verify physical or operating-system microphones"
            elif self._privacy.get("correction_suspended") or not self._permitted("/input/Voice"):
                self._privacy["status"] = "VRChat reports unmuted; privacy alert. Corrective control is blocked; review microphone permission and the watchdog policy to enable it again"
            elif self._privacy["corrective"] and not self._privacy["attempted"]:
                self._privacy["attempted"] = True
                try:
                    self._validate("voice.mute", {})
                    self._execute("voice.mute", {})
                    self._privacy["status"] = "One reviewed corrective mute attempt requested"
                except (ValueError, RuntimeError, PermissionError) as exc:
                    self._privacy["status"] = "Corrective control unavailable: " + str(exc)
            else:
                self._privacy["status"] = "VRChat reports unmuted; privacy alert" + ("; correction stopped to avoid conflicting with user input" if self._privacy["attempted"] else "")

    def _tick_chat(self, now):
        for row in list(self._chat):
            if self._finish_chat_command(row):
                continue
            predicate = self._chat_guards.get(row['id'])
            if predicate is not None:
                try:
                    valid = predicate() is True
                except Exception:
                    valid = False
                if not valid:
                    if row.get('action_id'):
                        self.service.cancel(row['action_id'], reason="Producer context changed")
                    row.update(status="cancelled", detail="Producer context changed")
                    self._chat_history.append(deepcopy(row))
                    self._chat.remove(row)
                    self._chat_guards.pop(row['id'], None)
                    continue
            if row["expires_at"] <= now:
                if row.get("action_id"):
                    self.service.cancel(row["action_id"], reason="Chatbox publication expired")
                row.update(status="expired", detail="Expired text was not resubmitted")
                self._chat_history.append(deepcopy(row))
                self._chat.remove(row)
        available = [row for row in self._chat if row["action_id"] is None and (not self._composing or row["kind"] == "user")]
        if available and now >= self._chat_next:
            row = max(available, key=lambda item: (item["priority"], -item["created_at"]))
            try:
                action = self._submit("/chatbox/input", (row["text"], row["immediate"], row["notification"]),
                                      owner="chatbox-scheduler", ttl=min(5, row["expires_at"] - now), priority=row["priority"])
                row.update(action_id=action["id"], status="scheduled")
                if row['id'] in self._chat_guards:
                    self.service.guard_dispatch(action['id'], self._chat_guards[row['id']])
                self._chat_next = now + 3
            except (ValueError, RuntimeError, PermissionError) as exc:
                row.update(status="blocked", detail=str(exc)[:200])
                self._chat_history.append(deepcopy(row))
                self._chat.remove(row)

        active_ids = {row['id'] for row in self._chat}
        self._chat_guards = {key: predicate for key, predicate in self._chat_guards.items() if key in active_ids}

    def snapshot(self):
        voice = self._obs("/avatar/parameters/MuteSelf")
        muted = voice.get("value") if voice else None
        voice_state = {"mode": self._voice_mode, "muted": muted if type(muted) is bool else None,
                       "status": self._voice_result, "pending": deepcopy(self._voice_pending), "privacy": deepcopy(self._privacy),
                       "provider": voice.get("source") if voice else None, "observed_at": voice.get("received_at") if voice else None,
                       "layers": {"vrchat": muted, "operating_system": "unverified", "physical_device": "unverified"}}
        return {"voice": voice_state,
                "chat": {"pending": deepcopy(self._chat), "history": deepcopy(list(self._chat_history)), "composing": self._composing,
                         "typing": self._typing, "next_send_at": self._chat_next, "supports_receiving": False},
                "camera": {"captures": deepcopy(list(self._captures)), "dolly": deepcopy(self._dolly)},
                "scaling": {**deepcopy(self._height), "observed": self._value("/avatar/eyeheight"),
                            "permission": self._value("/avatar/eyeheightscalingallowed"), "user_min": self._value("/avatar/eyeheightmin"),
                            "user_max": self._value("/avatar/eyeheightmax"), "safety_bounds": self._height_bounds,
                            "osc_limits": (.01, 10000.0), "officially_supported_limits": (.1, 100.0)},
                "avatar": {"eligible": deepcopy(self._eligible), "switch": deepcopy(self._switch)}, "safety": deepcopy(self._safety)}

    def close(self):
        self.reset_context("Application closed")
