# Resume VRC Eye after Development 17

Current baseline: **VRC-Eye-v1.21.0-Development-17.zip**. It descends from the
saved Development 16 ZIP, SHA-256 `35478c444361c71e2504f2c5d0ede281230395d7a0e1bc2e0d4879e1dd5d53ba`.
Earlier continuation guides describe historical states.

shared_tags.py uses native annotations; earlier roster tags migrate idempotently
without deleting originals. shared_notes.py and PlayerHistory share tags/notes,
and native_search combines user/friend aliases. Do not reintroduce roster-only tags.

settings_bundle.py owns six typed portable sections and the durable selective
restore/undo ledger. It updates supported option fields atomically and preserves
unselected fields/permissions. UI reload is separate from persisted commit.
Do not turn bundle data into executable or service permissions.

recovery_journal.py creates new raw/project copies, captures explicit manual
repair checkpoints, and conditionally restores matching working files. It does
not run tools. Phase receipts precede filesystem changes; failed/partial records
and files are retained. Raw is application-preserved and hash-checked, not an OS
sandbox. GUID diagnostics do not validate object IDs, rigs or compilation.

Keep Development 16 AssetRipper jobs, Home navigation and transfer owners intact.
Native AssetRipper/Unity, live-origin transfers and Windows/Linux GUI acceptance
remain open. Next major feature milestone is the isolated real scene-viewer
provider, then materials/textures, rigs/blendshapes and animation. The ledger is
ARC_VRCX_GAP_LEDGER_DEV17.json; 106 areas, 50 source-implemented, 38 partial,
9 missing, 7 prerequisites and 2 source-data limitations. The separate 160-package
roadmap remains 50 source-implemented / 69 partial / 41 pending.

Exact final test and packaging evidence is in BUILD_VALIDATION.json and
VALIDATION_1_21.md. No native or live provider acceptance should be inferred
from fixture or headless UI tests.
