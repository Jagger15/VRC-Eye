"""Portable reports from explicit creator record selections and frozen previews."""
from dataclasses import dataclass
import csv
import hashlib
import html
import io
import json
from pathlib import Path
import re
import time

from game_log import redact

SCHEMA = "vrc-eye.creator-report.v1"
PROFILES = ("private", "collaborator", "public")
FORMATS = ("html", "md", "json", "csv")
MAX_SELECTED = 200
MAX_REPORT_BYTES = 4 * 1024 * 1024
USER_ID = re.compile(r"usr_[A-Za-z0-9-]+", re.I)
INSTANCE = re.compile(r"(?i)(wrld_[a-z0-9-]+):[^\s\"<>]+|~(?:private|friends|hidden|group|nonce|region)\([^)]*\)")
PATH = re.compile(r"(?i)(?:[a-z]:[\\/]|(?:/home|/Users|/workspace|/tmp|/var|/etc)/)[^\s\"<>]*")
POSIX_PATH = re.compile(r"(?<![\w:])/(?:[A-Za-z0-9_.~-]+/)*[A-Za-z0-9_.~-]+")
URL = re.compile(r"(?i)\b(?:https?|file|rtsp[ts]?|rtmp)://[^\s\"<>]+")
SECRET_TEXT = re.compile(r"(?i)(\b(?:token|secret|password|credential|api.?key)\b\s*[:=]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)")
SECRET_KEY = re.compile(r"(?i)(?:token|password|cookie|authorization|secret|credential|api.?key)")
IDENTITY_KEY = re.compile(r"(?i)(?:^|_)(?:name|names|user|users|user_id|user_ids|author|author_id|participant|participants|instance|instance_id|path|filename|url|host|address|account)(?:$|_)")
TEXT_KEYS = frozenset(("summary", "note", "notes", "description", "label", "title", "text",
    "message", "expected", "observed", "cause", "reason", "steps", "reproduction", "credits",
    "feedback", "graphics", "avatars", "hardware", "route", "zone", "subsystem", "object_id"))
# A public report defaults to portable structure and numerical evidence. Unknown
# strings are withheld because a new schema field can contain private free text.
SAFE_VALUES = frozenset(("kind", "status", "severity", "quality", "unit", "platform",
    "marker_type", "logging_mode", "scope", "source", "schema", "outcome", "state",
    "format", "profile", "recording_id", "error_group", "receipt_iso", "recorded_at",
    "created_at", "updated_at", "id", "world_id", "build_id", "run_id", "step_id",
    "observation_ids", "record_ids", "checklist_version"))
SAFE_SOURCES = frozenset(("VRChat log", "local roster", "manual", "resource_guard", "unity_player",
    "client_reported", "world helper", "helper", "creator", "unavailable", "local runtime",
    "VRChat local log", "Creator helper log (untrusted declaration)"))
SAFE_SCOPES = frozenset(("local", "this client", "process", "local process", "observed instance population",
    "world helper", "helper", "local client", "peer transport", "world synchronization", "helper command",
    "local client / process", "local device"))
STRUCTURAL_KEYS = SAFE_VALUES | TEXT_KEYS | frozenset(("data", "details", "evidence", "value", "values",
    "period_seconds", "sample_count", "event_time", "receipt_time", "elapsed_seconds", "sequence",
    "clock_uncertainty_seconds", "recorded_at", "interval_start", "interval_end", "omitted_evidence",
    "limitations", "coverage", "helper_authenticated", "initial_observation", "baseline_known",
    "complete_roster", "delta_observed", "dropped_roster_entries", "ended", "metrics", "results",
    "profile_snapshot", "checklist_snapshot", "profile_id", "checklist_id", "steps", "tests",
    "version", "revision", "count", "first", "last", "minimum", "maximum", "mean", "median",
    "p95", "platforms", "builds", "assertions", "permissions", "controls", "parameters", "enabled",
    "pinned", "protected", "capacity", "recommendedCapacity", "recommended_capacity", "release_status",
    "source_revision", "schema_version", "created", "updated", "observation_period", "first_receipt",
    "last_receipt", "metadata", "draft", "base", "latest", "manifest", "entries", "changes"))
ENUMS = frozenset(("error", "warning", "log", "join", "leave", "population", "metric", "action",
    "helper", "assertion", "bookmark", "build", "phase", "reported_problem", "process_exit", "coverage",
    "zone", "note", "issue", "profile", "checklist", "run", "metadata", "metadata_draft", "recipe",
    "baseline", "release", "feedback", "inventory", "control_request", "world", "knowledge",
    "route", "experiment", "local", "unknown", "observed", "reported", "measured", "partial",
    "unavailable", "single_sample", "helper_declared", "complete", "debug", "info", "fatal",
    "manual", "comparison", "location", "ordinary", "build_and_test", "debug_logging",
    "windows", "android", "ios", "standalonewindows", "standalonewindows64", "osx", "linux",
    "not started", "in progress", "passed", "failed", "blocked", "not applicable", "n/a",
    "needs verification", "verified", "fixed", "open", "closed", "untested", "cancelled",
    "pending", "accepted", "rejected", "completed", "timeout", "confirmed_failure", "verified_failure",
    "public", "private", "collaborator", "draft", "staging", "published", "local_only"))
UNITS = frozenset(("ms", "milliseconds", "fraction", "s", "seconds", "fps", "%", "bytes", "B", "KB", "KiB", "MB", "MiB",
    "GB", "GiB", "players", "count", "events", "bytes/s", "B/s", "KB/s", "kbit/s", "Mbit/s", "Hz"))
UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z", re.I)
WORLD_ID = re.compile(r"wrld_[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\Z", re.I)
ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}T[0-9:.+Z-]+\Z")


def _safe_value(key, value):
    if key in ("kind", "status", "severity", "quality", "platform", "marker_type", "logging_mode", "outcome", "state", "profile"):
        return value.casefold().replace("_", " ") in ENUMS or value.casefold() in ENUMS
    if key == "unit":
        return value in UNITS
    if key == "source":
        return value in SAFE_SOURCES
    if key == "scope":
        return value in SAFE_SCOPES
    if key in ("receipt_iso", "created_at", "updated_at"):
        return bool(ISO_DATE.fullmatch(value))
    if key in ("error_group", "recording_id"):
        return bool(re.fullmatch(r"[0-9a-f]{16,64}", value))
    if key == "world_id":
        return bool(WORLD_ID.fullmatch(value))
    if key in ("id", "build_id", "run_id", "step_id", "observation_ids", "record_ids", "profile_id", "checklist_id"):
        return bool(UUID.fullmatch(value))
    if key == "schema":
        return value in (SCHEMA, "vrc-eye-creator-selection-1")
    return False


@dataclass(frozen=True)
class ReportPreview:
    document: str
    format: str
    record_ids: tuple
    profile: str
    omissions: tuple
    sha256: str
    world_id: str

    @property
    def bytes(self):
        return self.document.encode("utf-8")


def _clean_text(value):
    value = redact(str(value))
    value = SECRET_TEXT.sub(lambda match: match[1] + "[REDACTED]", value)
    value = USER_ID.sub("[user identifier removed]", value)
    value = INSTANCE.sub("[instance identifier removed]", value)
    value = URL.sub("[URL removed]", value)
    return POSIX_PATH.sub("[local path removed]", PATH.sub("[local path removed]", value))


def _sanitize(value, *, profile, include_text, omissions, key="", depth=0):
    if depth > 16:
        omissions.add("Fields deeper than the report nesting limit")
        return "[omitted]"
    if SECRET_KEY.search(key):
        omissions.add("Credentials and authentication fields")
        return "[redacted]"
    if profile != "private" and IDENTITY_KEY.search(key) and key not in ("world_id", "build_id", "run_id", "step_id"):
        omissions.add("Participant identities, instance identifiers, paths and URLs")
        return "[redacted]"
    if isinstance(value, dict):
        clean = {}
        for index, (k, v) in enumerate(value.items()):
            key_name = str(k)
            if profile != "private" and not include_text and key_name not in STRUCTURAL_KEYS:
                output_key = f"withheld_field_{index+1}"
                omissions.add("Unrecognized field names (may contain private text)")
            else:
                output_key = key_name if profile == "private" else _clean_text(key_name)
            clean[output_key] = _sanitize(v, profile=profile, include_text=include_text,
                omissions=omissions, key=key_name, depth=depth+1)
        return clean
    if isinstance(value, (list, tuple)):
        if len(value) > 2000:
            omissions.add("List items beyond 2000")
        return [_sanitize(v, profile=profile, include_text=include_text, omissions=omissions,
            key=key, depth=depth+1) for v in value[:2000]]
    if type(value) in (int, float, bool) or value is None:
        return value
    if not isinstance(value, str):
        omissions.add("Unsupported field values")
        return "[omitted]"
    if profile == "private":
        if not include_text and key in TEXT_KEYS:
            omissions.add("Free text (not selected for disclosure)")
            return "[text omitted]" if value else ""
        return SECRET_TEXT.sub(lambda match: match[1] + "[REDACTED]", redact(value))
    if not value:
        return ""
    if key == "source" and value not in SAFE_SOURCES:
        omissions.add("Custom source labels")
        return "custom source"
    if key == "scope" and value not in SAFE_SCOPES:
        omissions.add("Custom scope labels")
        return "custom scope"
    if not include_text and not _safe_value(key, value):
        omissions.add("Free text and unrecognized text fields (not selected for disclosure)")
        return "[text omitted]"
    return _clean_text(value)


def _context(records):
    builds, runs, sources, stamps = set(), set(), set(), []
    for record in records:
        data = record.get("data", {})
        if data.get("build_id"):
            builds.add(str(data["build_id"]))
        if data.get("run_id"):
            runs.add(str(data["run_id"]))
        if data.get("source"):
            sources.add(str(data["source"]))
        stamp = data.get("receipt_time")
        if type(stamp) in (int, float):
            stamps.append(stamp)
    return dict(build_ids=sorted(builds), run_ids=sorted(runs), sources=sorted(sources),
        observation_period={"first_receipt": min(stamps), "last_receipt": max(stamps)} if stamps else None)


def _classification(record):
    data = record.get("data", {})
    status = str(data.get("status", data.get("outcome", ""))).casefold()
    if status in ("verified_failure", "confirmed_failure", "failed"):
        return "Recorded failure; see selected test evidence"
    if data.get("kind") == "reported_problem" or record.get("kind") == "feedback":
        return "Reported problem"
    if status in ("not_started", "not started", "blocked", "untested", "needs_verification", "needs verification"):
        return "Untested or needs verification"
    if data.get("kind") == "error":
        return "Observed error; cause unconfirmed"
    if record.get("kind") in ("issue", "knowledge"):
        return "Tracked finding; verification state retained"
    return "Selected evidence"


def _render(report, format):
    if format == "json":
        return json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    if format == "csv":
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        writer.writerow(("schema", "profile", "world_id", "record_id", "kind", "classification", "data_json", "omissions", "limitations"))
        def cell(value):
            value = str(value)
            # Portable CSV must not turn untrusted creator text into formulas.
            return "'" + value if value.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else value
        for record in report["records"]:
            writer.writerow([cell(v) for v in (SCHEMA, report["profile"], report["world_id"], record["id"],
                record["kind"], record["classification"], json.dumps(record.get("data", {}), ensure_ascii=False),
                "; ".join(report["omissions"]), "; ".join(report["limitations"]))])
        return out.getvalue()
    encoded = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)
    if format == "md":
        # Indented code avoids fence injection and active remote image rendering.
        sections = ["# VRC Eye creator test report", "", "This portable report contains only the reviewed selection.", "",
            f"Disclosure profile: {report['profile']}. Selected records: {len(report['records'])}.", "",
            "## Context", "", *["    " + line for line in json.dumps({"world_id": report["world_id"],
                **report["context"]}, indent=2, ensure_ascii=False).splitlines()], "", "## Results", ""]
        for index, record in enumerate(report["records"], 1):
            sections.extend([f"### Selected record {index}", "", record["classification"], "",
                *["    " + line for line in json.dumps(record, indent=2, ensure_ascii=False).splitlines()], ""])
        sections.extend(["## Disclosure and limitations", "", *["- " + item for item in report["omissions"] + report["limitations"]],
            "", "## Portable schema", "", "    " + report["schema"], ""])
        return "\n".join(sections)
    def esc(value):
        return html.escape(str(value))
    results = []
    for index, record in enumerate(report["records"], 1):
        data = record.get("data", {})
        summary = data.get("summary", data.get("label", data.get("title", "")))
        fields = {k: data[k] for k in ("source", "scope", "quality", "value", "unit", "sample_count", "period_seconds",
            "build_id", "run_id", "receipt_iso") if k in data}
        table = "".join("<tr><th>" + esc(k.replace("_", " ").title()) + "</th><td>" + esc(v if v is not None else "Unknown") + "</td></tr>"
            for k, v in fields.items())
        details = json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False)
        results.append(f"<section><h3>Selected record {index}: {esc(record['kind'])}</h3>"
            f"<p class=\"classification\">{esc(record['classification'])}</p>"
            + ("<p>" + esc(summary) + "</p>" if summary else "")
            + ("<table>" + table + "</table>" if table else "")
            + "<details><summary>Full selected evidence</summary><pre>" + esc(details) + "</pre></details></section>")
    omissions = "".join("<li>" + esc(v) + "</li>" for v in report["omissions"])
    limitations = "".join("<li>" + esc(v) + "</li>" for v in report["limitations"])
    context = json.dumps(report["context"], indent=2, ensure_ascii=False, allow_nan=False)
    return ("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
        "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; style-src 'unsafe-inline'\">"
        "<title>VRC Eye creator test report</title><style>body{font:16px system-ui;max-width:1100px;"
        "margin:2rem auto;padding:0 1rem;color:#182333}pre{white-space:pre-wrap;overflow-wrap:anywhere;"
        "background:#f1f4f8;padding:1rem;border-radius:8px}h1{font-size:1.7rem}section{border-top:1px solid #ccd5df;"
        "padding:1rem 0}table{border-collapse:collapse;max-width:100%;margin:1rem 0}th,td{text-align:left;"
        "padding:.35rem .8rem;border:1px solid #dce2ea;overflow-wrap:anywhere}.classification{font-weight:600}"
        "summary{cursor:pointer}li{margin:.35rem 0}</style></head><body>"
        "<h1>VRC Eye creator test report</h1><p>This portable report contains only the reviewed selection.</p>"
        + f"<p><strong>World:</strong> {esc(report['world_id'])}<br><strong>Disclosure:</strong> {esc(report['profile'])}"
        + f"<br><strong>Selected records:</strong> {len(report['records'])}</p>"
        + "<h2>Test context</h2><pre>" + esc(context) + "</pre><h2>Results and evidence</h2>"
        + "".join(results) + "<h2>Disclosure</h2><ul>" + omissions + "</ul><h2>Limitations</h2><ul>"
        + limitations + "</ul><p>Portable schema: " + esc(report["schema"]) + "</p></body></html>\n")


def preview_report(store, world_id, selected_ids, profile="public", format="html", *,
                   include_text=False, clock=time.time):
    """Return exact export text; never select all notes or follow attachment paths.

    include_text is an explicit disclosure choice. Public free text can contain
    names no deterministic redactor can recognize, so the preview remains the
    final review boundary when the creator deliberately enables it.
    """
    if profile not in PROFILES or format not in FORMATS:
        raise ValueError("Unknown report profile or format.")
    if type(include_text) is not bool:
        raise ValueError("Free-text disclosure must be an explicit boolean choice.")
    if isinstance(selected_ids, (str, bytes)) or selected_ids is None:
        raise ValueError("Choose explicit creator record IDs for this report.")
    selected_ids = tuple(dict.fromkeys(selected_ids))
    if not selected_ids or len(selected_ids) > MAX_SELECTED:
        raise ValueError("Select between 1 and 200 records for a report.")
    omissions = {"Unselected records and attachments are excluded."}
    if not include_text:
        omissions.add("Free text was not selected for disclosure.")
    records = []
    for identifier in selected_ids:
        record = store.get(identifier)
        if record is None or record.get("world_id") != world_id:
            raise ValueError("A selected record is missing or belongs to another world.")
        clean = _sanitize(record, profile=profile, include_text=include_text, omissions=omissions)
        clean["classification"] = _classification(record)
        records.append(clean)
    limitations = ["This report describes selected evidence, not complete world or instance coverage.",
        "Observed correlations do not establish a cause.",
        "Publication state and live loaded build are separate facts.",
        "Sources retain their scopes; peer latency does not establish Udon synchronization health."]
    if include_text and profile != "private":
        limitations.append("Free text was explicitly included. Review names and other identifying language before sharing.")
    report = dict(schema=SCHEMA, profile=profile, world_id=_clean_text(world_id),
        generated_at=clock(), selected_record_ids=list(selected_ids), context=_context(records),
        records=records, omissions=sorted(omissions), limitations=limitations)
    document = _render(report, format)
    content = document.encode("utf-8")
    if len(content) > MAX_REPORT_BYTES:
        raise ValueError("Report exceeds 4 MB; narrow the selected evidence.")
    return ReportPreview(document, format, selected_ids, profile, tuple(sorted(omissions)),
        hashlib.sha256(content).hexdigest(), world_id)


def export_report(preview, path):
    """Write exactly a frozen preview, refusing silent overwrite or alteration."""
    if not isinstance(preview, ReportPreview):
        raise TypeError("Export requires a reviewed ReportPreview.")
    content = preview.bytes
    if len(content) > MAX_REPORT_BYTES or hashlib.sha256(content).hexdigest() != preview.sha256:
        raise ValueError("The report preview has changed; create and review another preview.")
    target = Path(path)
    expected = "." + preview.format
    if target.suffix.casefold() != expected:
        raise ValueError(f"Choose a {expected} file for this preview.")
    with target.open("xb") as stream:
        stream.write(content)
    return str(target)
