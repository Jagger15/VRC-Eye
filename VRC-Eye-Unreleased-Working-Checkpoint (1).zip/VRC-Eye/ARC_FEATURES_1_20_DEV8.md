# VRC Eye — ARC-inspired additions (Development 8)

Open **Ctrl+K → Avatar Library**. New sections are **3D preview**, **Folder discovery**,
**Import & export** and **Recovery**. These extend the existing catalog; opening
any section performs no network request or scan.

## Actual 3D mesh preview

Select a catalog avatar and use **Choose local OBJ mesh…** to load an authorized
local `.obj`. Orbit, pan, zoom, reset and fit controls operate on the parsed
geometry. Flat shading and wireframe display the selected mesh.

Supported input is UTF-8/ASCII polygon OBJ with finite vertex coordinates and
positive/negative indices. Simple planar polygons can be triangulated; malformed,
self-intersecting, non-planar or degenerate faces are rejected. Limits are 16 MiB,
20,000 vertices, 8,000 triangles and 64 vertices per polygon. Oversized files are
rejected without truncation. The preview uses orthographic projection and
depth-sorted triangles; intersecting surfaces may display imperfectly.

Material libraries and textures are never opened. UV/normal declarations can be
checked, but the renderer uses flat face shading. Curves/surfaces and unsupported
statements fail explicitly. This does not decode VRCA, FBX or Unity bundles, evaluate
shaders, animate skeletons or prove VRChat appearance/performance. Use an authorized
source-editor OBJ export; the optional Unity tool below can export one selected
mesh within the same limits. Source files remain unchanged.

## Folder and cache discovery

Choose a specific folder you own or are authorized to inspect. A selected VRChat
cache directory is allowed, but the app does not discover or scan every account,
drive or home folder. Links/reparse points and special files are skipped/refused.

A scan examines at most 4,096 entries to depth 6, returns up to 512 candidates and
reads at most 128 KiB of short headers. Filename suffixes and recognizable Unity
headers suggest file types only. Avatar identity and ownership remain unknown.
Full hashing is deferred until you select a candidate for inspection.

Select the intended catalog avatar, inspect a candidate, review its exact hash
and association, then register its local reference. Files are neither moved nor
deleted. The root/file identity and operating context are rechecked before the
catalog transaction commits. A changed file requires another scan/inspection.

**Automatic rescans** are a separate session-only opt-in at 30, 60 or 300 seconds.
They run only while this section remains visible and the shared worker is idle.
Leaving it, changing account/selection/privacy/source, stopping or closing the app
revokes that opt-in. A rescan stages candidates; it does not automatically assign
files to avatars, import metadata, decrypt bundles or write cache data.

## Bulk metadata import

Choose one JSON object, an array, `{"avatars": [...]}`, or the recognized VRC Eye
selected-record report format. Bounds are 8 MiB, 500 unique avatar IDs and 2,048 total
build descriptors. Duplicate keys/IDs, invalid data, oversized or excessively nested records and
non-finite values are rejected. Imported metadata is observation evidence, not
proof that a download is accessible or that the avatar belongs to you.

Review proposed metadata changes before saving. The batch is atomic: all rows
save or none do. If a reviewed prior record changes, the import stops. Existing
notes, favorites, thumbnails and file references are retained. Report reimports
restore only supported metadata/build descriptors, not private state or files.
No online lookups are needed. Discarding prepared work invalidates queued results.

## Standalone HTML gallery

Choose **Selected avatar** or **Current filtered page**, give the gallery a title,
and optionally include already saved thumbnails. The page selection is limited
to the currently displayed records; it is not an unseen whole-account export.
Prepare, review the included avatar identities, then save to a new `.html` file.
Existing files are not overwritten and no browser opens automatically.

The document includes names/IDs, creator names, observed visibility/platforms and
optional re-encoded embedded thumbnails. Descriptions, private notes, account IDs,
local paths, file inventories and provider endpoints are omitted. Human-entered
names and images may still contain personal content; the output is not anonymized.
HTML text is escaped, no scripts or external resources are included, and the page
has a restrictive content policy. No site is published or shared automatically.

## Manual recovery preparation

1. Select the catalog avatar and choose a local bundle you own or are authorized
   to recover. Inspect it and review the source hash/header evidence.
2. Choose a **new staging folder** outside the app and existing Unity projects.
   Review creation of `input.bundle`, `recovery-handoff.json` and an empty
   `RecoveredProject` directory. The original remains unchanged.
3. Separately install/open an official AssetRipper release appropriate for your
   system. Use its GUI to load the staged input and export into the empty output
   folder. VRC Eye does not install or launch the tool.
4. After export finishes, choose the output in VRC Eye and inspect it. Optionally
   select the saved handoff for comparison.

The inspector reports bounded file categories, project structure, declared Unity/
package information and source-handoff comparisons. Its scan is limited to 20,000
entries, 24 directory levels and 8 GiB of declared file sizes. It does not execute
scripts, import a project into Unity or prove the output came from the selected
bundle. A matching hash confirms staged input bytes, not ownership, complete
source reconstruction or provider authenticity. Bundles often omit original
source code, authoring history, shader sources and editor-only data.

Failed/cancelled preparation can leave its newly created staging folder; inspect
its Activity receipt and destination. Existing files are never automatically
replaced or deleted. A local editable handoff manifest is not signed proof.

Official AssetRipper references reviewed during development:

- [GUI arguments](https://github.com/AssetRipper/AssetRipper/blob/master/Source/AssetRipper.GUI.Web/Arguments.cs)
- [Platform downloads](https://assetripper.github.io/AssetRipper/articles/Downloads.html)

These references did not establish a supported automatic export command for this
integration. Automatic tool execution remains unimplemented.

## Optional Unity repair copies

Install the included Avatar Toolkit locally in an authorized source-project test
copy using `Unity/AvatarToolkit/README.md`. Open **VRC Eye → Avatar Repair Copies**.
Select the source root, confirm authorization, scan, choose a concrete operation,
prepare a review, then create a separate output. Source changes invalidate the
review; each plan is one-use and expires after five minutes.

| Operation | Actual scope |
|---|---|
| Material shader replacement | Duplicate a referenced material and assign one explicitly selected shader. Compatibility/property mapping still needs inspection. |
| Missing mesh normals | Duplicate a readable referenced mesh and recalculate missing normals. No topology, rig, blendshape or tangent repair. |
| Animation path remap | Duplicate a clip and remap an explicit binding-path prefix; reject collisions and nonexistent target objects/components. Controllers remain unchanged. |
| Missing-script cleanup | Duplicate a saved prefab, unpack its copied links, and remove missing-script components on the copy. Missing scripts/behavior are not reconstructed. |
| OBJ geometry export | Exclusively save one selected mesh in source-local/bind-pose coordinates within the desktop viewer limits. No rig, materials, textures or animation. |

Material, mesh, clip and prefab copies are created in a fresh folder below
`Assets/VRC Eye Repairs` and require manual assignment after inspection. OBJ export
uses a separately selected new `.obj` filename. Unity/editor callbacks already in the
project may run during import/loading; use trusted source projects. Failure can
leave new partial outputs for inspection, while existing source assets are retained.

These are experimental editor-source tools. The editor code has not been compiled or run in Unity here. C# syntax/static
checks and the presence of EditMode tests do not establish native compatibility. Run the EditMode tests and inspect
results in Unity before using any copy in an avatar upload.
