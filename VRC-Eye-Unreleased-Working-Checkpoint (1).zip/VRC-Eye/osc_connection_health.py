"""Read-only endpoint inventory from existing OSC owners. No port probes."""
import math
from collections import Counter
from osc_service import HEALTH_SECONDS


def age(now,at):
    return round(now-at,1) if type(at) in (int,float) and math.isfinite(at) and 0<=now-at else None


def endpoint(host,port):return f'{host}:{port}' if host and port else 'Not established'


def report(data,*,now):
    service=data.get('service',{});config=data.get('transport',{});socket=data.get('socket',{})
    query=data.get('query_server',{});discovery=data.get('discovery',{});description=discovery.get('description') or {}
    received=age(now,socket.get('last_received_at'));checked=age(now,discovery.get('last_checked'))
    same_target=bool(description and (description.get('osc_host'),description.get('osc_port'))==(config.get('target_host'),config.get('target_port')))
    same_context=tuple(discovery.get('description_context') or ())==(service.get('generation'),service.get('avatar_generation'))
    fresh=checked is not None and checked<=HEALTH_SECONDS and same_context and same_target and not discovery.get('error')
    roles=[dict(role='Configured send',protocol='UDP',endpoint=endpoint(config.get('target_host'),config.get('target_port')),state='Configured; delivery unverified'),
        dict(role='Configured receive',protocol='UDP',endpoint=endpoint(config.get('receive_host'),config.get('receive_port')),state='Ephemeral port requested' if config.get('receive_port')==0 else 'Requested binding'),
        dict(role='Actual receive',protocol='UDP',endpoint=endpoint(socket.get('receive_host'),socket.get('receive_port')),state='Socket open' if socket.get('running') else 'Socket closed'),
        dict(role='Local OSCQuery',protocol='HTTP/TCP',endpoint=endpoint(query.get('host'),query.get('http_port')),state='Advertised' if query.get('running') and query.get('advertised') else 'Listening; advertisement unavailable/off' if query.get('running') else 'Stopped'),
        dict(role='Selected remote query',protocol='HTTP/TCP',endpoint=description.get('endpoint') or 'Not selected',state='Fresh, target/context matched' if fresh else 'Stale / unmatched / unchecked'),
        dict(role='Advertised remote OSC',protocol='UDP',endpoint=endpoint(description.get('osc_host'),description.get('osc_port')),state='Matches configured target' if same_target else 'Does not establish configured target')]
    findings=[]
    if not socket.get('running'):findings.append('Receive socket is closed. Connect observation in Networking; inspect its bind error if connection fails.')
    if socket.get('running') and config.get('receive_port') and config.get('receive_port')!=socket.get('receive_port'):
        findings.append('Actual receive port differs from requested port. Configure external senders for the actual port or use the advertised service.')
    if socket.get('running') and socket.get('receive_port')==config.get('target_port') and socket.get('receive_host') in (config.get('target_host'),'0.0.0.0'):
        findings.append('Send target overlaps the local receive endpoint. Review for a possible UDP loop; no settings were changed.')
    if description and not same_target:findings.append('Selected OSCQuery metadata describes a different UDP target. Review the selected instance before changing transport.')
    if description and not same_context:findings.append('Selected metadata belongs to an older connection/avatar context. Inspect the selected service again.')
    if description and (checked is None or checked>HEALTH_SECONDS):findings.append('Selected query observation is stale or its age is unknown.')
    if discovery.get('error'):findings.append('The selected query check failed; retained metadata is not current evidence.')
    if query.get('running') and query.get('osc_port')!=socket.get('receive_port'):findings.append('Local query advertises a different OSC receive port. Reconnect the shared observation service.')
    duplicate=sum(n-1 for n in Counter((r.get('host'),r.get('port')) for r in discovery.get('candidates',[])[:64]).values() if n>1)
    if duplicate:findings.append('Multiple discovery advertisements share an HTTP endpoint. This can be duplicate advertising; it does not prove a socket conflict.')
    return dict(schema=1,roles=roles,receive_age_seconds=received,query_age_seconds=checked,query_fresh=fresh,
        candidates=min(64,len(discovery.get('candidates',[]))),duplicate_advertisements=duplicate,
        managed_routes=len(data.get('workspace',{}).get('routes',[])),queued=service.get('queue_size',0),
        findings=findings or ['No inconsistency found in retained endpoint metadata. This is not a delivery or firewall test.'],
        limits='No port probing or process discovery. HTTP/TCP and OSC/UDP are separate endpoints. Addresses and advertisements do not authenticate applications. Direct traffic outside Eye is unobserved.')


def redacted(report):
    return {k:report[k] for k in ('schema','receive_age_seconds','query_age_seconds','query_fresh','candidates','duplicate_advertisements','managed_routes','queued','findings','limits')}


def describe(value):
    lines=[r['role']+' · '+r['protocol']+' · '+r['endpoint']+' · '+r['state'] for r in value['roles']]
    lines += ['',f"Last received packet age: {value['receive_age_seconds']} s; last query check age: {value['query_age_seconds']} s (None = unknown).",
        f"{value['candidates']} candidates · {value['managed_routes']} managed routes · {value['queued']} queued actions",*value['findings'],value['limits']]
    return '\n'.join(lines)
