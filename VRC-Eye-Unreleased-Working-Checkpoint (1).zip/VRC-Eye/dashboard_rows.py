"""Bounded display projections; dashboard widgets never start collectors."""
import json
import math
import re
from datetime import datetime, timezone
from hashlib import sha256

COLUMNS=('name','type','time','status','source','freshness')
TABLE_KINDS=frozenset(('session','activity','account','performance','eye','media','photos',
    'worlds','tasks','events','downloads','inbox','health','history','presence','runtime','diagnostics','applications','gamelog'))


def selected(rows,widget,*,limit=200,offset=0):
    """Pure projection: stable identity, whole-row filtering and typed time sort."""
    query=str(widget.get('filter','')).casefold()
    column=widget.get('sort','time')
    if column not in COLUMNS:column='time'
    prepared=[];seen={}
    for row in rows:
        item={k:row.get(k,'') for k in COLUMNS}
        key=str(row.get('id') or sha256(json.dumps(item,sort_keys=True,default=str).encode()).hexdigest())
        occurrence=seen.get(key,0);seen[key]=occurrence+1
        item['id']=key+(':'+str(occurrence) if occurrence else '')
        if isinstance(row.get('target'),dict):item['target']=dict(row['target'])
        if query in ' '.join(str(item[k]) for k in COLUMNS).casefold():prepared.append(item)
    def order(row):
        value=row[column]
        if column=='time':
            try:
                if isinstance(value,(int,float)) or isinstance(value,str) and re.fullmatch(r'[0-9]+(?:\.[0-9]+)?',value):number=float(value)
                else:
                    dt=datetime.fromisoformat(str(value).replace('Z','+00:00'))
                    number=dt.replace(tzinfo=dt.tzinfo or timezone.utc).timestamp()
                if not math.isfinite(number):raise ValueError
                return (1,number)
            except (ValueError,TypeError,OverflowError,OSError):return (0,0)
        return (1,str(value).casefold())
    # Equal values retain deterministic identities, irrespective of source order.
    prepared.sort(key=lambda r:r['id'])
    prepared.sort(key=order,reverse=bool(widget.get('descending',True)))
    return prepared[max(0,offset):max(0,offset)+limit],len(prepared)


def display(value,column):
    if column=='time' and isinstance(value,(int,float)):
        try:return datetime.fromtimestamp(value,timezone.utc).isoformat(timespec='seconds')
        except (ValueError,OverflowError,OSError):return 'Unknown'
    return str(value or '')


def runtime_rows(shell,hub,projection,*,samples=None):
    """One desktop-owned snapshot of existing services. Never enables a producer."""
    app=shell.app;out={k:[] for k in TABLE_KINDS}
    def add(kind,name,*,status='',source='Current observation',when='',ref='current'):
        out[kind].append(dict(id=kind+':'+ref,name=name,type=kind.title(),time=when,status=status,source=source,freshness=projection.get('sources',{}).get(kind,'Existing display snapshot; source age unknown'),freshness_source=kind))
    home=shell.pages.get('Home')
    for kind,attr in (('session','session_value'),('activity','events_value'),('account','account_value')):
        value=getattr(home,attr,None)
        add(kind,value.get() if value is not None else 'No current observation',source='Existing Home summary')
    add('media',projection.get('media','No fresh media observation'),source='Selected media provider')
    add('presence',projection.get('discord','Disabled'),source='Discord IPC')
    health=projection.get('service',{});data=health.get('data') or {}
    add('health',data.get('description','Official status not requested'),status='Stale / unknown' if health.get('stale',True) else 'Current',source='Official status provider')
    peers=getattr(app,'peer_service',None)
    add('eye',peers.snapshot().get('state','Private') if peers else 'Unavailable',source='Eye-to-Eye service')
    performance=shell.pages.get('Performance & Security')
    sample=samples.get('performance') if samples is not None else performance.service.snapshot() if performance else None
    from application_status import observed
    for name,value in observed(sample or {}).items():
        add('applications',name,status=value['state'],source=value['source'],ref=name)
    if sample and not sample.get('stale',True):
        from resource_core import format_value
        for key,label in (('ram.available','RAM available'),('cpu.system','CPU')):
            add('performance',label,status=format_value(key,sample.get('sample',{}).get(key,performance.service.clock())),source='Existing resource sample',ref=key)
    else:add('performance','Waiting for a current resource sample',status='Unknown')
    for kind,title in (('runtime','Unity Player'),('diagnostics','Crash & Diagnostics')):
        page=shell.pages.get(title)
        state=(samples.get(kind,{}) if samples is not None else page.service.snapshot() if page else {})
        add(kind,state.get('reason') or state.get('status') or 'Provider not started',
            status=state.get('state') or state.get('process','Unknown'),source=title)
        if kind=='runtime':
            for event in state.get('events',())[-200:]:
                out[kind].append(dict(id='runtime:event:'+str(event.get('seq',event)),
                    name=event.get('kind','Runtime event'),type='Runtime event',time=event.get('wall',''),
                    status=event.get('confidence','Observed'),source=event.get('source','Unity Player'),
                    freshness='Retained event; event time shown'))
    for row in hub.get('notifications',[]):
        if row.get('deleted'):continue
        out['inbox'].append(dict(id=row.get('api_family','')+':'+row.get('id',''),name=row.get('senderUsername') or row.get('message','Notification'),
            type=row.get('type',''),time=row.get('reported_time',''),status='Seen' if row.get('seen') is True else 'Unread',source=row.get('api_family','VRChat'),
            freshness='Observed '+str(row.get('observed_at') or 'at an unknown time'),target=dict(kind='notification',family=row.get('api_family'),id=row.get('id'))))
    players=getattr(app,'player_sessions',None)
    for card in (players.cards() if players is not None and hasattr(players,'cards') else ()):
        if card.user_id:out['session'].append(dict(id=card.user_id,name=card.name,type='Player',time=card.joined_at,status=card.primary_status,source='Current roster',freshness='Local roster observation',target=dict(kind='user',id=card.user_id,name=card.name)))
    return out


def project(store,account,*,analytics=False,coverage=None):
    out={key:[] for key in ('history','worlds','events','photos','tasks','downloads')}
    with store.native.connect() as db:
        # Each source has its own retained window; a burst of events cannot hide worlds.
        queries=[("kind='entity' AND json_extract(data,'$.entity_kind')='world'",'worlds')]
        if analytics:queries.extend((("kind='event'",'events'),("kind='notification'",'history')))
        records=[]
        for clause,key in queries:
            records.extend(db.execute('SELECT kind,id,data,provenance,updated FROM eye_native_records WHERE scope=? AND '+clause+' ORDER BY updated DESC,id LIMIT 200',(account,)))
        for raw in records:
            kind,ref,data,provenance,updated=raw;data=json.loads(data);p=json.loads(provenance)
            if kind=='entity' and data.get('entity_kind')=='world':
                out['worlds'].append(dict(id=ref,name=data.get('name') or ref,type='World',time=updated,status='Saved metadata',source=p.get('source','Local library'),freshness='Saved '+updated,target=dict(kind='world',id=data['entity_id'])))
            elif kind in ('event','notification') and analytics:
                row=dict(id=kind+':'+ref,name=data.get('display_name') or data.get('senderUsername') or data.get('world_name') or data.get('title') or ref,
                    type=data.get('category') or data.get('type') or kind,time=data.get('reported_time') or updated,
                    status='Historical' if data.get('historical') else 'Observed',source=p.get('source','VRC Eye'))
                out['history'].append(row);out['events'].append(row)
        tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'photo_items_v4' in tables:
            for row in db.execute('SELECT title,updated,id FROM photo_items_v4 WHERE scope=? AND hidden=0 ORDER BY updated DESC,id LIMIT 200',(account,)):
                out['photos'].append(dict(id=row[2],name=row[0],type='Photo',time=row[1],status='Cataloged',source='Local photo library',freshness='Catalog record; file not rechecked',target=dict(kind='photo',id=row[2])))
        if 'creator_projects_120' in tables:
            for row in db.execute('SELECT label,id FROM creator_projects_120 ORDER BY label,id LIMIT 200'):
                out['tasks'].append(dict(id=row[1],name=row[0],type='Creator project',time='',status='Open project for tasks',source='This device',freshness='Saved project reference',target=dict(kind='project',id=row[1])))
        if 'release_jobs_v5' in tables:
            for row in db.execute('SELECT created,state,id,payload FROM release_jobs_v5 ORDER BY created DESC,id LIMIT 200'):
                receipt=json.loads(row[3]);out['downloads'].append(dict(id=row[2],name=receipt.get('filename','Download job'),type='Download',time=row[0],status=row[1],source='Download manager',freshness='Saved receipt; file not rechecked',target=dict(kind='release',id=row[2],source=receipt.get('source',''))))
        if 'file_transfers_dev16' in tables:
            from pathlib import Path
            for raw in db.execute('SELECT data FROM file_transfers_dev16 WHERE scope=? ORDER BY updated DESC,id LIMIT 200',(account,)):
                row=json.loads(raw[0]);out['downloads'].append(dict(id=row['id'],name=Path(row['destination']).name,type='Resumable file',time=row.get('updated_at') or row['created_at'],status=row['state'],source=row['avatar_id'].split(':')[0],freshness='Saved checkpoint; refresh activity for current state',target=dict(kind='transfer',id=row['id'])))
    if coverage is not None:
        coverage.update(worlds='Newest 200 saved worlds',photos='Newest 200 visible catalog records',
            tasks='First 200 projects by name',downloads='Up to 200 receipts per local source',
            history='Newest 200 events and 200 notifications' if analytics else 'History display disabled',
            events='Newest 200 events and 200 notifications' if analytics else 'History display disabled')
    return out


def render(rows,widget,*,default=('name',),limit=5):
    rows,count=selected(rows,widget,limit=limit);columns=widget.get('columns') or list(default)
    if not rows:return 'No matching retained observations' if widget.get('filter') else 'No retained observations in this workspace'
    return '\n'.join(' · '.join(display(r.get(k,''),k) for k in columns if str(r.get(k,''))) for r in rows)+(f'\n{count} matching rows' if count>limit else '')
