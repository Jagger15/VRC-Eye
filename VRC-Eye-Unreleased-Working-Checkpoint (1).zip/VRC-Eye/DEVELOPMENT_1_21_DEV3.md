# VRC Eye 1.21.0 — Development checkpoint 3

This runnable source build adds external tracking and loader diagnostics based on
the supplied OpenVR-SpaceCalibrator 1.5.1 and MelonLoader 0.7.3 sources. It also
simplifies the collapsible sidebar. The wider VRCX, ARC and overlay roadmap remains
in progress; the previous checkpoint's features are retained.

## Start

Close the old copy, extract this ZIP into a separate folder, open `VRC-Eye`, and
run **Start.cmd** on Windows or **bash Start.sh** on Linux. Python 3.10 or newer
with Tkinter is required. The launcher prepares the app-local feature environment;
Linux also needs venv support from your distribution. **Demo.cmd / Demo.sh** and
**Safe-mode.cmd / Safe-mode.sh** remain available without dependency installation.
With an existing environment, install `requirements.txt` and run `python vrc_eye.py`.

Keep the old copy for rollback. Different extraction folders share the existing
per-user data locations; copying a folder does not isolate accounts or preferences.
This is a runnable source ZIP, not a compiled executable or signed installer.
No new runtime dependency is required by this checkpoint.

## New features

- **SpaceCal profile inspection:** Settings → SpaceCal & tracking diagnostics
  reads an explicitly selected JSON profile or the installed current-user Windows
  profile. It shows saved transforms, scale, configured flags and chaperone
  presence without changing calibration or the play space.
- **Transform worksheet:** forward/inverse point and vector previews use the
  supplied source's distinct degree/centimetre and radian/metre conventions.
  These offline calculations assume an identity existing driver origin and are
  never applied to live SteamVR poses.
- **SteamVR device health:** explicitly start a bounded inventory on VRC Eye's
  existing OpenVR owner. Inspect device class, controller role, model, connection
  and tracking health, then review saved-profile identity matches. Stale readings
  expire, and privacy/account changes clear the inspection and stop diagnostics.
- **MelonLoader diagnostics:** Unity Player → Installation → Loader diagnostics
  inspects a selected folder, source ZIP, Loader.cfg or historical log. It
  distinguishes source declarations from installed-file evidence and retains
  only supported settings and structured historical log summaries.
- **Sanitized reports:** export reviewed profile summaries or loader observations
  to new JSON files. Raw device serials, device hashes, source paths, chaperone
  geometry, arbitrary mod messages and raw loader logs are excluded.
- **Cleaner sidebar:** the visible “Collapsed/Expanded” words are removed.
  Section disclosure buttons, active-page hints, keyboard operation, saved
  choices and expand-all/collapse-all controls remain available.

See [the integration guide](EXTERNAL_TRACKING_GUIDE.md) for exact operation,
coordinate assumptions and the scope of each report.

## EAC and integration scope

[VRChat's published guidance](https://hello.vrchat.com/blog/vrchat-security-update)
allows standalone SteamVR tools and overlays while blocking modified clients.
These additions use external file inspection and the existing OpenVR connection.
They do not install a loader, inject into VRChat, patch game files, read process
memory or bypass EAC. The supplied Space Calibrator driver and MelonLoader
binaries are not included. This build is not an EAC compatibility certification.

Saved calibration is not live calibration status. This build does not replace
Space Calibrator's solver, write its driver IPC, change chaperone settings or
apply calibration a second time. Profile/device matches are identity observations,
not evidence of correct body assignments or successful calibration.

Real SteamVR hardware/compositor behavior, native Windows registry reads and
live VRChat acceptance remain unverified here. The clean-build test result and
platform limits are recorded in [validation](VALIDATION_1_21.md).

## Retained features and remaining work

The left/right wrist compass, temporary room waypoint, accent account header,
optional protected session restoration, Linux launchers, media/audio workspace,
VRCX interoperability, installation inspection and earlier creator features remain
included. Read [Development 2 notes](DEVELOPMENT_1_21_DEV2.md) and
[the compass guide](SPATIAL_COMPASS_GUIDE.md) for those features.

Remote-player ESP, Eye-to-Eye pose streaming, live VRChat-world alignment and the
full VRCX/ARC replacement roadmap are still pending. Local SteamVR device data
cannot supply another VRChat player's coordinates. The consolidated roadmap
contains 160 work packages and 849 future acceptance checks; this build does not
claim they are all implemented or tested. See [implementation status](IMPLEMENTATION_STATUS_1_21.md).

Source provenance and compatibility decisions are recorded in
[SOURCE_INTEGRATIONS_1_21_DEV3.md](SOURCE_INTEGRATIONS_1_21_DEV3.md).
