"""Reviewed Import & export panel using the existing avatar library lifecycle."""
from pathlib import Path

from companion_ui import button, choice, entry, line
from creator_projects_ui import text_area, set_text
from ui_theme import responsive_wrap
import avatar_catalog_bulk as bulk


class ImportExportPanel:
    def __init__(self, page, parent):
        self.page, self.parent = page, parent
        self.generation = 0
        self.import_plan = None
        self.gallery_plan = None
        self.selection_mode = page.tk.StringVar(value='Selected avatar')
        self.title = page.tk.StringVar(value='Avatar gallery')
        self.thumbnails = page.tk.BooleanVar(value=False)
        self.state = page.tk.StringVar(value='Choose a metadata file to inspect or prepare a gallery of saved observations.')
        responsive_wrap(page.ttk.Label(parent, text=(
            'Bulk metadata import uses the current account workspace and one database transaction. '
            'Supported: an avatar object, an array, an avatars array wrapper, or a VRC Eye avatar-library report. '
            'Limits: 8 MiB, 500 distinct avatar IDs and 2,048 build descriptors. Report imports restore observations only; '
            'file/package inventory, favorites, notes and thumbnails are not imported.'), style='Muted.TLabel')).pack(anchor='w', pady=6)
        row = line(page, parent)
        button(page, row, 'Inspect metadata batch…', self.inspect_import)
        button(page, row, 'Review & import batch…', self.import_batch)
        button(page, row, 'Discard prepared work', self.clear)
        responsive_wrap(page.ttk.Label(parent, textvariable=self.state)).pack(anchor='w', pady=5)
        page.ttk.Separator(parent).pack(fill='x', pady=7)
        page.ttk.Label(parent, text='Standalone HTML gallery', style='Heading.TLabel').pack(anchor='w')
        row = line(page, parent)
        choice(page, row, self.selection_mode, ('Selected avatar', 'Current filtered page'), width=25)
        page.ttk.Checkbutton(row, text='Include saved thumbnails', variable=self.thumbnails).pack(side='left', padx=5)
        row = line(page, parent)
        page.ttk.Label(row, text='Gallery title:').pack(side='left', padx=4)
        entry(page, row, self.title, 42)
        row = line(page, parent)
        button(page, row, 'Prepare gallery review', self.prepare_gallery)
        button(page, row, 'Review & save HTML…', self.save_gallery)
        responsive_wrap(page.ttk.Label(parent, text=(
            'Current filtered page means only the rows currently shown in the Library (12 cards or 48 list rows), '
            'not every matching record. Gallery exports retain names, avatar IDs, creator names, visibility and observed platforms. '
            'Descriptions, private notes, account IDs, source paths and provider URLs are omitted. '
            'Optional saved images may contain identifying content: inspect them in the existing preview before sharing. '
            'The HTML includes no scripts, external resources or automatic browser launch.'), style='Muted.TLabel')).pack(anchor='w', pady=6)
        self.preview = text_area(page, parent, height=18)
        set_text(self.preview, 'No batch or gallery prepared.')

    def require(self):
        self.page.writable()
        if self.page.job:
            raise ValueError('Wait for the current task to finish or stop before preparing another operation.')

    def clear(self):
        self.generation += 1
        if self.page.job:
            self.page.cancel()
        self.import_plan = None
        self.gallery_plan = None
        self.title.set('Avatar gallery')
        self.thumbnails.set(False)
        self.selection_mode.set('Selected avatar')
        self.state.set('Prepared imports and galleries cleared. Nothing was saved.')
        set_text(self.preview, 'No batch or gallery prepared.')

    def inspect_import(self):
        self.require()
        from tkinter import filedialog
        token = self.page.context()
        path = filedialog.askopenfilename(parent=self.page.app.root, title='Inspect avatar metadata JSON', filetypes=(('JSON metadata', '*.json'),))
        self.page.check_context(token)
        if not path:
            return
        scope = self.page.scope
        generation = self.generation
        self.import_plan = None
        def work(stop, progress):
            documents = bulk.read_batch(path, stop=stop, progress=progress)
            return bulk.prepare_import(self.page.library, scope, documents, stop=stop)
        def done(plan):
            if generation != self.generation:
                return
            self.import_plan = plan
            self.state.set(f'Inspected {len(plan.documents)} avatar observations. Review before saving; nothing imported yet.')
            set_text(self.preview, plan.summary)
        self.page.start_task(work, done, operation='Inspect avatar metadata batch')

    def import_batch(self):
        self.require()
        plan = self.import_plan
        if not plan or plan.scope != self.page.scope:
            raise ValueError('Inspect a metadata batch in this workspace first.')
        token, revision = self.page.context(), self.page.revision
        if not self.page.review('Review avatar metadata batch', plan.summary, 'Import entire batch'):
            return
        self.page.writable()
        if token != self.page.context() or revision != self.page.revision or self.import_plan is not plan:
            raise ValueError('The account or prepared batch changed. Inspect and review again.')
        self.import_plan = None
        def work(stop, progress):
            self.page.check_context(token)
            return bulk.commit_import(self.page.library, plan, stop=stop)
        def done(rows):
            self.page.refresh()
            self.state.set(f'Imported {len(rows)} avatar observations into this workspace in one transaction.')
            set_text(self.preview, 'Batch saved. Existing notes, favorites, thumbnails and file references retained. No files downloaded or imported.')
        self.page.start_task(work, done, operation='Import avatar metadata batch', persist=lambda result, scope: None)

    def identifiers(self):
        if self.selection_mode.get() == 'Selected avatar':
            return (self.page.selected()['id'],)
        if self.selection_mode.get() != 'Current filtered page':
            raise ValueError('Choose selected avatar or current filtered page.')
        return tuple(row['id'] for row in self.page.visible)

    def gallery_guard(self):
        filters = tuple(getattr(self.page, key).get() for key in ('query', 'platform', 'visibility', 'source', 'sort',
                        'favorites_only', 'files_only', 'after', 'before', 'view'))
        return (self.page.context(), self.page.revision, self.page.scope, self.page.privacy.get(),
                self.selection_mode.get(), self.identifiers(), self.title.get(), self.thumbnails.get(), filters, self.page.offset, self.generation)

    def prepare_gallery(self):
        self.require()
        token = self.gallery_guard()
        ids = token[5]
        scope, title, images = self.page.scope, self.title.get(), self.thumbnails.get()
        self.gallery_plan = None
        def done(plan):
            if token != self.gallery_guard():
                raise ValueError('The selection, filters or gallery options changed. Prepare again.')
            self.gallery_plan = (plan, token)
            self.state.set(f'Gallery prepared: {len(plan.identifiers)} avatar observations. Review before choosing a new HTML file.')
            set_text(self.preview, plan.summary)
        self.page.start_task(lambda stop, progress: bulk.prepare_gallery(self.page.library, scope, ids,
                             thumbnails=images, title=title, stop=stop), done, operation='Prepare local HTML gallery')

    def save_gallery(self):
        self.require()
        if not self.gallery_plan:
            raise ValueError('Prepare a gallery review first.')
        plan, token = self.gallery_plan
        if token != self.gallery_guard():
            raise ValueError('The selection or gallery options changed. Prepare again.')
        bulk.validate_gallery(self.page.library, plan)
        if not self.page.review('Review standalone avatar gallery', plan.summary, 'Choose new HTML file'):
            return
        self.page.writable()
        if token != self.gallery_guard() or not self.gallery_plan or self.gallery_plan[0] is not plan:
            raise ValueError('The account, selection or gallery options changed. Prepare again.')
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.page.app.root, title='Save new standalone avatar gallery',
            initialfile='avatar-gallery.html', defaultextension='.html', filetypes=(('HTML gallery', '*.html'),), confirmoverwrite=False)
        self.page.writable()
        if token != self.gallery_guard():
            raise ValueError('The account or gallery selection changed. Prepare again.')
        if not path:
            return
        self.gallery_plan = None
        context = self.page.context()
        def done(result):
            self.state.set(f'Standalone gallery saved ({result.size:,} bytes). Open the chosen file yourself to inspect before sharing.')
            set_text(self.preview, plan.summary + '\n\nExport completed. No browser or upload was started.')
        self.page.start_task(lambda stop, progress: bulk.save_gallery(self.page.library, plan, path,
            stop=stop, progress=progress, before_commit=lambda: self.page.check_context(context)), done,
            avatar=plan.identifiers[0], operation='Export HTML gallery', destination=str(Path(path)), persist=lambda result, scope: None)
