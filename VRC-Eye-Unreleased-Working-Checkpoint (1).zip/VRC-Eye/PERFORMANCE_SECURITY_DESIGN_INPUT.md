# VRC Eye 1.18.7 — implementation map

The supplied proposal below is preserved byte-for-byte after this preface.
This release adds **Advanced → Performance & Security**. The proposal describes
an eventual 15-stage system, including explicitly later dangerous controls.

| Proposal areas | 1.18.7 status |
| --- | --- |
| Architecture, observations, bounded stores, capability/expiry metadata | Implemented in resource_core/backend/service modules |
| Process identity, RAM, Windows commit, CPU, self-overhead | Implemented; live Windows testing remains |
| GPU/VRAM/thermal/disk | Implemented where the documented backends expose them; missing fields remain unknown |
| Duration, hysteresis, recovery, cooldown, composites, validation | Implemented; no automatic game actions |
| Dashboard, mode visibility, rules, graphs, banner, event timeline | Implemented in the new Advanced category |
| Spike/short growth analysis and context | Implemented with generic fresh log event types, never causal blame |
| Persistent recording, clean-stop recovery, replay, export, retention | Bounded optional resource journal; not the full app Black Box |
| Protection profiles and low power | Monitor Only / Balanced / Protective / Custom; low power slows this page's graph updates |
| Normal close | Explicit review, fresh exact target, no retry/escalation |
| Auto Safe Mode / auto-close / overlay | Later; no armed or placeholder controls |
| Hard OS containment, force termination, CPU limits/priority | Later per proposal; no capabilities claimed |
| Long-term baselines, OS crash integration, watchdog, restart | Later |

Operational details and limits: PERFORMANCE_SECURITY_SETUP.md.
Validation: VALIDATION.md. Original proposal follows.

---

# 1. Overall Architecture

I would divide the subsystem into six layers:

```
┌─────────────────────────────────────┐
│             VRC Eye UI              │
│ Dashboard / Safety / Overlay        │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│          Protection Engine          │
│ Rules / thresholds / escalation    │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│          Analysis Engine            │
│ Trends / spikes / correlations     │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│         Resource State Store        │
│ Current + rolling history          │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│        Platform Resource API        │
│ RAM / GPU / CPU / disk / temp      │
└──────────┬────────────────┬─────────┘
           │                │
       Windows            Linux
```

Each layer should be replaceable.

That means:

```
ResourceCollector
```

does **not** display UI.

```
ProtectionEngine
```

does **not** directly call Windows APIs.

```
SafetyUI
```

does **not** calculate thresholds.

That separation is going to save you later.

---

# 2. Core Services

I would eventually have something roughly like:

```
ResourceMonitorService
ResourceHistoryService
ResourceAnalysisService
ProtectionRuleEngine
ProtectionActionService
ResourceNotificationService
ResourceBlackBoxAdapter
ResourcePlatformBackend
```

Conceptually:

```
sample = platform_backend.sample()resource_store.update(sample)analysis = analyzer.process(sample)events = rule_engine.evaluate(    sample=sample,    analysis=analysis,)for event in events:    action_service.handle(event)
```

Nothing should be one giant:

```
monitor_vrchat()
```

function.

---

# 3. Resource Categories

VRC Eye should distinguish at least:

```
SYSTEM RAM
VRCHAT RAM

SYSTEM COMMIT
VRCHAT COMMIT

GPU VRAM
GPU LOAD

CPU LOAD
VRCHAT CPU

TEMPERATURE
DISK
PROCESS RESPONSIVENESS
```

Eventually:

```
PAGE FILE / SWAP
DISK I/O
GPU CLOCK / THROTTLING
CPU CLOCK / THROTTLING
```

could be added.

---

# 4. RAM Terminology Is Extremely Important

Do **not** simply show:

> VRChat RAM: 12 GB

without defining what that means.

There are several different memory measurements.

For example:

```
Working Set
Private Memory
Committed Memory
Virtual Address Space
System Available Memory
System Commit
```

They are not interchangeable.

For VRC Eye I'd probably expose simplified names in Casual Mode while retaining the real metrics internally.

---

# 5. VRChat Working Set

Working set roughly represents memory pages associated with VRChat that are currently resident in physical memory.

UI:

```
VRChat RAM
8.7 GB
```

Advanced tooltip:

```
Working Set
8.7 GB
```

But don't assume this represents every byte VRChat has committed.

---

# 6. VRChat Private/Committed Memory

This is often more useful when tracking memory growth.

Internally:

```
vrchat_private_bytes
vrchat_commit
```

Example:

```
Working set       8.4 GB
Private memory   10.1 GB
```

If:

```
working set stays similar
private memory keeps growing
```

you might be seeing paging/reclamation behavior.

---

# 7. System RAM

Always track:

```
Total physical RAM
Used physical RAM
Available physical RAM
Percentage available
```

Example:

```
SYSTEM MEMORY

Installed         32 GB
Used             27.4 GB
Available         4.6 GB
Usage              86%
```

---

# 8. Available Memory Matters More Than Percentage Alone

Consider:

```
System A
16 GB RAM
95% used
800 MB remaining
```

versus:

```
System B
128 GB RAM
95% used
6.4 GB remaining
```

Both say:

```
95%
```

but they're not in the same practical situation.

So rules should support both:

```
percent_used
```

and:

```
absolute_available
```

---

# 9. System Commit Pressure

On Windows especially, memory pressure isn't just physical RAM.

You want to know:

```
Committed
Commit Limit
Commit Remaining
```

because a process allocation can fail due to commit exhaustion even if the simplistic RAM meter doesn't tell the whole story.

Eventually your Resource Guard could evaluate:

```
physical available
AND
commit available
```

instead of just Task-Manager-style RAM percentage.

---

# 10. Swap / Page File

Advanced Mode:

```
Page file / swap usage
```

Useful for diagnosing:

```
RAM nearly full
→ aggressive paging
→ VRChat becomes extremely sluggish
```

A warning might be:

```
System memory pressure is causing heavy paging.
```

Rather than:

```
VRChat is broken.
```

---

# 11. VRAM Needs Its Own Abstraction

VRAM is complicated because the available telemetry differs significantly by:

- OS,
- GPU vendor,
- driver,
- graphics backend.

Do **not** make the rest of VRC Eye depend on NVIDIA-specific APIs.

Instead:

```
GpuMemoryMetrics:    total_dedicated    used_dedicated    available_dedicated    vrchat_dedicated_estimate    process_value_available    source    confidence
```

---

# 12. Device-Wide VRAM

This is the most dependable conceptual metric:

```
GPU VRAM
10.7 / 12 GB
89%
```

Linux AMDGPU, for example, exposes total and used VRAM through sysfs. [Linux Kernel Documentation](https://docs.kernel.org/gpu/amdgpu/driver-misc.html?utm_source=chatgpt.com)

That tells VRC Eye:

> The GPU is under VRAM pressure.

It does **not** necessarily tell VRC Eye:

> VRChat itself owns exactly 10.7 GB.

---

# 13. Per-Process VRAM

Treat this as an optional capability:

```
gpu.process_memory = available/unavailable
```

Never assume it works everywhere.

For example, NVIDIA's NVML exposes process GPU-memory fields, but its documentation notes that under Windows WDDM, `usedGpuMemory` can report `NVML_VALUE_NOT_AVAILABLE` because Windows manages the memory. [NVIDIA Docs](https://docs.nvidia.com/deploy/pdf/NVML_API_Reference_Guide.pdf?utm_source=chatgpt.com)

So the UI should gracefully switch between:

```
VRChat VRAM        6.8 GB
```

when genuinely available,

and:

```
Total GPU VRAM    10.8 / 12 GB
```

when process attribution isn't trustworthy.

---

# 14. Never Fabricate VRChat VRAM

Bad:

```
VRChat VRAM
9.3 GB
```

when that's actually total system GPU usage.

Good:

```
GPU VRAM
9.3 / 12 GB
```

Advanced:

```
Per-process VRAM attribution unavailable
on current telemetry backend.
```

---

# 15. GPU Load

Track separately:

```
3D / GPU utilization
```

but don't treat:

```
GPU = 99%
```

as inherently bad.

For a game, 95–100% GPU utilization may simply mean:

> The GPU is doing its job.

Therefore:

```
GPU load alone
```

should almost never trigger emergency protection.

---

# 16. GPU Pressure Is More Interesting

A more meaningful rule might be:

```
GPU utilization     100%
VRAM                98%
frame degradation   severe
duration            25 sec
```

Then:

```
High GPU pressure
```

becomes reasonable.

---

# 17. CPU Metrics

Track:

```
System CPU %
VRChat CPU %
Logical core count
Process CPU time
```

Optionally later:

```
per-core usage
```

---

# 18. CPU 100% Is Also Not Automatically Dangerous

Just like GPU usage:

```
CPU spike = not emergency
```

World/avatar loading may temporarily cause large CPU spikes.

You should distinguish:

```
spike
```

from:

```
sustained saturation
```

---

# 19. CPU Saturation Warning

Potential rule:

```
system CPU > 95%
AND
VRChat responsiveness degraded
AND
duration > 30 sec
```

Result:

```
⚠ Sustained CPU saturation
```

Not:

```
Emergency shutdown.
```

CPU exhaustion generally deserves lower severity than memory exhaustion.

---

# 20. Temperature Monitoring

Optional backend capability:

```
cpu_temperature
gpu_temperature
```

Do not hardcode one universal temperature as dangerous for every device.

Instead support:

```
manufacturer/backend-reported limits
```

when reliable,

or:

```
user-configured thresholds
```

otherwise.

---

# 21. Thermal States

Potential states:

```
UNKNOWN
NORMAL
ELEVATED
HIGH
CRITICAL
```

Example:

```
GPU Temperature
78°C
Normal for configured limit
```

or:

```
GPU temperature approaching
configured critical threshold.
```

---

# 22. Thermal Trend

Even more useful:

```
GPU 68°C
→ 72°C
→ 78°C
→ 84°C
```

over five minutes.

VRC Eye could identify:

```
rapid thermal rise
```

before the absolute threshold is crossed.

---

# 23. Disk Space

Track at least:

```
system drive
VRChat installation drive
VRChat cache drive
screenshot drive
VRC Eye data drive
```

They may not be the same drive.

---

# 24. Disk Warning Levels

Example:

```
Healthy       >15% free
Elevated      lower
Warning       user configurable
Critical      very low free space
```

I wouldn't hardcode those exact percentages globally; make them policy defaults that can evolve.

Also use absolute free bytes:

```
5%
```

on a 4 TB drive is still \~200 GB.

---

# 25. Disk Write Protection

If VRC Eye's own data drive gets critically low:

stop optional writes first:

```
thumbnail cache
extended telemetry
debug logs
old exports
```

but preserve:

```
critical safety logs
shutdown marker
Black Box essentials
```

---

# 26. Resource Sample

Create one normalized immutable sample.

Conceptually:

```
ResourceSample:    timestamp    system_ram_total    system_ram_used    system_ram_available    system_commit_used    system_commit_limit    vrchat_working_set    vrchat_private_memory    cpu_system_percent    cpu_vrchat_percent    gpu_percent    gpu_vram_total    gpu_vram_used    gpu_vrchat_memory    gpu_temp    cpu_temp    disk_free    disk_read_rate    disk_write_rate    vrchat_responsive
```

---

# 27. Include Metadata

Each metric should know:

```
valid
source
precision
timestamp
```

Example:

```
gpu_vrchat_memory = Metric(    value=None,    available=False,    source="NVML/WDDM",)
```

That is better than:

```
gpu_vrchat_memory = 0
```

because `0` and `unknown` are completely different.

---

# 28. Capability Registry

At startup:

```
RESOURCE CAPABILITIES

System RAM                 ✓
VRChat RAM                 ✓
System CPU                 ✓
VRChat CPU                 ✓
GPU load                   ✓
GPU total VRAM             ✓
VRChat-specific VRAM       —
GPU temperature            ✓
CPU temperature            ✓
Hard RAM containment       ✓
Soft RAM containment       ✓
```

Features depend on capabilities.

Not OS names.

---

# 29. Platform Interface

Something approximately like:

```
class ResourceBackend:    def sample_memory(self):        ...    def sample_cpu(self):        ...    def sample_gpu(self):        ...    def sample_thermal(self):        ...    def sample_disk(self):        ...    def supports(self, capability):        ...
```

Then:

```
WindowsResourceBackend
LinuxResourceBackend
```

---

# 30. Sampling Frequency

Do not poll everything at the same frequency.

Something like:

```
RAM                   1 Hz
CPU                   1 Hz
GPU                   1–2 Hz
VRAM                  1 Hz
Temperature           0.5–1 Hz
Disk                  1 Hz
Process responsiveness 0.5 Hz
```

The UI does not need 120 samples per second.

---

# 31. Adaptive Sampling

When healthy:

```
1 sample/sec
```

When approaching danger:

```
2–4 samples/sec
```

Black Box emergency window:

```
potentially higher
```

This reduces overhead during normal operation.

---

# 32. VRC Eye Must Monitor Its Own Overhead

The resource monitor itself should record:

```
VRC Eye CPU
VRC Eye RAM
sampling latency
missed samples
```

If VRC Eye's monitoring consumes significant CPU:

```
resource monitor degraded
```

and reduce sampling.

---

# 33. Never Block the UI Thread

Bad:

```
UI timer
→ query GPU
→ query sensors
→ wait
→ redraw
```

Good:

```
Resource worker
→ collect
→ normalize
→ publish snapshot
→ UI displays latest snapshot
```

---

# 34. Sampling Deadline

Each collection cycle should have an expected time budget.

For example:

```
expected cycle       1000 ms
collection budget     200 ms
```

If GPU backend hangs:

```
timeout
mark GPU unavailable
continue everything else
```

Don't let one sensor freeze Resource Guard.

---

# 35. Sensor Failure Isolation

Example:

```
NVML crashes
```

Result:

```
GPU telemetry disabled
RAM guard continues
CPU guard continues
Black Box continues
```

Never:

```
GPU error
→ entire ResourceMonitor crashes
```

---

# 36. Rolling History

Maintain several levels:

```
High resolution
last 60 sec

Medium resolution
last 15 min

Low resolution
entire session
```

Possible resolution:

```
1 sec
5 sec
30 sec
```

This prevents massive memory usage.

---

# 37. Downsampling

Don't retain:

```
1 Hz × 8 hours × 20 metrics
```

if you don't need it.

After a period:

```
five samples
→ min
→ max
→ average
```

store aggregate bucket.

---

# 38. Preserve Peaks

When downsampling, never only average.

Bad:

```
VRAM:
90 90 99 90 90
average = 91.8
```

You just erased the critical 99% event.

Store:

```
min
max
mean
```

for each bucket.

---

# 39. History Model

Example:

```
ResourceBucket:    start    end    ram_min    ram_max    ram_avg    vram_min    vram_max    vram_avg
```

Same for other metrics.

---

# 40. Basic Resource States

Each metric gets:

```
UNKNOWN
HEALTHY
ELEVATED
WARNING
CRITICAL
EMERGENCY
RECOVERING
```

Do not immediately jump from:

```
HEALTHY
```

to:

```
EMERGENCY
```

because of one sample.

---

# 41. System-Level Protection State

Aggregate:

```
RESOURCE HEALTH

HEALTHY
ELEVATED
WARNING
CRITICAL
EMERGENCY
```

But don't calculate an opaque score like:

```
74/100 health
```

Rule-based state is easier to understand.

---

# 42. Example Aggregate

```
RAM          WARNING
VRAM         CRITICAL
CPU          HEALTHY
GPU          ELEVATED
Thermal      HEALTHY

Overall      CRITICAL
```

Reason:

```
VRAM is currently the highest-severity condition.
```

---

# 43. Duration Thresholds

This is essential.

Bad:

```
VRAM > 95%
→ CRITICAL
```

Good:

```
VRAM > 95%
for 10 continuous seconds
→ CRITICAL
```

Transient spikes shouldn't immediately alarm the user.

---

# 44. Grace Periods

Some contexts deserve longer grace periods.

Example:

```
world just changed
avatar loading storm
```

Resource spikes expected.

Protection engine can know:

```
context = HEAVY_LOADING
```

and apply:

```
warning threshold unchanged
action threshold duration longer
```

---

# 45. Hysteresis

Without hysteresis:

```
94.9% → Warning
95.1% → Critical
94.9% → Warning
95.1% → Critical
```

UI flickers endlessly.

Instead:

```
Enter Critical: >95%
Exit Critical:  <91%
```

That gap is hysteresis.

Use it everywhere.

---

# 46. Warning Cooldown

Suppose RAM remains high for 20 minutes.

Don't notify:

```
8:00 Warning
8:01 Warning
8:02 Warning
...
```

Instead:

```
initial warning
```

then perhaps:

```
reminder after meaningful interval
```

or only if severity changes.

---

# 47. Escalation Resets

If condition improves:

```
CRITICAL
↓
RECOVERING
↓
HEALTHY
```

Don't immediately clear after one good sample.

Require:

```
healthy for N seconds
```

before reset.

---

# 48. Trend Detection

Absolute thresholds alone aren't enough.

Example:

```
VRChat RAM:

8.0 GB
8.8 GB
9.6 GB
10.4 GB
11.2 GB
```

Even if warning threshold is:

```
14 GB
```

the growth rate is concerning.

Compute:

```
MB/min
GB/min
```

---

# 49. Memory Growth Rate

Something like:

```
RAM growth
+1.8 GB / 10 min
```

could trigger:

```
Rapid memory growth observed.
```

Not:

```
Memory leak detected.
```

You don't know whether it's actually a leak.

---

# 50. Long-Term Growth Detection

Potential algorithm:

```
short slope     30 sec
medium slope     5 min
long slope      30 min
```

If:

```
short high
medium high
long high
```

then confidence rises.

---

# 51. Spike Detection

Separate from trend.

Example:

```
VRAM:
6 GB → 10.5 GB
within 4 sec
```

Event:

```
VRAM_SPIKE
```

Store:

```
before
after
delta
duration
```

---

# 52. Resource Event Object

Conceptually:

```
ResourceEvent:    type    metric    start_time    detected_time    start_value    peak_value    current_value    severity    confidence    related_context
```

---

# 53. Context Correlation

Connect Resource Monitor to Event Bus.

Events:

```
world.entered
player.joined
avatar.changed
avatar.loading
media.started
vrchat.window_unresponsive
```

Then:

```
VRAM spike
4 sec after avatar load
```

becomes meaningful.

---

# 54. Never Treat Correlation as Proof

Store:

```
correlated_event
```

not:

```
cause
```

UI:

```
VRAM increased shortly after avatar loading.
```

Not:

```
Alice caused a VRAM attack.
```

---

# 55. Protection Rules

Do not hardcode thresholds deep inside collectors.

Create rule objects:

```
ProtectionRule:    metric    comparator    threshold    duration    recovery_threshold    recovery_duration    severity    actions
```

Example:

```
Metric:
SystemAvailableRAM

Condition:
< 1.5 GB

Duration:
15 seconds

Severity:
Critical
```

---

# 56. Composite Rules

Support:

```
AND
OR
```

Example:

```
VRAM > 97%
AND
available RAM < 1 GB
AND
VRChat unresponsive
```

could be Emergency.

---

# 57. Rule Groups

Categories:

```
Memory
GPU
CPU
Thermal
Disk
Responsiveness
```

---

# 58. Default vs User Rules

Default rules:

```
VRC Eye recommended
```

User rules:

```
Custom
```

Never overwrite custom settings silently during updates.

If default improves:

```
New recommended protection settings available.
```

Let user accept.

---

# 59. Protection Profiles

I'd eventually have:

```
Monitor Only
Balanced
Protective
Maximum
Custom
```

### Monitor Only

No automatic actions.

### Balanced

Warnings and suggestions.

### Protective

Warnings + automatic low-risk responses.

### Maximum

May invoke Safe Mode / controlled close under severe conditions.

### Custom

Full configuration.

---

# 60. Casual Mode

Simple:

```
RESOURCE GUARD
──────────────
Protection      Balanced

RAM             Protected
VRAM            Protected
Temperature     Protected
Disk            Protected

[ Advanced ]
```

---

# 61. Advanced Mode

Expose:

```
Warning thresholds
Critical thresholds
Duration
Recovery
Cooldown
Trend sensitivity
Actions
```

---

# 62. Developer Mode

Expose:

```
raw samples
backend source
collection latency
rule evaluations
hysteresis state
event queue
action trace
```

Example:

```
Rule RAM-04
Condition false → true
Started 22:14:17
Duration 8.4 / 15 sec
```

This will be invaluable.

---

# 63. Protection Actions Need Their Own Risk Classes

I would classify actions:

```
Level 0 — Informational
Level 1 — VRC Eye-only action
Level 2 — Supported VRChat action
Level 3 — OS process modification
Level 4 — Process termination
```

---

# 64. Level 0 Actions

Examples:

```
log event
record Black Box marker
show dashboard warning
```

Always safe.

---

# 65. Level 1 Actions

Examples:

```
pause photo indexing
reduce VRC Eye sampling
disable novelty animation
pause background synchronization
enter VRC Eye Low Power Mode
```

Very low risk.

---

# 66. Level 2 Actions

Supported external interactions:

```
activate VRChat Safe Mode through OSC
reduce VRChat OS audio
```

Still require user configuration for automatic use.

---

# 67. Level 3 Actions

Operating-system modifications:

```
memory limits
CPU rate limits
priority changes
```

Advanced/Dangerous territory.

---

# 68. Level 4 Actions

```
Close VRChat
Force terminate VRChat
```

Should be the final protection stage.

---

# 69. Action Escalation Example

```
RAM elevated
↓
Dashboard yellow

RAM warning
↓
Overlay warning

RAM critical
↓
Safe Mode suggestion

RAM critical sustained
↓
Controlled-exit countdown

VRChat unresponsive
↓
Offer force termination
```

---

# 70. Warning UI

Example:

```
⚠ RESOURCE GUARD

System memory is running low.

Available RAM        1.2 GB
VRChat RAM          13.8 GB
VRAM                 92%

Condition active for 18 sec.

[ Open Monitor ]
[ Ignore 10 min ]
```

---

# 71. Critical UI

```
⚠ CRITICAL MEMORY PRESSURE

Available system memory is critically low.

VRC Eye recommends closing VRChat
before system stability deteriorates.

[ Close VRChat ]
[ Safe Mode ]
[ Cancel Protection ]
```

---

# 72. Auto-Close Countdown

If explicitly enabled:

```
EMERGENCY RESOURCE GUARD

VRChat will close in 15 seconds
if memory pressure remains critical.

[ Cancel ]
[ Close Now ]
```

If condition recovers during countdown:

```
Pressure recovered.
Automatic shutdown cancelled.
```

Very important.

---

# 73. Countdown Must Recheck Conditions

Never:

```
critical at T0
→ start 15 sec
→ close no matter what
```

Instead:

```
critical at T0
→ countdown
→ evaluate continuously
→ recover
→ abort action
```

---

# 74. Graceful Shutdown First

First attempt should always be:

```
normal close request
```

Then wait.

If VRChat exits:

```
success
```

Only force terminate if:

```
explicitly enabled
AND
timeout expired
AND
process remains
```

---

# 75. Force Terminate Warning

The option should carry something like:

```
☣ Force termination may prevent normal cleanup
and may result in loss of unsaved application state.
```

Default:

```
OFF
```

---

# 76. Emergency Resource Guard State Machine

Something like:

```
DISARMED
ARMED
WARNING
CRITICAL
COUNTDOWN
ACTION_PENDING
ACTION_RUNNING
RECOVERED
COOLDOWN
```

---

# 77. User Cancellation

If user hits:

```
Cancel Auto-Close
```

state becomes:

```
SUPPRESSED
```

for perhaps:

```
10 minutes
```

rather than restarting countdown one second later.

---

# 78. But Extreme Conditions Can Re-Warn

Suppose user suppresses warning at:

```
95%
```

then RAM gets much worse.

You can allow:

```
severity escalation
```

to override suppression.

Example:

```
WARNING suppressed
EMERGENCY still allowed to notify
```

---

# 79. Resource Guard Should Protect VRC Eye Too

Before killing VRChat, first make VRC Eye lighter:

```
pause thumbnails
pause image decoding
pause indexing
reduce graph frequency
pause nonessential API refresh
disable animations
```

Call it:

```
VRC Eye Emergency Low-Power Mode
```

---

# 80. Background Application Identification

VRC Eye could identify large resource users:

```
VRChat            12.4 GB
Chrome             4.1 GB
OBS                2.7 GB
Discord            1.2 GB
```

Then:

```
[ Make Room for VR ]
```

---

# 81. Make Room for VR

Do **not** automatically kill random applications.

Instead:

```
Applications using significant memory:

Chrome      4.1 GB
OBS         2.7 GB
Blender     3.0 GB

Select applications you want to close.
```

User chooses.

---

# 82. Protected Processes

Never suggest closing:

```
Windows shell
system services
security software
SteamVR critical components
VRC Eye safety helper
```

Maintain allow/deny classification carefully.

When uncertain:

```
do not recommend.
```

---

# 83. Windows Memory Containment

For a true hard cap, Windows Job Objects can enforce per-process or job-wide committed-memory limits; attempts to commit beyond the configured limit fail. Windows also supports notification limits that can notify without immediately enforcing a hard stop. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_limit_information?utm_source=chatgpt.com)

That's powerful—but dangerous.

---

# 84. Windows Notification-Only Mode

This is much more interesting for VRC Eye than immediately applying a hard cap.

Conceptually:

```
VRChat approaches configured memory limit
↓
Windows notifies VRC Eye
↓
VRC Eye warns user
```

without rejecting the allocation.

Microsoft specifically documents notification limits as a way to observe a limit while still allowing the process to continue committing memory. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information?utm_source=chatgpt.com)

That sounds perfect for:

```
Resource Guard Advanced
```

---

# 85. Windows Hard Memory Limit

Conceptually:

```
JOB_OBJECT_LIMIT_PROCESS_MEMORY
```

can restrict committed memory.

But when VRChat requests memory beyond that:

```
allocation fails
```

rather than Windows magically optimizing VRChat. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_limit_information?utm_source=chatgpt.com)

Therefore UI:

```
☣ HARD MEMORY LIMIT

May cause:
• failed allocations
• failed avatar/world loads
• instability
• crashes
```

---

# 86. Windows Job Assignment Complications

Don't assume you can always attach VRChat to a Job Object without testing.

Windows supports nested jobs on modern systems, but job membership and process-launch circumstances matter. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject?utm_source=chatgpt.com)

So capability detection should say:

```
Hard memory enforcement
Supported / Unavailable / Could not attach
```

not simply:

```
Windows = yes
```

---

# 87. Prefer Monitor Before Enforce on Windows

Recommended:

```
Monitor
↓
Notification limit
↓
User warning
↓
Resource Guard
```

Advanced:

```
Hard Job limit
```

Only after extensive testing.

---

# 88. Linux cgroup v2

Linux gives you a particularly nice model.

`memory.high` is a throttling/reclaim boundary rather than an immediate hard ceiling; crossing it puts the cgroup under heavy reclaim pressure, while the kernel documentation specifically notes that it does not directly invoke the OOM killer. [Kernel.org](https://www.kernel.org/doc/html/latest/admin-guide/cgroup-v2.html?highlight=freezer\&utm_source=chatgpt.com)

That's very close to the idea of:

```
Soft Memory Protection
```

---

# 89. Linux memory.high

UI:

```
Soft Limit
16 GB
```

Conceptually:

```
VRChat exceeds 16 GB
↓
memory pressure/reclaim
↓
VRC Eye monitors condition
```

Potential result:

```
performance may degrade
```

but it isn't necessarily immediately killed.

---

# 90. Linux memory.max

`memory.max` is the hard cgroup memory ceiling. If the cgroup cannot stay under that hard limit, the kernel may invoke OOM handling for the cgroup. [Kernel.org](https://www.kernel.org/doc/html/latest/admin-guide/cgroup-v2.html?highlight=freezer\&utm_source=chatgpt.com)

So:

```
☣ Hard Limit
```

rather than normal protection.

---

# 91. Linux Flatpak Complication

Because you want VRC Eye packaged as a Flatpak, don't assume the packaged application will always have permission to create/control arbitrary host cgroups.

So:

```
LinuxMemoryLimiterBackend
```

must probe capability.

Potential result:

```
Monitoring       Supported
Soft limit       Unavailable in sandbox
Hard limit       Unavailable
```

VRC Eye should still function.

---

# 92. CPU Rate Control

Windows Job Objects can also enforce CPU rate controls, including hard caps and min/max policies. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_cpu_rate_control_information?utm_source=chatgpt.com)

I would **not** use that as normal VRChat protection.

It would mostly be:

```
Advanced / Experimental
```

because starving VRChat's CPU can worsen frame performance and tracking responsiveness.

---

# 93. CPU Limiting Use Cases

Potentially useful only when someone explicitly wants:

```
VRChat may use at most 80% CPU
```

but I'd warn:

```
This may significantly reduce VRChat performance.
```

Not recommend it by default.

---

# 94. Process Priority

Windows allows changing process priority classes, but Microsoft cautions that High Priority can consume CPU at the expense of other processes, and Realtime is especially hazardous to system responsiveness. [Microsoft Learn](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setpriorityclass?utm_source=chatgpt.com)

Therefore VRC Eye should **never casually offer Realtime**.

---

# 95. Priority Presets

If you expose this at all:

```
Below Normal
Normal
Above Normal
```

Maybe:

```
High
```

under Dangerous/Advanced with warning.

Do not provide:

```
Realtime
```

as a casual toggle.

---

# 96. Better Idea: Lower VRC Eye Background Work

Rather than:

```
make VRChat High Priority
```

prefer:

```
VRC Eye enters Background/Low Power mode
```

That produces fewer scheduling surprises.

---

# 97. Performance Protection Isn't “FPS Booster”

Avoid marketing like:

```
BOOST FPS 300%
```

VRC Eye should say:

```
Reduce VRC Eye overhead
Detect resource contention
Protect system stability
```

Much more defensible.

---

# 98. Responsiveness Monitor

Resource protection should know whether VRChat's window/process is responsive.

States:

```
RESPONSIVE
SLOW
UNRESPONSIVE
UNKNOWN
```

---

# 99. Freeze Detection

Don't label:

```
1 missed response
```

as frozen.

Example logic:

```
window unresponsive
+
no meaningful process progress
+
log stalled
+
duration
```

raises confidence.

---

# 100. Possible Freeze

UI:

```
VRChat may be unresponsive.

CPU              0.3%
RAM              11.8 GB
Log activity     None for 38 sec

[ Keep Waiting ]
[ Save Snapshot ]
[ Close VRChat ]
```

---

# 101. Loading vs Frozen

This is where context matters.

If logs show:

```
world loading
avatar loading
asset activity
```

then high memory + temporary UI unresponsiveness may be expected.

Classification:

```
BUSY_LOADING
```

instead of:

```
FROZEN
```

---

# 102. Protection Context State

Maintain:

```
IDLE
WORLD_LOADING
AVATAR_LOADING
HIGH_POPULATION_JOIN
NORMAL_PLAY
SHUTTING_DOWN
CRASH_RECOVERY
```

Rules can behave differently by context.

---

# 103. World-Load Grace Window

Example:

```
world.entered
↓
heavy_load_context for 30 sec
```

During that:

```
display resource warnings
```

but maybe avoid aggressive automatic shutdown unless true system emergency occurs.

---

# 104. Avatar Storm Context

If:

```
15 avatars begin loading
```

set:

```
AVATAR_STORM
```

Safety Center can say:

```
High resource usage coincides with many
avatars loading.
```

Much better diagnostic context.

---

# 105. Per-Player Resource Correlation

Player List can consume resource events.

Example:

```
Alice avatar changed
T = 0

VRAM:
7.2 → 8.9 GB

RAM:
10.1 → 11.3 GB
```

If no other major loading event:

```
Observed impact: High
Confidence: Medium
```

---

# 106. Do Not Double Count

If:

```
five avatars loaded
```

a +3 GB VRAM spike shouldn't be attributed independently as:

```
Alice +3 GB
Bob +3 GB
Charlie +3 GB
...
```

Resource Correlator must know overlapping candidates.

---

# 107. Correlation Candidate Set

At time of spike:

```
candidates = [    avatar_load_A,    avatar_load_B,    world_asset_load,    media_start]
```

If multiple:

```
attribution = UNKNOWN
```

---

# 108. Resource Guard + Bridge Mode

Bridge can greatly improve context.

Instead of:

```
avatar event inferred from logs
```

you might receive:

```
avatar Alice initialization started
avatar Alice initialization completed
```

Then your correlation window is tighter.

Still:

```
correlation ≠ causation
```

---

# 109. Performance Baseline

After enough healthy sessions:

```
Typical VRChat RAM after 30 min
9–11 GB
```

Current:

```
15.8 GB
```

VRC Eye can say:

```
This session is using substantially more
memory than your recent typical sessions.
```

---

# 110. Baselines Must Be Hardware-Specific

If GPU changes:

```
RTX A → RTX B
```

old VRAM baseline isn't necessarily comparable.

Same for:

```
RAM upgrade
VRChat major update
driver change
```

So baseline key might include:

```
hardware fingerprint category
VRChat build
VRC Eye monitor schema version
```

Not a privacy-heavy hardware fingerprint; just internal configuration identity.

---

# 111. Baseline Warm-Up

Don't make conclusions after:

```
one session
```

State:

```
Learning baseline...
```

until enough samples exist.

---

# 112. Performance Regression Detection

Compare:

```
before VRChat update
after VRChat update
```

Potential report:

```
Since the latest observed VRChat build change:

Median RAM at 30m:
+1.7 GB

Median VRAM:
+900 MB

Average world-load duration:
+18%
```

Phrase as:

```
local regression observed
```

not:

```
VRChat update is broken.
```

---

# 113. Hardware Change Detection

If VRC Eye observes:

```
GPU changed
RAM amount changed
driver changed
```

reset/re-segment performance baselines.

---

# 114. Driver Correlation

Could report:

```
GPU driver changed before the first session
showing this performance regression.
```

Again:

```
correlation
```

not blame.

---

# 115. Resource Guard Timeline

Store significant events:

```
22:14 RAM warning
22:16 avatar storm
22:17 VRAM critical
22:18 Safe Mode offered
22:19 condition recovered
```

This belongs in Session Timeline.

---

# 116. Black Box Integration

Every sample doesn't necessarily need to be persisted individually forever.

Black Box receives compact telemetry:

```
RAM
VRAM
CPU
GPU
temps
responsiveness
disk
protection state
```

plus significant events.

---

# 117. Black Box Priority

When system becomes critical:

increase recording density.

Example:

```
Normal:
5 sec persisted

Warning:
1 sec

Emergency:
250–500 ms if practical
```

Keep overhead low.

---

# 118. Crash-Safe Writing

Black Box should use:

```
append
small records
periodic flush
checksums
```

Avoid rewriting one giant JSON file every second.

---

# 119. Two-File Journal

Potential strategy:

```
blackbox_A
blackbox_B
```

rotate between them.

Or:

```
append-only ring chunks
```

A crash corrupting final record doesn't destroy previous history.

---

# 120. Startup Recovery

At startup:

```
previous session has START
but no CLEAN_SHUTDOWN
```

Therefore:

```
Previous session ended unexpectedly.
```

Then analyze last samples.

---

# 121. Crash Analyzer

Example:

```
LAST 30 SECONDS

RAM available
2.4 GB → 340 MB

VRAM
88% → 99%

CPU
61% → 64%

GPU
97% → 99%

Temperature
Normal

VRChat responsiveness
Responsive → Unknown

Result:
Severe memory pressure preceded the shutdown.
```

Do not say:

```
Memory caused crash.
```

unless truly established.

---

# 122. Windows Crash Correlation

On Windows, you can supplement VRC Eye telemetry with OS crash/restart evidence afterward.

The point isn't to diagnose every BSOD.

It is to say:

```
VRC Eye recording stopped unexpectedly.
Windows also recorded an abnormal system shutdown.
```

Then show what VRC Eye observed before it disappeared.

---

# 123. Session Replay

Graph:

```
VRAM
100 |                █████
 90 |          ██████
 80 |     █████
 70 |█████
    +----------------------
     22:10       22:20
```

Below:

```
22:14 World joined
22:15 18 players loaded
22:16 VRAM Warning
22:18 VRAM Critical
22:19 VRChat unresponsive
```

---

# 124. Graph Design

Avoid constantly redrawing giant plots.

Keep:

```
fixed sample buffer
incremental UI update
```

Charts:

```
RAM
VRAM
CPU
GPU
Temperature
```

Separate charts rather than one unreadable spaghetti plot.

---

# 125. Graph Time Ranges

```
1 minute
5 minutes
15 minutes
1 hour
Session
```

---

# 126. Graph Event Markers

Vertical marker:

```
Avatar storm
World change
Safe Mode
Crash
```

Click marker for details.

---

# 127. Current Resource Dashboard

Casual:

```
SYSTEM HEALTH
────────────────────
RAM        78%      Healthy
VRAM       84%      Elevated
CPU        56%      Healthy
GPU        98%      Busy
Temp       Normal
```

Notice:

```
GPU 98% = Busy
```

not necessarily:

```
Danger!
```

---

# 128. Advanced Dashboard

```
SYSTEM MEMORY
Used                 25.0 GB
Available             7.0 GB
Commit               29 / 48 GB

VRCHAT
Working Set          10.4 GB
Private              12.1 GB
Growth               +420 MB / 10m

GPU
Utilization              98%
VRAM                  9.6 / 12 GB
Process VRAM         Unavailable

THERMAL
GPU                       74°C
CPU                       69°C
```

---

# 129. Status Language

Prefer:

```
Healthy
Elevated
Warning
Critical
```

over:

```
Good
Bad
Terrible
```

Precise, neutral.

---

# 130. Color

Could use:

```
green
yellow
orange
red
```

but every state must also have:

```
icon
text
```

for accessibility.

---

# 131. Notification Severity

Separate:

```
Informational
Warning
Critical
Emergency
```

Example:

```
GPU at 100%
```

could still be informational/elevated.

```
Available RAM 300 MB
```

might be Critical/Emergency.

---

# 132. User Acknowledgment

Warning event:

```
[ Dismiss ]
[ Snooze ]
[ Open Monitor ]
```

Critical:

```
[ Safe Mode ]
[ Close VRChat ]
[ Cancel ]
```

---

# 133. Suppression Rules

Users may choose:

```
Don't warn about GPU utilization
```

but you should distinguish:

```
disabled metric
```

from:

```
dismissed current event
```

---

# 134. Emergency Overrides

If user disables ordinary RAM warnings, you could still optionally allow:

```
System Emergency Warning
```

unless they explicitly disable that too.

But never silently override their preference.

---

# 135. Rule Test Button

Every automatic rule should have:

```
[ Test ]
```

Example:

```
Test RAM Warning
```

shows notification without actually consuming RAM.

---

# 136. Auto-Close Test Mode

Crucial:

```
TEST AUTO-CLOSE

Simulate:
VRAM critical

Expected:
15-sec countdown

VRChat will NOT actually close.
```

User can verify configuration safely.

---

# 137. Resource Simulation Engine

Developer Mode:

```
Set RAM       97%
Set VRAM      99%
Set CPU       100%
Set GPU       100%
Set Temp      Critical
Set Responsive False
```

Then observe rule engine.

---

# 138. Recorded Replay Tests

Feed actual telemetry file:

```
session_crash_001
```

into Protection Engine without VRChat running.

Verify:

```
same warnings
same transitions
same actions in simulation
```

---

# 139. Rule Unit Tests

Examples:

```
one VRAM spike does not trigger Critical
```

```
15 continuous high samples trigger Warning
```

```
condition recovers during countdown → no shutdown
```

```
bridge disconnect does not stop RAM protection
```

```
GPU telemetry failure does not disable CPU monitoring
```

---

# 140. Hysteresis Tests

Example:

```
95.2
94.8
95.1
94.9
```

should not produce:

```
CRITICAL WARNING CRITICAL WARNING
```

---

# 141. Restart Tests

Test:

```
VRChat PID changes
```

ResourceMonitor must:

```
detach old
reset process metrics
attach new
```

System metrics continue uninterrupted.

---

# 142. Process Identity

Never identify VRChat only by:

```
process name
```

Combine:

```
executable path
PID
creation time
```

so a PID reuse cannot trick the monitor.

---

# 143. Process Restart

State:

```
VRCHAT_NOT_RUNNING
↓
VRCHAT_STARTING
↓
MONITORING
↓
VRCHAT_EXITED
```

If process returns:

```
new session process context
```

---

# 144. Don't Carry Old Metrics Into New Process

When PID changes:

```
VRChat RAM 14GB
```

must not briefly remain displayed for new process.

Set:

```
Collecting...
```

until fresh sample.

---

# 145. Multiple VRChat Processes

If launcher/helper processes exist:

track:

```
primary game process
```

separately from ancillary processes.

If useful:

```
VRChat process tree total
```

can be another metric.

---

# 146. Resource Grouping

Potential:

```
VRChat Core
SteamVR
VRC Eye
OBS
Discord
Browser
```

so a streamer can see:

```
VR stack total
```

---

# 147. Resource Budget View

User could say:

```
Reserve at least 3 GB system RAM
```

rather than:

```
VRChat max 13 GB
```

This is arguably more useful.

Rule:

```
available RAM < reserve
→ warning
```

regardless of which process consumed it.

---

# 148. Reserve-Based Protection

Example:

```
System reserve
2 GB minimum

Available:
1.4 GB

Warning
```

This adapts better than hardcoding VRChat limits.

---

# 149. VRAM Reserve

Similarly:

```
Maintain 1 GB VRAM headroom
```

when the backend provides reliable budget numbers.

Warning:

```
VRAM headroom below target.
```

---

# 150. Adaptive Thresholds

Optional later:

```
32 GB RAM machine
```

gets different defaults from:

```
8 GB RAM machine
```

But always show what was selected.

No hidden magic.

---

# 151. Suggested-Threshold Wizard

On first setup:

```
Detected:
32 GB RAM
12 GB VRAM

Recommended protection:
Balanced
```

Then:

```
[ Use Recommended ]
[ Customize ]
```

---

# 152. Do Not Overfit Hardware

Avoid claiming:

```
RTX 4080 should always use threshold X
```

Actual usage depends heavily on:

- worlds,
- avatars,
- resolution,
- VR runtime,
- background apps.

Use headroom-based rules more than fixed brand-specific rules.

---

# 153. System Pressure vs VRChat Pressure

Display both:

```
SYSTEM PRESSURE
Critical

VRCHAT RESOURCE USE
High
```

because maybe Chrome caused the system pressure.

---

# 154. Attribution

Example:

```
System RAM rose +6 GB.

Largest observed process changes:

Chrome     +4.2 GB
VRChat     +1.0 GB
OBS        +600 MB
```

Then VRC Eye shouldn't blame VRChat.

---

# 155. Process Attribution Frequency

You don't need to scan every process at 10 Hz.

Perhaps:

```
every 5–10 sec
```

or when system pressure rises.

---

# 156. Dynamic Deep Scan

Healthy:

```
monitor VRChat + system
```

Warning:

```
scan top resource-consuming processes
```

More efficient.

---

# 157. Self-Protecting Logging

If disk space critical:

```
stop verbose logs
preserve error log
preserve Black Box minimal state
```

Don't let diagnostic logging fill the final 500 MB of the drive.

---

# 158. Telemetry Retention

Suggested settings:

```
Current session only
7 days
30 days
Custom
```

Long-term high-resolution telemetry generally isn't necessary.

---

# 159. Privacy

Resource telemetry is mostly local machine information.

By default:

```
local only
```

Diagnostic export:

```
Include detailed hardware information?
[ ]
```

Default could redact:

```
serial numbers
machine names
precise paths
```

---

# 160. Hardware Identification

For diagnostics, model names may be useful:

```
GPU model
RAM size
CPU model
```

but don't collect unnecessary device identifiers.

---

# 161. Black Box Privacy

Store:

```
resource events
session event types
```

not automatically:

```
private messages
chatbox text
tokens
```

Resource protection doesn't need that data.

---

# 162. Safety Center Integration

Safety Center card:

```
RESOURCE GUARD
──────────────
Status           Protected
RAM              Healthy
VRAM             Elevated
Thermals         Healthy
Black Box        Recording

[ Open ]
```

---

# 163. Player List Integration

Player row:

```
Alice
⚠ High observed resource impact
```

Only when correlation warrants it.

Click:

```
Observed:
VRAM +620 MB
RAM +810 MB

Other simultaneous loads: 0
Confidence: Medium
```

---

# 164. World Safety Memory

At session close, aggregate:

```
Peak RAM
Peak VRAM
Critical events
crashes
```

Next visit:

```
Last visit:
Peak VRAM 96%
Resource warning occurred
```

Never:

```
Dangerous world
```

---

# 165. World Baseline

Eventually:

```
Typical resource usage in this world
```

could be stored locally.

Example:

```
Your previous 4 visits:
Peak VRAM 8.2–9.1 GB
```

Current:

```
11.8 GB
```

Useful diagnostic clue.

---

# 166. Session Summary

At end:

```
PERFORMANCE SUMMARY
────────────────────
Peak VRChat RAM       13.4 GB
Peak system RAM          91%
Peak VRAM                 96%
Peak CPU                  89%
Peak GPU                 100%

Warnings                    2
Critical events              0
Auto actions                 0
```

No score.

---

# 167. Resource Event Summary

```
8:42 PM
VRAM Warning

9:18 PM
System RAM Warning

9:19 PM
Condition recovered
```

---

# 168. Session Compare

Compare:

```
Tuesday
Thursday
```

Example:

```
Peak VRAM
Tuesday       9.3 GB
Thursday     11.1 GB

Peak RAM
Tuesday      12.8 GB
Thursday     14.0 GB
```

---

# 169. Automatic Performance Regression

After enough data:

```
Recent sessions consistently show
~20% higher VRAM usage than earlier baseline.
```

Then display possible context:

```
VRChat build changed
GPU driver changed
VRC Eye version changed
```

No causal claim.

---

# 170. Update Compatibility Mode

After a new VRChat version:

```
RESOURCE MONITOR
Core metrics supported

Advanced per-process GPU telemetry
Not yet verified
```

Better than silently trusting assumptions.

---

# 171. Low-Power VRC Eye Mode

When VRChat pressure rises:

```
pause:
thumbnail generation
photo indexing
community synchronization
novelty animation
background exports
```

keep:

```
Resource Guard
Safety
Black Box
Overlay
Emergency controls
```

---

# 172. Low-Power Trigger

Could be automatic:

```
System resources critical
→ VRC Eye Minimal Mode
```

with notification:

```
VRC Eye reduced its own background activity
to conserve resources.
```

---

# 173. Background CPU Budget

VRC Eye itself should have target:

```
idle CPU < small amount
monitoring overhead minimal
```

Don't promise exact percentages across hardware.

Measure and expose:

```
VRC Eye monitoring overhead
```

in Developer Mode.

---

# 174. Resource Monitor Health

```
RESOURCE MONITOR HEALTH

RAM collector       Healthy
CPU collector       Healthy
GPU collector       Healthy
Thermal collector   Partial
Disk collector      Healthy

Sample lag          28 ms
Dropped cycles      0
```

---

# 175. Collector Restart

If GPU collector fails:

```
attempt restart
```

with exponential backoff.

Don't restart constantly:

```
1s
2s
5s
30s
```

then:

```
Disabled for session
```

if persistent.

---

# 176. Backend Selection

Example:

```
GPU Backend

Automatic
```

VRC Eye tries supported providers.

Advanced Mode:

```
Selected backend:
Windows Graphics Performance
```

or:

```
NVML
```

or:

```
AMDGPU sysfs
```

depending system.

---

# 177. Don't Expose Backend Complexity to Casual Users

Casual:

```
GPU Monitor: Working
```

Advanced:

```
Backend: AMDGPU sysfs
Process VRAM: Unsupported
```

---

# 178. Rule Evaluation Trace

Developer Mode:

```
RULE: SYS_RAM_CRITICAL

Available RAM:
1.28 GB

Threshold:
1.50 GB

Duration:
12.8 / 15 sec

Current state:
PENDING
```

This is incredibly useful for diagnosing why an alert did/didn't trigger.

---

# 179. Action Trace

```
22:41:10 Rule became Critical
22:41:10 Notification shown
22:41:11 Safe Mode suggestion generated
22:41:15 User selected Ignore
22:41:15 Rule suppressed until 22:51
```

---

# 180. Automatic Action Audit

If VRC Eye changes something:

```
22:42:00
VRC Eye automatically entered Low-Power Mode.

Reason:
System RAM Critical.
```

Every automatic action should have an explanation.

---

# 181. User Action Audit

Also:

```
22:42:14
User cancelled auto-close.
```

Important for diagnosing later.

---

# 182. Rule Versioning

Settings schema:

```
resource_rules_version = 3
```

When changing default algorithms between VRC Eye releases, preserve legacy custom rules safely.

---

# 183. Migration

Example:

```
Old:
RAM warning = 90%

New:
Available memory rule
```

Do not silently reinterpret 90% as something completely different.

Migration should explicitly transform or preserve behavior.

---

# 184. Config Validation

Reject:

```
warning threshold = 98%
critical threshold = 80%
```

unless intentionally supported.

Likewise:

```
recovery threshold > trigger threshold
```

may be logically incorrect depending metric direction.

---

# 185. Dangerous Configuration Warning

Example:

```
You configured:

RAM Warning     99%
Auto-Close      99.5%
Delay           0 sec

This configuration provides almost no
reaction time.

[ Keep ]
[ Use Recommended ]
```

---

# 186. Hard-Limit Validation

Never allow:

```
Hard RAM limit
below current VRChat committed memory
```

without major warning.

Potentially refuse because it could cause immediate failures.

---

# 187. Hard-Limit Arming

I'd require:

```
Enable Hard Memory Limit
↓
read warning
↓
choose limit
↓
Test configuration
↓
Arm
```

Not one toggle.

---

# 188. Hard Limit Persistence

Consider defaulting hard limits to:

```
This session only
```

until user explicitly chooses:

```
Apply every session
```

Safer.

---

# 189. Linux Soft Limit Preference

On supported Linux systems, `memory.high` is conceptually preferable for a soft containment mode because it creates reclaim/throttling pressure instead of acting as the immediate hard ceiling that `memory.max` provides. [Kernel.org](https://www.kernel.org/doc/html/latest/admin-guide/cgroup-v2.html?highlight=freezer\&utm_source=chatgpt.com)

So:

```
Balanced:
memory.high
```

could eventually be reasonable.

---

# 190. Windows Soft Equivalent

Windows doesn't map perfectly to the same `memory.high` semantics.

So don't pretend:

```
Windows Soft Limit
```

and:

```
Linux Soft Limit
```

have identical kernel behavior.

Present them as:

```
VRC Eye Soft Protection
```

with different platform implementations.

---

# 191. Cross-Platform Semantic Contract

Define features by intent:

```
MONITOR
WARN
SOFT_PROTECT
HARD_LIMIT
```

Platform decides how those are implemented.

This is better than exposing:

```
Job Objects
cgroups
```

throughout the program.

---

# 192. Platform Capability Example

```
Windows

Monitor              ✓
Warn                 ✓
Soft Protect         ✓ via VRC Eye policy
Hard Limit           ✓ if Job attachment supported
```

Linux:

```
Monitor              ✓
Warn                 ✓
Soft Protect         ✓ if cgroup memory.high available
Hard Limit           ✓ if memory.max available
```

---

# 193. CPU Protection Semantics

Similarly:

```
Monitor CPU
Warn CPU
Limit CPU
```

But default:

```
Limit CPU = disabled
```

because limiting CPU is usually a performance tradeoff, not a stability improvement.

---

# 194. GPU Limiting

I would **not** try to implement arbitrary GPU-frequency/power limiting through VRC Eye.

That's better left to:

```
driver control panels
hardware tools
```

Resource Guard should monitor and warn.

---

# 195. Temperature Auto-Exit

Could be allowed as:

```
Advanced
```

but only when reliable sensor data exists.

Example:

```
GPU temperature above user-configured
critical threshold for 60 sec
→ offer shutdown
```

Automatic close:

```
OFF by default
```

---

# 196. Disk Auto-Protection

If disk nearly full:

VRC Eye can safely:

```
stop its own optional recording
```

but shouldn't automatically delete:

```
VRChat screenshots
VRChat cache
user files
```

without consent.

---

# 197. Cache Cleanup

Separate Dangerous tool:

```
VRChat Cache Cleanup
```

not part of automatic Resource Guard.

Resource Guard may suggest:

```
VRChat cache is consuming significant storage.
[ Review Cache ]
```

---

# 198. Resource Profile Per Play Mode

Desktop:

```
lower expected GPU/VRAM pressure
```

VR:

```
higher expected rendering pressure
```

Don't necessarily use identical defaults.

But again, hardware-specific calibration matters more than guessing.

---

# 199. Streamer Mode

When OBS/browser/etc. are expected:

Resource dashboard could show:

```
VRChat
SteamVR
OBS
Browser
VRC Eye
```

Separate resource consumers.

Warnings might say:

```
Overall system RAM pressure is high.

VRChat      10.2 GB
OBS          3.1 GB
Browser      4.5 GB
```

---

# 200. Creator Mode

World testing may intentionally create severe resource spikes.

Creator profile:

```
warning sensitivity normal
automatic actions disabled
detailed telemetry enabled
```

So VRC Eye observes without interrupting every stress test.

---

# 201. Photography Mode

May use high-resolution camera output.

Resource Guard could identify:

```
Photography profile active
```

and avoid interpreting expected camera-related spikes as anomalous too quickly.

---

# 202. User Profiles

Resource profiles:

```
Balanced
Low-memory PC
High-end PC
Streaming
World Testing
Custom
```

But these are convenience presets, not claims that one exact setup is optimal.

---

# 203. Dynamic Recommendations

Example:

```
Your system has repeatedly reached
critical RAM pressure before VRAM pressure.

Consider prioritizing RAM warnings.
```

This is okay.

Avoid:

```
You must upgrade RAM.
```

unless simply presenting factual insufficiency.

---

# 204. “Why Am I Getting This Warning?”

Every warning should answer:

```
Why?
```

Example:

```
Why this appeared:

Available RAM fell below 1.5 GB
and remained there for 18 seconds.

Current:
1.2 GB

Threshold:
1.5 GB
```

This is fantastic UX.

---

# 205. “What Happens Next?”

Auto-action warning:

```
If memory remains below the threshold for
another 15 seconds, VRC Eye will request
VRChat to close.

You can cancel at any time.
```

No mystery.

---

# 206. Recovery Explanation

```
Resource pressure recovered.

Available RAM:
1.2 → 3.8 GB

Automatic close cancelled.
```

Very reassuring.

---

# 207. Notification Consolidation

If:

```
RAM Warning
VRAM Warning
Thermal Warning
```

happen together:

do not produce three giant overlays.

Combine:

```
⚠ MULTIPLE RESOURCE WARNINGS

RAM       Critical
VRAM      Critical
GPU Temp  Elevated
```

---

# 208. Primary Cause Presentation

Not actual causal inference.

Say:

```
Most severe current condition:
Low available RAM
```

rather than:

```
Cause:
RAM
```

---

# 209. Alert Rate Limiter

Safety notifications need global throttling.

Critical alerts can bypass ordinary notification throttling, but related alerts should merge.

---

# 210. Resource Guard and Wellness

If Resource Guard closes VRChat:

Wellness can transition to:

```
Break Mode
```

but should not pop:

```
Hydration!
Eye rest!
Bathroom!
```

while the user is troubleshooting a crash.

Safety first.

---

# 211. Resource Guard and DND

DND suppresses ordinary notifications.

Resource Warning:

```
may be delayed depending severity
```

Critical/Emergency:

```
always shown
```

unless user explicitly configures otherwise.

---

# 212. Resource Guard and Overlay

VR overlay could show only:

```
RAM    82%
VRAM   90%
```

when opened.

If critical:

```
⚠ VRAM CRITICAL
```

appears temporarily.

Don't keep giant monitoring HUD in vision.

---

# 213. Wrist View

Something like:

```
SYSTEM

RAM    78%
VRAM   88%
GPU    99%
Temp   OK
```

tap:

```
Open Resource Guard
```

---

# 214. Desktop Tray

Tray tooltip:

```
VRC Eye
VRChat running
RAM 78% • VRAM 88%
```

Optional.

---

# 215. Resource Status Icon

Potential main-header status:

```
● Healthy
▲ Elevated
⚠ Warning
‼ Critical
```

Click opens dashboard.

---

# 216. No False Precision

If sensor updates every second:

don't show:

```
GPU 83.728193%
```

UI:

```
84%
```

Detailed logs can preserve raw value.

---

# 217. Units

Always normalize internally:

```
bytes
seconds
°C
percentage 0–1
```

Format only in UI.

Avoid mixing:

```
MB
MiB
GB
GiB
```

randomly.

Pick a display convention and be consistent.

---

# 218. Monotonic Time

Duration logic should use a monotonic clock.

Do not calculate:

```
threshold duration
```

using wall-clock time because:

```
system time changes
NTP correction
user changes clock
```

could break timers.

Use wall time only for human timestamps.

---

# 219. Sampling Timestamp Pair

Every sample should have:

```
monotonic timestamp
wall-clock timestamp
```

Monotonic:

```
duration calculations
```

Wall clock:

```
22:43:12
```

---

# 220. Suspend / Resume

PC sleep:

```
no samples for 20 min
```

shouldn't be interpreted as:

```
monitor failed
```

Detect system resume and:

```
reset short-term trend windows
```

---

# 221. Headset Sleep

Don't necessarily stop Resource Guard just because HMD sleeps.

VRChat may still be running.

But sampling could reduce:

```
1 Hz → 0.2 Hz
```

until headset wakes.

---

# 222. VRChat Closed

System resource monitoring could enter:

```
Idle Mode
```

maybe stop VRChat-specific sampling entirely.

---

# 223. Startup Sampling

Before VRChat starts:

capture:

```
system baseline
```

Then after launch:

```
VRChat resource delta
```

This is extremely useful.

---

# 224. Baseline Snapshot

Example:

```
Before VRChat

RAM used        8.2 GB
VRAM            1.1 GB
CPU               4%
GPU               1%
```

After:

```
VRChat Home

RAM            13.4 GB
VRAM            5.9 GB
```

---

# 225. Startup Diagnostics

Track:

```
Process started
Unity initialized
Home loaded
Resource stabilization
```

Then:

```
Peak startup RAM
Peak startup VRAM
```

---

# 226. Memory Leak Heuristic

You can offer:

```
Possible sustained memory growth
```

but not:

```
Memory leak confirmed
```

Criteria:

```
positive long-term slope
no corresponding loading events
minimal recovery after world changes
```

Still heuristic.

---

# 227. Leak Watch

Advanced feature:

```
Memory Growth Watch

30 min trend:
+3.4 GB

World transitions:
3

Memory recovered after transitions:
Low
```

Could be useful for debugging VRChat updates.

---

# 228. Automatic Leak Response

I would not automatically restart VRChat based solely on leak heuristic.

Offer:

```
VRChat memory has been growing steadily.

[ Restart Later ]
[ Ignore ]
```

---

# 229. Scheduled Restart Suggestion

After long session + severe growth:

```
A clean restart may recover memory.
```

Button:

```
[ Quick Restart ]
```

which uses your session-preservation system.

---

# 230. Quick Restart Integration

Save:

```
world context
VRC Eye session
notes
media state
```

Then:

```
close VRChat
relaunch
offer previous world
```

Useful when memory grows but isn't emergency-level.

---

# 231. Protection Action Priority

If both:

```
Quick Restart suggested
```

and:

```
Emergency shutdown required
```

Emergency wins.

Centralize action arbitration.

---

# 232. Action Arbitration

Only one major action may be pending:

```
AUTO_CLOSE
SAFE_MODE
QUICK_RESTART
```

Avoid:

```
two modules simultaneously trying to restart VRChat
```

Especially with VRCX Companion Mode.

---

# 233. VRCX Arbitration

If VRCX is configured to handle crash restart:

```
VRC Eye:
diagnostics owner

VRCX:
restart owner
```

Resource Guard can still request user action but avoid duplicate relaunch logic.

---

# 234. External Integrations Must Not Block Protection

If:

```
Discord hung
Twitch offline
VRCX crashed
Bridge disconnected
```

Resource Guard remains operational.

It should have very few dependencies.

---

# 235. Critical Components

I'd mark these as essential:

```
Resource collector
Rule engine
Action controller
Black Box writer
Safety overlay channel
```

Everything else is optional.

---

# 236. Watchdog

Potential independent watchdog:

```
VRC Eye main process stops responding
```

could preserve:

```
last resource samples
crash marker
```

but keep this helper tiny.

---

# 237. Resource Guard Failure

If Resource Guard itself dies:

UI should say:

```
⚠ Resource Guard unavailable.
```

Not:

```
Protected
```

This sounds obvious, but safety software frequently gets this wrong.

---

# 238. Last Sample Age

Resource dashboard:

```
Last update
0.8 sec ago
```

If:

```
20 sec ago
```

status becomes:

```
STALE
```

---

# 239. Stale Metrics

Never display stale:

```
RAM 72% Healthy
```

without warning.

Instead:

```
RAM — unavailable
Last updated 23 sec ago
```

---

# 240. Overall Health Cannot Be Healthy If Critical Sensor Is Missing

Maybe:

```
Protection: Limited
```

rather than:

```
Healthy
```

if RAM collector failed.

---

# 241. Critical Capability Matrix

Example:

```
RAM monitoring        Required
VRAM monitoring       Optional
Thermal monitoring    Optional
Black Box             Recommended
```

Resource Guard can still run without GPU metrics.

---

# 242. Startup Self-Test

On first run/update:

```
Resource Guard Self-Test

System RAM          ✓
VRChat process      Waiting
GPU                 ✓
VRAM                ✓
Temperature         ✓
Disk                ✓
```

---

# 243. Permission Errors

If monitoring requires permission VRC Eye lacks:

```
GPU temperature unavailable:
insufficient permission.
```

Provide explanation.

Don't request administrator access unless genuinely necessary.

---

# 244. Least Privilege

Normal monitoring should run with ordinary user privileges wherever possible.

Only higher-risk controls should request elevated capability if unavoidable.

Do not run all of VRC Eye as administrator just because one optional feature needs it.

---

# 245. Dangerous Feature Boundary

These belong in:

```
☣ Dangerous
```

rather than normal Resource Guard:

```
Hard memory caps
Hard CPU caps
Force terminate
Aggressive process priority
Automatic background-app termination
```

---

# 246. Safe Defaults

Default installation:

```
Resource monitoring        ON
Warnings                   ON
Black Box                  optional/on depending design
Auto Safe Mode             OFF
Auto Close                 OFF
Force Terminate            OFF
Hard RAM Limit             OFF
CPU Limit                  OFF
```

---

# 247. Recommended Progression

Users could deliberately escalate:

```
Stage 1
Monitoring

Stage 2
Warnings

Stage 3
Automatic VRC Eye low-power mode

Stage 4
Automatic supported Safe Mode

Stage 5
Controlled VRChat close

Stage 6
OS resource enforcement
```

Each stage requires increasing intentionality.

---

# 248. “Protection Level” Isn't Permission Level

Don't confuse:

```
Maximum Protection
```

with:

```
Developer Mode
```

A casual user can use strong safety protection without seeing developer features.

---

# 249. Resource Guard Preset Example

```
BALANCED

RAM warnings                 ✓
VRAM warnings                ✓
Thermal warnings             ✓
Disk warnings                ✓
VRC Eye low-power            Automatic
VRChat Safe Mode             Ask
Close VRChat                 Ask
Hard resource limits         Off
```

---

# 250. Maximum Preset

```
MAXIMUM PROTECTION

Warnings                     ✓
Safe Mode                    Automatic on emergency
Close VRChat                 Countdown on emergency
Black Box                    High detail
Hard resource limits         Still Off
```

I would **still leave hard OS limits off**, even in Maximum.

They are a different category.

---

# 251. Hard Limits Profile

Explicit:

```
☣ RESOURCE CONTAINMENT

Windows Job / Linux cgroup

[ Configure ]
```

Separate from:

```
Maximum Protection
```

That distinction matters.

---

# 252. Implementation Order

Since you want one feature at a time, I would build Resource Protection in this order.

### Stage 1 — Process foundation

1. Detect VRChat PID reliably.
2. Track process start/exit.
3. Track process uptime.
4. Implement platform capability registry.

---

# 253. Stage 2 — RAM

5. System RAM.
6. VRChat working set.
7. VRChat private/committed memory.
8. Available RAM.
9. Rolling RAM history.
10. RAM graph.

This alone is already useful.

---

# 254. Stage 3 — RAM Guard

11. Warning thresholds.
12. Duration thresholds.
13. Hysteresis.
14. Cooldowns.
15. Warning notifications.
16. Recovery notifications.

Don't implement auto-close yet.

---

# 255. Stage 4 — CPU

17. System CPU.
18. VRChat CPU.
19. CPU history.
20. Sustained saturation warning.

---

# 256. Stage 5 — GPU

21. GPU discovery.
22. GPU utilization.
23. VRAM total.
24. VRAM used.
25. Per-process GPU capability detection.
26. VRAM history.
27. VRAM warning rules.

---

# 257. Stage 6 — Thermal

28. GPU temperature.
29. CPU temperature where available.
30. Temperature history.
31. Thermal warnings.

---

# 258. Stage 7 — Disk

32. Disk free space.
33. VRChat cache drive.
34. Screenshot drive.
35. VRC Eye data drive.
36. Critical disk warning.

---

# 259. Stage 8 — Analysis

37. Spike detector.
38. Trend detector.
39. Memory-growth detector.
40. Recovery detector.
41. context-aware loading state.

---

# 260. Stage 9 — Event Correlation

42. World changes.
43. Avatar load events.
44. player joins.
45. media events.
46. Resource event correlations.

---

# 261. Stage 10 — Safety Center

47. Overall state.
48. Resource Safety card.
49. VR overlay warning.
50. Session event timeline.

---

# 262. Stage 11 — Black Box

51. Rolling persistent buffer.
52. crash marker.
53. recovery reader.
54. Black Box report.
55. replay timeline.

---

# 263. Stage 12 — Protective Actions

56. VRC Eye Low-Power Mode.
57. Safe Mode suggestion.
58. automatic Safe Mode optional.
59. graceful VRChat close.
60. close countdown.
61. cancel/recovery behavior.

---

# 264. Stage 13 — Advanced OS Controls

Only after everything above is boringly stable:

62. Windows Job Object notification limits.
63. Windows hard memory cap.
64. Linux `memory.high`.
65. Linux `memory.max`.
66. CPU rate controls.
67. process priority tools.

---

# 265. Stage 14 — Performance Intelligence

68. session baseline.
69. world baseline.
70. regression detector.
71. driver/update correlation.
72. memory-growth watch.
73. session comparison.

---

# 266. Stage 15 — Bridge Enhancement

74. precise avatar-load telemetry.
75. better resource correlation.
76. client runtime health.
77. per-player safety correlation.

Core Resource Guard should already be finished before any of these exist.

---

# 267. Suggested Directory Structure

Something like:

```
src/vrc_eye/resources/
│
├── models.py
├── metrics.py
├── capabilities.py
├── monitor.py
├── store.py
├── history.py
├── analysis/
│   ├── trends.py
│   ├── spikes.py
│   ├── correlations.py
│   └── baselines.py
│
├── protection/
│   ├── rules.py
│   ├── engine.py
│   ├── actions.py
│   ├── states.py
│   └── presets.py
│
├── blackbox/
│   ├── writer.py
│   ├── reader.py
│   └── recovery.py
│
└── platform/
    ├── base.py
    ├── windows.py
    └── linux.py
```

UI separately:

```
ui/resource_dashboard.py
ui/resource_settings.py
ui/resource_overlay.py
```

---

# 268. Core Interface Boundary

Everything outside the resource package should interact through a small API:

```
resource_service.current_state()resource_service.current_metrics()resource_service.history(range)resource_service.subscribe(callback)resource_service.set_profile(profile)
```

Not:

```
from windows_gpu_nvml_sensor import ...
```

inside Safety Center.

---

# 269. Example Resource State

Something conceptual:

```
ResourceState(    overall=Severity.WARNING,    ram=MetricState(        value=0.89,        severity=Severity.WARNING,        trend=Trend.RISING,    ),    vram=MetricState(        value=0.93,        severity=Severity.ELEVATED,    ),    cpu=MetricState(        value=0.72,        severity=Severity.HEALTHY,    ),    gpu=MetricState(        value=0.99,        severity=Severity.HEALTHY,    ),    context=Context.NORMAL_PLAY,)
```

Notice:

```
GPU = 99%
severity = HEALTHY
```

could be completely valid.

---

# 270. Example Rule

Conceptually:

```
Rule(    id="ram_available_critical",    condition=LessThan(        metric="system.ram.available_bytes",        threshold=1_500_000_000,    ),    sustain_seconds=15,    recovery_threshold=2_500_000_000,    recovery_seconds=20,    severity=CRITICAL,)
```

---

# 271. Composite Rule

```
Rule(    id="memory_emergency",    condition=All(        ram_available < 750_MB,        commit_available < 1_GB,    ),    sustain_seconds=10,    severity=EMERGENCY,)
```

Then actions are configured separately.

---

# 272. Why Separate Rules From Actions?

Because:

```
Memory Emergency
```

may mean:

User A:

```
Warn only
```

User B:

```
Activate Safe Mode
```

User C:

```
Auto-close VRChat
```

Same condition.

Different policy.

---

# 273. Action Policy

Example:

```
ActionPolicy:    WARNING:        notify    CRITICAL:        notify        offer_safe_mode    EMERGENCY:        notify        countdown_close_if_enabled
```

Much cleaner.

---

# 274. Recovery Policy

Also separate:

```
When condition clears:

cancel pending actions
notify recovery if meaningful
return VRC Eye from emergency low-power mode
start cooldown
```

---

# 275. Protection Locks

If automatic action running:

```
action_lock
```

prevents another rule from initiating competing action.

Example:

```
RAM Emergency
VRAM Emergency
```

both hit simultaneously.

Only one:

```
Close VRChat countdown
```

should exist.

---

# 276. Root Event

Combined event:

```
RESOURCE_EMERGENCY
```

with contributors:

```
RAM
VRAM
```

instead of separate workflows.

---

# 277. Multi-Cause Warning

UI:

```
⚠ RESOURCE EMERGENCY

System RAM        Critical
GPU VRAM          Critical

VRChat is currently responsive.

[ Safe Mode ]
[ Close VRChat ]
```

---

# 278. Protect Against Oscillation

Imagine:

```
RAM critical
VRChat Safe Mode
RAM improves
Safe Mode clears?
```

Do not automatically undo VRChat's safety state unless the user explicitly requested that behavior.

Protective actions and recovery actions are not always symmetrical.

---

# 279. User Authority

VRC Eye should always make clear:

```
Automatic actions enabled by YOU.
```

Especially for:

```
auto-close
hard limits
```

---

# 280. Final Philosophy

The Resource/Performance system should have four progressively stronger roles:

### Observer

```
What is happening?
```

### Analyst

```
Is this unusual or worsening?
```

### Guardian

```
Should the user be warned?
```

### Protector

```
Should VRC Eye take an explicitly authorized action?
```

And that final role should always be the most conservative.

The ideal end-state is something like:

```
                VRC EYE RESOURCE GUARD
                         │
       ┌─────────────────┼─────────────────┐
       │                 │                 │
      RAM               GPU              CPU
       │                 │                 │
   Commit/RAM        VRAM/Load        Saturation
       │                 │                 │
       └──────────┬──────┴──────┬─────────┘
                  │             │
               Thermal        Disk
                  │             │
                  └──────┬──────┘
                         │
                    ANALYSIS
                trends / spikes
                correlations
                baselines
                         │
                    RULE ENGINE
                         │
           ┌─────────────┼─────────────┐
           │             │             │
         WARN         PROTECT       RECOVER
           │             │             │
        Overlay        Safe Mode      Cancel
        Desktop        Low Power      Cooldown
        Black Box      Close VRChat   Report
                         │
                   HARD CONTAINMENT
                    optional only
                 Job Object / cgroup
```

If you build it in that order, the dangerous pieces—hard limits and automatic termination—become relatively small extensions of a **well-tested monitoring system**, rather than being the foundation.

That is the difference between:

> “VRC Eye kills VRChat when RAM gets high.”

and:

> **“VRC Eye understands resource pressure, records what happened, explains why it is concerned, gives the user time to react, and can take increasingly strong protective actions only when explicitly authorized.”**