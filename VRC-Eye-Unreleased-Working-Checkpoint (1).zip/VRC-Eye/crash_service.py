"""Independent Black Box writer and collectors; Tk never owns the journal."""
from collections import deque
from concurrent.futures import Future
from copy import deepcopy
from pathlib import Path
import queue
import threading
import time

from crash_model import settings, safe_payload, WORLD
from crash_store import BlackBoxStore


class CrashService:
    def __init__(self,path,config=None,*,clock=time.monotonic,wall=time.time,core_factory=None):
        self.directory=Path(path).parent/'crash-diagnostics';self.config=settings(config)
        self.clock=clock;self.wall=wall;self.core_factory=core_factory
        self.lock=threading.RLock();self.stop=threading.Event();self.commands=queue.Queue(32);self.events=queue.Queue(512)
        self.threads=[];self.provider=None;self.latest=None;self.world='';self.dropped=0
        self.state=dict(status='Not started',records=0,seconds=0,incidents=0,process='unknown',severity='UNKNOWN',errors=[],recovered=None,os_status='Not queried')
        self.errors=deque(maxlen=100);self.seen=deque(maxlen=1024)
        self.identity=None;self.absent=0;self.hung_since=None;self.hung_saved=False;self.loading_until=0;self.segment=0;self.expected_until=0
        self.last_observed=None;self.last_auto_save=-1e30;self.last_sample=-1e30;self.last_checkpoint=-1e30;self.last_tick=None;self.last_wall=None
    def start(self):
        if self.threads:return
        self.threads=[threading.Thread(target=fn,daemon=True,name='VRC-Eye-BlackBox-'+name) for fn,name in ((self._writer,'Writer'),(self._collect,'Sensors'))]
        for thread in self.threads:thread.start()
    def snapshot(self):
        with self.lock:
            value=deepcopy(self.state)
            stamp=value.get('process_at')
            if self.stop.is_set() or stamp is None or not 0<=self.clock()-stamp<=5:value['process']='unknown'
            return value
    def submit(self,operation,*args):
        result=Future()
        if self.stop.is_set():result.set_exception(ValueError('Recorder is stopped.'));return result
        try:self.commands.put_nowait((result,operation,args))
        except queue.Full:result.set_exception(ValueError('Diagnostics queue is full. Try again after pending work completes.'))
        return result
    def offer(self,kind,source,payload=None,*,stamp=None,key=None,confidence='direct'):
        if not self.config['enabled'] or self.stop.is_set():return
        if stamp is not None and not 0<=self.wall()-stamp<=15:return
        with self.lock:
            if key is not None:
                if key in self.seen:return
                self.seen.append(key)
            data=safe_payload(kind,payload or {})
            try:self.events.put_nowait((kind,source,data,self.clock(),self.wall(),confidence))
            except queue.Full:self.dropped+=1
    def _collect(self):
        from resource_backend import CoreBackend
        from crash_platform import AuxiliaryProbe,responsiveness
        core=None;aux=None
        while not self.stop.is_set():
            if self.config['enabled']:
                try:
                    if core is None:core=(self.core_factory or CoreBackend)()
                    if aux is None:
                        try:aux=AuxiliaryProbe()
                        except ImportError:pass
                    snap=self.provider.snapshot() if self.provider else {}
                    sample=snap.get('sample') if not snap.get('stale',True) else None
                    if sample is None:sample=core.sample()
                    try:state=responsiveness(sample.identity,core.exact)
                    except Exception:state='unknown'
                    extra=aux.sample(self.clock()) if aux else {}
                    with self.lock:self.latest=(sample,snap.get('summary',{}).get('severity','UNKNOWN'),state,extra,snap.get('action',''))
                except Exception:
                    with self.lock:self.latest=None
            self.stop.wait(1)
    def _publish(self,**values):
        with self.lock:self.state.update(values)
    def _save(self,store,reason):
        if reason!='manual' and self.clock()-self.last_auto_save<30:return None
        try:ref=store.preserve(reason,self.world)
        except ValueError:
            if reason=='manual':raise
            self._publish(incident_warning='Incident could not be preserved: storage budget reached or evidence invalid. Export/delete old incidents.')
            return None
        if reason!='manual':self.last_auto_save=self.clock()
        self._publish(last_incident=ref)
        return ref
    def accept(self,store,latest,at,wall):
        """Deterministic state machine; unknown observations cannot assert an exit."""
        if latest is None or not 0<=at-latest[0].at<=5:
            self._publish(process='unknown',severity='UNKNOWN')
            if not getattr(self,'sensor_missing',False):
                store.append('gap','recorder',{'reason':'sensor_expired'},at,wall)
                store.append('provider.failed','resource',{'reason':'provider_error'},at,wall)
            self.sensor_missing=True
            if at-self.last_sample>=5:
                store.append('sample','resource',{'state':'unknown','process':'unknown','metrics':{}},at,wall,'unknown');self.last_sample=at
            return
        self.sensor_missing=False
        sample,severity,responsive,extra,action=latest
        if sample.at==self.last_observed:return
        self.last_observed=sample.at
        state='running' if sample.identity else 'not_running' if sample.process_status=='VRChat not running' else 'unknown'
        self._publish(process=state,process_at=sample.at,severity=severity)
        if action=='Normal close requested; no force termination or automatic retry.' and getattr(self,'last_action','')!=action:
            self.expected_until=at+30
        self.last_action=action
        if sample.identity:
            self.absent=0
            if sample.identity!=self.identity:
                if self.identity:
                    store.append('process.exited','process',{'reason':'session_change','expected_exit':False},at,wall,'medium')
                    self._save(store,'process_exit')
                self.identity=sample.identity;self.segment+=1;self.hung_since=None;self.hung_saved=False
                store.append('process.started','process',{'segment':self.segment},at,wall)
            if responsive=='unresponsive' and at>=self.loading_until:
                if self.hung_since is None:self.hung_since=at
                if at-self.hung_since>=10 and not self.hung_saved:
                    store.append('process.hung','process',{'duration':at-self.hung_since},at,wall,'medium')
                    self._save(store,'hang');self.hung_saved=True
            elif responsive=='responsive':
                if self.hung_saved:store.append('process.recovered','process',{},at,wall)
                self.hung_since=None;self.hung_saved=False
            else:self.hung_since=None
        elif state=='not_running' and self.identity:
            self.absent+=1
            if self.absent>=2:
                expected=at<=self.expected_until
                store.append('process.exited','process',{'expected_exit':expected,'segment':self.segment},at,wall)
                if not expected:self._save(store,'process_exit')
                self.identity=None;self.hung_since=None;self.hung_saved=False
        else:self.absent=0
        cadence=1 if severity in ('ELEVATED','WARNING','CRITICAL','EMERGENCY') else 5
        if at-self.last_sample>=cadence:
            metrics={k:dict(value=m.value if m.fresh(at) else None,age=max(0,min(86400,at-m.at)),ttl=min(60,max(.1,m.ttl)),source='resource') for k,m in sample.metrics.items()}
            payload=dict(metrics=metrics,state=responsive,process=state,severity=severity,segment=self.segment,**extra)
            store.append('sample','resource',payload,at,wall);self.last_sample=at
            if severity=='HEALTHY' and state=='running' and at-self.last_checkpoint>=60:
                store.append('checkpoint','derived',payload,at,wall,'medium');self.last_checkpoint=at
    def _command(self,store,op,args):
        if op=='list':return store.list()
        if op=='load':return store.load(*args)
        if op=='delete':return store.delete(*args)
        if op=='preserve':
            if not store.run:raise ValueError('Enable the recorder before preserving a snapshot.')
            return self._save(store,'manual')
        if op=='os':return store.add_os_evidence(*args)
        if op=='configure':
            value=settings(args[0]);before=store.config
            if not value['remember_world']:self.world='';store.forget_worlds()
            if before['enabled'] and not value['enabled']:store.pause(self.clock(),self.wall())
            if not before['enabled'] and value['enabled']:store.begin(self.clock(),self.wall());self.last_sample=-1e30;self.last_observed=None;self.identity=None
            store.config=value;store.prune()
            with self.lock:self.config=value
            return value
        raise ValueError('Unsupported diagnostics operation.')
    def _os_recovery(self,ref,start,end):
        from crash_platform import windows_evidence
        events,status=windows_evidence(start,end)
        if events and not self.stop.is_set():self.submit('os',ref,events)
        self._publish(os_status=status)
    def _writer(self):
        store=BlackBoxStore(self.directory,self.config,wall=self.wall);healthy=True
        try:
            recovered=store.open(self.clock(),self.wall(),recording=self.config['enabled'])
            self._publish(recovered=recovered,status='Recording' if store.run else 'Recording disabled')
            if recovered and self.config['windows_evidence']:
                data=store.load(recovered);last=data['summary']['end']
                threading.Thread(target=self._os_recovery,args=(recovered,max(0,last-60),self.wall()),daemon=True,name='VRC-Eye-OS-Evidence').start()
            while not self.stop.is_set() or not self.events.empty() or not self.commands.empty():
                at=self.clock();wall=self.wall()
                for _ in range(32):
                    try:future,op,args=self.commands.get_nowait()
                    except queue.Empty:break
                    if not future.set_running_or_notify_cancel():continue
                    try:future.set_result(self._command(store,op,args))
                    except Exception as error:future.set_exception(error)
                if store.run:
                    if self.last_tick is not None:
                        delay=at-self.last_tick
                        if delay>3:store.append('gap','recorder',{'reason':'sampling_gap','duration':delay},at,wall)
                        if abs((wall-self.last_wall)-delay)>3:store.append('gap','recorder',{'reason':'clock_change'},at,wall)
                    with self.lock:dropped=self.dropped;self.dropped=0;latest=self.latest
                    if dropped:store.append('gap','recorder',{'reason':'queue_overflow','dropped':dropped},at,wall)
                    store.append('heartbeat','recorder',{},at,wall)
                    self.accept(store,latest,at,wall)
                for _ in range(512):
                    try:kind,source,payload,t,w,confidence=self.events.get_nowait()
                    except queue.Empty:break
                    if not store.run:continue
                    store.append(kind,source,payload,t,w,confidence)
                    if kind=='instance.entered':self.loading_until=at+30
                    if kind in ('log.error','log.warning','log.crash','eye.error'):
                        self.errors.append(dict(kind=kind,wall=w,source=source,count=payload.get('count',1)))
                    if kind=='log.crash':self._save(store,'log_crash')
                self.last_tick=at;self.last_wall=wall
                self._publish(**store.status(),errors=list(self.errors),status='Recording' if store.run else 'Recording disabled')
                self.stop.wait(1)
        except Exception as error:
            healthy=False;self._publish(status='Recorder unavailable: '+type(error).__name__+'; existing evidence retained')
        finally:
            try:store.close(clean=healthy)
            except Exception:self._publish(status='Recorder could not confirm a clean stop')
            self.stop.set()
            while not self.commands.empty():
                future,_,_=self.commands.get_nowait()
                if not future.done():future.set_exception(ValueError('Recorder unavailable; existing evidence was retained.'))
    def close(self):
        self.stop.set()
        if self.threads:self.threads[0].join(timeout=2)
