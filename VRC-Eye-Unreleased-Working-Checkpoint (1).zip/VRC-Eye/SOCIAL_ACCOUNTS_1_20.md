# VRC Eye 1.20 — Social / Accounts foundation

Development 7 adds [outbound invitations and My avatars](SOCIAL_AVATARS_1_20_DEV7.md).
The sections below document the carried-forward Development 3 foundation.

This guide describes the implemented Development 3 checkpoint. It does not
represent the full Social/Accounts specification as complete. Existing VCC and
Avatar Library features remain. The source application still uses **one active
VRChat session at a time**; local account labels are not additional live logins.

## Where to find it

**Community → Social** contains Browse, Dashboard and Action history.
**You → Accounts** contains Accounts & logins, My profile and Action history.
The existing Ctrl+K command palette also finds these destinations. Changing the
Casual/Advanced/Developer presentation does not authorize an API action.

Opening either page does not sign in, poll VRChat, send requests, launch a helper,
join an instance, change an avatar, or arm OSC. The account strip distinguishes the
active VRC Eye API identity from the last identity observed in the game log. A log
identity can be stale; it is not proof that a running game is using that account.

## Social browsing

Choose a list and select **Load / refresh**. Supported views are online/website
friends, offline friends, friend requests, the notification inbox, received
invites, invite requests, invite responses, group invites, your groups, your mutes,
and your blocks. The last two are settings of the signed-in account, not detection
of other people's mutes or blocks.

Reads use the existing connection, request budget, cancellation and account-change
handling. The new notification view uses the existing legacy notification API,
not a NotificationV2 implementation. No WebSocket subscriber or second background
poller was added. Refresh is manual. There are no automatic friend actions or
notification writes when a row is selected.

Text/status/unread filters operate on the **fetched page**, not on all records on
VRChat. Notification pages have up to 100 raw records. An Invites view can show
zero matching rows while Next remains available because the source page was full
of other notification types. Dashboard numbers are explicitly dated, loaded-page
snapshots, not account-wide totals. The unpaged group/moderation readers retain
existing response bounds and reject unsupported data rather than claiming that
missing information is known.

Selection follows stable record identifiers when filtering or refreshing. Two
people with identical display names remain separate rows. A missing sender,
unsupported notification type, missing read state or malformed details is labeled
rather than invented. Required identity/recipient mismatches fail the load.

REST notification details may be JSON text. The normalizer also accepts equivalent
objects, bounds their size, rejects duplicate JSON keys/nonfinite values and keeps
only supported presentation fields. An invitation's retained world reference is
its **world ID**, not a private instance/nonce credential. Message URLs and selected
private-instance fragments are omitted from this new view. This is not a general
content-security scanner or a promise that arbitrary free text contains no
personal information.

## Social actions and reviews

Existing friend request, friend removal, mute/block, friend-request acceptance and
decline, and group invitation acceptance/decline controls now use the shared
reviewed-action service. Notification actions add **Mark read on VRChat** and
**Hide on VRChat**. Ordinary received invitations are not accepted/joined through
the friend/group request controls. Opening a referenced world opens only its
website page after confirmation; it does not join the invitation's instance or
send a self-invite. Outbound invitation composition is now available separately; see the Development 7 guide above.

Every review identifies the acting account and session, the operation, exact
target, consequences, authentication requirement, remote-write/API risk and
privacy impact. A review is frozen, one-use and expires after five minutes. The
selected account/record/draft is checked again after confirmation. The service
rechecks the connection object, identity, session revision, operating mode,
cancellation and relevant snapshot freshness immediately before dispatch.

Edits made after a review cannot silently retarget the queued request. A different
client connection for the same user is still a different connection and requires
fresh returned records. Switching accounts requests cancellation and clears the
old view; any action that had already crossed the transport boundary remains
attributed to its **initiating** account.

Game Favorites add/remove controls also use this service. Removing a game favorite
can remove the record from **every list attached to it**; the review preserves that
warning. Local VRC Eye favorites remain a distinct, existing collection system.
This is not an application-wide interception layer: legacy profile dialogs,
creator metadata actions, Developer/Black Lab and other unrelated write paths keep
their existing guards and are not all journaled by this new service.

## Action history and uncertain results

The new service commits a local receipt before dispatch. It cannot send when that
initial receipt cannot be saved. Receipts are stored in namespaced tables in the
existing CompanionStore database, not in another account database.

| State | Meaning |
|---|---|
| Queued | Reviewed and recorded locally; the transport boundary has not been entered. |
| Dispatching | The boundary was entered; a usable acknowledgement has not yet been recorded. |
| Confirmed | The expected acknowledgement was observed. This is not proof of the server's current state forever. |
| Rejected | A recognized rejecting HTTP response was received. |
| Not sent | Context, expiry, cancellation or local persistence prevented dispatch. |
| Uncertain | The action may have reached VRChat, but the expected acknowledgement was not recorded. |

A generic HTTP success or an unrelated response is not automatically accepted as
confirmation. For example, the read marker must identify the selected notification
and report seen=true; an own-profile reply must confirm every submitted changed
field. A connection loss can leave the outcome uncertain. **There is no automatic
write retry**, and an unacknowledged uncertain matching operation prevents a new
matching submission through this service.

History is scoped to the current account, or to an explicitly selected local
account label on Accounts. Refreshing history reads only the local database.
After restarting, a previous Queued receipt is shown as Interrupted / not sent;
a previous Dispatching receipt is Interrupted / uncertain. Recovery does not
contact VRChat or silently resend anything. Do not run two app instances against
the same database: the recovery interpretation assumes one VRC Eye process.

**Acknowledge uncertain outcome** records that you reviewed the uncertainty after
checking independently. It does not mark an operation successful, prove its
remote outcome, or retry it. Active actions cannot be acknowledged. Acknowledgement
allows a newly prepared review of the matching operation; it is not an automatic
retry queue.

When final receipt saving fails, the persistent record can remain Dispatching.
The page displays a warning and retains the observed outcome in memory for this
process. **Retry saving outcome locally** retries only that database write, never
the remote operation. If saving continues to fail, the in-memory result lasts only
until exit; after restarting, treat the persistent dispatch as uncertain.

There is a 2,000-receipt limit per account. A full history prevents new submissions
until the user explicitly clears completed records. Clear completed history removes
Confirmed, Rejected, Not sent, and interrupted pre-dispatch records; active and
uncertain records remain, even after uncertainty acknowledgement. Clearing local
history cannot undo a VRChat action.

Selected receipt exports contain only the operation, state, timestamps and the
local acknowledgement flag. Account/target IDs, session identity, aliases, message
bodies and submitted profile values are omitted. They are diagnostic snapshots,
not signed proof of remote state. Export uses exclusive file creation: it never
overwrites an existing file or follows an existing destination symlink.

## Accounts & logins

The active-login table contains zero or one authenticated session **in this
process**. It is not a server device/session inventory. Opening the table does not
reauthenticate or claim that a server session has just been revalidated.

Local account labels associate an exact user ID with a label and Main, Alt,
Creator or Other role. Up to 64 labels may be retained. They are convenience
organization, not verified ownership, permission grants or authentication. An
explicit Save review names the exact ID. Selecting a row fills the local form and
can select its local history; it never changes the live login. Forgetting a label
removes only that label, not credentials, receipts, avatars, favorites or a remote
account. These local IDs and labels are not encrypted by this workspace.

Connect / replace connection uses the existing connection dialog. With an active
session, a warning explains that a successful replacement closes it, requests
cancellation and clears account views. No second session is retained. Disconnect
current session is explicitly reviewed; it discards the local session but does
not claim to revoke other devices' logins.

The existing independent Remember username / Remember password checkboxes,
credential-storage behavior, verification handling and scoped Enter/keypad Enter
controls are unchanged. This workspace does not save cookies, verification codes,
new passwords or account-switch authentication tokens.

## My profile

Refresh explicitly loads the active account's own profile. The first editable
fields are status, status text and pronouns. Only recognized fields actually
returned by the source are enabled; missing/unsupported fields remain disabled.
Status text and pronouns use the existing 32-character validator. Biography and
avatar metadata editing are not newly added here.

Form edits are session-only. Discard restores the loaded values; a connection
change clears them. Review shows the previous and proposed values and submits
only changed fields. An unchanged form cannot issue a write. The snapshot must
remain recent through the request-budget wait. This is **not** a server-side
compare-and-swap guarantee: another application may edit the profile after the
snapshot was read.

The response must confirm the selected account and each submitted value before
this service records Confirmed. After completion the form is cleared and must be
refreshed; it is not optimistically presented as the authoritative remote state.

## Privacy, accessibility and limits

Each new page has a **Privacy view (this page)** switch. It clears that page's
loaded records, selections, profile draft, names/IDs and history display, and
requires reveal and explicit refresh before acting. It does not turn on an
application-wide streamer mode, encrypt the database or clear other workspaces.
Receipts locally retain acting/target IDs and operation outcomes, but not raw
response bodies, notification messages, credentials or submitted profile fields.

The pages reuse shared theme, font/control scaling, visible focus, named native
controls, keyboard-operable tables, dialogs and navigation. Their content bodies
scroll vertically and horizontally at narrow/large-text sizes. This checkpoint
has native Linux/Tk reachability tests at 200% scale, not a claim of complete
reflow, screen-reader interoperability, speech alerts or XR accessibility.

The broader roadmap still includes multi-session account retention and full
account-isolated migration, outbound invites, NotificationV2/live update handling,
complete notification routing, expanded profile/avatar metadata editing, Photos,
Invite Me, remaining accessibility, and deeper conditional creator tools. None is
silently represented as completed by the local account labels or this action
service. No supplied ARC binary, recovery/viewer executable, silent updater or new
runtime dependency was added.

## Validation and source references

See BUILD_VALIDATION.json for actual results and platform limits. Unit tests use
controlled API responses, temporary databases and adversarial inputs. Native tests
use real Tk widgets with synthetic accounts and HTTP fixtures. The full suite uses
the external-socket guard; loopback networking fixtures remain permitted. No live
VRChat/VRCX login, native Windows run, installed Unity/VPM or screen reader was used.

The test harness collects unreachable native-fixture cycles on the creating main
thread after pytest releases fixture references. It does not mock Tk, suppress
failures, or alter garbage collection in the shipped application. A preliminary
combined run aborted in background-thread garbage collection; its partial results
are not counted as the final validation run.

Protocol references reviewed during implementation (community-maintained primary
specifications, not a claim of VRChat approval or live verification):

- https://vrchat.community/reference/get-notifications
- https://vrchat.community/reference/mark-notification-as-read
- https://vrchat.community/reference/delete-notification
- https://raw.githubusercontent.com/vrchatapi/specification/master/openapi/components/schemas/Notification.yaml
- https://raw.githubusercontent.com/vrchatapi/specification/master/openapi/components/schemas/NotificationType.yaml
- https://raw.githubusercontent.com/vrchatapi/specification/master/openapi/components/schemas/NotificationDetailInvite.yaml
- https://github.com/python/cpython/blob/main/Doc/library/tkinter.rst
