"""Strict data-only import for explicitly exported Unity Editor Core reports."""
import datetime
import json
import re
from creator_projects import PACKAGE_NAME, UNITY_VERSION, read_bytes

FIELDS={'schema','product','created_utc','unity_version','active_build_target','compiling','playing',
        'selected_objects','dirty_scenes','package_count','packages_truncated','packages'}


def validate_report(raw):
    if not isinstance(raw,dict) or set(raw)!=FIELDS or type(raw['schema']) is not int or raw['schema']!=1 or raw['product']!='VRC Eye Editor Core':
        raise ValueError('Unsupported editor report schema. No commands or arbitrary records are imported.')
    if not isinstance(raw['unity_version'],str) or not UNITY_VERSION.fullmatch(raw['unity_version']):
        raise ValueError('The editor report needs an exact Unity version.')
    if not isinstance(raw['created_utc'],str) or len(raw['created_utc'])>40:
        raise ValueError('Invalid report timestamp.')
    try:
        stamp=datetime.datetime.fromisoformat(raw['created_utc'].replace('Z','+00:00'))
        if stamp.tzinfo is None:raise ValueError()
    except ValueError as error:raise ValueError('The report timestamp must include a timezone.') from error
    if not isinstance(raw['active_build_target'],str) or not re.fullmatch(r'[A-Za-z0-9_ -]{1,64}',raw['active_build_target']):
        raise ValueError('Unsupported build-target label.')
    for key in ('compiling','playing','packages_truncated'):
        if type(raw[key]) is not bool:raise ValueError('Invalid editor state.')
    for key in ('selected_objects','dirty_scenes','package_count'):
        if type(raw[key]) is not int or not 0<=raw[key]<=100000:raise ValueError('Invalid editor count.')
    rows=raw['packages']
    if not isinstance(rows,list) or len(rows)>256:raise ValueError('Editor package inventory exceeds 256 entries.')
    seen=set(); clean=[]
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'name','version','source'}:raise ValueError('Invalid editor package record.')
        if not isinstance(row['name'],str) or not PACKAGE_NAME.fullmatch(row['name']) or row['name'] in seen:raise ValueError('Invalid or duplicate package identifier.')
        if not isinstance(row['version'],str) or not re.fullmatch(r'[0-9A-Za-z.+-]{1,80}',row['version']):raise ValueError('Invalid package version; locations and URLs are not imported.')
        if not isinstance(row['source'],str) or not re.fullmatch(r'[A-Za-z]{1,40}',row['source']):raise ValueError('Invalid package-source label.')
        seen.add(row['name']);clean.append(dict(row))
    if raw['package_count']<len(rows) or not raw['packages_truncated'] and raw['package_count']!=len(rows):raise ValueError('Package counts do not match the report.')
    return dict(raw,packages=clean)


def load_report(path):
    try:raw=json.loads(read_bytes(path,256*1024).decode('utf-8-sig'))
    except (UnicodeError,json.JSONDecodeError,RecursionError) as error:raise ValueError('Unsupported JSON editor report.') from error
    return validate_report(raw)
