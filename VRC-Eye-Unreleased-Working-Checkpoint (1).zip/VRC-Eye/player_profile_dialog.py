"""Secondary player window: explicit sources, local notes, account editing and whispers."""

from text_viewport import window_body
import base64
import json
import math
from pathlib import Path
import queue
import sqlite3
import threading
import time

from avatar_links import parse_avatar_reference
from player_platforms import parse_user_platform
from player_profile import (UNKNOWN, STATUSES, merged_profile, summary_text, profile_links,
                            safe_link, scalar, read_profile_json, self_patch, avatar_patch)
from player_store import PlayerStore
from world_players import log_epoch, row_details
from vrchat_api import APIError
import player_api


def show_account(view):
    app = view.app
    if app.demo:
        return
    if not app.api or not app.api.authenticated:
        from online_dialog import show_connection_dialog
        show_connection_dialog(app, lambda: show_account(view) if not view.closed else None)
        return
    from world_players import PlayerRow, PlayerVisit
    row = next((row for row in view.player_rows.values() if row.visit and row.visit.user_id == app.api.user_id), None)
    if row is None:
        visit = PlayerVisit(0, "My account", app.api.user_id, state="Account view",
                            note="Signed-in account. This view does not establish a world visit.")
        row = PlayerRow("self", "My account", visit, None, None, True, ())
    dialog = show_profile(view, row, initial="account")
    if dialog:
        dialog.tabs.select(dialog.account_page)
        if not dialog.job and dialog.account_baseline is None:
            dialog.load_section("account")
    return dialog


def show_profile(view, row, *, initial="public"):
    app = view.app
    service = getattr(app, "player_sessions", None)
    if service and service.settings["presentation"]:
        from tkinter import messagebox
        messagebox.showinfo("Presentation mode", "Disable player-list presentation mode to open private profile details.", parent=app.root)
        return None
    windows = getattr(app, "player_profile_windows", None)
    if windows is None:
        app.player_profile_windows = windows = {}
    key = row.visit.user_id if row.visit and row.visit.user_id else (view.log_roster().identity, row.key)
    existing = windows.get(key)
    if existing and not existing.closed:
        existing.row = row
        existing.local_details = row_details(row, view.log_roster())
        existing.display_name.set(row.name)
        existing.window.title("VRC Eye · " + row.name)
        existing.render()
        existing.window.lift()
        return existing
    if sum(not window.closed for window in windows.values()) >= 8:
        from tkinter import messagebox
        messagebox.showinfo("Player windows", "Close a player window before opening another (maximum eight).", parent=view.parent)
        return
    window = ProfileDialog(view, row, initial=initial)
    windows[key] = window
    return window


class ProfileDialog:
    def __init__(self, view, row, *, initial="public"):
        self.view, self.app, self.row = view, view.app, row
        self.tk, self.ttk = self.app.tk, self.app.ttk
        self.user_id = row.visit.user_id if row.visit else ""
        self.local_details = row_details(row, view.log_roster())
        self.window = self.tk.Toplevel(self.app.root)
        self.window.title("VRC Eye · " + row.name)
        self.window.geometry("1080x840")
        self.window.minsize(940, 720)
        self.window.configure(bg=self.app.BG)
        self.closed, self.timer, self.job = False, None, None
        self.sections, self.collections, self.collection_rows = {}, {}, {}
        self.photos, self.network_buttons = [], []
        self.avatar_snapshot, self.account_baseline = None, None
        self.loaded_note = ""
        self.store = PlayerStore.for_app(self.app)
        self.connection = self.context()
        self.status = self.tk.StringVar(value="Select Refresh profile for current API data. Local observations remain available without sign-in.")
        self.collection_kind = self.tk.StringVar(value="Groups")
        self.display_name = self.tk.StringVar(value=row.name)
        self.build()
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        if self.user_id and not self.app.demo:
            try:
                self.loaded_note = self.store.note(self.user_id)
                self.notes.insert("1.0", self.loaded_note)
                if row.key != "self": self.store.observe_name(self.user_id, row.name)
            except (OSError, sqlite3.Error, ValueError):
                self.status.set("Local notes/history could not be opened. Check the VRC Eye settings folder permissions.")
        self.render()
        self.tick()
        if self.user_id and self.app.api and self.app.api.authenticated and not self.app.demo:
            self.load_section(initial)

    def context(self):
        client = self.app.api
        return client, getattr(client, "session_revision", None), self.app.data_generation, getattr(client, "user_id", ""), bool(client and client.authenticated)

    def translate_text(self):
        try:return __import__('text_translation_ui').show_profile(self)
        except (ValueError,OSError) as error:self.status.set(str(error))

    def text_area(self, parent, height=12):
        frame = self.ttk.Frame(parent); frame.pack(fill="both", expand=True, pady=4)
        text = self.tk.Text(frame, height=height, wrap="word", bg=self.app.PANEL, fg=self.app.TEXT,
                            insertbackground=self.app.TEXT, undo=False)
        scroll = self.ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        scroll.pack(side="right", fill="y"); text.pack(fill="both", expand=True)
        text.configure(yscrollcommand=scroll.set, state="disabled")
        return text

    @staticmethod
    def set_text(widget, value):
        # Preserve scroll position and avoid constantly replacing a chat transcript.
        if getattr(widget, "_vrc_eye_text", None) == value: return
        position = widget.yview()
        widget.configure(state="normal"); widget.delete("1.0", "end"); widget.insert("1.0", value)
        widget.configure(state="disabled")
        if position: widget.yview_moveto(position[0])
        widget._vrc_eye_text = value

    def button(self, parent, text, command, *, own=False):
        button = self.ttk.Button(parent, text=text, command=command)
        button.pack(side="left", padx=(0, 6))
        self.network_buttons.append((button, own))
        return button

    def build(self):
        ttk, tk = self.ttk, self.tk
        body = ttk.Frame(window_body(self.window), padding=14); body.pack(fill="both", expand=True)
        ttk.Label(body, textvariable=self.display_name, font='EyeTitleFont').pack(anchor="w")
        ttk.Label(body, text="Account ID: " + (self.user_id or "Unknown; name-only rows cannot fetch account data or save account notes."), style="Muted.TLabel").pack(anchor="w")
        bar = ttk.Frame(body); bar.pack(fill="x", pady=6)
        self.button(bar, "Refresh profile", lambda: self.load_section("public"))
        self.button(bar, "Refresh user details", lambda: self.load_section("account"))
        self.button(bar, "Boop", self.boop)
        ttk.Button(bar,text='Translate name / bio…',command=self.translate_text).pack(side='left',padx=(0,6))
        ttk.Button(bar, text="Import profile JSON…", command=self.import_json,
                   state="normal" if self.user_id and not self.app.demo else "disabled").pack(side="left", padx=6)
        self.cancel_button = ttk.Button(bar, text="Cancel request", command=self.cancel, state="disabled")
        self.cancel_button.pack(side="right")
        ttk.Label(body, textvariable=self.status, wraplength=1000, style="Muted.TLabel").pack(anchor="w", pady=(0, 5))
        self.tabs = ttk.Notebook(body); self.tabs.pack(fill="both", expand=True)
        pages = {}
        for title in ("Profile", "Social", "Collections", "Activity", "Media", "Notes", "JSON", "Account", "Whisper"):
            page = ttk.Frame(self.tabs, padding=10)
            self.tabs.add(page, text=title); pages[title] = page
        self.summary = self.text_area(pages["Profile"])
        row = ttk.Frame(pages["Social"]); row.pack(fill="x")
        self.button(row, "Load groups", lambda: self.load_section("groups"))
        self.button(row, "Load mutual friends", lambda: self.load_section("mutuals"))
        self.social = self.text_area(pages["Social"])
        ttk.Label(pages["Social"], text="Only returned/visible memberships and mutuals are shown. A denied request is not a zero count.", style="Muted.TLabel").pack(anchor="w")
        row = ttk.Frame(pages["Collections"]); row.pack(fill="x")
        kinds = ttk.Combobox(row, textvariable=self.collection_kind, state="readonly", width=25,
                     values=("Groups", "Mutual friends", "Favorite lists", "My uploaded avatars"))
        kinds.pack(side="left", padx=(0, 6))
        kinds.bind("<<ComboboxSelected>>", lambda _: self.show_collection(self.kind()))
        self.button(row, "Load selected collection", self.load_collection)
        self.button(row, "Load next page", self.next_page)
        self.button(row, "Open favorite list", self.load_favorite)
        ttk.Button(row, text="Open selected page", command=self.open_collection_link).pack(side="right")
        frame = ttk.Frame(pages["Collections"]); frame.pack(fill="both", expand=True, pady=8)
        self.table = ttk.Treeview(frame, columns=("type", "name", "id", "detail"), show="headings", selectmode="browse")
        for key, width in (("type", 100), ("name", 220), ("id", 365), ("detail", 140)):
            self.table.heading(key, text=key.upper()); self.table.column(key, width=width, minwidth=80)
        vertical = ttk.Scrollbar(frame, orient="vertical", command=self.table.yview)
        vertical.pack(side="right", fill="y")
        scroll = ttk.Scrollbar(frame, orient="horizontal", command=self.table.xview); scroll.pack(fill="x")
        self.table.pack(fill="both", expand=True)
        self.table.configure(xscrollcommand=scroll.set, yscrollcommand=vertical.set)
        ttk.Label(pages["Collections"], text="Favorite worlds/avatars are loaded through returned lists and remain subject to access controls.\n"
            "My uploaded avatars is available for your own account. Other players' complete libraries are unavailable.",
            style="Muted.TLabel", wraplength=940).pack(anchor="w")
        row = ttk.Frame(pages["Activity"]); row.pack(fill="x")
        self.button(row, "Refresh visible activity", lambda: self.load_section("activity"))
        ttk.Button(row, text="Refresh local observations", command=self.render).pack(side="left")
        ttk.Button(row, text="Forget observed names", command=self.forget_names).pack(side="right")
        self.activity = self.text_area(pages["Activity"])
        row = ttk.Frame(pages["Media"]); row.pack(fill="x")
        self.button(row, "Load image previews", self.load_images)
        ttk.Button(row, text="Open selected link", command=self.open_link).pack(side="right")
        self.links = ttk.Treeview(pages["Media"], columns=("kind", "url"), show="headings", selectmode="browse", height=6)
        self.links.heading("kind", text="LINK"); self.links.heading("url", text="URL")
        self.links.column("kind", width=180); self.links.column("url", width=700)
        self.links.pack(fill="x", pady=8)
        pictures = ttk.Frame(pages["Media"]); pictures.pack(fill="both", expand=True)
        self.image_labels = {}
        for title in ("Profile picture", "Banner", "Current avatar image"):
            cell = ttk.Frame(pictures); cell.pack(side="left", fill="both", expand=True)
            ttk.Label(cell, text=title).pack()
            label = ttk.Label(cell, text="No preview loaded", wraplength=290); label.pack(fill="both", expand=True)
            self.image_labels[title] = label
        ttk.Label(pages["Media"], text="Links open only when clicked. Images are snapshots; a profile picture may be an avatar image fallback.", style="Muted.TLabel").pack(anchor="w")
        ttk.Label(pages["Notes"], text="Private notes on this computer · saved by exact account ID · never uploaded to VRChat or a whisper relay", wraplength=940).pack(anchor="w")
        self.notes = tk.Text(pages["Notes"], height=16, wrap="word", undo=True, bg=self.app.PANEL, fg=self.app.TEXT, insertbackground=self.app.TEXT)
        self.notes.pack(fill="both", expand=True, pady=8)
        ttk.Button(pages["Notes"], text="Save local notes", command=self.save_notes,
                   state="normal" if self.user_id and not self.app.demo else "disabled").pack(anchor="e")
        ttk.Button(pages["Notes"],text='Saved VRCX fields and annotations…',command=lambda:__import__('native_saved_details').show(self.app.sidebar,'friend',self.user_id),
                   state='normal' if self.user_id and not self.app.demo else 'disabled').pack(anchor='e')
        if not self.user_id or self.app.demo: self.notes.configure(state="disabled")
        ttk.Label(pages["JSON"], text="Filtered received JSON with source timestamps. Credential/account-recovery fields and join nonces are excluded.\n"
                  "Local notes and whisper secrets are never included.", wraplength=940).pack(anchor="w")
        ttk.Button(pages["JSON"], text="Save filtered JSON…", command=self.export_json).pack(anchor="e")
        self.json_view = self.text_area(pages["JSON"])
        self.account_page = pages["Account"]
        self.build_account(self.account_page)
        from peer_profile_link import PeerWhisperPane
        self.whisper = PeerWhisperPane(self, pages["Whisper"])

    def build_account(self, parent):
        ttk, tk = self.ttk, self.tk
        ttk.Label(parent, text="Edit your signed-in account and avatars you own", style="Accent.TLabel").pack(anchor="w")
        ttk.Label(parent, text="Status is VRChat's joinability/privacy preference; it does not change an instance's access rules.\n"
            "Load settings before editing. Only changed fields are sent. A canceled/failed write may already have reached VRChat; refresh before retrying.", wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=6)
        row = ttk.Frame(parent); row.pack(fill="x")
        self.button(row, "Load my settings", lambda: self.load_section("account"), own=True)
        self.button(row, "Load my credits", lambda: self.load_section("credits"), own=True)
        self.credit_text = tk.StringVar(value="Credits: not loaded · own account only.")
        ttk.Label(row, textvariable=self.credit_text).pack(side="right")
        self.edit_vars = {key: tk.StringVar() for key in ("status", "statusDescription", "pronouns", "isBoopingEnabled", "hasSharedConnectionsOptOut", "hasDiscordFriendsOptOut")}
        self.account_fields, self.avatar_fields = [], []
        fields = ttk.Frame(parent); fields.pack(fill="x", pady=8)
        for index, (key, label) in enumerate((("status", "Status / joinability"), ("statusDescription", "Status text (32 characters)"),
                ("pronouns", "Pronouns (32 characters)"), ("isBoopingEnabled", "Allow boops"),
                ("hasSharedConnectionsOptOut", "Opt out of mutual connections"), ("hasDiscordFriendsOptOut", "Opt out of Discord friend connections"))):
            ttk.Label(fields, text=label).grid(row=index, column=0, sticky="w", padx=(0, 10), pady=2)
            if key == "status":
                entry = ttk.Combobox(fields, textvariable=self.edit_vars[key], values=tuple(STATUSES), state="readonly", width=45)
            elif key in ("statusDescription", "pronouns"):
                entry = ttk.Entry(fields, textvariable=self.edit_vars[key], width=48)
            else:
                entry = ttk.Combobox(fields, textvariable=self.edit_vars[key], values=("Unchanged", "Yes", "No"), state="readonly", width=45)
            entry.grid(row=index, column=1, sticky="ew", pady=2)
            self.account_fields.append((entry, "normal" if key in ("statusDescription", "pronouns") else "readonly"))
        row = ttk.Frame(parent); row.pack(fill="x")
        self.button(row, "Save my status / privacy", self.save_account, own=True)
        ttk.Label(parent, text="Owned avatar metadata · name, description, public/private status and tags", style="Accent.TLabel").pack(anchor="w", pady=(12, 4))
        row = ttk.Frame(parent); row.pack(fill="x")
        self.avatar_id = tk.StringVar()
        self.avatar_id_entry = ttk.Entry(row, textvariable=self.avatar_id, width=55)
        self.avatar_id_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.button(row, "Load owned avatar", self.load_owned, own=True)
        fields = ttk.Frame(parent); fields.pack(fill="x", pady=5)
        self.avatar_vars = {key: tk.StringVar() for key in ("name", "description", "releaseStatus", "tags")}
        for index, key in enumerate(self.avatar_vars):
            ttk.Label(fields, text={"releaseStatus": "Public / private", "tags": "Tags (comma separated)"}.get(key, key.title())).grid(row=index, column=0, sticky="w", padx=(0, 10), pady=2)
            entry = (ttk.Combobox(fields, textvariable=self.avatar_vars[key], values=("public", "private"), state="readonly", width=66)
                     if key == "releaseStatus" else ttk.Entry(fields, textvariable=self.avatar_vars[key], width=69))
            entry.grid(row=index, column=1, sticky="ew", pady=2)
            self.avatar_fields.append((entry, "readonly" if key == "releaseStatus" else "normal"))
        row = ttk.Frame(parent); row.pack(fill="x")
        self.button(row, "Save owned avatar info", self.save_avatar, own=True)
        self.avatar_edit_status = tk.StringVar(value="Load an owned avtr_ ID or official avatar page first. Changing the ID requires another ownership check.")
        ttk.Label(parent, textvariable=self.avatar_edit_status, wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=6)

    def connected(self, action):
        if self.closed or not self.user_id or self.app.demo: return
        if not self.app.api or not self.app.api.authenticated:
            from online_dialog import show_connection_dialog
            show_connection_dialog(self.app, lambda: action() if not self.closed else None)
        else: action()

    def start(self, function, apply, *, mutation=False):
        if self.closed: return
        self.sync_context()
        if self.job: return
        context = self.context()
        if not context[-1]: return
        stop, output, progress = threading.Event(), queue.Queue(maxsize=1), ["Queued; VRChat metadata requests share a 60-second interval…"]
        self.job = (context, stop, output, progress, apply, mutation)
        self.app.transfer_stops.append(stop)
        self.controls()
        self.status.set(progress[0])
        def worker():
            try:
                value = function(context[0], stop, lambda text: progress.__setitem__(0, text))
                output.put((value, ""))
            except (APIError, ValueError, OSError) as error:
                output.put((None, str(error)))
            finally:
                if stop in self.app.transfer_stops: self.app.transfer_stops.remove(stop)
        threading.Thread(target=worker, daemon=True).start()

    def load_section(self, section, offset=0, group=None):
        if self.job: return
        def run():
            self.start(lambda client, stop, progress: player_api.read_section(client, self.user_id, section,
                offset=offset, group=group, stop=stop, progress=progress), self.accept_section)
        self.connected(run)

    def accept_section(self, snapshot):
        if snapshot.user_id != self.user_id: raise ValueError("Player ID mismatch.")
        key = snapshot.section + (f":{snapshot.offset}" if snapshot.section in ("mutuals", "favorite-lists", "avatars") else "")
        if snapshot.offset == 0:
            for old in [k for k, v in self.sections.items() if v.section == snapshot.section]: self.sections.pop(old)
        self.sections[key] = snapshot
        if isinstance(snapshot.data, list):
            current = self.collections.get(snapshot.section, []) if snapshot.offset else []
            self.collections[snapshot.section] = (current + snapshot.data)[:2000]
            self.show_collection(snapshot.section)
        elif snapshot.section == "favorite-items":
            self.collections[snapshot.section] = snapshot.data["favorites"]
            self.show_collection(snapshot.section)
        if snapshot.section == "account" and self.is_own():
            self.account_baseline = snapshot.data.copy()
            self.fill_account()
        if snapshot.section == "credits": self.credit_text.set("Credits: " + str(snapshot.data["balance"]) + " · " + snapshot.checked_at)
        data = merged_profile(self.sections)
        service = getattr(self.app, "player_sessions", None)
        if service: service.accept_profile(snapshot)
        keep_names = service is None or (service.storing and service.local.get(self.user_id,{}).get("save_history",True))
        if self.user_id and keep_names and isinstance(data.get("displayName"), str):
            try: self.store.observe_name(self.user_id, data["displayName"], snapshot.checked_at)
            except (OSError, sqlite3.Error): pass
        if snapshot.section in ("public", "account", "import"):
            try:
                slim = dict(data)
                if "trustTags" in slim: slim["tags"] = slim["trustTags"]
                record = parse_user_platform(json.dumps(slim), self.user_id, allow_missing=True)
                from dataclasses import replace
                record = replace(record, origin="VRChat API" if snapshot.section != "import" else "Imported user JSON", imported_at=snapshot.checked_at)
                self.app.player_platforms[self.user_id] = record
                self.app.refresh_player_cells(); self.view.draw()
            except ValueError: pass
        self.render()

    def is_own(self):
        return bool(self.user_id and self.app.api and self.app.api.authenticated and self.app.api.user_id == self.user_id)

    def controls(self):
        for button, own in self.network_buttons:
            enabled = not self.job and self.user_id and not self.app.demo and (not own or self.is_own())
            button.configure(state="normal" if enabled else "disabled")
        self.cancel_button.configure(state="normal" if self.job else "disabled")
        own = self.is_own() and not self.app.demo and not self.job
        self.avatar_id_entry.configure(state="normal" if own else "disabled")
        for widget, ready in self.account_fields:
            widget.configure(state=ready if own and self.account_baseline is not None else "disabled")
        for widget, ready in self.avatar_fields:
            widget.configure(state=ready if own and self.avatar_snapshot is not None else "disabled")

    def cancel(self):
        job, self.job = self.job, None
        if job:
            job[1].set()
            self.status.set("Canceled. A write may already have reached VRChat; refresh before retrying." if job[5] else "Request canceled.")
        self.controls()

    def sync_context(self):
        context = self.context()
        if context != self.connection:
            __import__('text_translation_ui').close_for(self)
            self.cancel()
            self.connection = context
            self.store=PlayerStore.for_app(self.app);self.loaded_note=''
            self.notes.delete('1.0','end')
            if self.user_id and not self.app.demo:
                self.loaded_note=self.store.note(self.user_id);self.notes.insert('1.0',self.loaded_note)
            self.sections.clear(); self.collections.clear(); self.collection_rows.clear()
            self.account_baseline = self.avatar_snapshot = None
            self.whisper.close()
            self.photos.clear()
            for label in self.image_labels.values(): label.configure(image="", text="No preview loaded")
            self.credit_text.set("Credits: refresh your own account.")
            for var in (*self.edit_vars.values(), *self.avatar_vars.values()): var.set("")
            self.render()
            self.show_collection("")
            self.status.set("Connection or log session changed. Refresh profile; local notes remain on this computer.")
        return context

    def tick(self):
        if self.closed: return
        service = getattr(self.app, "player_sessions", None)
        hidden = bool(service and service.settings["presentation"])
        if hidden:
            __import__('text_translation_ui').close_for(self)
            if not getattr(self, "presentation_hidden", False): self.window.withdraw()
            self.presentation_hidden = True
            self.timer = self.app.root.after(200, self.tick)
            return
        if getattr(self, "presentation_hidden", False):
            self.presentation_hidden = False
            self.window.deiconify()
        self.sync_context()
        if self.job:
            job_context, stop, output, progress, apply, mutation = self.job
            try: result, error = output.get_nowait()
            except queue.Empty: self.status.set(progress[0])
            else:
                self.job = None
                if not stop.is_set() and job_context == self.context():
                    if error:
                        self.status.set(error + (" A write may already have reached VRChat; refresh before retrying." if mutation else ""))
                    else:
                        try:
                            apply(result)
                            self.status.set("Request completed. Displayed values are snapshots; see JSON for source times.")
                        except (ValueError, APIError, self.tk.TclError) as error:
                            self.status.set(str(error))
        self.controls()
        self.whisper.tick()
        self.timer = self.app.root.after(200, self.tick)

    def render(self):
        data = merged_profile(self.sections)
        record = self.app.player_platforms.get(self.user_id)
        self.set_text(self.summary, summary_text(data, local_name=self.row.name, platform=record.label if record else "Unknown"))
        socials = ["Reported badges (not a claim of all earned badges)"]
        badges = data.get("badges")
        if isinstance(badges, list):
            socials.extend(f"• {scalar(v, 'badgeName')} · {scalar(v, 'badgeDescription')} · assigned {scalar(v, 'assignedAt')}" for v in badges if isinstance(v, dict))
            if not badges: socials.append("None returned.")
        else: socials.append(UNKNOWN)
        group = data.get("representedGroup")
        socials += ["\nRepresented group", json.dumps(group, ensure_ascii=False, indent=2) if group is not None else UNKNOWN]
        for key, title in (("groups", "Visible joined groups"), ("mutuals", "Returned mutual friends")):
            rows = self.collections.get(key)
            socials += ["\n" + title, f"{len(rows)} loaded (may be partial / privacy-filtered). See Collections." if rows is not None else "Not loaded. Use the buttons above."]
        self.set_text(self.social, "\n".join(socials))
        local = [self.local_details, "\nVisible API activity (snapshot)"]
        local.extend(f"{key}: {scalar(data, key)}" for key in ("state", "last_activity", "last_login", "last_mobile", "location"))
        roster = self.view.log_roster()
        visits = [v for v in roster.visits if self.user_id and v.user_id == self.user_id]
        seconds, completed = 0, 0
        for visit in visits:
            start, end = log_epoch(visit.joined), log_epoch(visit.left or roster.ended)
            if start is not None and end is not None and end >= start:
                seconds += end-start
                completed += 1
        observed_time = f"{int(seconds)//3600}h {int(seconds)%3600//60}m {int(seconds)%60}s ({completed} complete visits)" if completed else "Unavailable (no complete timed visits)"
        local += ["\nCompleted observed time in this world/log: " + observed_time,
                  "This is observed shared time, not their lifetime playtime. Missing/ongoing visits are excluded.", "\nObserved avatar changes in the loaded log"]
        events = [e for e in self.app.events if self.user_id and e.user_id == self.user_id][-100:]
        local.extend(f"{e.timestamp} · {e.avatar}" for e in events)
        if not events: local.append("No exact-ID avatar changes retained.")
        local += ["\nPrevious display names observed locally (not login usernames or a complete history)"]
        if self.user_id and not self.app.demo:
            try: local.extend(f"{name} · first {first} · last {last}" for name, first, last in self.store.names(self.user_id))
            except (OSError, sqlite3.Error): local.append("Could not read local history.")
        if self.is_own() and isinstance(data.get("pastDisplayNames"), list):
            local += ["\nOwn account's returned display-name history", json.dumps(data["pastDisplayNames"], ensure_ascii=False, indent=2)]
        self.set_text(self.activity, "\n".join(local))
        self.link_values = profile_links(data, self.user_id) if self.user_id else []
        children = self.links.get_children()
        if children: self.links.delete(*children)
        for index, value in enumerate(self.link_values): self.links.insert("", "end", iid=str(index), values=value)
        raw = self.json_text()
        self.set_text(self.json_view, raw if len(raw) <= 2*1024*1024 else "Display truncated at 2 MiB; use Save filtered JSON for the complete snapshot.\n\n" + raw[:2*1024*1024])

    def json_text(self):
        return json.dumps({"userId": self.user_id, "filtered": True, "sections": [dict(source=s.section, checked_at=s.checked_at,
            offset=s.offset, more=s.more, data=s.data) for s in self.sections.values()]}, ensure_ascii=False, indent=2)

    def import_json(self):
        from tkinter import filedialog, messagebox
        if not self.user_id or self.app.demo: return
        path = filedialog.askopenfilename(parent=self.window, title="Import matching player/profile JSON", filetypes=[("JSON", "*.json")])
        if not path: return
        try:
            with Path(path).open("rb") as stream: raw = stream.read(2*1024*1024+1)
            result = read_profile_json(raw.decode("utf-8-sig"), self.user_id)
            self.cancel(); self.accept_section(result)
            self.status.set("Imported matching profile snapshot; this does not establish current values or editing permission.")
        except (OSError, ValueError, UnicodeError) as error: messagebox.showerror("Profile import", str(error), parent=self.window)

    def export_json(self):
        from tkinter import filedialog, messagebox
        path = filedialog.asksaveasfilename(parent=self.window, title="Save filtered profile JSON", defaultextension=".json", initialfile="player-profile.json")
        if path:
            try:
                with Path(path).open("x", encoding="utf-8") as stream: stream.write(self.json_text())
            except OSError: messagebox.showerror("JSON save", "Could not save; choose a new filename and writable folder.", parent=self.window)

    def open_link(self):
        chosen = self.links.selection()
        if chosen:
            try: self.open_url(self.link_values[int(chosen[0])][1])
            except (IndexError, ValueError): pass

    def open_url(self, value):
        if not safe_link(value): return
        import webbrowser
        from tkinter import messagebox
        try:
            if not webbrowser.open(value): raise OSError
        except (OSError, webbrowser.Error): messagebox.showerror("Open link", "Could not open the URL in your browser.", parent=self.window)

    def load_images(self):
        from profile_images import fetch_preview
        values = [(kind, url) for kind, url in self.link_values if kind in self.image_labels]
        if not values:
            self.status.set("No image URLs supplied. Refresh profile first."); return
        def worker(client, stop, progress):
            results = {}
            for kind, url in values:
                client._check(stop); progress("Loading " + kind.lower() + "…")
                try: results[kind] = fetch_preview(client, url, stop=stop)
                except APIError as error: results[kind] = str(error)
            return results
        def apply(results):
            self.photos.clear()
            for kind, value in results.items():
                if isinstance(value, str): self.image_labels[kind].configure(image="", text=value); continue
                photo = self.tk.PhotoImage(data=base64.b64encode(value).decode(), master=self.window)
                factor = max(1, math.ceil(photo.width()/300), math.ceil(photo.height()/180))
                if factor > 1: photo = photo.subsample(factor)
                self.photos.append(photo); self.image_labels[kind].configure(image=photo, text="")
        self.connected(lambda: self.start(worker, apply))

    def kind(self):
        return {"Groups": "groups", "Mutual friends": "mutuals", "Favorite lists": "favorite-lists", "My uploaded avatars": "avatars"}.get(self.collection_kind.get(), "groups")

    def load_collection(self): self.load_section(self.kind())

    def next_page(self):
        kind = self.kind()
        pages = [s for s in self.sections.values() if s.section == kind]
        if not pages or not max(pages, key=lambda s: s.offset).more:
            self.status.set("No next page reported. Load this collection first."); return
        last = max(pages, key=lambda s: s.offset)
        if last.offset >= 1900:
            self.status.set("Collection reached this window's 2,000-row limit."); return
        self.load_section(kind, last.offset + player_api.PAGE)

    def show_collection(self, kind):
        children = self.table.get_children()
        if children: self.table.delete(*children)
        self.collection_rows.clear()
        for index, item in enumerate(self.collections.get(kind, [])):
            if not isinstance(item, dict): continue
            data = item.get("world") or item.get("avatar") or item
            if not isinstance(data, dict): continue
            reference = data.get("groupId") or data.get("id") or ""
            name = data.get("displayName") or data.get("name") or "Unnamed"
            detail = data.get("visibility") or data.get("memberVisibility") or data.get("releaseStatus") or ""
            key = str(index); self.collection_rows[key] = (kind, item, data)
            self.table.insert("", "end", iid=key, values=(data.get("type", kind), name, reference, detail))

    def load_favorite(self):
        chosen = self.table.selection()
        selected = self.collection_rows.get(chosen[0]) if chosen else None
        if not selected or selected[0] != "favorite-lists":
            self.status.set("Load Favorite lists and select a returned world/avatar list first."); return
        self.load_section("favorite-items", group=selected[1])

    def open_collection_link(self):
        chosen = self.table.selection(); selected = self.collection_rows.get(chosen[0]) if chosen else None
        if not selected: return
        data = selected[2]; reference = data.get("groupId") or data.get("id", "")
        import re
        match = re.fullmatch(r"(usr|grp|wrld|avtr)_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", reference) if isinstance(reference, str) else None
        if match:
            section = {"usr": "user", "grp": "group", "wrld": "world", "avtr": "avatar"}[match[1]]
            self.open_url(f"https://vrchat.com/home/{section}/{reference}")

    def save_notes(self):
        if not self.user_id or self.app.demo: return True
        try:
            if self.context()!=self.connection:raise ValueError('The account changed. Reopen the profile before editing its notes.')
            text = self.notes.get("1.0", "end-1c")
            from account_actions import local_writable
            from account_header import private
            local_writable(self.app)
            if private(self.app):raise ValueError('Reveal private information before editing notes.')
            view=getattr(self.store,'_note_views',{}).get(self.user_id)
            if view and view.pending:
                from shared_notes import review_text
                from creator_projects_ui import review_document
                if not review_document(self.app,'Review earlier notes',review_text(view,text),accept='Save this shared note'):return False
            def current():
                if self.context()!=self.connection or private(self.app):raise ValueError('Account or privacy changed. Reopen notes.')
                local_writable(self.app)
            self.store.save_note(self.user_id, text, reconcile=True, guard=current)
            service = getattr(self.app, "player_sessions", None)
            if service: service.refresh_local()
            self.loaded_note = text
            self.status.set("Notes saved locally. Nothing was sent to VRChat or a relay.")
            return True
        except (OSError, sqlite3.Error, ValueError) as error:
            from tkinter import messagebox
            messagebox.showerror("Local notes", "Could not save local notes: " + str(error), parent=self.window)
            return False

    def forget_names(self):
        from tkinter import messagebox
        if self.user_id and not self.app.demo and messagebox.askyesno("Forget names", "Delete this account's locally observed name history?", parent=self.window):
            try: self.store.forget_names(self.user_id); self.render()
            except (OSError, sqlite3.Error): self.status.set("Could not remove the local name history.")

    def boop(self):
        from tkinter import messagebox
        def run():
            if messagebox.askyesno("Send boop", f"Send one VRChat boop to {self.row.name}? VRChat checks friendship and boop preferences.", parent=self.window):
                self.start(lambda client, stop, progress: player_api.send_boop(client, self.user_id, stop=stop, progress=progress),
                           lambda result: self.set_text(self.social, result), mutation=True)
        self.connected(run)

    def fill_account(self):
        data = self.account_baseline
        for key, var in self.edit_vars.items():
            if key == "status": var.set(next((label for label, raw in STATUSES.items() if raw == data.get(key)), ""))
            elif key in ("statusDescription", "pronouns"): var.set(data[key] if isinstance(data.get(key), str) else "")
            else: var.set("Yes" if data.get(key) is True else "No" if data.get(key) is False else "Unchanged")
        if not self.avatar_id.get() and isinstance(data.get("currentAvatar"), str): self.avatar_id.set(data["currentAvatar"])

    def save_account(self):
        from tkinter import messagebox
        self.sync_context()
        if not self.is_own() or self.account_baseline is None:
            self.status.set("Load your own settings before saving."); return
        try:
            values = {}
            for key, var in self.edit_vars.items():
                text = var.get()
                if key == "status":
                    if text not in STATUSES: continue
                    value = STATUSES[text]
                elif key in ("statusDescription", "pronouns"): value = text
                else:
                    if text == "Unchanged": continue
                    value = text == "Yes"
                if key not in self.account_baseline and value == "": continue
                if self.account_baseline.get(key) != value: values[key] = value
            if not values: self.status.set("No account fields changed."); return
            values = self_patch(values)
            if not messagebox.askyesno("Save my account", "Apply these changes to your signed-in account?\n\n" + json.dumps(values, ensure_ascii=False, indent=2), parent=self.window): return
            self.start(lambda client, stop, progress: player_api.update_self(client, self.user_id, values, stop=stop, progress=progress), self.accept_section, mutation=True)
        except ValueError as error: self.status.set(str(error))

    def load_owned(self):
        if not self.is_own(): return
        reference = self.avatar_id.get()
        self.start(lambda client, stop, progress: player_api.owned_avatar(client, reference, stop=stop, progress=progress), self.accept_avatar)

    def accept_avatar(self, result):
        if parse_avatar_reference(self.avatar_id.get()) != result["data"]["id"]:
            raise ValueError("The avatar ID field changed. Load the intended avatar again.")
        self.avatar_snapshot = result
        for key, var in self.avatar_vars.items():
            value = result["data"].get(key, "")
            var.set(", ".join(v for v in value if isinstance(v, str)) if key == "tags" and isinstance(value, list) else value if isinstance(value, str) else "")
        self.avatar_edit_status.set("Ownership checked for " + result["data"]["id"] + ". Valid for five minutes on this account.")
        reference = result["data"]["id"]
        self.app.asset_exports.pop(reference, None); self.app.asset_selections.pop(reference, None)
        self.app.online_visibility.pop(reference, None); self.app.visibility.pop(reference, None)
        self.app.downloads.pop(reference, None)
        self.app.refresh_visibility_cells()

    def save_avatar(self):
        from tkinter import messagebox
        self.sync_context()
        if not self.is_own() or self.avatar_snapshot is None:
            self.status.set("Load an owned avatar first."); return
        try:
            reference = parse_avatar_reference(self.avatar_id.get())
            if reference != self.avatar_snapshot["data"]["id"]: raise ValueError("Avatar ID changed. Load it again.")
            values = {}
            for key, var in self.avatar_vars.items():
                value = [v.strip() for v in var.get().split(",") if v.strip()] if key == "tags" else var.get()
                if value != self.avatar_snapshot["data"].get(key): values[key] = value
            if not values: self.status.set("No avatar fields changed."); return
            values = avatar_patch(values)
            if not messagebox.askyesno("Save owned avatar", f"Apply these changes to {reference}?\n\n" + json.dumps(values, ensure_ascii=False, indent=2), parent=self.window): return
            snapshot = self.avatar_snapshot
            self.start(lambda client, stop, progress: player_api.update_owned_avatar(client, snapshot, values, stop=stop, progress=progress), self.accept_avatar, mutation=True)
        except ValueError as error: self.status.set(str(error))

    def close(self):
        if self.closed: return True
        if self.user_id and not self.app.demo and self.notes.get("1.0", "end-1c") != self.loaded_note and not self.save_notes():
            return False
        self.cancel(); self.whisper.close()
        __import__('text_translation_ui').close_for(self)
        self.closed = True
        if self.timer is not None: self.app.root.after_cancel(self.timer)
        self.sections.clear(); self.photos.clear(); self.avatar_snapshot = None
        for key, window in tuple(getattr(self.app, "player_profile_windows", {}).items()):
            if window is self: self.app.player_profile_windows.pop(key)
        self.window.destroy()
        return True
