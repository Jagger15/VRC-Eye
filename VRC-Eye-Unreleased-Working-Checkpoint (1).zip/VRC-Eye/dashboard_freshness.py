"""Source age is independent of Home repaint time; never starts a provider."""
import math
import time
from copy import deepcopy


def label(age=None, *, stale=False, available=True):
    if not available:return 'Unavailable / not observed'
    if type(age) not in (int,float) or not math.isfinite(age) or age<0:return 'Age unknown'
    return ('Stale' if stale else 'Observed') + f' · {int(age)}s ago'


def observations(shell, media, health, samples):
    result={}
    def add(key,age,stale,available,ttl,note=''):
        result[key]=dict(age=age,stale=stale,available=available,ttl=ttl,note=note)
    page=shell.pages.get('Media & Audio')
    row=next((r for r in media.get('sources',()) if r.id==media.get('selected')),None)
    add('media',page.service.clock()-row.observed if row and page else None,media.get('current') is None,row is not None,6)
    add('health',health.get('age'),health.get('stale',True),health.get('data') is not None,300)
    sample=samples.get('performance',{})
    note=' · unused optional sensors at 30s' if any(v>5 for v in sample.get('auxiliary_cadence',{}).values()) else ''
    add('performance',sample.get('age'),sample.get('stale',True),sample.get('sample') is not None,5,note)
    add('applications',sample.get('age'),sample.get('stale',True),bool(getattr(sample.get('sample'),'applications',())),5)
    for key,title in (('runtime','Unity Player'),('diagnostics','Crash & Diagnostics')):
        page=shell.pages.get(title);sample=samples.get(key,{})
        stamp=sample.get('process_at');age=page.service.clock()-stamp if page and stamp is not None else None
        available=stamp is not None and sample.get('enabled',True)
        add(key,age,age is None or age>5 or not available,available,5)
    return result


def labels(observed,elapsed=0):
    result={}
    for key,item in observed.items():
        age=item['age'];age=age+elapsed if type(age) in (int,float) else None
        stale=item['stale'] or age is None or age>item['ttl']
        result[key]=label(age,stale=stale,available=item['available'])+item.get('note','')
    return result


def sources(shell,media,health):
    page=shell.pages.get('Performance & Security')
    return labels(observations(shell,media,health,{'performance':page.service.snapshot() if page else {}}))


def aged(projection,*,now=None):
    """Age a frozen projection without polling or falsely refreshing its sources."""
    result=deepcopy(projection)
    if 'observations' not in result:return result
    elapsed=max(0,(time.monotonic() if now is None else now)-result['captured'])
    result['sources']=labels(result['observations'],elapsed)
    for rows in result.get('widgets',{}).values():
        for row in rows:
            source=row.get('freshness_source')
            if source in result['sources']:
                row['freshness']=result['sources'][source]
                if row['freshness'].startswith('Stale') and source in ('health','runtime','diagnostics','applications'):
                    row['status']='Stale / unknown'
    return result
