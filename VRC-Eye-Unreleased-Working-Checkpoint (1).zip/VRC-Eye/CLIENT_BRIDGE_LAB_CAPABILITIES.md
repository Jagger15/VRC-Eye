# VRC Eye 1.19.8 — Client Bridge Lab implementation matrix

Status meanings: **implemented** means VRC Eye's code path exists and is tested with controlled inputs. **Provider required** means actual runtime observations/effects require a compatible, separately supplied integration. Neither status means live VRChat compatibility or platform approval.

| Supplied design area | Implemented in 1.19.8 | Remaining boundary |
| --- | --- | --- |
| Deep self-avatar diagnostics | Own-avatar bounded transition timeline, typed phase/tracking/posture/configuration observations, freshness, context and overhead | Provider required; no automatic posture diagnosis or arbitrary runtime object browser |
| Parameter experiments | One-value 1–60 second experiment, exact current/desired revision, requested/dispatched/acknowledged/observed trace, unknown writer, conditional restoration | Provider required for writes; no multi-step sequence runner, reusable preset library or automatic competing-controller identification |
| Local rendering/audio isolation | Named exposure-reducing changes against advertised targets, baseline/applied/restored metric separation | Provider required; single-sample correlation, not statistical profiling or causal attribution |
| Integration conflict isolation | Eligible diagnostic/overlay/input module inventory and bounded pause/restore, version/config revision | Provider required; protected and unknown modules cannot be paused |
| Targeted recovery | Four named integration-owned operations, correlated new telemetry and healthy-state milestones | Provider required; no arbitrary client repair or universal restart |
| Creator-authorized diagnostics | Bounded manifest, typed fields, explicit review, expiring reported authority, exact named shared-test control | Provider required; no new Udon transport or SDK installer; authorization and completion remain provider-reported |
| API/runtime consistency | Hook into existing account.get/avatar.get results, account/time/cache distinctions, provider and available OSC context | No extra API request, automatic repair, credential export or guarantee of simultaneous snapshots |
| Cooperative playtest comparison | Closed data-only card, category opt-in, current-context Eye-to-Eye validation, recipient acceptance, import/export, uncertainty-aware comparison | Existing paired peer/shared context required for live sending; no silent collection or measured cross-clock synchronization |
| Reviewed capability definitions | Seven telemetry plus six action schemas, strict unknown-field/type/size rejection, per-capability grants, SDK recheck | A reviewed contract is not certification of a particular external provider |
| Real experiment lifetime | Single-use expiring review; account/runtime/avatar/world/configuration/permission binding; provider-owned lease contract | External provider must enforce atomic CAS and expiry; disconnect may leave restoration unconfirmed |
| Reports and offline inspection | Previewed sanitized report export, bounded capture/drop counters, Replay data-only report view, six Sandbox failure scenarios | New Client Lab Replay does not execute a complete captured bridge-event sequence |

## Capability catalog

All rows use capability version 1 and review revision `client-bridge-lab-1`. Live compatibility is unverified. Unknown capabilities never inherit Developer permission.

| Capability | Kind | Scoped effect |
| --- | --- | --- |
| `lab.context` | telemetry | Experiment context and capture cost |
| `lab.self_avatar` | telemetry | Own-avatar initialization and transition timeline |
| `lab.parameters` | telemetry | Own-avatar parameter observations and write attribution |
| `lab.presentation` | telemetry | Local presentation observations |
| `lab.modules` | telemetry | Integration-owned module inventory |
| `lab.health` | telemetry | Integration recovery health evidence |
| `lab.creator` | telemetry | Creator-exposed manifest and diagnostics |
| `lab.parameter_set` | action | Temporary own-avatar custom parameter experiment |
| `lab.presentation_reduce` | action | Temporary exposure-reducing local presentation test |
| `lab.module_pause` | action | Temporary pause of an eligible integration module |
| `lab.recover` | action | Named integration-only recovery |
| `lab.creator_action` | action | Individually reviewed creator playtest control |
| `lab.restore` | action | Compare-and-restore an existing experiment lease |

The seven observation channels are classified as read-only diagnostics. Actions retain distinct effect classes: local presentation, own-avatar state, integration-owned state or creator-defined shared test action. This implementation marks state-changing lab actions as experimental/Extremely Risky because external compatibility and restoration are not validated; it does not apply that action label to every read-only connection.

## Existing surfaces retained

The original API Workbench catalog remains 58 entries (37 reads, 18 writes, three reference-only), with its original action review and shared API pacing. Existing OSC controls, world/avatar creator tools, VRCX Companion Mode, Runtime Companion, Black Box, Safety, wellness and Eye-to-Eye services are not replaced by independent lab implementations. The new optional bridge settings pane links to the existing connection manager.

No application patching, anti-tamper evasion, credential extraction, asset extraction, private-location discovery, remote control of nonconsenting people, ownership spoofing, unrestricted execution or disruptive traffic is implemented by this update.

## Source and useful entry points

The supplied proposal is preserved byte-for-byte in `CLIENT_BRIDGE_LAB_DESIGN_INPUT.md`. It is the roadmap source, not an implementation-complete label. The guide documents operation and limits. `client_bridge_lab_contracts.json` is a data-only reference with synthetic examples, not a dynamic command loader. `bridge_lab_fixture.py` is the executable isolated provider model; `bridge_sdk.py` is the existing authenticated provider interface extended with lab preconditions.
