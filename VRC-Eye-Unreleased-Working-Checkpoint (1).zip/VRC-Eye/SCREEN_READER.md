# Screen reader

Unreleased source checkpoint, retaining build **2026.05.10.02.47.1** and compatibility **1.21.0**.

VRC Eye now has a local built-in screen reader, a keyboard reading view, and optional Windows/Linux accessibility providers. The built-in workflow is implemented and has portable behavior tests. Actual NVDA, Narrator, Orca, braille/caret interaction and graphical desktop acceptance are **not certified by this checkpoint**. See `SCREEN_READER_QUALIFICATION.json` for the exact execution record.

## Start and stop

Use the permanent **Screen reader** header button, or **Accessibility → Screen reader**. These controls are available before sign-in. No VRChat account, microphone, model download or cloud service is required.

Reader mode starts **Off**. Choose **Built-in speech** and Apply to use local speech, or **System screen reader** to expose the interface to an installed assistive tool without speaking navigation through the built-in engine. Reading view works even with speech off. An explicit **Test local voice** button speaks harmless sample controls in any mode.

On Windows, built-in speech uses installed SAPI voices through Windows PowerShell. On Linux, install the distribution's `espeak-ng` or `espeak` package. **List local voices** lists installed identifiers; leaving the voice field empty uses the engine default. Missing engines produce a readable status and leave Reading view available. Speech rate, volume, descriptions, focus announcements, status cadence, notification announcements, urgent interruptions and typing echo have separate controls.

Typing echo and non-secret text-field values start off. Characters/Words echo is opt-in. Ordinary keyboard editing continues to use Tk's existing behavior.

| Shortcut, inside VRC Eye | Action |
| --- | --- |
| Ctrl+Alt+F12 | Toggle built-in speech |
| Ctrl+Alt+F11 | Open Reading view |
| Ctrl+Alt+F10 | Stop current and queued reader speech |
| Ctrl+Alt+F9 / F8 | Read next / previous item |
| Ctrl+Alt+F7 | Read a bounded window overview |
| Ctrl+Alt+F6 | Read the focused control |
| Ctrl+Alt+F5 | Repeat the last utterance |

These are application-local function-key chords. They do not replace Tab, Enter, Escape, text editing, AltGr characters or a system reader's modifier keys. Reader commands pause while the navigation-shortcut capture dialog is collecting a chord.

## What is read

The shared semantic tree describes names, roles, enabled/disabled and checked/selected states, values, headings, groups, tabs, dialogs and relationships. It is rebuilt from the current visible window. Hidden pages and closed dialogs are excluded. Entry/Text field values require the relevant opt-in, and unlabelled editable fields are not guessed from their contents. Combo-box, numeric and selection values are read as control state, subject to protection/privacy settings.

Tables expose visible column headings and selected rows with each value preceded by its column name. Reading view can select a row, choose a combo-box option, switch a tab or invoke an existing sorting heading. A changed/replaced row receives a different accessible identity. Old references cannot activate a different replacement record.

Reading view has search, previous/next, a text detail area, explicit Focus control and Activate buttons, and Refresh. Reading never invokes a control. Activate calls the control's existing guarded command, retaining its validation, account checks and confirmations. Modal dialogs retain their grab, and closing Reading view returns it to the original dialog.

Long read-only text has successive 800-character parts. A projection is bounded to 2,500 semantic nodes and 500 rows/parts per source. Large projections report truncation; narrow the original page/table or navigate its pages to inspect further content. Window overview reads up to 16 items within a 3,000-character budget, then tells the user to continue with next item or Reading view. Speech is divided into bounded utterances; it does not accumulate an unbounded transcript.

Built-in mode uses Tk message and file-picker dialogs so their labels, choices and confirmation text remain in the same readable interface. The file picker supports folders, filename entry, type filters, single/multiple selection and save-path review. It only returns paths; the existing action still validates and performs any file operation. Off/System mode retains the original OS dialogs. Closing the reader restores the dialog functions it installed.

## Live updates and visual alternatives

Page completion/error status, sign-in status and shared application alerts can be announced without moving focus. Ordinary updates coalesce by source at the selected interval. Repeated progress samples replace older pending samples. Error interruptions can be disabled. Notification announcements retain the existing notification speech grant, quiet hours, DND, category mutes, batching, privacy and cooldown checks. The prior notification speech engine is not also used when reader output is selected; quiet/context transitions cancel pending reader notification output.

Resource, Unity-resource, incident-replay and population graphs expose summaries and observation rows derived from the same graph data. Summaries include range/current bounds, minima/maxima and evidence gaps. Existing activity-heatmap and mutual-graph tables remain the data alternatives. The reader does not estimate values from pixels.

Photo, outgoing-image, texture and 3D-model previews expose their available metadata and point to the associated details, hierarchy, material and mesh-health tables. No visual descriptions or identities are invented. Existing photo notes remain the place for user-written descriptions.

## Privacy and lifecycle

Masked fields, credential-labelled inputs, explicit protected regions and secret table columns are suppressed before speech or native projection. Mask protection remains attached to a field after its visual reveal control removes the mask. Passwords, tokens and verification-code fields never use typing echo. A field's textvariable is its value, never its inferred name.

Account/session, page, Demo/Safe, local-lock and presentation/privacy context changes invalidate the reader generation, discard queued speech, empty Reading view and invalidate native projections. Public navigation/settings labels remain available while private content is redacted. Workers receive only projected semantic data; they never read Tk variables. Native projections expire, and queued native actions have short deadlines and recheck the live context on the Tk thread.

No reading transcript is persisted. Speech uses literal stdin and a fixed process invocation, without a shell, temporary text file or interpolated script. The Windows SAPI request is JSON data and explicitly uses literal-text mode. Preference profiles contain only reader settings, never read text or credentials. Profile import is validated and reviewed; reset and session undo are provided. Demo and Safe mode keep preference changes session-only.

Privacy cannot erase speech already heard or information a third-party assistive tool has already received. System readers control their own speech/braille queues. VRC Eye clears its own pending output/projections and emits changes; this does not claim control over another program's caches.

## Native providers and qualification boundary

Windows source implements MSAA `IAccessible` semantics, hierarchy, hit testing, focus/selection/default actions and change/live-region notifications on this application's windows. Windows supplies the MSAA-to-UI-Automation compatibility path; this is not a separately qualified custom UIA provider. The `comtypes` dependency is explicit in `requirements.txt`.

Linux source registers an AT-SPI2 application on the local accessibility bus through `dbus-next`, exposing Accessible, Component, Action and read-only projected Text interfaces, plus structural/focus/selection/status events. Bus disconnection or missing desktop accessibility services leaves a recoverable status. No network listener or remote bus is created.

These providers do not claim complete native editing/caret/braille or two-dimensional table-cell interfaces. Native text editing continues through the ordinary focused widget's keyboard behavior; the built-in reading view provides the shared inspection/action workflow. Full interoperability needs task-based testing on the intended Windows and Linux desktops, with the actual assistive tools and their versions recorded.

This execution environment has no Windows runtime and rejects local Unix sockets, preventing an X server and accessibility bus from starting. Real-Tk acceptance tests are supplied and skip explicitly without a display. Portable AT-SPI interface/signature tests are not substitutes for an Orca session. An actual eSpeak process generated nonzero PCM speech from the harmless preview; no speaker/headphone output was tested.

The exact counts, exclusions, source hashes and remaining native gates are in `validation/screen-reader-summary.json`, `SCREEN_READER_QUALIFICATION.json` and `PENDING_WORKING_VALIDATION.json`. ARC/VRCX parity and VR-overlay accessibility are separate from this reader change.

Protocol references: [Microsoft WM_GETOBJECT](https://learn.microsoft.com/en-us/windows/win32/winauto/wm-getobject), [comtypes servers](https://comtypes.readthedocs.io/en/stable/server.html), [GNOME AT-SPI interfaces](https://gnome.pages.gitlab.gnome.org/at-spi2-core/devel-docs/xml-interfaces.html).
