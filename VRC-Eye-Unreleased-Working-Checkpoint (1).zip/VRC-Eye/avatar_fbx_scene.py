"""FBX inspection through a pinned native adapter, called after containment.

Geometry is the default stored pose, normalized by ufbx to meters/Y-up.
No filesystem access, shader execution or source rewriting. Selected take
samples are evaluated only inside the contained worker.
"""
from hashlib import sha256
from avatar_scene import Scene,SceneNode,ScenePart,name,vector,integer,transform,bounds,MAX_VERTICES,MAX_TRIANGLES
from avatar_scene_deform import affine
from avatar_scene_appearance import Material,parse as image_parse
from avatar_fbx_report import decode as report_decode
import avatar_mesh_health as health

_native=None


def preload():
    global _native
    try:import vrc_eye_ufbx
    except ImportError:raise ValueError('FBX preview needs the optional native adapter. Build it explicitly with: python -m pip install ./native/fbx (see ARC03_FBX_IMPORT.md).') from None
    if getattr(vrc_eye_ufbx,'ADAPTER_VERSION',None)!=2 or getattr(vrc_eye_ufbx,'UFBX_VERSION',None)!='0.23.1':
        raise ValueError('FBX preview requires Eye adapter 2 with ufbx 0.23.1. Rebuild the pinned native/fbx source.')
    _native=vrc_eye_ufbx


def parse(source,selected=None,*,sample=None,texture_cache=None):
    if _native is None:raise ValueError('FBX importer was not bootstrapped before containment.')
    selected={} if selected is None else selected
    raw=_native.snapshot(source,*(sample or ()))
    texture_cache={} if texture_cache is None else texture_cache
    report=dict(version=raw['version'],ascii=raw['ascii'],unit_meters=raw['units'],axes=raw['axes'],fps=raw['fps'],bones=raw['bones'],meshes=[],takes=[],dependencies=[],warnings=raw['warnings'])
    if raw['unsupported']:raise ValueError('FBX contains curves/NURBS/procedural geometry outside this polygon preview subset.')
    nodes=[];pending={row['id']:row for row in raw['nodes']};known={}
    while pending:
        ready=[i for i,r in pending.items() if r['parent']==-1 or r['parent'] in known]
        if not ready:raise ValueError('Invalid FBX hierarchy.')
        for i in ready:
            row=pending.pop(i);known[i]=row
            nodes.append(SceneNode(i,row['parent'],name(row['name'],'FBX root'),affine(row['matrix'])))
    meshes={m['id']:m for m in raw['meshes']}
    for m in meshes.values():
        if m['caches']:raise ValueError('FBX vertex caches are not evaluated; export a self-contained polygon snapshot.')
        report['meshes'].append((name(m['name'],'FBX mesh'),m['vertices'],m['faces'],m['skins'],m['channels'],m['targets'],m['caches']))
    report['takes']=[(name(t['name'],'Unnamed take'),t['start'],t['end'],t['layers']) for t in raw['takes']]
    textures=[];texture_refs={};texture_rows={};staged_used=set();pixels=0
    for i,t in enumerate(raw['textures']):
        ref=t['filename'];label=name(ref.replace('\\','/').split('/')[-1],name(t['name'],'Unnamed texture'))
        data=t['content'];state='embedded' if data else 'missing'
        # Only plain exact names may bind to user-selected bytes. Arbitrary
        # directories, traversal, drive names and URLs are never resolved.
        if not data and (not ref or ref!=label or any(c in ref for c in '/\\:') or ref in ('.','..')):state='blocked'
        elif not data and ref in selected:data=selected[ref];state='selected';staged_used.add(ref)
        row=[label,state,len(data),sha256(data).hexdigest() if data else '',False];report['dependencies'].append(row);texture_rows[i]=row
        if not data or t['type']!=0:continue  # layered/procedural textures are listed, not flattened
        # Decode only a diffuse map that a material actually references.
        if not any(m['texture']==i for m in raw['materials']):continue
        if len(textures)>=16:raise ValueError('FBX exceeds 16 decoded diffuse textures.')
        mime='image/png' if data.startswith(b'\x89PNG\r\n\x1a\n') else 'image/jpeg' if data.startswith(b'\xff\xd8\xff') else None
        if mime is None:continue
        if len(data)>8*1024**2:raise ValueError('FBX texture exceeds 8 MiB.')
        wraps=tuple({0:10497,1:33071}.get(v) for v in t['wrap'])
        if None in wraps:continue
        doc={'materials':[{'pbrMetallicRoughness':{'baseColorTexture':{'index':0}}}],
            'textures':[{'source':0,'sampler':0}], 'samplers':[{'wrapS':wraps[0],'wrapT':wraps[1]}],
            'images':[{'bufferView':0,'mimeType':mime,'name':label}]}
        key=(sha256(data).hexdigest(),label,wraps)
        if key not in texture_cache:
            _,decoded=image_parse(doc,data,[{'buffer':0,'byteLength':len(data)}]);texture_cache[key]=decoded[0]
        image=texture_cache[key]
        pixels+=image.source_width*image.source_height
        if pixels>8*1024**2:raise ValueError('FBX textures exceed the 8 megapixel scene budget.')
        texture_refs[i]=len(textures);textures.append(image)
    for label,data in selected.items():
        if label not in staged_used:report['dependencies'].append((name(label,'Selected texture'),'unused',len(data),sha256(data).hexdigest(),False))
    materials=[];parts=[];vertices=triangles=0;material_cache={}
    for node in nodes:
        n=known[node.index]
        if n['mesh']<0:continue
        mesh=meshes[n['mesh']];groups={}
        for a,b,c,slot in mesh['triangles']:groups.setdefault(slot,[]).append((a,b,c))
        for slot,faces in groups.items():
            used=sorted({v for face in faces for v in face});remap={v:j for j,v in enumerate(used)}
            vertices+=len(used);triangles+=len(faces)
            if vertices>MAX_VERTICES or triangles>MAX_TRIANGLES or len(parts)>=512:raise ValueError('Instanced FBX geometry exceeds the scene budget.')
            points=tuple(vector(mesh['points'][i],3) for i in used)
            if mesh['local']:points=tuple(transform(affine(n['geometry']),p) for p in points)
            faces=tuple(tuple(remap[i] for i in f) for f in faces)
            uv=tuple(vector(mesh['uvs'][i],2) for i in used) if mesh['uvs'] else ()
            material=-1
            if n['materials']:
                mi=n['materials'][integer(slot,0,len(n['materials'])-1)];m=raw['materials'][mi];ti=m['texture'];t=raw['textures'][ti] if ti>=0 else None
                has_uv=bool(uv) and (not t or not t['uv_name'] or t['uv_name']==mesh['uv_name'])
                mk=(mi,has_uv)
                if mk not in material_cache:
                    if len(materials)>=128:raise ValueError('FBX exceeds 128 preview material variants.')
                    color=vector(m['color'],3);factor=vector([m['factor']],1)[0]
                    tex=texture_refs.get(ti,-1) if has_uv else -1
                    note='Unlit diffuse color/PNG/JPEG subset; no shader, PBR, transparency or vertex-color matching. Texture preview at most 256 px; UV0 only.'
                    if ti>=0 and tex<0:note+=' Referenced texture is unavailable or unsupported for this mesh.'
                    material_cache[mk]=len(materials);materials.append(Material(name(m['name'],'FBX material'),tuple(max(0.,min(1.,v*factor)) for v in color)+(1.,),tex,notices=(note,)))
                material=material_cache[mk]
                if materials[material].texture>=0:
                    # The full FBX UV-to-texture affine transform is baked into
                    # this part's UV0; geometry/source UVs are never rewritten.
                    matrix=affine(t['transform']);uv=tuple(transform(matrix,(u,v,0))[:2] for u,v in uv);texture_rows[ti][4]=True
            if len({v for f in faces for v in f})<3:raise ValueError('FBX has no usable triangle geometry.')
            parts.append(ScenePart(node.index,points,faces,uv,material,health=health.analyze(points,faces,uvs=uv)))
    if not parts:raise ValueError('FBX has no supported polygon mesh to preview.')
    info=report_decode(report)
    notices=('FBX preview normalized to meters, right-handed Y-up. Source units, axes, takes and dependency hashes are listed below.',
        'Default stored skinning and blendshapes are baked into the imported pose. Use Animation timeline to prepare a bounded take range; manual FBX bone/morph controls remain unavailable.',
        'All mesh instances are shown, including hidden nodes. Subdivision, constraints, shader effects, transparency and vertex colors are not evaluated.',
        'Mesh health uses expanded polygon-corner indices; original shared-vertex topology and source normals/tangents are not diagnosed.',
        f'{raw["constraints"]} constraints present; {sum(m["subdivision"]>0 for m in meshes.values())} meshes request subdivision; {len(raw["warnings"])} importer warning types.')
    return Scene(tuple(nodes),tuple(parts),bounds(tuple(v for p in parts for v in p.vertices)),sha256(source).hexdigest(),len(source),notices,tuple(materials),tuple(textures),(),info)
