# VRC Eye 1.18.10 — VRCX Companion implementation map

The complete supplied discussion follows byte-for-byte after this preface.
The requested category is **Advanced → VRCX Companion**.

| Discussion area | Implemented behavior and boundaries |
| --- | --- |
| Independent companion architecture | Optional process provider and one local policy authority; no dependency on VRCX, its account, or the Client Bridge |
| Ownership and presets | Balanced, VRCX Primary, VRC Eye Primary; shared-category overrides, protected core responsibilities and reasoned decisions |
| Temporary Solo | Session-only suspension of coordinated ownership; existing manual banner preference is preserved; VRCX remains independent |
| Passive detection and health | Optional psutil, unique root plus children, creation identity, two distinct absent samples, expiry, ambiguous/unknown states and independent retry |
| Notification arbitration | Friend/pinned-player social banners checked at enqueue and display; queued banners cleared when ownership changes; roster/history still process events |
| Presence and overlays | Ownership/availability rows and truthful unavailable external state; no VRC Eye Discord publisher or negotiated overlay layout is invented |
| Launch and recovery | One runtime launch screen, separate Launch/Recovery ownership, reviewed one-shot requests and shared major-action reservation across Unity, Resource Guard and Wellness |
| Cross-application races | VRC Eye respects its configured external owner; no unsupported cross-application lock, VRCX acknowledgement or autonomous fallback |
| Shared runtime sessions | Runtime boundaries invalidate outstanding reviews; session tokens are not recorded/exported |
| Health/conflict diagnostics | Own-app feature availability compared with user-declared VRCX settings; external activity remains unverified |
| Handoffs | Source-verified generic and exact-ID detail URIs, reviewed before opening; no join/avatar-switch/favorite mutation commands |
| Explicit exchange | Recognized native CSV/friends JSON, whole-file validation, previewed local insert-only import, manual ID-list export, existing data preserved |
| Legacy migration | Existing cache preferences preserved; read-only cache settings/search, JSON import and manual banner suppression centralized |
| Privacy and environment | Opt-in mode, bounded memory/events/queues/reviews, normalized exports/Black Box events; Demo/Safe Mode block actions and file changes |
| Casual/Advanced/Developer | Five scrollable tabs with appropriate visibility, reasoning/availability, reviewed export and isolated simulation |
| Low-priority button cleanup | One persistent global connection button; avatar search in Search; redundant navigation/profile-load controls removed; contextual actions retained |

New modules: vrcx_companion_model.py, vrcx_companion_service.py,
vrcx_companion_ui.py, vrcx_handoff.py, vrcx_legacy_ui.py, vrcx_exchange.py and
vrcx_exchange_ui.py. The central coordinator is connected to Player List,
Unity Player, Resource Guard, Wellness and Black Box. Runtime profiles and
companion presets remain separate.

No supported VRCX settings/heartbeat/restart/RPC coordination API was identified.
Accordingly, local preferences and user declarations are explicitly distinguished
from observed process evidence. Automatic recovery, external feature verification,
negotiated overlays and deeper companion protocols remain future work. See
VRCX_COMPANION_SETUP.md for operation and VALIDATION.md for executed checks.

---

Yes. The **VRCX Companion Mode** we were designing was much more ambitious than simply “detect whether VRCX is running.” The intended end state was a **cooperative operating mode between VRC Eye and VRCX**, where both applications could be running beside VRChat without fighting over notifications, Discord presence, restart behavior, session tracking, overlays, or other duplicated responsibilities.

The most important design rule was:

> **VRCX Companion Mode should make VRC Eye behave better when VRCX exists, but VRC Eye must never need VRCX in order to function.**

That rule affects basically every part of the architecture.

---

# What VRCX Companion Mode actually is

Companion Mode is essentially an **integration/arbitration layer**.

VRC Eye would recognize that the user also runs VRCX and change its behavior accordingly. It would not try to replace VRCX, control VRCX, or merge the two applications into one giant program.

Instead, VRC Eye would say, conceptually:

> “VRCX is present. We both know things about this VRChat session. Which responsibilities should VRCX handle, which should I handle, and where do we need to stay out of each other's way?”

That distinction matters enormously.

The architecture we discussed looked roughly like this:

```
                         VRChat
                            │
            ┌───────────────┴───────────────┐
            │                               │
          VRCX                           VRC Eye
            │                               │
     Social / History                Runtime / Safety
     Account features                Diagnostics
     Lists / history                 Hardware
     Social alerts                   Black Box
     Discord presence                Unity/runtime tools
            │                               │
            └──────────────┬────────────────┘
                           │
                    Companion Layer
                           │
              Ownership + Coordination
```

The **Companion Layer does not become the source of truth for VRChat**.

It simply coordinates the two companion applications.

---

# The ownership model

This was probably the most important concept in the whole design.

Instead of asking:

> “Does VRCX support this?”

we ask:

> “Who owns this responsibility right now?”

There would effectively be an ownership table.

| Responsibility                       | Normal Companion owner |
| ------------------------------------ | ---------------------- |
| Social/account-oriented information  | VRCX                   |
| Social notifications                 | VRCX                   |
| Long-term social/history functions   | VRCX                   |
| Lists and VRCX-specific organization | VRCX                   |
| Discord Rich Presence                | Usually VRCX           |
| Live VRChat session monitoring       | VRC Eye                |
| Live Player List state               | VRC Eye                |
| Runtime/process monitoring           | VRC Eye                |
| Unity Player/runtime supervision     | VRC Eye                |
| GPU / CPU / resource telemetry       | VRC Eye                |
| Safety systems                       | VRC Eye                |
| Black Box diagnostics                | VRC Eye                |
| Crash investigation                  | VRC Eye                |
| Hardware/VR-runtime monitoring       | VRC Eye                |
| VRC Eye overlay                      | VRC Eye                |
| Crash restart                        | Negotiated             |
| Launch coordination                  | Negotiated             |
| Duplicate notifications              | Companion coordinator  |
| Integration conflicts                | Companion coordinator  |

This gives the two programs **different specialties** rather than turning one into a subordinate of the other.

The shorthand version was:

**VRCX understands your VRChat social ecosystem.**

**VRC Eye understands your live VRChat runtime.**

That is a very clean division.

---

# The three tandem presets

We discussed making the ownership system understandable to normal users through presets rather than exposing dozens of toggles immediately.

The three main presets were:

### Balanced

This would probably be the normal default.

VRCX handles the things it traditionally does well: social information, social notifications, history, account-related tools, lists, and normally Discord Rich Presence.

VRC Eye handles runtime monitoring, diagnostics, safety, Player List live-state tracking, Black Box, hardware monitoring, Unity/runtime functions, and its own overlay.

Neither program tries to duplicate the other.

---

### VRCX Primary

This means:

> “When both applications can reasonably perform a function, prefer VRCX.”

VRC Eye would become more conservative about anything that overlaps with VRCX.

It would still retain its unique features.

For example, **VRCX Primary would absolutely not disable Black Box, Safety, Runtime Companion, Resource Guard, or Unity monitoring**, because those are VRC Eye responsibilities.

It primarily changes the behavior of overlapping convenience functions.

---

### VRC Eye Primary

This is the reverse.

VRC Eye would be allowed to own more of the shared convenience functionality.

That could be useful for someone who mainly uses VRC Eye but occasionally opens VRCX for history or social management.

Importantly, this still wouldn't mean VRC Eye attempts to impersonate VRCX.

It just means that in ambiguous cases, ownership resolves toward VRC Eye.

---

# Solo Mode

There was also the concept of **temporary Solo Mode**.

This is extremely useful for troubleshooting.

Suppose both programs are running and something weird happens.

Instead of telling the user:

> “Close VRCX manually, restart everything, see if it changes.”

VRC Eye could temporarily suspend all VRCX-aware behavior.

Conceptually:

```
VRCX detected
Companion Mode active

[ Temporarily use VRC Eye Solo Mode ]
```

VRCX could remain running.

VRC Eye would simply stop treating it as part of the coordinated environment.

This gives us a very clean A/B test.

```
Problem exists in Companion Mode
        ↓
Enable Solo Mode
        ↓
Problem disappears
        ↓
Likely integration/ownership conflict
```

That becomes particularly useful once the diagnostics system gets sophisticated.

---

# VRCX detection should be passive

One of the deliberate boundaries was that VRC Eye shouldn't require some fragile hack just to know VRCX exists.

At the basic level, Companion Mode can operate from **process awareness**.

Conceptually:

```
VRCX.exe detected
        │
        ▼
Companion features available
```

If VRCX isn't present:

```
VRCX: Not Running

VRC Eye functionality:
████████████████████ 100%
```

Not:

```
VRCX: Not Running

ERROR
Player List unavailable
History unavailable
Runtime unavailable
Safety unavailable
```

That second architecture is exactly what we wanted to avoid.

VRCX detection is supposed to unlock **conveniences**, not fundamental VRC Eye functionality.

---

# The mature plan deliberately avoids depending on VRCX internals

This is worth clarifying because our earlier experimentation and our later Companion architecture weren't exactly the same.

Earlier VRCX-related work included things such as reading VRCX-cached information—for example cached avatar IDs, creator information, status/date information, and a configured VRCX data location.

That was useful experimentation.

But as the project became larger, the Companion Mode architecture became intentionally stricter.

We did **not** want the long-term architecture to become:

```
VRC Eye
   ↓
secretly rummages around VRCX database
   ↓
hopes its database structure never changes
   ↓
everything explodes when VRCX updates
```

Especially not:

```
VRC Eye modifies VRCX SQLite database
```

That was a hard architectural line.

Likewise, we did not want to depend on some undocumented localhost interface simply because it happened to exist.

The preferred hierarchy became:

```
Documented integration
        ↓
Documented export/import
        ↓
Verified handoff
        ↓
Process awareness
        ↓
Independent VRC Eye observation
```

rather than:

```
Reverse-engineer VRCX internals
        ↓
Hard-code assumptions
        ↓
Hope
```

So Companion Mode is substantially safer than an architecture based on directly manipulating VRCX's internal state.

---

# Notification arbitration

This is one of the biggest practical benefits.

Imagine someone joins.

Without coordination:

```
VRCX:
Friend joined instance.

VRC Eye:
Friend joined instance.

Overlay:
Friend joined instance.

Windows toast:
Friend joined instance.
```

Congratulations. The user has been informed four times that Bob exists.

Companion Mode prevents this.

When VRCX owns social notifications, VRC Eye still processes the underlying event because **VRC Eye's Player List needs to remain accurate**.

It just doesn't turn that event into another social popup.

So internally:

```
PLAYER_JOIN
    │
    ├── Update Player List       YES
    ├── Update session state     YES
    ├── Update internal history  as configured
    └── Social notification      SUPPRESSED
                                  Owner: VRCX
```

That is a very important distinction.

**Suppressing a notification must never mean suppressing the event.**

VRC Eye still needs the event for its own internal systems.

---

# Safety alerts are different

The ownership model would not treat all notifications identically.

Something like:

```
Friend joined
```

is social.

VRCX can own that.

Something like:

```
GPU memory critically exhausted
```

is runtime information.

VRC Eye owns that.

Something like:

```
VRChat stopped responding
```

belongs to VRC Eye.

Something like:

```
Black Box detected repeated renderer failures
```

belongs to VRC Eye.

Something like:

```
Resource Guard protection activated
```

belongs to VRC Eye.

Companion Mode therefore requires a **notification router**, not simply a global:

```
if VRCX:
    notifications = false
```

The decision needs to happen by category.

Conceptually:

```
NotificationRouter
│
├── SOCIAL
│      owner → VRCX
│
├── ACCOUNT
│      owner → VRCX
│
├── SESSION
│      owner → configurable
│
├── RUNTIME
│      owner → VRC Eye
│
├── SAFETY
│      owner → VRC Eye
│
├── DIAGNOSTIC
│      owner → VRC Eye
│
└── SYSTEM
       owner → VRC Eye
```

That is much more robust.

---

# Discord Rich Presence arbitration

Discord RPC was another obvious collision point.

If both VRCX and VRC Eye advertise VRChat activity, you can end up with programs fighting over Discord presence.

That is ugly architecturally and potentially confusing to users.

So Discord presence gets an explicit owner.

In the normal Balanced setup, our planned preference was:

```
Discord Rich Presence
Owner: VRCX
```

VRC Eye sees that and keeps its own RPC publisher inactive.

Not broken.

Not unloaded.

Not constantly retrying.

Just deliberately suppressed because another application owns the capability.

Internally the state should ideally look something like:

```
VRC Eye Discord RPC

Status: Suppressed
Reason: Owned by VRCX
Companion preset: Balanced
```

That distinction is important for diagnostics.

Otherwise a user sees:

```
Discord RPC: Off
```

and doesn't know whether it is broken or intentionally disabled.

The system should distinguish:

```
DISABLED
```

from:

```
SUPPRESSED_BY_OWNER
```

from:

```
FAILED
```

That philosophy occurs throughout VRC Eye.

---

# Overlay coexistence

The same idea applies to overlay behavior.

VRC Eye's overlay is much more oriented toward the runtime/safety/diagnostic ecosystem we're building.

It may contain things like live warnings, performance information, player information, Resource Guard events, runtime status, Black Box indicators, or later bridge-provided information.

Companion Mode shouldn't create a visual war between applications.

Therefore overlay coexistence needs to be deliberate.

The coordinator should know:

```
VRC Eye Overlay: Active
VRCX notification surface: Active

Collision policy: Companion
```

and use the appropriate layout/notification ownership decisions.

The goal isn't necessarily that VRC Eye micromanages another application's windows.

The goal is that **VRC Eye understands it isn't the only companion application present**.

---

# Launch coordination

Another major section of Companion Mode was launch behavior.

As VRC Eye evolves into the thing that supervises the Unity Player / VRChat runtime, it increasingly knows:

```
VRChat isn't running
VRChat is starting
VRChat is initializing
VRChat is running
VRChat has degraded
VRChat is unresponsive
VRChat exited
```

VRCX also has behavior associated with the VRChat lifecycle.

So we need to prevent:

```
VRC Eye launching something
+
VRCX launching something
+
Steam launching something
+
recovery logic launching something
```

from turning into an accidental race.

The Companion coordinator needs to understand **launch intent**.

For example:

```
User
 │
 ▼
VRC Eye
 │
 ├── Launch VRCX if configured
 │
 └── Launch VRChat
         │
         ▼
  Runtime Session A
```

If VRCX is already open:

```
VRCX detected
→ attach Companion state
→ don't launch another instance
```

And critically, VRCX disappearing must not be interpreted as VRChat disappearing.

These are separate processes with separate lifecycles.

---

# VRCX Companion presets and VRChat launch profiles are two different things

This is a subtle architectural distinction that becomes important once the Unity Player section exists.

We talked about VRChat/runtime profiles such as:

**Normal VR**, **Desktop**, **Troubleshooting**, **Creator/Test**, **Low-Overhead**, and **Custom**.

Those are **runtime profiles**.

Meanwhile:

**Balanced**, **VRCX Primary**, and **VRC Eye Primary**

are **companion ownership profiles**.

They are two independent axes.

So you could have:

```
Runtime Profile:
Troubleshooting

Companion Profile:
Balanced
```

or:

```
Runtime Profile:
Desktop

Companion Profile:
VRCX Primary
```

or:

```
Runtime Profile:
Low-Overhead

Companion Profile:
VRC Eye Primary
```

That is much cleaner than trying to jam everything into one enormous “mode” selector.

---

# Crash/restart arbitration

This becomes extremely important now that we've designed Black Box / Crash Diagnostics and the Unity Player / Runtime Companion.

VRC Eye may detect:

```
VRChat process exited unexpectedly
```

Black Box immediately needs to preserve the crash window.

Runtime Companion needs to close the runtime session.

Player List needs to close the active instance/session.

Crash Diagnostics needs to classify what happened.

But then comes a separate question:

> Who restarts VRChat?

That's where Companion Mode steps in.

If VRCX is configured as the crash restart owner, VRC Eye should **not** race it.

The sequence becomes:

```
VRChat crashes
      │
      ▼
VRC Eye detects crash
      │
      ├── Freeze Black Box window
      ├── Close Runtime Session A
      ├── Close instance session
      ├── Close player-presence sessions
      ├── Begin crash analysis
      │
      └── Restart?
             │
             ▼
         Owner = VRCX
             │
             ▼
         VRC Eye waits
```

VRC Eye remains the **diagnostics owner**.

VRCX can still be the **restart owner**.

Those are independent responsibilities.

This was exactly the type of duplication the ownership system was designed to solve.

---

# Only one major recovery action at a time

This ties directly into our wider Runtime Companion design.

We already had the concept that only one major corrective action should be pending:

```
AUTO_CLOSE

SAFE_MODE

QUICK_RESTART
```

Companion Mode adds another arbitration dimension.

VRC Eye must not do:

```
QUICK_RESTART
```

while VRCX simultaneously initiates another restart.

Otherwise:

```
Crash
 │
 ├── VRCX launches VRChat
 │
 └── VRC Eye launches VRChat
```

and suddenly we have Steam/process weirdness.

So the recovery system needs effectively a lock:

```
RecoveryActionOwner
```

with something conceptually resembling:

```
NONE
VRC_EYE
VRCX
USER
EXTERNAL
```

The exact enum names weren't the point.

The important architectural rule was:

> **One crash, one recovery authority.**

---

# Runtime Sessions make this safer

The runtime session model we designed for Unity Player / Runtime Companion fits Companion Mode extremely well.

Every VRChat process lifetime becomes its own session.

For example:

```
Runtime Session A
14:03:11 → 16:22:48
Exit: CRASHED
```

VRCX or VRC Eye then initiates recovery.

A new process appears.

That becomes:

```
Runtime Session B
16:23:09 → ACTIVE
```

Never:

```
Runtime Session A mysteriously became healthy again
```

This matters because Companion Mode should never cause state from an old crashed instance to bleed into the newly launched instance.

---

# VRCX Health tile

We also planned an actual **VRCX health/status surface** rather than hiding the integration somewhere deep in Settings.

Something along the lines of:

```
VRCX Companion
──────────────────────────

VRCX             ● Running
Companion Mode   ● Active
Preset             Balanced

Social Alerts      VRCX
Discord RPC        VRCX
Runtime Alerts     VRC Eye
Crash Diagnostics  VRC Eye
Restart            VRCX

Conflicts           None
```

In an unhealthy condition:

```
VRCX Companion
──────────────────────────

VRCX             ⚠ Degraded
Companion Mode     Active

Issue:
VRCX session integration appears stale.

Last update:
12.8 seconds ago

VRC Eye protection:
Active

Affected features:
VRCX handoff / coordination
```

Again, the major philosophy is graceful degradation.

The status system we've been developing elsewhere fits nicely:

```
HEALTHY
DEGRADED
FAILED
DISABLED
```

and where appropriate:

```
STALE
```

The UI should never transform missing information into fake information.

If we don't know something, say:

```
Unavailable
```

not:

```
0
```

---

# Companion conflict detector

This is one of the more interesting pieces.

Rather than requiring the user to understand why two companion applications might interfere, VRC Eye could proactively identify common tandem conflicts.

For example:

```
⚠ Companion conflict detected

Both VRCX and VRC Eye appear configured to
publish Discord Rich Presence.
```

Or:

```
⚠ Duplicate notification configuration

VRCX owns social notifications, but VRC Eye
social notifications are also enabled.
```

Or:

```
⚠ Recovery conflict

Both companion applications appear configured
to relaunch VRChat after a crash.
```

Or an overlay-related conflict.

This transforms Companion Mode from:

> “We support VRCX.”

into:

> “VRC Eye understands that VRCX is part of this installation.”

That's much more valuable.

---

# Tandem troubleshooting

Eventually the troubleshooting page should be able to present the entire companion environment in one place.

Conceptually:

```
VRChat
Process       HEALTHY
Logs          HEALTHY
OSC           HEALTHY

VRC Eye
Runtime       HEALTHY
Black Box     HEALTHY
Safety        HEALTHY
Database      HEALTHY

VRCX
Process       HEALTHY
Integration   HEALTHY

Custom Bridge
Status        DISABLED

──────────────────────

Companion conflicts: 0
Protection: Full
```

If something fails:

```
VRCX
Process       RUNNING
Integration   DEGRADED

⚠ Some VRCX handoff functionality is unavailable.

VRC Eye runtime monitoring remains active.
```

That last sentence represents a really important UX philosophy we've repeatedly applied throughout the project:

> **Explain what broke, but also explicitly explain what is still working.**

Instead of terrifying people with a giant red:

```
ERROR
```

---

# Player List integration

Companion Mode is especially important for our redesigned Player List.

The VRC Eye Player List is fundamentally a **live-session tool**.

It should never become dependent on VRCX.

So even in Companion Mode:

```
VRChat logs/local state
        ↓
VRC Eye Player List
```

remains intact.

VRCX can supplement social/history functionality where appropriate, but the Player List doesn't suddenly turn into:

```
VRCX isn't running
→ no players
```

Absolutely not.

The live roster continues.

If optional information becomes unavailable, that individual field becomes:

```
Unavailable
```

while everything else keeps functioning.

---

# Joining/leaving events demonstrate the architecture nicely

Imagine Alice enters the instance.

VRC Eye observes it.

Internally:

```
Alice
Status: Present
Join time: 18:44:02
```

Player List updates.

Session tracking updates.

Safety systems can evaluate whatever they're supposed to evaluate.

History can update according to the user's privacy settings.

But because Companion Mode says:

```
Social Notifications Owner = VRCX
```

VRC Eye doesn't throw up another:

```
Alice joined!
```

notification.

That single example captures the entire Companion Mode philosophy:

> **Data processing and presentation ownership are separate things.**

---

# Shared-session awareness

We also wanted both applications to be understood as participating in the same VRChat session.

Not necessarily sharing some giant internal object.

Rather, VRC Eye understands:

```
VRChat Session
   │
   ├── VRC Eye observing
   └── VRCX present
```

That lets integration decisions be scoped to the current runtime.

If VRChat restarts:

```
Session A
CLOSED
```

and then:

```
Session B
NEW
```

the companion state can be reevaluated.

That avoids stale ownership decisions surviving across crashes, restarts, or mode changes.

---

# “Open in VRCX”

We discussed verified handoffs as one of the cleaner integration strategies.

Rather than VRC Eye reimplementing some complicated VRCX function, it can say:

```
Open in VRCX
```

where a reliable/documented handoff exists.

This is conceptually very powerful.

Suppose VRC Eye is looking at something for which VRCX has the richer historical/social interface.

VRC Eye doesn't need to rebuild VRCX inside itself.

It hands the user off.

This follows the broader principle:

> **Integrate capabilities, don't clone applications.**

And importantly, if there isn't a reliable way to perform a particular handoff, we don't pretend there is.

---

# Import/export instead of clandestine synchronization

The same philosophy applies to larger datasets.

Where integration requires moving information between applications, the preferred approach was **documented exports/imports and migrations**.

Something explicit like:

```
VRCX
  ↓
Export
  ↓
Known interchange data
  ↓
VRC Eye Import
```

is vastly preferable to:

```
SELECT * FROM mysterious_internal_vrcx_table
```

The explicit method is slower to initially design but dramatically safer.

It also gives us opportunities for validation:

```
Import source recognized
Schema version supported
Records validated
Duplicates identified
Conflicts reviewed
```

rather than blindly trusting another application's private storage structure.

---

# Backup philosophy

Companion Mode also ties into backups.

If VRC Eye imports external companion data or migrates integration settings, we wanted the general system philosophy to remain:

```
preserve original
validate
migrate
verify
```

not destructive transformation.

The user should never lose their VRCX configuration because VRC Eye decided to “clean things up.”

In fact, ideally VRC Eye wouldn't be modifying the VRCX configuration at all.

It changes **its own interpretation and behavior**.

That's much safer.

---

# Privacy boundaries

Companion Mode inherits the larger privacy architecture we designed for VRC Eye.

Things like:

**Local History Off**

**Incognito Session**

**Streamer Mode**

**Guest Mode**

**Sensitive-data redaction**

still apply.

Companion Mode doesn't override them merely because another program is running.

For example, if VRC Eye history is disabled, detecting VRCX should not secretly turn VRC Eye history back on.

Similarly:

```
Incognito Session
```

needs to mean something consistently throughout the VRC Eye ecosystem.

---

# VRCX Companion Mode is NOT the custom-client bridge

This distinction is extremely important.

We actually have three conceptual layers now:

```
Stock VRChat
    │
    ├──── VRC Eye external monitoring
    │
    ├──── VRCX Companion Mode
    │
    └──── Optional Client Bridge
```

They solve totally different problems.

**VRCX Companion Mode** coordinates another companion application.

**The Client Bridge** optionally provides structured data from a compatible client.

You can have:

```
VRCX Companion: ON
Client Bridge: OFF
```

and everything is perfectly valid.

Or:

```
VRCX Companion: OFF
Client Bridge: ON
```

Also valid.

Or both.

Or neither.

The architecture should never become:

```
No VRCX
→ bridge fails
→ runtime fails
→ Player List fails
→ Safety fails
```

Our recurring architecture rule has been:

> **Optional integrations increase capability; they do not unlock basic functionality.**

---

# Companion Mode should also respect our bridge security model

If a compatible custom-client bridge eventually exists, VRCX doesn't get some magical route through it.

The bridge remains its own capability-negotiated system.

Something like:

```
Handshake
Protocol version
Capability negotiation
Permission check
Heartbeat
Structured messages
```

with capabilities along the lines of the ones we discussed:

```
runtime.summary
player.selection
voice_activity
avatar.load_state
avatar.performance
runtime.errors
```

Not:

```
execute arbitrary Unity call
```

and not:

```
read arbitrary memory
```

and not:

```
modify arbitrary object
```

VRCX Companion doesn't weaken that boundary.

---

# Casual UI

The Casual experience should hide most of this.

A normal user does not need to see:

```
NotificationOwnershipResolver.SOCIAL
```

They should see something like:

```
VRCX Companion

Connected

VRC Eye and VRCX are working together.
Duplicate notifications and conflicting
features are being managed automatically.

Status: Healthy
```

Perhaps with:

```
Preset: Balanced
```

and little else.

If something is wrong:

```
VRCX Companion

Limited

VRCX appears to be running, but some
companion features are unavailable.

VRC Eye protection remains active.
```

Very straightforward.

---

# Advanced UI

Advanced Mode is where we expose the ownership matrix.

Something conceptually like:

```
VRCX COMPANION
──────────────────────────────────

Detected application
VRCX                       Running

Companion Mode             Enabled
Preset                     Balanced

FEATURE OWNERSHIP

Social notifications       VRCX
Discord Rich Presence      VRCX
Social/history actions     VRCX

Live Player List           VRC Eye
Runtime monitoring         VRC Eye
Safety                     VRC Eye
Black Box                  VRC Eye
Unity Player               VRC Eye
Resource Guard             VRC Eye

Crash restart              VRCX
Launch coordinator         VRC Eye

──────────────────────────────────

Conflict Detection         Enabled
Duplicate Suppression      Enabled
Handoff Integration        Enabled
```

And then Advanced could allow category-specific overrides.

---

# Developer Mode

Developer Mode can go considerably deeper.

For example, it might show exactly **why** ownership was resolved the way it was.

Conceptually:

```
SOCIAL_NOTIFICATION
Requested owner: AUTO
Preset: BALANCED
VRCX detected: TRUE
VRCX health: HEALTHY
Resolved owner: VRCX
Suppression rule: ACTIVE
```

or:

```
CRASH_RESTART
Requested owner: VRCX
VRCX health: FAILED
Fallback available: TRUE
Resolved owner: VRC_EYE
```

And perhaps diagnostic event history:

```
02:31:14 VRCX detected
02:31:14 Companion negotiation started
02:31:14 Social notification owner → VRCX
02:31:14 Discord RPC owner → VRCX
02:31:14 Runtime owner → VRC Eye
02:31:14 Crash diagnostics owner → VRC Eye
02:31:15 Companion state HEALTHY
```

That would be extremely useful during development without cluttering the normal UI.

---

# Failures must be isolated

This is one of the deeper architectural principles from the entire VRC Eye project.

Suppose VRCX crashes.

Bad architecture:

```
VRCX crashed
     ↓
Companion failed
     ↓
Player List failed
     ↓
Database failed
     ↓
Safety failed
     ↓
VRC Eye explodes
```

Our architecture instead should behave like:

```
VRCX crashed
     │
     ▼
VRCX provider FAILED
     │
     ├── Handoffs unavailable
     ├── VRCX social ownership released
     └── Companion state DEGRADED

VRC Eye:
Runtime          HEALTHY
Player List      HEALTHY
Safety           HEALTHY
Black Box        HEALTHY
Resource Guard   HEALTHY
Unity Companion  HEALTHY
```

That is provider isolation.

It's the same philosophy we've been developing for the Unity Player/runtime architecture.

---

# VRCX coming back shouldn't require restarting VRC Eye

Likewise, if VRCX reappears:

```
VRCX process detected
        ↓
Provider reconnects
        ↓
Health check
        ↓
Ownership re-evaluated
        ↓
Companion HEALTHY
```

No:

> “Please restart VRC Eye.”

That should be unnecessary.

Our providers should be independently reconnectable.

---

# Staleness matters

There's also an important difference between:

```
Disconnected
```

and:

```
Stale
```

Suppose integration information hasn't updated recently.

VRC Eye should not continue pretending it's current.

It can say:

```
VRCX Companion
STALE

Last update: 12.4 seconds ago
```

And importantly, values derived from stale integration should not silently become:

```
0
false
empty
```

They become:

```
Unavailable
```

or:

```
Stale
```

This same data-validity principle appears throughout our Runtime Companion design.

---

# The mature internal architecture

If we turn everything we discussed into software components, the Companion system would conceptually look something like this:

```
VrcxDetector
       │
       ▼
VrcxProvider
       │
       ▼
CompanionCoordinator
       │
       ├── OwnershipResolver
       │
       ├── NotificationRouter
       │
       ├── PresenceArbiter
       │
       ├── RecoveryArbiter
       │
       ├── LaunchCoordinator
       │
       ├── HandoffService
       │
       └── ConflictDetector
                   │
                   ▼
             RuntimeStore
                   │
                   ▼
                  UI
```

Those exact class names aren't sacred, but the **separation of responsibility** is.

The detector should not decide notification ownership.

The notification router should not restart VRChat.

The crash-recovery system should not manipulate VRCX data.

The UI should not contain the actual integration logic.

That separation will save us enormous pain later.

---

# Why the ownership resolver matters so much

Consider the alternative.

You end up with random code everywhere:

```
if (vrcxRunning)
{
    ...
}
```

Then another feature:

```
if (settings.VrcxEnabled)
{
    ...
}
```

And another:

```
if (!vrcxRunning || forceNotification)
{
    ...
}
```

Eventually nobody knows why anything is happening.

Instead, everything asks one authority:

```
Who owns SOCIAL_NOTIFICATION?
```

Response:

```
VRCX
```

or:

```
VRC_EYE
```

The feature itself doesn't need to understand the entire VRCX ecosystem.

That gives us deterministic behavior.

---

# Conflict detection can then become extremely intelligent

Because the ownership resolver already knows what *should* happen and the runtime monitors know what *is* happening, the conflict detector can compare the two.

Conceptually:

```
Expected:
DiscordRPC owner = VRCX

Observed:
VRCX RPC active
VRC Eye RPC active

Result:
CONFLICT
```

or:

```
Expected:
Restart owner = VRCX

Observed:
VRCX restart enabled
VRC Eye Quick Restart enabled

Result:
CONFLICT
```

That is much better than merely detecting VRCX.exe.

---

# How this ties into Black Box

Companion events themselves should eventually become useful diagnostic metadata.

Imagine a crash report showing:

```
02:11:44  VRCX Companion HEALTHY
02:11:45  Runtime resource pressure increased
02:11:46  VRChat UNRESPONSIVE
02:11:47  VRCX crash recovery triggered
02:11:47  VRC Eye restart suppressed
02:11:48  VRChat process exited
02:11:48  Runtime Session 184 closed: CRASHED
02:11:48  Black Box capture finalized
02:11:50  VRCX initiated relaunch
02:11:54  Runtime Session 185 created
```

Now Companion Mode itself becomes explainable.

The user can tell **who did what**.

That is fantastic for troubleshooting mysterious restart loops.

---

# The relationship with Safety

Safety should remain one of the strongest VRC Eye-owned domains.

VRCX being absent, frozen, outdated, or closed should never mean:

```
Protection disabled
```

At worst, VRC Eye might report:

```
VRCX Integration: Degraded
Protection: Full
```

or if some genuinely related component is affected:

```
Protection: Limited
```

with an explanation.

But the external safety architecture remains VRC Eye's responsibility.

This is especially important because we deliberately designed external protection so that **VRCX, the optional bridge, and other integrations are enhancements rather than points of catastrophic failure.**

---

# Relationship with the Unity Player / Runtime Companion

The new **Unity Player** section actually makes the division between VRCX and VRC Eye much clearer.

VRCX doesn't need to become the runtime supervisor.

That is VRC Eye's territory.

VRC Eye can observe:

```
VRChat.exe
Unity initialization
graphics/runtime state
GPU
display state
window state
SteamVR relationship
resource behavior
logs
hangs
crashes
restart generations
Black Box telemetry
```

while VRCX continues to specialize in social/account/history functionality.

The two applications become complementary rather than redundant.

---

# Relationship with Crash & Diagnostics

Same story.

VRCX may initiate a restart.

But VRC Eye still owns the question:

> **Why did VRChat crash?**

So the split becomes:

```
VRCX
"VRChat died. Restart it."

VRC Eye
"VRChat died. Here's what happened during the
previous 90 seconds, what subsystem degraded,
what resources looked like, what Unity reported,
which providers were healthy, and what recovery
action occurred."
```

That's an extremely natural partnership.

---

# Troubleshooting profile interaction

This gets particularly useful with the **Troubleshooting** runtime profile we planned.

That profile included concepts such as:

```
Black Box Enhanced
Log Monitoring Detailed
Runtime Companion Detailed
Resource Sampling Detailed
Optional Plugins Disabled
Experimental Modules Disabled
Overlay Minimal
```

Companion Mode could remain active while that profile is used.

So you could reproduce an issue with:

```
Runtime Profile: Troubleshooting
Companion Profile: Balanced
```

Then repeat it using:

```
Runtime Profile: Troubleshooting
Companion Mode: Solo
```

Now VRC Eye has a really useful comparison:

```
With VRCX coordination
vs.
Without VRCX coordination
```

without changing all the other diagnostic variables.

---

# Low-Overhead profile interaction

Our planned Low-Overhead runtime profile would keep critical components alive:

```
Runtime Monitor
Black Box
Critical Safety
```

while disabling things like:

```
Player History
Rich Overlay
Integrations
Nonessential Tools
```

In that state, VRCX Companion integration itself might therefore be minimized or disabled depending on exactly what the user configured.

Again, the important thing is that **runtime profile and companion ownership profile remain separate concepts**.

---

# Migration from the older VRCX integration

Architecturally, I would consider this an important transition in the project.

The older idea was closer to:

```
VRC Eye can read useful VRCX cached data.
```

The mature design became:

```
VRC Eye and VRCX are independent products
that can coexist intelligently.
```

That's a much stronger design.

It avoids coupling our project to a VRCX schema or undocumented implementation decision.

It also means a VRCX update is dramatically less likely to break half of VRC Eye.

---

# The intended rollout order

Our roadmap put Companion Mode **after the fundamental VRC Eye architecture exists**.

The conceptual order was:

**Core session/runtime/resource/safety infrastructure → VRCX detection → explicit feature ownership → duplicate suppression/arbitration → handoffs and documented import/export → tandem diagnostics/conflict detection → deeper optional integrations later.**

That sequencing matters.

We don't want to build:

```
VRCX integration
```

and then shape the entire VRC Eye architecture around it.

Instead, VRC Eye should be complete enough to say:

> “I already know how to perform my job. Now I know how to cooperate with VRCX too.”

---

# What Companion Mode explicitly should NOT become

This is probably worth emphasizing more than anything else.

It is **not**:

```
VRCX database editor
```

It is not:

```
undocumented VRCX API client
```

It is not:

```
VRCX replacement mode
```

It is not:

```
VRCX required mode
```

It is not:

```
custom-client mode
```

It is not:

```
bridge mode
```

It is not:

```
one giant merged VRCX/VRC Eye data structure
```

And it absolutely should not become:

```
if VRCX breaks
    VRC Eye breaks
```

The correct relationship is:

```
                     VRChat
                       │
          ┌────────────┴────────────┐
          │                         │
        VRCX                     VRC Eye
          │                         │
Social / history              Runtime / safety
Account tools                 Black Box
Lists                         Diagnostics
Presence                      Hardware
          │                   Player List
          │                   Unity Companion
          │                         │
          └────────────┬────────────┘
                       │
                COMPANION MODE
                       │
                  Cooperation
```

---

# The ultimate user experience

The really polished version shouldn't feel like the user is operating an integration system at all.

They install VRC Eye.

VRC Eye notices VRCX.

It says:

```
VRCX detected.

Enable Companion Mode?

VRC Eye and VRCX can coordinate notifications,
Discord presence, restart behavior, and other
overlapping features.
```

They choose Balanced.

From that point onward:

```
VRCX handles VRCX things.
VRC Eye handles VRC Eye things.
```

No double notifications.

No Discord Rich Presence fighting.

No two programs attempting to restart VRChat simultaneously.

No broken Player List because VRCX was closed.

No Black Box failure because VRCX crashed.

No requirement for a custom-client bridge.

No secret modification of VRCX's database.

No giant monolithic dependency chain.

And if anything goes wrong, Advanced/Developer Mode can explain:

```
what VRCX is doing
what VRC Eye is doing
who owns each feature
what was suppressed
why it was suppressed
what provider failed
what remains functional
and whether the two programs are conflicting
```

That, in essence, was the real vision for **VRCX Companion Mode**: not “VRCX support” as a checkbox, but an actual **coexistence framework** inside VRC Eye.

And with the newer **Black Box / Crash Diagnostics**, **Safety**, **Player List**, and **Unity Player / Runtime Companion** architecture we've subsequently designed, Companion Mode actually makes *more* sense now than it did when we originally came up with it, because the responsibility boundary between the two programs has become much sharper.