"""Read-only local adapter observations for optional peer networking.

A provider label comes from the adapter name or its local Windows driver
metadata. An IP range alone never proves that a VPN is installed. `is_up` is an
OS interface observation, not proof of VPN membership, login or peer reachability.
Registry-only rows describe configured adapters and deliberately use unknown
link state. No discovery packets, subprocesses, accounts or network probes.
"""
from __future__ import annotations

import ipaddress
from itertools import islice
import os
import re
import socket

PROVIDERS = ('LAN', 'Hamachi', 'Tailscale', 'ZeroTier', 'Radmin VPN', 'NetBird', 'Other VPN', 'Relay')
MAX_INTERFACES = 128
MAX_ADDRESSES_PER_INTERFACE = 16
MAX_RECORDS = 256
NETWORK_CLASS = '{4D36E972-E325-11CE-BFC1-08002BE10318}'
_POOL_HAMACHI = ipaddress.ip_network('25.0.0.0/8')
_POOL_TAILSCALE = (ipaddress.ip_network('100.64.0.0/10'), ipaddress.ip_network('fd7a:115c:a1e0::/48'))
_NAMED = (('Hamachi', r'\bhamachi\b'), ('Tailscale', r'\btailscale(?:\d+)?\b'),
          ('ZeroTier', r'\bzero[ -]?tier\b'), ('Radmin VPN', r'\bradmin\b'),
          ('NetBird', r'\bnetbird\b'))
_GENERIC_VPN = re.compile(r'\b(?:vpn|openvpn|wireguard|wintun|tap(?:-windows|\d*)|tun\d*|utun\d*|wg\d+|wt\d+|'
                          r'nordlynx|nordvpn|protonvpn|mullvad|surfshark|softether|anyconnect|forticlient|'
                          r'cloudflare\s*warp|ivpn|windscribe)\b', re.I)


def _label(value, maximum=180):
    if not isinstance(value, str):
        return ''
    # Local adapter labels are display data, not executable commands. Remove
    # control/bidi formatting so the selection UI cannot be visually reordered.
    return ''.join(c for c in value if ord(c) >= 32 and not (0x7f <= ord(c) <= 0x9f or
                  0x202a <= ord(c) <= 0x202e or 0x2066 <= ord(c) <= 0x2069 or
                  0xd800 <= ord(c) <= 0xdfff))[:maximum]


def provider_for(name, description=''):
    """Name/driver classification only; never infer a provider from an address."""
    words = _label(name) + ' ' + _label(description)
    for provider, pattern in _NAMED:
        if re.search(pattern, words, re.I):
            return provider
    # Documented default interface names are local hints, not device identity:
    # docs.netbird.io/get-started/cli (wt0), docs.zerotier.com/route-between-phys-and-virt/ (zt7nnig26).
    local_name = _label(name).casefold()
    if local_name == 'wt0':
        return 'NetBird'
    if re.fullmatch(r'zt[a-z0-9]{6,13}', local_name):
        return 'ZeroTier'
    return 'Other VPN' if _GENERIC_VPN.search(words) else 'LAN'


def _ip(value):
    if not isinstance(value, str) or not 1 <= len(value) <= 128 or value.strip() != value:
        raise ValueError('Choose an IP address literal, not a host name or URL.')
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        raise ValueError('Choose an IP address literal, not a host name or URL.') from None
    if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped is not None:
        raise ValueError('Use a native IPv4 or IPv6 address, not an IPv4-mapped address.')
    if getattr(address, 'scope_id', None):
        raise ValueError('Scoped IPv6 addresses are not supported. Choose IPv4 or a non-link-local IPv6 address.')
    return address


def _sensible(address):
    if address.is_unspecified or address.is_multicast or str(address) == '255.255.255.255':
        raise ValueError('Choose a unicast address, not a wildcard, multicast or broadcast address.')
    if address.version == 6 and address.is_link_local:
        raise ValueError('Link-local IPv6 needs scope routing, which this connection mode does not support.')
    # 0/8 and 240/4 are not sensible peer destinations; 25/8 and 26/8 are
    # deliberately permitted because VPN adapters use those routed ranges.
    if address.version == 4 and (int(address) < 1 << 24 or int(address) >= 240 << 24):
        raise ValueError('This reserved address cannot be used for a peer connection.')
    return address


def _mask(value, version):
    if value is None or value == '':
        return None
    bits = 32 if version == 4 else 128
    try:
        if isinstance(value, int) and not isinstance(value, bool) or isinstance(value, str) and value.isascii() and value.isdigit():
            prefix = int(value)
            if not 0 <= prefix <= bits:
                return None
            numeric = ((1 << bits) - 1) ^ ((1 << (bits - prefix)) - 1)
            return str(ipaddress.IPv4Address(numeric) if version == 4 else ipaddress.IPv6Address(numeric))
        address = ipaddress.ip_address(value)
        if address.version != version or getattr(address, 'scope_id', None):
            return None
        numeric = int(address); prefix = numeric.bit_count()
        if numeric != ((1 << bits) - 1) ^ ((1 << (bits - prefix)) - 1):
            return None
        return str(address)
    except (ValueError, TypeError):
        return None


def _record(name, address, netmask=None, *, description='', is_up=None, source='psutil'):
    try:
        ip = _sensible(_ip(address))
    except ValueError:
        return None
    return dict(name=_label(name) or 'Unnamed adapter', address=str(ip), netmask=_mask(netmask, ip.version),
                provider=provider_for(name, description), is_up=is_up if type(is_up) is bool else None,
                loopback=ip.is_loopback, source=source)


def _reg_value(reg, key, name, default=None):
    try:
        return reg.QueryValueEx(key, name)[0]
    except (OSError, ValueError):
        return default


def _reg_keys(reg, key):
    for index in range(MAX_INTERFACES):
        try:
            yield reg.EnumKey(key, index)
        except OSError:
            return


def _windows_registry(reg=None):
    """Return names/driver descriptions and configured addresses, never link health."""
    if reg is None:
        import winreg as reg
    connections = {}; descriptions = {}; rows = []
    network = r'SYSTEM\CurrentControlSet\Control\Network' + '\\' + NETWORK_CLASS
    classes = r'SYSTEM\CurrentControlSet\Control\Class' + '\\' + NETWORK_CLASS
    interfaces = r'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
    try:
        with reg.OpenKey(reg.HKEY_LOCAL_MACHINE, network) as key:
            for guid in _reg_keys(reg, key):
                try:
                    with reg.OpenKey(key, guid + r'\Connection') as connection:
                        name = _label(_reg_value(reg, connection, 'Name', ''))
                        if name:
                            connections[str(guid).lower()] = name
                except OSError:
                    continue
    except OSError:
        pass
    try:
        with reg.OpenKey(reg.HKEY_LOCAL_MACHINE, classes) as key:
            for index in _reg_keys(reg, key):
                try:
                    with reg.OpenKey(key, index) as driver:
                        guid = _reg_value(reg, driver, 'NetCfgInstanceId', '')
                        description = _label(_reg_value(reg, driver, 'DriverDesc', ''))
                        if isinstance(guid, str) and 1 <= len(guid) <= 80:
                            descriptions[guid.lower()] = description
                except OSError:
                    continue
    except OSError:
        pass
    try:
        with reg.OpenKey(reg.HKEY_LOCAL_MACHINE, interfaces) as key:
            for guid in _reg_keys(reg, key):
                name = connections.get(str(guid).lower(), str(guid))
                description = descriptions.get(str(guid).lower(), '')
                try:
                    with reg.OpenKey(key, guid) as adapter:
                        for address_key, mask_key in (('IPAddress', 'SubnetMask'), ('DhcpIPAddress', 'DhcpSubnetMask')):
                            addresses = _reg_value(reg, adapter, address_key, [])
                            masks = _reg_value(reg, adapter, mask_key, [])
                            if isinstance(addresses, str): addresses = [addresses]
                            if isinstance(masks, str): masks = [masks]
                            if not isinstance(addresses, (list, tuple)): continue
                            if not isinstance(masks, (list, tuple)): masks = []
                            for pos, address in enumerate(addresses[:MAX_ADDRESSES_PER_INTERFACE]):
                                row = _record(name, address, masks[pos] if pos < len(masks) else None,
                                              description=description, is_up=None, source='windows_registry_configured')
                                if row is not None and len(rows) < MAX_RECORDS:
                                    rows.append(row)
                except OSError:
                    continue
    except OSError:
        pass
    metadata = {name.casefold(): descriptions.get(guid, '') for guid, name in connections.items()}
    # Some APIs expose a GUID in place of its friendly name.
    metadata.update(descriptions)
    return metadata, rows


def scan_adapters():
    """Bounded local observations; call from explicit refresh or a network worker."""
    metadata, registry_rows = {}, []
    if os.name == 'nt':
        try:
            metadata, registry_rows = _windows_registry()
        except (ImportError, OSError, ValueError):
            pass
    rows = []
    try:
        import psutil
        addresses = psutil.net_if_addrs()
        try:
            stats = psutil.net_if_stats()
        except (OSError, RuntimeError, NotImplementedError):
            stats = {}
        for index, (name, entries) in enumerate(addresses.items()):
            if index >= MAX_INTERFACES or len(rows) >= MAX_RECORDS:
                break
            status = stats.get(name)
            up = getattr(status, 'isup', None)
            for item in islice(entries, MAX_ADDRESSES_PER_INTERFACE):
                if item.family not in (socket.AF_INET, socket.AF_INET6):
                    continue
                row = _record(name, item.address, item.netmask, description=metadata.get(str(name).casefold(), ''),
                              is_up=up, source='psutil_local_interface')
                if row is not None:
                    rows.append(row)
                    if len(rows) >= MAX_RECORDS:
                        break
    except (ImportError, OSError, RuntimeError, NotImplementedError):
        pass
    seen = {(row['name'].casefold(), row['address']) for row in rows}
    for row in registry_rows:
        key = (row['name'].casefold(), row['address'])
        if key not in seen and len(rows) < MAX_RECORDS:
            rows.append(row); seen.add(key)
    # The built-in IPv4 loopback is useful when optional interface enumeration is
    # unavailable. It claims only local-stack availability, never VPN detection.
    if not any(row['address'] == '127.0.0.1' for row in rows) and len(rows) < MAX_RECORDS:
        rows.append(_record('Loopback', '127.0.0.1', '255.0.0.0', is_up=True, source='local_loopback'))
    return rows[:MAX_RECORDS]


def _records(records):
    if records is None:
        return scan_adapters()
    if not isinstance(records, (list, tuple)) or len(records) > MAX_RECORDS:
        raise ValueError('Invalid local adapter observations.')
    return records


def _provider_pool(mode, address):
    if mode == 'Hamachi' and (address.version != 4 or address not in _POOL_HAMACHI):
        raise ValueError('Hamachi requires an IPv4 address in its 25.0.0.0/8 range.')
    if mode == 'Tailscale' and not any(address.version == pool.version and address in pool for pool in _POOL_TAILSCALE):
        raise ValueError('Tailscale requires its 100.64.0.0/10 or fd7a:115c:a1e0::/48 address.')


def selected_adapter(mode, address, records=None):
    """Validate an observed, up adapter before bind; registry configuration is insufficient."""
    if mode not in PROVIDERS or mode == 'Relay':
        raise ValueError('Choose a supported local network provider.')
    target = _sensible(_ip(address)); _provider_pool(mode, target)
    matches = []
    for row in _records(records):
        if not isinstance(row, dict) or row.get('provider') != mode:
            continue
        try:
            observed = _ip(row.get('address'))
        except ValueError:
            continue
        if observed == target and row.get('is_up') is True:
            matches.append(row)
    if not matches:
        raise ValueError('The selected adapter is unavailable, not up, or belongs to a different provider. Refresh adapters.')
    unique = {(row.get('name'), row.get('address')) for row in matches}
    if len(unique) != 1:
        raise ValueError('The address belongs to more than one adapter. Choose a distinct adapter address.')
    row = matches[0]
    return dict(name=_label(row.get('name')) or 'Unnamed adapter', address=str(target),
                netmask=_mask(row.get('netmask'), target.version), provider=mode, is_up=True,
                loopback=target.is_loopback, source=_label(row.get('source')))


def _network(row):
    address = _ip(row['address']); mask = _mask(row.get('netmask'), address.version)
    if mask is None:
        return None
    prefix = int(ipaddress.ip_address(mask)).bit_count()
    bare = str(address).split('%')[0]
    return ipaddress.ip_network(bare + '/' + str(prefix), strict=False)


def _compatible(source, destination):
    if source.version != destination.version:
        raise ValueError('Source adapter and destination must use the same IP version.')
    if source.is_loopback != destination.is_loopback:
        raise ValueError('Loopback destinations require a loopback source, and remote destinations require a remote adapter.')
    if source.is_link_local != destination.is_link_local and destination.is_link_local:
        raise ValueError('A link-local destination requires a link-local adapter source.')


def choose_source(mode, destination, source_address='', records=None):
    """Select one usable matching adapter or require explicit disambiguation.

Known subnets prefer the directly attached route when several adapter addresses
exist. They do not forbid operator-configured routed/custom ZeroTier, NetBird or
other VPN networks. This function does not inspect or alter the OS route table.
"""
    if mode not in PROVIDERS or mode == 'Relay':
        raise ValueError('Relay endpoints do not use a local VPN adapter selection.')
    destination_ip = _sensible(_ip(destination)); _provider_pool(mode, destination_ip)
    observed = _records(records)
    if mode == 'Other VPN' and not source_address:
        raise ValueError('Other VPN requires an explicit local VPN adapter selection.')
    if source_address:
        row = selected_adapter(mode, source_address, observed)
        _compatible(_ip(row['address']), destination_ip)
        network = _network(row)
        if network and destination_ip.version == 4 and destination_ip in network and network.prefixlen < 31:
            if destination_ip in (network.network_address, network.broadcast_address):
                raise ValueError('The destination is a subnet or broadcast address, not a peer.')
        return row['address']
    candidates = []
    for row in observed:
        if not isinstance(row, dict) or row.get('provider') != mode or row.get('is_up') is not True:
            continue
        try:
            validated = selected_adapter(mode, row.get('address'), observed)
            _compatible(_ip(validated['address']), destination_ip)
        except ValueError:
            continue
        if validated not in candidates:
            candidates.append(validated)
    nearby = [row for row in candidates if (network := _network(row)) is not None and destination_ip in network]
    if nearby:
        best_prefix = max(_network(row).prefixlen for row in nearby)
        candidates = [row for row in nearby if _network(row).prefixlen == best_prefix]
    if len(candidates) != 1:
        raise ValueError('Choose an explicit up adapter for this provider and IP version; automatic selection is unavailable or ambiguous.')
    # Reuse all explicit-source checks, including subnet broadcast rejection.
    return choose_source(mode, destination, candidates[0]['address'], observed)
