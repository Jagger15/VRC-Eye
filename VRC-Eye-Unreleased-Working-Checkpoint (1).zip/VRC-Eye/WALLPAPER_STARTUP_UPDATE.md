# Wallpapers and automatic Pillow setup

Normal starts through `Start.cmd` on Windows, `bash Start.sh` on Linux, or
`python vrc_eye.py` now check and prepare the application-local environment.
If Pillow is missing or outside the supported range, startup downloads and
installs it first. This separate step allows image support to install even
when another optional feature package cannot be resolved. The next check
verifies the Pillow image decoder and ImageTk import, including a tiny pixel
operation. A broken installed copy receives a targeted reinstall. Healthy
copies are reused without reinstalling them on each launch.

Setup keeps using the existing local environment, supported version range,
OS-owned startup lock, isolated pip configuration, binary wheels and bounded
timeouts. It does not install packages into the system Python. Failed or
offline installation still opens available features and retries on a later
normal start. The child launch consumes a marker to prevent an installation
or relaunch loop after failure. Safe Mode, Demo, help and version commands
continue to skip package setup. Importing the entry-point module is passive.

In **Customization → Appearance → Choose background image**, PNG files now
work without Pillow. The standard-library fallback covers palette, grayscale,
RGB/RGBA, transparency, 16-bit samples and interlaced PNGs. It retains the
20 MiB input and 16-million-pixel bounds, saves a metadata-free local copy up
to 2560 × 1440, and displays centered cover images with 0–100% opacity. Its
resizing uses point sampling; Pillow provides the existing smoother filtering
when installed. JPEG/WebP imports and rounded controls still use Pillow.
Already-saved wallpapers remain readable when Pillow is unavailable.

Image checksums, account/privacy guards, read-only modes, high contrast,
source preservation and portable-profile exclusions remain in place. An
existing rounded-controls preference no longer blocks unrelated opacity
changes when Pillow is missing. Setup health and the picker explain which
formats work without an extra package.

Validation: **91 tests and 27 subtests passed; six graphical tests skipped**
because no native display was available. The focused run covers bootstrap,
direct entry, Pillow priority and repair, wallpaper codecs and UI callbacks,
saved copies, alpha/opacity, malformed PNGs and privacy/account boundaries.
A clean Python `-S` subprocess completed import, save, reload and compositing
with no site packages or Pillow. Install commands were exercised using
controlled runners; no real package download, Windows UI or Linux graphical
session was exercised here. Previous full-suite results describe the earlier
checkpoint. The current build identity remains unchanged; this update does
not create a numbered release, executable or installer.
