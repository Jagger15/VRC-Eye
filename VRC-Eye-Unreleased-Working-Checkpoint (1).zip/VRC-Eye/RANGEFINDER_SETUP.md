# Pointing rangefinder — VRC Eye 1.19.5

This feature shows distance in **feet** to the first remote-player collider your avatar's ray hits. It needs an uploaded avatar configured with the included Unity helper. It does not need VRCX, exported JSON, API sign-in, or a script installed in the world.

**Recognize your friend visually, then aim.** The signal has no player name or user ID. It cannot label a reading as your friend's, follow a selected username, point you toward someone, or establish who is behind a wall. Measurements are kept separate from the log's player rows and CSV.

## 1. Create your avatar copy in Unity

Use a PC avatar project opened through VRChat Creator Companion, with the **Avatars SDK 3.10.5 or newer** and its supported Unity version. The helper expects a humanoid rig and the normal VRChat project layers. It is an editor tool, not an Udon script.

1. Copy `Unity/Editor/VRCEyeRangefinderSetup.cs` from this ZIP into `Assets/VRCEye/Editor/` in your avatar project. Wait for Unity to compile it.
2. Put your avatar in the scene and select its root object with the **VRC Avatar Descriptor**.
3. Open **Tools → VRC Eye → Set up pointing rangefinder**.
4. Choose **Right hand**, **Left hand**, or **Head (desktop or VR)**. Head aiming is the practical option in desktop mode.
5. Click **Create rangefinder avatar copy**.

The helper creates a separate scene object named `<your avatar> - VRC Eye rangefinder`. It copies the FX controller and expression-parameter asset into a unique folder under `Assets/VRCEyeGenerated/`; it does not modify those original assets. Existing animation clips and menus can remain shared references because the helper does not edit them. The original scene avatar is disabled after success so you can test the copy. Re-enable it to use it again.

The copy's blueprint ID is cleared for a **new upload**. The helper does not publish anything. Standard FX controllers are supported; an Animator Override Controller, reserved parameter-name conflict, missing bones, or insufficient parameter capacity produces an error. Avatar tools that regenerate FX controllers during a build may require their own integration; verify the generated output before uploading.

## 2. Check alignment and the generated signal

The new rig is `AWRangeRig`. A VRChat parent constraint follows your selected bone without parenting the ray underneath the head's chopped transform. Its child **Emitter - aim its blue Z axis** is the ray origin. Adjust this child's local rotation/position if the default direction does not match your pointing pose. A short cyan marker shows the direction when the local rig is active; it is not a full-length beam or a nameplate marker.

The helper starts the rig inactive. Its added FX layer enables it when `IsLocal` is true and runs a looping heartbeat. Remote copies keep the rig disabled.

For an editor check, use the generated `FX.controller` on the copy's root Animator while in Play mode, select **Local measuring** by setting `IsLocal` true, and inspect the Animator parameters below. Changes made only in Play mode revert when you leave it. A test object with a collider on layer **Player (9)** can stand in for a remote player's collider; remove that test object afterward. This editor check is not a substitute for testing with a friend in VRChat.

| Parameter | Type | Expected behavior |
| --- | --- | --- |
| `AWRange_Hit` | Bool | True while a player collider is hit; false on a miss. |
| `AWRange_Ratio` | Float | Hit distance divided by the configured 100-meter ray length. |
| `AWRange_Heartbeat` | Float | Continuously cycles between about 0.1 and 0.9, including while standing still. |

All three expression parameters are **unsaved and not network-synced**. Keep their names unchanged. The helper's ray uses **100 meters**, has **Apply Transform Scale disabled**, and tests only the **Player (9)** layer, excluding your local capsule. Its miss behavior is **Snap To Start**. VRC Eye requires the explicit hit flag and heartbeat; it never treats a maximum range or a missing value as a player distance.

The feet conversion is `ratio × configured ray length in meters ÷ 0.3048`. For example, a ratio of `0.03048` with a 100-meter ray is **10 feet**. The reading is from the emitter to the collider surface, not from your avatar's center to the other player's center. In-world visual scale and collider shape can differ from what you expect.

Upload the generated copy through the usual SDK workflow after checking it. Wear that uploaded copy in VRChat.

## 3. Connect VRC Eye

1. Extract the complete `VRC-Eye-v1.19.5.zip` and run **Start.cmd**.
2. Open **World → Rangefinder…**. Keep **Avatar ray length = 100 meters** for the default helper. Use **Networking** to configure the shared OSC receiver; there is no separate rangefinder port field.
3. Click **Start listening**.
4. In VRChat's Action Menu, enable **OSC → Enabled**. If it was already enabled, toggle it off and on after the listener starts so it can receive fresh parameter values.
5. Point at a player, point away, then point back. Moving your aim slightly initializes values if VRChat only sends parameters when they change.

The window displays a large feet reading, **No hit**, or a waiting/error message. **Keep this rangefinder on top** keeps this desktop window visible above other desktop windows; it does not create an in-headset overlay. You can view it through your headset's existing desktop view.

The rangefinder subscribes to VRC Eye's shared OSC receiver. Normal startup can prepare passive loopback observation; **Start listening** attaches this view, and Stop/window close detaches only this view. App exit closes the shared port. The included avatar helper remains intended for VRChat on the same PC; LAN tracking accuracy and standalone-headset behavior have not been validated. See [OSC_CONTROLS_SETUP.md](OSC_CONTROLS_SETUP.md) for shared transport and discovery.

## 4. Troubleshooting

| Symptom | Check |
| --- | --- |
| Cannot listen / another OSC app uses the port | Choose free-port fallback in Networking and advertise the shared receiver with OSCQuery, or explicitly configure a separate manual output port. VRC Eye never takes over another listener. |
| Need a different VRChat output port | For example, VRChat's launch option `--osc=9000:127.0.0.1:9002` sends output to 9002; then choose receive port 9002 under Networking → OSC transport. This changes routing for other OSC apps too. Remove/change the option to restore your previous routing. |
| Waiting for avatar signal | Wear the modified uploaded copy, enable OSC, and check that `AWRange_Heartbeat` actually changes in the generated FX layer. Verify all three parameters appear in your avatar's OSC output. |
| Avatar was uploaded before these parameters existed | Use VRChat's OSC configuration reset option for the current avatar, then toggle OSC. This resets custom address mappings for that avatar; keep any mappings you need first. Reuploading alone may leave an older OSC configuration. |
| Heartbeat received, but waiting for hit/distance | Aim at a player, away, then back and move the ray slightly. Check `AWRange_Hit`/`AWRange_Ratio` in the Unity Animator or an OSC output monitor. Use OSCQuery or a separately configured port for another monitor; a second process cannot bind the same exclusive port. VRChat's OSC Debug panel primarily displays incoming OSC; it does not establish that this outgoing signal is present. |
| No hit | Check the emitter's direction, the target's player collider, range, and ray settings. The short marker should follow your chosen hand/head. |
| Signal stopped | No changing heartbeat arrived for over 3 seconds. Check OSC, avatar state, and the port. Reinitialize by pointing away and back once the signal resumes. Old measurements are discarded. |
| Readings seem scaled incorrectly | Keep both ray lengths at 100 meters, or deliberately set the same new length in Unity and VRC Eye. Keep Apply Transform Scale off. |
| Marker or heartbeat fails on a complex avatar | Check whether another animation, layer mask, or build-time avatar tool overrides the added rig or FX layer. Review the copy in Unity and the uploaded result. |

The configured ray ignores world-geometry layers, so walls are not used to validate visibility. Another player closer along the same ray wins. The software cannot tell which person produced a hit. Collider behavior and avatar/world settings can affect results; compatibility with every world is not established.

OSC is UDP and parameters are often sent only when they change. The heartbeat detects a stopped stream, but it cannot guarantee that every hit/distance packet arrived. After an unexpected reading, aim away and back. The result is a convenience measurement, not a guaranteed live location record.

## Validation and implementation references

The Python protocol, measurement state, real loopback sockets, and UI callbacks have automated tests. SDK type/member names were checked against the official 3.10.5 assemblies. **Unity compilation, avatar upload, actual OSC from VRChat, native Windows layout, and live distance accuracy have not been tested in this build environment.** There is no Unity editor or VRChat client available here.

- [VRChat raycast component](https://creators.vrchat.com/avatars/avatar-components/raycast/)
- [OSC ports and enabling OSC](https://docs.vrchat.com/docs/osc-overview)
- [OSC avatar parameter output and configuration](https://docs.vrchat.com/docs/osc-avatar-parameters)
- [VRChat player layers](https://creators.vrchat.com/worlds/layers/)
- [VRChat constraints](https://creators.vrchat.com/common-components/constraints/)
- [Official SDK package index](https://vrchat.github.io/packages/index.json)
