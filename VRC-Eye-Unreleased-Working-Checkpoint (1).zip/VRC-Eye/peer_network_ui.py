"""Explicit connection setup, saved routes and status for VRC Eye networking.

Opening or closing this page never starts or stops the application-owned service.
VPN discovery reads local adapter metadata only; it cannot prove peer reachability.
"""
from copy import deepcopy
import time

from companion_ui import Page, Table, button, choice, entry, line
from peer_ui import readable, set_table, format_time


MODES = ('LAN', 'Hamachi', 'Tailscale', 'ZeroTier', 'Radmin VPN', 'NetBird', 'Other VPN', 'Relay')
TABS = ('Easy Connect', 'Profiles & adapters', 'Connection status', 'OSC transport', 'Developer API', 'Client Bridge')
DIRECT_NOTICE = ('Direct and VPN connections disclose a network endpoint to the other peer. '
                 'A VPN adapter does not establish whether its provider uses a direct or relayed path.')
RELAY_NOTICE = ('Relay mode keeps each peer’s network address out of the other peer’s connection. '
                'Your relay operator still sees your address and traffic metadata. Pairing uses an '
                'encrypted peer tunnel. VRC Eye does not provide a public relay.')


class NetworkingPage(Page):
    def __init__(self, shell, parent):
        super().__init__(shell, parent, 'Networking', task_controls=False)
        self.service = getattr(self.app, 'peer_service', None)
        if self.service is None:
            raise ValueError('VRC Eye Peer Services is unavailable.')
        self.last_draw = -float('inf')
        self.loaded_profile_id = None
        self.loaded_profile = None
        self.adapter_records = []
        self.last_boundary = None
        self.mobile_invitation = None
        self.summary = self.tk.StringVar()
        self.label(parent, self.summary)
        row = line(self)
        button(self, row, 'Private Mode / disconnect all', self.private_mode)
        button(self, row, 'Eye-to-Eye', lambda: self.shell.show('VRC Eye Primary'))
        settings = self.service.network_settings()
        self.relay_only = self.tk.BooleanVar(value=bool(settings.get('relay_only', False)))
        self.ttk.Checkbutton(parent, text='Hide my IP from peers (relay only)', variable=self.relay_only,
                             command=lambda: self.guard(self.save_privacy)).pack(anchor='w', pady=5)
        self.note(parent, 'Relay-only privacy blocks direct and VPN hosting or joining, and ends an existing '
                  'direct connection when enabled. The relay operator still sees your IP. Private Mode '
                  'disables peer networking while local VRC Eye tools remain available.')
        self.tabs = self.ttk.Notebook(parent)
        self.tabs.pack(fill='both', expand=True)
        self.frames, self.panes = {}, {}
        from resource_ui import ResourcePage
        for name in TABS:
            frame = self.ttk.Frame(self.tabs)
            self.tabs.add(frame, text=name)
            self.frames[name] = frame
            self.panes[name] = ResourcePage.scrolling_pane(self, frame)
        self.build_easy_connect()
        self.build_profiles()
        self.build_status()
        from osc_ui import OSCTransportPanel
        self.osc_transport = OSCTransportPanel(self.panes["OSC transport"], self.app)
        from developer_ui import DeveloperNetworkPanel
        self.developer_api = DeveloperNetworkPanel(self, self.panes['Developer API'])
        pane=self.panes['Client Bridge']
        self.heading(pane,'Optional local client bridge')
        self.note(pane,'Connection settings and per-capability permissions use the existing authenticated local bridge supervisor. Opening this page never starts a listener, grants telemetry, enables controls, or connects to VRChat.')
        self.note(pane,'A compatible voluntary provider must implement the named Client Lab contracts. This release supplies an SDK and isolated fixtures, not a modified VRChat client. Provider identity, scope and measurements are claims, not independently verified compatibility.')
        from bridge_dialog import show_bridge
        button(self,line(self,pane),'Open connection & capability permissions',lambda:show_bridge(self.app))
        button(self,line(self,pane),'Open Developer Client Bridge Lab',lambda:self.app.experience.open_tool('developer:Client Bridge Lab'))
        self.note(pane,'Use the supervisor to enable the local named pipe or Unix socket, approve capabilities, and explicitly enable game controls. Lab actions also require their separate session arming and exact per-action review. Developer access alone grants none of these permissions.')
        self.render()
        self.status.set('Choose Create or Join when ready. Opening this page does not connect or scan adapters.')

    def label(self, parent, variable):
        self.ttk.Label(parent, textvariable=variable, wraplength=920, justify='left').pack(anchor='w', pady=5)

    def note(self, parent, text):
        self.ttk.Label(parent, text=text, wraplength=920, justify='left', style='Muted.TLabel').pack(anchor='w', pady=5)

    def heading(self, parent, text):
        self.ttk.Label(parent, text=text, style='Title.TLabel').pack(anchor='w', pady=(12, 5))

    def field(self, parent, title, value='', options=None, width=52):
        row = line(self, parent)
        self.ttk.Label(row, text=title, width=24).pack(side='left')
        variable = self.tk.StringVar(value=value)
        if options:
            choice(self, row, variable, options, width=width)
        else:
            entry(self, row, variable, width)
        return variable

    def guard(self, action):
        try:
            return super().guard(action)
        except RuntimeError as error:
            self.status.set(str(error))

    def active(self):
        if self.closed:
            raise ValueError('This page is closed.')
        if self.app.demo or getattr(self.app, 'safe_mode', False):
            raise ValueError('Leave Demo or Safe Mode before changing network settings or connecting.')
        snapshot = self.service.snapshot()
        if snapshot.get('state') in ('BLOCKED', 'CLOSED') or snapshot.get('privacy', {}).get('incognito'):
            raise ValueError(snapshot.get('reason') or 'Peer networking is disabled by the current privacy or environment settings.')

    def build_easy_connect(self):
        pane = self.panes['Easy Connect']
        self.note(pane, 'Easy Connect guides explicit setup using your saved connection profiles. For a VPN, '
                  'install and join the same provider network separately before selecting its local adapter. '
                  'For Relay, obtain the relay address, port and TLS fingerprint from its operator. '
                  'VRC Eye never installs a VPN, signs in to its account or connects automatically.')
        self.heading(pane, '1. Choose a connection method')
        self.mode = self.field(pane, 'Connection method', 'LAN', MODES, 22)
        self.method_help = self.tk.StringVar(value=DIRECT_NOTICE)
        self.label(pane, self.method_help)
        button(self, line(self, pane), 'Choose a local adapter…', lambda: self.tabs.select(self.frames['Profiles & adapters']))
        self.heading(pane, '2. Create a connection for others to join')
        self.profile_name = self.field(pane, 'Profile name', 'My connection')
        self.address = self.field(pane, 'Local / relay address', '127.0.0.1')
        self.port = self.field(pane, 'Port (0 = automatic)', '0', width=12)
        self.relay_pin = self.field(pane, 'Relay TLS fingerprint', '', width=68)
        self.note(pane, 'For LAN or VPN hosting, choose the local adapter address. For Relay, enter the relay '
                  'server address and its nonzero port. A profile stores these settings, never invitation '
                  'secrets. Saving or loading a profile does not start networking.')
        row = line(self, pane)
        button(self, row, 'Save connection profile', self.save_profile)
        button(self, row, 'Review & create connection…', self.create_connection)
        self.heading(pane, '3. Invite one person after hosting is ready')
        row = line(self, pane)
        button(self, row, 'Create one-use invitation', self.invite)
        button(self, row, 'Connect mobile · QR…', self.invite_mobile)
        self.invitation = self.field(pane, 'Invitation to give a peer', '', width=70)
        self.note(pane, 'Give this invitation only to its intended recipient. It expires and can be used '
                  'once. Create another for each peer. An invitation does not grant access to saved content.')
        self.heading(pane, 'Or join a connection someone shared')
        self.join_token = self.field(pane, 'Invitation you received', '', width=70)
        self.source_address = self.field(pane, 'Local source adapter IP', '', width=40)
        self.note(pane, 'For a direct VPN invitation, choose its matching local adapter in Profiles & adapters. '
                  'LAN may use the operating system route when this field is blank. Relay uses the operating '
                  'system route and does not use a selected source adapter.')
        row = line(self, pane)
        button(self, row, 'Inspect invitation', self.inspect_invitation)
        button(self, row, 'Review & join…', self.join)
        self.invitation_preview = self.tk.StringVar(value='Inspect an invitation to see its route and pinned device identity. Its secret is never included in this preview.')
        self.label(pane, self.invitation_preview)

    def build_profiles(self):
        pane = self.panes['Profiles & adapters']
        self.heading(pane, 'Saved connection profiles')
        self.profiles = Table(self, pane, (('name', 'Name', 180), ('mode', 'Method', 120),
                              ('endpoint', 'Local / relay endpoint', 280)), height=6)
        row = line(self, pane)
        button(self, row, 'Load selected profile', self.load_profile)
        button(self, row, 'New profile', self.new_profile)
        button(self, row, 'Delete selected profile…', self.delete_profile)
        self.note(pane, 'A loaded profile fills Easy Connect. Use Review & create connection there to start it. '
                  'Profiles create a host route; joining always requires a fresh invitation.')
        self.heading(pane, 'Local adapter discovery')
        button(self, line(self, pane), 'Refresh local adapters', self.refresh_adapters)
        self.adapters = Table(self, pane, (('name', 'Adapter', 190), ('address', 'Address', 140),
                              ('provider', 'Observed provider', 140), ('state', 'Local link', 90),
                              ('source', 'Evidence', 170)), height=8)
        row = line(self, pane)
        button(self, row, 'Use adapter for hosting', self.use_host_adapter)
        button(self, row, 'Use adapter for joining', self.use_join_adapter)
        self.adapter_details = self.tk.StringVar(value='Refresh reads local adapter metadata only. It does not contact another device.')
        self.label(pane, self.adapter_details)
        self.note(pane, 'Adapter names are observational hints, not authenticated provider membership. '
                  'An adapter being up does not mean any peer is connected or reachable. Registry-only '
                  'configuration cannot establish link state; such an adapter cannot be selected until '
                  'live local state is available.')

    def build_status(self):
        pane = self.panes['Connection status']
        self.connection_details = self.tk.StringVar()
        self.label(pane, self.connection_details)
        self.peers = Table(self, pane, (('name', 'Peer / device', 190), ('state', 'Connection', 110),
                           ('version', 'Version', 90), ('latency', 'VRC Eye service latency', 160)),
                           height=8, select=self.inspect_peer)
        row = line(self, pane)
        button(self, row, 'Disconnect selected peer', self.disconnect)
        button(self, row, 'Open peer in VRC Eye Primary', self.open_peer)
        self.peer_details = self.tk.StringVar(value='Select a peer to inspect authenticated device identity and negotiated capabilities.')
        self.label(pane, self.peer_details)
        self.note(pane, 'Device identity is not a verified VRChat account identity. Service latency is not '
                  'VRChat ping. A detected VPN adapter does not prove the provider’s underlying direct or '
                  'relayed path; only observed VRC Eye transport state is reported here.')

    def profile_record(self):
        try:
            port = int(self.port.get())
        except ValueError:
            raise ValueError('Enter a numeric port from 0 to 65535.') from None
        if not 0 <= port <= 65535:
            raise ValueError('Enter a port from 0 to 65535.')
        mode = self.mode.get()
        if mode not in MODES:
            raise ValueError('Choose a supported connection method.')
        record = {'name': self.profile_name.get().strip(), 'mode': mode,
                  'address': self.address.get().strip(), 'port': port,
                  'relay_pin': self.relay_pin.get().strip() if mode == 'Relay' else ''}
        if not record['name'] or not record['address']:
            raise ValueError('Enter a profile name and a local or relay address.')
        if mode == 'Relay' and (not port or len(record['relay_pin']) != 64):
            raise ValueError('Relay requires its server port and 64-character TLS fingerprint.')
        return record

    def save_profile(self):
        self.active()
        record = self.service.save_connection_profile(self.profile_record(), profile_id=self.loaded_profile_id)
        self.loaded_profile_id, self.loaded_profile = record['id'], deepcopy(record)
        self.status.set('Connection profile saved. Networking has not started.')
        self.render()
        return record

    def selected_profile(self):
        record = self.profiles.selected()
        if not record:
            raise ValueError('Select a saved connection profile first.')
        return record

    def load_profile(self):
        record = self.selected_profile()
        self.loaded_profile_id, self.loaded_profile = record['id'], deepcopy(record)
        for key, variable in (('name', self.profile_name), ('mode', self.mode), ('address', self.address),
                              ('port', self.port), ('relay_pin', self.relay_pin)):
            variable.set(str(record.get(key, '')))
        self.tabs.select(self.frames['Easy Connect'])
        self.status.set('Profile loaded. Review & create connection starts it explicitly.')
        self.render()

    def new_profile(self):
        self.loaded_profile_id = self.loaded_profile = None
        self.profile_name.set('My connection')
        self.mode.set('Relay' if self.service.network_settings().get('relay_only') else 'LAN')
        self.address.set('127.0.0.1')
        self.port.set('0')
        self.relay_pin.set('')
        self.tabs.select(self.frames['Easy Connect'])
        self.status.set('New profile ready to edit. No connection started.')

    def delete_profile(self):
        self.active()
        record = self.selected_profile()
        if not self.confirm('Delete connection profile', f"Delete saved profile “{record['name']}”?\n\nThis removes its saved route, not an active connection."):
            return
        self.active()
        current = next((row for row in self.service.network_settings()['profiles'] if row['id'] == record['id']), None)
        if current != record:
            raise ValueError('This saved profile changed during review. Select it again.')
        self.service.delete_connection_profile(record['id'])
        if self.loaded_profile_id == record['id']:
            self.loaded_profile_id = self.loaded_profile = None
        self.status.set('Saved connection profile deleted.')
        self.render()

    def review_stamp(self):
        data = self.service.snapshot()
        settings = self.service.network_settings()
        return (self.context(), getattr(self.app, 'data_generation', None), bool(getattr(self.app, 'safe_mode', False)),
                data.get('state'), data.get('mode'), bool(settings.get('relay_only')),
                tuple(sorted((p['peer_id'], p.get('session', ''), p.get('state', '')) for p in data.get('peers', []))))

    def create_connection(self):
        self.active()
        record = self.profile_record()
        settings = self.service.network_settings()
        snapshot = self.service.snapshot()
        if snapshot.get('transport') and snapshot.get('state') != 'PRIVATE':
            raise ValueError('Enter Private Mode before creating a different connection.')
        if settings.get('relay_only') and record['mode'] != 'Relay':
            raise ValueError('Hide my IP from peers permits Relay connections only.')
        profile_id = self.loaded_profile_id
        original_profile = next((row for row in settings['profiles'] if row['id'] == profile_id), None)
        stamp = self.review_stamp()
        text = (readable(record) + '\n\n' + (RELAY_NOTICE if record['mode'] == 'Relay' else DIRECT_NOTICE)
                + '\n\nSave this profile and create the connection? Enter Private Mode before changing an active connection. Nothing is published automatically.')
        if not self.confirm('Create VRC Eye connection', text):
            return
        self.active()
        if self.profile_record() != record or self.loaded_profile_id != profile_id or self.review_stamp() != stamp:
            raise ValueError('Connection settings changed during review. Review them again before connecting.')
        current_profile = next((row for row in self.service.network_settings()['profiles'] if row['id'] == profile_id), None)
        if current_profile != original_profile:
            raise ValueError('The saved profile changed during review. Reload it before connecting.')
        saved = self.service.save_connection_profile(record, profile_id=profile_id)
        self.loaded_profile_id, self.loaded_profile = saved['id'], deepcopy(saved)
        self.service.start_connection_profile(saved['id'])
        self.invitation.set('')
        self.status.set('Connection setup requested. Create an invitation after the service reports it is ready.')
        self.render()

    def invite(self):
        self.active()
        self.invitation.set(self.service.invite())
        self.status.set('One-use invitation created. Give it only to the intended person.')

    def invite_mobile(self):
        from mobile_pairing import MobileInvitation
        if self.mobile_invitation:self.mobile_invitation.close()
        self.mobile_invitation=MobileInvitation(self)

    @staticmethod
    def safe_invitation_preview(details):
        # Explicit allowlist: an unexpected provider field must never echo a token.
        names = ('mode', 'endpoint', 'address', 'port', 'expires_at', 'device_id', 'pin',
                 'relay_pin', 'endpoint_visibility', 'available', 'reason')
        clean = {key: details.get(key) for key in names if key in details}
        if 'expires_at' in clean:
            clean['expires_at'] = format_time(clean['expires_at'])
        return clean

    def inspect_invitation(self):
        token = self.join_token.get().strip()
        if not token:
            raise ValueError('Paste an invitation first.')
        details = self.service.inspect_invitation(token)
        self.invitation_preview.set(readable(self.safe_invitation_preview(details)))
        return details

    def join(self):
        self.active()
        token = self.join_token.get().strip()
        if not token:
            raise ValueError('Paste an invitation first.')
        source = self.source_address.get().strip()
        details = self.service.inspect_invitation(token)
        if not details.get('available', True):
            raise ValueError(details.get('reason') or 'This invitation is not currently usable.')
        mode = details['mode']
        if mode == 'Relay' and source:
            raise ValueError('Clear the local source adapter for Relay; it uses the operating system route.')
        if mode not in ('LAN', 'Relay') and not source:
            raise ValueError('Choose a matching local VPN adapter before reviewing this invitation.')
        stamp = self.review_stamp()
        preview = self.safe_invitation_preview(details)
        preview['local_source'] = source or 'Operating system route'
        preview['selected_provider'] = mode
        if source:
            local = next((row for row in self.adapter_records if row['address'] == source), None)
            preview['source_provider'] = local['provider'] if local else 'Manual source address; validated before connecting'
        text = (readable(preview) + '\n\n' + (RELAY_NOTICE if mode == 'Relay' else DIRECT_NOTICE)
                + '\n\nJoin this pinned device? No profile, draft or permission is published automatically.')
        self.invitation_preview.set(readable(preview))
        if not self.confirm('Join VRC Eye connection', text):
            return
        self.active()
        if self.join_token.get().strip() != token or self.source_address.get().strip() != source or self.review_stamp() != stamp:
            raise ValueError('Connection settings changed during review. Inspect the invitation again.')
        current = self.service.inspect_invitation(token)
        if current != details or not current.get('available', True):
            raise ValueError('The invitation or its eligibility changed during review. Inspect it again.')
        self.service.join(token, source_address=source)
        self.join_token.set('')
        self.status.set('Connection requested. Wait for the authenticated peer handshake before sharing.')
        self.render()

    def save_privacy(self):
        try:
            self.active()
            self.service.set_network_privacy(relay_only=bool(self.relay_only.get()))
        except Exception:
            self.relay_only.set(bool(self.service.network_settings().get('relay_only', False)))
            raise
        if self.relay_only.get():
            self.invitation.set('')
        self.status.set('Connection privacy saved. Relay operator visibility is unchanged.')
        self.render()

    def private_mode(self):
        self.service.private_mode()
        self.invitation.set('')
        self.join_token.set('')
        self.invitation_preview.set('Private Mode enabled. Invitations were cleared from this page.')
        self.status.set('Peer networking stopped. Local VRC Eye tools and saved profiles remain available.')
        self.render()

    def refresh_adapters(self):
        from peer_adapters import scan_adapters
        self.adapter_records = scan_adapters()
        self.adapters.set(self.adapter_records, lambda row: (row['name'], row['address'], row['provider'],
                    'Up' if row['is_up'] is True else 'Down' if row['is_up'] is False else 'Unknown', row['source']))
        self.adapter_details.set(f'{len(self.adapter_records)} local adapter addresses found. This does not establish any peer connection.')
        self.status.set('Local adapter metadata refreshed. No network probe was sent.')

    def selected_adapter(self):
        record = self.adapters.selected()
        if not record:
            raise ValueError('Refresh local adapters and select a row first.')
        if record.get('is_up') is not True:
            raise ValueError('The selected adapter is not observed up. Start its connection in the provider app, then refresh.')
        return record

    def use_host_adapter(self):
        record = self.selected_adapter()
        self.mode.set(record['provider'] if record['provider'] in MODES else 'Other VPN')
        self.address.set(record['address'])
        self.adapter_details.set(readable(record))
        self.tabs.select(self.frames['Easy Connect'])
        self.status.set('Local adapter selected for hosting. Review & create connection starts it explicitly.')
        self.render()

    def use_join_adapter(self):
        record = self.selected_adapter()
        self.source_address.set(record['address'])
        self.adapter_details.set(readable(record))
        self.tabs.select(self.frames['Easy Connect'])
        self.status.set('Local source adapter selected for joining. The invitation determines the connection method.')

    def selected_peer(self):
        record = self.peers.selected()
        if not record:
            raise ValueError('Select a peer in Connection status first.')
        return record

    def disconnect(self):
        self.active()
        self.service.disconnect(self.selected_peer()['peer_id'])
        self.status.set('Selected peer disconnected.')
        self.render()

    def inspect_peer(self):
        record = self.peers.selected()
        if record:
            fields = ('peer_id', 'alias', 'state', 'version', 'session', 'availability', 'latency_ms',
                      'clock_offset_ms', 'clock_uncertainty_ms', 'compatibility', 'capabilities')
            self.peer_details.set(readable({key: record.get(key) for key in fields if key in record}))

    def open_peer(self):
        peer = self.selected_peer()
        self.shell.show('VRC Eye Primary')
        page = self.shell.pages.get('VRC Eye Primary')
        if page is not None:
            page.focus_peer(peer['peer_id'])

    def focus_peer(self, peer_id):
        self.render()
        for key, record in self.peers.records.items():
            if record['peer_id'] == peer_id:
                self.peers.tree.selection_set(key)
                break
        self.tabs.select(self.frames['Connection status'])
        self.inspect_peer()

    def render(self):
        if self.closed:
            return
        data = self.service.snapshot()
        settings = self.service.network_settings()
        boundary = (self.context(), getattr(self.app, 'data_generation', None), bool(getattr(self.app, 'safe_mode', False)), data.get('state'), data.get('mode'))
        if self.last_boundary is not None and boundary != self.last_boundary:
            account_changed = boundary[:3] != self.last_boundary[:3]
            paused = data.get('state') in ('PRIVATE', 'BLOCKED', 'CLOSED') or data.get('mode') == 'Private'
            if account_changed or paused:
                self.invitation.set('')
                self.join_token.set('')
                self.invitation_preview.set('Connection context changed. Inspect a fresh invitation before joining.')
        self.last_boundary = boundary
        recovery = settings.get('recovery_reason')
        self.summary.set(f"{data.get('mode', 'Private')} · {data.get('state', 'PRIVATE')} — {data.get('reason', '')}" + ('\nRecovery: ' + recovery if recovery else ''))
        self.relay_only.set(bool(settings.get('relay_only')))
        self.method_help.set(RELAY_NOTICE if self.mode.get() == 'Relay' else DIRECT_NOTICE)
        set_table(self.profiles, settings.get('profiles', []), lambda row: (row['name'], row['mode'], f"{row['address']}:{row['port']}"))
        transport = data.get('transport', {})
        fields = ('state', 'mode', 'provider', 'network_path', 'endpoint_visibility', 'source_address',
                  'source_selection', 'address', 'port', 'reason', 'encryption')
        details = {key: transport.get(key) for key in fields if key in transport}
        details.update(identity=data.get('identity'), relay_only=bool(settings.get('relay_only')),
                       recovery_reason=settings.get('recovery_reason') or 'None')
        self.connection_details.set(readable(details))
        set_table(self.peers, data.get('peers', []), lambda p: (p.get('profile', {}).get('alias') or p.get('alias') or p['peer_id'][:18],
                      p.get('state'), p.get('version'), 'Unavailable' if p.get('latency_ms') is None else f"{p['latency_ms']:.1f} ms"))
        self.osc_transport.refresh()
        self.last_draw = time.monotonic()

    def tick(self):
        if self.closed:
            return
        super().tick()
        if time.monotonic() - self.last_draw >= .5:
            self.guard(self.render)

    def close(self):
        if self.closed:
            return True
        if self.mobile_invitation:self.mobile_invitation.close()
        self.invitation.set('')
        self.join_token.set('')
        self.invitation_preview.set('')
        self.osc_transport.close()
        return super().close()
