# App hotkey mapping

Open **Accessibility → Keyboard**, or find **Keyboard shortcuts** in Find a tool.
The editor now has **151 actions**: every one of the 121 tool destinations,
Find a tool, quick search, focus movement, workspace tabs, keyboard help,
text size, eight reader commands, alternate-input controls, and Home layout controls.

Search by action, destination, category or assigned chord. Filter by category
and Assigned/Unassigned. Select an action, type a chord or use Capture, then
**Review and apply assignment**. Capture does not run the action. Blank disables
an assignment. **Reassign chord to selected action** shows both the displaced
assignment and the new one before applying. Restore selected default, Restore
all defaults and Undo are available. Import is reviewed; export is a data-only
JSON profile. Existing version-1 navigation profiles remain readable; new
exports use version 2 and include local commands and reader mappings.

## Scope and recovery

Navigation and local controls work in the focused VRC Eye main window, with no
active grab. Tool routes use their existing availability, permissions and
review steps. A shortcut opens the tool, rather than submitting an account
action, launching a download, connecting a service or running a script.
Screen-reader commands also operate in the active app dialog, through the
existing reader's privacy and protected-field handling. Native OS file dialogs
and menus retain their own input behavior. These are not global hotkeys: they
do not control VRC Eye while typing in VRChat or another application.

Defaults retain Ctrl+K for Find a tool, Ctrl+Shift+K for quick search,
Ctrl+Comma for Settings, F6/Shift+F6 for regions, and Ctrl+Alt+F5–F12 for the
reader. Other actions start unassigned. F1 help, Ctrl+0 text-size recovery,
Escape, ordinary typing, editing shortcuts and native control navigation
remain available. Main-window region shortcuts are remappable; dialogs retain
standard F6 region behavior unless a reader action is explicitly assigned F6.

Supported chords are Ctrl+K, Ctrl+Comma, Ctrl+Shift+letter (excluding native
editing combinations), F2–F12 with optional Ctrl/Shift, and Ctrl+Alt+F2–F12
with optional Shift. Bare F10 remains reserved for native menu navigation.
Alt is accepted only with Ctrl and a function key, never with ordinary text
characters. AltGr/Super modifiers are excluded. Keys are logical key names;
Capture helps with the current layout. The OS or another accessibility tool
may consume a combination first; choose another chord in that case.

One chord has one owner. Configured switch-key overlaps are displayed even
while alternate input is stopped. Applying a conflicting assignment while it
is running is rejected; starting alternate input rechecks all assignments.
Switch Next/Select/Pause keys remain configurable in Alternate input. A held
hotkey performs its action once; releasing it rearms it, including X11-style
repeat release/press pairs. Captured keys remain latched until release.

Text actions adjust by ten percentage points, bounded to 100–500%, and use the
existing appearance settings. Home Undo/Restore require Home to be open and
the layout unlocked; lock checks and stale-layout protection still apply.
Startup remains locked. Starting alternate input is an explicit action;
loading a shortcut profile does not start it or activate any command.

Saved mappings persist for the local user; Demo and Safe mode changes remain
session-only. Saving fails before active mappings change. Undo restores both
sides of a reassignment. Display/accessibility profiles remain separate from
shortcut profiles. Existing settings backups retain the same option key.

## Validation and platform acceptance

Portable tests cover all tool routes, shared settings writers, old-profile
migration, conflict/reassignment/Undo, save failures, filtered editor behavior,
modal and focus boundaries, key repeat, capture recovery, reader routing,
alternate-input conflicts and shutdown cleanup. Six real-Tk acceptance tests
are supplied for Windows/Linux, covering the editor, dialog reader remaps,
repeat handling, capture, shared text scaling and 500% controls. Native GUI,
physical keyboard layouts, Windows Alt delivery, Linux desktop/WM reserved
keys and screen-reader interoperability still require platform testing.

Tk binding and event semantics reference:
https://www.tcl-lang.org/man/tcl8.6/TkCmd/bind.htm
