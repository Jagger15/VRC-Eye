"""Bounded, local-only World Creator records and immutable test snapshots.

No API credentials or networking are involved. A failed write never replaces an
existing record. Retention is explicit and skips evidence referenced by another
record, so collecting observations cannot silently erase a bookmarked incident.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import json
import math
import re
import sqlite3
import threading
import time
import uuid


MAX_RECORD_BYTES = 256 * 1024
MAX_RECORDS = 20000
MAX_TOTAL_BYTES = 64 * 1024 * 1024
MAX_DEPTH = 20
MAX_NODES = 20000
_KIND = re.compile(r"[a-z][a-z0-9_]{0,39}\Z")
_WORLD = re.compile(r"wrld_[A-Za-z0-9][A-Za-z0-9_-]{0,127}\Z")
_SNAPSHOTS = ("profile_snapshot", "checklist_snapshot")


def validate_world_id(value):
    """Accept published IDs or an explicitly local project UUID, never a path."""
    if isinstance(value, str) and _WORLD.fullmatch(value):
        return value
    if isinstance(value, str) and value.startswith("local:"):
        try:
            identifier = str(uuid.UUID(value[6:]))
        except (ValueError, AttributeError):
            pass
        else:
            if value[6:] == identifier:
                return value
    raise ValueError("Choose a world ID or a local project UUID before saving creator records.")


def new_local_world_id():
    return "local:" + str(uuid.uuid4())


def _kind(value):
    if not isinstance(value, str) or not _KIND.fullmatch(value):
        raise ValueError("Creator record kinds must be short lowercase identifiers.")
    return value


def _identifier(value):
    if not isinstance(value, str):
        raise ValueError("Creator record IDs must be UUID strings.")
    try:
        identifier = str(uuid.UUID(value))
    except (ValueError, AttributeError) as error:
        raise ValueError("Creator record IDs must be UUID strings.") from error
    if identifier != value:
        raise ValueError("Creator record IDs must be canonical UUID strings.")
    return identifier


def json_copy(value, *, require_dict=True):
    """Validate JSON without stringifying arbitrary Python objects or NaN."""
    if require_dict and not isinstance(value, dict):
        raise ValueError("Creator data must be a JSON object.")
    nodes = [0]
    active = set()

    def visit(item, depth):
        nodes[0] += 1
        if nodes[0] > MAX_NODES or depth > MAX_DEPTH:
            raise ValueError("Creator data is too deeply nested or has too many values.")
        if item is None or isinstance(item, (str, bool)):
            return
        if isinstance(item, int):
            if abs(item) > 2 ** 63 - 1:
                raise ValueError("Creator integer values exceed the supported range.")
            return
        if isinstance(item, float):
            if not math.isfinite(item):
                raise ValueError("Creator measurements must be finite numbers; use null for unavailable data.")
            return
        if not isinstance(item, (dict, list)):
            raise ValueError("Creator data supports JSON objects, lists, and scalar values only.")
        identity = id(item)
        if identity in active:
            raise ValueError("Creator data cannot contain circular references.")
        active.add(identity)
        try:
            if isinstance(item, dict):
                for key, child in item.items():
                    if not isinstance(key, str) or len(key) > 256:
                        raise ValueError("Creator field names must be strings of at most 256 characters.")
                    visit(child, depth + 1)
            else:
                for child in item:
                    visit(child, depth + 1)
        finally:
            active.remove(identity)

    visit(value, 0)
    try:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        size = len(encoded.encode("utf-8"))
    except (ValueError, UnicodeError, OverflowError) as error:
        raise ValueError("Creator data must contain valid UTF-8 JSON values.") from error
    if size > MAX_RECORD_BYTES:
        raise ValueError("A creator record is limited to 256 KiB; split or attach large evidence separately.")
    return json.loads(encoded)


def _strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from _strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from _strings(child)


class CreatorStore:
    def __init__(self, path=None, *, max_records=MAX_RECORDS,
                 max_bytes=MAX_TOTAL_BYTES, clock=time.time):
        if path is None:
            from vrcx_integration import settings_path
            path = settings_path().with_name("world_creator.sqlite3")
        self.path = Path(path)
        for label, value, maximum in (("record", max_records, MAX_RECORDS),
                                       ("byte", max_bytes, MAX_TOTAL_BYTES)):
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= maximum:
                raise ValueError("Invalid creator store " + label + " limit.")
        self.max_records = max_records
        self.max_bytes = max_bytes
        self.clock = clock
        self._lock = threading.RLock()
        self._closed = False
        if str(path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(path), timeout=5, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        try:
            with self._db:
                version = self._db.execute("PRAGMA user_version").fetchone()[0]
                if version not in (0, 1):
                    raise ValueError("This creator database was made by a newer VRC Eye version.")
                self._db.execute("PRAGMA foreign_keys=ON")
                self._db.execute("""CREATE TABLE IF NOT EXISTS creator_records (
                    id TEXT PRIMARY KEY, kind TEXT NOT NULL, world_id TEXT NOT NULL,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    data TEXT NOT NULL, data_bytes INTEGER NOT NULL)""")
                self._db.execute("CREATE INDEX IF NOT EXISTS creator_context ON creator_records(world_id,kind,updated_at)")
                self._db.execute("PRAGMA user_version=1")
        except BaseException:
            self._db.close()
            self._closed = True
            raise

    @contextmanager
    def _transaction(self):
        with self._lock:
            if self._closed:
                raise RuntimeError("The creator workspace is closed.")
            # IMMEDIATE makes quotas and context checks atomic across store handles.
            self._db.execute("BEGIN IMMEDIATE")
            try:
                yield self._db
            except BaseException:
                self._db.rollback()
                raise
            else:
                self._db.commit()

    @staticmethod
    def _record(row):
        if row is None:
            return None
        return {"id": row["id"], "kind": row["kind"], "world_id": row["world_id"],
                "created_at": row["created_at"], "updated_at": row["updated_at"],
                "data": json.loads(row["data"])}

    def save(self, kind, world_id, data, record_id=None):
        kind, world_id = _kind(kind), validate_world_id(world_id)
        clean = json_copy(data)
        if kind == "run":
            for field in _SNAPSHOTS:
                clean.setdefault(field, None)
        encoded = json.dumps(clean, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        size = len(encoded.encode("utf-8"))
        if size > MAX_RECORD_BYTES:
            raise ValueError("A creator record is limited to 256 KiB.")
        identifier = _identifier(record_id) if record_id is not None else str(uuid.uuid4())
        stamp = datetime.fromtimestamp(self.clock(), timezone.utc).isoformat(timespec="microseconds")
        with self._transaction() as db:
            existing = db.execute("SELECT * FROM creator_records WHERE id=?", (identifier,)).fetchone()
            if existing is not None:
                if (existing["kind"], existing["world_id"]) != (kind, world_id):
                    raise ValueError("A creator record cannot be moved into another world or record kind.")
                old_data = json.loads(existing["data"])
                if kind == "run" and any(json.dumps(old_data.get(field), sort_keys=True) != json.dumps(clean.get(field), sort_keys=True) for field in _SNAPSHOTS):
                    raise ValueError("A test run keeps its original profile and checklist snapshots; start a new run for changed instructions.")
            count, used = db.execute("SELECT count(*),coalesce(sum(data_bytes),0) FROM creator_records").fetchone()
            if count + (existing is None) > self.max_records or used - (existing["data_bytes"] if existing else 0) + size > self.max_bytes:
                raise ValueError("Creator storage limit reached. Export work or prune unreferenced observations before recording more.")
            created = existing["created_at"] if existing else stamp
            db.execute("""INSERT INTO creator_records VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,
                data=excluded.data,data_bytes=excluded.data_bytes""",
                (identifier, kind, world_id, created, stamp, encoded, size))
        return {"id": identifier, "kind": kind, "world_id": world_id,
                "created_at": created, "updated_at": stamp, "data": json.loads(encoded)}

    def get(self, record_id):
        identifier = _identifier(record_id)
        with self._lock:
            if self._closed:
                raise RuntimeError("The creator workspace is closed.")
            return self._record(self._db.execute("SELECT * FROM creator_records WHERE id=?", (identifier,)).fetchone())

    def list(self, kind=None, world_id=None, limit=500):
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_RECORDS:
            raise ValueError("Creator list limit must be between 1 and 20,000.")
        clauses, params = [], []
        if kind is not None:
            clauses.append("kind=?")
            params.append(_kind(kind))
        if world_id is not None:
            clauses.append("world_id=?")
            params.append(validate_world_id(world_id))
        query = "SELECT * FROM creator_records"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY updated_at DESC,rowid DESC LIMIT ?"
        params.append(limit)
        with self._lock:
            if self._closed:
                raise RuntimeError("The creator workspace is closed.")
            return [self._record(row) for row in self._db.execute(query, params).fetchall()]

    def delete(self, record_id):
        with self._transaction() as db:
            return bool(db.execute("DELETE FROM creator_records WHERE id=?", (_identifier(record_id),)).rowcount)

    def create_run(self, world_id, profile=None, checklist=None, data=None):
        clean = json_copy({} if data is None else data)
        for field, supplied in (("profile_snapshot", profile), ("checklist_snapshot", checklist)):
            if supplied is not None:
                supplied = json_copy(supplied)
                if "id" in supplied and "kind" in supplied and "data" in supplied:
                    if supplied.get("world_id") != world_id:
                        raise ValueError("Run templates must belong to the selected world.")
                    clean[field.replace("_snapshot", "_id")] = supplied["id"]
                    supplied = supplied["data"]
            clean[field] = supplied
        clean.setdefault("status", "In progress")
        return self.save("run", world_id, clean)

    def search(self, query, world_id=None, limit=100):
        if not isinstance(query, str) or not query.strip() or len(query) > 200:
            raise ValueError("Enter a creator search term of 1–200 characters.")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
            raise ValueError("Creator search returns at most 500 records.")
        needle = query.strip().casefold()
        # Match literal text; wildcard and SQL syntax have no special meaning.
        return [record for record in self.list(world_id=world_id, limit=MAX_RECORDS)
                if needle in json.dumps(record["data"], ensure_ascii=False).casefold()][:limit]

    def export_selection(self, record_ids, world_id=None):
        """Copy only explicitly selected records, without broadening to private notes."""
        if not isinstance(record_ids, (list, tuple)) or len(record_ids) > 500:
            raise ValueError("Select at most 500 creator records for one export.")
        if world_id is not None:
            validate_world_id(world_id)
        records = []
        seen = set()
        for identifier in record_ids:
            if identifier in seen:
                continue
            record = self.get(identifier)
            if record is None or (world_id is not None and record["world_id"] != world_id):
                raise ValueError("An export selection is missing or belongs to another world.")
            seen.add(identifier)
            records.append(record)
        return {"schema": "vrc-eye-creator-selection-1", "records": records,
                "privacy": "Explicit selection only; review contents before sharing."}

    def retention_status(self):
        with self._lock:
            if self._closed:
                raise RuntimeError("The creator workspace is closed.")
            count, used = self._db.execute("SELECT count(*),coalesce(sum(data_bytes),0) FROM creator_records").fetchone()
            observations = self._db.execute("SELECT count(*) FROM creator_records WHERE kind='observation'").fetchone()[0]
        return {"records": count, "data_bytes": used, "observations": observations,
                "max_records": self.max_records, "max_data_bytes": self.max_bytes,
                "policy": "Explicit pruning; referenced and pinned evidence is retained."}

    def prune_observations(self, world_id=None, keep=1000):
        if world_id is not None:
            validate_world_id(world_id)
        if isinstance(keep, bool) or not isinstance(keep, int) or not 0 <= keep <= MAX_RECORDS:
            raise ValueError("Observation retention count must be between 0 and 20,000.")
        with self._transaction() as db:
            rows = db.execute("SELECT * FROM creator_records ORDER BY updated_at DESC,rowid DESC").fetchall()
            records = [self._record(row) for row in rows]
            references = set()
            for record in records:
                references.update(value for value in _strings(record["data"]) if value != record["id"])
            candidates = [record for record in records if record["kind"] == "observation"
                          and (world_id is None or record["world_id"] == world_id)]
            removed, protected = 0, 0
            for record in candidates[keep:]:
                data = record["data"]
                if record["id"] in references or data.get("pinned") or data.get("protected"):
                    protected += 1
                    continue
                db.execute("DELETE FROM creator_records WHERE id=?", (record["id"],))
                removed += 1
        return {"removed": removed, "protected": protected, "remaining": len(candidates) - removed}

    def close(self):
        with self._lock:
            if not self._closed:
                self._db.close()
                self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()
