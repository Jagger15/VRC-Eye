"""Bounded, previewed image staging and fixed-origin multipart upload."""
from dataclasses import dataclass,field
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import os
import stat
import uuid

from companion_data import reference
from player_api import context,check_context,lock
from vrchat_api import APIError
import native_api

TAGS={'gallery':'gallery','icons':'icon','stickers':'sticker','emoji':'emoji','avatar-gallery':'avatargallery','avatar':'avatarimage','world':'worldimage','group-gallery':'gallery','group-gallery-pending':'gallery'}
MAX_BODY=12*1024*1024
ANIMATION_STYLES=('aura','bats','bees','bounce','cloud','confetti','crying','dislike','fire','idea','lasers','like','magnet','mistletoe','money','noise','orbit','pizza','rain','rotate','shake','snow','snowball','spin','splash','stop','zzz')
LOOP_STYLES=('linear','pingpong')
MASKS=('circle','flower','heart','pow','square','star')


@dataclass(frozen=True)
class ImageDraft:
    png:bytes=field(repr=False)
    digest:str
    width:int
    height:int
    original_size:tuple
    transformation:str
    frames:int=1
    fps:int=12


@dataclass(frozen=True)
class Multipart:
    body:bytes=field(repr=False)
    boundary:str
    @property
    def content_type(self):return 'multipart/form-data; boundary='+self.boundary


@dataclass(frozen=True)
class Upload:
    draft:ImageDraft=field(repr=False)
    snapshot:object=field(repr=False)
    path:str
    parameters:tuple
    target:str
    fields:tuple=field(repr=False)


def stage(path,*,square=False,animated=False,fps=12,print_image=False):
    from PIL import Image,ImageOps
    fd=os.open(Path(path),os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        before=os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or not 0<before.st_size<=64*1024*1024:raise ValueError('Choose a regular image up to 64 MiB.')
        with os.fdopen(fd,'rb',closefd=False) as source:raw=source.read(64*1024*1024+1)
        after=os.fstat(fd)
        if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise ValueError('The selected image changed while it was read.')
    finally:os.close(fd)
    if len(raw)>64*1024*1024:raise ValueError('The image grew beyond the input limit.')
    with Image.open(BytesIO(raw)) as im:
        frames=getattr(im,'n_frames',1)
        if im.width*im.height>32_000_000 or not 1<=frames<=64 or frames>1 and not animated:raise ValueError('Choose a static image up to 32 megapixels, or explicitly enable animated emoji (at most 64 frames).')
        if animated and (not 2<=frames<=64 or type(fps) is not int or not 1<=fps<=64):raise ValueError('Animated emoji need 2–64 frames and 1–64 FPS.')
        original=im.size;image=ImageOps.exif_transpose(im).convert('RGBA')
        if animated:
            if im.width*im.height*frames>64_000_000:raise ValueError('Animation decoding exceeds 64 million total frame pixels.')
            grid=2 if frames<=4 else 4 if frames<=16 else 8;image=Image.new('RGBA',(grid*128,grid*128))
            for index in range(frames):
                im.seek(index);tile=ImageOps.fit(im.convert('RGBA'),(128,128),method=Image.Resampling.LANCZOS)
                image.paste(tile,((index%grid)*128,(index//grid)*128))
        elif print_image:
            image=ImageOps.pad(image,(1920,1080),method=Image.Resampling.LANCZOS,color=(255,255,255,255))
        elif square:image=ImageOps.fit(image,(min(1024,image.width,image.height),)*2,method=Image.Resampling.LANCZOS)
        else:image.thumbnail((2048,2048),Image.Resampling.LANCZOS)
        output=BytesIO();image.save(output,format='PNG',optimize=True);png=output.getvalue()
    if len(png)>10*1024*1024:raise ValueError('The staged PNG exceeds 10 MiB. Select a smaller image.')
    transformation=(f'{frames}-frame square atlas at {fps} FPS; each frame center-cropped' if animated else
                    '1920 × 1080 white-padded print; aspect ratio preserved' if print_image else 'center-cropped square' if square else 'aspect ratio preserved')
    return ImageDraft(png,sha256(png).hexdigest(),image.width,image.height,original,
        'EXIF orientation applied; '+transformation+'; PNG without original metadata',frames if animated else 1,fps)


def preview_frames(draft):
    """Decode only the reviewed outgoing atlas, in upload/playback order."""
    from PIL import Image
    if (not isinstance(draft,ImageDraft) or sha256(draft.png).hexdigest()!=draft.digest
        or type(draft.frames)is not int or not 2<=draft.frames<=64
        or type(draft.fps)is not int or not 1<=draft.fps<=64):
        raise ValueError('Choose and stage an animated emoji first.')
    grid=2 if draft.frames<=4 else 4 if draft.frames<=16 else 8
    if (draft.width,draft.height)!=(grid*128,grid*128):raise ValueError('The reviewed atlas has unsupported dimensions.')
    with Image.open(BytesIO(draft.png)) as atlas:
        if atlas.size!=(draft.width,draft.height) or atlas.format!='PNG':raise ValueError('The reviewed PNG differs from its declared dimensions.')
        atlas.load()
        return tuple(atlas.crop(((i%grid)*128,(i//grid)*128,(i%grid+1)*128,(i//grid+1)*128)).convert('RGBA') for i in range(draft.frames))


def multipart(draft,parameters,*,legacy=False,print_image=False):
    if not isinstance(draft,ImageDraft) or sha256(draft.png).hexdigest()!=draft.digest:raise ValueError('The reviewed image changed.')
    boundary='EyeImage'+uuid.uuid4().hex;parts=[]
    values={'data':json.dumps(dict(parameters),ensure_ascii=False)} if legacy else dict(parameters)
    for key,value in values.items():
        if not key.replace('_','').isalnum() or not isinstance(value,(str,int,bool)):raise ValueError('Unsupported image upload field.')
        parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+key+'"\r\n\r\n'+str(value)+'\r\n').encode())
    name='image' if legacy or print_image else 'file'
    parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+name+'"; filename="image.png"\r\nContent-Type: image/png\r\n\r\n').encode()+draft.png+b'\r\n')
    parts.append(('--'+boundary+'--\r\n').encode());body=b''.join(parts)
    if len(body)>MAX_BODY:raise ValueError('Image request exceeds 12 MiB.')
    return Multipart(body,boundary)


def prepare(client,*,result,values):
    data=native_api.fresh(client,result)
    required={'image','timestamp','note'} if result.kind=='prints' else {'image'}
    allowed=required|({'maskTag'} if result.kind=='stickers' else {'maskTag','animationStyle','loopStyle'} if result.kind=='emoji' else set())
    if not isinstance(values,dict) or not required<=set(values) or set(values)-allowed or not isinstance(values['image'],ImageDraft):raise ValueError('Choose and preview an image and the displayed required fields first.')
    draft=values['image'];kind=result.kind
    if kind not in TAGS and kind!='prints':raise ValueError('Load the destination media page or owned creator details first.')
    if kind in ('avatar','world') and data.get('authorId')!=context(client)[0]:raise ValueError('Only an owned asset can receive a new cover.')
    path='file/image';params={'tag':TAGS[kind]} if kind in TAGS else {}
    if kind=='prints':
        from datetime import datetime,timezone
        moment=datetime.fromisoformat(values['timestamp'].replace('Z','+00:00'))
        if moment.tzinfo is None:raise ValueError('Specify the print capture timestamp with a UTC offset.')
        if draft.width!=1920 or draft.height!=1080:raise ValueError('Preview the 1920 × 1080 print output first.')
        params={'note':native_api.text(values['note'],1000),'timestamp':moment.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')};path='prints'
    if kind=='avatar-gallery':
        if data.get('authorId')!=context(client)[0]:raise ValueError('Refresh the owned avatar before changing its gallery.')
        params['galleryId']=data['id']
    if kind in ('icons','stickers','emoji') and draft.width!=draft.height:raise ValueError('This destination needs the square crop option.')
    if kind in ('stickers','emoji'):
        params['maskTag']=values.get('maskTag','square')
        if params['maskTag'] not in MASKS:raise ValueError('Choose a supported image mask.')
    if kind=='emoji':
        params['animationStyle']=values.get('animationStyle','stop')
        if params['animationStyle'] not in ANIMATION_STYLES:raise ValueError('Choose a supported emoji animation style.')
    if draft.frames>1:
        if kind!='emoji' or not 2<=draft.frames<=64 or not 1<=draft.fps<=64:raise ValueError('Only the emoji destination accepts a reviewed animation atlas.')
        params.update(tag='emojianimated',frames=draft.frames,framesOverTime=draft.fps)
        params['loopStyle']=values.get('loopStyle','linear')
        if params['loopStyle'] not in LOOP_STYLES:raise ValueError('Choose a supported loop style.')
    target=kind+' · '+result.subject if result.subject else kind
    fields=(('Destination',None,target),('Original dimensions',None,str(draft.original_size)),('Outgoing PNG',None,f'{draft.width} × {draft.height}, {len(draft.png):,} bytes'),
            ('Transformation',None,draft.transformation),('SHA-256',None,draft.digest))
    fields+=tuple((k,None,v) for k,v in params.items() if k in ('timestamp','note','frames','framesOverTime','maskTag','animationStyle','loopStyle'))
    return Upload(draft,result,path,tuple(params.items()),target,fields)


def dispatch(client,plan,*,stop=None,progress=None,before_dispatch=None,on_confirmed=None):
    if not isinstance(plan,Upload):raise ValueError('Prepare an image upload first.')
    native_api.fresh(client,plan.snapshot);expected=plan.snapshot.account
    body=multipart(plan.draft,plan.parameters,print_image=plan.path=='prints');lock(client,stop)
    try:
        check_context(client,expected,stop);client._wait_metadata(stop,progress);check_context(client,expected,stop);native_api.fresh(client,plan.snapshot)
        if before_dispatch:before_dispatch()
        result=client._request(plan.path,method='POST',multipart=body,allow_empty=True)
        reference(result.get('id'),('prnt',) if plan.path=='prints' else ('file',))
        if result.get('ownerId',result.get('authorId',expected[0]))!=expected[0]:raise APIError('The uploaded image reply belongs to another account.')
        if on_confirmed:on_confirmed()
        check_context(client,expected,stop)
        return native_api.bounded(result)
    finally:client.lock.release()
