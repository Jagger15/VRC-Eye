"""Explicit snapshot trials; no source write or automatic model assignment."""
from tkinter import filedialog
from companion_ui import button,choice
from friendly_ui import flow_line as line
import avatar_skin_optimization as skin


class SkinOptimization:
    def __init__(self,controls):
        self.controls=controls;self.panel=controls.panel;self.page=page=controls.page
        self.scene=None;self.report=None;self.pending=False;self.revision=0;self.context=None;self.settings=None
        self.nodes={};self.clips={};self.box=page.ttk.Frame(controls.box)
        page.ttk.Label(self.box,text='Skin influence trial',style='Heading.TLabel').pack(anchor='w')
        page.ttk.Label(self.box,text='Measure influence reduction on the imported pose and a selected clip. The current manual pose is not included. This creates an observation only. Use VRC Eye → Skin Influence Copies in Unity to review a separate mesh asset.',wraplength=1000).pack(anchor='w')
        row=line(page,self.box);self.node=page.tk.StringVar(value='');self.clip=page.tk.StringVar(value='Imported pose only')
        page.ttk.Label(row,text='Skinned node').pack(side='left');self.node_picker=choice(page,row,self.node,(),self.invalidate,width=35)
        page.ttk.Label(row,text='Clip scope').pack(side='left');self.clip_picker=choice(page,row,self.clip,(),self.select_clip,width=35)
        self.variables={};row=line(page,self.box)
        for key,label,value in (('limit','Influences (1–4)','2'),('tolerance','Max error (source units)','0.001'),('start','Start seconds','0'),('end','End seconds','1'),('count','Samples (1–128)','16')):
            v=page.tk.StringVar(value=value);self.variables[key]=v;page.ttk.Label(row,text=label).pack(side='left');page.ttk.Entry(row,textvariable=v,width=8).pack(side='left')
        row=line(page,self.box);button(page,row,'Measure reduction',self.inspect);button(page,row,'Review and export trial…',self.export);button(page,row,'Close skin trial',self.hide)
        self.detail=page.tk.StringVar(value='Choose a skinned node and measure explicitly.');page.ttk.Label(self.box,textvariable=self.detail,wraplength=1000,justify='left').pack(anchor='w')

    def invalidate(self):
        self.revision+=1;self.report=None;self.settings=None
        if self.pending and self.page.job:self.page.cancel()
        self.pending=False;self.detail.set('Selection changed. Measure again.')

    def show(self):
        self.controls.require();self.invalidate();self.scene=self.controls.scene
        self.nodes={f'{n.index}: {n.name}':n.index for n in self.scene.nodes if any(p.node==n.index and p.rig and p.rig.skin>=0 for p in self.scene.parts)}
        self.node_picker.configure(values=tuple(self.nodes));self.node.set(next(iter(self.nodes),''))
        clips=self.scene.animations.clips if self.scene.animations else ()
        self.clips={'Imported pose only':None}|{f'{i+1}: {c.name}':i for i,c in enumerate(clips)}
        self.clip_picker.configure(values=tuple(self.clips));self.clip.set('Imported pose only');self.box.pack(fill='both',expand=True,pady=8)
        if not self.nodes:self.detail.set('No editable skin influences in this decoded scene. Baked FBX poses cannot be used for this trial.')

    def select_clip(self):
        self.invalidate();i=self.clips.get(self.clip.get())
        if i is not None:
            c=self.scene.animations.clips[i];self.variables['start'].set(str(c.start));self.variables['end'].set(str(c.end));self.variables['count'].set('1' if c.start==c.end else '16')

    def selection(self):return self.node.get(),self.clip.get(),tuple(v.get() for v in self.variables.values())

    def inspect(self):
        self.controls.require();self.panel.require()
        if self.scene is None or self.scene is not self.controls.scene:raise ValueError('Reopen the trial for the selected scene.')
        if self.node.get() not in self.nodes or self.clip.get() not in self.clips:raise ValueError('Select a listed skinned node and clip scope.')
        if self.controls.timeline:self.controls.timeline.pause()
        self.invalidate();revision=self.revision;scene=self.scene;context=self.panel.context();settings=self.selection();clip=self.clips[self.clip.get()]
        try:
            opts=dict(limit=int(self.variables['limit'].get()),tolerance=float(self.variables['tolerance'].get()))
            if clip is not None:opts.update(start=float(self.variables['start'].get()),end=float(self.variables['end'].get()),count=int(self.variables['count'].get()))
        except ValueError:raise ValueError('Enter numeric seconds/error and integer influence/sample counts.') from None
        node=self.nodes[self.node.get()];self.pending=True;self.detail.set('Measuring the selected source snapshot…')
        def done(result):
            if revision!=self.revision:return
            self.pending=False
            if self.panel.closed or scene is not self.controls.scene or context!=self.panel.context() or settings!=self.selection():
                self.detail.set('Source, scope or context changed. Measure again.');return
            self.report=result;self.context=context;self.settings=settings;self.detail.set(skin.describe(result))
        try:self.page.start_task(lambda stop,progress:skin.inspect(scene,node,clip=clip,stop=stop,progress=progress,**opts),done,operation='Skin influence trial')
        except Exception:self.pending=False;raise

    def require_report(self):
        self.controls.require();self.page.writable()
        if self.report is None or self.scene is not self.controls.scene or self.context!=self.panel.context() or self.settings!=self.selection():raise ValueError('The source, settings or context changed. Measure again before export.')
        return self.report

    def export(self):
        report=self.require_report()
        if not self.page.review('Export skin influence trial?',skin.document(report),'Choose new report file'):return
        if self.require_report() is not report:raise ValueError('Trial changed during review.')
        path=filedialog.asksaveasfilename(parent=self.page.app.root,title='New skin influence trial',initialfile='skin-influence-trial.json',defaultextension='.json',filetypes=(('JSON report','*.json'),))
        if self.require_report() is not report:raise ValueError('Trial changed during review.')
        if path:skin.export(report,path);self.page.status.set('Exported the reviewed trial; no mesh asset or assignment was changed.')

    def hide(self):
        self.invalidate();self.scene=None;self.nodes={};self.clips={};self.node.set('');self.clip.set('');self.node_picker.configure(values=());self.clip_picker.configure(values=());self.box.pack_forget()

    def clear(self):self.hide();self.detail.set('No skin trial retained.')
