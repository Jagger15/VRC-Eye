# VRCX Companion — VRC Eye 1.18.10

Close the previous VRC Eye instance, extract VRC-Eye-v1.18.10.zip, then run Start.cmd.
Open **Advanced → VRCX Companion**. Python 3.10+ and Tkinter are required. Process
observation uses psutil, prepared automatically by **Start.cmd**. If setup is
unavailable offline, the app opens with available features and retries missing
packages on a later normal launch.
No VRChat account or Client Bridge is required. VRC Eye remains usable without VRCX.

## First use

Companion Mode defaults **off**. Enable it and choose Balanced, VRCX Primary, or
VRC Eye Primary. The page observes process presence and applies VRC Eye's own
preferences. It does not establish a negotiated connection to VRCX. Process
presence does not prove responsiveness, account login, notification delivery,
Discord publication or restart activity.

Casual shows Overview and Tools. Advanced adds Ownership and Diagnostics.
Developer adds decision reasons, process generation/PID, normalized event history
and an isolated simulation. Tabs and sidebar navigation scroll vertically.

The old optional read-only avatar-cache setting remains independent of Companion
Mode. Existing enabled/path preferences are preserved. Its location and records
are not copied into Companion diagnostics.

## Presets and ownership

| Category | Balanced | VRCX Primary | VRC Eye Primary |
| --- | --- | --- | --- |
| Social notifications | VRCX | VRCX | VRC Eye |
| Account convenience functions | VRCX | VRCX | VRC Eye |
| Session notifications | VRC Eye | VRCX | VRC Eye |
| Discord presence preference | VRCX | VRCX | VRC Eye |
| Manual launch | VRC Eye | VRCX | VRC Eye |
| Recovery launch | VRCX | VRCX | VRC Eye |
| Core roster, runtime, safety and diagnostics | VRC Eye | VRC Eye | VRC Eye |

These are preferences while a unique VRCX process has been observed, not commands
sent to VRCX. Core responsibility cannot be transferred. Each shared category can
use its preset or an explicit override. VRCX feature settings are **user declared**:
Unknown, Enabled or Disabled. A declared Disabled feature releases its preference
to VRC Eye. Unknown remains unverified rather than being inferred from the process.
Changing a preset retains explicit category overrides; Reset overrides removes them.

VRC Eye currently has no Discord Rich Presence publisher, automatic restart engine,
or account/session popup publisher. Their ownership rows prepare arbitration and
show availability; selecting an owner does not create those features. Existing
runtime monitoring, Black Box and Resource Guard keep their own settings. No
unimplemented Safety protection is claimed by the companion page.

When VRCX owns SOCIAL, VRC Eye suppresses eligible Player List friend/pinned-player
banners. The event still updates the roster, session timeline and configured local
history. Runtime/resource alerts are not routed through this social suppression.
The former Player Settings switch is now **Always suppress VRC Eye player banners
(legacy)** in Companion Tools. Its existing value is preserved, including in Solo
Mode; uncheck it explicitly when testing banners.

Temporary **Solo Mode** suspends VRCX-aware ownership for the current VRC Eye run.
It neither closes VRCX nor edits the saved preset. VRCX can still emit its own
notifications or restart VRChat. Use Solo for comparison, with that limitation in
mind. Disabling Companion Mode also restores local ownership.

## Presence, failure and conflicts

A background worker samples approximately once per second. It matches exact VRCX
process names and creation times, groups same-name children under one root, and
reports ambiguous roots separately. These observations are not authenticated
application identity. Enumeration is bounded; incomplete/denied observations are
Unknown. No process command lines, credentials or VRCX memory are inspected.

Two distinct absent samples confirm VRCX's absence and release ownership. A missed
or stale sample does not assert an exit. Observations expire after five seconds.
Previously established ownership is retained during uncertainty; the page explains
why. This avoids silently authorizing recovery during a provider gap. The provider
retries independently; VRCX returning does not require a VRC Eye restart.

Conflicts compare declared VRCX settings with VRC Eye's actual feature availability.
They report possible configured overlap, not observed external activity. A zero
conflict count does not verify the other application. VRCX notification, Discord,
restart and overlay activity remain unavailable because no supported coordination
telemetry interface was established for this release.

## One reviewed VRC Eye action at a time

Unity Player now has a **Launch / Recovery** selector. Crash & Diagnostics'
**Review recovery launch…** routes to that same launch screen with Recovery selected.
The worker rechecks process absence and Companion ownership immediately before
sending the Steam request. Recovery uses the RESTART owner; ordinary Launch uses
LAUNCH. When VRCX owns the request, choose a different owner or temporary Solo
before reviewing a manual VRC Eye request.

Unity launch/recovery, Resource Guard normal close and Wellness normal exit share
one local action reservation. Reviews expire within 60 seconds (shorter where the
existing feature requires it), bind the exact target/context and companion/runtime
revision, and are consumed once. Configuration, runtime generation, process
evidence or environment changes invalidate them. Submission starts a 30-second
cooldown, including an uncertain handler result. Expired reservations also prevent
an immediate unknown retry. No automatic close, restart or ownership fallback is
added. Existing exact-process checks remain in the action providers.

This coordinates **VRC Eye callers only**. It is not a cross-application lock and
cannot prevent an independently configured VRCX/Steam action. OS handler acceptance
is recorded as submission, never proof that a game launched successfully.

## Consolidated tools and handoffs

VRCX cache settings, cache-only avatar search, explicit avatar JSON import, the
legacy banner preference, and favorites exchange now live in this category.
Generic avatar search lives in Search; generic avatar JSON/cache actions remain
available where they apply to a selected avatar. Cached metadata retains its
source and age qualifications, and a name match still requires explicit selection.
VRCX database connections remain read-only and optional.

**Open VRCX…** requests the registered `vrcx://` handler. **Open in VRCX…** accepts
an exact user/world/avatar/group ID, previews the target, and sends only the
source-verified detail command. It does not send join, avatar-switch or favorite
mutation commands. VRCX must be logged in for detail handling; portable installs
may lack the registered handler. No delivery, login or focus acknowledgement is
available. Typed IDs stay in the page's memory and are excluded from diagnostics.

Repeated global VRChat connection controls are consolidated into the persistent
sidebar. Repeated navigation/bridge shortcuts and the duplicate Wellness profile
load button were removed. Contextual selection actions, exports, cancellation
and paging remain with the records they operate on.

## Explicit favorites exchange

The import/export dialog works with files the user selects. It does not inspect or
modify VRCX's favorites database, settings, cookies or account session.

Supported UTF-8 imports, up to 2 MiB and 10,000 input records:

| VRCX export | Recognized format |
| --- | --- |
| Own avatars | CSV `AvatarID,AvatarName`, header first |
| Default favorite avatars/worlds | CSV `ID,Name`, header first or last; one type per file |
| Favorite friends | CSV `UserID,Name`, header first or last |
| Friends list | CSV `UserID,DisplayName,Memo`; Memo is discarded |
| Friends list JSON | Object with only a `friends` list of exact user IDs |

The whole file is validated before review. Unknown schemas/columns, wrong ID types
and malformed rows are rejected. Duplicate IDs are consolidated. A preview shows
what will be added and what already exists. Confirming adds only missing entries
to **VRC Eye local favorites**, in one transaction. Existing names, collections
and saved metadata are preserved. Original export files remain unchanged. Nothing
is added to game favorites or sent to a server.

Export selects all local avatar, world or friend IDs of one type, up to 10,000,
including entries beyond the visible page. It produces an exclusive text file
for a manual VRCX import. Review its count and privacy implications first. Names,
notes and collection labels are excluded; the IDs themselves are included by
request. Existing destination files are never overwritten. Larger collections
require a separate full Favorites backup; this export does not silently truncate.

## Privacy, persistence and diagnostics

Only VRC Eye's preferences are saved. Solo state, process identity, review tokens,
observations, suppression counts and the last 128 companion events are session
memory. Demo and Safe Mode suspend detection and disallow live integration actions
or preference/file mutations through the companion tools.

Sanitized `companion.*` decisions feed the independently configured Black Box.
Payloads contain allowlisted state/category/owner/action/preset/count/generation
fields, without PIDs, process paths, names, private instances, typed handoff IDs,
cache data or credentials. The Black Box's separate recording/retention settings
continue to apply.

Reviewed Companion JSON reports use the same restricted fields plus source-age,
settings declarations and counts. Exact timestamps remain. Exports never overwrite
an existing file or upload/share it. The isolated simulator performs no OS calls,
application launches, persistence or changes to live state.

## Verification and remaining limits

See VALIDATION.md for test results. Native Windows process enumeration, actual
VRCX/Steam handlers, native Tk layout, VRCX login and tandem VRChat operation still
need a target-system check. No live VRCX or VRChat process was launched, moved or
terminated during this build.

The included release implements local ownership, social suppression, shared
reviewed actions, passive presence, known handoffs, explicit exchange and diagnostics.
There is no VRCX heartbeat/settings API, automatic recovery, verified external
Discord publisher state, negotiated overlay layout, or cross-application lock.
Runtime profiles and companion presets remain separate. Existing integrations
never become prerequisites for the live roster or runtime monitoring.

Primary VRCX sources verified at commit `5d606ccda974ac53ce7baab369c3a0bded1541be`:

- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/src/stores/vrcx.js
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/Installer/installer.nsi
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/Dotnet/StartupArgs.cs
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/src/views/Favorites/dialogs/AvatarExportDialog.vue
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/src/views/Tools/dialogs/ExportAvatarsListDialog.vue
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/src/views/Favorites/dialogs/AvatarImportDialog.vue
- https://github.com/vrcx-team/VRCX/blob/5d606ccda974ac53ce7baab369c3a0bded1541be/src/views/Tools/dialogs/ExportFriendsListDialog.vue
