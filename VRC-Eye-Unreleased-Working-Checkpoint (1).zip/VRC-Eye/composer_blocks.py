"""Data-only chat blocks. Rendering creates a private, frozen draft, never sends."""
from datetime import datetime
from copy import deepcopy
from native_library import plain,scope

KEY='composer.blocks.v1.'
KINDS=('Text','Clock','Selected media')
JOINS={'New line':'\n','Space':' ','None':''}


def validate(raw=None):
    if raw is None:return dict(schema=1,join='New line',blocks=[])
    if not isinstance(raw,dict) or set(raw)!={'schema','join','blocks'} or type(raw['schema']) is not int or raw['schema']!=1 or raw['join'] not in JOINS:
        raise ValueError('Choose a supported composer block document.')
    blocks=raw['blocks']
    if not isinstance(blocks,list) or len(blocks)>12:raise ValueError('Use at most 12 composer blocks.')
    for block in blocks:
        if not isinstance(block,dict) or set(block)!={'kind','text','enabled'} or block['kind'] not in KINDS or type(block['enabled']) is not bool:
            raise ValueError('Composer blocks contain only a known kind, text and checkbox state.')
        plain(block['text'],1000)
        try:block['text'].encode('utf-8')
        except UnicodeError:raise ValueError('Block text must use valid Unicode.') from None
        if block['kind']!='Text' and block['text']:raise ValueError('Provider blocks cannot contain hidden template code or text.')
    if sum(len(b['text']) for b in blocks)>6000:raise ValueError('Keep saved block text within 6,000 characters.')
    return deepcopy(raw)


def render(raw,*,now=None,media=None):
    value=validate(raw);pieces=[];evidence=[]
    for index,block in enumerate(value['blocks']):
        if not block['enabled']:continue
        kind=block['kind']
        if kind=='Text':text=block['text'];basis='Typed text'
        elif kind=='Clock':text=(now or datetime.now().astimezone()).strftime('%H:%M');basis='Local clock snapshot'
        else:
            if media is None:raise ValueError(f'Block {index+1}: no fresh selected media. Select a player or disable this block.')
            title=getattr(media,'title','');artist=getattr(media,'artist','')
            text=' — '.join(v for v in (title,artist) if isinstance(v,str) and v)
            plain(text,1000,empty=False);basis='Fresh selected player metadata; audible playback unverified'
        if text:pieces.append(text);evidence.append(basis)
    draft=JOINS[value['join']].join(pieces)
    from mod_workflows import segments
    parts=segments(draft)
    return dict(text=draft,segments=len(parts),utf16_units=len(draft.encode('utf-16-le'))//2,sources=evidence)


def save(store,account,raw):store.set_option(KEY+scope(account),validate(raw))
def load(store,account):return validate(store.option(KEY+scope(account)))
