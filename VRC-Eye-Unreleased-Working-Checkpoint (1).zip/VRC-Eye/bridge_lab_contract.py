"""Reviewed, data-only Client Bridge Lab capability contracts.

The connection proves possession of a temporary local pairing secret, not the
truth of provider claims. No contract exposes memory, arbitrary object access,
code loading, hidden content, authentication material or a remote API executor.
"""
from __future__ import annotations
from copy import deepcopy
import math
import re

CONTRACT_REVISION = 'client-bridge-lab-1'
READ_ONLY = 'Read-only diagnostic'
LOCAL = 'Local presentation change'
SELF = 'Own-avatar state change'
SHARED = 'Creator-defined shared test action'
INTEGRATION = 'Integration-owned state change'
UNKNOWN = 'Unknown side effects'
# Built-ins are not write targets even when a provider advertises them writable.
# Reference: https://creators.vrchat.com/avatars/animator-parameters/
BUILT_INS = frozenset(('IsLocal PreviewMode Viseme Voice GestureLeft GestureRight '
    'GestureLeftWeight GestureRightWeight AngularY VelocityX VelocityY VelocityZ '
    'VelocityMagnitude Upright Grounded Seated AFK TrackingType VRMode MuteSelf '
    'InStation Earmuffs IsOnFriendsList AvatarVersion IsAnimatorEnabled '
    'ScaleModified ScaleFactor ScaleFactorInverse EyeHeightAsMeters EyeHeightAsPercent').split())
ELIGIBLE_MODULES = frozenset(('diagnostic', 'overlay', 'input_routing'))
RECOVERIES = {
    'telemetry.rebuild': 'Rebuild only integration-owned telemetry subscriptions',
    'diagnostic.reopen': 'Reopen only the integration diagnostic channel',
    'configuration.reload': 'Reload only the validated integration configuration',
    'parameter_route.reset': 'Reset only an integration-owned parameter route',
}
# name: title, wire kind, reviewed effect class. Additions require implementation,
# schema validation, tests and explicit UI review; advertisement is not approval.
CONTRACTS = {
    'lab.context': ('Experiment context and capture cost', 'telemetry', READ_ONLY),
    'lab.self_avatar': ('Own-avatar initialization and transition timeline', 'telemetry', READ_ONLY),
    'lab.parameters': ('Own-avatar parameter observations and write attribution', 'telemetry', READ_ONLY),
    'lab.presentation': ('Local presentation observations', 'telemetry', READ_ONLY),
    'lab.modules': ('Integration-owned module inventory', 'telemetry', READ_ONLY),
    'lab.health': ('Integration recovery health evidence', 'telemetry', READ_ONLY),
    'lab.creator': ('Creator-exposed manifest and diagnostics', 'telemetry', READ_ONLY),
    'lab.parameter_set': ('Temporary own-avatar custom parameter experiment', 'action', SELF),
    'lab.presentation_reduce': ('Temporary exposure-reducing local presentation test', 'action', LOCAL),
    'lab.module_pause': ('Temporary pause of an eligible integration module', 'action', INTEGRATION),
    'lab.recover': ('Named integration-only recovery', 'action', INTEGRATION),
    'lab.creator_action': ('Individually reviewed creator playtest control', 'action', SHARED),
    'lab.restore': ('Compare-and-restore an existing experiment lease', 'action', INTEGRATION),
}
TELEMETRY = frozenset(k for k, v in CONTRACTS.items() if v[1] == 'telemetry')
ACTIONS = frozenset(k for k, v in CONTRACTS.items() if v[1] == 'action')
TEMPORARY = frozenset(('lab.parameter_set', 'lab.presentation_reduce', 'lab.module_pause'))


def identifier(value, maximum=80):
    from bridge_protocol import BridgeError
    if not isinstance(value, str) or not 1 <= len(value) <= maximum or not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_. /:-]*', value):
        raise BridgeError('Use a short structured diagnostic identifier, not a path, URL or script.')
    if '://' in value or '..' in value or re.search(r'(?i)(?:password|cookie|auth.?token|secret|credential)', value):
        raise BridgeError('Secret-bearing identifiers and executable/path-like names are not supported.')
    return value


def scalar(value):
    from bridge_protocol import BridgeError
    if type(value) not in (bool, int, float) or type(value) is not bool and (not math.isfinite(value) or abs(value) > 2**40):
        raise BridgeError('Only bounded boolean, integer and finite float observations are supported.')
    return value


def typed(kind, value):
    from bridge_protocol import BridgeError, choice
    choice(kind, ('bool', 'int', 'float'))
    scalar(value)
    if (kind == 'bool' and type(value) is not bool or
        kind == 'int' and (type(value) is not int or not 0 <= value <= 255) or
        kind == 'float' and (type(value) not in (int, float) or not -1 <= value <= 1)):
        raise BridgeError('The custom parameter value does not match its declared type/range.')
    return value


def same(a, b):
    """Type-aware comparisons: true is not the same observation as integer 1."""
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return set(a) == set(b) and all(same(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def validate_context(value):
    import bridge_protocol as p
    p.exact(value, ('revision', 'runtime_session', 'account_id', 'avatar_id', 'world_id', 'world_session', 'config_revision'))
    p.integer(value['revision'], 1, 2**31-1)
    p.integer(value['config_revision'])
    p.ref(value['runtime_session'])
    p.ref(value['account_id'], 'usr')
    for field, prefix in (('avatar_id', 'avtr'), ('world_id', 'wrld'), ('world_session', '')):
        if value[field] is not None:
            p.ref(value[field], prefix)
    if (value['world_id'] is None) != (value['world_session'] is None):
        raise p.BridgeError('World and private local world-session identity must change together.')
    return value


def records(value, maximum, key):
    import bridge_protocol as p
    if not isinstance(value, list) or len(value) > maximum:
        raise p.BridgeError('The diagnostic batch exceeds its record bound.')
    seen = set()
    for row in value:
        if not isinstance(row, dict) or key not in row or not isinstance(row[key], str) or row[key] in seen:
            raise p.BridgeError('Diagnostic records need unique structured identifiers.')
        seen.add(row[key])
    return value


def presentation_state(value):
    import bridge_protocol as p
    p.exact(value, ('avatar_hidden', 'audio_suppressed', 'effects', 'revision'))
    p.boolean(value['avatar_hidden']); p.boolean(value['audio_suppressed'])
    p.choice(value['effects'], ('standard', 'reduced', 'minimal')); p.integer(value['revision'])
    return value


def validate_manifest(value):
    import bridge_protocol as p
    p.exact(value, ('id', 'revision', 'author_id', 'authority_account', 'authority_kind', 'authority_expires_ms', 'fields', 'controls'))
    p.ref(value['id']); p.integer(value['revision'])
    p.ref(value['author_id'], 'usr'); p.ref(value['authority_account'], 'usr')
    p.choice(value['authority_kind'], ('creator_project', 'explicit_playtest', 'none'))
    p.integer(value['authority_expires_ms'], 0, 60000)
    for row in records(value['fields'], 32, 'key'):
        p.exact(row, ('key', 'value'), ('unit',))
        identifier(row['key'])
        if row['value'] is not None: scalar(row['value'])
        if 'unit' in row: identifier(row['unit'], 24)
    for row in records(value['controls'], 16, 'id'):
        p.exact(row, ('id', 'effect', 'scope', 'authorized', 'persistent', 'destructive'))
        identifier(row['id']); p.text(row['effect'], 180)
        p.choice(row['scope'], ('shared_test', 'unknown'))
        for flag in ('authorized', 'persistent', 'destructive'): p.boolean(row[flag])
    return value


def validate_telemetry(name, value):
    import bridge_protocol as p
    if name not in TELEMETRY: raise p.BridgeError('Unknown lab telemetry capability.')
    required, optional = {
        'lab.context': (('context', 'capture_cost_ms', 'compatibility'), ()),
        'lab.self_avatar': (('context', 'event', 'phase'), ('tracking_type', 'vr_mode', 'upright', 'in_station', 'animator_state', 'controller_revision')),
        'lab.parameters': (('context', 'parameters'), ()),
        'lab.presentation': (('context', 'targets'), ()),
        'lab.modules': (('context', 'modules'), ()),
        'lab.health': (('context', 'channel', 'state', 'telemetry_revision'), ('recovery_id',)),
        'lab.creator': (('context', 'manifest'), ()),
    }[name]
    p.exact(value, required, optional)
    validate_context(value['context'])
    if name == 'lab.context':
        p.number(value['capture_cost_ms'], 1000)
        p.choice(value['compatibility'], ('unvalidated', 'provider_tested'))
    elif name == 'lab.self_avatar':
        p.choice(value['event'], ('snapshot', 'initialization', 'animator_transition', 'tracking_change', 'configuration_change'))
        p.choice(value['phase'], ('initializing', 'ready', 'transition', 'unavailable'))
        if 'tracking_type' in value: p.integer(value['tracking_type'], 0, 6)
        for key in ('vr_mode', 'in_station'):
            if key in value: p.boolean(value[key])
        if 'upright' in value: p.number(value['upright'], 1)
        if 'animator_state' in value: identifier(value['animator_state'])
        if 'controller_revision' in value: p.integer(value['controller_revision'])
    elif name == 'lab.parameters':
        for row in records(value['parameters'], 64, 'name'):
            p.exact(row, ('name', 'type', 'value', 'writable', 'synced', 'saved', 'revision'), ('writer',))
            identifier(row['name']); p.choice(row['type'], ('bool', 'int', 'float'))
            # Built-in observations have broader ranges than custom parameters.
            scalar(row['value'])
            if row['name'] not in BUILT_INS: typed(row['type'], row['value'])
            p.boolean(row['writable']); p.integer(row['revision'])
            p.choice(row['synced'], ('yes', 'no', 'unknown')); p.choice(row['saved'], ('yes', 'no', 'unknown'))
            if 'writer' in row: identifier(row['writer'])
    elif name == 'lab.presentation':
        for row in records(value['targets'], 32, 'target_user_id'):
            p.exact(row, ('target_user_id', 'avatar_hidden', 'audio_suppressed', 'effects', 'revision'))
            p.ref(row['target_user_id'], 'usr')
            presentation_state({k: v for k, v in row.items() if k != 'target_user_id'})
    elif name == 'lab.modules':
        for row in records(value['modules'], 32, 'id'):
            p.exact(row, ('id', 'kind', 'version', 'config_revision', 'paused', 'can_pause', 'revision'))
            identifier(row['id']); identifier(row['version'], 40)
            p.choice(row['kind'], (*sorted(ELIGIBLE_MODULES), 'anti_cheat', 'authentication', 'security', 'privacy', 'enforcement', 'unknown'))
            p.integer(row['config_revision']); p.integer(row['revision'])
            p.boolean(row['paused']); p.boolean(row['can_pause'])
    elif name == 'lab.health':
        identifier(value['channel']); p.choice(value['state'], ('healthy', 'degraded', 'unavailable'))
        p.integer(value['telemetry_revision'])
        if 'recovery_id' in value: p.ref(value['recovery_id'])
    elif name == 'lab.creator':
        validate_manifest(value['manifest'])
    p.encode(value)
    return deepcopy(value)


def validate_action(name, value):
    import bridge_protocol as p
    if name not in ACTIONS: raise p.BridgeError('Unknown lab action capability.')
    extra = {
        'lab.parameter_set': ('duration_ms', 'name', 'expected', 'value', 'expected_revision'),
        'lab.presentation_reduce': ('duration_ms', 'target_user_id', 'mode', 'expected'),
        'lab.module_pause': ('duration_ms', 'module_id', 'expected_revision'),
        'lab.recover': ('operation', 'channel'),
        'lab.creator_action': ('manifest_id', 'manifest_revision', 'control_id'),
        'lab.restore': ('original_capability', 'expected_revision'),
    }[name]
    p.exact(value, ('context', 'experiment_id') + extra)
    validate_context(value['context']); p.ref(value['experiment_id'])
    if name in TEMPORARY: p.integer(value['duration_ms'], 1000, 60000)
    if name == 'lab.parameter_set':
        identifier(value['name'])
        if value['name'] in BUILT_INS: raise p.BridgeError('Built-in avatar parameters are observation-only, regardless of provider advertising.')
        scalar(value['expected']); scalar(value['value']); p.integer(value['expected_revision'])
    elif name == 'lab.presentation_reduce':
        p.ref(value['target_user_id'], 'usr'); p.choice(value['mode'], ('hide', 'suppress_audio', 'reduce_effects', 'minimal_effects'))
        presentation_state(value['expected'])
    elif name == 'lab.module_pause':
        identifier(value['module_id']); p.integer(value['expected_revision'])
    elif name == 'lab.recover':
        p.choice(value['operation'], RECOVERIES); identifier(value['channel'])
    elif name == 'lab.creator_action':
        p.ref(value['manifest_id']); p.integer(value['manifest_revision']); identifier(value['control_id'])
    elif name == 'lab.restore':
        p.choice(value['original_capability'], TEMPORARY); p.integer(value['expected_revision'])
    p.encode(value)
    return deepcopy(value)


def validate_result(name, value, params):
    import bridge_protocol as p
    p.exact(value, ('acknowledged', 'experiment_id', 'context_revision'), ('applied_revision',))
    p.integer(value['context_revision'], 1); p.ref(value['experiment_id'])
    if value['acknowledged'] is not True or value['experiment_id'] != params['experiment_id'] or value['context_revision'] != params['context']['revision']:
        raise p.BridgeError('The acknowledgement did not match the reviewed lab experiment.')
    if 'applied_revision' in value: p.integer(value['applied_revision'])
    return deepcopy(value)


def contract_catalog():
    return [{'capability': k, 'title': v[0], 'kind': v[1], 'classification': v[2],
             'review_revision': CONTRACT_REVISION, 'live_compatibility': 'unverified',
             'risk': 'Read-only diagnostic' if v[1] == 'telemetry' else 'Extremely Risky — experimental state change',
             'provider_advertisement_is_authority': False} for k, v in CONTRACTS.items()]


def check_preconditions(name, params, read):
    """Recheck fresh, approved observations immediately before queue/dispatch.

    ``read`` must return a *fresh* observation or raise. The provider still owns
    the final atomic comparison and the lease; telemetry is not a transaction.
    """
    import bridge_protocol as p
    context = read('lab.context')['context']
    if not same(context, params['context']):
        raise p.BridgeError('Lab context changed before dispatch.')
    if name in TEMPORARY:
        source, collection, key, target = {
            'lab.parameter_set': ('lab.parameters', 'parameters', 'name', params.get('name')),
            'lab.presentation_reduce': ('lab.presentation', 'targets', 'target_user_id', params.get('target_user_id')),
            'lab.module_pause': ('lab.modules', 'modules', 'id', params.get('module_id')),
        }[name]
        observation = read(source)
        if not same(observation['context'], context): raise p.BridgeError('Precondition belongs to an older context.')
        row = next((r for r in observation[collection] if r[key] == target), None)
        if row is None: raise p.BridgeError('The reviewed target is no longer observed.')
        if name == 'lab.parameter_set':
            if params['name'] in BUILT_INS or not row['writable'] or context['avatar_id'] is None:
                raise p.BridgeError('The own-avatar parameter is not writable.')
            typed(row['type'], params['value'])
            if row['revision'] != params['expected_revision'] or not same(row['value'], params['expected']):
                raise p.BridgeError('Parameter changed before dispatch; nothing was sent.')
        elif name == 'lab.module_pause':
            if row['kind'] not in ELIGIBLE_MODULES or not row['can_pause'] or row['paused'] or row['revision'] != params['expected_revision']:
                raise p.BridgeError('Module is protected, paused or changed since review.')
        elif not same({k: row[k] for k in ('avatar_hidden','audio_suppressed','effects','revision')}, params['expected']):
            raise p.BridgeError('Presentation state changed before dispatch.')
    elif name == 'lab.recover':
        observation = read('lab.health')
        if not same(observation['context'], context) or observation['channel'] != params['channel']:
            raise p.BridgeError('Recovery channel changed before dispatch.')
    elif name == 'lab.creator_action':
        observation = read('lab.creator'); manifest = observation['manifest']
        if not same(observation['context'], context) or context['world_id'] is None or manifest['id'] != params['manifest_id'] or manifest['revision'] != params['manifest_revision']:
            raise p.BridgeError('Creator manifest/context changed before dispatch.')
        if manifest['authority_kind'] == 'none' or manifest['authority_account'] != context['account_id'] or manifest['authority_expires_ms'] <= 0:
            raise p.BridgeError('Current scoped creator/playtest authority is absent.')
        control = next((c for c in manifest['controls'] if c['id'] == params['control_id']), None)
        if not control or control['scope'] != 'shared_test' or not control['authorized'] or control['persistent'] or control['destructive']:
            raise p.BridgeError('This creator control is not eligible for execution.')
