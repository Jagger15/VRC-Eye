"""Static GLB 2.0 scene geometry, without external reads or scene code execution.

Reference: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
This deliberately bounded subset renders TRIANGLES with FLOAT POSITION and
unsigned indices, node TRS/matrices, four-weight skinning and position morphs.
Unsupported required extensions and compressed geometry are rejected. Embedded base-color
appearance is a bounded subset. Parent transforms are applied to vertices.
"""
from dataclasses import dataclass
from hashlib import sha256
import json
import math
import struct

MAX_BYTES = 32 * 1024**2
MAX_JSON = 2 * 1024**2
MAX_NODES = 512
MAX_VERTICES = 100000
MAX_TRIANGLES = 30000
MAX_OUTPUT = 24 * 1024**2
IDENTITY = (1.,0.,0.,0., 0.,1.,0.,0., 0.,0.,1.,0., 0.,0.,0.,1.)


def integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError('GLB integer or reference is outside the supported bounds.')
    return value


def vector(value, length):
    if not isinstance(value, (list,tuple)) or len(value) != length or any(
            type(n) not in (int,float) or not math.isfinite(n) or abs(n)>1e9 for n in value):
        raise ValueError('GLB coordinates and transforms must be finite and bounded.')
    return tuple(float(n) for n in value)


def array(doc, key, limit):
    value = doc.get(key, [])
    if not isinstance(value, list) or len(value)>limit or any(not isinstance(v,dict) for v in value):
        raise ValueError('GLB object array exceeds the supported scene budget.')
    return value


def multiply(a,b):
    return vector([sum(a[r+4*k]*b[k+4*c] for k in range(4)) for c in range(4) for r in range(4)],16)


def transform(matrix,point):
    return vector([sum(matrix[r+4*k]*point[k] for k in range(3))+matrix[r+12] for r in range(3)],3)


def local_matrix(node):
    if 'matrix' in node:
        if any(k in node for k in ('translation','rotation','scale')):
            raise ValueError('GLB nodes cannot combine matrix and TRS transforms.')
        matrix=vector(node['matrix'],16)
        if any(abs(matrix[n]-expected)>1e-8 for n,expected in ((3,0),(7,0),(11,0),(15,1))):
            raise ValueError('Only affine GLB node matrices are supported.')
        # glTF matrices must be decomposable to TRS, without shear.
        columns=[matrix[c*4:c*4+3] for c in range(3)]
        for i in range(3):
            for j in range(i+1,3):
                bound=math.sqrt(sum(v*v for v in columns[i])*sum(v*v for v in columns[j]))
                if bound and abs(sum(a*b for a,b in zip(columns[i],columns[j])))>bound*1e-5:
                    raise ValueError('Sheared GLB node matrices are unsupported.')
        return matrix
    t=vector(node.get('translation',[0,0,0]),3);s=vector(node.get('scale',[1,1,1]),3)
    x,y,z,w=vector(node.get('rotation',[0,0,0,1]),4)
    if abs(x*x+y*y+z*z+w*w-1)>1e-4:raise ValueError('GLB rotation must be a unit quaternion.')
    rotation=(1-2*(y*y+z*z),2*(x*y+z*w),2*(x*z-y*w),0,
              2*(x*y-z*w),1-2*(x*x+z*z),2*(y*z+x*w),0,
              2*(x*z+y*w),2*(y*z-x*w),1-2*(x*x+y*y),0, t[0],t[1],t[2],1)
    return vector([rotation[i]*(s[i//4] if i<12 else 1) for i in range(16)],16)


def name(value, default):
    if not isinstance(value,str):return default
    # Scene names are local display data, never identifiers or paths.
    return ''.join(c for c in value if c.isprintable() and c not in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069')[:120] or default


def bounds(vertices):
    return tuple(tuple(fn(v[k] for v in vertices) for k in range(3)) for fn in (min,max))


@dataclass(frozen=True)
class SceneNode:
    index: int
    parent: int
    name: str
    matrix: tuple=IDENTITY


@dataclass(frozen=True)
class ScenePart:
    node: int
    vertices: tuple
    triangles: tuple
    uvs: tuple=()
    material: int=-1
    colors: tuple=()
    health: tuple=()
    rig: object=None


@dataclass(frozen=True)
class Scene:
    nodes: tuple
    parts: tuple
    bounds: tuple
    sha256: str
    source_bytes: int
    notices: tuple
    materials: tuple=()
    textures: tuple=()
    skins: tuple=()
    import_report: object=None
    animations: object=None


def parse(data):
    if not isinstance(data,bytes) or not 28<=len(data)<=MAX_BYTES:
        raise ValueError('Choose a GLB file no larger than 32 MiB.')
    if struct.unpack_from('<III',data)!=(0x46546c67,2,len(data)):
        raise ValueError('Use a complete GLB 2.0 file with a matching length.')
    chunks=[];offset=12
    while offset<len(data):
        if offset+8>len(data) or len(chunks)>=8:raise ValueError('Invalid GLB chunk layout.')
        length,kind=struct.unpack_from('<II',data,offset);offset+=8
        if length%4 or offset+length>len(data):raise ValueError('Invalid GLB chunk length or alignment.')
        chunks.append((kind,data[offset:offset+length]));offset+=length
    if len(chunks)!=2 or chunks[0][0]!=0x4e4f534a or chunks[1][0]!=0x004e4942:
        raise ValueError('This viewer requires one JSON chunk followed by one embedded BIN chunk.')
    if len(chunks[0][1])>MAX_JSON:raise ValueError('GLB scene JSON exceeds 2 MiB.')
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('Duplicate GLB JSON keys are unsupported.')
            result[k]=v
        return result
    try:doc=json.loads(chunks[0][1].decode('utf-8'),object_pairs_hook=pairs,
                       parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite GLB JSON.')))
    except (UnicodeError,RecursionError,json.JSONDecodeError):raise ValueError('Invalid GLB JSON.') from None
    if not isinstance(doc,dict) or not isinstance(doc.get('asset'),dict) or doc['asset'].get('version')!='2.0' or doc['asset'].get('minVersion','2.0')!='2.0':
        raise ValueError('Use glTF asset version 2.0.')
    required=doc.get('extensionsRequired',[])
    if not isinstance(required,list) or any(not isinstance(v,str) or v!='KHR_texture_transform' for v in required):raise ValueError('Required glTF extensions are not supported by the static viewer.')
    pending=[(doc,0)];count=0
    while pending:
        value,depth=pending.pop();count+=1
        if depth>32 or count>150000:raise ValueError('GLB JSON nesting or item count exceeds the scene budget.')
        if isinstance(value,dict):pending.extend((v,depth+1) for v in value.values())
        elif isinstance(value,list):pending.extend((v,depth+1) for v in value)
    binary=chunks[1][1];buffers=array(doc,'buffers',1)
    if len(buffers)!=1 or 'uri' in buffers[0]:raise ValueError('GLB geometry must use one embedded buffer; external resources are never opened.')
    size=integer(buffers[0].get('byteLength'),1,len(binary))
    if len(binary)-size>3:raise ValueError('Invalid GLB BIN padding.')
    binary=binary[:size]
    views=array(doc,'bufferViews',4096);accessors=array(doc,'accessors',4096)
    from avatar_scene_appearance import parse as appearance
    materials,textures=appearance(doc,binary,views)
    nodes=array(doc,'nodes',MAX_NODES);meshes=array(doc,'meshes',MAX_NODES);scenes=array(doc,'scenes',32)
    if not scenes or not nodes:raise ValueError('The GLB has no explicit scene to display.')
    scene_index=integer(doc.get('scene',0),0,len(scenes)-1)
    parents={};children={}
    for i,node in enumerate(nodes):
        child=node.get('children',[])
        if not isinstance(child,list) or len(child)>MAX_NODES:raise ValueError('Invalid GLB child list.')
        for j in child:
            integer(j,0,len(nodes)-1)
            if j in parents or j==i:raise ValueError('GLB nodes must form a tree without duplicate parents or cycles.')
            parents[j]=i
        children[i]=tuple(child)
    # Validate every node, including nodes outside the selected scene.
    for i in range(len(nodes)):
        ancestors=set();j=i
        while j in parents:
            if j in ancestors or len(ancestors)>=64:raise ValueError('GLB hierarchy is cyclic or deeper than 64 levels.')
            ancestors.add(j);j=parents[j]
    roots=scenes[scene_index].get('nodes',[])
    if not isinstance(roots,list) or len(roots)>MAX_NODES:raise ValueError('Invalid GLB scene roots.')
    visited=set();ordered=[];world={}
    pending=[]
    for i in reversed(roots):
        integer(i,0,len(nodes)-1)
        if i in parents:raise ValueError('GLB scene roots must not have parents.')
        pending.append((i,-1,IDENTITY))
    while pending:
        i,parent,parent_matrix=pending.pop()
        if i in visited:raise ValueError('Duplicate GLB scene root.')
        visited.add(i);node=nodes[i]
        if node.get('extensions'):raise ValueError('Node extensions require another scene provider.')
        matrix=multiply(parent_matrix,local_matrix(node));world[i]=matrix
        ordered.append(SceneNode(i,parent,name(node.get('name'),f'Node {i+1}'),matrix))
        pending.extend((j,i,matrix) for j in reversed(children[i]))
    cache={};decoded_components=0
    def accessor(index,position):
        nonlocal decoded_components
        integer(index,0,len(accessors)-1)
        if (index,position) in cache:return cache[index,position]
        a=accessors[index]
        normalized=a.get('normalized',False)
        if 'sparse' in a or a.get('extensions') or type(normalized) is not bool:
            raise ValueError('Sparse or extended accessors are unsupported.')
        component=a.get('componentType');kind=a.get('type')
        if type(component) is not int:raise ValueError('GLB component types must be integers.')
        width_count=1
        if position=='matrix':
            width_count=16
            if kind!='MAT4' or component!=5126 or normalized:raise ValueError('Inverse bind matrices require FLOAT MAT4 accessors.')
            fmt='f'*16;limit=256
        elif position=='joints':
            width_count=4
            if kind!='VEC4' or component not in (5121,5123) or normalized:raise ValueError('Joint indices require unsigned byte/short VEC4 accessors.')
            fmt={5121:'B',5123:'H'}[component]*4;limit=MAX_VERTICES
        elif position in ('uv','color','weights'):
            width_count=2 if position=='uv' else 3 if position=='color' and kind=='VEC3' else 4
            valid_types=('VEC2',) if position=='uv' else ('VEC4',) if position=='weights' else ('VEC3','VEC4')
            if kind not in valid_types or component not in (5126,5121,5123) or normalized!=(component!=5126):
                raise ValueError('UV/color streams require FLOAT or normalized unsigned byte/short vectors.')
            fmt={5126:'f',5121:'B',5123:'H'}[component]*width_count;limit=MAX_VERTICES
        elif position:
            width_count=4 if position=='tangent' else 3
            if component!=5126 or kind!='VEC'+str(width_count) or normalized:
                raise ValueError('Positions, normals and tangents require FLOAT vectors.')
            fmt='f'*width_count;limit=MAX_VERTICES
        else:
            if component not in (5121,5123,5125) or kind!='SCALAR' or normalized:raise ValueError('Triangle indices must be unsigned scalar integers.')
            fmt={5121:'B',5123:'H',5125:'I'}[component];limit=MAX_TRIANGLES*3
        width=struct.calcsize('<'+fmt);alignment=width//width_count
        count=integer(a.get('count'),1,limit)
        decoded_components+=count*width_count
        if decoded_components>MAX_VERTICES*24+MAX_TRIANGLES*3:
            raise ValueError('GLB declared geometry exceeds the total decoded-accessor budget.')
        view=views[integer(a.get('bufferView'),0,len(views)-1)]
        if view.get('buffer')!=0 or type(view.get('buffer')) is not int or view.get('extensions'):
            raise ValueError('Geometry must use the embedded GLB buffer without extensions.')
        start=integer(view.get('byteOffset',0),0,len(binary));length=integer(view.get('byteLength'),1,len(binary))
        offset=integer(a.get('byteOffset',0),0,length);stride=view.get('byteStride',width)
        integer(stride,width,252)
        if (not position and 'byteStride' in view or stride%alignment or offset%alignment or
                (start+offset)%alignment or position and (stride%4 or offset%4) or
                start+length>len(binary) or offset+stride*(count-1)+width>length):
            raise ValueError('GLB accessor alignment, stride or range is invalid.')
        result=[]
        for n in range(count):
            value=struct.unpack_from('<'+fmt,binary,start+offset+n*stride)
            if normalized:value=tuple(v/{5121:255,5123:65535}[component] for v in value)
            if position=='color':
                from avatar_scene_appearance import factor
                value=tuple(factor(v) for v in value)+( (1.,) if width_count==3 else () )
                result.append(value)
            elif position=='joints':result.append(value)
            else:result.append(vector(value,width_count) if position else value[0])
        cache[index,position]=result
        return result
    from avatar_scene_deform import parse_skins,RigPart,positions,influences,morph_weights,MAX_TARGETS,MAX_MORPH_VERTICES
    skins,skin_map=parse_skins(doc,ordered,accessor)
    parts=[];vertex_total=0;triangle_total=0;primitive_total=0;morph_total=0
    for sn in ordered:
        node=nodes[sn.index]
        if 'mesh' not in node:
            if 'skin' in node or 'weights' in node:raise ValueError('Skin/morph nodes must reference a mesh.')
            continue
        mesh=meshes[integer(node['mesh'],0,len(meshes)-1)]
        primitives=array(mesh,'primitives',512)
        if not primitives:raise ValueError('GLB mesh has no primitives.')
        target_count=None
        for primitive in primitives:
            primitive_total+=1
            if primitive_total>512:raise ValueError('GLB primitive instances exceed 512.')
            if primitive.get('mode',4)!=4 or type(primitive.get('mode',4)) is not int:
                raise ValueError('Export GLB triangle primitives for this viewer.')
            if primitive.get('extensions'):
                raise ValueError('Compressed or extended primitives need another scene provider.')
            attributes=primitive.get('attributes')
            if not isinstance(attributes,dict) or 'POSITION' not in attributes:raise ValueError('Every mesh needs a POSITION accessor.')
            if any(k.startswith(('JOINTS_','WEIGHTS_')) and k not in ('JOINTS_0','WEIGHTS_0') for k in attributes):
                raise ValueError('This preview supports four skin influences per vertex; additional influence sets need another provider.')
            vertices=accessor(attributes['POSITION'],True)
            material=integer(primitive['material'],0,len(materials)-1) if 'material' in primitive else -1
            uv_name='TEXCOORD_'+str(materials[material].uv_set if material>=0 else 0)
            uvs=accessor(attributes[uv_name],'uv') if uv_name in attributes else ()
            colors=accessor(attributes['COLOR_0'],'color') if 'COLOR_0' in attributes else ()
            normals=accessor(attributes['NORMAL'],'normal') if 'NORMAL' in attributes else ()
            tangents=accessor(attributes['TANGENT'],'tangent') if 'TANGENT' in attributes else ()
            if any(stream and len(stream)!=len(vertices) for stream in (uvs,colors,normals,tangents)):
                raise ValueError('UV, color, normal and tangent counts must match POSITION count.')
            indices=accessor(primitive['indices'],False) if 'indices' in primitive else list(range(len(vertices)))
            if len(indices)%3:raise ValueError('Triangle indices must be grouped in threes.')
            triangles=[];source_faces=[]
            for n in range(0,len(indices),3):
                triangle=tuple(integer(v,0,len(vertices)-1) for v in indices[n:n+3])
                source_faces.append(triangle)
                if len(set(triangle))<3:continue
                triangles.append(triangle)
            if not triangles:raise ValueError('A GLB primitive contains no distinct-index triangles.')
            from avatar_mesh_health import analyze
            health=analyze(vertices,source_faces,normals=normals,tangents=tangents,uvs=uvs)
            used=sorted({v for t in triangles for v in t});remap={v:n for n,v in enumerate(used)}
            vertex_total+=len(used);triangle_total+=len(triangles)
            if vertex_total>MAX_VERTICES or triangle_total>MAX_TRIANGLES:
                raise ValueError('GLB preview exceeds 100,000 used vertices or 30,000 triangles across instances. Export a reduced copy.')
            targets=array(primitive,'targets',MAX_TARGETS)
            if target_count is None:target_count=len(targets)
            elif target_count!=len(targets):raise ValueError('All mesh primitives must have the same morph target count.')
            defaults=morph_weights(node.get('weights',mesh.get('weights',[0.]*len(targets))),len(targets))
            extras=mesh.get('extras',{});labels=extras.get('targetNames') if isinstance(extras,dict) else None
            if labels is not None and (not isinstance(labels,list) or len(labels)!=len(targets) or any(not isinstance(v,str) for v in labels)):
                raise ValueError('Morph target names must match the target count.')
            names=tuple(name(v,f'Target {i+1}') for i,v in enumerate(labels)) if labels is not None else tuple(f'Target {i+1}' for i in range(len(targets)))
            morph_total+=len(targets)*len(used)
            if morph_total>MAX_MORPH_VERTICES:raise ValueError('GLB morph previews support at most 200,000 target vertices across instances.')
            deltas=[]
            for target in targets:
                if not target or set(target)-{'POSITION','NORMAL','TANGENT'}:raise ValueError('Only position/normal/tangent morph declarations are supported.')
                displacement=None
                for semantic,index in target.items():
                    if semantic not in attributes:raise ValueError('Morph attributes need matching base attributes.')
                    values=accessor(index,'morph')
                    if len(values)!=len(vertices):raise ValueError('Morph target count must match POSITION count.')
                    if semantic=='POSITION':displacement=values
                deltas.append(tuple(displacement[v] for v in used) if displacement is not None else ((0.,0.,0.),)*len(used))
            skin=skin_map[node['skin']] if 'skin' in node else -1
            joints=weights=()
            if skin>=0:
                if 'JOINTS_0' not in attributes or 'WEIGHTS_0' not in attributes:raise ValueError('Skinned meshes require JOINTS_0 and WEIGHTS_0.')
                js,ws=influences(accessor(attributes['JOINTS_0'],'joints'),accessor(attributes['WEIGHTS_0'],'weights'),len(vertices),skins[skin])
                joints=tuple(js[v] for v in used);weights=tuple(ws[v] for v in used)
            elif 'JOINTS_0' in attributes or 'WEIGHTS_0' in attributes:
                raise ValueError('Skin attributes require an assigned skin in this viewer.')
            rig=RigPart(tuple(vertices[v] for v in used),world[sn.index],skin,joints,weights,names,tuple(deltas),defaults) if skin>=0 or targets or doc.get('animations') else None
            transformed=positions(rig,skins,world) if rig else tuple(transform(world[sn.index],vertices[v]) for v in used)
            matrix=world[sn.index]
            mirrored=skin<0 and (matrix[0]*(matrix[5]*matrix[10]-matrix[9]*matrix[6])-matrix[4]*(matrix[1]*matrix[10]-matrix[9]*matrix[2])+matrix[8]*(matrix[1]*matrix[6]-matrix[5]*matrix[2]))<0
            faces=tuple(tuple(remap[v] for v in (t[::-1] if mirrored else t)) for t in triangles)
            parts.append(ScenePart(sn.index,transformed,faces,tuple(uvs[v] for v in used) if uvs else (),material,tuple(colors[v] for v in used) if colors else (),health,rig))
    if not parts:raise ValueError('The selected GLB scene contains no supported triangles.')
    all_vertices=tuple(v for part in parts for v in part.vertices);box=bounds(all_vertices)
    if max(box[1][k]-box[0][k] for k in range(3))<=1e-12:raise ValueError('Scene geometry has degenerate bounds.')
    notices=('Base-color embedded PNG/JPEG preview with material-selected UV sets, UV transforms, vertex colors and nearest/linear filtering. Missing UV streams use color factors. PBR shading, lights and cameras are not rendered.',
             'Animation declarations are present; inspect per-clip availability and coverage in Animation timeline before playback.' if doc.get('animations') else 'No animation clips in this scene.',
             'Only the default scene is displayed.' if 'scene' in doc else 'No default was declared; the first scene is displayed.',
             'Four-weight linear skinning at imported joint transforms; position morphs precede skinning. Normal/tangent morph deltas are validated but not rendered. Mesh-health findings describe source geometry.',
             'External resources are never read; this preview does not show Unity shader appearance.')
    scene=Scene(tuple(ordered),tuple(parts),box,sha256(data).hexdigest(),len(data),notices,materials,textures,skins)
    from dataclasses import replace
    from avatar_animation_glb import parse as animation
    return replace(scene,animations=animation(doc,binary,views,accessors,scene))


def descendants(scene,node):
    found={node}
    for current in scene.nodes:
        if current.parent in found:found.add(current.index)
    return found


def make_view(scene,hidden=(),focus=None,*,framing=None):
    """Prepare bounded OBJ-renderer batches once per visibility/focus change."""
    from avatar_model_preview import MeshPreview
    ids={n.index for n in scene.nodes}
    if set(hidden)-ids or focus is not None and focus not in ids:raise ValueError('Select a node in the current scene.')
    excluded=set()
    for node in hidden:excluded.update(descendants(scene,node))
    visible=[p for p in scene.parts if p.node not in excluded]
    focused=[p for p in visible if p.node in descendants(scene,focus)] if focus is not None else list(scene.parts)
    if not focused:raise ValueError('The selected node has no visible mesh to frame.')
    box=bounds(tuple(v for p in focused for v in p.vertices));center=tuple((box[0][k]+box[1][k])/2 for k in range(3))
    radius=max(math.sqrt(sum((v[k]-center[k])**2 for k in range(3))) for p in focused for v in p.vertices)
    if framing is not None:
        center=vector(framing[0],3);radius=vector([framing[1]],1)[0]
    if radius<=1e-12:raise ValueError('Selected mesh bounds cannot be framed.')
    # Focus displays the selected subtree; it does not drop geometry silently.
    if focus is not None:visible=focused
    batches=[]
    for part in visible:
        for start in range(0,len(part.triangles),6000):
            triangles=part.triangles[start:start+6000];used=sorted({v for t in triangles for v in t});remap={v:n for n,v in enumerate(used)}
            vertices=tuple(tuple((part.vertices[v][k]-center[k])/radius for k in range(3)) for v in used)
            if any(abs(v)>10000 for point in vertices for v in point):raise ValueError('Motion exceeds 10,000 framing radii. Reset the pose and choose a larger framing or a translation anchor.')
            batches.append((part.node,MeshPreview(vertices,tuple(tuple(remap[v] for v in t) for t in triangles),len(vertices),len(triangles),scene.source_bytes,scene.sha256,box,(),(),tuple(part.uvs[v] for v in used) if part.uvs else (),part.material,tuple(part.colors[v] for v in used) if part.colors else ())))
    return tuple(batches),center,radius


def wire_bounds(scene,nodes,center,radius,camera,width,height):
    from avatar_model_preview import validate_camera
    validate_camera(camera)
    vertices=tuple(v for p in scene.parts if p.node in nodes for v in p.vertices)
    if not vertices:return ()
    low,high=bounds(vertices)
    corners=[tuple(((high[k] if n & (1<<k) else low[k])-center[k])/radius for k in range(3)) for n in range(8)]
    cy,sy=math.cos(math.radians(camera.yaw)),math.sin(math.radians(camera.yaw))
    cp,sp=math.cos(math.radians(camera.pitch)),math.sin(math.radians(camera.pitch));scale=min(width,height)*.42*camera.zoom
    output=[]
    for x,y,z in corners:
        rx,rz=cy*x+sy*z,-sy*x+cy*z
        output.append((width*(.5+camera.pan_x)+rx*scale,height*(.5+camera.pan_y)-(cp*y-sp*rz)*scale))
    return tuple(output[n]+output[n^(1<<k)] for n in range(8) for k in range(3) if not n&(1<<k))
