"""Read-only IL2CPP v31 declaration browser for an extracted native-map pack.

Reads bounded byte snapshots and gzip JSON only. No supplied executable, script,
address invocation or live process access. A matching manifest is not publisher
authentication. Native-type names remain supplied map evidence.
"""
import gzip
import hashlib
import io
import os
from pathlib import Path
import re
import struct
import time
from developer_core import bounded_json
from inspection_inputs import snapshot, checkpoint

MIB = 1024*1024
FORMATS = {'strings': (2, None), 'events': (3, '<IIiiiI'), 'properties': (4, '<IiiII'),
           'methods': (5, '<9I'), 'defaults': (7, '<iii'), 'default_data': (8, None),
           'parameters': (10, '<3I'), 'fields': (11, '<3I'), 'nested': (15, '<I'),
           'interfaces': (16, '<I'), 'types': (19, '<16I8H2I'), 'images': (20, '<10I')}


def digest(value):
    if not isinstance(value, str) or not re.fullmatch('[a-fA-F0-9]{64}', value):
        raise ValueError('Missing or invalid reference hash.')
    return value.lower()


def label(value, limit=4096):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError('Invalid declaration text.')
    return value


def discover(root, stop=None):
    root = Path(root).absolute()
    if not root.is_dir() or any(p.is_symlink() for p in (root, *root.parents)):
        raise ValueError('Select an extracted reference folder without symbolic links.')
    files = []; count = 0
    for folder, dirs, names in os.walk(root, followlinks=False):
        checkpoint(stop)
        relative = Path(folder).relative_to(root)
        count += len(dirs)+len(names)
        if count > 500: raise ValueError('Select the small extracted reference pack, not a game or home folder.')
        if len(relative.parts) >= 5: dirs[:] = []
        if any((Path(folder)/name).is_symlink() for name in dirs+names):
            raise ValueError('Reference folders containing symbolic links are not accepted.')
        files.extend(Path(folder)/name for name in names)
    def one(name):
        matches = [p for p in files if p.name == name]
        if len(matches) != 1: raise ValueError('Select one pack containing exactly one '+name+'.')
        return matches[0]
    metadata = one('global-metadata-v31.dat'); native = one('native_types.jsonl.gz')
    report = native.parent/'report.json'; validation = native.parent/'export-validation.json'
    if report not in files or validation not in files:
        raise ValueError('The type map needs its adjacent report.json and export-validation.json.')
    manifests = [p for p in files if p.name == 'il2cpp-manifest.json']
    if len(manifests) > 1: raise ValueError('Choose a single reference pack.')
    return metadata, native, report, validation, manifests[0] if manifests else None


class Table:
    def __init__(self, raw, offset, length, fmt):
        self.raw, self.offset = raw, offset
        self.record = struct.Struct(fmt)
        if length % self.record.size: raise ValueError('Metadata table has a partial record.')
        self.count = length//self.record.size
        if self.count > 1000000: raise ValueError('Metadata table exceeds the record limit.')
    def __len__(self): return self.count
    def __getitem__(self, index):
        if type(index) is not int or not 0 <= index < self.count: raise ValueError('Metadata reference is out of range.')
        return self.record.unpack_from(self.raw, self.offset+index*self.record.size)


class Reference:
    def __init__(self, raw, native, identity, *, stop=None, deadline=None):
        self.raw, self.native, self.identity = raw, native, dict(identity)
        if len(raw) < 256 or struct.unpack_from('<II', raw) != (0xFAB11BAF, 31):
            raise ValueError('Only normalized IL2CPP metadata version 31 is supported.')
        header = struct.unpack_from('<64I', raw)
        self.sections = [(header[2+i*2], header[3+i*2]) for i in range(31)]
        spans = []
        for offset, size in self.sections:
            if offset > len(raw) or size > len(raw)-offset or size and offset < 256:
                raise ValueError('Metadata section lies outside the input.')
            if size: spans.append((offset, offset+size))
        spans.sort()
        if any(a[1] > b[0] for a,b in zip(spans,spans[1:])): raise ValueError('Overlapping metadata sections.')
        self.tables = {name: Table(raw,*self.sections[section],fmt) for name,(section,fmt) in FORMATS.items() if fmt}
        self.types = self.tables['types']; self.names = {}; self.name_bytes = 0; self.defaults = {}
        if len(self.types)>100000 or len(self.tables['images'])>2000: raise ValueError('Reference catalog is too large.')
        self.owners = [None]*len(self.types)
        for i in range(len(self.tables['images'])):
            row = self.tables['images'][i]; assembly = self.string(row[0])
            self.range(row[2],row[3],len(self.types))
            for j in range(row[2],row[2]+row[3]):
                if self.owners[j] is not None: raise ValueError('Duplicate metadata type ownership.')
                self.owners[j] = assembly
        if any(n is None for n in self.owners): raise ValueError('Metadata type ownership is incomplete.')
        for index in range(len(self.tables['defaults'])):
            f,t,d = self.tables['defaults'][index]
            if f in self.defaults or not 0<=f<len(self.tables['fields']) or not 0<=t<len(native) or not (d == -1 or 0<=d<self.sections[8][1]):
                raise ValueError('Invalid field constant reference.')
            self.defaults[f] = (t,d)
        self.rows = []; self.definition_index = {}
        for i in range(len(self.types)):
            if i%256 == 0: checkpoint(stop,deadline)
            t = self.types[i]
            for start,count,table in ((t[8],t[18],'fields'),(t[9],t[16],'methods'),(t[10],t[19],'events'),
                                      (t[11],t[17],'properties'),(t[12],t[20],'nested'),(t[13],t[22],'interfaces')):
                self.range(start,count,len(self.tables[table]))
            name = self.type_name(t[2]); self.type_name(t[4])
            # Primitive descriptors carry a kind rather than a definition index.
            descriptor=native[t[2]]
            primitive=descriptor[2] is None and descriptor[1] in (*range(1,15),22,24,25,28)
            if not primitive and descriptor[2] != i: raise ValueError('Native type map does not match the metadata definitions.')
            if t[2] in self.definition_index: raise ValueError('Duplicate by-value type identity.')
            self.definition_index[t[2]]=i
            self.rows.append(dict(index=i,name=name,assembly=self.owners[i],kind='Enum' if t[24]&2 else 'Type',
                                  fields=t[18],properties=t[17],methods=t[16],events=t[19]))
        for table in ('fields','parameters','events','methods','properties'):
            for i in range(len(self.tables[table])):
                if i%2048 == 0: checkpoint(stop,deadline)
                r = self.tables[table][i]; self.string(r[0])
                if table in ('fields','events'): self.type_name(r[1])
                elif table == 'parameters': self.type_name(r[2])
                elif table == 'methods': self.type_name(r[2])
        self.identity['counts'] = {k:len(v) for k,v in self.tables.items()}
        self.identity['counts']['native_types'] = len(native)
        self.identity['native_match'] = 'Not checked; the game DLL is not required for declaration browsing.'

    @staticmethod
    def range(start, count, length):
        if count and (not 0<=start<length or count>length-start): raise ValueError('Metadata member range is invalid.')

    def string(self, index):
        if index in self.names: return self.names[index]
        start,size = self.sections[2]
        if not 0<=index<size: raise ValueError('Metadata string reference is invalid.')
        end = self.raw.find(b'\0',start+index,min(start+size,start+index+4097))
        if end == -1: raise ValueError('Metadata string is unterminated or too long.')
        try: value = label(self.raw[start+index:end].decode('utf-8'))
        except UnicodeError as error: raise ValueError('Metadata name is not UTF-8.') from error
        self.name_bytes += end-(start+index)
        if len(self.names)>=500000 or self.name_bytes>32*MIB: raise ValueError('Metadata name catalog exceeds the text budget.')
        self.names[index] = value
        return value

    def type_name(self, index):
        if index == 0xFFFFFFFF: return None
        if not 0<=index<len(self.native): raise ValueError('Native type reference is invalid.')
        return self.native[index][0]

    def search(self, query='', assembly='All', kind='All', offset=0, limit=100):
        query=label(query,160).casefold(); offset=max(0,int(offset));limit=max(1,min(200,int(limit)))
        if kind not in ('All','Enum','Type'): raise ValueError('Choose a type filter.')
        matches = [r for r in self.rows if (assembly=='All' or r['assembly']==assembly) and
                   (kind=='All' or r['kind']==kind) and query in r['name'].casefold()]
        return matches[offset:offset+limit],len(matches)

    def parent(self, index):
        t=self.types[index];n=t[4]
        if n==0xFFFFFFFF:return None
        index=self.definition_index.get(n,self.native[n][2])
        if index is not None and not 0<=index<len(self.types):raise ValueError('Parent definition is out of range.')
        return index

    def constant(self, field):
        pair=self.defaults.get(field)
        if pair is None or pair[1]==-1: return None
        typ,index=pair;kind=self.native[typ][1];start,size=self.sections[8];pos=start+index;end=start+size
        def take(n):
            nonlocal pos
            if pos+n>end: raise ValueError('Truncated metadata constant.')
            out=self.raw[pos:pos+n];pos+=n;return out
        if kind in (8,9):
            first=take(1)[0]
            if first<128: value=first
            elif first<192: value=((first&63)<<8)|take(1)[0]
            elif first<224: value=((first&31)<<24)|int.from_bytes(take(3),'big')
            elif first==240: value=int.from_bytes(take(4),'little')
            elif first==254: value=0xFFFFFFFE
            elif first==255: value=0xFFFFFFFF
            else: raise ValueError('Unsupported compressed integer constant.')
            return (-2147483648 if value==0xFFFFFFFF else -(value//2+1) if value&1 else value//2) if kind==8 else value
        fmt={2:'?',3:'H',4:'b',5:'B',6:'h',7:'H',10:'q',11:'Q'}.get(kind)
        return struct.unpack('<'+fmt,take(struct.calcsize(fmt)))[0] if fmt else None

    def detail(self, index, *, offset=0, limit=200):
        t=self.types[index];members=[];offset=max(0,int(offset));limit=max(1,min(200,int(limit)))
        groups=(('fields',t[8],t[18]),('properties',t[11],t[17]),('events',t[10],t[19]),('methods',t[9],t[16]))
        total=sum(g[2] for g in groups);position=0
        # Decode only the requested page, including method argument excerpts.
        # Large types must not allocate every expanded signature to show 200 rows.
        for group,start,count in groups:
            low=max(0,offset-position);high=min(count,offset+limit-position)
            for j in range(start+low,start+max(low,high)):
                row=self.tables[group][j];name=self.string(row[0])
                if group=='fields':
                    members.append(dict(kind='Field',name=name,type=self.type_name(row[1]),constant=self.constant(j) if t[24]&2 else None))
                elif group=='properties':
                    getter,setter=row[1:3]
                    if any(x!=-1 and not 0<=x<t[16] for x in (getter,setter)): raise ValueError('Property accessor is outside its declaring type.')
                    members.append(dict(kind='Property',name=name,type=self.type_name(self.tables['methods'][t[9]+getter][2]) if getter!=-1 else None,
                                        access=('get ' if getter!=-1 else '')+('set' if setter!=-1 else '')))
                elif group=='events':members.append(dict(kind='Event',name=name,type=self.type_name(row[1])))
                else:
                    parameter_count=row[8]>>16;parameter_start=row[4]
                    self.range(parameter_start,parameter_count,len(self.tables['parameters']))
                    args=[];remaining=3000-len(name)
                    for p in range(parameter_start,parameter_start+min(parameter_count,64)):
                        a=self.tables['parameters'][p];arg=(self.type_name(a[2]) or '?')+' '+self.string(a[0])
                        if len(arg)>remaining:break
                        args.append(arg);remaining-=len(arg)+2
                    if len(args)<parameter_count:args.append('… [arguments truncated]')
                    members.append(dict(kind='Method',name=name+'('+', '.join(args)+')',type=self.type_name(row[2])))
            position+=count
        return dict(self.rows[index],parent=self.type_name(t[4]),parent_index=self.parent(index),
                    interfaces=[self.type_name(self.tables['interfaces'][j][0]) for j in range(t[13],t[13]+min(t[22],64))],
                    interface_count=t[22],interfaces_truncated=t[22]>64,
                    total_members=total,offset=offset,members=members)

    def selected_report(self,index,offset=0):
        return dict(schema='vrc-eye-metadata-selection-1',reference=dict(self.identity),
                    declaration=self.detail(index,offset=offset),
                    scope='Selected declaration page only. Names/types/accessors do not establish executable behavior or public API access.')


def load(root, *, stop=None, progress=lambda value:None):
    deadline=time.monotonic()+90
    metadata,native_path,report_path,validation_path,manifest=discover(root,stop)
    def read(path,limit): return snapshot(path,limit,stop=stop,deadline=deadline)
    report=bounded_json(read(report_path,512*1024)[0],limit=512*1024)
    validation=bounded_json(read(validation_path,512*1024)[0],limit=512*1024)
    if not isinstance(report,dict) or not isinstance(validation,dict): raise ValueError('Invalid reference manifest.')
    expected=digest(report.get('metadataSha256'));dll=digest(report.get('dllSha256'))
    if digest(validation.get('normalizedMetadataSha256'))!=expected or digest(validation.get('inputDllSha256'))!=dll:
        raise ValueError('Reference manifests disagree about their input identities.')
    progress('Reading normalized metadata…');raw,sha=read(metadata,128*MIB)
    if sha!=expected: raise ValueError('Normalized metadata hash differs from the reference map.')
    entries=validation.get('files')
    if not isinstance(entries,list): raise ValueError('Missing reference file hashes.')
    entries=[r for r in entries if isinstance(r,dict) and r.get('name')=='native_types.jsonl.gz']
    if len(entries)!=1: raise ValueError('Missing or duplicate native type-map identity.')
    compressed,native_sha=read(native_path,16*MIB)
    if digest(entries[0].get('sha256'))!=native_sha or entries[0].get('bytes')!=len(compressed):
        raise ValueError('Native type-map bytes differ from the reference manifest.')
    progress('Validating type names and relationships…');native=[];expanded=0;name_bytes=0
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
            while True:
                checkpoint(stop,deadline)
                line=stream.readline(65537)
                if not line: break
                expanded+=len(line)
                if len(line)>65536 or expanded>128*MIB or len(native)>=500000: raise ValueError('Expanded type map exceeds the inspection limit.')
                row=bounded_json(line,limit=65536)
                if not isinstance(row,dict) or type(row.get('typeIndex')) is not int or row['typeIndex']!=len(native):
                    raise ValueError('Native type indices must be unique and contiguous.')
                kind=row.get('kind');definition=row.get('typeDefinitionIndex')
                if type(kind) is not int or not 0<=kind<=255 or definition is not None and (type(definition) is not int or not 0<=definition<100000):
                    raise ValueError('Invalid native type descriptor.')
                name=label(row.get('displayName'));name_bytes+=len(name.encode('utf-8'))
                if name_bytes>32*MIB:raise ValueError('Native type names exceed the text budget.')
                native.append((name,kind,definition))
    except (OSError,EOFError) as error: raise ValueError('Native type gzip is incomplete or invalid.') from error
    if type(report.get('nativeTypes')) is not int or len(native)!=report['nativeTypes']:
        raise ValueError('Native type count differs from the report.')
    identity=dict(metadata_sha256=sha,native_types_sha256=native_sha,declared_dll_sha256=dll,
                  metadata_version=31,game_build='Unknown',unity_version='Unknown',
                  validation='Selected metadata/type-map hashes and declaration structure checked; publisher and native mappings not authenticated.')
    if manifest:
        doc=bounded_json(read(manifest,256*1024)[0])
        if not isinstance(doc,dict) or digest(doc.get('GameAssemblySha256'))!=dll: raise ValueError('Build manifest and map DLL identities disagree.')
        identity.update(game_build=label(doc.get('GameVersion','Unknown'),160),unity_version=label(doc.get('UnityVersion','Unknown'),80))
    reference=Reference(raw,native,identity,stop=stop,deadline=deadline)
    if type(report.get('methodDefinitions')) is not int or report['methodDefinitions']!=len(reference.tables['methods']): raise ValueError('Method count differs from the reference report.')
    checkpoint(stop,deadline);progress('Reference ready. No game code was loaded.')
    return reference


def check_binary(reference,path,*,stop=None):
    _,actual=snapshot(path,1024*MIB,stop=stop,deadline=time.monotonic()+90,digest_only=True)
    return dict(state='Exact hash match' if actual==reference.identity['declared_dll_sha256'] else 'Hash mismatch',
                checked_sha256=actual,expected_sha256=reference.identity['declared_dll_sha256'],
                scope='Selected file bytes only; does not validate symbol addresses or current runtime compatibility.')
