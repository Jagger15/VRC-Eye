# Safety design input and implementation status — VRC Eye 1.18.5

The original user-supplied specification is preserved verbatim below. It is a
planning document, not a list of protections already running in this release.
Its Stock / Bridge-enhanced / Bridge-only labels are requested design categories;
the availability of each proposed OS, VRChat or runtime integration must be
verified when that module is implemented. Mock statuses such as PROTECTED or
Recording in the examples are not current VRC Eye status reports.

## Bridge foundation (introduced in 1.18.4)

- An optional external local client bridge, disabled by default, with an open
  versioned protocol, Python reference SDK and working diagnostic adapter.
- Quarantine for every connection, including telemetry until approved; separate
  per-capability approvals, session/10-minute/1-hour expiry, an extra local-game
  controls switch, and bridge-only request pause.
- Authenticated local IPC; capability negotiation; session/account/runtime
  isolation; heartbeat and sample expiry; bounded typed requests, confirmation,
  no automatic retry; bridge failure isolation and an in-memory request ledger.
- A dedicated Advanced bridge dialog that shows fresh approved telemetry and
  reviewed, capability-specific local controls supplied by a connected adapter.
  The bridge requires no API login or VRCX. A real game adapter is required for
  game data/actions; the diagnostic example cannot enable them.

## Coverage of the supplied design

| Requested area | Status in 1.18.5 |
| --- | --- |
| Sections 27–30 and 51: integration isolation, quarantine, permissions, consent, bridge supervisor | Implemented for this bridge only; permissions are connection-bound, not persistent friend-sharing permissions |
| Sections 3–8, 35, 53–55: avatar/voice/microphone/interaction/player/runtime integration | Typed telemetry and local-action contracts plus advanced-panel controls; requires an adapter implementing each capability; richer player panels and automatic correlation remain planned |
| Sections 4–5: presets and focus groups | Client-defined preset descriptions and reviewed requests supported; VRC Eye has no built-in client renderer implementation |
| Sections 21 and 24: outbound stop and action ledger | Bridge-only request pause and last 200 in-memory outcomes; application-wide controls/persistent auditing remain planned |
| Section 49: Wellness | Expanded local Wellness Center with optional external process, SteamVR overlay/proximity/battery and Windows audio inputs; see WELLNESS_SETUP.md. Cross-module Safety coordination remains planned |
| Section 56: deliberate exclusions | Design boundaries retained; no arbitrary Unity execution, other-client control or protected-asset bypass added |
| Other requested modules and the combined Safety Center | Planned; not implemented or claimed active by this bridge-foundation release |

The core companion pages remain independent of the bridge. A later Safety
Center can use `app.bridge.available`, `app.bridge.get_sample` and reviewed
`app.bridge.request` calls while retaining its stock operation. See
BRIDGE_SETUP.md and BRIDGE_PROTOCOL.md for implemented behavior and limitations.
No placeholder Safety category has been added yet.

---

## Original supplied specification

**🟢 Stock** = works with normal VRChat.\
**🟣 Bridge-enhanced** = works normally, but a compatible client bridge can make it more accurate.\
**🔵 Bridge-only** = only appears when a compatible client explicitly provides the required capability.

VRChat already provides substantial built-in protections for voice, avatars, avatar audio, particles/lights, shaders, custom animations and interactions, and its Safe Mode can disable remote-user features immediately. Safe Mode is also exposed through the documented OSC `/input/PanicButton`, so VRC Eye can legitimately build emergency controls around it without modifying VRChat. [VRChat](https://docs.vrchat.com/docs/VRChat-safety-and-trust-system?utm_source=chatgpt.com)

# 1. Emergency Safety Controls

These should probably be the most accessible controls anywhere in VRC Eye.

- **🟢 Emergency Safe Mode button.** Sends VRChat's supported Panic/Safe Mode command. One click from desktop, SteamVR overlay, wrist panel, or global hotkey.
- **🟢 Emergency Escape Panel.** Opens a minimal panel containing:
  - Activate Safe Mode
  - Mute your microphone
  - Reduce/mute VRChat application audio
  - Enable VRC Eye Privacy Mode
  - Close VRChat
- **🟢 Global emergency hotkey.** Something deliberately difficult to press accidentally.
- **🟢 VR overlay emergency button.** Always reachable even if VRChat's UI becomes difficult to use.
- **🟢 Safety countdown.** Before an automatic protective action:
  > Critical resource condition. VRChat will close in 15 seconds.
  With **Cancel** and **Exit Now**.
- **🟢 Offline emergency operation.** Panic, mic control, audio reduction and exit should continue working even if VRC Eye's internet/API services are unavailable.
- **🟢 Minimal Emergency Mode.** Shut down every unnecessary VRC Eye module and leave only resource monitoring, emergency controls, logging and overlay functionality running.

VRChat's own Panic mode also pauses Avatar Dynamics interactions and changes its Safety configuration to maximum protection. [VRChat](https://docs.vrchat.com/docs/permissions-and-settings?utm_source=chatgpt.com)

# 2. Safe Arrival / Public Instance Protection

This was one of the strongest ideas we discussed.

**Safe Arrival Mode** activates temporarily whenever the user enters an unfamiliar or public instance.

VRC Eye could watch:

- player population,
- number of players arriving/loading,
- VRChat RAM,
- system RAM,
- VRAM,
- GPU load,
- frame/performance degradation where measurable,
- avatar load errors,
- audio spikes,
- tracking state,
- network behavior.

Example:

```
SAFE ARRIVAL

Public instance
Players                  46
Avatars loading          19
VRAM                     88%
System RAM               81%
Audio                    Normal
Tracking                 Normal

Heightened monitoring: 18 sec remaining
```

Other related features:

- **🟢 Avatar Storm Detector.** Detect many avatars loading in a short period.
- **🟢 Crowd Pressure Warning.** Combine rapidly rising population with resource pressure.
- **🟢 Safe Join Gate.** When joining through VRC Eye, show instance type, population and previous local problems before entering.
- **🟢 Unexpected Instance Warning.** Alert if VRC Eye observes that the user landed somewhere different from the intended destination.
- **🟢 Personal World Safety Memory.** Remember things such as:
  - previous crashes here,
  - repeated high VRAM pressure,
  - frequent audio spikes,
  - unusually long loading.
  Importantly, phrase it as **your previous experience**, not “this world is dangerous.”
- **🟢 Automatic Safe Mode escalation.** Optional and disabled by default. Multiple severe conditions could trigger VRChat's supported Panic action.
- **🟣 Better attribution with Bridge Mode.** A bridge could tell VRC Eye which avatar finished loading immediately before a resource spike.

# 3. Avatar Safety

Stock VRC Eye cannot directly control arbitrary avatar internals, but it can still provide useful protection.

### Stock

- **🟢 Avatar load-state monitoring.**
  - Loading
  - Loaded
  - Failed
  - Security failure
  - Bundle/load failure
  - Unknown error
- **🟢 Avatar-load danger monitor.** Correlate avatar loading with sudden RAM/VRAM/performance changes.
- **🟢 Observed Resource Impact.**

Example:

```
Alice changed avatars.

Observed shortly afterward:
VRAM +620 MB
RAM  +840 MB

Confidence: Medium
```

Not:

> Alice's avatar uses exactly 620 MB.

- **🟢 Performance warnings.** Flag severe *observed* resource impact without accusing the avatar creator of malicious behavior.
- **🟢 Avatar failure history.** Remember that your machine previously failed to load a particular observed avatar/session context.

### Bridge-enhanced

A compatible client might provide authoritative client-side telemetry:

- avatar performance rank,
- texture memory,
- load state,
- renderer count,
- PhysBone statistics,
- contact count,
- local audio/effect state.

Example:

```
ALICE — AVATAR SAFETY

Performance             Very Poor
Texture Memory          184 MB
Load State              Ready
Avatar Audio            Enabled
Visual Effects          Enabled
```

### Bridge-only local safety actions

If the client deliberately exposes them:

- **🔵 Hide/show avatar locally**
- **🔵 Disable avatar audio**
- **🔵 Reduce visual effects**
- **🔵 Disable locally rendered particles/lights**
- **🔵 Apply normal VRChat safety settings**
- **🔵 Pause avatar interactions**
- **🔵 Simplified/fallback avatar mode**, if supported by that client

These should affect **only the local user's experience**.

# 4. Per-Player Safety Profiles — Bridge Mode

This was a particularly good bridge concept.

Instead of ten switches:

```
Safety for Alice

● Normal
○ Reduced
○ Minimal
○ Hidden
```

The client defines what each preset actually controls.

For example:

**Normal**

- normal avatar,
- audio,
- effects,
- interactions.

**Reduced**

- avatar remains visible,
- avatar audio disabled,
- expensive visual effects reduced.

**Minimal**

- limited visual presentation,
- reduced effects/interactions.

**Hidden**

- avatar hidden locally.

VRC Eye would merely request the preset through the bridge.

# 5. Focus Group Safety — Bridge Mode

Useful in crowded public instances.

The player could pin people they actually want to interact with:

```
FOCUS GROUP

✓ Alice
✓ Bob
✓ Charlie

[ Apply Focus Safety ]
```

A compatible client could then reduce local rendering/audio/effects from everyone outside that group.

Potential uses:

- crowded conventions,
- photography,
- performance-heavy instances,
- sensory accessibility,
- small conversations in large publics.

Again, this should be local-only.

# 6. Audio Safety

We discussed this extensively because audio can be one of the most immediately unpleasant things in social VR.

### Stock

- **🟢 Overall VRChat audio spike detector.**
- **🟢 Sustained loudness monitor.**
- **🟢 Application audio limiter.**
- **🟢 Emergency VRChat volume reduction.**
- **🟢 Audio-device disconnect warning.**
- **🟢 Unexpected output-device switch warning.**
- **🟢 Hearing-protection warnings.**
- **🟢 Audio Guard status indicator.**
- **🟢 Optional audio ducking when VRC Eye emits an important warning.**

A warning could look like:

```
⚠ AUDIO GUARD

VRChat output has remained unusually loud
for 8 seconds.

[ Lower VRChat Volume ]
[ Mute VRChat ]
[ Ignore ]
```

### Bridge-enhanced

The big benefit is attribution.

Stock VRC Eye might only know:

> VRChat audio spiked.

A bridge could potentially report:

> Alice's voice became active.

or:

> Alice's avatar audio is currently playing.

Then the player card could expose local controls.

I would still avoid automatically labelling someone malicious merely because they were loud.

# 7. Microphone Privacy

Separate from incoming audio.

- **🟢 Mic-state indicator.**
- **🟢 Mic Privacy Watchdog.**
- **🟢 Expected-state protection.**

Example:

```
You expected to be muted.

Current microphone state:
UNMUTED

[ Mute Now ]
```

- **🟢 Device-change warning.** If the selected mic disappears and the OS changes inputs.
- **🟢 Mic test before VR.**
- **🟢 Local clipping/noise meter.**
- **🟢 Privacy indicator in SteamVR overlay.**
- **🟢 Headset-off mic privacy option.**
- **🟢 Streamer Mode mic warnings.**

VRChat exposes voice control through its supported OSC input controller, so VRC Eye can implement supported external mute controls. [VRChat](https://docs.vrchat.com/docs/osc-as-input-controller?utm_source=chatgpt.com)

# 8. Interaction / Personal-Space Safety

VRChat already requires mutual permission for Avatar Dynamics interactions and offers global and per-user interaction controls. [VRChat](https://docs.vrchat.com/docs/permissions-and-settings?utm_source=chatgpt.com)

VRC Eye could complement this with:

- **🟢 Display current interaction-safety reminders.**
- **🟢 Public-instance interaction reminder.**
- **🟢 Quick shortcut to pause interactions where supported.**
- **🟢 Interaction-state indicator.**
- **🟣 Bridge-enhanced exact interaction state.**
- **🔵 Bridge local per-user interaction control**, if explicitly provided by the client.

VRC Eye should not attempt to bypass someone else's interaction permissions.

# 9. RAM / VRAM / CPU / GPU Safety

This becomes one of VRC Eye's major differentiators.

Monitor:

- VRChat working-set RAM,
- system RAM utilization,
- available memory,
- VRAM,
- GPU utilization,
- CPU utilization,
- memory-growth velocity,
- temperatures,
- paging/commit pressure where available.

Escalation:

```
NORMAL
   ↓
WARNING
   ↓
CRITICAL
   ↓
EMERGENCY
```

Possible actions:

- warning only,
- VR overlay warning,
- pause nonessential VRC Eye tasks,
- suggest Safe Mode,
- offer VRChat shutdown,
- automatically close VRChat if explicitly enabled.

# 10. Emergency Resource Guard

The stronger version of the previous feature.

Instead of:

> CPU reached 95%, kill VRChat.

use sustained/multi-signal conditions.

Example:

```
VRAM        >98%
RAM         critically low
Duration    20 sec
VRChat      severely degraded

→ Critical Resource Event
```

Options:

- warn,
- cancel,
- close VRChat gracefully,
- force terminate only as a final explicit option.

CPU/GPU usage alone should generally **not** trigger termination because games can normally operate near full GPU utilization.

# 11. VRChat Memory Guard

We also discussed actual OS-level memory containment.

Modes:

```
Memory Guard

○ Monitor
● Soft protection
○ Hard limit
```

### Windows

Potentially use Job Object process-memory limits.

### Linux

cgroups can provide soft/hard memory boundaries.

The critical warning:

> A hard limit does not make VRChat magically consume less memory. If Unity requests memory beyond the limit, allocations may fail and VRChat may crash.

So VRC Eye should prefer **monitoring and soft protection**.

# 12. Thermal Protection

- CPU temperature monitoring
- GPU temperature monitoring
- sustained thermal warning
- thermal-throttling awareness where available
- VR overlay warning
- optional controlled VRChat shutdown at user-defined critical conditions

Avoid claims such as:

> 83°C is dangerous for every GPU.

Hardware models have different operating limits.

# 13. Disk / Storage Protection

- **Disk Space Guard**
- Watch VRChat cache, screenshots, logs and VRC Eye's own data.
- Warn before the system drive becomes critically full.
- Stop optional VRC Eye recording first.
- Offer safe cleanup actions.
- Avoid silently deleting user content.
- Cache/log cleanup belongs in your higher-risk settings because deleting the wrong files can make troubleshooting harder.

# 14. Network Safety / Diagnostics

Not necessarily “security,” but useful protection against bad sessions.

- latency monitoring,
- jitter,
- packet loss,
- network-interface changes,
- Wi-Fi ↔ Ethernet changes,
- VPN activation/deactivation,
- bandwidth competition detection,
- Internet dropout detection.

VRC Eye could distinguish:

```
VRChat problem?
or
Local network problem?
```

without inspecting/decrypting VRChat communications.

# 15. Tracking and Physical VR Safety

This is another major area.

- **🟢 Tracker disconnect warnings**
- **🟢 Controller disconnect warnings**
- **🟢 HMD tracking-loss warning**
- **🟢 Tracker Drift Monitor**
- **🟢 Tracking stability history**
- **🟢 Calibration Assistant**
- **🟢 Unexpected tracking-space change warning**
- **🟢 Headset/controller battery warnings**
- **🟢 Approximate battery-runtime prediction**
- **🟢 USB device disconnect/reset warnings**

### Playspace protection

SteamVR/OpenVR's Chaperone API exposes calibration state and play-area dimensions, and utilities can determine whether bounds are visible. [GitHub](https://github.com/ValveSoftware/openvr/wiki/IVRChaperone_Overview?utm_source=chatgpt.com)

VRC Eye could therefore provide:

```
PLAYSPACE

Calibration          ✓
Play Area            2.4 × 2.1 m
Boundary             Visible
Tracking             Stable
```

and:

> ⚠ SteamVR boundary configuration appears invalid.

It could also offer a supported **Show Boundary** action where the runtime permits it.

# 16. Headset-Off Safety

When SteamVR indicates the headset is no longer being worn:

- hide sensitive overlay content,
- hide Whispers,
- hide personal notes,
- suppress private notification previews,
- optionally mute the microphone,
- reduce background VRC Eye activity,
- switch to privacy mode.

This is useful if someone else walks up to the monitor/headset.

# 17. Privacy Safety

This grew into a substantial category.

- **Sensitive-data guard**
- **Streamer Privacy Mode**
- **Presentation Mode**
- **Guest Mode**
- **Instance-ID redaction**
- **User-ID redaction**
- **Local path redaction**
- **Token/credential redaction**
- **Screenshot privacy scanner**
- **Notification-preview privacy**
- **Clipboard guard**
- **Private diagnostic export**

Example:

```
Copied text appears to contain a private
instance identifier.

[ Copy Redacted ]
[ Copy Original ]
[ Cancel ]
```

# 18. Suspicious Link Protection

Whenever VRC Eye detects or is asked to open an external URL:

- show domain,
- distinguish HTTPS/non-HTTPS,
- warn about suspiciously formatted domains,
- require confirmation for unfamiliar links,
- never automatically execute/download unknown files.

This would apply especially to media/history/social integrations.

# 19. Account Safety

VRC Eye should never become a reason someone's VRChat account becomes less secure.

Features:

- **2FA status reminder where legitimately available**
- Account-security checklist
- Warn if sensitive account actions are enabled
- Never expose credentials in logs
- Secure local storage for VRC Eye secrets
- Session/account separation
- Auto-lock account-changing controls in Guest Mode

VRChat itself recommends unique passwords, password managers and enabling two-factor authentication. [VRChat](https://help.vrchat.com/hc/en-us/articles/31640825601683-Account-Safety-Recommendations?utm_source=chatgpt.com)

# 20. Read-Only Lock

One of the strongest VRC Eye self-protection ideas.

```
READ-ONLY MODE: ON

Monitoring              ✓
Player list             ✓
Safety                  ✓
History                 ✓

Friend actions          ✗
Group actions           ✗
Avatar edits            ✗
World edits             ✗
Other account changes   ✗
```

Ideal for users who only want VRC Eye as a monitor.

# 21. Outbound Kill Switch

Separate from Read-Only Mode.

One button immediately stops VRC Eye from sending:

- API mutations,
- Whispers,
- OSC commands,
- bridge commands,
- integration actions.

Incoming monitoring continues.

Think of it as:

> **Stop VRC Eye from touching anything right now.**

# 22. Mutation Circuit Breaker

Protects the user **from bugs in VRC Eye itself**.

If VRC Eye suddenly attempts an abnormal number of changes:

```
Expected:
1 friend action

Observed:
37 account mutations queued
```

VRC Eye stops the queue automatically:

> **Circuit breaker activated. No further account-changing actions will be sent.**

This becomes particularly important if you eventually add bulk tools.

# 23. API Safety Governor

One central subsystem responsible for:

- rate limiting,
- backoff,
- mutation queues,
- retries,
- duplicate suppression,
- maximum actions/minute,
- automatic halt after repeated errors.

No individual VRC Eye module should independently spam the API.

# 24. Action Ledger

Record every important action **VRC Eye itself performed**:

```
20:31:12  Muted VRChat
20:31:44  Enabled Safe Mode
20:32:17  Sent friend request
20:33:02  Changed world description
```

Very useful for:

> “Did VRC Eye actually do that?”

It should not log passwords/tokens.

# 25. Recoverable Local Deletes

VRC Eye-local information shouldn't immediately vanish.

For:

- notes,
- favorites,
- histories,
- presets,
- layouts,
- rules,

use:

```
Delete
  ↓
Recycle area
  ↓
Permanent delete after retention period
```

with an immediate **Undo**.

# 26. Configuration Checkpoints

Before dangerous settings changes:

```
Checkpoint created:
Before Advanced Safety Changes
```

Then:

> Restore configuration from 8:42 PM.

This should also run before imports, migrations and major upgrades.

# 27. Integration Isolation

If one integration breaks, it shouldn't take everything with it.

For example:

```
Discord integration crashed 4 times.
Discord has been disabled for this session.

Safety Center remains operational.
```

Same idea for:

- VRCX,
- Bridge Mode,
- Twitch,
- media,
- overlay,
- plugins.

# 28. Bridge Quarantine

When an unknown or newly updated client bridge connects:

```
New Bridge Detected

ExampleClient 5.1

Allowed:
✓ Read telemetry

Blocked:
✗ Safety actions
✗ VRC Eye commands
```

The user explicitly approves additional capabilities.

A client update could optionally cause permissions to be reviewed again.

# 29. Bridge Capability Permissions

Rather than:

> Allow client: YES

use:

```
ExampleClient

☑ Player telemetry
☑ Avatar telemetry
☑ Voice activity
☑ Runtime diagnostics

☐ Avatar safety controls
☐ Interaction controls
☐ VRC Eye commands
```

That greatly limits blast radius.

# 30. Consent Expiration

Especially for VRC Eye-to-VRC Eye features.

Sharing permissions could be:

- this action only,
- this session,
- one hour,
- until they leave,
- persistent friend permission.

Useful for:

- diagnostics sharing,
- session status,
- hardware information,
- shared creator testing.

# 31. Activity Anomaly Monitor

We discussed this instead of claiming VRC Eye can magically detect cheaters.

Stock VRC Eye may be able to observe unusual correlations, but it should say:

> **Unusual activity observed**

rather than:

> **CHEATER DETECTED.**

Possible observations:

- extreme/repeated movement anomalies when reliable telemetry exists,
- unusual avatar load behavior,
- repeated client-performance spikes,
- suspicious sequence of errors.

Never automatically accuse/report someone.

### Bridge-enhanced

A compatible client might provide richer movement/avatar/runtime telemetry, making anomaly detection better.

Still:

**Anomaly ≠ cheating.**

# 32. Incident / Report Assistant

When something concerning happens:

```
INCIDENT

Time              8:42 PM
World             Example World
Player            Alice

Nearby events:
8:41:57 avatar changed
8:42:01 audio spike
8:42:03 performance drop
8:42:04 user bookmarked incident
```

Then:

- Save locally
- Add notes
- Include relevant diagnostic timestamps
- Export sanitized report data

No automatic accusation.

# 33. Encounter Safety Memory

Privately remember your own previous interactions:

- encounter count,
- local notes,
- prior incident bookmarks,
- last encountered,
- locally assigned tags.

But avoid constructing automated “danger scores” for other people.

# 34. Authority Identification

The Player List can help the user know who actually has authority.

Potential badges:

- World Creator
- Instance Owner
- Group Moderator/Admin when verifiable
- VRChat Staff when VRChat explicitly identifies them

VRChat's Safety documentation notes that instance moderation actions are available to instance owners and applicable group moderators/admins. [VRChat](https://docs.vrchat.com/docs/VRChat-safety-and-trust-system?utm_source=chatgpt.com)

That can be useful if the user needs help during an incident.

# 35. My Moderation State

Show **your controls toward that user**:

```
Alice

Voice              Muted
Avatar             Hidden
Interactions       Disabled
Chatbox            Allowed
```

This is much safer and more useful than trying to guess whether Alice muted you.

# 36. Safe Rejoin Guard

After a crash:

```
Previous session ended during:

⚠ VRAM critical
⚠ 22 avatars loading
⚠ repeated Unity errors

[ Launch Home ]
[ Rejoin Anyway ]
```

Don't automatically throw the user back into the exact environment that may have preceded the failure.

# 37. Crash Recovery

Detect unexpected VRChat termination and preserve:

- current world,
- session timeline,
- recent players,
- resource history,
- logs,
- VRC Eye state.

Offer:

- restart VRChat,
- launch Home,
- previous-world rejoin where appropriate,
- open diagnostics.

# 38. Black Box Recorder

One of the strongest safety features we discussed.

Keep a rolling disk-backed buffer of the last several minutes:

- RAM,
- VRAM,
- CPU,
- GPU,
- temperatures,
- disk activity,
- network state,
- tracking,
- SteamVR state,
- avatar/player events,
- Unity errors,
- VRC Eye events.

If the entire PC crashes, the data immediately before the crash can survive.

On next boot:

```
Previous session ended unexpectedly.

[ Analyze Black Box ]
```

# 39. System-Crash Correlation

On Windows, VRC Eye can correlate its Black Box with system evidence after reboot. Microsoft documents Event ID 41 for an unexpected shutdown and Event 1001 when Windows recorded a bugcheck/dump; importantly, Event 41 alone does **not** identify the cause. [Microsoft Learn](https://learn.microsoft.com/en-us/troubleshoot/windows-server/performance/troubleshoot-unexpected-reboots-system-event-logs?utm_source=chatgpt.com)

So VRC Eye might correctly say:

> Severe memory pressure occurred 12 seconds before the unexpected shutdown.

but not:

> VRChat definitely caused your PC to crash.

# 40. Diagnostics Replay

A flight-recorder timeline:

```
22:14:02 World joined
22:14:11 18 avatars began loading
22:14:17 VRAM 72 → 91%
22:14:19 Tracker disconnected
22:14:24 network jitter increased
22:14:31 VRChat stopped responding
22:14:38 process exited
```

Graphs underneath for RAM/VRAM/CPU/etc.

This could become one of VRC Eye's flagship features.

# 41. Safety Checkpoints

Periodically store tiny snapshots while everything is healthy:

- current world,
- player count,
- RAM,
- VRAM,
- tracker state,
- audio state,
- network state.

Then after a failure, compare the last good state with the final state.

# 42. Error Center

Translate cryptic logs into useful categories:

```
Avatar Load Failure
OSC Connection Failure
Graphics Device Error
Media Failure
API Failure
SteamVR Failure
Unknown Unity Error
```

Include:

- timestamp,
- severity,
- subsystem,
- likely consequences,
- relevant troubleshooting action.

Never turn uncertain log text into false certainty.

# 43. Diagnostic Bundle Generator

Generate a sanitized support package containing things such as:

- VRC Eye version,
- OS,
- VRChat version,
- relevant logs,
- crash timeline,
- selected hardware information,
- Black Box excerpt,
- feature-health status.

Automatically redact:

- tokens,
- private IDs where unnecessary,
- personal filesystem paths,
- private instance information.

# 44. Safe Startup Mode

If VRC Eye itself crashes repeatedly:

```
VRC Eye detected repeated startup failures.

Starting in Safe Mode:
✓ Safety Center
✓ Logs
✓ Resource Guard

Disabled:
✗ integrations
✗ plugins
✗ overlays
✗ experimental modules
```

Then modules can be re-enabled one at a time.

# 45. VRC Eye Self-Watchdog

Monitor VRC Eye itself for:

- runaway memory,
- excessive CPU,
- stuck event queue,
- repeated exceptions,
- stalled log parser,
- broken integrations.

The safety application shouldn't become the thing destabilizing the PC.

# 46. Separate Safety Watchdog

Potentially a tiny independent helper responsible only for:

- detecting that VRC Eye died,
- preserving the crash marker,
- maintaining minimal logging,
- offering recovery.

Keep it very small so it doesn't become another failure source.

# 47. Feature Health Matrix

A single quick status page:

```
SAFETY HEALTH

VRChat Logs          ✓
Resource Guard       ✓
SteamVR              ✓
Tracking             ✓
OSC                   ✓
Audio Guard          ✓
Black Box            ✓
Bridge               Not connected
```

This makes it obvious when a safety feature isn't actually operating.

# 48. Rapid Visual Change Protection

An experimental external capture-based system could look for extreme rapid screen brightness changes.

If detected:

```
⚠ EXTREME VISUAL CHANGES DETECTED

[ Activate Safe Mode ]
[ Hide VRChat Window ]
```

This should be described as an **experimental comfort/safety aid**, not medical protection.

# 49. Wellness / Long-Session Safety

These are softer safety features, but they're still part of protecting the player:

- hydration reminder,
- breaks,
- bedtime,
- meals/snacks,
- bathroom,
- eye rest,
- headset-off break,
- posture,
- gentle movement/stretch,
- standing duration,
- room-safety check,
- temperature/comfort,
- motion-discomfort mode,
- hearing protection,
- low battery as a break opportunity,
- session-duration display,
- last-break timer,
- “Doing okay?” check-in,
- quiet hours,
- session summary,
- wellness profiles,
- “I'm taking a break,”
- snooze/dismiss,
- consolidated reminders.

No guilt/scoring mechanics.

# 50. Accessibility as Safety

Accessibility overlaps heavily with safety.

- high contrast,
- scalable alerts,
- reduced motion,
- persistent important warnings,
- visual equivalent of audio alarms,
- audio equivalent of visual alarms,
- remappable emergency controls,
- large-control mode,
- no color-only warnings,
- comfortable VR-overlay distance/size.

An emergency warning isn't useful if the player can't perceive it.

# 51. Client Bridge Safety Supervisor

This is probably how I would package all of the client-enhanced safety functionality.

```
CLIENT SAFETY BRIDGE
────────────────────────

ExampleClient          Connected
Protocol               1.3
Telemetry              ✓
Avatar Safety          ✓
Voice State            ✓
Interaction State      ✓
Runtime Telemetry      ✓

Permission Level:
Telemetry + Local Safety
```

When disconnected:

```
Bridge disconnected.

VRC Eye has returned to
standard safety monitoring.
```

No core safety feature should stop working just because the custom client disappears.

# 52. Bridge Safety Guard

This is arguably the most useful client-assisted feature.

Example sequence:

```
Alice's avatar begins loading
             ↓
Bridge identifies avatar load
             ↓
VRAM rapidly increases
             ↓
frame performance deteriorates
             ↓
VRC Eye correlates events
             ↓
⚠ High resource impact observed

[ Reduce Alice's Avatar ]
[ Hide Locally ]
[ Safe Mode ]
[ Ignore ]
```

This gives VRC Eye something much closer to the **advanced safety feeling** older client users liked, while the actual client-specific capability is provided by their already-running bridge.

# 53. Bridge Voice Attribution

Without a bridge:

> Loud VRChat audio detected.

With a compatible bridge:

```
🔊 Alice
   Bob
   Charlie
```

Then VRC Eye can offer the user's local safety controls for that player if supported.

Still avoid:

> Alice is intentionally blasting your ears.

VRC Eye knows activity, not intent.

# 54. Bridge Selected-Player Safety Panel

If the player selects someone in VRChat:

```
VRChat selection
      ↓
Bridge
      ↓
VRC Eye automatically opens Alice
```

VRC Eye can immediately expose:

```
Alice

Voice             Active
Avatar             Loaded
Performance        Very Poor
Distance           3.2m

LOCAL SAFETY
[ Mute ]
[ Hide ]
[ Reduce Effects ]
[ Pause Interaction ]
```

That would make emergency per-user actions dramatically faster.

# 55. Bridge Runtime Safety

A compatible client might expose more precise runtime conditions such as:

- avatar initialization state,
- local Unity errors,
- unusual renderer behavior,
- scene/runtime health,
- richer performance telemetry.

VRC Eye could combine that with external CPU/GPU/RAM monitoring.

The bridge should provide **specific structured telemetry**, not unrestricted “execute any Unity function” access.

# 56. Things VRC Eye Should Deliberately NOT Do

For the Safety Suite, I’d actually document these exclusions because they increase user trust.

VRC Eye should not:

- automatically accuse users of cheating,
- automatically report users based on heuristics,
- claim exact remote-avatar VRAM without trustworthy data,
- try to determine who muted you from unreliable clues,
- bypass another user's interaction/privacy controls,
- affect another person's client,
- bypass VRChat permissions,
- attempt anti-cheat evasion,
- hide custom-client usage,
- extract protected avatar/world assets in the name of “safety,”
- silently perform destructive account actions.

VRChat's current Safety System is explicitly designed to give the **local user control over what they see/hear**, which is exactly the model I'd keep for VRC Eye. [VRChat](https://docs.vrchat.com/docs/vrchat-safety-and-trust-system?utm_source=chatgpt.com)

---

## How I'd organize the actual Safety Center

Rather than presenting 50 switches at once:

```
VRC EYE SAFETY CENTER
══════════════════════════

Overall Status          PROTECTED

Emergency
  Safe Mode             Ready
  Escape Panel          Ready

Session
  Safe Arrival          On
  Avatar Guard          On
  Crowd Guard           On

System
  Resource Guard        On
  Thermal Guard         On
  Disk Guard            On

VR
  Tracking Guard        On
  Playspace             Healthy
  Audio Guard           On

Privacy
  Privacy Guard         On
  Sensitive Data        Protected

Recovery
  Black Box             Recording
  Crash Recovery        Ready

VRC Eye
  Read-Only Lock        Off
  Circuit Breaker       Armed
  API Governor          Active

Client Bridge
  Not connected
  Standard protection active
```

Then **Casual Mode** could simply expose:

> **Standard / High / Maximum / Custom**

while **Advanced Mode** exposes all the thresholds and individual modules.

And if a compatible client appears:

```
Enhanced Safety Available

✓ Voice attribution
✓ Avatar telemetry
✓ Per-player local safety
✓ Selected-user synchronization

[ Enable Enhanced Safety ]
```

That preserves the principle you've been building toward throughout VRC Eye:

> **Stock users get a very strong safety system.**\
> **Client users get more precise telemetry and faster local controls.**\
> **The core Safety Center never requires a modified client.**

That distinction is important because it keeps VRC Eye useful to everyone while still giving Bridge users some genuinely valuable extra protection.