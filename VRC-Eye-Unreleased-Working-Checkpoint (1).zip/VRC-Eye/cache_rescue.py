"""Cache-first avatar rescue, with optional exact-ID file metadata matching."""

from text_viewport import window_body

from avatar_links import parse_avatar_reference
from download_sizes import default_selections


def show_rescue_dialog(app, *, event=None, avatar_id=""):
    from tkinter import messagebox
    from cache_dialog import show_cache_dialog
    from online_dialog import lookup_online, show_connection_dialog
    from vrca_dialog import show_vrca_dialog
    tk, ttk = app.tk, app.ttk
    window = tk.Toplevel(app.root)
    window.title("VRC Eye · Rescue cached avatar")
    window.geometry("850x720")
    window.minsize(820, 690)
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Rescue cached avatar", font='EyeTitleFont').pack(anchor="w")
    if event is not None:
        ttk.Label(frame, text=f"Selected log entry: {event.player} → {event.avatar}",
                  style="Accent.TLabel", wraplength=770).pack(anchor="w", pady=(8, 0))
    ttk.Label(frame, text=("Preserve a local bundle for you or a friend. Open Browse local cache to inspect and save files "
        "already on this PC; no sign-in, VRCX, or JSON is required. Close VRChat before copying a locked file, then rescan.\n\n"
        "Sharing an instance does not guarantee that the full avatar is cached. Player and avatar names do not identify "
        "cache files. Unidentified bundles stay .bundle until their identity is established."),
        style="Muted.TLabel", wraplength=770).pack(anchor="w", pady=(12, 14))
    ttk.Button(frame, text="Browse local cache…", style="Accent.TButton",
               command=lambda: show_cache_dialog(app) if window.winfo_exists() else None).pack(anchor="w", pady=(0, 18))
    ttk.Label(frame, text="Optional: match a specific avatar", font='EyeSectionFont').pack(anchor="w")
    ttk.Label(frame, text=("Enter its complete avatar ID or official page link. Matching reuses loaded file metadata or "
        "asks VRChat for metadata available to your account. Multiple builds require your selection. "
        "The selected log entry remains your chosen association; its name is not used as a file identifier."),
        style="Muted.TLabel", wraplength=770).pack(anchor="w", pady=(6, 8))
    reference = tk.StringVar(value=avatar_id)
    ttk.Entry(frame, textvariable=reference).pack(fill="x", pady=(0, 10))
    status = tk.StringVar(value="An intact cache copy can survive a damaged source project, but it cannot recreate the complete original Unity project.")
    generation, revision = app.data_generation, [0]

    def edited(*_):
        revision[0] += 1
        status.set("Avatar ID changed. Choose Find avatar in cache to use the new ID.")

    reference.trace_add("write", edited)

    def current(request):
        return window.winfo_exists() and request == revision[0] and generation == app.data_generation

    def file_details(ref, request):
        if current(request):
            show_vrca_dialog(app, ref, prefer_local=True)

    def open_match(ref, request):
        if not current(request):
            raise ValueError("The avatar ID or log session changed, or the rescue window closed. Reopen the rescue action.")
        export = app.asset_exports.get(ref)
        if export is None or export.avatar_id != ref:
            raise ValueError("Matching file metadata is unavailable. Browse local cache, or use the file-details dialog to import metadata.")
        choice = default_selections(export, app.asset_selections.get(ref)).get("pc")
        if choice:
            status.set("Searching the cache for this PC file ID and version. A URL match does not prove that the bundle is usable.")
            show_cache_dialog(app, choice.url, ref)
        else:
            status.set("Choose the matching platform/build in the file-details dialog, then click Browse cache.")
            file_details(ref, request)

    def lookup(ref, request):
        if not current(request):
            status.set("The avatar ID or log session changed. Reopen the rescue action.")
            return
        if ref in app.asset_exports:
            open_match(ref, request)
            return
        if not app.api or not app.api.authenticated:
            show_connection_dialog(app, lambda: lookup(ref, request))
            return
        client = app.api
        expected_export = app.asset_exports.get(ref)

        def received(result):
            if not current(request):
                raise ValueError("The avatar ID or session changed, or the rescue window closed. Start the lookup again.")
            if result.metadata.avatar_id != ref:
                raise ValueError("The returned metadata belongs to a different avatar ID.")
            if app.asset_exports.get(ref) is not expected_export:
                raise ValueError("Loaded file metadata changed during this lookup. Choose Find avatar in cache again.")
            if result.export is None:
                raise ValueError("VRChat supplied no file URLs for this account. Browse local cache remains available; an avatar name cannot select the correct file.")
            app.remember_search_avatar(result, client=client, generation=generation)
            open_match(ref, request)

        lookup_online(app, "avatar", ref, received, parent=window,
                      on_fallback=lambda: file_details(ref, request))

    def find():
        try:
            ref = parse_avatar_reference(reference.get())
            lookup(ref, revision[0])
        except ValueError as error:
            messagebox.showerror("Could not match this avatar", str(error), parent=window)

    buttons = ttk.Frame(frame)
    buttons.pack(fill="x", pady=(0, 10))
    ttk.Button(buttons, text="Find avatar in cache…", command=find).pack(side="left")
    ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right")
    ttk.Label(frame, textvariable=status, style="Muted.TLabel", wraplength=770).pack(anchor="w", pady=(0, 12))
    ttk.Label(frame, text=("Save selected preserves the cached bytes unchanged, including any encryption. "
        "Decrypt with key is a separate, optional step for supported files and requires their matching key. "
        "Neither action can restore missing or damaged bytes. Originals are kept and destination files are never overwritten."),
        style="Muted.TLabel", wraplength=770).pack(anchor="w")
