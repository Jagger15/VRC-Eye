"""Local-only bridge transports: private Unix socket or Windows named pipe.

Both carry a four-byte unsigned big-endian length followed by UTF-8 JSON.
Windows writes the whole frame in one message-mode pipe write. Never use pickle.
"""
import os
from pathlib import Path
import re
import socket
import stat
import struct
import tempfile
import threading
import time

from bridge_protocol import BridgeError, MAX_MESSAGE, decode, encode, fresh_id


def pipe_address(value):
    if not isinstance(value,str) or not re.fullmatch(r"\\\\\.\\pipe\\VRC-Eye-[a-f0-9]{32}",value):
        raise BridgeError("Only local VRC Eye named-pipe endpoints are supported.")
    return value


def unix_address(value):
    if not isinstance(value,str) or len(os.fsencode(value))>100 or not Path(value).is_absolute() or Path(value).name!="bridge.sock":
        raise BridgeError("Invalid local bridge socket endpoint.")
    return value


def same_unix_user(sock):
    if not hasattr(socket,"SO_PEERCRED") or not hasattr(os,"getuid"):
        raise BridgeError("This Unix transport requires Linux peer credentials.")
    _,uid,_=struct.unpack("3i",sock.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize("3i")))
    if uid!=os.getuid():raise BridgeError("Bridge peers must belong to the same OS user.")


class SocketStream:
    def __init__(self,sock):
        self.sock=sock;self.sock.settimeout(.2);self.buffer=bytearray();self.partial_since=None;self.closed=False
    def send(self,document):
        if self.closed:raise BridgeError("Bridge stream is closed.")
        self.sock.sendall(encode(document))
    def receive(self,timeout=.2):
        deadline=time.monotonic()+timeout
        while True:
            if len(self.buffer)>=4:
                size=struct.unpack("!I",self.buffer[:4])[0]
                if not 1<=size<=MAX_MESSAGE:raise BridgeError("Bridge frame exceeds 64 KiB.")
                if len(self.buffer)>=size+4:
                    raw=bytes(self.buffer[4:size+4]);del self.buffer[:size+4]
                    self.partial_since=time.monotonic() if self.buffer else None
                    return decode(raw)
            if self.partial_since is not None and time.monotonic()-self.partial_since>2:
                raise BridgeError("Incomplete bridge frame timed out.")
            remaining=deadline-time.monotonic()
            if remaining<=0:return None
            import select
            ready,_,_=select.select([self.sock],[],[],remaining)
            if not ready:return None
            block=self.sock.recv(16384)
            if not block:raise EOFError("Bridge disconnected.")
            if not self.buffer:self.partial_since=time.monotonic()
            self.buffer.extend(block)
            if len(self.buffer)>MAX_MESSAGE+4+16384:raise BridgeError("Bridge receive buffer exceeded.")
    def close(self):
        if self.closed:return
        self.closed=True
        try:self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:pass
        self.sock.close()


class UnixListener:
    transport="unix"
    def __init__(self):
        self.closed=False;self.directory=Path(tempfile.mkdtemp(prefix="vrceye-bridge-"));self.sock=None
        try:
            os.chmod(self.directory,0o700);self.endpoint=unix_address(str(self.directory/"bridge.sock"))
            self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.bind(self.endpoint)
            os.chmod(self.endpoint,0o600);self.sock.listen(1);self.sock.settimeout(.2)
        except Exception:self.close();raise
    def accept(self):
        try:sock,_=self.sock.accept()
        except socket.timeout:return None
        try:same_unix_user(sock);return SocketStream(sock)
        except Exception:sock.close();raise
    def close(self):
        self.closed=True
        if self.sock:self.sock.close()
        try:(self.directory/"bridge.sock").unlink()
        except FileNotFoundError:pass
        try:self.directory.rmdir()
        except OSError:pass


class WindowsSecurity:
    """Explicit DACL for the current token's user SID; not Everyone/default DACL."""
    def __init__(self):
        import ctypes as ct
        from ctypes import wintypes as wt
        self.ct=ct;self.kernel=ct.WinDLL("kernel32",use_last_error=True);self.advapi=ct.WinDLL("advapi32",use_last_error=True)
        class SecurityAttributes(ct.Structure):
            _fields_=[("length",wt.DWORD),("descriptor",wt.LPVOID),("inherit",wt.BOOL)]
        self.kernel.GetCurrentProcess.restype=wt.HANDLE
        self.kernel.CloseHandle.argtypes=[wt.HANDLE];self.kernel.CloseHandle.restype=wt.BOOL
        self.kernel.LocalFree.argtypes=[wt.HLOCAL];self.kernel.LocalFree.restype=wt.HLOCAL
        self.advapi.OpenProcessToken.argtypes=[wt.HANDLE,wt.DWORD,ct.POINTER(wt.HANDLE)];self.advapi.OpenProcessToken.restype=wt.BOOL
        self.advapi.GetTokenInformation.argtypes=[wt.HANDLE,ct.c_int,wt.LPVOID,wt.DWORD,ct.POINTER(wt.DWORD)];self.advapi.GetTokenInformation.restype=wt.BOOL
        self.advapi.ConvertSidToStringSidW.argtypes=[wt.LPVOID,ct.POINTER(wt.LPWSTR)];self.advapi.ConvertSidToStringSidW.restype=wt.BOOL
        self.advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[wt.LPCWSTR,wt.DWORD,ct.POINTER(wt.LPVOID),ct.POINTER(wt.DWORD)];self.advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype=wt.BOOL
        token=wt.HANDLE();sid_text=wt.LPWSTR();self.descriptor=wt.LPVOID()
        try:
            if not self.advapi.OpenProcessToken(self.kernel.GetCurrentProcess(),8,ct.byref(token)):raise BridgeError("Cannot obtain local bridge user identity.")
            size=wt.DWORD();self.advapi.GetTokenInformation(token,1,None,0,ct.byref(size))
            if not 1<=size.value<=65536:raise BridgeError("Cannot read local bridge user identity.")
            buffer=ct.create_string_buffer(size.value)
            if not self.advapi.GetTokenInformation(token,1,buffer,size,ct.byref(size)):raise BridgeError("Cannot read local bridge user identity.")
            sid=ct.cast(buffer,ct.POINTER(wt.LPVOID))[0]
            if not self.advapi.ConvertSidToStringSidW(sid,ct.byref(sid_text)):raise BridgeError("Cannot encode local bridge identity.")
            sddl="D:P(A;;GA;;;"+sid_text.value+")"
            if not self.advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl,1,ct.byref(self.descriptor),None):raise BridgeError("Cannot restrict bridge pipe permissions.")
            self.attributes=SecurityAttributes(ct.sizeof(SecurityAttributes),self.descriptor,False);self.address=ct.addressof(self.attributes)
        finally:
            if token:self.kernel.CloseHandle(token)
            if sid_text:self.kernel.LocalFree(ct.cast(sid_text,wt.HLOCAL))
    def close(self):
        if self.descriptor:self.kernel.LocalFree(self.descriptor);self.descriptor=None


class PipeStream:
    def __init__(self,connection):self.connection=connection;self.closed=False
    def send(self,document):self.connection.send_bytes(encode(document))
    def receive(self,timeout=.2):
        if not self.connection.poll(timeout):return None
        raw=self.connection.recv_bytes(MAX_MESSAGE+4)
        if len(raw)<5 or struct.unpack("!I",raw[:4])[0]!=len(raw)-4:raise BridgeError("Invalid named-pipe bridge frame.")
        return decode(raw[4:])
    def close(self):
        if not self.closed:self.closed=True;self.connection.close()


class WindowsListener:
    transport="pipe"
    def __init__(self,*,api=None,security=None,connection_factory=None):
        if api is None:
            import _winapi as api
        if connection_factory is None:
            from multiprocessing.connection import PipeConnection
            connection_factory=PipeConnection
        self.api=api;self.factory=connection_factory;self.security=security or WindowsSecurity()
        self.endpoint=pipe_address("\\\\.\\pipe\\VRC-Eye-"+fresh_id().replace("-",""))
        self.stopped=threading.Event();self.handle=None;self.overlap=None;self.lock=threading.RLock()
        try:self.handle=self._new_handle()
        except Exception:self.security.close();raise
    def _new_handle(self):
        # Explicit local-only, first-instance, one peer, overlapped message-mode pipe.
        return self.api.CreateNamedPipe(self.endpoint,0x00000003|0x40000000|0x00080000,0x00000004|0x00000002|0x00000008,1,MAX_MESSAGE+4,MAX_MESSAGE+4,0,self.security.address)
    def accept(self):
        with self.lock:
            if self.stopped.is_set():raise EOFError("Bridge listener stopped.")
            if self.handle is None:self.handle=self._new_handle()
            handle=self.handle
            if self.overlap is None:self.overlap=self.api.ConnectNamedPipe(handle,overlapped=True)
            overlap=self.overlap
        waited=self.api.WaitForMultipleObjects([overlap.event],False,200)
        if waited==258:return None
        if waited!=0:raise BridgeError("Named-pipe connection wait failed.")
        _,error=overlap.GetOverlappedResult(True)
        if error:raise BridgeError("Named-pipe connection failed.")
        with self.lock:
            if self.stopped.is_set():raise EOFError("Bridge listener stopped.")
            self.handle=None;self.overlap=None
        try:return PipeStream(self.factory(handle))
        except Exception:self.api.CloseHandle(handle);raise
    def close(self):
        with self.lock:
            if self.stopped.is_set():return
            self.stopped.set()
            if self.overlap is not None:
                try:self.overlap.cancel();self.overlap.GetOverlappedResult(True)
                except OSError:pass
                self.overlap=None
            if self.handle is not None:
                self.api.CloseHandle(self.handle);self.handle=None
            self.security.close()


def listener():
    if os.name=="nt":return WindowsListener()
    if os.name=="posix" and hasattr(socket,"SO_PEERCRED"):return UnixListener()
    raise BridgeError("The local bridge currently supports Windows named pipes and Linux Unix sockets.")


def connect(transport,endpoint):
    if transport=="unix" and os.name=="posix":
        endpoint=unix_address(endpoint);parent=Path(endpoint).parent;info=parent.lstat();target=Path(endpoint).lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o077 or not stat.S_ISSOCK(target.st_mode) or target.st_uid!=os.getuid() or target.st_mode&0o077:
            raise BridgeError("The bridge socket must be private to this OS user.")
        sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(2.)
        try:sock.connect(endpoint);same_unix_user(sock);return SocketStream(sock)
        except Exception:sock.close();raise
    if transport=="pipe" and os.name=="nt":
        import _winapi
        from multiprocessing.connection import PipeConnection
        endpoint=pipe_address(endpoint);_winapi.WaitNamedPipe(endpoint,2000)
        handle=_winapi.CreateFile(endpoint,0x80000000|0x40000000,0,0,3,0x40000000,0)
        try:_winapi.SetNamedPipeHandleState(handle,2,None,None);return PipeStream(PipeConnection(handle))
        except Exception:_winapi.CloseHandle(handle);raise
    raise BridgeError("This bridge transport is not supported on this OS.")
