"""Capture a consistent DB + WAL in private scratch without opening the source."""
from pathlib import Path
import os
import shutil
import sqlite3
import tempfile
import time
from creator_projects import assert_no_links,local_path
from vrcx_sources import source,stopped

LIMIT=1024*1024*1024


def capture(path,destination,*,stop=None):
    target=assert_no_links(local_path(destination));assert_no_links(target.parent)
    if target.exists():raise ValueError('Choose a new snapshot filename.')
    original=source(path,database=True);created=None;success=False
    with tempfile.TemporaryDirectory(prefix='vrceye-snapshot-') as folder:
        clone=Path(folder)/'source.sqlite3'
        copied=False
        for _ in range(4):
            stopped(stop);evidence=source(original.path,database=True)
            for suffix,ident in evidence.files:
                out=Path(str(clone)+suffix)
                if out.exists():out.unlink()
                if ident[1] is None:continue
                if ident[1][2]>LIMIT:raise ValueError('A database or WAL exceeds the 1 GiB snapshot limit.')
                fd=os.open(evidence.path+suffix,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
                with os.fdopen(fd,'rb') as incoming,out.open('xb') as outgoing:
                    info=os.fstat(incoming.fileno())
                    if (info.st_dev,info.st_ino)!=ident[1][:2]:raise ValueError('The selected database identity changed.')
                    total=0
                    while True:
                        stopped(stop);block=incoming.read(1024*1024)
                        if not block:break
                        total+=len(block)
                        if total>LIMIT:raise ValueError('Snapshot exceeds its byte limit.')
                        outgoing.write(block)
            try:evidence.check();copied=True;break
            except ValueError:continue
        if not copied:raise ValueError('The source kept changing during capture. Pause VRCX activity or close it, then try again.')
        wal=Path(str(clone)+'-wal')
        if wal.exists() and wal.stat().st_size:
            with wal.open('rb') as stream:header=stream.read(32)
            if len(header)!=32 or header[:4] not in (b'7\x7f\x06\x82',b'7\x7f\x06\x83'):raise ValueError('The selected WAL header is invalid.')
        src=dst=None
        try:
            # Recovery only touches our private copy. No source SHM is opened,
            # created, mapped or copied. SQLite rebuilds its own clone's index.
            src=sqlite3.connect(clone);src.execute('PRAGMA trusted_schema=OFF');deadline=time.monotonic()+30
            src.set_progress_handler(lambda:int(time.monotonic()>deadline or stop is not None and stop.is_set()),1000)
            if src.execute('PRAGMA quick_check').fetchone()[0]!='ok':raise ValueError('Snapshot integrity check failed.')
            with target.open('xb') as stream:
                info=os.fstat(stream.fileno());created=(info.st_dev,info.st_ino)
            os.chmod(target,0o600);dst=sqlite3.connect(target)
            def progress(status,remaining,total):
                stopped(stop)
                if time.monotonic()>deadline:raise ValueError('Snapshot copy exceeded its time budget.')
            src.backup(dst,pages=256,progress=progress,sleep=.01);dst.close();dst=None
            stopped(stop)
            success=True;return str(target)
        except (sqlite3.Error,OSError):
            raise ValueError('The captured database could not be verified or saved.') from None
        finally:
            if dst:dst.close()
            if src:src.close()
            if not success and created and target.exists():
                info=target.lstat()
                if (info.st_dev,info.st_ino)==created:target.unlink()


def capture_checked(path,destination,*,stop=None):
    return capture(path,destination,stop=stop)


def capture_group(paths, directory, *, stop=None, check=lambda: None, attempts=4):
    """Capture stores during one unchanged observation window.

    This is not a distributed SQLite transaction: no source is locked or
    modified. Every DB and WAL must retain its identity/size/timestamps from
    before the first copy until after the last copy. A busy writer causes a
    bounded whole-group retry, never a bundle of mixed successful attempts.
    Callers supply validated single-component output names and a private dir.
    """
    root = assert_no_links(local_path(directory))
    if not paths or len(paths) > 104 or not 1 <= attempts <= 4:
        raise ValueError('Invalid profile snapshot group.')
    for name in paths:
        if not isinstance(name, str) or Path(name).name != name or name in ('.', '..') or '\\' in name:
            raise ValueError('Invalid profile snapshot name.')
        if (root / name).exists():
            raise ValueError('Snapshot destination is already occupied.')
    for _ in range(attempts):
        stopped(stop); check()
        evidence = [source(path, database=True) for path in paths.values()]
        # The retry directory is owned scratch; a failed attempt never leaks
        # an earlier member into the next attempt or the published archive.
        with tempfile.TemporaryDirectory(prefix='group-', dir=root) as temporary:
            stage = Path(temporary)
            for name, path in paths.items():
                stopped(stop); check()
                capture_checked(path, stage / name, stop=stop)
            stopped(stop); check()
            try:
                for item in evidence: item.check()
            except ValueError:
                continue
            for name in paths:
                shutil.move(str(stage / name), str(root / name))
            return {'mode': 'unchanged-source-window', 'stores': len(paths),
                    'attempts': _ + 1, 'includes_wal': True}
    raise ValueError('Profile stores kept changing together. Pause recording and try the backup again.')
