"""Everyday service workflows embedded in the existing Accounts and Social tabs."""
import json
import re
from companion_ui import Page, Table, line, button, entry, choice, note
from account_workspace_ui import submit_review
import native_api as api

VIEWS={
 'profile':{'My profile':'profile','Profile themes':'profile-themes'},
 'worlds':{'My worlds':'worlds','Selected world':'world'},
 'creator':{'Owned avatar image':'avatar','Owned avatar gallery':'avatar-gallery'},
 'messages':{'Invite messages':'message','Invite responses':'response','Request messages':'request','Request responses':'requestResponse'},
 'inbox':{'NotificationV2 inbox':'notifications-v2'},
 'media':{'Gallery':'gallery','Account icons':'icons','Stickers':'stickers','Emoji':'emoji','Prints':'prints'},
 'inventory':{'My inventory':'inventory','Archived inventory':'inventory-archived','Global cosmetic catalog':'inventory-global','Selected item':'inventory-item','Template details':'inventory-template','My profile (redeem reward)':'profile'},
 'groups':{'Group details':'group','Members':'group-members','Roles':'group-roles','Galleries':'group-galleries','Requests':'group-requests','Invites':'group-invites',
   'Bans':'group-bans','Posts':'group-posts','Calendar':'group-calendar','Instances':'group-instances','Audit log':'group-audit',
   'Gallery (group ID / gallery ID)':'group-gallery','Pending gallery images':'group-gallery-pending','Transfer eligibility (group ID / user ID)':'group-transfer-check','My profile (create group)':'profile'}}
ACTION_LABELS={k:k.replace('-',' ').capitalize() for k in api.ACTIONS}
ACTION_LABELS.update({'profile-edit':'Save biography / appearance','notification2-see':'Mark read','notification2-hide':'Hide notification',
 'notification2-respond':'Respond','saved-message-edit':'Save this message slot','inventory-consume':'Consume selected bundle',
 'reward-redeem':'Redeem reward code','world-publish':'Publish selected world','world-unpublish':'Unpublish selected world',
 'media-delete':'Delete selected file','print-delete':'Delete selected print','inventory-unequip':'Unequip selected item',
 'group-role-delete':'Delete selected role','group-gallery-create':'Create gallery','group-gallery-edit':'Save selected gallery','group-gallery-delete':'Delete selected gallery'})


def fields_for(action):
    if action=='profile-edit':return api.PROFILE
    if action=='saved-message-edit':return {'message':2000}
    if action=='world-edit':return api.WORLD
    if action in ('group-role-create','group-role-edit'):return api.ROLE
    if action in ('group-gallery-create','group-gallery-edit'):return api.GALLERY
    if action in ('group-role-add','group-role-remove'):return {'roleId':120}
    if action in ('group-post-create','group-post-edit'):return api.POST
    if action in ('group-event-create','group-event-edit'):return {k:v for k,v in api.EVENT.items() if action.endswith('create') or k!='sendCreationNotification'}
    if action=='group-settings':return api.GROUP
    if action=='group-create':return dict({k:api.GROUP[k] for k in ('name','shortCode','description','joinState','bannerId','iconId')},privacy=('public','default'),roleTemplate=('default','managedFree','managedInvite','managedRequest'))
    if action=='group-represent':return {'isRepresenting':bool}
    if action=='group-event-follow':return {'isFollowing':bool}
    if action=='reward-redeem':return {'code':200}
    if action=='inventory-equip':return {'equipSlot':api.EQUIP_SLOTS}
    if action in ('profile-theme-create','profile-theme-edit'):return api.THEME
    if action=='group-instance-create':return api.GROUP_INSTANCE
    if action=='group-gallery-add-image':return {'fileId':120}
    if action=='group-gallery-order':return {'ids':'strings'}
    return {}


class ServicePanel(Page):
    def __init__(self,owner,parent,area):
        self.owner=owner;self.area=area;self.image_windows=[]
        super().__init__(owner.shell,parent,{'profile':'Biography and appearance','worlds':'My worlds','groups':'Groups',
            'media':'My VRChat media','inventory':'Inventory','messages':'Saved invitation messages','inbox':'NotificationV2','creator':'Owned avatar media'}[area])
        self.view=self.tk.StringVar(value=next(iter(VIEWS[area])));self.subject=self.tk.StringVar();self.target=self.tk.StringVar()
        self.action=self.tk.StringVar();self.response=self.tk.StringVar();self.result=None;self.group_result=None;self.offset=0;self.controls={}
        self.detail=self.tk.StringVar(value='Load explicitly. Selecting a record only fills the local form.')
        self.item_type=self.tk.StringVar();self.equip_slot=self.tk.StringVar();self.item_tag=self.tk.StringVar();self.seen=self.tk.StringVar(value='Any')
        self.item_flags=self.tk.StringVar();self.item_not_flags=self.tk.StringVar();self.item_order=self.tk.StringVar(value='descending')
        row=line(self);choice(self,row,self.view,tuple(VIEWS[area]),self.reset,34)
        if area in ('groups','worlds','creator','inventory'):
            self.ttk.Label(row,text='ID').pack(side='left');entry(self,row,self.subject,50)
        if area=='inventory':
            row=line(self)
            self.ttk.Label(row,text='Item type').pack(side='left');choice(self,row,self.item_type,('',)+api.INVENTORY_TYPES,width=18)
            self.ttk.Label(row,text='Tag').pack(side='left');entry(self,row,self.item_tag,18)
            self.ttk.Label(row,text='Equipped slot').pack(side='left');choice(self,row,self.equip_slot,('',)+api.EQUIP_SLOTS,width=18)
            choice(self,row,self.seen,('Any','Seen','Unseen'),width=10)
            row=line(self);self.ttk.Label(row,text='Include flags').pack(side='left');entry(self,row,self.item_flags,22)
            self.ttk.Label(row,text='Exclude flags').pack(side='left');entry(self,row,self.item_not_flags,22)
            choice(self,row,self.item_order,('descending','ascending'),width=14)
            for var in (self.item_type,self.item_tag,self.equip_slot,self.seen,self.item_flags,self.item_not_flags,self.item_order):var.trace_add('write',lambda *_:self.reset())
        row=line(self);button(self,row,'Load / refresh',lambda:self.load(0));button(self,row,'Previous',lambda:self.load(max(0,self.offset-100)));button(self,row,'Next',self.next)
        if area=='groups':
            button(self,row,'Refresh group permissions',self.load_group)
            button(self,row,'Load complete gallery for ordering',lambda:self.load(0,complete_gallery=True))
        if area=='worlds':button(self,row,'Inspect selected world',self.inspect_world)
        self.table=Table(self,parent,(('name','Name / title',230),('type','Type / state',170),('id','ID',360),('date','Reported time',170)),height=7,select=self.selection)
        self.ttk.Label(parent,textvariable=self.detail,wraplength=970).pack(anchor='w',pady=5)
        row=line(self);self.actions_box=choice(self,row,self.action,(),self.build_form,38)
        self.ttk.Label(row,text='Target ID').pack(side='left');entry(self,row,self.target,48)
        self.form=self.ttk.Frame(parent);self.form.pack(fill='x',pady=6)
        row=line(self);button(self,row,'Review and submit…',self.submit);button(self,row,'Discard local draft',self.build_form)
        if area in ('groups','worlds','creator'):button(self,row,'Reviewed batch queue…',self.batch)
        if area=='profile':button(self,row,'Choose appearance from owned items…',lambda:__import__('native_appearance_ui').show(self))
        if area in ('profile','worlds','groups','messages','inbox'):
            button(self,line(self),'Translate selected text…',lambda:__import__('text_translation_ui').show(self))
        if area=='inventory':
            button(self,row,'Inspect selected item',lambda:self.inspect_inventory(False));button(self,row,'Inspect item template',lambda:self.inspect_inventory(True))
        note(self,'All changes use your active VRChat account. Permissions and entitlement are enforced by VRChat; imported history cannot authorize an action. '
             'A submitted request is never retried automatically. View receipts in Action history.')
        if area in ('media','creator','worlds','groups'):
            button(self,line(self),'Upload image…',lambda:__import__('native_image_ui').show(self))
            note(self,'Print uploads review a 1920 × 1080 image, capture timestamp and note. Animated emoji review an atlas and frame rate. Original local photos are preserved.')
        if area=='groups':
            button(self,line(self),'Open selected gallery images',self.inspect_gallery)
            note(self,'Use Roles to delete an ordinary role, or Galleries to create, edit and delete galleries. Refresh group permissions before reviewing changes. Default and management roles are protected. Group transfer needs an eligibility check for the exact recipient.')
        if area=='inventory':note(self,'Item type, tag, seen and equipment filters apply to your active or archived inventory. Unequip clears the selected item’s slot and keeps the item. Changes recheck ownership and the equipped slot. VRChat decides compatibility and entitlement.')

    def require(self):
        if hasattr(self.owner,'require_revealed'):self.owner.require_revealed()
        if getattr(self.owner,'private',None) and self.owner.private.get():raise ValueError('Reveal the parent workspace before loading this view.')
        self.connected()

    def reset(self):
        self.cancel();self.result=None;self.table.set([],lambda r:());self.detail.set('Load the selected view explicitly.');self.action.set('');self.build_form()

    def account_changed(self):
        for window in tuple(self.image_windows):window.close()
        self.group_result=None;self.subject.set('');self.target.set('');self.reset()
        self.item_type.set('');self.item_tag.set('');self.equip_slot.set('');self.seen.set('Any')
        self.item_flags.set('');self.item_not_flags.set('');self.item_order.set('descending')

    def close(self):
        for window in tuple(self.image_windows):window.close()
        return super().close()

    def load(self,offset,*,complete_gallery=False):
        self.require();kind=VIEWS[self.area][self.view.get()];subject=self.subject.get().strip()
        if complete_gallery and kind!='group-gallery':raise ValueError('Select an exact group gallery before loading its complete order.')
        if self.area=='messages':subject=kind;kind='messages'
        filters=self.filters() if kind in ('inventory','inventory-archived') else {}
        expected=(self.view.get(),self.subject.get(),self.filters())
        def done(result):
            if expected!=(self.view.get(),self.subject.get(),self.filters()):raise ValueError('The service view changed. Refresh it.')
            self.result=result;self.offset=offset
            if result.kind=='group':self.group_result=result
            data=result.data;rows=data if isinstance(data,list) else next((data[k] for k in ('results','data','items','inventoryItems','inventoryTemplates') if isinstance(data.get(k),list)),[data])
            self.table.set(rows,lambda r:(r.get('displayName') or r.get('name') or r.get('title') or r.get('message') or r.get('itemName',''),
                r.get('type') or r.get('membershipStatus') or r.get('releaseStatus') or r.get('itemType',''),r.get('id') or r.get('userId') or r.get('inventoryId',''),r.get('createdAt') or r.get('created_at') or r.get('startsAt','')))
            self.detail.set(f'{len(rows)} records · checked {result.checked_at}. '+('More pages may exist.' if result.more else 'End of this response.'))
            self.set_actions()
        self.start(lambda c,s,p:api.read_gallery_complete(c,subject,stop=s,progress=p) if complete_gallery else api.read(c,kind,subject=subject,offset=offset,filters=filters,stop=s,progress=p),done)

    def filters(self):
        out={k:v.get().strip() for k,v in (('types',self.item_type),('tags',self.item_tag),('equipSlot',self.equip_slot)) if v.get().strip()}
        if self.seen.get()!='Any':out['seen']=self.seen.get()=='Seen'
        for key,var in (('flags',self.item_flags),('notFlags',self.item_not_flags)):
            if var.get().strip():out[key]=var.get().strip()
        if self.item_order.get()!='descending':out['order']=self.item_order.get()
        return out

    def inspect_inventory(self,template):
        self.require();row=self.table.selected()
        if not row:raise ValueError('Select a returned inventory item or catalog entry.')
        embedded=row.get('template') if isinstance(row.get('template'),dict) else {}
        ref=(row.get('templateId') or row.get('inventoryTemplateId') or embedded.get('id')) if template else row.get('id') or row.get('inventoryId')
        if template and not ref and self.result and self.result.kind=='inventory-global':ref=row.get('id')
        if not ref:raise ValueError('This item did not return the requested identifier.')
        self.subject.set(ref);self.view.set('Template details' if template else 'Selected item');self.load(0)

    def next(self):
        if not self.result or not self.result.more:raise ValueError('No next page was reported.')
        self.load(self.offset+100)

    def load_group(self):
        self.require();group=self.subject.get().split('/')[0]
        def done(result):
            if self.subject.get().split('/')[0]!=group:raise ValueError('The group selection changed. Refresh permissions again.')
            self.group_result=result;self.detail.set('Current group grants: '+', '.join(result.data.get('myMember',{}).get('permissions',[])));self.set_actions()
        self.start(lambda c,s,p:api.read(c,'group',subject=group,stop=s,progress=p),done)

    def inspect_gallery(self):
        self.require();r=self.table.selected()
        if not self.result or self.result.kind!='group-galleries' or not r:raise ValueError('Load Galleries and choose a gallery first.')
        self.subject.set(self.result.subject+'/'+r['id']);self.view.set('Gallery (group ID / gallery ID)');self.load(0)

    def inspect_world(self):
        r=self.table.selected()
        if not r:raise ValueError('Choose one of your worlds.')
        self.subject.set(r['id']);self.view.set('Selected world');self.load(0)

    def selection(self):
        r=self.table.selected()
        if not r:return
        self.target.set(r.get('userId') or r.get('id') or r.get('inventoryId',''))
        self.detail.set('\n'.join(f'{re.sub(r"([A-Z])",r" \1",k).capitalize()}: '+(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)) for k,v in r.items() if k not in ('versions','file'))[:5000])
        self.build_form()

    def set_actions(self):
        kind=self.result.kind if self.result else '';actions=[]
        if kind=='profile':actions=['group-create'] if self.area=='groups' else ['reward-redeem'] if self.area=='inventory' else ['profile-edit']
        elif kind=='profile-themes':actions=['profile-theme-create','profile-theme-edit','profile-theme-delete']
        elif kind=='messages':actions=['saved-message-edit']
        elif kind=='notifications-v2':actions=['notification2-see','notification2-respond','notification2-hide']
        elif kind=='world':actions=['world-edit','world-publish','world-unpublish']
        elif kind in ('gallery','icons','stickers','emoji','avatar-gallery'):actions=['media-delete']
        elif kind=='prints':actions=['print-delete']
        elif kind=='inventory':actions=['inventory-consume','inventory-equip','inventory-unequip','inventory-archive']
        elif kind=='inventory-archived':actions=['inventory-unarchive']
        elif kind.startswith('group') and self.group_result:
            group=self.group_result.data;own=self.group_result.account[0]
            actions=['group-join','group-leave','group-cancel-request','group-represent','group-block']
            actions += [a for a,p in api.GROUP_PERMISSION.items() if api.allowed(group,own,p)
                and (a!='group-role-delete' or kind=='group-roles')
                and (not a.startswith('group-gallery-') or kind=='group-galleries' and a in ('group-gallery-create','group-gallery-edit','group-gallery-delete')
                     or kind in ('group-gallery','group-gallery-pending') and a in ('group-gallery-add-image','group-gallery-remove-image','group-gallery-order'))]
            if any(api.allowed(group,own,p) for p in ('group-instance-open-create','group-instance-plus-create','group-instance-public-create')):actions+=['group-instance-create']
            actions+=['group-event-follow']
            if group.get('ownerId')==own:actions+=['group-transfer','group-delete']
        self.action_map={ACTION_LABELS[a]:a for a in actions};self.actions_box.configure(values=tuple(self.action_map))
        self.action.set(next(iter(self.action_map),''));self.build_form()

    def build_form(self):
        for child in self.form.winfo_children():child.destroy()
        self.controls={};action=getattr(self,'action_map',{}).get(self.action.get(),'')
        r=self.table.selected() or (self.result.data if self.result and isinstance(self.result.data,dict) else {})
        if action=='group-gallery-order' and self.result:r={'ids':[v.get('fileId','') for v in self.result.data]}
        if action=='notification2-respond':
            responses=r.get('responses',[]);self.responses={v.get('type','')+' · '+str(v.get('text',v.get('data','')))[:100]:v for v in responses if isinstance(v,dict) and isinstance(v.get('type'),str)}
            choice(self,line(self,self.form),self.response,tuple(self.responses),width=65);self.response.set(next(iter(self.responses),''));return
        for key,rule in fields_for(action).items():
            row=self.ttk.Frame(self.form);row.pack(fill='x',pady=2)
            label=re.sub(r'([A-Z])',r' \1',key).capitalize()
            self.ttk.Label(row,text=label,width=29).pack(side='left',anchor='n')
            enabled=self.tk.BooleanVar(value=key in r or action in ('saved-message-edit','reward-redeem') or key in ('name','shortCode','title','text','startsAt','endsAt') and action.endswith('create'))
            self.ttk.Checkbutton(row,text='Include',variable=enabled).pack(side='right')
            current=r.get(key,'')
            if rule is bool:
                variable=self.tk.BooleanVar(value=current is True);self.ttk.Checkbutton(row,variable=variable).pack(side='left')
            else:
                if isinstance(current,list):current='\n'.join(str(v) for v in current)
                variable=self.tk.StringVar(value=str(current) if current is not None else '')
                if isinstance(rule,tuple):choice(self,row,variable,rule,width=35)
                elif isinstance(rule,int) and rule>200 or rule in ('links','strings'):
                    widget=self.tk.Text(row,height=3,width=68,wrap='word');widget.pack(side='left',fill='x',expand=True);widget.insert('1.0',str(current));variable=widget
                else:entry(self,row,variable,66)
                if rule=='color':button(self,row,'Color…',lambda v=variable:self.choose_color(v))
                if rule in ('links','strings'):self.ttk.Label(row,text='one per line').pack(side='left')
            self.controls[key]=(rule,variable,enabled)

    def choose_color(self,variable):
        from tkinter import colorchooser
        current=variable.get().lstrip('#');value=colorchooser.askcolor(color='#'+current if re.fullmatch('[0-9a-fA-F]{6}',current) else '#ffffff',parent=self.app.root)[1]
        if value:variable.set(value.lstrip('#'))

    def draft(self):
        values={}
        for key,(rule,var,enabled) in self.controls.items():
            if not enabled.get():continue
            value=var.get('1.0','end-1c') if isinstance(var,self.tk.Text) else var.get()
            if rule in ('links','strings'):value=[v.strip() for v in value.splitlines() if v.strip()]
            elif rule=='number':
                try:value=int(value)
                except ValueError:raise ValueError(key+' needs a whole number.') from None
            values[key]=value
        return values

    def signature(self):return (self.context(),self.view.get(),self.subject.get(),self.target.get(),self.action.get(),self.draft(),self.response.get(),id(self.result),id(self.group_result),self.filters())

    def submit(self):
        self.require();action=getattr(self,'action_map',{}).get(self.action.get())
        if not action or not self.result:raise ValueError('Refresh a service view and choose an available action.')
        values=self.draft()
        if action=='notification2-respond':values={'response':getattr(self,'responses',{}).get(self.response.get())}
        submit_review(self,action,result=self.result,row=self.table.selected(),values=values,target=self.target.get(),group_result=self.group_result,
            view_guard=self.signature,done=lambda outcome:(self.reset(),self.status.set(outcome.message)))

    def batch(self):
        return __import__('native_batch_ui').show(self)


def install_accounts(page):
    panels=[]
    for title,area in (('Biography / appearance','profile'),('My worlds','worlds'),('My media','media'),('Avatar media','creator'),('Inventory','inventory')):
        frame=page.ttk.Frame(page.tabs);page.frames[title]=frame;page.tabs.add(frame,text=title);panels.append(ServicePanel(page,frame,area))
    page.native_panels=panels


def install_social(page):
    panels=[]
    from native_inbox_ui import UnifiedInbox
    frame=page.ttk.Frame(page.tabs);page.frames['Inbox']=frame;page.tabs.add(frame,text='Inbox');panels.append(UnifiedInbox(page,frame))
    from provider_ui import ProviderPanel
    frame=page.ttk.Frame(page.tabs);page.frames['Optional providers']=frame;page.tabs.add(frame,text='Optional providers');panels.append(ProviderPanel(page,frame))
    for title,area in (('Saved messages','messages'),('Groups','groups')):
        frame=page.ttk.Frame(page.tabs);page.frames[title]=frame;page.tabs.add(frame,text=title);panels.append(ServicePanel(page,frame,area))
    page.native_panels=panels
