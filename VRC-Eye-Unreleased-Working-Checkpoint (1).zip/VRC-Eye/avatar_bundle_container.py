"""Bounded UnityFS v6–8 container reader. No extraction, keys or external paths.

Layout reference: UnityPy 1.25.4 files/BundleFile.py (MIT), reviewed 2026-10-06.
Only Unity 2022.3, combined directory/block info, plain/LZ4/LZMA blocks.
"""
import lzma
import re
import struct

MAX_EXPANDED=64*1024**2
MAX_INDEX=1024**2


class Reader:
    def __init__(self,data):self.data=data;self.pos=0
    def take(self,n):
        if type(n) is not int or n<0 or n>len(self.data)-self.pos:raise ValueError('Truncated Unity bundle data.')
        value=self.data[self.pos:self.pos+n];self.pos+=n;return value
    def unpack(self,fmt):return struct.unpack(fmt,self.take(struct.calcsize(fmt)))
    def string(self,limit=256):
        end=self.data.find(b'\0',self.pos,min(len(self.data),self.pos+limit+1))
        if end<0:raise ValueError('Unity bundle string exceeds its supported limit.')
        try:value=self.take(end-self.pos).decode('utf-8')
        except UnicodeError:raise ValueError('Invalid Unity bundle text.') from None
        self.take(1);return value
    def align(self,n):
        if any(self.take((-self.pos)%n)):raise ValueError('Nonzero Unity bundle padding is unsupported.')


def engine_version(value):
    if not isinstance(value,str) or not re.fullmatch(r'2022\.3\.\d{1,3}f\d{1,2}',value):
        raise ValueError('Bundle preview currently supports declared Unity 2022.3 release builds only; keep this file for manual recovery.')
    return value


def decompress(data,size,kind):
    if not 0<size<=MAX_EXPANDED:raise ValueError('Unity bundle decompression exceeds 64 MiB.')
    if kind==0:out=data
    elif kind in (2,3):
        import lz4.block
        try:out=lz4.block.decompress(data,uncompressed_size=size)
        except Exception:raise ValueError('Damaged LZ4 Unity bundle block.') from None
    elif kind==1:
        if len(data)<6:raise ValueError('Truncated LZMA Unity bundle block.')
        prop=data[0];lc=prop%9;prop//=9;lp=prop%5;pb=prop//5
        dictionary=struct.unpack('<I',data[1:5])[0]
        if pb>4 or lc+lp>4 or not 4096<=dictionary<=MAX_EXPANDED:raise ValueError('Unsupported LZMA dictionary/properties.')
        try:
            decoder=lzma.LZMADecompressor(format=lzma.FORMAT_RAW,filters=[dict(id=lzma.FILTER_LZMA1,dict_size=dictionary,lc=lc,lp=lp,pb=pb)])
            out=decoder.decompress(data[5:],max_length=size+1)
            if not decoder.eof or decoder.unused_data:raise ValueError('Incomplete or trailing LZMA bundle block.')
        except lzma.LZMAError:raise ValueError('Damaged LZMA Unity bundle block.') from None
    else:raise ValueError('Unsupported or encrypted Unity bundle compression. No decryption is attempted.')
    if len(out)!=size:raise ValueError('Unity bundle decompressed size does not match its declaration.')
    return out


def unpack(data):
    r=Reader(data)
    if r.string(16)!='UnityFS':raise ValueError('Only UnityFS bundles are decoded; UnityWeb/UnityRaw and other formats retain manual recovery.')
    version,=r.unpack('>I')
    if version not in (6,7,8):raise ValueError('Unsupported UnityFS container version.')
    r.string(64);engine=engine_version(r.string(64))
    size,compressed,expanded,flags=r.unpack('>QIII')
    if size!=len(data):raise ValueError('Unity bundle declared size differs from the selected bytes.')
    if flags&~0x2ff or not flags&0x40 or flags&0x100 or flags&0x3f not in (0,1,2,3):
        raise ValueError('Unsupported or encrypted UnityFS flags. No decryption is attempted.')
    if not 1<=compressed<=MAX_INDEX or not 1<=expanded<=MAX_INDEX:raise ValueError('Unity bundle directory exceeds 1 MiB.')
    if version>=7:r.align(16)
    if flags&0x80:
        end=len(data)-compressed
        if end<r.pos:raise ValueError('Unity bundle directory overlaps its header.')
        index=data[end:]
    else:index=r.take(compressed);end=len(data)
    if flags&0x200:r.align(16)
    directory=Reader(decompress(index,expanded,flags&0x3f));directory.take(16)
    count,=directory.unpack('>I')
    if not 1<=count<=4096:raise ValueError('Unity bundle block count exceeds its limit.')
    blocks=[];total=packed=0
    for _ in range(count):
        raw,stored,kind=directory.unpack('>IIH')
        if kind&~0x7f or kind&0x3f not in (0,1,2,3) or not raw or not stored:raise ValueError('Unsupported Unity bundle block flags or size.')
        total+=raw;packed+=stored
        if total>MAX_EXPANDED or packed>end-r.pos:raise ValueError('Unity bundle exceeds its expanded or stored byte budget.')
        blocks.append((raw,stored,kind&0x3f))
    if r.pos+packed!=end:raise ValueError('Unity bundle block layout has gaps or trailing bytes.')
    count,=directory.unpack('>I')
    if not 1<=count<=128:raise ValueError('Unity bundle contains more than 128 embedded files.')
    entries=[];names=set();ranges=[]
    for _ in range(count):
        start,length,kind=directory.unpack('>QQI');name=directory.string()
        if not re.fullmatch(r'[A-Za-z0-9_. -]{1,256}',name) or name in ('.','..') or name.casefold() in names:
            raise ValueError('Ambiguous or path-bearing Unity bundle entry names are unsupported.')
        if kind not in (0,4) or not length or start+length>total:raise ValueError('Invalid Unity bundle entry range or flags.')
        names.add(name.casefold());ranges.append((start,start+length));entries.append((name,start,length,kind))
    if directory.pos!=len(directory.data):raise ValueError('Trailing Unity bundle directory data.')
    ordered=sorted(ranges)
    if any(a[1]>b[0] for a,b in zip(ordered,ordered[1:])):raise ValueError('Overlapping Unity bundle entries are unsupported.')
    payload=b''.join(decompress(r.take(stored),raw,kind) for raw,stored,kind in blocks)
    return engine,tuple((name,payload[start:start+length],kind) for name,start,length,kind in entries)
