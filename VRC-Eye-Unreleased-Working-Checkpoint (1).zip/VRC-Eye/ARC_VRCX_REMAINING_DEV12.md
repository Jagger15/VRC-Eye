# ARC and VRCX functions still incomplete in VRC Eye Development 12

Date: 4 October 2026. Comparison: the supplied VRCX **2026.09.16** source and the supplied ARC package (main **1.41.3.112**, Core **1.0.4.0**), using the saved static ARC review. The 25 mod-inspired proposals are tracked separately in SESSION_TOOLS_DEV12.md.

This is a complete disposition of the **106 ARC/VRCX feature packages** in the saved plan: 82 VRCX and 24 ARC. It does not claim visibility into every hidden ARC binary behavior or later upstream changes. Reference programs/mods were not executed. “Source implemented” is not native/live certification.

## Most consequential gaps

- **ARC:** full VRCA/FBX/Unity avatar viewing, actual textures/rigs/blendshapes/animations; integrated AssetRipper recovery; richer Unity repair tools; resumable transfers and durable provider recovery.
- **VRCX:** complete creator duplicate/version rollback, exhaustive profile history, gallery approval/large-gallery ordering, interactive Discord join requests, unattended private-instance rejoin, complete migration/roundtrip coverage, broader dashboards/providers, and a signed updater with its own Eye feed.
- **Validation:** real Windows/Linux GUI and credential vaults, Discord/tray/URI handlers, Unity, SteamVR/audio/Vosk and live VRChat entitlements/actions still need native acceptance. These are distinguished from missing code below.

## ARC — all 24 incomplete feature areas

| ID | Function | What remains | Existing narrower behavior |
|---|---|---|---|
| ARC-01 | Isolated avatar provider contract and lifecycle (Missing) | Qualified, isolated rich-avatar viewer/parser provider with bounded IPC, version checks, resource limits and proven host containment. | OBJ preview and manual source-project inspection are available. |
| ARC-02 | Authorized VRCA and Unity bundle ingestion (Missing) | Decode authorized VRCA/Unity bundles into actual mesh/material/rig/animation scene data; supported-version and missing-dependency reporting. | Bundle preservation/header inspection is not scene decoding. |
| ARC-03 | Authorized FBX import and scene inspection (Missing) | FBX import/scene inspection including axes, units, importer settings, takes and external dependency handling. | Selected OBJ geometry is supported. |
| ARC-04 | Actual material and texture viewer (Missing) | Actual material/submesh assignments, texture and alpha display, UV channels, typed shader properties and rendered shader fallbacks. | OBJ uses flat shading/wireframe; it does not load textures. |
| ARC-05 | Rig, skinning and blendshape viewer (Missing) | Bone/bind-pose/influence inspection, skinned preview, reversible poses and blendshape controls. | Creator-declared hierarchy and a generic mannequin do not supply an actual rig. |
| ARC-06 | Clip, take and safe controller animation preview (Missing) | Actual clip/take playback and scrubbing, speed/loop/root-motion controls and safe Animator/controller-subset preview. | Declared parameter/test workflows do not evaluate an actual Unity avatar. |
| ARC-07 | AssetRipper provider selection, version and provenance (Missing) | Selected AssetRipper provider registry with exact executable/version/hash/platform/license/capability validation. | Manual official-provider guidance and staged input are available. |
| ARC-08 | Integrated user-owned recovery orchestration (Partial) | Integrated owned-process recovery/export orchestration with a verified exact-version interface, cancellation and child-process cleanup. | User prepares a staging folder, runs the external GUI manually, then inspects output. |
| ARC-09 | Recovered-project provenance and reviewed editor handoff (Partial) | Complete recovered-output manifests, dependency/loss reports, immutable raw-versus-repaired lineage and a reviewed automatic editor handoff. | Manual recovery handoff hashes and bounded output/project inspection exist. |
| ARC-10 | Renderer bounds diagnostics and copy-only correction (Missing) | Compare real mesh/renderer/pose bounds and apply reviewed bounds corrections or margins to clones. | Generic creator validation is not the renderer-bounds repair workflow. |
| ARC-11 | Reviewed mesh and importer setting transfer (Missing) | Compatible mesh/renderer/importer setting transfer with typed diffs, fresh copies and controlled reimport policy. | No general mesh/importer settings copier is implemented. |
| ARC-12 | Conservative rig and skinned-mesh optimization (Missing) | Dependency-checked influence reduction, proven-unused bone removal and renderer consolidation with measured deformation comparisons. | No actual rig/skinned-mesh optimizer is implemented. |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies (Partial) | Full topology/stream/index/tangent diagnostics and narrowly reviewed tangent repairs. | The experimental Unity source can duplicate a readable mesh and recalculate missing normals; no retopology/decimation/UV reconstruction. |
| ARC-14 | Shader and material compatibility diagnostics (Partial) | Real shader/pipeline/platform compatibility, typed-property/keyword/texture-dependency analysis and measured compile availability. | Read-only shader/package inventory and a selected shader-replacement copy exist. |
| ARC-15 | Typed material property mapping on copies (Partial) | Exact-shader-version mapping profiles and reviewed texture, offset/scale, color, number/vector, queue and keyword transfer. | A single shader replacement on a copied material is not property migration. |
| ARC-16 | Reviewed shader package install and removal (Partial) | Shader-specific install/remove planning with dependency review, post-operation compilation/diffs and change-aware removal journal. | Read-only shader inventories and generic project-copy package jobs exist. |
| ARC-17 | Animation and controller dependency repair copies (Partial) | Object-reference curve repairs, clip swaps and cloned Animator/override-controller dependency closure repair. | Experimental clip-copy binding-prefix remap exists; controllers remain unchanged. |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair (Partial) | Actual serialized-asset/component dependency graph, allowlisted component copying and reference remapping on clones. | Dev12 adds stable-ID declared hierarchy/component comparison; experimental copied-prefab missing-script removal already exists. |
| ARC-19 | General repair-copy journal and conditional rollback (Partial) | One durable general repair-copy journal with source/dependency evidence, owned-output phases and conditional rollback across richer repairs. | Current copy-only operations and local reviews do not provide the entire cross-operation recovery contract. |
| ARC-20 | Scoped automated catalog metadata backfill (Missing) | Reviewed, scoped automatic catalog metadata backfill with field/source/freshness rules and durable progress. | Ordinary API reads, auto friend sync, watches and known-creator browsing are not whole-catalog backfill. |
| ARC-21 | Evidence-based automated local-file association (Partial) | Explainable multi-candidate matching and separately enabled deterministic exact-match file-association rules. | Selected-folder rescans stage candidates; users explicitly inspect and associate files. |
| ARC-22 | Opt-in resumable authorized transfers (Missing) | Durable resumable partial transfers with strong validator/range support, fresh account/destination checks and complete final integrity verification. | Existing authorized downloads and local copies are retained; no general automatic resume claim. |
| ARC-23 | Explicit bounded transient retry policy (Missing) | Explicit opt-in bounded transient retry policy for these asset/recovery jobs, sharing backoff and the original approval lease. | Automatic friend reconnection is a separate feature and does not complete this asset job policy. |
| ARC-24 | Durable job and publication crash reconciliation (Partial) | General versioned crash reconciliation across source/output/process identities, transfer phases and catalog publication. | Local job receipts/interrupted states exist; comprehensive recoverable provider/publication orchestration remains incomplete. |

The optional Unity repair-copy source has not been compiled or exercised in Unity here. Bounds, mesh setting copying, skinned-mesh optimization, full dependency repair and richer rollback are not supplied by the generic mannequin or declared-hierarchy browser.

## VRCX — missing or partial functions

| ID | Function | Specific remaining scope |
|---|---|---|
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Exhaustive per-field profile change capture and every historical producer are not implemented. |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | A general creator duplicate detector and complete historical asset-version/rollback workflow are still missing. |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Image approval has no verified endpoint in the pinned source. Ordering is limited to one complete unfiltered page of fewer than 100 images. |
| VX-MIG-01 | Versioned source contract inventory | Additional historical source-version adapters are not exhaustive. |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Requires rollback-journal stores. This does not erase physical logs/photos, original VRCX files, all creator/media stores or minimal action receipts. |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Independent live stores are not universally one atomic database. Profile snapshots can represent slightly different instants. |
| VX-MIG-14 | User, world and avatar memos plus account notes | Legacy note editors and canonical annotation editors remain separate; automatic bidirectional note synchronization is not implemented. |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Persistent custom-user-tag VRCX producer/export contract remains conditional. |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Additional individual display/date/sidebar preference mappings need explicit equivalent contracts. |
| VX-MIG-20 | Video, resource and auxiliary game-log history | All version-specific auxiliary payloads remain conditional. |
| VX-MIG-23 | Notification archives and invite message details | Exhaustive nested payloads across historical versions are not supported. |
| VX-MIG-25 | Print favorite references and conditional print metadata | Complete historical print metadata/export schemas remain conditional. |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Exhaustive legacy/cross-application formats are not claimed. |
| VX-MIG-28 | Saved searches, filters and portable views | No verified persisted VRCX saved-search producer was found; such migration remains conditional. |
| VX-MIG-29 | Native selective backup and complete restore | Original photos/Unity projects, protected login sessions, execution/network approvals and unrecognized stores are excluded. This is not every possible application store. |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Complete bidirectional VRCX roundtrip is not claimed; ID/CSV exports lose richer native relationships/history. |
| VX-DESK-01 | Shared dashboard projections | Every earlier runtime/log widget is not a common immutable subscription API. |
| VX-DESK-02 | Configurable dashboards and widget layouts | Generic status/media widgets do not offer the same sortable tabular semantics as history/photo/download rows. |
| VX-DESK-06 | Discord content, join controls and coexistence | Interactive Discord join-request acceptance is not implemented. Native Discord IPC and application registration remain user/environment prerequisites. |
| VX-DESK-08 | Opt-in crash recovery controller | Unattended private-instance rejoin and installed native crash/launch acceptance remain incomplete. |
| VX-DESK-15 | Tray/background and low-power operation | Native tray/startup/shutdown acceptance and comprehensive adaptive sensor/provider throttling remain. |
| VX-DESK-16 | Settings profiles, backup and rollback UX | History and undo cover ten desktop presentation/notification fields, not every setting store; protected secrets and source assets are not portable profile data. |
| VX-DESK-17 | Optional update channels and recoverable installation | Publisher endpoint, trusted signing keys, installer/update-channel implementation and native rollback acceptance remain missing. |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Live provider acceptance, broader providers and generalized playback-error correlation remain incomplete. |

**Updater:** Eye still needs its own release manifest/feed, publisher signing keys, verified installer/staging logic, schema-compatible rollback and platform acceptance. This build does not point Eye at VRCX release ZIPs or enable an installation transport. The saved UPDATER_PLAN_DEV10.md remains preparation.

**Overlay parity:** the retained shared SteamVR social overlay is read-only. Interactive notification/invite actions and complete configurable overlay event/widget coverage remain incomplete; the desktop host worksheet and composer do not implement those VR controls.

## Implemented code with remaining acceptance or unavoidable source limits

| ID | Area | Remaining check / limit |
|---|---|---|
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Native window, idle-event and Windows/Linux protected-vault acceptance remain. The lock is a UI privacy boundary, not disk encryption. |
| VX-NATIVE-29 | Optional avatar metadata search providers | Provider availability/access/terms and live metadata/image results need acceptance; no VRCX-only entitlement is assumed. |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source groups absent from the selected database cannot be reconstructed. |
| VX-MIG-26 | Photo index migration with verified file relinking | The source has no file fingerprint, so historical byte identity cannot be proven. No implicit path scans or roster matching. |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Installed protocol registration/focus/delivery requires native OS acceptance. |
| VX-MIG-33 | Future acceptance matrix and migration release gates | The full prepared acceptance matrix, native Windows and release gates remain open. |
| VX-DESK-05 | Native Discord presence provider | Native Discord application registration and Windows/Linux IPC acceptance remain required. |
| VX-DESK-07 | Configured application launch automation | Native launch/cleanup acceptance remains. No process-name killing, force-kill fallback or application-readiness claim. |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Installed zero-VRCX and coexistence acceptance remains; all parity gaps remain visible in this ledger. |

The custom-user-tag source search found transient CustomTag/ClearCustomTags messages and in-memory customUserTags updates in src/stores/vrcx.js and src/coordinators/userCoordinator.js. That establishes a live behavior, not a persisted export schema suitable for a migration adapter. No saved-search producer or missing historical photo fingerprints were invented.

## Deliberately excluded ARC behavior

- ARC authentication or server/API-key dependence, importing its cookies/credentials, or automatic uploading/reporting of local avatar caches.
- Hotswap upload substitution, private-asset access-control bypass and content/safety-filter bypass.
- Running arbitrary bundled viewers, scripts or binaries simply because they were included in an old mod archive.
- Claiming omitted source scripts, shader source, animation authoring history or other absent bundle data can be reconstructed.

These are dispositions, not promised future features. The supplied main binary contains a disabled API-download message; static strings alone do not prove which upstream controls currently work.

## Full 106-area disposition

| ID | Feature | Development 12 classification |
|---|---|---|
| VX-NATIVE-01 | One normalized event timeline and inbox state | Source implemented; native/live acceptance open |
| VX-NATIVE-02 | Account storage isolation and safe legacy migration | Source implemented; native/live acceptance open |
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite |
| VX-NATIVE-04 | Resilient friend live feed with bounded reconciliation | Source implemented; native/live acceptance open |
| VX-NATIVE-05 | Unified notifications including NotificationV2 | Source implemented; native/live acceptance open |
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Partial |
| VX-NATIVE-07 | Complete invitation responses | Source implemented; native/live acceptance open |
| VX-NATIVE-08 | Edit saved invitation messages | Source implemented; native/live acceptance open |
| VX-NATIVE-09 | Photo invitations and replies | Source implemented; native/live acceptance open |
| VX-NATIVE-10 | Complete own-profile editor | Source implemented; native/live acceptance open |
| VX-NATIVE-11 | Shared bounded image upload transport | Source implemented; native/live acceptance open |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | Partial |
| VX-NATIVE-13 | Everyday owned-world editor and publication | Source implemented; native/live acceptance open |
| VX-NATIVE-14 | Group details, membership and permission-aware navigation | Source implemented; native/live acceptance open |
| VX-NATIVE-15 | Group moderation and reviewed batch operations | Source implemented; native/live acceptance open |
| VX-NATIVE-16 | Group role management | Source implemented; native/live acceptance open |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Partial |
| VX-NATIVE-18 | Group calendars and event management | Source implemented; native/live acceptance open |
| VX-NATIVE-19 | Group creation, settings and ownership lifecycle | Source implemented; native/live acceptance open |
| VX-NATIVE-20 | Instant local entity search | Source implemented; native/live acceptance open |
| VX-NATIVE-21 | Manage VRChat favorite groups within service limits | Source implemented; native/live acceptance open |
| VX-NATIVE-22 | Complete native local collections and exports | Source implemented; native/live acceptance open |
| VX-NATIVE-23 | Group instances and explicit visit handoff | Source implemented; native/live acceptance open |
| VX-NATIVE-24 | VRChat gallery and account icon management | Source implemented; native/live acceptance open |
| VX-NATIVE-25 | Sticker and emoji management | Source implemented; native/live acceptance open |
| VX-NATIVE-26 | VRChat print browsing and publishing | Source implemented; native/live acceptance open |
| VX-NATIVE-27 | Inventory and cosmetic catalog browser | Source implemented; native/live acceptance open |
| VX-NATIVE-28 | Inventory consume, reward and supported equipment actions | Source implemented; native/live acceptance open |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite |
| VX-MIG-01 | Versioned source contract inventory | Partial |
| VX-MIG-02 | Consistent read-only SQLite and WAL acquisition | Source implemented; native/live acceptance open |
| VX-MIG-03 | Explicit source-account and destination-scope mapping | Source implemented; native/live acceptance open |
| VX-MIG-04 | Native entity, collections and annotation data model | Source implemented; native/live acceptance open |
| VX-MIG-05 | Provenance, immutable review and migration ledger | Source implemented; native/live acceptance open |
| VX-MIG-06 | Deterministic deduplication and field-level conflicts | Source implemented; native/live acceptance open |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Partial |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Partial |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation |
| VX-MIG-10 | Unify imported and existing native Favorites | Source implemented; native/live acceptance open |
| VX-MIG-11 | Bulk avatar observations integrated with AvatarLibrary | Source implemented; native/live acceptance open |
| VX-MIG-12 | World and user descriptive observations | Source implemented; native/live acceptance open |
| VX-MIG-13 | Local avatar tags with native editing and filtering | Source implemented; native/live acceptance open |
| VX-MIG-14 | User, world and avatar memos plus account notes | Partial |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Partial |
| VX-MIG-16 | Selected VRCX status preset import | Source implemented; native/live acceptance open |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Partial |
| VX-MIG-18 | Avatar-use aggregate history | Source implemented; native/live acceptance open |
| VX-MIG-19 | World visits, join/leave and portal event history | Source implemented; native/live acceptance open |
| VX-MIG-20 | Video, resource and auxiliary game-log history | Partial |
| VX-MIG-21 | Friend changes and social observation feeds | Source implemented; native/live acceptance open |
| VX-MIG-22 | Derived activity sessions and analytics provenance | Source implemented; native/live acceptance open |
| VX-MIG-23 | Notification archives and invite message details | Partial |
| VX-MIG-24 | Moderation observations and mutual graph snapshots | Source implemented; native/live acceptance open |
| VX-MIG-25 | Print favorite references and conditional print metadata | Partial |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Partial |
| VX-MIG-28 | Saved searches, filters and portable views | Partial |
| VX-MIG-29 | Native selective backup and complete restore | Partial |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Partial |
| VX-MIG-31 | Selective migration workspace and standalone native routes | Source implemented; native/live acceptance open |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite |
| VX-DESK-01 | Shared dashboard projections | Partial |
| VX-DESK-02 | Configurable dashboards and widget layouts | Partial |
| VX-DESK-03 | Unified notification delivery and focus rules | Source implemented; native/live acceptance open |
| VX-DESK-04 | Activity charts, heatmaps and history analysis | Source implemented; native/live acceptance open |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite |
| VX-DESK-06 | Discord content, join controls and coexistence | Partial |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite |
| VX-DESK-08 | Opt-in crash recovery controller | Partial |
| VX-DESK-09 | Reviewed join and last-instance recovery orchestration | Source implemented; native/live acceptance open |
| VX-DESK-10 | Automatic photo context association | Source implemented; native/live acceptance open |
| VX-DESK-11 | Optional compatible photo metadata output | Source implemented; native/live acceptance open |
| VX-DESK-12 | Photo organization, source moves and recovery | Source implemented; native/live acceptance open |
| VX-DESK-13 | Photo metadata index and richer gallery search | Source implemented; native/live acceptance open |
| VX-DESK-14 | VRChat service-health integration | Source implemented; native/live acceptance open |
| VX-DESK-15 | Tray/background and low-power operation | Partial |
| VX-DESK-16 | Settings profiles, backup and rollback UX | Partial |
| VX-DESK-17 | Optional update channels and recoverable installation | Partial |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Partial |
| VX-DESK-19 | Reviewed VRChat configuration and launch settings editor | Source implemented; native/live acceptance open |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite |
| ARC-01 | Isolated avatar provider contract and lifecycle | Missing |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing |
| ARC-03 | Authorized FBX import and scene inspection | Missing |
| ARC-04 | Actual material and texture viewer | Missing |
| ARC-05 | Rig, skinning and blendshape viewer | Missing |
| ARC-06 | Clip, take and safe controller animation preview | Missing |
| ARC-07 | AssetRipper provider selection, version and provenance | Missing |
| ARC-08 | Integrated user-owned recovery orchestration | Partial |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial |
| ARC-14 | Shader and material compatibility diagnostics | Partial |
| ARC-15 | Typed material property mapping on copies | Partial |
| ARC-16 | Reviewed shader package install and removal | Partial |
| ARC-17 | Animation and controller dependency repair copies | Partial |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial |
| ARC-19 | General repair-copy journal and conditional rollback | Partial |
| ARC-20 | Scoped automated catalog metadata backfill | Missing |
| ARC-21 | Evidence-based automated local-file association | Partial |
| ARC-22 | Opt-in resumable authorized transfers | Missing |
| ARC-23 | Explicit bounded transient retry policy | Missing |
| ARC-24 | Durable job and publication crash reconciliation | Partial |

## Evidence and practical limits

- IMPLEMENTATION_STATUS_1_21.json and its Markdown view retain all 160 broader roadmap packages; this report selects all ARC/VRCX IDs.
- ARC_VRCX_GAP_LEDGER_DEV12.json includes the remaining scope, implementation evidence, present source modules and pinned reference evidence for every one of the 106 areas.
- ARC_FEATURES_1_20_DEV8.md and planning/VRC-Eye-1.19.10-ARC-Avatar-Integration-Review.md document the actual-model, recovery and Unity source boundaries.
- VRCX_COMPLETION_DEV6.md plus the retained Development 7–11 notes document what already exists. Persistent sign-in/sync, notifications, notes/tags, saved maps, photo metadata, ordinary account/group actions and watched-friend filters are not listed as wholly missing.
- VALIDATION_1_21.md reports the exact executed checks and environment exclusions. Offline fixtures do not prove API entitlement, delivery, native rendering, hardware behavior or full upstream parity.
