"""Optional Windows GSMTC metadata/control adapter, never PCM capture.

Microsoft Windows.Media.Control session/manager API. SourceAppUserModelId is
not a PID. Manager session events invalidate all retained handles; duplicate
app labels remain separate sources. All WinRT work lives in the owner worker.
"""
import asyncio
import threading
from media_model import session, validate_operation


class WindowsMedia:
    def __init__(self, manager=None):
        self.manager = manager
        self.dirty = True
        self.epoch = 0
        self.handles = {}
        self.token = None
        self.lock = threading.RLock()
        self.closing = False

    def changed(self, *_):
        with self.lock:
            if not self.closing: self.dirty = True; self.epoch += 1

    async def connect(self):
        if self.manager is None:
            try:
                from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager
            except ImportError:
                raise ValueError('Windows media needs optional winrt-Windows.Media.Control and winrt-Windows.Foundation.') from None
            self.manager = await asyncio.wait_for(GlobalSystemMediaTransportControlsSessionManager.request_async(), 4)
        if self.token is None: self.token = self.manager.add_sessions_changed(self.changed)

    @staticmethod
    def seconds(value):
        try: return value.total_seconds()
        except (AttributeError, TypeError): return None

    async def read(self, identifier, handle):
        media = await asyncio.wait_for(handle.try_get_media_properties_async(), 3)
        info = handle.get_playback_info(); controls = info.controls
        timeline = handle.get_timeline_properties()
        caps = [op for op, key in (('play','is_play_enabled'),('pause','is_pause_enabled'),
            ('next','is_next_enabled'),('previous','is_previous_enabled'),('stop','is_stop_enabled'),
            ('seek','is_playback_position_enabled')) if getattr(controls, key, False) is True]
        try: state = {3:'stopped',4:'playing',5:'paused'}.get(int(info.playback_status),'unknown')
        except (TypeError, ValueError): state = 'unknown'
        # GSMTC supplies no universal track ID. Bind to the returned metadata tuple.
        import hashlib
        identity = repr((media.title, media.artist, media.album_title, getattr(media,'track_number',None)))
        return dict(id=identifier, provider='Windows GSMTC', label=handle.source_app_user_model_id,
            track=hashlib.sha256(identity.encode()).hexdigest(), title=media.title, artist=media.artist,
            album=media.album_title, state=state, position=self.seconds(timeline.position),
            duration=self.seconds(timeline.end_time), seek_start=self.seconds(timeline.min_seek_time),
            seek_end=self.seconds(timeline.max_seek_time), rate=getattr(info,'playback_rate',1.) or 1., capabilities=caps)

    async def poll(self):
        await self.connect()
        with self.lock:
            if self.dirty:
                self.epoch += 1
                self.handles = {'windows:%s:%s'%(self.epoch,i): h for i,h in enumerate(list(self.manager.get_sessions())[:32])}
                self.dirty = False
            generation, handles = self.epoch, dict(self.handles)
        result = []
        for identifier, handle in handles.items():
            try: result.append(await self.read(identifier, handle))
            except (OSError, RuntimeError, asyncio.TimeoutError): continue
        with self.lock:
            if self.dirty or self.epoch != generation: return []
        return result

    async def command(self, expected, operation, value, before_dispatch):
        with self.lock:
            handle, generation = self.handles.get(expected.id), self.epoch
            if self.dirty or handle is None: raise ValueError('Windows media session changed.')
        current = session(await self.read(expected.id, handle), expected.observed)
        if current.track_key != expected.track_key: raise ValueError('The track changed; review this control again.')
        validate_operation(current, operation, value)
        with self.lock:
            if self.dirty or generation != self.epoch or self.handles.get(expected.id) is not handle:
                raise ValueError('Windows media session changed.')
            before_dispatch()
            method = getattr(handle, {'play':'try_play_async','pause':'try_pause_async','next':'try_skip_next_async',
                'previous':'try_skip_previous_async','stop':'try_stop_async','seek':'try_change_playback_position_async'}[operation])
            request = method(round(value * 10_000_000)) if operation == 'seek' else method()
        accepted = await asyncio.wait_for(request, 4)
        if type(accepted) is not bool: raise ValueError('Windows returned an unsupported media acknowledgement.')
        return accepted

    async def close(self):
        with self.lock:
            self.closing = True; self.handles.clear(); self.dirty = True; self.epoch += 1
            manager, token = self.manager, self.token
        # Do not hold the callback's lock across native removal: a callback that
        # is already in flight may need to return before removal can complete.
        if manager is not None and token is not None:
            manager.remove_sessions_changed(token)
        with self.lock:
            # Failed removal deliberately retains both the manager and token for
            # explicit cleanup retry; the service prohibits observation restart.
            if self.manager is manager and self.token == token:
                self.token = None; self.manager = None
