# 1.21.0 Development checkpoint 5 — validation

The final clean-extracted portable suite passed **4,422 tests and 1,059
subtests**, with no failures or errors. This includes **76 new tests** for the
first missing-VRCX-features batch. The offline socket guard recorded **zero
external connection attempts**. Two warnings concern an existing test-class
name and an intentionally duplicated ZIP fixture entry.

## Coverage

- Real native-library writes: nested field choices, local/incoming policies,
  absent/null/list distinctions, source/destination changes, cancellation,
  expiry, scope boundaries, forgotten records, one-use reviews and rollback.
- The existing HTTP transport and action journal: role deletion, protected roles,
  revoked permissions, gallery administration, item-holder/slot changes,
  slot-based unequip, response shape validation and uncertain outcomes.
- Typed reward-redemption list replies and exact code correlation, without
  persisting the code in receipts.
- Exact outgoing emoji frame order and image bytes; playback, pause/step/atlas,
  presets, reduced motion and account/privacy/close lifecycle boundaries.
- Headless tests exercise the real Groups, Inventory, import-comparison and image
  dialog callbacks. Worker validation avoids Tk variable reads. These fixtures
  do not establish native layout or operating-system behavior.
- The retained portable regression for the other application workflows.

All **552 manifest-covered files** match the tested
extracted tree. All **503 Python files** parse with Python 3.10 grammar;
execution used Python 3.12.14. Dependency checks passed with no new
requirements. Shell syntax and CLI version launch passed. All seven prior
launchers and all 644 Development 4 archive paths are retained. Final ZIP CRC
and source-byte checks passed.

## Limits

This is not the full GUI/local-transport acceptance gate. Of **5,106 collected
tests**, **473 native GUI tests skipped**, **210 tests in 13 local-transport-associated
modules were omitted**, and **one Unix bridge test was deselected**. Some omitted
modules also contain portable unit cases; they are not counted as passed. The
same exclusions documented for Development 4 are retained because this sandbox
cannot provide the required display/socket facilities. The exact command and
exclusions are in BUILD_VALIDATION.json.

Native Windows credentials/tray/startup, live VRChat operations and entitlements,
SteamVR and audio hardware, Unity compilation, Discord IPC, installed VRCX
migration and a physical mobile connection still require acceptance elsewhere.
No live VRChat writes were performed during these tests.

The VRCX ledger now has **32 source-implemented packages and 50 partial**. The
larger 160-package / 849-future-check roadmap remains incomplete. Those planned
checks are not counted as executed tests. This is a runnable source ZIP, without
a compiled executable, signed installer or automatic updater.

Earlier Development 4 validation is retained in
[VALIDATION_1_21_DEV4.md](VALIDATION_1_21_DEV4.md) and
BASELINE_1_21_DEV4_VALIDATION.json. See the
[new-feature guide](VRCX_BATCH1_1_21.md),
[development notes](DEVELOPMENT_1_21.md) and
[feature ledger](IMPLEMENTATION_STATUS_1_21.md).
