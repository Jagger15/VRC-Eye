# VRC Eye — Development 30 candidate

This is the cumulative Development 30 **source candidate**, saved in the existing unreleased working checkpoint. It brings the retained creator, recovery and settings work together with the completed desktop pass below. It is ready for device testing; it is not a qualified Windows/Linux binary release or full ARC/VRCX parity claim.

The public footer remains `2026.05.10.02.47.1`; API/peer compatibility remains `1.21.0`. These retained identifiers are not new release numbers. No Development 22–29 ZIPs were created. The release hold remains active for distribution while native qualification is open.

## Candidate acceptance

| Gate | Delivered behavior | Evidence / remaining boundary |
| --- | --- | --- |
| Shared application observations | Independent Steam and VRChat status from the existing OS process owner; Home conditions and resource page use that data. Unknown/stale does not mean stopped. | Deterministic process fixtures and freshness tests. Real Windows, Wine/Proton and Flatpak visibility pending. |
| Shared log views | Home Game log card, retained-source coverage, stable paging, exact generation-bound navigation to Game Log. | Real owner/UI tests cover rollover, reset, selection and changed-context exports. |
| Session integration | New log revisions no longer discard intermission events. Source resets start a fresh cursor without replaying historical entries. | World/player/source-reset regression. Player activity still does not prove loading completed. |
| Setup and recovery health | Settings opens current provider/dependency checks, selected-workspace navigation, explicit read-only SQLite quick_check and reviewed report export. Safe Startup is supported. | Real SQLite bytes unchanged; no native owner initialization; private/context changes clear results. Availability is not driver/provider certification. |
| Metadata workspace | Account- and exact-pack declaration bookmarks; bounded comparison of two local reference packs; reviewed JSON export. | Independent binary fixtures verify enum-constant differences, exact pack identity, budgets, cancellation and UI flow. No executable/API-compatibility inference. |
| Appearance | Owned local image copy, persistent opacity, synchronized slider/numeric preview, optional rounded native controls, high-contrast fallback and privacy clearing. | Decoder/compositor, save/remove, settings migration and UI callbacks verified. Four native ttk gates included; actual desktop rendering/focus is not qualified here. |
| Settings continuity | Older appearance bundles migrate with defaults; cosmetic choices participate in reviewed restore/undo. Profile backup includes metadata bookmarks. | Portable settings and backup suites. Image bytes and paths stay device-local and are excluded from portable recovery. |
| Existing feature retention | GLB material/pose/topology improvements, profile verification, granular settings undo and journaled Creator copy/package jobs remain integrated. | Full portable regression and source hashes; broader native/Unity limits retained. |
| Distribution integrity | Every prior checkpoint member retained; current source/test manifest, validation reports and updated backlog included. | Archive entry/hash checks and Python 3.10 grammar verification. No signed installer/update qualification. |

## Where to try it

- **Performance & Security** shows Steam and VRChat observations. Enable the existing resource monitor to collect them. A process name observation does not establish login, world membership or focus.
- **Customization → Home layout → Add widget** offers **Steam & VRChat** and **Game log**. Steam/VRChat conditions are also available for layout rules and widget visibility. Opening a log row selects that exact retained entry in **Game Log**.
- **Settings → Setup health and dependencies…** shows existing provider states and package availability. **Check local databases** reads the current companion/native database once. **Export reviewed report…** includes availability and integrity results without record payloads or source paths.
- **Customization → Appearance** offers **Choose background image…**, **Remove background image**, an opacity slider and numeric box, and **Rounded buttons and text fields**. Choosing/removing a local image applies immediately; opacity and corner choices use **Apply appearance**. The image appears in the shell banner and margins; content panels keep opaque surfaces. High contrast takes precedence.
- **Local inspection reports → Metadata reference** adds declaration bookmarks and **Compare with another pack…**. Load the current pack first, choose a baseline, and export the comparison after review. Bookmarks only resolve in their exact pack and account.

Background inputs accept bounded PNG/JPEG/WebP, use the first frame, strip metadata, and retain a resized PNG copy. Opacity and rounding are portable preferences. The image itself is intentionally not part of a portable profile/theme. Unreadable saved images leave the normal interface usable; choose a new image to recover.

Metadata comparison matches assembly/name/kind declarations, flags duplicate names as ambiguous, and compares retained parents/interfaces/member signatures/constants. It caps shared structural comparisons at 10,000 types and 200,000 members, caps each type at 20,000 members, and returns at most 2,000 changed rows. Truncated interfaces/arguments, budgets and omitted rows are explicit. Renames appear as added/removed declarations; no guessed equivalence is applied.

## Remaining qualification

Native Tk rendering, keyboard/focus and assistive technology on Windows/Linux; process visibility with actual Steam/VRChat/Wine/Proton/Flatpak; SteamVR/overlay hardware; native media/session-keyring providers; installed Unity/VPM/AssetRipper behavior; filesystem/power-loss durability; signed installer/update rollback. These remain in the backlog rather than being treated as passed by portable tests.

All 40 broad ARC/VRCX partial areas remain partial. Seven advance in this pass. The six missing ARC ingestion/animation/repair areas remain deferred. Read [the current status table](PARTIAL_COMPLETION_STATUS.md) for exact remaining work.

Run from a separate extraction with **Start.cmd** on Windows or **bash Start.sh** on Linux. Use the existing backup verification/recovery controls before moving a real profile; the source ZIP contains no user profile or credentials.
