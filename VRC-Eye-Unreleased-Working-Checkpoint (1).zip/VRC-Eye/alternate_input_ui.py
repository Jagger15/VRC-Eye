"""Alternate input settings and switch/pointer-operable control actions."""
import json
from pathlib import Path
from tkinter import TclError
from alternate_input import Preferences, MODES, SWITCH_KEYS
from companion_ui import button, choice, entry
from friendly_ui import flow_line
from text_viewport import window_body


class InputPanel:
    def __init__(self,page,parent):
        self.page=page;self.manager=page.experience.alternate;self.variables={}
        page.ttk.Label(parent,text='Switches and controllers that send keyboard keys can move through visible controls. One-switch mode advances automatically; Two-switch mode advances on demand. Dwell activates buttons after the pointer stays still. Head/eye pointers and OS voice tools can supply ordinary pointer input. No device driver or global key capture is installed.',wraplength=750).pack(anchor='w',fill='x',pady=8)
        for key,label,values in (('mode','Switch mode',MODES),('next_key','Next control key',SWITCH_KEYS),('select_key','Select key',SWITCH_KEYS),('pause_key','Pause / resume key',SWITCH_KEYS)):
            row=flow_line(page,parent);page.ttk.Label(row,text=label).pack(side='left')
            var=page.tk.StringVar(value=getattr(self.manager.preferences,key));self.variables[key]=var
            choice(page,row,var,values)
        for key,label in (('scan_ms','Scan interval (500–10000 ms)'),('dwell_ms','Dwell time (500–10000 ms)'),('tolerance','Pointer tolerance (0–40 pixels)')):
            row=flow_line(page,parent);page.ttk.Label(row,text=label).pack(side='left')
            var=page.tk.StringVar(value=str(getattr(self.manager.preferences,key)));self.variables[key]=var
            entry(page,row,var,10)
        var=page.tk.BooleanVar(value=self.manager.preferences.dwell);self.variables['dwell']=var
        page.ttk.Checkbutton(parent,text='Enable pointer dwell activation',variable=var).pack(anchor='w',pady=6)
        row=flow_line(page,parent)
        for title,fn in (('Apply input settings',self.apply),('Undo input settings',self.undo),('Reset input settings',self.reset)):
            button(page,row,title,fn)
        row=flow_line(page,parent)
        for title,fn in (('Start alternate input',self.manager.start),('Stop alternate input',self.manager.stop),('Next control',self.manager.step),('Previous control',lambda:self.manager.step(-1))):
            button(page,row,title,fn)
        page.ttk.Label(parent,textvariable=self.manager.status,wraplength=750,style='Accent.TLabel').pack(anchor='w',fill='x',pady=10)
        page.ttk.Label(parent,text='Settings are saved; active scanning/dwell always starts explicitly for each session. Escape stops input. Hold controls are excluded. Function keys act once on release. Focus, account or privacy changes cancel pending input. Native file dialogs and OS menus keep their own input support. Selecting a field opens control actions and a small on-screen keyboard; your OS keyboard or dictation can also enter text.',wraplength=750).pack(anchor='w',fill='x',pady=8)
        row=flow_line(page,parent);button(page,row,'Import input profile…',self.import_profile);button(page,row,'Export input profile…',self.export_profile)

    def values(self):
        value={k:v.get() for k,v in self.variables.items()}
        for key in ('scan_ms','dwell_ms','tolerance'):
            text=str(value[key]).strip()
            if not text.isascii() or not text.isdigit():raise ValueError('Enter whole numbers for timing and pointer tolerance.')
            value[key]=int(text)
        return value
    def sync(self):
        for k,v in self.variables.items():v.set(getattr(self.manager.preferences,k))
    def apply(self):self.manager.apply(self.values());self.sync()
    def undo(self):self.manager.undo();self.sync()
    def reset(self):self.manager.apply(Preferences().to_dict());self.sync()
    def import_profile(self):
        from tkinter import filedialog
        from customization import read_document
        from creator_projects_ui import review_document
        path=filedialog.askopenfilename(parent=self.page.app.root,filetypes=[('Input profile','*.json')])
        if not path:return
        prefs=Preferences.parse(read_document(path))
        if review_document(self.page.app,'Review alternate-input profile',json.dumps(prefs.to_dict(),indent=2)+'\nInput will remain stopped until you select Start.',accept='Apply'):
            self.manager.apply(prefs.to_dict());self.sync()
    def export_profile(self):
        from tkinter import filedialog
        path=filedialog.asksaveasfilename(parent=self.page.app.root,initialfile='VRC-Eye-Alternate-Input.json',defaultextension='.json')
        if path:
            with Path(path).open('x',encoding='utf-8') as stream:json.dump(self.manager.preferences.to_dict(),stream,indent=2)
            self.manager.status.set('Input profile exported. It contains settings only.')


class ControlActions:
    def __init__(self,manager,source,stamp):
        self.manager=manager;self.source=source;self.stamp=stamp;self.closed=False;self.job=None;self.upper=False;self.key_page=0
        app=manager.app;self.app=app;self.previous_grab=app.root.grab_current()
        self.window=app.tk.Toplevel(source.winfo_toplevel());self.window.title('Alternate input · Control actions')
        self.window.transient(source.winfo_toplevel());self.window.geometry('760x570')
        body=app.ttk.Frame(window_body(self.window),padding=14);body.pack(fill='both',expand=True)
        app.ttk.Label(body,text='Control actions',style='Heading.TLabel').pack(anchor='w')
        app.ttk.Label(body,text='Switch scanning works here too. Close returns to the original control. Input is cancelled if that control or its workspace changes.',wraplength=680).pack(anchor='w',pady=8)
        self.notice=app.tk.StringVar();app.ttk.Label(body,textvariable=self.notice,wraplength=680).pack(anchor='w')
        self.buttons=[]
        def add(title,fn,parent=body):
            b=app.ttk.Button(parent,text=title,command=lambda:self.run(fn));b.pack(anchor='w',pady=3);self.buttons.append(b);return b
        kind=source.winfo_class()
        if kind in ('Entry','TEntry','Text','TSpinbox','Spinbox') and str(source.cget('state')) not in ('disabled','readonly'):
            self.keys=app.ttk.Frame(body);self.keys.pack(fill='x',pady=5);self.draw_keys()
            add('Letters / numbers / symbols',self.next_keys)
            add('Upper / lower case',self.change_case)
            add('Space',lambda:self.type_text(' '));add('Backspace',self.backspace)
            if kind=='Text':add('New line',lambda:self.type_text('\n'))
        if kind in ('TCombobox','TScale','Scale','TSpinbox','Spinbox','Treeview','TNotebook'):
            add('Previous / decrease',lambda:self.adjust(-1));add('Next / increase',lambda:self.adjust(1))
        if kind in ('Treeview','Text','Canvas','Listbox'):
            for label,axis,direction in (('Scroll up','y',-1),('Scroll down','y',1),('Scroll left','x',-1),('Scroll right','x',1)):
                add(label,lambda a=axis,d=direction:getattr(source,a+'view_scroll')(d,'units'))
        if kind=='Treeview':add('Read selected row',self.details)
        add('Return to control',self.close)
        self.window.protocol('WM_DELETE_WINDOW',self.close)
        self.window.bind('<Escape>',lambda _:self.close())
        self.window.grab_set()
        if self.buttons:self.buttons[0].focus_set()
        self.check()

    def valid(self):
        if not self.manager.valid(self.source,self.stamp):return False
        return self.app.root.grab_current() is self.window

    def run(self,fn):
        if self.closed:return
        if not self.valid():self.close();return
        try:
            fn()
            if not self.closed:self.stamp=self.manager.stamp(self.source)
        except (TclError,ValueError) as error:self.notice.set(str(error))

    def check(self):
        self.job=None
        if self.closed:return
        if not self.valid():self.close();return
        self.job=self.window.after(100,self.check)

    def draw_keys(self):
        for child in self.keys.winfo_children():child.destroy()
        chars=('abcdefghijklmnopqrstuvwxyz','0123456789','@._-+/:!?(),;\'"#%&*=')[self.key_page]
        for index,char in enumerate(chars):
            char=char.upper() if self.upper else char
            b=self.app.ttk.Button(self.keys,text=char,command=lambda c=char:self.run(lambda:self.type_text(c)))
            b.grid(row=index//7,column=index%7,sticky='ew',padx=2,pady=2)
        for column in range(7):self.keys.columnconfigure(column,weight=1)
    def next_keys(self):self.key_page=(self.key_page+1)%3;self.draw_keys()
    def change_case(self):self.upper=not self.upper;self.draw_keys()

    def type_text(self,text):
        source=self.source
        if source.winfo_class()=='Text':
            try:source.delete('sel.first','sel.last')
            except TclError:pass
        else:
            try:
                if source.selection_present():source.delete('sel.first','sel.last')
            except TclError:pass
        source.insert('insert',text)

    def backspace(self):
        source=self.source
        if source.winfo_class()=='Text':
            try:source.delete('sel.first','sel.last')
            except TclError:source.delete('insert -1 chars','insert')
        elif source.selection_present():source.delete('sel.first','sel.last')
        else:
            index=source.index('insert')
            if index>0:source.delete(index-1,index)

    def adjust(self,direction):
        source=self.source;kind=source.winfo_class()
        if kind=='TCombobox':
            values=source.cget('values')
            if values:
                index=source.current();source.current(max(0,min(len(values)-1,index+direction)))
                source.event_generate('<<ComboboxSelected>>')
        elif kind in ('TScale','Scale'):
            low,high=float(source.cget('from')),float(source.cget('to'))
            step=getattr(source,'_eye_keyboard_step',abs(high-low)/100)
            source.set(max(min(low,high),min(max(low,high),float(source.get())+direction*step)))
        elif kind in ('TSpinbox','Spinbox'):
            source.event_generate('<<Increment>>' if direction>0 else '<<Decrement>>')
        elif kind=='Treeview':
            rows=[]
            def visit(parent=''):
                for row in source.get_children(parent):
                    rows.append(row)
                    if source.item(row,'open'):visit(row)
            visit();selected=source.selection()
            if rows:
                index=rows.index(selected[0]) if selected and selected[0] in rows else -1
                row=rows[max(0,min(len(rows)-1,index+direction))]
                source.selection_set(row);source.focus(row);source.see(row)
        elif kind=='TNotebook':
            tabs=[t for t in source.tabs() if source.tab(t,'state')=='normal']
            if tabs:source.select(tabs[(tabs.index(str(source.select()))+direction)%len(tabs)])

    def details(self):
        source=self.source;self.close();self.manager.keyboard.table_details(source)

    def close(self):
        if self.closed:return
        self.closed=True
        if self.job:self.window.after_cancel(self.job)
        self.window.destroy();self.manager.dialog=None
        if self.manager.valid(self.source,self.stamp):
            if self.previous_grab is not None and self.previous_grab.winfo_exists() and self.app.root.grab_current() is None:self.previous_grab.grab_set()
            self.manager.keyboard.focus(self.source)
