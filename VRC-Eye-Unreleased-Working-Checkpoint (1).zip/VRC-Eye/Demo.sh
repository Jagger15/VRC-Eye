#!/usr/bin/env bash
set -u
eye_script=$(readlink -f -- "$0") || exit 1
exec bash "$(dirname -- "$eye_script")/Start.sh" --demo "$@"
