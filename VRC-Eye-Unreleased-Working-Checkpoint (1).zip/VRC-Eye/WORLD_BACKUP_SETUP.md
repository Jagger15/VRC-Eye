# VRCW world backups — VRC Eye 1.18

## Open the workflow

1. Extract the versioned release ZIP and run **Start.cmd**. Python 3.10+ with
   Tkinter is required. **World → World backups…** opens the dedicated window.
2. Paste a complete `wrld_…` ID or `https://vrchat.com/home/world/wrld_…` page
   link. A saved map's world ID can prefill the field; the map is not proof of
   ownership or permission. Names and instance membership are not accepted as
   file identities.
3. Click **Look up world** and sign in to your VRChat account if prompted.
   VRC Eye verifies the returned world ID and author. For someone else's world,
   it also checks whether that author is currently your friend. A pending friend
   request, public visibility, or merely having bytes cached does not qualify.
4. Select a platform/build. PC, Android, and iOS appear only when the API returns
   a usable file URL for that platform. Multiple builds require an explicit
   selection. The app never rewrites a URL to try a different variant.

World metadata uses the [world lookup](https://vrchat.community/reference/get-world).
Friendship uses the [friend-status lookup](https://vrchat.community/reference/get-friend-status)
for the world's author ID, not a display-name match. These are community-maintained
API definitions; service responses and access can change. VRC Eye's metadata
requests are spaced by 60 seconds, including the separate friendship request.
The window displays waiting progress. Cancel remains available.

## Choose the output

**Your world** means the API's author ID equals the signed-in account ID. Choose:

- **Unchanged backup:** preserves the selected build's exact bytes as `.vrcw`,
  including encryption or existing damage. It needs no recovery packages/key.
- **Decrypt with supplied key:** authenticates and recovers a supported
  encrypted bundle using the key you provide. It needs the optional packages.

**A friend's world** always requires **Decrypt with supplied key**. Ask the
world's actual author for the matching 32-byte key and permission to make this
backup. Paste the key and check the permission box. The app verifies friendship
and encrypted-chunk authentication; your checkbox records your statement of the
author's consent for this operation. It cannot independently verify a private
conversation or establish legal ownership of every bundled asset. An unrelated
user's key or a key that fails authentication cannot produce a recovered file.

Keys must be **64 hexadecimal characters or Base64 encoding exactly 32 bytes**.
Account passwords, authentication cookies, world IDs, and cache verification
hashes are not substitutes. The key field is masked. **Paste key** validates
the clipboard input without logging it. VRC Eye clears its key field when the
operation starts, the picker is cancelled, the world/build changes, or the window
closes. It never saves keys in settings, backup filenames, metadata, or logs.
It does not clear or manage your system clipboard/history, and does not promise
secure erasure of memory managed by Python or the operating system.

**Start.cmd** automatically prepares `cryptography`, `lz4` and the other app
dependencies in the release folder's `.recovery-env`. If setup cannot complete
offline, available core features still open; reopen **Start.cmd** when online to
retry missing packages. Dependency installation downloads packages but does
not inspect or change your worlds or cache. Missing dependencies stop before a
world download begins.

## Download a world

1. Select **Download from VRChat** as the source.
2. Choose the output mode, supply the key when needed, and confirm permission
   when the world belongs to a friend.
3. Click **Save VRCW…** and choose a new `.vrcw` filename outside the cache.
   The suggested name includes world ID, platform, Unity version, asset version,
   variant, and `backup` or `recovered`.
4. Watch download/recovery progress. On success, the window reports the actual
   saved path, size, whether decryption occurred, and the saved bytes' SHA-256.

The app downloads directly from the exact asset URL returned by the world API,
using the existing session for eligible API file requests. It does not drive
the in-game downloader or extract credentials from VRCX or your browser. HTTPS
hosts and redirects are restricted to the same approved VRChat asset hosts as
avatar transfers. Authentication cookies are limited to the exact API file host
and never forwarded to CDN hosts.

An unchanged download streams into a temporary file and publishes it only after
the transfer completes. Supplied-key recovery first downloads into a private
temporary folder beside the destination, then authenticates the complete
encrypted stream and publishes the recovered VRCW. A failed decrypt never leaves
an encrypted download masquerading as a recovered VRCW. Temporary output is
removed on normal errors/cancellation. Allow free disk space for both the
encrypted download and recovered copy. A forced process termination or power
loss may leave `.vrc-eye-world-*` or `.avatarwatch-vrca-*.part` temporary files;
remove those only after all transfers have stopped.

## Recover a matching cached world

1. Complete the same world lookup and build selection.
2. Change the source to **Matching cache entry**. The folder is suggested from
   the selected VRChat log folder and any custom `cache_directory` setting.
3. Browse to `Cache-WindowsPlayer` or its parent and click **Scan selected build**.
4. Choose an available result. The match uses the selected API file ID,
   file version/revision, and **that build's variant only**. A standard entry is
   never silently substituted for a security entry, or vice versa.
5. Supply the matching key for recovery and use **Save VRCW…** outside the cache.

The original `__data` is read only. Cache guards check locks, links, path
containment, and file identity before reading and again before publication.
Locked or changed entries require closing VRChat/rescanning. Scanning is bounded
to 25,000 entries, 5,000 results, and 20 seconds; a limited scan is reported.
An empty scan does not start a download automatically. VRCX's metadata database
is not a world bundle cache. Arbitrary local files or imported JSON cannot be
used to assert ownership or substitute a different bundle in this workflow.

## Limits and troubleshooting

- **World author is not you or a verified friend:** the operation stops even if
  the world is public. Sign in as the world author, or have that author supply
  the key/permission and establish the friendship before looking up again.
- **Access denied / no usable build URLs:** the account cannot use that API
  record/build. The app does not bypass the restriction or guess a cache match.
  A key is not an API access token. Restore legitimate access and refresh.
- **Permission check expired:** look up again. A new operation needs a permission
  snapshot less than five minutes old. A transfer already in progress may finish
  after that time, but session/account/selection changes cancel it.
- **Wrong key, damaged bytes, unknown format, or already readable input:** no
  recovered output is published. Check the selected version/variant with the
  author. An already readable owner build can be saved unchanged. This release
  does not offer an unchanged backup of a friend's world.
- **Existing destination:** choose a different name. Existing files are never
  overwritten, including if another process creates the destination mid-transfer.
- **File limits:** 2 GiB per download/recovery, 8 MiB of bundle metadata, 100,000
  blocks, 10,000 directory nodes. Larger/unsupported inputs stop with an error.

The recovery decoder supports one published chunked **AES-256-GCM** framing in
**UnityFS 6–8**, with uncompressed/LZ4 block metadata. It authenticates every
encrypted chunk and rebuilds the bundle's block-size metadata. The implementation
is shared with the existing avatar recovery feature; its
[format reference](https://github.com/VRC1337/VRChatStudio) is not bundled or run.
Other encryption/layouts are unsupported. Authentication does not validate all
unencrypted metadata, repair corruption, or guarantee that Unity/VRChat can load
the file. A VRCW is a built bundle, not the original editable Unity project,
source assets, or a reupload-ready project.

Automated tests use controlled HTTP responses, real temporary file operations,
and synthetic encrypted bundles. They do not establish compatibility with your
actual world or key. See **VALIDATION.md** for the full testing scope.
