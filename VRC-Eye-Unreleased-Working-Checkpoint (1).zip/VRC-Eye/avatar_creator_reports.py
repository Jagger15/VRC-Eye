"""Exact reviewed avatar reports and data-only handoffs; never follow asset paths."""
from dataclasses import dataclass
import csv
import hashlib
import html
import io
import json
from pathlib import Path
import time
import zipfile

from creator_reports import _sanitize, _clean_text

FORMATS = ('html', 'md', 'json', 'csv')
PROFILES = ('public', 'collaborator', 'private')
SCHEMA = 'vrc-eye.avatar-report.v1'
MAX_BYTES = 4 * 1024 * 1024
LIMITATIONS = (
    'Selected evidence only; unselected records, source assets and attachments are excluded.',
    'Source inspection, simulation, Unity tests and live observations are distinct evidence.',
    'Declared compatibility, discovered parameters and tested operation are different facts.',
    'A sent OSC message or observed echo does not confirm a visual change or completed action.',
    'Local build, published association and currently worn build are separate facts.',
)


@dataclass(frozen=True)
class AvatarReportPreview:
    document: str
    format: str
    record_ids: tuple
    profile: str
    omissions: tuple
    sha256: str
    avatar_id: str

    @property
    def bytes(self):
        return self.document.encode('utf-8')


def _classification(data):
    if data.get('simulated') or data.get('mode') == 'simulation':
        return 'Isolated simulation; not live verification'
    if data.get('mode') in ('source', 'unity', 'manual', 'live'):
        return data['mode'].capitalize() + ' evidence; applies only to the recorded context'
    return 'Selected local record; technical verification is not implied'


def _render(report, format):
    encoded = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if format == 'json':
        return encoded + '\n'
    if format == 'md':
        return ('# VRC Eye avatar creator report\n\n'
                'This report contains the exact reviewed record selection.\n\n' +
                '\n'.join('    ' + line for line in encoded.splitlines()) + '\n')
    if format == 'csv':
        stream = io.StringIO(newline='')
        writer = csv.writer(stream)
        writer.writerow(('schema', 'avatar_id', 'record_id', 'kind', 'evidence', 'data_json', 'limitations'))
        def cell(value):
            text = str(value)
            return "'" + text if text.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')) else text
        for record in report['records']:
            writer.writerow([cell(value) for value in (SCHEMA, report['avatar_id'], record.get('id', ''),
                record.get('kind', ''), record['classification'], json.dumps(record.get('data', {}), ensure_ascii=False),
                '; '.join(report['limitations']))])
        return stream.getvalue()
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">'
        '<title>VRC Eye avatar creator report</title><style>'
        'body{font:16px system-ui;max-width:1000px;margin:2rem auto;padding:0 1rem;color:#162338}'
        'pre{white-space:pre-wrap;overflow-wrap:anywhere;padding:1rem;background:#eef2f7;border-radius:8px}'
        '</style></head><body><h1>VRC Eye avatar creator report</h1>'
        '<p>Exact reviewed selection. Simulation is not live verification.</p><pre>' +
        html.escape(encoded) + '</pre></body></html>\n')


def preview_report(store, avatar_id, selected_ids, profile='public', format='html', *,
                   include_text=False, clock=time.time):
    if profile not in PROFILES or format not in FORMATS or type(include_text) is not bool:
        raise ValueError('Choose a supported report format and explicit disclosure profile.')
    if not isinstance(selected_ids, (list, tuple)):
        raise ValueError('Select explicit avatar record IDs.')
    identifiers = tuple(dict.fromkeys(selected_ids))
    if not 1 <= len(identifiers) <= 200:
        raise ValueError('Select between 1 and 200 records.')
    omissions = {'Unselected records, asset references and attachments are not read or included.'}
    records = []
    for identifier in identifiers:
        record = store.get(identifier)
        if not record or record.get('avatar_id') != avatar_id:
            raise ValueError('A selected record is missing or belongs to another avatar.')
        clean = _sanitize(record, profile=profile, include_text=include_text, omissions=omissions)
        clean['classification'] = _classification(record.get('data', {}))
        records.append(clean)
    report = dict(schema=SCHEMA, avatar_id=_clean_text(avatar_id), profile=profile,
                  generated_at=clock(), selected_record_ids=identifiers, records=records,
                  omissions=sorted(omissions), limitations=list(LIMITATIONS))
    if include_text and profile != 'private':
        report['limitations'].append('Free text was selected; review names and identifying language before sharing.')
    document = _render(report, format)
    if len(document.encode('utf-8')) > MAX_BYTES:
        raise ValueError('Narrow the selection; this report exceeds 4 MiB.')
    return AvatarReportPreview(document, format, identifiers, profile, tuple(sorted(omissions)),
                               hashlib.sha256(document.encode('utf-8')).hexdigest(), avatar_id)


def export_report(preview, path):
    if not isinstance(preview, AvatarReportPreview):
        raise TypeError('Export requires an exact reviewed avatar report preview.')
    content = preview.bytes
    if len(content) > MAX_BYTES or hashlib.sha256(content).hexdigest() != preview.sha256:
        raise ValueError('The preview changed; generate and review it again.')
    target = Path(path)
    if target.suffix.casefold() != '.' + preview.format:
        raise ValueError('The selected filename must match the report format.')
    with target.open('xb') as stream:
        stream.write(content)
    return str(target)


@dataclass(frozen=True)
class HandoffPreview:
    files: tuple
    sha256: str
    omissions: tuple

    @property
    def document(self):
        return '\n\n'.join('File: ' + name + '\n' + contents for name, contents in self.files)


def _handoff_hash(files):
    return hashlib.sha256(json.dumps(files, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def preview_handoff(manifest, *, include_description=False):
    """Generate docs from a selected validated contract; omit hierarchy and assets.

    Parameter semantics may be creator text. The exact frozen document is the
    inclusion review; no path, URL, package, model or preview is dereferenced.
    """
    from avatar_manifest import load_manifest
    if type(include_description) is not bool:
        raise ValueError('Description disclosure must be explicitly selected.')
    source = load_manifest(manifest)
    public = {key: source[key] for key in ('schema', 'schema_version', 'avatar_id', 'package_id',
        'platform', 'revision', 'build_id', 'stage', 'toolkit_version') if key in source}
    if 'toolkit_version' in public:
        public['toolkit_version'] = _clean_text(public['toolkit_version'])
    public['parameters'] = []
    param_keys = ('name', 'type', 'direction', 'default', 'neutral', 'min', 'max', 'synced',
                  'saved', 'privacy', 'module', 'validity', 'freshness_seconds', 'ephemeral',
                  'action', 'acknowledgment', 'rate_hz')
    for parameter in source.get('parameters', []):
        entry = {key: parameter[key] for key in param_keys if key in parameter}
        if include_description:
            entry['semantic'] = _clean_text(parameter.get('semantic', ''))
        public['parameters'].append(entry)
    public['modules'] = [{key: module[key] for key in ('id', 'version', 'dependencies', 'platforms', 'tier', 'costs', 'uninstall')
                         if key in module} for module in source.get('modules', [])]
    for module in public['modules']:
        if 'version' in module:
            module['version'] = _clean_text(module['version'])
    public['capabilities'] = source.get('capabilities', [])
    # Scope information stays in documentation; absence of source objects makes
    # this intentionally an integration contract, not a reimportable source dump.
    portable = dict(schema='vrc-eye.avatar-handoff.v1', contract=public,
                    limitations=list(LIMITATIONS), source_assets_included=False)
    lines = ['VRC Eye Avatar Toolkit — portable handoff', '',
             'Review the supplied contract before enabling a supported local integration.',
             'This package contains documentation and selected contract data only.',
             'No avatar source assets, private hierarchy, images, credentials or executable extensions are included.', '',
             'Declared modules:']
    lines.extend('  - ' + _clean_text(m['id']) + ' ' + _clean_text(m.get('version', '')) for m in public['modules'])
    lines.extend(['', 'Compatibility and repair:',
        '1. Match avatar association, platform and manifest revision before applying a preset.',
        '2. Compare missing parameter names, types and direction against the selected contract.',
        '3. Use neutral/unavailable values while a provider or acknowledgment is absent.',
        '4. A runtime preset cannot add a missing prefab; use the authorized Unity project for authoring.',
        '5. Review public avatar state, peer sharing and report disclosure separately.',
        '6. Use menu/desktop alternatives while a wrist interface is unavailable.',
        '7. Keep test mode and actual runtime confirmation in the support report.',
        '8. Shared manifests do not grant editor, account, avatar or world-control permissions.', '', *LIMITATIONS])
    files = (('avatar-contract.json', json.dumps(portable, indent=2, ensure_ascii=False, allow_nan=False) + '\n'),
             ('READ-ME.txt', '\n'.join(lines) + '\n'))
    if sum(len(contents.encode('utf-8')) for _, contents in files) > MAX_BYTES:
        raise ValueError('The portable handoff exceeds 4 MiB.')
    return HandoffPreview(files, _handoff_hash(files),
                          ('Source assets', 'Hierarchy', 'Preview images', 'Local paths', 'Unselected notes', 'Executable packages'))


def export_handoff(preview, path):
    if not isinstance(preview, HandoffPreview) or preview.sha256 != _handoff_hash(preview.files):
        raise ValueError('Generate and review an unchanged handoff preview first.')
    if tuple(name for name, _ in preview.files) != ('avatar-contract.json', 'READ-ME.txt'):
        raise ValueError('Only the generated data contract and instructions are permitted.')
    if sum(len(contents.encode('utf-8')) for _, contents in preview.files) > MAX_BYTES:
        raise ValueError('The portable handoff exceeds 4 MiB.')
    target = Path(path)
    if target.suffix.casefold() != '.zip':
        raise ValueError('Choose a .zip filename.')
    with target.open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as archive:
            for name, contents in preview.files:
                archive.writestr(name, contents.encode('utf-8'))
    return str(target)
