# Avatar Creator design input — 1.19.3

The original supplied design is preserved byte-for-byte after the source marker.
The coverage map describes the implemented 1.19.3 surfaces and their boundaries;
it does not turn proposed or native-dependent capabilities into verified results.

See AVATAR_CREATOR_SETUP.md, AVATAR_TOOLKIT_SETUP.md and VALIDATION.md for usage
and the required native checks. The release uses local file-based Unity exchange,
explicit localhost OSC and optional existing peer/SteamVR services.


| Specification features | Implemented surface and boundary |
| --- | --- |
| 1–4: Avatar Link, Unity toolkit, parameter installer, validator | Local OSC broker and reviewed fixed-module editor installer; declarative/source validation. Native Unity and VRChat behavior still requires verification. |
| 5–16: Wrist, status, safety, battery, streamer, music, camera, DND/AFK, connection, hardware, resource, media | Twelve editor-authored primitive starter modules plus local provider/mapping controls. No arbitrary avatar modification, universal media capture or native account-status mutation. |
| 17–18: Contacts and PhysBone debugging | Self-only starter Contact controls, source declarations/validation, worksheets and guided interaction tests. No arbitrary live PhysBone inspector or remote participant control. |
| 19: Profiles | Installation/runtime distinction, exact compatibility preview and reviewed runtime values; unsupported values remain unsupported. |
| 20–21: Authorized hierarchy and manifests | Bounded creator-supplied snapshots, contract validation, provenance and semantic comparison. No model discovery or automatic asset fetching. |
| 22–23: Authorized preview and generic mannequin | Static permitted references and optional Unity-rendered source PNG; interactive generic geometric demonstration. General-purpose imported 3D model rendering/retargeting is not included. |
| 24–25: Workspace and parameter debugger | Dedicated tabs, workspace/context isolation, live values, ownership/freshness evidence, freeze and selected trace/bookmark records. External writers remain uncertain. |
| 26: Property conflicts | Supplied-binding overlap/subtree analysis and investigation worksheet. Full arbitrary animator state-graph analysis and automatic controller repair are not included. |
| 27: Tests and Black Box | Frozen guided runs, isolated demonstrations, source validation and selected incident records/bookmarks. No claim that a simulated pass verifies the client. |
| 28–29: Builds and platform budget | Separate revision records, semantic manifest comparisons, parity checks, scoped baselines and estimated plans. Generated-build measurements need supplied evidence. |
| 30–31: Rig/fit/viewpoint and raycast tools | Typed worksheets, attachment simulation and guided hit/miss/unavailable tests. No live skeleton reconstruction or automatically authored raycast backend. |
| 32: Creator overlay / universal controls | Optional shared overlay presenter and desktop actions. Availability and capture visibility depend on the native runtime; desktop tools remain available. |
| 33–34: Module SDK/composer and handoff | Finite data-only recipes, manifest contract, generated portable instructions and reviewed exports. Custom recipes require creator implementation in Unity. |
| 35–36: Test-world and peer playtests | Manual station workflows and optional selected peer coordination; separate world authority, no raw remote OSC forwarding or source transfer. |

This release's Linux checks do not constitute native Windows, Unity, SteamVR, audio-device, Contact or uploaded-avatar verification. Use the editor package's native checklist and the recorded evidence modes when validating a release for distribution.

--- BEGIN ORIGINAL SUPPLIED TEXT (unchanged bytes) ---
The central idea should be:

> **Creators deliberately make an avatar compatible with VRC Eye; VRC Eye then provides local information, controls, diagnostics, and optional sharing through that compatibility.**

That preserves the direction we established previously: **back-burner, optional, external-first, and useful without a custom client.** It also leaves room for a substantial creator toolkit without turning the rest of VRC Eye into software that requires Unity projects, specially prepared avatars, or an online service.

The first 23 sections below expand your existing list. The later sections are additional proposals. This is a design specification—not a claim that these features have already been implemented.

# The overall architecture

Before individual features, I would separate this into five cooperating pieces.

| Piece                                  | Its responsibility                                                                        | What it should not require              |
| -------------------------------------- | ----------------------------------------------------------------------------------------- | --------------------------------------- |
| **VRC Eye Avatar Workspace**           | Profiles, local notes, manifests, diagnostics, previews, and creator-facing UI            | A running VRChat client                 |
| **VRC Eye Avatar Link**                | Communication with deliberately exposed avatar parameters and supported VRChat interfaces | A custom client                         |
| **Unity Avatar Toolkit**               | Installing, configuring, validating, testing, and exporting avatar integrations           | A VRC Eye account or server             |
| **Avatar modules and prefabs**         | Creator-authored displays, controls, and visual responses inside the avatar               | Arbitrary scripts running inside VRChat |
| **Optional sharing and collaboration** | Sharing selected test results, compatibility information, and playtest events             | Uploading the avatar’s source assets    |

There is an important technical boundary here. VRChat supports avatar parameter communication through OSC, but an uploaded avatar is not a place where we can install an arbitrary background application. VRChat restricts which components can operate on avatars; ordinary custom scripts are not a general-purpose avatar runtime. Our Unity code therefore does its work **during authoring and building**, while the uploaded integration consists of supported avatar components, animations, parameters, and assets. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

This gives us two fundamentally different operations:

**Preparing an avatar:** The creator uses Unity to install and build compatible components.

**Using an already compatible avatar:** VRC Eye communicates with the parameters and interfaces that were deliberately made available.

An external companion should not promise to attach a functional wrist display to any arbitrary avatar currently being worn. Without suitable source access or an existing compatible integration, the fallback is a desktop or SteamVR interface—not pretending we can rewrite the avatar.

## Local operation needs more than one definition

I would give this subsystem three operating profiles.

**Offline Authoring** allows local project inspection, already-available previews, manifests, notes, validation, and simulated tests. It does not depend on VRChat, peer discovery, or a VRC Eye service. Installing missing dependencies or publishing an avatar would remain separate, explicitly online operations.

**Local Companion** permits communication between VRC Eye and supported applications on the same computer. Battery displays, local media effects, parameter controls, and many diagnostics fit here. VRChat may itself be online, but VRC Eye does not need an Eye-to-Eye connection.

**Shared Companion** adds deliberately enabled collaboration or public presentation. Each shared capability gets its own permission.

The subtle point is that **“VRC Eye is not connected to a server” does not mean “my avatar is not broadcasting information.”** VRChat’s `Synced` expression-parameter setting controls whether parameter state is sent to other players. That is a separate channel from VRC Eye networking. [VRChat Creators](https://creators.vrchat.com/avatars/expression-menu-and-controls/)

Consequently, privacy needs separate controls for local display, avatar-visible state, Eye-to-Eye sharing, and report exports.

For sensitive information, I would use **separate private and public parameters**. The private channel might contain an exact battery level; the public channel might contain only a user-approved “taking a break soon” status.

The synchronization setting belongs to the authored avatar configuration. Runtime privacy should therefore work by **withholding sensitive values from preconfigured public channels**, not by pretending VRC Eye can dynamically rewrite the avatar’s parameter asset.

---

# Part I — Expanding the existing 23 features

## 1. VRC Eye Avatar Link

**Avatar Link should be the runtime communication layer—not the Unity installer, not a model downloader, and not a client modification.**

Its job is to determine what the current avatar deliberately exposes, connect appropriate VRC Eye features to it, and handle transitions safely.

### Discovery and compatibility

VRChat provides OSC avatar-parameter input/output and an avatar-change notification. OSCQuery additionally supports discovering endpoints and their capabilities. Those are the appropriate starting points for a stock-client implementation. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

I would combine that information with an optional creator manifest.

Discovery answers:

> “These parameters are available.”

The manifest answers:

> “These parameters belong to the battery module, use these ranges, and should behave this way.”

Observed feedback answers:

> “We have actually seen this particular integration respond.”

Those are different evidence levels. The interface should distinguish **declared compatibility**, **discovered parameters**, and **tested operation**.

A matching name alone should not produce a large green “Fully compatible” badge.

### The connection lifecycle

Avatar Link should have explicit states such as unavailable, discovering, awaiting avatar initialization, compatible, partially compatible, suspended, and disconnected.

On an avatar change, it should invalidate pending work for the old avatar, stop old parameter writers, discard queued commands, identify the new parameter contract, and wait for a safe initialization state before rearming controls.

This prevents a surprisingly serious class of bugs:

> A wrist-button request from Avatar A must not execute after the user has switched to Avatar B.

Profiles should be associated with the relevant account context, avatar identifier, platform variant, and known manifest revision—not just a display name.

### Parameter direction must be explicit

I would define names from the avatar’s perspective:

| Proposed parameter        | Direction     | Purpose                               | Default handling       |
| ------------------------- | ------------- | ------------------------------------- | ---------------------- |
| `EYE_In_Heartbeat`        | Into avatar   | Communication freshness input         | Local, transient       |
| `EYE_Out_HeartbeatAck`    | Out of avatar | Authored response to heartbeat        | Local, transient       |
| `EYE_In_BatteryLeft`      | Into avatar   | Normalized battery reading            | Private                |
| `EYE_In_BatteryLeftValid` | Into avatar   | Whether that reading is usable        | Private                |
| `EYE_In_PublicStatus`     | Into avatar   | Deliberately public status selection  | Neutral until approved |
| `EYE_Out_CameraRequest`   | Out of avatar | Request for a permitted camera action | Local request          |
| `EYE_In_CameraResult`     | Into avatar   | Result or acknowledgment state        | Local feedback         |

These are proposed names, not existing VRChat standards.

Direction matters because a displayed state should not accidentally be interpreted as an instruction. “Camera is active” and “activate camera” must not share a parameter.

### Acknowledgment is not the same as success

Avatar Link should distinguish:

**Sent:** VRC Eye transmitted a value.

**Observed:** A corresponding parameter update was received.

**Module acknowledged:** A deliberately authored response was observed.

**Action confirmed:** The actual destination reported completion, where such reporting exists.

An OSC echo is not proof that a material changed, a camera captured a photo, or another person saw a badge.

For important operations, the UI should be comfortable saying **“requested; completion unconfirmed.”**

### Security and capability boundaries

Avatar Link should expose a small action vocabulary: select a profile, acknowledge a reminder, request a photo, pause a local effect, or create a diagnostic bookmark.

It should not expose a generic “execute command,” “run script,” or “open whatever URL this avatar supplies” facility.

A local OSC signal also should not be treated as cryptographic proof of avatar authorship or user intent. High-impact actions need stronger local confirmation than an arbitrary parameter change.

Finally, OSC configuration files should be a compatibility fallback, not a permanent dependency. VRChat documents that Build & Test does not save those configurations in the same way as published avatars, and describes the configuration-file mechanism as potentially changeable. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

---

## 2. Unity Avatar Toolkit

The Unity Toolkit should be the **creator’s workbench** for making an avatar compatible with Avatar Link.

The basic workflow would be:

> Select avatar → choose modules → inspect proposed changes → install non-destructively → validate → test → export compatibility information.

### Packaging and project integration

I would distribute it as a properly versioned VPM package, with clear SDK dependencies and separate editor assemblies. VPM is the package-management system used by the Creator Companion, and its documentation describes dependency manifests and the separation needed for editor tooling. [VRChat Creator Companion](https://vcc.docs.vrchat.com/vpm/?utm_source=chatgpt.com)

The package should not silently upgrade an entire project merely because a creator wants a battery display.

Instead, it should report:

> “This project’s SDK is outside the toolkit’s tested range. Existing modules can be inspected; installation requires a supported combination.”

Offline inspection should still work when all required packages are already present.

### Cooperating with existing avatar tooling

We should avoid building a second, incompatible controller-merging ecosystem unnecessarily.

Modular Avatar already provides parameter and animator integration tools, while NDMF provides a framework for non-destructive avatar build processing. Those are sensible integration candidates, subject to our own compatibility testing. [Modular Avatar](https://modular-avatar.nadena.dev/docs/reference/merge-animator?utm_source=chatgpt.com)

The toolkit could support a preferred non-destructive backend and a more limited explicit-install workflow. It should not quietly run multiple overlapping installation paths.

### Editor connection versus exported files

There should be two ways to get information into VRC Eye.

A **file-based workflow** exports a manifest and optional preview assets. This is simple, inspectable, and works without a persistent connection.

An **optional local editor connection** provides live selection, validation results, preview commands, and test feedback while Unity is open.

The editor connection must be scoped to the selected project and avatar. Credentials for that connection belong in local application settings, not in prefab assets that might be distributed.

### Presentation modes

Casual users should see module choices and understandable warnings. Advanced users should see parameter layouts, controller integration, and build details. Creator and Developer views can expose deeper tooling without requiring separate application builds.

The important distinction is that changing the UI mode does not establish authorship or grant access to someone else’s assets.

---

## 3. Automatic parameter installer

This is one of the most valuable features—and one of the easiest to implement badly.

“Automatic installer” should mean:

> **A dependency-aware installer that can explain, reproduce, repair, update, and undo its own changes.**

It should not mean “append some parameters and hope.”

### Pre-install analysis

Before modifying anything, it should inspect the selected avatar, expression assets, controller assignments, module dependencies, platform variants, and existing integrations.

It should identify collisions by **meaning and type**, not just by spelling.

For example:

> “An existing `EYE_In_Status` parameter is a Float, but this module expects an Int.”

That is not an invitation to silently change the existing parameter.

The creator should be offered an explicit remapping, a compatible existing definition, or cancellation.

### Parameter budgeting

VRChat currently documents a 256-bit synchronized custom-parameter budget. A synchronized Bool costs one bit; an Int or Float costs eight. Cross-platform synchronization also depends on parameter position and type, not simply matching names. [VRChat Creators](https://creators.vrchat.com/avatars/animator-parameters/)

The installer should show both **total resulting cost** and **the incremental cost of the proposed installation**.

For example, a proposed public package containing one status Int and two Boolean indicators would consume ten synchronized bits. Exact private battery readings could remain unsynchronized.

However, packing several states into one Int is not automatically superior. It can make independent states harder to represent and increase animator complexity. The installer should optimize for understandable behavior, not just the smallest number.

### Persistence is a design decision

Ephemeral values—heartbeat state, pending commands, current resource warnings, capture acknowledgments—should not be restored as though they were user preferences.

Customization choices, such as a selected visual theme, may be reasonable to save. VRChat’s `Saved` setting preserves parameter values across relevant reloads, while menus have a documented limit of eight controls per menu. Both should be accounted for automatically. [VRChat Creators](https://creators.vrchat.com/avatars/expression-menu-and-controls/)

The installer should create submenus where needed rather than overwrite existing menu entries.

### Stable external names and private internal names

Internal implementation parameters can be renamed to avoid collisions.

Externally consumed parameters need a stable contract—or an accurately exported mapping.

This becomes especially important with build processors. Modular Avatar can rename parameters, so a manifest created before processing may no longer describe the final avatar correctly. [Modular Avatar](https://modular-avatar.nadena.dev/docs/reference/parameters)

Therefore:

> **The final compatibility manifest must reflect the generated avatar, not merely the source prefab.**

### Non-destructive, repeatable installation

Installing the same module twice should not create duplicate menus, controllers, or Contacts.

Each installed module should have a stable installation identifier and an ownership record describing which assets and references belong to it.

Updates should show a change preview. Removal should delete or detach only toolkit-owned material, while preserving anything another module still references.

Undo support is useful, but it is not enough by itself for every file operation. Installation should also maintain an explicit change journal and appropriate backups of modified assets.

### Cross-platform consistency

A PC build might contain a full wrist interface while a mobile build contains only a small indicator. The installer still needs to preserve their compatible synchronized layout.

Removing a visual module from one platform must not inadvertently shift every later parameter into the wrong position.

The toolkit should validate the resulting platform pair together, rather than treating each platform as an unrelated avatar.

### What installation must never do silently

It should not globally change Write Defaults, replace the creator’s FX controller, rewrite unrelated expression parameters, publish an avatar, detach its upload identity, or compress assets destructively.

Those are separate operations with separate consequences.

---

## 4. Unity validator

The validator should answer more than “Will the SDK accept this?”

It should answer:

> “Will these modules work together, what evidence supports that conclusion, and what has not been tested?”

### Three validation stages

**Source validation** checks the creator’s project configuration.

**Generated-build validation** checks the result after installation, merging, renaming, stripping, and platform processing.

**Runtime verification** checks actual signals and interactions in a controlled test.

Passing one stage must not imply that the others passed.

A source prefab can look correct while a build processor changes its parameter names. A built avatar can be structurally correct while its wrist control is difficult to reach.

### Findings need evidence

Each finding should contain its severity, affected object or asset, technical explanation, likely user-visible symptom, and proposed remedy.

An example:

> **Blocking:** Battery display expects `EYE_In_BatteryLeftValid`, but the generated controller does not contain that parameter. The display may show a number without knowing whether it is current.

The validator should distinguish **error**, **warning**, **information**, and **not tested**. “Not tested” must not be disguised as a pass.

### Validation categories

Parameter checks should cover names, types, ranges, direction, defaults, persistence, synchronization, and competing writers.

Controller checks should cover missing references, unreachable states, unintended transitions, incorrect bindings, and modules that modify unrelated avatar properties.

Prefab checks should cover anchors, missing meshes, excessive dependencies, disabled receivers, and unsupported platform assumptions.

Privacy checks should trace whether private inputs can influence public outputs.

Performance checks should inspect the final build. VRChat’s ranking system counts components even when they are disabled, so “this expensive module starts turned off” is not equivalent to removing its build-time cost. [VRChat Creators](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/)

### Fixes should be scoped

A safe fix might add a missing toolkit-owned parameter or reconnect a known module reference.

A potentially destructive fix—changing a controller-wide setting or restructuring the rig—should provide a proposed diff and require review.

The validator should never turn into a “Fix Everything” button that makes the project unrecognizable.

---

## 5. Wrist controller prefab

The wrist controller should be a **small, avatar-native interface**, not a miniature desktop crammed onto a forearm.

### Physical placement

The installer should support left-wrist, right-wrist, forearm, and manually assigned anchors.

Placement needs separate controls for position, orientation, display size, and interaction volume. Adjusting visual size should not accidentally make the touch target enormous.

Humanoid bone detection can suggest an anchor, but the creator should confirm it. Generic rigs and unusual avatars need manual attachment support rather than incorrect assumptions.

The module should animate its own objects, not impose a wrist pose or modify the avatar’s overall arm behavior.

### Interaction design

A useful first version might contain a small number of pages: status, battery, local controls, and diagnostics.

Frequently used controls should remain reachable without a deep menu structure. Important actions should have clear feedback and an obvious cancel path.

A button should indicate at least three distinct things: being touched, being accepted, and having completed its action.

Those should not all be the same flash.

### Alternatives are part of the feature

Every meaningful wrist action should have an expression-menu or external UI equivalent.

That covers desktop mode, inaccessible wrist placement, tracking problems, clothing that obscures the display, and users who simply dislike reaching across their body.

A wrist interface is an optional convenience, not the only route to safety controls or essential functionality.

### Visual behavior

I would provide compact and expanded forms, adjustable contrast, icon-plus-label options, and a low-motion presentation.

The display should also have a visibility policy: owner-oriented interface, deliberately public display, or decorative shell with private controls elsewhere.

Owner-only rendering must not be marketed as protection against the wearer’s own screenshots or recording. Capture visibility needs testing in the actual rendering paths.

---

## 6. Status display prefab

The status display is the **presentation component**. It should not own the underlying logic for every status it displays.

That logic belongs in a shared status resolver.

### Separate status dimensions

A single “status” value quickly becomes ambiguous.

Someone can be AFK, recording, connected to Avatar Link, and experiencing a battery warning simultaneously.

I would distinguish:

**Availability:** available, busy, away, or manually selected quiet time.

**Activity:** recording, taking photos, testing an avatar, or listening to media.

**System condition:** connected, stale, degraded, or unavailable.

**User-selected message:** an authored symbolic status such as “please wave first.”

A display may choose a simplified combination, but the underlying system should not discard those distinctions.

### Presentation rules

Each status should define its source, priority, duration, public/private setting, and stale behavior.

For example, “manual quiet mode” should not disappear because an automatic media detector briefly reports playback.

A transient resource warning should not permanently replace the user’s chosen social status.

### Text limitations

For avatar-native displays, I would initially use finite icon and label sets, driven by supported parameter types, rather than promise arbitrary text rendering from ordinary OSC avatar parameters. The documented avatar parameter interface uses Bool, Int, and Float values. [VRChat](https://docs.vrchat.com/docs/osc-avatar-parameters)

Free-form local text can still exist in the VRC Eye window or overlay.

A creator could later author a more sophisticated text module, but it should be a separately budgeted feature—not an invisible assumption behind every status display.

---

## 7. Safety bracelet

The safety bracelet should be a **deliberate local control surface**, not an automatic authority that declares the user “safe.”

### What it could activate

A bracelet action could request an explicitly configured VRC Eye safety profile: quiet companion notifications, pause media-reactive effects, hide private overlays, stop optional outgoing sharing, or activate creator-authored low-stimulation avatar settings.

Where a particular VRChat action has an independently supported route, it could be included. Where it does not, the UI should show the limitation or provide an appropriate manual handoff.

An avatar parameter by itself should not be treated as universal access to VRChat’s safety settings.

### Activation and deactivation

Entering a protective local mode should be easy and consistent. Exiting it should be deliberate enough to prevent an accidental touch from immediately undoing the change.

The bracelet should show what was actually applied:

> “VRC Eye notifications quieted. Media effects paused. Public status update unconfirmed.”

That is more useful than a single reassuring check mark.

### Friend alerts

An optional Eye-to-Eye message could say that the user enabled their chosen safety mode.

It should be separately enabled, recipient-limited, rate-limited, and free of unnecessary context. It should not automatically attach location history, private notes, audio, or diagnostic dumps.

The bracelet remains fully useful when no peers are connected.

### Failure handling

The local application should expose the same action through an accessible alternative. A lost avatar connection must not make the safety feature unreachable.

And if an avatar-side indicator becomes stale, the application must not claim it has successfully updated or hidden that indicator.

---

## 8. Battery display

The battery display should be built around **device identity, data validity, and useful prioritization**.

OpenVR exposes battery-percentage and charging properties, but our integration should still treat support and reliability as provider- and device-dependent. [GitHub](https://github.com/ValveSoftware/openvr/blob/master/headers/openvr.h?utm_source=chatgpt.com)

### Device assignment

The user should map devices to meaningful roles: left controller, right controller, headset where supported, or individually named trackers.

Those mappings should survive ordinary reconnects where a stable identifier is available.

Raw device identifiers should remain local. A public avatar display does not need to broadcast serial numbers or a complete hardware inventory.

### Presentation choices

The module could offer individual device readings, a compact lowest-battery indicator, or a summary such as “all tracked devices above your warning threshold.”

A useful design might show the two controllers continuously while cycling through trackers on a secondary page.

The user should be able to exclude irrelevant devices from the “lowest battery” calculation.

### Unknown is not empty

Missing, unsupported, stale, disconnected, charging, and genuinely empty are different states.

A lost device must not suddenly appear to have zero percent charge. A stale last-known reading should be marked as stale rather than presented as current.

The avatar-side display therefore needs a validity state, not just a number.

### Alerts and updates

Battery values rarely need high-frequency transmission. The application should send meaningful changes and occasional freshness updates, using a configurable policy.

Warnings should use hysteresis: crossing into a warning state and leaving it should require different conditions, preventing repeated alerts around one threshold.

Remaining-runtime estimates should be optional and explicitly uncertain unless the application has enough relevant history to justify them.

---

## 9. Streamer badge

The streamer badge should distinguish **declared intent** from **observed application state**.

### Different meanings

“I identify as a streamer,” “my recording software is running,” “recording is active,” and “a live stream is active” are not interchangeable.

The badge should support a manual mode and optional provider-backed modes.

OBS’s WebSocket protocol exposes stream and recording status requests, giving us a documented integration path for that provider rather than relying on process detection. [GitHub](https://github.com/obsproject/obs-websocket/blob/master/docs/generated/protocol.md?utm_source=chatgpt.com)

### Separate recording-related states

A complete implementation should distinguish live streaming, local recording, paused recording, replay-buffer activity, and unavailable provider information.

Each can have a different user-selected presentation.

The status provider should be read-only by default. Showing a badge does not require permission to start or stop a broadcast.

### Privacy

The avatar only needs the coarse status that the user approved.

It does not need the stream key, destination account, recording path, scene names, window titles, or source list.

Those details should never become expression parameters or appear in a normal shared diagnostic report.

### Disconnect behavior

Losing the OBS connection should not automatically mean “recording stopped.”

The honest state is “unknown.” The visual policy might retain a cautionary symbol or show an unavailable indicator, but it should not falsely assure others that recording is inactive.

Finally, the badge cannot guarantee that everybody sees it, and it is not proof of consent from people nearby. It is a communication aid.

---

## 10. Music visualizer

The music visualizer should be a **local signal-processing feature with a deliberately small avatar output contract**.

### Audio-source selection

The user should select a specific supported source, rather than the application quietly analyzing every sound on the computer.

Windows provides process-specific loopback capture mechanisms, which makes selected-application analysis a practical design target on supported configurations. [Microsoft Learn](https://learn.microsoft.com/en-us/samples/microsoft/windows-classic-samples/applicationloopbackaudio-sample/?utm_source=chatgpt.com)

A source failure should produce silence or an unavailable state—not an automatic switch to whole-system capture.

Microphone input should be separate and disabled unless deliberately selected.

### Processing pipeline

The application could calculate overall energy, several frequency bands, a smoothed intensity envelope, and an optional beat estimate.

Those should pass through configurable gain, normalization, smoothing, and a silence gate before reaching the avatar.

The useful outputs are not raw audio samples. They are small control signals such as:

> “Low-frequency intensity is 0.6; overall activity is 0.4.”

This lets a creator drive emission, a meter, a restrained particle effect, or an authored animation.

### Local versus remote presentation

A smooth local effect should not be assumed to reproduce with precise musical timing for other players. VRChat’s custom parameter synchronization is not a guaranteed high-rate music transport. [VRChat Creators](https://creators.vrchat.com/avatars/animator-parameters/)

I would therefore separate a detailed local visualizer from a simpler optional public effect.

The public variant could use one intensity signal and a broad activity state, with smoothing designed for imperfect updates.

### Performance and comfort

A first release should favor a few inexpensive visual properties over dozens of independent objects or lights.

Intensity ceilings, motion limits, and non-flashing themes should be available. The module should fade to its neutral state when the audio source becomes silent or unavailable.

A demo mode should use synthetic test data, clearly labeled, without capturing any audio.

---

## 11. Camera-control prefab

This feature has a stronger stock-client foundation than a vague “maybe through a bridge” description would suggest.

VRChat documents OSC camera controls including mode, pose, capture, delayed capture, and multiple camera options. [VRChat](https://docs.vrchat.com/docs/vrchat-202533)

### Separate the control prop from the real camera

The avatar prefab is the button panel or decorative controller.

VRC Eye is the request broker.

VRChat’s supported camera interface is the destination.

The prefab itself does not become a general-purpose script controlling the camera directly.

A simple interaction would be:

> Touch shutter control → avatar emits a local request → VRC Eye validates the request → supported camera action is sent → feedback is displayed where available.

### Useful controls

An initial module could provide capture, delayed capture, close, and selected camera-mode controls.

A more advanced profile could expose tested lock, smoothing, framing, and other supported settings.

Each action should be capability-checked. The presence of a camera module should not imply that every control works on every platform or client version.

### Avoid duplicate actions

Repeated receipt of a request must not create an uncontrolled burst of photographs.

The broker needs debouncing, request identifiers where the authored protocol supports them, a cooldown, and conservative retry behavior.

For capture actions, uncertainty is preferable to blindly repeating a request:

> “Capture requested; no independent completion confirmation.”

### Camera pose is a separate problem

A wrist prop’s authored transform does not automatically provide VRC Eye with its live world-space pose.

Therefore, “make the real camera follow this physical prop” requires an additional supported pose source and a verified coordinate mapping. It should not be promised merely because camera pose can be controlled.

A fixed preset, a user-defined camera path, and live prop tracking are three different capabilities.

### Sharing and recording

Eye-to-Eye photo coordination should initially share cues and readiness, not grant another person unrestricted control of the user’s camera.

Any remote shutter feature would need explicit session-scoped permission and visible local feedback.

---

## 12. DND/AFK indicators

This feature needs a strong distinction between **native VRChat state**, **VRC Eye state**, and **manual presentation**.

VRChat exposes built-in animator parameters including AFK, and its documentation describes built-in parameters as read-only. We should consume supported state rather than assume we can write arbitrary native status through an avatar parameter. [VRChat Creators](https://creators.vrchat.com/avatars/animator-parameters/)

### Three possible sources

A native AFK indicator reflects the relevant VRChat state when available.

A VRC Eye quiet-mode indicator reflects the companion’s own notification policy.

A manual indicator reflects a user-selected message.

These should have separate labels internally, even when a creator chooses similar artwork.

### Priority rules

Manual intent should have predictable precedence.

For example, a user who deliberately chooses “please do not interrupt” should not have that message cleared because an activity heuristic notices movement.

Likewise, a detected AFK state should not automatically enable every VRC Eye privacy setting unless that behavior was configured.

### Avoid overinterpreting inactivity

A lack of input can suggest inactivity, but it is not proof that someone is away.

The UI should identify inferred states as inferred and make them easy to override.

### Native DND is not just a badge

Showing a DND symbol on the avatar does not necessarily change account status, invitation behavior, or notification delivery.

Those would be separate actions through independently supported interfaces.

The display should never imply otherwise.

---

## 13. VRC Eye connection indicator

A single connection light is too ambiguous unless we define exactly what it means.

### Separate connection domains

The user may have a functioning local avatar connection while Eye-to-Eye networking is disabled.

They may have peers connected while the current avatar has no compatible parameters.

Unity might be connected to VRC Eye while VRChat is closed.

I would therefore expose separate internal states for the editor connection, local Avatar Link, relevant data providers, and optional peer networking.

A compact avatar icon can represent a selected subset, but its tooltip and documentation should explain the meaning.

### Heartbeat design

A heartbeat should change over time, and an authored response should demonstrate that the intended module is participating.

A constant Boolean set to true at startup is not a health check. It can remain true long after the application stops functioning.

The module should have a tested freshness timeout and default to an unconfirmed state on initialization.

### Important limitation

An avatar-side timeout depends on its animation logic continuing to evaluate.

If the avatar’s animator is stopped, culled, or otherwise not progressing as expected, the display may itself stop updating. Consequently, the indicator is **a best-effort status display**, not a reliable security signal.

A person seeing a glowing icon should not interpret it as authenticated proof that VRC Eye is currently connected.

### Useful failure information

The application should explain whether the problem is endpoint discovery, a missing parameter, a mismatched manifest, no response, a suspended profile, or a disconnected provider.

“Not connected” alone is insufficient for troubleshooting.

---

## 14. Hardware-status parameters

This should be a **normalized telemetry interface**, rather than a collection of arbitrary hardware-specific numbers.

### A shared value model

Every internal measurement should carry a value, unit, source, sample time, validity state, and intended privacy level.

For example:

> Left-controller battery: 64%, reported by the selected provider, sampled recently, private.

The avatar parameter representation may be simpler, but the application should preserve the richer internal record.

### Potential categories

Useful categories include device availability, charging state, tracking availability where supported, application resource pressure, selected audio-device state, and a coarse hardware-warning level.

Exact temperatures, utilization metrics, and wireless measurements should be exposed only when a provider actually supplies them.

“Unavailable” is preferable to a fabricated universal hardware dashboard.

### Normalization

The manifest should define the expected range and meaning of each exported value.

A value of `0.5` must not ambiguously mean 50 percent utilization in one module and 50 degrees in another.

For avatar-facing parameters, normalized values plus a validity flag are often easier to use consistently.

### Privacy

Most avatars do not need to publish exact hardware data.

A coarse optional status—“tracking interruption” or “device charging”—may be sufficient.

The system should avoid broadcasting stable identifiers, detailed hardware inventories, or raw diagnostic strings.

### Relationship with existing software

Hardware providers should be independent modules. Failure of a tracker provider should not disable the battery module for unrelated controllers or the rest of Avatar Link.

---

## 15. Resource-warning indicator

The resource-warning indicator should communicate **observed pressure**, not assign blame.

### What it represents

Possible states include sustained application memory growth, a selected device becoming unavailable, prolonged poor frame timing from a supported source, or a provider-specific warning.

Each warning should identify what was measured and which threshold policy triggered it.

The application should not jump from:

> “Performance declined after an avatar change”

to:

> “This avatar is definitely responsible.”

Other simultaneous changes may matter.

### Decision logic

Warnings should use a time window, persistence requirements, and hysteresis.

One brief spike should not repeatedly trigger the indicator.

A user should be able to inspect the underlying timeline and see whether a warning represents an instantaneous reading or a sustained condition.

### Avatar presentation

A small private symbol is often enough. The detailed explanation belongs in the application or overlay.

An optional public display should use a coarse user-approved message, not reveal raw resource data automatically.

### Optional responses

A warning could offer a diagnostic bookmark or switch to a creator-authored low-effect preset.

It should not silently change unrelated VRChat settings, close programs, or disable other people’s avatars.

Also, a runtime low-effect preset should not be described as improving the uploaded avatar’s performance rank. That ranking is based on the avatar’s counted contents, including disabled components. [VRChat Creators](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/)

---

## 16. Local-media reactive effects

I would keep this separate from the music visualizer because it handles **media state and authored cues**, not just audio intensity.

### Possible inputs

A supported local media provider might supply playback started, paused, stopped, progress, or a selected cue.

A creator could map those to an avatar’s authored animations: headphones appearing, a small activity icon, a progress ring, or a restrained decorative effect.

The system should not require that other people hear or receive the media.

### Cue mapping

A cue should refer to a known action identifier, not arbitrary executable content.

For example:

> `media.started` → select authored effect state 2.

A cue timeline could be stored locally and associated with a particular user-selected media item.

It should include a clear policy for seeking, restarting, pausing, and changing tracks so that an effect does not become stuck in the wrong state.

### Metadata privacy

Track names, file paths, application titles, and other metadata should remain private unless explicitly selected for a supported presentation.

The normal avatar contract should use finite states or normalized progress rather than transmitting unnecessary text.

### Failure behavior

If the provider disappears, the module should fade or reset to neutral.

It should not silently change to another audio source, publish the last known media title, or keep replaying a cue sequence as though playback were continuing.

A source simulator would make this feature testable without opening a media application.

---

## 17. Physical Contact-based buttons

These are **virtual avatar Contacts**, not physical-world sensors.

VRChat’s Contact system can drive avatar animator parameters. Its receiver options include self/others filtering and local-only operation; those settings have different meanings and must not be conflated. [VRChat Creators](https://creators.vrchat.com/common-components/contacts/)

### Local Only is not the same as Self Only

A receiver that operates on the local client can still be configured to react to other people.

For a private wrist control, the intended configuration would generally be self interaction enabled, other interaction disabled, and local processing, followed by explicit testing.

The installer should make this distinction visible.

### Input processing

A raw Contact signal should pass through an interaction state machine.

That state machine should distinguish touch entry, continued contact, release, accepted activation, cooldown, and cancellation.

A momentary touch can activate a simple action. A hold can be used where deliberate confirmation is appropriate. Repeated activation while a finger remains inside the receiver should be an intentional option, not an accident.

### Very short pulses

VRChat documents an `OnEnter` receiver behavior that resets on the next frame. A short pulse therefore should not be the sole basis for a reliable external command path. [VRChat Creators](https://creators.vrchat.com/common-components/contacts/)

The toolkit should provide a tested latch or request/acknowledgment pattern that holds the request long enough to be processed and then rearms cleanly.

Similarly, an animator value is not automatically guaranteed to be available through the selected OSC configuration. The installation and test workflow must verify the actual exported signal.

### Feedback

The creator should be able to configure separate visual feedback for contact detection, request acceptance, and action completion.

This makes failures diagnosable:

> “The button detected my touch, but VRC Eye rejected the request because camera control was disabled.”

### Security boundary

Contact tags are interaction labels, not passwords.

An avatar receiver also should not be assumed to provide trustworthy identity information about the person who caused a signal.

Contact controls should trigger a narrow local action allowlist. They should not execute scripts, open arbitrary links, send private information, or grant ongoing remote control.

---

## 18. PhysBone interaction debugging

This should have **three clearly labeled levels of visibility**.

### Authoring inspection

Inside an authorized Unity project, the toolkit can inspect the configured PhysBone roots, chains, colliders, exclusions, limits, parameter prefixes, and relevant animation bindings.

It can show relationships and highlight suspicious configurations.

For example, it could identify a reference to a missing collider, two systems competing over the same transform, or an unexpected humanoid-rig dependency.

This is source inspection, not runtime observation.

### Runtime signals

PhysBones can provide animator values representing grabbed, posed, angle, stretch, and squish states. Those signals are useful, but they are not a complete stream of every bone’s live transform. [VRChat Creators](https://creators.vrchat.com/common-components/physbones/)

A VRC Eye graph could show a creator-exposed tail-grab signal or normalized stretch history after the corresponding output route has been verified.

It should not fabricate a full moving skeleton from five scalar values.

### Existing in-game debugging

VRChat already provides an avatar debugging overlay for visualizing PhysBones and Contacts. Our workflow should complement that rather than imply it is unavailable without VRC Eye. [VRChat Creators](https://creators.vrchat.com/avatars/avatar-components/debugging-avatar-components/)

A useful test instruction could pair that overlay with VRC Eye’s signal timeline.

### Configuration changes versus runtime controls

The toolkit can edit source settings in Unity.

We should not promise arbitrary supported live tuning of avatar PhysBone spring, pull, and similar properties through OSC. VRChat documents those avatar properties as initialization-time settings and explicitly cautions against relying on unsupported animation tricks to change them. [VRChat Creators](https://creators.vrchat.com/common-components/physbones/)

A creator-authored reset or enable/disable behavior is a separate, narrower capability.

### Test cases

A reusable PhysBone test profile could check initial rest state, self interaction, permitted external interaction, release behavior, posing, reset behavior, and avatar reload.

The report should record the tested configuration and observed outputs.

It should distinguish “no signal was received” from “the PhysBone did not move.” The second conclusion needs visual or other appropriate evidence.

---

## 19. Avatar profile presets

There should be **creator installation presets** and **runtime user presets**.

They are related but not interchangeable.

### Creator presets

A creator preset chooses module composition, parameter contracts, visual variants, platform options, and default privacy.

For example, “Compact Utility” might install only a private battery indicator and two controls.

A creator preset can affect the build.

### Runtime presets

A runtime preset selects values and behaviors that the existing built avatar already supports.

It might select a wrist page, visual theme, local media intensity, public-status policy, or notification behavior.

It cannot magically add a missing mesh, receiver, or animation.

### Preset matching

A preset should declare which manifest versions and capabilities it expects.

Applying it to a partially compatible avatar should produce a preview:

> “Five settings can be applied. Two are unsupported on this avatar.”

It should not silently substitute unrelated parameters with similar names.

### Precedence

The system needs a consistent order for defaults, avatar-specific settings, session overrides, and deliberate manual changes.

An automatic profile should not continually overwrite a control that the user just adjusted.

I would use temporary ownership or suspension rules so manual intervention has a predictable effect.

### Partial application and rollback

Runtime parameter updates should not be presented as an atomic transaction unless the authored integration genuinely implements one.

The application should report partial application and offer a scoped restore.

Restoring should avoid overwriting newer manual changes made after the preset was applied.

Ephemeral connection state and pending requests must never be saved as preset content.

---

## 20. Creator-authorized hierarchy viewer

The hierarchy viewer should be an **inspection surface for supplied data**, not a universal view into avatars around the user.

### Supported sources

It could display the current selection from an authorized Unity connection, a creator-exported hierarchy snapshot, or the structure of an explicitly supplied local model.

Each source needs a visible label.

A snapshot should include its export time and build association, so the viewer does not imply that it represents the current live avatar.

### What to display

Useful views include the object tree, module ownership, component summaries, attachment anchors, animation targets, parameter dependencies, and PhysBone relationships.

A search for “battery display” should find the corresponding objects and explain which assets and parameters they depend on.

Filtering should help creators focus on modules, rig elements, rendering objects, or interactions.

### Source hierarchy versus generated hierarchy

Non-destructive build tools may merge or transform structures.

The viewer should therefore support a mapping between source objects and their generated counterparts where the build pipeline can supply that mapping.

Otherwise, a creator might search for an object name that no longer exists in the final build and conclude incorrectly that the module was lost.

### Sanitization

A shared hierarchy export should omit unnecessary local paths, usernames, private object labels, and unrelated project content.

The creator should be able to export only the toolkit-relevant subtree.

### Editing

The VRC Eye viewer should be read-only by default.

Any optional “select this object in Unity” or “propose a repair” command should be scoped to the explicitly connected project. It should not turn a hierarchy document into a remote editing interface.

---

## 21. Creator-supplied avatar manifests

The manifest is the feature that makes the rest of this ecosystem manageable.

It should be **a versioned, declarative description of compatibility**.

### Identity and provenance

A manifest should distinguish avatar identifier, creator-provided package identity, platform variant, toolkit version, module versions, schema version, and build association.

Those identifiers answer different questions.

An avatar identifier does not uniquely describe every platform build or every revision. A manifest revision does not prove that the user is currently wearing that exact build.

The interface should show whether a match is inferred, user-confirmed, or established through an additional trusted source.

### Parameter definitions

Each externally relevant parameter should declare its final emitted name, type, direction, range, default, persistence policy, synchronization policy, module association, and semantic meaning.

For example:

> “This Float represents normalized left-controller battery charge. It is meaningful only while the associated validity flag is true.”

That is much more useful than a list of names.

### Capability definitions

Modules should declare capabilities such as battery display, camera request, local status presentation, or test-marker output.

Capabilities should include prerequisites and safe defaults.

A manifest can also define supported command identifiers, expected acknowledgments, rate policies, and initialization requirements.

It should not contain executable scripts.

### Preview and hierarchy references

Preview assets, thumbnails, and hierarchy snapshots should be separately referenced and separately permissioned.

A person may be allowed to use an integration manifest without receiving the avatar’s meshes or source project.

The application should not automatically fetch every referenced asset just because a manifest was opened.

### Integrity and trust

Hashes can associate files with a manifest. Signatures can help identify a publisher.

Neither mechanism, by itself, establishes that the publisher owns every included asset or that a claimed capability works.

The UI should not collapse provenance, permission, and technical verification into one “verified” badge.

### Safe import

Manifests need size limits, schema validation, bounded collections, safe path handling, and clear rejection of unsupported fields that would alter behavior.

A manifest should never be allowed to request arbitrary local-file access, unrestricted network destinations, or automatic execution.

### Migration

When a module changes parameter names or semantics, the manifest format should support an explicit migration description.

VRC Eye can then explain why a preset is outdated and propose a controlled conversion instead of guessing.

---

## 22. Authorized T-pose / 3D avatar preview

This should be a **preview system with explicit fidelity levels**.

### Preview sources

A creator could supply a lightweight model, a permitted local source asset, or a preview rendered through the authorized Unity project.

These are different workflows with different capabilities.

A simple external model viewer should not claim to reproduce every Unity material, avatar animation, or VRChat-specific behavior.

### Three fidelity levels

**Reference preview:** A static or lightly posed model for identifying the avatar and inspecting module placement.

**Interactive technical preview:** A model with supported rigging, animation, and module-state simulation.

**Unity-backed preview:** A view generated from the actual authorized project, using its relevant assets and editor environment.

Even the last category should not automatically be labeled identical to VRChat runtime behavior.

### T-pose versus rest pose

The viewer should distinguish the imported rest pose, a configured humanoid reference pose, and a generated T-pose.

Those can differ.

Applying a preview pose must affect only the local preview instance. It should not alter the source asset unexpectedly, change the avatar currently worn in VRChat, or attempt to pose somebody else’s avatar.

Generic rigs may need a creator-supplied pose rather than a humanoid retargeting assumption.

### Useful inspection tools

The preview could provide turntable controls, orthographic views, anchor markers, module visibility, selected-object highlighting, and overlays for supplied bounds or interaction volumes.

A wrist module could be tested with synthetic battery data or a simulated camera acknowledgment.

Every simulated state should be visibly labeled.

### Resource and trust controls

Previews should stop rendering when hidden, support a lower frame-rate mode, and have memory and asset-size limits.

Untrusted model or package content should not be given arbitrary script or network execution simply to display a preview.

An authorized Unity project connection and an untrusted downloaded preview file should not share the same trust level.

---

## 23. Generic mannequin preview

The mannequin is not merely a placeholder image. It can be a **fully useful module-testing environment**.

### What it should demonstrate

It can show wrist-module placement, badge layouts, parameter-driven visual states, interaction feedback, and generic attachment behavior.

It can also support keyboard or mouse simulation of Contact inputs without any VR hardware.

That makes the toolkit usable before a creator has prepared a distributable preview model.

### What it must not imply

The mannequin should not claim to represent the actual avatar’s body proportions, collision behavior, rig structure, or material rendering unless that information was explicitly supplied.

A generic wrist position is an example anchor, not proof that the module will fit a particular avatar.

### Partial data

A creator might provide only anchors and a sanitized bone description.

In that case, the viewer could show an abstract skeleton or attachment markers without receiving the actual mesh.

The display should identify which parts are supplied data and which are generic presentation.

### Demonstration isolation

The mannequin’s simulation should be isolated from live commands by default.

Clicking a simulated camera button should show the request/response sequence inside the preview—not unexpectedly take a real photograph in VRChat.

A deliberate “connect this test to the live session” operation should be separate and clearly visible.

This gives us a safe, useful teaching tool, troubleshooting surface, and module-development environment.

---

# Part II — Additional features worth adding

## 24. Avatar Creator workspace and context recognition

I would add an Avatar Creator workspace that brings the otherwise scattered features together.

### Recognizing context

The application could recognize a connected Unity project, a selected avatar descriptor, an imported manifest, or a current avatar associated with an existing workspace.

That should change which tools are presented—not automatically grant authority.

The workspace should distinguish:

> “This is the avatar you are wearing.”

> “This is an avatar associated with your local project.”

> “This project is open and has explicitly granted editor access.”

Those are not equivalent.

### Workspace contents

Each workspace should contain local notes, TODOs, manifests, platform variants, module installations, validation history, test profiles, preview associations, and release records.

A creator could keep separate workspaces for multiple avatars without mixing their parameter mappings.

### Unsaved and mismatched state

The workspace should clearly show when the source project has changed since the last recorded build, when the manifest is older than the build, or when the current runtime avatar cannot be confidently matched.

This would prevent a common troubleshooting failure:

> Testing one revision while reading the documentation for another.

### UI placement

I would place this under the existing Avatar area as a Creator/Toolkit workspace, with tabs for Overview, Modules, Parameters, Validation, Testing, Preview, Builds, and Notes.

Global connection configuration should remain under **VRC Eye → Networking**, with contextual links here rather than duplicated settings.

---

## 25. Live parameter inspector and signal-routing debugger

This is probably the most important missing runtime tool.

A creator needs to see **where a value came from, what transformed it, and where it went**.

### End-to-end signal traces

A trace might show:

> Hardware provider → normalized battery value → privacy filter → avatar mapping → OSC send → observed output.

Another might show:

> Contact receiver → authored request latch → OSC receive → action permission check → camera request → acknowledgment.

This makes it possible to locate the actual failure stage.

### Value presentation

The inspector should show the raw value, interpreted meaning, expected range, source, timestamp, active writer, and whether the value is simulated.

It should support freezing a view and comparing two moments without pausing the live application.

### Competing writers

VRC Eye should maintain explicit ownership for values routed through its own broker.

A media module should not accidentally overwrite a value controlled by a manual preset. An imported test sequence should not fight a live hardware provider.

A reasonable priority policy might be manual override, temporary test ownership, active feature provider, then default.

However, the application must not claim to identify every external writer on the machine. For traffic outside its controlled routing, it may only be able to report a suspected conflict.

### OSC coexistence

OSCQuery should be used where appropriate for discovery and compatible routing, while coexistence with other OSC applications is tested deliberately. [VRChat](https://docs.vrchat.com/docs/oscquery)

The application should not silently seize ports, rewrite another tool’s configuration, or become an unnecessary dependency for unrelated tracking software.

### Recording traces

Short traces should be allowlisted and locally stored.

Normal diagnostics should not record every available parameter indefinitely, especially where another application may expose sensitive or highly detailed data.

Exports should default to the parameters relevant to the selected incident.

---

## 26. Animator and property-conflict analyzer

Parameter correctness alone does not guarantee that an avatar behaves correctly.

Two systems may both animate the same material, object state, transform, or blendshape.

VRChat’s playable layers combine multiple controllers in a defined order, making cross-layer interaction an important part of avatar behavior. [VRChat Creators](https://creators.vrchat.com/avatars/playable-layers/?utm_source=chatgpt.com)

### Property ownership map

The analyzer should answer:

> “Which modules can write this property?”

For a wrist object, it might reveal that the toolkit controls visibility while an existing outfit animation also disables its parent.

For a status material, it might show that a theme animation overwrites the same color property used by the warning indicator.

### State-graph analysis

The tool could flag unreachable states, states with no intended exit, conflicting transitions, and reset paths that fail to restore neutral behavior.

It should also identify bindings that unexpectedly reach outside a module’s declared object subtree.

A battery prefab should not animate the avatar’s hips or head.

### Explanations, not magical repair

Findings should show the competing assets and the circumstances under which they conflict.

The tool can suggest isolating a property, moving a visual object, changing a module binding, or adding a documented integration layer.

It should not globally rewrite controller conventions to make one warning disappear.

### Limits

Static analysis cannot prove every possible runtime combination behaves correctly.

The report should say what was analyzed, what assumptions were used, and which cases need runtime testing.

---

## 27. Automated test runner and Black Box integration

The toolkit should have a repeatable test system rather than relying entirely on “I clicked it and it seemed fine.”

### Test types

Source tests can verify parameter and module structure.

Simulation tests can exercise the proposed signal contract.

Unity tests can inspect generated behavior in the authorized project.

Live tests can verify selected actions and feedback through Avatar Link.

Each result should retain its test type so simulated success is never mistaken for live verification.

### Failure scenarios

The test library should include avatar switching, provider disconnection, delayed responses, stale values, held buttons, rapid repeated input, missing acknowledgments, profile changes, and reconnects.

Privacy transitions deserve dedicated tests:

> Enable a public status, enter private mode, and verify that the intended neutral public state is requested and observed where possible.

### Assertions

A test should state an observable expectation, such as:

> “After the request is acknowledged and the control is released, the module returns to its ready state without issuing a second action.”

It should not assert “the user is safe” or “every remote viewer saw the update.”

### Black Box integration

A failed test could create a diagnostic bookmark in the broader VRC Eye Black Box system, linking relevant parameter traces, provider state, module versions, and application events.

The report should preserve chronology without assuming causation.

### Reproducibility

Saved test profiles should record the manifest, relevant build identity, provider versions where known, and selected privacy configuration.

That allows a later test to explain why its results are not directly comparable to an earlier one.

---

## 28. Build comparison, version history, and release records

I would make this a first-class feature, not an incidental log.

### Distinct identities

The system should track source revision, toolkit configuration revision, generated build, platform target, manifest revision, and published-avatar association separately.

One “version number” cannot adequately represent all of them.

### Meaningful diffs

A build comparison could report that a module added three parameters, changed a default, introduced a public channel, removed a mobile variant, increased a counted resource, or changed an attachment anchor.

The most valuable diffs are semantic:

> “The camera button now requires a longer hold.”

> “The status parameter changed meaning; an existing preset may select the wrong icon.”

Those are more useful than raw file timestamps.

### Release readiness

A release record should include validation results, completed test profiles, known limitations, compatibility notes, and an explicit list of supported platforms.

The creator should be able to mark a release as experimental or withdrawn without deleting historical records.

### Publication remains separate

A successful build should not silently publish.

The final publishing workflow should show the intended avatar association and platform targets, then use the appropriate authorized process.

The application should not assume that a locally tested build is the one currently available to other people.

### Retention

Creators should control how long large preview or test artifacts are kept.

Small manifests and release notes can remain useful even after bulky temporary outputs are removed.

---

## 29. Platform-variant planner and module-cost budgeting

Every module should disclose its cost before installation and after the final build.

### Cost dimensions

The planner should consider synchronized parameter usage, rendering assets, materials, interaction components, animation complexity, and relevant platform restrictions.

A module’s cost is not always additive. Two modules might share an atlas or controller structure, while another combination might introduce an extra renderer.

Therefore, the planner should show an estimate before building and measured generated-build information afterward.

### Platform variants

VRChat supports per-platform avatar overrides, which provides an appropriate foundation for platform-specific toolkit variants. [VRChat Creators](https://creators.vrchat.com/avatars/per-platform-avatar-overrides/?utm_source=chatgpt.com)

A creator could select a full PC wrist controller and a reduced mobile display while preserving the required shared parameter contract.

Unsupported effects should be replaced with an intentional alternative or omitted with an explanation—not left as broken references.

### Quality tiers

I would define module tiers such as minimal, standard, and elaborate.

The minimal tier should remain useful, not be an intentionally crippled advertisement for the larger one.

### Optimization proposals

The planner might suggest replacing multiple independent labels with one atlas, reducing visual complexity, or removing an unused module from a platform build.

It should show the expected tradeoff.

It should not destructively change textures, meshes, or third-party assets without review.

### Important distinction

Runtime visibility toggles and build-time removal must be presented separately.

A runtime low-effect profile can reduce active behavior, while build-time optimization changes what is actually included and counted. Those are different tools serving different purposes.

---

## 30. Rig, fit, viewpoint, and attachment diagnostics

This could become a particularly useful general creator feature.

### Attachment sockets

The toolkit should let creators define named sockets for wrist displays, chest badges, head-mounted indicators, or other modules.

Each socket should declare its intended orientation, scale behavior, supported module types, and optional platform-specific adjustment.

This is more reliable than every prefab inventing its own bone-name search.

### Rig validation

The toolkit can use VRChat’s rig requirements as a reference for relevant humanoid checks while retaining an explicit generic-rig workflow. [VRChat Creators](https://creators.vrchat.com/avatars/rig-requirements/)

It should report missing or unsuitable anchors rather than force a humanoid assumption onto every avatar.

### Fit testing

A test panel could preview standing, sitting, selected hand gestures, and creator-supplied reference poses.

The aim is technical: determine whether a control clips into clothing, becomes unreadable, or moves unexpectedly.

It should not modify the avatar’s proportions merely to make a module fit.

### Viewpoint diagnostics

A creator workspace could compare the authored viewpoint, relevant rig placement, selected test pose, and observed runtime parameters where exposed.

That could help document standing or camera-height problems without claiming that a single source measurement identifies their cause.

### Accessibility

Left- and right-side layouts, one-handed controls, adjustable touch targets, menu alternatives, and reduced-motion presentation should be treated as standard module options.

The same capability should remain accessible even when a particular gesture or attachment location is inconvenient.

---

## 31. Raycast-based interaction and placement helpers

This is an additional avenue beyond Contacts.

VRChat now documents an avatar `VRCRaycast` component that can position a result transform at a ray hit and expose associated information. [VRChat Creators](https://creators.vrchat.com/avatars/avatar-components/raycast/?utm_source=chatgpt.com)

### Creator-facing uses

The toolkit could help configure and test a pointer, a placement marker, a surface-aware decorative effect, or a creator-authored distance indicator.

A visual editor should show the ray origin, direction, intended collision selection, result transform, and behavior when nothing is hit.

### Safe dependency handling

The validator should detect self-referential transform setups or a result object that unexpectedly moves the ray’s own origin.

The manifest should describe any externally exposed result values without implying that VRC Eye receives an entire scene representation.

### What it does not provide

A ray hit is not a general UI permission, a reliable identity of a nearby user, or authority to manipulate the object it intersects.

It also does not automatically solve every wrist interaction problem. A raycast-based menu needs its own authored selection logic.

### Testing

The module should include clear hit, miss, disabled, and unavailable states.

Its preview should distinguish a simulated hit from actual in-game behavior.

I would introduce this after the simpler Contact-based controls are stable, because it adds another interaction model and additional configuration complexity.

---

## 32. Creator SteamVR overlay and universal control panel

The avatar toolkit should have a **non-avatar interface with equivalent core functionality**.

### Why it matters

A creator may be testing an avatar with a broken wrist module. They still need to inspect parameters, disable an effect, change a test profile, or record a failure.

An overlay also supports users who cannot modify their avatar.

### Overlay contents

A compact creator overlay could show the selected workspace, connection state, active parameter writers, recent test events, and a small set of approved actions.

Detailed analysis can remain in the desktop window.

The overlay should not replicate every editor panel at once.

### Shared action model

The desktop UI, overlay, expression menu, and wrist prefab should call the same internal actions.

That prevents different interfaces from implementing subtly different safety, permission, or acknowledgment rules.

### Interaction independence

Closing or hiding the overlay should not stop an active test unless that is explicitly requested.

Conversely, pausing Avatar Link should not make the overlay itself unavailable.

### Capture visibility

The application should offer clear guidance and test tools for where the overlay appears in relevant capture workflows.

It should not promise universal invisibility to recordings merely because an interface is intended for the wearer.

The overlay is a practical fallback and diagnostic surface, not a secret display channel.

---

## 33. Module-authoring SDK and visual module composer

Eventually, other creators should be able to build compatible modules without copying our internal implementation.

### Module contract

A module package should declare its identity, version, dependencies, supported platforms, parameters, menu entries, anchors, visual assets, test cases, and uninstall behavior.

Its documentation should explain which capabilities work locally and which deliberately expose public state.

### Reusable building blocks

The toolkit could provide approved primitives for value displays, state indicators, button requests, progress meters, acknowledgment feedback, and timeout presentation.

A visual composer could combine these into a module without requiring a creator to write an entire communication system.

The composer should produce inspectable assets and a manifest, not an opaque blob.

### Behavior versus appearance

A theme package should change appearance without gaining new permissions.

Replacing an icon or material should not suddenly enable camera control or public sharing.

Behavioral changes should be declared and reviewed separately.

### Extension security

Installing a Unity package can be a materially different trust decision from opening a data-only manifest.

The application should explain that distinction and should not automatically install executable editor extensions received from another user.

A data-only module description must not be allowed to smuggle in arbitrary code execution through action fields.

### Compatibility tests

Module authors should receive a standard test suite covering initialization, removal, duplicate installation, privacy behavior, and coexistence.

Passing it can produce a test report, but should not be portrayed as a universal safety certification.

---

## 34. Creator handoff packages, documentation, and repair guides

This would make the toolkit useful for commissions, avatar distribution, and support.

### Handoff package

A creator could export a small package containing a manifest, module documentation, permitted preview assets, recommended runtime presets, known limitations, and a troubleshooting guide.

The package should not automatically include the source project.

Different assets may have different distribution permissions, so exports need an explicit inclusion review.

### Generated documentation

Because the manifest already describes capabilities, the toolkit can generate documentation that matches the actual build:

> “This avatar supports a private battery display and local camera requests. It does not contain a public recording badge.”

This prevents generic instructions from advertising features that were removed from a variant.

### Repair guidance

When a user imports an incompatible preset or encounters missing parameters, the guide should identify the likely mismatch and a narrow next step.

For example:

> “The installed preset expects module contract version 3; the avatar advertises version 2. These two settings cannot be applied.”

That is better than instructing the user to reinstall everything.

### Support exports

A support bundle should default to the relevant manifest, sanitized diagnostics, module versions, and selected test failures.

Preview meshes, private notes, account identifiers, and local paths should remain excluded unless explicitly selected.

### Local ownership of documentation

These packages should remain useful without a VRC Eye service.

An online compatibility directory could be optional later, but basic documentation and troubleshooting should not depend on a central account.

---

## 35. Creator-authored avatar test-world integration

A compatible test world could provide standardized environments for evaluating avatar modules.

### Useful test stations

A creator could build stations for checking wrist readability, selected poses, Contact interactions, camera framing, and visual behavior under different lighting.

A test world can make repeated comparisons easier because the environment is controlled.

VRChat supports Contacts and PhysBones in worlds as well as avatars, although world and avatar interaction mechanisms have distinct behavior and interfaces. [VRChat Creators](https://creators.vrchat.com/releases/release-3-10-0/?utm_source=chatgpt.com)

### Keep world authority separate

An avatar manifest should not automatically grant control over a world.

Any world helper must expose its own deliberately supported actions and use a separately established communication route.

We should not assume that a generic avatar OSC parameter can call arbitrary Udon methods.

### Coordinated tests

A test session could guide the user through known stations and associate manually confirmed results with the active avatar build.

An optional compatible helper could supply additional structured events, but the test workflow should still work with manual markers.

### Reproducibility

The report should record the world version or available identifying context, selected test profile, avatar build association, and relevant environment settings.

Results obtained in different environments should not be presented as directly comparable without qualification.

This is a natural connection to the World Creator features, while keeping the two toolkits technically independent.

---

## 36. Optional Eye-to-Eye creator playtests

This should be an extension of the toolkit—not a prerequisite.

### What to share

Participants could share readiness, selected test steps, coarse compatibility results, manually approved screenshots, and sanitized observations.

A creator might ask testers to perform a defined sequence and then collect results associated with a particular build.

### No automatic source transfer

Joining a playtest should not transmit the avatar model, source hierarchy, raw hardware inventory, complete OSC history, or private notes.

Each exportable data category should be separately selected.

### Session roles

Useful roles could include creator, tester, observer, and note-taker.

Those roles should affect the collaboration interface, not grant hidden control over another person’s application or avatar.

### Requests rather than remote commands

A creator can request that a tester select a profile or begin a test.

The tester’s application should validate the request and obtain the required local approval.

Raw remote OSC forwarding is not an appropriate substitute for a permissioned action layer.

### Offline continuity

A tester should be able to complete a checklist locally and export the result later.

A disconnected session should retain local notes and completed steps rather than lose the entire test.

The networking transport—LAN, an explicitly configured private network, or another supported Eye-to-Eye option—should not change the permission model.

---

# Part III — Shared engineering rules for every module

All of these features become much easier to maintain if they follow one common contract.

## Every signal needs a source and a freshness policy

A battery value, recording state, resource warning, and manual status should not be treated as interchangeable raw numbers.

Internally, each should retain where it came from, when it was sampled, whether it is valid, and what should happen when it becomes stale.

The avatar representation can be compact, but the application should not discard that context.

## Every output needs an owner

A parameter should have a known active writer inside VRC Eye.

Manual controls, automated profiles, test simulators, and hardware providers must not endlessly overwrite one another.

When the application cannot identify an external writer, it should report uncertainty rather than invent attribution.

## Every command needs bounded behavior

Commands should have a defined scope, prerequisite, permission, timeout, rearm condition, and feedback policy.

A request should never remain pending forever and unexpectedly execute after a reconnection.

Repeated delivery should not cause repeated high-impact actions.

## Every module needs a neutral state

The neutral state should be explicit and testable.

For some modules that means invisible. For others it means an unavailable symbol or a static decorative appearance.

“Leave the last value forever” should be an intentional choice, not the accidental result of missing disconnect handling.

Where the avatar cannot be reached or its animation logic is no longer evaluating, the application must acknowledge that it cannot guarantee the visual reset.

## Every privacy control needs an actual data path

A privacy toggle should show which destinations it affects.

Disabling Eye-to-Eye networking, withholding public avatar state, hiding a local overlay, and excluding fields from a report are separate actions.

A single friendly label can coordinate them, but the implementation needs to know exactly which operations succeeded.

## Every generated artifact needs provenance

The toolkit should know which installation created an object, which module owns a parameter, which build produced a manifest, and which test produced a report.

That is what makes safe upgrades, meaningful diagnostics, and reliable uninstall possible.

---

# Part IV — How I would develop this without derailing VRC Eye

I would preserve the back-burner status and build the system in small, independently useful stages.

| Stage                       | Deliverable                                                           | The release gate                                                           |
| --------------------------- | --------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| **Foundation**              | Manifest schema, workspace model, privacy model, parameter ownership  | Local inspection and simulation work without networking                    |
| **Avatar Link core**        | Discovery, avatar-change handling, parameter inspector                | Switching avatars cannot reuse stale queued actions                        |
| **First Unity integration** | Non-destructive installer, validator, one simple battery module       | Repeated install, update, and removal are predictable                      |
| **Controls and status**     | Wrist controls, indicators, camera requests, presets                  | Requests, acknowledgments, disconnects, and privacy transitions are tested |
| **Creator diagnostics**     | Hierarchy inspection, PhysBone traces, test runner, build comparisons | Reports distinguish source inspection, simulation, and runtime evidence    |
| **Preview and ecosystem**   | Authorized previews, module SDK, handoff packages, collaboration      | Untrusted content and shared sessions cannot acquire unintended privileges |

The first end-to-end demonstration should be deliberately modest:

A creator installs one private battery display. The toolkit shows the exact changes, builds a final manifest, and validates the generated parameter names. VRC Eye recognizes the compatible avatar, sends a valid battery reading, and the display updates. The provider is then disconnected, and the display transitions to its intended unavailable state. The avatar is switched, and all old writes stop. Finally, the module is removed without damaging unrelated avatar assets.

That single demonstration would exercise the most important architecture: installation, build integration, discovery, privacy, validity, disconnection, avatar transitions, and removal.

Once that works reliably, the other displays and controls become additional modules rather than separate systems with separate failure modes.

**The long-term identity should be clear: VRC Eye Avatar Toolkit is a creator-authorized way to make avatars useful, observable, and controllable through deliberate integrations. Avatar Link runs those integrations; the Unity Toolkit authors them; the workspace explains and tests them. None of them should be required for the rest of VRC Eye to remain useful.**