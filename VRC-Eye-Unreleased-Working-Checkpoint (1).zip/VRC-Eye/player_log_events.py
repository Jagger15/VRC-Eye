"""Normalize parsed log observations on the log worker; never parse inside a row."""
import hashlib
import json
from player_session_model import PlayerEvent
from world_players import log_epoch


def digest(*parts):
    return hashlib.sha256(json.dumps(parts,ensure_ascii=True,separators=(",",":"),sort_keys=True).encode()).hexdigest()


class RosterEvents:
    def __init__(self):
        self.previous=None
        self.pending=[]
    def capture(self,roster,avatar=None,*,reconstructed=False):
        old=self.previous
        changed=old is None or roster!=old
        def emit(kind,stamp,user="",name="",**data):
            if log_epoch(stamp) is None:return
            if roster.started:data["session_start"]=roster.started
            fingerprint=digest(roster.started or roster.source,kind,stamp,user,name,data)
            self.pending.append(PlayerEvent.make(kind,stamp,user_id=user,name=name,data=data,event_id=fingerprint,reconstructed=reconstructed))
        if changed:
            if roster.started and (old is None or roster.identity!=old.identity):
                emit("instance.entered",roster.started,world_id=roster.world_id,world_name=roster.room,instance_id=roster.instance_id)
            elif roster.started and old and (roster.world_id,roster.room,roster.instance_id)!=(old.world_id,old.room,old.instance_id):
                emit("instance.entered",roster.started,world_id=roster.world_id,world_name=roster.room,instance_id=roster.instance_id,update=True)
            previous={v.serial:v for v in old.visits} if old and roster.identity==old.identity else {}
            for visit in roster.visits:
                before=previous.get(visit.serial)
                if before==visit:continue
                common=dict(joined=visit.joined,first_observed=visit.first_seen,conflict=visit.state=="Uncertain",local=visit.name==roster.local_name)
                if before is None or not before.user_id and visit.user_id or before.state!=visit.state and visit.active:
                    emit("player.joined" if visit.joined else "player.resolved",visit.joined or visit.first_seen,visit.user_id,visit.name,**common)
                if visit.left and (before is None or visit.left!=before.left):
                    emit("player.left",visit.left,visit.user_id,visit.name,**common)
            if roster.ended and (not old or old.ended!=roster.ended):emit("instance.left",roster.ended)
            self.previous=roster
        if avatar is not None and avatar.kind!="Uncertain":
            emit("avatar.changed",avatar.timestamp,avatar.user_id,avatar.player,avatar_name=avatar.avatar,reload=avatar.kind=="Reload")
        # Consumers drain every batch. A corrupt/huge input cannot grow this indefinitely.
        if len(self.pending)>8192:self.pending=self.pending[-8192:]
    def drain(self):
        result=tuple(self.pending);self.pending.clear();return result
