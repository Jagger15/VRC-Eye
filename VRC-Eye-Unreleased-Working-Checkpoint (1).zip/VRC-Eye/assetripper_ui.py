"""Managed recovery shares Avatar Library's scoped worker and review boundary."""
import json
import time
from account_header import private
from companion_ui import Table,button,line
from creator_projects_ui import review_document,text_area,set_text
from assetripper_jobs import Jobs,inspect_tool


class ManagedRecovery:
    def __init__(self,owner,parent):
        self.owner,self.page=owner,owner.page
        self.service=Jobs(self.page.shell.store);self.tool=None;self.generation=0;self.permitted=False;self.last_refresh=0
        self.info=self.page.tk.StringVar(value='No recovery tool selected. Select and inspect your installed native AssetRipper executable explicitly.')
        owner.label('Managed AssetRipper export',title=True)
        owner.label('Uses the inspected bundle, NEW staging folder, and permission checkbox above. The selected tool runs with your OS permissions. Its local API must match before input is loaded; native release compatibility still requires acceptance testing.')
        row=line(self.page,parent)
        button(self.page,row,'Select / inspect AssetRipper…',self.choose)
        button(self.page,row,'Review managed export…',self.run)
        button(self.page,row,'Refresh recovery jobs',self.refresh)
        self.page.ttk.Label(parent,textvariable=self.info,wraplength=940).pack(anchor='w',pady=4)
        self.table=Table(self.page,parent,(('time','Last phase',340),('state','Outcome',330)),height=4,select=self.select)
        row=line(self.page,parent);button(self.page,row,'Review Unity project handoff…',self.handoff)
        button(self.page,row,'Working copies / repair history…',self.history)
        self.report=text_area(self.page,parent,height=9)
        for variable in (owner.authorized,owner.destination):
            variable.trace_add('write',self.draft_changed)
        self.refresh()

    def draft_changed(self,*_):
        self.service.clear()
        if self.permitted:
            self.generation+=1;self.permitted=False;self.page.cancel()

    def require(self):
        self.owner.require()
        if private(self.page.app):raise ValueError('Reveal private information before managing recovery jobs.')

    def clear(self):
        self.generation+=1;self.permitted=False;self.tool=None;self.service.clear()
        self.table.set([],lambda r:());set_text(self.report,'Recovery details cleared. Recorded jobs and staged files remain.')
        self.info.set('Select and inspect the installed tool again in this workspace.')

    def choose(self):
        self.require();token=self.owner.signature();generation=self.generation
        from tkinter import filedialog
        value=filedialog.askopenfilename(parent=self.page.app.root,title='Choose AssetRipper executable in its dedicated installation folder')
        if not value:return
        self.owner.after_dialog(token);self.require()
        def done(tool):
            if generation!=self.generation or token!=self.owner.signature():raise ValueError('Recovery draft changed. Inspect the tool again.')
            self.tool=tool;self.info.set('Tool identity recorded: '+tool.sha256+f' · {len(tool.installation)} installation files pinned. Publisher/release unverified; runtime API not checked yet.')
        self.page.start_task(lambda stop,progress:inspect_tool(value,stop=stop,progress=progress),done,operation='Inspect installed recovery executable')

    def run(self):
        self.require();avatar=self.page.selected()['id']
        if not self.owner.authorized.get():raise ValueError('Confirm ownership or permission for the selected bundle.')
        plan=self.service.prepare(self.tool,self.owner.source,self.owner.destination.get(),avatar,self.page.scope)
        token=self.owner.signature();context=self.page.context();generation=self.generation
        try:
            report=(self.tool.summary()+f'\n\nSelected avatar association: {plan.avatar}\nSource: {plan.source.path}\nSource SHA-256: {plan.source.digest}\nNEW staging folder: {plan.destination}\n\n'
                'The avatar association is your declaration, not proof of ownership. VRC Eye stages a verified input.bundle and creates a new RecoveredProject folder. '
                'This managed job WILL launch the selected native executable, load the verified input through its owned loopback service, and request Unity export. '
                'Installation files are rechecked before launch; dependencies are not publisher-authenticated. The child receives a minimal environment and separate local state folder. '
                'Up to ten minutes, 4 GiB observed aggregate process memory, 64 tracked child processes, '
                '8 GiB / 20,000 entries of output, and an 8 MiB log. Output is checked at most once per second and after each command; '
                'these are observed limits, not OS quotas or filesystem/network containment. Logs and partial output remain on cancellation. '
                'No automatic rerun, installer, Unity launch or source-completeness claim. Native release compatibility is unqualified. '
                'Review exported scripts and dependencies before any later Unity import.')
            if not review_document(self.page.app,'Review managed AssetRipper export',report,accept='Launch and export'):return
            self.require()
            if token!=self.owner.signature() or generation!=self.generation:raise ValueError('The recovery draft changed. Review again.')
            self.permitted=True
            def check():
                self.page.check_context(context)
                if not self.permitted or generation!=self.generation or getattr(self.page.app,'_native_private',False):
                    raise ValueError('Recovery account, privacy or draft changed.')
            def work(stop,progress,prepared=plan):return self.service.run(prepared,guard=check,stop=stop,progress=progress)
            def done(row):
                self.permitted=False
                if token!=self.owner.signature():raise ValueError('Recovery finished in the initiating workspace. Refresh its job record before continuing.')
                self.owner.handoff=row['destination'];self.owner.output.set(row['output']);self.owner.labels()
                self.info.set(row['state']+'. Inspect the inventory before reviewing a Unity handoff.');self.refresh()
            self.page.start_task(work,done,avatar=avatar,operation='Managed AssetRipper export',destination=plan.destination,persist=lambda result,scope:None)
            plan=None
        finally:
            if plan:self.service.discard(plan)

    def refresh(self):
        if self.page.privacy.get() or private(self.page.app):
            self.clear();return
        self.table.set(self.service.rows(self.page.scope),lambda r:((r['log'] or ['Prepared'])[-1],r['state']),identity=lambda r:r['id'])
        self.select();self.last_refresh=time.monotonic()

    def select(self):
        if self.page.privacy.get() or private(self.page.app):set_text(self.report,'Private details hidden.');return
        row=self.table.selected()
        if not row:set_text(self.report,'Select a recovery job to inspect phases, inventory and dependencies. Provider log tails are included only when Show local paths is enabled.');return
        value=dict(row)
        if not self.page.show_paths.get():
            value.pop('provider_log',None);value.pop('destination',None);value.pop('output',None)
        set_text(self.report,json.dumps(value,indent=2,ensure_ascii=False))

    def handoff(self):
        self.require();row=self.table.selected()
        if not row or not row['state'].startswith(('Exported','Partial')):raise ValueError('Select a completed export with a recorded inventory first.')
        if row['account']!=__import__('native_library').scope(self.page.scope):raise ValueError('Recovery workspace changed.')
        if row['inventory']['missing_project_entries']:raise ValueError('The exported folder lacks required Unity project entries. Inspect and repair it separately first.')
        self.page.shell.show('Creator Projects');projects=self.page.shell.pages['Creator Projects']
        projects.add_paths([row['output']],issues=('Recovered output may contain executable scripts. Review inventory and unresolved dependencies before using the separate reviewed Open Unity action.',))

    def history(self):
        self.require();row=self.table.selected()
        if not row or row['account']!=__import__('native_library').scope(self.page.scope):raise ValueError('Select a recovery job from this workspace.')
        __import__('recovery_journal_ui').show(self.page.shell,account=self.page.scope,source=row.get('output',''))

    def tick(self):
        if private(self.page.app):
            if self.tool or self.permitted:self.clear()
            return
        if time.monotonic()-self.last_refresh>2:self.refresh()
