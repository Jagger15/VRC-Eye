# Dashboard and Creator recovery validation

Same unreleased checkpoint; no numbered release. Calendar build name: `2026.05.10.02.47.1`; internal compatibility: `1.21.0`.

| Verification | Result |
| --- | --- |
| Focused | 310 passed; 18 subtests passed |
| New cases | 38 passed |
| Portable suite | 5,389 passed; 1,065 subtests passed; 512 skipped; 1 deselected |
| Failures / errors | 0 / 0 |
| Python 3.10 grammar | 646 files passed |
| Source/test freeze | 666 hashes unchanged |

## Verified behavior

- Home tables filter every loaded row before stable sorting and 25-row paging. Saved worlds have a separate source window; coverage labels expose retained limits. Desktop-owned revisions share one snapshot per producer, source ages advance without polling, context changes clear old rows, and Unity runtime/events plus Crash diagnostics use the same cards.
- Shared display demand recognizes visible, uncollapsed Home cards and full pages. Minimized/low-power operation uses a 600-second unused public-status cadence and 120-second unused Unity metadata retries; foreground demand returns them to 120/30 seconds. Normal health request limits and failure backoff remain enforced. Core/window/recording/protection/recovery timing is unchanged.
- Creator Projects Copy only, Restore packages, Set exact package version and Remove package now create shared journal workspaces with raw/project/history. The frozen review identifies the actual project/ command; shared helper receipts and post-run checkpoints provide conditional undo while preserving later edits. Creator Activity links to Recovery history.
- Creator copy jobs persist account-scoped intent before file writes and link workspace/helper/checkpoint IDs through each phase. Interrupted copies and tools remain inspectable. Earlier-process unfinished receipts show their saved phase as outcome-unverified; restart never executes, retries or deletes them.

Tests cover paging beyond 200 rows, filtering/sorting, shrinking results, source-window isolation, advancing ages, single producer snapshots, context clearing, demand without provider startup, health backoff/one-worker ownership, immediate new-process metadata inspection, original/raw preservation, all three package commands, failed commands, conditional undo preserving later edits, canceled copy/helper work, restart receipts, tampered/expired reviews, failed durable-intent writes, UI execution and changed confirmation boundaries.

## Limits and evidence

- Native Tk UI could not start: no DISPLAY server. 476 display-dependent tests skipped; remaining skips are optional OpenVR, cryptography/lz4, recovery and QR prerequisites.
- 13 transport-dependent modules excluded and one native Unix SDK case deselected, matching the retained portable baseline.
- No installed VPM/Unity or Windows descendant process acceptance. Test runners use synthetic projects and injected CLI adapters; no supplied third-party executable was run.
- Home paging covers explicitly bounded loaded windows, not unbounded database search. Other runtime/log producers and Smart Start remain partial.
- Only optional status polling and Unity metadata retry timing changed. Default enabled GPU/disk rules retain demand; process/window/recording/protection/recovery timing is unchanged. Long-run/native power savings are unmeasured.
- Creator template jobs and arbitrary editor helpers remain outside shared journal execution. File undo is conditional and per-file; modes/empty directories, atomic cross-owner publication and power-loss behavior remain open.
- The full-run terminal log ended before its final summary. Completion and counts use the completed JUnit report plus exit status; its final socket-guard counter is unavailable. The focused guard recorded zero attempts.

Detailed commands, hashes and JUnit/log paths: `PENDING_WORKING_VALIDATION.json` → `dashboard_recovery_update`. Earlier validation remains attached to its saved source manifest.
