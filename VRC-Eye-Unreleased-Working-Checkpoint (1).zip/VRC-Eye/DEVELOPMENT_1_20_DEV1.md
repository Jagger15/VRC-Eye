# VRC Eye 1.20.0 — Development checkpoint 1

**This is an implemented development checkpoint, not the completed 1.20 feature release.**
It extends the recovered 1.19.9 source. It does not include unrecovered changes
previously described in another conversation. The full roadmap remains in
`IMPLEMENTATION_STATUS_1_20.md` and the historical `planning/` documents.

## Start this build

Close the old running copy. Extract the whole archive into a **new folder**, open
`VRC-Eye`, and run the existing `Start.cmd`. Keep the folder together. Startup and
its dependency setup are unchanged; no separate install scripts were added.
`Demo.cmd` and `Safe-mode.cmd` remain available. Do not run two copies against the
same settings/database. Back up your VRC Eye data before testing a development build.

The application title and header identify **Development 1**. This is the source
application with its existing launcher, not a newly compiled/signed Windows EXE.

## Added in this checkpoint

**Advanced → Creator Projects (VCC).** One local catalog in the existing VRC Eye
SQLite store. Add selected projects, discover within a selected parent, or review
paths imported from a chosen VCC settings file. Inspect exact Unity declarations,
UPM/VPM dependencies, locks and embedded package manifests. Keep missing folders
and their last known inventory. Create explicit account-scoped avatar/world ID
associations without claiming ownership. Export a path-free inventory report.
The five workspace sections are Projects, Inventory, Reviewed changes,
Templates & tools, and Activity; use the workspace selector for all sections.

**Reviewed project-copy jobs.** A genuine source-copy implementation with change
checks, one-use plans, cancellation, bounds, destination checks and reservations.
Optional installed VPM command adapters restore, set an exact package version,
remove a package without force, or create a new template project. Existing-project
VPM changes run on **new copies only**. These adapters were exercised with fixtures;
real installed VPM/Unity behavior is not certified by that testing. See the VCC guide.

**Optional Editor Core source package.** Export `com.vrceye.editor-core-1.20.0.zip`
from the VCC workspace. It contains an editor-only, explicitly invoked local
snapshot/export tool. VRC Eye validates and associates its JSON reports. There is
no automatic install, pairing, listener, build dispatch or publishing. Its C# source
was inspected and packaged, but **not compiled or run in Unity** here. Existing
Avatar Toolkit source is preserved separately and is not silently upgraded.

**VRC Eye → Accessibility.** Shared light/dark high-contrast options, 100–200%
text/shared-control scale, larger controls, stronger focus, spacing, reduced-motion
inheritance, presets, reviewed data-only import/export, undo and reset. Available
before sign-in and in all views. Settings edits the same values. These are display
and policy foundations, not completed screen-reader, audio-alert, remapping or XR
support. Custom drawing and every page's extreme-scale reflow remain unverified.

**VRC Eye → Useful Links.** A categorized, filterable browser-only catalog with
reviewed custom HTTPS bookmarks. No background downloads or embedded sign-in.
This is not yet the separate SDK/VCC release archive downloader.

**Shared repairs.** Resource backend initialization retries with bounded backoff
and a manual wake-up, without spawning duplicate collectors. Sensor health counts
fresh numeric observations; an all-unavailable GPU response is not Available.
Disk and CPU thermal health are distinguished. Incomplete process enumeration
retains observed VRCX presence but does not establish uniqueness or a connection.

**Navigation.** Larger/bolder section headings and between-section separators.
No separators were inserted between individual category buttons.

## Preserved behavior and scope

Independent remembered username/password controls and scoped Enter/keypad Enter
sign-in/verification remain. The original creator, networking, OSC, wellness,
Developer/Black Lab, optional bridge and other workspaces remain in the source.
Changing appearance never grants permissions or arms a transport.

No VRChat credentials, live account requests, supplied ARC executables, third-party
avatar extraction, Unity project scripts, VPM downloads or automatic dependency
upgrades were used to validate this checkpoint. Normal future use of deliberately
selected CLI operations can download packages; those effects require review.

Full Social/Accounts and Photos, Invite Me, ARC catalog expansion, separate SDK/VCC
release downloads, and the remaining accessibility/VCC capabilities are **not
represented as finished**. They remain in the implementation matrix. Do not rely
on the old planning documents' feature descriptions as proof of code completion.

## Validation and reports

`BUILD_VALIDATION.json` describes this checkpoint's actual runs and limitations.
`BASELINE_1_19_9_VALIDATION.json` is historical evidence shipped with the recovered
baseline, not a new result. `VCC_INTEGRATION_1_20.md` explains operations and their
limits. Automated tests use controlled accounts, manifests and transport doubles;
passing them is not proof of current VRChat, VRCX, VPM, Windows or Unity behavior.

Native Linux/Tk tests exercise the real UI. No native Windows credential-vault,
Windows sensor, screen-reader or Unity compilation test has been performed here.

## Data and recovery

The creator catalog adds namespaced tables to the existing companion database;
no legacy table is destructively migrated. Project links are account-scoped, while
the filesystem catalog is local to the OS user's VRC Eye workspace. It is not the
planned complete multi-account system. Accessibility uses the existing
`ui.presentation` record. Custom bookmarks use `links.catalog.120`.

Project job JSON receipts are kept in `creator-project-receipts` beside the existing
companion database. Database Activity keeps the most recent 100 receipts per
project; disk receipts are not automatically deleted in this checkpoint. Receipts
contain local destinations, times, digests and outcomes, not raw tool output.
Treat local paths as private when sharing those files. Path-free inventory exports
are a separate, deliberately limited representation.

A failed/canceled job may leave a partial new copy. Inspect it; do not assume it is
a usable backup, and do not blindly rerun a package operation. No project directory
is automatically deleted. If the process crashes, a reservation may remain in
`creator-project-locks`. After closing VRC Eye and confirming no related VPM/Unity
job is running, inspect the matching reservation before removing that reservation
file. Do not remove locks while a job is active. Automated crash reconciliation
and a full recovery UI remain pending.

To return to the earlier application, close this build and reopen the preserved
old folder. The old app should ignore new namespaced tables/options, but this is
not a substitute for a data backup. Project-copy rollback means selecting the
unchanged original; this checkpoint does not implement in-place project rollback.

## Final checkpoint validation result

Clean-extracted source: **2,884 tests and 1,141 subtests passed**; zero failures,
errors or skips. One pre-existing TestListener collection warning remains.
The external-socket test guard recorded no non-loopback connection attempts.
All 302 Python files parse with the Python 3.10 grammar. Native preview validation
recorded no Tk callback errors, no outbound socket attempts, no OSC sends and no
active bridge listener. The preview used explicitly synthetic projects.

The final archive has 406 files. All 371 baseline paths are retained. The four
launchers and requirements.txt are byte-identical to 1.19.9. Final executable
source, tests, Unity source/package and runtime catalogs match the clean-tested
tree; only validation metadata/documentation was finalized afterward.
