"""Desktop features share existing account, runtime, media and photo owners."""
from copy import deepcopy
import json
import time
from native_events import hub_for
from public_services import ServiceHealth
from desktop_notifications import Delivery
from desktop_automation import Automation
from desktop_discord import Presence,activity

KEY='desktop.native.settings.v1'
DEFAULTS=dict(schema=1,banners=True,sound=False,dnd=False,quiet_hours=False,quiet_start=22*60,quiet_end=8*60,
    banner_seconds=15,muted_types=[],health_poll=False,discord=False,discord_application='',discord_details='',
    launch_apps=False,recover_crashes=False,recovery_delay=30,recovery_limit=2,recovery_profile='Normal',
    photo_context=False,analytics=False,power='Balanced',close_to_tray=False,background_photos=True,
    background_feed=True,history_private_text=False,speech=False,speech_details=False,vr_notifications=False,priority_types=[],
    discord_template='Custom',discord_art=False,discord_join=False,discord_requests=False,discord_elapsed=False,autolock_minutes=0,
    notification_batch_seconds=2,notification_cooldown_seconds=15)
GRANTS=('health_poll','discord','launch_apps','recover_crashes','photo_context','analytics','close_to_tray','history_private_text','speech','speech_details','vr_notifications','discord_art','discord_join','discord_requests','discord_elapsed')


def settings(raw=None):
    if raw is None:return deepcopy(DEFAULTS)
    if not isinstance(raw,dict) or set(raw)-DEFAULTS.keys():raise ValueError('Unsupported desktop settings.')
    value=deepcopy(DEFAULTS);value.update(raw)
    for key,default in DEFAULTS.items():
        if type(default) is bool and type(value[key]) is not bool:raise ValueError(key+' must be a checkbox value.')
    if type(value['schema']) is not int or value['schema']!=1:raise ValueError('Unsupported settings schema.')
    for key,lo,hi in (('quiet_start',0,1439),('quiet_end',0,1439),('banner_seconds',5,120),('recovery_delay',10,300),('recovery_limit',1,3),('notification_batch_seconds',0,10),('notification_cooldown_seconds',0,300)):
        if type(value[key]) is not int or not lo<=value[key]<=hi:raise ValueError(f'{key} must be between {lo} and {hi}.')
    if value['power'] not in ('Balanced','Low power') or value['recovery_profile'] not in ('Normal','Desktop','Troubleshooting','Low overhead'):
        raise ValueError('Unsupported power or recovery profile.')
    if not isinstance(value['muted_types'],list) or len(value['muted_types'])>40 or any(not isinstance(x,str) or len(x)>100 for x in value['muted_types']):raise ValueError('Invalid muted notification categories.')
    if not isinstance(value['priority_types'],list) or len(value['priority_types'])>40 or any(not isinstance(x,str) or len(x)>100 for x in value['priority_types']):raise ValueError('Invalid priority notification categories.')
    for key,limit in (('discord_application',22),('discord_details',128)):
        if not isinstance(value[key],str) or len(value[key])>limit or any(ord(c)<32 for c in value[key]):raise ValueError('Invalid Discord setting.')
    if value['discord']:
        import re
        if not re.fullmatch('[0-9]{16,22}',value['discord_application']):raise ValueError('A registered public Discord application ID is required before enabling presence.')
    if value['discord_template'] not in ('Custom','World name','World and session'):raise ValueError('Choose a supported presence template.')
    if type(value['autolock_minutes']) is not int or not 0<=value['autolock_minutes']<=120:raise ValueError('Auto-lock must be 0 (off) to 120 minutes.')
    return value


class Desktop:
    def __init__(self,shell):
        self.shell,self.app,self.store=shell,shell.app,shell.store
        try:self.policy=settings(self.store.option(KEY))
        except ValueError:self.policy=settings()
        from desktop_speech import Speech
        self.speech=Speech();self.vr_active=False;self.presence_world=None;self.presence_instance=None
        from desktop_lock import AppLock
        self.app_lock=AppLock(self.app,self.store)
        self.health=ServiceHealth();self.delivery=Delivery(shell);self.presence=Presence();self.automation=Automation(self.store)
        self.next_projection=0;self.projection={};self.closed=False;self.boundary=None;self.revision=0;self.projection_revision=0
        self.tray=None;self.notice='';self.hidden=False

    def configure(self,value,*,source='Desktop controls'):
        from account_actions import local_writable
        local_writable(self.app);value=settings(value)
        if value['autolock_minutes']:
            from desktop_lock import KEY as LOCK_KEY
            if not self.store.option(LOCK_KEY):raise ValueError('Set a local lock passphrase before enabling auto-lock.')
        before=deepcopy(self.policy)
        self.store.set_option(KEY,value);self.policy=value;self.revision+=1
        tools=getattr(self.shell,'session_tools',None)
        if tools:tools.setting_change(before,value,source)
        self.store.set_option('native.history.private-text',value['history_private_text'])
        self.delivery.clear();self.automation.pending.clear();self.automation.recovery=None
        self.tick()

    def tick(self):
        if self.closed:return
        if not self.app.demo and not getattr(self.app,'safe_mode',False):self.app_lock.tick(self.policy['autolock_minutes'])
        if self.tray:
            import queue
            for _ in range(8):
                try:command=self.tray.events.get_nowait()
                except queue.Empty:break
                if command=='show':
                    if self.app.desktop_locked:self.app_lock.show_curtain()
                    else:self.app.root.deiconify();self.app.root.lift();self.hidden=False
                elif command=='quit':self.app.close();return
        from account_header import private
        hidden=private(self.app);blocked=bool(self.app.demo or getattr(self.app,'safe_mode',False))
        minimized=self.app.root.state() in ('iconic','withdrawn')
        from desktop_demand import demand,apply
        apply(self.shell,self.health,demand(self.shell,hidden=hidden,minimized=minimized,power=self.policy['power']))
        hub=hub_for(self.shell);hub.sync()
        photo_service=getattr(self.shell,'photo_service',None)
        if photo_service:
            players=getattr(self.app,'player_sessions',None)
            photo_service.context_projection=(dict(token=photo_service.token(),at=time.monotonic(),session=dict(players.meta))
                if players and self.policy['photo_context'] and not blocked and not hidden and not players.settings.get('incognito') else None)
        if self.boundary!=hub.generation:
            self.boundary=hub.generation;self.projection={};self.next_projection=0;self.automation.pending.clear();self.automation.recovery=None
            self.presence_world=self.presence_instance=None;self.vr_active=False
        if hidden:self.presence_world=self.presence_instance=None;self.vr_active=False
        self.delivery.tick(hub,self.policy,blocked=blocked or hidden)
        from session_restore import offline
        self.health.configure(self.policy['health_poll'] and not blocked and not offline(self.app))
        self.health.request()
        owner=self.shell.companion.snapshot()['ownership']['PRESENCE']['owner']
        enabled=self.policy['discord'] and not blocked and not hidden and owner=='VRC_EYE'
        self.presence.configure(enabled,self.policy['discord_application'],self.presence_payload())
        unity=self.shell.pages.get('Unity Player')
        if unity:
            self.automation.tick(unity.service.snapshot(),self.policy,unity.service,self.shell.companion,blocked=blocked or hidden)
        if time.monotonic()>=self.next_projection:
            tools=getattr(self.shell,'session_tools',None)
            efficient=tools and tools.efficient and self.app.root.state() in ('iconic','withdrawn')
            self.next_projection=time.monotonic()+(5 if minimized or self.policy['power']=='Low power' or efficient else 2)
            self.project(hidden)

    def project(self,hidden=False):
        self.projection_revision=getattr(self,'projection_revision',0)+1
        if hidden:self.projection={'coverage':'Private information hidden'};return
        hub=hub_for(self.shell).project();scope=hub['account'] or 'shared'
        with self.store.native.connect() as db:
            counts={kind:count for kind,count in db.execute('SELECT kind,COUNT(*) FROM eye_native_records WHERE scope IN (?,?) GROUP BY kind',(scope,'shared'))}
        media=self.shell.pages.get('Media & Audio');media_snapshot=media.service.snapshot() if media else {};current=media_snapshot.get('current')
        from dashboard_actions import context
        samples={key:page.service.snapshot() if (page:=self.shell.pages.get(title)) else {}
            for key,title in (('performance','Performance & Security'),('runtime','Unity Player'),('diagnostics','Crash & Diagnostics'))}
        self.projection_context=context(self.app)
        self.projection=dict(checked=time.time(),captured=time.monotonic(),revision=self.projection_revision,account=scope,counts=counts,inbox=len(hub['notifications']),
            unread=sum(r.get('seen') is not True and not r.get('deleted') for r in hub['notifications']),coverage=hub['coverage'],
            media=(getattr(current,'title','') or 'Selected player has no title') if current else 'No fresh media observation',
            service=self.health.snapshot(),discord=self.presence.status,recovery=self.automation.status)
        from dashboard_freshness import observations,labels
        self.projection['observations']=observations(self.shell,media_snapshot,self.projection['service'],samples)
        self.projection['sources']=labels(self.projection['observations'])
        self.projection['coverage_by_widget']={'runtime':'Current summary and newest 200 retained runtime events'}
        from dashboard_rows import project,runtime_rows
        self.projection['widgets']=runtime_rows(self.shell,hub,self.projection,samples=samples)
        self.projection['widgets'].update(project(self.store,scope,analytics=self.policy['analytics'],coverage=self.projection['coverage_by_widget']))
        log=getattr(self.shell,'log',None)
        if log:
            view=log.projection();self.projection['source_revisions']={'gamelog':(view['generation'],view['revision'])}
            self.projection['coverage_by_widget']['gamelog']=f"Newest 200 of {view['retained']} retained log lines; {view['dropped']} rolled out"
            self.projection['widgets']['gamelog']=[dict(id=f"log:{view['generation']}:{r.serial}",name=r.message[:400],type=r.category,
                time=r.stamp,status=r.severity,source='Recorded game log',freshness='Historical log entry; event time shown',
                target=dict(kind='log',id=r.serial,generation=view['generation'])) for r in view['rows']]
        creator=getattr(self.app,'avatar_creator',None)
        if creator and getattr(creator,'_library',None):
            from avatar_transfer_jobs import Transfers
            from pathlib import Path
            for row in Transfers(creator.library).rows('local' if scope=='shared' else scope):
                self.projection['widgets']['downloads'].append(dict(id=row['id'],name=Path(row['destination']).name,type='Avatar transfer',time=row.get('updated_at') or row['created_at'],status=row['state'],source='Avatar Library',freshness='Saved checkpoint; file not rechecked',target=dict(kind='transfer',id=row['id'])))

    def vr_runtime(self):
        return getattr(self.shell.pages.get('Wellness'),'runtime',None)

    def presence_payload(self,policy=None):
        policy=policy or self.policy;world=None;instance=None;elapsed=None
        players=getattr(self.app,'player_sessions',None);meta=getattr(players,'meta',{})
        snapshot=self.presence_world;client=getattr(self.app,'api',None)
        if snapshot and client and snapshot.source_client is client and snapshot.account==(getattr(client,'user_id',''),getattr(client,'session_revision',None)) and 0<=client.clock()-snapshot.checked<120 and not meta.get('ended') and meta.get('world_id')==snapshot.subject and getattr(players,'local_user_id','')==client.user_id:
            world=snapshot.data;candidate=self.presence_instance
            if candidate and candidate.source_client is client and candidate.account==snapshot.account and 0<=client.clock()-candidate.checked<120 and candidate.world==snapshot.subject and meta.get('instance_id') in (candidate.instance,candidate.location):instance=candidate
            if policy['discord_elapsed']:
                from social_history import epoch
                started=epoch(meta.get('started'))
                if started is not None:elapsed=int(started)
        return activity(details=policy['discord_details'],template=policy['discord_template'],world=world,instance=instance,
            art=policy['discord_art'],join=policy['discord_join'],requests=policy['discord_requests'],elapsed=elapsed)

    def start_social_overlay(self):
        from account_actions import local_writable
        from account_header import private
        local_writable(self.app)
        if private(self.app):raise ValueError('Reveal private information before starting the social overlay.')
        if not self.shell.ensure_page('Wellness'):raise ValueError('The shared SteamVR workspace is unavailable.')
        self.vr_runtime().ensure_spatial_inputs();self.vr_active=True
        self.notice='Social overlay armed for this session on the shared SteamVR connection.'

    def show_social_feed(self):
        self.start_social_overlay()
        rows=hub_for(self.shell).project()['notifications'][-5:]
        text='VRC Eye · latest observed notifications\n'+'\n'.join((r.get('senderUsername','')+' · '+str(r.get('message') or r.get('type','Notification')))[:150] for r in rows if not r.get('deleted'))
        self.vr_runtime().display_social(dict(enabled=True,text=text if rows else 'No observed notifications in the current account.',seconds=30))

    def snapshot(self):
        from dashboard_actions import context,workspace
        from dashboard_freshness import aged
        if getattr(self,'projection_context',None)!=context(self.app) or self.projection.get('account')!=workspace(self.app):return {}
        return aged(self.projection)

    def window_close(self):
        if self.policy['close_to_tray']:
            if self.tray is None:
                from desktop_tray import Tray
                self.tray=Tray();self.tray.start()
            if self.tray.ready:self.app.root.withdraw();self.hidden=True;return
            self.shell.ui_notice.set(self.tray.status+'. The window was minimized and can be restored from the taskbar.')
            self.app.root.iconify();return
        self.app.close()

    def profile(self):
        from customization import load
        value=deepcopy(self.policy)
        for key in GRANTS:value[key]=False
        value['discord_application']='';value['discord_details']='';value['autolock_minutes']=0
        return dict(schema=1,kind='vrc-eye-desktop-profile',desktop=value,customization=load(self.app),
                    disabled_grants=list(GRANTS),scope='This device; login sessions and executable approvals excluded')

    def import_profile(self,raw):
        from customization import validate,save
        if not isinstance(raw,dict) or raw.get('schema')!=1 or raw.get('kind')!='vrc-eye-desktop-profile':raise ValueError('Choose a VRC Eye desktop profile.')
        value=settings(raw.get('desktop'));layout=validate(raw.get('customization'))
        for key in GRANTS:value[key]=False
        value['discord_application']='';value['discord_details']='';value['autolock_minutes']=0
        before=self.profile();before['desktop']=deepcopy(self.policy)
        # Both records share the same owned SQLite transaction. Restore never
        # imports login sessions, executable entries or outside-service grants.
        from customization import KEY as UI_KEY
        from account_actions import local_writable
        local_writable(self.app)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for key,item in ((KEY,value),(UI_KEY,layout),('desktop.profile.undo.v1',before),('native.history.private-text',False)):
                db.execute('INSERT OR REPLACE INTO options VALUES(?,?)',(key,json.dumps(item,ensure_ascii=False)))
        self.policy=value;self.revision+=1;self.app._customization_session=None
        home=self.shell.pages.get('Home')
        if home and hasattr(home,'dashboard'):home.dashboard.rebuild(layout)
        self.tick()

    def close(self):
        self.closed=True;self.delivery.clear();self.health.close();self.presence.close();self.automation.close();self.speech.close();self.app_lock.close()
        if self.tray:self.tray.close()


def service_for(shell):
    service=getattr(shell,'desktop_service',None)
    if service is None:service=Desktop(shell);shell.desktop_service=service
    return service
