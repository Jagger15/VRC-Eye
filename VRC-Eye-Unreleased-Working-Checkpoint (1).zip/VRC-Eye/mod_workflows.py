"""Bounded local workflow models. No devices, network, or game side effects."""
from collections import deque
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import json
import math
import time
import uuid

from companion_data import entity_id
from native_library import plain, canonical

KINDS = {'tryouts':'avatar', 'outings':'world', 'setup':'avatar', 'comfort':'world',
         'shots':'world', 'hosts':'user'}
STATES = {'tryouts':('Try later','Keep','Maybe','Pass'), 'outings':('Planned','Visited','Skip'),
          'setup':('Draft','Known good','Needs review'), 'comfort':('Unreviewed','Reviewed','Changed'),
          'shots':('Planned','Requested','Captured','Retake'), 'hosts':('Expected','Observed','Follow up','Done')}
DESKTOP_KEYS = ('dnd','banners','sound','quiet_hours','quiet_start','quiet_end','power',
                'banner_seconds','notification_batch_seconds','notification_cooldown_seconds')
PRESETS = {'Quiet':{'dnd':True,'sound':False,'power':'Low power'},
           'Social':{'dnd':False,'banners':True,'power':'Balanced'},
           'Creator':{'dnd':True,'sound':False,'power':'Balanced'}}


def row(kind, value):
    if kind not in KINDS or not isinstance(value,dict):raise ValueError('Choose a supported card type.')
    allowed={'id','ref','title','notes','state','detail','screenshot','map_file','map_point','version','created','updated','rank','photo','attempts','changes'}
    if set(value)-allowed:raise ValueError('Unsupported card field.')
    result={'id':value.get('id') or uuid.uuid4().hex}
    if not isinstance(result['id'],str) or len(result['id'])!=32 or any(c not in '0123456789abcdef' for c in result['id']):raise ValueError('Invalid card identity.')
    result['ref']=entity_id(KINDS[kind],value['ref'])
    for key,limit in (('title',160),('notes',1500),('detail',500),('screenshot',1024),('map_file',1024),('map_point',60),('version',100)):
        result[key]=plain(value.get(key,''),limit,empty=key!='title')
    result['state']=value.get('state',STATES[kind][0])
    if result['state'] not in STATES[kind]:raise ValueError('Choose a supported card state.')
    for key in ('created','updated','rank'):
        n=value.get(key,time.time() if key!='rank' else 0)
        if type(n) not in (int,float) or not math.isfinite(n) or not 0<=n<=1e12:raise ValueError('Invalid card time/order.')
        result[key]=n
    result['photo']=deepcopy(value.get('photo'))
    if result['photo'] is not None:
        p=result['photo']
        if not isinstance(p,dict) or set(p)!={'path','sha256','bytes','checked'}:raise ValueError('Invalid photo receipt.')
        plain(p['path'],1024,empty=False)
        if not isinstance(p['sha256'],str) or len(p['sha256'])!=64 or any(c not in '0123456789abcdef' for c in p['sha256']):raise ValueError('Invalid photo fingerprint.')
        if type(p['bytes']) is not int or not 0<p['bytes']<=64*1024**2:raise ValueError('Invalid photo size.')
        if type(p['checked']) not in (int,float) or not math.isfinite(p['checked']):raise ValueError('Invalid photo check time.')
    result['attempts']=deepcopy(value.get('attempts',[]))
    if not isinstance(result['attempts'],list) or len(result['attempts'])>20:raise ValueError('At most twenty capture attempts per card.')
    for attempt in result['attempts']:
        if not isinstance(attempt,dict) or set(attempt)-{'at','state','capture_id','photo'}:raise ValueError('Invalid capture attempt.')
    result['changes']=deepcopy(value.get('changes',[]))
    if not isinstance(result['changes'],list) or len(result['changes'])>20:raise ValueError('Invalid card history.')
    for change in result['changes']:
        if not isinstance(change,dict) or set(change)!={'at','before','after'} or change['before'] not in STATES[kind] or change['after'] not in STATES[kind]:raise ValueError('Invalid card state history.')
        if type(change['at']) not in (int,float) or not math.isfinite(change['at']):raise ValueError('Invalid card history time.')
    canonical(result)
    return result


class Cards:
    """Use the existing native profile records, transactions and account scopes."""
    def __init__(self, native, scope):self.native,self.scope=native,scope
    def load(self, kind):
        if kind not in KINDS:raise ValueError('Unknown card type.')
        document=self.native.get(self.scope,'profile','workflow.'+kind)
        values=document['data'].get('cards',[]) if document else []
        if not isinstance(values,list) or len(values)>100:raise ValueError('Invalid saved card collection.')
        return sorted([row(kind,v) for v in values],key=lambda r:(r['rank'],r['created'],r['id']))
    def write(self,kind,values):
        if len(values)>100:raise ValueError('This collection holds at most 100 cards.')
        values=[row(kind,v) for v in values]
        if len({v['id'] for v in values})!=len(values):raise ValueError('Duplicate card identity.')
        data={'schema':1,'cards':values}
        if len(canonical(data).encode())>96*1024:raise ValueError('This collection reached its text budget; shorten notes or remove completed cards.')
        self.native.put(self.scope,'profile','workflow.'+kind,data,provenance={'source':'VRC Eye session tools','privacy':'local'})
    def save(self,kind,value):
        value=row(kind,value);values=self.load(kind);old=next((r for r in values if r['id']==value['id']),None)
        value['created']=old['created'] if old else value['created'];value['updated']=time.time()
        if old:
            value['changes']=old['changes']
            if value['state']!=old['state']:value['changes']=(value['changes']+[dict(at=time.time(),before=old['state'],after=value['state'])])[-20:]
            value['rank']=old['rank'];values=[value if r['id']==value['id'] else r for r in values]
        else:value['rank']=max((r['rank'] for r in values),default=-1)+1;values.append(value)
        self.write(kind,values);return value
    def remove(self,kind,identifier):self.write(kind,[v for v in self.load(kind) if v['id']!=identifier])
    def move(self,kind,identifier,delta):
        values=self.load(kind);index=next((i for i,v in enumerate(values) if v['id']==identifier),None)
        if index is None:raise ValueError('Select an existing card.')
        target=max(0,min(len(values)-1,index+delta));values.insert(target,values.pop(index))
        for rank,v in enumerate(values):v['rank']=rank
        self.write(kind,values)


def segments(text):
    """Unicode graphemes, preferred sentence/word breaks, native UTF-16 bounds."""
    from osc_controls import preview_chat
    text=text.replace('\r\n','\n').replace('\r','\n') if isinstance(text,str) else text
    plain(text,6000,empty=False)
    try:
        import regex
    except ImportError:raise ValueError('Composer segmentation requires the regex dependency; restart with the launcher.') from None
    clusters=regex.findall(r'\X',text.replace('\r\n','\n').replace('\r','\n'))
    result=[]
    while clusters:
        current=[];units=lines=0;last_break=0
        for piece in clusters:
            size=len(piece.encode('utf-16-le'))//2
            if units+size>144 or lines+piece.count('\n')>8:break
            current.append(piece);units+=size;lines+=piece.count('\n')
            if piece.isspace() or piece in ('.','!','?','。','！','？'):last_break=len(current)
        if not current:raise ValueError('A single character sequence exceeds the chatbox limit.')
        count=len(current)
        if count<len(clusters) and last_break>=count//2:count=last_break
        part=''.join(clusters[:count]);clusters=clusters[count:]
        if part.strip():preview_chat(part);result.append(part)
        if len(result)>32:raise ValueError('Use at most 32 message segments per review.')
    if not result:raise ValueError('Enter a message.')
    return result


class Composer:
    def __init__(self,controls,clock=time.monotonic):
        self.controls,self.clock=controls,clock;self.parts=[];self.current=None;self.completed=0;self.state='Draft';self.deadline=0
    def begin(self,text,guard):
        value=segments(text);self.cancel();self.parts=value;self.guard=guard;self.deadline=self.clock()+600;self.completed=0;self.state='Queued'
    def cancel(self):
        self.controls.cancel_chat_producer('accessible-composer');self.parts=[];self.current=None;self.state='Cancelled; already submitted text cannot be recalled'
    def tick(self):
        if not self.parts and not self.current:return
        if not self.guard() or self.clock()>self.deadline:self.cancel();return
        snap=self.controls.snapshot()['chat']
        if self.current:
            if any(v['id']==self.current for v in snap['pending']):return
            previous=next((v for v in reversed(snap['history']) if v['id']==self.current),None)
            if not previous or previous['status']!='submitted':self.cancel();self.state='Stopped: segment not submitted';return
            self.completed+=1;self.current=None
        if not self.parts:self.state='All segments submitted; receipt by other users unverified';return
        try:
            review=self.controls.review('chat.publish',text=self.parts[0],producer='accessible-composer',kind='user',ttl=60)
            publication=self.controls.execute(review);self.current=publication['id'];self.parts.pop(0)
            self.controls.guard_chat_publication(self.current,self.guard)
            self.state=f'{self.completed} submitted · {len(self.parts)+1} remaining'
        except ValueError:
            self.cancel();self.state='Stopped: review OSC chat permission and connection';raise


class Costs:
    def __init__(self,clock=time.perf_counter):self.clock=clock;self.rows={};self.started=clock()
    @contextmanager
    def measure(self,label):
        start=self.clock()
        try:yield
        finally:
            ms=max(0,(self.clock()-start)*1000)
            if label not in self.rows and len(self.rows)>=64:label='Other instrumented callbacks'
            r=self.rows.setdefault(label,dict(count=0,total_ms=0.,max_ms=0.,slow=0))
            r.update(count=r['count']+1,total_ms=r['total_ms']+ms,max_ms=max(r['max_ms'],ms),slow=r['slow']+int(ms>50))
    def snapshot(self):
        seconds=max(.001,self.clock()-self.started)
        return [dict(feature=k,**v,mean_ms=v['total_ms']/v['count'],per_second=v['count']/seconds) for k,v in self.rows.items()]


def hierarchy_nodes(manifest,query='',root='',baseline=None,changes_only=False):
    values=manifest.get('hierarchy',[])
    if len(values)>2000:raise ValueError('Hierarchy exceeds the creator manifest limit.')
    nodes={v['id']:deepcopy(v) for v in values};old={v['id']:v for v in (baseline or {}).get('hierarchy',[])}
    changed={}
    for key,v in nodes.items():
        before=old.get(key);labels=[]
        if baseline is not None:
            if before is None:labels=['Added']
            else:
                for field,label in (('name','Renamed'),('parent','Reparented'),('components','Components changed')):
                    if before.get(field)!=v.get(field):labels.append(label)
        changed[key]=', '.join(labels)
    matches={k for k,v in nodes.items() if query.casefold() in (' '.join((v.get('name',''),k,*v.get('components',[])))).casefold() and (not changes_only or changed[k])}
    def parents(key):
        seen=set()
        while key in nodes and key not in seen:
            seen.add(key);yield key;key=nodes[key].get('parent','')
    if root:matches={k for k in matches if root in set(parents(k))}
    included=set(matches)
    for key in matches:included.update(parents(key))
    result=[]
    for key,v in nodes.items():
        if key in included:
            v['change']=changed[key];v['matched']=key in matches
            v['breadcrumb']=' / '.join(nodes[k].get('name',k) for k in reversed(list(parents(key))))
            result.append(v)
    removed=[dict(v,change='Removed',matched=True,breadcrumb='Previous manifest') for k,v in old.items() if k not in nodes and (not query or query.casefold() in str(v).casefold())]
    return result,removed


def preset_changes(value):
    if not isinstance(value,dict) or not value or set(value)-set(DESKTOP_KEYS):raise ValueError('Presets contain supported presentation/notification settings only.')
    from desktop_service import settings
    settings(value)
    return deepcopy(value)


def redact_activity(metadata):
    """Structural categories only: no URLs, identities, text or raw error bodies."""
    category=str(metadata.get('route',metadata.get('path',''))).split('?',1)[0].strip('/').split('/',1)[0]
    if category not in ('auth','users','worlds','avatars','groups','friends','favorites','notifications','files','inventory','prints','instances','visits'):
        category='other'
    status=metadata.get('status')
    if status not in ('completed','complete','success','error'):status='attempted'
    duration=metadata.get('duration_ms',0)
    duration=min(1e7,max(0,float(duration))) if type(duration) in (int,float) and math.isfinite(duration) else 0
    method=metadata.get('method','GET')
    return dict(at=time.time(),feature='VRChat API',destination='VRChat API',purpose=category,
                fields='Authentication fields' if category=='auth' else 'Selected endpoint fields (contents omitted)',
                method=method if method in ('GET','POST','PUT','PATCH','DELETE') else 'Other',
                state=status,dispatched=metadata.get('dispatched') is True,duration_ms=duration)
