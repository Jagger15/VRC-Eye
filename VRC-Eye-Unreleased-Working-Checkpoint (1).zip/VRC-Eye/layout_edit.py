"""Reversible editing of registered desktop layout elements, locked per session."""
from copy import deepcopy
from tkinter import TclError
from customization import load,save


def require_unlocked(app):
    manager=getattr(getattr(app,'experience',None),'layout_editor',None)
    if manager is not None and manager.locked:raise ValueError('Unlock the layout using the visible lock button before moving, resizing or hiding tiles.')


def edit_rows(rows, identifier, action, amount=1, *, target=None):
    rows=deepcopy(rows);row=next((r for r in rows if r['id']==identifier),None)
    if action=='restore':
        for r in rows:r['hidden']=False
        return rows
    if row is None:raise ValueError('This tile is no longer in the layout. Open the current layout.')
    if action=='hide':row['hidden']=True
    elif action=='show':row['hidden']=False
    elif action=='width':
        current=row.get('span',0) or (3 if row['size']=='Wide' else 1)
        row['span']=max(1,min(3,current+amount))
    elif action=='height':row['height']=max(0,min(1200,row.get('height',0)+amount*50))
    elif action=='move':
        group=[r for r in rows if r['pinned']==row['pinned'] and not r.get('hidden',False)]
        if target is None:
            index=group.index(row);target=group[max(0,min(len(group)-1,index+amount))]['id']
        other=next((r for r in group if r['id']==target),None)
        if other is None:raise ValueError('Move within the pinned or unpinned group; change Pin in Customization to switch groups.')
        at=rows.index(other);rows.remove(row);rows.insert(at,row)
    elif action=='dimensions':
        width,height=amount
        if type(width) is not int or not 1<=width<=3 or type(height) is not int or not 0<=height<=1200:raise ValueError('Use 1–3 columns and a minimum height from 0–1200.')
        row.update(span=width,height=height)
    else:raise ValueError('Choose a supported layout edit.')
    return rows


class LayoutEditor:
    def __init__(self,experience):
        self.experience=experience;self.app=experience.app;self.root=self.app.root
        self.locked=True;self.drag=None;self.history=[];self.editing_layout=None;self.context=self.boundary()
        self.status=self.app.tk.StringVar(value='Layout locked. Unlock to move, resize or hide Home tiles.')
        self.caption=self.app.tk.StringVar(value='Layout locked')
        from screen_reader_model import annotate
        self.button=annotate(self.app.ttk.Button(self.app.header_actions,textvariable=self.caption,command=self.toggle),public=True,
                             name='Layout lock',value=lambda:'Locked' if self.locked else 'Unlocked',description='Toggle direct layout editing. Locked at every startup. Hidden tiles can be restored.')
        self.button.pack(side='left',padx=6)
        self.icons={};self.paint_icon()

    def boundary(self):
        from account_header import boundary,private
        return boundary(self.app),private(self.app)

    def paint_icon(self):
        # A small built-in bitmap avoids depending on an emoji font.
        from tkinter import BitmapImage
        try:
            rows=[]
            for y in range(18):
                row=0
                for x in range(18):
                    body=3<=x<=14 and 8<=y<=16
                    loop=(x in (5,12) and 3<=y<=8) or (y in (1,2) and 7<=x<=10)
                    if not self.locked:loop=(x==12 and 3<=y<=8) or (x==5 and 3<=y<=5) or (y in (1,2) and 7<=x<=10)
                    if body or loop:row|=1<<x
                rows.extend(((row>>shift)&255 for shift in (0,8,16)))
            data='#define lock_width 18\n#define lock_height 18\nstatic unsigned char lock_bits[] = {'+','.join(hex(b) for b in rows)+'};'
            self.icon=BitmapImage(master=self.root,data=data,foreground=self.app.ACCENT)
            self.button.configure(image=self.icon,compound='left')
        except (TclError,AttributeError,RuntimeError):pass  # Text still identifies state in headless fixtures.

    def home(self):
        return getattr(self.app.sidebar.pages.get('Home'),'dashboard',None)

    def toggle(self):
        self.set_locked(not self.locked)

    def set_locked(self,locked):
        self.locked=bool(locked);self.drag=None;self.context=self.boundary()
        home=self.home()
        self.editing_layout=home.active_name if not locked and home else None
        self.caption.set('Layout locked' if locked else 'Layout unlocked')
        self.status.set('Layout locked.' if locked else 'Editing Home tiles. Drag handles or use Move / Resize / Hide buttons. Changes save immediately; Undo and Restore hidden are available.')
        self.paint_icon()
        if home:home.rebuild()
        self.experience.notice.set(self.status.get())

    def resolve(self,settings,resolved):
        if self.locked:return resolved
        if self.editing_layout not in settings['layouts']:self.editing_layout=resolved['name']
        rows=[deepcopy(r) for r in settings['layouts'][self.editing_layout] if not r.get('hidden',False)]
        return dict(name=self.editing_layout,reason='Layout editing; automatic switching paused',rows=rows)

    def check(self):
        if self.boundary()!=self.context:
            if not self.locked:self.set_locked(True)
            self.context=self.boundary();self.drag=None
        require_unlocked(self.app)

    def edit(self,identifier,action,amount=1,*,target=None,expected=None):
        self.check();home=self.home()
        if home is None:raise ValueError('Open Home to edit its tiles.')
        value=load(self.app);before=deepcopy(value);name=home.active_name
        rows=value['layouts'].get(name)
        if rows is None:raise ValueError('That layout has been removed.')
        if expected is not None and rows!=expected:raise ValueError('The layout changed during the drag. Try again.')
        updated=edit_rows(rows,identifier,action,amount,target=target)
        if updated==rows:return
        value['layouts'][name]=updated
        save(self.app,value,'Home tile '+action,expected=before)
        self.history.append((name,deepcopy(rows),deepcopy(updated)));self.history=self.history[-20:]
        self.refresh_editor();self.status.set('Tile layout saved'+(' for this session.' if self.app.demo or getattr(self.app,'safe_mode',False) else '.'))

    def undo(self):
        self.check()
        if not self.history:raise ValueError('No direct layout edit to undo in this session.')
        name,before,after=self.history[-1];value=load(self.app);expected=deepcopy(value)
        if value['layouts'].get(name)!=after:raise ValueError('This layout changed in another editor. Undo cannot overwrite those changes.')
        value['layouts'][name]=deepcopy(before);save(self.app,value,'Direct layout edit undone',expected=expected)
        self.history.pop();self.refresh_editor();self.status.set('Previous tile layout restored.')

    def refresh_editor(self):
        editor=self.app.sidebar.pages.get('Customization')
        if editor is not None and hasattr(editor,'state'):editor.state=load(self.app);editor.refresh()

    def resize_height(self,home,identifier,amount):
        self.check()
        row,box=next((r,b) for r,b in home.cards if r['id']==identifier)
        scale=self.experience.preferences.font_percent/100
        from math import ceil
        base=max(row.get('height',0),ceil(box.winfo_height()/scale/50)*50)
        height=max(0,min(1200,base+amount*50))
        self.edit(identifier,'dimensions',(row.get('span',0) or (3 if row['size']=='Wide' else 1),height))

    def toolbar(self,home,parent):
        from companion_ui import button
        from friendly_ui import flow_line
        row=flow_line(home.page,parent)
        button(home.page,row,'Lock layout' if not self.locked else 'Unlock layout',self.toggle)
        if not self.locked:
            button(home.page,row,'Undo layout edit',self.undo)
            button(home.page,row,'Restore hidden tiles',lambda:self.edit(None,'restore'))
        home.page.ttk.Label(parent,textvariable=self.status,wraplength=750).pack(anchor='w',fill='x',pady=5)

    def handles(self,home,parent,row):
        if self.locked:return
        from companion_ui import button
        from friendly_ui import flow_line
        grip=home.page.ttk.Label(parent,text='Move tile · drag here',cursor='fleur',style='CardMuted.TLabel')
        grip.pack(anchor='w',fill='x',pady=4)
        grip.bind('<ButtonPress-1>',lambda e:self.begin(home,row['id'],'move',e))
        grip.bind('<B1-Motion>',self.motion);grip.bind('<ButtonRelease-1>',self.drop)
        controls=flow_line(home.page,parent)
        for title,action,amount in (('Earlier','move',-1),('Later','move',1),('Narrower','width',-1),('Wider','width',1),('Shorter','height',-1),('Taller','height',1),('Hide','hide',1)):
            b=button(home.page,controls,title,lambda a=action,n=amount:self.resize_height(home,row['id'],n) if a=='height' else self.edit(row['id'],a,n))
            b._eye_focus_identity=('layout',row['id'],title)
        resize=home.page.ttk.Label(parent,text='Resize tile · drag here',cursor='sizing',style='CardMuted.TLabel')
        resize.pack(anchor='e',pady=4)
        resize.bind('<ButtonPress-1>',lambda e:self.begin(home,row['id'],'resize',e))
        resize.bind('<B1-Motion>',self.motion);resize.bind('<ButtonRelease-1>',self.drop)
        for handle in (grip,resize):handle.bind('<Escape>',lambda _:self.cancel_drag())

    def begin(self,home,identifier,action,event):
        try:
            self.check();rows=deepcopy(load(self.app)['layouts'][home.active_name]);row=next(r for r in rows if r['id']==identifier)
            row=deepcopy(row)
            box=next(b for r,b in home.cards if r['id']==identifier)
            row['_display_height']=round(box.winfo_height()/self.experience.preferences.font_percent*100/50)*50
            self.drag=(home,identifier,action,event.x_root,event.y_root,rows,self.boundary(),row)
            event.widget.focus_set()
            self.status.set('Release over a tile to move, or release to set its minimum size. Escape cancels.')
        except (ValueError,StopIteration) as error:self.status.set(str(error))
        return 'break'

    def motion(self,event):
        if self.drag:self.status.set('Drag preview: '+str(event.x_root-self.drag[3])+' px across, '+str(event.y_root-self.drag[4])+' px down. Release to apply; Escape cancels.')
        return 'break'

    def cancel_drag(self):self.drag=None;self.status.set('Layout drag cancelled.');return 'break'

    def drop(self,event):
        drag=self.drag;self.drag=None
        if drag is None:return 'break'
        home,identifier,action,x,y,rows,context,row=drag
        try:
            self.check()
            if self.boundary()!=context or self.home() is not home:raise ValueError('The workspace changed. Drag cancelled.')
            focused=self.root.focus_get()
            if focused is None or focused.winfo_toplevel() is not self.root or self.root.grab_current() is not None:
                raise ValueError('Focus moved away from the layout. Drag cancelled.')
            if not (home.frame.winfo_rootx()<=event.x_root<home.frame.winfo_rootx()+home.frame.winfo_width() and home.frame.winfo_rooty()<=event.y_root<home.frame.winfo_rooty()+home.frame.winfo_height()):
                self.status.set('Released outside the layout. Drag cancelled.');return 'break'
            if action=='move':
                target=next((r['id'] for r,box in home.cards if box.winfo_rootx()<=event.x_root<box.winfo_rootx()+box.winfo_width() and box.winfo_rooty()<=event.y_root<box.winfo_rooty()+box.winfo_height()),None)
                if target:self.edit(identifier,'move',target=target,expected=rows)
            else:
                columns=max(1,min(3,home.frame.winfo_width()//320));unit=max(1,home.frame.winfo_width()/columns)
                width=max(1,min(3,(row.get('span',0) or (3 if row['size']=='Wide' else 1))+round((event.x_root-x)/unit)))
                scale=self.experience.preferences.font_percent/100
                height=max(0,min(1200,max(row.get('height',0),row['_display_height'])+round((event.y_root-y)/(50*scale))*50))
                self.edit(identifier,'dimensions',(width,height),expected=rows)
        except ValueError as error:self.status.set(str(error))
        return 'break'

    def tick(self):
        if self.boundary()!=self.context:
            if not self.locked:self.set_locked(True)
            self.context=self.boundary()

    def close(self):self.drag=None;self.history.clear()
