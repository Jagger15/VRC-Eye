# VRC Eye 1.19.8 — Client Bridge Lab guide

## What is included

This update builds on VRC Eye 1.19.7. **Client Bridge Lab — Unsupported & Experimental** is the ninth Developer / Black Lab section. Eight views implement inspection, reviewed experiments, recovery evidence, and voluntary playtest comparisons. The original API Workbench, account connection, OSC service, local bridge and Eye-to-Eye service remain the shared foundations.

There are **13 new, versioned bridge capabilities: seven telemetry channels and six action contracts**. VRC Eye implements their validation, permissions, dispatch, observation, review and report paths. The Python provider SDK implements the same pre-dispatch checks. The isolated Sandbox supplies an in-memory provider so the workflows can be exercised immediately without a VRChat account.

**No VRChat-specific runtime plugin, modified client, injected DLL, or compiled Unity integration is supplied by this update.** Live telemetry and effects require a separately implemented compatible provider, explicitly connected and approved by the user. The SDK and a successful synthetic test do not establish that such a provider exists for a particular client, that its claims are true, or that its implementation is approved by VRChat. All live compatibility remains unverified.

The original 58-entry API catalog is retained: 37 read adapters, 18 write adapters and three reference-only entries. This release adds bridge evidence and comparisons; it does not claim new web endpoints or replace the existing authentication model.

## Start and navigation

Close the old running copy. Extract the entire **VRC-Eye-v1.19.8.zip** into a new folder, open **VRC-Eye**, and run **Start.cmd**. Keep the files together. The four Windows launchers and requirements.txt are unchanged from 1.19.7. Automatic dependency preparation remains part of startup; no new installation script is required.

Choose **Developer** in the top View selector. Open **Advanced → Developer / Black Lab**, then choose **Client Bridge Lab** in the workspace selector. Its own selector exposes Self-avatar, Parameters, Local isolation, Module isolation, Recovery, Creator diagnostics, API/runtime comparison and Playtest comparison. **Ctrl+K** finds the lab, individual views and networking settings. There are now 77 indexed destinations.

Page bodies scroll vertically. Tables and detail editors retain their own scrollbars. The main views were exercised with native Tk on Linux, including a 1060 × 720 Larger-text/Compact layout; this is not Windows DPI or screen-reader certification.

Connection configuration remains under **VRC Eye → Networking → Client Bridge**. Its button opens the existing authenticated local bridge connection and permission dialog. There is no second independent bridge listener. **API settings** opens the separate Developer API networking configuration.

Opening a view does not start a listener, pair a provider, enable game controls, grant OSC access, send peer messages or arm live actions. Developer access still requires no entitlement key.

## Environments and permission layers

**Sandbox** is the default. Its in-memory provider exercises the real bridge schemas, BridgeState permission rules, request queue, acknowledgements and observation lifecycle. It has synthetic account/resource identifiers and deliberately synthetic performance values. It has no API connection, login credential, bridge socket, process access or OSC sender. The lab's internal simulated grants do not grant anything to the application's live bridge.

**Live** uses the application's existing optional ClientBridge and existing services. A provider must be connected, attached to the appropriate account/runtime, explicitly approved, responsive and publishing fresh context. Each telemetry channel and each action needs its own capability approval. Temporary actions additionally need the separate restore capability. The existing connection's game-control permission and the lab's session-only **Arm live lab controls** switch are both required. API write arming and OSC permissions are separate and unchanged. Demo and Safe mode cannot execute live lab controls.

**Replay** has no bridge executor. In this new lab it displays a previously exported, bounded, sanitized report as data; it does **not** re-execute a captured command or implement a new full event-replay engine. The original Developer Testing Lab retains its separate deterministic player-event replay tools.

Sandbox isolation is not an application-wide offline switch: unrelated normal features may still be running. Changing the Developer environment or account invalidates lab reviews, clears account-scoped capture, and disarms controls. A connection, permissions, avatar/world or configuration transition also invalidates experiment context. No queued action is transferred to a new context.

## The eight views

### 1. Self-avatar state timeline

The timeline shows provider-supplied initialization, animator, tracking and configuration observations for the user's own avatar. Rows preserve local arrival ordering, elapsed time, context revision, phase and available posture/tracking values. Identical repeated snapshots are collapsed so changes remain visible. Missing telemetry is unavailable, not a fabricated zero.

`Upright`, `TrackingType`, `VRMode`, `InStation` and the other known built-in avatar parameters are observation-only in the lab. The tool can expose a reported posture change alongside initialization, but does not conclude which component caused it or promise to repair posture automatically. The provider's capture-cost report and VRC Eye's measured local lab-tick cost are separate values.

### 2. Parameter tracing and temporary experiments

Select a fresh custom parameter. Its row shows observed value, declared type, writability, synchronization/persistence information, revision and a reported writer when supplied. Unknown synchronization, persistence or writer information stays unknown.

Enter one JSON value (`true`, `false`, an integer or a decimal) and a **1–60 second** duration. Select **Prepare parameter test**. Preparation validates the target and creates an expiring review; it does not dispatch anything. Inspect the exact requested value, current value/revision, account/avatar context, possible synchronized or persistent effects, and restoration conditions. Confirm the exact experiment separately.

Custom writes are bounded to the declared supported bool/int/float ranges. Built-ins cannot become writable through provider advertising. One active experiment is allowed at a time. The trace separates requested, dispatched, acknowledged and subsequently observed state. A reported writer is a provider claim, not independent proof. A later changed revision is preserved rather than overwritten to force the test's value.

The existing OSC inspector is reachable from this view. In Live the lab can inspect the shared service's recorded own-avatar parameter actions; it does not start OSC or secretly route a bridge test through OSC. A general multi-step sequence runner, preset library and automatic controller arbitration are not included in this release.

### 3. Local rendering and audio isolation

The provider may advertise a narrowly scoped list of presentation targets. The new lab exposes only **hide**, **suppress audio**, **reduce effects** or **minimal effects**, with a reviewed temporary duration. It has no command to reveal blocked content, show hidden players, see through barriers or disable protections.

The ledger retains the baseline metric, the metric after the reduction and a separate metric after restoration when available. Its comparison is a **single-sample correlation**, not a statistical benchmark, proof of causation or attribution of malicious intent. The displayed performance values in Sandbox are synthetic fixtures.

### 4. Integration-module isolation

Inspect integration-owned module IDs, versions, configuration revisions, paused state and reported pause support. Only modules classified as diagnostic, overlay or input-routing are eligible for the scoped pause experiment. Authentication, anti-cheat, security, privacy, enforcement and unknown modules remain ineligible even when a provider advertises them as pausable.

Prepare one module pause, review it, observe the reported effect, then restore conditionally. This is not a universal process/module disabler or a code-loading console.

### 5. Targeted integration recovery

Choose one named operation against the exact integration-owned channel: rebuild telemetry subscriptions, reopen the diagnostic channel, reload validated integration configuration, or reset an integration-owned parameter route. The review describes that bounded effect. These contracts do not reload an avatar, change a microphone, reset safety preferences or leave an instance.

The ledger keeps **requested**, **acknowledged**, **new correlated telemetry**, and **health check satisfied** as distinct milestones. A successful acknowledgement alone is not healthy recovery. The provider must subsequently publish the matching recovery ID, a newer telemetry revision and a healthy report. Missing or degraded evidence remains unconfirmed; the local recovery observation window is bounded.

### 6. Creator-exposed diagnostics

The view displays a bounded creator manifest: its ID/revision, diagnostic fields, named controls, declared effects and expiring account/session authority. Review the manifest explicitly, then separately prepare and confirm one eligible control. Authorship alone is not treated as authority over a live session.

Only explicitly authorized, nonpersistent, nondestructive shared-test controls from the reviewed manifest are eligible. Arbitrary command payloads, unrestricted live variables and universal object editing are not present. Provider-reported authority is still a claim; the provider must check real permission at execution. Acknowledgement does not prove completion of the world-side effect.

This release consumes the manifest contract; it does not ship a new Udon transport, SDK build orchestrator or automatic creator-helper installation. Existing creator tooling remains available separately.

### 7. API versus runtime comparison

Use the existing API Workbench to deliberately capture an `account.get` result. The lab observes that already-authorized result; opening the comparison sends no hidden refresh. It compares account/selected-avatar evidence with fresh bridge context and available shared OSC context, keeping observation times, age and source limitations visible.

An `avatar.get` response establishes that an avatar record was read, **not** that the account selected it. Mismatched accounts, missing context, old evidence, cached responses and unknown OSC observation age are distinguished. API disagreement never initiates a correction, repeated selection, login or credential transfer. A corrective API action still requires the existing API review path.

### 8. Cooperative playtest comparison

Start or deliberately join an exact generated test ID. For live Eye-to-Eye sharing, use a Creator playtest already shared through the existing service, or choose a ready peer and **Use selected peer session as test ID**. A new arbitrary local test does not establish authority for a network context. Supported IDs are canonical UUIDs or the service's 32-character lowercase hexadecimal IDs.

All three sharing categories start **off**: milestone, performance and avatar state. Select only what to include, preview the exact card, and explicitly export or send it. Live sending uses the existing authenticated Eye-to-Eye diagnostics permission and context checks. A recipient must accept an incoming card before the lab's **Load accepted cards** operation includes it. Old sessions and rejected/pending cards are excluded. Cards can also be deliberately imported as bounded data and compared locally.

Milestone timing comes from a creator-exposed boolean observation after joining the local test, not from clicking the preview button. Missing providers and unobserved events remain missing evidence. Cards include a per-test provider reference, contract revision and bounded version claim, but no account ID, private instance code or credential.

Independent local starts are **not** comparable as synchronized clocks. Optional shared-cue alignment uses participant-supplied uncertainty, not measured clock synchronization. The comparison displays the timing difference and the sum of those uncertainty bounds, conditional on the participants' assumptions. Synthetic cards never become live-playtest evidence. Repeated cards or the same provider reference are not treated as independent participants; distinct participant identity is not independently certified. At most 32 supplied cards are held in the comparison.

## Reviews, temporary lifetimes and restoration

Reviews expire after **30 seconds**, are single-use, and are bound to connection, runtime session, account, avatar/world, configuration, permissions, target and exact payload. Context freshness and target revision are checked at preparation, execution, queue dispatch and provider-SDK callback dispatch. The provider remains responsible for the final atomic comparison with its current state.

The inherited bridge queue and local request budget remain in use. A restore waiting for the local budget has not been sent; a sent action with a lost acknowledgement is not automatically duplicated. The web API's separate shared pacing is unaffected.

A temporary experiment has a real 1–60 second lease. The provider must retain the exact baseline, applied value/revision, expiry and context. It must enforce lease expiry locally, including when VRC Eye disappears. The Sandbox models that behavior, but VRC Eye cannot certify that an external implementation follows it.

**Stop / restore** cancels unsent work and attempts a named inverse only while current context and state still match the experiment's applied revision/value. A newer user or controller revision is never blindly overwritten. Merely seeing the old value again does not prove which component restored it. An unknown acknowledgement, lost connection or context transition can end with **Restoration unconfirmed**. Neither stopping the app nor disconnecting the provider guarantees undo. Consult the visible ledger rather than assuming that a button returning means the effect is gone.

## Offline scenarios

The Sandbox selector supports posture transition, competing writer, context change, disconnect, lost acknowledgement and recovery-unhealthy scenarios. Lost acknowledgement applies to the next synthetic request. Reset Sandbox creates a new isolated fixture; it does not reconnect a real bridge or change live permissions.

For a practical parameter test, choose AccessoryEnabled, prepare `true` for five seconds, confirm, inspect the trace and press Stop / restore. For conflict handling, inject competing_writer while the temporary change is active. For uncertain outcomes, reset, inject lost_ack, and execute the reviewed synthetic request. Observe the outcome instead of repeatedly resending it. These are local fixture experiments, not traffic sent to VRChat.

## Reports and retention

The timeline and parameter trace each retain at most 400 records, the ledger 100 experiments, and the bridge's lab-event ring 256 records with a byte bound. Drop counters are visible. These are bounded in-memory diagnostics, not a permanent record of all players' behavior.

**Preview report** builds a sanitized local report. **Export reviewed report…** requires that preview and explicitly creates a new file; it does not silently overwrite one. The export includes selected own-avatar transitions, experiment milestones without target identities, drop counts and capture overhead. It excludes account/resource identifiers, private instance codes, pairing secrets, credentials, parameter names/values, free provider text, module names, creator payloads, peer cards/identities, notes and wellness information.

A local inspection window may display authorized IDs or values; it is not itself a sanitized export. Screenshots of that window need separate review. Cooperative cards are separate deliberate disclosures, not automatically attached to a report. A Replay import is limited to 256 KiB of supported-format data and never executed.

## Provider implementation contract

The existing Python **bridge_sdk.py** remains the optional provider interface. The additive wire protocol keeps major version 1 and individually negotiates capability version 1. **client_bridge_lab_contracts.json** contains the closed catalog and synthetic examples for reference; loading it does not register new executable capabilities. Executable validation is in **bridge_lab_contract.py**.

Publish lab.context first, tied to the authenticated bridge's attached account and runtime. Its avatar/world/configuration context uses monotonically increasing revisions; use a private local world-session nonce, not a private instance access code. Publish the dependent channels under that exact context and retain truthful observation age. Unknown keys, oversized batches, mismatched types and unreviewed capability names are rejected. Missing data must not be synthesized as successful observations.

Action callbacks run only through explicit **dispatch_pending()** on the provider's appropriate thread. The SDK rechecks approved fresh context/target state before calling them. A provider must additionally make the actual mutation and revision check atomic, verify actual live-session authority, enforce the lease, stop stale queued work, and publish independent post-action observations. Do not return an acknowledgement as proof of observed effect. Do not export VRChat login material to this protocol.

**tests/test_bridge_lab_sdk.py** includes an authenticated local Unix-socket host/SDK exercise using an entirely in-memory synthetic backend. It covers dispatch, observation and restoration. It is not a VRChat provider or evidence that Windows named-pipe/runtime integration works. **tests/test_bridge_lab_contract.py**, **test_bridge_lab_service.py**, **test_bridge_lab_peers.py** and **test_bridge_lab_native.py** cover schema, lifetimes, uncertainty, sharing and native UI behavior.

## Connection status correction

The shared peer transport now removes its final peer and publishes DISCONNECTED
under the same lock, before potentially yielding during socket disposal. This
prevents a transient empty peer list with a stale CONNECTED status. A deterministic
cleanup-boundary test covers joined, hosting and private states; hosting remains
LISTENING and application shutdown remains PRIVATE. This is separate from lab
capability permissions and does not reconnect a peer automatically.

## Compatibility and references

VRChat's documentation states that built-in avatar parameters are read-only through Expressions Menus and OSC, while creator-defined custom parameters can be configured to synchronize. Its OSC documentation provides the supported parameter input/output surface. This is why an own-avatar write is not described as necessarily screen-local. [Animator parameters](https://creators.vrchat.com/avatars/animator-parameters/) · [OSC avatar parameters](https://docs.vrchat.com/docs/osc-avatar-parameters).

VRChat's Community Guidelines prohibit application modification and anti-tamper circumvention. An experimental or local label does not confer platform approval. The web API also has separate published usage and authentication conditions; the existing application's public-distribution authentication review remains unresolved. [Community Guidelines](https://hello.vrchat.com/community-guidelines) · [Creator Guidelines](https://hello.vrchat.com/creator-guidelines). These references were checked on 2026-10-02.

See **CLIENT_BRIDGE_LAB_CAPABILITIES.md** for the exact implementation matrix, **CLIENT_BRIDGE_LAB_DESIGN_INPUT.md** for the supplied source proposal, and **VALIDATION.md / BUILD_VALIDATION.json** for measured checks and limitations. No live VRChat account, real avatar/world runtime, external multiplayer playtest or Windows desktop was used to validate this release.

Final source validation: **2,727 tests, 1,141 subtests**, one pre-existing collection warning. See VALIDATION.md for the separate unresolved intermittent networking-test observation.
