# VRC Eye 1.21.0 — Development 11

This checkpoint builds on the complete Development 10 source. It adds the three
selected improvements: persistent pictures, friend-location filters and more
specific watchlist alerts. It retains the automatic API sync, reconnect recap,
avatar-search picture fix, global quick search and reviewed status rules.

## Picture cache

Open **Picture cache…** from Search, global quick search, the avatar search
window, Feed → Locations, or Desktop controls → Setup.

- Persistence is enabled by default. Choose a 32, 64, 128 or 256 MiB picture-data
  limit; the default is 128 MiB. SQLite overhead is additional. The cache also
  keeps at most 3,000 entries across all accounts and removes the least recently
  used previews when either limit is exceeded.
- Avatar, player and world pictures use the same loader. Each account has its
  own cached previews; another account cannot reuse them.
- Online previews are reused for up to 24 hours. Older pictures can be shown in
  Offline mode for up to 30 days and are labeled on search tiles. Offline cache
  misses do not request a picture from the network. The signed-in account still
  establishes which cached pictures can be read; this is not offline login.
- **Inspect usage** shows entry count, picture bytes and database size.
  **Clear this account** and **Clear all pictures** remove disposable previews.
  Older pending image workers cannot refill a cleared cache. Already displayed
  pictures remain visible, and new requests may cache pictures again.
- Disabling persistence stops disk reads/writes by the loader and clears its
  small memory cache. Existing disk pictures remain until cleared or later
  eviction; disabling persistence does not delete files.

The cache is `picture-previews.sqlite3` beside Eye's companion database. It stores
bounded PNG previews and hashed account/URL keys, never cookies, credential
material or plaintext URLs. Pictures are ordinary local files protected by the
operating system, not encrypted assets. These previews are separate from avatar
downloads and the user's photo library. Invalid cache entries are discarded;
a broken disposable cache does not prevent a valid online image from loading.

## Friend-location filters and pins

In **Feed → Locations**, combine friend name/ID, world name/ID, presence, reported
platform and a local friend collection, then choose **Apply filters**. World
names become searchable after Eye has observed their metadata. A missing or
private location never establishes a destination. Reported PC/Android/iOS
platforms do not establish a headset model or desktop/VR mode.

Filters and up to 100 individually pinned friends are saved for the signed-in
account. **Pin watched friends** includes user and collection watches in the
priority order. Priority affects world groups, their instances and the expanded
friend list. **Pin / unpin friend** changes the selected friend's individual pin.
**Reset filters** clears filtering while preserving individual pins.

Counts describe matching observed friends, not instance population. Collection
membership refreshes on the regular view refresh or **Refresh collections**.
Deleted collections match nobody until another collection or All collections
is selected. Privacy clears displayed filters while keeping saved preferences;
switching accounts loads that account's own preferences.

## Conditional watches and temporary mutes

In **Feed → Watchlists**, keep the existing Online, Status and Location options
or add the following conditions:

| Condition | When it alerts |
| --- | --- |
| Enters world | A live report shows the chosen world after a fresh observation of a different shared world, Offline, Private or Traveling. Moving between instances in the same known world does not count. A previously private location makes this a newly visible destination, not proof of where the friend was before. |
| Leaves Busy | A fresh observed Busy status changes to Active, Join Me or Ask Me. Unknown statuses and stale baselines do not establish this transition. |
| Friends gather | A local friend collection crosses a threshold of 2–50 freshly observed members in one explicitly shared instance. Set a world ID to restrict it, or leave blank for any shared world. |

Use **Use selected Locations world** to copy the currently selected shared world
into the condition. One watch is stored per user or collection; saving the same
target replaces its conditions and preserves an existing temporary mute.

Select a watch and mute it for **15 minutes, 1 hour or 8 hours**, or unmute it
early. Expiry is saved across restarts. Events observed while muted are not
replayed. Gathering alerts re-arm after the observed count falls below the
threshold; snapshots, reconnect catch-up and settings changes seed a baseline
silently. Other collection members must have a non-stale observation less than
ten minutes old. The displayed count remains an observation, not guaranteed
current occupancy or permission to join.

These rules use Eye's existing sync owner and SOCIAL notification delivery,
including quiet hours, DND, cooldowns and ownership settings. No additional
pipeline connection or polling loop is created. Alerts are opt-in, and only the
latest 200 watch observations are kept in the session view.

## Scope and validation

The focused checks cover persistent cache behavior, eviction, corruption,
offline network suppression, account/privacy boundaries, inflight cache clears,
saved filters and pins, collection scoping, exact-world transitions, gathering
thresholds, quiet baseline seeding and mute expiry. Headless UI checks exercise
the actual settings and watch-form callbacks. See [validation](VALIDATION_1_21.md)
for the final full portable run and inherited exclusions.

Native Windows/Linux rendering and live VRChat image/event behavior still need
acceptance. This is a runnable source checkpoint, not a compiled executable or
signed installer. The [updater remains preparation only](UPDATER_PLAN_DEV10.md).
The wider roadmap and full VRCX parity remain incomplete.
