"""Optional external process RAM sampler; no process memory contents are read."""
import queue
import threading
import time


class ResourceSampler:
    def __init__(self,probe_factory=None,thread_factory=threading.Thread):
        if probe_factory is None:
            from wellness_runtime import ProcessProbe
            probe_factory=ProcessProbe
        self.factory=probe_factory;self.thread_factory=thread_factory;self.stop=threading.Event();self.output=queue.Queue(maxsize=1);self.thread=None
    def start(self):
        if self.thread is not None:return
        self.thread=self.thread_factory(target=self.run,daemon=True,name="VRC-Eye-Player-RAM");self.thread.start()
    def run(self):
        try:probe=self.factory()
        except Exception:self.send((None,"RAM monitor unavailable; install the optional psutil dependency."));return
        while not self.stop.is_set():
            try:
                sample=probe.sample();ids=sample["pids"]
                if len(ids)!=1:self.send((None,"RAM monitor needs one identifiable VRChat process."))
                else:self.send((dict(working_set_bytes=probe.exact(ids[0]).memory_info().rss),"External process RAM; cause of changes unknown."))
            except Exception:self.send((None,"RAM monitor unavailable for the current process."))
            self.stop.wait(2)
    def send(self,item):
        try:self.output.get_nowait()
        except queue.Empty:pass
        self.output.put_nowait(item)
    def close(self):self.stop.set()
