> **Live captions.** Offline selected-input or desktop-output transcription, a detachable caption window, readable styles, five hotkey commands and explicit TXT/SRT export. Choose an extracted local Vosk model under Accessibility → Live captions. [Guide](LIVE_CAPTIONS.md).
> **6,743 tests + 1,078 subtests passed.** Final focused regression: 931 tests + 27 subtests, including the later header-label correction. Six new graphical cases are supplied but unrun; real Vosk inference and physical audio/desktop acceptance remain pending.

> **Broader hotkey mapping.** 151 actions across all 121 tool destinations, focus, display, reader, alternate input and Home layout controls. Search/filter, reviewed reassignment, Undo and profiles. [Guide](HOTKEY_MAPPING.md).
> **6,674 tests + 1,078 subtests passed.** Six new native graphical cases are supplied but unrun; Windows/Linux and physical-input acceptance remain pending.

> **Alternate input and editable Home tiles.** Switch scanning, pointer dwell, on-screen control actions, and a visible lock for tile move/resize/hide with restore and undo. [Guide](ALTERNATE_INPUT_AND_LAYOUT.md).
> **6,508 tests + 1,078 subtests passed.** Seven new native graphical cases are supplied but unrun; platform and assistive-device acceptance remain pending.

> **Color vision support.** Red–green and blue–yellow presets, Monochrome, draft preview and shared profiles in Accessibility → Display. Maps/charts now pair colors with shapes, patterns and labels. [Guide](COLOR_VISION.md).
> **6,439 tests + 1,078 subtests passed.** Seven new native graphical cases are supplied but unrun; Windows/Linux visual acceptance remains pending. Build identity and ARC/VRCX qualification are unchanged.

> **Desktop text size: 100–500%.** Slider, exact percentage box, preview, reset and Ctrl+0 recovery in Accessibility/Settings/Customization. [Guide](LARGE_TEXT.md).
> **6,313 tests + 1,078 subtests passed.** Ten native graphical tests are supplied but unrun. Windows/Linux acceptance remains pending. Build identity and ARC/VRCX qualification are unchanged.

> **Desktop keyboard control.** F1 help, remappable region navigation, workspace tabs, dialogs, tables, cards, sliders and World map controls are implemented. [Controls and scope](KEYBOARD_CONTROL.md).
> **6,272 tests + 1,078 subtests passed**, including 56 new portable keyboard tests. Twelve additional real-Tk tests are supplied but unrun. Native Windows/Linux acceptance remains pending. Build identity and ARC/VRCX qualification are unchanged; no installer/executable was produced.

> **Built-in screen reader.** Local speech, keyboard Reading view, accessible dialogs, privacy guards and factual data alternatives are implemented. [Setup, shortcuts and scope](SCREEN_READER.md).
> **6,216 tests + 1,078 subtests passed**, including all 93 new portable reader tests. Six new real-Tk tests are supplied but unrun; native NVDA/Narrator/Orca and hardware-audio acceptance remain open. Optional native providers are included but not certified. Build identity is unchanged; no installer/executable was produced. ARC/VRCX qualification remains unchanged.

> **ARC-12 skin influence reduction.** Desktop Preview now measures selected influence caps over declared poses and exports reviewed error observations. Unity 2022.3 source offers maximum-error-gated new mesh assets with dependency/preservation checks and copy history. [Scope and qualification](ARC12_SKIN_OPTIMIZATION.md).
> **6,122 tests + 1,078 subtests passed**, including all 54 new ARC-12 portable tests. The 13 new Unity methods remain unrun; native copying is unqualified. There are 22 partial ARC and 24 open VRCX partial-area records; no separately missing ARC area remains. Build identity is unchanged; no installer or executable was produced. Earlier work is preserved below.

> **ARC-11 setting transfers.** Unity 2022.3 source compares selected renderer settings and ModelImporter policies, applies reviewed values to separate copies, requires explicit reference mappings and records ordered reimport observations. Desktop Recovery can inspect the reports. [Scope and qualification](ARC11_SETTING_TRANSFERS.md).
> **6,068 tests + 1,078 subtests passed**, including all 72 new report-reader tests. The 13 new Unity methods remain unrun; native transfer is unqualified. Build identity is unchanged; no installer or executable was produced. Earlier work is preserved below.

> **ARC-10 bounds workflow.** Desktop imported/displayed/sampled node-bounds reports with finite margins and reviewed JSON export. Unity 2022.3 source adds root-bone-space diagnostics and reviewed corrections on new prefab copies. [Usage and qualification](ARC10_RENDERER_BOUNDS.md).
> **5,996 tests + 1,078 subtests passed**, including all 55 new bounds tests. The 13 new Unity EditMode methods are supplied but unrun; native correction remains unqualified. The build name is unchanged and no installer or executable was produced. Earlier work is preserved below.

> **ARC-06 initial animation playback.** GLB transform/morph clips and prepared Linux FBX takes, with timeline, seek, loop/speed, translation anchor, diagnostics and imported-pose reset. [Usage and limits](ARC06_ANIMATION_PREVIEW.md). Rebuild the optional FBX adapter for Eye ABI 2.
> **5,941 tests + 1,078 subtests passed**, including all 104 new animation tests. Unity controller graphs/evaluation, object-reference material swaps, humanoid retargeting and graphical desktop/Windows qualification remain open. Existing bundle, FBX import and wallpaper/startup work is preserved below.

> **ARC-03 initial FBX import.** Authorized ASCII/binary FBX preview on Linux, with hierarchy, units/axes conversion, static stored deformation, diffuse textures and separate rig/blend/take/dependency inspection. Build the optional adapter explicitly; [setup and coverage](ARC03_FBX_IMPORT.md).
> **5,837 tests + 1,078 subtests passed**, including 70 new FBX tests and eight upstream Blender/Maya fixtures. Windows containment, broader creator/exporter coverage and graphical desktop qualification remain open. Prior bundle and wallpaper/startup work is preserved below.

> **ARC-02 initial bundle decoder.** Adds explicit authorized UnityFS preview on Linux using a contained, pinned parser. Supports a bounded Unity 2022.3 mesh/hierarchy/material-slot/skin/single-frame-morph subset. [Setup, coverage and remaining work](ARC02_BUNDLE_INGESTION.md).
> Integrated regression: **5,767 tests + 1,078 subtests passed**, including 80 new ARC-02 tests. Windows bundle containment and real creator-built fixtures remain open. The wallpaper/startup update below is preserved.

> **Wallpaper and startup update.** Normal launches automatically install missing Pillow first, independently of other optional packages. Direct `python vrc_eye.py` starts now use the same setup as Start.cmd / Start.sh. PNG wallpapers also work without Pillow, including saved images and opacity. See [setup, formats and validation](WALLPAPER_STARTUP_UPDATE.md). This remains the unreleased working checkpoint.

> **Previous ARC repair continuation.** Links reviewed shader compiler observations to exact installations and verifies reloaded material/mesh copies.
> Full portable regression: **5,625 tests + 1,065 subtests passed**, 516 environment skips, zero failures.
> [Changes and workflow](ARC_REPAIR_CONTINUATION.md) · [remaining gates](PARTIAL_COMPLETION_STATUS.md). All 16 ARC areas retain native/provider or platform gates; Unity code and six new editor fixtures remain unrun. No release identity changed.

> **Previous ARC containment continuation.** Adds real Linux GLB kernel containment, pinned recovery dependencies and an isolated launch environment.
> Full regression: **5,572 tests + 1,065 subtests passed**, 516 environment skips, zero failures.
> [Changes and requirements](ARC_CONTINUATION.md) · [remaining gates](PARTIAL_COMPLETION_STATUS.md). All 16 ARC areas still need native/provider or platform work before end-to-end closure; no release identity changed.

> **Retained autonomous completion checkpoint.** Advances 18 areas: recovery/catalog reconciliation, backup consistency, parser/exporter limits, Discord requests, retained-record search, translation, full gallery ordering and Unity repair-copy workflows.
> See [changes](AUTONOMOUS_COMPLETION_NOTES.md), [final validation](AUTONOMOUS_COMPLETION_VALIDATION.md), and the [40-area ledger](PARTIAL_COMPLETION_STATUS.md).
> Portable regression: 5,535 tests and 1,065 subtests passed; 516 environment skips. Native/provider containment, provenance and distribution gates remain open. Same build identity; no numbered release or installer.

Retained in this combined source: [English name translation and shader dependency preservation](TRANSLATION_AND_DEPENDENCY_UPDATE.md). Its previous regression remains historical evidence in `CONTINUATION_VALIDATION.json`.

> **Current Development 30 source candidate.** Adds shared Steam/VRChat and game-log views, setup health, metadata bookmarks/comparison, and persistent appearance controls.
> The existing build identity is retained. See [milestone and usage](DEVELOPMENT_30_MILESTONE.md), [validation](DEVELOPMENT_30_VALIDATION.md), and [remaining partial areas](PARTIAL_COMPLETION_STATUS.md). Native desktop/provider qualification remains open.

> **Unreleased working checkpoint.** The public build name now uses
> `YYYY.DD.MM.HH.mm.D` and appears at the bottom-right of the application.
> The clock is 24-hour; weekday is Monday=1 through Sunday=7. Each build keeps its
> saved timestamp across launches. See [pending development](PENDING_DEVELOPMENT.md).
> The release hold through Development 30 remains active.
> Local settings undo now recovers deleted VR checklist profiles and saved hardware
> summaries. VR editors reject stale saves; portable backups still exclude hardware
> summaries. Native desktop acceptance remains open.

> **Current dashboard and recovery work.** Adds Home paging and advancing source ages,
> shared Unity/diagnostics cards, demand-aware optional polling, and journaled Creator
> Projects copy jobs with durable receipts and conditional repair undo.
> See [current partial-area status](PARTIAL_COMPLETION_STATUS.md) for usage and limits.
> The calendar build name and Development 30 release hold are unchanged.

> **Earlier partial-area work retained.** Adds reversible GLB joint poses, material-selected
> UV sets and declared texture filtering, vertex topology diagnostics, and three
> more settings recovery sections for wellness and compass preferences.
> See [current partial-area status](PARTIAL_COMPLETION_STATUS.md) for usage,
> remaining work and native acceptance limits. This is the same unreleased checkpoint.

> **Retained Development checkpoint 21.** Adds deeper GLB material/texture inspection,
> mesh health, enabled exact-byte association rules with batch undo, broader observed
> profile history, and saved composer/OSC display settings backup and undo.
> See [Development 21 notes](DEVELOPMENT_21_RELEASE_NOTES.md),
> [validation](DEVELOPMENT_21_VALIDATION.md) and [remaining ARC/VRCX work](ARC_VRCX_REMAINING_DEV21.md).
> Extract separately, then use Start.cmd on Windows or `bash Start.sh` on Linux.

> **Retained Development checkpoint 20.** Adds sidebar/photo-grouping settings backup and undo,
> provider freshness, optional sensor throttling, bounded GLB base-color/texture preview,
> checkpointed VPM recovery helpers, session-day photos, draft blocks and OSC endpoint diagnostics.
> See [Development 20 notes](DEVELOPMENT_20_RELEASE_NOTES.md),
> [validation](DEVELOPMENT_20_VALIDATION.md) and [remaining ARC/VRCX work](ARC_VRCX_REMAINING_DEV20.md).
> Extract separately, then use Start.cmd on Windows or `bash Start.sh` on Linux.

> **Retained Development checkpoint 19 — unified continuation.** Retains Development 18's
> static GLB viewer and shared direct-settings history. Home rules and widget
> visibility can now require up to four conditions, including power preference.
> Home also offers a temporary fallback pause while retaining the saved override.
> See [Development 19 notes](DEVELOPMENT_19_RELEASE_NOTES.md) and the
> [remaining ARC/VRCX report](ARC_VRCX_REMAINING_DEV19.md).

> **1.21.0 — Development checkpoint 18.** Adds static GLB scene inspection with
> hierarchy/visibility/bounds, conditional Home layouts and supported direct-edit undo history.
> Open **Avatar Library → 3D preview**, **Customization → Profiles & sharing**,
> or **Customization → History**. Existing OBJ preview remains available.
> See [changes and setup](CONTINUATION_DEV18.md), [remaining ARC/VRCX work](ARC_VRCX_REMAINING_DEV18.md),
> and [validation](VALIDATION_1_21.md). Runnable Windows/Linux source; native/live acceptance remains open.
>
> **Retained 1.21.0 — Development checkpoint 17.** Adds shared private tags and saved views,
> selective settings restore/undo, recovery working-copy history and source dependency diagnostics.
> Open **Shared notes / tags → Manage tags**, **Desktop controls → Profiles**, or
> **Avatar Library → Recovery → Working copies / repair history…**.
> See [changes and setup](CONTINUATION_DEV17.md), [remaining ARC/VRCX functions](ARC_VRCX_REMAINING_DEV17.md),
> and [validation](VALIDATION_1_21.md). Runnable Windows/Linux source; native and live acceptance remain open.
>
> **Retained 1.21.0 — Development checkpoint 16.** Adds reviewed local AssetRipper export jobs,
> contextual Home row actions and freshness, and resumable owned-world / SDK / VCC downloads.
> Open **Avatar Library → Recovery**, **Home**, or the resumable action in **World backups / SDK / VCC Downloads**.
> See [changes and setup](CONTINUATION_DEV16.md), [remaining ARC/VRCX functions](ARC_VRCX_REMAINING_DEV16.md),
> and [validation](VALIDATION_1_21.md). Runnable Windows/Linux source; native GUI, installed AssetRipper
> and live-provider acceptance remain open.
>
> **Retained 1.21.0 — Development checkpoint 15.** Continues the completed Development 14 build.
> Player-session notes now share storage with profiles and Favorites, with conflict checks,
> explicit legacy review and preserved intentional clears. Open a player → Notes → Shared notes / tags….
> See [changes and setup](CONTINUATION_DEV15.md),
> [remaining ARC/VRCX functions](ARC_VRCX_REMAINING_DEV15.md), and [validation](VALIDATION_1_21.md).
> Runnable Windows/Linux source build; native/live acceptance remains open.
>
> **Retained Development checkpoint 14.** Adds reviewed resumable avatar downloads,
> bounded retries and outcome recovery, sortable/filterable Home tables, and shared private notes.
> Open **Avatar Library → Transfers**, **Customization → Home layout**, or **Favorites → Notes / tags…**.
> See [changes and setup](TRANSFERS_NOTES_DASHBOARDS_DEV14.md),
> [remaining ARC/VRCX features](ARC_VRCX_REMAINING_DEV14.md), and [validation](VALIDATION_1_21.md).
> Runnable Windows/Linux source build; native/live acceptance remains open.
>
> **Retained Development checkpoint 13.** Adds structured friend/profile history,
> exact avatar-file matching and file-health checks, and reviewed background catalog metadata batches.
> Open **Feed → Observed changes → Profile changes…** or **Avatar Library → File health & matches / Metadata updates**.
> See [what changed and how to use it](CATALOG_HISTORY_DEV13.md),
> [remaining ARC/VRCX features](ARC_VRCX_REMAINING_DEV13.md), and [validation](VALIDATION_1_21.md).
> This is a runnable Windows/Linux source build; native/live acceptance remains open.
>
> **Retained Development checkpoint 12.** Open **Session tools…** in the sidebar
> for the new planning boards, shared soundboard/audio pin, presets/history,
> private composer, readiness/OSC/activity diagnostics and mascot packs.
> Creator Preview adds searchable hierarchy/component comparison.
> See [delivered scope and setup](SESSION_TOOLS_DEV12.md),
> [all remaining ARC/VRCX areas](ARC_VRCX_REMAINING_DEV12.md), and
> [validation limits](VALIDATION_1_21.md). Optional Vosk needs a local model.
> This is a runnable Windows/Linux source checkpoint, not a signed installer.
>
> **Retained Development checkpoint 11.** Pictures now persist across restarts
> with account separation, offline previews, size limits and clear controls.
> Feed → Locations adds saved friend/world/presence/platform/collection filters
> and pins. Watchlists adds world-entry, leaving-Busy and gathering alerts, with
> temporary mutes. See [Development 11 changes](PICTURES_FILTERS_WATCHES_DEV11.md).
> The [Development 10 friend views and search-picture fixes](FRIEND_ACTIVITY_DEV10.md)
> are retained.
> [Updater preparation](UPDATER_PLAN_DEV10.md) explains adapting VRCX's approach;
> an Eye update feed and installation transport are not configured in this build.
> Open Global quick search from the sidebar or with Ctrl+Shift+K. Status rules
> are under Accounts → My profile and require a separate session enable review.
> Retained: [Development 9 changes](LIVE_SEARCH_STATUS_DEV9.md),
> [Development 8 sync](AUTOMATIC_SYNC_DEV8.md), and
> [the retained Development 6 features](VRCX_COMPLETION_DEV6.md).
> This is a runnable Windows/Linux source build; full parity and native/live
> acceptance remain incomplete. See [implementation status](IMPLEMENTATION_STATUS_1_21.md)
> and [validation](VALIDATION_1_21.md).
>
> **Earlier 1.20 baseline — Development checkpoint 8.** Added OBJ mesh previews, bulk avatar
> metadata imports, HTML galleries, selected-folder discovery, recovery preparation
> and optional Unity repair-copy source tools. OBJ geometry is supported; VRCA
> rendering and automatic source extraction remain pending. The editor tools have
> not been compiled or run in Unity here. The full roadmap remains unfinished.
> Start with [development notes](DEVELOPMENT_1_20.md),
> [ARC-inspired feature guide](ARC_FEATURES_1_20_DEV8.md), and
> [implementation status](IMPLEMENTATION_STATUS_1_20.md).
> Previous Social/Accounts, Avatar Library, VCC, SDK downloads, keyboard and creator
> features are retained. Older release notes below are historical documentation.

# VRC Eye

A desktop companion for VRChat avatars, worlds, friends, favorites and optional local wellness reminders.

## Version 1.19.9: Remembered sign-in and keyboard login

A small update on 1.19.8. Close the old copy, extract **VRC-Eye-v1.19.9.zip**,
open **VRC-Eye**, and run **Start.cmd**. No launcher or dependency changes.

The existing VRChat connection window now has separate **Remember username** and
**Remember password** checkboxes. Either, both, or neither can be selected.
New values save only after successful sign-in, including verification. Unchecking
an option immediately forgets that stored value without deleting the other one.
**Forget saved sign-in** removes both; Disconnect only discards the current session.

**Enter and keypad Enter** submit sign-in or the requested verification code,
with duplicate-request protection and automatic focus on the code field. Mouse
buttons remain available. There is no automatic sign-in or verification bypass.

Passwords use **Windows Credential Manager**, never plaintext settings. The
username has its own per-user JSON file. Password-only mode leaves the username
blank and checks that untouched autofill belongs to the typed username. A failed
storage operation is reported without breaking an otherwise successful sign-in.
Demo/Safe mode do not read or change saved values. Non-Windows systems support
username remembering and Enter, but password remembering stays disabled.

Read **[LOGIN_GUIDE.md](LOGIN_GUIDE.md)** for the four combinations, storage,
forgetting and validation details. Native Windows storage and live VRChat sign-in
remain untested here; the release uses offline tests and real Tk keyboard checks.

## Version 1.19.8: Client Bridge Lab

Built on 1.19.7. Close the previous copy, extract **VRC-Eye-v1.19.8.zip**, open
**VRC-Eye**, and run **Start.cmd**. Launchers and dependencies are unchanged.

Choose **Developer → Developer / Black Lab → Client Bridge Lab**. The new ninth
section has eight views: self-avatar timeline, parameter tracing, local rendering/
audio isolation, integration-module isolation, targeted recovery, creator
manifests, API/runtime comparisons and cooperative playtest cards. Ctrl+K now
indexes **77 destinations**. Bridge settings remain in **VRC Eye → Networking**.

**Seven telemetry and six action contracts** extend the existing authenticated
local bridge and Python provider SDK. A separate isolated Sandbox provider
exercises the real validation, permissions, queue and acknowledgement paths.
Live controls require a compatible, explicitly approved provider and separate
session-only lab arming; opening a page does not grant or start anything.

Temporary experiments use one-use reviews, 1–60 second leases, exact context and
revision checks, and conditional restoration that preserves newer user choices.
Unknown acknowledgements are not retried; disconnect can leave restoration
unconfirmed. Peer cards are category-opt-in, bounded, accepted through the
existing Eye-to-Eye workflow, and compared with clock uncertainty rather than
assumed synchronization. Sanitized reports are previewed before export.

**No VRChat-specific provider, modified client or injected DLL is included.**
Actual runtime telemetry/effects need a separately implemented provider. Live
VRChat, external multiplayer and Windows-native behavior remain unverified.
The existing 58-entry web API workbench is retained without new endpoint claims.

Read **[CLIENT_BRIDGE_LAB_GUIDE.md](CLIENT_BRIDGE_LAB_GUIDE.md)** and the exact
**[implementation matrix](CLIENT_BRIDGE_LAB_CAPABILITIES.md)**. The supplied
proposal is preserved in **CLIENT_BRIDGE_LAB_DESIGN_INPUT.md**. Validation and
remaining limitations are recorded in **VALIDATION.md / BUILD_VALIDATION.json**.

## Version 1.19.7: Developer / Black Lab

This release extends the existing 1.19.6.1 application. Close the old copy,
extract **VRC-Eye-v1.19.7.zip**, open **VRC-Eye**, and run **Start.cmd**. Keep the
files together. The launchers and dependency list are unchanged.

Choose **Developer** in the top View selector, then open **Advanced → Developer /
Black Lab**. **Ctrl+K** also finds its sections. The workspace starts in
**Sandbox**, with live writes disarmed and no developer key required.

The new catalog has **58 entries: 37 read adapters, 18 write adapters, and 3
reference-only entries**. Live adapters use VRC Eye's existing API connection,
lock, request interval, cookies and transport. They are executable implementations,
not simulated buttons in the Live environment; **no live VRChat account or service
has been used to validate them in this build environment**. Each entry says so.

The eight sections are **Overview, API Workbench, Traffic, Events & State,
Testing Lab, Data & Recovery, Integrations, and Reports**. They include guided
fields and data-only JSON requests; exact one-use action reviews; selected
post-write verification reads; sanitized shared API and pipeline observation;
response/schema comparisons; page-by-page list inspection; shared player-state
provenance; isolated fixture failures and replay; read-only SQLite inspection;
consistent private database backups; and previewed sanitized report exports.

Networking configuration remains in **VRC Eye → Networking**, with a new
**Developer API** tab for application contact identification. Existing creator,
OSC, peer, companion and runtime services are not replaced. Opening Developer
never grants OSC permissions, starts a bridge listener, or arms live writes.
Tool search now indexes **67 destinations**.

Read **[DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)** for operation and privacy details,
**[DEVELOPER_CAPABILITIES.md](DEVELOPER_CAPABILITIES.md)** for the exact implemented
catalog and roadmap gaps, and **[VALIDATION.md](VALIDATION.md)** for verification
scope. The supplied full design is retained as **DEVELOPER_DESIGN_INPUT.md**;
it is a roadmap, not a claim that every proposal is implemented.

## Version 1.19.6.1: Friendlier interface — minor update

Close an older running copy, extract **VRC-Eye-v1.19.6.1.zip**, open **VRC-Eye**,
and double-click **Start.cmd**. Keep the extracted files together. The existing
one-step dependency setup is unchanged; there are no new install scripts.

This is an interface update on top of 1.19.5, not a separate application or a
replacement for its services. The version includes the requested **.1** suffix.

- **Home:** session/log status, retained avatar-event count, account status and
  shortcuts to players, avatars, OSC, Eye-to-Eye, wellness and networking.
- **Clearer navigation:** Primary is displayed as **Players & avatars**, Feed as
  **Friend activity**, and VRC Eye Primary as **Eye-to-Eye**. The old internal
  page keys and existing feature callbacks remain available.
- **Casual / Advanced / Developer:** one shared detail-level selector. Everyday
  tools stay visible in Casual; More tools, workspace dropdowns and search keep
  advanced tools accessible. Changing views grants no extra permissions.
- **Find a tool:** press **Ctrl+K** to search 57 indexed destinations, including
  creator workspaces and advanced tabs. Search is local navigation, not a web or
  VRChat lookup, and opening a control does not arm or execute it.
- **Less clutter:** compact tab navigation, a five-column Casual avatar table,
  expandable technical details, and plain-language Casual OSC connection status.
  Existing detailed editors and diagnostics remain available.
- **Settings:** comfortable/compact spacing, standard/larger text, a startup-page
  choice, log-source selection, account shortcuts and optional technical tools.
  **Ctrl+,** opens Settings. Network addresses and ports remain under
  **VRC Eye → Networking**, including OSC transport.

Appearance changes are stored in a dedicated local `ui.presentation` record;
Demo and Safe mode keep them session-only. Reset appearance changes only those
options, not favorites, profiles, authoring data or permissions. In Settings,
picking a new log fills the field; **Watch logs** explicitly starts monitoring.
Normal-launch monitoring behavior from the previous release is unchanged.

Read [INTERFACE_GUIDE.md](INTERFACE_GUIDE.md) for the navigation changes and
[VALIDATION.md](VALIDATION.md) for test coverage and runtime limitations. The
application was exercised with native Tk in a Linux virtual display, not on a
Windows desktop or a live VRChat session. Existing runtime compatibility notes
for OSC, peers, hardware and Unity still apply.

## Version 1.19.5: Shared OSC controls

Extract **VRC-Eye-v1.19.5.zip**, open **VRC-Eye**, and run **Start.cmd**.
The one-step dependency setup from 1.19.4 is preserved, including the optional
OSCQuery discovery dependency. There are no new installation scripts.

Open **VRC Eye → VRC Eye Primary → OSC Controls** for **Overview, Control Deck,
Avatar Parameters, Voice & Privacy, Chatbox, Camera, Tracking, Presets & Rules,
Routes & Permissions, and Inspector**. Address and port settings are centralized
under **VRC Eye → Networking → OSC transport**.

- One shared service supplies Avatar Link, rangefinder observations, camera/map
  captures, reviewed native inputs, and explicitly configured managed routes.
- Passive OSCQuery discovery and receiving start without enabling writes.
  Busy ports can use an available port; no other listener is displaced.
- Scoped session arming, exact OSC types, temporary ownership, bounded held-input
  releases, and cancellation across avatar/client/account changes.
- Microphone behavior and privacy feedback, reviewed chatbox publication,
  camera settings/countdowns/Dolly requests, eligible avatar switching, scaling,
  and separate native VRChat Safe Mode versus VRC Eye Safety Mode.
- Data-only presets, transforms, rules and optional tracking/provider routes;
  incoming peer countdowns require a separate one-use local capture approval.
- Bounded action history, metadata-only diagnostic exports, troubleshooting,
  and an isolated simulator that never sends to live VRChat.

Read [OSC_CONTROLS_SETUP.md](OSC_CONTROLS_SETUP.md) before arming controls.
A sent packet is not proof of delivery or completion. The policy covers traffic
routed through VRC Eye, not other programs' direct connections. Live VRChat,
Windows UI, tracking hardware and multicast discovery still need runtime testing;
compatibility-gated endpoints remain explicitly unverified.

## Version 1.19.4: One-step startup

Extract **VRC-Eye-v1.19.4.zip**, open **VRC-Eye**, and double-click **Start.cmd**.
Python **3.10 or newer with Tkinter** remains the only prerequisite you install
separately. Start prepares the app's dependencies automatically; the separate
feature installers are no longer needed.

- Reuses the local `.recovery-env` or creates it on the first normal launch.
- Installs the consolidated `requirements.txt` only when packages are missing
  or do not satisfy its version requirements. Healthy launches do not run pip.
- If setup cannot complete offline or a package install fails, available core
  features still open. A later **Start.cmd** launch retries missing dependencies.
- **Safe-mode.cmd**, **Demo.cmd**, and command-line help/version checks skip
  installation. Normal `python vrc_eye.py` launches now use automatic setup too.
- Preparing packages does not sign in, pair devices, enable input providers,
  connect OBS/peers/Avatar Link, or install a Unity package.

Keep the extracted application files together. There is one dependency list and
one normal launcher. For an explicitly managed Python environment, use
`python -m pip install -r requirements.txt`, then `python avatar_watch.py`.
A normal first setup needs package-download access; an already prepared
installation can use its available features offline.

Setup uses the app's own environment and ignores pip settings that could redirect
installation elsewhere. Two launches cannot install into it simultaneously. If
an earlier environment is damaged, it is left intact and core tools open using
the available Python; interrupted environments created by this launcher can be
retried without deleting them.

## Version 1.19.3: Avatar Creator

Extract **VRC-Eye-v1.19.3.zip**, open **VRC-Eye**, and run **Start.cmd**.
Under **Primary → Avatars**, Activity is joined by **Creator, Modules, Avatar Link,
Parameters, Preview, Tests, Diagnostics, Profiles and History**.

- Private avatar workspaces, strict creator manifests, module planning/composition,
  validation, parameter budgets and platform/build comparisons.
- Reviewed localhost OSC with avatar/account/platform guards, typed parameters,
  separate public-output permission, writer ownership and expiring action requests.
- Optional existing-provider battery/resource signals, temporary status, selected
  WAV/manual effect analysis and read-only OBS status with explicit connection.
- Local mannequin/static-reference previews, guided evidence-based tests,
  scoped runtime profiles and restoration, notes, release worksheets and reports.
- An editor-only Unity Avatar Toolkit with twelve finite starter modules,
  reviewed clone installation, recovery journal, source export and static preview.
- Optional reviewed peer test cards through existing Networking and read-only
  SteamVR presentation through the existing Wellness connection.

Local authoring and OSC need no extra packages. **Start.cmd** automatically
prepares the optional OBS WebSocket dependency alongside the other packages. **AVATAR_CREATOR_SETUP.md** and
**AVATAR_TOOLKIT_SETUP.md** explain setup, implemented boundaries and native tests.
The Unity toolkit is experimental and requires testing in your own project;
this build environment cannot verify Unity compilation or Windows/VR behavior.
No avatar is automatically published or uploaded, and source/simulation evidence
does not count as successful live verification. See **VALIDATION.md**.

## Version 1.19.2: World Creator

Extract **VRC-Eye-v1.19.2.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open **Primary → World** for the new **Creator, Metadata, Builds, Live Test,
Diagnostics, Tasks, History and Controls** tabs alongside Players and Map.

- Private local world workspaces, metadata drafts with conflict comparison,
  description sections, build/platform evidence and project manifests.
- Versioned test profiles, guided checklist/recipe runs, evidence bookmarks,
  issues, baseline comparisons and advisory release requirements.
- Opt-in bounded log/roster observations, existing-provider measurements,
  error timelines, observed population and portable reviewed reports.
- Structured creator worksheets for persistence, accessibility, locomotion,
  rendering, media, network budgets, localization, dependencies and soak testing.
- Optional selected peer playtest sharing through the existing Networking service,
  a read-only SteamVR card, and explicitly declared local helper MIDI controls.

Local creator tools need no additional packages. **Start.cmd** automatically
prepares the optional MIDI adapter dependencies alongside the other packages. Metadata drafts are applied through
the official SDK/website; this release does not make remote publication writes.
Shared resets, arbitrary Udon execution and interactive VR overlay input are not
implemented. See **WORLD_CREATOR_SETUP.md**, **CREATOR_HELPER_SETUP.md** and
**VALIDATION.md** for workflow, boundaries and native checks still required.

## Version 1.19.1: Networking workspace

Extract **VRC-Eye-v1.19.1.zip**, open **VRC-Eye**, and run **Start.cmd**.
The **VRC Eye** sidebar section now contains **VRC Eye Primary** and **Networking**.

- **Networking** owns connection setup, adapter selection, host/join invitations,
  peer connection details and disconnection. These controls moved out of Primary.
- Added Tailscale, ZeroTier, Radmin VPN, NetBird and explicitly selected other VPN
  adapters alongside LAN, Hamachi and the existing pinned relay transport.
- Saved local connection profiles and a guided invitation workflow make repeat
  setup easier. Launching the app or loading a profile never starts networking.
- **Hide my IP from peers (relay only)** rejects LAN/VPN connections and ends an
  active direct connection when enabled. Relay failure never falls back to direct.
- Private profiles, notes, plans and shared activities remain in **VRC Eye Primary**.
  The same peer service, consent rules and private workspace serve both categories.

**Start.cmd** automatically prepares connection dependencies. Install and join
your chosen VPN separately. Relay connections require a trusted operator's
address and certificate fingerprint; no public VRC Eye service is provisioned.
See **NETWORKING_SETUP.md** for provider setup, privacy and compatibility details.

## Version 1.19.0: VRC Eye to VRC Eye

Extract **VRC-Eye-v1.19.0.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open **VRC Eye → VRC Eye Primary**. The workspace starts in **Private Mode**.

- Local profiles/bios, private notes, bookmarks, recommendation drafts, session
  cards, party/photo/media plans, countdowns, creator checklists and playtests.
- Sanitized diagnostic and performance cards, personal performance comparisons,
  safe preset export/import with a reviewed diff and rollback checkpoint.
- Optional authenticated peer connections over LAN, Hamachi or a self-hosted opaque
  relay. **Start.cmd** automatically prepares the optional connection components.
- Explicit Whispers and card sharing, ready checks, countdowns, safety check-ins,
  session roles, creator snapshots, mutual evidence and recipient-owned notices.
- Per-peer permissions, expiring approvals, blocks, Private Mode, emergency
  sharing revocation, capability explanations and isolated developer simulations.
- Player details and the former Whisper tab now lead to this shared service.
  Player/device associations are explicit local labels, not verified VRChat identities.

Connecting never publishes the saved bio or private records automatically. Local
tools work without networking packages, a VRC Eye account or a relay. There is no
preconfigured public relay or cloud message archive. See **PEER_SERVICES_SETUP.md**
for the connection workflow, privacy boundaries and supported behavior, and
**PEER_SERVICES_DESIGN_INPUT.md** for the supplied design and implementation map.

## Version 1.18.10: VRCX Companion

Extract **VRC-Eye-v1.18.10.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open **Advanced → VRCX Companion** and enable the optional mode when ready.

- Passive VRCX presence with explicit stale/unknown states; Balanced, VRCX Primary,
  VRC Eye Primary and temporary Solo Mode, plus per-category ownership.
- Social-banner suppression preserves live roster/session processing. Reviewed
  launches and normal exits share a single VRC Eye action reservation.
- Existing VRCX cache tools, JSON import and banner preference are centralized.
  Reviewed exact-ID handoffs and native favorites import/export are available.
- Casual/Advanced/Developer views, declared-conflict diagnostics, sanitized
  Black Box events, reviewed reports and an isolated simulator.
- Global connection buttons and several redundant navigation/profile controls
  are consolidated; avatar search is in Search, recovery launch in Unity Player.

VRCX settings are user declarations, not verified activity. VRC Eye does not
modify VRCX's database/settings or claim a negotiated connection. The core app
remains independent, and no automatic recovery or Discord publisher is added.
See **VRCX_COMPANION_SETUP.md** for supported formats, operating details and native
checks still needed. **VRCX_COMPANION_DESIGN_INPUT.md** preserves the supplied design.

## Version 1.18.9: Unity Player

Extract **VRC-Eye-v1.18.9.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open **Advanced → Unity Player**. Core monitoring works with stock VRChat;
**Start.cmd** automatically prepares psutil for process telemetry.

- Runtime generations, cautious startup/hang/exit states, source/expiry metadata,
  Unity/renderer detection, normalized errors and shared Resource Guard readings.
- Windows window/display inspection and reviewed foreground, restore, center,
  primary-display, off-screen and known-good-position recovery requests.
- Typed Steam launch profiles with explicit option review and process rechecks.
- Casual/Advanced/Developer views, opt-in bounded summaries, reviewed exports,
  an isolated simulator, capability status and Black Box runtime events.
- Optional process-bound runtime summary/error bridge capabilities, using the
  existing consent/lease model and the existing canonical Player List.

Monitoring defaults on; long-term runtime summary retention defaults off.
Read **UNITY_PLAYER_SETUP.md** for capabilities, privacy, launch behavior and
native Windows/VRChat verification still needed. The complete supplied design and
an implementation map are in **UNITY_PLAYER_DESIGN_INPUT.md**.

## Version 1.18.8: Crash & Diagnostics

Extract **VRC-Eye-v1.18.8.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open **Advanced → Crash & Diagnostics**. The Black Box records automatically
while the app runs, even when this page is closed.

- A disk-backed 5/10/15-minute rolling recorder, checksummed records, independent
  incident preservation and next-start recovery of unfinished recordings.
- Local resource/process observations, normalized session/error events, optional
  Windows evidence, healthy-checkpoint comparisons and cautious incident summaries.
- Casual/Advanced/Developer views, scrubbable replay, source/expiry information,
  an error center, retention controls and reviewed diagnostic ZIP exports.
- Manual Steam launch/world-page recovery and **Safe-mode.cmd** for startup issues.

The recorder defaults to a 10-minute window, 30-day retention and 10 incidents.
Raw logs, personal identifiers, credentials and private instance codes are excluded.
**Start.cmd** automatically prepares psutil for OS/process telemetry.
No login or bridge is required. Read **CRASH_DIAGNOSTICS_SETUP.md** for operation,
privacy, recovery limits and Windows verification still needed.

## Version 1.18.7: Performance & Security

Extract **VRC-Eye-v1.18.7.zip**, open **VRC-Eye**, and run **Start.cmd**.
Open the new **Advanced → Performance & Security** sidebar category.
If the core collector is unavailable after an offline setup, reopen **Start.cmd**
when online to retry the missing dependencies, including psutil.

- Local RAM, Windows commit, process/system CPU, available GPU/VRAM/thermal and
  disk readings, with explicit sources and unknown/stale states.
- Configurable sustained-pressure rules, recovery hysteresis, cooldowns,
  composite rules, consolidated warnings and an isolated simulation.
- Casual/Advanced/Developer views, peak-preserving graphs, short RAM growth trends
  and an event timeline that treats correlation as an observation, not blame.
- Opt-in bounded resource journals, startup clean-stop checks, retention,
  category-specific deletion, private session export and action-free replay.
- Explicitly reviewed normal-close requests with process identity and freshness
  checks. Automatic shutdown and hard resource limits remain unimplemented.

Monitoring and Balanced warnings default on; resource recordings default off.
Missing optional sensors do not stop the rest of VRC Eye. No client bridge or
VRChat login is required. Read **PERFORMANCE_SECURITY_SETUP.md** for the included
features and the proposal's later phases, and **VALIDATION.md** for test scope.

## Version 1.18.6: Player sessions

Extract **VRC-Eye-v1.18.6.zip**, open **VRC-Eye**, and run **Start.cmd**.
Python 3.10+ with Tkinter is required. Close the previous release first.

- A shared player-session service with stable IDs, cautious provisional matches,
  replay deduplication, stale-state handling and field source/freshness inspection.
- Compact, Standard, Detailed and custom-column layouts, Casual/Advanced/Developer
  modes, pins, local favorites, search, filters and incremental 100-row pages.
- Player details with Overview, Session, Avatar, History, Safety, Notes and Advanced
  sections, plus the existing full profile and account tools.
- Opt-in encounters, approximate shared time, notes/tags, retention, per-player
  history choices, incognito, explicit exports and replay-resistant deletion.
- Lazy role and relationship lookups; approved, instance-bound bridge voice,
  distance, avatar state/performance and reviewed local controls.
- Presentation aliases, optional RAM correlations, memory-only thumbnail caching,
  session timelines and an isolated replay/synthetic diagnostic tool.

Read **PLAYER_LIST_SETUP.md** for operating steps and **PLAYER_LIST_DESIGN_INPUT.md**
for the implementation map. The two identical specification uploads are included
once. Phone/wrist/player-overlay views, automatic VRC Eye discovery and shared
social features from the blueprint's later phases remain future work. The existing
Wellness overlay and paired whispers remain available.

Core player tracking needs no added package or login. History starts in Session
only mode. Optional RAM monitoring uses the existing wellness dependency installer;
bridge-only facts require a compatible connected adapter. Native Windows/VRChat
operation still requires testing on the target system; see **VALIDATION.md**.

## Version 1.18.5: Wellness Center

Extract **VRC-Eye-v1.18.5.zip**, open **VRC-Eye**, and run **Start.cmd**.
Python 3.10+ with Tkinter is required. Close the previous release first.

- **Casual / Advanced** Wellness views, an ordered next-reminder list, editable
  first/repeat delays, VR/Desktop profiles, sitting and session time markers.
- Meaningful-break tracking: a brief headset lift does not reset every reminder;
  a configurable five-minute default counts as a meaningful break. Resume is manual.
- Consolidated prompts, per-reminder snooze/skip/disable, Focus/DND/Creator holds,
  quiet hours, scheduled meals and calendar-day bedtime overrides.
- Optional static desktop cards, a quiet Windows chime, large text, Streamer
  preview hiding, and a separate SteamVR head/wrist/dashboard overlay.
- Optional external process sessions, reported proximity/battery inputs and a
  Windows VRChat digital audio meter with editable comfort notices. Reviewed
  local volume/mute/normal-exit controls never run automatically.
- Private local retention choices, reviewed deletion, explicit summary exports,
  configuration-only templates and an isolated reminder simulation.

Manual Wellness needs no extra packages or VRChat login. For optional inputs,
**Start.cmd** prepares the packages; explicitly connect in **Advanced → Inputs /
comfort**. Missing device data remains unknown. Core reminders and device
connections start off on a new install. Existing profiles/settings are migrated.

Read **WELLNESS_SETUP.md** for setup and limitations, **WELLNESS_DESIGN_INPUT.md**
for the supplied proposal and implementation map, and **VALIDATION.md** for
verification. Windows audio and SteamVR hardware/overlay interaction still need
live testing. Social break-status sharing and wider Safety/Resource Guard
coordination remain future work; the existing client bridge is retained.

## Previous release 1.18.4: Optional client bridge foundation

The bridge remains available in 1.18.5 and needs no extra packages.

- **Advanced → Client bridge…** opens the optional bridge panel. Enable it,
  pair a compatible local adapter, and approve individual telemetry/control
  capabilities. Every new connection starts in quarantine.
- Local game controls require explicit capability approval, a separate enable
  switch, a matching attached client context, and a live heartbeat. Each request
  has a review and confirmation; failed/uncertain requests are not retried.
- Disconnect, consent expiry and account/runtime changes invalidate permissions
  and queued work. Stale telemetry becomes unavailable. The bridge also has a
  request pause switch and a small in-memory request ledger.
- The open protocol, Python SDK and **Bridge-example.cmd** diagnostic client are
  included. A real compatible adapter is required for game telemetry/actions;
  the example only tests the connection. VRC Eye stays external to VRChat.
- **SAFETY_DESIGN_INPUT.md** preserves the full supplied Safety specification
  and its implementation status. The wider Safety Center and automatic guards
  are planned separately. All seven existing pages remain independent of this
  bridge; no empty Safety category is added.

Read **BRIDGE_SETUP.md** for use and SDK integration, **BRIDGE_PROTOCOL.md** for
the portable message format, and **VALIDATION.md** for test scope. Native Windows
pipe/Linux socket operation and real-client compatibility still need desktop
testing; no live VRChat client was accessed during development.

## Previous release 1.18.3: Sidebar and companion pages

These companion pages are retained in 1.18.5.
**Start.cmd** automatically prepares packages for live Feed, JPEG/WebP previews
and the optional encryption/recovery features. Your existing settings and notes remain.

- **Primary** holds the existing Avatars and World menus.
- **Feed** shows observed friend changes, shared locations, presence, visible
  group changes and current picture previews, with optional live updates.
- **Game Log** filters recorded activity, assets, video/image links, errors and
  explicit crash markers, with image previews and retained-log exports.
- **Search** queries users, worlds, groups and supported avatar collections;
  exact-ID avatar lookup and the existing VRCA workflow are available.
- **Favorites** separates server-limited Game Favorites from local VRC Eye
  collections without an item-count cap, including CSV backup/import.
- **Social** manages friends, incoming friend/group invites, and your own
  mutes/blocks, with a review before each account-changing action.
- **Wellness** includes the requested editable, optional reminders, quiet hours,
  profiles, manual standing/battery inputs, session/break timers, snooze/dismiss,
  consolidated prompts and saved summaries, without scores or streaks.

Read **COMPANION_SETUP.md** for every page's controls, storage and availability.
The new online pages use the existing connection without requiring JSON or VRCX.
Private fields stay unavailable; recorded logs cannot reveal every loaded asset.
The 1.18.5 Wellness update adds optional desktop cards and a SteamVR overlay.
API requests share the
60-second queue, and canceled/uncertain writes are never retried automatically.
See **VALIDATION.md** for test results and remaining live-environment checks.

## Previous release 1.18.2: Player windows, account editing, and paired whispers

This release introduced player windows and account controls, retained in 1.18.5.
Python 3.10+ with Tkinter is required. Close the previous release before starting
this one. Local settings and player notes use the VRC Eye settings folder.

- Select a player in **World → Players** to open their own window. Tabs separate
  profile, social information, collections, activity, media, notes, JSON, account
  editing, and whispers. **Player window…** reopens the selected player's window.
- Sign in through **VRChat connection…** or a profile refresh to load available
  fields directly. No VRCX or manual JSON is required. Each request uses the
  existing shared 60-second metadata interval; extra sections load on demand.
- Use **My account…** for your status text, status/joinability, pronouns, booping
  preference, and mutual/Discord connection privacy preferences. Only changed
  fields are sent after you review them. Status does not change instance access.
- In **Account**, load an avatar you own to edit its name, description,
  public/private status, and tags. Saving checks the signed-in account and a
  recent exact-ID ownership result. This editor changes metadata, not Unity files.
- Local notes survive restart. Observed display names are recorded when their
  player window is opened/refreshed. Neither is sent to VRChat or a whisper relay.
- **Whisper** provides paired VRC Eye text messaging. Both people must explicitly
  connect to a shared relay and privately exchange a pairing invitation. The
  complete self-hosted relay is included; no public relay service is provided.
  **Start.cmd** automatically prepares encryption and JPEG/WebP image dependencies.

Read **PLAYER_PROFILE_SETUP.md** for the field-by-field availability table and
editing steps, and **WHISPER_SETUP.md** for pairing and relay setup. Lifetime
playtime, hidden collections, other users' credit balances, and a complete
username history are unavailable. A denied/missing field is not treated as zero.
That release passed **631 automated tests** with the optional recovery dependencies present,
including local HTTP/TLS whisper exchanges. Native Windows rendering and live
VRChat account/API actions remain unverified; see **VALIDATION.md**.

## Version 1.18.1: World players and visit information

The preceding release added the following world and roster features.

**World → Players** is now separate from **World → Map**. Watch the current
VRChat log to populate the player list even when no map or avatar changes exist.

- World summary: observed world name/ID, player count, maximum capacity,
  friends present, entry/exit timestamps, and elapsed time in the world.
- Player list: observed join/leave times, presence status, platform, trust rank,
  FPS, ping, and the existing helper-based distance in feet. Rejoins are separate
  visits; select a row for full dates and data sources.
- **Refresh world / friends** signs in if needed. Capacity comes from world
  metadata; friends are matched by exact logged account IDs against the signed-in
  account's friend-list snapshot. Connected sessions automatically request the
  detected world's metadata once. Refresh manually to update the friend list.
- **Refresh selected player…** reads platform and trust using the logged `usr_…`
  ID. Existing imported snapshots also work, but JSON and VRCX are not required.
- **Start helper feed** now works without a map. Update the included Udon world
  reporter to add headset-mode information, your local build platform, and local
  average FPS. Markers still require a calibrated map and a cooperating world.

**Limits are visible in the UI.** Log counts are observed counts; fresh helper
counts take priority. The maximum is the **world API limit**, which may differ
from an instance-specific limit. Platform and trust are snapshots. Android
headset brands and phone versus tablet are not identifiable. Remote FPS and
player ping display **Unavailable**. A missing exit stays **Not observed**;
the running timer assumes you remain in the last logged world.

Read **WORLD_PLAYERS_SETUP.md** for details. The API queue allows one metadata
request per minute, so refreshing several fields can take more than a minute.
All **579 automated tests** pass with the optional recovery dependencies present.
Native Windows rendering, live VRChat/API behavior, and Unity compilation remain
unverified; see **VALIDATION.md**.

Public build naming now uses **Year.Day.Month.Hour.Minute.Weekday**:
`YYYY.DD.MM.HH.mm.D`, with two-digit day/month/hour/minute and Monday=1 through
Sunday=7. For example, `2026.05.10.02.43.1` identifies Monday, 5 October 2026,
02:43. The number identifies the build and does not change at application startup.
`BUILD_VERSION` and the matching offset-qualified `BUILD_TIMESTAMP` in
`avatar_watch.py` are stamped together once per build. This checkpoint uses
America/New_York time; continue using that build timezone for later stamps.
`python tools/package_release.py --next-version --build-time 2026-10-06T09:15:00-04:00`
previews a name without changing files; omitting `--build-time` uses the build
machine's local clock. A second build needs a later minute. The packager validates
the date, weekday and saved timestamp, and refuses to overwrite an existing ZIP.
Old API/peer compatibility constants and historical release counters remain
available internally. They are no longer the public build name.

## Version 1.18.0: VRCW world backups and supplied-key recovery

**Start.cmd** automatically prepares the dependencies for supplied-key decryption.
If setup was unavailable offline, reopen it when online to retry.

Open **World → World backups…**, enter a `wrld_…` ID or official world-page
link, and click **Look up world**. Sign in through the existing VRChat connection
if needed. Choose the returned **PC, Android, or iOS** build, when available.

- **Your own world:** save an unchanged `.vrcw` backup, or choose **Decrypt with
  supplied key** to download and recover the supported encrypted format in one operation.
- **A friend's world:** the API must confirm that the world's author is your
  friend. Paste the key that author supplied and confirm their permission.
  Every encrypted chunk must authenticate before a recovered `.vrcw` is saved.
  This path does not offer an unchanged/keyless backup.
- **Cached build:** select **Matching cache entry**, choose the cache folder,
  scan the selected build, select an available result, and save. Matching includes
  file ID, version/revision, and variant; no other build is substituted. Close
  VRChat and rescan if the entry is locked.

Both sources have progress, cancellation, a saved-file SHA-256, and existing-file
protection. Original cache files are preserved. Keys and permission snapshots
stay in memory; no manual JSON or VRCX integration is required. World/friend
lookups share the existing one-request-per-minute metadata queue, so a friend's
lookup can take more than a minute. Recheck after five minutes before starting
a new backup, or after changing the connection/world selection.

**Recovery supports one published UnityFS/AES-GCM layout, not every encryption
format.** Wrong keys, unsupported layouts, damaged bytes, access errors, and
missing build metadata produce an error, without a fallback to another world's
file or another variant. An unchanged backup can still be encrypted. A VRCW
is a built world bundle and does not restore the original Unity project. The
transfer/recovery limit is 2 GiB. An account's file access restrictions still apply.

Read **WORLD_BACKUP_SETUP.md** for the full workflow and troubleshooting.
The 1.18.0 release passed **529 automated tests** with recovery dependencies installed, including
actual temporary-file transfers and synthetic encrypted world bundles. Live
VRChat world access, real-world decryption, Unity loading, and native Windows
rendering remain unverified; see **VALIDATION.md**.

## Version 1.17: capture the map background with VRChat's camera

Version 1.17 introduced the camera workflow below. It remains in this release
and needs no extra package.

Open **World → Camera capture…**. Position the native Photo camera above the area
and point it straight down. Enable OSC, select your VRChat photos folder, then
use **Capture + watch** to request a shot and preview the newly saved PNG.
**Watch manual shot** lets you press the shutter in-game instead. You can also
choose an existing camera PNG. **Prepare Photo camera** optionally sets Photo
mode and hides avatars/UI while keeping the environment visible.

Choose **Use photo as map** after checking the preview, or **Save map PNG…** to
save a separate image. The original photo is preserved. Larger supported photos
are reduced to fit the map viewer; the capture window supports up to 4K-class
photos within its 32 MiB / 16 megapixel limits. Map import starts uncalibrated
and does not inherit a previous map's world ID or coordinates.

**This produces an aerial perspective image, not a perfectly flat orthographic
map.** Camera placement is manual. Roofs and uneven terrain can obscure/distort
the result, and the app does not remove them or scan unseen rooms. Higher views
with narrower fields of view can look flatter when camera range permits.
Taking the image needs no custom world helper; **live player markers still do**.

See **World → Map setup…** / **WORLD_MAP_SETUP.md** for the full workflow and
camera limits. UDP requests and local files have automated tests; native camera
operation, Windows/Tk rendering, and live map alignment remain untested here.

## Version 1.16: separate Avatars and World tabs

Version 1.16 introduced the separate tabs. Existing avatar tools remain on **Avatars**;
**World** now has the map viewer and the existing **Rangefinder…** action.

- **World layout:** import an overhead PNG/GIF, pan and zoom, add named waypoints,
  and save/reopen a portable `.vrcmap` containing the image and your settings.
- **Player markers in supported worlds:** load a calibrated map and start the
  local log feed. Search players by display name, highlight a selection, and see
  straight-line distance in feet plus height difference. Dots clear when data
  expires or the room changes. Duplicate names remain separate instance IDs.
- **Standalone map viewing:** layouts and waypoints work without API sign-in,
  VRCX, JSON exports, or a live VRChat session. No extra Python dependency is needed.

**Live markers require the included Udon helper to be installed in the world.**
This needs a world you can edit or cooperation from its creator. VRC Eye does
not automatically retrieve any world's layout or locate everyone in arbitrary
existing worlds. The app shows waiting/expired/mismatch states when data is
unavailable; it never estimates positions from avatar names or account metadata.

Read **WORLD_MAP_SETUP.md**, also accessible through **World → Map setup…**.
It explains map calibration, PC Udon logging, and installing
`Unity/World/VRCEyeMapReporter.cs` in a Worlds project. The helper is local,
off by default, and enabled by interacting with its world object. It supplies
new position snapshots through the normal local VRChat log; there is no manual
JSON step. This is a desktop map page, not an in-headset overlay.

**454 automated tests pass.** Navigation/controllers, profile saving, map geometry,
freshness, world changes, and a real temporary-log worker are covered. Native
Windows/Tk rendering and the helper's Unity compilation/upload/live VRChat use
remain untested here. See **VALIDATION.md** for scope.

## Version 1.15: public-avatar archiving without key or JSON input

Version 1.15 introduced **Archive public…** in the main window and search results, plus **Avatar → Archive public avatar…** in the row submenu. These remain on the Avatars tab in the current release.

### Download or copy a public avatar

1. Open **Archive public…**. Paste the complete `avtr_…` ID or official avatar-page link, or start from a selected row/search result to prefill its ID. An avatar name alone does not identify the file.
2. Click **Look up public avatar** and sign in through the normal **VRChat connection** dialog if needed. The app obtains metadata itself; no exported JSON, VRCX, or supplied encryption key is required. Metadata comes from the [API's avatar lookup](https://vrchat.community/reference/get-avatar).
3. The archive action requires the API to report **Public** and supply usable file URLs for that ID. Private/Unknown status, inaccessible records, mismatched IDs, and missing file URLs stop this action with an explanation. The public label is a snapshot at the displayed lookup time, not a promise of continued access. The existing 60-second metadata spacing/cache applies.
4. Choose the platform/build you want: **PC, Android, or iOS**, when supplied. A single build is selected automatically; multiple builds require your choice.
5. Choose **Download public VRCA…** and a new destination. The default filename includes the avatar ID, platform, Unity version, asset version, and variant. Downloads show progress and the saved copy's SHA-256, and can be cancelled.
6. Alternatively, click **Find cached build…**. The cache browser searches the selected file ID/version. Select an available result and choose **Save selected…** to copy it unchanged. Close VRChat and rescan if it is locked. No cached result is proof that your currently worn/seen avatar uses that exact build.

**No key is needed to preserve bytes, but this is not keyless decryption.** A readable, accessible bundle can be archived directly. An encrypted downloaded/cache file stays encrypted after copying and still needs the matching key before decryption. A recognized header, public status, `.vrca` extension, or a newly calculated checksum does not establish that the file is complete, unencrypted, or usable in Unity. This action never requests a key or invokes the recovery decoder. It cannot repair damaged bytes or reconstruct the complete original Unity project.

Public avatars may still have download restrictions. An access error is reported without automatically retrying other URLs, changing variants, or changing authentication. Account/session changes cancel pending downloads, and stale avatar metadata must be looked up again. Existing destinations are not overwritten; the source cache is preserved. No event-to-avatar association is created by archiving a search result. The previously available standalone cache browser remains usable without sign-in; identifying one of its files as a specific public avatar requires suitable metadata.

**No recovery packages are needed for this feature.** The optional supplied-key recovery screen from version 1.14 remains separate. All **415 automated tests** pass with recovery dependencies installed. Tests use synthetic data and controlled HTTP responses; live VRChat account/file access and the native Windows interface remain untested here.

## Version 1.14: cache rescue and a supplied-key recovery field

Version 1.14 introduced the cache-rescue and supplied-key features below. They remain available in 1.15; use the current versioned ZIP and **Start.cmd**.

### Rescue a local copy for you or a friend

1. Click **Rescue cached avatar…** in the main window, or right-click your friend's log entry and choose **Avatar → Rescue cached avatar…**.
2. Click **Browse local cache…**. It scans the configured VRChat cache on this PC without requiring sign-in, VRCX, or an exported JSON file. If a file is locked, close VRChat and rescan before copying it. Keep existing files before clearing the cache.
3. To narrow the results, enter the exact avatar ID or official avatar-page link and choose **Find avatar in cache…**. This reuses loaded file metadata or offers normal VRChat sign-in and a metadata lookup. A single PC build is matched by its file ID/version; multiple builds open the build chooser, where you select a build and click **Browse cache…**. JSON/direct-URL options remain available in that chooser.
4. Select an available cache result and click **Save selected…** to preserve its bytes in a new file outside the cache. Existing destinations and original cache entries are kept.

Being in the same instance does not guarantee that the full avatar is present in your cache. Names, cache timestamps, and a friend's profile do not establish which file contains their avatar. The log entry is context for your selection; the rescue action does not guess or change event-to-avatar links. Online matching only uses file metadata available to your account. If metadata is inaccessible, the local browser still works, but unidentified files cannot be labeled as a particular avatar automatically.

An exact URL match associated with avatar metadata and a recognized Unity header can be saved as **.vrca**. Unidentified Unity bundles use **.bundle**; unrecognized data uses **.bin**. A cache copy can still be encrypted or damaged. **Save selected preserves encryption unchanged**, and a `.vrca` filename does not prove that the avatar will load. It does not install or reupload the saved file.

### Paste a key your friend provides

The cache browser now has **Decrypt with key…** for a selected, available Unity bundle. This is an experimental, optional recovery path for one published encrypted UnityFS layout.

1. Open **Start.cmd**. It creates/reuses `.recovery-env` and automatically prepares the consolidated dependencies, including `cryptography` and `lz4`. If setup cannot complete offline, available core features still open; reopen **Start.cmd** online to retry before decryption. Ordinary monitoring and unchanged cache copies remain available without these packages.
2. In the cache browser, select the correct file and click **Decrypt with key…**.
3. Copy your friend's **matching 256-bit file key** and click **Paste key**, or paste directly into the masked field with **Ctrl+V**. It accepts 64 hexadecimal characters or Base64 that decodes to exactly 32 bytes. An account password, avatar ID, or a key for a different file/build will not work.
4. Click **Decrypt to new file…** and choose a new destination outside the cache. Known, matched avatars use `.vrca`; otherwise the result remains `.bundle`.

The key is used locally and is not written to settings, logs, or CSV exports. The input field is cleared when recovery starts, on validation failure, and when the window closes. The app does not obtain, guess, or extract missing keys. Pasting does not clear your system clipboard.

Recovery supports the published chunked AES-GCM framing inside UnityFS versions 6–8, with uncompressed or LZ4 block metadata. It authenticates each encrypted chunk, rebuilds the bundle's block-size metadata, and saves a separate copy. Unknown layouts, wrong keys, failed authentication, truncation, source changes, and locks stop recovery. Normal errors and cancellation discard the temporary output. The existing 2 GiB limit applies; metadata is limited to 8 MiB. Encrypted-data authentication does not validate every unencrypted metadata field or prove Unity can load the result. Some readable Unity bundles also show the recovery button; the button itself is not an encryption detector.

**This cannot repair missing or corrupted cache bytes, or reconstruct the complete original Unity project.** A usable cached bundle may remain when the source project is damaged, but a compiled VRCA is not a replacement for project backups. Keep the original project/assets and any existing working backups too.

All **389 automated tests** pass, including synthetic encrypted bundles and the key-paste/rescue callbacks. **Actual VRChat cache files, real supplied keys, and the Windows interface have not been tested here.** See `VALIDATION.md` for scope and limits. The format reference is [VRChatStudio's supplied-key implementation](https://github.com/VRC1337/VRChatStudio); this release does not bundle or run that application.

## Version 1.13: VRC Eye, performance, trust, and Shader Watch

Version 1.13 renamed the app to **VRC Eye**. `vrc_eye.py` is the new entrypoint; `avatar_watch.py` remains compatible with existing scripts. These features remain available in 1.14.

### Avatar performance

The new **PERFORMANCE** column shows **Excellent, Good, Medium, Poor, or Very Poor** separately for **PC, iOS, and Android**. Assign the correct avatar link, sign in through **VRChat connection…**, then choose **Refresh details** or right-click **Avatar → Performance & Shader Watch… → Look up ratings online**. The API is the primary source; **Import avatar JSON…** is a backup and does not require file-download URLs.

Ratings come from explicit `performance` platform summaries or `unityPackages[].performanceRating`. Missing and unrecognized ratings stay **Unknown**. When several standard/security builds disagree and no platform summary is supplied, the column says **Multiple builds**; the viewer lists each build's rating. Impostor ratings are excluded. No rating is calculated from download size, partial statistics, or avatar names.

The asterisk marks the log row's unverified association with a selected avatar ID. These are the latest loaded metadata snapshots, **not proof of the avatar's rating at an older log-event time**. The viewer and CSV include their source and lookup/import time. Refresh again for newer data; the existing 60-second request spacing and short-lived cache still apply.

### Player trust and block status

The new **TRUST RANK (TAGS)** column is populated by **Player details… → Look up online**, using the exact `usr_` ID from the player's join log. It supports **Nuisance, Visitor, New User, User, Known User, and Trusted User** from available trust tags. Nuisance requires the confirmed `system_troll` tag; a probable flag alone is not promoted into that label. Platform can remain Unknown while a trust rank is available. Missing/invalid tags are Unknown; an explicit empty tag list means Visitor.

**Veteran User and Legendary User are historical labels, not current API ranks.** Old tags in an imported report are identified as historical; they do not create current Veteran or Legendary ranks. In particular, `system_trust_veteran` means **Trusted User**, not Veteran User. API trust tags also do not reveal a user's current choice to display a lower nameplate rank. Player details explains these limits and shows the snapshot time.

**“Blocked me” is unavailable.** The documented moderation endpoint lists actions made by your own account, not other users' blocks against you. VRC Eye does not infer a block from absence, a hidden avatar, a missing profile, or an API error. Player details shows this explicitly.

### Shader Watch

Right-click a linked avatar and choose **Avatar → Performance & Shader Watch…**. The viewer can list shader names and their renderer/material slots from **your own Unity avatar project**:

1. Copy `Unity/Editor/VRCEyeShaderReport.cs` into that project's `Assets/Editor` folder.
2. Select the avatar root with its uploaded blueprint ID. Choose the matching Windows, Android, or iOS build target.
3. Use **Tools → VRC Eye → Export shader report** and save the CSV.
4. In VRC Eye, choose **Import shader CSV…**. Its avatar ID must match the selected link.

Reports include inactive renderers and missing-material slots. They are explicitly labeled **local Unity project snapshots**; material swaps in animations and changes made during a build are outside the report's scope. Reports are limited to 2 MiB / 5,000 slots and kept separately for each platform. Reimport a report to replace that platform's snapshot.

**This does not scan other players' live shaders.** Ordinary logs and the available API do not supply a complete shader inventory, so those avatars show Unavailable unless you supply a matching project report. The app does not claim the CSV proves what was uploaded or is currently rendered in VRChat.

All new details stay in memory for the session. Disconnecting clears API-derived ranks; changing/clearing the log session clears the reports. Existing VRCX settings are read from the old AvatarWatch folder when no VRC Eye settings exist, and future settings saves use `%LOCALAPPDATA%\VRC-Eye\settings.json`. Existing uploaded rangefinder avatars keep working with the unchanged `AWRange_*` OSC parameters. If replacing the Unity rangefinder helper, remove the old `AvatarWatchRangefinderSetup.cs` before adding `VRCEyeRangefinderSetup.cs`.

Implementation references: [performance ranking](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/), [public user tags](https://vrchat.community/tags/user), [VRChat trust display](https://docs.vrchat.com/docs/vrchat-safety-and-trust-system), [moderation direction](https://vrchat.community/reference/get-player-moderations), [VRCX build ratings](https://github.com/vrcx-team/VRCX/blob/master/src/shared/utils/avatar.js), and [Unity renderer materials](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Renderer-sharedMaterials.html).

## Version 1.12: pointing rangefinder in feet

Close the old app, extract all of the current versioned ZIP, and run **Start.cmd**.

Open **Rangefinder…** to see the distance in feet to the player collider your avatar's ray hits. This uses an uploaded avatar configured with the included Unity setup helper and local OSC. **It does not work from an ordinary avatar without setup.** Read **RANGEFINDER_SETUP.md** first; the window also has an **Avatar setup instructions** button.

The helper creates a separate avatar copy with hand or head aiming, a short direction marker, and a heartbeat. Once uploaded, wear that copy, start the listener, enable OSC in VRChat, and point at a player, away, then back to initialize. A missed hit or stopped signal clears the distance. No VRCX, JSON export, or VRChat API sign-in is needed for this feature.

Recognize your friend visually: **the rangefinder cannot identify or track usernames, provide a direction to a friend, or assign measurements to log rows.** It measures from its emitter to the closest remote-player collider along the ray, and ignores world-geometry layers. It needs no custom world script, but compatibility with every world has not been established. The listener currently supports VRChat on the same PC, including PC VR; it does not listen on your LAN for standalone headsets. Keep-on-top affects the desktop window and is not an in-headset overlay.

The release includes Python tests and an editor-only C# setup helper. **Actual Unity compilation/upload, VRChat OSC output, live distance accuracy, and the native Windows interface remain untested here.** See VALIDATION.md for the checks performed.

After the current Development 30 release hold is satisfied, future release ZIPs
use `VRC-Eye-vYYYY.DD.MM.HH.mm.D.zip`. Maintainers stamp the two build constants
and run `python tools/package_release.py` after validation to create the matching
archive. Retained legacy development suffixes are omitted from calendar filenames.

## Version 1.11: search avatars and download from a result

Open **Search avatars…** in the main window. You can find an avatar and open its download dialog without selecting a log event or importing JSON.

1. Choose **My uploads**, **My favorites**, **Featured avatars**, or **VRCX cache**.
2. Enter part of an avatar name or creator name, or leave the box blank to browse. A complete `avtr_…` ID or official avatar-page link performs an exact online lookup regardless of the selected collection.
3. Click **Search / load**. Online searches ask you to sign in through **VRChat connection…** when needed. Searching VRCX's local database needs only its configured path and enabled connection.
4. Select a result and click **Download VRCA…**. Select its platform/build in the download dialog, then click **Download VRCA…** there and choose a new destination file. Available file metadata is reused; if a result lacks file URLs, the app looks up that exact avatar ID first.

Results show the avatar name, creator, public/private status when supplied, reported build platforms, and exact ID. **Open on VRChat** and **Copy avatar link** act on the selected result. Reported build platforms are not the player's device or a guarantee that a downloadable file is available. VRCX results do not report build platforms until an online lookup supplies metadata.

### Search scope and paging

This is **not unrestricted global avatar-name search**. The community-documented `/avatars` endpoint provides your uploads or featured avatars; `/avatars/favorites` provides your favorites. VRC Eye uses those collections and exact-ID lookup. It does not query other users' private uploads. VRCX cache search covers only avatars already recorded in your local database. See the API project's [avatar collection documentation](https://vrchat.community/reference/search-avatars) and [favorites documentation](https://vrchat.community/reference/get-favorited-avatars).

Online collections load **50 records per page**. Name/creator filters apply to the pages you have loaded; **zero matches is not proof that later pages contain none**. Click **Load more** to check the next page. Up to **1,000 records per search** can be checked. VRCX applies the text filter in its read-only database query and returns matching pages. Changing the query or collection requires **Search / load** again. Same-named avatars remain separate results by ID.

Each new online page uses the existing metadata queue, with requests spaced at least 60 seconds apart. Recent pages can be reused with their original timestamp. **Cancel** stops waiting and ignores late responses; earlier loaded pages remain available. A failure on a later page also leaves previous results visible. A connection, account, or log-session change requires a new search before continuing or downloading from old results.

Search downloads need no JSON when VRChat supplies usable file URLs for your account. They retain the existing platform/build selection, destination protection, progress, cancellation, and checksum features. File access can still fail; signing in does not make a deleted or inaccessible file available. Searching does not assign an avatar to a player or log event. The download dialog keeps its JSON/direct-URL/local-file backups and **Fetch online** can refresh the selected search avatar without a log row.

**Version 1.11 has automated API, database, and controller tests with synthetic data. It has not been run with a live VRChat account or the Windows GUI.**

## Version 1.10: direct lookup first, JSON as backup

You can now obtain avatar file metadata, public/private status, dates, and player-platform snapshots directly from VRChat. **Exported JSON is no longer required for these lookups when the relevant ID and account access are available.** VRCX remains optional.

### Connect once for this app session

1. Open **VRChat connection…** at the bottom of the main window.
2. Enter your **VRChat username and password in that desktop window**, then complete the verification method VRChat requests. `totp` means an authenticator code, `emailOtp` an email code, and `otp` a recovery code.
3. Continue using the avatar and player actions below. **Disconnect** discards this app's in-memory connection; exiting also discards it. You will need to sign in again after restarting VRC Eye.

This implementation supports VRChat account credentials, not Steam/Oculus/Apple interactive sign-in. It does not discover or import browser/VRCX cookies. Credentials go only to `https://api.vrchat.cloud` over HTTPS. Passwords, codes, and session cookies are not written to settings, CSV, or logs. Starting in 1.19.9, the separate **Remember password** checkbox can save the password in Windows Credential Manager after successful sign-in; **Remember username** independently saves/fills the username. Codes and cookies remain session-only. See **LOGIN_GUIDE.md**. Sign-in is optional; the existing local and JSON features remain available without it. Disconnect does not claim to revoke other applications' sessions on the server.

### The primary workflows

| Action | Connected behavior | Backup |
| --- | --- | --- |
| Avatar → Download VRCA… | For a selected avatar ID, fetch its file metadata when not already loaded, then open the build/download dialog. | Use JSON backup, load avatar JSON, paste an accessible asset URL, or preserve a local file. |
| Save local avatar… | Fetch missing file metadata for the selected ID, then find the identified PC build in the local cache. | Import avatar JSON; existing cache matching and file-lock limits still apply. |
| Download sizes… | Fetch missing file metadata, then **Fetch sizes** reads headers for the selected platform builds. | Manual sizes or separate analysis JSON when file URLs or usable headers are unavailable. |
| Refresh details | Fetch status, dates, and file metadata for the selected avatar. | With no connected account, use VRCX's read-only cached details. |
| Player details… | Opening the dialog starts a lookup for the exact user ID from the log; **Look up online** refreshes it. | Import/paste user JSON. |

The VRCA dialog also has **Fetch online**, and the sizes dialog has **Fetch avatar online** to request updated metadata. Existing session file choices are reused by normal actions; explicitly fetch again if you need newer choices. Multiple builds still require your selection. Avatar file access depends on what VRChat returns for your account. Sign-in cannot make a deleted or inaccessible file available.

**You still need an avatar ID.** When connected and the row has no avatar link, the app opens the link chooser instead of requiring a JSON file. Paste a known avatar-page link/ID or select an explicitly labeled local/VRCX candidate. The user record does not reliably provide the avatar ID worn at an old log event, and the switch log supplies only the avatar name. VRC Eye does not guess a file from a name, thumbnail, cache age, or the player's device. A pasted/candidate link is still your chosen association with the event.

Player lookup needs the `usr_…` ID from an unambiguous prior join entry. PC/Android/iOS remain **snapshots**, and `last_platform` stays **last known**. The lookup time is displayed; it is not proof of the device at the older event time. Avatar build platforms are never substituted for player-platform data. JSON and online records show distinct sources in the details and CSV. The platform CSV columns are now **Player platform**, **Player platform source**, and **Player platform checked/imported at (UTC)**.

### Waiting, access errors, and source handling

New metadata requests are serialized and spaced at least **60 seconds apart**. A recent result for the same ID can be reused for 60 seconds with its original lookup time. The lookup window shows any wait, can be cancelled, and offers **Use JSON backup…** for file/player workflows. There is no automatic polling of the instance roster. Authentication steps and explicitly started file downloads/header probes are separate from the metadata queue.

Access failures, expired sessions, unavailable records, unsupported responses, and server rate limits display a reason. Failed lookups preserve existing values; check their recorded source/time because they may be outdated. Online avatar dates/status take precedence over the optional VRCX cache until cleared/disconnected. An avatar response without usable file URLs can still update its available status/dates. Later JSON import remains an explicit way to supply file metadata.

When connected, file downloads and size checks can use the session cookie on the exact `api.vrchat.cloud` API file path. Cookies are **not forwarded to CDNs or other hosts**. Metadata/sign-in redirects are refused; file redirects retain the existing allowed-host checks. Disconnect/account changes cancel active work, invalidate pending results, and discard API-derived row data and file metadata. Log resets discard row metadata; the signed-in client's bounded short-lived metadata cache can still satisfy a same-ID lookup with the original timestamp.

The API is community documented and can change or reject third-party clients. **Version 1.10's sign-in, verification, metadata, and download-cookie behavior has automated tests with simulated responses; it has not been tested with a live account or the Windows GUI.** No real credentials or avatar bundles were used during development. The instructions below document the retained JSON/local workflows and earlier features.

## Version 1.9: avatar submenu and player platform imports

### Download from an avatar's submenu

1. Right-click that avatar's event in the list. You can also select the row and press **Shift+F10** or the keyboard Menu key.
2. Choose **Avatar → Download VRCA…**.
3. Select a build from the avatar JSON you already loaded, load its avatar JSON, or paste an accessible asset URL. Click **Download VRCA…** in the dialog and choose a new destination file.

The dialog identifies the selected player and avatar event. **Save local avatar…**, **Download sizes…**, and avatar website/link actions are also in the Avatar submenu. The menu keeps its original row target if new events reorder the list. If the target disappears, the session resets, or its avatar link changes, reopen the menu.

This action uses the existing downloader and its session metadata. A name or avatar-page link alone still does not supply a downloadable file URL. Direct asset URLs work without VRCX; avatar JSON can come from another source with the same `id` and `unityPackages` fields. Protected, expired, or unavailable URLs can still fail. Local cache saving retains the file-identification and locked-file limits below. The submenu belongs to VRC Eye's desktop window.

### See PC, Android, or iOS from a user JSON export

The **Player platform** column is separate from the avatar's downloadable build platforms. This section describes the JSON backup introduced in version 1.9; version 1.10 adds direct lookup above. The supported log lines and connected VRCX avatar database do not supply a reliable current device for each player. VRCX's user metadata can contain that information, but it is not persisted in the avatar table that VRC Eye reads.

1. Select an event and click **Player details…**, or use the same action in its right-click menu.
2. Import a **user** JSON export from VRCX's user JSON tab, or paste user JSON from another source. VRCX does not need to be running or connected for this import.
3. The JSON's `id` must match the unambiguous `usr_…` ID from that player's earlier join entry in the log. An avatar JSON export cannot provide the player's platform.

| User JSON field | Display |
| --- | --- |
| `presence.platform`, otherwise `platform` | PC, Android, or iOS, marked **(snapshot)**. |
| `last_platform`, when the above fields are absent or empty | PC, Android, or iOS, marked **(last known)**. |
| Missing data, an unsupported platform value, or no unambiguous logged user ID | **Unknown**. No device is inferred from an avatar, download, or display name. |

Recognized values are `standalonewindows`, `android`, and `ios`. Android includes standalone Android headsets and Android phones; PC includes desktop and PC VR. These fields do not identify a particular headset or distinguish VR from desktop mode. An unsupported current-platform value remains Unknown even if an older `last_platform` value exists.

The selected row's details show the source field and UTC import time. **Import time is not the source observation time.** A record can already be outdated when imported. The latest imported record is displayed beside all retained events with that exact user ID, including historical events; it does not prove what device was in use at an event's timestamp. Reimport newer data to update it. **Refresh details** still refreshes avatar dates/visibility only.

If no ID is available, open a log containing an `OnPlayerJoined NAME (usr_…)` entry, then select an avatar event occurring after that join. Older events are not retroactively linked by name. Conflicting same-name joins leave identity Unknown until the roster is unambiguous. Player departure and world changes clear parser associations.

Imports are limited to 2 MiB. Only the user ID, recognized platform, field name, and import timestamp are retained. **Clear for this user** removes that user's imported record. Clear view, a new log/watch, demo mode, and exit discard the records. CSV now includes these fields with an explicit source-age/event-time qualification. This feature makes no API requests, requires no VRC Eye login, and does not read VRCX's credentials or process memory.

## Version 1.8: selected-row local saving and working size lookup

**The size feature previously accepted only manually entered values or separate analysis JSON.** It did not fetch sizes from a normal VRCX avatar export. Its button was also disabled until a row had an assigned avatar link. Version 1.8 adds a server-size lookup and lets you begin from any selected, non-demo event.

### Save an identified avatar from your local cache

1. Select that avatar's event in the main list and click **Save local avatar…**.
2. If its file details are not loaded, choose the avatar JSON exported from VRCX's **JSON** tab. An existing selected avatar ID must match the export.
3. If there is one PC build, or you previously chose one, the matching cache browser opens. If PC builds are ambiguous, select one in the file dialog and click **Browse cache…**.
4. Select an available cache result and click **Save selected…**.

This is a shortcut for saving an identified, already-cached file. **It does not automatically identify every avatar in your current instance.** The supported switch logs contain player/avatar names, not reliable file IDs or asset URLs. A page link or `avtr_…` ID alone is also insufficient for locating its bundle. Names, timestamps, and recent cache entries are never treated as proof of which file belongs to a player. The feed is observed event history, not a guaranteed current roster.

When you import JSON for an unlinked row, its avatar ID is assigned to **that event only**, with an **unverified** association marker. Other same-name events remain unlinked. Imported file details and platform choices are remembered by ID for this session and reused by **Save VRCA…**, **Save local avatar…**, and **Download sizes…**. Clear view, opening a new log, starting another watch, demo mode, or closing the app clears them. Locked, encrypted, missing, and unrecognized cache files retain the limitations described below.

### Fetch PC, iOS, and Android download sizes

1. Select an event and open **Download sizes…**. If it has no assigned avatar ID, choose its VRCX avatar JSON when prompted.
2. Use **Load avatar JSON…** if file URLs are not already loaded. This accepts the ordinary avatar JSON export; it is separate from **Import analysis JSON…**.
3. Select one build for each platform you want checked. A platform with one available build is selected by default; multiple builds require your choice. Missing/skipped platforms stay unchanged.
4. Click **Fetch sizes**. Successful readings update the main list immediately, with PC, iOS, and Android still together in one column.

The lookup uses HTTP `HEAD`, then a one-byte range request when necessary. Redirects keep the HEAD method. It reads headers and closes the response without streaming the avatar body, including when a server ignores the range request. It requires an accessible asset URL and usable length headers. Sign-in requirements, expired URLs, missing totals, and unexpected responses produce **a reason beside the affected platform**, rather than a fabricated number. An unsuccessful lookup keeps any existing value; a platform without a value remains Unknown. Unknown is not zero or unsupported.

Values describe your **selected build and variant**, which may not be the newest upload or the one currently loaded by VRChat. The tool records whether each value came from server headers, a completed download, a manual entry, or imported analysis. A completed **Download VRCA…** operation also records its actual transferred byte count when its platform and avatar are identified by an imported export. Local cache copies and browser downloads do not update download sizes: cache size may differ, and browser transfers are not observed.

**Apply entered sizes** saves manual edits or imported analysis values. Binary/decimal units remain distinct. **Clear values → Apply entered sizes** removes the stored sizes for that avatar ID. Failed probes preserve manual edits. A partial refresh conservatively keeps a stale marker if older values remain. The aggregate recorded time is the last change to the combined size record; retained platform values can be older. Importing changed file choices also marks previous sizes stale.

The column/CSV heading is **Download sizes**, with provenance in **Download sizes source**. Source labels include selected build information but not signed asset URLs. Version 1.10 adds the optional direct connection described above; credentials are never imported from VRCX or a browser. This feature has automated protocol and controller tests; it has not been checked against your actual URLs or Windows GUI.

## Version 1.7: browse and save cached files

Open **Save VRCA… → Browse cache…** to inspect files already in VRChat's local cache.

For a particular avatar:

1. In VRCX, open the avatar and export its **JSON** tab.
2. In VRC Eye, open **Save VRCA… → Load VRCX JSON…**, then select the platform/build you need.
3. Click **Browse cache…**. **Find URL match** looks for that file/version in VRChat's cache without requesting a download.
4. Select an available result and click **Save selected…**. Choose a new filename outside the cache.

The browser also works without a URL: **List all cache files** lists supported cache entries by modification time, newest first. These entries remain **Unidentified**. It cannot recover an avatar name or `avtr_…` ID just from a cache folder or Unity header. A pasted asset URL can narrow the lookup, but loaded avatar file metadata is needed for the avatar association used by `.vrca` export. This metadata may come from the API or imported JSON. An event's name-match association still does not prove which avatar the player wore.

| Cache result | Saved copy |
| --- | --- |
| Matches the loaded avatar's asset URL and has a recognized Unity bundle header | `.vrca`, with contents still unverified. |
| Recognized Unity bundle without that avatar association | `.bundle`; it might be an avatar or a world. |
| Unrecognized bytes, including possibly encrypted or damaged data | `.bin`, preserving the raw bytes. Save selected does not convert, decrypt, or repair them. |
| Locked, unreadable, changed since the scan, or over 2 GiB | Cannot be copied. Close VRChat and rescan for locked/changing files. |

Renaming a raw backup does not turn it into a working avatar. A recognized header also does not prove completeness or that VRChat can load the file. The saved checksum identifies the bytes copied. Cache bytes and compression can differ from the original downloaded file; **cached size is not download size or VRAM usage**. The cache modification time is a filesystem timestamp, not the avatar's upload/update date.

**VRCX's avatar database and ImageCache are not a second store of avatar bundles.** This feature uses VRCX's exported avatar metadata to locate files in **VRChat's cache**. Selecting a VRCX data folder will not turn its database or preview images into avatars.

The default cache folder is:

```text
%USERPROFILE%\AppData\LocalLow\VRChat\VRChat\Cache-WindowsPlayer
```

VRC Eye reads `cache_directory` from the `config.json` beside the selected VRChat logs, when present, to suggest a custom location. **Browse…** lets you select it manually. You can select `Cache-WindowsPlayer` or its parent. The scanner supports the hashed-folder/version-folder/`__data` layout used by VRCX's cache lookup; it skips linked child folders/files and recognizable image/metadata payloads. Formats may change with VRChat updates.

All cache scanning and copying is local. No credentials or process memory are read, and the tool does not alter cache contents or install the saved file into VRChat. Existing destinations are never overwritten. Copies are refused if the source changes or becomes locked after scanning. A scan is bounded to 25,000 directory entries, 5,000 results, or approximately 20 seconds between filesystem operations; partial results are labeled. Use an asset URL match to narrow large caches. Scans and copies can be cancelled.

The file must still be present. A newer JSON export may identify a different version from one remaining in your cache; older/unmatched entries are not silently substituted. Keep any existing backup before clearing your cache. This release was tested against synthetic cache folders, not your installation.

## Version 1.6: save VRCA files

Click **Save VRCA…** below the avatar list.

| Option | What it does |
| --- | --- |
| Back up local VRCA… | Copies an existing file byte-for-byte to a new `.vrca` file, preserving the original. This also accepts a damaged file you want to keep. |
| Download VRCA… | Saves a copy from an available VRChat asset URL to a new `.vrca` file. |
| Load VRCX JSON… | Reads an exported avatar record and lists its available PC, iOS, and Android asset URLs by platform and build. Select the one you want before downloading. |
| Open URL in browser | Opens the supplied asset URL in your browser, where existing sign-in may help. VRC Eye cannot confirm that a browser download succeeded. |

To use VRCX, open the avatar in VRCX, refresh its details, and use the download/export button on its **JSON** tab. In VRC Eye, choose **Save VRCA… → Load VRCX JSON…**, open that JSON file, select a platform/build, and click **Download VRCA…**. If the event has an assigned avatar ID, the JSON must match it. An unverified association remains unverified. With a selected unlinked event, version 1.8 assigns the imported ID to that event and marks the association unverified. Without a selected event, no event links are changed.

You can also paste a known asset URL directly. A URL such as `https://vrchat.com/home/avatar/avtr_…` is an avatar page, not a file download. The supported log entries and VRCX's local avatar-cache table do not supply downloadable asset URLs. VRC Eye does not automatically discover a file from an avatar name. Version 1.7's **Browse cache…** adds local cache-file lookup and preservation as described above.

**Saving is not repair.** Backing up a corrupted file preserves its current bytes, including its damage. A new download helps only if an accessible, usable copy still exists. Ordinary saving does not decrypt bundles; version 1.14 adds the separate supplied-key option described above. The tool does not recover deleted uploads from the service, rebuild Unity source projects, or install saved files into VRChat. It never overwrites an existing destination.

Transfers run in the background with progress and cancellation. Each saved copy shows its SHA-256 checksum. If you have a trusted expected SHA-256, enter it before starting; mismatches are rejected. A calculated checksum alone, a recognized Unity header, or the `.vrca` extension does not establish that the avatar will load. The app does not open or execute downloaded bundles.

Incomplete transfers with a known expected size, empty downloads, and obvious web/error responses are rejected. Without a known size or trusted checksum, completeness cannot be verified. Handled failures and cancellations remove the temporary transfer file; forced termination or a storage failure can leave a `.avatarwatch-vrca-*.part` file. Cancellation can wait for the current network read to finish. Each transfer is limited to 2 GiB and JSON imports to 2 MiB.

Downloads use HTTPS URLs on supported VRChat asset hosts and validate redirects. URLs can expire, authentication may be required, and an unfamiliar CDN host is refused. Version 1.10 adds optional direct sign-in and restricted use of its in-memory session for API file requests. An access-denied response remains an error; your browser also needs permission to retrieve the file. Online actions make network requests as described above. File URLs are remembered in memory for this session, are not included in event CSV exports, and are not saved as settings.

The avatar JSON used here supplies **asset URLs**. The separate **Import analysis JSON…** feature described below supplies download sizes; these are different imports.

## Version 1.5: platform sizes and avatar dates

The main list now has three additional columns:

| Column | Data source |
| --- | --- |
| Download sizes | PC, iOS, and Android together in one cell, using fetched sizes, completed identified downloads, or values you enter/import. |
| Uploaded / created (UTC) | The selected avatar's `created_at` date saved by VRCX. |
| Last updated (UTC) | The selected avatar's `updated_at` date saved by VRCX. |

Use the horizontal scrollbar under the list to see all columns. Selecting a row also shows its details beneath the table.

### Automatic dates

Keep the connection under **VRCX…** enabled. Select an event, use **Set / change link…** to choose its avatar ID, and its dates load with its public/private status. **Refresh details** (previously Refresh status) rereads those fields from VRCX's cache.

The uploaded/created date is the **avatar record's creation date**, not a verified first asset-bundle upload time or a separate upload date for each platform. Last updated is the avatar record's update date; it may include metadata changes. Dates are normalized to UTC, and the table displays `YYYY-MM-DD`. CSV retains the full timestamp when available. Missing, invalid, sentinel, or unzoned timestamp values display Unknown. Cache-added times, log-event times, and the time you run VRC Eye are never substituted for upload/update dates.

Dates and visibility can be outdated. They apply to the ID you selected, and an asterisk marks an unverified name match. They are not inferred from names alone.

### Combined download sizes

**Platform sizes are not available through the current VRCX database connection.** VRCX gets its `fileSize` values through a separate file-analysis request. Use version 1.8's **Fetch sizes** with exported asset URLs, or the manual/analysis fallback below. VRC Eye does not acquire VRCX's credentials or claim its local database contains those sizes.

1. Assign an avatar link to the row first.
2. Click **Download sizes…**.
3. Enter known download sizes for PC, iOS, and Android, then click **Apply entered sizes**. Include units such as `42.5 MiB`, `42.5 MB`, or `44564480 B`. Prefer bytes when you have them; copied display values may be rounded.
4. Leave a platform blank if you do not know its size. Unknown does **not** mean unsupported or zero.

All three platforms stay in one cell, for example `PC: … | iOS: … | Android: …`. Binary units are labeled accurately: MiB means 1,048,576 bytes; MB means 1,000,000 bytes. Download size is separate from uncompressed size, texture memory, and VRAM usage.

Sizes are tied to the selected avatar ID and carry source information. Other rows only use them if you explicitly assign the same ID to those rows. They stay in memory for this session and are included in CSV exports with their source and recording time. Clear view, a new log, or closing the app discards them. **Clear values → Apply entered sizes** removes an ID's stored values.

When a refresh detects a different cached avatar-update timestamp, the supplied size cell is marked **[stale]**. This marker survives a later failed refresh. Recheck the sizes, open the dialog, and save/confirm them against the newly loaded details. If the update timestamp is unknown, the app cannot assess freshness; supplied values may still be outdated.

**Import analysis JSON…** is an optional path for platform analysis data you already have. It accepts VRCX's `fileAnalysis` shape (or that platform map directly), reads only numeric `fileSize` bytes, and ignores uncompressed/texture fields. A standard avatar JSON export belongs under **Load avatar JSON… → Fetch sizes**; its URLs allow a separate size lookup, but the JSON itself does not include the analysis values.

Example structure only; these numbers are fictional:

```json
{
  "fileAnalysis": {
    "standalonewindows": {"success": true, "fileSize": 41943040},
    "ios": {"success": true, "fileSize": 10485760},
    "android": {"success": true, "fileSize": 15728640}
  }
}
```

A supplied `avatarId` or `id` must match the selected avatar. Without an ID, the import is explicitly user-assigned to the selected ID; the app cannot verify that association. Missing platforms stay Unknown, failed analyses are ignored, and malformed values are rejected. Imports are limited to 2 MiB, read locally, and never executed or used to request URLs.

## Version 1.4: public/private visibility

The main event list and avatar chooser now include **Visibility (cached)**. It shows **Public**, **Private**, or **Unknown**, using the selected avatar ID's saved release status in VRCX.

1. Close the old VRC Eye, extract the entire ZIP, and run **Start.cmd**.
2. Make sure the connection under **VRCX…** is enabled and passes **Check connection**, then save it.
3. Select an event and click **Set / change link…**. Paste a known avatar link or ID, or choose a possible VRCX/OSC name match.
4. The event's visibility loads automatically. **Refresh details** rereads the cache for every assigned avatar ID, including when the event list is paused.

| Value | Meaning |
| --- | --- |
| Public / Private | VRCX has saved this release status for your selected avatar ID. |
| Public* / Private* | The selected ID came from an **unverified name match**. The status belongs to that candidate; it does not prove the player's avatar is the same one. |
| Unknown | No ID has been selected, VRCX is disabled/unavailable, or that ID has no recognized saved public/private status. |

The column applies to the **new avatar**, not the previous one. Names alone never set a status, even when VRCX has only one matching name. Link assignments remain specific to each event; a new row with the same name starts Unknown. OSC configurations provide candidate IDs but no release status, so an OSC-selected ID also needs a VRCX record for visibility.

**This is cached status, not a live website check or a historical status at the event's timestamp.** Refresh rereads the local database without requesting an update from VRChat. Values can be outdated until VRCX updates its cache. Changing the selected link or VRCX settings clears older values before a new lookup; failed lookups leave Unknown. These status reads make no changes to VRCX.

CSV exports now include visibility, its source, and the time VRC Eye read the cache in UTC. The timestamp is **not** the time VRCX last fetched the avatar. Asterisks and the original link provenance are preserved in exports.

**VRAM usage is not included.** The supported switch logs and VRCX avatar-cache table do not supply a reliable per-avatar VRAM reading. Download size is not a VRAM measurement. VRChat's own **Show Avatar Stats → Texture Memory** is a texture-memory estimate, not a measurement of all GPU memory currently used by that avatar; see the official performance documentation linked below.

## Version 1.3: VRCX integration

VRC Eye can now read **VRCX's locally saved avatar cache** to offer additional avatar IDs, names, and creators in the website-link chooser.

1. Close the old VRC Eye, extract this entire ZIP, and run **Start.cmd**.
2. Click **VRCX…** beside the avatar-link buttons.
3. Click **Check connection**. If needed, use **Browse…** to select your `VRCX.sqlite3` file.
4. Click **Save settings**.
5. Select an avatar event and click **Open on VRChat**. The choices now include **VRCX cache** matches, with creators shown where available.

The usual Windows database location is:

```text
%APPDATA%\VRCX\VRCX.sqlite3
```

Portable installations and custom database locations can be selected manually. You can also override the saved path for one launch:

```text
python vrc_eye.py --vrcx-db "D:\VRCX\VRCX.sqlite3"
```

The connection check shows how many avatar records are in that cache. The file may be available while VRCX is running or after it closes. Results are read again each time you open the avatar chooser, so close and reopen that chooser after VRCX updates its cache. Busy databases produce a retry message.

**Coverage is limited to avatars VRCX has actually cached.** VRCX's activity feed and avatar cache are different data sets. This integration does not read the feed, fetch a remote avatar database, or guarantee IDs for everyone in your instance. Every name match still requires your selection. Different IDs sharing the same name remain separate, even if only one has the creator you expect. The same ID found through both VRCX and OSC is shown once with both sources listed.

The database connection uses SQLite read-only mode and makes no data or schema changes. Queries target only `cache_avatar` and its schema metadata. VRC Eye does not read VRCX account credentials, private notes, or friend history. No VRCX login is required inside VRC Eye. Private/deleted avatar pages remain subject to the website's normal access rules.

Only the VRCX database path and enable toggle are saved in VRC Eye's own settings file, `%LOCALAPPDATA%\VRC-Eye\settings.json` on Windows. Avatar events, link assignments, cached details, and supplied sizes stay in memory until you export them. Disable **Use VRCX avatar matches, dates, and visibility** to use only local OSC matches and pasted links; visibility and date columns will show Unknown. Separately supplied sizes remain available for the current session.

The supported VRCX table is `cache_avatar`, requiring `id` and `name`; `author_name`, `release_status`, `created_at`, and `updated_at` are used when present. Schema compatibility is checked before querying. This interface is based on VRCX source checked on 2026-09-26 and may require an update if VRCX changes that schema. The earlier empty-feed diagnostics remain available; this integration improves link matching, not the detection of missing log events.

## Version 1.2: open an avatar on the VRChat website

Extract the complete updated ZIP and run **Start.cmd**.

1. Select an event and click **Open on VRChat**, or double-click its row.
2. If you already assigned an avatar link to that event, its page opens in your default browser.
3. Otherwise, paste a known VRChat avatar-page link or complete `avtr_…` ID. You can also choose a possible name match from locally saved avatars, when available.

**A name alone is not an avatar ID.** The usual switch log contains names; automatic links for every other player's avatar are not possible from that entry alone. Locally saved OSC avatar configurations provide names and IDs for avatars your client has used, but a same-name match does not verify that it is the avatar in the log. Every such match is presented for you to choose, and is labeled **Local name match (unverified)**. No match is assigned automatically.

**Copy link** copies the selected event's assigned URL. **Set / change link…** lets you replace it. The assignment applies only to that event, stays in memory, and is included in CSV exports with its source. It is not reused for another event with the same avatar name. Clearing history, opening a new log, or closing the app clears the associated assignments.

Links open ordinary pages under `https://vrchat.com/home/avatar/`. Availability depends on the website and your account; private or deleted avatars may not be viewable. Website sign-in happens in your browser, separately from VRC Eye's optional direct connection. The app does not circumvent page access restrictions.

Local candidate lookup reads `OSC/usr_*/Avatars/avtr_*.json` under the chosen VRChat log folder. Candidate lookup makes no network requests. Your browser accesses the website only when you choose to open a link. The earlier empty-feed diagnostics remain available; this feature does not resolve a log that lacks avatar-switch entries.

## Version 1.1: empty-feed troubleshooting

This update makes empty feeds diagnosable. It does not confirm the cause on a particular PC without its log data.

1. Close the old app, extract this updated ZIP, and run **Start.cmd**.
2. Click **Show all** to remove search and display filters and resume the view. Your own entries and reloads are now shown by default, making a test switch visible.
3. Switch avatars, or have someone in your instance switch, and allow a few seconds for the log to update.
4. If the feed remains empty, click **Diagnostics → Copy report** and provide that report when requesting help. It contains counts and a log filename, not player names or log contents.
5. Use **Open log…** to select the currently changing `output_log_*.txt` explicitly if automatic folder selection picks an old file.

Diagnostics distinguish three cases: events hidden by filters; switch-shaped lines rejected by the parser; and a log without named avatar-switch messages. If switch-shaped lines are rejected, provide one such line with player/avatar names replaced by placeholders so its exact header can be checked.

The reader now supports UTF-8 and BOM-marked UTF-16, with incremental decoding across partial writes. Header parsing accepts additional timestamp, bracket, separator, and severity variations. These variants are covered by tests; they have not been confirmed as the cause of the reported empty feed.

## Run on Windows

1. Extract the entire ZIP into a folder.
2. Install **Python 3.10 or newer** from [python.org](https://www.python.org/downloads/windows/) if needed. Keep the default Tcl/Tk component enabled.
3. Double-click **Start.cmd**. It prepares the packages in `requirements.txt`
   automatically; see **Source and checks** for manual environment setup.
4. Start the **PC version of VRChat**. The app watches the usual log folder automatically.

Use **Demo.cmd** to try the interface with labeled, fictional sample events.

The default log folder is:

```text
%USERPROFILE%\AppData\LocalLow\VRChat\VRChat
```

If your logs are elsewhere, use **Browse…**, or edit the folder field and click **Watch logs**. Select the folder containing `output_log_*.txt`, not the Steam installation folder.

This is a desktop companion window. It does not add a menu to VRChat or an in-headset overlay. PC VR and desktop sessions are supported; standalone Quest cannot supply a live Windows log folder.

## What the feed means

| Event | Meaning |
| --- | --- |
| Changed | A different avatar name was observed for the same player in this instance. |
| First seen | The player's first avatar entry in the observed instance; the previous avatar is unknown. |
| Reload | Another entry with the same avatar name; this may be a reload or a different avatar sharing the name. |
| Uncertain | An ambiguous name boundary, or conflicting join identities sharing a display name. |

The first avatar load after someone joins is not counted as a confirmed change. Player departure, world changes, and a new log reset the appropriate previous-avatar state. **Hide my avatar** uses the log's local-player identity; if it has not been found, the app says so and may include your own entries.

- Search matches player names, avatar names, and world names.
- **First loads** and **Reloads** toggle those events in the feed.
- **Always on top** keeps the desktop window above other desktop windows.
- **Pause view** freezes the table while events continue to be collected.
- **Clear view** removes displayed history while keeping previous-avatar tracking active.
- **Export CSV** saves the visible, filtered rows in chronological order, including full timestamps and names. While paused it exports the frozen view.
- Selecting a row shows full names and the source log beneath the table.

The newest log is read from its beginning to reconstruct the session. Older events in that file can appear when you first launch the tool; their timestamps are preserved. New lines are checked twice per second. A new VRChat log starts a fresh view. The last 3,000 avatar events are retained in memory; export anything you want to keep before closing.

## Limits and troubleshooting

The log feed reads names reported by VRChat; it does not obtain thumbnails or models from those log entries, or events from players outside the logged session. The switch entry does not supply an avatar ID; selected IDs come from links you paste or candidates already in local caches. File saving is a separate explicit action. Clothing toggles and expression changes are not avatar switches. Two avatars with the same name cannot be reliably distinguished. Avatar names and player names can contain unusual text; uncertain name boundaries are labeled.

The entry currently used is a timestamped `[Behaviour] Switching PLAYER to avatar AVATAR` line. VRChat updates can change or remove it. If no avatar entries appear:

1. Check that a recent `output_log_*.txt` exists in the chosen folder.
2. Check VRChat's settings for disabled output logging, then restart VRChat if needed.
3. Have someone in your instance switch avatars and wait briefly for the log to flush.
4. If lines increase but avatar entries remain at zero, that session may not contain the supported switch entry. The app cannot reconstruct data the client does not log.

An unchanged log may mean VRChat is idle or closed. “Watching local log” describes file monitoring; it is not a connection-status check. All times use the timestamp in the log. Invalid UTF-8 is replaced safely. Incomplete lines wait for a newline; unusually long lines are bounded and skipped. The app follows one VRChat session at a time.

Monitoring makes no network requests and uses no login credentials, client injection, process memory access, game-file changes, or automatic history uploads. Website links launch your browser only on request; VRCA downloads and size lookups access supplied URLs only when you start them. History disappears on exit unless you export it. CSV cells that could be interpreted as formulas are escaped. This is an independent, unofficial tool.

## Source and checks

Keep all application files together in the extracted folder. **Start.cmd**, **Start.sh**, and normal `python vrc_eye.py` launches prepare the consolidated `requirements.txt` automatically in `.recovery-env`. Missing Pillow is installed first so another optional package cannot block image support. Healthy installations are reused. If installation cannot complete offline, available core features and PNG wallpapers still open; the next normal launch retries missing packages. Safe Mode, Demo, help and version commands skip installation. To manage your own Python environment, use `python -m pip install -r requirements.txt`, then the legacy entry point `python avatar_watch.py`. Tests that require unavailable optional packages are skipped. The separate Unity editor helper is used only inside an authorized VRChat avatar project.

```text
python vrc_eye.py
python vrc_eye.py --demo
python vrc_eye.py --logs "C:\path\to\VRChat\VRChat"
python -m unittest discover -s tests -v
```

On Linux, Python must include Tkinter; select the VRChat log folder inside your
actual Proton prefix. Run `python3 vrc_eye.py` from the extracted application
folder; normal launches prepare the application-local requirements automatically.
Windows and Linux are project targets; current platform verification limits are
recorded in [development notes](DEVELOPMENT_1_20.md).

The parser and incremental reader are covered by included tests for partial writes, Unicode, first loads, same-name reloads, room changes, file rotation, truncation, diagnostics, header variations, UTF-16, explicit file selection, and CSV escaping. Runtime validation details are in `VALIDATION.md`.

## References

Protocol behavior, metadata sources, and the supported encrypted cache framing were checked between 2026-09-26 and 2026-09-28. The implementation is original; reference sources were used to identify emitted formats and metadata fields.

- [VRChatStudio supplied-key format reference](https://github.com/VRC1337/VRChatStudio)
- [cryptography AESGCM API](https://cryptography.io/en/46.0.0/hazmat/primitives/aead/)
- [python-lz4 block API](https://python-lz4.readthedocs.io/en/stable/lz4.block.html)

- [VRChat: local storage](https://docs.vrchat.com/docs/local-vrchat-storage)
- [VRChat: configurable cache location](https://docs.vrchat.com/docs/configuration-file)
- [VRCX cache path/version lookup](https://github.com/vrcx-team/VRCX/blob/master/Dotnet/AssetBundleManager.cs)
- [VRCX image cache implementation](https://github.com/vrcx-team/VRCX/blob/master/Dotnet/ImageCache.cs)
- [VRChat 2025.2.1 beta notes: avatar-switch log restored](https://docs.vrchat.com/docs/vrchat-202521-openbeta)
- [VRCX maintained log parser](https://github.com/vrcx-team/VRCX/blob/master/Dotnet/LogWatcher.cs)
- [VRChat OSC avatar configuration files](https://docs.vrchat.com/docs/osc-avatar-parameters)
- [VRCX avatar-cache implementation](https://github.com/vrcx-team/VRCX/blob/master/src/services/database/avatarFavorites.js)
- [VRCX database schema](https://github.com/vrcx-team/VRCX/blob/master/src/services/database/index.js)
- [VRCX user platform and presence handling](https://github.com/vrcx-team/VRCX/blob/master/src/coordinators/userCoordinator.js)
- [VRCX user metadata types](https://github.com/vrcx-team/VRCX/blob/master/src/types/api/user.d.ts)
- [VRCX in-memory user cache](https://github.com/vrcx-team/VRCX/blob/master/src/stores/user.js)
- [VRCX direct sign-in implementation](https://github.com/vrcx-team/VRCX/blob/master/src/stores/auth.js)
- [Community API authentication implementation](https://github.com/vrchatapi/vrchatapi-python/blob/main/vrchatapi/api/authentication_api.py)
- [Community API usage guidance and sign-in example](https://github.com/vrchatapi/vrchatapi-python)
- [Community API user schema](https://github.com/vrchatapi/specification/blob/master/openapi/components/schemas/User.yaml)
- [Community API avatar schema](https://github.com/vrchatapi/specification/blob/master/openapi/components/schemas/Avatar.yaml)
- [VRCX platform file-analysis lookup](https://github.com/vrcx-team/VRCX/blob/master/src/coordinators/cacheCoordinator.js)
- [VRCX JSON-tab export behavior](https://github.com/vrcx-team/VRCX/blob/master/src/components/dialogs/DialogJsonTab.vue)
- [VRCX maintainer's database-location guidance](https://github.com/vrcx-team/VRCX/discussions/1588)
- [VRChat: viewing avatar statistics and texture memory](https://creators.vrchat.com/avatars/avatar-performance-ranking-system/)
- [VRChat: texture memory differs from download size](https://creators.vrchat.com/avatars/avatar-optimizing-tips/)
