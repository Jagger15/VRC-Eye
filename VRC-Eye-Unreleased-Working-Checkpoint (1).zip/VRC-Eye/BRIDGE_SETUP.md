> **1.19.8 additive Client Bridge Lab contracts:** See
> [CLIENT_BRIDGE_LAB_GUIDE.md](CLIENT_BRIDGE_LAB_GUIDE.md) and
> [client_bridge_lab_contracts.json](client_bridge_lab_contracts.json).
> They reuse this connection; capability version 1 is negotiated individually.
> Lab actions require exact context/target preconditions and provider-owned
> lifetime enforcement. This release supplies no VRChat-specific provider.

# VRC Eye 1.18.5 — optional client bridge

This release prepares the external bridge needed by the detailed Safety design.
Open **Advanced → Client bridge…** in the sidebar. The bridge starts disabled.
The existing seven pages work without it. A compatible adapter must connect,
advertise its implemented capabilities and receive your approval before any
bridge data or local game control becomes available.

The bridge is not a VRChat client or a mod loader. VRC Eye does not install,
inject, discover or attach code to VRChat. There is no adapter for a particular
custom client bundled here. The included Python SDK and open protocol let a
client author supply one through their own supported integration mechanism.
The diagnostic example is complete and runnable but does not control VRChat.

## Connect an adapter

1. Start VRC Eye, open **Client bridge…**, and click **Enable bridge**.
2. Click **Copy connection code** and paste it into the local adapter you have
   chosen. This is a temporary bridge pairing secret, not a VRChat login.
3. The adapter's name, version and claimed attachment appear in the panel.
   Every new connection is quarantined. Identity and attachment are reported by
   the adapter; the handshake does not independently verify its publisher or
   whether it is actually attached to VRChat.
4. Select individual capability rows (Ctrl/Shift for multiple). Choose
   **This connection**, **10 minutes** or **1 hour**, then **Approve selected…**.
   Read the review and any client-defined preset descriptions. Each capability
   becomes available after the client acknowledges the permission revision.
5. Approving telemetry is enough to display its fresh, structured sample.
   Local game actions also require **Enable approved local game controls for
   this connection**. Game actions appear only while all their gates are met.
6. Select an available action, enter the exact `usr_…` ID (comma-separated IDs
   for focus groups), choose the requested state, and review the request.
   The microphone action does not need a target ID. VRC Eye waits for a typed
   client confirmation and never automatically retries an uncertain action.

The advanced panel intentionally uses exact IDs. It does not yet synchronize
its selection with the World player list. A friendlier per-player Safety panel
and automatic resource/voice correlation belong to the later Safety modules.

### Disconnect and controls

- **Revoke selected / Revoke all** ends approval and clears affected samples.
  Any permission revision also invalidates outstanding requests conservatively.
- **Pause bridge requests (keep telemetry)** blocks new bridge requests, even
  diagnostic pings. Approved incoming telemetry resumes after the new permission
  revision is acknowledged. This switch affects the bridge only; it is not the
  proposed application-wide outbound kill switch.
- **Disconnect client** ends its current session and clears all its approvals.
  The listener remains enabled. A reconnect starts in quarantine again.
- **Disable bridge** closes the listener and connection, and invalidates its
  connection code. The next enable generates a new endpoint and secret.
- Closing the panel leaves an enabled bridge running. Closing VRC Eye stops it.
  Closing the panel or disabling clears the current clipboard only if it still
  contains the code copied by that panel; it does not clear clipboard history.
- Signing in, signing out, changing the signed-in user, or entering Demo ends
  the current bridge session. Demo cannot enable the bridge. API sign-in is not
  required for standalone bridge use; if signed in, the adapter's local user ID
  must match that account for game capabilities.

The host and SDK use a five-second heartbeat lease. Fresh telemetry lasts at
most three seconds, with the reported sample age subtracted. Disconnected or
expired measurements are unavailable, never displayed as zero. A changed
client runtime/account/world requires a new session and new consent. An adapter
author is responsible for reporting that lifecycle change.

An already dispatched local action can finish even if a disconnect, pause or
revocation follows. These controls prevent further requests; they cannot undo
an effect that the client already applied. Refresh the client state before
trying an unconfirmed action again.

## Run the diagnostic example

On Windows, open **Bridge-example.cmd** in the extracted VRC-Eye folder.
On Linux, run `python3 bridge_example.py` from that folder. The example needs
Python 3.10+ and the standard library; it does not need the optional extras.

Enable the bridge in VRC Eye, copy the code, and paste it into the example's
hidden terminal prompt. Approve **Adapter diagnostics** and **Connection round
trip** in VRC Eye. Select Adapter diagnostics to see elapsed seconds and click
**Test connection** for an authenticated ping. Ctrl+C ends the example and
removes its live capabilities from VRC Eye.

The example identifies itself as `diagnostic`. It cannot enable game telemetry
or game controls, even if such capabilities were added to its manifest.

## Capabilities provided by this foundation

All listed capabilities use schema version 1. They describe what a compatible
adapter can exchange, not measurements VRC Eye can collect by itself.

| Type | Capability IDs | Meaning |
| --- | --- | --- |
| Diagnostic | `bridge.ping`, `bridge.diagnostics` | Connection round trip and adapter uptime; usable by the example |
| Player telemetry | `player.selection`, `player.voice_activity`, `player.distance` | Selected exact ID, active voice/avatar audio flags, or distance in metres |
| Avatar telemetry | `avatar.load_state`, `avatar.performance` | Load state, performance rank, texture bytes and component counts |
| Runtime telemetry | `unity.runtime_health` | Optional FPS/frame time, process working set, tracking and foreground state |
| Your local state | `local.microphone_state`, `local.moderation_state` | Your microphone and your own per-user mute/hide/interaction settings |
| Local audio actions | `safety.microphone_mute`, `safety.voice_mute`, `safety.avatar_audio` | Request a specific local mute/audio state |
| Local visual actions | `safety.avatar_visibility`, `safety.avatar_effects`, `safety.avatar_particles`, `safety.avatar_lights` | Request local rendering/effects changes |
| Local interaction action | `safety.interactions` | Request enabling/disabling your local interactions with a target |
| Client-defined local actions | `safety.player_preset`, `safety.focus_group` | Apply a described preset to one user or to everyone outside selected IDs |

Texture memory is an adapter-reported texture estimate, not exact total GPU
VRAM attributable to an avatar. Missing fields stay missing. Voice activity is
not a loudness measurement or an accusation. Local moderation reports describe
your controls toward someone; they do not reveal who blocked or muted you.
Core avatar metadata, file permissions and cache recovery remain independent
of bridge reports. The bridge cannot authorize protected file access.

## SDK integration for client authors

The reference SDK is **bridge_sdk.py**, with **bridge_protocol.py** and
**bridge_transport.py**. It exposes:

| API | Contract |
| --- | --- |
| `BridgeClient(...)` | Stable installation/client ID, display name/version, kind, runtime context, capability manifest, and explicit local action handlers |
| `connect(connection_code)` | Authenticate a local endpoint and start I/O; call from an integration worker because the handshake waits |
| `connected()` / `allowed(capability)` | Current connection and effective approval checks |
| `publish(capability, value)` | Publish a validated fresh sample only when allowed; coalesces the latest sample per capability |
| `dispatch_pending(limit=1)` | Execute queued typed handlers on the adapter's own appropriate game/main thread, never on the I/O worker |
| `set_runtime(context)` | Close the connection, clear queued work and update attachment identity; explicitly reconnect and obtain fresh consent |
| `close()` | Cancel handshake/I/O, clear consent and queued work; no automatic reconnect |

`bridge_example.py` demonstrates an actual client from construction through
shutdown. For a game adapter, use `kind="vrchat"` and an attached context:

```python
context = {
    "attached": True,
    "runtime_session": "66666666-6666-6666-6666-666666666666",
    "local_user_id": "usr_11111111-1111-1111-1111-111111111111",
}
```

Those are illustrative IDs. Generate a new runtime UUID for the actual
attachment and on every world/instance change, account change or runtime reset.
Use the actual local user ID. On detach, call `set_runtime` with
`attached=False`, `runtime_session=None`, `local_user_id=None` immediately.
Never reuse cached game context to claim attachment after a game shutdown.

Advertise only telemetry the client actually measures and local callbacks it
actually implements. The SDK rejects action capabilities without handlers.
A handler takes the exact parameters defined in **BRIDGE_PROTOCOL.md** and
returns `{"applied": True}` only after applying the requested local change.
It must recheck that the runtime and target still exist and that normal local
permissions allow the operation. It must not reach another user's client.
Run `dispatch_pending` regularly on the client thread that owns the relevant
objects. Never access Unity objects from the SDK I/O worker. Keep callbacks
short; a callback already entered cannot be forcibly canceled by the SDK.

No native DLL/shared-library wrapper is included in 1.18.5. C#, C++ and other
adapters can implement the documented framing, handshake and typed messages
directly. The protocol has no Python pickle objects, remote evaluation, Unity
object handles, arbitrary file access or client-to-VRC-Eye command execution.

## Local transport and retention

Windows uses a randomized, local-only, single-instance message-mode named pipe
restricted to the current Windows user. Linux uses an owner-only Unix socket
inside a private temporary directory and checks the peer's OS UID. Both also
require the temporary 256-bit pairing secret. No TCP port, web service,
broadcast discovery, VRChat password or session cookie is used by the bridge.
macOS and remote network connections are not supported in this release.

Permissions and pairing secrets are kept in memory and are not saved in
settings. The panel holds the latest fresh sample for each approved capability.
It also keeps the most recent 200 request/permission outcomes in memory, without
payloads, player IDs or pairing secrets. **Show recent bridge requests** displays
them. This is not the planned disk-backed black box or global action ledger.

Malformed/incompatible sessions are disconnected. Three protocol/connection
failures within a minute isolate the bridge until you enable it again. The rest
of VRC Eye continues. This is bridge failure isolation, not an application-wide
API mutation circuit breaker or a separate crash watchdog process.

## Safety specification and availability

**SAFETY_DESIGN_INPUT.md** preserves the full supplied 56-section specification
and separates this release's bridge foundation from the future Safety Center.
The proposed combined emergency panel, resource guards, Safety overlay, crash
recorder, global privacy/read-only/outbound switches and automated correlations
remain future work. Version 1.18.5 adds a separate Wellness overlay and reviewed
external OS audio/normal-exit controls; see **WELLNESS_SETUP.md**. These do not
implement the broader Safety specification or require client-bridge telemetry.

Tests exercise real host/SDK workers and encoded messages through controlled
message pipes, plus Tk callbacks and platform adapter contracts. The build
environment cannot create Unix sockets, has no Windows runtime and has no
graphical display. Native transport/layout checks and a live compatible-client
test are still required. See **VALIDATION.md** for the exact verification scope.

## Player-list extension in 1.18.6

The backward-compatible optional telemetry capability `instance.context` version 1
is required before the new Player List attaches bridge samples to people:

```json
{"world_id":"wrld_11111111-2222-3333-4444-555555555555","instance_id":"1234","network_master":"usr_11111111-1111-1111-1111-111111111111"}
```

`world_id` is an exact lowercase world ID. `instance_id` is the complete instance
string after the colon, including its modifiers, at most 1024 characters without
control characters. `network_master` is optional and may be null. The adapter must
report its actual current context, with ordinary sample age and permission revision.
Do not copy the supplied example IDs. Context and player telemetry need separate
approvals and a fresh matching local log context. Old adapters need not advertise
this optional capability; their existing protocol 1.0 features continue working.

Voice indicators expire after one second of source age; distance and other player
telemetry use at most the existing three-second lease. The host retains both receive
and sample-observation times internally. No new game command or injection method
is introduced. See PLAYER_LIST_SETUP.md for reviewed per-player controls and
limitations. Missing capabilities remain unavailable.
