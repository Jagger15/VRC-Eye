"""Read asset sizes from HTTP headers without streaming avatar bodies."""

import re
from datetime import datetime, timezone
from http.client import HTTPException
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener

from avatar_details import (MAX_SIZE, PLATFORMS, DownloadSizes, normalize_avatar_timestamp,
                            sizes_are_stale)
from avatar_links import parse_avatar_reference
from vrca_files import AssetRedirectHandler, VRCAError, VRCACancelled, validate_asset_url


def _cancel(stop):
    if stop is not None and stop.is_set():
        raise VRCACancelled("Size lookup cancelled; existing values were kept.")


def _length(value):
    if value is None:
        return None
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{1,16}", value.strip()):
        raise VRCAError("The server returned an invalid file size.")
    result = int(value)
    if result > MAX_SIZE:
        raise VRCAError("The server-reported size exceeds the supported range.")
    return result


def probe_download_size(url, *, stop=None, opener=None):
    """HEAD first; one-byte range fallback. Never read the response body."""
    url = validate_asset_url(url)
    client = opener or build_opener(AssetRedirectHandler())
    for method in ("HEAD", "GET"):
        _cancel(stop)
        headers = {"User-Agent": "VRC-Eye/1.18.6 size-check", "Accept-Encoding": "identity"}
        if method == "GET":
            headers["Range"] = "bytes=0-0"
        request = Request(url, method=method, headers=headers)
        try:
            with client.open(request, timeout=10) as response:
                _cancel(stop)
                validate_asset_url(response.geturl())
                media = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if media.startswith(("text/", "image/", "audio/", "video/")) or "json" in media or "xml" in media:
                    raise VRCAError("The URL returned a page or another file type, not avatar download metadata.")
                if response.headers.get("Content-Encoding", "identity").strip().lower() not in ("", "identity"):
                    raise VRCAError("The response was encoded; its length is not a reliable avatar file size.")
                length = _length(response.headers.get("Content-Length"))
                content_range = response.headers.get("Content-Range", "")
                if response.status == 200 and not content_range:
                    if length is not None:
                        return length
                    if method == "HEAD":
                        continue
                    raise VRCAError("The server did not provide a total size. Enter a known size manually or import analysis JSON.")
                if method == "GET" and response.status == 206:
                    match = re.fullmatch(r"bytes 0-0/([0-9]{1,16})", content_range.strip())
                    if match and length in (None, 1):
                        total = _length(match[1])
                        if total:
                            return total
                    raise VRCAError("The partial response did not identify the complete file size.")
                raise VRCAError("The server returned an unexpected response instead of a complete file size.")
        except HTTPError as error:
            error.close()
            _cancel(stop)
            if method == "HEAD" and error.code in (405, 501):
                continue
            if error.code in (401, 403):
                raise VRCAError("Access denied (sign-in required). VRC Eye cannot read this URL's size; use a known size or file-analysis JSON.") from None
            raise VRCAError(f"Size lookup failed (HTTP {error.code}); the file URL may be unavailable or expired.") from None
        except (URLError, OSError, HTTPException):
            _cancel(stop)
            raise VRCAError("Size lookup failed. Check the connection and whether the asset URL is still available.") from None


def platform_choices(export):
    return {key: [item for item in export.choices if item.platform == title]
            for key, title, _native in PLATFORMS} if export else {key: [] for key, _, _ in PLATFORMS}


def default_selections(export, remembered=None):
    result = {}
    for key, choices in platform_choices(export).items():
        selected = (remembered or {}).get(key)
        if selected in choices:
            result[key] = selected
        elif len(choices) == 1:
            result[key] = choices[0]
    return result


def choice_description(choice):
    return f"Unity {choice.unity_version} · asset {choice.asset_version} · {choice.variant}"


def probe_platform_sizes(selections, *, stop=None, progress=None, probe=None):
    found, errors = {}, {}
    probe = probe or probe_download_size
    for key, title, _native in PLATFORMS:
        choice = selections.get(key)
        if choice is None:
            continue
        if choice.platform != title:
            raise VRCAError("The selected build does not match its platform.")
        _cancel(stop)
        if progress:
            progress(title)
        try:
            amount = probe(choice.url, stop=stop)
            found[key] = (amount, "Server headers · " + choice_description(choice))
        except VRCACancelled:
            raise
        except VRCAError as error:
            errors[key] = str(error)
    _cancel(stop)
    return found, errors


def merge_size_readings(avatar_id, current, readings, updated_at=""):
    """Keep untouched values and their provenance; failed probes never erase them."""
    reference = parse_avatar_reference(avatar_id)
    if current and current.avatar_id != reference:
        raise ValueError("Size readings belong to a different avatar ID.")
    if not readings:
        return current
    values, sources, retained = {}, [], False
    for index, (key, title, _native) in enumerate(PLATFORMS):
        old = getattr(current, key) if current else None
        if key in readings:
            amount, source = readings[key]
            if type(amount) is not int or not 0 <= amount <= MAX_SIZE:
                raise ValueError(f"{title} size must be a nonnegative integer number of bytes.")
            values[key] = amount
        else:
            values[key] = old
            source = (current.platform_sources[index] or current.source) if current and old is not None else ""
            retained |= old is not None
        sources.append(source)
    baseline = current.avatar_updated_at if current and retained else normalize_avatar_timestamp(updated_at)
    stale = bool(current and retained and sizes_are_stale(current, updated_at))
    summary = "; ".join(f"{title}: {sources[index]}" for index, (key, title, _) in enumerate(PLATFORMS)
                        if values[key] is not None)
    return DownloadSizes(reference, **values, source=summary, platform_sources=tuple(sources),
                         recorded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                         avatar_updated_at=baseline, stale=stale)
