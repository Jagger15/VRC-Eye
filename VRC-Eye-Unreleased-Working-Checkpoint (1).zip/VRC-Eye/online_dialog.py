"""Optional remembered sign-in and cancellable direct metadata lookup dialogs."""

from text_viewport import window_body

import queue
import threading

from vrchat_api import APIError, VRChatAPI
from login_storage import LoginStore, LoginStorageError
from account_header import boundary, presentation, private, attempt


def show_connection_dialog(app, on_connected=None):
    tk, ttk = app.tk, app.ttk
    existing = getattr(app, "connection_window", None)
    if existing is not None and existing.winfo_exists():
        if on_connected:
            existing.on_connected = on_connected
        existing.lift()
        return
    store = LoginStore(enabled=not (getattr(app, "demo", False) or getattr(app, "safe_mode", False)))
    restore = getattr(app, 'session_restore', None)
    # Connected summaries do not read saved credentials. The form loads them
    # only for an explicit switch/reconnect or an initially signed-out dialog.
    autofilled = None
    window = tk.Toplevel(app.root)
    app.connection_window = window
    window.on_connected = on_connected
    window.title("VRChat connection")
    window.geometry("730x710")
    window.minsize(680, 670)
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=22)
    frame.pack(fill="both", expand=True)
    summary = tk.StringVar()
    summary_detail = tk.StringVar()
    ttk.Label(frame, textvariable=summary, style="Subtitle.TLabel", wraplength=650).pack(anchor="w")
    ttk.Label(frame, textvariable=summary_detail, style="Muted.TLabel", wraplength=650).pack(anchor="w", pady=(4, 12))
    account_controls = ttk.Frame(frame)
    account_controls.pack(fill="x", pady=(0, 10))
    form = ttk.Frame(frame)
    ttk.Label(form, text=("Sign in for avatar/world metadata, player details, and your friend-list snapshot. "
        "Credentials are sent over HTTPS to api.vrchat.cloud. Remembering is optional; "
        "verification codes are never saved. Stay signed in stores eligible session cookies in protected OS storage. Local tools work without signing in. "
        "Use a VRChat username/password, not Steam/Oculus sign-in."),
        wraplength=675, style="Muted.TLabel").pack(anchor="w", pady=(10, 12))
    username = tk.StringVar(value="")
    password = tk.StringVar(value="")
    code = tk.StringVar()
    remember_username = tk.BooleanVar(value=False)
    remember_password = tk.BooleanVar(value=False)
    fields = []
    for title, variable, mask in (("VRChat username", username, ""), ("Password", password, "•")):
        ttk.Label(form, text=title).pack(anchor="w")
        entry = ttk.Entry(form, textvariable=variable, show=mask)
        from screen_reader_model import annotate
        annotate(entry,name=title,protected=bool(mask),public=bool(mask))
        entry.pack(fill="x", pady=(3, 8))
        fields.append(entry)
    remember_row = ttk.Frame(form)
    remember_row.pack(fill="x", pady=(0, 5))
    username_check = ttk.Checkbutton(remember_row, text="Remember username", variable=remember_username)
    username_check.pack(side="left", padx=(0, 22))
    password_check = ttk.Checkbutton(remember_row, text="Remember password", variable=remember_password)
    password_check.pack(side="left")
    memory_status = tk.StringVar(value="Saved sign-in is separate from the active session.")
    stay = tk.BooleanVar(value=bool(restore and restore.snapshot.enabled))
    stay_touched = False
    ttk.Label(form, text="Choose either, both, or neither. New values save after successful sign-in; unchecking forgets that value.",
              wraplength=675, style="Muted.TLabel").pack(anchor="w", pady=(0, 10))
    sign_in = ttk.Button(form, text="Sign in", style="Accent.TButton")
    sign_in.pack(anchor="w", pady=(0, 12))
    verification = ttk.Frame(form)
    ttk.Label(verification, text="Verification method / code").pack(anchor="w")
    row = ttk.Frame(verification)
    row.pack(fill="x")
    method = ttk.Combobox(row, state="disabled", width=16)
    method.pack(side="left", padx=(0, 8))
    code_entry = ttk.Entry(row, textvariable=code, show="•", state="disabled")
    annotate(code_entry,name='Verification code',protected=True,public=True)
    annotate(method,name='Verification method',public=True)
    code_entry.pack(side="left", fill="x", expand=True)
    verify = ttk.Button(row, text="Verify", state="disabled")
    verify.pack(side="left", padx=(8, 0))
    phase = "connected" if app.api and app.api.authenticated else "sign_in"
    status = tk.StringVar(value="Connected for this session." if phase == "connected" else "Press Enter or click Sign in.")
    messages = ttk.Frame(frame)
    messages.pack(fill='x')
    annotate(ttk.Label(messages, textvariable=status, style="Muted.TLabel", wraplength=650),name='Sign-in status',role='status',value=status.get).pack(anchor="w", pady=(10, 5))
    annotate(ttk.Label(messages, textvariable=memory_status, wraplength=650, style="Muted.TLabel"),name='Remembered sign-in status',role='status',value=memory_status.get).pack(anchor="w", pady=(0, 6))
    session_controls = ttk.Frame(frame)
    session_controls.pack(fill='x', pady=(0, 8))
    stay_check = ttk.Checkbutton(session_controls, text='Stay signed in on this computer', variable=stay)
    stay_check.pack(side='left')
    restore_button = ttk.Button(session_controls, text='Try saved session')
    restore_button.pack(side='left', padx=8)
    remove_session = ttk.Button(session_controls, text='Remove saved session')
    remove_session.pack(side='left')
    session_status = tk.StringVar()
    ttk.Label(frame, textvariable=session_status, wraplength=650, style='Muted.TLabel').pack(anchor='w')
    local_client = None
    pending = None
    busy = False
    internal_edit = False
    forget = None
    poll_id = None
    observed_context = boundary(app)
    observed_private = private(app)
    auth_guard = None
    installing = False
    disposed = False
    manage = switch = sign_out = None

    def change_fields(user, secret):
        nonlocal internal_edit
        internal_edit = True
        try:
            username.set(user)
            password.set(secret)
        finally:
            internal_edit = False

    def edited(which):
        nonlocal autofilled
        if internal_edit:
            return
        if which == "password":
            autofilled = None

    username.trace_add("write", lambda *_: edited("username"))
    password.trace_add("write", lambda *_: edited("password"))

    def memory_allowed():
        # Recheck at use time as the main window can enter Demo while this
        # dialog or an authentication request is still open.
        return store.enabled and not (getattr(app, "demo", False) or getattr(app, "safe_mode", False))

    def load_credentials():
        nonlocal autofilled
        notices = []
        try:
            saved_username = store.load_username()
        except LoginStorageError as error:
            saved_username = ''
            notices.append(str(error))
        try:
            saved_password = store.load_password()
        except LoginStorageError as error:
            saved_password = None
            notices.append(str(error))
        autofilled = saved_password if saved_password and (not saved_username or saved_password.matches(saved_username)) else None
        change_fields(saved_username, autofilled.password if autofilled else '')
        remember_username.set(bool(saved_username))
        remember_password.set(saved_password is not None)
        memory_status.set(' '.join(notices) or store.vault.reason)

    def labels():
        value = presentation(app)
        summary.set('VRChat account · ' + value.title)
        summary_detail.set('Account details are hidden by privacy or presentation settings. Reveal them to sign in or manage this account.' if value.hidden else
                           'Account name shown. Other privacy settings still keep account actions hidden.' if private(app) else
                           value.detail or ('Eye uses this account for API actions. The running game may use another account.' if value.active else 'Local tools are available without signing in.'))

    def controls():
        hidden = private(app)
        credentials_enabled = not busy and phase == "sign_in" and not hidden
        if phase == 'connected':
            account_controls.pack(fill='x', before=messages, pady=(0, 10))
        else:
            account_controls.pack_forget()
        if phase != 'connected' and not hidden:
            form.pack(fill='x', before=messages)
        else:
            form.pack_forget()
        if phase == 'verify' and not hidden:
            verification.pack(fill='x')
        else:
            verification.pack_forget()
        for entry in fields:
            entry.configure(state="normal" if credentials_enabled else "disabled")
        sign_in.configure(state="normal" if credentials_enabled else "disabled")
        username_check.configure(state="normal" if credentials_enabled and memory_allowed() else "disabled")
        password_check.configure(state="normal" if credentials_enabled and memory_allowed() and store.password_available else "disabled")
        verify_enabled = not busy and phase == "verify" and not hidden
        verify.configure(state="normal" if verify_enabled else "disabled")
        method.configure(state="readonly" if verify_enabled else "disabled")
        code_entry.configure(state="normal" if verify_enabled else "disabled")
        if forget:
            forget.configure(state="normal" if not busy and phase != 'verify' and memory_allowed() and not hidden else "disabled")
        if switch:
            switch.configure(state='normal' if not busy and phase == 'connected' and not hidden else 'disabled')
        if manage:
            manage.configure(state='normal' if phase == 'connected' and not hidden and getattr(app, 'sidebar', None) else 'disabled')
        if sign_out:
            sign_out.configure(state='normal' if phase == 'connected' and not hidden and not busy and restore else 'disabled')
        if restore and not stay_touched:
            stay.set(restore.snapshot.enabled)
        ready = bool(restore and not busy and phase != 'verify' and memory_allowed() and not hidden)
        restore_busy = bool(restore and restore.snapshot.busy)
        stay_check.configure(state='normal' if ready and not restore_busy else 'disabled')
        restore_button.configure(state='normal' if ready and not restore_busy else 'disabled',
                                 text='Complete verification' if restore and restore.snapshot.state == 'challenge_required' else 'Try saved session')
        remove_session.configure(state='normal' if ready else 'disabled')
        session_status.set('' if hidden else restore.snapshot.detail if restore else '')
        labels()

    def refresh_account():
        nonlocal observed_context, observed_private, local_client, pending, phase, autofilled
        if disposed:
            return
        context, hidden = boundary(app), private(app)
        if not installing and (context != observed_context or hidden != observed_private):
            if restore and hidden != observed_private:
                restore.manual()
            if local_client is not None and local_client is not app.api:
                local_client.close()
            local_client = None
            pending = autofilled = None
            change_fields('', '')
            code.set('')
            attempt(app, window)
            phase = 'connected' if presentation(app).active else 'sign_in'
            status.set('Account or privacy changed. Pending sign-in canceled; credentials were not saved.')
        observed_context, observed_private = context, hidden
        controls()

    def current():
        if boundary(app) != observed_context or private(app) != observed_private:
            refresh_account()
            return False
        return not disposed and not private(app)

    def begin_switch():
        nonlocal phase
        if not current() or busy:
            return
        if restore:
            restore.manual()
        phase = 'sign_in'
        load_credentials()
        status.set('The current account stays connected until another sign-in succeeds. Close to cancel.')
        controls()
        fields[0].focus_set()

    def manage_account():
        if current() and getattr(app, 'sidebar', None):
            app.sidebar.show('Accounts')
            close()

    def forget_one(which):
        # Unchecking applies immediately, even if the user closes without signing
        # in again. The controls are disabled during an authentication attempt.
        if not current() or busy or phase == "verify" or not memory_allowed():
            controls()
            return
        variable = remember_username if which == "username" else remember_password
        if variable.get():
            memory_status.set("Your " + which + " will be remembered after successful sign-in.")
            return
        try:
            (store.forget_username if which == "username" else store.forget_password)()
            memory_status.set("Saved " + which + " removed. The current form can still be used to sign in.")
        except LoginStorageError as error:
            variable.set(True)
            memory_status.set(str(error))

    def forget_saved():
        nonlocal autofilled
        if busy or phase == "verify" or not memory_allowed() or private(app):
            return
        errors = []
        for which, variable, action in (("username", remember_username, store.forget_username),
                                         ("password", remember_password, store.forget_password)):
            try:
                action()
                variable.set(False)
            except LoginStorageError as error:
                errors.append(str(error))
        change_fields("", "")
        autofilled = None
        code.set("")
        memory_status.set(" ".join(errors) if errors else "Saved username and password removed. Your current connection is unchanged.")
        if phase != 'connected':
            fields[0].focus_set()

    def save_success():
        nonlocal pending, autofilled
        errors = []
        user, secret = pending or ("", "")
        pending = None
        if not memory_allowed():
            memory_status.set("Sign-in memory was not saved while Demo or Safe mode is active.")
            return
        if remember_username.get():
            try:
                store.save_username(user)
            except LoginStorageError as error:
                errors.append(str(error))
        if remember_password.get():
            try:
                store.save_password(user, secret)
            except LoginStorageError as error:
                errors.append(str(error))
        if stay.get() and restore:
            if not restore.remember(app.api):
                errors.append('The saved-session operation is busy. Use Stay signed in again after it finishes.')
        # Values from unchecked options were already deleted on toggle. Do not
        # touch a second application's newer credential entry on a plain login.
        autofilled = None
        change_fields(user if remember_username.get() else "", "")
        if errors:
            memory_status.set("Signed in, but some remember settings could not be saved. " + " ".join(errors))
        elif remember_username.get() or remember_password.get():
            choices = "username and password" if remember_username.get() and remember_password.get() else ("username" if remember_username.get() else "password")
            memory_status.set("Your " + choices + " will be filled in the next time you open this window.")
        return bool(errors)

    def finish_login(client, methods):
        nonlocal phase, pending, installing, observed_context
        if auth_guard != (boundary(app), private(app)):
            refresh_account()
            return
        if methods:
            phase = "verify"
            attempt(app, window, 'verify', auth_guard[0])
            method.configure(values=methods)
            method.current(0)
            controls()
            status.set("Enter the requested code, then press Enter or click Verify: totp = authenticator, emailOtp = email, otp = recovery code.")
            code_entry.focus_set()
        else:
            if not client.authenticated:
                pending = None
                phase = "sign_in"
                status.set("VRChat did not confirm sign-in. No new credentials were saved.")
                controls()
                return
            installing = True
            try:
                app.set_api_client(client)
                observed_context = boundary(app)
            finally:
                installing = False
            attempt(app, window)
            storage_warning = save_success()
            phase = "connected"
            controls()
            code.set("")
            status.set("Connected for this session. Account actions use the identity shown above.")
            continuation = window.on_connected
            if continuation:
                if storage_warning:
                    # Do not lose a save-error warning when an automatic lookup
                    # continuation closes this window.
                    from tkinter import messagebox
                    messagebox.showwarning("Sign-in memory", memory_status.get(), parent=window)
                close()
                continuation()

    def start(job, client):
        nonlocal busy, poll_id
        if busy:
            return
        busy = True
        controls()
        status.set("Contacting VRChat…")
        results = queue.Queue(maxsize=1)

        def worker():
            try:
                results.put((job(), ""))
            except (APIError, ValueError) as error:
                results.put((None, str(error)))
            except Exception:
                # A failed worker must release busy state, and an unexpected
                # exception must not echo a password-bearing exception payload.
                results.put((None, "Sign-in could not complete. Check the connection and try again."))

        def done():
            nonlocal busy, pending, phase, poll_id
            poll_id = None
            if not window.winfo_exists():
                pending = None
                if client is not app.api:
                    client.close()
                return
            try:
                methods, error = results.get_nowait()
            except queue.Empty:
                poll_id = app.root.after(100, done)
                return
            busy = False
            if client is not local_client or client.closed.is_set():
                pending = None
                controls()
                return
            if auth_guard != (boundary(app), private(app)):
                refresh_account()
                return
            if error:
                if phase != "verify":
                    user = pending[0] if pending else ""
                    pending = None
                    change_fields(user, "")
                    fields[1].focus_set()
                else:
                    code_entry.focus_set()
                status.set(error)
                if phase != 'verify':
                    attempt(app, window)
                controls()
            else:
                finish_login(client, methods)

        threading.Thread(target=worker, daemon=True).start()
        poll_id = app.root.after(100, done)

    def login():
        nonlocal local_client, pending, phase, autofilled, auth_guard
        if not current() or busy or phase != "sign_in":
            return
        if restore:
            restore.manual()
        user, secret = username.get().strip(), password.get()
        if not user or not secret:
            status.set("Enter your VRChat username and password first.")
            (fields[0] if not user else fields[1]).focus_set()
            return
        if autofilled is not None and not autofilled.matches(user):
            change_fields(user, "")
            autofilled = None
            status.set("That saved password belongs to a different username. Enter this account's password to continue.")
            fields[1].focus_set()
            return
        if local_client is not None and local_client is not app.api:
            local_client.close()
        local_client = VRChatAPI()
        # Retain a password beyond the initial request only when the user asked
        # to remember it, until full sign-in (including 2FA) is confirmed.
        pending = (user, secret if remember_password.get() else "")
        phase = "sign_in"
        change_fields("", "")
        autofilled = None
        code.set("")
        client = local_client
        auth_guard = (boundary(app), private(app))
        attempt(app, window, 'sign_in', auth_guard[0])
        start(lambda: client.login(user, secret), client)

    def verify_code():
        if not current() or busy or local_client is None or phase != "verify":
            return
        chosen, value = method.get(), code.get()
        if not value.strip():
            status.set("Enter your verification code first.")
            code_entry.focus_set()
            return
        code.set("")
        client = local_client
        start(lambda: client.verify(chosen, value), client)

    def enter(event=None):
        # Widget-local bindings avoid turning Enter on Close/Disconnect/remember
        # controls (or elsewhere in the app) into a surprise sign-in operation.
        if not busy:
            if phase == "verify":
                verify_code()
            elif phase != "connected":
                login()
        return "break"

    def disconnect():
        nonlocal local_client, pending, phase, autofilled, observed_context
        if not current():
            return
        if restore:
            restore.disconnect()
        if local_client is not None:
            local_client.close()
        local_client = None
        pending = None
        phase = "sign_in"
        autofilled = None
        app.set_api_client(None)
        observed_context = boundary(app)
        attempt(app, window)
        password.set("")
        code.set("")
        controls()
        status.set("Disconnected. Session cookies were discarded. Saved sign-in stays until you uncheck it or use Forget saved sign-in.")

    def stay_changed():
        nonlocal stay_touched
        if not current() or busy or phase == 'verify' or not restore:
            return
        stay_touched = True
        if not stay.get():
            restore.forget()
        elif app.api and app.api.authenticated:
            restore.remember(app.api)
        else:
            status.set('The session will be saved only after full sign-in, including any required verification.')
        controls()

    def remove_saved_session():
        nonlocal stay_touched
        if current() and not busy and phase != 'verify' and restore:
            stay_touched = True
            stay.set(False)
            restore.forget()
            controls()

    def sign_out_account():
        if not current() or busy or not restore:
            return
        disconnect()
        remove_saved_session()
        status.set('Disconnected. Saved-session removal is in progress; remembered username/password are separate.')

    def try_saved_session():
        nonlocal local_client, pending, auth_guard
        if not current() or busy or not restore:
            return
        candidate = restore.claim_challenge()
        if candidate is None:
            restore.restore()
        else:
            if local_client is not None and local_client is not app.api:
                local_client.close()
            local_client = candidate
            pending = None
            remember_username.set(False)
            remember_password.set(False)
            stay.set(True)
            auth_guard = (boundary(app), private(app))
            finish_login(candidate, candidate.methods)
        controls()

    def close():
        nonlocal pending, autofilled, poll_id, disposed
        disposed = True
        pending = None
        autofilled = None
        if local_client is not None and local_client is not app.api:
            local_client.close()
        if poll_id is not None:
            try:
                app.root.after_cancel(poll_id)
            except (AttributeError, ValueError):
                pass
            poll_id = None
        change_fields("", "")
        code.set("")
        attempt(app, window)
        window.refresh_account = None
        window.on_connected = None
        window.destroy()
        app.connection_window = None

    sign_in.configure(command=login)
    verify.configure(command=verify_code)
    stay_check.configure(command=stay_changed)
    restore_button.configure(command=try_saved_session)
    remove_session.configure(command=remove_saved_session)
    username_check.configure(command=lambda: forget_one("username"))
    password_check.configure(command=lambda: forget_one("password"))
    for widget in (*fields, sign_in, method, code_entry, verify):
        widget.bind("<Return>", enter)
        widget.bind("<KP_Enter>", enter)
    bottom = ttk.Frame(frame)
    bottom.pack(fill="x")
    ttk.Button(bottom, text="Disconnect", command=disconnect).pack(side="left")
    forget = ttk.Button(bottom, text="Forget saved sign-in", command=forget_saved)
    forget.pack(side="left", padx=(12, 0))
    close_button = ttk.Button(bottom, text="Close", command=close)
    close_button.pack(side="right")
    manage = ttk.Button(account_controls, text='Manage account', command=manage_account)
    manage.pack(side='left')
    switch = ttk.Button(account_controls, text='Switch account…', command=begin_switch)
    switch.pack(side='left', padx=(10, 0))
    sign_out = ttk.Button(account_controls, text='Sign out and remove session', command=sign_out_account)
    sign_out.pack(side='left', padx=(10, 0))
    window.protocol("WM_DELETE_WINDOW", close)
    window.bind("<Escape>", lambda _event: close())
    window.refresh_account = refresh_account
    if phase != 'connected' and not private(app):
        load_credentials()
    controls()
    (close_button if private(app) else switch if phase == 'connected' else fields[0] if not username.get() else fields[1] if not password.get() else sign_in).focus_set()


def lookup_online(app, kind, reference, on_result, *, parent=None, on_fallback=None):
    if parent is not None and not parent.winfo_exists():
        return
    if not app.api or not app.api.authenticated:
        show_connection_dialog(app, lambda: lookup_online(app, kind, reference, on_result,
            parent=parent, on_fallback=on_fallback))
        return
    tk, ttk = app.tk, app.ttk
    client = app.api
    generation = app.data_generation
    window = tk.Toplevel(parent or app.root)
    window.title("VRChat lookup")
    window.geometry("710x270")
    window.configure(bg=app.BG)
    frame = ttk.Frame(window_body(window), padding=22)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text=f"Look up {kind}: {reference}", wraplength=660).pack(anchor="w")
    status = tk.StringVar(value="Looking up metadata…")
    ttk.Label(frame, textvariable=status, wraplength=660, style="Muted.TLabel").pack(anchor="w", pady=(12, 12))
    stop = threading.Event()
    app.transfer_stops.append(stop)
    results, progress = queue.Queue(maxsize=1), ["Looking up metadata…"]

    def worker():
        try:
            results.put((client.lookup(kind, reference, stop=stop, progress=lambda text: progress.__setitem__(0, text)), ""))
        except (APIError, ValueError) as error:
            results.put((None, str(error)))
        finally:
            app.transfer_stops.remove(stop)

    def done():
        if not window.winfo_exists():
            return
        if client is not app.api or generation != app.data_generation:
            stop.set()
            status.set("The connection or log session changed. Reopen this action.")
            return
        try:
            result, error = results.get_nowait()
        except queue.Empty:
            status.set(progress[0])
            app.root.after(100, done)
            return
        if error:
            status.set(error)
            return
        try:
            on_result(result)
        except (ValueError, APIError) as error:
            status.set(str(error))
            return
        window.destroy()

    def close():
        stop.set()
        window.destroy()

    def fallback():
        close()
        on_fallback()

    buttons = ttk.Frame(frame)
    buttons.pack(fill="x")
    if on_fallback:
        ttk.Button(buttons, text="Use JSON backup…", command=fallback).pack(side="left")
    ttk.Button(buttons, text="Cancel / close", command=close).pack(side="right")
    window.protocol("WM_DELETE_WINDOW", close)
    threading.Thread(target=worker, daemon=True).start()
    app.root.after(100, done)
