# VRC Eye — remaining ARC and VRCX functions after Development 19

This inventory covers **106 feature areas: 82 VRCX and 24 ARC**. Development 19 incorporates the completed Development 18 work and the Home improvements from this continuation. Source implementation and native/live acceptance are separate gates.

| Disposition | Areas |
|---|---:|
| Source implemented; native/live acceptance open | 50 |
| Acceptance / provider prerequisite | 7 |
| Partial | 39 |
| Source-data limitation | 2 |
| Missing | 8 |

**47 areas remain missing/partial: 39 partial and 8 missing.** The Development 18 static GLB milestone and its ARC-01 partial status are retained. This is not full rich-avatar viewer parity.

## Development 19 changes

- **VX-DESK-02**: Up to four AND-combined Home/widget conditions; power preference rules; temporary fallback with persistent override preserved; privacy masking of layout controls; clear empty views.
- **VX-DESK-16**: Uses Development 18 shared field-level settings history and rollback; no parallel Home-only journal.
- **VX-MIG-17 / VX-MIG-29**: Combined conditions retain supported native settings export/restore/undo, and older single-condition documents remain readable.

## Next work

1. Native Windows/Linux acceptance for the GLB viewer, combined Home conditions, privacy, keyboard navigation, high contrast and large text.
2. Richer material/texture scene inspection and qualified model import, followed by rigs/blendshapes and animation.
3. Installed AssetRipper, Unity and real-origin resumable-transfer acceptance; typed repair-helper integration with the working-copy journal.
4. Broader dashboard subscriptions, remaining direct settings stores, tray/background reliability, interactive Discord requests and SteamVR controls.
5. Publisher feed/signing/package/rollback prerequisites before update installation.

## All missing and partial areas

| ID | Feature | State | Remaining implementation or qualification |
|---|---|---|---|
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Partial | All other profile fields/producers, every historical source schema and unobserved changes remain outside coverage. Actual change times and hidden data cannot be reconstructed from snapshots. |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | Partial | General creator duplicate detection across asset/model content, complete historical asset-version acquisition and actual rollback remain missing. Exact local hashes do not establish equivalent avatars. |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Partial | Image approval has no verified endpoint in the pinned source. Ordering is limited to one complete unfiltered page of fewer than 100 images. |
| VX-MIG-01 | Versioned source contract inventory | Partial | Additional historical source-version adapters are not exhaustive. |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Partial | Requires rollback-journal stores. This does not erase physical logs/photos, original VRCX files, all creator/media stores or minimal action receipts. |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Partial | Independent live stores are not universally one atomic database. Profile snapshots can represent slightly different instants. |
| VX-MIG-14 | User, world and avatar memos plus account notes | Partial | Historical producer/export schemas and bidirectional external-app note synchronization remain incomplete. Creator notebooks, quick notes and photo notes retain their distinct purposes. Private annotations do not update API profile tags or account notes. |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Partial | Persistent custom-user-tag VRCX producer/export contracts remain conditional. Tags are local entity annotations; unobserved external labels cannot be reconstructed. |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Partial | Other individual display/date/sidebar stores and unverified external VRCX settings mappings remain incomplete. Exported Development 18 conditional layouts require a reader supporting those optional fields. |
| VX-MIG-20 | Video, resource and auxiliary game-log history | Partial | All version-specific auxiliary payloads remain conditional. |
| VX-MIG-23 | Notification archives and invite message details | Partial | Exhaustive nested payloads across historical versions are not supported. |
| VX-MIG-25 | Print favorite references and conditional print metadata | Partial | Complete historical print metadata/export schemas remain conditional. |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Partial | Exhaustive legacy/cross-application formats are not claimed. |
| VX-MIG-28 | Saved searches, filters and portable views | Partial | No verified persisted VRCX saved-search producer was found; such external migration remains conditional. These are native VRC Eye tag views. |
| VX-MIG-29 | Native selective backup and complete restore | Partial | Original photos, Unity/recovery workspaces, protected sessions, approvals and unrecognized stores remain outside portable settings. The private direct-edit ledger is not part of the portable settings bundle. |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Partial | Complete bidirectional VRCX roundtrip is not claimed; ID/CSV exports lose richer native relationships/history. |
| VX-DESK-01 | Shared dashboard projections | Partial | Other runtime/log views do not yet share one revisioned subscription/paging contract. Producer freshness for every summary and Smart Start remain incomplete. |
| VX-DESK-02 | Configurable dashboards and widget layouts | Partial | Interactive VR dashboard rendering, broader runtime-specific conditions and native Windows/Linux accessibility/layout acceptance remain open. |
| VX-DESK-06 | Discord content, join controls and coexistence | Partial | Interactive Discord join-request acceptance is not implemented. Native Discord IPC and application registration remain user/environment prerequisites. |
| VX-DESK-08 | Opt-in crash recovery controller | Partial | Unattended private-instance rejoin and installed native crash/launch acceptance remain incomplete. |
| VX-DESK-15 | Tray/background and low-power operation | Partial | Native tray/startup/shutdown acceptance and comprehensive adaptive sensor/provider throttling remain. |
| VX-DESK-16 | Settings profiles, backup and rollback UX | Partial | Direct edits in all other stores, physical asset recovery and native active-control/accessibility acceptance remain open. Credentials, service grants, executable approvals and paths are excluded. History is bounded and does not retrospectively reconstruct earlier edits. |
| VX-DESK-17 | Optional update channels and recoverable installation | Partial | Publisher endpoint, trusted signing keys, installer/update-channel implementation and native rollback acceptance remain missing. |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Partial | Live provider acceptance, broader providers and generalized playback-error correlation remain incomplete. |
| ARC-01 | Isolated avatar provider contract and lifecycle | Partial | Rich-avatar/Unity-bundle/FBX provider coverage, formal OS sandbox containment and native Windows/Linux process/render qualification remain open. The bundled static GLB parser is process fault separation, not an OS security boundary. |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing | Decode authorized VRCA/Unity bundles into actual mesh/material/rig/animation scene data; supported-version and missing-dependency reporting. |
| ARC-03 | Authorized FBX import and scene inspection | Missing | FBX import/scene inspection including axes, units, importer settings, takes and external dependency handling. |
| ARC-04 | Actual material and texture viewer | Missing | Actual material/submesh assignments, texture and alpha display, UV channels, typed shader properties and rendered shader fallbacks. |
| ARC-05 | Rig, skinning and blendshape viewer | Missing | Bone/bind-pose/influence inspection, skinned preview, reversible poses and blendshape controls. |
| ARC-06 | Clip, take and safe controller animation preview | Missing | Actual clip/take playback and scrubbing, speed/loop/root-motion controls and safe Animator/controller-subset preview. |
| ARC-07 | AssetRipper provider selection, version and provenance | Partial | Exact installed-release/version qualification, publisher/license verification, dependency pinning and a qualified provider registry remain. A local executable hash and compatible API do not authenticate its publisher. |
| ARC-08 | Integrated user-owned recovery orchestration | Partial | Native Windows/Linux installed-release acceptance, complete descendant containment, exporter memory/disk containment and version-specific quality/failure qualification remain. This process lifecycle is not an OS sandbox. |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial | Original-source completeness, semantic object/fileID/material/rig validation, OS-enforced immutability and successful Unity import are not established. Raw data is protected by application behavior and hash checks, not an OS sandbox. |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing | Compare real mesh/renderer/pose bounds and apply reviewed bounds corrections or margins to clones. |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing | Compatible mesh/renderer/importer setting transfer with typed diffs, fresh copies and controlled reimport policy. |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing | Dependency-checked influence reduction, proven-unused bone removal and renderer consolidation with measured deformation comparisons. |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial | Full topology/stream/index/tangent diagnostics and narrowly reviewed tangent repairs. |
| ARC-14 | Shader and material compatibility diagnostics | Partial | Actual shader compilation, render-pipeline/platform compatibility and complete typed material-property/keyword/texture analysis still require richer parser/editor evidence. GUID presence alone does not validate the target object. |
| ARC-15 | Typed material property mapping on copies | Partial | Exact-shader-version mapping profiles and reviewed texture, offset/scale, color, number/vector, queue and keyword transfer. |
| ARC-16 | Reviewed shader package install and removal | Partial | Shader-specific install/remove planning with dependency review, post-operation compilation/diffs and change-aware removal journal. |
| ARC-17 | Animation and controller dependency repair copies | Partial | Object-reference curve repairs, clip swaps and cloned Animator/override-controller dependency closure repair. |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial | Binary Unity component and object-level dependency graphs, validated Unity fileIDs, component copying and reference remapping remain incomplete. Static GLB hierarchy does not establish Unity semantic equivalence. |
| ARC-19 | General repair-copy journal and conditional rollback | Partial | Automatic capture around every existing Unity/VPM repair helper, typed repair plans, native Windows/Unity and power-loss acceptance remain open. Rollback publishes one file at a time, not an atomic multi-file transaction; file modes and empty-directory history are outside coverage. |
| ARC-21 | Evidence-based automated local-file association | Partial | Separately enabled deterministic automatic association rules, scope-wide rule revocation and mass-association undo remain open. Matches reuse recorded associations and never prove ownership or semantic avatar identity. |
| ARC-22 | Opt-in resumable authorized transfers | Partial | Other asset owners, supplied-key/decrypted resumable streams, real-origin range support and native Windows filesystem acceptance remain. Unsupported validators require a new reviewed complete download; modified or uncertain partials remain for inspection. |
| ARC-23 | Explicit bounded transient retry policy | Partial | Qualification of actual provider rate-limit/redirect behavior and broader nontransfer task policies remain. External extraction, imports and repairs are never automatically replayed. |
| ARC-24 | Durable job and publication crash reconciliation | Partial | OS-proven external-process containment, atomic cross-owner catalog publication and native power-loss/filesystem qualification remain incomplete. Releasing a stale reservation does not reconcile or replay uncertain file operations. |

## Acceptance/provider prerequisites and source-data limits

| ID | Feature | State | Remaining evidence or constraint |
|---|---|---|---|
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite | Native window, idle-event and Windows/Linux protected-vault acceptance remain. The lock is a UI privacy boundary, not disk encryption. |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite | Provider availability/access/terms and live metadata/image results need acceptance; no VRCX-only entitlement is assumed. |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation | Source groups absent from the selected database cannot be reconstructed. |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation | The source has no file fingerprint, so historical byte identity cannot be proven. No implicit path scans or roster matching. |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite | Installed protocol registration/focus/delivery requires native OS acceptance. |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite | The full prepared acceptance matrix, native Windows and release gates remain open. |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite | Native Discord application registration and Windows/Linux IPC acceptance remain required. |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite | Native launch/cleanup acceptance remains. No process-name killing, force-kill fallback or application-readiness claim. |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite | Installed zero-VRCX and coexistence acceptance remains; all parity gaps remain visible in this ledger. |

## Complete disposition ledger

The JSON companion retains implementation evidence and remaining details.

| ID | Feature | Disposition |
|---|---|---|
| VX-NATIVE-01 | One normalized event timeline and inbox state | Source implemented; native/live acceptance open |
| VX-NATIVE-02 | Account storage isolation and safe legacy migration | Source implemented; native/live acceptance open |
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | Acceptance / provider prerequisite |
| VX-NATIVE-04 | Resilient friend live feed with bounded reconciliation | Source implemented; native/live acceptance open |
| VX-NATIVE-05 | Unified notifications including NotificationV2 | Source implemented; native/live acceptance open |
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | Partial |
| VX-NATIVE-07 | Complete invitation responses | Source implemented; native/live acceptance open |
| VX-NATIVE-08 | Edit saved invitation messages | Source implemented; native/live acceptance open |
| VX-NATIVE-09 | Photo invitations and replies | Source implemented; native/live acceptance open |
| VX-NATIVE-10 | Complete own-profile editor | Source implemented; native/live acceptance open |
| VX-NATIVE-11 | Shared bounded image upload transport | Source implemented; native/live acceptance open |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | Partial |
| VX-NATIVE-13 | Everyday owned-world editor and publication | Source implemented; native/live acceptance open |
| VX-NATIVE-14 | Group details, membership and permission-aware navigation | Source implemented; native/live acceptance open |
| VX-NATIVE-15 | Group moderation and reviewed batch operations | Source implemented; native/live acceptance open |
| VX-NATIVE-16 | Group role management | Source implemented; native/live acceptance open |
| VX-NATIVE-17 | Group posts, announcements and gallery access | Partial |
| VX-NATIVE-18 | Group calendars and event management | Source implemented; native/live acceptance open |
| VX-NATIVE-19 | Group creation, settings and ownership lifecycle | Source implemented; native/live acceptance open |
| VX-NATIVE-20 | Instant local entity search | Source implemented; native/live acceptance open |
| VX-NATIVE-21 | Manage VRChat favorite groups within service limits | Source implemented; native/live acceptance open |
| VX-NATIVE-22 | Complete native local collections and exports | Source implemented; native/live acceptance open |
| VX-NATIVE-23 | Group instances and explicit visit handoff | Source implemented; native/live acceptance open |
| VX-NATIVE-24 | VRChat gallery and account icon management | Source implemented; native/live acceptance open |
| VX-NATIVE-25 | Sticker and emoji management | Source implemented; native/live acceptance open |
| VX-NATIVE-26 | VRChat print browsing and publishing | Source implemented; native/live acceptance open |
| VX-NATIVE-27 | Inventory and cosmetic catalog browser | Source implemented; native/live acceptance open |
| VX-NATIVE-28 | Inventory consume, reward and supported equipment actions | Source implemented; native/live acceptance open |
| VX-NATIVE-29 | Optional avatar metadata search providers | Acceptance / provider prerequisite |
| VX-MIG-01 | Versioned source contract inventory | Partial |
| VX-MIG-02 | Consistent read-only SQLite and WAL acquisition | Source implemented; native/live acceptance open |
| VX-MIG-03 | Explicit source-account and destination-scope mapping | Source implemented; native/live acceptance open |
| VX-MIG-04 | Native entity, collections and annotation data model | Source implemented; native/live acceptance open |
| VX-MIG-05 | Provenance, immutable review and migration ledger | Source implemented; native/live acceptance open |
| VX-MIG-06 | Deterministic deduplication and field-level conflicts | Source implemented; native/live acceptance open |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | Partial |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | Partial |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | Source-data limitation |
| VX-MIG-10 | Unify imported and existing native Favorites | Source implemented; native/live acceptance open |
| VX-MIG-11 | Bulk avatar observations integrated with AvatarLibrary | Source implemented; native/live acceptance open |
| VX-MIG-12 | World and user descriptive observations | Source implemented; native/live acceptance open |
| VX-MIG-13 | Local avatar tags with native editing and filtering | Source implemented; native/live acceptance open |
| VX-MIG-14 | User, world and avatar memos plus account notes | Partial |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | Partial |
| VX-MIG-16 | Selected VRCX status preset import | Source implemented; native/live acceptance open |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | Partial |
| VX-MIG-18 | Avatar-use aggregate history | Source implemented; native/live acceptance open |
| VX-MIG-19 | World visits, join/leave and portal event history | Source implemented; native/live acceptance open |
| VX-MIG-20 | Video, resource and auxiliary game-log history | Partial |
| VX-MIG-21 | Friend changes and social observation feeds | Source implemented; native/live acceptance open |
| VX-MIG-22 | Derived activity sessions and analytics provenance | Source implemented; native/live acceptance open |
| VX-MIG-23 | Notification archives and invite message details | Partial |
| VX-MIG-24 | Moderation observations and mutual graph snapshots | Source implemented; native/live acceptance open |
| VX-MIG-25 | Print favorite references and conditional print metadata | Partial |
| VX-MIG-26 | Photo index migration with verified file relinking | Source-data limitation |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | Partial |
| VX-MIG-28 | Saved searches, filters and portable views | Partial |
| VX-MIG-29 | Native selective backup and complete restore | Partial |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | Partial |
| VX-MIG-31 | Selective migration workspace and standalone native routes | Source implemented; native/live acceptance open |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | Acceptance / provider prerequisite |
| VX-MIG-33 | Future acceptance matrix and migration release gates | Acceptance / provider prerequisite |
| VX-DESK-01 | Shared dashboard projections | Partial |
| VX-DESK-02 | Configurable dashboards and widget layouts | Partial |
| VX-DESK-03 | Unified notification delivery and focus rules | Source implemented; native/live acceptance open |
| VX-DESK-04 | Activity charts, heatmaps and history analysis | Source implemented; native/live acceptance open |
| VX-DESK-05 | Native Discord presence provider | Acceptance / provider prerequisite |
| VX-DESK-06 | Discord content, join controls and coexistence | Partial |
| VX-DESK-07 | Configured application launch automation | Acceptance / provider prerequisite |
| VX-DESK-08 | Opt-in crash recovery controller | Partial |
| VX-DESK-09 | Reviewed join and last-instance recovery orchestration | Source implemented; native/live acceptance open |
| VX-DESK-10 | Automatic photo context association | Source implemented; native/live acceptance open |
| VX-DESK-11 | Optional compatible photo metadata output | Source implemented; native/live acceptance open |
| VX-DESK-12 | Photo organization, source moves and recovery | Source implemented; native/live acceptance open |
| VX-DESK-13 | Photo metadata index and richer gallery search | Source implemented; native/live acceptance open |
| VX-DESK-14 | VRChat service-health integration | Source implemented; native/live acceptance open |
| VX-DESK-15 | Tray/background and low-power operation | Partial |
| VX-DESK-16 | Settings profiles, backup and rollback UX | Partial |
| VX-DESK-17 | Optional update channels and recoverable installation | Partial |
| VX-DESK-18 | Optional media-link enrichment and translation providers | Partial |
| VX-DESK-19 | Reviewed VRChat configuration and launch settings editor | Source implemented; native/live acceptance open |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | Acceptance / provider prerequisite |
| ARC-01 | Isolated avatar provider contract and lifecycle | Partial |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | Missing |
| ARC-03 | Authorized FBX import and scene inspection | Missing |
| ARC-04 | Actual material and texture viewer | Missing |
| ARC-05 | Rig, skinning and blendshape viewer | Missing |
| ARC-06 | Clip, take and safe controller animation preview | Missing |
| ARC-07 | AssetRipper provider selection, version and provenance | Partial |
| ARC-08 | Integrated user-owned recovery orchestration | Partial |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | Partial |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | Missing |
| ARC-11 | Reviewed mesh and importer setting transfer | Missing |
| ARC-12 | Conservative rig and skinned-mesh optimization | Missing |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | Partial |
| ARC-14 | Shader and material compatibility diagnostics | Partial |
| ARC-15 | Typed material property mapping on copies | Partial |
| ARC-16 | Reviewed shader package install and removal | Partial |
| ARC-17 | Animation and controller dependency repair copies | Partial |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | Partial |
| ARC-19 | General repair-copy journal and conditional rollback | Partial |
| ARC-20 | Scoped automated catalog metadata backfill | Source implemented; native/live acceptance open |
| ARC-21 | Evidence-based automated local-file association | Partial |
| ARC-22 | Opt-in resumable authorized transfers | Partial |
| ARC-23 | Explicit bounded transient retry policy | Partial |
| ARC-24 | Durable job and publication crash reconciliation | Partial |
