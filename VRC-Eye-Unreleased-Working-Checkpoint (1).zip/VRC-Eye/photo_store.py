"""Scoped local photo catalog on the existing CompanionStore database.

Logical photos and physical references are separate. Byte equality never merges
accounts or photos. Session references reuse PlayerHistory and carry no roster or
world snapshot; removed/private session history is never reconstructed here.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sqlite3
import uuid

from avatar_library import scope_id
from companion_data import CompanionStore, entity_id
from creator_projects import assert_no_links, local_path
from photo_files import directory_identity, MAX_BYTES, MAX_PIXELS, normalize_recipe

MAX_SOURCES = 64
MAX_PHOTOS = 20000
MAX_ALBUMS = 256
MAX_JOBS = 2000
THUMB_BUDGET = 32 * 1024 * 1024
STATES = ('Available', 'Missing', 'Changed', 'Unreadable', 'Replaced')


def stamp(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def uid(): return str(uuid.uuid4())


def text(value, limit=512):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError('Photo text is invalid or exceeds its length limit.')
    try: value.encode('utf-8')
    except UnicodeError as error: raise ValueError('Photo text must be valid Unicode.') from error
    return value.strip()


def key(path): return os.path.normcase(str(local_path(path)))


def json_data(value, limit=262144):
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False)
    if len(raw.encode('utf-8')) > limit: raise ValueError('Photo record exceeds its metadata budget.')
    return raw


def date_filter(value):
    if not value: return ''
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        raise ValueError('Use dates in YYYY-MM-DD format.')
    try: datetime.fromisoformat(value)
    except ValueError as error: raise ValueError('Choose a valid date.') from error
    return value


def filters(value):
    allowed = {'query', 'favorite', 'after', 'before', 'world', 'status','author','participant','session_day'}
    if not isinstance(value, dict) or set(value) - allowed: raise ValueError('Unsupported saved photo filters.')
    result = {'query': text(value.get('query', ''), 256), 'favorite': value.get('favorite', False),
              'after': date_filter(value.get('after', '')), 'before': date_filter(value.get('before', '')),
              'world': value.get('world', ''), 'status': value.get('status', 'All')}
    if type(result['favorite']) is not bool or result['status'] not in ('All', *STATES): raise ValueError('Invalid photo filter.')
    if result['world']: result['world'] = entity_id('world', result['world'])
    for key in ('author','participant'):
        if value.get(key):result[key]=entity_id('user',value[key])
    if result['before'] and result['after'] and result['before'] < result['after']: raise ValueError('The end date must not precede the start date.')
    if value.get('session_day'):result['session_day']=date_filter(value['session_day'])
    return result


class PhotoStore:
    def __init__(self, companion):
        self.companion = companion if isinstance(companion, CompanionStore) else CompanionStore(companion)
        self.run = uid()

    @contextmanager
    def connect(self):
        with self.companion.connect() as db:
            db.row_factory = sqlite3.Row
            db.create_function("photo_casefold",1,lambda value:str(value).casefold(),deterministic=True)
            db.execute('''CREATE TABLE IF NOT EXISTS photo_sources_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,path TEXT NOT NULL,path_key TEXT NOT NULL,
                label TEXT NOT NULL,recursive INTEGER NOT NULL,identity TEXT NOT NULL,
                state TEXT NOT NULL,checked TEXT NOT NULL,UNIQUE(scope,path_key))''')
            db.execute('CREATE TABLE IF NOT EXISTS photo_context_v1(scope TEXT,photo TEXT,digest TEXT,data TEXT,PRIMARY KEY(scope,photo))')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_items_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,title TEXT NOT NULL,notes TEXT NOT NULL,
                favorite INTEGER NOT NULL DEFAULT 0,hidden INTEGER NOT NULL DEFAULT 0,
                world_id TEXT NOT NULL DEFAULT '',session_id TEXT NOT NULL DEFAULT '',
                created TEXT NOT NULL,updated TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_files_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,photo_id TEXT NOT NULL,source_id TEXT NOT NULL,
                path TEXT NOT NULL,path_key TEXT,digest TEXT NOT NULL,evidence TEXT NOT NULL,
                meta TEXT NOT NULL,thumbnail BLOB,status TEXT NOT NULL,checked TEXT NOT NULL,
                date_value TEXT NOT NULL,UNIQUE(scope,path_key))''')
            db.execute('''CREATE INDEX IF NOT EXISTS photo_files_v4_photos ON photo_files_v4(scope,photo_id)''')
            db.execute('''CREATE INDEX IF NOT EXISTS photo_files_v4_hash ON photo_files_v4(scope,digest)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_albums_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,name TEXT NOT NULL,query TEXT NOT NULL,
                cover TEXT NOT NULL DEFAULT '',updated TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_members_v4(
                scope TEXT NOT NULL,album TEXT NOT NULL,photo TEXT NOT NULL,PRIMARY KEY(scope,album,photo))''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_covers_v4(
                scope TEXT NOT NULL,session TEXT NOT NULL,photo TEXT NOT NULL,PRIMARY KEY(scope,session))''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_jobs_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,run TEXT NOT NULL,operation TEXT NOT NULL,
                state TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,detail TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_exports_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,photo TEXT NOT NULL,path TEXT NOT NULL,
                source_digest TEXT NOT NULL,output_digest TEXT NOT NULL,recipe TEXT NOT NULL,created TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_export_intents_v4(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,photo TEXT NOT NULL,path TEXT NOT NULL,
                digest TEXT NOT NULL,state TEXT NOT NULL,created TEXT NOT NULL,detail TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_watches_v6(
                source TEXT PRIMARY KEY,scope TEXT NOT NULL,enabled INTEGER NOT NULL,
                interval INTEGER NOT NULL,revision TEXT NOT NULL,run TEXT NOT NULL,
                state TEXT NOT NULL,checked TEXT NOT NULL,detail TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS photo_sheets_v6(
                id TEXT PRIMARY KEY,scope TEXT NOT NULL,name TEXT NOT NULL,
                slots TEXT NOT NULL,layout TEXT NOT NULL,updated TEXT NOT NULL)''')
            yield db

    def sources(self, scope):
        with self.connect() as db:
            rows = [dict(r) for r in db.execute('SELECT * FROM photo_sources_v4 WHERE scope=? ORDER BY label,id', (scope_id(scope),))]
        for row in rows: row['identity'] = json.loads(row['identity']); row['recursive'] = bool(row['recursive'])
        return rows

    def source(self, scope, identity):
        return next((r for r in self.sources(scope) if r['id'] == identity), None)

    def add_source(self, scope, path, label='', recursive=False):
        scope = scope_id(scope); path = assert_no_links(local_path(path)); label = text(label or path.name, 100)
        if type(recursive) is not bool: raise ValueError('Recursive scanning must be explicitly selected.')
        ident = directory_identity(path); pkey = key(path)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows = list(db.execute('SELECT id,path,path_key,recursive FROM photo_sources_v4 WHERE scope=?', (scope,)))
            old = next((r for r in rows if r['path_key'] == pkey), None)
            if not old and len(rows) >= MAX_SOURCES: raise ValueError('A workspace supports at most 64 photo sources.')
            for r in rows:
                other = local_path(r['path'])
                if r is not old and ((recursive and other.is_relative_to(path)) or (r['recursive'] and path.is_relative_to(other))):
                    raise ValueError('This source overlaps another recursive source. Keep one scan owner per folder.')
            identity = old['id'] if old else uid()
            db.execute('INSERT OR REPLACE INTO photo_sources_v4 VALUES(?,?,?,?,?,?,?,?,?)',
                       (identity,scope,str(path),pkey,label,int(recursive),json_data(ident),'Approved; not scanned',stamp()))
            # Reapproval changes the folder contract and revokes the old watch grant.
            db.execute('DELETE FROM photo_watches_v6 WHERE scope=? AND source=?',(scope,identity))
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='photo_compatible_rules'").fetchone():
                db.execute('DELETE FROM photo_compatible_rules WHERE scope=? AND source=?',(scope,identity))
        return self.source(scope, identity)

    def source_state(self, scope, identity, state):
        with self.connect() as db:
            db.execute('UPDATE photo_sources_v4 SET state=?,checked=? WHERE scope=? AND id=?', (text(state,200),stamp(),scope_id(scope),identity))

    def forget_source(self, scope, identity):
        with self.connect() as db:
            db.execute('UPDATE photo_files_v4 SET source_id=\'\' WHERE scope=? AND source_id=?', (scope_id(scope),identity))
            db.execute('DELETE FROM photo_sources_v4 WHERE scope=? AND id=?', (scope_id(scope),identity))
            db.execute('DELETE FROM photo_watches_v6 WHERE scope=? AND source=?', (scope_id(scope),identity))
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='photo_compatible_rules'").fetchone():
                db.execute('DELETE FROM photo_compatible_rules WHERE scope=? AND source=?',(scope_id(scope),identity))

    def watches(self, scope):
        with self.connect() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM photo_watches_v6 WHERE scope=? ORDER BY source',(scope_id(scope),))]
        for row in rows:
            row['enabled']=bool(row['enabled'])
            if row['run']!=self.run and row['state']=='Checking':
                row['state']='Interrupted; reconciliation pending'
        return rows

    def watch(self, scope, source):
        return next((r for r in self.watches(scope) if r['source']==source),None)

    def configure_watch(self, scope, source, *, enabled, interval=30):
        if type(enabled) is not bool or type(interval) is not int or interval not in (10,30,60,300):
            raise ValueError('Choose a watch interval of 10, 30, 60 or 300 seconds.')
        scope=scope_id(scope)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if not db.execute('SELECT 1 FROM photo_sources_v4 WHERE scope=? AND id=?',(scope,source)).fetchone():
                raise ValueError('The source is no longer approved.')
            if enabled and db.execute('SELECT COUNT(*) FROM photo_watches_v6 WHERE scope=? AND enabled=1 AND source!=?',(scope,source)).fetchone()[0]>=8:
                raise ValueError('At most eight sources can be watched in one workspace. Pause another source first.')
            db.execute('INSERT OR REPLACE INTO photo_watches_v6 VALUES(?,?,?,?,?,?,?,?,?)',
                       (source,scope,int(enabled),interval,uid(),self.run,'Waiting' if enabled else 'Paused',stamp(),
                        'Enabled explicitly; existing and new stable images will be indexed.' if enabled else 'Paused until explicitly resumed.'))
        return self.watch(scope,source)

    def watch_status(self, scope, source, revision, state, detail):
        with self.connect() as db:
            db.execute('UPDATE photo_watches_v6 SET run=?,state=?,checked=?,detail=? WHERE scope=? AND source=? AND revision=?',
                       (self.run,text(state,100),stamp(),text(detail,1000),scope_id(scope),source,revision))

    def watch_block(self, scope, source, revision):
        with self.connect() as db:
            db.execute("UPDATE photo_watches_v6 SET enabled=0,state='Reapproval required' WHERE scope=? AND source=? AND revision=?",
                       (scope_id(scope),source,revision))

    def file_evidence(self, scope):
        """Cheap stat inventory for a bounded watch pass, without images or notes."""
        with self.connect() as db:
            return {r['path_key']:{'id':r['photo_id'],'status':r['status'],'source_id':r['source_id'],
                    'fingerprint':json.loads(r['evidence'])['fingerprint']}
                    for r in db.execute('SELECT photo_id,path_key,status,evidence,source_id FROM photo_files_v4 WHERE scope=? AND path_key IS NOT NULL',(scope_id(scope),))}

    def observe(self, scope, observation, *, source_id=''):
        scope = scope_id(scope); path = local_path(observation['path']); now = stamp()
        digest = observation['sha256']; fp = observation['fingerprint']; meta = observation['metadata']
        if not re.fullmatch(r'[a-f0-9]{64}', digest): raise ValueError('Invalid photo digest.')
        if not 0 < observation['size'] <= MAX_BYTES or not 0 < observation['width'] * observation['height'] <= MAX_PIXELS:
            raise ValueError('Invalid image evidence.')
        thumbnail = observation['thumbnail']
        if not isinstance(thumbnail, bytes) or len(thumbnail) > 256 * 1024: raise ValueError('Invalid bounded thumbnail.')
        evidence = {'fingerprint': fp, 'size': observation['size'], 'width': observation['width'],
                    'height': observation['height'], 'format': observation['format']}
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if source_id:
                src = db.execute('SELECT * FROM photo_sources_v4 WHERE scope=? AND id=?',(scope,source_id)).fetchone()
                if not src or not path.is_relative_to(local_path(src['path'])): raise ValueError('Photo is outside the approved source.')
            previous = db.execute('SELECT * FROM photo_files_v4 WHERE scope=? AND path_key=?',(scope,key(path))).fetchone()
            if previous and previous['digest'] == digest:
                db.execute('UPDATE photo_files_v4 SET evidence=?,meta=?,thumbnail=?,status=\'Available\',checked=?,source_id=? WHERE id=?',
                           (json_data(evidence),json_data(meta),thumbnail,now,source_id or previous['source_id'],previous['id']))
                self._prune_thumbnails(db,scope)
                return previous['photo_id'], 'Unchanged'
            if db.execute('SELECT COUNT(*) FROM photo_items_v4 WHERE scope=?',(scope,)).fetchone()[0] >= MAX_PHOTOS:
                raise ValueError('The 20,000-photo workspace limit was reached. No old records were removed.')
            if previous:
                # Different bytes at the same path get a new photo, never inherit
                # an earlier favorite, world/session link or privacy review.
                db.execute('UPDATE photo_files_v4 SET path_key=NULL,status=\'Replaced\',thumbnail=NULL WHERE id=?',(previous['id'],))
            photo_id = uid(); file_id = uid()
            db.execute('INSERT INTO photo_items_v4 VALUES(?,?,?,?,0,0,\'\',\'\',?,?)',
                       (photo_id,scope,text(observation['name'],512),'',now,now))
            db.execute('INSERT INTO photo_files_v4 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                       (file_id,scope,photo_id,source_id,str(path),key(path),digest,json_data(evidence),json_data(meta),thumbnail,'Available',now,meta.get('date','')))
            self._prune_thumbnails(db,scope)
        return photo_id, 'New version' if previous else 'Imported'

    @staticmethod
    def _prune_thumbnails(db,scope):
        total = db.execute('SELECT COALESCE(SUM(length(thumbnail)),0) FROM photo_files_v4 WHERE scope=?',(scope,)).fetchone()[0]
        if total <= THUMB_BUDGET: return
        for identity,size in db.execute('SELECT id,length(thumbnail) FROM photo_files_v4 WHERE scope=? AND thumbnail IS NOT NULL ORDER BY checked,id',(scope,)).fetchall():
            db.execute('UPDATE photo_files_v4 SET thumbnail=NULL WHERE id=?',(identity,)); total -= size
            if total <= THUMB_BUDGET: break

    def clear_thumbnails(self,scope):
        with self.connect() as db:
            return db.execute('UPDATE photo_files_v4 SET thumbnail=NULL WHERE scope=?',(scope_id(scope),)).rowcount

    @staticmethod
    def _row(row):
        if not row: return None
        row = dict(row); evidence = json.loads(row.pop('evidence'))
        row.update(evidence); row['metadata'] = json.loads(row.pop('meta'))
        row['sha256'] = row.pop('digest'); row['favorite'] = bool(row['favorite']); row['hidden'] = bool(row['hidden'])
        return row

    def get(self,scope,photo):
        with self.connect() as db:
            row = db.execute('''SELECT p.*, f.id AS file_id,f.source_id,f.path,f.digest,f.evidence,f.meta,
                     f.thumbnail,f.status,f.checked,f.date_value FROM photo_items_v4 p JOIN photo_files_v4 f
                     ON f.photo_id=p.id AND f.scope=p.scope WHERE p.scope=? AND p.id=?''',(scope_id(scope),photo)).fetchone()
        return self._row(row)

    def by_path(self,scope,path):
        with self.connect() as db:
            row=db.execute('SELECT photo_id FROM photo_files_v4 WHERE scope=? AND path_key=?',(scope_id(scope),key(path))).fetchone()
        return self.get(scope,row[0]) if row else None

    def list(self,scope,*,query=None,source='',album='',session='',hidden=False,offset=0,limit=48):
        scope = scope_id(scope); query = filters(query or {})
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError('Invalid photo page.')
        if type(hidden) is not bool: raise ValueError('Invalid hidden-photo filter.')
        where = ['p.scope=?','p.hidden=?']; args = [scope,int(hidden)]
        if source: where.append('f.source_id=?'); args.append(source)
        if session: where.append('p.session_id=?'); args.append(session)
        if album:
            a = self.album(scope,album)
            if not a: raise ValueError('Select an album in this workspace.')
            if a['query']:
                saved = filters(a['query'])
                # Smart album matches AND explicit visible filters (not overwrite).
                self._query_sql(where,args,saved)
            else:
                where.append('p.id IN (SELECT photo FROM photo_members_v4 WHERE scope=? AND album=?)'); args.extend((scope,album))
        self._query_sql(where,args,query)
        clause = ' AND '.join(where)
        join = ' FROM photo_items_v4 p JOIN photo_files_v4 f ON f.photo_id=p.id AND f.scope=p.scope WHERE '+clause
        with self.connect() as db:
            from photo_session_day import load,group
            policy=load(self.companion,scope)
            if 'photo_session_day(' in clause and not policy['enabled']:raise ValueError('Enable session-day grouping before filtering by it.')
            db.create_function('photo_session_day',1,lambda value:group(value,policy)['day'],deterministic=True)
            total = db.execute('SELECT COUNT(*)'+join,args).fetchone()[0]
            rows = db.execute('''SELECT p.*,f.id AS file_id,f.source_id,f.path,f.digest,f.evidence,f.meta,
                      f.thumbnail,f.status,f.checked,f.date_value'''+join+' ORDER BY f.date_value DESC,p.id LIMIT ? OFFSET ?',(*args,limit,offset)).fetchall()
        return {'items':[self._row(r) for r in rows], 'total':total, 'more':offset+len(rows)<total}

    @staticmethod
    def _query_sql(where,args,q):
        if q.get('session_day'):where.append('photo_session_day(f.date_value)=?');args.append(q['session_day'])
        if q['query']:
            where.append("instr(photo_casefold(p.title||' '||p.notes||' '||p.world_id||' '||COALESCE((SELECT data FROM photo_context_v1 c WHERE c.scope=p.scope AND c.photo=p.id AND c.digest=f.digest),'')),photo_casefold(?))>0")
            args.append(q['query'])
        if q['favorite']: where.append('p.favorite=1')
        if q['after']: where.append('substr(f.date_value,1,10)>=?'); args.append(q['after'])
        if q['before']: where.append('substr(f.date_value,1,10)<=?'); args.append(q['before'])
        if q['world']: where.append('p.world_id=?'); args.append(q['world'])
        if q['status']!='All': where.append('f.status=?'); args.append(q['status'])
        for key,field in (('author','author_ids'),('participant','participant_ids')):
            if q.get(key):
                where.append("EXISTS(SELECT 1 FROM photo_context_v1 c,json_each(c.data,'$."+field+"') j WHERE c.scope=p.scope AND c.photo=p.id AND c.digest=f.digest AND j.value=?)")
                args.append(q[key])

    def edit(self,scope,photo,**values):
        allowed={'title','notes','favorite','hidden','world_id','session_id'}
        if not values or set(values)-allowed: raise ValueError('Unsupported photo edit.')
        for k in ('favorite','hidden'):
            if k in values and type(values[k]) is not bool: raise ValueError('Photo flags must be true or false.')
        for k,limit in (('title',512),('notes',4000),('session_id',128)):
            if k in values: values[k]=text(values[k],limit)
        if 'world_id' in values and values['world_id']: values['world_id']=entity_id('world',values['world_id'])
        values['updated']=stamp()
        with self.connect() as db:
            result=db.execute('UPDATE photo_items_v4 SET '+','.join(k+'=?' for k in values)+' WHERE scope=? AND id=?',(*values.values(),scope_id(scope),photo))
            if result.rowcount!=1: raise ValueError('Photo no longer belongs to this workspace.')

    def availability(self,scope,photo,state):
        if state not in STATES: raise ValueError('Unsupported photo availability.')
        with self.connect() as db:
            db.execute('UPDATE photo_files_v4 SET status=?,checked=?,thumbnail=CASE WHEN ?=\'Available\' THEN thumbnail ELSE NULL END WHERE scope=? AND photo_id=?',
                       (state,stamp(),state,scope_id(scope),photo))

    def associate_source(self,scope,photo,source):
        row=self.get(scope,photo);src=self.source(scope,source)
        if not row or not src or not local_path(row['path']).is_relative_to(local_path(src['path'])):
            raise ValueError('The photo and approved source must belong to this workspace and location.')
        with self.connect() as db:
            db.execute('UPDATE photo_files_v4 SET source_id=? WHERE scope=? AND photo_id=?',
                       (source,scope_id(scope),photo))

    def missing_after_scan(self,scope,source,seen):
        """Only the caller's completed, unchanged-root scan may invoke this."""
        seen = {key(p) for p in seen}
        with self.connect() as db:
            rows=list(db.execute('SELECT id,path_key FROM photo_files_v4 WHERE scope=? AND source_id=? AND path_key IS NOT NULL',(scope_id(scope),source)))
            for row in rows:
                if row['path_key'] not in seen:
                    db.execute('UPDATE photo_files_v4 SET status=\'Missing\',checked=?,thumbnail=NULL WHERE id=?',(stamp(),row['id']))

    def relink(self,scope,photo,observation):
        old=self.get(scope,photo)
        if not old or old['sha256']!=observation['sha256']: raise ValueError('Relink requires the same photo bytes. Import different bytes as a separate photo.')
        path=local_path(observation['path'])
        evidence={k:observation[k] for k in ('fingerprint','size','width','height','format')}
        with self.connect() as db:
            clash=db.execute('SELECT photo_id FROM photo_files_v4 WHERE scope=? AND path_key=?',(scope_id(scope),key(path))).fetchone()
            if clash and clash[0]!=photo: raise ValueError('That file is already a separate photo in this workspace; no records were merged.')
            db.execute('UPDATE photo_files_v4 SET path=?,path_key=?,source_id=\'\',evidence=?,thumbnail=?,status=\'Available\',checked=? WHERE scope=? AND photo_id=?',
                       (str(path),key(path),json_data(evidence),observation['thumbnail'],stamp(),scope_id(scope),photo))
            self._prune_thumbnails(db,scope_id(scope))
        return self.get(scope,photo)

    def duplicates(self,scope):
        with self.connect() as db:
            return [dict(r) for r in db.execute('''SELECT f.digest AS sha256,COUNT(*) AS count FROM photo_files_v4 f JOIN photo_items_v4 p
                  ON p.id=f.photo_id AND p.scope=f.scope WHERE f.scope=? AND p.hidden=0 AND f.status!='Replaced'
                  GROUP BY f.digest HAVING COUNT(*)>1 ORDER BY COUNT(*) DESC LIMIT 100''',(scope_id(scope),))]

    def albums(self,scope):
        with self.connect() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM photo_albums_v4 WHERE scope=? ORDER BY name,id',(scope_id(scope),))]
        for r in rows:r['query']=json.loads(r['query']) if r['query'] else None
        return rows

    def album(self,scope,identity): return next((r for r in self.albums(scope) if r['id']==identity),None)

    def add_album(self,scope,name,*,query=None):
        name=text(name,100); scope=scope_id(scope)
        if not name: raise ValueError('An album needs a name.')
        q=json_data(filters(query)) if query is not None else ''; identity=uid()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT COUNT(*) FROM photo_albums_v4 WHERE scope=?',(scope,)).fetchone()[0]>=MAX_ALBUMS:
                raise ValueError('The 256-album workspace limit was reached.')
            db.execute('INSERT INTO photo_albums_v4 VALUES(?,?,?,?,\'\',?)',(identity,scope,name,q,stamp()))
        return self.album(scope,identity)

    def album_member(self,scope,album,photo,*,add=True):
        a=self.album(scope,album); p=self.get(scope,photo)
        if not a or not p: raise ValueError('Select a photo and album from this workspace.')
        if a['query']: raise ValueError('Smart album membership follows its saved filters; use a manual album for explicit membership.')
        with self.connect() as db:
            if add: db.execute('INSERT OR IGNORE INTO photo_members_v4 VALUES(?,?,?)',(scope_id(scope),album,photo))
            else:
                db.execute('DELETE FROM photo_members_v4 WHERE scope=? AND album=? AND photo=?',(scope_id(scope),album,photo))
                db.execute('UPDATE photo_albums_v4 SET cover=\'\' WHERE scope=? AND id=? AND cover=?',(scope_id(scope),album,photo))

    def delete_album(self,scope,album):
        with self.connect() as db:
            db.execute('DELETE FROM photo_members_v4 WHERE scope=? AND album=?',(scope_id(scope),album))
            db.execute('DELETE FROM photo_albums_v4 WHERE scope=? AND id=?',(scope_id(scope),album))

    def set_cover(self,scope,photo,*,album='',session=''):
        row=self.get(scope,photo)
        if not row or row['hidden'] or row['status']!='Available': raise ValueError('Choose a visible, available photo for the cover.')
        if bool(album)==bool(session): raise ValueError('Choose exactly one cover destination.')
        with self.connect() as db:
            if album:
                a=self.album(scope,album)
                if not a or a['query']: raise ValueError('Choose a manual album.')
                if not db.execute('SELECT 1 FROM photo_members_v4 WHERE scope=? AND album=? AND photo=?',(scope_id(scope),album,photo)).fetchone():
                    raise ValueError('Add the photo to this album before selecting its cover.')
                db.execute('UPDATE photo_albums_v4 SET cover=?,updated=? WHERE scope=? AND id=?',(photo,stamp(),scope_id(scope),album))
            else:
                if row['session_id']!=session: raise ValueError('Link the photo to this retained session first.')
                db.execute('INSERT OR REPLACE INTO photo_covers_v4 VALUES(?,?,?)',(scope_id(scope),text(session,128),photo))

    def session_cover(self,scope,session):
        with self.connect() as db: row=db.execute('SELECT photo FROM photo_covers_v4 WHERE scope=? AND session=?',(scope_id(scope),session)).fetchone()
        photo=self.get(scope,row[0]) if row else None
        return photo if photo and not photo['hidden'] and photo['status']=='Available' and photo['session_id']==session else None

    def begin_job(self,scope,operation):
        scope=scope_id(scope); identity=uid(); now=stamp()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT COUNT(*) FROM photo_jobs_v4 WHERE scope=?',(scope,)).fetchone()[0]>=MAX_JOBS:
                raise ValueError('Photo activity is full. Explicitly clear completed history first.')
            db.execute('INSERT INTO photo_jobs_v4 VALUES(?,?,?,?,?,?,?,?)',(identity,scope,self.run,text(operation,80),'Running',now,now,''))
        return identity

    def finish_job(self,scope,identity,state,detail):
        if state not in ('Complete','Partial','Cancelled','Failed'): raise ValueError('Unsupported photo job state.')
        with self.connect() as db:
            db.execute('UPDATE photo_jobs_v4 SET state=?,detail=?,updated=? WHERE scope=? AND id=?',(state,text(detail,1000),stamp(),scope_id(scope),identity))

    def jobs(self,scope):
        with self.connect() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM photo_jobs_v4 WHERE scope=? ORDER BY created DESC,rowid DESC LIMIT 100',(scope_id(scope),))]
        for r in rows:
            if r['run']!=self.run and r['state']=='Running':r['state']='Interrupted / inspect outcome'
        return rows

    def clear_jobs(self,scope):
        with self.connect() as db: return db.execute('DELETE FROM photo_jobs_v4 WHERE scope=? AND state!=\'Running\'',(scope_id(scope),)).rowcount

    def begin_export(self,scope,photo,path,digest):
        identity=uid()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT COUNT(*) FROM photo_export_intents_v4 WHERE scope=?',(scope_id(scope),)).fetchone()[0]>=MAX_JOBS:
                raise ValueError('Export recovery history is full. Review and clear completed export records first.')
            if db.execute('SELECT COUNT(*) FROM photo_exports_v4 WHERE scope=?',(scope_id(scope),)).fetchone()[0]>=MAX_PHOTOS:
                raise ValueError('The 20,000-export inventory limit was reached; no file was written.')
            db.execute('INSERT INTO photo_export_intents_v4 VALUES(?,?,?,?,?,?,?,?)',
                       (identity,scope_id(scope),photo,str(local_path(path)),digest,'Inspect destination',stamp(),
                        'Destination recorded before publication. An interrupted operation is never repeated automatically.'))
        return identity

    def finish_export(self,scope,identity,state,detail):
        if state not in ('Saved','Inspect destination','Acknowledged'):raise ValueError('Unsupported export recovery state.')
        with self.connect() as db:
            db.execute('UPDATE photo_export_intents_v4 SET state=?,detail=? WHERE scope=? AND id=?',
                       (state,text(detail,1000),scope_id(scope),identity))

    def export_intents(self,scope):
        with self.connect() as db:
            return [dict(r) for r in db.execute('SELECT * FROM photo_export_intents_v4 WHERE scope=? ORDER BY created DESC,rowid DESC LIMIT 100',(scope_id(scope),))]

    def clear_export_intents(self,scope):
        with self.connect() as db:
            return db.execute("DELETE FROM photo_export_intents_v4 WHERE scope=? AND state IN ('Saved','Acknowledged')",(scope_id(scope),)).rowcount

    def acknowledge_job(self,scope,identity):
        with self.connect() as db:
            row=db.execute('SELECT run,state FROM photo_jobs_v4 WHERE scope=? AND id=?',(scope_id(scope),identity)).fetchone()
            if not row or row['run']==self.run or row['state']!='Running':raise ValueError('Only interrupted older-session tasks can be acknowledged.')
            db.execute("UPDATE photo_jobs_v4 SET state='Partial',detail=?,updated=? WHERE scope=? AND id=?",
                       ('Interrupted outcome acknowledged after manual review; this is not proof of completion.',stamp(),scope_id(scope),identity))

    def record_export(self,scope,photo,output,recipe):
        row=self.get(scope,photo)
        if not row: raise ValueError('Source photo record disappeared after saving; inspect the export destination.')
        with self.connect() as db:
            db.execute('INSERT INTO photo_exports_v4 VALUES(?,?,?,?,?,?,?,?)',(uid(),scope_id(scope),photo,output['path'],row['sha256'],output['sha256'],json_data(normalize_recipe(recipe)),stamp()))

    def is_export(self,path):
        # Export suppression is a read-only app-wide side-effect guard. It never
        # exposes other-account titles, bytes, membership, or paths to the UI.
        with self.connect() as db:return db.execute('SELECT 1 FROM photo_exports_v4 WHERE path=? UNION ALL SELECT 1 FROM photo_export_intents_v4 WHERE path=? LIMIT 1',(str(local_path(path)),str(local_path(path)))).fetchone() is not None

    def export_paths(self):
        """Internal suppression set only, never shown as another account's data."""
        with self.connect() as db:
            return {key(r[0]) for r in db.execute('SELECT path FROM photo_exports_v4 UNION SELECT path FROM photo_export_intents_v4')}

    def sheets(self,scope):
        with self.connect() as db:
            rows=[dict(r) for r in db.execute('SELECT * FROM photo_sheets_v6 WHERE scope=? ORDER BY name,id',(scope_id(scope),))]
        for r in rows:r['slots']=json.loads(r['slots']);r['layout']=json.loads(r['layout'])
        return rows

    def save_sheet(self,scope,name,selection,settings,*,identity=''):
        from photo_composite import slots,layout,geometry
        scope=scope_id(scope);name=text(name,100);selection=slots(selection);settings=layout(settings)
        geometry(settings,len(selection))
        if not name:raise ValueError('Name the contact-sheet project.')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for item in selection:
                if not db.execute('SELECT 1 FROM photo_items_v4 WHERE scope=? AND id=? AND hidden=0',(scope,item['photo'])).fetchone():
                    raise ValueError('A photo is missing, hidden or belongs to another workspace.')
            if identity:
                if not db.execute('SELECT 1 FROM photo_sheets_v6 WHERE scope=? AND id=?',(scope,identity)).fetchone():
                    raise ValueError('The saved project no longer exists in this workspace.')
            else:
                if db.execute('SELECT COUNT(*) FROM photo_sheets_v6 WHERE scope=?',(scope,)).fetchone()[0]>=64:
                    raise ValueError('This workspace already has 64 contact-sheet projects.')
                identity=uid()
            db.execute('INSERT OR REPLACE INTO photo_sheets_v6 VALUES(?,?,?,?,?,?)',
                       (identity,scope,name,json_data(selection),json_data(settings),stamp()))
        return identity

    def delete_sheet(self,scope,identity):
        with self.connect() as db:
            db.execute('DELETE FROM photo_sheets_v6 WHERE scope=? AND id=?',(scope_id(scope),identity))

    def record_sheet_export(self,scope,selection,settings,output,evidence):
        from photo_composite import slots,layout
        selection=slots(selection);settings=layout(settings)
        # Reuse the export inventory for suppression/recovery, retaining all sources
        # in its data-only recipe while the primary-photo column points at slot one.
        recipe={'kind':'contact-sheet','slots':selection,'layout':settings,'source_digests':evidence}
        with self.connect() as db:
            db.execute('INSERT INTO photo_exports_v4 VALUES(?,?,?,?,?,?,?,?)',
                       (uid(),scope_id(scope),selection[0]['photo'],output['path'],evidence[selection[0]['photo']],output['sha256'],json_data(recipe),stamp()))


def retained_sessions(history, *, incognito=False, offset=0):
    """Read only existing nonprivate history; never infer a new session from a photo."""
    if history is None or incognito:return []
    if type(offset) is not int or offset<0:raise ValueError('Invalid session-history page.')
    with history.connect() as db:
        db.row_factory=sqlite3.Row
        return [dict(r) for r in db.execute('''SELECT s.* FROM encounter_sessions s
                WHERE NOT EXISTS(SELECT 1 FROM private_player_sessions p WHERE p.id=s.id)
                ORDER BY started DESC,id LIMIT 100 OFFSET ?''',(offset,))]


def retained_session(history,identity,*,incognito=False):
    if history is None or incognito:return None
    with history.connect() as db:
        db.row_factory=sqlite3.Row
        row=db.execute('''SELECT s.* FROM encounter_sessions s WHERE s.id=? AND
             NOT EXISTS(SELECT 1 FROM private_player_sessions p WHERE p.id=s.id)''',(text(identity,128),)).fetchone()
        return dict(row) if row else None
