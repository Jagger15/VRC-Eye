# VRC Eye 1.21.0 — Development 21 implementation status

The 160-package preparation roadmap records **51 source-implemented, 70 partial and 39 pending packages**. ARC-21 advances to source implemented for reviewed exact-byte rules, workspace revocation and batch undo. Native/live acceptance remains open; full prepared acceptance has not been executed.

The separate 106-area ARC/VRCX ledger has **39 partial and 7 missing areas**, 51 source-implemented areas with acceptance open, 7 provider/acceptance prerequisites and 2 source-data limitations. These inventories have different scopes.

See DEVELOPMENT_21_RELEASE_NOTES.md, DEVELOPMENT_21_VALIDATION.md and ARC_VRCX_REMAINING_DEV21.md. Earlier checkpoint evidence remains in the JSON ledger.

| ID | Work package | Prepared scope status |
|---|---|---|
| FND-01 | One account, source and privacy context contract | pending |
| FND-02 | Shared event identity and projections | partial |
| FND-03 | Durable task ownership and recovery contracts | partial |
| FND-04 | Capabilities, provider ownership and fallback | pending |
| FND-05 | Replacement UI and accessible shared actions | pending |
| FND-06 | Read-only contract and parity ledger | pending |
| FND-07 | Native platform and distribution gates | pending |
| FND-08 | Scope and release-hold tracking | pending |
| VX-NATIVE-01 | One normalized event timeline and inbox state | source_implemented |
| VX-NATIVE-02 | Account storage isolation and safe legacy migration | source_implemented |
| VX-NATIVE-03 | Retained accounts and secure sign-in switching | partial |
| VX-NATIVE-04 | Resilient friend live feed with bounded reconciliation | source_implemented |
| VX-NATIVE-05 | Unified notifications including NotificationV2 | source_implemented |
| VX-NATIVE-06 | Friend relationship and profile history with reliable provenance | partial |
| VX-NATIVE-07 | Complete invitation responses | source_implemented |
| VX-NATIVE-08 | Edit saved invitation messages | source_implemented |
| VX-NATIVE-09 | Photo invitations and replies | source_implemented |
| VX-NATIVE-10 | Complete own-profile editor | source_implemented |
| VX-NATIVE-11 | Shared bounded image upload transport | source_implemented |
| VX-NATIVE-12 | Owned-avatar creator tools and galleries | partial |
| VX-NATIVE-13 | Everyday owned-world editor and publication | source_implemented |
| VX-NATIVE-14 | Group details, membership and permission-aware navigation | source_implemented |
| VX-NATIVE-15 | Group moderation and reviewed batch operations | source_implemented |
| VX-NATIVE-16 | Group role management | source_implemented |
| VX-NATIVE-17 | Group posts, announcements and gallery access | partial |
| VX-NATIVE-18 | Group calendars and event management | source_implemented |
| VX-NATIVE-19 | Group creation, settings and ownership lifecycle | source_implemented |
| VX-NATIVE-20 | Instant local entity search | source_implemented |
| VX-NATIVE-21 | Manage VRChat favorite groups within service limits | source_implemented |
| VX-NATIVE-22 | Complete native local collections and exports | source_implemented |
| VX-NATIVE-23 | Group instances and explicit visit handoff | source_implemented |
| VX-NATIVE-24 | VRChat gallery and account icon management | source_implemented |
| VX-NATIVE-25 | Sticker and emoji management | source_implemented |
| VX-NATIVE-26 | VRChat print browsing and publishing | source_implemented |
| VX-NATIVE-27 | Inventory and cosmetic catalog browser | source_implemented |
| VX-NATIVE-28 | Inventory consume, reward and supported equipment actions | source_implemented |
| VX-NATIVE-29 | Optional avatar metadata search providers | partial |
| VX-MIG-01 | Versioned source contract inventory | partial |
| VX-MIG-02 | Consistent read-only SQLite and WAL acquisition | source_implemented |
| VX-MIG-03 | Explicit source-account and destination-scope mapping | source_implemented |
| VX-MIG-04 | Native entity, collections and annotation data model | source_implemented |
| VX-MIG-05 | Provenance, immutable review and migration ledger | source_implemented |
| VX-MIG-06 | Deterministic deduplication and field-level conflicts | source_implemented |
| VX-MIG-07 | Deletion tombstones, retention and privacy policy | partial |
| VX-MIG-08 | Atomic batches, recoverable projections and per-record rollback | partial |
| VX-MIG-09 | Favorite group dates, ordering and empty-group semantics | partial |
| VX-MIG-10 | Unify imported and existing native Favorites | source_implemented |
| VX-MIG-11 | Bulk avatar observations integrated with AvatarLibrary | source_implemented |
| VX-MIG-12 | World and user descriptive observations | source_implemented |
| VX-MIG-13 | Local avatar tags with native editing and filtering | source_implemented |
| VX-MIG-14 | User, world and avatar memos plus account notes | partial |
| VX-MIG-15 | Native user labels and conditional custom-tag migration | partial |
| VX-MIG-16 | Selected VRCX status preset import | source_implemented |
| VX-MIG-17 | Selective nonsecret settings and preference mapping | partial |
| VX-MIG-18 | Avatar-use aggregate history | source_implemented |
| VX-MIG-19 | World visits, join/leave and portal event history | source_implemented |
| VX-MIG-20 | Video, resource and auxiliary game-log history | partial |
| VX-MIG-21 | Friend changes and social observation feeds | source_implemented |
| VX-MIG-22 | Derived activity sessions and analytics provenance | source_implemented |
| VX-MIG-23 | Notification archives and invite message details | partial |
| VX-MIG-24 | Moderation observations and mutual graph snapshots | source_implemented |
| VX-MIG-25 | Print favorite references and conditional print metadata | partial |
| VX-MIG-26 | Photo index migration with verified file relinking | partial |
| VX-MIG-27 | Legacy screenshot formats and declaration conflicts | partial |
| VX-MIG-28 | Saved searches, filters and portable views | partial |
| VX-MIG-29 | Native selective backup and complete restore | partial |
| VX-MIG-30 | Reviewed export and honest VRCX roundtrip coverage | partial |
| VX-MIG-31 | Selective migration workspace and standalone native routes | source_implemented |
| VX-MIG-32 | Optional handoff boundaries and replacement capability audit | partial |
| VX-MIG-33 | Future acceptance matrix and migration release gates | partial |
| VX-DESK-01 | Shared dashboard projections | partial |
| VX-DESK-02 | Configurable dashboards and widget layouts | partial |
| VX-DESK-03 | Unified notification delivery and focus rules | source_implemented |
| VX-DESK-04 | Activity charts, heatmaps and history analysis | source_implemented |
| VX-DESK-05 | Native Discord presence provider | partial |
| VX-DESK-06 | Discord content, join controls and coexistence | partial |
| VX-DESK-07 | Configured application launch automation | partial |
| VX-DESK-08 | Opt-in crash recovery controller | partial |
| VX-DESK-09 | Reviewed join and last-instance recovery orchestration | source_implemented |
| VX-DESK-10 | Automatic photo context association | source_implemented |
| VX-DESK-11 | Optional compatible photo metadata output | source_implemented |
| VX-DESK-12 | Photo organization, source moves and recovery | source_implemented |
| VX-DESK-13 | Photo metadata index and richer gallery search | source_implemented |
| VX-DESK-14 | VRChat service-health integration | source_implemented |
| VX-DESK-15 | Tray/background and low-power operation | partial |
| VX-DESK-16 | Settings profiles, backup and rollback UX | partial |
| VX-DESK-17 | Optional update channels and recoverable installation | partial |
| VX-DESK-18 | Optional media-link enrichment and translation providers | partial |
| VX-DESK-19 | Reviewed VRChat configuration and launch settings editor | source_implemented |
| VX-DESK-20 | Standalone replacement onboarding and coexistence | partial |
| ARC-01 | Isolated avatar provider contract and lifecycle | partial |
| ARC-02 | Authorized VRCA and Unity bundle ingestion | pending |
| ARC-03 | Authorized FBX import and scene inspection | pending |
| ARC-04 | Actual material and texture viewer | partial |
| ARC-05 | Rig, skinning and blendshape viewer | pending |
| ARC-06 | Clip, take and safe controller animation preview | pending |
| ARC-07 | AssetRipper provider selection, version and provenance | partial |
| ARC-08 | Integrated user-owned recovery orchestration | partial |
| ARC-09 | Recovered-project provenance and reviewed editor handoff | partial |
| ARC-10 | Renderer bounds diagnostics and copy-only correction | pending |
| ARC-11 | Reviewed mesh and importer setting transfer | pending |
| ARC-12 | Conservative rig and skinned-mesh optimization | pending |
| ARC-13 | Topology and tangent diagnostics with narrow repair copies | partial |
| ARC-14 | Shader and material compatibility diagnostics | partial |
| ARC-15 | Typed material property mapping on copies | partial |
| ARC-16 | Reviewed shader package install and removal | partial |
| ARC-17 | Animation and controller dependency repair copies | partial |
| ARC-18 | Component and hierarchy dependency analysis and explicit repair | partial |
| ARC-19 | General repair-copy journal and conditional rollback | partial |
| ARC-20 | Scoped automated catalog metadata backfill | source_implemented |
| ARC-21 | Evidence-based automated local-file association | source_implemented |
| ARC-22 | Opt-in resumable authorized transfers | partial |
| ARC-23 | Explicit bounded transient retry policy | partial |
| ARC-24 | Durable job and publication crash reconciliation | partial |
| OVR-00 | Overlay 0 — detect/render | partial |
| OVR-01 | Overlay 1 — dashboard tab | pending |
| OVR-02 | Overlay 2 — input/navigation | partial |
| OVR-03 | Overlay 3 — IPC | pending |
| OVR-04 | Overlay 4 — home | pending |
| OVR-05 | Overlay 5 — notifications | pending |
| OVR-06 | Overlay 6 — media/session | pending |
| OVR-07 | Overlay 7 — social/world | pending |
| OVR-08 | Overlay 8 — Quick Panel | partial |
| OVR-09 | Overlay 9 — Wrist | partial |
| OVR-10 | Overlay 10 — Pinned panels | pending |
| OVR-11 | Overlay 11 — OSC | pending |
| OVR-12 | Overlay 12 — diagnostics/performance | partial |
| OVR-13 | Overlay 13 — creator | pending |
| OVR-14 | Overlay 14 — accessibility | partial |
| OVR-15 | Overlay 15 — platform hardening | partial |
| OVR-16 | Overlay 16 — custom layouts | pending |
| OVR-17 | Later OpenXR feasibility — proposed addition, not recovered Overlay 0–16 | pending |
| PRD-01 | Universal search, recents and navigation history | partial |
| PRD-02 | Optional operating-system global hotkeys | pending |
| PRD-03 | Canonical session lifecycle and start/end/resume centers | pending |
| PRD-04 | Session tasks, scratchpad, moment bookmarks and snooze | pending |
| PRD-05 | World queue and reusable itineraries | partial |
| PRD-06 | Session plans, event preparation and backup plans | pending |
| PRD-07 | Optional automation engine and casual routines | partial |
| PRD-08 | Recognized clipboard, QR links and quick capture | pending |
| PRD-09 | Local voice notes and optional offline transcription | partial |
| PRD-10 | Offline policy and network budgets | partial |
| PRD-11 | Portable data roots and local migration | pending |
| PRD-12 | Recovery center, safe startup, drafts, undo and trash | pending |
| PRD-13 | Feature availability, dependencies and permission explanations | partial |
| PRD-14 | Health, errors, status, snapshots and support diagnostics | partial |
| PRD-15 | Service ownership, startup controls and bounded watchdog | partial |
| PRD-16 | Storage, retention and resource-aware maintenance | pending |
| PRD-17 | Workspaces, detached panels and layered settings | pending |
| PRD-18 | Privacy shield, global pause and session lock | pending |
| PRD-19 | Validated deep links, bookmarks and cross-surface handoff | pending |
| UI-01 | Collapsible sections throughout the sidebar | partial |
| UI-02 | Prominent accent account header on every page | partial |
| SPAT-01 | Shared spatial frames, validity and capability service | partial |
| SPAT-02 | SteamVR wrist reference compass | partial |
| SPAT-03 | Shared targets, waypoints and rendezvous guidance | partial |
| SPAT-04 | Spatial player markers and source-aware roster | pending |
| SPAT-05 | Consented Eye-to-Eye spatial beacons | pending |
| SPAT-06 | Creator map and compatible bridge spatial adapters | pending |
| SPAT-07 | Optional OSC and Avatar Toolkit compass adapter | pending |
