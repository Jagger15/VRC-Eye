# VRC Eye 1.21.0 — Development checkpoint 2

This runnable source checkpoint adds the first SteamVR compass milestone and
interface/account improvements to the verified Development 1 package. The full
VRCX, ARC and overlay roadmap remains in progress.

## Start

Close the old copy, extract this ZIP into a separate folder, open `VRC-Eye`, and
run **Start.cmd** on Windows or **bash Start.sh** on Linux. Python 3.10 or newer
with Tkinter is required. The launcher prepares the app-local feature environment;
Linux also needs venv support from your distribution. **Demo.cmd / Demo.sh** and
**Safe-mode.cmd / Safe-mode.sh** remain available without dependency installation.
With an existing environment, install `requirements.txt` and run `python vrc_eye.py`.

Keep the old copy for rollback. Different extraction folders share the existing
per-user data locations; copying a folder does not isolate accounts or preferences.
No uploaded VRChat/VRCX installation binaries, account database, saved credentials
or Python environment are included. This is not a compiled executable.

## New in this checkpoint

- **SteamVR wrist compass:** optional local reference heading, head/controller
  heading source, explicit left/right switching, independent per-hand placement,
  dashboard recovery controls, compact/details display and one temporary room
  waypoint. Open Settings or the Home shortcut. See [the compass guide](SPATIAL_COMPASS_GUIDE.md).
- **Collapsible sidebar:** all five sections can be folded independently, with
  an active-page hint and expand-all, collapse-all and reset controls. Saved
  disclosure choices survive restart. Direct navigation can reveal a section
  for the current visit without overwriting that choice.
- **Clearer account header:** the confirmed account uses the current accent,
  with signed-in status and privacy controls visible across pages. Opening the
  connection window still shows the active-account summary.
- **Optional Stay signed in:** protected session storage can restore a saved
  session after validating it with VRChat. Username/password remembering remains
  separate. Expired sessions and required verification return to sign-in;
  offline, privacy, Demo and Safe states suppress automatic restoration.
- **Linux launchers:** Start, Demo and Safe-mode scripts accompany the existing
  Windows launchers. No additional runtime dependency was introduced by this
  checkpoint.

The compass shares the existing OpenVR owner; it does not create a competing
VR connection or require OSC/avatar installation. Stale tracking, privacy and
account transitions clear guidance. Reconnect waits for prior native ownership
to retire. Saved appearance/placement preferences do not enable tracking at startup.

**Player ESP and remote-player positions remain pending.** This checkpoint uses
local SteamVR tracking and a room waypoint. Eye-to-Eye streaming, creator-pose
sharing and live VRChat-world alignment are not connected. The 160-package
consolidated roadmap is not complete; see the [implementation ledger](IMPLEMENTATION_STATUS_1_21.md).

## Saved session behavior

Stay signed in is an explicit opt-in after confirmed authentication. Windows
uses user-bound DPAPI protection; Linux uses an available, unlocked Secret Service
on the current user's session bus. There is no plaintext cookie fallback or
automatic keyring-unlock prompt. If protected storage is unavailable, ordinary
sign-in still works and the failure is shown.

Only unexpired, secure, persistent auth/twoFactorAuth cookies with supported
VRChat scope are eligible. Session/discard cookies are not extended. Saved
sessions stay local to the OS user and are excluded from portable data.

A saved session is a candidate until validation succeeds. It cannot replace a
confirmed active account because a background request finished late. Disconnect
ends the current connection; disabling Stay signed in or forgetting the saved
session disables future restoration and requests protected-secret removal.
A storage failure is reported and can require retry. A session check may still
require VRChat verification, and this build does not bypass it.

Native SteamVR/headset behavior, Windows vault operations, a real desktop Linux
keyring and live VRChat authentication require separate acceptance. Executed
checks and exact limitations are recorded in [validation](VALIDATION_1_21.md).

## Retained Development 1 features

Media & Audio, installation inspection, VRCX/photo/account/search integrations
and stable accent tabs remain included. Their usage is summarized below; the
original checkpoint notes are retained in [DEVELOPMENT_1_21_DEV1.md](DEVELOPMENT_1_21_DEV1.md).

## Media & Audio

Open **VRC Eye → Media & Audio** or use **Ctrl+K**. Discover supported players
explicitly, then select a source. Windows uses GSMTC; Linux uses MPRIS on the
current user's session bus. The app shows each player's advertised capabilities,
track metadata and reported/estimated position. Unsupported controls stay unavailable.
Seek and transport commands recheck the selected player, track and context.

Now Playing text requires a preview and uses the existing OSC permissions and
chatbox scheduler. A final producer check cancels stale source/track text before
transmission. Stopping media cancels Eye observation and queued publications; it
does not automatically pause unrelated external players.

History is optional and account-scoped. Bookmarks and an ordered DJ cue list
retain observed sources and positions. The DJ page controls the pinned player;
independent audio decks, beatmatching and automatic cue playback are not included.
Private listening hides metadata and stops the associated Eye publication path.

The Mixer offers explicit named input/output selection, microphone level tests,
microphone/music/private-cue gain and mute, and separate monitor/outgoing buses.
Private cue cannot enter outgoing audio. Outgoing routing starts only after its
session switch is enabled and the selected mix is started. The linked sample-peak
limiter limits stereo digital peaks; it is not a true-peak or acoustic safety meter.
No recording is made by the mixer. Device changes or capture faults stop output;
there is no automatic default-device fallback or automatic rearming.

This capture backend uses 48 kHz float32 input and stereo output. Choose an
existing named virtual endpoint for outgoing audio and configure VRChat's input
in the game. The app does not install a driver, create a PipeWire virtual source,
capture arbitrary application processes, or prove remote audibility. Those native
routes and platform acceptance checks remain separate work.

## Installation and local interoperability

**Unity Player → Installation** inspects a selected folder or ZIP without running
its programs or extracting an installation. It reports bounded file inventory,
passive engine/version/architecture/import evidence, component roles and declared
SteamVR actions/bindings. Optional selected-file hashes, saved baselines, comparison,
exact runtime association and sanitized reports preserve partial/unknown states.

The shared VRChat configuration reader recognizes photo folder, date split and
cache directory fields. Steam/Proton candidates and configured folders remain
explicit choices. Photos can inspect supported VRCX JSON and VRChat XMP metadata
with provenance and conflict reporting; sensitive identity/instance/roster fields
are hidden by default. Inspection does not silently write annotations or sessions,
and existing metadata-free export preserves the original source image.

VRCX interoperability includes a custom-column CSV preview/mapping flow, local
favorite-group membership import, richer selected avatar observations, separate
local tags, and selected-record handoff. Original VRCX databases stay read-only.
Imports do not turn cached metadata into current VRChat ownership or asset authority.

Social notification details remain bounded and source-labelled. Account-scoped
status presets fill the existing profile draft and retain its review step. Saved
searches and optional recent searches restore form fields; opening or selecting
one does not issue a network search automatically.

See `IMPLEMENTATION_STATUS_1_21.md` for every prepared package's status and
`VALIDATION_1_21.md` for executed checks and remaining native validation.
