"""Deterministic OSC laboratory. It has no network transport or live replay path."""
from __future__ import annotations

from collections import deque
from copy import deepcopy
import heapq
import math


class VirtualClock:
    def __init__(self, now=100.0):
        self.now = float(now)

    def __call__(self): return self.now

    def advance(self, seconds):
        if type(seconds) not in (float, int) or not math.isfinite(seconds) or not 0 <= seconds <= 3600:
            raise ValueError("Advance the simulator by zero to 3600 seconds.")
        self.now += seconds
        return self.now


class SimulatedTransport:
    """The real service talks to this in-memory transport, never a UDP socket."""
    simulated = True

    def __init__(self, clock):
        self.clock = clock
        self.connected = False
        self.generation = 0
        self.receive_port, self.target_port = 9001, 9000
        self.bind_host, self.target_host = "127.0.0.1", "127.0.0.1"
        self.sent = deque(maxlen=1024)
        self.queue = deque(maxlen=512)
        self.invalid = self.dropped = 0
        self.drop_remaining = 0
        self.reject_addresses = set()
        self.fail_send = False
        self.on_send = None

    def start(self, **config):
        # Values remain descriptive. start() does not import socket or bind ports.
        self.connected = True
        self.generation += 1
        self.receive_port = config.get("receive_port", self.receive_port)
        self.target_port = config.get("target_port", self.target_port)
        self.bind_host = config.get("bind_host", "127.0.0.1")
        self.target_host = config.get("target_host", "127.0.0.1")
        self.queue.clear()
        return self.snapshot()

    def stop(self):
        self.connected = False
        self.generation += 1
        self.queue.clear()

    close = stop

    def send(self, address, args):
        from osc_transport import encode_message
        if not self.connected or self.fail_send: raise OSError("Simulated transport disconnected.")
        encode_message(address, tuple(args))
        dropped = self.drop_remaining > 0
        if dropped:
            self.drop_remaining -= 1
            self.dropped += 1
        rejected = address in self.reject_addresses
        record = {"time": self.clock(), "address": address, "args": tuple(args), "generation": self.generation, "dropped": dropped, "rejected": rejected}
        self.sent.append(record)
        if self.on_send and not dropped and not rejected: self.on_send(record)
        # UDP send completion does not disclose the simulated peer's rejection.
        return None

    def drain(self, limit=128):
        return tuple(self.queue.popleft() for _ in range(min(limit, len(self.queue))))

    def snapshot(self):
        return {"connected": self.connected, "generation": self.generation, "receive_port": self.receive_port, "target_port": self.target_port, "target_host": self.target_host, "bind_host": self.bind_host, "invalid": self.invalid, "dropped": self.dropped, "mode": "SIMULATOR — no live network"}


class OSCSimulator:
    """A fresh shared service with a virtual clock, fake transport and fault controls.

    It deliberately cannot accept an existing service: opening diagnostics must
    never turn recorded actions into commands to a live VRChat instance.
    """
    AVATAR = "avtr_11111111-2222-3333-4444-555555555555"

    def __init__(self):
        from osc_service import OSCService
        self.clock = VirtualClock()
        self.transport = SimulatedTransport(self.clock)
        self.service = OSCService(transport=self.transport, clock=self.clock)
        self.events = []
        self.history = deque(maxlen=512)
        self.sequence = 0
        self.observation_delay = .05
        self.echo_enabled = True
        self.transport.on_send = self._echo
        self.service.connect()
        self.observe("/avatar/change", (self.AVATAR,))

    def _log(self, kind, **details):
        self.history.append({"time": self.clock(), "kind": kind, **details})

    def _enqueue(self, kind, details, delay):
        if type(delay) not in (float, int) or not math.isfinite(delay) or not 0 <= delay <= 3600:
            raise ValueError("Simulator event delay must be zero to 3600 seconds.")
        if len(self.events) >= 512: raise ValueError("Simulator event queue is full.")
        self.sequence += 1
        heapq.heappush(self.events, (self.clock() + delay, self.sequence, kind, deepcopy(details)))

    def _echo(self, record):
        if self.echo_enabled:
            self._enqueue("observation", {"address": record["address"], "args": record["args"], "generation": tuple(self.service.state_guard)}, self.observation_delay)

    def observe(self, address, args, *, delay=0):
        from osc_transport import encode_message
        encode_message(address, tuple(args))
        if delay:
            self._enqueue("observation", {"address": address, "args": tuple(args), "generation": tuple(self.service.state_guard)}, delay)
            return
        result = self.service.observe(address, tuple(args), source=("127.0.0.1", self.transport.target_port))
        self._log("observation", address=address, args=tuple(args))
        return result

    def advance(self, seconds=.1):
        self.clock.advance(seconds)
        self.service.tick()
        while self.events and self.events[0][0] <= self.clock():
            _, _, kind, details = heapq.heappop(self.events)
            if tuple(details.get("generation", ())) != tuple(self.service.state_guard):
                self._log("stale_event_discarded", address=details.get("address"))
                continue
            if kind == "observation": self.observe(details["address"], details["args"])
        self.service.tick()
        return self.snapshot()

    def drop_next(self, count=1):
        if type(count) is not int or not 0 <= count <= 512: raise ValueError("Drop count must be zero to 512.")
        self.transport.drop_remaining = count
        self._log("packet_loss", count=count)

    def reject(self, address, enabled=True):
        from osc_transport import validate_address
        validate_address(address)
        if enabled: self.transport.reject_addresses.add(address)
        else: self.transport.reject_addresses.discard(address)
        self._log("peer_rejection", address=address, enabled=bool(enabled))

    def change_type(self, address, kind, *, read_only=False):
        self.service.registry.register_parameter(address, kind, read_only=read_only, evidence="simulated")
        self._log("endpoint_type_changed", address=address, type=kind)

    def change_avatar(self, avatar_id):
        self.observe("/avatar/change", (avatar_id,))
        self._log("avatar_transition", avatar_id=avatar_id)

    def conflicting_writer(self, address, args):
        # Unmanaged writers are represented by external observations, not authority.
        self.observe(address, tuple(args))
        self._log("external_writer", address=address)

    def malformed_packet(self, payload=b"not-an-osc-packet"):
        from osc_transport import decode_packet, OSCError
        if type(payload) is not bytes or len(payload) > 16384: raise ValueError("Provide a bounded packet.")
        try:
            decode_packet(payload)
        except OSCError:
            self.transport.invalid += 1
            self._log("malformed_packet_rejected", bytes=len(payload))
            return False
        return True

    def disconnect(self):
        self.service.disconnect()
        self.events.clear()
        self._log("disconnected")

    def reconnect(self, *, target_port=9000, receive_port=9001):
        self.service.connect(target_port=target_port, receive_port=receive_port)
        self.events.clear()
        self._log("reconnected", target_port=target_port, receive_port=receive_port)

    def replay(self, records):
        """Replay only bounded observations into this simulator, never live actions."""
        if not isinstance(records, list) or len(records) > 512: raise ValueError("Replay accepts at most 512 observation records.")
        prepared = []
        from osc_transport import encode_message
        for row in records:
            if not isinstance(row, dict) or set(row) - {"address", "args", "delay"} or not {"address", "args"} <= set(row):
                raise ValueError("Replay supports observation records only.")
            encode_message(row["address"], row["args"])
            delay = row.get("delay", 0)
            if type(delay) not in (float, int) or not math.isfinite(delay) or not 0 <= delay <= 3600: raise ValueError("Invalid replay delay.")
            prepared.append((row["address"], tuple(row["args"]), delay))
        if len(self.events) + len(prepared) > 512: raise ValueError("Replay exceeds the simulator queue bound.")
        for address, args, delay in prepared: self.observe(address, args, delay=delay)
        self._log("observations_replayed", count=len(prepared))
        return self.snapshot()

    def inject(self, event, **payload):
        """Finite UI fault controls. No dynamic lookup of arbitrary method names."""
        operations = {"advance": (self.advance, {"seconds"}),
                      "observe": (self.observe, {"address", "args", "delay"}),
                      "packet_loss": (self.drop_next, {"count"}),
                      "rejection": (self.reject, {"address", "enabled"}),
                      "type_change": (self.change_type, {"address", "kind", "read_only"}),
                      "avatar_change": (self.change_avatar, {"avatar_id"}),
                      "conflicting_writer": (self.conflicting_writer, {"address", "args"}),
                      "malformed": (self.malformed_packet, set()),
                      "disconnect": (self.disconnect, set()),
                      "reconnect": (self.reconnect, {"target_port", "receive_port"}),
                      "replay": (self.replay, {"records"})}
        if event == "missing_observations":
            if set(payload) != {"enabled"} or type(payload["enabled"]) is not bool:
                raise ValueError("missing_observations requires a boolean enabled value.")
            self.echo_enabled = not payload["enabled"]
            self._log("missing_observations", enabled=payload["enabled"])
        elif event == "delay":
            seconds = payload.get("seconds")
            if set(payload) != {"seconds"} or type(seconds) not in (float, int) or not math.isfinite(seconds) or not 0 <= seconds <= 30:
                raise ValueError("Observation delay must be zero to 30 seconds.")
            self.observation_delay = seconds
            self._log("observation_delay", seconds=seconds)
        elif event in operations:
            operation, fields = operations[event]
            if set(payload) - fields: raise ValueError("Unknown simulator event fields.")
            try: operation(**payload)
            except TypeError as exc: raise ValueError("Missing or invalid simulator event fields.") from exc
        else: raise ValueError("Unknown simulator event; no live actions are accepted.")
        return self.snapshot()

    def snapshot(self):
        return {"state": "Running" if self.transport.connected else "Disconnected", "live": False, "mode": "SIMULATOR — no live network", "simulated": True, "time": self.clock(), "service": self.service.snapshot(), "transport": self.transport.snapshot(), "sent": deepcopy(list(self.transport.sent)), "pending_events": len(self.events), "history": deepcopy(list(self.history))}

    def close(self):
        self.events.clear()
        self.service.disconnect()
