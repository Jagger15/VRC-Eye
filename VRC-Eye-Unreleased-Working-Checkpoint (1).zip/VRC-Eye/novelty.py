"""Local calendar celebrations and opt-in presentation; no peer dispatch."""
from copy import deepcopy
from datetime import date
import calendar
import time

KEY='ui.novelty'
SKINS=('Conure','Robot eye','Cat','Slime','Drone')
def defaults():
    return dict(schema=1,enabled=False,birthday=False,month=1,day=1,name='',feb29='March 1',
                weekend=False,days=[5,6],frequency='Weekly',message='🦜 It’s the weekend — have fun!',
                animation='Gentle',sounds=False,ow0=False,show_mascot=False,skin='Conure',seen=[])
def validate(raw):
    if not isinstance(raw,dict) or set(raw)!=set(defaults()) or type(raw['schema']) is not int or raw['schema']!=1:raise ValueError('Invalid novelty preferences.')
    for key in ('enabled','birthday','weekend','sounds','ow0','show_mascot'):
        if type(raw[key]) is not bool:raise ValueError('Use on/off novelty switches.')
    if type(raw['month']) is not int or type(raw['day']) is not int:raise ValueError('Enter a valid birthday month and day.')
    try:date(2000,raw['month'],raw['day'])
    except ValueError:raise ValueError('Enter a valid birthday month and day.') from None
    for key,limit in (('name',80),('message',200)):
        value=raw[key]
        if not isinstance(value,str) or len(value)>limit or any(ord(c)<32 or 0x202a<=ord(c)<=0x202e or 0x2066<=ord(c)<=0x2069 for c in value):raise ValueError('Use a short plain-text greeting.')
    if raw['feb29'] not in ('February 28','March 1','Leap years only') or raw['frequency'] not in ('Weekly','Daily','Manual only') or raw['animation'] not in ('Off','Gentle','Celebrate') or raw['skin'] not in SKINS:raise ValueError('Choose a supported novelty option.')
    if not isinstance(raw['days'],list) or len(raw['days'])>7 or any(type(x) is not int or not 0<=x<=6 for x in raw['days']) or len(raw['days'])!=len(set(raw['days'])):raise ValueError('Choose valid weekend days.')
    if not isinstance(raw['seen'],list) or len(raw['seen'])>120 or any(not isinstance(x,str) or len(x)>50 for x in raw['seen']):raise ValueError('Invalid celebration history.')
    return deepcopy(raw)

def eligible(prefs,today):
    if not prefs['enabled']:return []
    result=[];month,day=prefs['month'],prefs['day']
    if (month,day)==(2,29) and not calendar.isleap(today.year):
        month,day=(2,28) if prefs['feb29']=='February 28' else (3,1) if prefs['feb29']=='March 1' else (0,0)
    if prefs['birthday'] and (month,day)==(today.month,today.day):result.append(('birthday','birthday:'+str(today.year)))
    if prefs['weekend'] and today.weekday() in prefs['days'] and prefs['frequency']!='Manual only':
        occurrence=today.isoformat() if prefs['frequency']=='Daily' else '%s-W%02d'%today.isocalendar()[:2]
        result.append(('weekend','weekend:'+occurrence))
    return [(kind,key) for kind,key in result if key not in prefs['seen']]

def owned(app,text):
    """Call only with application-owned wording, never account or user data."""
    engine=getattr(app,'novelty',None)
    return text.translate(str.maketrans('rR','wW')) if engine and engine.settings['enabled'] and engine.settings['ow0'] else text

class Novelty:
    def __init__(self,app):
        self.app=app;self.settings=validate(app.sidebar.store.option(KEY,None) or defaults())
        self.launch_date=date.today();self.state=None;self.revision=0;self.last_auto=-float('inf')
    def save(self,settings):
        value=validate(settings)
        if not self.app.demo and not getattr(self.app,'safe_mode',False):self.app.sidebar.store.set_option(KEY,value)
        self.settings=value;self.revision+=1
        if not value['enabled']:self.state=None
        self.app.sidebar.refresh_navigation()
        home=self.app.sidebar.pages.get('Home')
        if home:home.last_snapshot=None
    def quiet(self):
        from account_header import private
        if private(self.app):return True
        wellness=self.app.sidebar.pages.get('Wellness');engine=getattr(wellness,'engine',None)
        if engine and (engine.quiet() or any(getattr(engine,k,False) for k in ('focus','dnd','safety_busy'))):return True
        return bool(getattr(self.app,'player_sessions',None) and self.app.player_sessions.settings.get('notifications_muted'))
    def present(self,kind,*,preview=False,settings=None):
        prefs=validate(settings) if settings is not None else self.settings
        quiet=self.quiet();name=prefs['name'] if not quiet else ''
        text=('Happy birthday'+(', '+name if name else '')+'!') if kind=='birthday' else prefs['message'] if kind=='weekend' else 'Hello from your VRC Eye companion!'
        self.state=dict(kind=kind,text=text,preview=preview,started=time.monotonic(),skin='Conure' if kind=='weekend' else prefs['skin'],
                        animation='Off' if quiet or getattr(getattr(self.app,'presentation',None),'reduced_motion',False) else prefs['animation'],
                        sound_suppressed=quiet,prefs=prefs)
        if prefs['sounds'] and not quiet and not self.app.demo and not getattr(self.app,'safe_mode',False):self.app.root.bell()
    def tick(self):
        from account_header import private
        if private(self.app):self.state=None;return
        if self.app.sidebar.current!='Home' or self.app.demo or getattr(self.app,'safe_mode',False):return
        if self.state or self.quiet() or time.monotonic()-self.last_auto<60:return
        # Calendar policy is first eligible Home visit in the launch date; no midnight surprise.
        if date.today()!=self.launch_date:return
        events=eligible(self.settings,self.launch_date)
        if events:
            kind,key=events[0];prefs=deepcopy(self.settings);prefs['seen']=(prefs['seen']+[key])[-120:]
            self.save(prefs);self.last_auto=time.monotonic();self.present(kind)
    def dismiss(self):self.state=None;self.last_auto=time.monotonic()

def install(app):
    if not getattr(app,'novelty',None):app.novelty=Novelty(app)
    return app.novelty
