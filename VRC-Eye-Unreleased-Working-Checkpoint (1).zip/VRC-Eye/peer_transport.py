"""Optional, authenticated VRC Eye networking.

Private-mode construction imports no cryptography and opens no sockets. Direct
connections expose their selected endpoint. Relay mode uses a pinned outer TLS
connection plus inner, host-pinned TLS: the relay forwards opaque bytes only.
Device identities authenticate installations, never a claimed VRChat account.
"""
from __future__ import annotations

import base64
import collections
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import queue
import re
import secrets
import socket
import ssl
import struct
import threading
import time
import uuid
import unicodedata

MAX_FRAME = 131072
MAX_PEERS = 16
MAX_INVITES = 64
HANDSHAKE_TIMEOUT = 10.0
INVITATION_PREFIX = 'VRCEYE1.'
_PROTOCOL = 1
_VERSION = '1.21.0'
MODES = ('LAN', 'Hamachi', 'Tailscale', 'ZeroTier', 'Radmin VPN', 'NetBird', 'Other VPN', 'Relay')
VPN_MODES = MODES[1:-1]
_HEX = re.compile(r'^[0-9a-f]{64}$')


def _json(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError('Duplicate field')
            result[key] = value
        return result
    def invalid(_):
        raise ValueError('Invalid number')
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    except (RecursionError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError('Invalid network frame') from exc


def _encode(value):
    raw = json.dumps(value, separators=(',', ':'), ensure_ascii=True,
                     sort_keys=True, allow_nan=False).encode('utf-8')
    if len(raw) > MAX_FRAME:
        raise ValueError('Network frame too large')
    return raw


def _b64(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _unb64(value, size=None):
    if not isinstance(value, str) or len(value) > 12000 or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Invalid encoded value')
    raw = base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
    if size is not None and len(raw) != size:
        raise ValueError('Invalid key size')
    return raw


def _device_id(raw):
    return 'eye_' + hashlib.sha256(raw).hexdigest()


def _caps():
    from peer_protocol import capabilities
    return capabilities()


def _alias(value):
    if not isinstance(value, str) or len(value) > 80 or any(unicodedata.category(c).startswith('C') for c in value):
        raise ValueError('Invalid alias')
    return value


def _endpoint(address, port):
    if not isinstance(address, str) or len(address) > 253 or not address or any(c.isspace() for c in address):
        raise ValueError('Enter a host name or IP address')
    if any(c in address for c in '/\\@?#'):
        raise ValueError('Enter a host name or IP address')
    if type(port) is not int or not 0 <= port <= 65535:
        raise ValueError('Invalid port')
    return address, port


def _write_private(path, data):
    fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'wb') as target:
        target.write(data)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _load_identity(directory):
    """Called exclusively from networking workers; optional crypto stays lazy."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
    from cryptography.x509.oid import NameOID
    import datetime

    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    device_path = directory / 'device-key.pem'
    if not device_path.exists():
        key = ed25519.Ed25519PrivateKey.generate()
        try:
            _write_private(device_path, key.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        except FileExistsError:
            pass
    key = serialization.load_pem_private_key(device_path.read_bytes(), password=None)
    if not isinstance(key, ed25519.Ed25519PrivateKey):
        raise ValueError('Invalid device identity')
    raw = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    tls_key_path, cert_path = directory / 'tls-key.pem', directory / 'tls-cert.pem'
    # A partial initial identity must never silently rotate an already pinned certificate.
    if tls_key_path.exists() != cert_path.exists():
        raise ValueError('Incomplete TLS identity; restore the matching certificate and key')
    if not cert_path.exists():
        tls_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'VRC Eye device')])
        now = datetime.datetime.now(datetime.timezone.utc)
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                .public_key(tls_key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(now - datetime.timedelta(minutes=5))
                .not_valid_after(now + datetime.timedelta(days=3650))
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                .sign(tls_key, hashes.SHA256()))
        _write_private(tls_key_path, tls_key.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        _write_private(cert_path, cert.public_bytes(serialization.Encoding.PEM))
    cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(str(cert_path), str(tls_key_path))
    return {'key': key, 'public': _b64(raw), 'id': _device_id(raw), 'context': context,
            'pin': cert.fingerprint(hashes.SHA256()).hex()}


def _client_context():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE  # Exact out-of-band pin checked BEFORE application data.
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    return context


def _verify_pin(stream, expected):
    if not isinstance(expected, str) or not _HEX.fullmatch(expected):
        raise ValueError('Invalid certificate fingerprint')
    actual = hashlib.sha256(stream.getpeercert(binary_form=True)).hexdigest()
    if not secrets.compare_digest(actual, expected):
        raise ValueError('Certificate fingerprint does not match invitation')


def _signed(identity, body):
    result = dict(body)
    result['signature'] = _b64(identity['key'].sign(b'VRC-EYE-PEER-V1\0' + _encode(body)))
    return result


def _verify_signed(raw, key):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(raw, dict) or not isinstance(raw.get('signature'), str):
        raise ValueError('Missing authenticated handshake')
    body = {k: v for k, v in raw.items() if k != 'signature'}
    try:
        Ed25519PublicKey.from_public_bytes(_unb64(key, 32)).verify(
            _unb64(raw['signature'], 64), b'VRC-EYE-PEER-V1\0' + _encode(body))
    except Exception as exc:
        raise ValueError('Device authentication failed') from exc
    return body


class _TLSStream:
    """Standard OpenSSL TLS carried over another stream (including outer TLS)."""
    def __init__(self, stream, context, *, server_side=False, hostname=None):
        self.stream = stream
        self.incoming, self.outgoing = ssl.MemoryBIO(), ssl.MemoryBIO()
        self.tls = context.wrap_bio(self.incoming, self.outgoing, server_side=server_side,
                                   server_hostname=None if server_side else hostname)

    def _flush(self):
        while self.outgoing.pending:
            self.stream.sendall(self.outgoing.read())

    def _feed(self):
        data = self.stream.recv(16384)
        if not data:
            self.incoming.write_eof()
            raise EOFError('Connection closed')
        self.incoming.write(data)

    def do_handshake(self):
        deadline = time.monotonic() + HANDSHAKE_TIMEOUT
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError("TLS handshake timed out")
            self.stream.settimeout(max(.05, deadline - time.monotonic()))
            try:
                self.tls.do_handshake()
                self._flush()
                return
            except ssl.SSLWantReadError:
                self._flush()
                self._feed()
            except ssl.SSLWantWriteError:
                self._flush()

    def recv(self, count):
        while True:
            try:
                result = self.tls.read(count)
                self._flush()
                return result
            except ssl.SSLWantReadError:
                self._flush()
                self._feed()
            except ssl.SSLWantWriteError:
                self._flush()

    def sendall(self, data):
        offset = 0
        while offset < len(data):
            try:
                offset += self.tls.write(data[offset:])
                self._flush()
            except ssl.SSLWantReadError:
                self._flush()
                self._feed()
            except ssl.SSLWantWriteError:
                self._flush()

    def settimeout(self, value):
        self.stream.settimeout(value)

    def getpeercert(self, binary_form=False):
        return self.tls.getpeercert(binary_form=binary_form)

    def shutdown(self, how=socket.SHUT_RDWR):
        self.stream.shutdown(how)

    def close(self):
        self.stream.close()


class _FrameReader:
    def __init__(self, stream, deadline=None):
        self.stream, self.buffer = stream, bytearray()
        self.deadline, self.started = deadline, None

    def read(self):
        while True:
            now = time.monotonic()
            deadline = self.deadline or (self.started + HANDSHAKE_TIMEOUT if self.started else None)
            if deadline is not None and now >= deadline:
                raise ValueError("Network frame timed out")
            if len(self.buffer) >= 4:
                length = struct.unpack('!I', self.buffer[:4])[0]
                if not 0 < length <= MAX_FRAME:
                    raise ValueError('Network frame size rejected')
                if len(self.buffer) >= 4 + length:
                    raw = bytes(self.buffer[4:4 + length])
                    del self.buffer[:4 + length]
                    self.started = time.monotonic() if self.buffer else None
                    value = _json(raw)
                    if not isinstance(value, dict):
                        raise ValueError('Expected network object')
                    return value
            needed = (4 - len(self.buffer)) if len(self.buffer) < 4 else (4 + length - len(self.buffer))
            if self.deadline is not None:
                self.stream.settimeout(max(.05, self.deadline - time.monotonic()))
            data = self.stream.recv(min(16384, needed))
            if not data:
                raise EOFError('Connection closed')
            if self.started is None:
                self.started = time.monotonic()
            self.buffer.extend(data)


def _send_frame(stream, value):
    raw = _encode(value)
    stream.sendall(struct.pack('!I', len(raw)) + raw)


def parse_invitation(value, *, now=None):
    """Validate without opening a socket or importing cryptography."""
    if not isinstance(value, str) or not value.startswith(INVITATION_PREFIX) or len(value) > 8192:
        raise ValueError('Invalid VRC Eye invitation')
    info = _json(_unb64(value[len(INVITATION_PREFIX):]))
    fields = {'version', 'mode', 'address', 'port', 'pin', 'key', 'token', 'expires'}
    if not isinstance(info, dict) or info.get('mode') not in MODES:
        raise ValueError('Invalid invitation mode')
    if info['mode'] == 'Relay':
        fields |= {'relay_pin', 'room'}
    if set(info) != fields or type(info.get('version')) is not int or info.get('version') != _PROTOCOL:
        raise ValueError('Unsupported invitation')
    _endpoint(info['address'], info['port'])
    if not info['port'] or not _HEX.fullmatch(str(info['pin'])):
        raise ValueError('Invalid invitation endpoint')
    _unb64(info['key'], 32)
    _unb64(info['token'], 32)
    if info['mode'] == 'Relay':
        if not _HEX.fullmatch(str(info['relay_pin'])):
            raise ValueError('Invalid relay fingerprint')
        _unb64(info['room'], 32)
    now = time.time() if now is None else now
    if type(info['expires']) not in (float, int) or not now < info['expires'] <= now + 3605:
        raise ValueError('Invitation expired or has an invalid expiry')
    return info


def network_info():
    """Compatibility view of local adapters; richer details live in peer_adapters."""
    from peer_adapters import scan_adapters
    return [{'name': row['name'], 'address': row['address'],
             'hamachi': row['provider'] == 'Hamachi', 'loopback': row['loopback']}
            for row in scan_adapters()]


def hamachi_interfaces():
    return [row for row in network_info() if row['hamachi']]


def _selected_source(mode, destination, source_address=''):
    """Choose a current local source, without DNS or any network probes."""
    if not isinstance(source_address, str):
        raise ValueError('Choose a local source address')
    if mode == 'Relay':
        if source_address:
            raise ValueError('Relay connections do not use a direct peer adapter selection')
        return ''
    if mode in VPN_MODES or source_address:
        from peer_adapters import choose_source
        return choose_source(mode, destination, source_address)
    # Preserve existing LAN invitations and their normal OS route when the user
    # did not choose a source. Named VPNs never take this compatibility path.
    return ''


def _selected_host(mode, address):
    if mode in VPN_MODES:
        from peer_adapters import selected_adapter
        return selected_adapter(mode, address)
    return None


class PeerTransport:
    def __init__(self, directory, callback, *, clock=time.monotonic, wall=time.time, relay_only=False):
        self.directory, self.callback = Path(directory), callback
        self.clock, self.wall = clock, wall
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.threads, self.sockets = set(), set()
        self.peers, self.invites = {}, {}
        self.identity = None
        self.identity_lock = threading.Lock()
        self.listener = None
        self.state, self.mode, self.reason = 'PRIVATE', 'Private', ''
        self.address, self.port, self.alias = '', 0, ''
        self.relay_pin, self.room = '', ''
        self.handshakes = 0
        self.generation = 0
        self.relay_only = False
        self.source_address, self.source_selection = '', 'None'
        self.set_relay_only(relay_only)

    def set_relay_only(self, enabled):
        """Tightening closes an active direct instance; recreate it to reconnect."""
        if type(enabled) is not bool:
            raise ValueError('Relay-only privacy must be enabled or disabled')
        with self.lock:
            self.relay_only = enabled
            close_direct = enabled and self.mode not in ('Private', 'Relay')
            if close_direct:
                # Prevent any not-yet-tracked in-flight socket from being adopted.
                self.stop.set()
        if close_direct:
            self.close()
        return self.snapshot()

    def _check_policy(self, mode):
        with self.lock:
            if self.relay_only and mode != 'Relay':
                raise ValueError('Relay-only privacy blocks direct LAN and VPN connections')
            if self.stop.is_set():
                raise ValueError('Peer transport is closed; start a new connection')

    def _emit(self, event):
        try:
            return self.callback(dict(event)) is not False
        except Exception:
            # A failed consumer must not leak data through exception diagnostics.
            return False

    def _status(self, state, reason=''):
        with self.lock:
            if self.stop.is_set():
                return
            self.state, self.reason = state, reason
        self._emit({'type': 'status', 'state': state, 'reason': reason})

    def _spawn(self, function, *args):
        def run():
            try:
                function(*args)
            finally:
                with self.lock:
                    self.threads.discard(threading.current_thread())
        thread = threading.Thread(target=run, name='VRC-Eye-Peer', daemon=True)
        with self.lock:
            if self.stop.is_set():
                return
            self.threads.add(thread)
        thread.start()

    def _track(self, stream):
        with self.lock:
            if self.stop.is_set() or (self.relay_only and self.mode != 'Relay'):
                stream.close()
                raise RuntimeError('Peer transport closed or blocked by relay-only privacy')
            self.sockets.add(stream)
        return stream

    def _dispose(self, stream):
        if stream is None:
            return
        with self.lock:
            self.sockets.discard(stream)
        try:
            stream.shutdown(socket.SHUT_RDWR)
        except (OSError, ValueError):
            pass
        try:
            stream.close()
        except OSError:
            pass

    def _identity(self):
        with self.identity_lock:
            if self.identity is None:
                self.identity = _load_identity(self.directory)
            return self.identity

    def snapshot(self):
        with self.lock:
            peers = [{k: list(value) if k == 'capabilities' else value for k, value in peer.items() if k in (
                'peer_id', 'alias', 'version', 'capabilities', 'session', 'rtt_ms',
                'clock_offset_ms', 'clock_uncertainty_ms')} for peer in self.peers.values()]
            if self.mode == 'Relay':
                encryption = 'TLS; relay tunnel adds end-to-end pinned TLS'
                visibility = 'Relay sees endpoints; peers see relay only'
            elif self.mode in VPN_MODES:
                encryption = 'Pinned TLS between VRC Eye devices'
                visibility = ('Peers see virtual addresses; the VPN provider or direct VPN routing may also '
                              'expose physical endpoints. VPN routing is not observed.')
            elif self.mode == 'Private':
                encryption, visibility = 'No peer connection', 'No peer networking'
            else:
                encryption, visibility = 'Pinned TLS', 'Peers can see the selected network endpoint'
            return {'state': self.state, 'mode': self.mode, 'address': self.address,
                    'port': self.port, 'reason': self.reason,
                    'identity': self.identity['id'] if self.identity else '',
                    'peers': peers, 'relay_pin': self.relay_pin,
                    'relay_only': self.relay_only, 'provider': self.mode,
                    'source_address': self.source_address, 'source_selection': self.source_selection,
                    'network_path': 'Not observed; VRC Eye does not inspect the underlying VPN route',
                    'encryption': encryption, 'endpoint_visibility': visibility}

    def host(self, address, port=0, mode='LAN', *, alias='', relay_pin=''):
        if mode not in MODES:
            raise ValueError('Choose a supported connection mode')
        self._check_policy(mode)
        _endpoint(address, port)
        alias = _alias(alias)
        if mode == 'Relay' and (not port or not _HEX.fullmatch(relay_pin)):
            raise ValueError('Relay requires a port and certificate fingerprint')
        if mode != 'Relay':
            try:
                parsed = ipaddress.ip_address(address)
            except ValueError as exc:
                raise ValueError('Choose a local adapter IP address') from exc
            if parsed.is_unspecified or parsed.is_multicast:
                raise ValueError('Bind a specific local adapter address')
            _selected_host(mode, address)
        with self.lock:
            if self.stop.is_set() or self.state != 'PRIVATE':
                raise ValueError('Enter Private Mode before starting another connection')
            self._check_policy(mode)
            self.address, self.port, self.mode = address, port, mode
            self.source_address = address if mode != 'Relay' else ''
            self.source_selection = 'Explicit' if mode != 'Relay' else 'System route to relay'
            self.alias, self.relay_pin = _alias(alias), relay_pin
            self.state, self.reason = 'STARTING', ''
            self.generation += 1
        self._spawn(self._host_worker)
        return self.snapshot()

    def _open_socket(self, address, port, *, source_address='', mode):
        """Resolve then connect with cancellation checked before each OS action."""
        self._check_policy(mode)
        try:
            literal = ipaddress.ip_address(address)
        except ValueError:
            candidates = socket.getaddrinfo(address, port, type=socket.SOCK_STREAM)
        else:
            family = socket.AF_INET6 if literal.version == 6 else socket.AF_INET
            endpoint = (address, port, 0, 0) if family == socket.AF_INET6 else (address, port)
            candidates = [(family, socket.SOCK_STREAM, 0, '', endpoint)]
        # A privacy change while DNS was in flight must prevent the TCP attempt.
        self._check_policy(mode)
        source_family = (socket.AF_INET6 if ipaddress.ip_address(source_address).version == 6
                         else socket.AF_INET) if source_address else None
        for family, socktype, protocol, _, endpoint in candidates:
            if source_family and source_family != family:
                continue
            with self.lock:
                self._check_policy(mode)
                raw = self._track(socket.socket(family, socktype, protocol))
            try:
                raw.settimeout(HANDSHAKE_TIMEOUT)
                if source_address:
                    raw.bind((source_address, 0))
                self._check_policy(mode)
                # The tracked socket can be closed immediately if policy tightens.
                raw.connect(endpoint)
                self._check_policy(mode)
                return raw
            except Exception:
                self._dispose(raw)
                self._check_policy(mode)
        raise OSError('Unable to connect to the selected endpoint')

    def _connect_outer(self, address, port, pin):
        raw = self._open_socket(address, port, mode='Relay')
        stream = None
        try:
            stream = self._track(_client_context().wrap_socket(raw, server_hostname=address, do_handshake_on_connect=False))
            stream.do_handshake()
            with self.lock:
                self.sockets.discard(raw)
            _verify_pin(stream, pin)
            return stream
        except Exception:
            self._dispose(stream or raw)
            raise

    def _host_worker(self):
        try:
            self._check_policy(self.mode)
            self._identity()
            if self.mode == 'Relay':
                self._relay_host()
                return
            self._check_policy(self.mode)
            _selected_host(self.mode, self.address)
            family = socket.AF_INET6 if ':' in self.address else socket.AF_INET
            listener = self._track(socket.socket(family, socket.SOCK_STREAM))
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            listener.bind((self.address, self.port))
            listener.listen(MAX_PEERS)
            listener.settimeout(.25)
            with self.lock:
                self.listener = listener
                self.port = listener.getsockname()[1]
            self._status('LISTENING')
            while not self.stop.is_set():
                try:
                    raw, _ = listener.accept()
                except socket.timeout:
                    continue
                with self.lock:
                    accepted = self.handshakes + len(self.peers) < MAX_PEERS
                    if accepted:
                        self.handshakes += 1
                if not accepted:
                    raw.close()
                    continue
                raw.settimeout(HANDSHAKE_TIMEOUT)
                self._track(raw)
                self._spawn(self._accept, raw, False)
        except ImportError:
            self._status('ERROR', 'Install the optional cryptography package to enable networking')
        except Exception:
            self._status('ERROR', 'Unable to start the selected peer connection')
        finally:
            self._dispose(self.listener)

    def _relay_host(self):
        stream = self._connect_outer(self.address, self.port, self.relay_pin)
        with self.lock:
            self.listener = stream
            self.room = _b64(secrets.token_bytes(32))
        _send_frame(stream, {'op': 'host', 'room': self.room})
        reader = _FrameReader(stream)
        if reader.read() != {'op': 'ready'}:
            raise ValueError('Relay registration failed')
        stream.settimeout(.25)
        self._status('LISTENING')
        while not self.stop.is_set():
            try:
                request = reader.read()
            except socket.timeout:
                continue
            if set(request) != {'op', 'connection'} or request['op'] != 'incoming':
                raise ValueError('Invalid relay request')
            if not re.fullmatch(r'[0-9a-f]{32}', str(request['connection'])):
                raise ValueError('Invalid relay connection')
            with self.lock:
                if self.handshakes + len(self.peers) >= MAX_PEERS:
                    continue
                self.handshakes += 1
            self._spawn(self._relay_attach, request['connection'])

    def _relay_attach(self, connection):
        stream = None
        try:
            stream = self._connect_outer(self.address, self.port, self.relay_pin)
            _send_frame(stream, {'op': 'attach', 'room': self.room, 'connection': connection})
            if _FrameReader(stream).read() != {'op': 'paired'}:
                raise ValueError('Relay pairing failed')
            self._accept(stream, True)
            stream = None
        except Exception:
            self._emit({'type': 'status', 'state': self.state, 'reason': 'Relay peer handshake failed'})
            with self.lock:
                self.handshakes = max(0, self.handshakes - 1)
        finally:
            self._dispose(stream)

    def invite(self, ttl=600, *, peer_id=None):
        if type(ttl) not in (int, float) or not 1 <= ttl <= 3600:
            raise ValueError('Invitation lifetime must be 1–3600 seconds')
        if peer_id is not None and not re.fullmatch(r'eye_[0-9a-f]{64}', peer_id):
            raise ValueError('Invalid expected device identity')
        with self.lock:
            if self.state != 'LISTENING' or not self.identity or self.stop.is_set():
                raise ValueError('Start hosting before creating an invitation')
            self.invites = {key: item for key, item in self.invites.items() if item[0] > self.clock()}
            if len(self.invites) >= MAX_INVITES:
                raise ValueError('Too many active invitations; revoke invitations or wait for expiry')
            token = _b64(secrets.token_bytes(32))
            self.invites[hashlib.sha256(token.encode()).hexdigest()] = (self.clock() + ttl, peer_id)
            info = {'version': _PROTOCOL, 'mode': self.mode, 'address': self.address,
                    'port': self.port, 'pin': self.identity['pin'], 'key': self.identity['public'],
                    'token': token, 'expires': self.wall() + ttl}
            if self.mode == 'Relay':
                info.update(relay_pin=self.relay_pin, room=self.room)
        return INVITATION_PREFIX + _b64(_encode(info))

    def revoke_invites(self):
        with self.lock:
            self.invites.clear()

    def join(self, invitation, alias='', source_address=''):
        info = parse_invitation(invitation, now=self.wall())
        alias = _alias(alias)
        self._check_policy(info['mode'])
        selected = _selected_source(info['mode'], info['address'], source_address)
        if selected:
            info['source_address'] = selected
        with self.lock:
            if self.stop.is_set() or self.state != 'PRIVATE':
                raise ValueError('Enter Private Mode before starting another connection')
            self._check_policy(info['mode'])
            self.state, self.mode, self.reason = 'CONNECTING', info['mode'], ''
            self.address, self.port = info['address'], info['port']
            self.source_address = selected
            self.source_selection = ('Explicit' if source_address else 'Detected adapter' if selected
                                     else 'System route to relay' if self.mode == 'Relay' else 'System route')
            self.alias = _alias(alias)
            self.relay_pin = info.get('relay_pin', '')
        self._spawn(self._join_worker, info)
        return self.snapshot()

    def _validate_hello(self, body, op):
        if body.get('op') != op or type(body.get('protocol')) is not int or body.get('protocol') != _PROTOCOL:
            raise ValueError('Incompatible peer protocol')
        _alias(body.get('alias'))
        if body.get('version') != _VERSION:
            # Protocol compatibility permits other app versions; display their claim.
            if not isinstance(body.get('version'), str) or not re.fullmatch(r'[0-9A-Za-z._+-]{1,32}', body['version']):
                raise ValueError('Invalid peer version')
        capabilities = body.get('capabilities')
        if not isinstance(capabilities, list) or len(capabilities) > 128 or any(
                not isinstance(value, str) or not re.fullmatch(r'[a-zA-Z0-9._:-]{1,80}', value) for value in capabilities):
            raise ValueError('Invalid capabilities')
        _unb64(body.get('key'), 32)
        if not isinstance(body.get('session'), str) or not re.fullmatch(r'[0-9a-f]{32}', body['session']):
            raise ValueError('Invalid peer session')
        _unb64(body.get('nonce'), 32)

    def _accept(self, raw, nested):
        stream = None
        attached = False
        try:
            identity = self._identity()
            if nested:
                stream = self._track(_TLSStream(raw, identity['context'], server_side=True))
                stream.do_handshake()
            else:
                stream = self._track(identity['context'].wrap_socket(raw, server_side=True, do_handshake_on_connect=False))
                stream.do_handshake()
            with self.lock:
                self.sockets.discard(raw)
            session, nonce = uuid.uuid4().hex, _b64(secrets.token_bytes(32))
            hello = {'op': 'hello', 'protocol': _PROTOCOL, 'key': identity['public'],
                     'nonce': nonce, 'session': session, 'alias': self.alias,
                     'version': _VERSION, 'capabilities': _caps()}
            _send_frame(stream, _signed(identity, hello))
            reader = _FrameReader(stream, deadline=time.monotonic() + HANDSHAKE_TIMEOUT)
            auth = reader.read()
            body = _verify_signed(auth, auth.get('key'))
            self._validate_hello(body, 'auth')
            if set(body) != {'op', 'protocol', 'key', 'nonce', 'session', 'alias', 'version', 'capabilities', 'server_nonce', 'token'}:
                raise ValueError('Invalid authentication fields')
            peer_id = _device_id(_unb64(body['key'], 32))
            if body['session'] != session or body['server_nonce'] != nonce or peer_id == identity['id']:
                raise ValueError('Invalid handshake binding')
            _unb64(body['token'], 32)
            token_hash = hashlib.sha256(body['token'].encode()).hexdigest()
            with self.lock:
                grant = self.invites.get(token_hash)
                if not grant or grant[0] <= self.clock() or (grant[1] and grant[1] != peer_id):
                    raise ValueError('Invitation expired, consumed or not intended for this device')
                if peer_id in self.peers:
                    raise ValueError('Device already connected')
                del self.invites[token_hash]
            _send_frame(stream, _signed(identity, {'op': 'ready', 'session': session, 'nonce': body['nonce']}))
            reader.deadline = None
            with self.lock:
                self.handshakes = max(0, self.handshakes - 1)
            attached = True
            self._connection(stream, reader, peer_id, body)
        except Exception:
            self._emit({'type': 'status', 'state': self.state, 'reason': 'Peer authentication or connection failed'})
        finally:
            if not attached:
                with self.lock:
                    self.handshakes = max(0, self.handshakes - 1)
            self._dispose(stream or raw)

    def _join_worker(self, info):
        raw = stream = None
        try:
            self._check_policy(info['mode'])
            identity = self._identity()
            if info['mode'] == 'Relay':
                raw = self._connect_outer(info['address'], info['port'], info['relay_pin'])
                _send_frame(raw, {'op': 'join', 'room': info['room']})
                if _FrameReader(raw).read() != {'op': 'paired'}:
                    raise ValueError('Relay invitation unavailable')
                stream = self._track(_TLSStream(raw, _client_context(), hostname=info['address']))
                stream.do_handshake()
            else:
                self._check_policy(info['mode'])
                _selected_source(info['mode'], info['address'], info.get('source_address', ''))
                raw = self._open_socket(info['address'], info['port'],
                    source_address=info.get('source_address', ''), mode=info['mode'])
                if not info.get('source_address'):
                    with self.lock:
                        self.source_address = raw.getsockname()[0]
                stream = self._track(_client_context().wrap_socket(raw, server_hostname=info['address'], do_handshake_on_connect=False))
                stream.do_handshake()
            with self.lock:
                self.sockets.discard(raw)
            _verify_pin(stream, info['pin'])
            reader = _FrameReader(stream, deadline=time.monotonic() + HANDSHAKE_TIMEOUT)
            hello = reader.read()
            body = _verify_signed(hello, info['key'])
            self._validate_hello(body, 'hello')
            if set(body) != {'op', 'protocol', 'key', 'nonce', 'session', 'alias', 'version', 'capabilities'} or body['key'] != info['key']:
                raise ValueError('Host identity does not match invitation')
            peer_id = _device_id(_unb64(body['key'], 32))
            if peer_id == identity['id']:
                raise ValueError('Cannot connect a device to itself')
            nonce = _b64(secrets.token_bytes(32))
            auth = {'op': 'auth', 'protocol': _PROTOCOL, 'key': identity['public'], 'nonce': nonce,
                    'session': body['session'], 'alias': self.alias, 'version': _VERSION,
                    'capabilities': _caps(), 'server_nonce': body['nonce'], 'token': info['token']}
            _send_frame(stream, _signed(identity, auth))
            ready = _verify_signed(reader.read(), info['key'])
            if ready != {'op': 'ready', 'session': body['session'], 'nonce': nonce}:
                raise ValueError('Host authentication failed')
            reader.deadline = None
            self._status('CONNECTED')
            self._connection(stream, reader, peer_id, body)
        except ImportError:
            self._status('ERROR', 'Install the optional cryptography package to enable networking')
        except Exception:
            self._status('ERROR', 'Connection failed: check the invitation, certificate fingerprint, network and host')
        finally:
            self._dispose(stream or raw)

    def _connection(self, stream, reader, peer_id, hello):
        peer = {'peer_id': peer_id, 'alias': hello['alias'], 'version': hello['version'],
                'capabilities': sorted(set(_caps()) & set(hello['capabilities'])),
                'session': hello['session'], 'queue': queue.Queue(maxsize=128), 'stream': stream,
                'stop': threading.Event(), 'rtt_ms': None, 'clock_offset_ms': None, 'clock_uncertainty_ms': None}
        with self.lock:
            if self.stop.is_set() or peer_id in self.peers or len(self.peers) >= MAX_PEERS:
                raise ValueError('Peer connection unavailable')
            self.peers[peer_id] = peer
        sent_seq = received_seq = 0
        awaiting, pings = {}, {}
        recent = collections.deque()
        last_receive = self.clock()
        next_ping = 0.0
        partial_since = None
        try:
            if not self._emit({'type': 'connected', **{key: peer[key] for key in (
                    'peer_id', 'alias', 'version', 'capabilities', 'session')}}):
                raise ValueError('Peer receiver unavailable')
            stream.settimeout(.2)
            while not self.stop.is_set() and not peer['stop'].is_set():
                now = self.clock()
                if now - last_receive > 45:
                    raise TimeoutError('Peer connection timed out')
                if reader.buffer:
                    partial_since = partial_since or now
                    if now - partial_since > HANDSHAKE_TIMEOUT:
                        raise TimeoutError('Incomplete frame timeout')
                else:
                    partial_since = None
                for _ in range(16):
                    if len(awaiting) >= 256:
                        break
                    try:
                        message = peer['queue'].get_nowait()
                    except queue.Empty:
                        break
                    sent_seq += 1
                    _send_frame(stream, {'op': 'data', 'seq': sent_seq, 'message': message})
                    message_id = message.get('message_id')
                    if isinstance(message_id, str):
                        awaiting[message_id] = now
                awaiting = {key: stamp for key, stamp in awaiting.items() if now - stamp < 60}
                if now >= next_ping:
                    stamp = secrets.token_hex(8)
                    pings = {stamp: (now, self.wall())}
                    _send_frame(stream, {'op': 'ping', 'id': stamp})
                    next_ping = now + 15
                try:
                    frame = reader.read()
                except socket.timeout:
                    continue
                last_receive = self.clock()
                recent.append(last_receive)
                while recent and last_receive - recent[0] > 10:
                    recent.popleft()
                if len(recent) > 400:
                    raise ValueError('Peer rate limit exceeded')
                op = frame.get('op')
                if op == 'data' and set(frame) == {'op', 'seq', 'message'}:
                    message = frame['message']
                    if type(frame['seq']) is not int or frame['seq'] != received_seq + 1 or not isinstance(message, dict):
                        raise ValueError('Invalid message sequence')
                    if (message.get('sender') != peer_id or message.get('recipient') != self.identity['id']
                            or message.get('session') != peer['session']):
                        raise ValueError('Message identity or session mismatch')
                    if len(_encode(message)) > 65536:
                        raise ValueError('Peer envelope too large')
                    received_seq += 1
                    if not self._emit({'type': 'message', 'peer_id': peer_id, 'message': message}):
                        raise ValueError('Peer receiver unavailable')
                    mid = message.get('message_id')
                    if isinstance(mid, str) and len(mid) <= 128:
                        _send_frame(stream, {'op': 'ack', 'id': mid})
                elif op == 'ack' and set(frame) == {'op', 'id'}:
                    mid = frame['id']
                    if not isinstance(mid, str) or len(mid) > 128:
                        raise ValueError('Invalid receipt')
                    started = awaiting.pop(mid, None)
                    if started is not None:
                        self._emit({'type': 'delivered', 'peer_id': peer_id, 'message_id': mid,
                                    'rtt_ms': max(0, (self.clock() - started) * 1000)})
                elif op == 'ping' and set(frame) == {'op', 'id'} and re.fullmatch(r'[0-9a-f]{16}', str(frame['id'])):
                    _send_frame(stream, {'op': 'pong', 'id': frame['id'], 'time': self.wall()})
                elif op == 'pong' and set(frame) == {'op', 'id', 'time'}:
                    if not isinstance(frame['id'], str) or type(frame['time']) not in (int, float):
                        raise ValueError('Invalid timing response')
                    stamp = pings.pop(frame['id'], None)
                    if stamp:
                        rtt = max(0, self.clock() - stamp[0])
                        offset = frame['time'] - (stamp[1] + self.wall()) / 2
                        if not -86400 <= offset <= 86400:
                            raise ValueError('Peer clock is outside the supported range')
                        with self.lock:
                            peer.update(rtt_ms=rtt * 1000, clock_offset_ms=offset * 1000,
                                        clock_uncertainty_ms=rtt * 500)
                        self._emit({'type': 'latency', 'peer_id': peer_id, 'rtt_ms': rtt * 1000,
                                    'clock_offset_ms': offset * 1000, 'clock_uncertainty_ms': rtt * 500})
                else:
                    raise ValueError('Unsupported transport frame')
        except Exception:
            if not self.stop.is_set() and not peer['stop'].is_set():
                self._emit({'type': 'status', 'state': self.state, 'reason': 'A peer disconnected or sent an invalid frame'})
        finally:
            status_event = None
            with self.lock:
                if self.peers.get(peer_id) is peer:
                    del self.peers[peer_id]
                # Publish the peer removal and final state atomically. Socket
                # shutdown may yield; snapshots must not show CONNECTED with
                # the last peer already removed during that interval.
                if not self.stop.is_set() and not self.peers and self.state == 'CONNECTED':
                    self.state, self.reason = 'DISCONNECTED', 'Reconnect requires a new invitation'
                    status_event = {'type': 'status', 'state': self.state, 'reason': self.reason}
            self._dispose(stream)
            self._emit({'type': 'disconnected', 'peer_id': peer_id, 'session': peer['session']})
            # Closing from the UI supersedes the captured disconnect status.
            if status_event is not None and not self.stop.is_set():
                self._emit(status_event)
        return True

    def send(self, peer_id, envelope):
        if not isinstance(envelope, dict) or len(_encode(envelope)) > 65536:
            raise ValueError('Invalid peer message')
        with self.lock:
            peer = self.peers.get(peer_id)
            if self.stop.is_set() or not peer or peer['stop'].is_set():
                raise ValueError('Peer is not connected')
            if (envelope.get('sender') != self.identity['id'] or envelope.get('recipient') != peer_id
                    or envelope.get('session') != peer['session']):
                raise ValueError('Outgoing message identity or session mismatch')
            try:
                # Deep copy prevents caller mutations after validation/queuing.
                peer['queue'].put_nowait(_json(_encode(envelope)))
            except queue.Full as exc:
                raise ValueError('Peer send queue is full') from exc
        return True

    def disconnect(self, peer_id):
        with self.lock:
            peer = self.peers.get(peer_id)
            if peer:
                peer['stop'].set()
                stream = peer['stream']
            else:
                stream = None
        self._dispose(stream)

    def close(self):
        self.stop.set()
        with self.lock:
            self.invites.clear()
            for peer in self.peers.values():
                peer['stop'].set()
            streams = list(self.sockets)
            self.state, self.mode, self.reason = 'PRIVATE', 'Private', ''
            self.source_address, self.source_selection = '', 'None'
        for stream in streams:
            self._dispose(stream)
        # GUI-safe: workers are interrupted by socket close, never joined on Tk.

    def wait_closed(self, timeout=2.0):
        """Optional test/CLI teardown helper; never called by the GUI."""
        deadline = time.monotonic() + timeout
        while True:
            with self.lock:
                threads = list(self.threads)
            if not threads or time.monotonic() >= deadline:
                return not threads
            for thread in threads:
                thread.join(max(0, min(.1, deadline - time.monotonic())))
