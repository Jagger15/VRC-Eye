"""Bounded, read-only OSCQuery inspection, passive discovery and subscriptions.

Discovery never grants write permission, changes a transport destination or
sends a visible VRChat control. The HTTP subscription server contains no user
values; enabling tracking subscriptions is a separate explicit choice.
"""
from collections import deque
from copy import deepcopy
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import math
import socket
import socketserver
import threading
import time
from urllib.parse import urlsplit
import uuid

from osc_transport import OSCError, MAX_ARGUMENTS, literal_host, port, validate_address

MAX_DOCUMENT = 524288
MAX_NODES = 2048
QUERY_SERVICE = "_oscjson._tcp.local."
OSC_SERVICE = "_osc._udp.local."
_KINDS = {"i": "Int", "f": "Float", "T": "Bool", "F": "Bool", "s": "String"}


def _document(raw):
    if type(raw) is not bytes or len(raw) > MAX_DOCUMENT:
        raise OSCError("OSCQuery document exceeds the size limit.")

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate object key")
            result[key] = value
        return result

    try:
        doc = json.loads(raw, object_pairs_hook=pairs,
                         parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (ValueError, UnicodeError, RecursionError):
        raise OSCError("Invalid OSCQuery JSON document.") from None
    if type(doc) is not dict:
        raise OSCError("OSCQuery document must be an object.")
    count = [0]

    def bounded(value, depth):
        count[0] += 1
        if depth > 32 or count[0] > 32768:
            raise OSCError("OSCQuery JSON complexity exceeds the limit.")
        if isinstance(value, dict):
            for key, item in value.items():
                if len(key) > 1024:
                    raise OSCError("OSCQuery object key exceeds the limit.")
                try:
                    key.encode("utf-8")
                except UnicodeError:
                    raise OSCError("OSCQuery object key is invalid Unicode.") from None
                bounded(item, depth + 1)
        elif isinstance(value, list):
            for item in value:
                bounded(item, depth + 1)
        elif isinstance(value, str):
            if len(value) > 8192:
                raise OSCError("OSCQuery string exceeds the limit.")
            try:
                value.encode("utf-8")
            except UnicodeError:
                raise OSCError("OSCQuery string is invalid Unicode.") from None
        elif type(value) is float and not math.isfinite(value):
            raise OSCError("Non-finite OSCQuery value.")
    bounded(doc, 0)
    return doc


def _url(url, allow_lan):
    try:
        parsed = urlsplit(url)
        endpoint_port = parsed.port
        endpoint_host = parsed.hostname
    except (ValueError, TypeError):
        raise OSCError("Use an explicit http://IPv4:PORT/ OSCQuery URL.") from None
    if parsed.scheme != "http" or parsed.username or parsed.password or parsed.fragment or parsed.query or parsed.path not in ("", "/") or endpoint_port is None:
        raise OSCError("Use an explicit http://IPv4:PORT/ OSCQuery URL without a path or query.")
    host = literal_host(endpoint_host, allow_lan=allow_lan)
    return host, port(endpoint_port)


def _get(host, endpoint_port, path, timeout):
    connection = http.client.HTTPConnection(host, endpoint_port, timeout=timeout)
    timer = None
    try:
        connection.connect()
        request_socket = connection.sock

        def deadline():
            try:
                request_socket.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

        timer = threading.Timer(timeout, deadline)
        timer.daemon = True
        timer.start()
        connection.request("GET", path, headers={"Accept": "application/json", "Connection": "close"})
        response = connection.getresponse()
        if response.status != 200:
            raise OSCError("OSCQuery did not return HTTP 200; redirects are not followed.")
        length = response.getheader("Content-Length")
        if length is not None and (not length.isdigit() or int(length) > MAX_DOCUMENT):
            raise OSCError("OSCQuery document exceeds the size limit.")
        if response.getheader("Content-Encoding", "identity").lower() != "identity":
            raise OSCError("Compressed OSCQuery responses are not accepted.")
        return _document(response.read(MAX_DOCUMENT + 1))
    except (OSError, http.client.HTTPException, ValueError) as exc:
        if isinstance(exc, OSCError):
            raise
        raise OSCError("OSCQuery inspection failed: " + str(exc)[:180]) from None
    finally:
        if timer is not None:
            timer.cancel()
        connection.close()


def describe_tree(tree):
    """Return advertised declarations, preserving unsupported types as evidence."""
    endpoints, visits, seen = [], [0], set()

    def visit(node, depth, expected):
        visits[0] += 1
        if type(node) is not dict or depth > 16 or visits[0] > MAX_NODES:
            raise OSCError("OSCQuery tree exceeds the node or nesting limit.")
        address = node.get("FULL_PATH", expected)
        if address != "/":
            validate_address(address)
        if address != expected or address in seen:
            raise OSCError("OSCQuery contains inconsistent or duplicate paths.")
        seen.add(address)
        tags = node.get("TYPE")
        if tags is not None:
            if type(tags) is not str or len(tags) > MAX_ARGUMENTS:
                raise OSCError("Invalid OSCQuery type description.")
            access = node.get("ACCESS")
            if access is not None and (type(access) is not int or access not in (0, 1, 2, 3)):
                raise OSCError("Invalid OSCQuery access flags.")
            item = {"address": address, "tags": tags, "types": tuple(_KINDS.get(t, "Unsupported") for t in tags),
                    "supported_types": all(t in _KINDS for t in tags), "access": access,
                    "description": str(node.get("DESCRIPTION", ""))[:1024],
                    "evidence": "advertised", "read_only": True}
            if len(item["types"]) == 1:
                item["type"] = item["types"][0]
            for name in ("VALUE", "RANGE", "UNIT"):
                if name in node:
                    item[name.lower()] = deepcopy(node[name])
            endpoints.append(item)
        children = node.get("CONTENTS", {})
        if type(children) is not dict or len(children) > MAX_NODES:
            raise OSCError("Invalid OSCQuery contents.")
        for key, child in children.items():
            if not key or "/" in key:
                raise OSCError("Invalid OSCQuery child name.")
            path = ("" if address == "/" else address) + "/" + key
            visit(child, depth + 1, path)

    visit(tree, 0, "/")
    return endpoints


def query_endpoint(url, *, allow_lan=False, timeout=1.5):
    """Read HOST_INFO and namespace for one explicitly selected literal address."""
    if type(allow_lan) is not bool or type(timeout) not in (int, float) or not 0.1 <= timeout <= 5:
        raise OSCError("Invalid OSCQuery inspection options.")
    host, endpoint_port = _url(url, allow_lan)
    info = _get(host, endpoint_port, "/?HOST_INFO", timeout)
    if info.get("OSC_TRANSPORT", "UDP") != "UDP":
        raise OSCError("This service does not advertise UDP OSC.")
    osc_host = literal_host(info.get("OSC_IP", host), allow_lan=allow_lan)
    osc_port = port(info.get("OSC_PORT", endpoint_port))
    tree = _get(host, endpoint_port, "/", timeout)
    endpoints = describe_tree(tree)
    return {"endpoint": "http://%s:%d/" % (host, endpoint_port), "host_info": info,
            "name": str(info.get("NAME", "Unnamed OSCQuery service"))[:256],
            "osc_host": osc_host, "osc_port": osc_port, "endpoints": endpoints,
            "parameters": [item for item in endpoints if item["address"].startswith("/avatar/parameters/")],
            "source": "OSCQuery", "read_only": True,
            "notice": "Advertised descriptions are untrusted evidence, not permission or proof that a write succeeded."}


class OSCDiscovery:
    """Nonblocking candidate discovery and explicitly selected HTTP inspections.

    ``start`` enables passive mDNS discovery. ``inspect(url)`` and
    ``select(candidate_id)`` enqueue read-only HTTP work and return immediately.
    ``snapshot()`` returns copies; ``description`` is the current selected result.
    Starting discovery or learning one candidate never selects it automatically.
    """
    def __init__(self, clock=time.monotonic, *, allow_lan=False, context_provider=None):
        if type(allow_lan) is not bool:
            raise OSCError("LAN discovery setting must be a boolean.")
        if context_provider is not None and not callable(context_provider):
            raise OSCError("Discovery context provider must be callable.")
        self.clock, self.allow_lan = clock, allow_lan
        self.context_provider = context_provider
        self._description_context = None
        self._description_started_at = None
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._jobs = deque(maxlen=64)
        self._candidates = {}
        self._description = None
        self._selected = ""
        self._request = 0
        self._generation = 0
        self._state = "Stopped"
        self._error = ""
        self._available = False
        self._last_checked = None
        self.dropped = 0

    @property
    def description(self):
        with self._lock:
            return deepcopy(self._description)

    def start(self):
        with self._lock:
            if self._thread is not None and self._thread.is_alive() and not self._stop.is_set():
                return
            self._generation += 1
            self._stop = threading.Event()
            self._state, self._error = "Discovering", ""
            self._thread = threading.Thread(target=self._run, args=(self._stop, self._generation),
                                            daemon=True, name="VRC Eye OSCQuery discovery")
            self._thread.start()

    def _queue(self, job):
        with self._lock:
            if len(self._jobs) == self._jobs.maxlen:
                self.dropped += 1
                return False
            self._jobs.append(job)
            self._wake.set()
            return True

    def inspect(self, url):
        _url(url, self.allow_lan)
        # Capture the application generation when work is requested, not when
        # its HTTP response eventually arrives. A delayed response can describe
        # an avatar that was replaced while this request was in flight.
        context = deepcopy(self.context_provider()) if self.context_provider is not None else None
        started_at = self.clock()
        self.start()
        with self._lock:
            self._request += 1
            token = self._request
            self._description = None
            self._description_context = None
            self._description_started_at = None
            self._selected = str(url)
            self._state, self._error = "Loading description", ""
            if not self._queue(("inspect", token, str(url), context, started_at)):
                self._state = "Degraded"
                raise OSCError("Discovery queue is full; try again after it drains.")
        return token

    def select(self, candidate_id):
        with self._lock:
            candidate = self._candidates.get(candidate_id)
            if candidate is None:
                raise OSCError("This OSCQuery candidate is no longer available.")
            token = self.inspect(candidate["url"])
            self._selected = candidate_id
            return token

    def refresh(self):
        with self._lock:
            selected = self._selected
            candidate = self._candidates.get(selected)
            if candidate:
                return self.select(selected)
            if selected.startswith("http://"):
                return self.inspect(selected)
        raise OSCError("Choose an OSCQuery instance first.")

    def _run(self, stop, generation):
        zc = browser = None
        try:
            try:
                from zeroconf import IPVersion, ServiceBrowser, Zeroconf
                options = {"ip_version": IPVersion.V4Only}
                if not self.allow_lan:
                    options["interfaces"] = ["127.0.0.1"]
                zc = Zeroconf(**options)
                owner = self

                class Listener:
                    def add_service(self, service, kind, name):
                        if not stop.is_set():
                            owner._queue(("add", kind, name))
                    update_service = add_service

                    def remove_service(self, service, kind, name):
                        if not stop.is_set():
                            owner._queue(("remove", kind, name))

                browser = ServiceBrowser(zc, QUERY_SERVICE, Listener())
                with self._lock:
                    if generation == self._generation:
                        self._available = True
            except Exception as exc:
                with self._lock:
                    if generation == self._generation:
                        self._available = False
                        self._error = "Automatic discovery unavailable; manual OSCQuery remains available. " + str(exc)[:180]
                        if self._state == "Discovering":
                            self._state = "Manual fallback"
            while not stop.is_set():
                with self._lock:
                    job = self._jobs.popleft() if self._jobs else None
                if job is None:
                    self._wake.wait(0.15)
                    self._wake.clear()
                    continue
                if job[0] == "inspect":
                    _, token, url, context, started_at = job
                    with self._lock:
                        if token != self._request:
                            continue
                    try:
                        description = query_endpoint(url, allow_lan=self.allow_lan)
                        error = ""
                    except OSCError as exc:
                        description, error = None, str(exc)
                    with self._lock:
                        if token == self._request and generation == self._generation and not stop.is_set():
                            self._description = description
                            self._description_context = deepcopy(context) if description is not None else None
                            self._description_started_at = started_at if description is not None else None
                            self._error = error
                            self._state = "Description loaded" if description else "Degraded"
                            self._last_checked = self.clock()
                else:
                    _, kind, name = job
                    identifier = hashlib.sha256(name.encode("utf-8", errors="replace")).hexdigest()[:24]
                    if job[0] == "remove":
                        with self._lock:
                            if generation != self._generation or stop.is_set():
                                continue
                            self._candidates.pop(identifier, None)
                            if self._selected == identifier:
                                self._request += 1
                                self._description = None
                                self._description_context = None
                                self._description_started_at = None
                                self._state = "Service lost"
                        continue
                    if zc is None or len(name) > 256:
                        continue
                    try:
                        info = zc.get_service_info(kind, name, timeout=250)
                        if info is None:
                            continue
                        addresses = []
                        for address in info.parsed_addresses():
                            try:
                                addresses.append(literal_host(address, allow_lan=self.allow_lan))
                            except OSCError:
                                continue
                        if not addresses:
                            continue
                        host = "127.0.0.1" if "127.0.0.1" in addresses else addresses[0]
                        service_port = port(info.port)
                    except Exception:
                        continue
                    with self._lock:
                        if generation != self._generation or stop.is_set():
                            continue
                        if len(self._candidates) >= 64 and identifier not in self._candidates:
                            self.dropped += 1
                            continue
                        self._candidates[identifier] = {"id": identifier, "name": name[:256], "host": host,
                            "port": service_port, "url": "http://%s:%d/" % (host, service_port),
                            "last_seen": self.clock(), "evidence": "mDNS advertisement, unauthenticated"}
                        if self._state in ("Discovering", "Manual fallback"):
                            self._state = "Service found"
        finally:
            if browser is not None:
                try:
                    browser.cancel()
                except Exception:
                    pass
            if zc is not None:
                try:
                    zc.close()
                except Exception:
                    pass

    def stop(self):
        with self._lock:
            self._stop.set()
            self._wake.set()
            self._generation += 1
            self._request += 1
            self._jobs.clear()
            self._candidates.clear()
            self._description = None
            self._description_context = None
            self._description_started_at = None
            self._selected = ""
            self._state = "Stopped"
            self._available = False
            thread, self._thread = self._thread, None
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=0.3)

    close = stop

    def snapshot(self):
        with self._lock:
            return {"state": self._state, "available": self._available, "error": self._error,
                    "selected": self._selected, "candidates": deepcopy(list(self._candidates.values())),
                    "description": deepcopy(self._description), "last_checked": self._last_checked,
                    "description_context": deepcopy(self._description_context),
                    "description_started_at": self._description_started_at,
                    "generation": self._generation, "queued": len(self._jobs), "dropped": self.dropped,
                    "allow_lan": self.allow_lan,
                    "notice": "Discovery is read-only; choose an instance explicitly. Windows VRChat query information is normally local to that computer."}


class _BoundedHTTPServer(socketserver.ThreadingMixIn, HTTPServer):
    daemon_threads = True
    block_on_close = False
    allow_reuse_address = False
    request_queue_size = 8

    def __init__(self, address, handler):
        self._slots = threading.BoundedSemaphore(4)
        super().__init__(address, handler)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()


class OSCQueryServer:
    """Read-only subscription tree; advertisement is optional and asynchronous.

    ``start`` returns the bound HTTP port. The UDP endpoint belongs to SharedOSC;
    this server never creates another UDP control receiver. Default publication
    is loopback only. Tracking-system subscription needs ``tracking=True``.
    """
    def __init__(self, *, name="VRC Eye", clock=time.monotonic):
        if type(name) is not str or not 1 <= len(name) <= 48 or any(ord(c) < 32 or c == "." for c in name):
            raise OSCError("Use a short service name without periods or control characters.")
        self.name, self.clock = name, clock
        self._lock = threading.RLock()
        self._server = self._thread = self._advertise_thread = None
        self._stop = threading.Event()
        self._generation = 0
        self.http_port = self.osc_port = 0
        self.receive_host = "127.0.0.1"
        self.tracking = self.advertised = False
        self.error = ""

    @property
    def running(self):
        return self._server is not None and not self._stop.is_set()

    def start(self, osc_port, http_port=0, receive_host="127.0.0.1", allow_lan=False,
              tracking=False, advertise=True):
        osc_port, http_port = port(osc_port), port(http_port, ephemeral=True)
        if any(type(value) is not bool for value in (allow_lan, tracking, advertise)):
            raise OSCError("OSCQuery options must be booleans.")
        host = literal_host(receive_host, allow_lan=allow_lan)
        self.stop()
        tree = {"FULL_PATH": "/", "ACCESS": 0, "CONTENTS": {"avatar": {"FULL_PATH": "/avatar", "ACCESS": 0, "CONTENTS": {}}}}
        if tracking:
            tree["CONTENTS"]["tracking"] = {"FULL_PATH": "/tracking", "ACCESS": 0, "CONTENTS": {
                "vrsystem": {"FULL_PATH": "/tracking/vrsystem", "ACCESS": 0, "CONTENTS": {}}}}
        host_info = {"NAME": self.name, "OSC_IP": host, "OSC_PORT": osc_port, "OSC_TRANSPORT": "UDP",
                     "EXTENSIONS": {"ACCESS": True, "VALUE": False}}

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = "VRC-Eye-OSCQuery"
            sys_version = ""

            def setup(self):
                super().setup()
                self.connection.settimeout(1.0)
                self._timer = threading.Timer(2.0, self._deadline)
                self._timer.daemon = True
                self._timer.start()

            def _deadline(self):
                try:
                    self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            def finish(self):
                self._timer.cancel()
                super().finish()

            def log_message(self, *args):
                pass

            def do_GET(self):
                if len(self.path) > 2048:
                    self.send_error(414)
                    return
                parsed = urlsplit(self.path)
                if parsed.netloc or parsed.scheme:
                    self.send_error(400)
                    return
                if parsed.query == "HOST_INFO":
                    value = host_info
                else:
                    value = tree
                    path = parsed.path or "/"
                    for component in path.strip("/").split("/") if path != "/" else ():
                        value = value.get("CONTENTS", {}).get(component)
                        if value is None:
                            self.send_error(404)
                            return
                    if parsed.query:
                        if parsed.query not in value:
                            self.send_response(204)
                            self.send_header("Connection", "close")
                            self.end_headers()
                            self.close_connection = True
                            return
                        value = {parsed.query: value[parsed.query]}
                raw = json.dumps(value, ensure_ascii=True, separators=(",", ":")).encode("ascii")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(raw)
                self.close_connection = True

        try:
            server = _BoundedHTTPServer((host, http_port), Handler)
        except OSError as exc:
            raise OSCError("OSCQuery HTTP port is unavailable: " + str(exc)) from None
        with self._lock:
            self._server = server
            self._stop = threading.Event()
            self._generation += 1
            self.http_port, self.osc_port = server.server_address[1], osc_port
            self.receive_host, self.tracking = host, tracking
            self.error, self.advertised = "", False
            self._thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True, name="VRC Eye OSCQuery HTTP")
            self._thread.start()
            if advertise:
                self._advertise_thread = threading.Thread(target=self._advertise,
                    args=(self._stop, self._generation, host, self.http_port, osc_port),
                    daemon=True, name="VRC Eye OSCQuery advertisement")
                self._advertise_thread.start()
        return self.http_port

    def _advertise(self, stop, generation, host, http_port, osc_port):
        zc = None
        registered = []
        try:
            from zeroconf import IPVersion, ServiceInfo, Zeroconf
            zc = Zeroconf(interfaces=[host], ip_version=IPVersion.V4Only)
            instance = self.name + "-" + uuid.uuid4().hex[:8]
            for kind, service_port in ((QUERY_SERVICE, http_port), (OSC_SERVICE, osc_port)):
                if stop.is_set():
                    return
                info = ServiceInfo(kind, instance + "." + kind, addresses=[socket.inet_aton(host)],
                                   port=service_port, properties={}, server=instance + ".local.")
                zc.register_service(info)
                registered.append(info)
            with self._lock:
                if generation == self._generation and not stop.is_set():
                    self.advertised = True
            stop.wait()
        except Exception as exc:
            with self._lock:
                if generation == self._generation and not stop.is_set():
                    self.error = "Automatic subscription advertisement unavailable; configure the receive port manually. " + str(exc)[:160]
        finally:
            if zc is not None:
                for info in registered:
                    try:
                        zc.unregister_service(info)
                    except Exception:
                        pass
                try:
                    zc.close()
                except Exception:
                    pass

    def stop(self):
        with self._lock:
            self._stop.set()
            self._generation += 1
            server, self._server = self._server, None
            thread, self._thread = self._thread, None
            advertiser, self._advertise_thread = self._advertise_thread, None
            self.advertised = False
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=0.3)
        if advertiser is not None and advertiser is not threading.current_thread():
            advertiser.join(timeout=0.1)

    close = stop

    def snapshot(self):
        with self._lock:
            return {"running": self.running, "http_port": self.http_port, "osc_port": self.osc_port,
                    "host": self.receive_host, "advertised": self.advertised, "tracking": self.tracking,
                    "generation": self._generation, "error": self.error,
                    "subscriptions": ["/avatar"] + (["/tracking/vrsystem"] if self.tracking else []),
                    "notice": "Tracking-system output also needs VRChat's in-client approval; subscription metadata grants no write authority."}
