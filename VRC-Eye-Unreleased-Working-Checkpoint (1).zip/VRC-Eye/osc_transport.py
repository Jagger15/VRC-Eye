"""Strict OSC wire types and one bounded UDP endpoint for the shared service.

Importing this module never opens a socket. This transport does not authorize
commands; the shared action service must do that before calling ``send``.
UDP send completion is transmission evidence, never application confirmation.
"""
from collections import deque
from dataclasses import dataclass
import ipaddress
import math
import re
import socket
import struct
import threading
import time

MAX_PACKET = 49152
MAX_MESSAGES = 128
MAX_ARGUMENTS = 64
MAX_STRING = 32768  # Includes reviewed, bounded native Dolly path JSON.


class OSCError(ValueError):
    """Rejected OSC configuration, wire data, or transport operation."""


def port(value, *, ephemeral=False):
    if isinstance(value, bool) or not re.fullmatch(r"[0-9]{1,5}", str(value)):
        raise OSCError("Port must be an integer from 1 to 65535.")
    number = int(value)
    if not (0 if ephemeral else 1) <= number <= 65535:
        raise OSCError("Port must be an integer from 1 to 65535.")
    return number


def literal_host(value, *, allow_lan=False, bind=False):
    """Accept explicit IPv4 addresses; never perform name resolution.

    LAN mode permits explicitly configured unicast addresses (including VPN
    address ranges). It does not make the listening interface public implicitly.
    """
    if not isinstance(value, str) or len(value) > 15:
        raise OSCError("Use a literal IPv4 address.")
    try:
        address = ipaddress.IPv4Address(value)
    except ipaddress.AddressValueError:
        raise OSCError("Use a literal IPv4 address, such as 127.0.0.1.") from None
    if address.is_multicast or address == ipaddress.IPv4Address("255.255.255.255"):
        raise OSCError("Multicast and broadcast OSC destinations are not supported.")
    if address.is_unspecified and not (bind and allow_lan):
        raise OSCError("An unspecified address is only allowed for explicitly enabled LAN listening.")
    if not address.is_loopback and not allow_lan:
        raise OSCError("Enable and review LAN access before using a non-loopback address.")
    return str(address)


def validate_address(value):
    if not isinstance(value, str):
        raise OSCError("OSC address must be text.")
    try:
        size = len(value.encode("utf-8"))
    except UnicodeError:
        raise OSCError("OSC address must be valid Unicode.") from None
    if size > 1024:
        raise OSCError("OSC address is too long.")
    if not value.startswith("/") or value == "/" or "//" in value:
        raise OSCError("Use a literal OSC method address.")
    # OSC pattern syntax is deliberately excluded: a control has one destination.
    if any(ord(c) < 33 or ord(c) == 127 or c in "#*,?[]{}\\" for c in value):
        raise OSCError("OSC address must be literal and contain no control characters.")
    return value


def _string(value):
    if type(value) is not str or "\0" in value:
        raise OSCError("OSC strings must be text without embedded NUL characters.")
    try:
        raw = value.encode("utf-8")
    except UnicodeError:
        raise OSCError("OSC strings must be valid Unicode.") from None
    if len(raw) > MAX_STRING:
        raise OSCError("OSC string exceeds the size limit.")
    raw += b"\0"
    return raw + b"\0" * (-len(raw) % 4)


@dataclass(frozen=True)
class OSCMessage:
    address: str
    args: tuple
    types: tuple

    @property
    def value(self):
        return self.args[0] if len(self.args) == 1 else self.args

    @property
    def kind(self):
        return self.types[0] if len(self.types) == 1 else "Multi"

    @property
    def type(self):
        return self.kind

    @property
    def tags(self):
        return "".join(
            ("T" if value else "F") if kind == "Bool" else {"Int": "i", "Float": "f", "String": "s"}[kind]
            for kind, value in zip(self.types, self.args))


def encode_message(address, args=()):
    """Encode exact Python Bool, signed Int32, finite Float32 and UTF-8 String.

    A tuple/list is required even for a single argument. There are no implicit
    numeric or string conversions. Multi-argument messages keep their types.
    """
    validate_address(address)
    if not isinstance(args, (tuple, list)) or len(args) > MAX_ARGUMENTS:
        raise OSCError("OSC arguments must be a bounded tuple or list.")
    tags, parts = [], []
    for value in args:
        if type(value) is bool:
            tags.append("T" if value else "F")
        elif type(value) is int and -(2 ** 31) <= value < 2 ** 31:
            tags.append("i")
            parts.append(struct.pack(">i", value))
        elif type(value) is float and math.isfinite(value):
            try:
                packed = struct.pack(">f", value)
                if not math.isfinite(struct.unpack(">f", packed)[0]):
                    raise OverflowError()
            except (OverflowError, struct.error):
                raise OSCError("OSC float is outside the finite 32-bit range.") from None
            tags.append("f")
            parts.append(packed)
        elif type(value) is str:
            tags.append("s")
            parts.append(_string(value))
        else:
            raise OSCError("Expected Bool, signed Int32, finite Float32 or String.")
    result = _string(address) + _string("," + "".join(tags)) + b"".join(parts)
    if len(result) > MAX_PACKET:
        raise OSCError("OSC message exceeds the packet limit.")
    return result


def encode_bundle(messages):
    """Group encoded messages into an immediate bundle; this is not a transaction."""
    if not isinstance(messages, (tuple, list)) or not 1 <= len(messages) <= MAX_MESSAGES:
        raise OSCError("OSC bundle requires a bounded list of encoded messages.")
    pieces = [b"#bundle\0", struct.pack(">Q", 1)]
    size = 16
    for message in messages:
        if type(message) is not bytes:
            raise OSCError("OSC bundle members must be encoded packets.")
        size += len(message) + 4
        if size > MAX_PACKET:
            raise OSCError("OSC bundle exceeds the packet limit.")
        pieces.extend((struct.pack(">i", len(message)), message))
    result = b"".join(pieces)
    decode_packet(result)
    return result


def decode_packet(data):
    """Parse completely or reject completely, with bounded recursion and work."""
    if type(data) is not bytes or not data or len(data) > MAX_PACKET or len(data) % 4:
        raise OSCError("Invalid OSC packet size.")
    messages, visits = [], [0]

    def string(block, offset):
        end = block.find(b"\0", offset)
        following = (end + 4) & ~3
        if end < offset or end - offset > MAX_STRING or following > len(block) or any(block[end:following]):
            raise OSCError("Invalid OSC string or padding.")
        try:
            return block[offset:end].decode("utf-8"), following
        except UnicodeError:
            raise OSCError("Invalid OSC text.") from None

    def visit(block, depth):
        visits[0] += 1
        if depth > 4 or visits[0] > MAX_MESSAGES * 2:
            raise OSCError("OSC bundle nesting or node limit exceeded.")
        if block.startswith(b"#bundle\0"):
            if len(block) <= 16 or block[8:16] != struct.pack(">Q", 1):
                raise OSCError("Only non-empty immediate OSC bundles are accepted.")
            offset = 16
            while offset < len(block):
                if offset + 4 > len(block):
                    raise OSCError("Truncated OSC bundle length.")
                size = struct.unpack_from(">i", block, offset)[0]
                offset += 4
                if size <= 0 or size % 4 or offset + size > len(block):
                    raise OSCError("Invalid OSC bundle element.")
                visit(block[offset:offset + size], depth + 1)
                offset += size
            return
        address, offset = string(block, 0)
        validate_address(address)
        tags, offset = string(block, offset)
        if not tags.startswith(",") or len(tags) - 1 > MAX_ARGUMENTS:
            raise OSCError("Invalid OSC argument type tags.")
        args, types = [], []
        for tag in tags[1:]:
            if tag in "if":
                if offset + 4 > len(block):
                    raise OSCError("Truncated OSC argument.")
                value = struct.unpack_from(">i" if tag == "i" else ">f", block, offset)[0]
                offset += 4
                if tag == "f" and not math.isfinite(value):
                    raise OSCError("Non-finite OSC argument.")
                args.append(value)
                types.append("Int" if tag == "i" else "Float")
            elif tag in "TF":
                args.append(tag == "T")
                types.append("Bool")
            elif tag == "s":
                value, offset = string(block, offset)
                args.append(value)
                types.append("String")
            else:
                raise OSCError("Unsupported OSC argument type.")
        if offset != len(block):
            raise OSCError("Unexpected trailing OSC data.")
        if len(messages) >= MAX_MESSAGES:
            raise OSCError("OSC message count exceeded.")
        messages.append(OSCMessage(address, tuple(args), tuple(types)))

    visit(data, 0)
    return tuple(messages)


@dataclass(frozen=True)
class OSCPacket:
    messages: tuple
    source: tuple
    received_at: float
    generation: int


class SharedOSC:
    """Exclusive UDP socket, one receive worker, bounded rate and queue.

    No SO_REUSEADDR is used. A busy receive port is an error unless the caller
    explicitly opts into an OS-selected fallback port. Source addresses are
    observations, not authenticated application identities.
    """
    def __init__(self, clock=time.monotonic, max_queue=256, rate_limit=2048):
        self.clock = clock
        self._queue = deque(maxlen=max(1, min(int(max_queue), 1024)))
        self._rate_limit = max(1, min(int(rate_limit), 8192))
        self._lock = threading.Lock()
        self._lifecycle = threading.RLock()
        self._socket = self._thread = None
        self._stop = threading.Event()
        self.generation = 0
        self.receive_port = self.target_port = 0
        self.receive_host = self.target_host = "127.0.0.1"
        self.allow_lan = False
        self.invalid = self.dropped = self.received = self.sent = 0
        self.last_received_at = None
        self.error = ""
        self.drop_reasons={name:{"total":0,"last_at":None,"buckets":deque(maxlen=61)} for name in ("rate_limit","source_policy","queue_full","malformed")}

    def _drop(self,reason):
        now=self.clock();row=self.drop_reasons[reason];row["total"]+=1;row["last_at"]=now
        second=int(now);buckets=row["buckets"]
        if buckets and buckets[-1][0]==second:buckets[-1][1]+=1
        else:buckets.append([second,1])

    @property
    def running(self):
        return self._socket is not None and not self._stop.is_set()

    @property
    def connected(self):
        return self.running

    def start(self, receive_port=9001, target_port=9000, target_host="127.0.0.1", allow_lan=False,
              *, receive_host="127.0.0.1", fallback_port=False):
        receive_port, target_port = port(receive_port, ephemeral=True), port(target_port)
        if type(allow_lan) is not bool or type(fallback_port) is not bool:
            raise OSCError("LAN and fallback settings must be booleans.")
        target_host = literal_host(target_host, allow_lan=allow_lan)
        receive_host = literal_host(receive_host, allow_lan=allow_lan, bind=True)
        with self._lifecycle:
            self.stop()
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                try:
                    sock.bind((receive_host, receive_port))
                except OSError:
                    if not fallback_port or not receive_port:
                        raise
                    sock.bind((receive_host, 0))
                sock.settimeout(0.1)
            except OSError as exc:
                if sock is not None:
                    sock.close()
                raise OSCError("OSC receive port is unavailable; choose an unused port or explicitly enable automatic fallback. " + str(exc)) from None
            self.generation += 1
            self.receive_port, self.target_port = sock.getsockname()[1], target_port
            self.receive_host, self.target_host = receive_host, target_host
            self.allow_lan = allow_lan
            self.error = ""
            self.last_received_at = None
            self._stop = threading.Event()
            self._socket = sock
            self._thread = threading.Thread(target=self._receive, args=(sock, self._stop, self.generation, allow_lan),
                                            daemon=True, name="VRC Eye shared OSC")
            self._thread.start()
            return self.receive_port

    def _receive(self, sock, stop, generation, allow_lan):
        window, count = self.clock(), 0
        while not stop.is_set():
            try:
                data, source = sock.recvfrom(MAX_PACKET + 1)
                now = self.clock()
                if now - window >= 1 or now < window:
                    window, count = now, 0
                count += 1
                if count > self._rate_limit:
                    self.dropped += 1
                    self._drop("rate_limit")
                    continue
                try:
                    literal_host(source[0], allow_lan=allow_lan)
                except OSCError:
                    self.dropped += 1
                    self._drop("source_policy")
                    continue
                messages = decode_packet(data)
                with self._lock:
                    if stop.is_set() or generation != self.generation:
                        continue
                    if len(self._queue) == self._queue.maxlen:
                        self.dropped += 1
                        self._drop("queue_full")
                    self._queue.append(OSCPacket(messages, source, now, generation))
                    self.received += 1
                    self.last_received_at = now
            except socket.timeout:
                continue
            except OSCError:
                self.invalid += 1
                self._drop("malformed")
            except OSError as exc:
                if not stop.is_set():
                    self.error = str(exc)[:200]
                    stop.set()
                break

    def drain(self, limit=256):
        if type(limit) is not int:
            raise OSCError("Drain limit must be an integer.")
        with self._lock:
            return tuple(self._queue.popleft() for _ in range(min(len(self._queue), max(0, min(limit, 1024)))))

    def send(self, address, args=()):
        payload = encode_message(address, args)
        with self._lifecycle:
            if not self.running:
                raise OSCError("OSC transport is stopped.")
            try:
                count = self._socket.sendto(payload, (self.target_host, self.target_port))
            except OSError as exc:
                raise OSCError("OSC send failed: " + str(exc)) from None
            if count != len(payload):
                raise OSCError("OSC packet was not completely transmitted.")
            self.sent += 1
            return count

    def stop(self):
        with self._lifecycle:
            self._stop.set()
            sock, thread = self._socket, self._thread
            self._socket = self._thread = None
            self.generation += 1
            if sock is not None:
                sock.close()
            if thread is not None and thread is not threading.current_thread():
                thread.join(timeout=0.3)
            with self._lock:
                self._queue.clear()
            self.last_received_at = None

    close = stop
    connect = start

    def snapshot(self):
        with self._lock:
            queued = len(self._queue)
        return {"running": self.running, "generation": self.generation, "receive_host": self.receive_host,
                "receive_port": self.receive_port, "target_host": self.target_host, "target_port": self.target_port,
                "allow_lan": self.allow_lan, "queued": queued, "invalid": self.invalid, "dropped": self.dropped,
                "received": self.received, "sent": self.sent, "last_received_at": self.last_received_at,
                "drop_reasons": {k:{"total":v["total"],"last_at":v["last_at"],"last_60_seconds":sum(n for at,n in tuple(v["buckets"]) if 0<=self.clock()-at<60)} for k,v in self.drop_reasons.items()},
                "drop_context":{"rate_limit_per_second":self._rate_limit,"queue_capacity":self._queue.maxlen,"window":"rolling 60 seconds, one-second buckets","session_generation":self.generation},
                "error": self.error, "notice": "UDP transmissions are not acknowledgements; source addresses do not authenticate applications."}


LocalOSC = SharedOSC
