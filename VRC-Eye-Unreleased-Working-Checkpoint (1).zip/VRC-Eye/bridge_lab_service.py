"""Client Bridge Lab coordinator: evidence first, bounded scoped experiments.

Live actions use the existing ClientBridge. Sandbox owns a separate in-memory
BridgeState; Replay has no executor. Opening pages never opens/grants a transport.
"""
from __future__ import annotations
from collections import OrderedDict, deque
from copy import deepcopy
import hashlib
import json
import secrets
import threading
import time
from pathlib import Path

from bridge_protocol import BridgeError, fresh_id
from bridge_lab_contract import (CONTRACTS, TEMPORARY, ACTIONS, BUILT_INS, ELIGIBLE_MODULES,
    RECOVERIES, contract_catalog, same, typed, identifier, validate_action)
from bridge_lab_peers import CATEGORIES, validate_card, compare_cards, test_ref
from developer_core import canonical, bounded_json, stamp


def _digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


class BridgeLabService:
    def __init__(self, developer, *, clock=time.monotonic):
        self.developer, self.clock = developer, clock
        self.lock = threading.RLock()
        self.epoch = None
        self.signature = None
        self.sandbox = None
        self.armed = False
        self.closed = False
        self.prepared = OrderedDict()
        self.experiments = OrderedDict()
        self.timeline = deque(maxlen=400)
        self.parameter_trace = deque(maxlen=400)
        self.timeline_dropped = self.trace_dropped = 0
        self.last_event = 0
        self.started = clock()
        self.manifest_review = None
        self.api_evidence = None
        self.context = None
        self.last_reason = 'No live provider is required for Sandbox.'
        self.last_overhead_ms = 0.0
        self.peer_cards = OrderedDict()
        self.test = None
        self.milestones = {}
        self.creator_values = {}
        self.last_parameters = {}
        self.replay_report = None

    @property
    def environment(self): return self.developer.environment

    def state(self):
        if self.environment == 'Replay' or self.closed: return None
        if self.environment == 'Sandbox': return self.sandbox.state if self.sandbox else None
        app = self.developer.app
        if getattr(app, 'demo', False) or getattr(app, 'safe_mode', False): return None
        return getattr(getattr(app, 'bridge', None), 'state', None)

    def _emit(self, event, row=None):
        self.developer.recorder.emit('bridge_lab.'+event, row or {}, environment=self.environment,
                                     origin='Client Bridge Lab', operation=(row or {}).get('capability',''))

    def _append(self, ring, row, counter):
        if len(ring) == ring.maxlen: setattr(self, counter, getattr(self, counter)+1)
        ring.append(deepcopy(row))

    def _end_context(self, reason, *, clear=False):
        self.armed = False
        self.prepared.clear(); self.manifest_review = None
        for experiment in self.experiments.values():
            if experiment['finished']: continue
            future=experiment.get('future')
            sent = 'dispatched' in experiment.get('stages',{}) or future is not None and getattr(future, 'bridge_dispatched_at', None) is not None
            if future is not None and not future.done(): future.cancel()
            experiment.update(finished=True, status='Restoration unconfirmed' if sent and experiment['capability'] in TEMPORARY else 'Outcome unknown' if sent else 'Cancelled before dispatch', reason=reason)
        self.context = None
        self.last_parameters.clear(); self.creator_values.clear(); self.milestones.clear()
        self.last_reason = reason
        if clear:
            self.timeline.clear(); self.parameter_trace.clear(); self.experiments.clear()
            self.peer_cards.clear(); self.test = None; self.api_evidence = None; self.replay_report = None
            self.timeline_dropped=self.trace_dropped=0
            self.started=self.clock()
        self._emit('context_invalidated', {'reason':reason})

    def invalidate(self, reason='Developer account/environment changed.'):
        with self.lock:
            self._end_context(reason, clear=True)
            self.epoch=None; self.signature=None; self.sandbox=None; self.last_event=0

    def _refresh_epoch(self):
        epoch=(self.environment, self.developer.generation)
        if epoch != self.epoch:
            self._end_context('Developer environment or account changed; reviews and capture were cleared.', clear=True)
            self.epoch=epoch; self.signature=None; self.last_event=0; self.sandbox=None
            if self.environment=='Sandbox':
                from bridge_lab_fixture import LabSandbox
                self.sandbox=LabSandbox(self.clock)

    def _sample(self, name):
        state=self.state()
        return state.get_sample(name) if state else None

    def _fresh(self, name):
        sample=self._sample(name)
        if not sample: raise BridgeError('Fresh approved '+name+' telemetry is unavailable; no value is assumed.')
        if name.startswith('lab.') and not same(sample['value']['context'], self.context):
            raise BridgeError('The observation belongs to a different experiment context.')
        return sample

    def _identity(self, state):
        snap=state.snapshot()
        sample=state.get_sample('lab.context')
        context=sample['value']['context'] if sample else None
        signature=(snap['session'], _digest(context), tuple(sorted(k for k in snap['available'] if k.startswith('lab.'))),
                   state.permission_revision)
        return signature,context,snap

    def tick(self):
        if self.closed: return
        began=time.monotonic()
        with self.lock:
            self._refresh_epoch()
            if self.sandbox and self.environment=='Sandbox': self.sandbox.tick()
            state=self.state()
            if state is None:
                if self.signature is not None:
                    self._end_context('Provider unavailable. No live executor is present.'); self.signature=None
                return
            signature,context,snap=self._identity(state)
            if signature != self.signature:
                first=self.signature is None
                self._end_context('Lab connection, permissions, avatar/world or configuration changed.' if not first else 'Review this provider and the available capabilities.')
                # A new bridge session uses a new event sequence namespace.
                if self.signature is None or signature[0] != self.signature[0]: self.last_event=0
                self.signature=signature
            self.context=deepcopy(context)
            bundle=state.lab_events_since(self.last_event)
            self.last_event=bundle['sequence']
            for event in bundle['events']:
                if self.context is not None and same(event['sample']['value']['context'], self.context): self._consume(event)
            for token,draft in list(self.prepared.items()):
                if self.clock()-draft['created']>30: self.prepared.pop(token,None)
            for experiment in list(self.experiments.values()):
                if not experiment['finished']: self._advance(experiment)
            self.last_overhead_ms=(time.monotonic()-began)*1000

    def _consume(self, event):
        name,sample=event['capability'],event['sample']
        value=sample['value']
        relative=max(0,(sample['observed']-self.started)*1000)
        provider='Synthetic fixture' if self.environment=='Sandbox' else 'Connected provider claim'
        if name=='lab.self_avatar':
            row={k:deepcopy(v) for k,v in value.items() if k!='context'}
            row.update(elapsed_ms=round(relative,3), local_sequence=event['sequence'], provider=provider,
                       observed_at=stamp(), context_revision=value['context']['revision'])
            # Repeated identical snapshots do not bury the transitions.
            previous=self.timeline[-1] if self.timeline else None
            keys=('event','phase','tracking_type','vr_mode','upright','in_station','animator_state','controller_revision','context_revision')
            if previous is None or any(not same(previous.get(k),row.get(k)) for k in keys):
                self._append(self.timeline,row,'timeline_dropped')
        elif name=='lab.parameters':
            for row in value['parameters']:
                old=self.last_parameters.get(row['name'])
                if old is None or not same(old,row):
                    observation=dict(name=row['name'], observed=deepcopy(row['value']), revision=row['revision'],
                                     writer=row.get('writer','source unknown'), attribution='Provider claim; not independently established' if row.get('writer') else 'Source unknown',
                                     elapsed_ms=round(relative,3), context_revision=value['context']['revision'])
                    self._append(self.parameter_trace,observation,'trace_dropped')
                    self.last_parameters[row['name']]=deepcopy(row)
        elif name=='lab.creator':
            for field in value['manifest']['fields']:
                old=self.creator_values.get(field['key'])
                if self.test and field['value'] is True and old is not True and sample['observed']>=self.test['started']:
                    self.milestones[field['key']]=max(0,(sample['observed']-self.test['started'])*1000)
                self.creator_values[field['key']]=field['value']

    def arm(self, enabled):
        with self.lock:
            self.tick()
            if type(enabled) is not bool: raise ValueError('Choose a boolean lab control setting.')
            if not enabled:
                self.armed=False; self.prepared.clear()
                self.stop_all()
                return
            if self.environment!='Live': raise ValueError('Only Live has a lab-control arming switch. Sandbox has no live executor.')
            self._require_context()
            self.armed=True
            self._emit('armed', {'reason':'Explicit session-only lab arming; API and OSC permissions are unchanged.'})

    def _require_context(self, capability=None):
        if self.environment=='Replay': raise BridgeError('Replay has no bridge action executor.')
        state=self.state()
        if not state or self.context is None or not self._sample('lab.context'):
            raise BridgeError('No fresh, approved experiment context. Open the existing bridge connection settings to inspect the provider.')
        if capability and not state.available(capability): raise BridgeError('This named capability is not advertised, approved, responsive and enabled.')
        if capability in TEMPORARY and not state.available('lab.restore'):
            raise BridgeError('Temporary experiments require a separately approved compare-and-restore capability.')
        return state

    def _record(self, capability, target):
        source,key,collection={
            'lab.parameter_set':('lab.parameters','name','parameters'),
            'lab.presentation_reduce':('lab.presentation','target_user_id','targets'),
            'lab.module_pause':('lab.modules','id','modules'),
        }[capability]
        sample=self._fresh(source)
        row=next((r for r in sample['value'][collection] if r[key]==target),None)
        if row is None: raise BridgeError('The selected target was not present in the fresh scoped telemetry.')
        return deepcopy(row), sample

    @staticmethod
    def _value(capability,row):
        if capability=='lab.parameter_set': return row['value']
        if capability=='lab.module_pause': return row['paused']
        return {k:row[k] for k in ('avatar_hidden','audio_suppressed','effects')}

    def _manifest_signature(self, value):
        return _digest({k:v for k,v in value.items() if k not in ('fields','authority_expires_ms')})

    def review_manifest(self):
        """Called after an explicit local review. Does not assert actual server authority."""
        with self.lock:
            self.tick(); self._require_context()
            sample=self._fresh('lab.creator'); manifest=sample['value']['manifest']
            if manifest['authority_kind']=='none' or manifest['authority_account']!=self.context['account_id'] or manifest['authority_expires_ms']<=0:
                raise BridgeError('No current, scoped creator/playtest authority is reported for this account.')
            self.manifest_review=dict(signature=self._manifest_signature(manifest), context=deepcopy(self.context),
                                      expires=self.clock()+min(60,manifest['authority_expires_ms']/1000),
                                      provider_claim=True)
            return dict(status='Manifest explicitly reviewed for this context', authoritative=False,
                        expires_seconds=min(60,manifest['authority_expires_ms']/1000),
                        note='Provider must still verify the specific control and live-session authority at dispatch.')

    def prepare(self, capability, options):
        with self.lock:
            self.tick(); state=self._require_context(capability)
            if capability not in ACTIONS or capability=='lab.restore': raise BridgeError('Choose a supported scoped experiment; restoration requires an existing lease.')
            if not isinstance(options,dict): raise BridgeError('Experiment options must be structured data.')
            # Reject hidden/excess imported options rather than silently ignoring them.
            allowed={
                'lab.parameter_set':{'name','value','duration_seconds'},
                'lab.presentation_reduce':{'target_user_id','mode','duration_seconds'},
                'lab.module_pause':{'module_id','duration_seconds'},
                'lab.recover':{'operation','channel'},
                'lab.creator_action':{'control_id'},
            }[capability]
            if set(options)!=allowed: raise BridgeError('Experiment options do not match the selected capability.')
            params=dict(context=deepcopy(self.context),experiment_id=fresh_id())
            baseline={}; applied=None; target=None; effects=[]
            if capability in TEMPORARY:
                duration=options['duration_seconds']
                if type(duration) is not int or not 1<=duration<=60: raise BridgeError('Temporary experiments must last 1–60 seconds.')
                params['duration_ms']=duration*1000
                target=options.get('name',options.get('target_user_id',options.get('module_id')))
                baseline,_=self._record(capability,target)
                if capability=='lab.parameter_set':
                    if self.context['avatar_id'] is None: raise BridgeError('No current own-avatar identity is reported.')
                    if target in BUILT_INS or not baseline['writable']: raise BridgeError('This parameter is observation-only.')
                    value=typed(baseline['type'],options['value'])
                    if baseline['type']=='float': value=float(value)
                    params.update(name=target,expected=deepcopy(baseline['value']),value=value,expected_revision=baseline['revision'])
                    applied=value
                    effects=['Own avatar; synchronization: '+baseline['synced']+'; persistence: '+baseline['saved'],
                             'Requested, dispatched and observed values are separate. An unidentified writer remains source unknown.']
                elif capability=='lab.module_pause':
                    if baseline['kind'] not in ELIGIBLE_MODULES or not baseline['can_pause'] or baseline['paused']:
                        raise BridgeError('Only an unpaused integration-owned diagnostic, overlay or input-routing module with explicit pause support is eligible.')
                    params.update(module_id=target,expected_revision=baseline['revision']); applied=True
                    effects=['Pause only '+baseline['kind']+' module '+target,
                             'Version '+baseline['version']+'; configuration revision '+str(baseline['config_revision'])]
                else:
                    before={k:baseline[k] for k in ('avatar_hidden','audio_suppressed','effects','revision')}
                    params.update(target_user_id=target,mode=options['mode'],expected=before)
                    applied=self._value(capability,baseline)
                    if options['mode']=='hide': applied['avatar_hidden']=True
                    elif options['mode']=='suppress_audio': applied['audio_suppressed']=True
                    elif options['mode'] in ('reduce_effects','minimal_effects'):
                        applied['effects']='minimal' if options['mode']=='minimal_effects' or baseline['effects']=='minimal' else 'reduced'
                    else: raise BridgeError('Only exposure-reducing presentation controls are available.')
                    effects=['Local presentation reduction only; no blocked-content reveal or protection changes.',
                             'Provider claims of local scope are not independently verified. Frame-time changes show correlation, not intent or cause.']
                if same(applied,self._value(capability,baseline)): raise BridgeError('The proposed experiment would not change the currently observed value.')
            elif capability=='lab.recover':
                sample=self._fresh('lab.health'); baseline=sample['value']
                if options['channel']!=baseline['channel']: raise BridgeError('Choose the observed integration-owned diagnostic channel.')
                if options['operation'] not in RECOVERIES: raise BridgeError('Choose a named integration recovery, not a generic repair command.')
                params.update(operation=options['operation'],channel=options['channel'])
                effects=[RECOVERIES[options['operation']], 'Acknowledgement, new correlated telemetry and a healthy report are separate milestones.']
            else:
                sample=self._fresh('lab.creator'); baseline=sample['value']['manifest']
                review=self.manifest_review
                if not review or self.clock()>=review['expires'] or not same(review['context'],self.context) or review['signature']!=self._manifest_signature(baseline):
                    raise BridgeError('Review the current creator manifest and its scoped authority before preparing a shared control.')
                if baseline['authority_account']!=self.context['account_id'] or baseline['authority_kind']=='none' or self.clock()>=sample['observed']+baseline['authority_expires_ms']/1000:
                    raise BridgeError('Creator/playtest authority evidence is absent, stale or for another account.')
                control=next((c for c in baseline['controls'] if c['id']==options['control_id']),None)
                if not control or control['scope']!='shared_test' or not control['authorized'] or control['persistent'] or control['destructive']:
                    raise BridgeError('Unknown, unauthorized, destructive or persistent creator controls are not executable in this adapter.')
                if self.context['world_id'] is None: raise BridgeError('An exact current world/test session is required.')
                params.update(manifest_id=baseline['id'],manifest_revision=baseline['revision'],control_id=control['id'])
                effects=[control['effect'],'Creator-defined shared test state may change. World authorship alone is not authorization.']
            params=validate_action(capability,params)
            token=secrets.token_hex(16)
            draft=dict(token=token,capability=capability,params=params,baseline=deepcopy(baseline),applied=deepcopy(applied),
                       target=target,created=self.clock(),signature=deepcopy(self.signature),epoch=self.epoch,
                       metrics=self._metrics(),effects=effects)
            self.prepared[token]=draft
            while len(self.prepared)>16: self.prepared.popitem(last=False)
            preview={k:deepcopy(v) for k,v in draft.items() if k not in ('signature','epoch','created')}
            preview.update(environment=self.environment,classification=CONTRACTS[capability][2],
                risk='Extremely Risky — experimental state change' if self.environment=='Live' else 'Isolated synthetic experiment',
                restoration='Compare-and-restore only while context and exact applied revision remain current; a disconnect leaves restoration unconfirmed.' if capability in TEMPORARY else 'No general undo is promised.',
                confirmation_expires_seconds=30, live_compatibility='unverified')
            return preview

    def execute(self, token):
        with self.lock:
            self.tick(); draft=self.prepared.pop(token,None)
            if draft is None: raise BridgeError('This review is absent, expired or already used. Prepare a fresh experiment.')
            capability=draft['capability']; state=self._require_context(capability)
            if self.environment=='Live' and not self.armed: raise BridgeError('Arm lab controls separately for this live connection; API arming does not grant them.')
            if self.signature!=draft['signature'] or self.epoch!=draft['epoch'] or self.clock()-draft['created']>30:
                raise BridgeError('The reviewed experiment context changed.')
            if any(not r['finished'] for r in self.experiments.values()): raise BridgeError('Finish the current experiment first so comparisons isolate one change.')
            if capability in TEMPORARY:
                current,_=self._record(capability,draft['target'])
                if not same(current,draft['baseline']): raise BridgeError('Observed state changed since review. Nothing was sent.')
            elif capability=='lab.creator_action':
                sample=self._fresh('lab.creator'); current=sample['value']['manifest']
                review=self.manifest_review
                if not review or self.clock()>=review['expires'] or self._manifest_signature(current)!=self._manifest_signature(draft['baseline']) or self.clock()>=sample['observed']+current['authority_expires_ms']/1000:
                    raise BridgeError('Creator manifest or scoped authority changed before dispatch.')
            else:
                current=self._fresh('lab.health')['value']
                if current['channel']!=draft['params']['channel']: raise BridgeError('Recovery channel changed.')
            params=draft['params']
            future=state.request(capability,params,expected_session=state.session)
            row=dict(draft,id=params['experiment_id'],future=future,started=self.clock(),
                     deadline=self.clock()+params.get('duration_ms',10000)/1000,finished=False,status='Requested; queued',
                     acknowledged=False,applied_revision=None,observed=False,restoring=False,restored=False,
                     stages={'requested':round(self.clock(),6)},after_metrics=None,reason='No automatic retry.')
            self.experiments[row['id']]=row
            while len(self.experiments)>100: self.experiments.popitem(last=False)
            self._emit('requested',{'capability':capability,'state':row['status']})
            return self._public_experiment(row)

    def _advance(self,row):
        future=row['future']; sent=getattr(future,'bridge_dispatched_at',None)
        if sent is not None:
            row['stages'].setdefault('restore_dispatched' if row['restoring'] else 'dispatched',round(sent,6))
            if row['status']=='Requested; queued': row['status']='Dispatched; acknowledgement pending'
        if future.done() and not row.get('future_consumed'):
            row['future_consumed']=True
            try: result=future.result()
            except Exception:
                row.update(finished=True,status='Restoration unconfirmed' if row['restoring'] else 'Outcome unknown' if sent is not None else 'Cancelled before dispatch',
                           reason='The provider did not confirm the result; no automatic retry. This may include rejection or a lost response.')
                return
            row['stages']['restoration_acknowledged' if row['restoring'] else 'acknowledged']=round(self.clock(),6)
            row['acknowledged']=True
            if row['restoring']:
                row['restore_revision']=result.get('applied_revision'); row['status']='Restoration acknowledged; observation pending'
            else:
                row['applied_revision']=result.get('applied_revision'); row['status']='Acknowledged; observation pending'
            if row['capability']=='lab.creator_action':
                row.update(finished=True,status='Acknowledged; shared-state completion unverified'); return
        if row['capability']=='lab.recover':
            sample=self._sample('lab.health')
            if sample and sent is not None and sample['observed']>=sent:
                health=sample['value']
                if health['channel']==row['params']['channel'] and health.get('recovery_id')==row['id'] and health['telemetry_revision']>row['baseline']['telemetry_revision']:
                    row['stages'].setdefault('new_telemetry',round(sample['observed'],6))
                    if row['acknowledged'] and health['state']=='healthy':
                        row['stages']['health_check_satisfied']=round(self.clock(),6)
                        row.update(finished=True,status='Health check satisfied — provider reported'); return
                    row['status']='New telemetry received; health check not satisfied' if row['acknowledged'] else 'New telemetry received; acknowledgement pending'
            if self.clock()>=row['deadline']: row.update(finished=True,status='Recovery unverified',reason='A healthy correlated report was not observed within the local inspection window.')
            return
        if row['capability'] not in TEMPORARY: return
        try: current,sample=self._record(row['capability'],row['target'])
        except BridgeError:
            if self.clock()>=row['deadline']: row.update(finished=True,status='Restoration unconfirmed',reason='Fresh target telemetry is unavailable; no blind restore was sent.')
            return
        current_value=self._value(row['capability'],current)
        baseline=self._value(row['capability'],row['baseline'])
        if row['restoring']:
            if row.get('restore_revision') is not None and current['revision']==row['restore_revision'] and sample['observed']>=(sent if sent is not None else self.clock()+1) and same(current_value,baseline):
                row['stages']['restoration_observed']=round(sample['observed'],6)
                row.update(finished=True,restored=True,status='Restoration observed — provider reported',restored_metrics=self._metrics()); return
            if self.clock()>=row['restore_deadline']: row.update(finished=True,status='Restoration unconfirmed',reason='No matching fresh post-restoration observation. No automatic retry.')
            return
        if sent is not None and sample['observed']>=sent and current['revision']>row['baseline']['revision']:
            if same(current_value,row['applied']) and row['applied_revision'] is not None and current['revision']==row['applied_revision']:
                row['observed']=True
                row['stages'].setdefault('matching_value_observed',round(sample['observed'],6))
                row['status']='Matching value observed; causation not established'
                if row['after_metrics'] is None: row['after_metrics']=self._metrics()
            elif row['observed']:
                row['status']='Value changed after the request; cause not established'
                row['competing_writer']=current.get('writer','source unknown')
        if row.get('stop_requested') or self.clock()>=row['deadline']: self._restore(row)

    def _restore(self,row):
        if row['finished'] or row['restoring']: return
        row['stop_requested']=True
        future=row['future']
        if getattr(future,'bridge_dispatched_at',None) is None:
            if not future.done(): future.cancel()
            row.update(finished=True,status='Cancelled before dispatch'); return
        try:
            state=self._require_context('lab.restore')
            current,_=self._record(row['capability'],row['target'])
            current_value=self._value(row['capability'],current)
            baseline=self._value(row['capability'],row['baseline'])
            if same(current_value,baseline) and current['revision']>row['baseline']['revision']:
                row.update(finished=True,status='Baseline observed; undo origin unverified',reason='No restoration request was needed. A provider lease or another writer may have restored it.'); return
            if not row['acknowledged'] or row['applied_revision'] is None or not row['observed']:
                raise BridgeError('The applied revision was not both acknowledged and observed; blind restoration was suppressed.')
            if current['revision']!=row['applied_revision'] or not same(current_value,row['applied']):
                row.update(finished=True,status='Restoration skipped — newer state preserved',reason='Current value or revision no longer matches the experiment. No old value was written.'); return
            params=dict(context=deepcopy(self.context),experiment_id=row['id'],original_capability=row['capability'],expected_revision=current['revision'])
            if self.clock()<state.next_request:
                row['status']='Restoration waiting for local request budget';return
            restore=state.request('lab.restore',params,expected_session=state.session)
            row.update(future=restore,future_consumed=False,restoring=True,restore_deadline=self.clock()+5,status='Restoration requested; compare-and-restore pending')
            row['stages']['restoration_requested']=round(self.clock(),6)
        except BridgeError as exc:
            row.update(finished=True,status='Restoration unconfirmed',reason=str(exc))

    def stop_all(self):
        with self.lock:
            self.prepared.clear()
            for row in self.experiments.values():
                if row['finished']: continue
                if row['capability'] in TEMPORARY: self._restore(row)
                else:
                    future=row['future']; sent=getattr(future,'bridge_dispatched_at',None) is not None
                    if not future.done(): future.cancel()
                    row.update(finished=True,status='Outcome unknown' if sent else 'Cancelled before dispatch',reason='Inspection stopped; already dispatched operations cannot be unsent.')

    def _metrics(self):
        sample=self._sample('unity.runtime_health')
        if not sample: return {'available':False,'frame_ms':None,'fps':None,'source':'unavailable'}
        value=sample['value']
        return dict(available=True,frame_ms=value.get('frame_ms'),fps=value.get('fps'),
                    source='synthetic' if self.environment=='Sandbox' else 'client_reported',
                    observed_monotonic=sample['observed'],age_seconds=max(0,self.clock()-sample['observed']))

    def observe_api(self,result,context):
        """Receive only the existing workbench's authorized result; never issue a read."""
        response=result.get('response')
        if not isinstance(response,dict): return
        operation=result.get('operation')
        field='currentAvatar' if operation=='account.get' else 'id' if operation=='avatar.get' else None
        avatar=response.get(field) if field else None
        if not isinstance(avatar,str): return
        try:
            from bridge_protocol import ref
            ref(avatar,'avtr')
        except BridgeError: return
        with self.lock:
            self._refresh_epoch()
            if context.environment!=self.environment or context.generation!=self.developer.generation:return
            self.api_evidence=dict(avatar_id=avatar,account_id=context.identity[0],environment=context.environment,
                  generation=context.generation,observed_at=result.get('observed_at'),received=self.clock(),
                  cache_state=result.get('cache_state'),source='Authorized API response' if context.environment=='Live' else 'Synthetic API fixture',
                  evidence_kind='service_selected_avatar' if operation=='account.get' else 'accessible_avatar_record')

    def consistency(self):
        with self.lock:
            self.tick()
            provider=self.context
            api=deepcopy(self.api_evidence)
            if api: api['age_seconds']=max(0,self.clock()-api['received'])
            local={'source':'OSC','state':'unavailable','avatar_id':None}
            if self.environment=='Live':
                osc=getattr(self.developer.app,'osc_service',None)
                if osc is not None and getattr(osc,'connected',False):
                    local=dict(source='Existing OSC service',avatar_id=getattr(osc,'avatar_id','') or None,
                               account_id=getattr(osc,'account_id','') or None, state='Last reported context',
                               freshness='Avatar context age is not exposed by this provider; no freshness assumption.')
            outcome='Insufficient comparable evidence'
            reasons=[]
            if api and provider:
                if api['environment']!=self.environment or api['generation']!=self.developer.generation or api['account_id']!=provider['account_id']:
                    outcome='Different account/environment contexts; not comparable'
                elif api['evidence_kind']!='service_selected_avatar':
                    outcome='Accessible avatar record is not evidence of which avatar is currently selected'
                elif api['age_seconds']>10:
                    outcome='API observation is stale for this local comparison'
                elif api['avatar_id']==provider['avatar_id']:
                    outcome='Matching selected-avatar identifiers observed; runtime readiness remains separate'
                else:
                    outcome='Different selected-avatar identifiers observed; neither source is declared correct'
                reasons.append('API time is response-capture time; cached source age and in-flight transitions may be unknown.')
            if local.get('account_id') and provider and local['account_id']!=provider['account_id']:
                local['comparison']='Different account context; excluded'
            elif local.get('avatar_id') and provider:
                local['comparison']='Same last-reported identifier' if local['avatar_id']==provider['avatar_id'] else 'Different last-reported identifier; age unknown'
            return dict(api=api or {'state':'No selected-avatar API observation captured; use the existing account.get workbench read.'},
                        osc=local,bridge={'context':deepcopy(provider),'source':'Synthetic fixture' if self.environment=='Sandbox' else 'Connected provider claim'},
                        outcome=outcome,reasons=reasons,automatic_corrections=False,network_requests=0)

    def osc_trace(self):
        if self.environment!='Live': return {'environment':self.environment,'state':'Live OSC is not inspected in this environment.'}
        service=getattr(self.developer.app,'osc_service',None)
        if service is None: return {'state':'Existing OSC service is unavailable. No provider was started.'}
        snapshot=service.snapshot()
        # Only own avatar parameter actions, not chat, tracking poses or microphone.
        actions=[r for r in snapshot.get('actions',[]) if r.get('address','').startswith('/avatar/parameters/')][-100:]
        return {'source':'Shared OSC action service','actions':actions,
                'note':'No OSC permissions were granted or packets sent. Observations do not prove which controller caused them.'}

    def start_test(self,test_id=None):
        from bridge_protocol import ref
        with self.lock:
            self.tick(); test_id=test_id or fresh_id(); test_ref(test_id)
            self.test=dict(id=test_id,started=self.clock(),provider_ref=fresh_id()); self.milestones.clear(); self.peer_cards.clear()
            return {'test_id':test_id,'clock_basis':'Independent local start unless participants deliberately supply a shared-cue uncertainty bound.'}

    def make_card(self,milestone,categories,*,alignment='local_start',uncertainty_ms=None):
        with self.lock:
            self.tick()
            if self.test is None: raise ValueError('Start or join a shared test ID before preparing a card.')
            identifier(milestone)
            if not isinstance(categories,(list,tuple)) or not categories or set(categories)-set(CATEGORIES): raise ValueError('Select the categories you choose to share.')
            fresh=bool(self._sample('lab.context'))
            has_milestone='milestone' in categories
            elapsed=self.milestones.get(milestone) if fresh and has_milestone else None
            observed=True if elapsed is not None else False if fresh and has_milestone and milestone in self.creator_values else None
            metrics=self._metrics() if fresh and 'performance' in categories else {}
            avatar=self._sample('lab.self_avatar') if fresh and 'avatar_state' in categories else None
            provider_version=(self.state().snapshot().get('client') or {}).get('version') if fresh else None
            if provider_version is not None:
                try:identifier(provider_version,40)
                except BridgeError:provider_version=None
            return validate_card(dict(schema=1,card_id=fresh_id(),test_id=self.test['id'],milestone=milestone,
                       provider_ref=self.test['provider_ref'],provider_contract='client-bridge-lab-1',provider_version=provider_version,
                       provider='synthetic' if fresh and self.environment=='Sandbox' else 'client_reported' if fresh else 'unavailable',
                       categories=list(dict.fromkeys(categories)),observed=observed,elapsed_ms=elapsed,
                       alignment=alignment,uncertainty_ms=uncertainty_ms,
                       metrics={k:metrics[k] for k in ('frame_ms','fps') if k in metrics},
                       avatar_phase=avatar['value']['phase'] if avatar else None))

    def add_card(self,card):
        card=validate_card(card)
        with self.lock:
            if self.test is None or card['test_id']!=self.test['id']: raise ValueError('This card belongs to another test. Join its test ID explicitly first.')
            self.peer_cards[card['card_id']]=card
            while len(self.peer_cards)>32: self.peer_cards.popitem(last=False)
            return compare_cards(list(self.peer_cards.values()))

    def send_card(self,peer_id,card):
        with self.lock:
            self.tick(); card=validate_card(card)
            if self.environment!='Live': raise ValueError('Sandbox and Replay cannot send Eye-to-Eye messages.')
            if self.test is None or card['test_id']!=self.test['id']: raise ValueError('The reviewed playtest context has changed.')
            peer=getattr(self.developer.app,'peer_service',None)
            if peer is None: raise ValueError('The existing Eye-to-Eye service is unavailable.')
            return peer.send(peer_id,'lab.observation',card,context=card['test_id'])

    def received_cards(self):
        if self.environment!='Live': return []
        peer=getattr(self.developer.app,'peer_service',None)
        if peer is None: return []
        snapshot=peer.snapshot()
        sessions={p['peer_id']:p.get('session') for p in snapshot.get('peers',[]) if p.get('state')=='READY'}
        return [{'peer_id':m.get('peer_id'),'payload':m['payload']} for m in snapshot.get('inbox',[])
                if m.get('kind')=='lab.observation' and m.get('direction')=='incoming' and m.get('status')=='ACCEPTED'
                and sessions.get(m.get('peer_id'))==m.get('session') and self.test and m.get('context')==self.test['id']][-32:]

    def inject(self,scenario):
        with self.lock:
            self.tick()
            if self.environment!='Sandbox' or not self.sandbox: raise ValueError('Contract failure scenarios are isolated to Sandbox.')
            self.sandbox.inject(scenario); self.tick()
            return self.snapshot()

    def reset_sandbox(self):
        with self.lock:
            if self.environment!='Sandbox': raise ValueError('Only Sandbox has an isolated fixture to reset.')
            self.invalidate('Synthetic fixture reset; no live services touched.'); self.tick()
            return self.snapshot()

    def _public_experiment(self,row):
        result={k:deepcopy(v) for k,v in row.items() if k not in ('future','signature','epoch','token','created','future_consumed')}
        before=row.get('metrics',{}); after=row.get('after_metrics') or {}
        a,b=before.get('frame_ms'),after.get('frame_ms')
        result['comparison']=dict(frame_ms_delta=(b-a) if type(a) in (int,float) and type(b) in (int,float) else None,
                                  interpretation='Single-sample correlation only; no causal or malicious-intent conclusion.')
        return result

    def summary(self):
        with self.lock:
            return dict(environment=self.environment,armed=self.armed,context_available=self.context is not None,
                        running=sum(not r['finished'] for r in self.experiments.values()),
                        timeline_records=len(self.timeline),parameter_observations=len(self.parameter_trace),
                        network_configuration='VRC Eye → Networking → Client Bridge',
                        live_compatibility='unverified',restoration_guaranteed=False)

    def snapshot(self):
        with self.lock:
            state=self.state(); snap=state.snapshot() if state else {}
            channels={}
            for name,(_,kind,_) in CONTRACTS.items():
                sample=self._sample(name) if kind=='telemetry' else None
                channels[name]=dict(advertised=name in snap.get('advertised',{}),available=name in snap.get('available',[]),
                                    age_seconds=max(0,self.clock()-sample['observed']) if sample else None,
                                    state='fresh provider claim' if sample else 'approved action' if kind=='action' and name in snap.get('available',[]) else 'unavailable')
            return dict(environment=self.environment,armed=self.armed,provider=snap.get('client') or None,
                        context=deepcopy(self.context),channels=channels,catalog=contract_catalog(),
                        timeline=deepcopy(list(self.timeline)),parameter_trace=deepcopy(list(self.parameter_trace)),
                        experiments=[self._public_experiment(r) for r in self.experiments.values()],
                        running=sum(not r['finished'] for r in self.experiments.values()),reason=self.last_reason,
                        dropped=dict(timeline=self.timeline_dropped,parameter_trace=self.trace_dropped,
                                     bridge_events=getattr(state,'lab_events_dropped',0)),
                        local_tick_ms=self.last_overhead_ms, provider_capture_cost_ms=(self._sample('lab.context') or {}).get('value',{}).get('capture_cost_ms'),
                        live_compatibility='unverified',network_started_by_lab=False,restoration_guaranteed=False)

    def view(self,name):
        with self.lock:
            self.tick()
            if self.environment=='Replay': return deepcopy(self.replay_report or {'state':'Replay has no executor. Import a sanitized Client Lab report to inspect its captured evidence.'})
            source={'Self-avatar':'lab.self_avatar','Parameters':'lab.parameters','Local isolation':'lab.presentation',
                    'Module isolation':'lab.modules','Recovery':'lab.health','Creator diagnostics':'lab.creator'}.get(name)
            sample=self._sample(source) if source else None
            result={'source':source,'sample':deepcopy(sample),'state':'fresh provider claim' if sample else 'unavailable',
                    'experiments':[self._public_experiment(r) for r in self.experiments.values()]}
            if name=='Self-avatar': result['timeline']=deepcopy(list(self.timeline))
            if name=='Parameters': result.update(trace=deepcopy(list(self.parameter_trace)),osc=self.osc_trace(),built_in_write_policy='Read-only regardless of provider advertisement')
            if name in ('Local isolation','Module isolation'): result['metrics']=self._metrics()
            return result

    def report_preview(self):
        with self.lock:
            self.tick(); snapshot=self.snapshot()
            # Provider/free-text labels, account/resource/session IDs, parameter names
            # and values are omitted before any diagnostic file can be written.
            timeline=[{k:v for k,v in r.items() if k in ('elapsed_ms','local_sequence','event','phase','tracking_type','vr_mode','upright','in_station','context_revision')} for r in self.timeline]
            rows=[]
            for index,row in enumerate(self.experiments.values(),1):
                stages={k:round(max(0,v-row['started'])*1000,3) for k,v in row['stages'].items()}
                rows.append(dict(experiment='Experiment '+str(index),capability=row['capability'],status=row['status'],finished=row['finished'],
                                 stages_ms=stages,observed=row['observed'],restored=row['restored']))
            return dict(format='vrc-eye-client-lab-report-1',version='1.21.0',created_at=stamp(),environment=self.environment,
                        timeline=timeline,experiments=rows,dropped=snapshot['dropped'],parameter_observation_count=len(self.parameter_trace),
                        provider_capture_cost_ms=snapshot['provider_capture_cost_ms'],local_tick_ms=snapshot['local_tick_ms'],
                        scope={'included':['Own-avatar state transitions','Experiment milestones without target identities','Capture counters and overhead'],
                               'excluded':['Pairing secrets','Account and resource identifiers','Private instance codes','Parameter names and values',
                                           'Provider text and module names','Creator manifest payloads','Peer identities and cards','Credentials','Notes','Wellness']},
                        validation={'live_vrchat_tested':False,'provider_claims_independently_verified':False,'restoration_guaranteed':False})

    def load_replay(self,raw):
        with self.lock:
            if self.environment!='Replay': raise ValueError('Choose Replay to inspect a report without an executor.')
            value=bounded_json(raw)
            # Reports are rendered as data only; no replayed record is an action.
            if not isinstance(value,dict) or value.get('format')!='vrc-eye-client-lab-report-1': raise ValueError('Choose a sanitized Client Lab report.')
            if len(canonical(value))>256*1024: raise ValueError('The replay report exceeds the local inspection limit.')
            self.replay_report=deepcopy(value)
            return {'state':'Read-only report loaded','executor':None,'network_requests':0}

    def close(self):
        with self.lock:
            self._end_context('Application closed or provider disconnected; restoration is unconfirmed for dispatched changes.')
            self.closed=True
            if self.sandbox: self.sandbox.state.disconnect()
            self.sandbox=None


def write_new_json(path,value):
    data=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)
    if len(data.encode('utf-8'))>256*1024: raise ValueError('The reviewed export exceeds its size limit.')
    # Existing files cannot be silently replaced.
    with open(Path(path),'x',encoding='utf-8') as stream: stream.write(data)
