"""Avatar Link compatibility adapter; it owns no socket or receive worker."""
from collections import deque
import hashlib
from types import SimpleNamespace

from avatar_osc import OSCError
from osc_transport import OSCMessage


class AvatarSharedTransport:
    def __init__(self, controller):
        self.controller, self.service = controller, controller.service
        self.enabled = False
        self.dropped = 0
        self._queue = deque(maxlen=256)
        self._contract = ()
        self._observation_guard = None
        self._last_owners = {}
        self._unsubscribe = self.service.subscribe(self._observe)

    @property
    def connected(self):
        return self.enabled and self.service.connected

    @property
    def generation(self):
        return self.service.generation

    @property
    def receive_port(self):
        return self.service.transport.receive_port

    @property
    def target_port(self):
        return self.service.transport.target_port

    @property
    def invalid(self):
        return self.service.invalid + getattr(self.service.transport, "invalid", 0)

    @property
    def contract_armed(self):
        if self._contract == ("observation-only",):
            return self.connected and self._observation_guard == self.service.state_guard
        return bool(self.connected and self._contract and all(self.service.is_granted("avatar-link", address) for address in self._contract))

    def _observe(self, address, args, observation):
        if not self.enabled or not observation.get("live") or len(args) != 1 or not address.startswith("/avatar/"):
            return
        kind = {bool: "Bool", int: "Int", float: "Float", str: "String"}.get(type(args[0]))
        source = observation.get("source")
        if kind is None or not source:
            return
        if len(self._queue) == self._queue.maxlen:
            self.dropped += 1
        self._queue.append(SimpleNamespace(messages=(OSCMessage(address, tuple(args), (kind,)),),
            source=tuple(source), received_at=observation["received_at"], generation=self.generation))

    def connect(self, receive_port=9001, target_port=9000):
        self.controller.connect()
        self.enabled = True
        self._queue.clear()
        # Attaching another view does not require restarting VRChat to emit its
        # avatar again. Seed only a current, pinned shared observation.
        observation = self.service.observation("/avatar/change")
        if observation and observation.get("live"):
            self._observe("/avatar/change", observation["args"], observation)

    def invalidate(self, reason="Avatar Link context changed"):
        self._contract = ()
        self._last_owners.clear()
        # Do not change the global permission generation for an already-inert
        # adapter: observation updates must not invalidate unrelated reviews.
        if "avatar-link" in self.service.permissions:
            self.service.revoke("avatar-link")

    def close(self):
        self.invalidate("Avatar Link detached")
        self.enabled = False
        self._queue.clear()

    def drain(self, limit=128):
        return tuple(self._queue.popleft() for _ in range(min(limit, len(self._queue))))

    def arm_contract(self, manifest, allow_public=False):
        observation = self.service.observation("/avatar/change")
        if not observation or not observation.get("live") or manifest["avatar_id"].lower() != str(observation["value"]).lower():
            raise OSCError("Avatar Link's contract must match the currently observed shared OSC avatar.")
        allowed = []
        for parameter in manifest["parameters"]:
            address = "/avatar/parameters/" + parameter["name"]
            public = parameter["privacy"] == "public" or parameter["synced"]
            item = self.service.registry.register_parameter(address, parameter["type"],
                minimum=parameter["min"], maximum=parameter["max"],
                read_only=parameter["direction"] != "in", public=public,
                cleanup=(parameter["neutral"],) if parameter["ephemeral"] and parameter["direction"] == "in" else None,
                evidence="Declared Avatar Toolkit manifest; visual operation unverified")
            if not item.read_only and (not public or allow_public):
                allowed.append(address)
        if not allowed:
            # An output-only request contract may be armed without write grants.
            self._contract = ("observation-only",)
            self._observation_guard = self.service.state_guard
            return
        self.service.arm(allowed, source="avatar-link", reviewed=True, public=allow_public)
        self._contract = tuple(allowed)

    def send_parameter(self, address, value, owner="manual", neutral=False):
        self.controller.ensure_active()
        if not self.connected:
            raise OSCError("Attach Avatar Link to shared OSC first.")
        try:
            priority = {"default": 10, "provider": 20, "profile": 60, "test": 70, "manual": 80, "heartbeat": 80}[owner]
            owner_id = "avatar-link:" + owner + ":" + hashlib.sha256(address.encode()).hexdigest()[:16]
            reviewed = self.service.review(address, (value,), source="avatar-link", owner=owner_id,
                                           priority=priority, ttl=2)
            result = self.service.send_now(reviewed)
            self._last_owners[address] = owner_id
            return result
        except (ValueError, OSError) as error:
            raise OSCError(str(error)) from error

    def send(self, address, value):
        return self.send_parameter(address, value)

    def release_parameter(self, address, owner):
        identifier = self._last_owners.pop(address, None)
        if identifier:
            self.service.release_owner(identifier)
