# VRC Eye 1.21.0 — Development 18

This build extends the verified Development 17 source with static GLB scene
inspection, conditional Home layouts and history for supported direct preference
edits. The existing OBJ preview and all earlier source files are retained.

## Start and update

Close the older copy, extract **VRC-Eye-v1.21.0-Development-18.zip** into a separate
folder, then run **Start.cmd** on Windows or **bash Start.sh** on Linux. Existing
per-user data locations, launchers and requirements are retained. This is runnable
Python source, not a compiled EXE, Flatpak or signed installer.

## Static 3D scene inspection

Open **Avatar Library → 3D preview**, select the avatar record you want to work
with, and choose **Choose static GLB scene…**. The original **Choose local OBJ
mesh…** action is still available. Nothing loads automatically on opening the page.

The GLB viewer reads actual embedded triangle meshes, composes parent/node
translation, rotation and scale (or supported affine matrices), and displays mesh
instances in their scene hierarchy. Orbit, pan, zoom, fit, reset, solid and wireframe
controls remain available through buttons, the keyboard and the canvas. There is
no automatic rotation.

Select a hierarchy node to highlight its subtree and inspect world-space bounds.
**Hide selected subtree** and **Show selected subtree** change visibility only.
**Frame selected subtree** shows and frames that subtree; **Show all / reset
framing** restores the full scene. A bounds checkbox draws a dashed box. The
hierarchy reports vertices/triangles per node; the detail text reports the number
of triangles currently displayed. The full path is hidden unless Show paths is on.

The parsed scene and visibility state remain in memory. Account, selected-avatar,
privacy or close boundaries clear the preview and prevent late results from
reappearing. The existing Avatar Library Cancel action stops a pending parse.
Generic task receipts persist; the selected model bytes are not copied into the
catalog or settings backups. Original meshes are never modified or simplified.

### Supported GLB subset

- GLB 2.0 with one JSON chunk and one embedded geometry BIN buffer.
- Static TRIANGLES, FLOAT VEC3 positions, unsigned scalar indices or unindexed
  triangles, supported interleaved position accessors, hierarchy and instancing.
- Default scene, or the first scene when the file declares no default.
- At most 32 MiB of input, 2 MiB JSON, 512 nodes/primitive instances, 64 hierarchy
  levels, 100,000 used vertices and 30,000 triangles across instances. Accessor
  decoding also has a cumulative component budget; output is limited to 24 MiB.

Export a **static baked mesh copy** from your source editor. Skinning, morph
weights/targets, compressed geometry, required extensions and external geometry
buffers are rejected with an explanation. Animations are not played; materials,
textures, UVs, lighting, cameras and Unity shaders are not rendered. This is not
VRCA/Unity-bundle or FBX decoding. It does not establish the avatar's in-game
appearance, rig correctness, source ownership or project completeness.

The renderer uses orthographic, flat-shaded, depth-sorted triangles. It has no
GPU depth buffer, so intersecting surfaces can sort imperfectly. The parser runs
in a bundled Python subprocess with a 30-second deadline and explicit owned-process
cancellation. The parent verifies protocol, source digest, hierarchy and geometry
before accepting a result. This provides process fault separation, **not an OS
security sandbox**. Windows/native rendering and process acceptance remain open.
The format follows the [Khronos glTF 2.0 specification](https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html).

## Conditional Home layouts

Open **Customization → Profiles & sharing**. Create named layouts in **Home
layout**, then add ordered rules choosing an existing layout and one condition.
Enable automatic Home layout rules when ready. The first enabled matching rule
wins; otherwise the saved default layout is shown. Move rules up/down to change
priority. Deleting a layout removes its related rules and manual override.

Conditions include sign-in state, Offline/Online mode, an observed current-account
session, privacy visibility, DND and presentation mode. They read existing local
observations and never start collectors, connect services, switch accounts or
change permissions. Online mode means VRC Eye is not configured Offline; it does
not prove current internet reachability. Session conditions use the current
account's existing session observation. Unknown facts do not match.

Home shows the active layout and the selection reason. Choose a layout and use
**Hold this layout** to override automatic switching until **Clear manual override**.
The override persists across restart and applies on this device across accounts.
Clearing it resumes the configured rules when automatic selection is enabled.
These profiles change Home layout selection; they do not apply appearance profiles
or change Casual/Advanced/Developer mode themselves.

Under **Home layout**, a widget's **Show widget when** condition can hide its
card without deleting it. Hidden cards return when the condition matches again.
Table filtering/sorting edits the layout actually displayed, including when copied
layouts share widget IDs. Older layout files remain readable. Exported Development
18 conditional layouts require a reader that supports the new optional fields.
Demo/Safe Mode layout edits remain session-only.

## Direct settings and layout history

Open **Customization → History → Settings and layout history / undo…**, or use
the existing settings-backup dialog under Desktop controls. The new direct-edit
history is separate from the selective backup-restore history.

Supported direct writes through the shared preference store record their change
and receipt in the same SQLite transaction. This includes appearance/accessibility,
Home layouts/conditions/profiles, supported notification display/focus fields,
main-window shortcuts, account friend-location filters and private tag saved views.
Unchanged defaults and unrelated data do not create receipts. Old/corrupt unsupported
documents are not copied into history; the existing settings recovery path remains.

Device settings are labelled **This device** and their history is accessible from
any account. Friend-filter/view history is labelled **This workspace** and remains
account-scoped. The most recent 100 direct-edit/undo receipts are retained for the
device and another 100 per workspace. Earlier changes are not reconstructed.
Credentials, permissions, executable approvals, private notes and original assets
are excluded. The history ledger itself is not included in portable settings.

**Review undo of direct edit…** lists exact current/restored fields and later edits
that will be preserved. Home widgets are matched by stable IDs, so moving a widget
does not lose its property history. Lists such as widget order and profile-rule
priority are treated as whole fields. When undo would invalidate a later layout
reference or dependent structure, it is refused before writing. A change during
review also aborts the entire undo transaction. Undo itself creates a receipt.

The active supported presentation controls reload after undo. The Customization
editor reloads saved values; other open settings editors should be reopened.
Stale Home-editor saves are rejected, including an atomic check at publication.
Direct-edit history does not cover arbitrary stores or bypass writes, and it does
not replace the separate asset/recovery checkpoint journal.

Selective settings backups and Home-layout exports now include conditional Home
settings. A Development 17 bundle without conditions is still readable and shows
disabled condition defaults during the reviewed import.

## Remaining scope

The ARC/VRCX ledger has **39 partial and 8 missing areas**, plus 7 acceptance/provider
prerequisites and 2 source-data limitations. ARC-01 is now partial after this static
GLB milestone; full rich-avatar provider parity remains open. The separate 160-package
roadmap has 50 source-implemented, 70 partial and 40 pending packages.

Next are richer materials/textures and qualified model import, then rig/blendshape
controls and animation. Automatic repair-helper integration with the journal,
interactive Discord/SteamVR work and native provider/GUI acceptance remain open.
See ARC_VRCX_REMAINING_DEV18.md for every remaining area.
