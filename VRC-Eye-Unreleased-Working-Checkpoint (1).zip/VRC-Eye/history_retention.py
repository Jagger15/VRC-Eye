"""Reviewed deletion across native history, friend feed and one roster scope.

All participating stores must use rollback journals so SQLite's attached-store
transaction can commit them together. Action receipts and personal notes stay.
"""
from contextlib import contextmanager
from hashlib import sha256
import json
import time
from native_library import scope,stamp
from social_history import epoch,normalize,USER
from vrcx_sources import stopped


def references(value,user):
    if isinstance(value,str):return value in (user,'friend:'+user,'user:'+user)
    if isinstance(value,list):return any(references(v,user) for v in value)
    if isinstance(value,dict):return any(references(v,user) for v in value.values())
    return False


class Retention:
    def __init__(self,library,players,*,clock=time.monotonic):
        self.library,self.players,self.clock=library,players,clock;self.review=None
        with players.connect():pass

    @contextmanager
    def connect(self):
        with self.library.connect() as db:
            db.commit();db.execute('ATTACH DATABASE ? AS roster',(str(self.players.path),))
            for schema in ('main','roster'):
                mode=db.execute('PRAGMA '+schema+'.journal_mode').fetchone()[0]
                if mode not in ('delete','truncate','persist'):
                    raise ValueError('Coordinated history deletion requires rollback-journal stores. Close background writers and recover a profile copy first.')
                db.execute('PRAGMA '+schema+'.synchronous=FULL')
            yield db

    def select(self,db,target,before,user,stop=None):
        output={};count=0
        def selected(value,when):
            return (not user or references(value,user)) and (before is None or when is not None and when<before)
        native=[]
        kinds=('event','notification','relationship') if user else ('event','notification')
        for raw in db.execute('SELECT * FROM eye_native_records WHERE scope=? AND kind IN ('+','.join('?' for _ in kinds)+')',(target,*kinds)):
            stopped(stop);count+=1
            if count>200000:raise ValueError('Retention preview is limited to 200,000 records per store.')
            row=self.library._row(raw)
            if selected(row['data'],normalize(row)['epoch']):native.append((row['kind'],row['id'],raw['fingerprint']))
        output['native']=native
        feed=[];count=0
        for raw in db.execute('SELECT * FROM feed_events WHERE account=?',(target,)):
            stopped(stop);count+=1
            if count>200000:raise ValueError('Feed deletion exceeds the preview limit.')
            if selected(dict(raw),epoch(raw['checked'])):feed.append((raw['serial'],sha256(json.dumps(dict(raw),sort_keys=True).encode()).hexdigest()))
            if len(feed)>200000:raise ValueError('Feed deletion exceeds the preview limit.')
        output['feed']=feed
        for table,column in (('encounters','first_observed'),('avatar_observations','stamp'),('player_incidents','stamp')):
            items=[];count=0
            for raw in db.execute('SELECT * FROM roster.'+table):
                stopped(stop);count+=1
                if count>200000:raise ValueError('Roster deletion exceeds the preview limit.')
                row=dict(raw)
                if selected(row,epoch(row[column])):items.append((row['id'],sha256(json.dumps(row,sort_keys=True).encode()).hexdigest()))
            output[table]=items
        return output

    def prepare(self,target,*,before=None,user='',stop=None):
        target=scope(target)
        if target!=self.players.account_scope:raise ValueError('Select the player store for this exact workspace.')
        if user and not USER.fullmatch(user):raise ValueError('Enter an exact VRChat user ID.')
        cutoff=epoch(before) if before else None
        if before and cutoff is None:raise ValueError('Use a timezone-aware retention cutoff.')
        if cutoff is None and not user:raise ValueError('Choose a date or a user before deleting history.')
        with self.connect() as db:rows=self.select(db,target,cutoff,user,stop)
        review=dict(target=target,before=cutoff,user=user,rows=rows,expires=self.clock()+300)
        self.review=review;self.frozen=json.dumps(review,sort_keys=True)
        return review

    def commit(self,review,*,stop=None,check=lambda:None):
        if review is not self.review or json.dumps(review,sort_keys=True)!=self.frozen or self.clock()>review['expires']:
            raise ValueError('Prepare a new history deletion review.')
        self.review=None;target=review['target'];rows=review['rows'];check()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('UPDATE roster.roster_settings SET value=value WHERE id=1')
            if self.select(db,target,review['before'],review['user'],stop)!=rows:raise ValueError('History changed after review. Prepare again.')
            now=stamp()
            for kind,ref,_ in rows['native']:
                stopped(stop);check();key=(target,kind,ref)
                db.execute('DELETE FROM eye_native_records WHERE scope=? AND kind=? AND id=?',key)
                db.execute('DELETE FROM eye_native_ancestors WHERE scope=? AND kind=? AND id=?',key)
                db.execute('UPDATE eye_native_changes SET before_json=NULL,rolled_back=1 WHERE scope=? AND kind=? AND id=?',key)
                db.execute('INSERT OR IGNORE INTO eye_native_suppressed VALUES(?,?,?,?)',(*key,now))
            db.executemany('DELETE FROM feed_events WHERE account=? AND serial=?',[(target,r[0]) for r in rows['feed']])
            for table in ('encounters','avatar_observations','player_incidents'):
                stopped(stop);check();ids=[(r[0],) for r in rows[table]]
                db.executemany('INSERT OR IGNORE INTO roster.deleted_player_records VALUES(?)',ids)
                db.executemany('DELETE FROM roster.'+table+' WHERE id=?',ids)
            if review['user']:
                from player_history import user_hash
                db.execute('INSERT INTO roster.encounter_suppression VALUES(?,?) ON CONFLICT(user_hash) DO UPDATE SET before_epoch=max(before_epoch,excluded.before_epoch)',(user_hash(review['user']),review['before'] or time.time()))
            db.execute('DELETE FROM roster.encounter_sessions WHERE id NOT IN (SELECT session_id FROM roster.encounters) AND id NOT IN (SELECT session_id FROM roster.avatar_observations) AND id NOT IN (SELECT session_id FROM roster.player_incidents)')
            db.execute("UPDATE eye_native_meta SET value=value+1 WHERE key='revision'")
            stopped(stop);check()
        return {key:len(value) for key,value in rows.items()}
