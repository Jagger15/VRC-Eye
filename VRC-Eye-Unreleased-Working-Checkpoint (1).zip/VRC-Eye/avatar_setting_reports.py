"""Strict, read-only inspection of editable Unity setting-transfer observations."""
from dataclasses import dataclass
import json
import math
import re
from avatar_library_files import checked_stream,check_cancel

LIMIT=2*1024*1024
KINDS=('MeshRenderer','SkinnedMeshRenderer','ModelImporter')
CATEGORIES=('streams','submeshes','materials','bones','hierarchy')
# Value contracts match EyeSettingSpecs. Unknown fields never become commands.
RENDERER={
    'enabled':('bool',()),'shadowCastingMode':('enum',('Off','On','TwoSided','ShadowsOnly')),
    'receiveShadows':('bool',()),'lightProbeUsage':('enum',('Off','BlendProbes','UseProxyVolume','CustomProvided')),
    'reflectionProbeUsage':('enum',('Off','BlendProbes','BlendProbesAndSkybox','Simple')),
    'allowOcclusionWhenDynamic':('bool',()),'motionVectorGenerationMode':('enum',('Camera','Object','ForceNoMotion')),
    'probeAnchor':('reference',()),'lightProbeProxyVolumeOverride':('reference',())}
SKIN={'quality':('enum',('Auto','Bone1','Bone2','Bone4')),'updateWhenOffscreen':('bool',()),'skinnedMotionVectors':('bool',())}
IMPORTER={k:('bool',()) for k in ('isReadable','optimizeMeshPolygons','optimizeMeshVertices','weldVertices','keepQuads','preserveHierarchy','optimizeGameObjects','importBlendShapes')}
IMPORTER.update(meshCompression=('enum',('Off','Low','Medium','High')),indexFormat=('enum',('Auto','UInt16','UInt32')),
    importNormals=('enum',('Import','Calculate','None')),importTangents=('enum',('Import','CalculateLegacy','CalculateLegacyWithSplitTangents','CalculateMikk','None')),
    normalCalculationMode=('enum',('Unweighted_Legacy','Unweighted','AreaWeighted','AngleWeighted','AreaAndAngleWeighted')),
    normalSmoothingAngle=('float',()))


def text(v,limit=4096):
    if not isinstance(v,str) or len(v)>limit or any(ord(c)<32 for c in v):raise ValueError('Invalid or oversized observation text.')
    return v


def fields(v,keys):
    if not isinstance(v,dict) or set(v)!=set(keys):raise ValueError('Unsupported observation fields; choose the complete v1 report.')
    return v


def value(v,kind,options):
    text(v)
    if kind=='bool' and v not in ('true','false'):raise ValueError('Expected a typed boolean value.')
    if kind=='enum' and v not in options:raise ValueError('Unsupported enum value.')
    if kind=='float':
        if not re.fullmatch(r'-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?',v):raise ValueError('Expected a finite numeric value.')
        n=float(v)
        if not math.isfinite(n) or not 0<=n<=180:raise ValueError('Normal smoothing angle must be within 0–180 degrees.')
    if kind=='reference' and not (v=='null' or re.fullmatch(r'asset:[0-9a-f]{32}:-?\d+:[A-Za-z0-9_.+]+|node:root(?:/\d+)*(?:#\d+:[A-Za-z0-9_.+]+)?',v)):
        raise ValueError('References need explicit asset GUID/local ID or destination node identities.')
    return v


def inventory(raw):
    fields(raw,CATEGORIES);result=[]
    for key in CATEGORIES:
        rows=raw[key]
        if not isinstance(rows,list) or len(rows)>10000:raise ValueError('Observation inventory exceeds its row budget.')
        result.append((key,tuple(text(v,2048) for v in rows)))
    return tuple(result)


@dataclass(frozen=True)
class Report:
    unity:str
    kind:str
    source_evidence:str
    source:str
    destination:str
    output:str
    receipt_id:str
    rows:tuple
    before:tuple
    after:tuple


def parse(raw):
    if not isinstance(raw,(bytes,str)):raise ValueError('Choose a UTF-8 JSON observation.')
    if len(raw if isinstance(raw,bytes) else raw.encode('utf-8'))>LIMIT:raise ValueError('Setting observation exceeds two MiB.')
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('Duplicate observation field.')
            result[k]=v
        return result
    try:d=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('Non-finite JSON value.')))
    except (UnicodeError,RecursionError,json.JSONDecodeError) as e:raise ValueError('Invalid UTF-8 JSON observation.') from e
    fields(d,('schema','unity','kind','sourceEvidence','source','destination','output','receiptId','rows','before','after','status'))
    if d['schema']!='vrc-eye.setting-transfer.v1' or d['status']!='copy_observed_no_assignment':raise ValueError('Only copy observations are supported; no operation is replayed.')
    receipt=text(d['receiptId'],32)
    if not re.fullmatch('[0-9a-f]{32}',receipt):raise ValueError('Missing copy receipt identity.')
    unity=text(d['unity'],80)
    if not re.fullmatch(r'2022\.3\.\d+[a-z]\d+',unity):raise ValueError('Unsupported Unity version contract.')
    kind=d['kind']
    if kind not in KINDS:raise ValueError('Unsupported renderer/importer type.')
    evidence=text(d['sourceEvidence'],64)
    if not re.fullmatch('[0-9a-f]{64}',evidence):raise ValueError('Missing source fingerprint.')
    for k in ('source','destination','output'):text(d[k])
    specs=IMPORTER if kind=='ModelImporter' else RENDERER| (SKIN if kind=='SkinnedMeshRenderer' else {})
    rows=d['rows'];seen=set();parsed=[]
    if not isinstance(rows,list) or not 1<=len(rows)<=256:raise ValueError('Choose a report with 1–256 individually reviewed settings.')
    for row in rows:
        fields(row,('key','kind','before','after'));key=text(row['key'],100)
        if key in seen:raise ValueError('Duplicate setting transfer.')
        seen.add(key);spec=specs.get(key)
        if kind!='ModelImporter' and re.fullmatch(r'material\[(?:0|[1-9]\d{0,2})\]',key) and int(key[9:-1])<256:spec=('reference',())
        if not spec or row['kind']!=spec[0]:raise ValueError('Unsupported setting or mismatched value type: '+key)
        parsed.append((key,spec[0],value(row['before'],*spec),value(row['after'],*spec)))
    return Report(unity,kind,evidence,d['source'],d['destination'],d['output'],receipt,tuple(parsed),inventory(d['before']),inventory(d['after']))


def load(path,*,stop=None):
    check_cancel(stop)
    with checked_stream(path,limit=LIMIT) as (_,stream,_):data=stream.read(LIMIT+1)
    check_cancel(stop);return parse(data)


def changes(report):
    before=dict(report.before);after=dict(report.after)
    return tuple((key,before[key],after[key]) for key in CATEGORIES if before[key]!=after[key])


def describe(report,*,details=False):
    lines=['Unity setting-transfer observation · '+report.kind+' · '+report.unity,
        'Editable report supplied by an editor. This desktop review does not authenticate the native run, prove current source hashes, or certify culling, deformation or FPS.',
        'The report describes an observed copy with no assignment. Check Repair Copy History for its final completed/interrupted phase. Importing this report applies no settings.',
        'Copy receipt: '+report.receipt_id,
        'Source fingerprint recorded: '+report.source_evidence,'Reviewed values:']
    if details:lines+=['Source: '+report.source,'Destination: '+report.destination,'Output: '+report.output]
    for key,kind,before,after in report.rows:
        lines.append(key+': '+(before+' → '+after if kind!='reference' or details else 'Explicit reference mapping recorded'))
    before=dict(report.before);after=dict(report.after)
    for key in CATEGORIES:
        changed=before[key]!=after[key]
        lines.append(key+': '+('CHANGED' if changed else 'unchanged')+f'; {len(before[key])} → {len(after[key])} ordered entries')
        if details and changed:lines+=['  BEFORE '+str(i)+': '+v for i,v in enumerate(before[key])]+['  AFTER '+str(i)+': '+v for i,v in enumerate(after[key])]
    lines.append('Stream/index digests marked unavailable are unverified. Matching counts do not prove matching vertex, material, submesh or bone ordering. Inspect the ordered details in the authorized project.')
    return '\n'.join(lines)
