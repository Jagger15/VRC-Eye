# VRC Eye 1.21.0 — Development 12 validation

The final portable regression passed **4,683 tests and 1,059 subtests**, with
**zero failures/errors** and **zero blocked external-socket attempts** in 107.20s.
There are **475 skipped native-GUI cases**, **1 deselected Unix bridge case**, and
the same **13 excluded local-transport modules** as the Development 11 baseline.
Skips/exclusions are not passes. Two pre-existing warnings remain (a test-listener
constructor and a deliberately duplicated ZIP member).

All **551 Python files** parse under the Python 3.10 grammar. Development 12 adds
**25 model/headless UI tests** covering scopes, ordering/state history, preset
conflicts, privacy invalidation, known-creator deduplication, Unicode segmentation,
chat cancellation, private clip routing/decoding, shared stream cleanup, cancelled
recognition loading, stale speech publication, OSC drop counters, hierarchy
comparison and provider/mascot/photo input bounds. They are included in the final
portable result. The headless widget adapter constructs all six new screens,
saves real cards and clears their private state; it is not native visual QA.

A focused audio/lifecycle/OSC run passed 50 tests and 38 subtests (six native
cases skipped). An isolated named-VPN loopback fixture passed one test/four
subtests after a transient SQLite failure in an unfiltered sweep. The final
portable gate retains baseline exclusions for comparability, rather than counting
these separate checks as full-module native acceptance.

Native Tk display tests could not start: Xvfb could not establish local sockets,
and the execution policy rejected the elevated test request. Windows/Linux GUI,
physical microphones/output endpoints, actual Vosk recognition/models, Unity,
SteamVR, tray/Discord, secure vaults, live VRChat account writes and live provider
results remain **unverified**. No uploaded mod or native payload was executed.

The unfiltered exploratory sweep also found outdated widget/dependency assertions;
they were updated for the added standard ttk LabelFrame and soundfile/regex
requirements. A stale Development 11 build-identity assertion was corrected along
with BUILD_CHANNEL before the final passing run. After the final portable run, one speech-status string was clarified to say
existing microphone routes remain active; no behavioral code changed, and all
25 workflow tests passed again. The packaging allowlist was also extended for
the previous validation snapshot and current gap ledger. The package tool verifies
all archived bytes against the final source.

This is a **runnable Windows/Linux source ZIP**, not a compiled executable,
signed installer, native acceptance release or full ARC/VRCX replacement.
Requirements include short-clip decoding and Unicode segmentation. Offline speech
is optional via requirements-speech.txt and an explicitly selected local model.
Exact command, exclusions, provenance and source hashes are in
BUILD_VALIDATION.json and SOURCE_CHECKPOINT_MANIFEST.json.
