# ARC-02: authorized Unity bundle preview — initial implementation

ARC-02 now has an actual byte-decoding path into the existing 3D viewer. It is
**partially implemented**, with an experimental supported subset and outstanding
Windows/native/creator-fixture qualification. It is not a complete replacement
for ARC's bundle viewer or a Unity source-project recovery tool.

## Use

On Linux, install the optional `requirements-bundles.txt` into the same Python
virtual environment that runs VRC Eye:

```sh
python -m pip install -r requirements-bundles.txt
```

The parser requires exactly UnityPy 1.25.4. Linux also requires `libseccomp.so.2`
and kernel seccomp support, as used by the existing GLB worker. There is no
uncontained bundle fallback. On Windows, the new bundle decoder reports that
containment is unavailable and leaves inspection, copying and manual recovery
available. Existing OBJ/GLB workflows are retained.

In Avatar Library, select an avatar workspace, open its 3D preview and choose
**Choose authorized Unity bundle…**. Select the local file and confirm ownership
or permission. The file suffix is only a picker convenience; actual header,
version, platform and content checks determine whether it can be decoded.
Nothing is loaded merely by opening the panel. A catalog association or matching
hash is not a rights grant.

The existing hierarchy, subtree visibility/framing, material inspection, mesh
health, bone display and supported pose/blendshape controls consume the result.
Source SHA-256, partial coverage and skipped/missing dependencies remain visible.
Safe Mode, account, privacy, selected-avatar and close changes invalidate pending
preview results. The Safe Mode fix also applies to the existing preview loaders.

## Initial decoding coverage

| Input/data | Implemented subset |
| --- | --- |
| Container | UnityFS v6, v7 and v8; combined block/directory records; plain, LZ4/LZ4HC and bounded LZMA; directory before or after data; supported alignment flags |
| Serialized assets | Version 22, little-endian, declared Unity 2022.3 `f` releases; embedded type trees or the pinned parser's versioned native-class schema |
| Build target labels | Windows64, Linux64 and Android data; these labels identify serialized data, not host-platform validation |
| Hierarchy | GameObject and Transform names, parent/child agreement, composed position/rotation/scale, cycle and missing-parent rejection |
| Mesh | Uncompressed vertex channels, supported numeric formats including half/normalized values, triangle submeshes, 16/32-bit indices, baseVertex, UV0, vertex colors and diagnostic normals/tangents |
| Resources | Vertex data in the same selected bundle; cross-file mesh references resolve only to embedded serialized files |
| Materials | One material assignment per submesh and a labeled unlit `_BaseColor`/`_Color` approximation; values are clamped for display |
| Skin | Up to four influences per vertex, referenced bone transforms and inverse bind poses, with validation before deformation |
| Blendshapes | Single-frame position deltas, channel names and stored weights; existing preview weight controls |
| Unsupported objects | Object-type counts only; MonoBehaviour/MonoScript bodies and animation clips are not decoded or executed |

Coordinates preserve Unity units and reflect X for the preview coordinate
system. Stored transforms/weights produce a static preview; animation,
constraints, PhysBones and runtime visibility are not evaluated. All stored
renderer objects are considered, including disabled objects and LOD levels.

Extra material slots that redraw the last submesh are not reproduced.
Textures, Unity shader evaluation, transparency reconstruction, packed mesh
compression, static batching, multi-frame blendshapes, more-than-four influence
skinning, big-endian/other serialized versions, other Unity version families,
external dependencies and animation/controller playback remain unsupported.
Missing or unsupported renderer dependencies may produce explicitly labeled
partial coverage; no supported geometry produces an error, never a placeholder
model. Malformed hierarchy/metadata stops decoding. No decryption or access-control
bypass is attempted.

## Limits and process boundaries

The parent reads a checked snapshot of at most 32 MiB. Only these bytes enter the
worker over stdin; no source path or app credentials are passed. Trusted parser
imports and versioned schema loading happen before the kernel policy is installed.
The worker then denies filesystem access, networking, process creation and new
file descriptors. It retains CPU, memory, wall-time, output and cancellation
budgets. The parent validates the declarative result and source digest before
accepting it into the viewer.

Bundle limits: 64 MiB expanded data, 1 MiB block directory, 4 MiB metadata per
serialized file, 128 embedded files and 4,096 objects. Scene limits remain 512
nodes/parts, 100,000 used vertices, 30,000 triangles, 128 materials, 32 skins,
256 bones per skin and 200,000 morph target vertices. Large real-world avatars
can exceed these limits and retain their manual workflow.

The adapter traverses bounded metadata and explicitly selects native data
classes. It does not construct UnityPy's filesystem-discovering Environment,
use automatic pointer dereferencing, instantiate Unity objects, export files,
load assemblies or call a decryption API. Optional parser dependencies remain
trusted installed software; a version string is not publisher authentication.

## Validation and remaining work

Tests construct real UnityFS and serialized-v22 bytes, independently pack their
headers/directories, and use UnityPy's native-class type-tree writer for object
bodies. They exercise actual decoding and the real Linux subprocess, including
filesystem/network/process denial, rather than returning mocked scene data.
These are **synthetic fixtures**, not evidence from the Unity editor or VRChat.

`validation/arc02-final.xml` and `PENDING_WORKING_VALIDATION.json` identify the
current integrated regression. Native canvas acceptance, creator-owned Unity
build fixtures across supported patches/targets, broader asset coverage and a
contained Windows worker remain open. The previous 16 partial ARC areas are
unchanged in completion status. ARC-02 moves from missing to partial, leaving
five separately missing capabilities: ARC-03/06/10/11/12.

The newer wallpaper/startup checkpoint was merged before integrated validation.
No build identity, numbered release, executable or installer was created.

## Parser provenance

The optional parser is [UnityPy 1.25.4](https://pypi.org/project/UnityPy/1.25.4/),
licensed MIT. It builds on AssetStudio and uses versioned TypeTreeDumps/TPK data;
see the upstream package's notices and dependencies. No third-party parser code
or binaries are redistributed in this source checkpoint. The tested dependency
versions and TPK hash are recorded in `validation/arc02-parser-environment.json`.

Source/API references reviewed for this integration:
[UnityPy repository](https://github.com/K0lb3/UnityPy),
[container reader](https://github.com/K0lb3/UnityPy/blob/master/UnityPy/files/BundleFile.py),
[object reader](https://github.com/K0lb3/UnityPy/blob/master/UnityPy/files/ObjectReader.py).
The installed 1.25.4 source was inspected for metadata, vertex channels and
schema handling; native compatibility is not inferred from documentation.
