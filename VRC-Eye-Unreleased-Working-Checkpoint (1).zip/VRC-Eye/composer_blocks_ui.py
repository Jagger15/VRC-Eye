"""Reorderable block editor feeding the existing reviewed/paced chat composer."""
from companion_ui import Table
import composer_blocks as blocks


class Editor:
    def __init__(self,dialog,parent):
        self.dialog=dialog;self.document=blocks.validate()
        dialog.label(parent,'Draft blocks · add only the fields you want to share. Build takes a snapshot into the private draft below. Sending still requires reviewing and confirming that draft.')
        self.table=Table(dialog,parent,(('kind','Block',150),('state','Enabled',70),('text','Text / source',430)),height=4)
        self.table.tree.bind('<<TreeviewSelect>>',lambda _:dialog.guard(self.select))
        row=dialog.line(parent);self.kind=dialog.tk.StringVar(value='Text');self.enabled=dialog.tk.BooleanVar(value=True);self.join=dialog.tk.StringVar(value='New line')
        dialog.ttk.Combobox(row,textvariable=self.kind,values=blocks.KINDS,state='readonly',width=18).pack(side='left')
        dialog.ttk.Checkbutton(row,text='Enabled',variable=self.enabled).pack(side='left')
        dialog.ttk.Label(row,text='Join with').pack(side='left');dialog.ttk.Combobox(row,textvariable=self.join,values=tuple(blocks.JOINS),state='readonly',width=12).pack(side='left')
        self.text=dialog.text(parent,2)
        row=dialog.line(parent)
        for label,action in (('Add block',lambda:self.edit(False)),('Update selected',lambda:self.edit(True)),('Move up',lambda:self.move(-1)),('Move down',lambda:self.move(1)),('Remove',self.remove)):
            dialog.button(row,label,action)
        row=dialog.line(parent)
        for label,action in (('Build private draft',self.build),('Save blocks locally',self.save),('Load saved blocks',self.load),('Clear blocks',self.clear)):
            dialog.button(row,label,action)
        self.refresh()

    def selected(self):
        item=self.table.selected()
        if item is None:raise ValueError('Select a draft block.')
        return int(item['index'])

    def refresh(self):
        self.table.set([dict(index=i,**b) for i,b in enumerate(self.document['blocks'])],lambda b:(b['kind'],'Yes' if b['enabled'] else 'No',b['text'] if b['kind']=='Text' else 'Snapshot when Build is pressed'),identity=lambda b:str(b['index']))

    def select(self):
        self.dialog.ready();item=self.document['blocks'][self.selected()]
        self.kind.set(item['kind']);self.enabled.set(item['enabled']);self.dialog.put(self.text,item['text'])

    def value(self):return blocks.validate(dict(self.document,join=self.join.get()))

    def edit(self,update):
        self.dialog.ready();value=self.value();kind=self.kind.get()
        item=dict(kind=kind,text=self.text.get('1.0','end-1c') if kind=='Text' else '',enabled=self.enabled.get())
        if update:value['blocks'][self.selected()]=item
        else:value['blocks'].append(item)
        self.document=blocks.validate(value);self.refresh()

    def move(self,direction):
        self.dialog.ready();index=self.selected();target=index+direction
        if not 0<=target<len(self.document['blocks']):return
        self.document['blocks'].insert(target,self.document['blocks'].pop(index));self.refresh();self.table.tree.selection_set(str(target))

    def remove(self):self.dialog.ready();self.document['blocks'].pop(self.selected());self.refresh()

    def clear(self):
        self.document=blocks.validate();self.join.set('New line');self.kind.set('Text');self.enabled.set(True)
        self.dialog.put(self.text,'');self.refresh()

    def build(self):
        dialog=self.dialog;dialog.ready();page=dialog.shell.pages.get('Media & Audio')
        media=page.service.snapshot().get('current') if page else None
        result=blocks.render(self.value(),media=media)
        dialog.put(dialog.draft,result['text']);dialog.reviewed=None;dialog.put(dialog.review,'')
        dialog.speech_status.set(f"Private block snapshot · {result['utf16_units']} UTF-16 units · {result['segments']} segments. Review segments before sending.")

    def save(self):
        dialog=self.dialog;dialog.ready();blocks.save(dialog.shell.store,dialog.owner.scope,self.value())
        dialog.status.set('Blocks saved locally in this workspace, including typed text. No provider values or send permission saved.')

    def load(self):
        dialog=self.dialog;dialog.ready();self.document=blocks.load(dialog.shell.store,dialog.owner.scope);self.join.set(self.document['join']);self.refresh()
        dialog.status.set('Saved blocks loaded. Build and review a fresh draft before sending.')
