"""Optional direct Rich Presence over local Discord IPC; no Discord login."""
import json
import os
import re
import socket
import struct
import threading
import time
import uuid
from copy import deepcopy

MAX_FRAME=65536


def public_destination(secret):
    """Decode only Eye's public-instance protocol; never arbitrary URLs."""
    if not isinstance(secret,str) or not secret.startswith('vrc-eye:1:'):raise ValueError('Unsupported Discord invitation format.')
    from companion_data import entity_id
    parts=secret[10:].split(':')
    if len(parts)!=2 or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}(?:~region\((?:us|use|eu|jp)\))?',parts[1]):raise ValueError('Unsupported public instance invitation.')
    return entity_id('world',parts[0]),parts[1]


class Pipe:
    """Windows overlapped named-pipe I/O with cancellation and finite waits."""
    def __init__(self,path):
        import ctypes
        from ctypes import wintypes as w
        self.c=ctypes;self.k=ctypes.WinDLL('kernel32',use_last_error=True)
        class Overlapped(ctypes.Structure):
            _fields_=[('Internal',ctypes.c_size_t),('InternalHigh',ctypes.c_size_t),('Offset',w.DWORD),('OffsetHigh',w.DWORD),('hEvent',w.HANDLE)]
        self.Overlapped=Overlapped
        self.k.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,w.LPVOID,w.DWORD,w.DWORD,w.HANDLE];self.k.CreateFileW.restype=w.HANDLE
        self.k.CreateEventW.argtypes=[w.LPVOID,w.BOOL,w.BOOL,w.LPCWSTR];self.k.CreateEventW.restype=w.HANDLE
        for name in ('ReadFile','WriteFile'):
            getattr(self.k,name).argtypes=[w.HANDLE,w.LPVOID,w.DWORD,ctypes.POINTER(w.DWORD),ctypes.POINTER(Overlapped)]
        self.k.WaitForSingleObject.argtypes=[w.HANDLE,w.DWORD]
        self.k.GetOverlappedResult.argtypes=[w.HANDLE,ctypes.POINTER(Overlapped),ctypes.POINTER(w.DWORD),w.BOOL]
        self.k.CancelIoEx.argtypes=[w.HANDLE,ctypes.POINTER(Overlapped)];self.k.CloseHandle.argtypes=[w.HANDLE]
        self.handle=self.k.CreateFileW(path,0xC0000000,0,None,3,0x40000000,None)
        if self.handle==ctypes.c_void_p(-1).value:raise OSError('Discord IPC unavailable')

    def io(self,data=None,count=0):
        c=self.c;event=self.k.CreateEventW(None,True,False,None)
        if not event:raise OSError('Discord IPC event unavailable')
        op=self.Overlapped();op.hEvent=event;done=c.c_ulong();buffer=c.create_string_buffer(data) if data is not None else c.create_string_buffer(count)
        try:
            fn=self.k.WriteFile if data is not None else self.k.ReadFile
            success=fn(self.handle,buffer,len(data) if data is not None else count,c.byref(done),c.byref(op))
            if not success and c.get_last_error()!=997:raise OSError('Discord IPC rejected an operation')
            if not success and self.k.WaitForSingleObject(event,2000)!=0:
                self.k.CancelIoEx(self.handle,c.byref(op))
                # Drain cancellation before the overlapped buffer goes away.
                self.k.GetOverlappedResult(self.handle,c.byref(op),c.byref(done),True)
                raise TimeoutError('Discord IPC timed out')
            if not self.k.GetOverlappedResult(self.handle,c.byref(op),c.byref(done),False):raise OSError('Discord IPC operation failed')
            return done.value if data is not None else buffer.raw[:done.value]
        finally:self.k.CloseHandle(event)

    def recv(self,count):return self.io(count=count)

    def readable(self):
        available=self.c.c_ulong()
        self.k.PeekNamedPipe.argtypes=[self.c.c_void_p,self.c.c_void_p,self.c.c_ulong,self.c.c_void_p,self.c.POINTER(self.c.c_ulong),self.c.c_void_p]
        if not self.k.PeekNamedPipe(self.handle,None,0,None,self.c.byref(available),None):
            raise OSError('Discord IPC pipe disconnected')
        return available.value>0
    def sendall(self,data):
        if self.io(data)!=len(data):raise OSError('Discord IPC short write')
    def close(self):
        if self.handle:self.k.CloseHandle(self.handle);self.handle=None


def connect():
    if os.name=='nt':
        for number in range(10):
            try:return Pipe(r'\\?\pipe\discord-ipc-'+str(number))
            except OSError:pass
    else:
        roots=list(dict.fromkeys([os.environ.get(k) for k in ('XDG_RUNTIME_DIR','TMPDIR','TMP','TEMP') if os.environ.get(k)]+['/tmp']))
        for root in roots:
            if not os.path.isabs(root):continue
            for number in range(10):
                sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);sock.settimeout(.2)
                try:sock.connect(os.path.join(root,'discord-ipc-'+str(number)));sock.settimeout(2);return sock
                except OSError:sock.close()
    raise OSError('A desktop Discord IPC endpoint is not available')


def send(pipe,opcode,payload):
    body=json.dumps(payload,separators=(',',':'),allow_nan=False).encode()
    if len(body)>MAX_FRAME:raise ValueError('Discord payload exceeds its limit.')
    pipe.sendall(struct.pack('<II',opcode,len(body))+body)


def receive(pipe):
    def exact(n):
        pieces=[]
        while n:
            part=pipe.recv(n)
            if not part:raise OSError('Discord disconnected')
            pieces.append(part);n-=len(part)
        return b''.join(pieces)
    opcode,size=struct.unpack('<II',exact(8))
    if size>MAX_FRAME:raise ValueError('Discord frame exceeds its limit.')
    value=json.loads(exact(size))
    if not isinstance(value,dict):raise ValueError('Invalid Discord frame.')
    return opcode,value


def activity(*,private=False,details='',elapsed=None,template='Custom',world=None,instance=None,art=False,join=False,requests=False):
    result={'details':'Using VRC Eye','state':'VRChat companion'}
    if not private and details:result['details']=str(details)[:128]
    if not private and type(elapsed) is int and elapsed>0:result['timestamps']={'start':elapsed}
    if private:return result
    if world:
        from companion_data import entity_id
        ref=entity_id('world',world.get('id'));name=str(world.get('name') or ref)[:128]
        if template in ('World name','World and session'):result['details']=name;result['state']='Exploring in VRChat'
        if template=='World and session' and instance:
            result['state']='Public instance' if instance.kind=='public' else 'In VRChat'
        if art:
            from urllib.parse import urlsplit
            url=world.get('thumbnailImageUrl') or world.get('imageUrl') or ''
            try:u=urlsplit(url)
            except ValueError:u=None
            if u and u.scheme=='https' and u.hostname in ('api.vrchat.cloud','api.vrchat.com','files.vrchat.cloud','assets.vrchat.com') and not u.query and not u.fragment and not u.username and not u.password:
                result['assets']={'large_image':url,'large_text':name}
        if join and instance and instance.world==ref and instance.kind=='public' and not instance.closed and instance.active is not False and not instance.restricted:
            # Never publish owner, friend/group restrictions, nonces or hidden
            # capabilities. Only an explicitly inspected public instance.
            if re.fullmatch(r'[A-Za-z0-9_-]{1,64}(?:~region\((?:us|use|eu|jp)\))?',instance.instance):
                from urllib.parse import urlencode
                result['buttons']=[{'label':'Join public instance','url':'https://vrchat.com/home/launch?'+urlencode({'worldId':ref,'instanceId':instance.instance})}]
                if requests:
                    secret='vrc-eye:1:'+ref+':'+instance.instance
                    result.update(secrets={'join':secret},party={'id':secret},instance=True)
                    result.pop('buttons',None)
    return result


class Presence:
    def __init__(self,*,connector=connect,clock=time.monotonic):
        self.connector=connector;self.lock=threading.RLock();self.wake=threading.Event()
        self.thread=None;self.closed=False;self.enabled=False;self.application='';self.value=None;self.generation=0
        self.status='Disabled';self.release_failed=False
        self.clock=clock;self.requests={};self.decisions=[];self.invitations={};self.join_status='No join requests';self.ack_generation=-1

    def configure(self,enabled,application='',value=None):
        if enabled and not re.fullmatch(r'[0-9]{16,22}',application):raise ValueError('Enter your registered public Discord application ID.')
        with self.lock:
            next_value=deepcopy(value) if enabled and value else None
            if (bool(enabled),application,next_value)!=(self.enabled,self.application,self.value):
                self.enabled=bool(enabled);self.application=application;self.value=next_value;self.generation+=1;self.wake.set()
                self.requests.clear();self.decisions.clear();self.invitations.clear();self.join_status='No join requests'
                self.ack_generation=-1
            if enabled and not self.closed and not (self.thread and self.thread.is_alive()):
                self.thread=threading.Thread(target=self._run,daemon=True,name='VRC-Eye-Discord-Presence');self.thread.start()

    def _expire(self):
        now=self.clock()
        self.requests={key:row for key,row in self.requests.items() if now-row['received']<120 and row['generation']==self.generation}
        self.invitations={key:row for key,row in self.invitations.items() if now-row['received']<120 and row['generation']==self.generation}

    def pending_requests(self):
        with self.lock:
            self._expire();return deepcopy(list(self.requests.values()))

    def dispatch(self,row,generation=None):
        if row.get('cmd')=='DISPATCH' and row.get('evt')=='ACTIVITY_JOIN':
            data=row.get('data')
            try:world,instance=public_destination(data.get('secret') if isinstance(data,dict) else None)
            except ValueError:return
            with self.lock:
                if not self.enabled or generation is not None and generation!=self.generation:return
                self._expire();key=world+':'+instance
                if len(self.invitations)<25 and key not in self.invitations:
                    self.invitations[key]=dict(id=key,world=world,instance=instance,generation=self.generation,received=self.clock(),review=uuid.uuid4().hex)
            return
        if row.get('cmd')!='DISPATCH' or row.get('evt')!='ACTIVITY_JOIN_REQUEST':return
        data=row.get('data');user=data.get('user') if isinstance(data,dict) else None
        if not isinstance(user,dict) or not isinstance(user.get('id'),str) or not re.fullmatch(r'[0-9]{16,22}',user['id']):return
        with self.lock:
            if (generation is not None and generation!=self.generation) or self.ack_generation!=self.generation or not self.enabled or not (self.value or {}).get('secrets',{}).get('join'):return
            self._expire()
            if user['id'] in self.requests or len(self.requests)>=25:return
            name=''.join(c for c in str(user.get('global_name') or user.get('username') or 'Discord user') if c.isprintable())[:80]
            self.requests[user['id']]=dict(id=user['id'],name=name,received=self.clock(),generation=self.generation,review=uuid.uuid4().hex,state='Pending')
            self.join_status='Join request awaiting review'

    def pending_invitations(self):
        with self.lock:self._expire();return deepcopy(list(self.invitations.values()))

    def take_invitation(self,review):
        with self.lock:
            self._expire()
            if not self.enabled or self.invitations.get(review.get('id'))!=review:raise ValueError('The invitation expired or the presence context changed.')
            return self.invitations.pop(review['id'])

    def decide(self,review,accept):
        if type(accept) is not bool:raise ValueError('Choose accept or decline.')
        with self.lock:
            self._expire();row=self.requests.get(review.get('id'))
            if self.closed or not self.enabled or not row or row!=review or row['state']!='Pending':
                raise ValueError('This join request expired or the presence context changed.')
            if not (self.value or {}).get('secrets',{}).get('join'):raise ValueError('A current public instance is required.')
            row['state']='Queued';self.decisions.append((deepcopy(row),accept));self.wake.set()

    def rpc(self,pipe,cmd,args,*,event=None,generation=None):
        nonce=uuid.uuid4().hex;payload={'cmd':cmd,'args':args,'nonce':nonce}
        if event:payload['evt']=event
        with self.lock:
            if generation is not None and generation!=self.generation:raise ValueError('Discord presence context changed.')
            send(pipe,1,payload)
        deadline=self.clock()+4
        for _ in range(32):
            if self.clock()>deadline:raise TimeoutError('Discord acknowledgement timed out')
            op,row=receive(pipe)
            if op==3:send(pipe,4,row);continue
            if op==2:raise OSError('Discord closed the connection')
            if op==1 and row.get('nonce')==nonce:
                if row.get('evt')=='ERROR':raise ValueError('Discord rejected the presence update.')
                return
            if op==1:self.dispatch(row,generation)
        raise ValueError('Discord did not acknowledge this update.')

    def command(self,pipe,value):
        self.rpc(pipe,'SET_ACTIVITY',{'pid':os.getpid(),'activity':value},generation=self.generation)

    def _decisions(self,pipe,generation):
        for _ in range(25):
            with self.lock:
                self._expire()
                if generation!=self.generation or not self.enabled or not self.decisions:return
                review,accept=self.decisions.pop(0);current=self.requests.get(review['id'])
                if current!=review:continue
                # Consume before sending: an uncertain acknowledgement must
                # never cause automatic invitation replay on reconnect.
                del self.requests[review['id']]
                self.join_status='Join response unconfirmed'
            self.rpc(pipe,'SEND_ACTIVITY_JOIN_INVITE' if accept else 'CLOSE_ACTIVITY_REQUEST',{'user_id':review['id']},generation=generation)
            with self.lock:
                if generation!=self.generation:return
                self.join_status='Join invitation acknowledged' if accept else 'Join request declined'

    def _poll(self,pipe,generation):
        if hasattr(pipe,'readable'):ready=pipe.readable()
        else:
            import select
            ready=bool(select.select([pipe],[],[],0)[0])
        if not ready:return
        op,row=receive(pipe)
        if op==3:send(pipe,4,row)
        elif op==2:raise OSError('Discord closed the connection')
        elif op==1:self.dispatch(row,generation)

    def _run(self):
        pipe=None;registered='';sent=-1;failures=0;subscribed=False
        try:
            while not self.closed:
                with self.lock:enabled,app,value,generation=self.enabled,self.application,self.value,self.generation
                if not enabled:
                    if pipe:
                        try:self.command(pipe,None);self.release_failed=False
                        except Exception:self.release_failed=True
                        pipe.close();pipe=None
                    self.status='Disabled; release unconfirmed' if self.release_failed else 'Disabled'
                    self.wake.wait(.5);self.wake.clear();continue
                try:
                    if pipe is None or app!=registered:
                        if pipe:self.command(pipe,None);pipe.close()
                        pipe=self.connector();send(pipe,0,{'v':1,'client_id':app});op,ready=receive(pipe)
                        if op!=1 or ready.get('evt')!='READY':raise ValueError('Discord IPC handshake was not acknowledged.')
                        registered=app;sent=-1;subscribed=False
                        self.rpc(pipe,'SUBSCRIBE',{},event='ACTIVITY_JOIN',generation=generation)
                    if generation!=sent:
                        # Recheck under the owner lock immediately before sharing.
                        with self.lock:
                            if generation!=self.generation or not self.enabled:continue
                        self.rpc(pipe,'SET_ACTIVITY',{'pid':os.getpid(),'activity':value},generation=generation);sent=generation
                        with self.lock:
                            if generation==self.generation:self.ack_generation=generation
                        self.status='Presence acknowledged by desktop Discord';failures=0
                    wants=bool((value or {}).get('secrets',{}).get('join'))
                    if wants!=subscribed:
                        self.rpc(pipe,'SUBSCRIBE' if wants else 'UNSUBSCRIBE',{},event='ACTIVITY_JOIN_REQUEST',generation=generation)
                        subscribed=wants
                    self._decisions(pipe,generation)
                    self._poll(pipe,generation)
                    self.wake.wait(.25 if subscribed else 1);self.wake.clear()
                except Exception:
                    if pipe:
                        try:pipe.close()
                        except OSError:pass
                    pipe=None;self.status='Unavailable or update unconfirmed; retrying with backoff'
                    with self.lock:self.requests.clear();self.decisions.clear();self.invitations.clear();self.ack_generation=-1
                    failures=min(5,failures+1);self.wake.wait(min(60,2**failures));self.wake.clear()
        finally:
            if pipe:
                try:self.command(pipe,None);self.release_failed=False
                except Exception:self.release_failed=True
                pipe.close()
            self.status='Stopped; presence release unconfirmed' if self.release_failed else 'Stopped'

    def close(self):
        with self.lock:
            self.closed=True;self.enabled=False;self.requests.clear();self.decisions.clear();self.invitations.clear();self.generation+=1;self.wake.set()
