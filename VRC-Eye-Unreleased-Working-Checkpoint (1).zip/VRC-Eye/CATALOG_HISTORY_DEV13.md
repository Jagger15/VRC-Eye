# VRC Eye 1.21.0 — Development 13

This checkpoint adds the three agreed improvements to the complete Development 12 source baseline. It is a runnable Windows/Linux source ZIP. Extract into a new folder, then run **Start.cmd** on Windows or **Start.sh** on Linux. Launchers and requirements are unchanged.

## Friend and profile history

Open **Feed → Observed changes → Profile changes…**, then **Load history**. This opens the existing **Desktop controls → History & discovery** workspace with **Profile changes** selected. Its existing local analytics setting must be enabled. Choose a user ID, search old/new values, select a change category, or apply date and time-zone filters. Select a row to see its before/after values and source; **Export this view…** uses the existing reviewed CSV export.

The existing friend snapshots, live friend pipeline and explicit friend profile/group refresh now capture structured comparisons for available name, bio, pronoun, profile-link, status, presence, shared-location, current-avatar, picture/banner, platform, reported-tag and friendship fields, plus visible group-ID sets. This adds no new polling connection.

Each comparison stores the preceding field observation and the new observation time. The actual time of the remote change remains unknown. First observations establish a baseline; omitted/null/unsupported fields do not erase known values. Empty strings and valid empty lists can be explicit observations. List order changes and rotated image query tokens do not create false changes. Inferred location placeholders are excluded. A group appearing or disappearing means visibility changed, not a proven join/leave event.

The profile baseline and structured changes commit together in the existing account-local feed database. Repeated snapshots do not duplicate comparisons. Legacy feed rows stay readable; they are not retroactively assigned invented field-level timestamps. The existing feed retention/forget/export paths apply. Structured writes retain up to 5,000 feed events within a 32 MiB detail budget; older observations can therefore fall out of history.

This covers the named fields supplied to these producers. It is not exhaustive capture of every profile property, hidden information, all old VRCX schemas, or unobserved changes during disconnection.

## Avatar file health and exact matches

Open **Avatar Library → File health & matches**.

1. **Choose folder…** and review the folder to inspect.
2. **Find exact matches** hashes supported candidates and compares their SHA-256 and byte size with this account's recorded file references.
3. Select a result to inspect the reason, matching avatar/build associations, and duplicate files within the scanned set.
4. If multiple associations match, choose one explicitly, then **Review matching association…**.

Matching copies the existing reference's avatar/build/role association to a new file reference. It rechecks the candidate, source folder and original reference before commit. Equal bytes may have several recorded associations; neither filenames nor byte equality establish ownership. A stale candidate/reference requires a new scan. Existing references and physical files remain intact.

**Check recorded files…** hashes previously registered paths and records whether their bytes still match, changed, are missing, or cannot be read. It never replaces an original file or silently accepts a changed digest.

Each run hashes at most **128 files / 4 GiB**. Folder traversal retains the existing 4,096-entry, depth-six, 512-candidate limits. Coverage limits are displayed. All findings are observations at scan/check time. No full-drive scan, background auto-association, automatic duplicate deletion or semantic mesh comparison is added.

## Background catalog metadata updates

Open **Avatar Library → Metadata updates**. Choose **Selected avatar** or **Current filtered page**, then a policy:

- **Fill missing:** request entries with missing supported fields and preserve populated fields.
- **Refresh stale (7 days):** refresh fields whose provider observation is absent or older than seven days; preserve locally attached pictures.
- **Refresh selected:** review updating the supported fields of the selected entries even if already populated.

**Include thumbnails** optionally enables supported image reads. Pictures are decoded through the existing bounded image path and saved as small PNG thumbnails. Provider URLs and session credentials are excluded from the job receipts.

**Review & start batch…** shows the exact account, avatars and fields. The batch then advances in the background using the existing API transport, cache, request lock and pacing. It does not open a second login or friend-sync loop. The shared one-request-per-minute metadata budget can make batches take several minutes; 100 entries is the model limit, and the UI's filtered page is only the currently displayed rows.

Each item records updated fields, preserved concurrent edits, unavailable fields and its outcome. Notes, favorites and local/project references are retained. Provider observations and item completion commit together. Rate limits, authentication failures and temporary request failures stop the batch for review; a missing record is recorded as an item failure. No asset download, avatar selection or remote edit is performed.

**Cancel batch** stops remaining work. Completed entries remain recorded. Account/session/privacy/offline changes and window shutdown invalidate pending work. After restart, an unfinished job is shown as **Interrupted**. Select a receipt and choose **Review remaining items…** to prepare a new batch from current evidence; there is no automatic startup retry. Entries removed from the catalog are not recreated by late results.

Job recovery here covers catalog metadata publication. General resumable asset transfers, external recovery-process reconciliation and repair rollback remain open.

## Validation and remaining work

The new tests use synthetic accounts, files, image bytes and provider responses. They cover transactional rollback, deduplication, scope separation, missing/null values, stable group comparisons, query-token redaction, changed file evidence, ambiguous matches, bounded reads, metadata conflicts, rate limits, cancellation, restart receipts, image failures and headless UI workflows. Native drawing and a live VRChat account are separate acceptance checks.

See **VALIDATION_1_21.md** for final totals and exclusions, and **ARC_VRCX_REMAINING_DEV13.md** for the refreshed 106-area disposition and suggested follow-up work. All Development 12 session tools remain included.

The API adapter continues to use the existing GET-avatar contract. Public reference checks: [VRChat.community generated API reference](https://github.com/vrchatapi/vrchatapi-dart/blob/main/vrchat_dart_generated/README.md) and [community specification](https://github.com/vrchatapi/specification). These are community-maintained contracts; offline checks do not establish live service entitlement or future compatibility.
