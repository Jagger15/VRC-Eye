"""Resumable reviewed batches; each dispatch still has its own action receipt.

Persist intent before dispatch. Approval is in memory, account-bound, one-use,
and expires after five minutes; reopening never resumes sending by itself.
"""
from contextlib import contextmanager
from dataclasses import dataclass
import json
import time
import uuid
from companion_data import entity_id, stamp
from vrcx_sources import stopped
import native_api as api

GROUP_ACTIONS=frozenset(('group-invite','group-cancel-invite','group-kick','group-ban','group-unban',
 'group-accept-request','group-reject-request','group-block-request','group-role-add','group-role-remove'))
CONTENT_ACTIONS=frozenset(('world-edit','world-publish','world-unpublish','update-owned-avatar'))


def intent(action, target, group='', values=None):
    values=values or {}
    if action in GROUP_ACTIONS:
        target=entity_id('user',target);group=entity_id('group',group)
        if action in ('group-role-add','group-role-remove'):
            if set(values)!={'roleId'}:raise ValueError('Select one group role for this batch.')
            values={'roleId':api.reference(values['roleId'],('grol',))}
        elif values:raise ValueError('This member action takes no editable fields.')
    elif action in CONTENT_ACTIONS:
        target=entity_id('avatar' if action=='update-owned-avatar' else 'world',target);group=''
        if action=='world-edit':values=api.patch(values,api.WORLD)
        elif action=='update-owned-avatar':
            from owned_avatars import EDITABLE,plain,_tags
            if not values or set(values)-set(EDITABLE):raise ValueError('Select supported avatar metadata fields.')
            values=dict(values)
            for key,value in values.items():
                if key=='tags':values[key]=list(_tags(value))
                elif key=='releaseStatus':
                    if value not in ('public','private'):raise ValueError('Choose public or private.')
                else:plain(value,100 if key=='name' else 5000,multiline=key=='description',empty=False)
        elif values:raise ValueError('Publish actions have no extra fields.')
    else:raise ValueError('This operation is not available in reviewed batches.')
    return dict(action=action,target=target,group=group,values=values)


@dataclass(frozen=True)
class Approval:
    id:str
    batch:str
    account:str
    rows:tuple
    token:tuple
    expires:float


class Batches:
    def __init__(self,service,*,clock=time.monotonic):
        self.service=service;self.clock=clock;self.approvals={}
        with self.connect() as db:
            # A prior process may have stopped at any instruction. Only a
            # durable action receipt can resolve its claimed queue entry.
            for row in db.execute("SELECT id,receipt FROM native_batch_items WHERE state='Claimed' AND run<>?",(service.run,)).fetchall():
                receipt=db.execute('SELECT state FROM social_receipts_v3 WHERE id=?',(row['receipt'],)).fetchone()
                state=receipt['state'] if receipt else 'Not sent'
                if state not in ('Confirmed','Rejected','Not sent'):state='Uncertain'
                db.execute('UPDATE native_batch_items SET state=? WHERE id=?',(state,row['id']))

    @contextmanager
    def connect(self):
        with self.service.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS native_batches(id TEXT PRIMARY KEY,account TEXT NOT NULL,created TEXT NOT NULL,label TEXT NOT NULL)')
            db.execute('''CREATE TABLE IF NOT EXISTS native_batch_items(id TEXT PRIMARY KEY,batch TEXT NOT NULL,
                ordinal INTEGER NOT NULL,intent TEXT NOT NULL,state TEXT NOT NULL,receipt TEXT NOT NULL,run TEXT NOT NULL)''')
            yield db

    def create(self,label,intents):
        token=self.service.token();self.service.check(token)
        if not 1<=len(intents)<=1000:raise ValueError('Queue between 1 and 1,000 exact targets.')
        rows=[intent(**row) for row in intents]
        if len({json.dumps(r,sort_keys=True) for r in rows})!=len(rows):raise ValueError('Remove duplicate batch targets.')
        ref=uuid.uuid4().hex
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE');self.service.check(token)
            db.execute('INSERT INTO native_batches VALUES(?,?,?,?)',(ref,token[1],stamp(),str(label)[:200]))
            db.executemany('INSERT INTO native_batch_items VALUES(?,?,?,?,?,?,?)',
                [(uuid.uuid4().hex,ref,i,json.dumps(r), 'Pending','','') for i,r in enumerate(rows)])
        return ref

    def list(self):
        own=self.service.token()[1]
        with self.connect() as db:return [dict(r) for r in db.execute('SELECT * FROM native_batches WHERE account=? ORDER BY created DESC LIMIT 200',(own,))]

    def rows(self,batch):
        own=self.service.token()[1]
        with self.connect() as db:
            if not db.execute('SELECT 1 FROM native_batches WHERE id=? AND account=?',(batch,own)).fetchone():raise ValueError('Select a batch for the active account.')
            return [dict(r,proposal=json.loads(r['intent'])) for r in db.execute('SELECT * FROM native_batch_items WHERE batch=? ORDER BY ordinal',(batch,))]

    def prepare(self,batch):
        rows=self.rows(batch);pending=tuple((r['id'],r['intent']) for r in rows if r['state'] in ('Pending','Not sent'))
        if not pending:raise ValueError('No unsent items remain. Uncertain, rejected and completed items are never automatically retried.')
        token=self.service.token();approval=Approval(uuid.uuid4().hex,batch,token[1],pending,token,self.clock()+300)
        self.approvals={approval.id:approval};return approval

    def discard(self,approval):self.approvals.pop(approval.id,None)

    def run(self,approval,*,stop=None,progress=None):
        if self.approvals.pop(getattr(approval,'id',None),None) is not approval:raise ValueError('Review the remaining batch again.')
        def check():
            stopped(stop);self.service.check(approval.token,stop)
            if self.clock()>=approval.expires:raise ValueError('Batch approval expired. Review the remaining targets to continue.')
        completed=[]
        for ref,raw in approval.rows:
            review=None
            try:
                check();row=intent(**json.loads(raw));c=approval.token[0]
                if row['action'] in GROUP_ACTIONS:
                    snapshot=api.read(c,'group',subject=row['group'],stop=stop,progress=progress)
                elif row['action']=='update-owned-avatar':
                    from owned_avatars import read_avatar
                    snapshot=read_avatar(c,row['target'],stop=stop,progress=progress)
                else:snapshot=api.read(c,'world',subject=row['target'],stop=stop,progress=progress)
                check();review=self.service.prepare(row['action'],result=snapshot,target=row['target'],values=row['values'])
                # Clamp the individual review to this batch's approval window.
                # The ordinary service continues checking its own review TTL.
                with self.connect() as db:
                    db.execute('BEGIN IMMEDIATE');check()
                    changed=db.execute("UPDATE native_batch_items SET state='Claimed',receipt=?,run=? WHERE id=? AND batch=? AND intent=? AND state IN ('Pending','Not sent')",
                        (review.id,self.service.run,ref,approval.batch,raw)).rowcount
                    if changed!=1:raise ValueError('This queue item changed or was already claimed.')
                # A narrow proxy stop also enforces approval expiry after any
                # shared transport wait, immediately before dispatch.
                class BoundStop:
                    def is_set(inner):return bool(stop and stop.is_set()) or self.clock()>=approval.expires
                    def wait(inner,seconds):
                        if stop:return stop.wait(min(seconds,max(0,approval.expires-self.clock()))) or inner.is_set()
                        time.sleep(min(seconds,max(0,approval.expires-self.clock())));return inner.is_set()
                outcome=self.service.execute(review,stop=BoundStop(),progress=progress)
                with self.connect() as db:db.execute('UPDATE native_batch_items SET state=? WHERE id=? AND receipt=?',(outcome.state,ref,review.id))
                completed.append(outcome)
                if outcome.state!='Confirmed':break
            except Exception:
                if review:
                    with self.connect() as db:
                        receipt=db.execute('SELECT state FROM social_receipts_v3 WHERE id=?',(review.id,)).fetchone()
                        state=receipt['state'] if receipt else 'Not sent'
                        if state not in ('Confirmed','Rejected','Not sent'):state='Uncertain'
                        db.execute("UPDATE native_batch_items SET state=? WHERE id=? AND receipt=? AND state='Claimed'",(state,ref,review.id))
                raise
            finally:
                if review:self.service.discard(review)
        return completed


def service_for(shell):
    from account_actions import service_for as actions
    service=actions(shell)
    value=getattr(shell,'native_batches',None)
    if value is None or value.service is not service:value=Batches(service);shell.native_batches=value
    return value
