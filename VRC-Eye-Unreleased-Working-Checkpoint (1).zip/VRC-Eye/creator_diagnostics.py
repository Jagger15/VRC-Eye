"""Bounded local creator evidence. Observations never imply world authority.

This module opens no sockets, installs no hooks, and never tails a file itself.
Its caller deliberately supplies observations from already available sources.
"""
from collections import Counter, deque
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import statistics
import time

from game_log import HEADER, redact
from world_players import log_epoch

MAX_OBSERVATIONS = 2000
MAX_BOOKMARK_EVENTS = 100
KINDS = frozenset(("error", "warning", "log", "join", "leave", "population", "metric",
    "action", "helper", "assertion", "bookmark", "build", "phase", "reported_problem",
    "process_exit", "coverage", "zone"))
SEVERITIES = frozenset(("debug", "info", "warning", "error", "fatal", "unknown"))
QUALITIES = frozenset(("observed", "reported", "measured", "partial", "unavailable",
    "single_sample", "helper_declared", "unknown", "complete"))
LOG_MODES = frozenset(("unknown", "ordinary", "build_and_test", "debug_logging"))


def _text(value, limit=1000):
    return redact(str(value or "").replace("\x00", ""))[:limit]


def _number(value, *, nonnegative=False):
    if value is None:
        return None
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("A measurement must be a finite number or unknown.")
    if nonnegative and value < 0:
        raise ValueError("This measurement cannot be negative.")
    return value


def _iso(stamp):
    try:
        return datetime.fromtimestamp(stamp, timezone.utc).isoformat()
    except (ValueError, OverflowError, OSError):
        return ""


def _rows(store, kind, world_id=None, limit=10000):
    return store.list(kind=kind, world_id=world_id, limit=limit)


def _data(record):
    return record.get("data", {})


class CreatorDiagnostics:
    def __init__(self, store, limit=MAX_OBSERVATIONS, *, clock=time.time,
                 monotonic=time.monotonic, max_per_second=200):
        if type(limit) is not int or not 10 <= limit <= MAX_OBSERVATIONS:
            raise ValueError("Observation retention must be between 10 and 2000 records.")
        self.store, self.limit = store, limit
        self.clock, self.monotonic = clock, monotonic
        self.max_per_second = max(1, min(1000, int(max_per_second)))
        self._arrivals = deque()
        self._seen = deque(maxlen=4000)
        self._seen_set = set()
        self._rosters = {}
        self.dropped = 0
        self.trimmed = 0
        self.protected = 0
        self.capture_seconds = 0.0
        self.started = monotonic()
        self.sequence = 0
        self.recording_id = hashlib.sha256(f"{clock()}:{self.started}:{id(self)}".encode()).hexdigest()[:24]
        existing = _rows(store, "observation")
        self._retained = deque(r["id"] for r in sorted(existing,
            key=lambda r: (_data(r).get("receipt_time", 0), r.get("created_at", ""))))
        self._trim()

    def _trim(self):
        if len(self._retained) > self.limit:
            if hasattr(self.store, "prune_observations"):
                result = self.store.prune_observations(keep=self.limit)
                self.trimmed += result["removed"]
                self.protected = result["protected"]
                existing = _rows(self.store, "observation", limit=20000)
                self._retained = deque(r["id"] for r in sorted(existing,
                    key=lambda r: _data(r).get("receipt_time", 0)))
            else:
                while len(self._retained) > self.limit:
                    self.store.delete(self._retained.popleft())
                    self.trimmed += 1

    def _deduplicate(self, key):
        if key in self._seen_set:
            return True
        if len(self._seen) == self._seen.maxlen:
            self._seen_set.discard(self._seen[0])
        self._seen.append(key)
        self._seen_set.add(key)
        return False

    def observe(self, world_id, kind, summary, source, *, scope="local", build_id=None,
                run_id=None, event_time=None, quality="observed", severity="info",
                subsystem="", object_id="", value=None, unit="", period_seconds=None,
                sample_count=None, zone="", step_id="", clock_uncertainty=None,
                source_event_id=None, details=None):
        """Record one selected event. A missing measurement stays None, never zero."""
        if kind not in KINDS or quality not in QUALITIES or severity not in SEVERITIES:
            raise ValueError("Unknown observation kind, quality, or severity.")
        if not isinstance(world_id, str) or not world_id.strip():
            raise ValueError("A world workspace is required.")
        if not source or not scope:
            raise ValueError("Evidence needs a source and scope.")
        value = _number(value)
        period_seconds = _number(period_seconds, nonnegative=True)
        clock_uncertainty = _number(clock_uncertainty, nonnegative=True)
        event_time = _number(event_time)
        if sample_count is not None and (type(sample_count) is not int or sample_count < 0):
            raise ValueError("Sample count must be a nonnegative integer or unknown.")
        if value is not None and kind == "metric" and not unit:
            raise ValueError("A metric needs its actual unit.")
        if source_event_id is not None:
            key = (world_id, source, build_id, run_id, str(source_event_id))
            if self._deduplicate(key):
                return None
        began = self.monotonic()
        while self._arrivals and began - self._arrivals[0] >= 1:
            self._arrivals.popleft()
        if len(self._arrivals) >= self.max_per_second:
            self.dropped += 1
            return None
        self._arrivals.append(began)
        self.sequence += 1
        received = self.clock()
        payload = dict(kind=kind, summary=_text(summary, 4000), source=_text(source, 160),
            scope=_text(scope, 160), build_id=_text(build_id, 128) or None,
            run_id=_text(run_id, 128) or None, event_time=event_time,
            receipt_time=received, receipt_iso=_iso(received),
            elapsed_seconds=max(0., began - self.started), sequence=self.sequence,
            recording_id=self.recording_id, quality=quality, severity=severity,
            subsystem=_text(subsystem, 160), object_id=_text(object_id, 160), value=value,
            unit=_text(unit, 48), period_seconds=period_seconds, sample_count=sample_count,
            zone=_text(zone, 160), step_id=_text(step_id, 128),
            clock_uncertainty_seconds=clock_uncertainty)
        if details is not None:
            if not isinstance(details, dict):
                raise ValueError("Observation details must be an object.")
            encoded = json.dumps(details, allow_nan=False)
            if len(encoded.encode("utf-8")) > 8000:
                raise ValueError("Observation details exceed the local record budget.")
            payload["details"] = json.loads(redact(encoded))
        if kind in ("error", "warning"):
            # Exact text is intentional: numbers, objects and builds can matter.
            grouped = [payload[k] for k in ("summary", "source", "scope", "build_id", "subsystem", "object_id", "severity")]
            payload["error_group"] = hashlib.sha256(json.dumps(grouped, sort_keys=True).encode()).hexdigest()[:24]
        record = self.store.save("observation", world_id, payload)
        self._retained.append(record["id"])
        self._trim()
        self.capture_seconds += max(0., self.monotonic() - began)
        return record

    def ingest_log(self, world_id, line, *, source="VRChat log", build_id=None,
                   run_id=None, logging_mode="unknown", source_event_id=None):
        if logging_mode not in LOG_MODES:
            raise ValueError("Unknown log capture configuration.")
        if hasattr(line, "message"):
            message, severity, stamp = line.message, line.severity, line.stamp
            source_event_id = source_event_id or f"{getattr(line, 'source', '')}:{line.serial}:{stamp}"
            source = source or "VRChat log"
        else:
            match = HEADER.match(str(line))
            stamp, severity, message = match.groups() if match else ("", "unknown", str(line))
        severity = severity.lower()
        if severity in ("exception", "assert"):
            severity = "error"
        if severity in ("log", "continuation"):
            severity = "info"
        if severity not in SEVERITIES:
            severity = "unknown"
        lower = message.casefold()
        if "udonvmexception" in lower and severity not in ("error", "fatal"):
            severity = "error"
        kind = "error" if severity in ("error", "fatal") else "warning" if severity == "warning" else "log"
        if kind == "log":
            if re.search(r"\bOnPlayerJoined\b", message):
                kind = "join"
            elif re.search(r"\bOnPlayerLeft\b", message):
                kind = "leave"
        # Prefixes are descriptive evidence, never authenticated helper messages.
        subsystem = "Udon" if "udon" in lower else ""
        return self.observe(world_id, kind, message, source, build_id=build_id,
            run_id=run_id, event_time=log_epoch(stamp) if stamp else None,
            severity=severity, subsystem=subsystem, source_event_id=source_event_id,
            details={"logging_mode": logging_mode, "helper_authenticated": False,
                     "interpretation": "Departure observed; reason unknown." if kind == "leave" else
                        "Arrival entry observed." if kind == "join" else "Selected log evidence.",
                     "coverage": "Selected local log entries; detailed Udon coverage may be unavailable."})

    def ingest_roster(self, world_id, roster, *, build_id=None, run_id=None):
        """Record aggregate observed population; never retain participant identifiers."""
        if getattr(roster, "world_id", "") and roster.world_id != world_id:
            return None
        identity = tuple(getattr(roster, "identity", (getattr(roster, "source", ""),)))
        revision = getattr(roster, "revision", None)
        key = (world_id, identity, build_id, run_id)
        previous = self._rosters.get(key)
        if previous and previous[0] == revision:
            return None
        visits = getattr(roster, "visits", ())
        active = [v for v in visits if getattr(v, "active", False)]
        # Duplicate records reconcile by stable local identifier, otherwise name.
        unique = {(getattr(v, "user_id", "") or getattr(v, "name", "") or str(getattr(v, "serial", ""))) for v in active}
        count = len(unique)
        dropped = max(0, int(getattr(roster, "dropped", 0)))
        initial = previous is None
        self._rosters[key] = (revision, count)
        if len(self._rosters) > 64:
            self._rosters.pop(next(iter(self._rosters)))
        ended = bool(getattr(roster, "ended", ""))
        return self.observe(world_id, "population", "Observation ended" if ended else "Population observed",
            "local roster", scope="observed instance population", build_id=build_id, run_id=run_id,
            quality="partial", value=None if ended else count,
            unit="players", sample_count=1, details={"initial_observation": initial,
                "baseline_known": False, "complete_roster": False,
                "delta_observed": None if initial or ended else count - previous[1],
                "dropped_roster_entries": dropped, "ended": ended,
                "limitation": "Observed population only; missing arrivals and departures remain unknown."})

    def timeline(self, world_id, *, kind=None, severity=None, build_id=None, run_id=None,
                 source=None, subsystem=None, object_id=None, step_id=None, since=None,
                 until=None, query="", limit=500):
        if not 1 <= int(limit) <= MAX_OBSERVATIONS:
            raise ValueError("Timeline limit must be between 1 and 2000.")
        matches = []
        filters = dict(kind=kind, severity=severity, build_id=build_id, run_id=run_id,
                       source=source, subsystem=subsystem, object_id=object_id, step_id=step_id)
        for record in _rows(self.store, "observation", world_id):
            data = _data(record)
            if any(v is not None and data.get(k) != v for k, v in filters.items()):
                continue
            stamp = data.get("receipt_time", 0)
            if since is not None and stamp < since or until is not None and stamp > until:
                continue
            if query and query.casefold() not in data.get("summary", "").casefold():
                continue
            matches.append(record)
        # Local monotonic sequence is authoritative inside a recording. Receipt
        # wall time across recordings is approximate, not synchronized event time.
        groups = {}
        for record in matches:
            data = _data(record)
            groups.setdefault(data.get("recording_id", ""), []).append(record)
        ordered = []
        for group in sorted(groups.values(), key=lambda g: min(_data(r).get("receipt_time", 0) for r in g)):
            ordered.extend(sorted(group, key=lambda r: _data(r).get("sequence", 0)))
        return ordered[-int(limit):]

    def error_groups(self, world_id, **filters):
        groups = {}
        for record in self.timeline(world_id, limit=self.limit, **filters):
            data = _data(record)
            if data.get("kind") not in ("error", "warning"):
                continue
            key = data.get("error_group", record["id"])
            group = groups.setdefault(key, dict(id=key, summary=data["summary"],
                source=data["source"], severity=data["severity"], build_id=data.get("build_id"),
                subsystem=data.get("subsystem", ""), object_id=data.get("object_id", ""),
                first=data["receipt_time"], last=data["receipt_time"], count=0,
                record_ids=[], run_ids=[]))
            group["count"] += 1
            group["first"] = min(group["first"], data["receipt_time"])
            group["last"] = max(group["last"], data["receipt_time"])
            group["record_ids"].append(record["id"])
            if data.get("run_id") and data["run_id"] not in group["run_ids"]:
                group["run_ids"].append(data["run_id"])
        return sorted(groups.values(), key=lambda g: g["last"], reverse=True)

    def health(self, world_id, *, run_id=None, max_age=15):
        rows = self.timeline(world_id, run_id=run_id, limit=self.limit)
        now = self.clock()
        metrics = {}
        errors = 0
        for record in rows:
            data = _data(record)
            if data.get("kind") == "error":
                errors += 1
            if data.get("kind") == "metric":
                key = (data["summary"], data["source"], data["scope"], data["unit"])
                age = max(0., now - data["receipt_time"])
                metrics[key] = dict(data, record_id=record["id"], age_seconds=age,
                    stale=age > max_age, available=age <= max_age and data.get("value") is not None)
        responsive = any(m["available"] and m.get("summary", "").casefold() in ("fps", "frame_ms", "frame time", "frame time (ms)") for m in metrics.values())
        network = any(m["available"] and any(word in m.get("summary", "").casefold() for word in ("network", "latency", "serialization", "queue", "synchronization")) for m in metrics.values())
        return dict(metrics=list(metrics.values()), errors_observed=errors if rows else None,
            dimensions={"stability": "Observed evidence" if errors else "No errors in selected evidence" if rows else "Unknown",
                "responsiveness": "Local frame measurements available" if responsive else "Unknown",
                "networking": "Source-specific networking measurements available" if network else "Unknown",
                "interaction_correctness": "Requires checklist or assertion evidence",
                "test_coverage": "Selected evidence only"},
            limitations=["No overall health score is inferred.", "No errors observed does not prove complete log coverage.",
                "Process memory is process-wide; local performance is not world-wide performance."],
            retention=self.retention_status())

    def bookmark(self, world_id, label="", *, seconds_before=30, observation_ids=None,
                 build_id=None, run_id=None, marker_type="manual", note="", zone="", step_id=""):
        if marker_type not in ("manual", "error", "comparison", "location"):
            raise ValueError("Unknown bookmark type.")
        seconds_before = _number(seconds_before, nonnegative=True)
        if seconds_before is None or seconds_before > 3600:
            raise ValueError("Bookmark context must be at most one hour.")
        now = self.clock()
        if observation_ids is None:
            chosen = self.timeline(world_id, build_id=build_id, run_id=run_id,
                since=now - seconds_before, limit=MAX_OBSERVATIONS)
        else:
            chosen = []
            for identifier in dict.fromkeys(observation_ids):
                row = self.store.get(identifier)
                if row is None or row.get("kind") != "observation" or row.get("world_id") != world_id:
                    raise ValueError("Bookmark evidence must belong to this world.")
                if build_id is not None and _data(row).get("build_id") != build_id:
                    raise ValueError("Bookmark evidence belongs to a different build.")
                if run_id is not None and _data(row).get("run_id") != run_id:
                    raise ValueError("Bookmark evidence belongs to a different run.")
                chosen.append(row)
        omitted = max(0, len(chosen) - MAX_BOOKMARK_EVENTS)
        chosen = chosen[-MAX_BOOKMARK_EVENTS:]
        # Snapshot selected evidence so ring expiry cannot break portable reports.
        while chosen and len(json.dumps(chosen).encode("utf-8")) > 48000:
            chosen.pop(0)
            omitted += 1
        return self.store.save("bookmark", world_id, dict(label=_text(label, 160) or "Incident marker",
            marker_type=marker_type, note=_text(note, 4000), zone=_text(zone, 160),
            step_id=_text(step_id, 128), build_id=build_id, run_id=run_id,
            recorded_at=now, interval_start=now - seconds_before, interval_end=now,
            observation_ids=[r["id"] for r in chosen], evidence=chosen, omitted_evidence=omitted,
            limitations=["Only already-received evidence is preserved; no future samples are implied."] ))

    def retention_status(self):
        return dict(limit=self.limit, retained=len(self._retained), trimmed=self.trimmed,
            dropped=self.dropped, protected=self.protected, max_events_per_second=self.max_per_second,
            capture_seconds=self.capture_seconds, recording_elapsed_seconds=max(0., self.monotonic() - self.started),
            byte_budget_note="Latest evidence ring plus explicitly referenced evidence; total store budget remains 64 MiB. Bookmarks have separate 48 KB evidence budgets.")


def capacity_summary(records, target_fps=90, *, envelope=None):
    """Describe measured frame times; do not change published capacity."""
    target_fps = _number(target_fps, nonnegative=True)
    if target_fps is None or not 1 <= target_fps <= 1000:
        raise ValueError("Target FPS must be between 1 and 1000.")
    groups = {}
    populations = []
    for row in records:
        data = _data(row)
        if data.get("kind") == "population" and data.get("value") is not None:
            populations.append(data["value"])
        if data.get("kind") != "metric" or data.get("unit") not in ("ms", "milliseconds") or data.get("value") is None:
            continue
        if data.get("summary", "").casefold() not in ("frame time", "frame_ms", "frame time (ms)"):
            continue
        key = (data.get("source"), data.get("scope"), data.get("build_id"), data.get("run_id"))
        groups.setdefault(key, []).append(data["value"])
    budget = 1000. / target_fps
    summaries = []
    for key, values in groups.items():
        ordered = sorted(values)
        summaries.append(dict(source=key[0], scope=key[1], build_id=key[2], run_id=key[3],
            count=len(values), median_ms=statistics.median(values),
            p95_ms=ordered[max(0, math.ceil(len(ordered) * .95) - 1)], maximum_ms=max(values),
            samples_within_target=sum(v <= budget for v in values), repeated=len(values) >= 3))
    envelope = envelope if isinstance(envelope, dict) else {}
    required = ("build", "platform", "graphics", "avatars", "features", "duration", "route", "instrumentation")
    return dict(target_fps=target_fps, frame_budget_ms=budget, groups=summaries,
        observed_population_range=[min(populations), max(populations)] if populations else None,
        missing_envelope=[k for k in required if not envelope.get(k)],
        limitations=["Observed samples are not a maximum-capacity recommendation.",
            "Distributions describe selected point samples, not a complete frame trace.",
            "Source and run groups remain separate. Larger populations and untested platforms remain unknown.",
            "Overlay and diagnostic overhead belong in the test configuration."])


def zone_coverage(records):
    zones = {}
    for record in records:
        data = _data(record)
        if not data.get("zone"):
            continue
        zone = zones.setdefault(data["zone"], dict(zone=data["zone"], observations=0, metrics=0, runs=set()))
        zone["observations"] += 1
        zone["metrics"] += int(data.get("kind") == "metric" and data.get("value") is not None)
        if data.get("run_id"):
            zone["runs"].add(data["run_id"])
    return [dict(z, runs=sorted(z["runs"]), coverage="Repeated runs" if len(z["runs"]) > 1 else "Single run or unknown run")
            for z in zones.values()]


def soak_summary(records):
    groups = {}
    for record in records:
        data = _data(record)
        if data.get("kind") != "metric" or data.get("value") is None:
            continue
        key = tuple(data.get(k) for k in ("summary", "source", "scope", "unit", "build_id", "run_id", "recording_id"))
        groups.setdefault(key, []).append(data)
    result = []
    for key, rows in groups.items():
        rows.sort(key=lambda r: (r.get("recording_id", ""), r.get("sequence", 0)))
        a, b = rows[0], rows[-1]
        elapsed = b.get("elapsed_seconds", 0) - a.get("elapsed_seconds", 0) if a.get("recording_id") == b.get("recording_id") else None
        result.append(dict(metric=key[0], source=key[1], scope=key[2], unit=key[3],
            build_id=key[4], run_id=key[5], recording_id=key[6], count=len(rows), first=a["value"], last=b["value"],
            delta=b["value"] - a["value"], period_seconds=elapsed,
            interpretation="Observed change; cause and leak status are unconfirmed."))
    return result


def network_summary(records, *, budgets=None, documented_constraints=None):
    """Compare like-for-like samples with creator budgets, not internet quality.

    Budgets are explicit {metric: {value, unit, source, scope}} values. Documented
    limits are optional creator-supplied versioned references, never hard-coded
    as assumptions about every VRChat SDK or helper implementation.
    """
    budgets = budgets or {}
    if not isinstance(budgets, dict):
        raise ValueError("Network budgets must be named measurement budgets.")
    for name, budget in budgets.items():
        if not isinstance(name, str) or not isinstance(budget, dict):
            raise ValueError("Invalid network budget.")
        if _number(budget.get("value"), nonnegative=True) is None or not all(budget.get(k) for k in ("unit", "source", "scope")):
            raise ValueError("Each network budget needs a value, unit, source, and scope.")
    constraints = []
    for limit in documented_constraints or []:
        if not isinstance(limit, dict) or not all(limit.get(k) for k in ("version", "reference", "description")):
            raise ValueError("Documented constraints need their version, reference, and description.")
        constraints.append({k: _text(limit[k], 1000) for k in ("version", "reference", "description")})
    groups = {}
    for record in records:
        data = _data(record)
        if data.get("kind") != "metric" or data.get("value") is None:
            continue
        key = tuple(data.get(k) for k in ("summary", "source", "scope", "unit", "build_id", "run_id"))
        groups.setdefault(key, []).append(dict(data, _record_id=record.get("id")))
    rows = []
    for key, values in groups.items():
        name, source, scope, unit, build_id, run_id = key
        # Only source/metric labels deliberately supplied as networking evidence
        # qualify; a generic frame or memory sample is not a network statistic.
        network_words = ("network", "serialization", "outbound", "queue", "latency", "completion", "synchronization", "sync_delay", "throughput")
        if not any(word in str(name).casefold() for word in network_words):
            continue
        budget = budgets.get(name)
        comparable = bool(budget and all(budget[k] == value for k, value in (("source", source), ("scope", scope), ("unit", unit))))
        samples = [r["value"] for r in values]
        above = sum(v > budget["value"] for v in samples) if comparable else None
        rows.append(dict(metric=name, source=source, scope=scope, unit=unit, build_id=build_id,
            run_id=run_id, sample_count=len(samples), minimum=min(samples), maximum=max(samples),
            median=statistics.median(samples), budget=budget["value"] if comparable else None,
            samples_above_budget=above, repeated_exceedance=above is not None and above >= 3,
            budget_comparable=comparable, record_ids=[r.get("_record_id") for r in values]))
    return dict(measurements=rows, documented_constraints=constraints,
        limitations=["Peer-service latency, VRChat synchronization, and helper command completion are distinct measurements.",
            "Only deliberately supplied instrumented measurements are analyzed.",
            "Repeated above-budget samples are an observed pattern, not proof of the action that caused it."])


def compare_observations(baseline, candidate, *, comparable=False, reasons=None):
    """Compare selected run evidence after workflows has checked the envelopes.

    A caller must explicitly pass the workflow comparison's comparable result.
    Missing sources or mismatched units/windows never acquire a numerical delta.
    Multiple samples are not automatically a confirmed, repeatable regression.
    """
    if type(comparable) is not bool:
        raise ValueError("Comparison compatibility must be a checked boolean result.")

    def grouped(records):
        metrics, errors = {}, {}
        for record in records:
            data = _data(record)
            if data.get("kind") == "metric" and type(data.get("value")) in (int, float):
                key = tuple(data.get(k) for k in ("summary", "source", "scope", "unit", "period_seconds"))
                metrics.setdefault(key, []).append(data["value"])
            elif data.get("kind") == "error":
                # Builds intentionally differ in a baseline comparison; object,
                # source and exact diagnostic text still distinguish findings.
                key = tuple(data.get(k) for k in ("summary", "source", "scope", "object_id", "subsystem", "severity"))
                row = errors.setdefault(key, dict(summary=data.get("summary", ""),
                    source=data.get("source", ""), scope=data.get("scope", ""), object_id=data.get("object_id", ""),
                    subsystem=data.get("subsystem", ""), count=0, record_ids=[]))
                row["count"] += 1
                row["record_ids"].append(record.get("id"))
        return metrics, errors

    before, prior_errors = grouped(baseline)
    after, current_errors = grouped(candidate)
    rows = []
    for key in sorted(set(before) | set(after), key=str):
        a, b = before.get(key, []), after.get(key, [])
        prior = statistics.median(a) if a else None
        current = statistics.median(b) if b else None
        allowed = comparable and bool(a and b)
        rows.append(dict(metric=key[0], source=key[1], scope=key[2], unit=key[3],
            period_seconds=key[4], baseline=prior, candidate=current,
            baseline_samples=len(a), candidate_samples=len(b),
            delta=current-prior if allowed else None,
            percent_change=(current-prior)/prior*100 if allowed and prior != 0 else None,
            compatible=allowed, multiple_samples=min(len(a), len(b)) >= 3))
    warnings = list(reasons or [])
    if not comparable:
        warnings.append("Run configuration compatibility is unconfirmed or rejected; measurement deltas are withheld.")
    warnings.extend(("Different sources, scopes, units, and measurement windows remain separate.",
        "A candidate-only error means it was absent from the selected baseline evidence, not that the baseline was error-free.",
        "A measured difference is not a confirmed cause or repeatable regression."))
    return dict(comparable=comparable, metrics=rows,
        candidate_only_errors=[current_errors[k] for k in current_errors.keys() - prior_errors.keys()],
        recurring_errors=[dict(current_errors[k], baseline_count=prior_errors[k]["count"])
                          for k in current_errors.keys() & prior_errors.keys()],
        baseline_only_errors=[prior_errors[k] for k in prior_errors.keys() - current_errors.keys()],
        warnings=warnings)
