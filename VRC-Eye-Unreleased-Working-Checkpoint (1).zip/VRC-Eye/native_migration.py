"""Selective VRCX 2026.09.16 readers into VRC Eye's native record authority.

Contracts: upstream src/services/database/index.js and config.js. No upstream
implementation is copied. Only declared physical tables/columns are read.
"""
from contextlib import contextmanager
from dataclasses import dataclass,field
from datetime import datetime,timezone,timedelta
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlsplit,urlunsplit
import json
import re
import sqlite3
import time

from companion_data import entity_id,reference,stamp
from native_library import NativeLibrary,scope,plain,clean,canonical,document,identity,validate_record,MAX_BATCH
from vrcx_sources import source,stopped

# table -> (category, declared columns). Account-prefixed tables are matched only
# after reconstructing an exact usr_UUID; display names never establish scope.
GLOBAL={
 'cache_avatar':('Avatar metadata','id added_at author_id author_name created_at description image_url name release_status thumbnail_image_url updated_at version'),
 'cache_world':('World metadata','id added_at author_id author_name created_at description image_url name release_status thumbnail_image_url updated_at version'),
 'favorite_avatar':('Favorite collections','id created_at avatar_id group_name'),
 'favorite_world':('Favorite collections','id created_at world_id group_name'),
 'favorite_friend':('Favorite collections','id created_at user_id group_name'),
 'favorite_print':('Print favorites','id print_id created_at'),
 'memos':('Memos and tags','user_id edited_at memo'),
 'world_memos':('Memos and tags','world_id edited_at memo'),
 'avatar_memos':('Memos and tags','avatar_id edited_at memo'),
 'avatar_tags':('Memos and tags','avatar_id tag color'),
 'gamelog_location':('World and game history','id created_at location world_id world_name time group_name'),
 'gamelog_join_leave':('World and game history','id created_at type display_name location user_id time'),
 'gamelog_portal_spawn':('World and game history','id created_at display_name location user_id instance_id world_name'),
 'gamelog_video_play':('Media and resource history','id created_at video_url video_name video_id location display_name user_id'),
 'gamelog_resource_load':('Media and resource history','id created_at resource_url resource_type location'),
 'gamelog_event':('Auxiliary game history','id created_at data'),
 'gamelog_external':('Auxiliary game history','id created_at message display_name user_id location'),
 'configs':('Selected preferences','key value'),
 'cache':('Photo metadata references','id file_path metadata cached_at'),
}
ACCOUNT={
 'feed_gps':('Social history','id created_at user_id display_name location world_name previous_location time group_name'),
 'feed_status':('Social history','id created_at user_id display_name status status_description previous_status previous_status_description'),
 'feed_bio':('Social history','id created_at user_id display_name bio previous_bio'),
 'feed_avatar':('Social history','id created_at user_id display_name owner_id avatar_name current_avatar_image_url current_avatar_thumbnail_image_url previous_current_avatar_image_url previous_current_avatar_thumbnail_image_url'),
 'feed_online_offline':('Social history','id created_at user_id display_name type location world_name time group_name'),
 'friend_log_current':('Friendship history','user_id display_name trust_level friend_number'),
 'friend_log_history':('Friendship history','id created_at type user_id display_name previous_display_name trust_level previous_trust_level friend_number'),
 'avatar_history':('Avatar-use totals','avatar_id created_at time'),
 'notes':('Account notes','user_id display_name note created_at'),
 'notifications':('Notification archives','id created_at type sender_user_id sender_username receiver_user_id message world_id world_name image_url invite_message request_message response_message expired'),
 'notifications_v2':('Notification archives','id created_at updated_at expires_at type link link_text message title image_url seen sender_user_id sender_username data responses details'),
 'moderation':('Moderation observations','user_id updated_at display_name block mute'),
 'mutual_graph_friends':('Mutual graph','friend_id'),
 'mutual_graph_links':('Mutual graph','friend_id mutual_id'),
 'mutual_graph_meta':('Mutual graph','friend_id last_fetched_at opted_out'),
 'activity_sessions_v2':('Derived activity sessions','session_id user_id start_at end_at is_open_tail source_revision'),
}
PREFERENCE_KEYS={'config:vrcx_statuspresets'}
PRIVATE_FIELDS=frozenset(('message','invite_message','request_message','response_message','bio','previous_bio','status_description','previous_status_description','data','details','responses'))
NESTED_FIELDS=frozenset(('id','type','title','message','text','label','name','description','groupId','groupName','worldId','worldName','eventId','userId','senderUserId','receiverUserId','imageUrl','createdAt','updatedAt','expiresAt','seen','responseType','responseData','accept','decline'))


def strict_json(raw):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('Duplicate JSON key.')
            out[k]=v
        return out
    try:
        value=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Non-finite JSON.')))
        clean(value)
        return value
    except (UnicodeError,TypeError,RecursionError,json.JSONDecodeError):
        raise ValueError('Invalid bounded UTF-8 JSON.') from None


def prefix_account(prefix):
    if not re.fullmatch(r'usr[0-9a-fA-F]{32}',prefix):raise ValueError('Unsupported source account prefix.')
    s=prefix[3:];return 'usr_'+s[:8]+'-'+s[8:12]+'-'+s[12:16]+'-'+s[16:20]+'-'+s[20:]


def contract(name):
    if name in GLOBAL:return name,'shared',GLOBAL[name]
    for suffix,spec in ACCOUNT.items():
        if name.endswith('_'+suffix):
            try:return suffix,prefix_account(name[:-len(suffix)-1]),spec
            except ValueError:pass
    return None


@contextmanager
def snapshot(path,stop=None):
    """Closed consistent databases only; never create or modify source SHM/WAL."""
    evidence=source(path,database=True)
    if Path(evidence.path+'-wal').exists() or Path(evidence.path+'-shm').exists():
        raise ValueError('Close VRCX and select its consistent database after WAL/SHM cleanup, or select a closed snapshot. Live migration is not enabled.')
    db=None
    try:
        stopped(stop);db=sqlite3.connect(Path(evidence.path).as_uri()+'?mode=ro&immutable=1',uri=True,timeout=.5,isolation_level=None)
        db.row_factory=sqlite3.Row;db.execute('PRAGMA query_only=ON');db.execute('PRAGMA trusted_schema=OFF')
        db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH,131072)
        deadline=time.monotonic()+15
        db.set_progress_handler(lambda:int(time.monotonic()>deadline or stop is not None and stop.is_set()),1000)
        db.execute('BEGIN');evidence.check()
        yield db,evidence
        evidence.check();stopped(stop)
        if Path(evidence.path+'-wal').exists() or Path(evidence.path+'-shm').exists():raise ValueError('The source opened while it was being inspected. Close it and inspect again.')
    except sqlite3.Error:
        raise ValueError('The selected source is busy, malformed or exceeded its query budget.') from None
    finally:
        if db is not None:db.close()


@dataclass(frozen=True)
class Table:
    name:str
    base:str
    account:str
    category:str
    columns:tuple
    rows:int


@dataclass(frozen=True)
class Inventory:
    evidence:object=field(repr=False)
    tables:tuple=()
    warnings:tuple=()


@dataclass(frozen=True)
class Migration:
    plan:object
    evidence:object=field(repr=False)
    report:dict=field(default_factory=dict)


def inspect(path,stop=None):
    tables=[];warnings=[]
    with snapshot(path,stop) as (db,evidence):
        for row in db.execute("SELECT name,type,sql FROM sqlite_master WHERE type IN ('table','view') ORDER BY name"):
            stopped(stop);spec=contract(row['name'])
            if not spec:continue
            base,account,(category,fields)=spec
            sql=re.sub(r'/\*.*?\*/|--[^\n]*',' ',row['sql'] or '',flags=re.S)
            if row['type']!='table' or re.match(r'\s*CREATE\s+VIRTUAL\s+TABLE',sql,re.I):
                raise ValueError('A supported source name is not a physical table: '+row['name'])
            available={r['name'] for r in db.execute('PRAGMA table_info("'+row['name']+'")')}
            fields=tuple(k for k in fields.split() if k in available)
            required={'configs':{'key','value'},'avatar_tags':{'avatar_id','tag'},'activity_sessions_v2':{'session_id','user_id','start_at','end_at'}}.get(base,{(spec[2][1].split())[0]})
            if not required<=available:
                warnings.append('Unsupported columns in '+row['name']);continue
            # configs are never counted/read broadly: they can contain secrets.
            if base=='configs':count=db.execute('SELECT count(*) FROM configs WHERE key IN (?)',tuple(PREFERENCE_KEYS)).fetchone()[0]
            else:count=db.execute('SELECT count(*) FROM "'+row['name']+'"').fetchone()[0]
            tables.append(Table(row['name'],base,account,category,fields,count))
    if not tables:raise ValueError('No supported VRCX source tables were found.')
    return Inventory(evidence,tuple(tables),tuple(warnings))


def safe_url(value):
    if not isinstance(value,str):return ''
    try:
        u=urlsplit(value)
        if u.scheme not in ('http','https') or not u.hostname or u.username or u.password:return ''
        return urlunsplit((u.scheme,u.netloc,u.path,'',''))[:2048]
    except ValueError:return ''


def normalized_time(value):
    if not value:return None
    try:
        d=datetime.fromisoformat(str(value).replace('Z','+00:00'))
        return d.astimezone(timezone.utc).isoformat() if d.tzinfo else None
    except (ValueError,OverflowError):return None


def nested(value):
    if isinstance(value,str):value=strict_json(value)
    def select(x,depth=0):
        if depth>6:raise ValueError('Archived notification nesting exceeds the supported limit.')
        if isinstance(x,dict):return {k:select(v,depth+1) for k,v in x.items() if k in NESTED_FIELDS}
        if isinstance(x,list):return [select(v,depth+1) for v in x[:100]]
        return clean(x)
    return select(value)


def prepare(inventory,library,*,categories,account_map=None,global_scope='shared',lineage='VRCX library',
            policy='keep',include_private=False,include_relationships=False,after='',before='',stop=None):
    if not isinstance(inventory,Inventory):raise ValueError('Inspect the source first.')
    library=library if isinstance(library,NativeLibrary) else NativeLibrary(library)
    account_map=account_map or {};dest_global=scope(global_scope);plain(lineage,120,empty=False)
    choices=set(categories);unknown=choices-{t.category for t in inventory.tables}
    if unknown:raise ValueError('Unknown selected source category.')
    if not choices:raise ValueError('Select source categories.')
    if not include_relationships and choices & {'Mutual graph','Moderation observations'}:
        raise ValueError('Explicitly include private relationship observations for those categories.')
    bounds=[]
    for v in (after,before):
        if v:
            try:
                parsed=datetime.fromisoformat(v.replace('Z','+00:00'))
                bounds.append(parsed.astimezone(timezone.utc) if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc))
            except ValueError:raise ValueError('Use an ISO date for the history range.') from None
        else:bounds.append(None)
    records={};counts={};skipped=0;warnings=list(inventory.warnings);source_hash=sha256();read_count=0
    lineage_id=identity('vrcx-lineage',lineage)
    def add(kind,ref,data,provenance,target):
        r=validate_record(dict(scope=target,kind=kind,id=ref,data=data,provenance=provenance))
        key=(target,kind,ref)
        if key in records and kind=='entity':
            previous=records[key]
            for field in ('name','fields'):
                if r['data'].get(field) in ('',{},None):r['data'][field]=previous['data'].get(field)
            if r['data'].get('name')==r['data'].get('entity_id'):r['data']['name']=previous['data'].get('name',r['data']['name'])
        records[key]=r
        if len(records)>MAX_BATCH:raise ValueError('Select fewer categories or a smaller date range; this preview exceeds 10,000 native records.')
    def ent(kind,ref,name,target,prov,fields=None):
        kind='friend' if kind=='user' else kind
        if kind=='print':reference(ref,('prnt',))
        else:ref=entity_id(kind,ref)
        rid=kind+':'+ref
        add('entity',rid,dict(entity_kind=kind,entity_id=ref,name=name or ref,fields=fields or {}),prov,target)
        return rid
    inventory.evidence.check()
    with snapshot(inventory.evidence.path,stop) as (db,evidence):
        for table in sorted(inventory.tables,key=lambda t:(not t.base.startswith('cache_'),t.name)):
            if table.category not in choices:continue
            target=dest_global if table.account=='shared' else scope(account_map.get(table.account,table.account))
            # Explicit mapping is required for any account source selected.
            if table.account!='shared' and table.account not in account_map:
                raise ValueError('Map the source account '+table.account+' before importing its history.')
            sql='SELECT '+','.join('"'+c+'"' for c in table.columns)+' FROM "'+table.name+'"'
            params=()
            if table.base=='configs':sql+=' WHERE key IN (?)';params=tuple(PREFERENCE_KEYS)
            # Date filtering precedes the selected-row budget. A large history
            # can be imported in disjoint date ranges without truncating its tail.
            scanned=0
            for item in db.execute(sql,params):
                stopped(stop);scanned+=1
                if scanned>500000:raise ValueError('Source scan exceeds 500,000 rows. Export a smaller source database.')
                row={k:clean(v) for k,v in dict(item).items()};base=table.base
                when=row.get('created_at') or row.get('updated_at') or row.get('edited_at')
                normalized=normalized_time(when)
                if bounds[0] or bounds[1]:
                    if normalized is None:skipped+=1;continue
                    dt=datetime.fromisoformat(normalized)
                    if bounds[0] and dt<bounds[0] or bounds[1] and dt>=bounds[1]+timedelta(days=1):skipped+=1;continue
                read_count+=1
                if read_count>MAX_BATCH:raise ValueError('The selected source exceeds 10,000 rows; select fewer categories or a narrower date range.')
                source_hash.update(canonical([table.name,row]).encode())
                rowkey=row.get('id',row.get('session_id'))
                if rowkey is None:rowkey=[row.get(k) for k in ('user_id','avatar_id','world_id','friend_id','mutual_id','tag','key') if k in row]
                prov=dict(source='VRCX 2026.09.16',lineage=lineage_id,table=base,
                          source_key=str(rowkey)[:240],reported_time=when,normalized_time=normalized,
                          source_account=table.account,authority='historical observation')
                eventid=identity(lineage_id,table.name,rowkey)
                counts[table.category]=counts.get(table.category,0)+1
                if base=='cache':
                    # metadataCache.db is an explicitly selected second source,
                    # inventoried by this same migration authority.
                    value=strict_json(row['metadata']) if row.get('metadata') else None
                    approved={};unknown=False
                    if isinstance(value,dict):
                        value={k[:1].lower()+k[1:]:v for k,v in value.items()}
                        if value.get('application')=='VRCX' and value.get('version')==1:
                            world=value.get('world') or {};world={k[:1].lower()+k[1:]:v for k,v in world.items()} if isinstance(world,dict) else {}
                            if world.get('id'):approved['world_id']=entity_id('world',world['id'])
                            if include_private:approved['world_name']=plain(world.get('name') or '',512)
                            approved['timestamp']=normalized_time(value.get('timestamp'))
                        else:unknown=True
                    else:unknown=True
                    path=plain(row['file_path'],4096,empty=False)
                    add('photo-reference',identity('photo-reference',lineage_id,path),dict(source_path=path,declared=approved,
                        cached_at=row.get('cached_at'),schema_supported=not unknown,linked=False,
                        coverage='Historical metadata reference; bytes and present path unverified'),prov,target)
                elif base.startswith('cache_'):
                    kind=base[6:];fields={k:v for k,v in row.items() if k not in ('id','name')}
                    for key in ('image_url','thumbnail_image_url'):fields[key]=safe_url(fields.get(key))
                    ent(kind,row['id'],row.get('name'),target,prov,fields)
                elif base.startswith('favorite_'):
                    kind=base[9:];key={'avatar':'avatar_id','world':'world_id','friend':'user_id','print':'print_id'}[kind]
                    er=ent(kind,row[key],row[key],target,prov)
                    name=row.get('group_name') or 'Print favorites';plain(name,100,empty=False)
                    groupid=identity('collection',kind,name)
                    add('collection',groupid,dict(entity_kind=kind,name=name),prov,target)
                    add('membership',identity(groupid,er),dict(collection=groupid,entity=er,added=when,rank=None),prov,target)
                elif base in ('memos','world_memos','avatar_memos','avatar_tags','notes'):
                    kind='avatar' if 'avatar' in base else 'world' if 'world' in base else 'friend'
                    key={'avatar':'avatar_id','world':'world_id','friend':'user_id'}[kind];er=kind+':'+entity_id(kind,row[key])
                    value=row.get('tag') if base=='avatar_tags' else row.get('note') if base=='notes' else row.get('memo')
                    if not value:skipped+=1;continue
                    typ='tag' if base=='avatar_tags' else 'note' if base=='notes' else 'memo'
                    if (target,'entity',er) not in records and not library.get(target,'entity',er):
                        ent(kind,row[key],row[key],target,prov)
                    data=dict(entity=er,type=typ,value=plain(value,20000))
                    if base=='avatar_tags' and row.get('color'):
                        if re.fullmatch(r'#[0-9a-fA-F]{6}',row['color']):data['color']=row['color']
                        else:warnings.append('An unsupported avatar-tag color was omitted.')
                    add('annotation',identity('annotation',er,typ,value if typ=='tag' else ''),data,prov,target)
                    if base=='memos':add('annotation',identity('annotation',er,'nickname',''),dict(entity=er,type='nickname',value=value.splitlines()[0][:120]),prov,target)
                elif base=='configs':
                    values=strict_json(row['value'])
                    if not isinstance(values,list):raise ValueError('Invalid source status presets.')
                    for index,v in enumerate(values[:10]):
                        if not isinstance(v,dict) or set(v)!={'status','statusDescription'} or v['status'] not in ('join me','active','ask me','busy','offline'):raise ValueError('Invalid source status preset.')
                        plain(v['statusDescription'],80)
                        if len(v['statusDescription'])>32:
                            warnings.append('An imported status preset exceeds the native 32-character limit; it is retained for review but cannot be applied unchanged.')
                        add('preference',identity('status-preset',v),dict(type='status-preset',name='Imported preset '+str(index+1),values=v),prov,target)
                    if len(values)>10:warnings.append('Only the first ten supported status presets were selected.')
                elif base=='avatar_history':
                    ref=entity_id('avatar',row['avatar_id']);duration=row.get('time')
                    if type(duration)is not int or not 0<=duration<=10**15:raise ValueError('Invalid source avatar-use milliseconds.')
                    add('aggregate',eventid,dict(category='avatar-use',entity='avatar:'+ref,total_ms=duration,latest_use=when,not_individual_sessions=True),prov,target)
                elif base=='activity_sessions_v2':
                    start,end=row.get('start_at'),row.get('end_at')
                    if type(start)is not int or type(end)is not int or not 0<=start<=end<=10**15:raise ValueError('Invalid derived activity interval.')
                    add('aggregate',eventid,dict(category='derived-activity',user_id=entity_id('user',row['user_id']),start_ms=start,end_ms=end,
                        open_tail=bool(row.get('is_open_tail')),source_revision=row.get('source_revision',''),derived=True),prov,target)
                else:
                    data={k:v for k,v in row.items() if k not in PRIVATE_FIELDS or include_private}
                    for key,value in tuple(data.items()):
                        if key.endswith('_url') or key in ('link',):data[key]=safe_url(value)
                        if key in ('location','previous_location','instance_id'):
                            data[key]=(value.split(':',1)[0] if isinstance(value,str) and value.startswith('wrld_') else None)
                        if key in ('data','details','responses') and isinstance(value,str):
                            try:data[key]=nested(value)
                            except ValueError:data.pop(key);warnings.append('Unsupported nested archive fields were omitted.')
                    data.update(category=base,reported_time=when,historical=True)
                    prov['imported_at']=stamp()
                    kind='notification' if base.startswith('notifications') else 'relationship' if base.startswith(('mutual_graph','moderation','friend_log_current')) else 'event'
                    if kind=='notification':data.update(api_family='v2' if base.endswith('v2') else 'v1',actionable=False)
                    add(kind,eventid,data,prov,target)
        evidence.check()
    # Freeze the approved source observations and policy in an immutable review.
    for r in records.values():r['provenance']['snapshot']=source_hash.hexdigest()
    plan=library.prepare(records.values(),source='VRCX: '+lineage,policy=policy,stop=stop)
    return Migration(plan,evidence,dict(categories=counts,source_rows=read_count,native_changes=len(plan.records),
        conflicts=len(plan.conflicts),suppressed=len(plan.suppressed),skipped=skipped,warnings=list(dict.fromkeys(warnings)),
        incomplete=['Source has no recoverable empty favorite groups or item ordering.',
        'Custom user-tag and saved-search persistence are not present in this source contract.',
        'Imported history is not a live permission or a notification to send.']))


def commit(migration,library,*,stop=None,check=None):
    if not isinstance(migration,Migration):raise ValueError('Prepare an import first.')
    migration.evidence.check()
    def valid():
        migration.evidence.check()
        if check:check()
    return library.commit(migration.plan,stop=stop,check=valid)
