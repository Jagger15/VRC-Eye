"""Accounts → My avatars: explicit browsing, fresh inspection and reviewed edits."""
from account_actions import local_writable
from companion_ui import Table, line, button, choice, entry
from ui_theme import responsive_wrap
import owned_avatars as owned


class OwnedAvatarsPanel:
    def __init__(self, page, parent):
        self.page, self.parent = page, parent
        self.result = None
        self.snapshot = None
        self.selected_id = ''
        self.offset = 0
        self.query = page.tk.StringVar(value='')
        self.visibility_filter = page.tk.StringVar(value='All')
        self.info = page.tk.StringVar(value='Load your avatar page explicitly. Opening this tab makes no request.')
        self.details = page.tk.StringVar(value='Select an avatar, then refresh its details before editing.')
        self.name = page.tk.StringVar(value='')
        self.release = page.tk.StringVar(value='')
        row = line(page, parent)
        button(page, row, 'Load my avatars', lambda: self.load(0))
        button(page, row, 'Previous page', lambda: self.load(max(0, self.offset - owned.PAGE_SIZE)))
        button(page, row, 'Next page', self.next_page)
        responsive_wrap(page.ttk.Label(parent, textvariable=self.info)).pack(anchor='w', pady=4)
        row = line(page, parent)
        page.ttk.Label(row, text='Filter loaded page:').pack(side='left', padx=4)
        entry(page, row, self.query, 27)
        choice(page, row, self.visibility_filter, ('All', 'public', 'private', 'hidden', 'Unknown'), width=11)
        button(page, row, 'Apply filter', self.render)
        self.table = Table(page, parent, (('name', 'Avatar', 220), ('state', 'Visibility', 95),
            ('platform', 'Returned platforms', 150), ('id', 'Avatar ID', 335)), height=5, select=self.selection)
        row = line(page, parent)
        button(page, row, 'Refresh selected details', self.load_selected)
        button(page, row, 'Discard draft', self.restore_form)
        button(page, row, 'Save observation to Avatar Library…', self.save_observation)
        responsive_wrap(page.ttk.Label(parent, textvariable=self.details)).pack(anchor='w', pady=5)
        row = line(page, parent)
        page.ttk.Label(row, text='Name (local limit 100):').pack(side='left', padx=4)
        self.name_entry = entry(page, row, self.name, 44)
        row = line(page, parent)
        page.ttk.Label(row, text='Visibility:').pack(side='left', padx=4)
        self.release_box = choice(page, row, self.release, ('private', 'public'), width=15)
        page.ttk.Label(parent, text='Description (local limit 5,000 characters):').pack(anchor='w', pady=(5, 0))
        self.description = self._text(height=4)
        page.ttk.Label(parent, text='Author tags, one per line without author_tag_ (other returned tags stay read-only):').pack(anchor='w', pady=(5, 0))
        self.tags = self._text(height=3)
        self.reserved = page.tk.StringVar(value='')
        responsive_wrap(page.ttk.Label(parent, textvariable=self.reserved, style='Muted.TLabel')).pack(anchor='w', pady=3)
        row = line(page, parent)
        button(page, row, 'Review avatar changes…', self.save)
        responsive_wrap(page.ttk.Label(parent, text=(
            'Only supported returned fields can be edited. Name and description changes cannot be empty. '
            'Tag bounds are local: 50 total, 100 characters each. Lists and drafts live only in this session. '
            'Changes require a detail read within 120 seconds and a review of the exact old/new values. '
            'VRChat may change after inspection; this is not a server-side compare-and-swap. '
            'Community-documented API; live acceptance is unverified. No image upload, avatar wear change or platform upload.'),
            style='Muted.TLabel')).pack(anchor='w', pady=6)
        self.clear()

    def _text(self, height):
        frame = self.page.ttk.Frame(self.parent)
        frame.pack(fill='x', pady=3)
        widget = self.page.tk.Text(frame, height=height, width=65, wrap='word', undo=False,
                                   font='TkDefaultFont', takefocus=True)
        scrollbar = self.page.ttk.Scrollbar(frame, orient='vertical', command=widget.yview)
        scrollbar.pack(side='right', fill='y')
        widget.configure(yscrollcommand=scrollbar.set)
        widget.pack(side='left', fill='both', expand=True)
        return widget

    def _set_text(self, widget, value, enabled=False):
        widget.configure(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', value)
        widget.configure(state='normal' if enabled else 'disabled')

    def require(self):
        self.page.require_revealed()
        local_writable(self.page.app)
        return self.page.connected()

    def clear(self):
        self.result = None
        self.offset = 0
        self.selected_id = ''
        self.query.set('')
        self.visibility_filter.set('All')
        self.table.set([], lambda row: ())
        self.clear_details()
        self.info.set('My avatars not loaded. Refresh explicitly after revealing this page.')

    def clear_details(self):
        self.snapshot = None
        self.name.set('')
        self.release.set('')
        self.name_entry.configure(state='disabled')
        self.release_box.configure(state='disabled')
        self._set_text(self.description, '')
        self._set_text(self.tags, '')
        self.reserved.set('')
        self.details.set('Select an avatar, then refresh its details before editing.')

    def load(self, offset=0):
        self.require()
        if self.page.job:
            raise ValueError('Wait for or cancel the pending task first.')
        self.clear_details()
        self.selected_id = ''
        self.table.set([], lambda row: ())
        self.result = None
        self.page.start(lambda client, stop, progress: owned.read_page(client, offset=offset, stop=stop, progress=progress), self.loaded)

    def loaded(self, result):
        self.require()
        if result.source_client is not self.page.app.api or result.account != owned.context(self.page.app.api):
            raise ValueError('The connection changed. Load your avatars again.')
        self.result = result
        self.offset = result.offset
        self.render()

    def next_page(self):
        self.require()
        if not self.result or not self.result.more:
            raise ValueError('No further page is indicated by the last response.')
        self.load(self.result.offset + owned.PAGE_SIZE)

    def render(self):
        self.require()
        original = self.selected_id
        rows = self.result.rows if self.result else ()
        query = self.query.get().casefold().strip()
        visibility = self.visibility_filter.get()
        def matches(row):
            data = dict(row.metadata)
            return (not query or query in (row.name + ' ' + row.avatar).casefold()) and (
                visibility == 'All' or (data.get('releaseStatus') or 'Unknown') == visibility)
        visible = [row for row in rows if matches(row)]
        def values(row):
            data = dict(row.metadata)
            platforms = sorted({dict(build).get('platform') or 'Unknown' for build in row.builds or ()})
            return row.name, data.get('releaseStatus') or 'Unknown', ', '.join(platforms) or 'Unknown', row.avatar
        self.table.set(visible, values)
        for key, row in self.table.records.items():
            if row.avatar == original:
                self.table.tree.selection_set(key)
                break
        else:
            self.selected_id = ''
            self.clear_details()
        if self.result:
            self.info.set(f'Loaded page offset {self.offset}: {len(rows)} returned, {len(visible)} visible. '
                          'Filters apply to this page only. No total or complete library is assumed.')

    def selected(self):
        self.require()
        row = self.table.selected()
        if (not row or not self.result or self.result.source_client is not self.page.app.api or
                self.result.account != owned.context(self.page.app.api) or not any(item is row for item in self.result.rows)):
            raise ValueError('Load your avatars and select a current row.')
        return row

    def selection(self):
        if self.page.private.get():
            self.clear()
            return
        row = self.table.selected()
        selected = row.avatar if row else ''
        if selected != self.selected_id:
            self.selected_id = selected
            self.clear_details()

    def load_selected(self):
        if self.page.job:
            raise ValueError('Wait for or cancel the pending task first.')
        row = self.selected()
        expected = row.avatar
        self.clear_details()
        def done(value):
            if self.selected().avatar != expected:
                raise ValueError('Selection changed during inspection. Refresh the selected avatar again.')
            self.snapshot = value
            self.restore_form()
        self.page.start(lambda client, stop, progress: owned.read_avatar(client, expected, stop=stop, progress=progress), done)

    def restore_form(self):
        self.require()
        value = self.snapshot
        if not value:
            self.clear_details()
            return
        if self.selected().avatar != value.avatar:
            self.clear_details()
            raise ValueError('Select and inspect the avatar again.')
        fields = value.fields
        self.name.set(fields.get('name', ''))
        self.release.set(fields.get('releaseStatus', ''))
        self.name_entry.configure(state='normal' if 'name' in fields else 'disabled')
        self.release_box.configure(state='readonly' if 'releaseStatus' in fields else 'disabled')
        self._set_text(self.description, fields.get('description', ''), 'description' in fields)
        tags = fields.get('tags', ())
        self._set_text(self.tags, '\n'.join(t[len('author_tag_'):] for t in tags if t.startswith('author_tag_')), 'tags' in fields)
        other = [tag for tag in tags if not tag.startswith('author_tag_')]
        self.reserved.set('Read-only returned tags: ' + (', '.join(other) if other else 'None returned in editable tag list'))
        self.details.set(value.summary())

    def draft(self):
        if not self.snapshot:
            raise ValueError('Refresh selected details first.')
        fields = self.snapshot.fields
        values = {}
        if 'name' in fields:
            values['name'] = self.name.get()
        if 'releaseStatus' in fields:
            values['releaseStatus'] = self.release.get()
        if 'description' in fields:
            values['description'] = self.description.get('1.0', 'end-1c')
        if 'tags' in fields:
            raw = self.tags.get('1.0', 'end-1c')
            author = ['author_tag_' + tag.strip() for tag in raw.splitlines() if tag.strip()]
            current_author = [tag for tag in fields['tags'] if tag.startswith('author_tag_')]
            # No-op form keeps the exact original ordering, including reserved tags.
            values['tags'] = list(fields['tags']) if author == current_author else [
                tag for tag in fields['tags'] if not tag.startswith('author_tag_')] + author
        return values

    def view_guard(self):
        self.require()
        row = self.selected()
        values = self.draft()
        return (self.page.context(), self.page.revision, self.page.private.get(), id(self.result),
                row.avatar, id(self.snapshot), tuple(sorted((k, tuple(v) if isinstance(v, list) else v) for k, v in values.items())))

    def save(self):
        self.require()
        local_writable(self.page.app)
        if not self.snapshot or self.selected().avatar != self.snapshot.avatar:
            raise ValueError('Refresh the selected avatar details before reviewing changes.')
        from account_workspace_ui import submit_review
        values = self.draft()
        def done(outcome):
            self.clear()
            if hasattr(self.page, 'history'):
                self.page.history.refresh(0)
            self.page.status.set(outcome.message + ' Reload my avatars to inspect the current state.')
        submit_review(self.page, 'update-owned-avatar', result=self.snapshot, values=values,
                      description='Selected owned avatar metadata', view_guard=self.view_guard, done=done)

    def save_observation(self):
        self.require()
        local_writable(self.page.app)
        if self.page.job:
            raise ValueError('Wait for or cancel the pending task first.')
        if not self.snapshot or self.selected().avatar != self.snapshot.avatar:
            raise ValueError('Refresh selected details before saving an observation.')
        snapshot = owned.validate_snapshot(self.page.app.api, self.snapshot)
        state = self.view_guard()
        if not self.page.confirm('Save avatar observation', f'Account workspace: {snapshot.owner}\nAvatar: {snapshot.avatar}\n\nSave the returned metadata and build observations to your local Avatar Library? Description, tags and visibility are retained locally. URLs and images are omitted. Draft edits are not included. This sends no remote request.'):
            return
        if state != self.view_guard():
            raise ValueError('The account, selection or draft changed. Review the observation again.')
        local_writable(self.page.app)
        owned.validate_snapshot(self.page.app.api, snapshot)
        self.page.app.avatar_creator.library.observe(snapshot.owner, snapshot.document(), 'VRChat API')
        self.page.status.set('Returned avatar observation saved to this account’s Avatar Library; no images downloaded or remote changes made.')
