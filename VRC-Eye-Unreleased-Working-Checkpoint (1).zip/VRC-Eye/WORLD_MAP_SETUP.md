# World maps in VRC Eye 1.18.1

The desktop app has separate **Avatars** and **World** tabs. Avatar tools stay
on Avatars; World contains **Players** and **Map** subtabs. The observed roster,
world counts and visit times are on Players; see **WORLD_PLAYERS_SETUP.md**.
Map contains the layout and player markers. Rangefinder remains on the World bar.
The log folder at the top is shared. This is a desktop page, not an in-headset
overlay or a modification to the VRChat menu.

## Capture a map image with VRChat's own camera

You can create the background from a native VRChat camera photo. This works
without installing the world helper: the helper is only needed for live player
markers. **The result is an aerial perspective photo, not a true orthographic
render or an automatically reconstructed floor plan.**

1. In the PC VRChat client, enable OSC from the Action Menu and open the native
   Photo camera. Use its normal movement/flying controls to place it above the
   part of the world you want to map, and aim straight down. Positioning is manual.
   The accessible area depends on camera range, world geometry, and camera mode.
2. For a flatter-looking result, use a higher viewpoint with a narrower field
   of view while keeping the same area in frame. Turn off focus blur and filters.
   Use 2160p / 4K or lower; 1080p is a convenient starting point. Keep the camera
   still while capturing. If you intend to calibrate it, align the image with
   the world's X/Z axes; a rotated or tilted image needs additional correction
   that this release does not perform.
3. Open **World → Camera capture…**. Choose your VRChat photo output folder.
   The normal Windows location is `Pictures/VRChat`, with `YYYY-MM` subfolders.
   The app also reads `picture_output_folder` from the selected log directory's
   VRChat `config.json` when available. It does not change that file. If Pictures
   is redirected, use VRChat's **Open Photos Folder**, then select that location
   with Browse. You can also select the current monthly folder directly.
4. Open **Networking → OSC transport** to configure the shared OSC service.
   Under **VRC Eye Primary → OSC Controls**, review and arm the **camera**
   capability. The map camera uses that same service and has no separate port
   setting. Avatar Link and the rangefinder share its observations.
5. Optionally click **Prepare Photo camera**. This sends camera-only requests to
   select Photo mode, show the world, and hide your avatar, other avatars, UI,
   and greenscreen. Check the result in-game. It does not move/rotate the camera
   or change its lens, focus, or filters. These settings remain in VRChat until
   you change them there; closing VRC Eye does not restore their previous values.
6. Click **Capture + watch**. VRC Eye indexes existing PNGs, requests one photo
   through OSC, then watches for a new file. A sent UDP request is not confirmation
   that the camera acted on it. If OSC is unavailable, click **Watch manual shot**,
   wait for the Ready message, then press the shutter inside VRChat instead.
7. Review the preview. If several new PNGs were detected together, choose one
   from the list. Photos are checked for a stable size and timestamp before
   being offered. Nothing replaces your current map until **Use photo as map**.
   **Choose existing PNG…** is also available if the image was saved earlier or
   finished saving after the watcher timed out.
8. **Use photo as map** creates an uncalibrated map without inheriting another
   map's world ID, edges, or waypoints. Save it with **Save map…**, or use
   **Save map PNG…** in the capture window to write a separate PNG copy.

Photos up to 32 MiB and 16 megapixels can be decoded; the longest edge of the
map copy is reduced to at most 2048 pixels when necessary. Reduction uses Tk's
pixel subsampling. The resulting map still needs to fit the 8 MiB image limit;
if it does not, take another shot at 1080p. The original VRChat photo is preserved.
Saving a map PNG requires a new filename and refuses to overwrite existing files.
Resizing changes resolution only; it does not flatten geometry or correct a
perspective image. No additional Python package is needed.

The watcher examines the selected directory and one level of subdirectories,
with a 20,000-entry limit. Choose the current monthly folder if the photo library
is larger. It waits up to 45 seconds and never silently imports the newest old
photo. Cancel/close ignores late results, but cannot undo a photo already requested
from VRChat. Other applications or manual shots can also create new PNGs, so
preview the selected file rather than assuming its origin or world identity.

Roofs, ceilings, trees, clipping, and higher floors can hide the ground. A photo
only records what the camera renders; it cannot see through these objects or
recover unseen rooms. On level ground, a straight-down photo can make a useful
reference map. Different heights and camera tilt can make marker alignment
inaccurate. Calibration still needs world coordinates; capture does not obtain
them or track players. Live markers retain the helper requirement below.

The documented camera controls include capture and rendering masks, but no
orthographic-projection switch. Camera pose control descriptions also differ
between VRChat's release notes and current wiki; this feature does not depend
on writing camera pose. It uses the normal Photo camera with manual positioning,
not the separate Camera Drone or automatic world scanning.

## View a world layout

1. Open **World → Map → Import image…** and choose an overhead PNG or GIF of the world.
   Images up to 2048 × 2048 pixels and 8 MiB are supported. For animated GIFs,
   only the initial frame is used. A world creator can supply an overhead render
   or floor plan. The app does not automatically download or reconstruct a
   world's geometry or find an existing map on the internet.
2. Drag to pan, use the mouse wheel or + / − to zoom, and use **Fit map** to reset
   the view. Right-click the image to name a waypoint. **Clear waypoints** removes
   all waypoints after confirmation.
3. **Save map…** creates a portable `.vrcmap` file containing the image,
   calibration, and waypoints. **Open map…** restores it. No separate image file
   or manually authored JSON is needed. Unsaved changes are marked in the title;
   save before exiting. Live player positions are never included in saved maps.

A layout and waypoints work without VRChat, VRCX, API sign-in, or a world helper.
They are reference information supplied by you, not a verification of the
current world's layout. A minimap depicts one overhead layer; overlapping floors
will overlap unless you provide separate floor maps.

## Align a map for player markers

Open **Calibrate…** and enter the actual world ID (`wrld_…`) plus these coordinates
from the world project, in Unity metres:

| Field | Meaning |
| --- | --- |
| X at left edge | World X at the image's left boundary |
| X at right edge | World X at the image's right boundary |
| Z at bottom edge | World Z at the image's bottom boundary |
| Z at top edge | World Z at the image's top boundary |

The image must be a top-down, axis-aligned view: X horizontal, Z vertical. Each
pair of opposite edges must differ. Reversed axes are supported. A straight-down
camera photo can be aligned for one flat reference plane; arbitrary tilt,
rotation, or different surface heights cannot be corrected by these four values. Do not
guess coordinates from an avatar name, username, or thumbnail. Ask the world
creator for a calibrated map if you do not have the project. Recalibration keeps
waypoints in the same image locations. Save afterward to retain the new values.

An unpublished Build & Test world can use a matching custom key such as
`local:my-world` in both the map and the reporter. Use the real world ID for a
published world. World IDs associate a profile with a reporter; they do not
authenticate a map or prove its calibration.

## Enable live player markers in a supported world

This integration requires a world you can edit, or its creator installing the
helper. It does **not** provide all-player tracking in arbitrary existing worlds.
Normal avatar-switch logs and this app's API/VRCX integrations do not supply
these live coordinates. The map has no fallback that guesses player locations.

For the world creator:

1. Open a VRChat **Worlds** Unity project with UdonSharp. Copy only
   `Unity/World/VRCEyeMapReporter.cs` into a scripts folder under Assets. This is
   a world behaviour, not something to put on an uploaded avatar.
2. Add it to one scene object. Give that object a visible label such as
   "VRC Eye map reporting — interact to toggle locally" and a collider so it can
   be interacted with. Set its Udon interaction text as desired.
3. Set **World Id** to match the calibrated map. Keep **Report On Start** off for
   normal use. Interaction enables or disables reporting only on that player's
   client. The state is not network-synchronized. Use only one reporter per scene.
4. Build & Test. For a published world, build/upload the updated world through
   the normal SDK workflow. A file sitting in your project cannot affect an
   already published world until it is included in that build.

For the desktop user:

1. Launch the PC VRChat client with Udon logging enabled. Build & Test does this
   automatically. For Steam, VRChat's documented debugging flags are:
   `--enable-debug-gui --enable-sdk-log-levels --enable-udon-debug-logging`
   Add these to VRChat's launch options, then restart VRChat. The Debug GUI need
   not stay open. Debug logging increases log size and can affect performance;
   disable it when you stop using this integration.
2. Join the updated world and interact with its reporter object to enable it
   locally. The default interval is two seconds; the helper clamps it to 1–5
   seconds and supports up to 100 players.
3. In VRC Eye, choose the current VRChat log folder and click **Watch logs**.
   Open **World** and click **Start helper feed**. To show dots, load/calibrate the
   matching map under **World → Map**. The Players page can use the helper without a map.
4. Wait for a new snapshot. Blue is you, green is other players, and gold is
   the selected player. Search by display name on the Players page. Select a row,
   click **Show on map**, and optionally turn on **Follow selected / me**.
5. **Stop helper feed** stops reading positions in VRC Eye. To stop generating
   snapshots in VRChat's log, interact with the reporter object again.

No exported JSON, VRCX, API sign-in, external server, or additional Python package
is needed for helper data. API sign-in is optional for account platform/trust,
world capacity and friend counts. The helper uses Udon's player API and writes a compact snapshot to the
normal local output log. The 1.18.1 helper also reports VR mode, local platform,
local average FPS and total player count. Replace and republish an older helper
to enable those fields. VRC Eye reads new entries from that log. Although the
machine-readable wire format is JSON, there is no manual JSON workflow.

## Freshness and identity

The feed starts at the end of the selected log, including after rotation or
truncation. It does not replay helper history. Each complete snapshot replaces
helper positions; the separate log-based player visit history is retained.
Repeated or out-of-order sequence numbers cannot refresh old markers.
Snapshots older than eight seconds are ignored; displayed markers also expire
within eight seconds without an update. The PC's clock and log timestamps must
agree. Restart the helper feed if you correct the clock during a session.

Joining/leaving a room clears player selection and positions. A map/reporter
world mismatch hides all markers. If a new join log supplies a world ID, a
reporter claiming a different ID is rejected. Changing log sources, restarting
Watch logs, or switching to the avatar Demo stops the position feed. Start it
again explicitly. **Pause view** does not pause world tracking. **Clear view**
retains world visits but can clear shared account metadata.

Helper player IDs are instance-local Udon IDs, not `usr_…` account IDs. The Players
page can associate a unique name with a same-world, same-log active visit; selected
details label that association as unverified. Duplicate names remain separate.
Account metadata/friend counts use explicit logged account IDs. Helper-only rows
have no account ID. Search covers the log roster and current helper rows; your
own marker remains visible while filtering.

Feet are straight-line 3D distances between reported player origins, including
height differences. They are not walking routes or collision/raycast distances.
Heading arrows use player rotation. Markers outside the calibrated image are
listed but not pinned misleadingly to the nearest map edge. Filtering hides
nonmatching dots; the status counts off-map players among the visible filter.

The reporter observes the positions VRChat exposes to Udon on your client;
network delay, log buffering, world scaling, and calibration affect accuracy.
World code and logs are not an authenticated location source. This feature is
for navigation in cooperating worlds. VRC Eye does not save the live roster,
but VRChat's own debug log contains the reporter's display names and coordinates.

## Troubleshooting

- **Waiting:** Confirm that the uploaded world contains the helper, reporting is
  enabled locally, Udon logging is enabled, and the selected log is growing.
  Look for a new `[VRCEyeMap]` line. An old log opened from disk cannot provide
  live positions. An unsupported world will remain waiting.
- **World mismatch:** Match the map and reporter IDs to the actual world; open
  a different map when changing worlds. There is no automatic profile switching.
- **Expired:** No recent complete snapshot arrived. Dots are deliberately cleared.
  If the helper has halted, check the SDK/Udon console and the VRChat log.
- **Wrong placement:** Check all four edge coordinates and image orientation.
  Use a top-down render rather than a perspective screenshot.
- **No room to move around the map:** Disable Follow, drag to pan, or click Fit map.
- **Standalone headset:** This integration reads a PC VRChat output log. It does
  not remotely read logs from standalone Android/iOS devices.

The included helper has source/syntax checks and the desktop data flow has
synthetic tests. Actual Unity compilation, upload, and a live VRChat instance
must still be tested in your environment. Keep the original world project.

## Implementation references

- Official Udon minimap example: https://creators.vrchat.com/worlds/examples/minimap/
- Player positions: https://creators.vrchat.com/worlds/udon/players/player-positions/
- Getting players: https://creators.vrchat.com/worlds/udon/players/getting-players/
- Udon debugging and log output: https://creators.vrchat.com/worlds/udon/debugging-udon-projects/
- VRCJSON serialization: https://creators.vrchat.com/worlds/udon/data-containers/vrcjson/
- Native camera OSC controls: https://docs.vrchat.com/docs/vrchat-202533
- Camera controls, masks, and photo folders: https://wiki.vrchat.com/wiki/Camera
- Photo resolution and folder configuration: https://docs.vrchat.com/docs/configuration-file
