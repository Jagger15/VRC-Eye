# Player windows — VRC Eye 1.18.5

Open **World → Players** and select a player. A separate window opens for that
account; selecting another player opens their window. A maximum of eight can
stay open. **Player window…** reopens the current selection. Windows for the same
account are reused, including when its display name or observed visit changes.
**My account…** opens your signed-in account directly, even without a roster row.

The basic roster still comes from the log. Profile lookup needs an exact logged
`usr_…` account ID and your VRChat connection. Names and helper-only IDs are never
used to guess an account. Opening a window while connected requests its public
profile once. Other data loads when you press its button. A signed-out window
still displays local information; a refresh offers the existing sign-in flow.

## Fields and sources

| Requested information | What this release displays |
| --- | --- |
| Bio, external links, pronouns | Returned public profile/user fields. Media lists supplied bio links and HTTP(S) URLs found in the bio. Links open only when clicked. |
| Status | Returned status text and status/joinability setting, with snapshot times in JSON. |
| Privacy status | The reported joinability setting and classification of an API-visible location. A private response does not reveal the hidden instance. |
| Age verification | Returned verification flag/category. False means not shown as verified; it does not identify the player's age or establish that they are a minor. |
| Game join date | `date_joined`, when returned by **Refresh user details**. This is separate from joining the current world. |
| Trust rank | Current supported trust-tag mapping. Historical tags do not establish current Veteran/Legendary ranks. |
| Booping | Returned preference and a **Boop** button with explicit confirmation. VRChat decides whether friendship and preferences allow the action. |
| Mutual friends | **Social → Load mutual friends**, with explicit pagination in Collections. Returned results may be restricted or partial. A denied request does not mean no mutual friends. |
| Discord connection | Returned Discord ID/display name, if exposed to your account. A missing field does not prove there is no Discord connection. |
| Personal notes | Private local text, saved against the exact player ID. No upload to the API or relay. |
| Joined groups | Returned visible memberships. Social also shows the represented group returned in the public profile. Hidden memberships remain unavailable. |
| Favorite worlds / avatars | **Collections → Favorite lists → Load selected collection**, select a returned list, then **Open favorite list**. Only world/avatar lists that the API permits are read. |
| Uploaded avatars | **My uploaded avatars** lists your own account's uploads. Other people's complete uploaded/private avatar libraries are unavailable. |
| Current avatar | Returned current-avatar ID/name and available image/link. It is a snapshot, not a guarantee of an old log event's avatar. |
| Activity | **Refresh visible activity** loads the permitted private-profile response. Activity also shows exact-ID avatar events retained in the loaded log and observed visit information. No private-location inference. |
| JSON | Filtered received sections and their source/time/page. Known credential and account-recovery fields and join nonces are excluded. Local notes and whisper secrets are excluded. |
| Banner / profile picture | Supplied URLs, optional previews, and click-to-open links. The profile picture can fall back to the returned avatar image when no custom picture is supplied. |
| Current group | Returned represented group. No inference of the group's current instance or a hidden membership. |
| Badges | Returned badges, descriptions and assignment times. This is not a claim that every earned or hidden badge was supplied. |
| Total time played | Lifetime VRChat playtime is unavailable. Activity separately totals complete timed visits for this player in the current/last loaded world roster. Missing and ongoing visits are excluded. |
| VRChat credits | **Account → Load my credits** for your signed-in account only. Other users' balances are unavailable. |
| Previous usernames | Locally observed display names since using this feature, plus your own returned display-name history if present. Login usernames and other people's complete past-name histories are unavailable. |
| Whisper | Opens the shared **VRC Eye Primary** workspace for an explicitly associated device. Pairing and connection options live in **VRC Eye → Networking**; see **NETWORKING_SETUP.md**. |

Use **Refresh profile** for the public profile and **Refresh user details** for
the corresponding user record. VRChat may omit fields, deny a section, or change
its API. These cases stay visibly unavailable. Existing snapshots remain visible
after a failed lookup and can be old; check their source times. The shared metadata
queue spaces requests by at least 60 seconds. Same-section recent reads reuse the
original timestamp. **Cancel request** stops queued work. No roster-wide profile
polling runs in the background.

Collection pages contain at most 100 entries, with a 2,000-row window limit.
**Load next page** is explicit. Group memberships and favorite-list contents use
their documented non-paginated responses, bounded to 2,000 entries. Complete
hidden collections cannot be reconstructed from profile counts or thumbnails.
**Open selected page** opens an exact returned user/group/world/avatar ID.

## Edit your own status, privacy preferences, and avatar information

1. Click **World → Players → My account…** and connect if needed. Its Account tab
   loads your settings. You can also select your own roster row and choose
   **Account → Load my settings**.
2. Set **Status / joinability** (Online, Join me, Ask me, Busy, or Offline), status
   text, or pronouns. The editor limits status text and pronouns to 32 characters.
   Boolean settings offer **Unchanged**, **Yes**, and **No**. The two connection
   settings are opt-outs: Yes opts out of mutual/Discord friend connections.
3. Click **Save my status / privacy** and review the exact changed fields. Cancel
   sends nothing. Successful writes display the returned account values.
4. For avatar metadata, paste your `avtr_…` ID or official avatar-page URL and
   click **Load owned avatar**. The API must return that exact avatar with your
   signed-in ID as author. Changing the ID requires another load.
5. Edit the name (up to 100 characters), description (up to 5,000), public/private
   status, or comma-separated tags. An empty description or tag list can clear
   that field. **Save owned avatar info** shows the changed fields before sending.

An ownership check expires after five minutes, including time spent in the API
queue. Avatar metadata writes do not upload a Unity package, modify another
creator's avatar, change avatar performance statistics, or restore a Unity
project. VRChat remains responsible for accepting/rejecting allowed values.

Forms are disabled while their request runs. A connection/account change clears
loaded editing baselines, image previews and credits, and rejects late results.
Changing a status/joinability preference does not change an existing instance's
access rules. These are actual account writes: if a request fails or is canceled
after transmission, the change may already have reached VRChat. Writes are never
automatically retried; refresh before trying again.

## Local notes, history, JSON and images

Notes save on **Save local notes** and when closing a window with changes. If a
save fails, the window/application remains open so the text can be recovered.
The limit is 20,000 characters per player. Notes and observed names are stored in
`players.sqlite3` beside VRC Eye's settings: normally
`%LOCALAPPDATA%\VRC-Eye\players.sqlite3` on Windows. They are local plaintext data,
not encrypted storage. Clearing a note and saving deletes that note. **Forget
observed names** deletes that account's locally recorded names, preserving notes.
History retains at most 100 display names per player and records names only when
a matching player window is opened/refreshed; it is not a background name tracker.

The JSON tab displays a filtered snapshot and can save it under a new filename.
It does not overwrite an existing file. Display is truncated with a notice above
2 MiB; saved JSON contains all retained sections. **Import profile JSON…** accepts
a matching user/public-profile object or VRC Eye filtered export up to 2 MiB.
From a VRC Eye export, it restores profile/user/activity fields only, as an
explicit imported snapshot. Collection pages, credits, and editing authorization
are not restored. Imports remain a backup, and never permit account/avatar edits.

Media previews are fetched only on **Load image previews**. Supported VRChat
asset/image hosts use bounded responses; API authentication cookies remain on
approved VRChat API image/file paths. Other links can be opened explicitly in
your browser. **Start.cmd** automatically prepares Pillow for JPEG/WebP decoding
and resizing. If setup cannot finish offline, bounded PNG/GIF support remains;
a later normal launch retries missing packages. Unsupported/denied previews
retain their clickable links. Images and API profile snapshots are held in memory
unless you explicitly save JSON. Closing the window clears its retained state.

## Sources and validation

The implementation was checked against the community-maintained API project's
endpoint definitions and VRCX source on 2026-09-30. These are not guarantees of
current access for every account or a supported official third-party API contract.

- Public profile: https://vrchat.community/reference/get-public-profile
- Visible private profile: https://vrchat.community/reference/get-private-profile
- User fields: https://vrchat.community/reference/get-user
- Update self: https://vrchat.community/reference/update-user
- Update owned avatar: https://vrchat.community/reference/update-avatar
- Boop: https://vrchat.community/reference/boop
- Mutuals: https://vrchat.community/reference/get-mutual-friends
- Groups: https://vrchat.community/reference/get-user-groups
- Favorite lists: https://vrchat.community/reference/get-favorite-groups
- Favorite contents: https://vrchat.community/reference/get-favorite-group-contents
- Own credits: https://vrchat.community/reference/get-balance
- Avatar listing: https://vrchat.community/reference/search-avatars

Tests use controlled API responses, temporary SQLite files, and headless widget
substitutes. No real account was edited, booped, or queried during development.
See **VALIDATION.md** for the limits of the checks.
