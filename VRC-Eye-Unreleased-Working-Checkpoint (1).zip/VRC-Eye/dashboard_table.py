"""Home table view over the desktop service's already collected snapshot."""
from dashboard_rows import COLUMNS,selected,display
from customization import update_widget


class DashboardTable:
    def __init__(self,dashboard,parent,settings):
        self.dashboard=dashboard;self.page=dashboard.page;self.settings=settings;self.rows=[];self.signature=None
        self.offset=0;self.page_size=25;self.coverage='Retained observations';self.row_context=None
        page=self.page;self.filter=page.tk.StringVar(value=settings.get('filter',''))
        bar=page.ttk.Frame(parent);bar.pack(fill='x',pady=(8,3))
        entry=page.ttk.Entry(bar,textvariable=self.filter,width=15);entry.pack(side='left',fill='x',expand=True);self.entry=entry
        entry.bind('<Return>',lambda _:page.guard(self.apply_filter))
        self.filter_button=page.ttk.Button(bar,text='Filter',command=lambda:page.guard(self.apply_filter));self.filter_button.pack(side='right')
        self.tree=page.ttk.Treeview(parent,columns=COLUMNS,show='headings',height=2 if settings['size']=='Compact' else 5,selectmode='browse')
        columns=settings.get('columns') or ['name','status','freshness']
        self.tree.configure(displaycolumns=columns)
        for key in COLUMNS:
            self.tree.column(key,width=130 if key!='time' else 180,minwidth=65,stretch=True)
        self.headings()
        y=page.ttk.Scrollbar(parent,orient='vertical',command=self.tree.yview)
        x=page.ttk.Scrollbar(parent,orient='horizontal',command=self.tree.xview)
        self.tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
        y.pack(side='right',fill='y');self.tree.pack(fill='both',expand=True);x.pack(fill='x')
        self.count=page.tk.StringVar();page.ttk.Label(parent,textvariable=self.count,style='Muted.TLabel').pack(anchor='w')
        pages=page.ttk.Frame(parent);pages.pack(fill='x')
        self.previous=page.ttk.Button(pages,text='Previous',command=lambda:page.guard(lambda:self.move_page(-1)));self.previous.pack(side='left')
        self.next=page.ttk.Button(pages,text='Next',command=lambda:page.guard(lambda:self.move_page(1)));self.next.pack(side='left')
        self.visible={};self.action_context=None;self.action_account=None
        self.open_button=page.ttk.Button(parent,text='Open selected…',command=lambda:page.guard(self.open_selected));self.open_button.pack(anchor='w',pady=3)
        self.tree.bind('<Return>',lambda _: (page.guard(self.open_selected),'break')[-1])
        self.tree.bind('<Double-1>',lambda _:page.guard(self.open_selected))
        menu=getattr(page.tk,'Menu',None)
        self.menu=menu(self.tree,tearoff=False) if menu and hasattr(self.tree,'tk') else None
        if self.menu:
            self.menu.add_command(label='Open selected…',command=lambda:page.guard(self.open_selected))
            self.menu.add_command(label='Shared notes / tags…',command=lambda:page.guard(lambda:self.open_selected('notes')))
            self.tree.bind('<Button-3>',self.popup);self.tree.bind('<Shift-F10>',self.popup)
            self.tree.bind('<KeyPress-Menu>',self.popup)

    def popup(self,event):
        if self.menu:
            if getattr(event,'num',None)==3:
                key=self.tree.identify_row(event.y)
                if not key:return 'break'
                self.tree.selection_set(key)
                x,y=event.x_root,event.y_root
            else:
                selected=self.tree.selection()
                if not selected:return 'break'
                self.tree.see(selected[0]);bounds=self.tree.bbox(selected[0])
                x=self.tree.winfo_rootx()+16;y=self.tree.winfo_rooty()+(bounds[1]+bounds[3] if bounds else 24)
            self.menu.tk_popup(x,y)
            self.menu.focus_set();self.menu.activate(0)
        return 'break'

    def open_selected(self,action='open'):
        from dashboard_actions import open_target
        chosen=self.tree.selection();row=self.visible.get(chosen[0]) if chosen else None
        if not row:raise ValueError('Select an individual Home row first.')
        return open_target(self.page,row.get('target'),self.action_context,self.action_account,action=action)

    def headings(self):
        for key in COLUMNS:
            arrow=(' ↓' if self.settings.get('descending',True) else ' ↑') if self.settings.get('sort','time')==key else ''
            self.tree.heading(key,text=key.title()+arrow,command=lambda k=key:self.page.guard(lambda:self.sort(k)))

    def change(self,**values):
        from dashboard_actions import context
        if self.row_context!=context(self.page.app) or context(self.page.app)[1]:
            self.update([],hidden=True);raise ValueError('Wait for refreshed Home rows before changing this table.')
        self.settings=update_widget(self.page.app,self.settings['id'],layout=getattr(self.dashboard,'active_name',None),**values)
        self.offset=0;self.signature=None;self.headings();self.update(self.rows,coverage=self.coverage)

    def move_page(self,direction):
        from dashboard_actions import context
        if self.row_context!=context(self.page.app) or context(self.page.app)[1]:
            self.update([],hidden=True);return
        self.offset=max(0,self.offset+self.page_size*direction)
        self.update(self.rows,coverage=self.coverage)

    def apply_filter(self):self.change(filter=self.filter.get())

    def sort(self,column):
        self.change(sort=column,descending=not self.settings.get('descending',True) if self.settings.get('sort','time')==column else False)

    def update(self,rows,*,hidden=False,coverage='Retained observations'):
        from dashboard_actions import context,workspace
        hidden=hidden or context(self.page.app)[1]
        was_hidden=self.signature is not None and self.signature[0]
        self.entry.configure(state='disabled' if hidden else 'normal');self.filter_button.configure(state='disabled' if hidden else 'normal')
        if hidden:self.filter.set('')
        elif was_hidden:self.filter.set(self.settings.get('filter',''))
        current=context(self.page.app)
        if hidden or self.row_context!=current:self.offset=0
        self.row_context=current;self.coverage=coverage
        self.rows=[] if hidden else rows
        values,count=selected(self.rows,self.settings,limit=self.page_size,offset=self.offset)
        if self.offset and not values:
            self.offset=max(0,((count-1)//self.page_size)*self.page_size)
            values,count=selected(self.rows,self.settings,limit=self.page_size,offset=self.offset)
        self.previous.configure(state='disabled' if hidden or not self.offset else 'normal')
        self.next.configure(state='disabled' if hidden or self.offset+len(values)>=count else 'normal')
        signature=(hidden,repr(values),current,count,self.offset,coverage)
        if signature==self.signature:return
        self.signature=signature
        self.visible={r['id']:r for r in values};self.action_context=signature[2];self.action_account=workspace(self.page.app)
        self.open_button.configure(state='disabled' if hidden or not any(r.get('target') for r in values) else 'normal')
        wanted={r['id'] for r in values}
        for key in self.tree.get_children():
            if key not in wanted:self.tree.delete(key)
        for position,row in enumerate(values):
            columns=tuple(display(row[k],k) for k in COLUMNS)
            if self.tree.exists(row['id']):self.tree.item(row['id'],values=columns);self.tree.move(row['id'],'',position)
            else:self.tree.insert('','end',iid=row['id'],values=columns)
        self.count.set('Private information hidden' if hidden else f'{self.offset+1 if values else 0}–{self.offset+len(values)} of {count} matching rows · {coverage}')
