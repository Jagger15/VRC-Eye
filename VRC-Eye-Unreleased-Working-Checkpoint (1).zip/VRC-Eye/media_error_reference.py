"""Build-qualified SDK error vocabulary and conservative local-log annotation."""
import re
from avatar_performance_report import text, timestamp
from inspection_inputs import json_file

BUILD='2026.3.3-1919-27c41b24d2-Release'
METADATA_SHA256='3d522fa493a0b9aa9aab306cc11177d2cb38832597fc4b107202f1775bf0d90e'
FAMILIES={
    'VideoError': ('VRC.SDK3.Components.Video.VideoError',('Unknown','InvalidURL','AccessDenied','PlayerError','RateLimited')),
    'VRCImageDownloadError': ('VRC.SDK3.Image.VRCImageDownloadError',('Unknown','InvalidURL','AccessDenied','DownloadError','InvalidImage','TooManyRequests')),
}
EXPLANATIONS={
    'Unknown':'The producer did not identify a more specific failure.',
    'InvalidURL':'The supplied media address was rejected as invalid. Check the actual address in the originating tool.',
    'AccessDenied':'Access was denied. This label alone does not establish whether the cause is permissions, host policy or another restriction.',
    'PlayerError':'The video player reported a failure. The code alone does not identify a codec, hardware or network cause.',
    'RateLimited':'The video request was rate limited. Wait before deliberately trying again; Eye does not retry it.',
    'DownloadError':'The image download failed. The code alone does not identify the failing host or network condition.',
    'InvalidImage':'The received image was rejected as invalid. The code alone does not prove the file is malicious.',
    'TooManyRequests':'The image producer reported too many requests. Wait before deliberately trying again; Eye does not retry it.',
}


def family_name(value):
    for key,(full,_) in FAMILIES.items():
        if value in (key,full): return key
    raise ValueError('Choose the explicit VideoError or VRCImageDownloadError family.')


def explain(family, code, *, build=''):
    key=family_name(family);full,names=FAMILIES[key]
    if type(code) is not int and not isinstance(code,str): raise ValueError('Error code must be an integer or named label.')
    if isinstance(code,str): code=text(code,80)
    if type(code) is int and not -(2**31)<=code<2**31: raise ValueError('Error code is outside the supported integer range.')
    matched=build in (BUILD,METADATA_SHA256)
    label=names[code] if type(code) is int and matched and 0<=code<len(names) else code if isinstance(code,str) and code in names else None
    state=('Build-qualified reference' if matched else 'Named label; build unverified') if label else 'Unresolved'
    meaning=EXPLANATIONS[label] if label else ('No numeric mapping is applied without the exact supported build/reference.' if not matched and type(code) is int else 'This code is not in the selected reference; retain it as unknown.')
    return dict(family=full,raw_code=code,label=label,state=state,explanation=meaning,
                supplied_build=text(build,160) if build else 'Unknown',reference_build=BUILD,reference_sha256=METADATA_SHA256,
                scope='Explains a supplied code; does not establish a runtime event, cause, public API or available action.')


PATTERN=re.compile(r'(?<![\w])(?P<family>VideoError|VRCImageDownloadError)\s*(?:[.:=]\s*|\(\s*)(?P<code>-?\d{1,10}|[A-Za-z][A-Za-z0-9_]{0,60})(?![\w])')


def log_findings(message):
    """Explicit family-qualified labels only; generic player/HTTP codes are ignored."""
    if not isinstance(message,str):return []
    results=[]
    for match in PATTERN.finditer(message[:20000]):
        raw=match['code'];code=int(raw) if re.fullmatch(r'-?\d+',raw) else raw
        try: row=explain(match['family'],code)
        except ValueError: continue
        results.append(row)
        if len(results)>=8:break
    return results


def log_summary(message):
    rows=log_findings(message)
    return '\n\n'.join(r['family']+' · '+str(r['raw_code'])+' · '+r['state']+'\n'+r['explanation'] for r in rows)


def parse(document):
    if not isinstance(document,dict) or document.get('schema')!='vrc-eye-media-errors-1': raise ValueError('Choose a VRC Eye media error report (schema 1).')
    build=text(document.get('build'),160);events=document.get('events')
    if not isinstance(events,list) or not 1<=len(events)<=200: raise ValueError('Include 1–200 media error events.')
    rows=[]
    for event in events:
        if not isinstance(event,dict):raise ValueError('Invalid media error event.')
        row=explain(event.get('family'),event.get('code'),build=build)
        row['observed_at']=timestamp(event.get('observed_at'));rows.append(row)
    return dict(schema='vrc-eye-media-error-analysis-1',supplied_build=build,events=rows,
                provenance='User-selected report claims; no live event acquisition or network requests.')


def read(path,*,stop=None):
    document,digest=json_file(path,stop=stop)
    result=parse(document);result['input_sha256']=digest
    return result
