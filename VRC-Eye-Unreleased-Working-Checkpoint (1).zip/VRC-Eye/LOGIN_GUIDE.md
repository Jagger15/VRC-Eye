> **1.21.0 Development checkpoint 2 update:** Optional **Stay signed in** now
> validates an eligible session from protected OS storage at startup. It is
> separate from remembered usernames and passwords. **Remove saved session**
> preserves the current connection; **Sign out and remove session** also
> disconnects. Windows uses user-bound DPAPI and Linux uses an unlocked Secret
> Service. No plaintext cookie fallback, automatic unlock or verification bypass
> is provided. Read [the current saved-session behavior](DEVELOPMENT_1_21.md).
> The 1.19.9 details below describe the earlier username/password feature;
> their statements about absent session persistence are historical.

# VRC Eye 1.19.9 — Remembered sign-in and keyboard login

This update builds on 1.19.8. Close the older copy, extract
**VRC-Eye-v1.19.9.zip**, open **VRC-Eye**, and run **Start.cmd**.
The launcher and dependency list are unchanged.

## The two independent remember options

Open the existing **VRChat connection** window. Choose either checkbox, both,
or neither, then sign in. New values are saved only after authentication has
finished, including any requested verification code.

| Remember username | Remember password | Next time the connection window opens |
| --- | --- | --- |
| Off | Off | Both fields are blank. |
| On | Off | The username is filled; enter the password. |
| Off | On | Only the masked password is filled; enter the username. |
| On | On | Both fields are filled; press Enter or click Sign in. |

Both options start off when nothing is saved. Simply checking an option without
completing sign-in does not save a new value. A failed login, failed verification,
cancelled attempt, or closed dialog does not replace previously saved values.
Opening the window never automatically signs in or sends a request.

Only one username and one password are remembered, not a multi-account list.
A new successful sign-in replaces the value for each selected option.

## Enter, keypad Enter, and verification

Press **Enter** or **keypad Enter** in either sign-in field or on the Sign in
button. When verification is requested, focus moves to the code field; enter the
code and press either Enter key to verify. The mouse buttons remain available.
Tab navigates the form; Space toggles a focused checkbox. Escape closes the window.

An empty username/password or empty verification code is caught before a worker
starts. Repeated Enter presses while a request is running do not start duplicate
requests. Verification does not restart password sign-in. Enter on unrelated
controls is not mapped to sign-in, and there is no application-wide Enter binding.

The saved password does not bypass verification. Codes and session cookies are
not persisted. Reopening an already connected dialog does not reauthenticate
merely because Enter is pressed.

## Forgetting values

**Uncheck Remember username** to remove the saved username immediately, without
removing the saved password. **Uncheck Remember password** removes the saved
password independently. These deletions do not require another successful login.
The current form can still be used to sign in; unchecking is about future storage.

**Forget saved sign-in** removes both stored values and clears the form. It does
not disconnect an authenticated session. **Disconnect** does the reverse: it
discards this app's in-memory session while keeping deliberately remembered
values. It does not claim to revoke other applications' server sessions.

Remember/forget controls are disabled during a request and while verification is
pending. Closing or disconnecting cancels that attempt's pending credential save.
Storage failures are visible: the app does not claim a password was removed when
Windows refused deletion, and a failed save does not undo a successful sign-in.
A save warning is also shown before a successful automatic lookup continuation
closes the dialog.

## Where the data lives

The username, when selected, goes in a separate `login-preferences.json` next to
VRC Eye's per-user settings. On Windows this is normally
`%LOCALAPPDATA%\VRC-Eye\login-preferences.json`. This small file contains only a
schema version and the username. It is not the shared companion database, and it
contains no password, code, cookie, or token.

The password is saved through **Windows Credential Manager**, using VRC Eye's
fixed generic entry `VRC-Eye/VRChat/sign-in/v1`. It uses persistence for the same
Windows user on the same computer, not enterprise roaming or all Windows users.
No new third-party package is needed. There is no plaintext password file and no
fallback that writes a password into the username file or general settings.

The password record contains a salted username comparison digest instead of a
raw saved username. This is an account-matching check, not an anonymity guarantee.
An untouched autofilled password is not submitted with a different username.
In password-only mode, use the same username spelling/capitalization used when
saving; a mismatch asks for the password manually. Deliberately editing the
password permits an intentional account switch.

Credential Manager protects storage through the operating system. It does not
make an unlocked or compromised Windows account safe from other software running
as that user. Passwords necessarily exist temporarily in the form and process
memory to sign in; the application clears fields and releases its pending
references but does not promise forensic erasure of Python/Tk memory.

**Non-Windows:** username remembering and keyboard login work, but password
remembering is disabled. There is no insecure substitute vault.
**Demo and Safe mode:** remembered sign-in is neither read nor changed; the
remember/forget controls are disabled.

Remembered values are outside the extracted application folder, so using a fresh
release folder with the same Windows account does not intentionally erase them.
The release packager excludes the login JSON and runtime databases. This update
adds no credential export, peer sharing, automatic login, session persistence,
API endpoint, or bridge capability.

## Validation scope

The release passed **2,808 tests and 1,141 subtests**, including **97 focused
storage/login tests** and **eight real Tk keyboard/focus/layout tests**. The
existing TestListener collection warning remains. A separate native UI capture
with synthetic values had no callback errors or out-of-window controls at both
standard and larger text sizes; it sent no OSC packets and opened no bridge
listener.

The Windows wrapper was tested using synthetic native-call doubles that exercise
its ctypes structure, fixed target, persistence flag, UTF-8 payload, returned
buffer handling, deletion, missing/locked records, and failure paths. **Windows
Credential Manager itself and live VRChat sign-in were not run in this Linux
environment.** See VALIDATION.md and BUILD_VALIDATION.json for exact build checks.

## Implementation references

Microsoft documents the native interface used here:

- [CREDENTIALW, generic credentials and persistence](https://learn.microsoft.com/en-us/windows/win32/api/wincred/ns-wincred-credentialw)
- [CredWriteW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-credwritew)
- [CredReadW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-credreadw)
- [CredDeleteW](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-creddeletew)
- [CredFree](https://learn.microsoft.com/en-us/windows/win32/api/wincred/nf-wincred-credfree)

These references describe Windows storage, not VRChat approval of the application.
The inherited third-party authentication/distribution review remains separate.
