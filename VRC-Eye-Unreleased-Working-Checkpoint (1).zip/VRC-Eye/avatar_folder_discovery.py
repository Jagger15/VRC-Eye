"""Bounded, read-only discovery inside one explicitly selected local directory.

Discovery stages possible files only. Names, suffixes and bundle headers never
establish an avatar identity, file access rights, or recoverable Unity source.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import os
from pathlib import Path
import stat
import time

from avatar_library_files import (FILE_LIMIT, check_cancel, checked_stream,
                                  fingerprint, inspect_file, validate_evidence, InspectionCancelled)
from creator_projects import assert_no_links, local_path

ENTRY_LIMIT = 4096
DEPTH_LIMIT = 6
CANDIDATE_LIMIT = 512
HEADER_BYTES = 32
READ_LIMIT = ENTRY_LIMIT * HEADER_BYTES
INTERVALS = (30, 60, 300)
SUFFIXES = {
    ".vrca": "Bundle candidate", ".bundle": "Bundle candidate",
    ".assetbundle": "Bundle candidate", ".obj": "OBJ source candidate",
    ".fbx": "FBX source candidate", ".glb": "glTF source candidate",
    ".gltf": "glTF source candidate", ".unitypackage": "Unity package candidate",
    ".zip": "ZIP package candidate", ".json": "JSON metadata candidate",
    ".meta": "Unity metadata candidate",
}


def _identity(info):
    return (str(info.st_dev), str(info.st_ino))


def _linked(info):
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


@dataclass(frozen=True)
class Source:
    path: str
    identity: tuple


def select_source(value):
    path = assert_no_links(local_path(value))
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or _linked(info):
        raise ValueError("Choose an existing, unlinked local folder.")
    if path == Path(path.anchor):
        raise ValueError("Select the specific authorized content folder, not a drive root.")
    return Source(str(path), _identity(info))


def validate_source(source):
    if not isinstance(source, Source):
        raise ValueError("Choose an authorized folder first.")
    path = assert_no_links(local_path(source.path))
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or _linked(info) or _identity(info) != source.identity:
        raise ValueError("The selected source folder changed. Choose the folder again.")
    return path


def _candidate_path(source, candidate):
    root = validate_source(source)
    if not isinstance(candidate, dict) or candidate.get("source") != source:
        raise ValueError("This candidate belongs to a different source folder.")
    relative = candidate.get("relative_path")
    if not isinstance(relative, str) or not relative or "\\" in relative:
        raise ValueError("Invalid discovery candidate path.")
    parts = relative.split("/")
    if any(p in ("", ".", "..") for p in parts) or Path(relative).is_absolute():
        raise ValueError("The candidate is outside the selected folder.")
    path = assert_no_links(root.joinpath(*parts))
    path.relative_to(root)
    return path


def scan_folder(source, *, stop=None, progress=None, entry_limit=ENTRY_LIMIT,
                depth_limit=DEPTH_LIMIT, candidate_limit=CANDIDATE_LIMIT,
                read_limit=READ_LIMIT):
    """Read at most 32 header bytes per bounded file; never decode cache data."""
    for value, bound, label in ((entry_limit, ENTRY_LIMIT, "entry"),
                                 (depth_limit, DEPTH_LIMIT, "depth"),
                                 (candidate_limit, CANDIDATE_LIMIT, "candidate"),
                                 (read_limit, READ_LIMIT, "read")):
        if type(value) is not int or not 1 <= value <= bound:
            raise ValueError("Invalid bounded " + label + " budget.")
    root = validate_source(source)
    result = {"source": source, "candidates": [], "entries": 0, "bytes_read": 0,
              "skipped": 0, "depth_skipped": 0, "truncated": False}
    # Directory descriptors pin traversal on platforms that support them. The
    # Windows fallback checks reparse flags and parent identity before/after.
    descriptor_walk = os.open in os.supports_dir_fd and os.scandir in os.supports_fd

    def visit(path, relative, depth, parent_fd=None, child_name=None):
        check_cancel(stop)
        validate_source(source)
        assert_no_links(path)
        before = path.lstat()
        if _linked(before) or not stat.S_ISDIR(before.st_mode):
            result["skipped"] += 1
            return
        descriptor = None
        try:
            if descriptor_walk:
                flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
                descriptor = (os.open(child_name, flags, dir_fd=parent_fd) if parent_fd is not None
                              else os.open(path, flags))
                if _identity(os.fstat(descriptor)) != _identity(before):
                    raise ValueError("A folder changed during discovery. Scan again.")
            with os.scandir(descriptor if descriptor is not None else path) as entries:
                for item in entries:
                    check_cancel(stop)
                    if result["entries"] >= entry_limit or len(result["candidates"]) >= candidate_limit:
                        result["truncated"] = True
                        break
                    result["entries"] += 1
                    if progress and result["entries"] % 128 == 0:
                        progress("Folder discovery: " + str(result["entries"]) + " entries examined")
                    # Unsupported names cannot become registered paths.
                    if "\\" in item.name or len(item.name) > 512 or any(ord(c) < 32 for c in item.name):
                        result["skipped"] += 1
                        continue
                    child = path / item.name
                    rel = relative + (item.name,)
                    try:
                        info = item.stat(follow_symlinks=False)
                        if _linked(info):
                            result["skipped"] += 1
                            continue
                        if stat.S_ISDIR(info.st_mode):
                            if depth >= depth_limit:
                                result["depth_skipped"] += 1
                            else:
                                visit(child, rel, depth + 1, descriptor, item.name)
                            if result["truncated"]: break
                            continue
                        if not stat.S_ISREG(info.st_mode) or info.st_size > FILE_LIMIT:
                            result["skipped"] += 1
                            continue
                        remaining = read_limit - result["bytes_read"]
                        if remaining < min(HEADER_BYTES, info.st_size):
                            result["truncated"] = True
                            break
                        assert_no_links(child)
                        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
                        file_fd = (os.open(item.name, flags, dir_fd=descriptor) if descriptor is not None
                                   else os.open(child, flags))
                        with os.fdopen(file_fd, "rb") as stream:
                            opened = os.fstat(stream.fileno())
                            if not stat.S_ISREG(opened.st_mode) or fingerprint(opened) != fingerprint(info):
                                raise ValueError("A discovery file changed while opening it.")
                            header = stream.read(min(HEADER_BYTES, remaining))
                            result["bytes_read"] += len(header)
                            after = os.fstat(stream.fileno())
                        assert_no_links(child)
                        if fingerprint(info) != fingerprint(after) or fingerprint(child.stat()) != fingerprint(after):
                            raise ValueError("A discovery file changed while reading it.")
                        kind = SUFFIXES.get(child.suffix.lower(), "")
                        if header.startswith((b"UnityFS\0", b"UnityWeb\0", b"UnityRaw\0")):
                            kind = "Unity bundle header (avatar unknown)"
                        if kind:
                            relative_path = "/".join(rel)
                            result["candidates"].append({
                                "id": sha256(relative_path.encode("utf-8")).hexdigest()[:24],
                                "source": source, "name": item.name, "relative_path": relative_path,
                                "kind": kind, "size": info.st_size, "fingerprint": fingerprint(info),
                                "avatar": "Unknown — explicit association required",
                            })
                    except InspectionCancelled:
                        raise
                    except (OSError, ValueError):
                        result["skipped"] += 1
            assert_no_links(path)
            if _identity(path.stat()) != _identity(before):
                raise ValueError("A folder changed during discovery. Scan again.")
        finally:
            if descriptor is not None: os.close(descriptor)

    visit(root, (), 0)
    validate_source(source)
    check_cancel(stop)
    result["candidates"].sort(key=lambda r: (r["relative_path"].casefold(), r["relative_path"]))
    return result


def inspect_candidate(source, candidate, *, stop=None, progress=None):
    path = _candidate_path(source, candidate)
    with checked_stream(path, expected=candidate.get("fingerprint")):
        pass
    evidence = inspect_file(path, stop=stop, progress=progress, limit=candidate['size'])
    if evidence["fingerprint"] != candidate.get("fingerprint"):
        raise ValueError("The candidate changed after discovery. Scan again.")
    validate_source(source)
    return evidence


def register_candidate(library, scope, avatar, source, candidate, evidence, *, role="asset", check=None):
    """Register only the explicitly reviewed evidence under the chosen avatar."""
    evidence = validate_evidence(evidence)
    path = _candidate_path(source, candidate)
    if str(path) != evidence["path"] or evidence["fingerprint"] != candidate.get("fingerprint"):
        raise ValueError("The candidate or reviewed file evidence changed. Inspect again.")
    def before_commit():
        validate_source(source)
        with checked_stream(path, expected=evidence["fingerprint"]):
            if check: check()
    before_commit()
    return library.register_file(scope, avatar, evidence, role=role, before_commit=before_commit,
                                 provenance="User-reviewed folder candidate; identity and rights not inferred")


class SessionRescan:
    """No threads, persistence, directory watching, or startup permission."""
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.stop()

    def stop(self):
        self.token = None
        self.interval = 0
        self.next_at = 0

    @property
    def enabled(self):
        return self.token is not None

    def enable(self, token, interval):
        if type(interval) is not int or interval not in INTERVALS or token is None:
            raise ValueError("Choose a 30, 60 or 300 second rescan interval.")
        self.token, self.interval = token, interval
        self.next_at = self.clock() + interval

    def due(self, token, *, visible, busy):
        if not self.enabled: return False
        if token != self.token or not visible:
            self.stop()
            return False
        if busy or self.clock() < self.next_at: return False
        self.next_at = self.clock() + self.interval
        return True
