"""Development 7: explicit owned-avatar reads and reviewed metadata edits.

Contract: community VRChat API specification, inspected 2026-10-03:
https://vrchat.community/reference/search-avatars
https://vrchat.community/reference/get-avatar
https://vrchat.community/reference/update-avatar
The schema is community-maintained; live server acceptance is unverified.
No upload, image mutation, avatar selection, deletion or platform creation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from urllib.parse import urlencode
import re

from companion_data import entity_id, stamp
from player_api import context, check_context, lock, invalidate
from vrchat_api import APIError

PAGE_SIZE = 100
SNAPSHOT_SECONDS = 300.
EDITABLE = ('name', 'description', 'releaseStatus', 'tags')
LIMITS = {'name': 100, 'description': 5000}
DIRECTIONS = '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069'


def plain(value, limit=200, *, multiline=False, empty=True):
    if (not isinstance(value, str) or len(value) > limit or
            any((ord(c) < 32 and not (multiline and c in '\n\t')) or ord(c) == 127 or c in DIRECTIONS for c in value)):
        raise ValueError('Text exceeds a local editor limit or contains unsupported controls.')
    try:
        value.encode('utf-8')
    except UnicodeError as error:
        raise ValueError('Text must be valid Unicode.') from error
    if not empty and not value.strip():
        raise ValueError('Name and description changes must contain text; clearing is not supported by this contract.')
    return value


def _tags(value):
    if not isinstance(value, (tuple, list)) or len(value) > 50:
        raise ValueError('The local editor supports at most 50 tags.')
    result = tuple(plain(tag, 100, empty=False) for tag in value)
    if len(set(result)) != len(result):
        raise ValueError('Duplicate tags are not editable here.')
    return result


def _optional(document, key, limit=200):
    value = document.get(key)
    if type(value) is int and 0 <= value <= 2**53 - 1:
        return str(value)
    try:
        return plain(value, limit)
    except ValueError:
        return ''


@dataclass(frozen=True)
class AvatarSnapshot:
    avatar: str
    owner: str
    metadata: tuple
    builds: tuple
    editable: tuple
    account: tuple
    checked: float
    checked_at: str
    detail: bool
    source_client: object = field(repr=False, compare=False)

    @property
    def name(self):
        return dict(self.metadata).get('name') or self.avatar

    @property
    def fields(self):
        return dict(self.editable)

    def document(self):
        """A new path/URL-free observation; never the original response object."""
        data = dict(self.metadata)
        data.update(id=self.avatar, authorId=self.owner)
        data.update(self.fields)
        if 'tags' in data:
            data['tags'] = list(data['tags'])
        if self.builds is not None:
            data['unityPackages'] = [dict(build) for build in self.builds]
        return data

    def summary(self):
        data = dict(self.metadata)
        lines = [f'Avatar: {self.name}', f'ID: {self.avatar}', f'Returned owner: {self.owner}',
                 f'Visibility: {data.get("releaseStatus") or "Unknown"}',
                 f'Avatar metadata revision: {data.get("version") or "Unknown"}',
                 f'Created: {data.get("created_at") or "Unknown"}', f'Updated: {data.get("updated_at") or "Unknown"}',
                 f'Explicitly read: {self.checked_at}',
                 'Builds below are returned observations, not complete historical versions or proof of compatibility.']
        if self.builds is None:
            lines.append('Platform/build information was not returned in a supported form.')
        elif not self.builds:
            lines.append('The response contained no build entries; no platform support is inferred.')
        else:
            for index, build in enumerate(self.builds, 1):
                b = dict(build)
                lines.append(f'{index}. {b.get("platform") or "Unknown platform"} | Unity {b.get("unityVersion") or "unknown"} | asset revision {b.get("assetVersion") or "unknown"} | {b.get("variant") or "unknown variant"} | {b.get("performanceRating") or "rating unknown"}')
        missing = [key for key in EDITABLE if key not in self.fields]
        if missing:
            lines.append('Read-only / unsupported or missing fields: ' + ', '.join(missing))
        return '\n'.join(lines)


@dataclass(frozen=True)
class AvatarPage:
    rows: tuple
    account: tuple
    checked: float
    offset: int
    more: bool
    source_client: object = field(repr=False, compare=False)


@dataclass(frozen=True)
class AvatarPlan:
    snapshot: AvatarSnapshot
    changes: tuple

    @property
    def avatar(self):
        return self.snapshot.avatar

    @property
    def fields(self):
        previous = self.snapshot.fields
        return tuple((key, previous[key], value) for key, value in self.changes)


def snapshot(document, client, account, checked, *, detail=False, expected=''):
    if not isinstance(document, dict):
        raise APIError('VRChat did not return an avatar object.')
    avatar = entity_id('avatar', document.get('id'))
    owner = entity_id('user', document.get('authorId'))
    if owner != account[0] or expected and avatar != expected:
        raise APIError('The returned avatar ID or author does not match this account and selection.')
    metadata = []
    for key, limit in (('name', 512), ('description', 20000), ('releaseStatus', 80),
                       ('authorName', 512), ('created_at', 100), ('updated_at', 100), ('version', 40)):
        value = _optional(document, key, limit)
        if value:
            metadata.append((key, value))
    editable = []
    for key in EDITABLE:
        if key not in document:
            continue
        value = document[key]
        try:
            if key == 'tags':
                if not isinstance(value, list):
                    raise ValueError('Unsupported tags.')
                value = _tags(value)
            elif key == 'releaseStatus':
                if value not in ('public', 'private'):
                    raise ValueError('Unsupported release state.')
            else:
                value = plain(value, LIMITS[key], multiline=key == 'description')
            editable.append((key, value))
        except ValueError:
            pass
    builds = None
    packages = document.get('unityPackages')
    if isinstance(packages, list) and len(packages) <= 100 and all(isinstance(p, dict) for p in packages):
        builds = tuple(tuple((key, _optional(p, key, 100)) for key in (
            'platform', 'unityVersion', 'assetVersion', 'variant', 'performanceRating', 'created_at')) for p in packages)
    return AvatarSnapshot(avatar, owner, tuple(metadata), builds, tuple(editable), account,
                          checked, stamp(), detail, client)


def _read(client, path, *, many=False, stop=None, progress=None):
    account = context(client)
    entity_id('user', account[0])
    lock(client, stop)
    try:
        check_context(client, account, stop)
        client._wait_metadata(stop, progress)
        check_context(client, account, stop)
        data = client._request(path, expect_list=many)
        check_context(client, account, stop)
        return data, account, client.clock()
    finally:
        client.lock.release()


def read_page(client, *, offset=0, stop=None, progress=None):
    if type(offset) is not int or not 0 <= offset <= 2_000_000_000 or offset % PAGE_SIZE:
        raise ValueError('Choose a supported avatar page offset.')
    params = dict(user='me', releaseStatus='all', n=PAGE_SIZE, offset=offset, sort='name', order='ascending')
    data, account, checked = _read(client, 'avatars?' + urlencode(params), many=True, stop=stop, progress=progress)
    if not isinstance(data, list) or len(data) > PAGE_SIZE:
        raise APIError('VRChat returned an unsupported owned-avatar page.')
    rows = tuple(snapshot(row, client, account, checked) for row in data)
    if len({row.avatar for row in rows}) != len(rows):
        raise APIError('The avatar page contains duplicate identities. Refresh the page.')
    return AvatarPage(rows, account, checked, offset, len(data) == PAGE_SIZE, client)


def read_avatar(client, avatar, *, stop=None, progress=None):
    avatar = entity_id('avatar', avatar)
    data, account, checked = _read(client, 'avatars/' + avatar, stop=stop, progress=progress)
    return snapshot(data, client, account, checked, detail=True, expected=avatar)


def validate_snapshot(client, value, *, detail=True):
    if (not isinstance(value, AvatarSnapshot) or value.source_client is not client or
            value.account != context(client) or value.owner != value.account[0] or
            not 0 <= client.clock() - value.checked < SNAPSHOT_SECONDS or detail and not value.detail):
        raise ValueError('Refresh the selected owned avatar using this connection before reviewing changes (five-minute freshness window).')
    entity_id('avatar', value.avatar)
    entity_id('user', value.owner)
    return value


def prepare(client, *, result, values):
    validate_snapshot(client, result)
    if not isinstance(values, dict) or not values or set(values) - set(EDITABLE):
        raise ValueError('Only returned name, description, public/private visibility and author tags can be edited.')
    baseline = result.fields
    changes = []
    for key, value in values.items():
        if key not in baseline:
            raise ValueError('This field was not returned in an editable form. Refresh before editing.')
        if key == 'tags':
            value = _tags(value)
            original_reserved = tuple(v for v in baseline[key] if not v.startswith('author_tag_'))
            if tuple(v for v in value if not v.startswith('author_tag_')) != original_reserved:
                raise ValueError('Classification and system tags are read-only; preserve them exactly.')
            for tag in value:
                if tag.startswith('author_tag_') and not re.fullmatch(r'author_tag_[A-Za-z0-9_ -]{1,89}', tag):
                    raise ValueError('Use author tags containing letters, numbers, spaces, underscores or hyphens.')
        elif key == 'releaseStatus':
            if value not in ('public', 'private'):
                raise ValueError('Choose public or private; hidden/all states cannot be written here.')
        else:
            value = plain(value, LIMITS[key], multiline=key == 'description')
        if value != baseline[key]:
            if key in LIMITS:
                plain(value, LIMITS[key], multiline=key == 'description', empty=False)
            changes.append((key, value))
    if not changes:
        raise ValueError('No changed avatar fields to submit.')
    return AvatarPlan(result, tuple(sorted(changes)))


def validate_plan(client, plan):
    if not isinstance(plan, AvatarPlan):
        raise ValueError('A reviewed avatar plan is required.')
    validate_snapshot(client, plan.snapshot)
    normalized = prepare(client, result=plan.snapshot, values=dict(plan.changes))
    if normalized.changes != plan.changes:
        raise ValueError('The reviewed avatar changes are invalid.')
    return plan


def dispatch(client, plan, *, stop=None, progress=None, before_dispatch=None, on_confirmed=None):
    """One shared-budget PUT; callbacks integrate the durable ActionService."""
    validate_plan(client, plan)
    expected = plan.snapshot.account
    payload = {key: list(value) if key == 'tags' else value for key, value in plan.changes}
    lock(client, stop)
    try:
        check_context(client, expected, stop)
        validate_plan(client, plan)
        client._wait_metadata(stop, progress)
        check_context(client, expected, stop)
        validate_plan(client, plan)
        if before_dispatch:
            before_dispatch()
        check_context(client, expected, stop)
        validate_plan(client, plan)
        try:
            data = client._request('avatars/' + plan.avatar, method='PUT', payload=payload)
        finally:
            # Even uncertain responses may have committed. Never reuse an old cache.
            invalidate(client, avatar_id=plan.avatar)
        if not isinstance(data, dict) or data.get('id') != plan.avatar or data.get('authorId') != expected[0]:
            raise APIError('Avatar acknowledgement did not establish the expected avatar and author.')
        for key, value in payload.items():
            if data.get(key) != value:
                raise APIError('Avatar acknowledgement did not confirm every reviewed field exactly.')
        if on_confirmed:
            on_confirmed()
        check_context(client, expected, stop)
        return snapshot(data, client, expected, client.clock(), detail=True, expected=plan.avatar)
    finally:
        client.lock.release()
