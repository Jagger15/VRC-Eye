"""Opt-in, bounded cooperative playtest observations. No remote actions or identities.

Clock alignment is supplied by participants, not certified by VRC Eye. Cards with
unrelated local starts must never be ordered as if they used a shared clock.
"""
from copy import deepcopy
from bridge_lab_contract import identifier

CATEGORIES = ('milestone', 'performance', 'avatar_state')


def test_ref(value):
    """Keep native Eye-to-Eye hex IDs exact; never normalize the context."""
    import re
    import bridge_protocol as p
    if not isinstance(value,str) or not re.fullmatch(r'(?:[0-9a-f]{32}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})',value):
        raise p.BridgeError('Use the exact generated shared playtest or peer-session ID (32 lowercase hex digits or a canonical UUID).')
    return value


def validate_card(value):
    import bridge_protocol as p
    p.exact(value, ('schema', 'card_id', 'test_id', 'milestone', 'provider', 'categories', 'observed',
                    'elapsed_ms', 'alignment', 'uncertainty_ms', 'metrics', 'avatar_phase', 'provider_ref', 'provider_contract', 'provider_version'))
    if type(value['schema']) is not int or value['schema'] != 1: raise p.BridgeError('Unsupported lab card schema.')
    p.ref(value['card_id']); test_ref(value['test_id']); identifier(value['milestone'])
    p.ref(value['provider_ref']);p.choice(value['provider_contract'],('client-bridge-lab-1',))
    if value['provider_version'] is not None:identifier(value['provider_version'],40)
    p.choice(value['provider'], ('client_reported', 'synthetic', 'unavailable'))
    if not isinstance(value['categories'], list) or not value['categories'] or len(value['categories'])>len(CATEGORIES) or not all(isinstance(c,str) for c in value['categories']) or len(value['categories']) != len(set(value['categories'])) or set(value['categories'])-set(CATEGORIES):
        raise p.BridgeError('Select only the diagnostic categories you deliberately share.')
    if value['observed'] is not None: p.boolean(value['observed'])
    if value['elapsed_ms'] is not None: p.number(value['elapsed_ms'], 86400000)
    p.choice(value['alignment'], ('local_start', 'participant_shared_cue'))
    if value['uncertainty_ms'] is not None: p.number(value['uncertainty_ms'], 86400000)
    if value['alignment'] == 'participant_shared_cue' and value['uncertainty_ms'] is None:
        raise p.BridgeError('Participant-supplied alignment requires an explicit uncertainty bound.')
    if value['observed'] is not True and value['elapsed_ms'] is not None:
        raise p.BridgeError('A missing or unobserved milestone cannot claim an event time.')
    if value['provider'] == 'unavailable' and (value['observed'] is not None or value['metrics'] or value['avatar_phase'] is not None):
        raise p.BridgeError('Unavailable providers cannot fabricate observations.')
    p.exact(value['metrics'], (), ('frame_ms', 'fps'))
    for metric in value['metrics'].values():
        if metric is not None: p.number(metric, 100000)
    if value['avatar_phase'] is not None: p.choice(value['avatar_phase'], ('initializing', 'ready', 'transition', 'unavailable'))
    if 'milestone' not in value['categories'] and (value['observed'] is not None or value['elapsed_ms'] is not None):
        raise p.BridgeError('Milestone disclosure was not selected.')
    if 'performance' not in value['categories'] and value['metrics']: raise p.BridgeError('Performance disclosure was not selected.')
    if 'avatar_state' not in value['categories'] and value['avatar_phase'] is not None: raise p.BridgeError('Avatar state disclosure was not selected.')
    p.encode(value)
    return deepcopy(value)


def compare_cards(cards):
    """Pairwise interval evidence, never a leaderboard or claim of cause."""
    if not isinstance(cards, list) or len(cards) > 32: raise ValueError('Compare at most 32 deliberately supplied participant cards.')
    clean = [validate_card(card) for card in cards]
    rows=[]
    for i, a in enumerate(clean):
        for j in range(i+1,len(clean)):
            b=clean[j]
            result=dict(cards=[i+1,j+1], evidence='provider/participant claims; distinct participants are not independently verified', outcome='not comparable')
            if a['card_id']==b['card_id']: result['reason']='Duplicate card; not independent evidence.'
            elif a['provider_ref']==b['provider_ref']: result['reason']='Same provider reference; not independent participant evidence.'
            elif (a['test_id'],a['milestone']) != (b['test_id'],b['milestone']): result['reason']='Different test or milestone.'
            elif a['provider']=='synthetic' or b['provider']=='synthetic':
                result['reason']='Synthetic evidence; never evidence about a live playtest.'
            elif a['observed'] is not True or b['observed'] is not True: result['reason']='At least one participant has no positive milestone observation.'
            elif a['alignment']!='participant_shared_cue' or b['alignment']!='participant_shared_cue':
                result['reason']='Independent local starts cannot establish cross-client ordering.'
            elif a['elapsed_ms'] is None or b['elapsed_ms'] is None:
                result['reason']='No captured event time is available.'
            else:
                # b-a, with conservative interval addition. Participant clock bounds
                # remain assumptions even when intervals do not overlap.
                delta=b['elapsed_ms']-a['elapsed_ms']; uncertainty=a['uncertainty_ms']+b['uncertainty_ms']
                result.update(outcome='conditional timing comparison', delta_ms=delta,
                              interval_ms=[delta-uncertainty,delta+uncertainty],
                              reason='Based only on participant-supplied shared-cue alignment and uncertainty; causation not established.')
            rows.append(result)
    return {'cards':clean, 'comparisons':rows, 'silent_collection':False,
            'note':'A missing diagnostic provider is missing evidence, not proof that an event failed.'}
