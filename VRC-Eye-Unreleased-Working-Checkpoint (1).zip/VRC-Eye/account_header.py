"""Session-only account presentation; never authentication, polling or authority.

The shell calls AccountHeader.tick from its existing UI tick. Names come only
from a confirmed response; saved credentials and game/VRCX identities are not
inputs. No network lock is acquired to paint the header.
"""

from text_viewport import window_body
from dataclasses import dataclass
import unicodedata


PREFERENCE = 'ui.account_identity_hidden'


def name(value):
    """Reject malformed optional names without rejecting a valid login."""
    if not isinstance(value, str) or not value.strip() or len(value) > 256:
        return ''
    if any(unicodedata.category(c) in ('Cc', 'Cs') or
           c in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069' for c in value):
        return ''
    return value.strip()


def _display_units(value):
    """Keep common combining/emoji sequences intact in a compact preview."""
    result = []
    regional = 0
    for char in value:
        code = ord(char)
        is_regional = 0x1f1e6 <= code <= 0x1f1ff
        joined = (unicodedata.category(char).startswith('M') or char == '\u200d' or
                  0x1f3fb <= code <= 0x1f3ff or 0xe0020 <= code <= 0xe007f)
        if result and (joined or result[-1].endswith('\u200d') or (is_regional and regional % 2)):
            result[-1] += char
        else:
            result.append(char)
        regional = regional + 1 if is_regional else 0
    return result


@dataclass(frozen=True)
class Identity:
    account_id: str
    session_revision: int
    revision: int
    username: str = ''
    display_name: str = ''
    confirmed_at: str = ''


def boundary(app):
    client = getattr(app, 'api', None)
    return (client, getattr(client, 'user_id', ''), getattr(client, 'session_revision', 0),
            bool(client and getattr(client, 'authenticated', False)),
            bool(client and getattr(client, 'closed', None) and client.closed.is_set()),
            getattr(app, 'data_generation', 0), bool(getattr(app, 'demo', False)),
            bool(getattr(app, 'safe_mode', False)))


def _value(value):
    result = value.get() if hasattr(value, 'get') else value() if callable(value) else value
    # Some pages have a StringVar named privacy containing status prose.
    # Only a privacy flag may hide identity; a nonempty caption is not a flag.
    return result is True or type(result) is int and result == 1


def private(app):
    """A failed privacy read must never make an identity visible."""
    return bool(privacy_reasons(app))


def privacy_reasons(app):
    try:
        return _privacy_reasons(app)
    except Exception:
        # Privacy inputs can be live Tk variables or closing page controllers.
        return ('Privacy state unavailable',)


def _privacy_reasons(app):
    reasons = []
    if getattr(app,'desktop_locked',False):reasons.append('Desktop locked')
    if _value(getattr(app, 'account_identity_hidden', False)):
        reasons.append('Hide account identity')
    if getattr(app, 'demo', False):
        reasons.append('Demo mode')
    players = getattr(app, 'player_sessions', None)
    prefs = getattr(players, 'settings', {})
    if prefs.get('presentation'):
        reasons.append('Player-list presentation mode')
    if prefs.get('anonymize'):
        reasons.append('Player-list anonymization')
    shell = getattr(app, 'sidebar', None)
    pages = getattr(shell, 'pages', {})
    wellness = pages.get('Wellness')
    if getattr(getattr(wellness, 'engine', None), 'settings', {}).get('streamer'):
        reasons.append('Wellness streamer mode')
    page = pages.get(getattr(shell, 'current', ''))
    if page and any(_value(getattr(page, key, False)) for key in ('private', 'privacy')):
        reasons.append('Current workspace privacy')
    library = getattr(getattr(getattr(app, 'avatar_creator', None), 'panel', None), 'library_page', None)
    if library and getattr(shell, 'current', '') == 'Primary':
        try:
            if library.parent.winfo_ismapped() and _value(getattr(library, 'privacy', False)):
                reasons.append('Avatar Library privacy')
        except (AttributeError, RuntimeError):
            return ('Privacy state unavailable',)
    return tuple(reasons)


def identity_visibility_context(app, reasons):
    return boundary(app), getattr(getattr(app, 'sidebar', None), 'current', ''), reasons


def identity_hidden(app):
    """Explicit name reveal affects account text only, never action permissions.

    Presentation modes may hide the banner automatically, but unchecking its
    visibility control must be able to show the confirmed name. The exception
    is session-only and expires on account, page or privacy-policy changes.
    Demo and unreadable privacy state cannot be overridden.
    """
    reasons = privacy_reasons(app)
    reveal = getattr(app, '_account_identity_reveal', None)
    if (not any(r in reasons for r in ('Demo mode', 'Privacy state unavailable', 'Hide account identity'))
            and reveal is not None and reveal == identity_visibility_context(app, reasons)):
        return False
    app._account_identity_reveal = None
    return bool(reasons)


@dataclass(frozen=True)
class Presentation:
    active: bool
    hidden: bool
    title: str
    detail: str = ''
    username: str = ''
    display_name: str = ''
    primary: str = ''
    caption: str = 'VRChat account'


def presentation(app):
    token = boundary(app)
    client, user, revision, authenticated, closed = token[:5]
    hidden = identity_hidden(app)
    active = bool(authenticated and not closed)
    identity = getattr(client, 'account_identity', None)
    if (not active or not isinstance(identity, Identity) or
            identity.account_id != user or identity.session_revision != revision):
        identity = None
    attempt = getattr(app, '_account_auth_attempt', None)
    phase = attempt[1] if isinstance(attempt, tuple) and len(attempt) == 3 and attempt[2] == token else ''
    restore = getattr(getattr(app, 'session_restore', None), 'snapshot', None)
    detail = ''
    username = display_name = ''
    caption = 'VRChat account'
    if identity and not hidden:
        username, display_name = name(identity.username), name(identity.display_name)
    if active:
        if hidden:
            title = 'Signed in — identity hidden'
            if not _value(getattr(app, 'account_identity_hidden', False)):
                detail = 'Hidden by: ' + ', '.join(privacy_reasons(app)) + '.'
        elif username:
            title = 'Signed in as: ' + username
            if display_name and display_name != username:
                detail = 'Display name: ' + display_name
        elif display_name:
            title = 'Signed in as: ' + display_name
            detail = 'Display name · Username not supplied'
        else:
            title = 'Signed in · Account name unavailable'
        if phase:
            detail = ('Verification required for another account' if phase == 'verify'
                      else 'Signing into another account…')
        elif getattr(client, 'connection_state', '') == 'unreachable':
            detail = 'Could not reach VRChat. This session has not been rejected.'
        elif getattr(restore, 'busy', False):
            detail = restore.detail or restore.title
    elif phase:
        title = 'Verification required' if phase == 'verify' else 'Signing in…'
    elif getattr(client, 'session_reason', '') == 'rejected' and not closed:
        title = 'Sign-in required · Session no longer accepted'
    elif getattr(restore, 'state', '') in ('restoring', 'locked', 'offline_unverified',
                                         'challenge_required', 'storage_error', 'rejected'):
        title, detail = restore.title, restore.detail
    else:
        title = 'Not signed in'
    primary = username or display_name or title
    if username or display_name:
        caption += ' · Signed in'
    # A concurrent account boundary never borrows the previous account's name.
    if token != boundary(app):
        title = 'Account state changed · Updating…'
        return Presentation(False, hidden, title, primary=title)
    return Presentation(active, hidden, title, detail, username, display_name, primary, caption)


def attempt(app, owner, phase='', token=None):
    current = getattr(app, '_account_auth_attempt', None)
    if phase:
        app._account_auth_attempt = (owner, phase, boundary(app) if token is None else token)
    elif current and current[0] is owner:
        app._account_auth_attempt = None


class AccountHeader:
    """One responsive account strip; tick reports authentication boundaries."""
    def __init__(self, app, parent):
        self.app = app
        self.closed = False
        self._boundary = boundary(app)
        self._rendered = None
        self._theme_signature = None
        self._layout_signature = None
        self._preview_signature = None
        self._privacy_notice = ''
        self.identity_window = None
        self.identity_value = None
        store = getattr(getattr(app, 'sidebar', None), 'store', None)
        try:
            stored = store.option(PREFERENCE, False) if store else False
            hidden = stored if type(stored) is bool else True
        except (OSError, ValueError, __import__('sqlite3').Error):
            hidden = True
        app.account_identity_hidden = hidden
        self.frame = app.ttk.Frame(parent)
        self.frame.columnconfigure(1, weight=1)
        self.edge = app.ttk.Frame(self.frame, style='AccountEdge.TFrame', width=3)
        self.edge.grid(row=0, column=0, rowspan=3, sticky='ns', padx=(0, 10))
        # Keep the legacy complete title available to existing account clients.
        # Every variable is replaced from the same redacted presentation.
        self.text = app.tk.StringVar()
        self.identity = app.tk.StringVar()
        self.caption = app.tk.StringVar()
        self.detail = app.tk.StringVar()
        self.hide = app.tk.BooleanVar(value=hidden)
        self.summary = app.ttk.Frame(self.frame)
        self.summary.grid(row=0, column=1, sticky='ew')
        self.summary.pack_propagate(False)
        self.context = app.ttk.Label(self.summary, textvariable=self.caption, style='Muted.TLabel', wraplength=420)
        self.context.pack(fill='x')
        self.label = app.ttk.Label(self.summary, textvariable=self.identity,
                                   style='AccountIdentity.TLabel', wraplength=420)
        self.label.pack(fill='x')
        self.controls = app.ttk.Frame(self.frame)
        self.controls.grid(row=0, column=2, sticky='e', padx=(12, 0))
        self.privacy = app.ttk.Checkbutton(self.controls, text='Hide account identity', variable=self.hide,
                                         command=self.set_private)
        self.privacy.grid(row=0, column=0, sticky='w', padx=(0, 8))
        self.identity_button = app.ttk.Button(self.controls, text='Identity…', width=8,
                                             command=self.open_identity)
        self.identity_button.grid(row=0, column=1, sticky='e', padx=(0, 8))
        self.button = app.ttk.Button(self.controls, text='Account…', width=8, command=self.open_account)
        self.button.grid(row=0, column=2, sticky='e')
        self.details = app.ttk.Label(self.frame, textvariable=self.detail, style='Muted.TLabel', wraplength=950)
        self.detail.trace_add('write', lambda *_: self.layout_details())
        self.frame.bind('<Configure>', self.resize, add='+')
        self.frame.bind('<<ThemeChanged>>', self.theme_changed, add='+')
        self.refresh()

    def layout_details(self):
        if self.closed:
            return
        if self.detail.get():
            self.details.grid(row=2, column=1, columnspan=2, sticky='ew', pady=(2, 0))
        else:
            self.details.grid_remove()

    def theme_changed(self, event=None):
        if self.closed:
            return
        from tkinter import font as tkfont
        style = self.app.ttk.Style(self.frame)
        base = tkfont.Font(root=self.frame, font=style.lookup('TLabel', 'font') or 'TkDefaultFont')
        family, size = base.actual('family'), base.actual('size')
        accent = getattr(self.app, 'ACCENT', style.lookup('TLabel', 'foreground'))
        signature = (family, size, accent, style.lookup('TLabel', 'background'))
        if signature != self._theme_signature:
            self._theme_signature = signature
            style.configure('AccountIdentity.TLabel', foreground=accent,
                            font=(family, size + max(2, round(size * .2)), 'bold'))
            style.configure('AccountEdge.TFrame', background=accent)
            self._identity_minimum = max(220, base.measure('Account name') + 16)
            # At large fonts, a one-line preview keeps the whole application's
            # content viewport usable at its minimum height. Full values remain
            # in the explicitly opened identity view; text is never shrunk.
            preview_lines = 1 if size >= 18 else 2
            self._primary_height = tkfont.Font(root=self.frame,
                font=style.lookup('AccountIdentity.TLabel', 'font')).metrics('linespace') * preview_lines + 4
            self._caption_height = base.metrics('linespace') + 4
            self._detail_height = base.metrics('linespace') * 2 + 4
            self._layout_signature = None
        self.resize()

    def resize(self, event=None):
        if self.closed or self._theme_signature is None:
            return
        width = self.frame.winfo_width() if event is None else event.width
        if width <= 1:
            return
        available = max(1, width - 13)
        controls = (self.privacy.winfo_reqwidth() + self.identity_button.winfo_reqwidth() +
                    self.button.winfo_reqwidth() + 16)
        beside = available >= self._identity_minimum + controls + 12
        controls_inline = available >= controls
        signature = (width, beside, controls_inline, controls)
        if signature == self._layout_signature:
            return
        self._layout_signature = signature
        self.summary.grid_configure(columnspan=1 if beside else 2)
        self.controls.grid_configure(row=0 if beside else 1, column=2 if beside else 1,
                                     columnspan=1 if beside else 2,
                                     sticky='e' if beside else 'w',
                                     padx=(12, 0) if beside else 0,
                                     pady=0 if beside else (4, 0))
        self.identity_button.grid_configure(row=0 if controls_inline else 1,
                                   column=1 if controls_inline else 0,
                                   sticky='e' if controls_inline else 'w')
        self.button.grid_configure(row=0 if controls_inline else 1,
                                   column=2 if controls_inline else 1,
                                   sticky='e' if controls_inline else 'w')
        self.privacy.grid_configure(padx=(0, 8) if controls_inline else 0)
        identity_width = max(1, available - controls - 12) if beside else available
        self.label.configure(wraplength=identity_width)
        self.context.configure(wraplength=identity_width)
        self.details.configure(wraplength=available)
        self._paint_preview()

    @staticmethod
    def _fit(label, variable, text, height):
        """Bound only the preview; the explicit identity view keeps full values."""
        variable.set(text)
        if label.winfo_reqheight() <= height:
            return
        units = _display_units(text)
        low, high = 0, len(units)
        while low < high:
            middle = (low + high + 1) // 2
            variable.set(''.join(units[:middle]).rstrip() + '…')
            if label.winfo_reqheight() <= height:
                low = middle
            else:
                high = middle - 1
        variable.set(''.join(units[:low]).rstrip() + '…')

    def _paint_preview(self):
        value = self._rendered
        if value is None or self._theme_signature is None:
            return
        signature = (value, self._privacy_notice, self._layout_signature, self._theme_signature)
        if signature == self._preview_signature:
            return
        self._preview_signature = signature
        self.caption.set(value.caption)
        if self.context.winfo_reqheight() > self._caption_height:
            self.caption.set('VRChat · Signed in' if value.username or value.display_name else 'VRChat account')
        if self.context.winfo_reqheight() > self._caption_height:
            self.caption.set('Signed in' if value.username or value.display_name else 'VRChat')
        self._fit(self.label, self.identity, value.primary, self._primary_height)
        self.summary.configure(height=self.context.winfo_reqheight() + self._primary_height)
        detail = '\n'.join(part for part in (value.detail, self._privacy_notice) if part)
        identity_detail = bool(value.display_name and value.detail == 'Display name: ' + value.display_name
                               and not self._privacy_notice)
        self.details.configure(style='Accent.TLabel' if identity_detail else 'Muted.TLabel')
        # Only identity detail can be long. Never abbreviate an error/restore
        # notice, whose full explanation belongs directly in the account strip.
        if identity_detail:
            self._fit(self.details, self.detail, detail, self._detail_height)
        elif self.detail.get() != detail:
            self.detail.set(detail)

    def open_identity(self):
        self.refresh()
        if not (self._rendered.username or self._rendered.display_name):
            return
        if self.identity_window is not None:
            self.identity_window.lift()
            return
        window = self.identity_window = self.app.tk.Toplevel(self.frame)
        window.title('Account identity')
        window.geometry('680x440')
        window.minsize(360, 260)
        window_body(window).columnconfigure(0, weight=1)
        window_body(window).rowconfigure(0, weight=1)
        self.identity_value = self.app.tk.Text(window_body(window), wrap='word', font='TkDefaultFont',
                                               padx=12, pady=12, width=36, height=8,
                                               undo=False, exportselection=False)
        self.identity_value.grid(row=0, column=0, sticky='nsew')
        scroll = self.app.ttk.Scrollbar(window_body(window), orient='vertical', command=self.identity_value.yview)
        scroll.grid(row=0, column=1, sticky='ns')
        self.identity_value.configure(yscrollcommand=scroll.set)
        self.app.ttk.Button(window_body(window), text='Close', command=self.close_identity).grid(
            row=1, column=0, columnspan=2, sticky='e', padx=12, pady=8)
        window.protocol('WM_DELETE_WINDOW', self.close_identity)
        window.bind('<Escape>', lambda _: self.close_identity())
        self._refresh_identity_view()
        self.identity_value.focus_set()

    def _refresh_identity_view(self):
        if self.identity_window is None:
            return
        value = self._rendered
        if value.username or value.display_name:
            parts = ['Username:\n' + value.username if value.username else 'Username not supplied.']
            if value.display_name:
                parts.append('Display name:\n' + value.display_name)
            text = '\n\n'.join(parts)
        else:
            text = value.primary
        if self.identity_value.get('1.0', 'end-1c') != text:
            self.identity_value.configure(state='normal')
            self.identity_value.delete('1.0', 'end')
            self.identity_value.insert('1.0', text)
            self.identity_value.configure(state='disabled')

    def close_identity(self):
        if self.identity_window is not None:
            self.identity_value.configure(state='normal')
            self.identity_value.delete('1.0', 'end')
            self.identity_window.destroy()
            self.identity_window = self.identity_value = None

    def open_account(self):
        from online_dialog import show_connection_dialog
        show_connection_dialog(self.app)

    def set_private(self):
        hidden = bool(self.hide.get())
        self.app.account_identity_hidden = hidden
        self.app._account_identity_reveal = None
        reasons = privacy_reasons(self.app)
        if not hidden and reasons and not any(reason in reasons for reason in ('Demo mode', 'Privacy state unavailable')):
            self.app._account_identity_reveal = identity_visibility_context(self.app, reasons)
        self._privacy_notice = ''
        policy_changed = getattr(getattr(self.app, 'session_restore', None), 'policy_changed', None)
        try:
            if policy_changed:
                policy_changed()
        finally:
            self.refresh()
        if not (getattr(self.app, 'demo', False) or getattr(self.app, 'safe_mode', False)):
            try:
                self.app.sidebar.store.set_option(PREFERENCE, hidden)
            except (OSError, ValueError, __import__('sqlite3').Error):
                self._privacy_notice = 'Privacy changed for this session; the preference could not be saved.'
                self.detail.set(self._privacy_notice)

    def refresh(self):
        if self.closed:
            return
        self.theme_changed()
        value = presentation(self.app)
        # Reflect effective visibility; an unchecked box must not silently leave
        # a name hidden by another presentation preference.
        if self.hide.get() != value.hidden:
            self.hide.set(value.hidden)
        if value != self._rendered:
            self._rendered = value
            self.text.set('VRChat account · ' + value.title)
            self.caption.set(value.caption)
            self.button.configure(text='Account…' if value.active else 'Sign in…')
            self.identity_button.state(['!disabled'] if value.username or value.display_name else ['disabled'])
        self._paint_preview()
        self._refresh_identity_view()
        window = getattr(self.app, 'connection_window', None)
        refresh = getattr(window, 'refresh_account', None)
        if refresh:
            refresh()

    def tick(self):
        if self.closed:
            return False
        token = boundary(self.app)
        changed = token != self._boundary
        self._boundary = token
        self.refresh()
        return changed

    def close(self):
        self.close_identity()
        self.closed = True
