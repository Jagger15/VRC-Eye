"""Opt-in sign-in memory, separate from shared settings/diagnostic databases.

Only the username is stored in a small local JSON file. Passwords use our one
fixed Windows Credential Manager entry; there is no plaintext/file fallback,
credential enumeration, cookie storage, or network access in this module.
"""
from __future__ import annotations

import ctypes
from dataclasses import dataclass, field
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sys
import tempfile

from vrcx_integration import settings_path

CREDENTIAL_TARGET = "VRC-Eye/VRChat/sign-in/v1"
CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2  # Same Windows user, on this computer; not all users.
ERROR_NOT_FOUND = 1168
MAX_CREDENTIAL_BYTES = 2560
MAX_USERNAME_BYTES = 4096


class LoginStorageError(Exception):
    """A user-facing failure whose text never contains supplied credentials."""


@dataclass(frozen=True, repr=False)
class SavedPassword:
    password: str = field(repr=False)
    salt: str = field(repr=False)
    account_digest: str = field(repr=False)

    @classmethod
    def create(cls, username: str, password: str) -> SavedPassword:
        if not isinstance(username, str) or not username.strip() or not isinstance(password, str) or not password:
            raise LoginStorageError("A username and password are needed before a password can be saved.")
        salt = secrets.token_hex(16)
        digest = hashlib.sha256(bytes.fromhex(salt) + username.strip().encode("utf-8")).hexdigest()
        return cls(password, salt, digest)

    def matches(self, username: str) -> bool:
        if not isinstance(username, str) or not username.strip():
            return False
        digest = hashlib.sha256(bytes.fromhex(self.salt) + username.strip().encode("utf-8")).hexdigest()
        return hmac.compare_digest(self.account_digest, digest)

    def encode(self) -> bytes:
        # The account binding is salted, not a saved raw username. It prevents
        # submitting an untouched autofilled password for another typed account.
        raw = json.dumps({"schema": 1, "password": self.password, "salt": self.salt,
                          "account_digest": self.account_digest}, ensure_ascii=False).encode("utf-8")
        if len(raw) > MAX_CREDENTIAL_BYTES:
            raise LoginStorageError("This password is too long for the Windows credential entry. Sign-in still works without remembering it.")
        return raw

    @classmethod
    def decode(cls, raw: bytes) -> SavedPassword:
        try:
            if not isinstance(raw, bytes) or not 1 <= len(raw) <= MAX_CREDENTIAL_BYTES:
                raise ValueError
            value = json.loads(raw.decode("utf-8"))
            if (not isinstance(value, dict) or set(value) != {"schema", "password", "salt", "account_digest"}
                    or type(value["schema"]) is not int or value["schema"] != 1
                    or not isinstance(value["password"], str) or not value["password"]
                    or not isinstance(value["salt"], str) or not re.fullmatch(r"[0-9a-f]{32}", value["salt"])
                    or not isinstance(value["account_digest"], str)
                    or not re.fullmatch(r"[0-9a-f]{64}", value["account_digest"])):
                raise ValueError
            value["password"].encode("utf-8")  # Reject malformed Unicode before filling a Tk field.
            return cls(value["password"], value["salt"], value["account_digest"])
        except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
            raise LoginStorageError("The saved password entry could not be read. Forget saved sign-in, then sign in again to replace it.") from None


# Fixed-width Win32 integer fields also make the ABI layout testable on Linux.
class _FILETIME(ctypes.Structure):
    _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]


class _CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", ctypes.c_uint32), ("Type", ctypes.c_uint32),
        ("TargetName", ctypes.c_wchar_p), ("Comment", ctypes.c_wchar_p),
        ("LastWritten", _FILETIME), ("CredentialBlobSize", ctypes.c_uint32),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", ctypes.c_uint32), ("AttributeCount", ctypes.c_uint32),
        ("Attributes", ctypes.c_void_p), ("TargetAlias", ctypes.c_wchar_p),
        ("UserName", ctypes.c_wchar_p),
    ]


class WindowsPasswordVault:
    """Read/write/delete only VRC Eye's own fixed generic credential."""
    available = True
    reason = "Passwords are saved in Windows Credential Manager for your Windows user on this computer."

    def __init__(self, *, _api=None, _last_error=None):
        if _api is None:
            if sys.platform != "win32":
                raise LoginStorageError("Password remembering currently requires Windows Credential Manager.")
            try:
                _api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
            except OSError:
                raise LoginStorageError("Windows Credential Manager is unavailable. You can still sign in without saving the password.") from None
        self._api = _api
        self._last_error = _last_error or getattr(ctypes, "get_last_error", lambda: 0)
        pointer = ctypes.POINTER(_CREDENTIALW)
        _api.CredReadW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.POINTER(pointer)]
        _api.CredReadW.restype = ctypes.c_int32
        _api.CredWriteW.argtypes = [pointer, ctypes.c_uint32]
        _api.CredWriteW.restype = ctypes.c_int32
        _api.CredDeleteW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32]
        _api.CredDeleteW.restype = ctypes.c_int32
        _api.CredFree.argtypes = [ctypes.c_void_p]
        _api.CredFree.restype = None

    def read(self) -> SavedPassword | None:
        pointer = ctypes.POINTER(_CREDENTIALW)()
        if not self._api.CredReadW(CREDENTIAL_TARGET, CRED_TYPE_GENERIC, 0, ctypes.byref(pointer)):
            if self._last_error() == ERROR_NOT_FOUND:
                return None
            raise LoginStorageError("Windows could not unlock the saved password. Enter it manually or try again after unlocking your Windows session.")
        if not pointer:
            raise LoginStorageError("Windows returned an unreadable saved password entry.")
        size = 0
        blob = None
        try:
            credential = pointer.contents
            size = int(credential.CredentialBlobSize)
            blob = credential.CredentialBlob
            if credential.Type != CRED_TYPE_GENERIC or not blob or not 1 <= size <= MAX_CREDENTIAL_BYTES:
                raise LoginStorageError("The saved password entry is invalid. Use Forget saved sign-in to remove it.")
            return SavedPassword.decode(ctypes.string_at(blob, size))
        finally:
            if blob and 0 < size <= MAX_CREDENTIAL_BYTES:
                ctypes.memset(blob, 0, size)
            self._api.CredFree(pointer)

    def write(self, value: SavedPassword) -> None:
        raw = value.encode()
        buffer = ctypes.create_string_buffer(raw, len(raw))
        credential = _CREDENTIALW()
        credential.Type = CRED_TYPE_GENERIC
        credential.TargetName = CREDENTIAL_TARGET
        credential.Comment = "VRC Eye opt-in VRChat sign-in password"
        # Never put the VRChat username in this visible metadata field. Username
        # remembering is an independent setting, including password-only mode.
        credential.UserName = "VRC Eye"
        credential.Persist = CRED_PERSIST_LOCAL_MACHINE
        credential.CredentialBlobSize = len(raw)
        credential.CredentialBlob = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        try:
            if not self._api.CredWriteW(ctypes.byref(credential), 0):
                raise LoginStorageError("Windows could not save the password. Your sign-in is unaffected; no plaintext copy was created.")
        finally:
            ctypes.memset(buffer, 0, len(raw))

    def delete(self) -> None:
        if not self._api.CredDeleteW(CREDENTIAL_TARGET, CRED_TYPE_GENERIC, 0):
            if self._last_error() != ERROR_NOT_FOUND:
                raise LoginStorageError("Windows could not remove the saved password. It may still be stored; try Forget saved sign-in again.")


class _UnavailableVault:
    available = False

    def __init__(self, reason):
        self.reason = reason

    def read(self):
        return None

    def write(self, value):
        raise LoginStorageError(self.reason)

    def delete(self):
        # No claim of successful deletion if this machine might have a locked vault.
        if sys.platform == "win32":
            raise LoginStorageError(self.reason)


class LoginStore:
    """Independent remembered values. The caller saves only after full sign-in."""
    def __init__(self, path: Path | None = None, *, vault=None, enabled=True):
        self.path = Path(path) if path is not None else settings_path().with_name("login-preferences.json")
        self.enabled = bool(enabled)
        if not self.enabled:
            vault = _UnavailableVault("Remembered sign-in is not read or changed in Demo or Safe mode.")
        elif vault is None:
            try:
                vault = WindowsPasswordVault()
            except LoginStorageError as error:
                vault = _UnavailableVault(str(error))
        self.vault = vault

    @property
    def password_available(self):
        return self.enabled and self.vault.available

    def load_username(self) -> str:
        if not self.enabled:
            return ""
        try:
            with self.path.open("rb") as stream:
                raw = stream.read(32769)
            if len(raw) > 32768:
                raise ValueError
            value = json.loads(raw.decode("utf-8"))
            if (not isinstance(value, dict) or set(value) != {"schema", "username"}
                    or type(value["schema"]) is not int or value["schema"] != 1
                    or not isinstance(value["username"], str) or not value["username"].strip()
                    or len(value["username"].encode("utf-8")) > MAX_USERNAME_BYTES):
                raise ValueError
            return value["username"]
        except FileNotFoundError:
            return ""
        except (OSError, ValueError, UnicodeError, RecursionError):
            raise LoginStorageError("The remembered username could not be read. Enter it manually or use Forget saved sign-in.") from None

    def save_username(self, username: str) -> None:
        if not self.enabled:
            raise LoginStorageError("Remembering is disabled in Demo or Safe mode.")
        if not isinstance(username, str) or not username.strip() or len(username.strip().encode("utf-8")) > MAX_USERNAME_BYTES:
            raise LoginStorageError("This username could not be saved.")
        temporary = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.path.parent,
                                             prefix=".login-", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                json.dump({"schema": 1, "username": username.strip()}, stream, ensure_ascii=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            temporary = None
        except (OSError, UnicodeError):
            raise LoginStorageError("The username could not be saved. Your sign-in is unaffected.") from None
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass

    def forget_username(self) -> None:
        if not self.enabled:
            raise LoginStorageError("Saved sign-in is not changed in Demo or Safe mode.")
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            raise LoginStorageError("The saved username could not be removed. It may still be stored.") from None

    def load_password(self) -> SavedPassword | None:
        return self.vault.read() if self.enabled else None

    def save_password(self, username: str, password: str) -> SavedPassword:
        if not self.enabled:
            raise LoginStorageError("Remembering is disabled in Demo or Safe mode.")
        value = SavedPassword.create(username, password)
        self.vault.write(value)
        return value

    def forget_password(self) -> None:
        if not self.enabled:
            raise LoginStorageError("Saved sign-in is not changed in Demo or Safe mode.")
        self.vault.delete()
