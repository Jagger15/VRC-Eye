# ARC-11: reviewed renderer and model-import setting transfers

Status: **partial, unreleased**. The Unity workflow is implemented as editor
source with native behavior tests supplied, but Unity compilation, import and
EditMode execution have not run in this environment. The desktop observation
reader has executable portable tests. No executable, installer or release identity
change is included. The ARC-10 checkpoint remains the preserved baseline.

## Unity workflow

Open **VRC Eye → Mesh and Importer Setting Transfers** in Unity 2022.3. Select
authorized source and destination assets. All setting selections begin off;
choose each value individually, inspect the destination-to-source comparison
and impact note, then prepare and confirm the exact review. Canceling the review,
closing the window or changing its inputs invalidates its plan. Plans expire
after five minutes and cannot be reused.

**Renderer mode** requires two saved `.prefab` roots under `Assets` and existing
renderers of exactly the same supported type: MeshRenderer or SkinnedMeshRenderer.
The copy is made from the destination prefab. It is unpacked from nested/variant
links and receives only selected settings. Mesh geometry, skin bones, bounds and
all unselected serialized values remain the destination's. Source names are not
used to guess reference mappings. Unique object names and unambiguous component
types are required for save/reload correspondence; missing scripts stop transfer.

| Setting group | Individually selectable values |
| --- | --- |
| Both renderer types | enabled, shadow casting, shadow reception, light probes, reflection probes, dynamic occlusion, motion-vector mode |
| Skinned renderer only | skin quality, offscreen updates, skinned motion vectors |
| Hierarchy references | probe anchor and light-probe proxy override, explicitly selected from destination objects or explicitly cleared |
| Material references | individual slots, each mapped to a saved Material under Assets or explicitly cleared; equal source/destination slot counts required |

A material-slot selection does not automatically assign the donor's material.
The review records the donor reference and the user's chosen target. Internal
references resolve to objects in the new clone by reviewed object identity;
external material references use asset GUID/local IDs. There is no mesh, bone,
controller, bounds, arbitrary component or script-property transfer in this mode.

**ModelImporter mode** requires saved FBX model roots under `Assets`, both using
Unity's ModelImporter. Mesh assets and prefabs without ModelImporter are refused.
The destination's FBX bytes are copied into a fresh folder; selected policies are
applied to that copy's importer and it is explicitly reimported. Both originals,
including their metadata, are protected by evidence checks. The copied FBX bytes
must remain identical to the destination source throughout the operation.

| Policy group | Individually selectable values |
| --- | --- |
| Readability and compression | CPU readability, mesh compression |
| Ordering and topology | polygon optimization, vertex optimization, vertex welding, quad retention, index format |
| Normal and tangent generation | normal import mode, tangent mode, normal weighting, smoothing angle |
| Hierarchy and deformation data | preserve hierarchy, optimize GameObjects, import blendshapes |

Readability, compression, both ordering optimizations and hierarchy policies have
explicit individual-review notices. No combined preset enables them implicitly.
Lossy settings can change topology or deformation and require inspection of the
result. The workflow validates Unity 2022.3 serialized fields and typed values;
unselected serialized policies are compared against the original destination.
Related settings automatically changed by a setter/reimport are rejected unless
they were individually selected. The shared mesh-optimization field is also
checked through both public policy values, preserving the unselected option.

The source importer's avatar, clip definitions, material remaps, scale, axis
conversion, SDK settings and other policies are not transferred. Existing
destination references remain exact; no material-name search is invoked.
Legacy external-material generation is rejected. Embedded-material import or
disabled material import is supported by the initial contract. Other model file
formats and importer versions remain outside this subset.

## Output and evidence

Every operation creates a fresh destination under `Assets/VRC Eye Repairs`, with
the copied prefab/FBX and `setting-transfer.json`. It never assigns that copy to a
scene, avatar or existing renderer. Serialized values and object references are
verified after prefab save/reload or model reimport. Incompatible types,
unsupported settings, missing explicit mappings and unexpected schema changes
stop the operation.

The report lists typed before/after values and ordered inventories for vertex
stream layouts/data evidence, submesh topology/index order, material slots, bone
references and hierarchy. Matching counts are insufficient: changed ordered
entries and data digests remain visible. A mesh without CPU readability has
explicitly unavailable stream/index digests; importer readability is never
silently enabled to collect diagnostics. Internal imported sub-assets use local
file IDs within the copy; external assets use GUID/local-ID identities.

ARC-19 records durable review intent, source/dependency fingerprints and before/
after file-write phases. Source and destination evidence includes loaded objects,
saved importer settings, dependency bytes and metadata, plus applicable project
context. Asset and dependency budgets apply (64 MiB per evidence file, 128 MiB
aggregate, up to 512 dependency assets; inventory limits include 500,000 mesh
vertices, two million indices and 10,000 entries per category). An unsupported
or unavailable dependency stops evidence capture.

`setting-transfer.json` identifies its Repair Copy History receipt. It records
an **observed copy**, not a final transaction attestation: a later callback can
still interrupt the receipt after the report is written. Check the receipt's
completed/interrupted phase and current hashes in Unity. Interrupted outputs
remain for inspection and are never silently resumed. Existing import/editor
callbacks can run; this workflow is not a sandbox for an untrusted Unity project.
Source mutations caused by those callbacks are detected, not automatically undone.

## Desktop report inspection

In **Avatar Library → Recovery**, choose **Inspect Unity setting-transfer report…**.
This reads a selected v1 JSON observation, validates its renderer/importer type,
allowlisted settings, typed values, explicit reference identities, version and
size limits, and recomputes ordered inventory differences. Local paths and
detailed inventory entries follow **Show local paths**. Privacy/account, avatar,
draft or display-scope changes invalidate pending results.

Reading a report makes no Unity changes, starts no importer and replays no
operation. The JSON is editable: its claimed editor version, source fingerprint
and execution history are not authenticated by the desktop reader. Inspect the
corresponding native receipt and source assets for current applicability.

## Validation and remaining gates

Portable tests cover every typed setting family, explicit references, reordering
with unchanged counts, malformed/duplicate/oversized data, unsupported versions,
file-link rejection, cancellation, path visibility and stale UI callbacks.
Native tests in `EyeSettingTransferTests.cs` cover copied scalar values,
unselected values, mapped materials and clone anchors, explicit nulls, canceled
plans, mutated drafts, incompatible types, changed source bytes, bone ordering,
real FBX reimport, source/meta preservation and import callback interference.

The native FBX fixture is an unmodified, MIT-licensed upstream ufbx Blender test
asset stored as inert `.fbx.bytes`; its provenance and license are alongside it.
The test copies it into its own temporary Assets folder before importing it.
It is not a creator-owned VRChat avatar qualification fixture.

**Thirteen new Unity EditMode methods are supplied but unrun.** C# syntax parsing
does not establish compilation or Unity API/serialization compatibility. Run the
entire Toolkit suite plus these methods in a disposable authorized Unity 2022.3
project, then qualify real creator models, nested/variant prefabs, material and
skin configurations, target-platform rendering, and reimport callback behavior.
Graphical desktop acceptance also remains open. ARC-11 stays partial until these
gates are met. No FPS improvement or full deformation equivalence is claimed.

## Primary implementation references

- [Unity 2022.3 ModelImporter](https://docs.unity.cn/2022.3/Documentation/ScriptReference/ModelImporter.html)
- [Unity 2022.3 SaveAndReimport](https://docs.unity.cn/2022.3/Documentation/ScriptReference/AssetImporter.SaveAndReimport.html)
- [Unity 2022.3 ModelImporter bindings](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Modules/AssetPipelineEditor/Public/ModelImporting/ModelImporter.bindings.cs)
- [Unity 2022.3 model importer inspector](https://github.com/Unity-Technologies/UnityCsReference/blob/2022.3/Modules/AssetPipelineEditor/ImportSettings/ModelImporterModelEditor.cs)

Documentation establishes the intended version contract; native qualification
remains a separate requirement.
