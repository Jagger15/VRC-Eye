"""ARC-12: bounded influence-reduction trials on immutable decoded skin data.

Reports are observations, never Unity dependency proof or writable model assets.
"""
from dataclasses import dataclass,replace,asdict
import json
import math
import time
from avatar_scene import integer,vector
from avatar_scene_deform import positions,influences
from avatar_animation import world_at
from avatar_bounds import times
from avatar_library_files import check_cancel

MAX_VERTEX_VISITS=4_000_000
LIMITS=('Finite samples do not establish between-sample or runtime equivalence. '
        'Source units are not assumed to be metres. Normals, tangents, shaders, '
        'controllers and procedural deformation are unverified. Zero-weight bones '
        'are not proven unused. No bone deletion, renderer merging, asset assignment '
        'or runtime speed claim follows from this trial. Use the Unity Toolkit '
        'Skin Influence Copies workflow for separately reviewed mesh assets.')


@dataclass(frozen=True)
class ErrorSample:
    pose:str
    seconds:float
    vertices:int
    maximum:float
    rms:float
    worst_part:int
    worst_vertex:int


@dataclass(frozen=True)
class Trial:
    source_sha256:str
    node:int
    influence_limit:int
    tolerance:float
    vertices:int
    influences_before:int
    influences_after:int
    changed_vertices:int
    zero_weight_bones:tuple
    samples:tuple
    maximum:float
    rms:float
    within_tolerance:bool


def reduce_rows(joints,weights,limit):
    """Stable ties use bone index; output retains the four-slot wire contract."""
    integer(limit,1,4)
    output_j=[];output_w=[]
    for js,ws in zip(joints,weights):
        selected=sorted(((w,j) for j,w in zip(js,ws) if w>0),key=lambda x:(-x[0],x[1]))[:limit]
        total=math.fsum(w for w,j in selected)
        if total<=0:raise ValueError('Every vertex requires a positive influence.')
        output_j.append(tuple(j for w,j in selected)+(0,)*(4-len(selected)))
        output_w.append(tuple(w/total for w,j in selected)+(0.,)*(4-len(selected)))
    return tuple(output_j),tuple(output_w)


def inspect(scene,node,*,limit=2,tolerance=.001,clip=None,start=None,end=None,count=16,stop=None,progress=None):
    check_cancel(stop);integer(limit,1,4);integer(node,0,511)
    tolerance=vector([tolerance],1)[0]
    if not 0<=tolerance<=1000:raise ValueError('Choose a maximum error tolerance from 0 to 1,000 source units.')
    selected=[(i,p) for i,p in enumerate(scene.parts) if p.node==node]
    if not selected or any(p.rig is None or p.rig.skin<0 for i,p in selected):
        raise ValueError('Select a mesh node with decoded editable skin influences. Baked FBX frames are not a skin-editing source.')
    schedule=[('Imported pose',0.,None)]
    if clip is not None:
        if scene.animations is None:raise ValueError('No decoded animation is available.')
        c=scene.animations.clips[integer(clip,0,len(scene.animations.clips)-1)]
        if c.reason:raise ValueError(c.reason)
        if c.frames:raise ValueError('Baked animation frames cannot measure edited skin influences; choose decoded transform/morph tracks.')
        start=c.start if start is None else start;end=c.end if end is None else end
        ts=times(start,end,count)
        if start<c.start or end>c.end:raise ValueError('Select sample times within the decoded clip range.')
        schedule.extend((c.name,t,c) for t in ts)
    vertices=sum(len(p.vertices) for i,p in selected)
    if vertices*len(schedule)*2>MAX_VERTEX_VISITS:raise ValueError('Influence trial exceeds four million vertex visits; reduce the sample scope.')
    deadline=time.monotonic()+15;reduced=[];before=after=changed=0;unused=[]
    for part_index,p in selected:
        r=p.rig;s=scene.skins[r.skin]
        js,ws=influences(r.joints,r.weights,len(r.base),s)
        out_j,out_w=reduce_rows(js,ws,limit);reduced.append((part_index,r,replace(r,joints=out_j,weights=out_w)))
        before+=sum(w>0 for row in ws for w in row);after+=sum(w>0 for row in out_w for w in row)
        changed+=sum(sum(w>0 for w in row)>limit for row in ws)
    # Whole decoded scene, not just the selected renderer. Still no dynamic proof.
    for skin_index in sorted({p.rig.skin for i,p in selected}):
        active={j for p in scene.parts if p.rig and p.rig.skin==skin_index for js,ws in zip(p.rig.joints,p.rig.weights) for j,w in zip(js,ws) if w>0}
        unused.extend((skin_index,j,n) for j,n in enumerate(scene.skins[skin_index].joints) if j not in active)
    samples=[];sum_squared=0.;maximum=0.
    for label,at,c in schedule:
        check_cancel(stop)
        if time.monotonic()>deadline:raise ValueError('Influence trial exceeded 15 seconds; reduce sample scope.')
        world,morph=world_at(scene,c,at) if c else ({n.index:n.matrix for n in scene.nodes},{})
        squared=0.;peak=-1.;worst_part=worst_vertex=0
        for part_index,original,candidate in reduced:
            a=positions(original,scene.skins,world,morph.get(node),stop=stop,deadline=deadline)
            b=positions(candidate,scene.skins,world,morph.get(node),stop=stop,deadline=deadline)
            for i,(x,y) in enumerate(zip(a,b)):
                if i%256==0:check_cancel(stop)
                error=math.fsum((u-v)**2 for u,v in zip(x,y));squared+=error
                if error>peak:peak=error;worst_part=part_index;worst_vertex=i
        maximum=max(maximum,math.sqrt(peak));sum_squared+=squared
        samples.append(ErrorSample(label,at,vertices,math.sqrt(peak),math.sqrt(squared/vertices),worst_part,worst_vertex))
        if progress:progress(len(samples),len(schedule))
    check_cancel(stop)
    if time.monotonic()>deadline:raise ValueError('Influence trial exceeded 15 seconds; reduce sample scope.')
    return Trial(scene.sha256,node,limit,tolerance,vertices,before,after,changed,tuple(unused),tuple(samples),maximum,math.sqrt(sum_squared/(vertices*len(samples))),maximum<=tolerance)


def document(report):
    return json.dumps(dict(schema='vrc-eye-skin-trial-1',space='source world coordinates',
                           asset_created=False,dependency_proof=False,runtime_profiled=False,
                           limits=LIMITS,**asdict(report)),indent=2,allow_nan=False)+'\n'


def describe(report):
    return (f'{report.vertices:,} vertices; influences {report.influences_before:,} → {report.influences_after:,}; '
            f'{report.changed_vertices:,} vertices reduced.\n{len(report.samples)} poses; maximum error {report.maximum:.9g}; '
            f'RMS {report.rms:.9g} source units. Maximum ≤ {report.tolerance:.9g}: {report.within_tolerance}.\n'
            f'{len(report.zero_weight_bones)} bone slots have no decoded weights (not deletion candidates).\n'+LIMITS)


def export(report,path):
    from pathlib import Path
    from creator_projects import assert_no_links
    path=Path(path).absolute()
    if path.suffix.lower()!='.json':raise ValueError('Use a new .json observation file.')
    assert_no_links(path)
    with path.open('x',encoding='utf-8') as stream:stream.write(document(report))
