"""Local world-creator test records and evidence-based comparisons.

Nothing in this module starts a provider, sends a command, contacts VRChat or
publishes a world. A worksheet describes a test; recording a result is a separate
human action. Optional observations must retain their original provenance.
"""
from copy import deepcopy
import math
import re
import time

SCHEMA = 1
STEP_STATUSES = ('Not started', 'In progress', 'Passed', 'Failed', 'Blocked',
                 'Not applicable', 'Needs verification')
ENVIRONMENTS = ('Real client', 'Build & Test', 'ClientSim', 'Editor')
CONDITION_STATES = ('Requested but unverified', 'Manually confirmed', 'Verified', 'Unavailable')
ISSUE_STATES = ('Investigation', 'Open', 'Fix implemented', 'Verified fixed', 'Closed')
COMPARISON_CONDITIONS = ('platform', 'graphics', 'avatars', 'features', 'route',
                         'hardware_class', 'logging', 'overlay', 'measurement_source')


def _sheet(label, names, help_text):
    return {'label': label, 'fields': [(name, name.replace('_', ' ').capitalize(),
                                      'multiline' if name in ('notes', 'steps', 'evidence', 'limitations', 'expected', 'observed', 'recovery', 'preparation', 'happened', 'doing', 'credits', 'known_limitations', 'reason') else 'text')
                                     for name in names], 'help': help_text}


WORKSHEETS = {
    'note': _sheet('Notes and TODOs', ('title', 'note_type', 'build_id', 'run_id', 'subsystem', 'platform', 'notes'), 'Private design notes, investigations, polish items and release reminders remain local.'),
    'recipe': _sheet('Reproduction recipe', ('title', 'build_id', 'preparation', 'steps', 'expected', 'expected_failure', 'timeout_seconds', 'stop_condition', 'branches', 'evidence'), 'One ordered instruction per line. Running a recipe creates a checklist snapshot; instructions never execute controls.'),
    'profile': _sheet('Test profile', ('title', 'checklist_id') + COMPARISON_CONDITIONS + ('launch_requirements', 'notes'), 'Requested settings are unverified until confirmed in a run. Launch-time requirements may need a new client session.'),
    'route': _sheet('Repeatable route', ('title', 'build_id', 'zones', 'viewpoint', 'input_mode', 'expected', 'evidence'), 'Name zones in route order. Visiting one area does not establish coverage elsewhere.'),
    'zone': _sheet('Named zone and coverage', ('title', 'build_id', 'route_id', 'coverage', 'source', 'evidence'), 'Manual zones need no coordinates. Record repeat visits and selected evidence; never infer other participants’ movement.'),
    'accessibility': _sheet('Accessibility audit', ('title', 'interaction', 'condition', 'input_mode', 'platform', 'expected', 'observed', 'status', 'evidence'), 'Record concrete play conditions without asking for a diagnosis. Human evaluation remains necessary.'),
    'media': _sheet('Media and dependency diagnostics', ('title', 'dependency', 'environment', 'platform', 'state', 'restrictions', 'expected', 'recovery', 'evidence'), 'States are not requested, requested, blocked, loading, failed, ready or unknown. Keep private URLs out of shared evidence.'),
    'persistence': _sheet('Persistence test lab', ('title', 'environment', 'build_id', 'expected_schema', 'case', 'restoration', 'migration', 'expected', 'observed', 'evidence'), 'Uploaded-world, Build & Test and ClientSim storage are distinct. Use isolated data; record presence/types rather than sensitive values.'),
    'network_budget': _sheet('World network budget', ('title', 'build_id', 'subsystem', 'metric', 'unit', 'source', 'budget', 'window_seconds', 'observed', 'recovery', 'evidence'), 'Creator budgets are separate from documented constraints. Peer latency, world synchronization and helper command time are distinct.'),
    'feedback': _sheet('Tester feedback and triage', ('title', 'run_id', 'step_id', 'bookmark_id', 'happened', 'expected', 'doing', 'repeated', 'triage_state', 'related_issue_id'), 'Local until an explicit selected-share preview. Similar reports are not confirmed duplicates.'),
    'dependency': _sheet('Assets, dependencies and credits', ('title', 'build_id', 'version', 'owner', 'documentation', 'provenance', 'credits', 'affected_tests', 'notes'), 'Creator-supplied project information only. Missing provenance or credits require review; this is not legal clearance.'),
    'localization': _sheet('Localization and onboarding', ('title', 'language', 'text_id', 'translation_state', 'review_state', 'context_test_state', 'host_assistance', 'observed', 'evidence'), 'Translated, reviewed and tested-in-context are separate. Record host assistance during uncoached first-time tests.'),
    'failure_test': _sheet('Controlled failure scenario', ('title', 'boundary', 'preparation', 'expected', 'recovery', 'status', 'evidence'), 'Only your own adapters or deliberately configured private-world switches. No unrelated participant traffic manipulation.'),
    'accepted_regression': _sheet('Accepted regression decision', ('title', 'baseline_run_id', 'candidate_run_id', 'affected_target', 'reason', 'limitations'), 'Preserve the comparison and explicit tradeoff; acceptance does not hide a measured change.'),
    'build': _sheet('Build and upload history', ('title', 'release_label', 'local_build_id', 'platform', 'project_revision', 'artifact_status', 'revision_status', 'upload_status', 'client_test_status', 'interaction_status', 'parity_status', 'source', 'evidence'), 'Local build, release label, published world and upload evidence are separate. Latest metadata does not identify a loaded build.'),
    'release_requirement': _sheet('Selected release requirement', ('title', 'requirement_type', 'target_platform', 'build_id', 'environment', 'run_id', 'step_id', 'issue_id', 'status', 'evidence', 'known_limitations'), 'Advisory creator criteria. Review and publication are separate; an unmet requirement is not VRChat rejection.'),
    'health_assertion': _sheet('Declared health assertion', ('title', 'build_id', 'subsystem', 'scope', 'timing', 'grace_seconds', 'severity', 'cost_budget', 'expected', 'evidence'), 'A declaration is not an observed pass. Optional helper results retain scope, evaluation timing and cost.'),
    'coordination': _sheet('Playtest roles and coverage', ('title', 'build_id', 'run_id', 'roles', 'selected_categories', 'sources_expected', 'sources_reporting', 'limitations'), 'Roles confer no VRChat privilege. Sharing uses the existing VRC Eye peer service and explicit selected records.')}


def _step(key, title, preparation, expected, evidence, **extra):
    return dict(id=key, title=title, preparation=preparation, expected=expected,
                evidence_hint=evidence, timeout_seconds=None, stop_condition='',
                optional=False, expected_failure=False, **extra)


def _template(title, purpose, steps, **extra):
    return dict(schema=SCHEMA, version=1, title=title, purpose=purpose, steps=steps,
                limitations='Instructions require a recorded result. Missing evidence is untested.',
                **extra)


TEMPLATES = {
    'smoke': _template('Normal-user smoke test', 'Check essential interactions in the intended client.', [
        _step('arrival', 'Arrival and initialization', 'Join through the normal entry route.', 'The intended spawn and essential instructions are available.', 'Record environment, observed initialization and any missing evidence.'),
        _step('interaction', 'Essential interaction', 'List the essential interaction and its starting state.', 'Complete it through normal user input.', 'Name the interaction and observed result.'),
        _step('recovery', 'Recover from an ordinary mistake', 'Select a reversible ordinary user action.', 'The participant can return to a usable state.', 'Record the action and recovery; do not erase saved progress.')]),
    'late_join': _template('Late-join state convergence', 'Test reconstructible state after arrival.', [
        _step('prepare', 'Prepare expected state', 'Choose declared door, round or environment states; change them before arrival.', 'Expected values and build are recorded.', 'Record creator-declared values and their source.'),
        _step('join', 'Late participant joins', 'Ask an opted-in participant to join normally.', 'Arrival is observed separately from initially present participants.', 'Record participant confirmation or a selected arrival observation.'),
        _step('converge', 'Check after settling', 'Wait the declared settling period without repeating the original action.', 'The late participant observes the declared current state.', 'Record each selected state as matched, mismatched or unavailable.')]),
    'ownership': _template('Ownership, master and suspension recovery', 'Find dependencies on unavailable participants.', [
        _step('owner', 'Object owner departs', 'Choose a test object; have its owner leave normally.', 'Its declared recovery behavior completes without the original owner.', 'Record selected ownership transitions and observed recovery.'),
        _step('master', 'Master changes', 'Use a private test session and normal participant departure.', 'Essential systems remain usable after the change.', 'Record behavior; master status is not permission.'),
        _step('resume', 'Suspend and resume', 'Have a consenting participant suspend and resume their client normally.', 'The declared state recovers after resumption.', 'Record time, state and unavailable observations; never manipulate traffic.')]),
    'persistence': _template('Persistence and schema migration', 'Keep uploaded, local and simulated storage environments distinct.', [
        _step('fresh', 'New participant or isolated test data', 'Record storage environment and expected schema; use isolated test data.', 'Initialization completes with expected key types.', 'Record presence and types, excluding sensitive saved values.'),
        _step('return', 'Returning participant', 'Record a non-sensitive test state, leave and return through the intended workflow.', 'Restoration completes and the expected state is verified.', 'Record storage environment, restoration completion and selected evidence.'),
        _step('migration', 'Migration or missing optional value', 'Use an explicit private test build or controlled test fixture.', 'The declared migration handles the previous schema or missing value.', 'Record expected schema, migration route and final verification.'),
        _step('reset', 'Explicit isolated-data reset', 'Confirm exactly which isolated data the declared reset changes.', 'Only the declared test data changes; other progress remains untouched.', 'Record actual scope and verified final state; blocked is valid.')]),
    'accessibility': _template('Accessibility and interaction audit', 'Evaluate actual interaction conditions without diagnoses.', [
        _step('reach', 'Seated and standing reach', 'Identify essential controls; try seated reduced-reach and standing conditions.', 'Essential interactions can be completed under the selected conditions.', 'Record condition and concrete interaction result.'),
        _step('input', 'Input and handedness', 'Select desktop/controller and left/right conditions to test.', 'Required controls work with the selected input.', 'Record tested combinations; others remain untested.'),
        _step('signals', 'Readable and redundant signals', 'Review essential text, non-color signals, subtitles or visual equivalents.', 'Essential information is understandable in the selected condition.', 'Record human evaluation and the affected control or signal.')]),
    'spawn': _template('Spawn, collision and locomotion route', 'Follow a repeatable manually selected route.', [
        _step('spawn', 'Spawn and respawn', 'List intended spawn points and selected input mode.', 'Arrival and respawn reach usable locations with exits.', 'Record each visited spawn; unvisited spawns remain untested.'),
        _step('route', 'Collision and movement route', 'Name zones and checkpoints; move through them normally.', 'No unintended trap, gap or blocked exit occurs on the route.', 'Record visited zones and available evidence; no inferred coordinates.'),
        _step('station', 'Stations and moving platforms', 'Use declared stations and platforms with the intended input.', 'Enter, move and exit through expected controls.', 'Record exact checkpoint, input and observed exit result.')]),
    'rendering': _template('Lighting, shader and reflection comparison', 'Change one declared rendering condition.', [
        _step('reference', 'Reference appearance', 'Fix viewpoint, build, platform, avatars and graphics settings.', 'Reference appearance and available measurements are recorded.', 'Record preset and selected image or metric evidence.'),
        _step('variant', 'Comparison preset', 'Change one declared lighting/reflection/effect setting.', 'The intended visual difference can be assessed.', 'Separate visual difference, unexpected appearance and measured performance change.'),
        _step('repeat', 'Repeat the comparison', 'Return to the reference and repeat the same route.', 'The finding repeats under comparable conditions, or remains uncertain.', 'Record repeats and unavailable measurements; no claim about all draw calls.')]),
    'media': _template('Media and external dependency recovery', 'Test actual client behavior and graceful unavailability.', [
        _step('normal', 'Declared dependency loads', 'List the selected media/resource; retain default URL restrictions.', 'The source reports ready or an honest unavailable state.', 'Record requested/loading/failed/ready only where observed; redact private URLs.'),
        _step('unavailable', 'Optional dependency unavailable', 'Use a controlled fixture or creator-exposed private test switch.', 'The world remains usable with the selected optional resource absent.', 'Record recovery and timeout; never disrupt unrelated traffic.'),
        _step('client', 'Intended client confirmation', 'Repeat in the intended actual client and platform.', 'The selected dependency behavior is confirmed there.', 'An editor preview does not satisfy this client result.')]),
    'parity': _template('Cross-platform semantic parity', 'Compare declared shared-state contracts and actual interactions.', [
        _step('manifest', 'Compare supplied manifests', 'Select intended builds and creator-provided manifests.', 'Network IDs, controls, assertions and persistence contracts agree where required.', 'Record missing declarations, mismatches and intentional differences.'),
        _step('interaction', 'Shared interaction across targets', 'Use opted-in participants on the intended platforms.', 'The declared interaction yields compatible shared state.', 'Record each tested platform and observed result; a build badge is insufficient.'),
        _step('exceptions', 'Review intentional differences', 'Review target-specific visual omissions separately.', 'Every accepted difference has a reason and affected scope.', 'Record the decision; do not label every mismatch a world-wide failure.')]),
    'localization': _template('Localization and first-time-user testing', 'Separate translation review from actual usability.', [
        _step('text', 'Visible text in context', 'Select language and text identifiers.', 'Reviewed text fits and remains readable in the actual interface.', 'Record translated, reviewed and tested-in-context separately.'),
        _step('arrival', 'Uncoached first arrival', 'Give the participant only instructions ordinary visitors receive.', 'They find essential controls, objective and accessibility settings.', 'Record completion and any host assistance instead of silently counting a pass.'),
        _step('recovery', 'First-time recovery', 'Ask for a safe ordinary action that can be corrected.', 'The participant can recognize and recover from the mistake.', 'Record where help was needed and affected visible text.')]),
    'soak': _template('Long-session stability', 'Observe bounded evidence and repeated behavior over time.', [
        _step('envelope', 'Record test envelope', 'Choose duration, sampling/retention limits and diagnostic overhead.', 'Build, conditions and sources are recorded before the run.', 'Record process-memory scope, unavailable metrics and planned checkpoints.'),
        _step('repeat', 'Repeat the same interaction', 'Use the same route or action at recorded intervals.', 'Declared state remains valid and selected queues recover.', 'Record measured drift, repeated errors and dropped samples without assigning a cause.'),
        _step('finish', 'Review end of observation', 'Compare early and late windows with the same conditions.', 'Available evidence supports a bounded stability finding.', 'Growth alone is not a confirmed leak; an unexpected exit alone is not a crash cause.')]),
    'resilience': _template('Controlled failure and recovery', 'Test only own adapters or deliberate private-build switches.', [
        _step('disconnect', 'Optional companion or peer disconnect', 'Stop your own selected adapter through normal controls.', 'Local notes remain available and no content is sent on reconnect without review.', 'Record observed recovery and retained local records.'),
        _step('timeout', 'Helper unavailable or late', 'Use the declared private fixture or disable your own helper route.', 'The request times out honestly without claiming application or unsafe retry.', 'Record request lifecycle and expected recovery.'),
        _step('recover', 'Restore the optional source', 'Reconnect through normal explicit controls.', 'The source becomes available without losing local evidence.', 'Record manual versus automatic recovery and remaining limitations.')]),
    'networking': _template('World network budget test', 'Assess declared world telemetry, independently of peer latency.', [
        _step('baseline', 'Record declared network baseline', 'Select instrumented subsystems and creator budgets.', 'Available queue/serialization observations retain source and unit.', 'Record coverage; unavailable statistics are not zero.'),
        _step('action', 'Perform selected test action', 'Keep platform, population and declared world configuration comparable.', 'Queues recover within the selected budget or an observed mismatch is recorded.', 'Record selected action, available throughput/queue samples and recovery window.'),
        _step('repeat', 'Repeat under the selected load', 'Repeat using the same declared test envelope.', 'A difference is reproducible or explicitly remains uncertain.', 'Keep VRC Eye peer latency, Udon synchronization and helper completion separate.')])}


def templates():
    """Editable copies; changing a returned template never changes future runs."""
    return deepcopy(TEMPLATES)


def _text(value, name, maximum=16000, empty=True):
    if not isinstance(value, str) or len(value) > maximum or '\x00' in value:
        raise ValueError('Invalid ' + name + '.')
    if not empty and not value.strip():
        raise ValueError(name.capitalize() + ' is required.')
    return value


def _number(value, name, minimum=0, maximum=1e12):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError('Invalid ' + name + '.')
    return value


class CreatorWorkflows:
    def __init__(self, store, clock=time.time):
        self.store = store
        self.clock = clock

    def _record(self, record_id, kind=None, world_id=None):
        record = self.store.get(record_id)
        if not record or (kind is not None and record['kind'] != kind):
            raise ValueError('The selected record is unavailable or has the wrong type.')
        if world_id is not None and record['world_id'] != world_id:
            raise ValueError('The selected record belongs to another world.')
        return deepcopy(record)

    def _save(self, record, data):
        return self.store.save(record['kind'], record['world_id'], data, record_id=record['id'])

    def _build(self, world_id, value):
        """Separate a store record UUID from the creator's actual build identifier."""
        if value in (None, ''):
            return None, None, None
        _text(value, 'build identifier', 200, False)
        try:
            record = self.store.get(value)
        except ValueError:
            record = None
        if record is not None:
            if record['kind'] != 'build' or record['world_id'] != world_id:
                raise ValueError('The selected build record belongs to another world or record type.')
        else:
            record = next((row for row in self.store.list(kind='build', world_id=world_id, limit=500)
                           if value in (row['data'].get('build_id'), row['data'].get('local_build_id'))), None)
        if record:
            stable = record['data'].get('build_id') or record['data'].get('local_build_id') or None
            return stable, record['id'], deepcopy(record['data'])
        # A helper manifest or explicit creator selection may supply a build ID
        # before any artifact history exists. It is not an upload assertion.
        return value, None, None

    def _evidence(self, world_id, ids, run_id=None, build_id=None):
        if ids is None:
            return []
        if not isinstance(ids, (list, tuple)) or len(ids) > 100:
            raise ValueError('Select at most 100 evidence records.')
        result = []
        for record_id in ids:
            record = self._record(record_id, world_id=world_id)
            data = record['data']
            if run_id and data.get('run_id') not in (None, '', run_id):
                raise ValueError('Evidence belongs to another test run.')
            if build_id and data.get('build_id') not in (None, '', build_id):
                raise ValueError('Evidence belongs to another build.')
            if record_id not in result:
                result.append(record_id)
        return result

    def install_template(self, world_id, key):
        if key not in TEMPLATES:
            raise ValueError('Unknown creator test template.')
        checklist = self.store.save('checklist', world_id, deepcopy(TEMPLATES[key]))
        profile = self.store.save('profile', world_id, {
            'schema': SCHEMA, 'version': 1, 'title': TEMPLATES[key]['title'],
            'checklist_id': checklist['id'], 'template': key, 'conditions': {},
            'sharing': 'Local only', 'sources': [], 'launch_requirements': '', 'launch_settings': [],
            'limitations': 'Requested conditions require confirmation; enabling a profile starts no source.'})
        return {'checklist': checklist, 'profile': profile}

    def save_worksheet(self, world_id, kind, data, record_id=None):
        """Save explicit local worksheet fields without claiming automated inspection."""
        if kind not in WORKSHEETS or not isinstance(data, dict):
            raise ValueError('Unknown creator worksheet.')
        allowed = {row[0] for row in WORKSHEETS[kind]['fields']}
        if set(data) - allowed:
            raise ValueError('Unsupported worksheet fields.')
        clean = {key: _text(data.get(key, ''), key, 16000 if key in
                 ('notes', 'steps', 'evidence', 'expected', 'observed', 'happened', 'doing', 'credits') else 2000)
                 for key in allowed}
        _text(clean.get('title'), 'title', 200, False)
        for key in ('build_id', 'run_id', 'baseline_run_id', 'candidate_run_id', 'bookmark_id', 'related_issue_id', 'issue_id', 'route_id', 'checklist_id'):
            if clean.get(key):
                if key == 'build_id':
                    clean['build_id'], clean['build_record_id'], _ = self._build(world_id, clean[key])
                    continue
                required_kind = {'build_id': 'build', 'run_id': 'run', 'baseline_run_id': 'run',
                                 'candidate_run_id': 'run', 'bookmark_id': 'bookmark', 'related_issue_id': 'issue',
                                 'route_id': 'route', 'checklist_id': 'checklist', 'issue_id': 'issue'}[key]
                self._record(clean[key], required_kind, world_id)
        if clean.get('environment') and clean['environment'] not in ENVIRONMENTS:
            raise ValueError('Select the actual test environment: ' + ', '.join(ENVIRONMENTS) + '.')
        if 'status' in clean:
            clean['status'] = clean['status'] or 'Not started'
            if clean['status'] not in STEP_STATUSES:
                raise ValueError('Use one of these result states: ' + ', '.join(STEP_STATUSES) + '.')
            if clean['status'] in ('Passed', 'Failed') and not clean.get('evidence', '').strip():
                raise ValueError('A result requires recorded evidence.')
        if kind == 'build':
            states = {
                'artifact_status': ('Unknown', 'Present', 'Missing'),
                'revision_status': ('Unverified', 'Matching', 'Older'),
                'upload_status': ('No record', 'Confirmed', 'Failed'),
                'client_test_status': ('Not tested', 'Tested'),
                'interaction_status': ('Incomplete', 'Passed', 'Failed'),
                'parity_status': ('Untested', 'Verified', 'Mismatch')}
            for key, choices in states.items():
                clean[key] = clean[key] or choices[0]
                if clean[key] not in choices:
                    raise ValueError(key.replace('_', ' ') + ': use ' + ', '.join(choices) + '.')
            if any(clean[k] in ('Present', 'Matching', 'Confirmed', 'Tested', 'Passed', 'Verified') for k in states) and not clean['evidence'].strip():
                raise ValueError('Build, upload and test claims require their recorded evidence.')
            clean['source'] = clean['source'] or 'Creator entry'
            clean['build_id'] = clean['local_build_id'] or None
        if kind == 'profile':
            clean['conditions'] = {key: dict(value=clean[key], status='Requested but unverified', source='profile')
                                   for key in COMPARISON_CONDITIONS if clean[key]}
            clean['version'] = 1
            clean['sources'] = []
            clean['launch_settings'] = [line.strip() for line in clean['launch_requirements'].splitlines() if line.strip()]
        if kind == 'feedback':
            clean['triage_state'] = clean['triage_state'] or 'Unresolved similarity'
            if clean['triage_state'] not in ('Unresolved similarity', 'Related report', 'Confirmed duplicate', 'New report'):
                raise ValueError('Choose New report, Unresolved similarity, Related report or Confirmed duplicate.')
            if clean['triage_state'] in ('Related report', 'Confirmed duplicate') and not clean['related_issue_id']:
                raise ValueError('Choose the issue this feedback relates to.')
        if kind == 'media':
            clean['state'] = clean['state'] or 'Unknown'
            if clean['state'] not in ('Unknown', 'Not requested', 'Requested', 'Blocked', 'Loading', 'Failed', 'Ready'):
                raise ValueError('Record an observed media state or Unknown.')
        if kind == 'release_requirement':
            clean['requirement_type'] = clean['requirement_type'] or 'manual'
            if clean['requirement_type'] not in ('manual', 'step', 'platform_build', 'issue'):
                raise ValueError('Unsupported release requirement type.')
            clean['environment'] = clean['environment'] or 'Real client'
        clean.update(schema=SCHEMA, sharing='Local only', entry_source='Creator worksheet',
                     limitations=clean.get('limitations') or WORKSHEETS[kind]['help'])
        if record_id:
            old = self._record(record_id, kind, world_id)
            if kind == 'profile':
                clean['version'] = old['data'].get('version', 0) + 1
        return self.store.save(kind, world_id, clean, record_id=record_id)

    def start_recipe(self, recipe_id, profile_id=None, build_id=None, environment='Real client'):
        recipe = self._record(recipe_id, 'recipe')
        data = recipe['data']
        instructions = [line.strip() for line in data.get('steps', '').splitlines() if line.strip()]
        if not instructions:
            raise ValueError('Add one ordered manual instruction per line to the recipe.')
        steps = [_step('step-' + str(index + 1), instruction[:200],
                       data.get('preparation', '') if index == 0 else 'Complete the preceding step or record the chosen branch.',
                       data.get('expected', ''), data.get('evidence', 'Record the actual observed result.'))
                 for index, instruction in enumerate(instructions)]
        for step in steps:
            step['stop_condition'] = data.get('stop_condition', '')
            step['branches'] = [line.strip() for line in data.get('branches', '').splitlines() if line.strip()]
            timeout = data.get('timeout_seconds', '')
            if timeout:
                try:
                    step['timeout_seconds'] = float(timeout)
                except (ValueError, TypeError):
                    raise ValueError('Recipe timeout must be a number of seconds.') from None
            step['expected_failure'] = data.get('expected_failure', '').strip().lower() in ('yes', 'true', '1')
        checklist = self.create_checklist(recipe['world_id'], data['title'], steps,
                                          purpose='Manual reproduction recipe ' + recipe['id'])
        return self.start_run(recipe['world_id'], profile_id, checklist['id'],
                              build_id or data.get('build_id') or None, environment)

    def create_checklist(self, world_id, title, steps, purpose='', version=1):
        _text(title, 'title', 200, False)
        if type(version) is not int or not 1 <= version <= 100000:
            raise ValueError('Checklist version must be a positive integer.')
        clean = self._steps(steps)
        return self.store.save('checklist', world_id, dict(schema=SCHEMA, title=title,
            purpose=_text(purpose, 'purpose'), version=version, steps=clean))

    @staticmethod
    def _steps(steps):
        if not isinstance(steps, list) or not 1 <= len(steps) <= 100:
            raise ValueError('Provide between one and 100 test steps.')
        result, seen = [], set()
        for index, step in enumerate(steps):
            if not isinstance(step, dict):
                raise ValueError('A test step must contain fields.')
            key = _text(step.get('id', 'step-' + str(index + 1)), 'step identifier', 120, False)
            if key in seen:
                raise ValueError('Step identifiers must be unique.')
            seen.add(key)
            row = {key_: _text(step.get(key_, ''), key_, 16000, key_ != 'title')
                   for key_ in ('title', 'preparation', 'expected', 'evidence_hint', 'stop_condition')}
            row['id'] = key
            row['timeout_seconds'] = step.get('timeout_seconds')
            if row['timeout_seconds'] is not None:
                _number(row['timeout_seconds'], 'step timeout', 1, 86400)
            for flag in ('optional', 'expected_failure'):
                if type(step.get(flag, False)) is not bool:
                    raise ValueError('Step flags must be booleans.')
                row[flag] = step.get(flag, False)
            row['branches'] = deepcopy(step.get('branches', []))
            if not isinstance(row['branches'], list) or len(row['branches']) > 10 or any(not isinstance(v, str) or len(v) > 200 for v in row['branches']):
                raise ValueError('Use short manual branch instructions.')
            result.append(row)
        return result

    def start_run(self, world_id, profile_id=None, checklist_id=None, build_id=None,
                  environment='Real client'):
        if environment not in ENVIRONMENTS:
            raise ValueError('Select the actual storage/test environment.')
        profile = self._record(profile_id, 'profile', world_id) if profile_id else None
        if checklist_id is None and profile:
            checklist_id = profile['data'].get('checklist_id') or None
        if checklist_id is None:
            installed = self.install_template(world_id, 'smoke')
            checklist = installed['checklist']
            if profile is None:
                profile = installed['profile']
        else:
            checklist = self._record(checklist_id, 'checklist', world_id)
        build_id, build_record_id, build_snapshot = self._build(world_id, build_id)
        steps = self._steps(checklist['data'].get('steps'))
        now = self.clock()
        for step in steps:
            step.update(status='Not started', evidence='', evidence_ids=[], execution=None,
                        updated_at=None, started_at=None)
        conditions = deepcopy(profile['data'].get('conditions', {})) if profile else {}
        self._conditions(conditions)
        return self.store.save('run', world_id, {
            'schema': SCHEMA, 'title': checklist['data'].get('title', 'Creator test'),
            'status': 'Active', 'outcome': 'Incomplete', 'environment': environment,
            'build_id': build_id, 'build_record_id': build_record_id, 'build_snapshot': build_snapshot,
            'build_identity_source': 'Creator-selected record' if build_record_id else ('Explicit identifier' if build_id else 'Unknown'),
            'profile_id': profile['id'] if profile else None,
            'checklist_id': checklist['id'], 'profile_snapshot': deepcopy(profile['data']) if profile else None,
            'checklist_snapshot': deepcopy(checklist['data']), 'conditions': conditions,
            'steps': steps, 'events': [], 'started_at': now, 'finished_at': None,
            'sharing': 'Local only', 'note': '', 'measurements': []})

    @staticmethod
    def _conditions(conditions):
        if not isinstance(conditions, dict) or len(conditions) > 40:
            raise ValueError('Use a bounded set of test conditions.')
        for key, row in conditions.items():
            _text(key, 'condition name', 120, False)
            if not isinstance(row, dict) or row.get('status') not in CONDITION_STATES:
                raise ValueError('Each condition needs a confirmation state.')
            _text(row.get('value', ''), 'condition value', 1000)
            _text(row.get('source', ''), 'condition source', 200)

    def set_condition(self, run_id, key, value, status='Manually confirmed', source='creator'):
        run = self._active(run_id)
        row = {'value': value, 'status': status, 'source': source}
        self._conditions({key: row})
        if status == 'Verified' and not source.strip():
            raise ValueError('A verified condition requires its evidence source.')
        data = run['data']
        previous = deepcopy(data['conditions'].get(key))
        data['conditions'][key] = row
        self._event(data, 'condition_changed', key=key, previous=previous, condition=row)
        return self._save(run, data)

    def _active(self, run_id):
        run = self._record(run_id, 'run')
        if run['data'].get('status') != 'Active':
            raise ValueError('This run is complete; start a retest to add results.')
        return run

    def _event(self, data, kind, **fields):
        if len(data.get('events', [])) >= 500:
            raise ValueError('This run reached its event limit; finish it and start another run.')
        data.setdefault('events', []).append(dict(kind=kind, at=self.clock(), **deepcopy(fields)))

    def set_step_result(self, run_id, step_id, status, evidence='', execution='manual',
                        evidence_ids=None):
        run = self._active(run_id)
        if status not in STEP_STATUSES or execution not in ('manual', 'helper-confirmed', 'automated'):
            raise ValueError('Unknown test status or execution type.')
        evidence = _text(evidence, 'evidence')
        ids = self._evidence(run['world_id'], evidence_ids, run_id, run['data'].get('build_id'))
        if status in ('Passed', 'Failed') and not evidence.strip() and not ids:
            raise ValueError('A passed or failed result requires recorded evidence.')
        if execution != 'manual' and not ids:
            raise ValueError('Helper-confirmed or automated results require source evidence records.')
        if execution != 'manual':
            raise ValueError('No approved execution-receipt adapter is available. Record a manual result with the selected evidence; helper log reports are untrusted observations.')
        data = run['data']
        step = next((s for s in data['steps'] if s['id'] == step_id), None)
        if step is None:
            raise ValueError('The selected step is not part of this run snapshot.')
        previous = step['status']
        now = self.clock()
        step.update(status=status, evidence=evidence, evidence_ids=ids, execution=execution, updated_at=now)
        if step.get('started_at') is None and status != 'Not started':
            step['started_at'] = now
        self._event(data, 'step_result', step_id=step_id, previous=previous, status=status,
                    evidence=evidence, evidence_ids=ids, execution=execution)
        data['outcome'] = run_summary(data)['outcome']
        return self._save(run, data)

    def finish_run(self, run_id, note='', stopped=False):
        run = self._active(run_id)
        data = run['data']
        data.update(status='Stopped' if stopped else 'Completed', finished_at=self.clock(),
                    note=_text(note, 'run note'), outcome=run_summary(data)['outcome'])
        self._event(data, 'run_stopped' if stopped else 'run_finished')
        return self._save(run, data)

    def bookmark(self, world_id, note='', build_id=None, run_id=None, step_id=None,
                 kind='manual', zone='', evidence_ids=None, before=15, after=5,
                 event_time=None, measurements=None):
        if kind not in ('manual', 'error', 'comparison', 'location'):
            raise ValueError('Unknown bookmark type.')
        build_id, build_record_id, _ = self._build(world_id, build_id)
        if run_id:
            run = self._record(run_id, 'run', world_id)
            if build_id is None:
                build_id = run['data'].get('build_id')
                build_record_id = run['data'].get('build_record_id')
            elif build_id != run['data'].get('build_id'):
                raise ValueError('Bookmark build differs from its run.')
            if step_id and step_id not in {s['id'] for s in run['data']['steps']}:
                raise ValueError('Bookmark step is not part of the selected run.')
        elif step_id:
            raise ValueError('A step bookmark requires its test run.')
        now = self.clock()
        at = now if event_time is None else _number(event_time, 'event time')
        before = _number(before, 'context before', maximum=3600)
        after = _number(after, 'context after', maximum=3600)
        ids = self._evidence(world_id, evidence_ids, run_id, build_id)
        return self.store.save('bookmark', world_id, {
            'schema': SCHEMA, 'title': note[:120] or 'Incident marker', 'note': _text(note, 'note'),
            'bookmark_type': kind, 'build_id': build_id, 'build_record_id': build_record_id, 'run_id': run_id, 'step_id': step_id,
            'zone': _text(zone, 'manual zone', 200), 'position': None,
            'event_time': at, 'received_at': now, 'window': {'start': max(0, at-before), 'end': at+after},
            'evidence_ids': ids, 'measurements': deepcopy(measurements or {}),
            'coverage': 'Selected evidence only; future context is not captured by this marker.',
            'sharing': 'Local only'})

    def issue_from_evidence(self, world_id, evidence_ids=None, title='Investigation',
                            observed='', expected='', reproduction='', build_id=None, run_id=None):
        build_id, build_record_id, _ = self._build(world_id, build_id)
        if run_id:
            run = self._record(run_id, 'run', world_id)
            if build_id is None:
                build_id = run['data'].get('build_id')
                build_record_id = run['data'].get('build_record_id')
            elif build_id != run['data'].get('build_id'):
                raise ValueError('Issue build differs from its run.')
        ids = self._evidence(world_id, evidence_ids, run_id, build_id)
        return self.store.save('issue', world_id, {
            'schema': SCHEMA, 'title': _text(title, 'title', 200, False),
            'status': 'Investigation', 'observed': _text(observed, 'observed behavior'),
            'expected': _text(expected, 'expected behavior'), 'reproduction': _text(reproduction, 'reproduction'),
            'build_id': build_id, 'build_record_id': build_record_id, 'run_id': run_id, 'affected_builds': [build_id] if build_id else [],
            'evidence_ids': ids, 'proposed_fix': '', 'confirmed_cause': '', 'attempted_fixes': [],
            'verification_run_id': None, 'verification_step_id': None, 'blocking': False,
            'sharing': 'Local only', 'signature': '', 'relations': []})

    def update_issue(self, issue_id, status, proposed_fix=None, verification_run_id=None,
                     verification_step_id=None):
        issue = self._record(issue_id, 'issue')
        if status not in ISSUE_STATES:
            raise ValueError('Unknown issue state.')
        data = issue['data']
        if proposed_fix is not None:
            data['proposed_fix'] = _text(proposed_fix, 'proposed fix')
        if status == 'Verified fixed':
            run = self._record(verification_run_id, 'run', issue['world_id'])
            step = next((s for s in run['data']['steps'] if s['id'] == verification_step_id), None)
            if not step or step['status'] != 'Passed' or run['data'].get('status') != 'Completed':
                raise ValueError('Verification needs a passed step in a completed retest.')
            data.update(verification_run_id=run['id'], verification_step_id=step['id'],
                        verified_build_id=run['data'].get('build_id'), verified_environment=run['data']['environment'])
        else:
            data.update(verification_run_id=None, verification_step_id=None,
                        verified_build_id=None, verified_environment=None)
        data['status'] = status
        return self._save(issue, data)

    def designate_baseline(self, run_id, title='Known-good reference', reason=''):
        run = self._record(run_id, 'run')
        if run['data'].get('status') != 'Completed':
            raise ValueError('A baseline requires a completed run.')
        return self.store.save('baseline', run['world_id'], dict(schema=SCHEMA,
            title=_text(title, 'baseline title', 200, False), run_id=run_id,
            reason=_text(reason, 'baseline reason'), environment=run['data']['environment'],
            build_id=run['data'].get('build_id'), outcome=run_summary(run['data'])['outcome']))

    def compare_runs(self, baseline_id, candidate_id):
        return compare_runs(self._record(baseline_id, 'run'), self._record(candidate_id, 'run'))

    def evaluate_release(self, world_id, requirements, run_ids=None):
        """Evaluate creator-selected evidence; this never authorizes publication.

        Requirement kinds: step (run_id, step_id, environment), platform_build
        (build_id, platform), issue (issue_id), manual (status, evidence).
        A manual review is labeled as such and is never inferred from recognition.
        """
        if not isinstance(requirements, list) or not 1 <= len(requirements) <= 100:
            raise ValueError('Select between one and 100 release requirements.')
        allowed = None if run_ids is None else set(run_ids)
        checks = []
        for requirement in requirements:
            if not isinstance(requirement, dict):
                raise ValueError('Invalid release requirement.')
            kind = requirement.get('kind')
            row = dict(label=_text(requirement.get('label', kind or 'Requirement'), 'requirement label', 200),
                       kind=kind, status='Needs verification', detail='', evidence_ids=[])
            if kind == 'step':
                run = self._record(requirement.get('run_id'), 'run', world_id)
                step = next((s for s in run['data']['steps'] if s['id'] == requirement.get('step_id')), None)
                environment = requirement.get('environment') or 'Real client'
                if environment not in ENVIRONMENTS:
                    raise ValueError('Invalid release test environment.')
                if not step or (allowed is not None and run['id'] not in allowed):
                    row['detail'] = 'The selected test step is not in the selected evidence.'
                elif run['data']['environment'] != environment:
                    row['detail'] = 'Required environment: ' + environment + '; recorded: ' + run['data']['environment'] + '.'
                elif requirement.get('build_id') and run['data'].get('build_id') != self._build(world_id, requirement['build_id'])[0]:
                    row['detail'] = 'The selected run tested a different build.'
                elif run['data'].get('status') != 'Completed':
                    row['detail'] = 'The run has not completed.'
                else:
                    row.update(status=step['status'], detail=step.get('evidence', ''),
                               evidence_ids=[run['id']] + step.get('evidence_ids', []))
            elif kind == 'platform_build':
                _, build_record_id, _ = self._build(world_id, requirement.get('build_record_id') or requirement.get('build_id'))
                build = self._record(build_record_id, 'build', world_id) if build_record_id else None
                data = build['data'] if build else {}
                if not build:
                    row['detail'] = 'No artifact record is associated with this declared build identifier.'
                elif not requirement.get('platform') or data.get('platform') != requirement['platform']:
                    row['detail'] = 'The required platform is not matched by this record.'
                elif data.get('artifact_status') != 'Present':
                    row['detail'] = 'No confirmed local artifact presence is recorded.'
                else:
                    row.update(status='Passed', detail='Artifact presence recorded; upload and client tests are separate.', evidence_ids=[build['id']])
            elif kind == 'issue':
                issue = self._record(requirement.get('issue_id'), 'issue', world_id)
                detail = 'Issue state: ' + issue['data'].get('status', 'Unknown')
                environment = requirement.get('environment') or 'Real client'
                if environment not in ENVIRONMENTS:
                    raise ValueError('Invalid release verification environment.')
                scoped = issue['data'].get('verified_environment') == environment
                if not scoped:
                    detail += '; verification is not recorded in ' + environment + '.'
                if requirement.get('build_id') and issue['data'].get('verified_build_id') != self._build(world_id, requirement['build_id'])[0]:
                    scoped = False
                    detail += '; required build is not verified.'
                row.update(status='Passed' if issue['data'].get('status') == 'Verified fixed' and scoped else 'Needs verification',
                           detail=detail, evidence_ids=[issue['id']])
            elif kind == 'manual':
                status = requirement.get('status', 'Needs verification')
                if status not in STEP_STATUSES:
                    raise ValueError('Invalid review status.')
                evidence = _text(requirement.get('evidence', ''), 'review evidence')
                if status in ('Passed', 'Failed') and not evidence.strip():
                    raise ValueError('A release review result needs its evidence.')
                row.update(status=status, detail='Creator review: ' + evidence)
            else:
                raise ValueError('Unsupported release requirement type.')
            checks.append(row)
        ready = all(row['status'] in ('Passed', 'Not applicable') for row in checks)
        return dict(schema=SCHEMA, world_id=world_id, checks=checks, ready=ready,
                    decision='Selected requirements satisfied' if ready else 'Outstanding requirements',
                    publication='Separate reviewed operation; no publishing is performed.',
                    limitations='Creator-defined evidence does not imply VRChat approval.')

    def approve_release(self, world_id, requirements, limitations='', staging_world_id=None):
        evaluation = self.evaluate_release(world_id, requirements)
        if not evaluation['ready'] and not limitations.strip():
            raise ValueError('Document known limitations before approving with outstanding requirements.')
        return self.store.save('release', world_id, dict(schema=SCHEMA,
            title='Creator release review', requirements=deepcopy(requirements), evaluation=evaluation,
            approved_at=self.clock(), known_limitations=_text(limitations, 'known limitations'),
            staging_world_id=staging_world_id, publication_status='Not published by this review'))

    def known_issue_matches(self, world_id, query, limit=10):
        words = set(re.findall(r'[a-z0-9_]{3,}', _text(query, 'search query', 1000).lower()))
        if not words:
            return []
        matches = []
        for record in self.store.list(kind='issue', world_id=world_id, limit=500):
            data = record['data']
            haystack = ' '.join(str(data.get(key, '')) for key in ('title', 'observed', 'signature', 'reproduction'))
            overlap = sorted(words & set(re.findall(r'[a-z0-9_]{3,}', haystack.lower())))
            if overlap:
                matches.append(dict(record=record, matched_terms=overlap,
                    explanation='Resembles an earlier report; cause and duplication are unconfirmed.'))
        return sorted(matches, key=lambda r: (-len(r['matched_terms']), r['record']['id']))[:max(0, min(50, limit))]


def run_summary(run):
    data = run.get('data', run)
    steps = data.get('steps', [])
    counts = {status: sum(step.get('status') == status for step in steps) for status in STEP_STATUSES}
    required = [s for s in steps if not s.get('optional', False)]
    if any(s.get('status') == 'Failed' for s in steps):
        outcome = 'Failed'
    elif required and all(s.get('status') == 'Not applicable' for s in required):
        outcome = 'Not applicable'
    elif required and all(s.get('status') in ('Passed', 'Not applicable') for s in required):
        outcome = 'Passed'
    else:
        outcome = 'Incomplete'
    return dict(outcome=outcome, counts=counts, total=len(steps),
                tested=counts['Passed'] + counts['Failed'],
                limitations='Blocked, unstarted and unavailable results are not passes.')


def compare_runs(baseline, candidate):
    a, b = baseline.get('data', baseline), candidate.get('data', candidate)
    differences, unknown = [], []
    if baseline.get('world_id') != candidate.get('world_id'):
        differences.append('World differs.')
    if a.get('environment') != b.get('environment'):
        differences.append('Test environment differs.')
    if not a.get('build_id') or not b.get('build_id'):
        unknown.append('Build identity is not recorded for both runs.')
    if a.get('status') != 'Completed' or b.get('status') != 'Completed':
        unknown.append('Both runs must be completed.')
    for key in COMPARISON_CONDITIONS:
        x, y = a.get('conditions', {}).get(key), b.get('conditions', {}).get(key)
        if not x or not y or x.get('status') not in ('Verified', 'Manually confirmed') or y.get('status') not in ('Verified', 'Manually confirmed'):
            unknown.append(key + ': conditions are not confirmed for both runs.')
        elif x.get('value') != y.get('value'):
            differences.append(key + ': ' + str(x.get('value')) + ' → ' + str(y.get('value')))
    a_steps = {s['id']: s for s in a.get('steps', [])}
    b_steps = {s['id']: s for s in b.get('steps', [])}
    missing = sorted(set(a_steps) - set(b_steps))
    added = sorted(set(b_steps) - set(a_steps))
    changed = []
    for key in sorted(set(a_steps) & set(b_steps)):
        left, right = a_steps[key], b_steps[key]
        if any(left.get(field) != right.get(field) for field in ('preparation', 'expected')):
            differences.append('Step definition differs: ' + key)
        if left.get('status') != right.get('status'):
            changed.append(dict(step_id=key, baseline=left.get('status'), candidate=right.get('status')))
    return dict(comparable=not differences and not unknown, differences=differences,
                unverified_conditions=unknown, missing_coverage=missing, added_coverage=added,
                changed_results=changed, finding='Recorded differences; repeat controlled tests before claiming regression.',
                baseline_build=a.get('build_id'), candidate_build=b.get('build_id'))


def frame_budget(target_fps):
    return 1000.0 / _number(target_fps, 'target frames per second', 1, 1000)


def capacity_summary(samples, target_fps=72):
    """Summarize explicitly supplied frame windows; do not suggest global capacity."""
    budget = frame_budget(target_fps)
    if not isinstance(samples, list) or len(samples) > 10000:
        raise ValueError('Use at most 10000 selected samples.')
    groups = {}
    unavailable = 0
    for sample in samples:
        if not isinstance(sample, dict):
            raise ValueError('A sample must identify its measurement and conditions.')
        if sample.get('frame_ms') is None:
            unavailable += 1
            continue
        value = _number(sample['frame_ms'], 'frame time', maximum=600000)
        count = sample.get('population')
        if type(count) is not int or not 0 <= count <= 1000:
            raise ValueError('Record the observed population for each selected sample.')
        source = _text(sample.get('source', ''), 'measurement source', 200, False)
        platform = _text(sample.get('platform', ''), 'tested platform', 100, False)
        scope = _text(sample.get('scope', ''), 'measurement scope', 200, False)
        configuration = _text(sample.get('configuration', ''), 'test configuration', 1000, False)
        _number(sample.get('period_seconds'), 'sample window', minimum=0.001, maximum=86400)
        groups.setdefault((count, source, platform, scope, configuration), []).append(value)
    rows = []
    for (count, source, platform, scope, configuration), values in sorted(groups.items()):
        values.sort()
        p95 = values[max(0, math.ceil(len(values)*0.95)-1)]
        rows.append(dict(population=count, source=source, platform=platform, scope=scope,
            configuration=configuration, sample_count=len(values), median_ms=(values[(len(values)-1)//2] + values[len(values)//2]) / 2,
            p95_ms=p95, worst_ms=values[-1], within_selected_budget=p95 <= budget,
            repeated=len(values) >= 2))
    return dict(target_fps=target_fps, frame_budget_ms=budget, groups=rows,
                unavailable_samples=unavailable, published_capacity_changed=False,
                limitations='Selected local sample windows only. Larger populations, other platforms and changed conditions remain untested. Diagnostic overhead belongs in the configuration.')


def convergence_state(expected, observed=None, elapsed=0, settling_seconds=5, available=True):
    _number(elapsed, 'elapsed time', maximum=86400)
    _number(settling_seconds, 'settling period', maximum=3600)
    if not isinstance(expected, dict) or len(expected) > 100:
        raise ValueError('Provide selected creator-declared expected states.')
    if observed is not None and not isinstance(observed, dict):
        raise ValueError('Observed states must be a mapping or unavailable.')
    settled = elapsed >= settling_seconds
    rows = []
    for key, value in expected.items():
        if not available:
            state = 'No observation available'
        elif observed is None or key not in observed:
            state = 'Not yet received' if not settled else 'No observation available'
        elif observed[key] == value:
            state = 'Matched'
        else:
            state = 'Received but mismatched'
        rows.append(dict(key=key, expected=deepcopy(value), observed=deepcopy(observed.get(key)) if observed else None,
                         state=state, failed=settled and state == 'Received but mismatched'))
    return dict(states=rows, settling=not settled,
                complete=bool(rows) and all(r['state'] == 'Matched' for r in rows),
                failed=any(r['failed'] for r in rows),
                limitations='Missing observations remain unknown; a temporary mismatch is not a lasting defect.')


def compare_manifests(left, right, intentional=None):
    """Compare only declared semantic fields, independent of visual asset variants."""
    if not isinstance(left, dict) or not isinstance(right, dict):
        raise ValueError('Supply two creator-provided manifests.')
    intentional = intentional or {}
    if not isinstance(intentional, dict):
        raise ValueError('Intentional differences require reasons keyed by field.')
    fields = ('network_objects', 'controls', 'assertions', 'persistence_schema', 'game_state', 'interactions')
    missing, differences, matched = [], [], []
    def canonical(value):
        if isinstance(value, list) and all(isinstance(v, dict) and isinstance(v.get('id'), str) for v in value):
            if len({v['id'] for v in value}) != len(value):
                raise ValueError('Manifest declaration identifiers must be unique.')
            return {v['id']: v for v in value}
        return value
    for field in fields:
        if field not in left or field not in right:
            missing.append(field)
        elif canonical(left[field]) == canonical(right[field]):
            matched.append(field)
        else:
            reason = _text(intentional.get(field, ''), 'intentional difference reason', 2000)
            differences.append(dict(field=field, intentional=bool(reason.strip()), reason=reason,
                                    scope='Only tests and controls depending on this declaration.'))
    return dict(matched=matched, differences=differences, unavailable=missing,
                declared_parity=not differences and not missing,
                unexplained=[d['field'] for d in differences if not d['intentional']],
                limitations='Only supplied declarations were compared; actual platform interactions need client tests.')


def debug_audit(manifest, public_build=False):
    if not isinstance(manifest, dict):
        raise ValueError('A creator-provided manifest is required.')
    findings = []
    for row in manifest.get('controls', []):
        if not isinstance(row, dict):
            continue
        if row.get('scope') != 'local' or row.get('test_only'):
            findings.append(dict(kind='control', id=row.get('id', 'Unknown'),
                scope=row.get('scope', 'Undeclared'), requirements=deepcopy(row.get('requirements', [])),
                severity='Review before public release' if public_build else 'Review declaration',
                detail='A declared action is not automatically unsafe; review actual authorization and test scope.'))
    for key in ('verbose_logging', 'test_ui', 'world_debugging', 'external_dependencies'):
        if key in manifest:
            findings.append(dict(kind=key, value=deepcopy(manifest[key]), severity='Review declaration'))
    return dict(findings=findings, coverage='Creator-supplied manifest only',
                limitations='Creator Mode grants no built-in debug privilege. Undeclared configuration was not inspected.')
