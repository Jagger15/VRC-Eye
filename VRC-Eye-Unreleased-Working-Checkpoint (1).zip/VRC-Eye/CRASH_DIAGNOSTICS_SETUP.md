# Crash & Diagnostics — VRC Eye 1.18.8

Close the old app, extract VRC-Eye-v1.18.8.zip, and run Start.cmd. Open
**Advanced → Crash & Diagnostics**. Python 3.10+ and Tkinter are required.
The core recorder works with stock VRChat; no account login, custom client,
modification or client bridge is required.

## First run

The Black Box starts automatically, including when its page is closed. It keeps
10 minutes of local diagnostic evidence by default. This is separate from the
opt-in Performance & Security resource journals and from player history.
**Start.cmd** automatically prepares psutil and the other app dependencies.
If package setup cannot finish offline, logs and recorder heartbeats still work;
a later normal launch retries missing packages. **Safe-mode.cmd** skips setup.

1. Choose **Preserve now** to save a manual incident without crashing anything.
2. **Refresh incidents**, select the incident, and read its Overview.
3. Switch to **Advanced** for Replay and Error Center. Scrub the slider or select
   a recorded event. Choose a metric to inspect its graph. Values expire; the
   replay does not interpolate missing measurements.
4. In **Developer**, inspect the selected timeline record for sequence numbers,
   recorded wall/monotonic timestamps, confidence, sources and measurement ages.
5. Select **Review export…** to preview the bundle's included/excluded data before
   saving. Resource measurements can be excluded. Save to a new ZIP filename;
   existing files are never overwritten. No upload or sharing happens here.

## What is collected

- Resource Guard's existing system/process RAM, Windows commit, CPU, available
  GPU/VRAM/temperature and disk-space readings. Individual unavailable sensors
  stay unknown. GPU device totals are not per-avatar or per-process attribution.
- An independent psutil core fallback when Resource Guard is disabled/unavailable.
  Sensor work runs separately from the disk writer, so a blocked collector does
  not stop heartbeats. Optional GPU collection is reused, not duplicated.
- VRChat process identity transitions. PID, executable path and creation time are
  used only in memory; persisted events use a numbered session segment.
- Windows window responsiveness, when observable. A sustained unresponsive state
  is treated cautiously, with 30 seconds of grace following a fresh world-enter
  event. A window responsiveness flag does not prove a deadlock.
- SteamVR process presence, system disk/network byte rates, and network interface
  link status. Interface link status is **not** Internet reachability or latency.
- Fresh, non-reconstructed world/player/avatar event types and normalized warning,
  error and explicit crash-marker counts. No names, raw lines or player IDs.
- Bridge connectivity changes. If the user has already connected Wellness inputs,
  observed SteamVR presence/proximity and the count of battery-reporting devices
  can be recorded. That count is not a complete inventory of tracked devices.
- Recorder heartbeat, source expiry, dropped-event counts, timing gaps/clock
  changes, and Tk callback error counts. Exception bodies are not persisted.

Normal metrics are written every 5 seconds, changing to 1 second under elevated
resource pressure. Source sample timestamps and expiry are retained. This release
has no source that justifies advertising 250 ms sensor precision. The recorder
writes a heartbeat every second; queued log events retain observation time.

## Incidents and recovery

A preserved incident is a transactionally copied snapshot of the ring, independent
of subsequent rotation. Triggers include explicit log crash markers, sustained
window unresponsiveness, observed unexplained process exit, manual preservation,
and a recorder run that ended without a clean-stop marker. Nearby automatic
triggers are coalesced with a 30-second cooldown to avoid incident storms; events
continue in the active ring. An already-preserved snapshot is not extended with
later process events. A reviewed Resource Guard normal-close request is exempt
from unexplained-exit capture for 30 seconds.

On startup, unfinished committed evidence is preserved before a new ring starts.
Optional read-only Windows Event Log queries correlate events around the end of
that recording and the subsequent boot (up to seven days apart). Queries check
provider names as well as event IDs. Event 1001 from WER-SystemErrorReporting can
establish a reported bugcheck; Kernel-Power 41/EventLog 6008 establish an unexpected
shutdown, **not its cause**. Application errors/hangs and display-recovery events
are retained when matched. Event Log access can fail or be incomplete. OS wall
times can reflect the next boot, and their monotonic placement is estimated.
They do not replace the final measured time or stretch the metric graph into
an unrecorded interval. The UI never claims a guaranteed crash diagnosis.

Overview compares available final-window metrics with an earlier healthy
checkpoint, summarizes error/avatar activity and identifies broad similarities
among retained incidents. Similarity is a small deterministic feature signature,
not a learned diagnosis, predictive model or attribution to a player.

**Launch VRChat…** uses Steam's normal launch URI after confirmation and a fresh
observation that VRChat is absent. It does not kill or restart a running client.
Saved Steam launch options may choose a world, so launching directly to the user's
Home is not guaranteed or exposed as a capability. **Open previous world…** is
available only for an opted-in saved world ID; it opens the website for choosing
a fresh instance. It never reconstructs a private instance or automatically joins.
Repeated similar incidents add a warning. All recovery is user initiated.

## Retention and privacy

Settings: rolling 5/10/15 minutes; incident age 7/30/90 days or no age deletion;
incident count 10/25/50 or no count deletion. Defaults are 10 minutes, 30 days,
10 incidents. Applying retention changes can prune existing incidents immediately,
so those changes are reviewed. Each incident also has a reviewed Delete action.

The active journal is limited to 10,000 records and 16 MiB of record payload.
Preserved payload has a 64 MiB budget, separate from SQLite metadata/free-page/WAL
overhead. A database page limit and frequent WAL checkpoints bound ordinary
storage growth. If the incident budget is full, new automatic preservation is
reported as unavailable; the active recorder continues. Export/delete old
incidents to free that budget. A disk write failure stops recording and retains
existing evidence rather than silently starting a replacement database.

Local storage is `crash-diagnostics/blackbox.sqlite3`, next to `companion.sqlite3`.
SQLite WAL with FULL synchronous commits and per-record SHA-256 checksums protects
completed writes. It cannot guarantee survival of a broken disk/controller or
uncommitted writes at power loss. Partial/invalid records are counted and excluded
from replay/export; gaps are visible. One process owns the recorder at a time.
Retention is applied at startup and during recording.

Credentials, tokens, player/account/avatar identifiers, private instance codes,
raw logs, personal paths, machine names and hardware serials are excluded before
persistence. A public world ID can be opted into for **local recovery only**, and
is always excluded from exports. Turning that option off clears stored recovery
IDs. Exact event timestamps and resource measurements remain in reviewed exports.
Exports include summary.json, timeline.json, manifest.json and SHA256SUMS.txt.
Deletion is logical application deletion; SSD/OS backups can retain old blocks.

## Safe Mode

Run **Safe-mode.cmd** or `python vrc_eye.py --safe-mode`. Three consecutive starts
that fail to reach the 30-second ready checkpoint prompt for Safe Mode. A normal
close marks startup as ready too. The marker does not claim the reason for an
interrupted start. Safe Mode starts with VRCX cache matching, GPU telemetry and
Wellness automatic sessions disabled; the bridge dialog remains disabled. The
Black Box and basic OS/log collection remain available. Previously disabled
recording stays disabled. Other settings are retained.

## Capability and validation limits

This release does not collect dump files, arbitrary Event Log text, private game
memory, packet contents, hardware serials, tracking poses, tracking-loss quality,
GPU-driver blame, per-avatar resource cost, or raw bridge payloads. It does not
perform automatic restarts, launch-option editing, Home-world overrides, force
termination or client modifications. Deeper hardware/driver diagnostics, richer
tracking/bridge providers and predictive similarity remain later extensions of
the supplied design; no working capability is implied for absent sources.

The full design and implementation map are in CRASH_DIAGNOSTICS_DESIGN_INPUT.md.
See VALIDATION.md for automated results and the remaining native Windows/VRChat
checks. This build environment cannot validate a real BSOD, power loss, Steam
launch, VR headset or native Tk layout.

Provider references used during implementation:
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-ishungappwindow
- https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/wevtutil
- https://docs.vrchat.com/docs/launch-options
