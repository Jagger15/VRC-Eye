# VRC Eye 1.21.0 — Development 17

Built from the verified saved Development 16 source archive. This batch adds
shared private tags, selective settings backup/restore/undo, recovery working-copy
history and supported Unity source dependency diagnostics.

## Start and update

Close the old copy, extract **VRC-Eye-v1.21.0-Development-17.zip** into a separate
folder, and run **Start.cmd** on Windows or **bash Start.sh** on Linux. Existing
per-user data locations are retained; launchers and requirements are unchanged.
This is runnable source, not a compiled EXE or signed installer.

## Shared private tags

Player Notes, profile/Favorites shared notes and local entity annotations now use
the same tags in their account workspace. Earlier roster tags are copied into the
native annotation store idempotently, leaving the earlier data intact. Existing
shared tags are preserved on migration; a deliberate tag replacement uses exactly
the reviewed list. Tag deletion suppresses acknowledged older copies from returning.
User/friend aliases and normalized case/Unicode tag comparisons are combined.
Notes and API profile tags remain distinct from private local tags.

Open **Shared notes / tags → Manage tags and saved views…**, or **Favorites →
VRC Eye data → Backup and recovery → Private tags and saved views…**. The manager
supports multi-select add/remove, workspace-wide rename/merge, entity type and text
filters, all/any included tags, excluded tags, and up to 30 named saved views.
At most 50 tags per edited item and 1,000 items per reviewed batch; inventory is
bounded to 50,000 entity/annotation records and displays the first 1,000 matches.
Concurrent edits fail before a batch commits. Local search/Favorites and roster
filters consume canonical annotations; later changes become visible on refresh.

## Selective settings backup and undo

Open **Desktop controls → Profiles → Selective settings backup / undo…**, also
available in **VRC Eye data → Backup and recovery**. Select any of six sections:

- Appearance/accessibility preferences.
- Home layouts and appearance profiles.
- Notification banners, sound, DND, quiet hours, category priority/muting and timing.
- Main-window navigation shortcuts; these are not OS-global hotkeys.
- Friend-location text/presence/platform filters; pins/collection selection remain local.
- Private tag saved views in the destination workspace.

Export writes a new JSON file. Restore validates the typed document, shows exact
before/after field changes, and applies selected fields in one SQLite transaction.
It preserves other sections and current credentials, service permissions, execution
approvals and source folders. Device settings apply across local accounts; saved
views/filters apply to the explicitly displayed destination workspace. Restoring
another workspace's bundle is an explicit data copy, not an account switch.

The most recent 100 restore/undo receipts per workspace persist across restart.
Undo restores fields still matching that receipt and lists later edits it will
preserve. Changed fields during review abort the commit. Unsupported schemas,
unknown fields, invalid chords, duplicate JSON keys and oversized documents fail.
After restore, supported live controls reload; reopen other settings editors before
editing. This history covers selective restore operations; it is not automatic
history of every direct edit in every component. Existing profile tools remain.

## Recovery working copies and repair history

Open **Avatar Library → Recovery → Working copies / repair history…**. A managed
AssetRipper job also has this handoff. Choose an exported Unity project and a NEW
workspace folder, review the source hash and copy size, and create the workspace.
VRC Eye creates **raw/** and **project/** plus **history/**. Edit only project/.
The original export and raw/ are never changed by this feature. Raw is protected
by application behavior and rechecked hashes, not OS permissions against user edits.

Use the existing reviewed Creator Projects handoff if you want to open the working
copy in Unity. After manual repair work, close Unity and choose **Review repair
checkpoint…**. The checkpoint lists added, removed and modified file paths and
hashes, saves the new bytes needed for future undo, and records dependency evidence.
This is an explicit checkpoint of edits you performed; it does not run an automatic
material/rig repair or intercept every Unity editor operation.

Choose a recorded checkpoint and **Review undo…**. Files still matching its result
are eligible; later edits are shown and preserved. Each replacement verifies its
history bytes and current file before writing. Per-file phases/outcomes are durable.
A multi-file rollback is not one atomic filesystem transaction. On cancellation,
failure or power loss, inspect retained receipts and files before continuing.
There is no startup replay or automatic deletion. Abandoned reservations can be
released after a separate review only when process inspection is available and
their recorded process is no longer running; releasing a reservation performs no repair or reconciliation.

Limits: source trees up to 20,000 entries, 8 GiB total and 2 GiB per file; bounded
relative paths; raw plus working copy needs twice the source size. Checkpoint
history displays the most recent 100 records and is limited to 8 GiB of snapshot
bytes, with bounded metadata/tree enumeration. New checkpoints stop after 100
history records; rollback receipts and existing files are never automatically purged.
Generated Library/Temp/Logs/Obj and version-control caches are excluded. File modes,
empty-directory history and complete filesystem transactionality are not tracked.
When process identity is unavailable, exclusive reservations still protect active
file work, but abandoned-reservation release is refused. Raw, working and history bytes stay in the selected workspace and are not included
in portable settings or desktop-profile backups. Native power-loss/Windows behavior
still needs acceptance.

## Dependency inspection

**Inspect dependencies** reads supported Unity text-serialized references and
.meta GUIDs without launching Unity or executing scripts. It reports unresolved
shader/texture/other asset references, duplicate GUIDs, orphan or invalid sidecars,
assets missing sidecars, Unity version and package declaration/lock evidence.
Each unresolved reference includes its relative file and line. Source hashes are
rechecked so a changing project cannot produce an accepted stale report.

A GUID found in the selected source identifies a containing asset only. Object
fileIDs, types, internal references, shader compatibility, rigs and compilation
are unverified. An absent GUID may resolve through an uninspected registry package
or Unity resource. Binary assets and unsupported text/reference forms are listed
as uninspected. Text reads are limited to 8 MiB/file, 64 MiB total and 100,000
references. The scanner does not promise a complete or working recovered project.

The representation follows Unity's [direct reference documentation](https://docs.unity3d.com/Manual/assets-direct-reference.html)
and [GUID/local file identifier API documentation](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/AssetDatabase.TryGetGUIDAndLocalFileIdentifier.html).

## Remaining scope

The real bundle/FBX scene viewer, materials/rig/animation preview, typed repair
helpers integrated with this journal, conditional dashboard profiles and interactive
Discord/SteamVR workflows remain later work. The [remaining ARC/VRCX report](ARC_VRCX_REMAINING_DEV17.md)
still records 38 partial and 9 missing areas. Native GUI, installed AssetRipper,
live transfer origins and Unity acceptance remain open. Fixture/headless checks
are not installed-provider or native GUI acceptance.
