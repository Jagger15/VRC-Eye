"""Offline validation and persistence format for VRC Eye networking choices.

Connection profiles contain reusable endpoints and public certificate pins only.
Invitations, credentials, device keys and arbitrary connection arguments are never
accepted. Parsing this module's data does not resolve names or import transport.
"""
from __future__ import annotations

from copy import deepcopy
import ipaddress
import json
import re
import unicodedata
import uuid

MODES = ('LAN', 'Hamachi', 'Tailscale', 'ZeroTier', 'Radmin VPN', 'NetBird', 'Other VPN', 'Relay')
MAX_PROFILES = 32
MAX_SETTINGS_BYTES = 32768
SETTING_KEY = 'network_settings'
_HEX_PIN = re.compile(r'^[0-9a-fA-F]{64}$')
_LABEL = re.compile(r'^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$')
RECOVERY_REASON = 'Saved networking settings were invalid. Relay-only protection is enabled; review and save your networking choices.'


def validate_address(value, *, literal=False):
    if not isinstance(value, str) or not value or len(value) > 253 or value != value.strip():
        raise ValueError('Enter a host name or IP address without surrounding spaces.')
    if any(unicodedata.category(char).startswith('C') or char.isspace() for char in value):
        raise ValueError('The network address contains unsupported characters.')
    if any(char in value for char in '/\\@?#%[]'):
        raise ValueError('Enter a network address without a URL, path, credentials, or scope suffix.')
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        if literal:
            raise ValueError('Choose a specific local adapter IP address.') from None
        labels = value[:-1].split('.') if value.endswith('.') else value.split('.')
        if not labels or not all(_LABEL.fullmatch(label) for label in labels):
            raise ValueError('Enter a valid host name or IP address.') from None
        return value.lower()
    if address.is_unspecified or address.is_multicast or (address.is_reserved and not address.is_loopback):
        raise ValueError('Choose a specific unicast network address.')
    return str(address)


def validate_host(address, port=0, mode='LAN', *, relay_pin=''):
    if not isinstance(mode, str) or mode not in MODES:
        raise ValueError('Choose a supported LAN, VPN, or Relay connection mode.')
    if type(port) is not int or not 0 <= port <= 65535 or (mode == 'Relay' and port == 0):
        raise ValueError('Choose a valid port; relays require a port between 1 and 65535.')
    address = validate_address(address, literal=mode != 'Relay')
    if not isinstance(relay_pin, str):
        raise ValueError('The relay certificate fingerprint must be text.')
    if mode == 'Relay':
        if not _HEX_PIN.fullmatch(relay_pin):
            raise ValueError('Relay connections require a SHA-256 certificate fingerprint.')
        relay_pin = relay_pin.lower()
    elif relay_pin:
        raise ValueError('A relay fingerprint belongs only to a Relay profile.')
    return {'address': address, 'port': port, 'mode': mode, 'relay_pin': relay_pin}


def validate_source_address(value):
    if value == '':
        return ''
    return validate_address(value, literal=True)


def validate_profile(data, *, identifier=None):
    if not isinstance(data, dict) or set(data) - {'id', 'name', 'mode', 'address', 'port', 'relay_pin', 'source_address'}:
        raise ValueError('Profiles accept only a name, route, endpoint, public relay pin, and optional source address.')
    if not {'name', 'mode', 'address', 'port'}.issubset(data):
        raise ValueError('A connection profile needs a name, mode, address, and port.')
    name = data['name']
    if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(unicodedata.category(c).startswith('C') for c in name):
        raise ValueError('Choose a profile name between 1 and 80 visible characters.')
    supplied = data.get('id')
    if supplied is not None and identifier is not None and supplied != identifier:
        raise ValueError('The profile identifier does not match the selected profile.')
    identifier = identifier or supplied or str(uuid.uuid4())
    try:
        if not isinstance(identifier, str) or str(uuid.UUID(identifier)) != identifier:
            raise ValueError
    except (ValueError, AttributeError):
        raise ValueError('Invalid connection profile identifier.') from None
    route = validate_host(data['address'], data['port'], data['mode'], relay_pin=data.get('relay_pin', ''))
    source = validate_source_address(data.get('source_address', ''))
    if source and route['mode'] == 'Relay':
        raise ValueError('Relay profiles use the relay route and do not accept a direct source address.')
    result = {'id': identifier, 'name': name.strip(), **route}
    if source:
        result['source_address'] = source
    return result


def _unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Duplicate networking setting.')
        value[key] = item
    return value


def _canonical(data):
    if not isinstance(data, dict) or not {'schema', 'relay_only', 'profiles'}.issubset(data) or set(data) - {'schema', 'relay_only', 'profiles', 'recovery_pending'} or type(data['schema']) is not int or data['schema'] != 1 or type(data['relay_only']) is not bool or type(data.get('recovery_pending', False)) is not bool:
        raise ValueError('Invalid networking settings.')
    if data.get('recovery_pending', False) and not data['relay_only']:
        raise ValueError('Recovery protection cannot allow direct connections before policy review.')
    if not isinstance(data['profiles'], list) or len(data['profiles']) > MAX_PROFILES:
        raise ValueError('Too many connection profiles.')
    profiles = []
    identifiers = set()
    for profile in data['profiles']:
        if not isinstance(profile, dict) or 'id' not in profile:
            raise ValueError('A saved profile is missing its identity.')
        clean = validate_profile(profile)
        if clean['id'] in identifiers:
            raise ValueError('Duplicate connection profile identity.')
        identifiers.add(clean['id'])
        profiles.append(clean)
    return {'schema': 1, 'relay_only': data['relay_only'], 'profiles': profiles, 'recovery_pending': data.get('recovery_pending', False)}


def decode_settings(raw):
    """Missing settings preserve 1.19.0; any malformed existing value fails closed."""
    if raw is None:
        return {'relay_only': False, 'profiles': [], 'recovery_reason': ''}
    try:
        if not isinstance(raw, str) or len(raw.encode('utf-8')) > MAX_SETTINGS_BYTES:
            raise ValueError('Invalid networking settings size.')
        data = json.loads(raw, object_pairs_hook=_unique,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid number.')))
        clean = _canonical(data)
        return {'relay_only': clean['relay_only'], 'profiles': clean['profiles'], 'recovery_reason': RECOVERY_REASON if clean['recovery_pending'] else ''}
    except (ValueError, TypeError, RecursionError, UnicodeError):
        return {'relay_only': True, 'profiles': [], 'recovery_reason': RECOVERY_REASON}


def encode_settings(settings):
    clean = _canonical({'schema': 1, 'relay_only': settings['relay_only'], 'profiles': deepcopy(settings['profiles']), 'recovery_pending': bool(settings.get('recovery_reason'))})
    if len(json.dumps(clean, ensure_ascii=False, allow_nan=False).encode('utf-8')) > MAX_SETTINGS_BYTES:
        raise ValueError('Saved networking settings exceed their size limit.')
    return clean
