"""Optional read-only process responsiveness and Windows evidence providers."""
import ctypes
from datetime import datetime,timezone
import os
from pathlib import Path
import re
import subprocess
import time
import xml.etree.ElementTree as ET
from resource_core import number


def responsiveness(identity,exact):
    if os.name!='nt' or not identity:return 'unknown'
    exact(identity)
    from ctypes import wintypes as w
    user=ctypes.WinDLL('user32',use_last_error=True)
    callback=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
    user.EnumWindows.argtypes=[callback,w.LPARAM];user.EnumWindows.restype=w.BOOL
    user.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)];user.GetWindowThreadProcessId.restype=w.DWORD
    user.IsWindowVisible.argtypes=[w.HWND];user.IsWindowVisible.restype=w.BOOL
    user.IsHungAppWindow.argtypes=[w.HWND];user.IsHungAppWindow.restype=w.BOOL
    states=[]
    def visit(hwnd,_):
        pid=w.DWORD();user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value==identity[0] and user.IsWindowVisible(hwnd):states.append(bool(user.IsHungAppWindow(hwnd)))
        return True
    if not user.EnumWindows(callback(visit),0):return 'unknown'
    exact(identity)
    return 'unknown' if not states else 'unresponsive' if any(states) else 'responsive'


class AuxiliaryProbe:
    def __init__(self,module=None):
        if module is None:import psutil as module
        self.ps=module;self.previous=None
    def sample(self,at):
        result={}
        try:
            names=[(p.info.get('name') or '').casefold() for p in self.ps.process_iter(['name'])]
            result['steam_running']=any(n in ('vrserver','vrserver.exe') for n in names)
        except Exception:pass
        try:
            stats=self.ps.net_if_stats();usable=[v for k,v in stats.items() if k.lower() not in ('lo','loopback')]
            if usable:result['network']='connected' if any(v.isup for v in usable) else 'disconnected'
        except Exception:pass
        try:
            disk=self.ps.disk_io_counters();net=self.ps.net_io_counters()
            counters=(disk.read_bytes,disk.write_bytes,net.bytes_recv,net.bytes_sent)
            if self.previous and 0<at-self.previous[0]<=15:
                for key,current,old in zip(('disk.read_bps','disk.write_bps','network.recv_bps','network.sent_bps'),counters,self.previous[1]):
                    if current>=old:result[key]=(current-old)/(at-self.previous[0])
            self.previous=(at,counters)
        except Exception:self.previous=None
        return result


NAMESPACE='{http://schemas.microsoft.com/win/2004/08/events/event}'
PAIRS={('Microsoft-Windows-Kernel-Power',41):'Kernel-Power',('Microsoft-Windows-WER-SystemErrorReporting',1001):'WER-SystemErrorReporting',
       ('Display',4101):'Display',('EventLog',6008):'EventLog',('Application Error',1000):'Application Error',('Application Hang',1002):'Application Hang'}


def parse_windows_events(xml,start,end):
    if len(xml)>2*1024**2 or '<!DOCTYPE' in xml.upper() or '<!ENTITY' in xml.upper():raise ValueError('Windows event response exceeds supported bounds.')
    xml=re.sub(r'<\?xml[^>]*\?>','',xml)
    try:root=ET.fromstring('<Events>'+xml+'</Events>')
    except ET.ParseError:raise ValueError('Windows event response could not be parsed.') from None
    result=[]
    for event in root.iter(NAMESPACE+'Event'):
        system=event.find(NAMESPACE+'System')
        if system is None:continue
        p=system.find(NAMESPACE+'Provider');code=system.findtext(NAMESPACE+'EventID');t=system.find(NAMESPACE+'TimeCreated')
        if p is None or t is None:continue
        try:code=int(code);stamp=datetime.fromisoformat(t.attrib['SystemTime'].replace('Z','+00:00')).timestamp()
        except (ValueError,KeyError):continue
        provider=PAIRS.get((p.attrib.get('Name'),code))
        if not provider or not start<=stamp<=end:continue
        payload=dict(provider=provider,code=code)
        fields={n.attrib.get('Name',''):n.text or '' for n in event.findall('.//'+NAMESPACE+'Data')}
        if provider in ('Application Error','Application Hang'):
            name=fields.get('AppName',fields.get('ExeFileName','')).lower()
            if name=='vrchat.exe':payload['application']='VRChat'
            elif name in ('vrserver.exe','vrcompositor.exe'):payload['application']='SteamVR'
            else:continue
        if provider=='WER-SystemErrorReporting':
            match=re.search(r'0x[0-9a-fA-F]{1,8}',fields.get('param1',''))
            if match:payload['bugcheck']=match[0]
        result.append(dict(wall=stamp,payload=payload))
        if len(result)>=64:break
    return result


def windows_evidence(start,end,run=subprocess.run):
    if os.name!='nt':return [],'Windows Event Log unavailable on this platform'
    if not all(number(v) for v in (start,end)) or not 0<=end-start<=7*86400:return [],'Evidence window exceeds seven days'
    exe=Path(os.environ.get('SystemRoot','C:/Windows'))/'System32/wevtutil.exe'
    events=[]
    utc=lambda t:datetime.fromtimestamp(t,timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
    for channel,codes in (('System',(41,1001,4101,6008)),('Application',(1000,1002))):
        query="*[System[("+' or '.join('EventID='+str(c) for c in codes)+") and TimeCreated[@SystemTime>='"+utc(start)+"' and @SystemTime<='"+utc(end)+"']]]"
        try:
            response=run([str(exe),'qe',channel,'/q:'+query,'/c:64','/rd:true','/f:xml'],capture_output=True,text=True,timeout=4,check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            events.extend(parse_windows_events(response.stdout,start,end))
        except (OSError,ValueError,subprocess.SubprocessError):return events,'Windows evidence incomplete or access unavailable'
    return events,'Windows evidence query completed; event time may reflect the subsequent boot'
