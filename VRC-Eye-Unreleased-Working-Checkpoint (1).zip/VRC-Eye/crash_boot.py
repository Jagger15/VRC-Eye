"""Local startup-failure guard. No traceback, credentials or account data."""
import json
import os
from pathlib import Path
from crash_store import OwnerLock


class StartupGuard:
    def __init__(self,path):
        self.path=Path(path);self.owner=OwnerLock(self.path.with_suffix('.lock'));self.failures=0;self.acquired=False
    def begin(self):
        self.owner.acquire();self.acquired=True
        previous={}
        try:
            if self.path.stat().st_size<=4096:previous=json.loads(self.path.read_text())
        except (OSError,ValueError):pass
        count=previous.get('failures',0) if isinstance(previous,dict) else 0
        if type(count) is not int or not 0<=count<=100:count=0
        self.failures=min(100,count+1) if isinstance(previous,dict) and previous.get('pending') is True else 0
        self._write(True);return self.failures>=3
    def _write(self,pending):
        temp=self.path.with_suffix('.tmp')
        with temp.open('w',encoding='utf-8') as stream:
            json.dump(dict(schema=1,pending=pending,failures=self.failures if pending else 0),stream);stream.flush();os.fsync(stream.fileno())
        os.replace(temp,self.path)
    def ready(self):
        if self.acquired:self._write(False)
    def close(self):self.owner.close();self.acquired=False
