"""Appearance previews, movable Home cards and portable presentation profiles."""
from copy import deepcopy
import json
from pathlib import Path

from companion_ui import Page,Table,button,choice,entry
from friendly_ui import ScrollPane,flow_line as line
from creator_projects_ui import review_document
from ui_preferences import Presentation,THEMES,SCALES
from customization import WIDGETS,APPEARANCE,load,save,label,widget,defaults,theme_document,parse_theme,read_document,validate
from appearance_colors import palette,contrast


class CustomizationPage(Page):
    def __init__(self,shell,parent):
        super().__init__(shell,parent,'Customization',task_controls=False)
        self.experience=self.app.experience;self.state=load(self.app);self.undo=None
        self.scroll=ScrollPane(self.app,parent,min_width=520);self.parent=self.scroll.body
        self.tabs=self.ttk.Notebook(self.parent);self.tabs.pack(fill='both',expand=True)
        self.frames={name:self.ttk.Frame(self.tabs,padding=12) for name in ('Appearance','Home layout','Profiles & sharing','Novelty','History')}
        for name,frame in self.frames.items():self.tabs.add(frame,text=name)
        self.vars={};self.build_appearance();self.build_home();self.build_profiles()
        button(self,line(self,self.frames['Profiles & sharing']),'Desktop notifications, automation & profiles…',lambda:__import__('desktop_ui').show(self.shell))
        from novelty_ui import NoveltySettings
        self.novelty=NoveltySettings(self,self.frames['Novelty'])
        self.history=self.tk.StringVar();self.ttk.Label(self.frames['History'],textvariable=self.history,wraplength=850,justify='left').pack(anchor='w')
        button(self,line(self,self.frames['History']),'Settings and layout history / undo…',lambda:__import__('settings_bundle_ui').show(self.shell))
        self.build_conditions()
        self.refresh();self.preview()

    def explain(self,parent,text):self.ttk.Label(parent,text=text,wraplength=850,style='Muted.TLabel').pack(anchor='w',fill='x',pady=6)

    def build_appearance(self):
        pane=self.frames['Appearance'];prefs=self.experience.preferences
        row=line(self,pane);self.ttk.Label(row,text='Theme').pack(side='left');self.vars['theme']=self.tk.StringVar(value=prefs.theme)
        choice(self,row,self.vars['theme'],THEMES,self.preview)
        self.vars['accent_enabled']=self.tk.BooleanVar(value=prefs.accent_enabled)
        self.ttk.Checkbutton(pane,text='Use my custom accent',variable=self.vars['accent_enabled'],command=self.preview).pack(anchor='w')
        for key,title,maximum in (('accent_hue','Hue',360),('accent_saturation','Saturation',100),('accent_brightness','Brightness',100)):
            row=self.ttk.Frame(pane);row.pack(fill='x',pady=5);row.columnconfigure(1,weight=1)
            self.ttk.Label(row,text=title,width=15).grid(row=0,column=0,sticky='w')
            var=self.tk.IntVar(value=getattr(prefs,key));self.vars[key]=var
            self.ttk.Scale(row,from_=0,to=maximum,variable=var,command=lambda *_:self.guard(self.preview)).grid(row=0,column=1,sticky='ew',padx=8)
            self.ttk.Spinbox(row,from_=0,to=maximum,textvariable=var,width=6,command=lambda:self.guard(self.preview)).grid(row=0,column=2,sticky='e')
        row=line(self,pane)
        for title,h in (('Mint',162),('Purple',275),('Blue',210),('Rose',335),('Amber',40)):
            button(self,row,title,lambda value=h:self.preset(value))
        from text_scaling import FontScaleControl
        self.font_control=FontScaleControl(self.app,pane,prefs.font_percent,changed=lambda:self.guard(self.preview))
        row=line(self,pane)
        self.ttk.Label(row,text='Row height (0 = automatic)').pack(side='left');self.vars['row_height']=self.tk.IntVar(value=prefs.row_height)
        choice(self,row,self.vars['row_height'],(0,28,36,44,56,72,96),self.preview,width=7)
        self.vars['bold_text']=self.tk.BooleanVar(value=prefs.bold_text)
        self.ttk.Checkbutton(pane,text='Stronger body text',variable=self.vars['bold_text'],command=self.preview).pack(anchor='w')
        self.vars['rounded_controls']=self.tk.BooleanVar(value=prefs.rounded_controls)
        self.ttk.Checkbutton(pane,text='Rounded buttons and text fields',variable=self.vars['rounded_controls'],command=self.preview).pack(anchor='w')
        row=line(self,pane);button(self,row,'Choose background image…',self.choose_background);button(self,row,'Remove background image',self.remove_background)
        self.background_status=self.tk.StringVar(value='PNG wallpapers work without Pillow. JPEG/WebP need Pillow. Images stay on this device; choosing or removing one takes effect immediately.')
        self.ttk.Label(pane,textvariable=self.background_status,wraplength=850).pack(anchor='w')
        row=self.ttk.Frame(pane);row.pack(fill='x',pady=5);row.columnconfigure(1,weight=1)
        self.ttk.Label(row,text='Image opacity %',width=15).grid(row=0,column=0,sticky='w')
        self.vars['background_opacity']=self.tk.StringVar(value=str(prefs.background_opacity))
        self.background_slider=self.tk.StringVar(value=str(prefs.background_opacity))
        self.ttk.Scale(row,from_=0,to=100,variable=self.background_slider,command=self.slider_opacity).grid(row=0,column=1,sticky='ew',padx=8)
        self.ttk.Spinbox(row,from_=0,to=100,textvariable=self.vars['background_opacity'],width=6,command=lambda:self.guard(self.preview)).grid(row=0,column=2,sticky='e')
        self.canvas=self.tk.Canvas(pane,height=170,highlightthickness=1);self.canvas.pack(fill='x',pady=12)
        self.vars['background_opacity'].trace_add('write',lambda *_:self.guard(self.opacity_changed))
        self.canvas.bind('<Configure>',lambda _:self.guard(self.preview))
        self.explain(pane,'Preview colors and opacity, then Apply. Background images appear in the shell banner and margins; content panels keep their readable surfaces. High contrast disables image and rounded decoration. Scale, focus, motion and large controls remain in Accessibility. Portable profiles include opacity and rounding, but no image or source path.')
        row=line(self,pane);button(self,row,'Apply appearance',self.apply);button(self,row,'Undo last change',self.revert)
        button(self,row,'Reset appearance',self.reset_appearance);button(self,row,'Accessibility…',lambda:self.shell.show('Accessibility'))

    def candidate(self):
        values={k:v.get() for k,v in self.vars.items()}
        values['font_scale']=self.font_control.get()
        try:
            raw=str(values['background_opacity']).strip()
            if not raw.isascii() or not raw.isdigit():raise ValueError()
            values['background_opacity']=int(raw)
        except (ValueError,TypeError):raise ValueError('Image opacity must be a whole percentage from 0 to 100.') from None
        return self.experience.preferences.changed(**values)

    def opacity_changed(self):
        # Invalid intermediate typing leaves the last valid preview intact.
        value=self.candidate().background_opacity
        self.background_slider.set(str(value));self.preview()

    def slider_opacity(self,value):
        value=str(round(float(value)))
        if str(self.vars['background_opacity'].get())!=value:self.vars['background_opacity'].set(value)

    def tick(self):
        super().tick()
        from account_header import private
        hidden=private(self.app)
        if hidden:
            self.cancel();self.preview_asset=None;self.preview_image=None;self.preview_photo=None;self.canvas.delete('all')
        elif getattr(self,'background_hidden',False):self.preview()
        self.background_hidden=hidden

    def preview(self):
        if not hasattr(self,'canvas'):return
        from account_header import private
        if private(self.app):self.canvas.delete('all');return
        prefs=self.candidate();bg,panel,text,muted,accent=palette(prefs,self.app._base_theme_colors)
        from tkinter import font as tkfont
        factor=prefs.font_percent/100;height=round(170*factor)
        c=self.canvas;c.configure(background=bg,height=height);c.delete('all');width=max(440,c.winfo_width())
        if prefs.contrast=='Default':
            from desktop_appearance import KEY,load,composite,photo_image
            value=self.shell.store.option(KEY)
            if value!=getattr(self,'preview_asset',None):
                self.preview_asset=value;self.preview_image=None
                try:self.preview_image=load(self.shell.store)
                except (ImportError,OSError,ValueError):pass
            if getattr(self,'preview_image',None) is not None:
                self.preview_photo=photo_image(composite(self.preview_image,(min(width,4096),min(height,2160)),bg,prefs.background_opacity),master=self.app.root)
                c.create_image(0,0,anchor='nw',image=self.preview_photo)
        background=c.create_rectangle(12,12,width-12,height-12,fill=panel,outline=accent,width=2)
        size=round(12*factor);weight='bold' if prefs.bold_text else 'normal';family=tkfont.nametofont('TkDefaultFont').actual('family')
        y=24
        for title,color,font in (('Preview · Selected tab',accent,(family,size,'bold')),
                                  ('Readable text, selected rows and keyboard focus',text,(family,size,weight)),
                                  ('Warning: review before continuing',text,(family,round(11*factor),'bold'))):
            item=c.create_text(28,y,text=title,fill=color,anchor='nw',font=font,width=width-60)
            bounds=c.bbox(item)
            y=(bounds[3] if bounds else y+size*2)+24
        c.configure(height=max(height,y));c.coords(background,12,12,width-12,max(height,y)-12)
        self.status.set('Preview only · accent '+accent+' · text contrast '+f'{min(contrast(accent,bg),contrast(accent,panel)):.1f}:1')

    def preset(self,hue):
        for k,v in dict(accent_hue=hue,accent_saturation=65,accent_brightness=85,accent_enabled=True).items():self.vars[k].set(v)
        self.preview()

    def background_guard(self,token):
        from dashboard_actions import context
        from account_header import private
        if self.closed or self.app.demo or getattr(self.app,'safe_mode',False) or private(self.app) or context(self.app)!=token:
            raise ValueError('The workspace changed or is read-only. Choose the image again after revealing it.')

    def choose_background(self):
        from tkinter import filedialog
        from dashboard_actions import context
        from desktop_appearance import KEY,decode,install
        token=context(self.app);self.background_guard(token);expected=self.shell.store.option(KEY)
        path=filedialog.askopenfilename(parent=self.app.root,title='Choose a local background image',filetypes=[('PNG — no extra package needed','*.png'),('JPEG/WebP — Pillow support','*.jpg *.jpeg *.webp')])
        self.background_guard(token)
        if not path:return
        def done(data):
            install(self.shell.store,data,expected=expected,guard=lambda:self.background_guard(token))
            if getattr(self.app,'backdrop',None):self.app.backdrop.apply(self.experience.preferences)
            self.preview_asset=None;self.preview();self.background_status.set('Saved a local image copy. The original file can be moved; opacity changes need Apply.')
        self.start(lambda c,s,p:decode(path),done,api=False)

    def remove_background(self):
        from dashboard_actions import context
        from desktop_appearance import KEY,asset_path
        token=context(self.app);self.background_guard(token);old=self.shell.store.option(KEY)
        self.shell.store.set_option(KEY,None,expected=old)
        if old:
            try:asset_path(self.shell.store,old).unlink(missing_ok=True)
            except (ValueError,OSError):pass
        self.preview_asset=None;self.preview_image=None;self.preview()
        if getattr(self.app,'backdrop',None):self.app.backdrop.apply(self.experience.preferences)
        self.background_status.set('Background image removed from this profile.')

    def apply_values(self,changes,reason):
        self.fresh()
        from desktop_health import available
        if changes.get('rounded_controls') and not self.experience.preferences.rounded_controls and not available('PIL'):raise ValueError('Install Pillow to use rounded decorations. Open Settings → Setup health for dependency details.')
        self.experience.preferences.changed(**changes)
        self.undo={k:getattr(self.experience.preferences,k) for k in APPEARANCE}
        self.experience.change(**changes)
        self.state=save(self.app,self.state,reason,expected=self.loaded_state);self.sync();self.refresh();self.status.set(reason)

    def apply(self):
        candidate=self.candidate()
        self.apply_values({k:getattr(candidate,k) for k in (*self.vars,'font_scale')},'Appearance applied')
    def sync(self):
        for k,v in self.vars.items():v.set(getattr(self.experience.preferences,k))
        self.font_control.set(self.experience.preferences.font_percent)
        self.preview()
    def revert(self):
        if self.undo is None:raise ValueError('No appearance change to undo in this session.')
        value=self.undo;self.apply_values(value,'Previous appearance restored')
    def reset_appearance(self):self.apply_values({k:getattr(Presentation(),k) for k in APPEARANCE},'Appearance reset')

    def build_home(self):
        pane=self.frames['Home layout'];row=line(self,pane)
        self.layout=self.tk.StringVar(value=self.state['active']);self.layout_choice=choice(self,row,self.layout,tuple(self.state['layouts']),self.switch_layout)
        button(self,row,'New / copy layout…',self.new_layout);button(self,row,'Delete layout',self.delete_layout)
        self.widgets=Table(self,pane,(('title','Widget',230),('size','Size',100),('pinned','Pinned',70),('closed','Collapsed',80)),height=8,select=self.selected_widget)
        row=line(self,pane);self.kind=self.tk.StringVar(value='Session');choice(self,row,self.kind,tuple(WIDGETS.values()))
        button(self,row,'Add widget',self.add_widget);button(self,row,'Duplicate selected',self.duplicate_widget)
        row=line(self,pane);button(self,row,'Move up',lambda:self.move(-1));button(self,row,'Move down',lambda:self.move(1));button(self,row,'Hide selected',self.remove_widget)
        button(self,row,'Show selected',self.show_widget)
        self.explain(pane,'Use the visible layout lock to enable editing. Hide removes a tile from Home without deleting its settings or notes. Hidden tiles remain listed here and can be shown again.')
        self.size=self.tk.StringVar(value='Standard');self.pinned=self.tk.BooleanVar();self.collapsed=self.tk.BooleanVar()
        row=line(self,pane);choice(self,row,self.size,('Compact','Standard','Wide'))
        self.ttk.Checkbutton(row,text='Pin near top',variable=self.pinned).pack(side='left')
        self.ttk.Checkbutton(row,text='Collapse content',variable=self.collapsed).pack(side='left')
        self.widget_filter=self.tk.StringVar();self.widget_columns=self.tk.StringVar()
        row=line(self,pane);self.ttk.Label(row,text='Widget filter').pack(side='left');entry(self,row,self.widget_filter,28)
        self.ttk.Label(row,text='Columns (name,type,time,status,source,freshness)').pack(side='left');entry(self,row,self.widget_columns,30)
        self.widget_sort=self.tk.StringVar(value='time');self.widget_descending=self.tk.BooleanVar(value=True)
        row=line(self,pane);self.ttk.Label(row,text='Sort rows by').pack(side='left')
        choice(self,row,self.widget_sort,('name','type','time','status','source','freshness'),width=14)
        self.ttk.Checkbutton(row,text='Descending',variable=self.widget_descending).pack(side='left')
        from dashboard_conditions import CONDITIONS
        self.widget_when=self.tk.StringVar(value='Always');row=line(self,pane)
        self.ttk.Label(row,text='Show widget when').pack(side='left');choice(self,row,self.widget_when,CONDITIONS,width=24)
        from dashboard_condition_picker import ConditionPicker
        self.widget_picker=ConditionPicker(self,pane,self.widget_when)
        button(self,line(self,pane),'Apply widget settings and visibility',self.edit_widget)
        row=line(self,pane);button(self,row,'Open Home',lambda:self.shell.show('Home'));button(self,row,'Reset Home layout',self.reset_home)
        self.explain(pane,'Reorder with the Move buttons. Duplicate cards reuse the existing data source. Notes stay with their account and are excluded from layout exports.')

    def rows(self):return self.state['layouts'][self.state['active']]
    def selected_widget(self):
        row=self.widgets.selected()
        if row:
            self.size.set(row['size']);self.pinned.set(row['pinned']);self.collapsed.set(row['collapsed'])
            self.widget_filter.set(row.get('filter',''));self.widget_columns.set(','.join(row.get('columns',[])))
            self.widget_sort.set(row.get('sort','time'));self.widget_descending.set(row.get('descending',True))
            self.widget_picker.set(row.get('when','Always'))
    def selected_row(self):
        row=self.widgets.selected()
        if not row:raise ValueError('Select a widget first.')
        return next(r for r in self.rows() if r['id']==row['id'])
    def fresh(self):
        if hasattr(self,'loaded_state') and load(self.app)!=self.loaded_state:
            self.state=load(self.app);self.refresh()
            raise ValueError('Settings changed in another editor. Current values were reloaded; repeat the edit.')
    def commit(self,reason):
        try:
            if reason.startswith(('Home widget','Home layouts','Home layout removed','Current Home layout','Created Home layout')):
                from layout_edit import require_unlocked
                require_unlocked(self.app)
            self.fresh();self.state=save(self.app,self.state,reason,expected=self.loaded_state)
        except ValueError:
            self.state=load(self.app);self.refresh();raise
        self.refresh();self.status.set(reason)
    def switch_layout(self):self.state['active']=self.layout.get();self.commit('Home layout selected: '+self.layout.get())
    def new_layout(self):
        from tkinter import simpledialog
        name=simpledialog.askstring('New Home layout','Layout name',parent=self.app.root)
        if name is None:return
        name=label(name)
        if name in self.state['layouts']:raise ValueError('That layout name already exists.')
        if len(self.state['layouts'])>=12:raise ValueError('Remove an old layout before adding another.')
        self.state['layouts'][name]=deepcopy(self.rows());self.state['active']=name;self.commit('Created Home layout: '+name)
    def delete_layout(self):
        if len(self.state['layouts'])<2:raise ValueError('Keep at least one Home layout.')
        from dashboard_conditions import forget_layout
        forget_layout(self.state,self.state['active'])
        del self.state['layouts'][self.state['active']];self.state['active']=next(iter(self.state['layouts']));self.commit('Home layout removed')
    def add_widget(self):
        if len(self.rows())>=30:raise ValueError('This layout already has 30 widgets.')
        self.rows().append(widget(next(k for k,v in WIDGETS.items() if v==self.kind.get())));self.commit('Home widget added')
    def duplicate_widget(self):
        row=self.selected_row()
        if len(self.rows())>=30:raise ValueError('This layout already has 30 widgets.')
        self.rows().append(dict(row,id=__import__('uuid').uuid4().hex));self.commit('Home widget duplicated')
    def move(self,direction):
        row=self.selected_row();rows=self.rows();old=rows.index(row);new=max(0,min(len(rows)-1,old+direction))
        rows.insert(new,rows.pop(old));self.commit('Home widget moved')
    def remove_widget(self):self.selected_row()['hidden']=True;self.commit('Home widget hidden')
    def show_widget(self):self.selected_row()['hidden']=False;self.commit('Home widget shown')
    def edit_widget(self):
        columns=[v.strip() for v in self.widget_columns.get().split(',') if v.strip()]
        if len(self.widget_filter.get())>256 or any(v not in ('name','type','time','status','source','freshness') for v in columns):raise ValueError('Use a filter up to 256 characters and the listed column names.')
        if len(columns)!=len(set(columns)):raise ValueError('Choose each column once.')
        self.selected_row().update(size=self.size.get(),span=0,pinned=self.pinned.get(),collapsed=self.collapsed.get(),filter=self.widget_filter.get(),columns=columns,sort=self.widget_sort.get(),descending=self.widget_descending.get(),when=self.widget_picker.get());self.commit('Home widget settings changed')
    def reset_home(self):self.state['layouts'][self.state['active']]=defaults()['layouts']['Everyday'];self.commit('Current Home layout reset')

    def build_profiles(self):
        pane=self.frames['Profiles & sharing'];row=line(self,pane);self.profile=self.tk.StringVar()
        self.profile_choice=choice(self,row,self.profile,());button(self,row,'Apply selected profile',self.apply_profile)
        row=line(self,pane);button(self,row,'Save current appearance as…',self.save_profile);button(self,row,'Remove selected profile',self.delete_profile)
        row=line(self,pane);button(self,row,'Export appearance…',lambda:self.export(False));button(self,row,'Import appearance…',lambda:self.import_file(False))
        row=line(self,pane);button(self,row,'Export Home layouts…',lambda:self.export(True));button(self,row,'Import Home layouts…',lambda:self.import_file(True))
        self.explain(pane,'Appearance profiles preserve your preferred colors, typography and accessibility. Layout files contain card placement and settings. Accounts, passwords, sessions, notes, paths and connection permissions are never included.')
    def save_profile(self):
        from tkinter import simpledialog
        name=simpledialog.askstring('Save appearance profile','Profile name',parent=self.app.root)
        if name is None:return
        name=label(name)
        if name in self.state['profiles']:raise ValueError('That profile name already exists.')
        if len(self.state['profiles'])>=20:raise ValueError('Remove an old profile before adding another.')
        self.state['profiles'][name]={k:getattr(self.experience.preferences,k) for k in APPEARANCE};self.profile.set(name);self.commit('Saved appearance profile: '+name)
    def apply_profile(self):
        changes=self.state['profiles'].get(self.profile.get())
        if changes is None:raise ValueError('Select a saved profile.')
        self.apply_values(changes,'Applied appearance profile: '+self.profile.get())
    def delete_profile(self):
        if self.profile.get() not in self.state['profiles']:raise ValueError('Select a saved profile.')
        del self.state['profiles'][self.profile.get()];self.profile.set('');self.commit('Appearance profile removed')
    def export(self,layouts):
        from tkinter import filedialog
        path=filedialog.asksaveasfilename(parent=self.app.root,defaultextension='.json',initialfile='VRC-Eye-Home-Layouts.json' if layouts else 'VRC-Eye-Appearance.json')
        if not path:return
        value=(dict(schema=1,active=self.state['active'],layouts=self.state['layouts'],profiles={},history=[],conditions=self.state.get('conditions',__import__('dashboard_conditions').defaults())) if layouts else theme_document(self.experience.preferences))
        with Path(path).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2)
        self.status.set('Settings exported')
    def import_file(self,layouts):
        from tkinter import filedialog
        path=filedialog.askopenfilename(parent=self.app.root,filetypes=[('Settings JSON','*.json')])
        if not path:return
        raw=read_document(path);value=validate(raw) if layouts else parse_theme(raw)
        if not review_document(self.app,'Review imported '+('Home layouts' if layouts else 'appearance'),json.dumps(value,indent=2)+'\n\nOnly these presentation settings will change.',accept='Apply'):return
        if layouts:
            self.state.update(active=value['active'],layouts=value['layouts'],conditions=value.get('conditions',__import__('dashboard_conditions').defaults()));self.commit('Home layouts imported')
        else:self.apply_values(value,'Appearance imported')
    def refresh(self):
        self.loaded_state=deepcopy(self.state)
        self.layout.set(self.state['active']);self.layout_choice.configure(values=tuple(self.state['layouts']))
        self.widgets.set(self.rows(),lambda r:(WIDGETS.get(r['kind'],'Unavailable: '+r['kind'])+(' · Hidden' if r.get('hidden',False) else ''),str(r.get('span'))+' columns' if r.get('span') else r['size'],'Yes' if r['pinned'] else 'No','Yes' if r['collapsed'] else 'No'))
        self.profile_choice.configure(values=tuple(self.state['profiles']))
        self.history.set('\n'.join(reversed(self.state['history'])) or 'No customization changes recorded.')
        if hasattr(self,'rules'):self.refresh_conditions()

    def build_conditions(self):
        from dashboard_conditions import CONDITIONS
        pane=self.frames['Profiles & sharing'];self.explain(pane,'Conditional Home profiles use existing observations only. The first enabled matching rule wins. Online mode means VRC Eye is not set to Offline; it does not prove network reachability. A manual override stays selected until resumed.')
        self.auto_home=self.tk.BooleanVar();row=line(self,pane)
        self.ttk.Checkbutton(row,text='Enable automatic Home layout rules',variable=self.auto_home).pack(side='left')
        button(self,row,'Apply automatic mode',self.apply_auto)
        self.rules=Table(self,pane,(('name','Rule',180),('layout','Layout',180),('when','When',170),('enabled','Enabled',70)),height=6,select=self.select_rule)
        self.rule_name=self.tk.StringVar();self.rule_layout=self.tk.StringVar(value=self.state['active']);self.rule_when=self.tk.StringVar(value='Always');self.rule_enabled=self.tk.BooleanVar(value=True)
        row=line(self,pane);self.ttk.Label(row,text='Rule name').pack(side='left');entry(self,row,self.rule_name,22)
        self.rule_layout_choice=choice(self,row,self.rule_layout,tuple(self.state['layouts']),width=20)
        choice(self,row,self.rule_when,CONDITIONS,width=24)
        self.ttk.Checkbutton(row,text='Enabled',variable=self.rule_enabled).pack(side='left')
        from dashboard_condition_picker import ConditionPicker
        self.rule_picker=ConditionPicker(self,pane,self.rule_when)
        row=line(self,pane);button(self,row,'Add rule',lambda:self.save_rule(False));button(self,row,'Update selected rule',lambda:self.save_rule(True))
        button(self,row,'Move rule up',lambda:self.move_rule(-1));button(self,row,'Move rule down',lambda:self.move_rule(1));button(self,row,'Remove rule',self.remove_rule)
        row=line(self,pane);button(self,row,'Hold current edited layout',self.hold_layout);button(self,row,'Resume automatic selection',self.resume_auto)

    def conditions(self):
        from dashboard_conditions import defaults
        return self.state.setdefault('conditions',defaults())

    def refresh_conditions(self):
        from dashboard_conditions import defaults,describe
        value=self.state.get('conditions',defaults());self.auto_home.set(value['enabled'])
        self.rules.set(value['rules'],lambda r:(r['name'],r['layout'],describe(r['when']),'Yes' if r['enabled'] else 'No'),identity=lambda r:r['id'])
        self.rule_layout_choice.configure(values=tuple(self.state['layouts']))
        if self.rule_layout.get() not in self.state['layouts']:self.rule_layout.set(self.state['active'])

    def select_rule(self):
        row=self.rules.selected()
        if row:
            self.rule_name.set(row['name']);self.rule_layout.set(row['layout']);self.rule_picker.set(row['when']);self.rule_enabled.set(row['enabled'])

    def apply_auto(self):self.conditions()['enabled']=self.auto_home.get();self.commit('Automatic Home selection updated')
    def hold_layout(self):self.conditions()['override']=self.state['active'];self.commit('Manual Home layout held until resumed')
    def resume_auto(self):self.conditions()['override']='';self.commit('Manual Home override cleared')

    def save_rule(self,update):
        chosen=self.rules.selected() if update else None
        if update and not chosen:raise ValueError('Select a Home rule first.')
        rows=self.conditions()['rules']
        row=dict(id=chosen['id'] if chosen else __import__('uuid').uuid4().hex,name=label(self.rule_name.get()),layout=self.rule_layout.get(),when=self.rule_picker.get(),enabled=self.rule_enabled.get())
        if chosen:rows[ next(i for i,r in enumerate(rows) if r['id']==chosen['id']) ]=row
        else:rows.append(row)
        self.commit('Home rule saved')

    def move_rule(self,direction):
        chosen=self.rules.selected()
        if not chosen:raise ValueError('Select a Home rule first.')
        rows=self.conditions()['rules'];old=next(i for i,r in enumerate(rows) if r['id']==chosen['id'])
        rows.insert(max(0,min(len(rows)-1,old+direction)),rows.pop(old));self.commit('Home rule priority changed')

    def remove_rule(self):
        chosen=self.rules.selected()
        if not chosen:raise ValueError('Select a Home rule first.')
        self.conditions()['rules']=[r for r in self.conditions()['rules'] if r['id']!=chosen['id']];self.commit('Home rule removed')
