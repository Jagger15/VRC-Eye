# ARC-03 — authorized FBX import and inspection

Status: **partial, experimental Linux import**. ASCII and binary FBX now reach the existing local scene viewer through a compiled, memory-only adapter. Windows containment, graphical desktop acceptance and a broader creator/exporter fixture matrix remain open. This is an unreleased source checkpoint; the build identity remains `2026.05.10.02.47.1` and compatibility version `1.21.0`.

## Setup and use

1. In the same Python environment used to run Eye, explicitly build the optional adapter from the project root: `python -m pip install ./native/fbx`. A C compiler and the matching Python development headers are required. If Python's configured compiler is unavailable, select an installed compiler explicitly, for example `CC=gcc python -m pip install ./native/fbx` on Linux. Eye does not install or download this adapter when opening preview.
2. Linux must support the existing `libseccomp.so.2` scene-worker policy. No weaker FBX mode is enabled on other platforms.
3. Select an avatar, open its 3D preview, then choose **Choose authorized FBX…**. Select only an FBX you own or have permission to inspect.
4. Optionally select up to 16 PNG/JPEG files. Cancel this second picker to use only embedded textures. External references bind only to exact, case-sensitive, plain filenames. References containing directories, drive names, traversal or URLs remain blocked. Ambiguous selected names, including case collisions, are rejected. Existing sibling files are never discovered automatically.
5. Review the selected-input permission prompt. The viewer shows hierarchy and static stored-pose geometry; the report lists units, axes, rigs, morphs, takes and dependency hashes. Source FBX and image files remain unchanged.

## Implemented coverage

| Area | Current behavior |
| --- | --- |
| Parser | Vendored ufbx **0.23.1**, commit `26a482ae66871d7de36eb722aa060bce95bce274`, through Eye adapter ABI 2 (ARC-06; the original ARC-03 evidence records ABI 1). Header and source versions are checked. Source hashes and MIT license are preserved in `native/fbx/UPSTREAM.json` and `LICENSE`. |
| File formats | Bounded ASCII and binary FBX, including compressed binary arrays and 32/64-bit node headers. File-format selection is forced to FBX. Actual regression fixtures cover 6100, 7400, 7500 and 7700; this does not qualify every producer/version the underlying parser accepts. |
| Hierarchy and transforms | Native hierarchy, parented/nonuniform transforms and geometric transforms. Convert once at the root to meters, right-handed Y-up. Report original parser-reported units and axes; importer defaults apply when declarations are absent. |
| Geometry | Polygon triangulation, mesh instances and material assignments. Expanded polygon corners preserve UV seams. Curves/NURBS/procedural geometry, vertex caches, point/line faces and oversized polygons are explicitly refused. Subdivision requests are reported but not evaluated. |
| Rig and morph availability | Report bone-attribute, skin-deformer, blend-channel and target counts separately per mesh. The native parser evaluates the default stored deformation into a static snapshot. No manual FBX rig controls, retargeting, blendshape sliders or constraints. ARC-06 adds explicitly prepared take playback. Instanced skinned meshes are refused because one evaluated world pose cannot safely stand in for all instances. |
| Takes | List each stack's name, start/end seconds and layer count, plus source frame rate. No take autoplays. [ARC-06](ARC06_ANIMATION_PREVIEW.md) now prepares bounded take ranges for playback. |
| Appearance | Unlit diffuse color/factor and PNG/JPEG diffuse textures. Embedded or explicitly selected bytes only; UV0 and the declared UV-to-texture transform, repeat/clamp wrapping. Texture references needing another UV set or unsupported formats/layers remain listed and unrendered. PBR/shader fidelity, transparency, vertex colors and normal/tangent mapping are outside this subset. |
| Dependencies | Embedded/selected/missing/blocked/unused state, byte length and SHA-256 for available texture data, with whether it contributes to diffuse preview. Selected-byte evidence is checked by the parent against the actual input snapshot. Path labels are reduced for display and are never opened by the parser. |
| Diagnostics | Source SHA-256, native warning types/counts, source mesh/rig/take availability, omitted effects, and coverage notices. Mesh-health calculations apply to expanded corner indices; they do not establish original shared-vertex topology or source normal/tangent health. |
| Context lifecycle | Account, avatar, privacy, Safe Mode, close and modal-dialog changes invalidate work. A late worker result cannot repopulate a stale preview. Existing cancellation, timeout, output and child-reaping behavior is reused. |

All mesh instances are shown, including source-hidden meshes. No visible mesh is invented for malformed or unsupported input. Opening the panel alone does not parse a file. No Unity editor, project scripts, FBX SDK, exporter, cache decryption or network fetch runs.

## Containment and budgets

The parent opens only explicitly selected regular files using the existing checked-stream rules. It sends an in-memory input set through pipes. Neither full source paths nor application credentials are passed to the worker. The native adapter and PNG/JPEG decoder are imported before containment; model bytes are read only after the Linux policy is installed.

The adapter is built with `UFBX_NO_STDIO`, exposes only a byte-snapshot function, and supplies fixed options with external loading and cache evaluation disabled. Kernel policy independently denies file access, new descriptors, sockets and subprocesses. This is the existing Linux scene policy, not a general exporter sandbox. Version constants and hashes document the build; they are not publisher authentication of arbitrary installed binaries. The installed application/compiler/dependencies remain trusted bootstrap inputs.

- FBX: 32 MiB. Explicit textures: 16 files, 8 MiB each, 16 MiB total. Embedded texture payloads: 16 MiB total.
- Native parser: 256 MiB temporary allocator, 256 MiB result allocator; 100,000 allocations per allocator, depth 64. The worker additionally retains its existing 1 GiB address-space and 30-second CPU/parent wall-time limits.
- Scene: 512 nodes/mesh parts, 100,000 expanded corners/used instanced vertices, 30,000 triangles, 64 corners per polygon, 128 source materials/textures, 16,384 elements, 64 takes and 64 warning types.
- Preview images: 16 decoded diffuse textures, at most 4096 pixels per dimension, 4 megapixels per image, 8 megapixels total; thumbnails at most 256 pixels. The parent validates raw RGBA and the full scene protocol. Result transfer remains at most 24 MiB.

Large FBX scenes can exceed these limits even when their source file is small. This implementation does not reduce or rewrite the source to fit.

## Evidence and remaining acceptance

`validation/arc03-focused.xml` and the full regression evidence recorded in `PENDING_WORKING_VALIDATION.json → arc03_fbx_update` describe the executed tests. The optional adapter was actually compiled and loaded on this Linux x86-64 / CPython 3.12 host. No Windows or graphical desktop acceptance is claimed.

The 70 new tests cover independently generated ASCII/binary fixtures, compressed arrays, both header widths, units/axes/nonuniform/geometric transforms, static instancing, stored skins/blends, embedded and selected texture pixels, hostile/missing references, malformed bytes and protocol reports, selected-file framing, permissions/cancellation/platform gates, stale UI completions, and kernel denial after native bootstrap. Eight unmodified upstream Blender/Maya test fixtures also pass through the actual contained worker. Their exact origin, hashes and license are in `tests/fixtures/fbx_arc03/PROVENANCE.json`; they are upstream test assets, not a claim of qualification against users' VRChat projects.

The initial source adapter already passes the focused tests. Remaining work includes Windows filesystem/network/process containment and packaging, graphical controls/accessibility/renderer acceptance on both supported desktops, more independently referenced creator/exporter and malformed-input cases, and fidelity improvements beyond the declared subset. Interactive FBX rig/morph controls remain future work. ARC-06 now adds bounded take playback; see its separate evidence and limits. ARC-03 remains partial.

Primary technical references: [ufbx node/space conversion](https://ufbx.github.io/elements/nodes/), [ufbx API reference](https://ufbx.github.io/reference), [pinned source](https://github.com/ufbx/ufbx/tree/26a482ae66871d7de36eb722aa060bce95bce274). The older `ufbx` Python wheel is not the adapter used by Eye.
