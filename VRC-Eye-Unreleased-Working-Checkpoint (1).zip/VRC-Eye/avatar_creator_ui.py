"""Lazy, local-first Avatar Creator tabs for Primary → Avatars.

The desktop panel owns no socket, provider, or automatic writer. Live actions go
through the controller's reviewed, context-bound service operations.
"""
from __future__ import annotations

import json
import queue
import threading
import time
import uuid
from pathlib import Path

from creator_ui import CreatorPanel, display_record

TABS = ("Library", "Creator", "Modules", "Avatar Link", "Parameters", "Preview", "Tests", "Diagnostics", "Profiles", "History")
STEP_STATUSES = ("Not started", "In progress", "Passed", "Failed", "Blocked", "Not applicable", "Needs verification")
PLATFORMS = ("Windows", "Android", "iOS", "Generic")


def readable(value):
    return json.dumps(value, ensure_ascii=False, indent=2, default=str) if isinstance(value, (dict, list, tuple)) else str(value if value is not None else "Unknown")


def parameter_value(definition, value):
    """Parse typed input; service validation remains the final authority."""
    value = str(value).strip()
    kind = definition.get("type", "")
    if kind == "Bool":
        if value.casefold() not in ("true", "false", "1", "0"):
            raise ValueError("A Bool value must be true or false.")
        return value.casefold() in ("true", "1")
    if kind == "Int":
        try:
            return int(value)
        except ValueError as error:
            raise ValueError("An Int value must be a whole number.") from error
    if kind == "Float":
        import math
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("A Float value must be finite.")
        return result
    raise ValueError("The selected parameter has no supported declared type.")


class AvatarCreatorPanel(CreatorPanel):
    """Borrow shared widget helpers while keeping an independent lifecycle."""
    def __init__(self, controller, notebook):
        self.controller, self.notebook = controller, notebook
        self.tk, self.ttk = controller.tk, controller.ttk
        self.pages, self.built, self.tables, self.table_rows = {}, set(), {}, {}
        self.inputs, self.forms, self.form_defaults = {}, {}, {}
        self.closed, self.workspace, self.active_tab = False, "", "Creator"
        self.last_refresh = 0.
        self.review = self.report_preview = self.module_plan = None
        self.run_id = self.profile_id = self.worksheet_id = None
        self.worksheet_key = ""
        self.composer_parts = []
        self.discovery_output = queue.Queue(maxsize=1)
        self.discovery_pending = False
        self.summary = self.tk.StringVar(value="Avatar Creator • local workspace")
        self.status = self.tk.StringVar(value="Private until you explicitly export or enable a reviewed output.")
        self.freeze = False
        for name in TABS:
            page = self.ttk.Frame(notebook, padding=10)
            self.pages[name] = page
            notebook.add(page, text=name)
            if name != "Library":
                self.ttk.Label(page, textvariable=self.summary, style="Accent.TLabel", wraplength=1050).pack(anchor="w", pady=(0, 6))
        notebook.bind("<<NotebookTabChanged>>", self.on_tab)

    def avatar(self):
        self.controller.refresh_context()
        avatar = self.controller.current_avatar()
        if not avatar:
            raise ValueError("Choose an avatar or create a local project in Creator first.")
        if avatar != self.workspace:
            self.refresh(force=True)
            raise ValueError("The avatar workspace changed. Review the current form before continuing.")
        return avatar

    def _guard(self):
        self.avatar()
        return (self.workspace, getattr(self.controller, "guard_token", None))

    def _check(self, guard):
        self.controller.refresh_context()
        if guard != (self.controller.current_avatar(), getattr(self.controller, "guard_token", None)):
            raise ValueError("Avatar, account, or connection context changed. Review this action again.")

    def _confirm(self, title, text, guard=None):
        from tkinter import messagebox
        guard = guard or self._guard()
        result = messagebox.askyesno(title, text)
        self._check(guard)
        return result

    def _form(self, parent, name, specifications):
        fields = {}
        self.form_defaults[name] = {}
        for spec in specifications:
            key, label, kind, *initial = spec
            default = initial[0] if initial else (kind[0] if isinstance(kind, (tuple, list)) and kind else "")
            fields[key] = self._field(parent, label, options=kind if isinstance(kind, (tuple, list)) else None,
                                      multiline=kind in ("multiline", "lines") if isinstance(kind, str) else False, value=str(default))
            self.form_defaults[name][key] = str(default)
        self.forms[name] = fields
        self._restore_form(name)
        return fields

    def _form_values(self, name):
        return {key: self._get(editor) for key, editor in self.forms.get(name, {}).items()}

    def _draft_records(self, avatar):
        return self.controller.store.list("ui_draft", avatar, limit=500) if avatar else []

    def _save_form(self, name, avatar=None):
        avatar = avatar or self.workspace
        if not avatar or name not in self.forms:
            return
        existing = next((r for r in self._draft_records(avatar) if r["data"].get("form") == name), None)
        data = {"form": name, "fields": self._form_values(name), "visibility": "private", "validated": False}
        if name == "composer":
            data["primitives"] = list(self.composer_parts)
        self.controller.store.save("ui_draft", avatar, data, existing["id"] if existing else None)

    def _restore_form(self, name):
        fields = self.forms.get(name, {})
        record = next((r for r in self._draft_records(self.workspace) if r["data"].get("form") == name), None)
        values = record["data"].get("fields", {}) if record else self.form_defaults.get(name, {})
        for key, editor in fields.items():
            self._set(editor, values.get(key, self.form_defaults.get(name, {}).get(key, "")))
        if name == "composer":
            self.composer_parts = list(record["data"].get("primitives", [])) if record else []

    def show(self, name):
        if self.closed or name not in self.pages:
            return
        self.active_tab = name
        if name not in self.built:
            content = self._scroll(self.pages[name])
            getattr(self, "build_" + name.lower().replace(" ", "_"))(content)
            if name != "Library":
                self.ttk.Label(self.pages[name], textvariable=self.status, style="Muted.TLabel", wraplength=1050).pack(anchor="w", pady=5)
            self.built.add(name)
        self.refresh(force=True)

    def refresh(self, force=False):
        if self.closed:
            return
        try:
            discovery_guard, discovery_result = self.discovery_output.get_nowait()
        except queue.Empty:
            pass
        else:
            self.discovery_pending = False
            if discovery_guard == (self.controller.current_avatar(), getattr(self.controller, "guard_token", None)) and "Avatar Link" in self.built:
                self._set(self.discovery_detail, readable(discovery_result), True)
                self.announce("Explicit local discovery completed. Discovery does not enable a route or establish authorship.")
        avatar = self.controller.current_avatar() or ""
        changed = avatar != self.workspace
        if changed:
            for name in tuple(self.forms):
                self._call(self._save_form, name)
            self.workspace = avatar
            self.review = self.report_preview = self.module_plan = None
            self.run_id = self.profile_id = self.worksheet_id = None
            self.freeze = False
            self.controller.active_run_id = None
            if "Avatar Link" in self.built:
                self.public_channels.set(False)
            if "Diagnostics" in self.built:
                self.route_simulated.set(False)
                self.obs_password.set("")
            for name in tuple(self.forms):
                self._restore_form(name)
            if "Tests" in self.built:
                self._rows("steps", ())
                self._set(self.step_detail, "Select a run in this avatar workspace.", True)
        context = self.controller.context or {}
        recognition = context.get("recognition", "Local workspace; authorship not established")
        manifest = self.manifest()
        self.summary.set(f"Avatar: {avatar or 'No workspace selected'}  |  {readable(recognition)}\n"
                         f"Build: {context.get('build_id') or 'Unknown'}  |  Platform: {context.get('platform') or 'Unknown'}  |  "
                         f"Manifest: {manifest.get('revision') or 'None'}")
        if not force and not changed and time.monotonic() - self.last_refresh < 2:
            return
        self.last_refresh = time.monotonic()
        if self.active_tab in self.built:
            callback = getattr(self, "refresh_" + self.active_tab.lower().replace(" ", "_"), None)
            if callback:
                self._call(callback)

    def manifest(self):
        return getattr(self.controller, "manifest", None) or {}

    def records(self, kind=None):
        return self.controller.store.list(kind, self.workspace, limit=500) if self.workspace else []

    def build_library(self, parent):
        if not hasattr(self.controller.app, "sidebar"):
            self._note(parent, "Avatar Library needs the initialized companion workspace; existing creator tools remain available.")
            return
        from avatar_library_ui import AvatarLibraryPage
        self.library_page = AvatarLibraryPage(self.controller, parent)

    def build_creator(self, parent):
        self._note(parent, "Creator tools work locally before an avatar is uploaded. Wearing an avatar, importing a creator manifest, and authorization to modify a Unity project are distinct states.")
        self.creator_fields = self._form(parent, "workspace", (("name", "Project / avatar name", "textline"), ("avatar_id", "Avatar or local project ID", "textline"),
            ("platform", "Workspace platform", PLATFORMS)))
        bar = self._bar(parent)
        self._button(bar, "Open / pin workspace", self.pin_workspace)
        self._button(bar, "New local project", self.new_project)
        self._button(bar, "Follow current avatar", self.follow_current)
        self._button(bar, "Use selected Activity avatar", lambda: self.controller.use_selected_avatar())
        self._button(self._bar(parent), "Set workspace platform", lambda: self.controller.select_platform(self.creator_fields["platform"].get()))
        bar = self._bar(parent)
        self._button(bar, "Import creator manifest…", self.import_manifest)
        self._button(bar, "Validate manifest", self.validate_manifest)
        self._button(bar, "Mark diagnostic bookmark", self.bookmark)
        self._button(bar, "Show creator overlay", lambda: self.controller.show_overlay())
        self._button(bar, "Hide creator overlay", lambda: self.controller.clear_overlay())
        self._note(parent, "Unity Toolkit source is included with this release. Select your avatar in Unity, review a module installation there, and export its manifest. This desktop workspace does not edit downloaded avatar assets.")
        self.note_fields = self._form(parent, "note", (("title", "Note / TODO title", "textline"), ("body", "Design note / next action", "multiline"),
            ("status", "Status", ("Note", "TODO", "In progress", "Done"))))
        self._button(self._bar(parent), "Save private note", self.save_note)
        self._table(parent, "notes", (("title", "Title", 260), ("status", "Status", 130), ("updated", "Updated", 160)), height=4)
        self.overview = self._text(parent, 8)
        self.validation_view = self._text(parent, 8)

    def refresh_creator(self):
        self._rows("notes", ((r["id"], (display_record(r), r["data"].get("status", "Note"), r["updated_at"])) for r in self.records("note")))
        self._set(self.overview, "Workspace context\n" + readable(self.controller.context or {}) + "\n\n" +
                  "Modules plans installations; Parameters separates declarations from observations; Preview is isolated simulation; Tests retains source, simulation, and runtime evidence separately. Profiles apply only through Avatar Link after review. History contains builds, release records, worksheets, and selected exports.", True)

    def pin_workspace(self):
        self.controller.set_workspace(self.creator_fields["avatar_id"].get().strip(), self.creator_fields["name"].get().strip())
        self.refresh(force=True)

    def new_project(self):
        identity = "local:" + str(uuid.uuid4())
        name = self.creator_fields["name"].get().strip() or "Untitled avatar project"
        self.controller.set_workspace(identity, name)
        self.refresh(force=True)
        self.creator_fields["avatar_id"].set(identity)
        self.creator_fields["name"].set(name)
        self.announce("Created a private local avatar project.")

    def follow_current(self):
        self.controller.follow_current_avatar()
        self.refresh(force=True)

    def import_manifest(self):
        from tkinter import filedialog
        guard = self._guard()
        path = filedialog.askopenfilename(title="Import authorized avatar manifest", filetypes=(("JSON manifest", "*.json"),))
        self._check(guard)
        if path:
            self.controller.import_manifest(path)
            self.refresh(force=True)
            self.announce("Manifest imported. Its declarations do not establish tested runtime operation.")

    def validate_manifest(self):
        from avatar_manifest import validate_manifest, parameter_budget
        self.avatar()
        if not self.manifest():
            raise ValueError("Import a creator-supplied manifest first.")
        result = {"findings": validate_manifest(self.manifest()), "budget": parameter_budget(self.manifest()),
                  "stage": self.manifest().get("stage", "source"), "runtime": "Not tested"}
        self.controller.store.save("validation", self.workspace, result)
        self._set(self.validation_view, readable(result), True)
        self.announce("Validation saved with its manifest stage. Runtime verification remains separate.")

    def save_note(self):
        values = {k: v.strip() for k, v in self._form_values("note").items()}
        if not values["title"]:
            raise ValueError("Enter a note title.")
        self.controller.store.save("note", self.avatar(), dict(values, visibility="private"))
        self._save_form("note")
        self.refresh_creator()
        self.announce("Private note saved.")

    def bookmark(self):
        self.avatar()
        self.controller.add_bookmark("Avatar Creator bookmark")
        self.announce("Local diagnostic bookmark created from available evidence.")

    def build_modules(self, parent):
        from avatar_creator_workflows import MODULE_CATALOG
        self._note(parent, "Plan a reversible installation for the creator-owned Unity project. Costs are estimates until generated-build evidence is imported. Runtime hiding does not remove build-time component cost.")
        self.module_names = {item["name"]: key for key, item in MODULE_CATALOG.items()}
        self.module_fields = self._form(parent, "module_plan", (("module", "Module", tuple(self.module_names)), ("platform", "Platform", PLATFORMS),
            ("tier", "Quality tier", ("minimal", "standard", "elaborate")), ("side", "Placement", ("Left", "Right", "Menu / desktop", "Custom anchor")),
            ("anchor", "Named attachment anchor", "textline"), ("accessibility", "Reach / target / motion notes", "multiline")))
        bar = self._bar(parent)
        self._button(bar, "Preview installation plan", self.preview_module_plan)
        self._button(bar, "Save local plan", self.save_module_plan)
        self._button(bar, "Export plan for Unity…", self.export_module_plan)
        self.module_detail = self._text(parent, 12)
        self._table(parent, "module_plans", (("module", "Module", 260), ("platform", "Platform", 110), ("tier", "Tier", 100), ("state", "State", 210)), height=5)
        from avatar_creator_workflows import PRIMITIVES, ACTION_IDS
        self._note(parent, "Compose a data-only module from finite primitives. Appearance and behavior remain separate; a recipe cannot execute scripts or gain new permissions.")
        self.composer_fields = self._form(parent, "composer", (("id", "Module identifier", "textline"), ("title", "Module title", "textline"),
            ("primitive", "Primitive", tuple(PRIMITIVES)), ("parameter", "Stable parameter name", "textline"),
            ("action", "Button request (optional)", ("", *ACTION_IDS)), ("neutral", "Neutral numeric value", "textline", "0"),
            ("timeout", "Timeout seconds", "textline", "5"), ("theme", "Appearance theme", "textline", "minimal")))
        bar = self._bar(parent)
        self._button(bar, "Add primitive to recipe", self.add_primitive)
        self._button(bar, "Save module recipe", self.save_recipe)
        self._button(bar, "Clear recipe primitives", self.clear_recipe)

    def preview_module_plan(self):
        self.avatar()
        values = self._form_values("module_plan")
        key = self.module_names[values["module"]]
        plan = self.controller.workflows.plan_modules([key], platform=values["platform"], tier=values["tier"])
        self.module_plan = {"plan": plan, "placement": values["side"], "anchor": values["anchor"], "accessibility": values["accessibility"], "module": key,
                            "title": values["module"], "platform": values["platform"], "tier": values["tier"], "state": "Planned; not installed", "avatar_id": self.workspace}
        self._set(self.module_detail, readable(self.module_plan), True)
        return self.module_plan

    def save_module_plan(self):
        result = self.preview_module_plan()
        self.controller.store.save("module_plan", self.avatar(), result)
        self._save_form("module_plan")
        self.refresh_modules()
        self.announce("Local plan saved. Review and installation happen in your Unity project.")

    def export_module_plan(self):
        self._export_json(self.preview_module_plan(), "avatar-module-plan.json", "Export module plan")

    def refresh_modules(self):
        self._rows("module_plans", ((r["id"], (display_record(r), r["data"].get("platform", ""), r["data"].get("tier", ""), r["data"].get("state", "Planned"))) for r in self.records("module_plan")))

    def add_primitive(self):
        self.avatar()
        fields = self._form_values("composer")
        if len(self.composer_parts) >= 32:
            raise ValueError("A recipe supports at most 32 finite primitives.")
        self.composer_parts.append({"type": fields["primitive"], "parameter": fields["parameter"].strip(), "label": fields["title"],
            "action": fields["action"], "neutral": float(fields["neutral"]), "timeout_seconds": float(fields["timeout"])})
        self._set(self.module_detail, readable(self.composer_parts), True)

    def clear_recipe(self):
        self.composer_parts = []
        self._set(self.module_detail, "New recipe. Add a primitive to begin.", True)

    def save_recipe(self):
        fields = self._form_values("composer")
        record = self.controller.workflows.compose_module(self.avatar(), {"id": fields["id"], "title": fields["title"], "version": "1.0.0",
            "platforms": [self.module_fields["platform"].get()], "primitives": list(self.composer_parts), "theme": fields["theme"]})
        self._set(self.module_detail, readable(record["data"]), True)
        self._save_form("composer")
        self.announce("Data-only module recipe saved locally. Review installation in Unity separately.")

    def build_avatar_link(self, parent):
        self._note(parent, "Avatar Link shares VRC Eye's OSC service. Transport settings and discovery are under VRC Eye → Networking → OSC Transport. Enable OSC in VRChat yourself, then attach here and review this avatar's declared contract.")
        self.link_fields = {}
        bar = self._bar(parent)
        self._button(bar, "Attach to shared OSC", self.connect_link)
        self._button(bar, "Detach Avatar Link", self.disconnect_link)
        self._button(bar, "OSC transport settings", lambda: self.controller.app.sidebar.show("Networking"))
        self._button(bar, "Inspect local OSC config…", self.inspect_osc_config)
        self._button(self._bar(parent), "OSC discovery and controls", self.show_shared_osc)
        self.discovery_detail = self._text(parent, 6)
        self.public_channels = self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(parent, text="Include deliberately public channels in this arming review", variable=self.public_channels).pack(anchor="w", pady=5)
        self._button(self._bar(parent), "Review and arm outputs…", self.arm_link)
        self._note(parent, "Sent, observed feedback, module acknowledgment, and destination completion are separate states. Local OSC alone is not authenticated proof of authorship or intent. Avatar/account changes suspend old writers and pending work.")
        self.link_status = self._text(parent, 11)
        self._table(parent, "requests", (("action", "Incoming request", 210), ("state", "State", 180), ("detail", "Origin / detail", 350)), height=5)
        self._button(self._bar(parent), "Review selected request…", self.review_incoming)
        bar = self._bar(parent)
        self._button(bar, "Request camera photo…", self.request_camera)
        self._button(bar, "Activate local protective mode…", self.activate_safety)
        self._button(bar, "Leave local protective mode", lambda: self.controller.leave_safety())
        self._note(parent, "Protective mode stops this companion's routes/effects and uses its existing local privacy/reminder controls. It does not change VRChat moderation settings or prove that remote avatar visuals disappeared.")

    def inspect_osc_config(self):
        from tkinter import filedialog
        from avatar_osc import read_config
        guard = self._guard()
        path = filedialog.askopenfilename(title="Inspect explicitly selected OSC configuration", filetypes=(("OSC configuration", "*.json"),))
        self._check(guard)
        if path:
            source = Path(path)
            if source.stat().st_size > 1024 * 1024:
                raise ValueError("Choose an OSC configuration smaller than 1 MiB.")
            result = read_config(source.read_bytes())
            self._set(self.discovery_detail, readable(result) + "\n\nConfiguration discovery only; routes and Avatar Link permissions were not changed.", True)

    def inspect_oscquery(self):
        from avatar_osc import query_endpoint
        guard = self._guard()
        port = int(self.query_port.get())
        if not 1 <= port <= 65535:
            raise ValueError("Use a local OSCQuery port between 1 and 65535.")
        if self.discovery_pending:
            raise ValueError("One local discovery request is already in progress.")
        self.discovery_pending = True
        def worker():
            try:
                result = query_endpoint(f"http://127.0.0.1:{port}/")
            except (OSError, ValueError) as error:
                result = {"error": str(error), "source": "Explicit local OSCQuery inspection"}
            try:
                self.discovery_output.put_nowait((guard, result))
            except queue.Full:
                pass
        threading.Thread(target=worker, name="VRC-Eye-Avatar-Discovery", daemon=True).start()
        self.announce("Inspecting the chosen loopback OSCQuery endpoint. No ports or routes are changed.")

    def request_camera(self):
        guard = self._guard()
        if self._confirm("Request camera photo", "Send one local photo request to the armed VRChat camera route? The request may not provide completion feedback.", guard):
            self._set(self.link_status, readable(self.controller.request_camera()), True)

    def activate_safety(self):
        guard = self._guard()
        if self._confirm("Activate local protective mode", "Stop Avatar Link, provider effects, companion overlays, and Eye-to-Eye sharing; defer existing wellness reminders? This does not change VRChat moderation settings.", guard):
            self._set(self.link_status, readable(self.controller.activate_safety()), True)

    def _link_snapshot(self):
        link = getattr(self.controller, "link", None)
        snapshot = getattr(link, "snapshot", None)
        return snapshot() if callable(snapshot) else {"state": "Unavailable"}

    def refresh_avatar_link(self):
        snapshot = self._link_snapshot()
        self._set(self.link_status, readable(snapshot), True)
        requests = self.controller.pending_requests()
        self._rows("requests", ((str(r.get("id", i)), (r.get("action", "Request"), r.get("state", r.get("status", "Needs local review")), r.get("parameter", r.get("source", "Local OSC; unverified origin")))) for i, r in enumerate(requests)))

    def connect_link(self):
        self.avatar()
        self.controller.connect_link()
        self.public_channels.set(False)
        self.refresh_avatar_link()
        self.announce("Local OSC connection requested. Review the current contract before arming outputs.")

    def show_shared_osc(self):
        shared = getattr(self.controller.app, "osc_controller", None)
        if shared is None:
            raise ValueError("Shared OSC controls are unavailable in this test or standalone host.")
        shared.show_controls()

    def disconnect_link(self):
        self.controller.disconnect_link()
        self.review = None
        self.public_channels.set(False)
        self.refresh_avatar_link()

    def arm_link(self):
        guard = self._guard()
        public = bool(self.public_channels.get())
        review = self.controller.review_arm(public=public)
        channels = [p.get("name", "") for p in self.manifest().get("parameters", []) if p.get("direction") == "in" and (public or p.get("privacy") != "public")]
        if self._confirm("Arm Avatar Link", "Allow reviewed output for the current avatar contract?\n\n" + "\n".join(channels) +
                         ("\n\nPublic channels can be visible to other participants." if public else "\n\nPublic channels remain disabled."), guard):
            self.controller.arm_link(public=public, review=review)
            self.refresh_avatar_link()
            self.announce("Arming request completed; inspect Avatar Link for the current state.")

    def review_incoming(self):
        guard = self._guard()
        review = self.controller.review_action(self._selected("requests")[0])
        if self._confirm("Review avatar request", readable(review) + "\n\nExecute this specific local action?", guard):
            result = self.controller.execute_action(review)
            self._set(self.link_status, readable(result), True)
            self.refresh_avatar_link()

    def build_parameters(self, parent):
        self._note(parent, "Declared schema, received values, and local sends are separate evidence. A received echo does not prove a material change, a photo, or visibility to another person.")
        self._table(parent, "parameters", (("name", "Parameter", 270), ("type", "Type / direction", 125), ("privacy", "Disclosure", 110), ("value", "Received value", 150), ("state", "Evidence", 200)), height=10)
        self.tables["parameters"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_parameter))
        self.parameter_fields = self._form(parent, "parameter_input", (("name", "Declared parameter", "textline"), ("value", "Requested typed value", "textline")))
        bar = self._bar(parent)
        self._button(bar, "Review and send value…", self.send_parameter)
        self._button(bar, "Freeze / resume inspector", self.toggle_freeze)
        self._button(bar, "Save selected trace bookmark", self.bookmark)
        self.parameter_detail = self._text(parent, 7)

    def refresh_parameters(self):
        if self.freeze:
            return
        snapshot = self._link_snapshot()
        observations = {p["name"]: p for p in snapshot.get("parameters", [])}
        rows = []
        for definition in self.manifest().get("parameters", []):
            name = definition["name"]
            observation = observations.get(name, {})
            received = observation.get("last_received_at") is not None
            state = observation.get("status") or "Declared; not observed"
            value = readable(observation.get("value")) if received else "Unknown"
            rows.append((name, (name, f"{definition['type']} / {definition['direction']}", definition.get("privacy", "private"), value, state)))
        self._rows("parameters", rows)

    def select_parameter(self):
        name = self._selected("parameters")[0]
        definition = next(p for p in self.manifest().get("parameters", []) if p["name"] == name)
        self.parameter_fields["name"].set(name)
        self.parameter_fields["value"].set(str(definition.get("default", "")))
        self._set(self.parameter_detail, readable(definition), True)

    def send_parameter(self):
        guard = self._guard()
        name = self.parameter_fields["name"].get().strip()
        definition = next((p for p in self.manifest().get("parameters", []) if p["name"] == name), None)
        if definition is None:
            raise ValueError("Choose a parameter in the current manifest.")
        value = parameter_value(definition, self.parameter_fields["value"].get())
        review = self.controller.review_parameter(name, value)
        if self._confirm("Send avatar parameter", readable(review) + "\n\nSending requests a value. It does not prove visible completion.", guard):
            self._set(self.parameter_detail, readable(self.controller.send_parameter(review)), True)
            self.refresh_parameters()

    def toggle_freeze(self):
        self.freeze = not self.freeze
        self.announce("Inspector frozen; the application continues observing." if self.freeze else "Inspector resumed.")
        if not self.freeze:
            self.refresh_parameters()

    def build_preview(self, parent):
        self._note(parent, "The generic mannequin demonstrates layout and states only. It is not the actual avatar, rig, proportions, or runtime verification. Preview controls never send live OSC.")
        from avatar_preview import MannequinPreview
        self.mannequin = MannequinPreview(parent, self.tk, self.ttk)
        self._table(parent, "hierarchy", (("name", "Creator-declared object", 260), ("parent", "Parent", 190), ("module", "Module", 150), ("components", "Declared components", 280)), height=7)
        self._note(parent, "Hierarchy comes only from the imported creator manifest; it is not a scan of a downloaded avatar. Source and generated identities remain separate. Actual model review uses creator-authorized Unity assets.")
        from creator_tree_ui import HierarchyPanel
        self.hierarchy_browser=HierarchyPanel(self,parent)
        self.preview_fields = self._form(parent, "fit_note", (("title", "Fit / viewpoint case", "textline"), ("anchor", "Anchor", "textline"),
            ("pose", "Reference pose", ("Standing", "Sitting", "Gesture", "T-pose", "Authored rest pose", "Other")),
            ("expected", "Expected fit / viewpoint", "multiline"), ("observed", "Observed result and source", "multiline")))
        self._button(self._bar(parent), "Save private fit observation", self.save_fit)

    def refresh_preview(self):
        if hasattr(self,'hierarchy_browser'):self.hierarchy_browser.set_manifest(self.manifest())
        self._rows("hierarchy", ((str(n.get("id", i)), (n.get("name", "Unnamed"), n.get("parent", ""), n.get("module", ""), ", ".join(n.get("components", [])))) for i, n in enumerate(self.manifest().get("hierarchy", []))))

    def save_fit(self):
        values = self._form_values("fit_note")
        if not values["title"].strip():
            raise ValueError("Give the fit case a title.")
        self.controller.store.save("fit_observation", self.avatar(), dict(values, source="Manually recorded", visibility="private"))
        self._save_form("fit_note")
        self.announce("Fit observation saved with a manual source. It does not diagnose a runtime cause.")


    def build_tests(self, parent):
        from avatar_creator_workflows import SIMULATION_SCENARIOS
        templates = self.controller.workflows.templates()
        self.test_templates = {str(item.get("title", item.get("name", key))): key for key, item in templates.items()}
        self.test_fields = self._form(parent, "test_start", (("template", "Test template", tuple(self.test_templates)),
            ("environment", "Evidence environment", ("Source inspection", "Generated-build inspection", "Simulation", "Live client", "Unity Editor")),
            ("platform", "Target platform", PLATFORMS), ("conditions", "Conditions / devices / privacy", "multiline")))
        self._note(parent, "Guided steps are manual observations unless explicitly recorded as isolated simulation. Passing a source or simulation case never establishes live operation.")
        self._button(self._bar(parent), "Start guided run", self.start_run)
        self._table(parent, "runs", (("title", "Run", 250), ("mode", "Mode / environment", 200), ("status", "State", 160)), height=4)
        self.tables["runs"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_run))
        self._table(parent, "steps", (("title", "Step", 330), ("status", "Result", 160), ("expected", "Expected", 430)), height=6)
        self.tables["steps"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_step))
        self.step_fields = self._form(parent, "step_result", (("status", "Result", STEP_STATUSES), ("note", "Observed result / evidence", "multiline")))
        bar = self._bar(parent)
        self._button(bar, "Save step result", self.save_step)
        self._button(bar, "Finish run", self.finish_run)
        self.step_detail = self._text(parent, 5)
        self.scenario = self._field(parent, "Isolated failure simulation", options=tuple(SIMULATION_SCENARIOS))
        self._button(self._bar(parent), "Run isolated simulation", self.simulate)

    def start_run(self):
        values = self._form_values("test_start")
        context = dict(self.controller.context or {}, environment=values["environment"], platform=values["platform"], requested_conditions=values["conditions"], manifest=self.manifest())
        run = self.controller.workflows.start_run(self.avatar(), self.test_templates[values["template"]], context=context, mode="manual")
        self.run_id = run["id"]
        self.controller.active_run_id = self.run_id
        self.controller.refresh_context()
        self._save_form("test_start")
        self.refresh_tests()
        self.tables["runs"].selection_set(self.run_id)
        self._show_run(run)

    def refresh_tests(self):
        self._rows("runs", ((r["id"], (display_record(r), r["data"].get("mode", "manual"), r["data"].get("status", "Unknown"))) for r in self.records("run")))
        if self.run_id:
            run = self.controller.store.get(self.run_id)
            if run and run["avatar_id"] == self.workspace:
                self._show_run(run)

    def _show_run(self, record):
        self._rows("steps", ((s["id"], (s["title"], s.get("status", "Not started"), s.get("expected", ""))) for s in record["data"].get("steps", [])))

    def select_run(self):
        record = self.controller.store.get(self._selected("runs")[0])
        if not record or record["avatar_id"] != self.avatar():
            raise ValueError("This run is not in the current avatar workspace.")
        self.run_id = record["id"]
        self.controller.active_run_id = self.run_id if record["data"].get("status") == "In progress" else None
        self.controller.refresh_context()
        self._show_run(record)

    def select_step(self):
        if not self.run_id:
            raise ValueError("Choose a run first.")
        record = self.controller.store.get(self.run_id)
        step = next(s for s in record["data"]["steps"] if s["id"] == self._selected("steps")[0])
        self.step_fields["status"].set(step["status"])
        self._set(self.step_fields["note"], step.get("note", ""))
        self._set(self.step_detail, readable(step), True)

    def save_step(self):
        self.avatar()
        if not self.run_id:
            raise ValueError("Choose an active test run.")
        record = self.controller.store.get(self.run_id)
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("The test belongs to another avatar workspace.")
        values = self._form_values("step_result")
        self.controller.workflows.set_step_result(self.run_id, self._selected("steps")[0], values["status"], note=values["note"])
        self._save_form("step_result")
        self.refresh_tests()

    def finish_run(self):
        self.avatar()
        if not self.run_id:
            raise ValueError("Choose an active test run.")
        record = self.controller.store.get(self.run_id)
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("The test belongs to another avatar workspace.")
        result = self.controller.workflows.finish_run(self.run_id)
        if getattr(self.controller, "active_run_id", None) == self.run_id:
            self.controller.active_run_id = None
            self.controller.refresh_context()
        self._set(self.step_detail, readable(result["data"]), True)
        self.refresh_tests()

    def simulate(self):
        run = self.controller.workflows.simulate(self.avatar(), self.scenario.get(), context=self.controller.context or {})
        self.run_id = run["id"]
        self.controller.active_run_id = None
        self.controller.refresh_context()
        self.refresh_tests()
        self._set(self.step_detail, readable(run["data"]), True)
        self.announce("Isolated simulation recorded. No avatar parameter or provider was changed.")

    def build_diagnostics(self, parent):
        from avatar_signals import STATUS_VALUES
        from peer_tools import METRICS
        self._note(parent, "Values include their source, unit, freshness, and disclosure. Missing devices are unknown, not empty batteries. Providers use existing measurements; optional OBS and local media are enabled explicitly.")
        self._table(parent, "signals", (("key", "Signal", 210), ("value", "Value / unit", 140), ("source", "Source", 230), ("quality", "Quality / privacy", 240)), height=8)
        self._button(self._bar(parent), "Refresh available signals", self.refresh_diagnostics)
        self.provider_fields = self._form(parent, "provider", (("role", "Battery role", ("left", "right", "headset", "tracker1", "tracker2", "tracker3", "tracker4")),
            ("device", "Observed device ID", "textline"), ("dimension", "Manual status dimension", tuple(STATUS_VALUES)),
            ("value", "Manual status value", "textline"), ("media", "Local effect source", ("none", "manual", "wav")), ("amplitude", "Manual amplitude (0 to 1)", "textline", "0")))
        bar = self._bar(parent)
        self._button(bar, "Assign selected device role", self.assign_device)
        self._button(bar, "Set temporary manual status", self.set_manual_status)
        self._button(bar, "Select local media source…", self.set_media_source)
        self._button(bar, "Set manual amplitude", self.set_amplitude)
        bar = self._bar(parent)
        self._button(bar, "Analyze next 0.1 s of WAV", lambda: self.analyze_media())
        self._button(bar, "Rewind WAV analysis", lambda: self.controller.signals.seek_media(0))
        self._button(bar, "Clear temporary manual status", lambda: self.controller.signals.clear_manual_status(self.provider_fields["dimension"].get()))
        self.media_state = self._field(parent, "Manually declared media state", options=("stopped", "playing", "paused"))
        self._button(self._bar(parent), "Declare local media state", self.set_media_state)
        self._note(parent, "Manual status choices: " + "; ".join(f"{key}: {', '.join(str(x) for x in values)}" for key, values in STATUS_VALUES.items()))
        self.routing_fields = self._form(parent, "route", (("parameter", "Declared destination parameter", "textline"), ("signal", "Provider signal key", "textline")))
        bar = self._bar(parent)
        self._button(bar, "Save signal mapping", self.save_mapping)
        self._button(bar, "Review starter mappings…", self.starter_mappings)
        self._button(bar, "Review and enable routes…", self.enable_routes)
        self._button(bar, "Stop provider routes", lambda: self.controller.enable_signal_routes(False))
        self.route_simulated = self.tk.BooleanVar(value=False)
        self.ttk.Checkbutton(parent, text="Include manual / WAV analysis test signals in the next routing review", variable=self.route_simulated).pack(anchor="w")
        self.obs_port = self._field(parent, "Local OBS WebSocket port", value="4455")
        self.obs_password = self._field(parent, "OBS password (not saved)")
        self.inputs[id(self.obs_password)].configure(show="•")
        bar = self._bar(parent)
        self._button(bar, "Connect local OBS", self.start_obs)
        self._button(bar, "Disconnect OBS", lambda: self.controller.signals.stop_obs())
        self._note(parent, "OBS status is optional and read-only. It describes this OBS connection only; it cannot establish whether other software or people are recording.")
        self.resource_fields = self._form(parent, "resource_warning", (("metric", "Existing resource metric key", tuple(METRICS)), ("threshold", "Warning threshold", "textline"),
            ("recovery", "Recovery threshold", "textline"), ("seconds", "Required sustained seconds", "textline", "3"), ("direction", "Warn when", ("Above threshold", "Below threshold"))))
        self._button(self._bar(parent), "Configure local resource warning", self.configure_warning)
        self.hardware_fields = self._form(parent, "hardware_meter", (("metric", "Existing private hardware metric", tuple(METRICS)),
            ("minimum", "Normalization minimum", "textline", "0"), ("maximum", "Normalization maximum", "textline", "100")))
        self._button(self._bar(parent), "Configure normalized hardware meter", self.configure_hardware)
        self._note(parent, "Mappings remain inactive until enabled for the current Avatar Link contract. Public and simulated values still require their explicit service permissions.")
        self.provider_detail = self._text(parent, 8)

    def refresh_diagnostics(self):
        signals = getattr(self.controller, "signals", None)
        snapshot = signals.sample() if signals else {"signals": {}, "status": "Providers unavailable"}
        self._rows("signals", ((key, (key, f"{readable(item.get('value')) if item.get('valid') else 'Unknown'} {item.get('unit', '')}", item.get("source", "Unknown"), f"{item.get('quality', 'Unknown')} / {item.get('privacy', 'private')}")) for key, item in snapshot.get("signals", {}).items()))
        self._set(self.provider_detail, readable({k: v for k, v in snapshot.items() if k != "signals"}), True)

    def assign_device(self):
        self.avatar()
        self.controller.signals.assign_device(self.provider_fields["role"].get(), self.provider_fields["device"].get().strip())
        self.refresh_diagnostics()

    def set_manual_status(self):
        self.avatar()
        self.controller.signals.set_manual_status(self.provider_fields["dimension"].get(), self.provider_fields["value"].get().strip())
        self.refresh_diagnostics()

    def set_media_source(self):
        from tkinter import filedialog
        guard = self._guard()
        source = self.provider_fields["media"].get()
        path = None
        if source == "wav":
            path = filedialog.askopenfilename(title="Choose local PCM wave effect source", filetypes=(("PCM wave audio", "*.wav"),))
            self._check(guard)
            if not path:
                return
        self.controller.signals.set_media_source(source, path=path)
        self.refresh_diagnostics()

    def set_amplitude(self):
        self.avatar()
        self.controller.signals.set_manual_amplitude(float(self.provider_fields["amplitude"].get()))
        self.refresh_diagnostics()

    def analyze_media(self):
        self.avatar()
        self.controller.signals.advance_media(.1)
        self.refresh_diagnostics()

    def set_media_state(self):
        self.avatar()
        self.controller.signals.set_manual_media_state(self.media_state.get())
        self.refresh_diagnostics()

    def configure_hardware(self):
        self.avatar()
        fields = self._form_values("hardware_meter")
        self.controller.signals.configure_hardware_metric(fields["metric"].strip().removeprefix("resource."), float(fields["minimum"]), float(fields["maximum"]))
        self._save_form("hardware_meter")
        self.refresh_diagnostics()

    def start_obs(self):
        self.avatar()
        try:
            self.controller.start_obs(int(self.obs_port.get()), self.obs_password.get())
        finally:
            self.obs_password.set("")
        self.announce("Optional local OBS connection requested. Inspect provider status for its result.")

    def configure_warning(self):
        self.avatar()
        fields = self._form_values("resource_warning")
        metric = fields["metric"].strip().removeprefix("resource.")
        self.controller.signals.configure_resource_warning(metric, float(fields["threshold"]), float(fields["recovery"]),
            seconds=float(fields["seconds"]), below=fields["direction"] == "Below threshold")
        self._save_form("resource_warning")
        self.refresh_diagnostics()

    def save_mapping(self):
        self.avatar()
        self.controller.set_signal_mapping(self.routing_fields["parameter"].get().strip(), self.routing_fields["signal"].get().strip())
        self.announce("Signal mapping saved. Provider routes require separate enablement.")

    def starter_mappings(self):
        guard = self._guard()
        review = self.controller.review_toolkit_routes()
        if self._confirm("Save starter module mappings", readable(review) + "\n\nSave these exact local mappings? Routing remains off.", guard):
            self.controller.save_toolkit_routes(review)
            self.refresh_diagnostics()

    def enable_routes(self):
        guard = self._guard()
        simulated = bool(self.route_simulated.get())
        details = {"mappings": getattr(self.controller, "routes", {}), "include_simulated_or_WAV": simulated}
        if self._confirm("Enable provider routes", readable(details) + "\n\nEnable these mappings for this avatar contract? Missing or stale signals use the declared validity/neutral policy. Review public permission in Avatar Link first.", guard):
            self.controller.enable_signal_routes(True, allow_simulated=simulated)
            self.announce("Provider routing enabled under the reviewed Avatar Link permissions.")

    def build_profiles(self, parent):
        self._note(parent, "Profiles request values under the current account, avatar, platform, and manifest revision. Partial application stays visible. Saving a profile never activates it.")
        self.profile_fields = self._form(parent, "profile", (("title", "Profile name", "textline"), ("description", "Purpose / conditions", "multiline"),
            ("platform", "Platform", PLATFORMS), ("public", "Disclosure", ("Private channels only", "Includes public channels"))))
        self.profile_values = {}
        self.profile_values_host = self.ttk.Frame(parent)
        self.profile_values_host.pack(fill="x")
        self.profile_contract = None
        self._rebuild_profile_parameters()
        bar = self._bar(parent)
        self._button(bar, "Save local profile", self.save_profile)
        self._button(bar, "Apply selected profile…", self.apply_profile)
        self._button(bar, "New profile", self.new_profile)
        self._table(parent, "profiles", (("title", "Profile", 220), ("platform", "Platform", 110), ("manifest", "Manifest revision", 200), ("public", "Disclosure", 230)), height=6)
        self.tables["profiles"].bind("<<TreeviewSelect>>", lambda _: self._call(self.load_profile))
        self.profile_detail = self._text(parent, 7)
        self._table(parent, "applications", (("profile", "Profile application", 300), ("results", "Requested operations", 160), ("updated", "Updated", 180)), height=4)
        self._button(self._bar(parent), "Review restore of selected application…", self.restore_profile)
        self._note(parent, "Restore is scoped to this application's known previous values. Unknown prior state and newer manual writes are preserved; restoration is not atomic.")

    def _rebuild_profile_parameters(self):
        fingerprint = readable(self.manifest().get("parameters", []))
        if fingerprint == self.profile_contract:
            return
        if "profile_values" in self.forms:
            self._save_form("profile_values")
        for child in self.profile_values_host.winfo_children():
            child.destroy()
        definitions = [p for p in self.manifest().get("parameters", []) if p.get("direction") == "in"]
        self.profile_values = self._form(self.profile_values_host, "profile_values", tuple((p["name"], f"{p['name']} ({p['type']}, {p.get('privacy', 'private')})", "textline") for p in definitions))
        self.profile_contract = fingerprint
        self._note(self.profile_values_host, "Leave a parameter blank to preserve its current value. Unknown current values are never assumed to be defaults.")

    def refresh_profiles(self):
        self._rebuild_profile_parameters()
        self._rows("profiles", ((r["id"], (display_record(r), r["data"].get("platform", "Unknown"), r["data"].get("manifest_revision", "Unknown"), "Includes public" if r["data"].get("allow_public") else "Private channels only")) for r in self.records("profile")))
        self._rows("applications", ((r["id"], (r["data"].get("profile_id", "Unknown"), len(r["data"].get("results", [])), r["updated_at"])) for r in self.records("profile_application")))

    def save_profile(self):
        avatar = self.avatar()
        values = self._form_values("profile")
        if not values["title"].strip():
            raise ValueError("Enter a profile name.")
        parameters = {}
        for definition in self.manifest().get("parameters", []):
            field = self.profile_values.get(definition["name"])
            if field and field.get().strip():
                parameters[definition["name"]] = parameter_value(definition, field.get())
        if not parameters:
            raise ValueError("Enter at least one declared parameter value.")
        public = values["public"] == "Includes public channels"
        if not public and any(p["name"] in parameters and p.get("privacy") == "public" for p in self.manifest().get("parameters", [])):
            raise ValueError("The profile includes a public parameter. Review its disclosure setting.")
        data = {"title": values["title"].strip(), "kind": "runtime", "description": values["description"], "platform": values["platform"],
                "manifest_revision": self.manifest().get("revision", ""), "package_id": self.manifest().get("package_id", ""),
                "account_id": (self.controller.context or {}).get("account_id", ""), "values": parameters, "allow_public": public, "privacy": "private"}
        record = self.controller.workflows.save_profile(avatar, data, record_id=self.profile_id)
        self.profile_id = record["id"]
        self._save_form("profile")
        self._save_form("profile_values")
        self.refresh_profiles()
        self.tables["profiles"].selection_set(self.profile_id)
        self.announce("Local profile saved. No values were sent.")

    def load_profile(self):
        record = self.controller.store.get(self._selected("profiles")[0])
        if not record or record["avatar_id"] != self.avatar():
            raise ValueError("Choose a profile from the current avatar.")
        self.profile_id = record["id"]
        data = record["data"]
        for key in ("title", "description", "platform"):
            self._set(self.profile_fields[key], data.get(key, ""))
        self.profile_fields["public"].set("Includes public channels" if data.get("allow_public") else "Private channels only")
        for name, field in self.profile_values.items():
            self._set(field, data.get("values", {}).get(name, ""))
        self._set(self.profile_detail, readable(data), True)

    def new_profile(self):
        self.profile_id = None
        for name in ("profile", "profile_values"):
            for key, editor in self.forms[name].items():
                self._set(editor, self.form_defaults[name].get(key, ""))

    def apply_profile(self):
        guard = self._guard()
        identity = self._selected("profiles")[0]
        record = self.controller.store.get(identity)
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("This profile is no longer in the current workspace.")
        review = self.controller.review_profile(identity)
        if self._confirm("Apply avatar profile", readable(review) + "\n\nRequest these values under the current Avatar Link contract? Completion requires separate observed evidence.", guard):
            self._set(self.profile_detail, readable(self.controller.apply_profile(review)), True)
            self.refresh_profiles()

    def restore_profile(self):
        guard = self._guard()
        identity = self._selected("applications")[0]
        record = self.controller.store.get(identity)
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("Select a profile application from this avatar workspace.")
        review = self.controller.review_profile_restore(identity)
        if self._confirm("Restore profile application", readable(review) + "\n\nRequest only the reviewed eligible previous values?", guard):
            self._set(self.profile_detail, readable(self.controller.restore_profile(review)), True)
            self.refresh_profiles()

    def build_history(self, parent):
        from avatar_creator_workflows import WORKSHEET_SCHEMAS
        self.worksheet_schemas = WORKSHEET_SCHEMAS
        self.worksheet_names = {item["label"]: key for key, item in WORKSHEET_SCHEMAS.items()}
        self._note(parent, "Builds, release decisions, platform plans, accessibility, rig, Contacts, PhysBones, dependencies, and handoff notes remain local evidence. A release record does not publish an avatar.")
        self.worksheet_kind = self._field(parent, "Structured worksheet", options=tuple(self.worksheet_names))
        bar = self._bar(parent)
        self._button(bar, "Open worksheet", self.change_worksheet)
        self._button(bar, "New worksheet record", self.new_worksheet)
        self.worksheet_host = self.ttk.Frame(parent)
        self.worksheet_host.pack(fill="x")
        self._button(self._bar(parent), "Save private worksheet", self.save_worksheet)
        self.history_filter = self._field(parent, "Search local records")
        self._button(self._bar(parent), "Search / refresh", self.refresh_history)
        self._table(parent, "history", (("kind", "Kind", 160), ("title", "Record", 300), ("updated", "Updated", 180)), height=8, multiple=True)
        self.tables["history"].bind("<<TreeviewSelect>>", lambda _: self._call(self.select_history))
        self.report_fields = self._form(parent, "report", (("profile", "Report disclosure", ("public", "collaborator", "private")), ("format", "Report format", ("html", "md", "json", "csv")),
            ("text", "Include selected free text", ("No", "Yes"))))
        bar = self._bar(parent)
        self._button(bar, "Preview selected report", self.preview_report)
        self._button(bar, "Export reviewed report…", self.export_report)
        self._button(bar, "Export creator handoff…", self.export_handoff)
        self._button(bar, "Compare two manifests / baselines", self.compare_selected)
        self.history_detail = self._text(parent, 10)
        self._note(parent, "Optional creator playtests reuse already connected peers. Select one saved result and specific fields, inspect its outgoing card, then send. Files, source models, device identifiers and private drafts are never automatically attached.")
        self._table(parent, "creator_peers", (("name", "Existing peer", 280), ("state", "Connection", 120)), height=4, multiple=True)
        self.share_fields_host = self.ttk.Frame(parent)
        self.share_fields_host.pack(fill="x")
        self.share_fields = {}
        self.share_record_id = None
        self.share_review = None
        bar = self._bar(parent)
        self._button(bar, "Choose shareable fields", self.choose_share_fields)
        self._button(bar, "Preview peer card", self.preview_peer_card)
        self._button(bar, "Send reviewed peer card…", self.send_peer_card)
        self._button(bar, "Read matching peer reports", self.read_peer_reports)
        self.change_worksheet()

    def change_worksheet(self):
        if self.worksheet_key:
            self._save_form("worksheet_" + self.worksheet_key)
        key = self.worksheet_names[self.worksheet_kind.get()]
        self.worksheet_id = None
        self.worksheet_key = key
        for child in self.worksheet_host.winfo_children():
            child.destroy()
        for name in tuple(self.forms):
            if name.startswith("worksheet_"):
                self.forms.pop(name)
        schema = self.worksheet_schemas[key]
        self.worksheet_fields = self._form(self.worksheet_host, "worksheet_" + key, tuple(schema["fields"]))
        self._note(self.worksheet_host, schema.get("help", "Private local record."))

    def new_worksheet(self):
        self.change_worksheet()
        for key, field in self.worksheet_fields.items():
            self._set(field, self.form_defaults["worksheet_" + self.worksheet_key].get(key, ""))

    def save_worksheet(self):
        values = self._form_values("worksheet_" + self.worksheet_key)
        record = self.controller.workflows.save_worksheet(self.avatar(), self.worksheet_key, values, self.worksheet_id)
        self.worksheet_id = record["id"]
        self._save_form("worksheet_" + self.worksheet_key)
        self.refresh_history()
        self.tables["history"].selection_set(record["id"])
        self.announce("Structured creator record saved locally.")

    def refresh_history(self):
        query = self.history_filter.get().strip().casefold()
        rows = [r for r in self.records() if r["kind"] != "ui_draft" and (not query or query in readable(r["data"]).casefold() or query in r["kind"])]
        self._rows("history", ((r["id"], (r["kind"].replace("_", " ").title(), display_record(r), r["updated_at"])) for r in rows))
        service = getattr(self.controller.app, "peer_service", None)
        peers = service.snapshot().get("peers", []) if service is not None else []
        self._rows("creator_peers", ((p["peer_id"], (p.get("profile", {}).get("name") or p.get("name") or p["peer_id"], p.get("state", "Unknown"))) for p in peers if p.get("state") == "READY"))

    def choose_share_fields(self):
        self.avatar()
        selected = self._selected("history")
        if len(selected) != 1:
            raise ValueError("Select one saved result to prepare a peer card.")
        record = self.controller.store.get(selected[0])
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("Select a result from this avatar workspace.")
        coordinator = self.controller.peer_coordinator
        fields = coordinator.available_fields(record)
        if not fields:
            raise ValueError("This record has no supported peer fields. Use a saved test run, observation, issue, or bookmark.")
        for child in self.share_fields_host.winfo_children():
            child.destroy()
        self.share_fields = {}
        self.share_record_id, self.share_review = record["id"], None
        for field in fields:
            variable = self.tk.BooleanVar(value=False)
            self.ttk.Checkbutton(self.share_fields_host, text=field.replace("_", " ").title(), variable=variable).pack(anchor="w")
            self.share_fields[field] = variable

    def preview_peer_card(self):
        guard = self._guard()
        if not self.share_record_id:
            raise ValueError("Choose shareable fields for a selected record first.")
        record = self.controller.store.get(self.share_record_id)
        if not record or record["avatar_id"] != self.workspace:
            raise ValueError("Choose a saved result from the current avatar workspace again.")
        fields = [key for key, variable in self.share_fields.items() if variable.get()]
        if not fields:
            raise ValueError("Select the particular fields to include.")
        peers = self._selected("creator_peers")
        context = self.controller.context or {}
        run_id = record["id"] if record["kind"] in ("run", "test_run") else record["data"].get("run_id", "")
        build_id = record["data"].get("build_id") or record["data"].get("context", {}).get("build_id") or context.get("build_id") or ""
        self.share_review = self.controller.peer_coordinator.preview(record, avatar_id=self.workspace, build_id=build_id, run_id=run_id,
            fields=fields, context_token=getattr(self.controller, "guard_token", None), peer_ids=peers)
        self.share_context, self.share_peers = guard, peers
        self._set(self.history_detail, self.share_review["preview_text"], True)
        self.announce("Outgoing card previewed for the selected connected peers. Review its exact fields before sending.")

    def send_peer_card(self):
        if self.share_review is None:
            raise ValueError("Preview a peer card first.")
        self._check(self.share_context)
        if self._confirm("Send reviewed creator card", self.share_review["preview_text"] + "\n\nSend this exact snapshot to the reviewed peers?", self.share_context):
            result = self.controller.peer_coordinator.share(self.share_review, list(self.share_peers), context_token=getattr(self.controller, "guard_token", None))
            self.share_review = None
            self._set(self.history_detail, readable(result), True)
            self.announce("Selected peer card submitted through existing peer permissions.")

    def read_peer_reports(self):
        self.avatar()
        rows = self.controller.peer_coordinator.received(avatar_id=self.workspace, build_id=(self.controller.context or {}).get("build_id") or "", run_id=getattr(self.controller, "active_run_id", None) or "")
        self._set(self.history_detail, readable(rows) + "\n\nPeer reports are not independent verification and do not change local test results.", True)

    def select_history(self):
        selected = self._selected("history", False)
        if len(selected) != 1:
            return
        record = self.controller.store.get(selected[0])
        if not record or record["avatar_id"] != self.workspace:
            return
        self._set(self.history_detail, readable(record), True)
        if record["kind"] == self.worksheet_key:
            self.worksheet_id = record["id"]
            for key, field in self.worksheet_fields.items():
                self._set(field, readable(record["data"].get(key, "")))

    def preview_report(self):
        from avatar_creator_reports import preview_report
        avatar = self.avatar()
        values = self._form_values("report")
        self.report_preview = preview_report(self.controller.store, avatar, self._selected("history"), profile=values["profile"], format=values["format"], include_text=values["text"] == "Yes")
        self.report_context = self._guard()
        self.report_format = values["format"]
        self._set(self.history_detail, self.report_preview.document, True)
        self.announce("Frozen preview ready. Review selected records and disclosure before export.")

    def export_report(self):
        from tkinter import filedialog
        from avatar_creator_reports import export_report
        if self.report_preview is None:
            raise ValueError("Preview the selected report first.")
        self._check(self.report_context)
        extension = self.report_format
        path = filedialog.asksaveasfilename(title="Export reviewed avatar report", initialfile="avatar-report." + extension, defaultextension="." + extension)
        self._check(self.report_context)
        if path:
            export_report(self.report_preview, path)
            self.announce("Exported exactly the reviewed report snapshot.")

    def export_handoff(self):
        from tkinter import filedialog
        from avatar_creator_reports import preview_handoff, export_handoff
        guard = self._guard()
        preview = preview_handoff(self.manifest())
        self._set(self.history_detail, preview.document, True)
        if not self._confirm("Export creator handoff", "Export the creator contract, local documentation, and declared module details shown in History? Source avatar assets are not included.", guard):
            return
        path = filedialog.asksaveasfilename(title="Export creator handoff", initialfile="avatar-handoff.zip", defaultextension=".zip")
        self._check(guard)
        if path:
            export_handoff(preview, path)
            self.announce("Creator handoff exported without source avatar assets.")

    def compare_selected(self):
        selected = self._selected("history")
        if len(selected) != 2:
            raise ValueError("Select exactly two manifest or baseline records for comparison.")
        rows = [self.controller.store.get(identity) for identity in selected]
        if any(not r or r["avatar_id"] != self.avatar() for r in rows):
            raise ValueError("Select two records from this avatar workspace.")
        if all(r["kind"] == "baseline" for r in rows):
            self._set(self.history_detail, readable(self.controller.workflows.compare_baselines(*rows)), True)
            return
        if any(r["kind"] != "manifest" for r in rows):
            raise ValueError("Select two manifests or two baseline records.")
        manifests = [r["data"].get("manifest", r["data"]) for r in rows]
        self._set(self.history_detail, readable(self.controller.workflows.compare(*manifests)), True)

    def _export_json(self, document, filename, title):
        from tkinter import filedialog
        guard = self._guard()
        payload = json.dumps(document, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
        path = filedialog.asksaveasfilename(title=title, initialfile=filename, defaultextension=".json")
        self._check(guard)
        if path:
            Path(path).write_text(payload, encoding="utf-8")
            self.announce("Local reviewed document exported.")

    def close(self):
        if self.closed:
            return
        library_page = getattr(self, "library_page", None)
        if library_page is not None:
            library_page.close()
        for name in tuple(self.forms):
            self._call(self._save_form, name)
        preview = getattr(self, "mannequin", None)
        if preview:
            preview.close()
        self.closed = True
