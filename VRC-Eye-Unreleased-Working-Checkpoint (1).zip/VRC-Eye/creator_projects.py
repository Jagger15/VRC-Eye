"""Local-first Unity/VCC project catalog. No CLI, networking or project writes.

All locations come from explicit selection. The existing CompanionStore owns the
SQLite database; account-bound links are separate from local filesystem records.
Manifest declarations are evidence, not a claim that Unity compiled a project.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from contextlib import nullcontext
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time
import uuid

from companion_data import entity_id

JSON_LIMIT = 2 * 1024 * 1024
PACKAGE_LIMIT = 1024
SKIP_DIRECTORIES = frozenset(('Library', 'Temp', 'Logs', 'Obj', '.git', '.svn', '.hg', '.vs', 'node_modules'))
PACKAGE_NAME = re.compile(r'[a-z0-9][a-z0-9._-]{1,159}\Z')
UNITY_VERSION = re.compile(r'\d{4}\.\d+\.\d+[abfp]\d+(?:[a-z0-9]*)?\Z')


def cancelled(stop):
    if stop is not None and stop.is_set():
        raise ValueError('Project operation canceled. No original project was changed.')


def local_path(value):
    """Normalize native absolute paths; never guess a Proton or drive mapping."""
    if not isinstance(value, (str, Path)) or not str(value).strip() or '\x00' in str(value):
        raise ValueError('Choose an absolute local folder or file.')
    text = str(value)
    if len(text) > 4096 or any(ord(c) < 32 for c in text):
        raise ValueError('The selected path is not supported.')
    if os.name != 'nt' and (re.match(r'^[A-Za-z]:[\\/]', text) or text.startswith('\\\\')):
        raise ValueError('This is a Windows path. Select its actual mounted Linux/macOS location; no drive mapping was guessed.')
    path = Path(text).expanduser()
    if not path.is_absolute():
        raise ValueError('Select an absolute path, not a relative project name.')
    return Path(os.path.normpath(str(path)))


def assert_no_links(path):
    """Refuse symlinks and Windows junction/reparse points, including ancestors."""
    path = local_path(path)
    for item in reversed((path, *path.parents)):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('Linked or reparse-point paths are not inspected. Select the real location instead.')
    return path


def read_bytes(path, limit=JSON_LIMIT):
    path = assert_no_links(path)
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError('A selected metadata file is not a regular file or exceeds the read limit.')
        data = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    if len(data) > limit or (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise ValueError('A metadata file changed while it was being read. Inspect again.')
    return data


def read_json(path):
    try:
        value = json.loads(read_bytes(path).decode('utf-8-sig'))
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise ValueError('A selected metadata file is not supported UTF-8 JSON.') from error
    if not isinstance(value, dict):
        raise ValueError('Expected a JSON object in the selected metadata file.')
    return value


def version_text(value):
    if isinstance(value, dict):
        value = value.get('version')
    if not isinstance(value, str) or len(value) > 160:
        return ''
    # Git/file/HTTP references can contain local paths or credentials. Do not
    # retain them in the catalog or reports as if they were package versions.
    return value if re.fullmatch(r'[0-9A-Za-z*~^<>=.+| -]{1,160}', value) else 'External reference (location omitted)'


def _mapping(value, field, issues):
    value = value.get(field, {})
    if not isinstance(value, dict) or len(value) > PACKAGE_LIMIT:
        issues.append(f'{field}: invalid or too many package records; not inspected.')
        return {}
    result = {}
    for key, item in value.items():
        if isinstance(key, str) and PACKAGE_NAME.fullmatch(key):
            result[key] = item
        else:
            issues.append(f'{field}: unsupported package identifier omitted.')
    return result


def inspect_project(value, *, stop=None):
    """Read only bounded manifests from one approved project, never Library/cache."""
    path = assert_no_links(local_path(value))
    cancelled(stop)
    base = dict(schema=1, path=str(path), name=path.name, kind='Unknown', unity='',
                state='Unavailable', checked=time.time(), packages=[], issues=[], manifest_digest='')
    if not path.is_dir():
        base['issues'].append('Project folder is unavailable. Catalog history is retained.')
        return base
    for folder in ('Assets', 'Packages', 'ProjectSettings'):
        assert_no_links(path / folder)
        if not (path / folder).is_dir():
            raise ValueError('Select a Unity project containing Assets, Packages and ProjectSettings.')
    documents = {}
    digest = hashlib.sha256()
    relative_files = ('ProjectSettings/ProjectVersion.txt', 'Packages/manifest.json',
                      'Packages/packages-lock.json', 'Packages/vpm-manifest.json', 'package.json')
    for relative in relative_files:
        cancelled(stop)
        full = path / relative
        try:
            raw = read_bytes(full)
            digest.update(relative.encode() + b'\0' + raw + b'\0')
            if relative.endswith('.json'):
                data = json.loads(raw.decode('utf-8-sig'))
                if not isinstance(data, dict):
                    raise ValueError('Expected a JSON object.')
                documents[relative] = data
            else:
                match = re.search(r'^m_EditorVersion:\s*(\S+)\s*$', raw.decode('utf-8-sig'), re.M)
                if match and UNITY_VERSION.fullmatch(match.group(1)):
                    base['unity'] = match.group(1)
                else:
                    base['issues'].append('ProjectVersion.txt: exact Unity version is unavailable.')
        except FileNotFoundError:
            digest.update(relative.encode() + b'\0MISSING\0')
        except (ValueError, UnicodeError, json.JSONDecodeError, RecursionError, OSError):
            base['issues'].append(relative + ': unreadable, unsupported or changed metadata.')
            digest.update(relative.encode() + b'\0UNREADABLE\0')
    upm = _mapping(documents.get('Packages/manifest.json', {}), 'dependencies', base['issues'])
    upm_lock = _mapping(documents.get('Packages/packages-lock.json', {}), 'dependencies', base['issues'])
    vpm_doc = documents.get('Packages/vpm-manifest.json', {})
    vpm = _mapping(vpm_doc, 'dependencies', base['issues'])
    locked = _mapping(vpm_doc, 'locked', base['issues'])
    names = set(upm) | set(upm_lock) | set(vpm) | set(locked)
    # Also inspect bounded direct embedded package manifests; never load scripts.
    with os.scandir(path / 'Packages') as directories:
        for i, item in enumerate(directories):
            cancelled(stop)
            if i >= PACKAGE_LIMIT:
                base['issues'].append('Embedded package enumeration reached its limit.')
                break
            if PACKAGE_NAME.fullmatch(item.name) and item.is_dir(follow_symlinks=False):
                names.add(item.name)
    if len(names) > PACKAGE_LIMIT:
        base['issues'].append('Combined package inventory reached its limit.')
    for name in sorted(names)[:PACKAGE_LIMIT]:
        cancelled(stop)
        installed = ''
        evidence = 'No embedded manifest observed'
        manifest_path = path / 'Packages' / name / 'package.json'
        try:
            data = read_json(manifest_path)
            if data.get('name') == name:
                installed = version_text(data.get('version'))
                evidence = 'Embedded package manifest'
                digest.update(name.encode() + b'\0' + read_bytes(manifest_path) + b'\0')
            else:
                evidence = 'Embedded package name mismatch'
                base['issues'].append(name + ': embedded manifest name mismatch.')
        except FileNotFoundError:
            pass
        except (ValueError, OSError):
            evidence = 'Embedded manifest unavailable'
        is_vpm = name in vpm or name in locked
        requested = version_text(vpm.get(name) if is_vpm else upm.get(name))
        lock = version_text(locked.get(name) if is_vpm else upm_lock.get(name))
        status = ('Installed manifest observed' if installed else
                  'Missing embedded package' if is_vpm else
                  'Unity lock recorded; installation not inspected' if lock else 'Declaration only')
        if is_vpm and not lock:
            status = 'VPM lock missing; resolution unverified'
        elif is_vpm and installed and lock != installed:
            status = 'Locked / installed version mismatch'
        if is_vpm and name in upm:
            base['issues'].append(name + ': present in both UPM and VPM declarations; review ownership.')
        base['packages'].append(dict(name=name, manager='VPM' if is_vpm else 'UPM / embedded',
                                    requested=requested, locked=lock, installed=installed,
                                    state=status, evidence=evidence))
    if 'com.vrchat.avatars' in names and 'com.vrchat.worlds' in names:
        base['kind'] = 'Mixed SDKs — review'
    elif 'com.vrchat.avatars' in names:
        base['kind'] = 'Avatar'
    elif 'com.vrchat.worlds' in names:
        base['kind'] = 'World'
    elif (path / 'Assets' / 'VRCSDK').exists():
        base['kind'] = 'Legacy SDK — unverified'
    else:
        base['kind'] = 'Unity'
    template = documents.get('package.json', {})
    if template.get('category') == 'ProjectTemplate':
        base['kind'] = 'Template'
    if not base['unity']:
        base['issues'].append('No exact Unity editor version established. Do not assume compatibility.')
    base['state'] = 'Review needed' if base['issues'] or any('missing' in p['state'].lower() or 'mismatch' in p['state'] for p in base['packages']) else 'Inspected'
    base['manifest_digest'] = digest.hexdigest()
    return base


def discover_projects(root, *, stop=None, max_entries=5000, max_depth=3):
    root = assert_no_links(local_path(root))
    if not root.is_dir():
        raise ValueError('Choose an existing search folder.')
    found, issues, pending = [], [], [(root, 0)]
    visited = 0
    while pending:
        cancelled(stop)
        path, depth = pending.pop()
        try:
            if (path / 'ProjectSettings').is_dir() and (path / 'Assets').is_dir() and (path / 'Packages').is_dir():
                assert_no_links(path / 'ProjectSettings')
                found.append(str(path))
                if len(found) >= 256:
                    issues.append('Project limit reached; choose a narrower folder to continue.')
                    break
                continue
            if depth >= max_depth:
                continue
            with os.scandir(path) as children:
                for item in children:
                    cancelled(stop)
                    visited += 1
                    if visited > max_entries:
                        return dict(paths=sorted(found), issues=issues + ['Entry limit reached; results are partial.'])
                    if item.name in SKIP_DIRECTORIES or not item.is_dir(follow_symlinks=False):
                        continue
                    try:
                        assert_no_links(Path(item.path))
                        pending.append((Path(item.path), depth + 1))
                    except ValueError:
                        issues.append('A linked directory was skipped.')
        except (OSError, ValueError):
            issues.append('An unreadable or linked directory was skipped.')
    return dict(paths=sorted(found), issues=issues)


def read_vcc_candidates(settings_file):
    """Read only the documented path list. Never retain auth or repository headers."""
    data = read_json(settings_file)
    paths = data.get('userProjects')
    if not isinstance(paths, list) or len(paths) > 2048:
        raise ValueError('This file has no supported VCC userProjects list. Add projects by folder instead.')
    result, issues = [], []
    for item in paths:
        # Do not guess schema changes or access a project merely by reading settings.
        if not isinstance(item, str):
            issues.append('An unsupported project-list entry was skipped.')
            continue
        try:
            value = str(local_path(item))
            if value not in result:
                result.append(value)
        except ValueError:
            issues.append('A non-native or invalid path needs manual location selection.')
    return dict(paths=result, issues=issues)


def public_report(snapshot):
    """Data-only report: paths, account links and arbitrary metadata are excluded."""
    return dict(schema=1, product='VRC Eye Creator Projects',
                kind=snapshot['kind'], unity=snapshot['unity'], state=snapshot['state'],
                checked=snapshot['checked'], packages=snapshot['packages'], issues=snapshot['issues'],
                evidence='Local manifests only; not a Unity build, runtime, permissions or compatibility test.')


class ProjectStore:
    def __init__(self, companion_store):
        self.store = companion_store
        with self.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS creator_projects_120(id TEXT PRIMARY KEY, path TEXT NOT NULL UNIQUE, label TEXT NOT NULL, snapshot TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS creator_project_links_120(project_id TEXT NOT NULL, account TEXT NOT NULL, kind TEXT NOT NULL, entity TEXT NOT NULL, PRIMARY KEY(project_id,account,kind,entity))')
            db.execute('CREATE TABLE IF NOT EXISTS creator_project_receipts_120(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, created REAL NOT NULL, data TEXT NOT NULL)')

    def save(self, snapshot, label=None, *, _db=None):
        path = os.path.normcase(str(local_path(snapshot['path'])))
        if not isinstance(label, (str, type(None))) or label is not None and not 1 <= len(label.strip()) <= 160:
            raise ValueError('Use a project label of 1–160 characters.')
        raw = json.dumps(snapshot, ensure_ascii=False, allow_nan=False)
        if len(raw.encode()) > 2 * 1024 * 1024:
            raise ValueError('Project inventory exceeds the catalog limit.')
        with (self.store.connect() if _db is None else nullcontext(_db)) as db:
            old = db.execute('SELECT id,label,snapshot FROM creator_projects_120 WHERE path=?', (path,)).fetchone()
            if old and snapshot['state']=='Unavailable':
                previous=json.loads(old[2])
                previous.update(state='Unavailable',checked=snapshot['checked'],issues=snapshot['issues'],last_available_checked=previous.get('last_available_checked',previous['checked']))
                raw=json.dumps(previous,ensure_ascii=False,allow_nan=False)
            ref = old[0] if old else str(uuid.uuid4())
            title = label.strip() if label else old[1] if old else snapshot['name'][:160]
            db.execute('INSERT INTO creator_projects_120 VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET label=excluded.label,snapshot=excluded.snapshot', (ref, path, title, raw))
        return ref

    def list(self, query='', offset=0, limit=100):
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 256:
            raise ValueError('Invalid project page.')
        with self.store.connect() as db:
            rows = db.execute('SELECT id,label,snapshot FROM creator_projects_120 WHERE instr(lower(label||\' \'||path),lower(?))>0 ORDER BY label COLLATE NOCASE,id LIMIT ? OFFSET ?', (str(query)[:256], limit, offset)).fetchall()
        return [dict(json.loads(raw), id=ref, label=label) for ref, label, raw in rows]

    def get(self, ref):
        with self.store.connect() as db:
            row = db.execute('SELECT label,snapshot FROM creator_projects_120 WHERE id=?', (ref,)).fetchone()
        if not row:
            raise ValueError('This project is no longer in the catalog.')
        return dict(json.loads(row[1]), id=ref, label=row[0])

    def forget(self, ref):
        # Catalog removal is deliberately separate from deleting any local file.
        with self.store.connect() as db:
            db.execute('DELETE FROM creator_project_links_120 WHERE project_id=?', (ref,))
            db.execute('DELETE FROM creator_projects_120 WHERE id=?', (ref,))

    def link(self, ref, account, kind, target):
        self.get(ref)
        if kind not in ('avatar', 'world'):
            raise ValueError('Only explicit avatar or world references can be linked.')
        account = entity_id('user', account) if account else 'local'
        target = entity_id(kind, target)
        with self.store.connect() as db:
            db.execute('INSERT OR IGNORE INTO creator_project_links_120 VALUES(?,?,?,?)', (ref, account, kind, target))

    def links(self, ref, account):
        account = entity_id('user', account) if account else 'local'
        with self.store.connect() as db:
            rows = db.execute('SELECT kind,entity FROM creator_project_links_120 WHERE project_id=? AND account=? ORDER BY kind,entity', (ref, account)).fetchall()
        return [dict(kind=kind, entity=entity) for kind, entity in rows]

    def for_entity(self, account, kind, target):
        """Reverse lookup using the existing scoped association table."""
        if kind not in ('avatar', 'world'):
            raise ValueError('Choose an avatar or world association.')
        account = entity_id('user', account) if account else 'local'
        target = entity_id(kind, target)
        with self.store.connect() as db:
            rows = db.execute('SELECT p.id,p.label,p.snapshot FROM creator_projects_120 p JOIN creator_project_links_120 l ON l.project_id=p.id WHERE l.account=? AND l.kind=? AND l.entity=? ORDER BY p.label,p.id LIMIT 256', (account, kind, target)).fetchall()
        return [dict(json.loads(raw), id=ref, label=label) for ref, label, raw in rows]

    def receipt(self, ref, data, *, _db=None, _identity=None):
        # Receipts are local only, contain no CLI stdout or VRChat credentials.
        if not isinstance(data, dict):
            raise ValueError('Invalid project receipt.')
        raw = json.dumps(data, ensure_ascii=False, allow_nan=False)
        if len(raw.encode()) > 131072:
            raise ValueError('Receipt exceeds the 128 KiB storage limit.')
        with (self.store.connect() if _db is None else nullcontext(_db)) as db:
            db.execute('INSERT INTO creator_project_receipts_120 VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data', (_identity or str(uuid.uuid4()), ref, time.time(), raw))
            db.execute('DELETE FROM creator_project_receipts_120 WHERE project_id=? AND id NOT IN (SELECT id FROM creator_project_receipts_120 WHERE project_id=? ORDER BY created DESC LIMIT 100)', (ref, ref))

    def receipts(self, ref):
        with self.store.connect() as db:
            rows = db.execute('SELECT data FROM creator_project_receipts_120 WHERE project_id=? ORDER BY created DESC LIMIT 100', (ref,)).fetchall()
        return [json.loads(row[0]) for row in rows]
