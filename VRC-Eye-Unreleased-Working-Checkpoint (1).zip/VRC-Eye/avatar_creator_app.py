"""Application-owned avatar creator workspace and explicitly armed local adapters."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import queue
import sqlite3
import threading
import time
import uuid

from avatar_creator_store import AvatarStore, validate_avatar_id
from avatar_creator_workflows import AvatarWorkflows
from avatar_manifest import load_manifest, validate_manifest
from avatar_link import AvatarLink
from avatar_signals import AvatarSignals
from avatar_creator_integrations import AvatarPeerCoordinator, AvatarOverlayController
from avatar_links import parse_avatar_reference


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


class AvatarCreatorWorkspace:
    def __init__(self, app, notebook=None, *, store=None, build_ui=True):
        self.app, self.tk, self.ttk = app, app.tk, app.ttk
        self.closed, self.panel = False, None
        self.message = "Offline Authoring. Avatar Link, providers, public output and sharing are off."
        if store is None:
            path = app.sidebar.store.path
            try:
                store = AvatarStore(path.with_name(path.stem + "-avatar-creators.sqlite3"))
            except (OSError, ValueError, sqlite3.Error):
                store = AvatarStore(":memory:")
                self.message = "Avatar creator storage is unavailable. Export this session's records before closing; they are temporary."
        self.store, self.workflows = store, AvatarWorkflows(store)
        self._library = None
        shared_osc = getattr(app, "osc_controller", None)
        if shared_osc is not None:
            from osc_avatar import AvatarSharedTransport
            self.link = AvatarLink(transport=AvatarSharedTransport(shared_osc))
        else:
            self.link = AvatarLink()
        self.signals = AvatarSignals(app=app)
        self.overlay = AvatarOverlayController()
        self.platform = "Windows"
        self.manifest = None
        self.context, self.guard_token = {}, ""
        self._signature, self._generation, self._link_epoch = None, 0, None
        self._manifest_workspace = None
        self._peer_coordinator = self._peer_service = None
        self._reviews, self._pending = {}, {}
        self._camera_stop = threading.Event()
        self._camera_results = queue.Queue(maxsize=4)
        self._camera_busy = False
        self._last_camera = -100.
        self._last_sample = self._last_render = self._last_record = 0.
        self.signal_snapshot = {}
        self.routes = {}
        self.routes_enabled = False
        self.allow_simulated_routes = False
        self.route_results = []
        self.recording = False
        self.active_run_id = None
        self.pinned = False
        self.mode = "Offline Authoring"
        self.safety_active = False
        self._safety_previous = None
        rows = store.list("workspace", limit=1)
        self.avatar_id = rows[0]["avatar_id"] if rows else "local:" + str(uuid.uuid4())
        if rows:
            saved_platform = rows[0]["data"].get("platform", "Windows")
            if saved_platform in ("Windows", "Android", "iOS", "Generic"):
                self.platform = saved_platform
            self.pinned = rows[0]["data"].get("pinned") is True
        if not rows:
            store.save("workspace", self.avatar_id, {"name": "My local avatar", "platform": self.platform})
        self.refresh_context()
        if build_ui:
            from avatar_creator_ui import AvatarCreatorPanel
            self.panel = AvatarCreatorPanel(self, notebook)
            self.panel.status.set(self.message)

    @property
    def library(self):
        if self._library is None:
            from avatar_library import AvatarLibrary
            self._library = AvatarLibrary(self.store)
        return self._library

    def current_avatar(self):
        return self.avatar_id

    def announce(self, message):
        self.message = str(message)[:4000]
        if self.panel:
            self.panel.status.set(self.message)
            self.panel.refresh()

    def _enabled(self):
        if self.closed or self.app.demo or getattr(self.app, "safe_mode", False):
            raise ValueError("Live avatar integrations are disabled in Demo and startup Safe Mode.")

    def set_workspace(self, avatar_id, name=""):
        if not avatar_id:
            avatar_id = "local:" + str(uuid.uuid4())
        if not avatar_id.startswith("local:"):
            avatar_id = parse_avatar_reference(avatar_id)
        validate_avatar_id(avatar_id)
        old = self.store.list("workspace", avatar_id, limit=1)
        values = dict(old[0]["data"]) if old else {}
        values.update(name=name or values.get("name") or avatar_id, platform=values.get("platform", self.platform), pinned=True)
        self.store.save("workspace", avatar_id, values, old[0]["id"] if old else None)
        self.avatar_id, self.pinned = avatar_id, True
        self.platform = values["platform"]
        self.refresh_context()
        self.announce("Avatar workspace pinned. Its local records are separate from the currently worn avatar.")
        return avatar_id

    def follow_current_avatar(self):
        self.pinned = False
        rows = self.store.list("workspace", self.avatar_id, limit=1)
        if rows:
            data = dict(rows[0]["data"], pinned=False)
            self.store.save("workspace", self.avatar_id, data, rows[0]["id"])
        self.refresh_context()
        self.announce("Following the avatar reported by the explicitly connected local OSC endpoint.")

    def use_selected_avatar(self):
        event = self.app.selected_event()
        link = self.app.avatar_links.get(event)
        if not link:
            raise ValueError("Select an Activity row with an associated avatar ID first.")
        return self.set_workspace(link[0], getattr(event, "after", ""))

    def select_platform(self, platform):
        if platform not in ("Windows", "Android", "iOS", "Generic"):
            raise ValueError("Choose Windows, Android, iOS or Generic.")
        self.platform = platform
        rows = self.store.list("workspace", self.avatar_id, limit=1)
        data = dict(rows[0]["data"]) if rows else {"name": self.avatar_id}
        data.update(platform=platform, pinned=self.pinned)
        self.store.save("workspace", self.avatar_id, data, rows[0]["id"] if rows else None)
        self.refresh_context()

    def refresh_context(self):
        snapshot = self.link.snapshot()
        observed = snapshot.get("observed_avatar_id", "")
        if observed and not self.pinned:
            try:
                self.avatar_id = parse_avatar_reference(observed)
            except ValueError:
                pass
        if self._manifest_workspace != self.avatar_id:
            self._manifest_workspace = self.avatar_id
            records = self.store.list("manifest", self.avatar_id, limit=1)
            self.manifest = load_manifest(records[0]["data"]) if records else None
            route_records = self.store.list("routes", self.avatar_id, limit=1)
            self.routes = dict(route_records[0]["data"].get("mappings", {})) if route_records else {}
            self.routes_enabled = False
        client = getattr(self.app, "api", None)
        account = getattr(client, "user_id", "") if getattr(client, "authenticated", False) else ""
        roster = getattr(self.app, "world_roster", None)
        client_session = (getattr(roster, "source", ""), getattr(roster, "generation", 0))
        signature = (id(client), getattr(self.app, "data_generation", 0), account,
            getattr(client, "session_revision", None), self.avatar_id, self.platform,
            _digest(self.manifest) if self.manifest else "", observed, client_session,
            bool(self.app.demo), bool(getattr(self.app, "safe_mode", False)))
        # The desktop review token includes the observed avatar. The OSC client
        # session must not: adopting /avatar/change must not erase that report.
        link_session = _digest([id(client), getattr(self.app, "data_generation", 0),
                               account, getattr(client, "session_revision", None), client_session,
                               bool(self.app.demo), bool(getattr(self.app, "safe_mode", False))])
        if signature != self._signature or snapshot.get("generation") != self._link_epoch:
            self._signature = signature
            self._generation += 1
            self.guard_token = hashlib.sha256(repr((signature, self._generation)).encode()).hexdigest()
            self._reviews.clear()
            self._pending.clear()
            self.routes_enabled = False
            self.allow_simulated_routes = False
            self.route_results = []
            self.recording = False
            self._camera_stop.set()
            shared = getattr(self.app, "osc_controller", None)
            if shared is not None:
                shared.cancel_owner("avatar-camera")
                self._camera_busy, self._shared_camera = False, None
            self.clear_overlay()
            self.signals.reset_context()
            if self._peer_coordinator is not None:
                self._peer_coordinator.clear()
            self.link.set_context(account_id=account, avatar_id=self.avatar_id,
                                  platform=self.platform, session=link_session)
            self.link.attach_manifest(self.manifest)
            self._link_epoch = self.link.snapshot().get("generation")
        if self.active_run_id:
            run = self.store.get(self.active_run_id)
            if not run or run["avatar_id"] != self.avatar_id or run["data"].get("status") != "In progress":
                self.active_run_id = None
            else:
                saved = run["data"].get("context", {})
                current = {"platform": self.platform, "account_id": account,
                           "manifest_revision": (self.manifest or {}).get("revision", ""),
                           "build_id": (self.manifest or {}).get("build_id", "")}
                if any(saved.get(key) not in (None, "", value) for key, value in current.items()):
                    self.active_run_id = None
        self.context = {"avatar_id": self.avatar_id, "observed_avatar_id": observed,
            "account_id": account, "platform": self.platform, "pinned": self.pinned,
            "manifest_revision": (self.manifest or {}).get("revision", ""),
            "build_id": (self.manifest or {}).get("build_id", ""),
            "manifest_stage": (self.manifest or {}).get("stage", "Unknown"),
            "recognition": "Declared manifest" if self.manifest else "Local project" if self.avatar_id.startswith("local:") else "Unresolved compatibility",
            "source": "Creator-supplied manifest" if self.manifest else "Local workspace",
            "mode": self.mode, "guard_token": self.guard_token,
            "world_id": getattr(roster, "world_id", ""), "run_id": self.active_run_id,
            "recording": self.recording, "routes_enabled": self.routes_enabled,
            "message": self.message}
        return self.context

    def import_manifest(self, path):
        self.refresh_context()
        with Path(path).open("rb") as source:
            data = source.read(256 * 1024 + 1)
        if len(data) > 256 * 1024:
            raise ValueError("Avatar manifests are limited to 256 KiB.")
        manifest = load_manifest(data)
        if manifest["avatar_id"] != self.avatar_id:
            raise ValueError("Open the manifest's exact avatar workspace before importing it.")
        self.store.save("manifest", self.avatar_id, manifest)
        self.manifest = manifest
        self.refresh_context()
        findings = validate_manifest(manifest)
        self.announce("Manifest imported as declared compatibility. Review validation and explicitly connect/arm before sending values.")
        return {"manifest": manifest, "findings": findings}

    def connect_link(self, receive_port=None, send_port=None, source_port=None):
        self._enabled()
        self.refresh_context()
        shared = getattr(self.app, "osc_controller", None)
        if shared is not None:
            shared.connect()
            receive_port, send_port = shared.service.transport.receive_port, shared.service.transport.target_port
        self.link.connect(receive_port=receive_port or 9001, target_port=send_port or 9000, source_port=source_port, reviewed=True)
        self.mode = "Local Companion"
        self.announce("Local OSC endpoint connected. Review the reported avatar and parameter contract before arming.")
        return self.link.snapshot()

    def disconnect_link(self):
        self.link.disconnect()
        self.routes_enabled = False
        self._pending.clear()
        self._reviews.clear()
        self._camera_stop.set()
        shared = getattr(self.app, "osc_controller", None)
        if shared is not None:
            shared.cancel_owner("avatar-camera")
            self._camera_busy, self._shared_camera = False, None
        self.mode = "Offline Authoring"
        self.refresh_context()
        self.announce("Avatar Link disconnected. Local authoring, notes and simulations remain available.")

    def start_obs(self, port=4455, password=""):
        self._enabled(); self.refresh_context()
        return self.signals.start_obs(port, password)

    def review_arm(self, public=False):
        self._enabled(); self.refresh_context()
        return self.link.review(action="arm", public=bool(public))

    def arm_link(self, public=False, review=None):
        self._enabled(); self.refresh_context()
        if review is None:
            return self.review_arm(public)
        result = self.link.arm(review=review, allow_public=bool(public))
        self.announce("Avatar Link armed for the reviewed contract. Public avatar parameters have their own sharing policy.")
        return result

    def review_parameter(self, name, value):
        self._enabled(); self.refresh_context()
        return self.link.review(action="send", parameter=name, value=value)

    def send_parameter(self, review):
        self._enabled(); self.refresh_context()
        result = self.link.send(review["parameter"], review["value"], owner="manual", review=review)
        self.announce("Parameter sent; observed feedback and actual module operation are separate evidence.")
        return result

    def set_signal_mapping(self, parameter, signal_key, enabled=True):
        self.refresh_context()
        declared = next((p for p in (self.manifest or {}).get("parameters", []) if p["name"] == parameter), None)
        if not declared or declared.get("direction") != "in":
            raise ValueError("Choose an input parameter declared by this manifest.")
        if not isinstance(signal_key, str) or not signal_key or len(signal_key) > 128:
            raise ValueError("Choose a named local signal.")
        updated = dict(self.routes)
        if enabled:
            updated[parameter] = signal_key
        else:
            updated.pop(parameter, None)
        if len(updated) > 64:
            raise ValueError("Choose at most 64 explicit signal mappings.")
        old = self.store.list("routes", self.avatar_id, limit=1)
        self.store.save("routes", self.avatar_id, {"mappings": updated}, old[0]["id"] if old else None)
        self.routes, self.routes_enabled = updated, False
        self.announce("Local mapping saved. Review and enable routing for this session separately.")

    def enable_signal_routes(self, enabled, *, allow_simulated=False):
        self._enabled(); self.refresh_context()
        if enabled and not self.link.snapshot().get("armed"):
            raise ValueError("Arm the matching Avatar Link contract before enabling provider routing.")
        self.routes_enabled = bool(enabled)
        self.allow_simulated_routes = bool(enabled and allow_simulated)
        self.announce("Selected provider routes enabled." if enabled else "Provider routing paused.")

    def review_toolkit_routes(self):
        from avatar_signals import TOOLKIT_SIGNAL_MAPPINGS
        self.refresh_context()
        inputs = {p["name"] for p in (self.manifest or {}).get("parameters", []) if p["direction"] == "in"}
        selected = {name: signal for name, signal in TOOLKIT_SIGNAL_MAPPINGS.items() if name in inputs}
        if not selected:
            raise ValueError("This manifest has no matching starter module inputs.")
        return self._review("routes", {"mappings": dict(self.routes, **selected), "starter_mappings": selected,
            "notice": "Save these exact local mappings. Sources still need explicit setup; routing remains off."})

    def save_toolkit_routes(self, review):
        data = self._consume(review, "routes")
        mappings = data["mappings"]
        if len(mappings) > 64:
            raise ValueError("Choose at most 64 explicit signal mappings.")
        old = self.store.list("routes", self.avatar_id, limit=1)
        self.store.save("routes", self.avatar_id, {"mappings": mappings}, old[0]["id"] if old else None)
        self.routes, self.routes_enabled = mappings, False
        self.announce("Reviewed starter mappings saved. Provider routing remains off until you enable it.")
        return deepcopy(mappings)

    def set_recording(self, enabled):
        self.refresh_context()
        self.recording = bool(enabled)
        self.announce("Selected parameter trace recording enabled." if enabled else "Trace recording stopped; saved records retained.")

    def add_bookmark(self, label="Avatar incident"):
        self.refresh_context()
        snapshot = self.link.snapshot()
        evidence = []
        size = 0
        for row in self.store.list("observation", self.avatar_id, limit=50):
            length = len(json.dumps(row, ensure_ascii=False, allow_nan=False).encode("utf-8"))
            if size + length > 128 * 1024:
                break
            evidence.append(row)
            size += length
        result = self.store.save("bookmark", self.avatar_id, {
            "title": str(label)[:200], "recorded_at": time.time(),
            "manifest_revision": self.context["manifest_revision"], "build_id": self.context["build_id"],
            "run_id": self.active_run_id, "world_id": self.context["world_id"],
            "link_state": str(snapshot.get("state", "Unknown")),
            "evidence": list(reversed(evidence)), "sharing": "Local only"})
        crash = self.app.sidebar.pages.get("Crash & Diagnostics")
        if crash and not self.app.demo:
            crash.service.offer("manual", "vrc_eye", {"reason": "manual", "count": len(evidence), "category": "VRC Eye"})
        self.announce("Local avatar bookmark saved. Only a count/category marker was offered to Black Box.")
        return result

    def _review(self, kind, data):
        token = uuid.uuid4().hex
        review = {"id": token, "kind": kind, "context": self.guard_token,
                  "expires": time.monotonic() + 30, "data": deepcopy(data)}
        if len(self._reviews) >= 32:
            self._reviews.pop(next(iter(self._reviews)))
        self._reviews[token] = deepcopy(review)
        return review

    def _consume(self, review, kind):
        self.refresh_context()
        saved = self._reviews.pop(review.get("id"), None) if isinstance(review, dict) else None
        if (not saved or saved != review or saved["kind"] != kind or saved["context"] != self.guard_token
                or time.monotonic() >= saved["expires"]):
            raise ValueError("This review changed or expired. Review again for the current avatar.")
        return saved["data"]

    def review_profile(self, profile_id):
        self.refresh_context()
        profile = self.store.get(profile_id)
        if not profile or profile["kind"] != "profile" or profile["avatar_id"] != self.avatar_id:
            raise ValueError("Choose a runtime profile for this avatar.")
        if not self.manifest:
            raise ValueError("Import a manifest before reviewing a runtime profile.")
        if profile["data"].get("account_id") not in (None, "", self.context["account_id"]):
            raise ValueError("This runtime profile belongs to another account.")
        preview = self.workflows.preview_profile(profile["data"], self.manifest)
        return self._review("profile", {"profile": profile, "preview": preview})

    def apply_profile(self, review):
        self._enabled()
        data = self._consume(review, "profile")
        results = [{"parameter": row["parameter"], "status": "Not applied", "reason": row["reason"]}
                   for row in data["preview"].get("unsupported", [])]
        for row in data["preview"].get("supported", []):
            name, value = row["parameter"], row["value"]
            try:
                request = self.link.review(action="send", parameter=name, value=value)
                result = self.link.send(name, value, owner="profile", review=request)
                results.append({"parameter": name, "value": value, "result": result})
            except ValueError as error:
                results.append({"parameter": name, "status": "Not applied", "reason": str(error)})
        record = self.store.save("profile_application", self.avatar_id, {"profile_id": data["profile"]["id"],
            "results": results, "context": self.guard_token, "atomic": False,
            "limitation": "OSC sends are not atomic or proof that the avatar applied each value."})
        self.announce("Profile requests recorded individually; inspect partial and unconfirmed results.")
        return record

    def review_profile_restore(self, application_id):
        self._enabled(); self.refresh_context()
        record = self.store.get(application_id)
        if (not record or record["kind"] != "profile_application" or record["avatar_id"] != self.avatar_id
                or record["data"].get("context") != self.guard_token):
            raise ValueError("Choose a profile application from the current armed avatar context.")
        supported, skipped = [], []
        for row in record["data"].get("results", []):
            command = row.get("result", {})
            if not command.get("id"):
                continue
            try:
                review = self.link.review_restore(command["id"])
                supported.append({"command_id": command["id"], "review": review})
            except ValueError as error:
                skipped.append({"parameter": row["parameter"], "reason": str(error)})
        return self._review("profile_restore", {"application_id": application_id,
            "supported": supported, "skipped": skipped,
            "limitation": "Restore only values still owned by this application. Newer changes remain in place."})

    def restore_profile(self, review):
        self._enabled()
        data = self._consume(review, "profile_restore")
        results = list(data["skipped"])
        for row in data["supported"]:
            try:
                results.append(self.link.restore(row["command_id"], review=row["review"]))
            except ValueError as error:
                results.append({"command_id": row["command_id"], "status": "Not restored", "reason": str(error)})
        record = self.store.save("profile_restore", self.avatar_id,
            {"application_id": data["application_id"], "results": results, "context": self.guard_token,
             "limitation": "Best-effort sends; rendered behavior remains unconfirmed."})
        self.announce("Scoped profile restoration recorded. Newer overrides were preserved.")
        return record

    def pending_requests(self):
        self.refresh_context()
        for key in tuple(self._pending):
            try:
                self.link.request(key)
            except ValueError:
                self._pending.pop(key, None)
        return [deepcopy(value) for value in self._pending.values()]

    def review_action(self, request_id):
        self._enabled(); self.refresh_context()
        request = self._pending.get(request_id)
        if not request:
            raise ValueError("This avatar request is no longer current.")
        if self.link.request(request_id) != request:
            raise ValueError("This avatar request changed. Review it again.")
        destination = {}
        if request["action"] == "acknowledge_reminder":
            wellness = self.app.sidebar.pages.get("Wellness")
            if not wellness or not hasattr(wellness, "respond") or not wellness.engine.visible:
                raise ValueError("There are no visible Wellness reminders to acknowledge.")
            destination["reminders"] = list(wellness.engine.visible)
            destination["operation"] = "Acknowledge only these visible local reminders."
        elif request["action"] == "select_profile":
            destination["operation"] = "Open Profiles on the desktop; choose and review a profile separately."
        return self._review("action", {"request": request, "destination": destination})

    def execute_action(self, review):
        self._enabled()
        data = self._consume(review, "action")
        request, destination = data["request"], data["destination"]
        pending = self._pending.pop(request.get("id"), None)
        if pending != request:
            raise ValueError("This request is no longer pending; it is never retried automatically.")
        self.link.request(request["id"])
        if request["action"] == "acknowledge_reminder":
            wellness = self.app.sidebar.pages.get("Wellness")
            if not wellness or list(wellness.engine.visible) != destination.get("reminders"):
                raise ValueError("Visible reminders changed. Review the current reminders before acknowledging them.")
        self.link.resolve_request(request["id"], "accepted", "Confirmed on desktop; destination action pending.")
        action = request.get("action", request.get("kind", ""))
        if action == "diagnostic_bookmark":
            self.add_bookmark("Avatar-requested test marker")
            detail = "Local bookmark saved after desktop confirmation."
        elif action == "safety_profile":
            detail = self.activate_safety()
            self.announce(detail)
            return {"action": action, "detail": detail, "status": "Local protective mode applied"}
        elif action == "request_photo":
            try:
                result = self.request_camera(request_id=request["id"])
            except ValueError as error:
                self.link.resolve_request(request["id"], "failed", str(error))
                raise
            # This starter signal reports broker acceptance, never a completed
            # photograph. It remains subject to the same privacy/writer gates.
            definition = next((p for p in (self.manifest or {}).get("parameters", [])
                               if p["name"] == "EYE_In_CameraAccepted"), None)
            if definition and definition["type"] == "Bool" and definition["direction"] == "in":
                try:
                    acknowledgement = self.link.review("send", "EYE_In_CameraAccepted", True)
                    result["acceptance_signal"] = self.link.send("EYE_In_CameraAccepted", True,
                        owner="test", review=acknowledgement)
                except ValueError as error:
                    result["acceptance_signal"] = {"status": "Unavailable", "reason": str(error)}
            return result
        elif action == "acknowledge_reminder":
            wellness.respond("done", keys=destination["reminders"])
            detail = "The exact reviewed local Wellness reminders were acknowledged."
        elif action == "select_profile":
            if self.panel is None:
                self.link.resolve_request(request["id"], "failed", "Desktop profile tools are unavailable.")
                raise ValueError("Desktop profile tools are unavailable.")
            self.panel.notebook.select(self.panel.pages["Profiles"])
            self.panel.show("Profiles")
            detail = "Profiles opened on the desktop. Choose and review a profile; no values were applied."
        elif action == "pause_effect":
            self.signals.set_media_source("none")
            detail = "Local media provider stopped; avatar neutral state remains subject to delivery."
        else:
            detail = "This action needs an explicit selection in its desktop tool; no action was executed."
            self.link.resolve_request(request["id"], "failed", detail)
            self.announce(detail)
            return {"action": action, "detail": detail, "status": "Not executed"}
        self.link.resolve_request(request["id"], "action_confirmed", detail)
        self.announce(detail)
        return {"action": action, "detail": detail}

    def request_camera(self, request_id=None):
        self._enabled(); self.refresh_context()
        if self._camera_busy or time.monotonic() - self._last_camera < 3:
            raise ValueError("A camera request is pending or cooling down; no repeat was sent.")
        snapshot = self.link.snapshot()
        if not snapshot.get("armed"):
            raise ValueError("Arm Avatar Link before using its camera request route.")
        shared = getattr(self.app, "osc_controller", None)
        if shared is not None:
            result = shared.camera_capture(owner="avatar-camera")
            self._last_camera = time.monotonic()
            self._shared_camera = (self.guard_token, request_id, result["id"])
            self._camera_busy = True
            return result
        from camera_capture import request_photo
        token = self.guard_token
        target_port = snapshot["target_port"]
        stop = threading.Event()
        self._camera_stop, self._camera_busy, self._last_camera = stop, True, time.monotonic()
        def worker():
            try:
                request_photo(target_port, stop)
                result = ("Camera request cancelled; delivery may be partial. No retry." if stop.is_set()
                          else "Capture requested; completion unconfirmed.")
                status = "failed" if stop.is_set() else "sent"
            except (OSError, ValueError):
                result = "Camera delivery failed or may be partial. No automatic retry."
                status = "failed"
            try:
                self._camera_results.put_nowait((token, request_id, status, result))
            except queue.Full:
                pass
        threading.Thread(target=worker, daemon=True, name="VRC-Eye-Avatar-Camera").start()
        return {"status": "Requested", "completion": "Unconfirmed"}

    def activate_safety(self):
        shared = getattr(self.app, "osc_controller", None)
        if shared is not None:
            shared.stop_controls("VRC Eye Safety Mode activated")
        self.signals.set_media_source("none")
        self.routes_enabled = False
        self.disconnect_link()
        self.clear_overlay()
        world = getattr(getattr(self.app, "world_view", None), "creator", None)
        if world:
            world.clear_overlay()
        peer = getattr(self.app, "peer_service", None)
        if peer:
            peer.private_mode()
        wellness = self.app.sidebar.pages.get("Wellness")
        if wellness:
            if not self.safety_active:
                self._safety_previous = wellness.engine.safety_busy
            wellness.engine.safety_busy = True
            wellness.runtime.display({})
        self.safety_active = True
        return "Local protective mode: media stopped, Avatar Link paused, creator cards hidden, peer sharing stopped, and available Wellness reminders held. Remote avatar visuals are not guaranteed reset."

    def leave_safety(self):
        wellness = self.app.sidebar.pages.get("Wellness")
        if wellness and self._safety_previous is not None:
            wellness.engine.safety_busy = self._safety_previous
        self.safety_active = False
        self._safety_previous = None
        self.announce("Protective hold released. Avatar Link, media and sharing remain off until explicitly enabled.")

    @property
    def peer_coordinator(self):
        service = getattr(self.app, "peer_service", None)
        if service is None:
            raise ValueError("VRC Eye peer services are unavailable.")
        if service is not self._peer_service:
            self._peer_service = service
            self._peer_coordinator = AvatarPeerCoordinator(service)
        return self._peer_coordinator

    def show_overlay(self, step="", status="", **settings):
        self._enabled(); self.refresh_context()
        world = getattr(getattr(self.app, "world_view", None), "creator", None)
        if world:
            world.clear_overlay()
        wellness = self.app.sidebar.pages.get("Wellness")
        runtime = getattr(wellness, "runtime", None)
        if self.overlay.runtime is not runtime:
            self.clear_overlay()
        self.overlay.runtime = runtime
        self.app._creator_overlay_owner = "avatar"
        return self.overlay.show(self.avatar_id, step=step, status=status or str(self.link.snapshot().get("state", "Unknown")), **settings)

    def clear_overlay(self):
        if getattr(self.app, "_creator_overlay_owner", None) == "world":
            runtime, self.overlay.runtime = self.overlay.runtime, None
            try:
                return self.overlay.clear()
            finally:
                self.overlay.runtime = runtime
        self.app._creator_overlay_owner = None
        return self.overlay.clear()

    def tick(self):
        if self.closed:
            return
        library_page = getattr(self.panel, "library_page", None)
        if library_page is not None:
            library_page.guard(library_page.tick)
        try:
            self.refresh_context()
            snapshot = self.link.tick()
            self.refresh_context()
            snapshot = self.link.snapshot()
            for request in self.link.drain_requests():
                if len(self._pending) < 32:
                    self._pending[request["id"]] = request
            now = time.monotonic()
            if now - self._last_sample >= 1:
                self._last_sample = now
                wellness = self.app.sidebar.pages.get("Wellness")
                self.signals.runtime = getattr(wellness, "runtime", None)
                afk = next((item for item in snapshot.get("parameters", [])
                            if item.get("name") == "AFK" and item.get("valid") is True), None)
                engine = getattr(wellness, "engine", None)
                quiet = bool(getattr(engine, "dnd", False) or getattr(engine, "focus", False)
                             or getattr(engine, "safety_busy", False)) if engine is not None else None
                self.signals.observe_availability(native_afk=afk["value"] if afk else None,
                                                  companion_quiet=quiet, seconds=2)
                resources = self.app.sidebar.pages.get("Performance & Security")
                self.signals.resource_service = getattr(resources, "service", None)
                self.signal_snapshot = self.signals.sample()
                if self.routes_enabled:
                    # Keep parameter->signal in the saved form so one provider
                    # can feed multiple separately declared destinations.
                    self.route_results = []
                    for parameter, signal_key in self.routes.items():
                        self.route_results.extend(self.signals.route(self.link, {signal_key: parameter},
                            allow_public=bool(snapshot.get("public_allowed")),
                            allow_simulated=self.allow_simulated_routes))
                if self.recording and now - self._last_record >= 2:
                    self._last_record = now
                    self._record_trace(snapshot)
            try:
                shared_camera = getattr(self, "_shared_camera", None)
                shared = getattr(self.app, "osc_controller", None)
                if shared is not None and shared_camera:
                    token, request_id, action_id = shared_camera
                    state = shared.action_status(action_id)
                    if token != self.guard_token:
                        shared.cancel_owner("avatar-camera")
                        self._camera_busy, self._shared_camera = False, None
                    elif str(state.get("status", "")).lower() in ("sent", "observed", "failed", "cancelled", "expired"):
                        self._shared_camera, self._camera_busy = None, False
                        status = "sent" if str(state["status"]).lower() in ("sent", "observed") else "failed"
                        detail = "Capture command sent; photograph completion unconfirmed." if status == "sent" else "Camera request cancelled or failed; no automatic retry."
                        if request_id:
                            self.link.resolve_request(request_id, status, detail)
                        self.announce(detail)
                token, request_id, status, result = self._camera_results.get_nowait()
            except queue.Empty:
                pass
            else:
                self._camera_busy = False
                if token == self.guard_token:
                    if request_id:
                        self.link.resolve_request(request_id, status, result)
                    self.announce(result)
            if self.panel and now - self._last_render >= 1:
                self._last_render = now
                self.panel.refresh()
        except (ValueError, OSError, sqlite3.Error) as error:
            self.routes_enabled = False
            self.recording = False
            self.message = "Avatar creator paused: " + str(error)
            if self.panel:
                self.panel.status.set(self.message)

    def _record_trace(self, snapshot):
        parameters = snapshot.get("parameters", [])
        selected = {item["name"]: deepcopy(item) for item in parameters if item["name"] in self.routes}
        self.store.save("observation", self.avatar_id, {"recorded_at": time.time(),
            "manifest_revision": self.context["manifest_revision"], "build_id": self.context["build_id"],
            "run_id": self.active_run_id, "parameters": selected,
            "link_state": str(snapshot.get("state", "Unknown")), "quality": "Local adapter observations",
            "limitation": "Selected parameter feedback is not proof of rendered behavior or remote viewers' state."})
        self.store.prune_observations(avatar_id=self.avatar_id, keep=2000)

    def close(self):
        if self.closed:
            return
        self.closed = True
        self._camera_stop.set()
        shared = getattr(self.app, "osc_controller", None)
        if shared is not None:
            shared.cancel_owner("avatar-camera")
        self.link.disconnect()
        self.signals.close()
        self.clear_overlay()
        if self.panel:
            self.panel.close()
        self.store.close()
