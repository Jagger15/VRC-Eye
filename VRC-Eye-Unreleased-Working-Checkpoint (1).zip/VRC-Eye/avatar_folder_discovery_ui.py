"""Avatar Library folder-discovery panel, using its single shared task slot."""
from __future__ import annotations

import json

from avatar_folder_discovery import (ENTRY_LIMIT, DEPTH_LIMIT, CANDIDATE_LIMIT,
                                     READ_LIMIT, SessionRescan, select_source,
                                     validate_source, scan_folder, inspect_candidate,
                                     register_candidate)
from avatar_details import format_download_size
from companion_ui import Table, button, choice, line


class FolderDiscoveryPanel:
    def __init__(self, page, parent):
        self.page, self.parent = page, parent
        self.source = None
        self.candidates = []
        self.context = self._context()
        self.scheduler = SessionRescan()
        self.interval = page.tk.StringVar(value="60")
        self.role = page.tk.StringVar(value="asset")
        self.folder_label = page.tk.StringVar(value="Choose a folder to inspect. No default folder is scanned.")
        self.status = page.tk.StringVar(value="Automatic rescanning is off.")
        self._owned_job = None
        self.closed = False
        page.ttk.Label(parent, text="Discover possible local avatar files inside one folder you authorize. A selected VRChat cache folder is supported, but cache entries may be incomplete or belong to worlds. Avatar identity and permission remain unknown.", wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=6)
        page.ttk.Label(parent, textvariable=self.folder_label, wraplength=940).pack(anchor="w", pady=4)
        row = line(page, parent)
        button(page, row, "Choose folder…", self.choose)
        button(page, row, "Scan folder", self.scan)
        button(page, row, "Stop", self.stop)
        row = line(page, parent)
        page.ttk.Label(row, text="Rescan every (seconds)").pack(side="left", padx=(0, 6))
        choice(page, row, self.interval, ("30", "60", "300"), self.interval_changed, width=7)
        button(page, row, "Enable session rescans", self.enable)
        self.table = Table(page, parent, (("file", "Possible file", 230), ("kind", "Evidence", 270),
                                        ("size", "Size", 100), ("avatar", "Avatar", 250)), height=10)
        row = line(page, parent)
        page.ttk.Label(row, text="Association role").pack(side="left", padx=(0, 6))
        choice(page, row, self.role, ("asset", "source", "package"), width=10)
        button(page, row, "Inspect and review association…", self.associate)
        page.ttk.Label(parent, textvariable=self.status, wraplength=940).pack(anchor="w", pady=5)
        page.ttk.Label(parent, text=f"Each scan: at most {ENTRY_LIMIT:,} entries, depth {DEPTH_LIMIT}, {CANDIDATE_LIMIT} candidates and {READ_LIMIT // 1024} KiB of headers. Links and reparse points are skipped. Rescans only stage candidates while this panel is visible; they stop when the folder, account, avatar selection or privacy changes. Nothing is decrypted, imported, moved or deleted.", wraplength=940, style="Muted.TLabel").pack(anchor="w", pady=5)

    def _context(self):
        return (self.page.context(), self.page.selected_id, bool(self.page.privacy.get()),
                bool(self.page.show_paths.get()))

    def _token(self):
        return (self._context(), self.source)

    def _visible(self):
        return (not self.closed and not self.page.closed and self.page.section.get() == "Folder discovery"
                and bool(self.parent.winfo_viewable()))

    def _require(self):
        self.page.writable()
        if self.closed: raise ValueError("Folder discovery is closed.")
        if self._context() != self.context:
            self.clear()
            raise ValueError("The workspace or selection changed. Choose the folder again.")
        return validate_source(self.source)

    def choose(self):
        self.page.writable()
        if self.page.job: raise ValueError("Wait for the current avatar task to stop first.")
        from tkinter import filedialog
        token = self._context()
        selected = filedialog.askdirectory(parent=self.page.app.root, title="Choose one folder you are authorized to inspect", mustexist=True)
        if token != self._context():
            self.clear()
            raise ValueError("The workspace changed while choosing a folder.")
        if not selected: return
        source = select_source(selected)
        if not self.page.review("Authorize folder discovery", f"Folder: {source.path}\n\nRead only files within this selected folder, within the displayed scan limits. Files and cache names do not establish permission, avatar identity or recoverable source. Candidates stay in this session until you explicitly inspect and associate one with a catalog avatar. Automatic rescans require a separate choice.", "Use this folder"):
            return
        if token != self._context():
            self.clear()
            raise ValueError("The workspace changed during folder review.")
        validate_source(source)
        self.clear()
        self.source = source
        self.folder_label.set(source.path if self.page.show_paths.get() else "Authorized folder selected · local path hidden")
        self.status.set("Folder authorized for this session. Select Scan folder.")

    def scan(self, automatic=False):
        self._require()
        if self.page.job: raise ValueError("Wait for the current avatar task to stop first.")
        source, token = self.source, self._token()
        def done(result):
            self._owned_job = None
            if token != self._token() or not self._visible():
                self.scheduler.stop()
                return
            self.candidates = result["candidates"]
            self.table.set(self.candidates, lambda r: (r["relative_path"] if self.page.show_paths.get() else r["name"], r["kind"], format_download_size(r["size"]), "Unknown"))
            boundary = " · Scan limit reached; results are partial" if result["truncated"] or result["depth_skipped"] else ""
            periodic = " · Session rescans enabled" if self.scheduler.enabled else " · Automatic rescanning off"
            self.status.set(f"{len(self.candidates)} candidates · {result['entries']} entries · {result['skipped']} skipped{boundary}{periodic}. Nothing registered.")
        self.page.start_task(lambda stop, progress: scan_folder(source, stop=stop, progress=progress), done,
                             operation="Rescan authorized folder" if automatic else "Scan authorized folder")
        self._owned_job = self.page.job

    def enable(self):
        self._require()
        if not self._visible(): raise ValueError("Open Folder discovery before enabling rescans.")
        if self.page.job: raise ValueError("Wait for the current avatar task to stop first.")
        self.scheduler.enable(self._token(), int(self.interval.get()))
        self.status.set("Session rescans enabled every " + self.interval.get() + " seconds while this panel stays visible. Candidates only; each association needs review.")

    def interval_changed(self):
        self.stop()
        self.status.set("Interval changed. Enable session rescans again to use it.")

    def stop(self):
        self.scheduler.stop()
        if self._owned_job is not None and self.page.job is self._owned_job:
            self.page.cancel()
        self._owned_job = None
        self.status.set("Automatic rescanning stopped. No candidate was registered.")

    def clear(self):
        self.stop()
        self.source = None
        self.candidates = []
        self.context = self._context()
        self.table.set([], lambda r: ())
        self.folder_label.set("Choose a folder to inspect. No default folder is scanned.")

    def close(self):
        self.clear()
        self.closed = True

    def associate(self):
        self._require()
        selected = self.table.selected()
        if selected is None: raise ValueError("Select a discovered candidate first.")
        avatar = self.page.selected()["id"]
        scope, token, source, role = self.page.scope, self._token(), self.source, self.role.get()
        if role not in ("asset", "source", "package"): raise ValueError("Select a file association role.")
        # Automatic rescans cannot replace the staged selection during review.
        self.scheduler.stop()
        def check():
            self.page.writable()
            if token != self._token() or self.page.selected()["id"] != avatar or not self._visible():
                raise ValueError("The avatar, source or workspace changed. Inspect and review again.")
        def done(evidence):
            self._owned_job = None
            check()
            details = {"workspace": scope, "explicit_avatar_association": avatar, "role": role,
                       "file": evidence["path"], "size": evidence["size"], "sha256": evidence["sha256"],
                       "evidence": selected["kind"]}
            if not self.page.review("Associate reviewed discovery candidate", json.dumps(details, indent=2) + "\n\nConfirm that you own or have permission to preserve this content and that this is the intended catalog association. The scanner has not identified an avatar, established ownership, decrypted a cache entry or recovered source. Save a reference only; the original remains untouched.", "Register reference"):
                return
            check()
            register_candidate(self.page.library, scope, avatar, source, selected, evidence, role=role, check=check)
            self.page.refresh()
            self.status.set("Reviewed file reference registered to the chosen avatar. Original unchanged. Automatic rescanning remains off.")
        self.page.start_task(lambda stop, progress: inspect_candidate(source, selected, stop=stop, progress=progress),
                             done, avatar=avatar, operation="Inspect discovery candidate")
        self._owned_job = self.page.job

    def tick(self):
        if self.closed: return
        if self._context() != self.context:
            self.clear()
            return
        if not self._visible() and (self.scheduler.enabled or self._owned_job is not None):
            self.stop()
            self.status.set("Folder discovery is no longer visible. Its task and automatic rescans were stopped.")
            return
        if self._owned_job is not None and self.page.job is not self._owned_job:
            # A failed/cancelled shared job has no completion callback. End the
            # periodic grant instead of silently repeating a failing read.
            self._owned_job = None
            self.scheduler.stop()
            self.status.set("Discovery task stopped or failed. Automatic rescanning is off; inspect the workspace status before retrying.")
        enabled = self.scheduler.enabled
        if self.scheduler.due(self._token(), visible=self._visible(), busy=self.page.job is not None):
            try:
                self.scan(automatic=True)
            except (OSError, ValueError):
                self.scheduler.stop()
                self.status.set("The source is unavailable or changed. Automatic rescanning stopped; choose and scan the folder again.")
        elif enabled and not self.scheduler.enabled:
            self.status.set("Automatic rescanning stopped because Folder discovery is no longer visible or its context changed.")
