# VRC Eye 1.20.0 — Development checkpoint 5

Development 5 adds **separate SDK/VCC download-only workspaces, paged historical
Unity editor browsing, and remappable main-window navigation shortcuts**. This
is not the completed 1.20 roadmap. Development 4's Photos/Invite Me and earlier
Avatar Library, Social/Accounts, VCC/creator, accessibility and other tools remain.

The exact baseline is the Development 4 ZIP, SHA-256:
`986953c3f4f09b0ebc3f9f13fa9f17c35a559620ee8a9e6446a6b842aaffbde7`.
Its bytes are unchanged. No source was reconstructed from progress claims.

## Install this development checkpoint

Close the previous running copy. Back up VRC Eye's local settings/databases and
keep the previous application folder. Extract the entire Development 5 ZIP into
a **new folder**, open `VRC-Eye`, and run **Start.cmd**. Do not run two versions
against the same databases. This is the source application with its existing
launcher, not a newly compiled/signed Windows executable.

All four launchers and requirements.txt remain unchanged. The prior independent
remembered username/password controls and scoped Enter/keypad Enter sign-in remain.
No runtime dependency or silent app updater is added. Downloaded artifacts are
never installed, run, extracted, or copied into a Unity project automatically.

## Delivered features

**Advanced → SDK downloads** and **Advanced → VCC downloads** are separate entry
points into the same local public-release cache, running-task slot and receipts.
Each has Releases, Downloads & Activity, and Sources & Limits. The command palette
includes both plus download history/source guidance; the Keyboard route brings
the total to 103 named tool routes. Views remain reachable through ordinary buttons.

SDK metadata accepts official Base/Avatars/Worlds package records. VCC metadata
accepts published supported assets from the publisher's public GitHub releases
list. Exact versions, declared dependencies/Unity fields, available publisher
size/hash evidence, prerelease visibility and loaded-page filters remain separate
from compatibility or installation claims. Queries never include VRChat credentials.
A direct stable-VCC browser handoff is explicitly unpinned and may start a browser
download whose completion is not observed here.

**Unity 2017.4, 2018.4, 2019.4 and 2022.3** can be browsed through exact patch and
platform records with explicit provider-page navigation. This is not a fixed
latest-patch list or a fabricated VCC compatibility table. Unity downloads use
reviewed browser handoffs, not in-app saves or Hub installs. Removed/unpublished
releases and complete legacy SDK `.unitypackage` coverage are not promised.

**SDK/VCC file saving** uses frozen one-use reviews, explicit destinations, source/
selection/account-context checks, a 2 GiB bound, validated no-auth redirects, hash/
length checks and the existing no-overwrite saver. Parent replacement, unsupported
responses, canceled requests and checksum mismatches are handled before commit.
Opening a page or filtering its cache does not download anything. No implicit
installation, migration, arbitrary repository, or background release polling exists.

**Download activity** records outcomes before dispatch and after completion. A
failed initial receipt prevents a request; an unsaved final receipt stays available
for a local-only save retry. Interrupted/uncertain results are not automatically
retried or relabeled as installed. Explicit file rechecks and selected path-free
exports are available; clearing completed history never deletes artifacts.

**VRC Eye → Accessibility → Keyboard** adds ten named navigation assignments with
conflict detection, reserved-key exclusions, modal chord capture, reviewed changes,
profiles, undo, defaults and disable controls. Defaults retain Ctrl+K/Ctrl+Comma;
the other actions are initially unassigned. A private root-widget binding layer
preserves Text input for handled chords; dialogs and sign-in Enter remain separate.
No global hotkeys, scripts, gameplay inputs or account actions can be assigned.
Normal settings persist before becoming active; Demo/Safe changes are session-only.

**Shared focus scrolling** reuses the existing account workspace behavior through
shared scroll panes. New SDK/VCC and keyboard rows stack when they no longer fit.
The new workflows were exercised at 100% and 200% text/control scale. This does not
certify complete application/header/custom-widget reflow or screen-reader support.

Read **RELEASE_DOWNLOADS_1_20.md** and **KEYBOARD_SHORTCUTS_1_20.md** for behavior,
limits, storage, recovery, source references and complete operation steps.

## Important verification boundary

Live metadata endpoints were unreachable in this environment. Provider adapters
were implemented against official documented contracts and controlled fixtures;
real hosted metadata, real SDK/VCC artifact downloads, CDN redirects and Unity
browser downloads were **not** verified. A native preview saved synthetic fixture
bytes through the real reviewed flow; those bytes are not an SDK or installer.

No real VRChat account/credential, live VRChat/VRCX action, native Windows run,
installed Unity/VPM execution, C# compile, screen-reader or XR interoperability
test occurred. No ARC binaries, copied utility source, installer or new runtime
dependency was introduced. Native Linux and passing fixtures are not substitutes
for those platform/service tests.

## Storage and returning to an earlier build

The existing companion database gains only namespaced `release_pages_v5` and
`release_jobs_v5` tables plus `ui.shortcuts.v1` options. Public catalogs/download
receipts are local OS-user data, not a completed multi-account system. Destinations
are stored locally even when hidden in the page. Cache/filter privacy is not
an encryption or application-wide streaming guarantee.

A failed or interrupted process may leave a temporary or completed download.
Inspect/recheck deliberately; no file is automatically removed or retried.
Restore/check a damaged database before retrying local record recovery. A data
backup remains essential; older code ignoring new names does not certify every
backward-compatibility case. Return to the preserved earlier application folder
only after closing the running build.

## Remaining roadmap

Retained multiple sessions/full account isolation, broader live Social features,
photo watching/physical organization/sharing, advanced 3D/Unity repair/recovery,
deeper VCC migration/providers and full accessibility/XR remain pending. Modern
SDK/VCC download tools are now present, but complete legacy archives, installers,
a compatibility resolver, signature verification and automatic dependency updating
are not represented as completed or implicitly approved.

The implementation matrix distinguishes these boundaries. Historical checkpoint
notes and BASELINE_DEV4_VALIDATION.json remain in the package. The final clean-
extracted checks and their limitations are recorded in BUILD_VALIDATION.json.

## Final clean-extracted validation result

**3,488 tests and 1,141 subtests passed**, with zero failures, errors or
skips, in 143.27 seconds. One pre-existing TestListener collection
warning remains. The external-socket guard recorded zero blocked attempts.
This is **193 additional tests**, including **37 new native Tk workflow cases**.
All **336 Python files** passed Python 3.10 grammar checks.

The final archive contains **454 files** and retains every one of the **442
Development 4 paths**. It adds 12 paths and modifies 20 baseline files. All four
launchers and requirements.txt remain byte-identical. The final executable source,
tests, runtime catalogs and Unity content match the clean-tested copy; only final
validation metadata and these result paragraphs were finalized afterward.

Native previews use synthetic catalogs only. A reviewed transfer saved 5,157 bytes
of non-executable fixture data with its matching hash, with zero native Tk callback
errors, external socket attempts, OSC sends or active bridge listener. It used one
HTTP response fixture, no live provider request and no installer execution.
