"""Read-only, bounded node-local geometry observations. Not Unity culling bounds."""
from dataclasses import dataclass,asdict
import json
import time
from avatar_scene import vector,integer,transform,bounds
from avatar_scene_pose import inverse
from avatar_animation import sample
from avatar_library_files import check_cancel

MAX_SAMPLES=128
MAX_VERTEX_VISITS=4_000_000


def box(value):
    if not isinstance(value,(list,tuple)) or len(value)!=2:raise ValueError('Bounds need minimum and maximum XYZ values.')
    lo,hi=(vector(v,3) for v in value)
    if any(a>b for a,b in zip(lo,hi)):raise ValueError('Bounds minimum must not exceed maximum.')
    return lo,hi


def union(boxes):
    boxes=tuple(box(v) for v in boxes)
    if not boxes:raise ValueError('No geometry bounds were observed.')
    return tuple(tuple(fn(b[side][k] for b in boxes) for k in range(3)) for side,fn in ((0,min),(1,max)))


def expand(value,margin):
    lo,hi=box(value);margin=vector(margin,3)
    if any(v<0 or v>1000 for v in margin):raise ValueError('Each per-side margin must be from 0 to 1,000 source units.')
    return box((tuple(a-m for a,m in zip(lo,margin)),tuple(b+m for b,m in zip(hi,margin))))


def contains(outer,inner):
    outer,inner=box(outer),box(inner)
    return all(outer[0][k]<=inner[0][k] and outer[1][k]>=inner[1][k] for k in range(3))


def times(start,end,count):
    start,end=vector([start,end],2);count=integer(count,1,MAX_SAMPLES)
    if start>end or end-start>3600 or abs(start)>86400 or abs(end)>86400:raise ValueError('Choose an increasing range of at most one hour.')
    if start==end:
        if count!=1:raise ValueError('A single-time observation needs one sample.')
        return (start,)
    if count<2:raise ValueError('A range needs at least two endpoint samples.')
    return tuple(end if i==count-1 else start+(end-start)*i/(count-1) for i in range(count))


@dataclass(frozen=True)
class Observation:
    schema:str
    source_sha256:str
    source_bytes:int
    node:int
    node_name:str
    space:str
    imported:tuple
    displayed:tuple
    sampled:tuple
    observed:tuple
    reference:tuple
    reference_kind:str
    proposed:tuple
    margin:tuple
    clip:str
    sample_times:tuple
    effective_times:tuple
    sample_bounds:tuple
    reference_contains_observed:bool
    limitations:tuple


def inspect(scene,node,*,displayed=None,clip=None,start=None,end=None,count=2,margin=(0,0,0),reference=None,explicit=None,stop=None,progress=None):
    """Each pose uses its own node inverse; no inverse-transform of a world AABB."""
    check_cancel(stop);deadline=time.monotonic()+15
    if type(node) is not int or node not in {n.index for n in scene.nodes}:raise ValueError('Select a node from the imported scene.')
    displayed=scene if displayed is None else displayed
    if displayed.sha256!=scene.sha256 or tuple((n.index,n.parent) for n in displayed.nodes)!=tuple((n.index,n.parent) for n in scene.nodes):raise ValueError('Displayed pose does not match the imported scene.')
    parts=[p for p in scene.parts if p.node==node]
    if not parts:raise ValueError('Choose a node that owns mesh geometry, not just a parent subtree.')
    sample_times=();effective=();clip_name='Imported and displayed pose only'
    if clip is not None:
        if scene.animations is None:raise ValueError('This scene has no prepared animation clips.')
        c=scene.animations.clips[integer(clip,0,len(scene.animations.clips)-1)]
        if c.reason:raise ValueError(c.reason)
        sample_times=times(c.start if start is None else start,c.end if end is None else end,count)
        if sample_times[0]<c.start or sample_times[-1]>c.end:raise ValueError('Sample times must stay within the selected clip.')
        clip_name=c.name
        if c.frames:effective=tuple(max(f.time for f in c.frames if f.time<=t) for t in sample_times)
        else:effective=sample_times
    # Deforming a full scene is also work, even when one renderer is inspected.
    visits=sum(len(p.vertices) for p in scene.parts)*len(sample_times)+sum(len(p.vertices) for p in parts)*(2+len(sample_times))
    if visits>MAX_VERTEX_VISITS:raise ValueError('Bounds sampling exceeds four million vertex visits. Reduce the sample count or use a smaller scene.')
    def local(pose):
        check_cancel(stop)
        matrix=inverse(next(n.matrix for n in pose.nodes if n.index==node));points=[]
        for p in pose.parts:
            if p.node!=node:continue
            for i,v in enumerate(p.vertices):
                if i%256==0:
                    check_cancel(stop)
                    if time.monotonic()>deadline:raise ValueError('Bounds sampling exceeded 15 seconds. Reduce its scope.')
                points.append(transform(matrix,v))
        return bounds(points)
    imported=local(scene);current=local(displayed);samples=[]
    for i,t in enumerate(sample_times):
        check_cancel(stop);samples.append(local(sample(scene,clip,t,stop=stop)))
        if progress:progress(i+1,len(sample_times))
    measured=union((imported,current,*samples));ref=imported if reference is None else box(reference)
    margin=vector(margin,3);proposed=expand(union((measured,ref)),margin)
    if explicit is not None:
        if any(margin):raise ValueError('Use either explicit bounds or margins, not both.')
        proposed=box(explicit)
        if not contains(proposed,measured):raise ValueError('Explicit bounds exclude observed geometry; enlarge them before review.')
    check_cancel(stop)
    limitations=(
        'Node-local geometry only. GLB/FBX previews do not supply Unity renderer-local culling bounds or the Unity root-bone frame.',
        'Only listed poses and times are covered. Between-sample motion, other clips, IK, PhysBones, cloth, constraints, custom scripts and shader deformation are unverified.',
        'No source, renderer, mesh, runtime or culling setting is changed. This proposal does not establish FPS improvement.',
        'Margins are per side in source units; units are exporter-defined for GLB and normalized meters for FBX. Zero/near-singular transforms stop sampling.')
    return Observation('vrc-eye.node-bounds.v1',scene.sha256,scene.source_bytes,node,next(n.name for n in scene.nodes if n.index==node),'per-pose node local',imported,current,union(samples) if samples else (),measured,ref,'manually entered reference' if reference is not None else 'imported geometry; not renderer bounds',proposed,margin,clip_name,sample_times,effective,tuple(samples),contains(ref,measured),limitations)


def document(observation):
    if not isinstance(observation,Observation):raise ValueError('Review a completed bounds observation first.')
    return json.dumps(asdict(observation),indent=2,ensure_ascii=False,allow_nan=False)+'\n'


def export(observation,path):
    from creator_projects import assert_no_links
    target=assert_no_links(path)
    if target.suffix.lower()!='.json':raise ValueError('Choose a new JSON report file.')
    data=document(observation).encode('utf-8')
    if len(data)>1024*1024:raise ValueError('Bounds report exceeds one MiB.')
    with target.open('xb') as stream:stream.write(data)
    return str(target)


def describe(o):
    def fmt(b):return 'min '+repr(b[0])+' / max '+repr(b[1])
    lines=[o.node_name+' · '+o.space,'Imported geometry: '+fmt(o.imported),'Displayed pose: '+fmt(o.displayed)]
    if o.sampled:lines.append('Sampled geometry: '+fmt(o.sampled))
    lines +=['Reference ('+o.reference_kind+'): '+fmt(o.reference),
        'Reference covers observed geometry: '+('Yes' if o.reference_contains_observed else 'No'),
        'Proposed bounds (read-only): '+fmt(o.proposed),'Per-side margins: '+repr(o.margin),
        'Sample scope: '+o.clip+'; '+str(len(o.sample_times))+' requested samples.',
        'Requested seconds: '+repr(o.sample_times),'Effective seconds: '+repr(o.effective_times),*o.limitations]
    return '\n'.join(lines)
